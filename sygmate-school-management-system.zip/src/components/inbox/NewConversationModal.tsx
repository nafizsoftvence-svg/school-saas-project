import React, { useState, useEffect } from 'react';
import {
  X,
  Send,
  Paperclip,
  FileText,
  Trash2,
  AlertCircle,
  Save,
  Users,
  GraduationCap
} from 'lucide-react';
import { EligibleRecipient, ConversationCategory } from '../../types/index.js';
import { api } from '../../services/api.js';
import { useAuth } from '../../context/AuthContext.js';

interface NewConversationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConversationCreated: (conversationId: string) => void;
  initialStudentId?: string;
  initialRecipientId?: string;
  initialDraft?: {
    id?: string;
    recipientId?: string;
    studentId?: string;
    subject?: string;
    body?: string;
    category?: ConversationCategory;
  };
}

export const NewConversationModal: React.FC<NewConversationModalProps> = ({
  isOpen,
  onClose,
  onConversationCreated,
  initialStudentId,
  initialRecipientId,
  initialDraft
}) => {
  const { user } = useAuth();
  const [recipients, setRecipients] = useState<EligibleRecipient[]>([]);
  const [isLoadingRecipients, setIsLoadingRecipients] = useState(false);
  const [selectedStudentId, setSelectedStudentId] = useState<string>(
    initialDraft?.studentId || initialStudentId || ''
  );
  const [selectedRecipientId, setSelectedRecipientId] = useState<string>(
    initialDraft?.recipientId || initialRecipientId || ''
  );
  const [subject, setSubject] = useState<string>(initialDraft?.subject || '');
  const [message, setMessage] = useState<string>(initialDraft?.body || '');
  const [category, setCategory] = useState<ConversationCategory>(
    initialDraft?.category || (user?.role === 'GUARDIAN' ? 'parent_teacher' : 'staff_internal')
  );
  const [attachments, setAttachments] = useState<
    Array<{
      id: string;
      name: string;
      size: string;
      sizeBytes: number;
      type: string;
      url: string;
    }>
  >([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Fetch permitted recipients based on selected student filter
  useEffect(() => {
    if (!isOpen) return;

    const fetchRecipients = async () => {
      setIsLoadingRecipients(true);
      setErrorMessage(null);
      try {
        const res = await api.communication.inbox.getEligibleRecipients(
          selectedStudentId || undefined
        );
        const recipientsList = Array.isArray((res as any)?.data?.data)
          ? (res as any).data.data
          : Array.isArray((res as any)?.data)
          ? (res as any).data
          : Array.isArray(res)
          ? res
          : [];
        setRecipients(recipientsList);
        if (!selectedRecipientId && recipientsList && recipientsList.length > 0) {
          setSelectedRecipientId(recipientsList?.[0]?.userId || '');
        }
      } catch (err: any) {
        setErrorMessage(err.message || 'Failed to load authorized recipient list.');
      } finally {
        setIsLoadingRecipients(false);
      }
    };

    fetchRecipients();
  }, [isOpen, selectedStudentId]);

  // Handle file attachment
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    if (attachments.length + files.length > 5) {
      setErrorMessage('Maximum 5 attachments permitted per message.');
      return;
    }

    const newAttachments = [...attachments];
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      if (file.size > 10 * 1024 * 1024) {
        setErrorMessage(`File ${file.name} exceeds 10MB limit.`);
        continue;
      }
      newAttachments.push({
        id: `att-tmp-${Date.now()}-${i}`,
        name: file.name,
        size: `${(file.size / (1024 * 1024)).toFixed(1)} MB`,
        sizeBytes: file.size,
        type: file.type || 'application/octet-stream',
        url: URL.createObjectURL(file)
      });
    }

    setAttachments(newAttachments);
    e.target.value = '';
  };

  const removeAttachment = (id: string) => {
    setAttachments((prev) => prev.filter((a) => a.id !== id));
  };

  const handleSend = async (asDraft = false) => {
    if (!selectedRecipientId) {
      setErrorMessage('Please select a recipient.');
      return;
    }
    if (!subject.trim()) {
      setErrorMessage('Please enter a conversation subject.');
      return;
    }
    if (!message.trim() && !asDraft) {
      setErrorMessage('Please enter your message body.');
      return;
    }

    setIsSubmitting(true);
    setErrorMessage(null);

    try {
      const res = await api.communication.inbox.createConversation({
        recipientId: selectedRecipientId,
        studentId: selectedStudentId || undefined,
        subject: subject.trim(),
        message: message.trim(),
        category,
        attachments,
        isDraft: asDraft
      });

      if (res.data?.data) {
        onConversationCreated(res.data.data.id);
        onClose();
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to send message.');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isOpen) return null;

  // Find unique linked children from recipients if user is Guardian
  const linkedChildren: Array<{ id: string; name: string; class?: string }> = user?.role === 'GUARDIAN'
    ? Array.from(
        new Map<string, { id: string; name: string; class?: string }>(
          recipients
            .filter((r) => r.studentId && r.studentName)
            .map((r) => [r.studentId!, { id: r.studentId!, name: r.studentName!, class: r.className }])
        ).values()
      )
    : [];

  return (
    <div
      id="inbox-compose-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fadeIn"
    >
      <div
        id="inbox-compose-modal"
        className="w-full max-w-2xl bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]"
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50/80">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-indigo-50 text-indigo-700 rounded-lg">
              <Send className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-slate-800">
                {initialDraft ? 'Edit Draft Conversation' : 'New Message / Conversation'}
              </h3>
              <p className="text-xs text-slate-500">
                Official institutional communication adhering to school messaging policy
              </p>
            </div>
          </div>
          <button
            id="compose-close-btn"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200/50 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-4 overflow-y-auto flex-1">
          {errorMessage && (
            <div
              id="compose-error-alert"
              className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-lg text-sm flex items-start gap-2.5"
            >
              <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Child Context Switcher for Multi-Child Guardians */}
          {user?.role === 'GUARDIAN' && linkedChildren.length > 1 && (
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1.5 flex items-center gap-1.5">
                <GraduationCap className="w-3.5 h-3.5 text-indigo-600" />
                Select Child (Filters Assigned Teachers)
              </label>
              <select
                id="compose-child-select"
                value={selectedStudentId}
                onChange={(e) => {
                  setSelectedStudentId(e.target.value);
                  setSelectedRecipientId('');
                }}
                className="w-full text-sm rounded-lg border border-slate-200 px-3 py-2 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="">All Linked Children</option>
                {linkedChildren.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name} ({c.class || 'Student'})
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Recipient Selection */}
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1.5 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5 text-indigo-600" />
                To (Authorized Recipient)
              </span>
              <span className="text-[11px] text-slate-400">Strictly authorized faculty & staff</span>
            </label>
            <select
              id="compose-recipient-select"
              value={selectedRecipientId}
              onChange={(e) => setSelectedRecipientId(e.target.value)}
              disabled={isLoadingRecipients}
              className="w-full text-sm rounded-lg border border-slate-200 px-3 py-2.5 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500 disabled:bg-slate-50"
            >
              <option value="">Select recipient...</option>
              {recipients.map((rec) => (
                <option key={`${rec.userId}-${rec.studentId || ''}`} value={rec.userId}>
                  {rec.name} — {rec.designation || rec.role} ({rec.relationshipContext || 'Staff'})
                </option>
              ))}
            </select>
          </div>

          {/* Conversation Category & Subject */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1.5">Category</label>
              <select
                id="compose-category-select"
                value={category}
                onChange={(e) => setCategory(e.target.value as ConversationCategory)}
                className="w-full text-sm rounded-lg border border-slate-200 px-3 py-2 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="parent_teacher">Parent-Teacher Academic</option>
                <option value="staff_internal">Staff Internal</option>
                <option value="administrative">Administrative Notice</option>
                <option value="guidance">Counseling & Guidance</option>
              </select>
            </div>
            <div className="sm:col-span-2">
              <label className="block text-xs font-medium text-slate-700 mb-1.5">Subject</label>
              <input
                id="compose-subject-input"
                type="text"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="e.g. Mathematics curriculum progress & supplemental assignments"
                className="w-full text-sm rounded-lg border border-slate-200 px-3 py-2 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

          {/* Message Body */}
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1.5 flex items-center justify-between">
              <span>Message Body</span>
              <span className="text-[11px] text-slate-400">{message.length}/10,000 characters</span>
            </label>
            <textarea
              id="compose-body-textarea"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              rows={7}
              placeholder="Compose your message clearly and respectfully..."
              className="w-full text-sm rounded-lg border border-slate-200 p-3 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none font-normal"
            />
          </div>

          {/* Attachments Section */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-medium text-slate-700 flex items-center gap-1.5">
                <Paperclip className="w-3.5 h-3.5 text-indigo-600" />
                Attachments ({attachments.length}/5)
              </label>
              <label
                htmlFor="compose-attachment-upload"
                className="text-xs font-medium text-indigo-600 hover:text-indigo-700 cursor-pointer flex items-center gap-1 hover:underline"
              >
                + Add files (Max 10MB)
              </label>
              <input
                id="compose-attachment-upload"
                type="file"
                multiple
                className="hidden"
                onChange={handleFileChange}
                accept=".pdf,.doc,.docx,.png,.jpg,.jpeg,.txt,.csv,.xls,.xlsx"
              />
            </div>

            {attachments.length > 0 && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-2">
                {attachments.map((att) => (
                  <div
                    key={att.id}
                    className="flex items-center justify-between p-2 rounded-lg border border-slate-200 bg-slate-50 text-xs text-slate-700"
                  >
                    <div className="flex items-center gap-2 truncate">
                      <FileText className="w-4 h-4 text-indigo-500 shrink-0" />
                      <span className="truncate font-medium">{att.name}</span>
                      <span className="text-slate-400 shrink-0">({att.size})</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => removeAttachment(att.id)}
                      className="p-1 text-slate-400 hover:text-rose-600 rounded hover:bg-rose-50 transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-slate-100 bg-slate-50/80">
          <button
            type="button"
            id="compose-save-draft-btn"
            onClick={() => handleSend(true)}
            disabled={isSubmitting || !subject.trim()}
            className="px-3 py-2 text-xs font-medium text-slate-600 hover:text-slate-800 bg-white border border-slate-200 rounded-lg hover:bg-slate-100 transition-colors flex items-center gap-1.5 disabled:opacity-50"
          >
            <Save className="w-3.5 h-3.5" />
            Save as Draft
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              id="compose-cancel-btn"
              onClick={onClose}
              disabled={isSubmitting}
              className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-800 transition-colors"
            >
              Cancel
            </button>
            <button
              type="button"
              id="compose-send-btn"
              onClick={() => handleSend(false)}
              disabled={isSubmitting || !selectedRecipientId || !subject.trim() || !message.trim()}
              className="px-5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-sm hover:shadow transition-all flex items-center gap-1.5 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Send className="w-3.5 h-3.5" />
              {isSubmitting ? 'Sending...' : 'Send Message'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
