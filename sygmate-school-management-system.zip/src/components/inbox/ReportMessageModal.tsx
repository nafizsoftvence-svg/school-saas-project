import React, { useState } from 'react';
import { X, Flag, AlertTriangle } from 'lucide-react';
import { api } from '../../services/api.js';

interface ReportMessageModalProps {
  isOpen: boolean;
  onClose: () => void;
  conversationId: string;
  conversationSubject: string;
  onReported: () => void;
}

export const ReportMessageModal: React.FC<ReportMessageModalProps> = ({
  isOpen,
  onClose,
  conversationId,
  conversationSubject,
  onReported
}) => {
  const [reason, setReason] = useState<
    'inappropriate_content' | 'harassment' | 'spam' | 'wrong_recipient' | 'other'
  >('inappropriate_content');
  const [details, setDetails] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError(null);

    try {
      await api.communication.inbox.reportConversation(conversationId, {
        reason,
        details: details.trim()
      });
      onReported();
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to report conversation.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div
      id="report-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fadeIn"
    >
      <div
        id="report-modal"
        className="w-full max-w-md bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden"
      >
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100 bg-rose-50/50">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-rose-100 text-rose-700 rounded-lg">
              <Flag className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-slate-800">Report Inappropriate Message</h3>
              <p className="text-xs text-slate-500">Flags this thread for school administrative review</p>
            </div>
          </div>
          <button
            id="report-close-btn"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-lg text-xs flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div>
            <span className="text-xs font-medium text-slate-600">Thread Subject:</span>
            <p className="text-xs font-semibold text-slate-800 truncate mt-0.5">
              {conversationSubject}
            </p>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1.5">
              Reason for Reporting
            </label>
            <select
              id="report-reason-select"
              value={reason}
              onChange={(e) => setReason(e.target.value as any)}
              className="w-full text-xs rounded-lg border border-slate-200 px-3 py-2 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-rose-500"
            >
              <option value="inappropriate_content">Inappropriate Language / Content</option>
              <option value="harassment">Harassment / Bullying</option>
              <option value="spam">Unsolicited / Spam</option>
              <option value="wrong_recipient">Sent to Wrong Recipient</option>
              <option value="other">Other Violation of School Policy</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1.5">
              Additional Details (Optional)
            </label>
            <textarea
              id="report-details-textarea"
              value={details}
              onChange={(e) => setDetails(e.target.value)}
              rows={3}
              placeholder="Provide context regarding the message violation..."
              className="w-full text-xs rounded-lg border border-slate-200 p-2.5 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-rose-500 resize-none"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
            <button
              type="button"
              id="report-cancel-btn"
              onClick={onClose}
              disabled={isSubmitting}
              className="px-3 py-1.5 text-xs font-medium text-slate-600 hover:text-slate-800 rounded-lg"
            >
              Cancel
            </button>
            <button
              type="submit"
              id="report-submit-btn"
              disabled={isSubmitting}
              className="px-4 py-1.5 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-lg shadow-sm transition-colors flex items-center gap-1.5 disabled:opacity-50"
            >
              <Flag className="w-3.5 h-3.5" />
              {isSubmitting ? 'Submitting...' : 'Submit Report'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
