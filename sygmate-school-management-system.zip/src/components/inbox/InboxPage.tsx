import React, { useState, useEffect, useCallback } from 'react';
import {
  Mail,
  Inbox,
  Send,
  Star,
  Archive,
  FileEdit,
  ShieldAlert,
  Search,
  Plus,
  RefreshCw,
  Filter,
  CheckCheck,
  User,
  GraduationCap,
  Sparkles,
  MessageSquare,
  AlertCircle,
  ChevronLeft,
  ChevronRight,
  Clock
} from 'lucide-react';
import { Conversation, ConversationCategory, UserRole } from '../../types/index.js';
import { api } from '../../services/api.js';
import { useAuth } from '../../context/AuthContext.js';
import { NewConversationModal } from './NewConversationModal.js';
import { MessageThreadView } from './MessageThreadView.js';
import { ModerationReportsModal } from './ModerationReportsModal.js';

interface InboxPageProps {
  initialFolder?: 'inbox' | 'sent' | 'drafts' | 'archived' | 'starred' | 'reported';
  studentIdContext?: string;
  onNavigate?: (view: string) => void;
}

export const InboxPage: React.FC<InboxPageProps> = ({
  initialFolder = 'inbox',
  studentIdContext,
  onNavigate
}) => {
  const { user } = useAuth();
  const [folder, setFolder] = useState<'inbox' | 'sent' | 'drafts' | 'archived' | 'starred' | 'reported'>(
    initialFolder
  );
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [totalUnread, setTotalUnread] = useState(0);
  const [selectedConversationId, setSelectedConversationId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);

  // Modals
  const [isComposeOpen, setIsComposeOpen] = useState(false);
  const [isModerationOpen, setIsModerationOpen] = useState(false);
  const [pendingReportsCount, setPendingReportsCount] = useState(0);
  const [draftToResume, setDraftToResume] = useState<any>(null);

  // Load conversations
  const loadConversations = useCallback(async () => {
    setIsLoading(true);
    try {
      const res = await api.communication.inbox.getConversations({
        folder,
        category: categoryFilter !== 'all' ? categoryFilter : undefined,
        search: searchQuery.trim() || undefined,
        studentId: studentIdContext || undefined,
        page,
        limit: 15
      });

      if (res.data) {
        setConversations(res.data.data || []);
        setTotalUnread(res.data.unreadCount || 0);
        if (res.data.pagination) {
          setTotalPages(res.data.pagination.totalPages || 1);
        }

        // If currently selected conversation is no longer in list and on mobile, reset
        if (selectedConversationId && !res.data.data.some((c) => c.id === selectedConversationId)) {
          // Keep selection unless switching folder
        }
      }
    } catch (err) {
      console.error('Failed to load conversations', err);
    } finally {
      setIsLoading(false);
    }
  }, [folder, categoryFilter, searchQuery, studentIdContext, page]);

  // Load pending moderation count for admin
  useEffect(() => {
    if (user?.role === 'SUPER_ADMIN') {
      api.communication.inbox.getReports().then((res) => {
        if (res.data?.data) {
          const pending = res.data.data.filter((r) => r.status === 'pending').length;
          setPendingReportsCount(pending);
        }
      }).catch(() => {});
    }
  }, [user?.role]);

  useEffect(() => {
    loadConversations();
  }, [loadConversations]);

  // Toggle archive
  const handleToggleArchive = async (id: string) => {
    try {
      await api.communication.inbox.toggleArchive(id);
      loadConversations();
    } catch (err) {
      console.error('Failed to toggle archive', err);
    }
  };

  // Toggle star
  const handleToggleStar = async (id: string) => {
    try {
      await api.communication.inbox.toggleStar(id);
      // Optimistic update
      setConversations((prev) =>
        prev.map((c) =>
          c.id === id ? { ...c, isStarredForMe: !c.isStarredForMe } : c
        )
      );
    } catch (err) {
      console.error('Failed to toggle star', err);
    }
  };

  // Click on a conversation
  const handleSelectConversation = (conv: Conversation) => {
    if (conv.isDraft) {
      // Resume draft in modal
      setDraftToResume({
        id: conv.id,
        recipientId: conv.draftRecipientId,
        studentId: conv.studentId,
        subject: conv.subject,
        body: conv.draftBody,
        category: conv.category
      });
      setIsComposeOpen(true);
    } else {
      setSelectedConversationId(conv.id);
      // Mark as read in local state
      setConversations((prev) =>
        prev.map((c) => (c.id === conv.id ? { ...c, unreadCount: 0 } : c))
      );
    }
  };

  const getRoleColor = (role: UserRole | string) => {
    switch (role) {
      case 'SUPER_ADMIN':
      case 'ADMIN':
        return 'text-purple-700 bg-purple-50 border-purple-200';
      case 'TEACHER':
        return 'text-emerald-700 bg-emerald-50 border-emerald-200';
      case 'GUARDIAN':
        return 'text-indigo-700 bg-indigo-50 border-indigo-200';
      case 'STUDENT':
        return 'text-blue-700 bg-blue-50 border-blue-200';
      default:
        return 'text-slate-700 bg-slate-50 border-slate-200';
    }
  };

  return (
    <div id="institutional-inbox-page" className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
      {/* Top Header & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
        <div className="flex items-center gap-3.5">
          <div className="p-3 bg-gradient-to-br from-indigo-500 to-indigo-600 text-white rounded-xl shadow-sm">
            <MessageSquare className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold text-slate-900 tracking-tight">
                Institutional Messaging & Inbox
              </h1>
              {totalUnread > 0 && (
                <span className="px-2 py-0.5 text-xs font-semibold bg-indigo-100 text-indigo-700 rounded-full">
                  {totalUnread} unread
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Secure, recorded, and auditable communication between parents, teachers, and school administration
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          {user?.role === 'SUPER_ADMIN' && (
            <button
              id="inbox-moderation-queue-btn"
              onClick={() => setIsModerationOpen(true)}
              className="px-3.5 py-2 text-xs font-semibold bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 rounded-xl transition-colors flex items-center gap-1.5"
            >
              <ShieldAlert className="w-4 h-4" />
              <span>Moderation Queue</span>
              {pendingReportsCount > 0 && (
                <span className="px-1.5 py-0.2 text-[10px] bg-amber-600 text-white font-bold rounded-full">
                  {pendingReportsCount}
                </span>
              )}
            </button>
          )}

          <button
            id="inbox-refresh-btn"
            onClick={() => loadConversations()}
            disabled={isLoading}
            className="p-2 text-slate-500 hover:text-slate-800 border border-slate-200 rounded-xl hover:bg-slate-50 transition-colors"
            title="Refresh inbox"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
          </button>

          <button
            id="inbox-new-message-btn"
            onClick={() => {
              setDraftToResume(null);
              setIsComposeOpen(true);
            }}
            className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-sm hover:shadow transition-all flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" />
            <span>New Message</span>
          </button>
        </div>
      </div>

      {/* Main Inbox Workspace: Split Navigation & List / Thread */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Navigation Bar (3 Cols) */}
        <div className="lg:col-span-3 space-y-4">
          <div className="bg-white rounded-2xl border border-slate-200/80 p-3 shadow-xs space-y-1">
            <span className="px-3 py-1.5 text-[11px] font-bold uppercase tracking-wider text-slate-400 block">
              Mailboxes
            </span>

            {[
              { id: 'inbox', label: 'Inbox', icon: Inbox, count: totalUnread },
              { id: 'starred', label: 'Starred', icon: Star },
              { id: 'sent', label: 'Sent Messages', icon: Send },
              { id: 'drafts', label: 'Drafts', icon: FileEdit },
              { id: 'archived', label: 'Archived', icon: Archive }
            ].map((item) => {
              const Icon = item.icon;
              const isActive = folder === item.id;
              return (
                <button
                  key={item.id}
                  id={`folder-btn-${item.id}`}
                  onClick={() => {
                    setFolder(item.id as any);
                    setSelectedConversationId(null);
                    setPage(1);
                  }}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-medium transition-colors ${
                    isActive
                      ? 'bg-indigo-50 text-indigo-700 font-semibold'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className={`w-4 h-4 ${isActive ? 'text-indigo-600' : 'text-slate-400'}`} />
                    <span>{item.label}</span>
                  </div>
                  {item.count !== undefined && item.count > 0 && (
                    <span className="px-2 py-0.5 text-[10px] font-bold bg-indigo-600 text-white rounded-full">
                      {item.count}
                    </span>
                  )}
                </button>
              );
            })}

            {user?.role === 'SUPER_ADMIN' && (
              <button
                id="folder-btn-reported"
                onClick={() => {
                  setFolder('reported');
                  setSelectedConversationId(null);
                  setPage(1);
                }}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-medium transition-colors ${
                  folder === 'reported'
                    ? 'bg-rose-50 text-rose-700 font-semibold'
                    : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <ShieldAlert
                    className={`w-4 h-4 ${folder === 'reported' ? 'text-rose-600' : 'text-slate-400'}`}
                  />
                  <span>Reported Messages</span>
                </div>
                {pendingReportsCount > 0 && (
                  <span className="px-2 py-0.5 text-[10px] font-bold bg-rose-600 text-white rounded-full">
                    {pendingReportsCount}
                  </span>
                )}
              </button>
            )}
          </div>

          {/* Category Filter Widget */}
          <div className="bg-white rounded-2xl border border-slate-200/80 p-4 shadow-xs space-y-3">
            <span className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
              <Filter className="w-3.5 h-3.5 text-indigo-600" />
              Category Filter
            </span>
            <div className="space-y-1.5">
              {[
                { id: 'all', label: 'All Categories' },
                { id: 'parent_teacher', label: 'Parent-Teacher' },
                { id: 'staff_internal', label: 'Staff Internal' },
                { id: 'administrative', label: 'Administrative' }
              ].map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => {
                    setCategoryFilter(cat.id);
                    setPage(1);
                  }}
                  className={`w-full text-left px-2.5 py-1.5 text-xs rounded-lg transition-colors ${
                    categoryFilter === cat.id
                      ? 'bg-slate-100 text-slate-900 font-semibold'
                      : 'text-slate-500 hover:bg-slate-50 hover:text-slate-800'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </div>

          {/* Institutional Policy Tip */}
          <div className="p-3.5 bg-indigo-50/60 rounded-2xl border border-indigo-100/80 text-xs text-indigo-900 space-y-1">
            <div className="flex items-center gap-1.5 font-semibold text-indigo-950">
              <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
              Messaging Conduct
            </div>
            <p className="text-[11px] text-indigo-800/90 leading-relaxed">
              All communications are securely recorded for student safety, accountability, and pedagogical alignment.
            </p>
          </div>
        </div>

        {/* Right Area: List + Thread (9 Cols) */}
        <div className="lg:col-span-9">
          <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden flex flex-col min-h-[640px] max-h-[820px]">
            {/* If conversation is selected: show thread view */}
            {selectedConversationId ? (
              <MessageThreadView
                conversationId={selectedConversationId}
                onBack={() => {
                  setSelectedConversationId(null);
                  loadConversations();
                }}
                onConversationUpdated={() => loadConversations()}
                onArchiveToggle={handleToggleArchive}
                onStarToggle={handleToggleStar}
              />
            ) : (
              // Conversation List View
              <div className="flex flex-col h-full">
                {/* Search & List Header */}
                <div className="p-4 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50/50">
                  <div className="relative flex-1 max-w-md">
                    <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                    <input
                      id="inbox-search-input"
                      type="text"
                      placeholder="Search messages by keyword, subject, or student..."
                      value={searchQuery}
                      onChange={(e) => {
                        setSearchQuery(e.target.value);
                        setPage(1);
                      }}
                      className="w-full text-xs pl-9 pr-4 py-2 rounded-xl border border-slate-200 bg-white text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>

                  <span className="text-xs text-slate-500 font-medium self-end sm:self-center">
                    {conversations?.length || 0} conversation{(conversations?.length || 0) !== 1 ? 's' : ''} in {folder}
                  </span>
                </div>

                {/* List Body */}
                <div className="flex-1 overflow-y-auto divide-y divide-slate-100">
                  {isLoading ? (
                    <div className="flex items-center justify-center py-24">
                      <div className="w-8 h-8 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin" />
                    </div>
                  ) : (conversations?.length || 0) === 0 ? (
                    <div className="py-24 text-center px-4">
                      <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center mx-auto mb-3">
                        <Mail className="w-6 h-6 opacity-70" />
                      </div>
                      <h4 className="text-sm font-semibold text-slate-800">No conversations in {folder}</h4>
                      <p className="text-xs text-slate-400 max-w-sm mx-auto mt-1">
                        {searchQuery
                          ? 'No messages matched your search criteria.'
                          : 'Your mailbox is clear. Start a new conversation with authorized faculty or parents.'}
                      </p>
                      <button
                        onClick={() => setIsComposeOpen(true)}
                        className="mt-4 px-4 py-2 text-xs font-semibold text-indigo-600 bg-indigo-50 rounded-xl hover:bg-indigo-100 transition-colors"
                      >
                        Compose Message
                      </button>
                    </div>
                  ) : (
                    conversations.map((conv) => {
                      const otherParticipant =
                        (conv.participants || []).find((p) => p.userId !== user?.id) || conv.participants?.[0];
                      const isUnread = (conv.unreadCount || 0) > 0;

                      return (
                        <div
                          key={conv.id}
                          id={`conversation-item-${conv.id}`}
                          onClick={() => handleSelectConversation(conv)}
                          className={`p-4 transition-colors cursor-pointer hover:bg-slate-50/80 flex items-start justify-between gap-3 ${
                            isUnread ? 'bg-indigo-50/30' : ''
                          }`}
                        >
                          <div className="flex items-start gap-3 min-w-0 flex-1">
                            {/* Avatar */}
                            <div className="w-10 h-10 rounded-full bg-indigo-100 text-indigo-700 flex items-center justify-center text-xs font-bold shrink-0 border border-indigo-200">
                              {otherParticipant?.avatarUrl ? (
                                <img
                                  src={otherParticipant.avatarUrl}
                                  alt={otherParticipant.name}
                                  className="w-full h-full rounded-full object-cover"
                                  referrerPolicy="no-referrer"
                                />
                              ) : (
                                otherParticipant?.name.substring(0, 2).toUpperCase()
                              )}
                            </div>

                            {/* Content overview */}
                            <div className="min-w-0 flex-1 space-y-1">
                              <div className="flex items-center gap-2 flex-wrap">
                                <span
                                  className={`text-xs ${
                                    isUnread ? 'font-bold text-slate-950' : 'font-semibold text-slate-800'
                                  }`}
                                >
                                  {otherParticipant?.name}
                                </span>
                                <span
                                  className={`text-[10px] px-1.5 py-0.2 rounded font-medium border ${getRoleColor(
                                    otherParticipant?.role || ''
                                  )}`}
                                >
                                  {otherParticipant?.role}
                                </span>

                                {conv.studentName && (
                                  <span className="text-[11px] text-slate-500 flex items-center gap-1 font-medium bg-slate-100 px-2 py-0.5 rounded-md">
                                    <GraduationCap className="w-3 h-3 text-indigo-500" />
                                    {conv.studentName}
                                  </span>
                                )}

                                {conv.isDraft && (
                                  <span className="text-[10px] bg-amber-100 text-amber-800 font-semibold px-1.5 py-0.2 rounded">
                                    Draft
                                  </span>
                                )}
                              </div>

                              <h4
                                className={`text-xs truncate ${
                                  isUnread ? 'font-bold text-indigo-950' : 'text-slate-800 font-medium'
                                }`}
                              >
                                {conv.subject}
                              </h4>

                              <p className="text-xs text-slate-500 truncate leading-relaxed">
                                {conv.lastMessagePreview || 'No messages yet'}
                              </p>
                            </div>
                          </div>

                          {/* Meta date & actions */}
                          <div className="flex flex-col items-end gap-2 shrink-0">
                            <span className="text-[11px] text-slate-400 font-medium">
                              {new Date(conv.lastMessageAt || conv.createdAt).toLocaleDateString([], {
                                month: 'short',
                                day: 'numeric'
                              })}
                            </span>

                            <div className="flex items-center gap-1">
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleToggleStar(conv.id);
                                }}
                                className="p-1 text-slate-400 hover:text-amber-500 transition-colors"
                              >
                                <Star
                                  className={`w-3.5 h-3.5 ${
                                    conv.isStarredForMe ? 'text-amber-500 fill-amber-500' : ''
                                  }`}
                                />
                              </button>

                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleToggleArchive(conv.id);
                                }}
                                className="p-1 text-slate-400 hover:text-indigo-600 transition-colors"
                                title="Archive"
                              >
                                <Archive className="w-3.5 h-3.5" />
                              </button>

                              {isUnread && (
                                <span className="w-2.5 h-2.5 bg-indigo-600 rounded-full shrink-0" />
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>

                {/* Pagination Controls */}
                {totalPages > 1 && (
                  <div className="p-3 border-t border-slate-100 bg-slate-50 flex items-center justify-between text-xs text-slate-500">
                    <span>
                      Page {page} of {totalPages}
                    </span>
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => setPage((p) => Math.max(1, p - 1))}
                        disabled={page <= 1}
                        className="p-1 rounded hover:bg-slate-200 disabled:opacity-40"
                      >
                        <ChevronLeft className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                        disabled={page >= totalPages}
                        className="p-1 rounded hover:bg-slate-200 disabled:opacity-40"
                      >
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Modals */}
      <NewConversationModal
        isOpen={isComposeOpen}
        onClose={() => {
          setIsComposeOpen(false);
          setDraftToResume(null);
        }}
        onConversationCreated={(id) => {
          setSelectedConversationId(id);
          loadConversations();
        }}
        initialStudentId={studentIdContext}
        initialDraft={draftToResume}
      />

      <ModerationReportsModal
        isOpen={isModerationOpen}
        onClose={() => {
          setIsModerationOpen(false);
          loadConversations();
        }}
        onSelectConversation={(id) => {
          setSelectedConversationId(id);
        }}
      />
    </div>
  );
};
