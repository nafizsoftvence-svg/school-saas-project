import React, { useState, useEffect, useRef } from 'react';
import {
  ArrowLeft,
  Star,
  Archive,
  Flag,
  Send,
  Paperclip,
  FileText,
  Download,
  Trash2,
  Check,
  CheckCheck,
  User,
  GraduationCap,
  Sparkles,
  Info
} from 'lucide-react';
import { Conversation, MessageItem, UserRole } from '../../types/index.js';
import { api } from '../../services/api.js';
import { useAuth } from '../../context/AuthContext.js';
import { ReportMessageModal } from './ReportMessageModal.js';

interface MessageThreadViewProps {
  conversationId: string;
  onBack: () => void;
  onConversationUpdated?: () => void;
  onArchiveToggle?: (id: string) => void;
  onStarToggle?: (id: string) => void;
}

export const MessageThreadView: React.FC<MessageThreadViewProps> = ({
  conversationId,
  onBack,
  onConversationUpdated,
  onArchiveToggle,
  onStarToggle
}) => {
  const { user } = useAuth();
  const [conversation, setConversation] = useState<Conversation | null>(null);
  const [messages, setMessages] = useState<MessageItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [replyText, setReplyText] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [attachments, setAttachments] = useState<
    Array<{
      id: string;
      name: string;
      size: string;
      sizeBytes: number;
      type: string;
      url: string;
    }>
  >([]);
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Fetch thread and messages
  const fetchThread = async (markRead = true) => {
    try {
      const res = await api.communication.inbox.getConversationById(conversationId);
      if (res.data) {
        setConversation(res.data.data);
        setMessages(res.data.messages || []);
        if (markRead) {
          api.communication.inbox.markAsRead(conversationId).catch(() => {});
        }
      }
    } catch (err: any) {
      setActionError(err.message || 'Failed to load conversation thread.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    setIsLoading(true);
    fetchThread();
  }, [conversationId]);

  // Scroll to bottom on new message
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendReply = async () => {
    if (!replyText.trim() && attachments.length === 0) return;

    setIsSending(true);
    setActionError(null);

    try {
      const res = await api.communication.inbox.reply(conversationId, {
        message: replyText.trim(),
        attachments
      });

      if (res.data) {
        setMessages((prev) => [...prev, res.data.data]);
        setReplyText('');
        setAttachments([]);
        if (onConversationUpdated) onConversationUpdated();
      }
    } catch (err: any) {
      setActionError(err.message || 'Failed to deliver reply.');
    } finally {
      setIsSending(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      e.preventDefault();
      handleSendReply();
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const newAttachments = [...attachments];
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      if (file.size > 10 * 1024 * 1024) {
        setActionError(`File ${file.name} exceeds 10MB limit.`);
        continue;
      }
      newAttachments.push({
        id: `att-${Date.now()}-${i}`,
        name: file.name,
        size: `${(file.size / (1024 * 1024)).toFixed(1)} MB`,
        sizeBytes: file.size,
        type: file.type || 'application/octet-stream',
        url: URL.createObjectURL(file)
      });
    }

    setAttachments(newAttachments);
    e.target.value = '';
  };

  const removeAttachment = (id: string) => {
    setAttachments((prev) => prev.filter((a) => a.id !== id));
  };

  const getRoleBadge = (role: UserRole | string) => {
    switch (role) {
      case 'SUPER_ADMIN':
      case 'ADMIN':
        return 'bg-purple-50 text-purple-700 border-purple-200';
      case 'TEACHER':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'GUARDIAN':
        return 'bg-indigo-50 text-indigo-700 border-indigo-200';
      case 'STUDENT':
        return 'bg-blue-50 text-blue-700 border-blue-200';
      default:
        return 'bg-slate-50 text-slate-700 border-slate-200';
    }
  };

  if (isLoading) {
    return (
      <div className="flex-1 flex items-center justify-center py-20">
        <div className="text-center space-y-3">
          <div className="w-8 h-8 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-xs font-medium text-slate-500">Loading conversation thread...</p>
        </div>
      </div>
    );
  }

  if (!conversation) {
    return (
      <div className="p-8 text-center text-slate-500">
        <Info className="w-8 h-8 mx-auto mb-2 text-slate-400" />
        <p className="text-sm font-medium">Conversation could not be found or access was restricted.</p>
        <button
          onClick={onBack}
          className="mt-4 px-4 py-2 text-xs font-semibold text-indigo-600 bg-indigo-50 rounded-lg hover:bg-indigo-100"
        >
          Return to Inbox
        </button>
      </div>
    );
  }

  const otherParticipant = (conversation.participants || []).find((p) => p.userId !== user?.id) || conversation.participants?.[0];
  const isStarred = conversation.isStarredForMe;
  const isArchived = conversation.isArchivedForMe;

  return (
    <div id="message-thread-view" className="flex flex-col h-full bg-slate-50/50">
      {/* Thread Header */}
      <div className="px-6 py-4 bg-white border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs">
        <div className="flex items-center gap-3">
          <button
            id="thread-back-btn"
            onClick={onBack}
            className="p-1.5 text-slate-500 hover:text-slate-800 rounded-lg hover:bg-slate-100 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>

          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-base font-semibold text-slate-900 tracking-tight">
                {conversation.subject}
              </h2>
              <span
                className={`px-2 py-0.5 text-[10px] font-semibold rounded-full border uppercase tracking-wider ${
                  conversation.category === 'parent_teacher'
                    ? 'bg-indigo-50 text-indigo-700 border-indigo-200'
                    : 'bg-emerald-50 text-emerald-700 border-emerald-200'
                }`}
              >
                {(conversation.category || 'General').replace(/_/g, ' ')}
              </span>
              {conversation.isReported && (
                <span className="px-2 py-0.5 text-[10px] font-semibold bg-rose-50 text-rose-700 border border-rose-200 rounded-full flex items-center gap-1">
                  <Flag className="w-2.5 h-2.5" /> Flagged
                </span>
              )}
            </div>

            <div className="flex items-center gap-2 text-xs text-slate-500 mt-1 flex-wrap">
              <span>Between:</span>
              <strong className="text-slate-700 font-medium">{otherParticipant?.name}</strong>
              <span className={`px-1.5 py-0.2 text-[10px] rounded border ${getRoleBadge(otherParticipant?.role)}`}>
                {otherParticipant?.role}
              </span>
              {conversation.studentName && (
                <>
                  <span className="text-slate-300">•</span>
                  <span className="flex items-center gap-1 text-slate-600 font-medium">
                    <GraduationCap className="w-3.5 h-3.5 text-indigo-500" />
                    Student: {conversation.studentName} {conversation.className ? `(${conversation.className})` : ''}
                  </span>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-1.5 self-end sm:self-center">
          <button
            id="thread-star-btn"
            onClick={() => onStarToggle && onStarToggle(conversation.id)}
            title={isStarred ? 'Unstar' : 'Star'}
            className={`p-2 rounded-lg border transition-colors ${
              isStarred
                ? 'bg-amber-50 text-amber-600 border-amber-200 hover:bg-amber-100'
                : 'text-slate-400 border-slate-200 hover:text-slate-700 hover:bg-slate-50'
            }`}
          >
            <Star className={`w-4 h-4 ${isStarred ? 'fill-amber-500' : ''}`} />
          </button>

          <button
            id="thread-archive-btn"
            onClick={() => onArchiveToggle && onArchiveToggle(conversation.id)}
            title={isArchived ? 'Unarchive' : 'Archive'}
            className={`p-2 rounded-lg border transition-colors ${
              isArchived
                ? 'bg-indigo-50 text-indigo-600 border-indigo-200 hover:bg-indigo-100'
                : 'text-slate-400 border-slate-200 hover:text-slate-700 hover:bg-slate-50'
            }`}
          >
            <Archive className="w-4 h-4" />
          </button>

          <button
            id="thread-report-btn"
            onClick={() => setIsReportModalOpen(true)}
            title="Report inappropriate content"
            className="p-2 text-slate-400 hover:text-rose-600 border border-slate-200 rounded-lg hover:bg-rose-50 transition-colors"
          >
            <Flag className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Messages Stream */}
      <div
        id="messages-scroll-area"
        className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4"
      >
        {actionError && (
          <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-lg text-xs">
            {actionError}
          </div>
        )}

        {messages.map((msg, idx) => {
          const isMe = msg.senderId === user?.id;

          return (
            <div
              key={msg.id || idx}
              className={`flex gap-3 max-w-3xl ${isMe ? 'ml-auto flex-row-reverse' : 'mr-auto'}`}
            >
              {/* Avatar */}
              <div
                className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 text-xs font-bold border ${
                  isMe
                    ? 'bg-indigo-600 text-white border-indigo-700'
                    : 'bg-white text-slate-700 border-slate-200'
                }`}
              >
                {msg.senderAvatarUrl ? (
                  <img
                    src={msg.senderAvatarUrl}
                    alt={msg.senderName}
                    className="w-full h-full rounded-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  msg.senderName.substring(0, 2).toUpperCase()
                )}
              </div>

              {/* Message Bubble Container */}
              <div className={`space-y-1.5 ${isMe ? 'items-end' : 'items-start'} max-w-[85%]`}>
                {/* Header label */}
                <div className={`flex items-center gap-2 text-xs ${isMe ? 'justify-end' : 'justify-start'}`}>
                  <span className="font-semibold text-slate-800">{msg.senderName}</span>
                  <span
                    className={`text-[10px] px-1.5 py-0.5 rounded font-medium border ${getRoleBadge(
                      msg.senderRole
                    )}`}
                  >
                    {msg.senderRole}
                  </span>
                  <span className="text-[11px] text-slate-400">
                    {new Date(msg.createdAt).toLocaleTimeString([], {
                      hour: '2-digit',
                      minute: '2-digit',
                      month: 'short',
                      day: 'numeric'
                    })}
                  </span>
                </div>

                {/* Bubble Body */}
                <div
                  className={`p-4 rounded-2xl text-sm leading-relaxed whitespace-pre-wrap shadow-xs ${
                    isMe
                      ? 'bg-indigo-600 text-white rounded-tr-none'
                      : 'bg-white text-slate-800 border border-slate-200 rounded-tl-none'
                  }`}
                >
                  {msg.body}

                  {/* Attachments inside bubble */}
                  {msg.attachments && msg.attachments.length > 0 && (
                    <div className={`mt-3 pt-3 border-t space-y-1.5 ${isMe ? 'border-indigo-500' : 'border-slate-100'}`}>
                      {msg.attachments.map((att, attIdx) => (
                        <div
                          key={att.id || attIdx}
                          className={`flex items-center justify-between p-2 rounded-lg text-xs font-medium ${
                            isMe
                              ? 'bg-indigo-700/60 text-white border border-indigo-500'
                              : 'bg-slate-50 text-slate-700 border border-slate-200'
                          }`}
                        >
                          <div className="flex items-center gap-2 truncate">
                            <FileText className="w-4 h-4 shrink-0" />
                            <span className="truncate">{att.name}</span>
                            <span className="text-[11px] opacity-75 shrink-0">({att.size})</span>
                          </div>
                          <a
                            href={att.url || '#'}
                            target="_blank"
                            rel="noopener noreferrer"
                            className={`p-1 rounded transition-colors ${
                              isMe ? 'hover:bg-indigo-800' : 'hover:bg-slate-200'
                            }`}
                            title="Download attachment"
                          >
                            <Download className="w-3.5 h-3.5" />
                          </a>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Delivery Indicator */}
                {isMe && (
                  <div className="flex items-center justify-end gap-1 text-[11px] text-slate-400 pr-1">
                    {msg.status === 'read' ? (
                      <span className="flex items-center gap-1 text-indigo-600">
                        <CheckCheck className="w-3.5 h-3.5" /> Read
                      </span>
                    ) : (
                      <span className="flex items-center gap-1">
                        <Check className="w-3.5 h-3.5" /> Delivered
                      </span>
                    )}
                  </div>
                )}
              </div>
            </div>
          );
        })}
        <div ref={messagesEndRef} />
      </div>

      {/* Reply Input Bar */}
      <div className="p-4 bg-white border-t border-slate-200 shadow-sm space-y-3">
        {/* Attachment chips preview */}
        {attachments.length > 0 && (
          <div className="flex flex-wrap gap-2">
            {attachments.map((att) => (
              <div
                key={att.id}
                className="flex items-center gap-1.5 px-2.5 py-1 bg-slate-100 border border-slate-200 rounded-md text-xs text-slate-700"
              >
                <FileText className="w-3.5 h-3.5 text-indigo-500" />
                <span className="truncate max-w-[150px] font-medium">{att.name}</span>
                <button
                  onClick={() => removeAttachment(att.id)}
                  className="p-0.5 text-slate-400 hover:text-rose-600"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>
        )}

        <div className="flex items-end gap-2">
          {/* File upload button */}
          <div>
            <label
              htmlFor="reply-attachment-upload"
              className="p-2.5 text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg cursor-pointer transition-colors block border border-slate-200"
              title="Attach files (Max 10MB)"
            >
              <Paperclip className="w-4 h-4" />
            </label>
            <input
              id="reply-attachment-upload"
              type="file"
              multiple
              className="hidden"
              onChange={handleFileChange}
              accept=".pdf,.doc,.docx,.png,.jpg,.jpeg,.txt,.csv,.xls,.xlsx"
            />
          </div>

          {/* Textarea */}
          <div className="flex-1 relative">
            <textarea
              id="reply-message-textarea"
              value={replyText}
              onChange={(e) => setReplyText(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Type your reply... (Press Ctrl + Enter to send)"
              rows={2}
              className="w-full text-sm rounded-lg border border-slate-200 p-2.5 bg-slate-50/50 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white resize-none"
            />
          </div>

          {/* Send button */}
          <button
            id="reply-send-btn"
            onClick={handleSendReply}
            disabled={isSending || (!replyText.trim() && attachments.length === 0)}
            className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-semibold text-xs shadow-sm hover:shadow flex items-center gap-1.5 transition-all disabled:opacity-50 disabled:cursor-not-allowed h-[42px]"
          >
            <Send className="w-4 h-4" />
            <span>{isSending ? 'Sending...' : 'Send'}</span>
          </button>
        </div>
      </div>

      {/* Report Modal */}
      <ReportMessageModal
        isOpen={isReportModalOpen}
        onClose={() => setIsReportModalOpen(false)}
        conversationId={conversation.id}
        conversationSubject={conversation.subject}
        onReported={() => {
          fetchThread(false);
          if (onConversationUpdated) onConversationUpdated();
        }}
      />
    </div>
  );
};
