import React, { useState, useEffect } from 'react';
import {
  X,
  ShieldAlert,
  CheckCircle2,
  AlertTriangle,
  Clock,
  User,
  Filter
} from 'lucide-react';
import { MessageReport } from '../../types/index.js';
import { api } from '../../services/api.js';

interface ModerationReportsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectConversation?: (conversationId: string) => void;
}

export const ModerationReportsModal: React.FC<ModerationReportsModalProps> = ({
  isOpen,
  onClose,
  onSelectConversation
}) => {
  const [reports, setReports] = useState<MessageReport[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [activeFilter, setActiveFilter] = useState<'all' | 'pending' | 'action_taken' | 'dismissed'>('all');
  const [resolvingId, setResolvingId] = useState<string | null>(null);
  const [resolutionStatus, setResolutionStatus] = useState<'reviewed' | 'dismissed' | 'action_taken'>('action_taken');
  const [resolutionNotes, setResolutionNotes] = useState('');

  const fetchReports = async () => {
    setIsLoading(true);
    try {
      const res = await api.communication.inbox.getReports();
      if (res.data) {
        setReports(res.data);
      }
    } catch (err) {
      console.error('Failed to load moderation reports', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchReports();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleResolve = async (reportId: string) => {
    try {
      await api.communication.inbox.resolveReport(reportId, {
        status: resolutionStatus,
        resolutionNotes
      });
      setResolvingId(null);
      setResolutionNotes('');
      fetchReports();
    } catch (err) {
      console.error('Failed to resolve report', err);
    }
  };

  const filteredReports = reports.filter((r) => {
    if (activeFilter === 'all') return true;
    return r.status === activeFilter;
  });

  return (
    <div
      id="moderation-reports-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fadeIn"
    >
      <div
        id="moderation-reports-modal"
        className="w-full max-w-4xl bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[85vh]"
      >
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-slate-50/80">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-amber-50 text-amber-700 rounded-lg">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-slate-800">
                Message Moderation & Flagged Reports
              </h3>
              <p className="text-xs text-slate-500">
                Administrative review of reported messages and communication policy violations
              </p>
            </div>
          </div>
          <button
            id="moderation-modal-close-btn"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200/50 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filter bar */}
        <div className="px-6 py-2.5 bg-slate-50 border-b border-slate-100 flex items-center gap-2">
          <Filter className="w-3.5 h-3.5 text-slate-400" />
          <span className="text-xs font-medium text-slate-500">Status:</span>
          {(['all', 'pending', 'action_taken', 'dismissed'] as const).map((st) => (
            <button
              key={st}
              onClick={() => setActiveFilter(st)}
              className={`px-2.5 py-1 text-xs rounded-md font-medium transition-colors ${
                activeFilter === st
                  ? 'bg-slate-800 text-white'
                  : 'text-slate-600 hover:bg-slate-200/60'
              }`}
            >
              {st === 'all'
                ? `All (${reports?.length || 0})`
                : st === 'pending'
                ? `Pending (${(reports || []).filter((r) => r.status === 'pending').length})`
                : st === 'action_taken'
                ? 'Action Taken'
                : 'Dismissed'}
            </button>
          ))}
        </div>

        {/* Body list */}
        <div className="p-6 overflow-y-auto flex-1 divide-y divide-slate-100">
          {isLoading ? (
            <div className="text-center py-12 text-sm text-slate-400">Loading moderation queue...</div>
          ) : (filteredReports?.length || 0) === 0 ? (
            <div className="text-center py-12">
              <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto mb-2 opacity-80" />
              <p className="text-sm font-medium text-slate-700">No moderation reports</p>
              <p className="text-xs text-slate-400 mt-1">All conversations adhere to safety policies.</p>
            </div>
          ) : (
            filteredReports.map((rep) => (
              <div key={rep.id} className="py-4 space-y-2.5">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2">
                    <span
                      className={`px-2 py-0.5 text-[10px] font-semibold rounded-full uppercase tracking-wider ${
                        rep.status === 'pending'
                          ? 'bg-amber-100 text-amber-800 border border-amber-200'
                          : rep.status === 'action_taken'
                          ? 'bg-rose-100 text-rose-800 border border-rose-200'
                          : 'bg-slate-100 text-slate-600'
                      }`}
                    >
                      {rep.status}
                    </span>
                    <span className="text-xs font-semibold text-slate-800">
                      Reason: {(rep.reason || 'General').replace(/_/g, ' ')}
                    </span>
                  </div>
                  <span className="text-[11px] text-slate-400 flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {new Date(rep.createdAt).toLocaleString()}
                  </span>
                </div>

                <div className="bg-slate-50 p-3 rounded-lg border border-slate-100 text-xs text-slate-700 space-y-1">
                  <div className="flex items-center gap-1.5 text-slate-500">
                    <User className="w-3.5 h-3.5" />
                    <span>Reported by:</span>
                    <strong className="text-slate-800 font-medium">{rep.reporterName}</strong>
                    <span>({rep.reporterRole})</span>
                  </div>
                  {rep.details && (
                    <p className="mt-1 text-slate-600 italic pl-5 border-l-2 border-slate-300">
                      "{rep.details}"
                    </p>
                  )}
                </div>

                {/* Resolution info if resolved */}
                {rep.status !== 'pending' && rep.resolutionNotes && (
                  <div className="p-2.5 bg-emerald-50/50 border border-emerald-100 rounded-lg text-xs text-emerald-800">
                    <span className="font-semibold">Resolution:</span> {rep.resolutionNotes} (by{' '}
                    {rep.resolvedBy || 'Admin'})
                  </div>
                )}

                {/* Actions */}
                <div className="flex items-center justify-between pt-1">
                  {onSelectConversation && (
                    <button
                      onClick={() => {
                        onSelectConversation(rep.conversationId);
                        onClose();
                      }}
                      className="text-xs text-indigo-600 hover:text-indigo-800 font-medium hover:underline"
                    >
                      View Conversation Thread →
                    </button>
                  )}

                  {rep.status === 'pending' && (
                    <div className="flex items-center gap-2">
                      {resolvingId === rep.id ? (
                        <div className="flex items-center gap-2">
                          <select
                            value={resolutionStatus}
                            onChange={(e) => setResolutionStatus(e.target.value as any)}
                            className="text-xs rounded border border-slate-200 px-2 py-1 bg-white"
                          >
                            <option value="action_taken">Action Taken</option>
                            <option value="dismissed">Dismiss Report</option>
                            <option value="reviewed">Mark Reviewed</option>
                          </select>
                          <input
                            type="text"
                            placeholder="Resolution notes..."
                            value={resolutionNotes}
                            onChange={(e) => setResolutionNotes(e.target.value)}
                            className="text-xs rounded border border-slate-200 px-2 py-1 w-48"
                          />
                          <button
                            onClick={() => handleResolve(rep.id)}
                            className="px-2.5 py-1 text-xs font-semibold bg-emerald-600 text-white rounded hover:bg-emerald-700"
                          >
                            Save
                          </button>
                          <button
                            onClick={() => setResolvingId(null)}
                            className="text-xs text-slate-400 hover:text-slate-600"
                          >
                            Cancel
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => setResolvingId(rep.id)}
                          className="px-3 py-1 text-xs font-medium bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg transition-colors"
                        >
                          Resolve Report
                        </button>
                      )}
                    </div>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
