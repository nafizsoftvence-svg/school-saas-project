import React, { useState } from 'react';
import { X, Printer, Download, CheckCircle2, ShieldCheck, Award, Building, Calendar, User } from 'lucide-react';
import { TransferCertificate } from '../../types';
import { downloadElementPdf, triggerSafePrint } from '../../utils/printPdf.js';

interface TransferCertificateViewerModalProps {
  certificate: TransferCertificate | null;
  onClose: () => void;
}

export const TransferCertificateViewerModal: React.FC<TransferCertificateViewerModalProps> = ({
  certificate,
  onClose
}) => {
  const [isExporting, setIsExporting] = useState(false);

  if (!certificate) return null;

  const handlePrint = async () => {
    try {
      setIsExporting(true);
      const cleanTc = (certificate.tcNumber || 'TC').replace(/[^a-zA-Z0-9_-]/g, '_');
      const filename = `TransferCertificate_${certificate.studentName.replace(/\s+/g, '_')}_${cleanTc}.pdf`;

      await downloadElementPdf('printable-transfer-certificate', filename, {
        orientation: 'portrait'
      });

      await triggerSafePrint({
        elementOrId: 'printable-transfer-certificate',
        fallbackTitle: `Transfer_Certificate_${cleanTc}`
      });
    } catch (err) {
      console.error('TC print/PDF error:', err);
      try {
        window.print();
      } catch {
        // ignore
      }
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-4xl rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Modal Top Bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/60 print:hidden">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-indigo-500/10 rounded-lg border border-indigo-500/20 text-indigo-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-white">Official Institutional Transfer Certificate</h2>
              <p className="text-xs text-slate-400 font-mono">Serial No: {certificate.tcNumber}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              disabled={isExporting}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white rounded-lg text-xs font-medium transition-colors"
            >
              <Printer className="w-4 h-4" />
              {isExporting ? 'Generating PDF...' : 'Print / Save PDF'}
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Certificate Body (Clean High-Contrast Document Aesthetic) */}
        <div
          id="printable-transfer-certificate"
          className="p-8 sm:p-12 bg-white text-slate-900 font-serif relative print:p-0 print:m-0"
        >
          {/* Institutional Header */}
          <div className="text-center border-b-2 border-slate-800 pb-6 mb-8">
            <div className="flex justify-center mb-2">
              <div className="w-16 h-16 rounded-full border-2 border-indigo-950 flex items-center justify-center bg-indigo-50 text-indigo-950 font-bold text-2xl font-sans">
                SYG
              </div>
            </div>
            <h1 className="text-3xl font-bold tracking-wide uppercase text-slate-900 font-sans">
              Sygmate International Academy
            </h1>
            <p className="text-xs text-slate-600 font-sans uppercase tracking-widest mt-1">
              Affiliated & Accredited Higher Secondary Board of Education
            </p>
            <p className="text-xs text-slate-500 font-sans mt-0.5">
              Campus Boulevard, Academic City • registrar@sygmate.edu • (800) 555-0199
            </p>
            <div className="inline-block mt-4 px-6 py-1.5 bg-slate-100 border border-slate-300 rounded text-sm font-bold uppercase tracking-wider text-slate-800 font-sans">
              Transfer & Character Certificate
            </div>
          </div>

          {/* Certificate Metadata Row */}
          <div className="flex justify-between items-center text-xs font-sans text-slate-600 mb-8 border-b border-slate-200 pb-3">
            <div>
              <span className="font-semibold text-slate-800">Certificate No:</span>{' '}
              <span className="font-mono text-indigo-700 font-bold">{certificate.tcNumber}</span>
            </div>
            <div>
              <span className="font-semibold text-slate-800">Admission / Student ID:</span>{' '}
              <span className="font-mono text-slate-800 font-bold">{certificate.admissionNumber}</span>
            </div>
            <div>
              <span className="font-semibold text-slate-800">Date of Issue:</span>{' '}
              <span className="font-mono text-slate-800">{certificate.issueDate}</span>
            </div>
          </div>

          {/* Certificate Narrative */}
          <div className="space-y-4 text-sm sm:text-base leading-relaxed text-slate-800">
            <p>
              This is to officially certify that <span className="font-bold underline decoration-indigo-300">{certificate.studentName}</span>, 
              son / daughter of <span className="font-semibold">{certificate.fatherName}</span> (Father/Guardian) and{' '}
              <span className="font-semibold">{certificate.motherName}</span> (Mother), was a bonafide student of this institution.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-y-3 gap-x-6 bg-slate-50 p-4 rounded-lg border border-slate-200 text-sm font-sans my-4">
              <div>
                <span className="text-slate-500">Date of Birth:</span>{' '}
                <span className="font-medium text-slate-900">{certificate.dateOfBirth}</span>
              </div>
              <div>
                <span className="text-slate-500">Nationality:</span>{' '}
                <span className="font-medium text-slate-900">{certificate.nationality}</span>
              </div>
              <div>
                <span className="text-slate-500">Academic Session Enrolled:</span>{' '}
                <span className="font-medium text-slate-900">{certificate.academicSessionName}</span>
              </div>
              <div>
                <span className="text-slate-500">Class & Section at Leaving:</span>{' '}
                <span className="font-semibold text-slate-900">{certificate.classLeft} - {certificate.sectionLeft}</span>
              </div>
              <div>
                <span className="text-slate-500">Official Date of Leaving:</span>{' '}
                <span className="font-medium text-slate-900">{certificate.dateOfLeaving}</span>
              </div>
              <div>
                <span className="text-slate-500">Institutional Dues Status:</span>{' '}
                <span className={`font-semibold ${certificate.hasClearedAllDues ? 'text-emerald-700' : 'text-amber-700'}`}>
                  {certificate.hasClearedAllDues ? 'All Dues Fully Paid & Cleared' : 'Conditional Clearance'}
                </span>
              </div>
              <div>
                <span className="text-slate-500">Total Academic Attendance:</span>{' '}
                <span className="font-medium text-slate-900">{certificate.attendedDays} / {certificate.totalAttendanceDays} days ({Math.round((certificate.attendedDays / certificate.totalAttendanceDays) * 100)}%)</span>
              </div>
              <div>
                <span className="text-slate-500">General Conduct & Character:</span>{' '}
                <span className="font-semibold text-indigo-900">{certificate.generalConduct}</span>
              </div>
            </div>

            <p>
              <span className="font-semibold">Reason for Leaving:</span> {certificate.reasonForLeaving}
            </p>

            {certificate.remarks && (
              <p className="italic text-slate-600 bg-amber-50/60 p-3 rounded border border-amber-200/60 text-xs">
                Institutional Remarks: {certificate.remarks}
              </p>
            )}

            <p className="mt-6">
              To our best knowledge, the pupil bears good moral character. We extend our warmest wishes for success and distinction in all future academic endeavors.
            </p>
          </div>

          {/* Verification QR & Signature Blocks */}
          <div className="mt-12 pt-8 border-t-2 border-slate-200 flex flex-col sm:flex-row justify-between items-end gap-6 font-sans">
            {/* QR Code Verification Block */}
            <div className="flex items-center gap-3 p-3 bg-slate-100 rounded-xl border border-slate-300">
              <div className="w-20 h-20 bg-white border border-slate-300 p-1 flex items-center justify-center rounded">
                {/* SVG QR Code Simulation with cryptographic pattern */}
                <svg viewBox="0 0 100 100" className="w-full h-full">
                  <rect x="0" y="0" width="100" height="100" fill="white" />
                  <rect x="10" y="10" width="25" height="25" fill="#1e1b4b" />
                  <rect x="15" y="15" width="15" height="15" fill="white" />
                  <rect x="19" y="19" width="7" height="7" fill="#1e1b4b" />
                  
                  <rect x="65" y="10" width="25" height="25" fill="#1e1b4b" />
                  <rect x="70" y="15" width="15" height="15" fill="white" />
                  <rect x="74" y="19" width="7" height="7" fill="#1e1b4b" />

                  <rect x="10" y="65" width="25" height="25" fill="#1e1b4b" />
                  <rect x="15" y="70" width="15" height="15" fill="white" />
                  <rect x="19" y="74" width="7" height="7" fill="#1e1b4b" />

                  {/* QR Data Dots */}
                  <rect x="42" y="15" width="6" height="6" fill="#1e1b4b" />
                  <rect x="52" y="25" width="6" height="6" fill="#1e1b4b" />
                  <rect x="42" y="45" width="8" height="8" fill="#1e1b4b" />
                  <rect x="55" y="55" width="8" height="8" fill="#1e1b4b" />
                  <rect x="75" y="65" width="8" height="8" fill="#1e1b4b" />
                  <rect x="65" y="80" width="8" height="8" fill="#1e1b4b" />
                  <rect x="45" y="75" width="6" height="6" fill="#1e1b4b" />
                </svg>
              </div>
              <div className="text-[11px] text-slate-600 leading-tight">
                <div className="font-bold text-slate-900 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  Verified Document
                </div>
                <div className="font-mono text-[10px] text-slate-500 mt-0.5">{certificate.tcNumber}</div>
                <div className="text-[10px] text-slate-400 mt-1">Scan to verify institutional integrity</div>
              </div>
            </div>

            {/* Official Signatures */}
            <div className="flex gap-12 text-center text-xs">
              <div className="flex flex-col items-center">
                <div className="w-32 border-b border-slate-700 mb-1 pb-4 font-mono text-[10px] text-slate-400 italic">
                  {certificate.issuedByName}
                </div>
                <span className="font-semibold text-slate-800">Prepared & Checked By</span>
                <span className="text-[10px] text-slate-500">Office of Admissions</span>
              </div>
              <div className="flex flex-col items-center">
                <div className="w-36 border-b border-slate-700 mb-1 pb-4 font-serif font-bold italic text-slate-800">
                  Dr. H. Vance, Ph.D.
                </div>
                <span className="font-semibold text-slate-800">Head of Institution</span>
                <span className="text-[10px] text-slate-500">Principal / Director</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
