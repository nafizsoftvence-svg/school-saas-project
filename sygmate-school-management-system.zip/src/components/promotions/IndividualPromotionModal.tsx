import React, { useState, useEffect } from 'react';
import {
  X,
  GraduationCap,
  Sparkles,
  AlertCircle,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  ShieldCheck,
  DollarSign
} from 'lucide-react';
import { api } from '../../services/api';
import { AcademicSession, SchoolClass, Section, StudentProfile } from '../../types';
import { LoadingSpinner } from '../ui/LoadingSpinner';

interface IndividualPromotionModalProps {
  students: StudentProfile[];
  sessions: AcademicSession[];
  classes: SchoolClass[];
  sections: Section[];
  preselectedStudentId?: string;
  onClose: () => void;
  onCompleted: () => void;
}

export const IndividualPromotionModal: React.FC<IndividualPromotionModalProps> = ({
  students,
  sessions,
  classes,
  sections,
  preselectedStudentId,
  onClose,
  onCompleted
}) => {
  const [studentId, setStudentId] = useState(preselectedStudentId || (students?.[0]?.id ?? ''));
  const activeSession = (sessions || []).find((s) => s.isActive) || sessions?.[0];
  const nextSession = (sessions || []).find((s) => s.id !== activeSession?.id) || sessions?.[0];

  const [targetSessionId, setTargetSessionId] = useState(nextSession?.id || '');
  const [targetClassId, setTargetClassId] = useState('');
  const [targetSectionId, setTargetSectionId] = useState('');
  const [targetRollNumber, setTargetRollNumber] = useState('');
  const [promotionType, setPromotionType] = useState<'PROMOTED' | 'RETAINED' | 'DOUBLE_PROMOTED'>('PROMOTED');
  const [feeOverrideApproved, setFeeOverrideApproved] = useState(false);
  const [feeOverrideReason, setFeeOverrideReason] = useState('');
  const [remarks, setRemarks] = useState('');

  const [standingLoading, setStandingLoading] = useState(false);
  const [standing, setStanding] = useState<any>(null);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const selectedStudent = (students || []).find((s) => s.id === studentId);

  // Auto pick next class when student changes
  useEffect(() => {
    if (selectedStudent) {
      const curClassIdx = (classes || []).findIndex((c) => c.id === selectedStudent.classId);
      if (curClassIdx >= 0 && curClassIdx < (classes || []).length - 1) {
        setTargetClassId(classes?.[curClassIdx + 1]?.id || '');
      }
      // Load standing
      fetchStanding(selectedStudent.id);
    }
  }, [studentId, selectedStudent]);

  // Target sections
  const targetSections = (sections || []).filter((s) => !targetClassId || s.classId === targetClassId);

  useEffect(() => {
    if (targetSections.length > 0 && !targetSectionId) {
      setTargetSectionId(targetSections?.[0]?.id || '');
    }
  }, [targetClassId, targetSections]);

  const fetchStanding = async (id: string) => {
    setStandingLoading(true);
    try {
      const res = await api.promotionsTransfers.getStudentStanding(id);
      if (res.success) {
        setStanding(res.standing);
      }
    } catch (e) {
      // ignore non-fatal standing error
    } finally {
      setStandingLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!studentId || !targetSessionId || !targetClassId || !targetSectionId || !targetRollNumber) {
      setError('Please fill in all mandatory target placement fields.');
      return;
    }

    if (standing?.hasOutstandingFees && !feeOverrideApproved) {
      setError('Student has outstanding fees. You must check fee override approval to proceed.');
      return;
    }

    setError(null);
    setSubmitting(true);

    try {
      const res = await api.promotionsTransfers.promoteIndividual({
        studentId,
        targetSessionId,
        targetClassId,
        targetSectionId,
        targetRollNumber,
        promotionType,
        feeOverrideApproved,
        feeOverrideReason: feeOverrideApproved ? feeOverrideReason : undefined,
        remarks: remarks || undefined
      });

      if (res.success) {
        onCompleted();
      } else {
        setError('Promotion failed.');
      }
    } catch (err: any) {
      setError(err.message || 'Failed to promote student');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden my-6">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-500/10 rounded-xl border border-indigo-500/20 text-indigo-400">
              <GraduationCap className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Individual Student Promotion</h2>
              <p className="text-xs text-slate-400">Advance student placement into the next academic session</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {error && (
            <div className="p-3.5 bg-rose-500/10 border border-rose-500/20 text-rose-300 rounded-xl text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Student Selector */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Select Student *</label>
            <select
              value={studentId}
              onChange={(e) => setStudentId(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
            >
              {students.map((st) => (
                <option key={st.id} value={st.id}>
                  {st.name} ({st.admissionNumber}) — {st.className} ({st.sectionName})
                </option>
              ))}
            </select>
          </div>

          {/* Real-Time Standing Metrics Card */}
          {standing && (
            <div className="bg-slate-800/40 border border-slate-700/60 rounded-xl p-4 text-xs">
              <div className="text-[10px] uppercase font-bold text-slate-400 mb-2">Student Standing Diagnostics</div>
              <div className="grid grid-cols-3 gap-3">
                <div className="bg-slate-900/60 p-2.5 rounded-lg border border-slate-800">
                  <div className="text-slate-400 text-[10px]">Academic GPA</div>
                  <div className="font-bold text-white text-sm">{(standing?.cumulativeGPA ?? 0).toFixed(2)}</div>
                  <div className="text-[10px] text-emerald-400 font-medium">
                    {standing?.passedAllCore ? 'Passed All Core' : `${standing?.failedExams ?? 0} Failed`}
                  </div>
                </div>

                <div className="bg-slate-900/60 p-2.5 rounded-lg border border-slate-800">
                  <div className="text-slate-400 text-[10px]">Attendance Rate</div>
                  <div
                    className={`font-bold text-sm ${
                      (standing?.attendancePercentage ?? 0) >= 75 ? 'text-emerald-400' : 'text-amber-400'
                    }`}
                  >
                    {standing?.attendancePercentage ?? 0}%
                  </div>
                  <div className="text-[10px] text-slate-400">{standing?.attendanceStanding || 'N/A'}</div>
                </div>

                <div className="bg-slate-900/60 p-2.5 rounded-lg border border-slate-800">
                  <div className="text-slate-400 text-[10px]">Fee Clearance</div>
                  <div
                    className={`font-bold text-sm ${
                      standing?.hasOutstandingFees ? 'text-rose-400' : 'text-emerald-400'
                    }`}
                  >
                    {standing?.hasOutstandingFees ? `$${standing?.totalDueFees ?? 0} Due` : 'Cleared'}
                  </div>
                  <div className="text-[10px] text-slate-400">
                    {standing?.hasOutstandingFees ? 'Hold Required' : 'Eligible'}
                  </div>
                </div>
              </div>

              {/* Fee Override Option if Due */}
              {standing.hasOutstandingFees && (
                <div className="mt-3 p-3 bg-amber-500/10 border border-amber-500/20 rounded-lg space-y-2">
                  <label className="inline-flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={feeOverrideApproved}
                      onChange={(e) => setFeeOverrideApproved(e.target.checked)}
                      className="w-4 h-4 text-amber-600 rounded bg-slate-900 border-slate-700"
                    />
                    <span className="text-amber-300 font-semibold text-xs">
                      Administrative Override: Approve promotion despite fee dues
                    </span>
                  </label>
                  {feeOverrideApproved && (
                    <input
                      type="text"
                      value={feeOverrideReason}
                      onChange={(e) => setFeeOverrideReason(e.target.value)}
                      placeholder="Specify justification reason for fee override..."
                      className="w-full bg-slate-900 border border-slate-700 rounded px-2.5 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                    />
                  )}
                </div>
              )}
            </div>
          )}

          {/* Target Parameters */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Target Academic Session *</label>
              <select
                value={targetSessionId}
                onChange={(e) => setTargetSessionId(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
              >
                {sessions.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Promotion Type</label>
              <select
                value={promotionType}
                onChange={(e) => setPromotionType(e.target.value as any)}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
              >
                <option value="PROMOTED">Standard Promotion</option>
                <option value="DOUBLE_PROMOTED">Accelerated / Double Promotion</option>
                <option value="RETAINED">Retention (Repeat Level)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Target Class *</label>
              <select
                value={targetClassId}
                onChange={(e) => setTargetClassId(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
              >
                <option value="">-- Select Class --</option>
                {classes.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Target Section *</label>
              <select
                value={targetSectionId}
                onChange={(e) => setTargetSectionId(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
              >
                <option value="">-- Select Section --</option>
                {targetSections.map((sec) => (
                  <option key={sec.id} value={sec.id}>
                    Section {sec.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-medium text-slate-300 mb-1">Assigned Target Roll Number *</label>
              <input
                type="text"
                value={targetRollNumber}
                onChange={(e) => setTargetRollNumber(e.target.value)}
                placeholder="e.g. 01, 101, A-04"
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white font-mono"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-medium text-slate-300 mb-1">Remarks & Academic Notes</label>
              <input
                type="text"
                value={remarks}
                onChange={(e) => setRemarks(e.target.value)}
                placeholder="Optional notes regarding this promotion decision..."
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
              />
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5"
            >
              {submitting ? <LoadingSpinner size="sm" /> : <CheckCircle2 className="w-4 h-4" />}
              Execute Promotion
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
