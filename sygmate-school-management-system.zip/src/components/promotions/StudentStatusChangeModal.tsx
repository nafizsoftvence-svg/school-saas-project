import React, { useState } from 'react';
import {
  X,
  UserCheck,
  AlertCircle,
  CheckCircle2,
  Calendar,
  Clock,
  ShieldAlert,
  ArrowRight,
  Lock
} from 'lucide-react';
import { api } from '../../services/api';
import { StudentProfile, StudentStatusType } from '../../types';
import { LoadingSpinner } from '../ui/LoadingSpinner';

interface StudentStatusChangeModalProps {
  student: StudentProfile;
  onClose: () => void;
  onSuccess: () => void;
}

export const StudentStatusChangeModal: React.FC<StudentStatusChangeModalProps> = ({
  student,
  onClose,
  onSuccess
}) => {
  const [newStatus, setNewStatus] = useState<StudentStatusType>('suspended');
  const [effectiveDate, setEffectiveDate] = useState(new Date().toISOString().split('T')[0]);
  const [endDate, setEndDate] = useState('');
  const [reason, setReason] = useState('');
  const [suspensionTerms, setSuspensionTerms] = useState('');
  const [remarks, setRemarks] = useState('');

  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newStatus || !reason || !effectiveDate) {
      setError('Please provide status, effective date, and justification reason.');
      return;
    }

    if (newStatus === student.status) {
      setError(`Student is already in '${student.status}' status.`);
      return;
    }

    setError(null);
    setSubmitting(true);

    try {
      const res = await api.promotionsTransfers.changeStudentStatus({
        studentId: student.id,
        newStatus,
        effectiveDate,
        endDate: endDate || undefined,
        reason,
        suspensionTerms: suspensionTerms || undefined,
        remarks: remarks || undefined
      });

      if (res.success) {
        onSuccess();
      } else {
        setError('Failed to update student status');
      }
    } catch (err: any) {
      setError(err.message || 'Failed to update student status');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden my-6">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-amber-500/10 rounded-xl border border-amber-500/20 text-amber-400">
              <UserCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Student Status Lifecycle Transition</h2>
              <p className="text-xs text-slate-400">
                {student.name} ({student.admissionNumber})
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {error && (
            <div className="p-3 bg-rose-500/10 border border-rose-500/20 text-rose-300 rounded-xl text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Current Status Indicator */}
          <div className="p-3 bg-slate-800/40 border border-slate-700/60 rounded-xl flex items-center justify-between text-xs">
            <span className="text-slate-400">Current Status:</span>
            <div className="flex items-center gap-2">
              <span className="font-mono uppercase font-bold text-slate-300 px-2.5 py-0.5 rounded-full bg-slate-800 border border-slate-700">
                {student.status}
              </span>
              <ArrowRight className="w-3.5 h-3.5 text-slate-500" />
              <span className="font-mono uppercase font-bold text-amber-400 px-2.5 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/20">
                {newStatus}
              </span>
            </div>
          </div>

          {/* Status Selection */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">New Target Status *</label>
            <select
              value={newStatus}
              onChange={(e) => setNewStatus(e.target.value as any)}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white font-medium"
            >
              <option value="active">ACTIVE — Fully Enrolled & Authorized</option>
              <option value="inactive">INACTIVE — Administrative Dormancy</option>
              <option value="suspended">SUSPENDED — Disciplinary / Temporary Hold</option>
              <option value="withdrawn">WITHDRAWN — Voluntary Official Exit</option>
              <option value="graduated">GRADUATED — Completed Institutional Program</option>
              <option value="transferred">TRANSFERRED — Relocated to External School</option>
              <option value="alumni">ALUMNI — Post-Graduation Registry</option>
            </select>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Effective Date *</label>
              <input
                type="date"
                value={effectiveDate}
                onChange={(e) => setEffectiveDate(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
              />
            </div>

            {newStatus === 'suspended' && (
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Suspension End Date</label>
                <input
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
                />
              </div>
            )}
          </div>

          {/* Reason */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Mandatory Justification Reason *</label>
            <input
              type="text"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="e.g. Disciplinary suspension approved by Academic Board; Completed final semester"
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
            />
          </div>

          {newStatus === 'suspended' && (
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Suspension Conditions & Terms</label>
              <textarea
                value={suspensionTerms}
                onChange={(e) => setSuspensionTerms(e.target.value)}
                rows={2}
                placeholder="e.g. Prohibited from campus premises; portal credentials restricted pending board review"
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white resize-none"
              />
            </div>
          )}

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Administrative Notes (Optional)</label>
            <input
              type="text"
              value={remarks}
              onChange={(e) => setRemarks(e.target.value)}
              placeholder="Internal file remarks..."
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
            />
          </div>

          {/* System Impact Notice */}
          <div className="p-3 bg-slate-800/30 border border-slate-700/40 rounded-xl text-[11px] text-slate-400 flex items-start gap-2">
            <Lock className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
            <p>
              Updating status cascades securely: Inactive, Suspended, Withdrawn, and Transferred students automatically have their linked portal user account disabled to prevent unauthorized campus access.
            </p>
          </div>

          <div className="flex justify-end gap-3 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-5 py-2 bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5"
            >
              {submitting ? <LoadingSpinner size="sm" /> : <CheckCircle2 className="w-4 h-4" />}
              Commit Status Change
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
