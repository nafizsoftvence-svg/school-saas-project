import React, { useState, useEffect } from 'react';
import {
  X,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  AlertTriangle,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Users,
  Settings,
  DollarSign,
  ChevronRight,
  Check,
  RefreshCw,
  Edit3
} from 'lucide-react';
import { api } from '../../services/api';
import { AcademicSession, SchoolClass, Section } from '../../types';
import { LoadingSpinner } from '../ui/LoadingSpinner';

interface BulkPromotionWizardProps {
  sessions: AcademicSession[];
  classes: SchoolClass[];
  sections: Section[];
  onClose: () => void;
  onCompleted: (batchId: string) => void;
}

export const BulkPromotionWizard: React.FC<BulkPromotionWizardProps> = ({
  sessions,
  classes,
  sections,
  onClose,
  onCompleted
}) => {
  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);

  // Configuration Form State
  const activeSession = (sessions || []).find((s) => s.isActive) || sessions?.[0];
  const nextSession = (sessions || []).find((s) => s.id !== activeSession?.id) || sessions?.[0];

  const [sourceSessionId, setSourceSessionId] = useState(activeSession?.id || '');
  const [targetSessionId, setTargetSessionId] = useState(nextSession?.id || '');
  const [sourceClassId, setSourceClassId] = useState('');
  const [sourceSectionId, setSourceSectionId] = useState('');
  const [targetClassId, setTargetClassId] = useState('');
  const [targetSectionId, setTargetSectionId] = useState('');

  // Policy Thresholds
  const [minGpa, setMinGpa] = useState<number>(2.0);
  const [minAttendanceRate, setMinAttendanceRate] = useState<number>(75);
  const [requireFeeClearance, setRequireFeeClearance] = useState<boolean>(true);

  // Dry-Run Evaluation Data
  const [previewLoading, setPreviewLoading] = useState(false);
  const [previewData, setPreviewData] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  // Student Decisions Map
  const [decisions, setDecisions] = useState<{
    [studentId: string]: {
      action: 'PROMOTE' | 'RETAIN' | 'GRADUATE' | 'EXCLUDE';
      targetRollNumber: string;
      feeOverrideApproved: boolean;
      feeOverrideReason: string;
      attendanceOverrideApproved: boolean;
      remarks: string;
    };
  }>({});

  // Execution State
  const [executing, setExecuting] = useState(false);
  const [executionResult, setExecutionResult] = useState<any>(null);

  // Filter sections when class changes
  const sourceSections = sections.filter((s) => !sourceClassId || s.classId === sourceClassId);
  const targetSections = sections.filter((s) => !targetClassId || s.classId === targetClassId);

  // Suggest next class automatically when source class is picked
  const handleSourceClassChange = (selectedClassId: string) => {
    setSourceClassId(selectedClassId);
    const sourceIndex = classes.findIndex((c) => c.id === selectedClassId);
    if (sourceIndex >= 0 && sourceIndex < classes.length - 1) {
      // Pick next class in hierarchy
      setTargetClassId(classes[sourceIndex + 1].id);
    }
  };

  // Run Preview
  const handleRunPreview = async () => {
    if (!sourceSessionId || !sourceClassId || !targetSessionId || !targetClassId) {
      setError('Please select source & target academic sessions and classes.');
      return;
    }

    setError(null);
    setPreviewLoading(true);
    try {
      const res = await api.promotionsTransfers.previewBulkPromotion({
        sourceSessionId,
        sourceClassId,
        sourceSectionId: sourceSectionId || undefined,
        targetSessionId,
        targetClassId,
        targetSectionId: targetSectionId || undefined,
        minGpa,
        minAttendanceRate,
        requireFeeClearance
      });

      if (res.success) {
        setPreviewData(res);

        // Initialize decisions map
        const initialMap: any = {};
        res.students.forEach((student: any) => {
          let defaultAction: 'PROMOTE' | 'RETAIN' | 'GRADUATE' | 'EXCLUDE' = 'PROMOTE';
          if (student.eligibilityStatus === 'FAILED_ACADEMIC') {
            defaultAction = 'RETAIN';
          }

          initialMap[student.studentId] = {
            action: defaultAction,
            targetRollNumber: student.assignedRollNumber || '',
            feeOverrideApproved: false,
            feeOverrideReason: '',
            attendanceOverrideApproved: false,
            remarks: ''
          };
        });

        setDecisions(initialMap);
        setStep(2);
      } else {
        setError('Failed to preview promotion');
      }
    } catch (err: any) {
      setError(err.message || 'Error executing preview');
    } finally {
      setPreviewLoading(false);
    }
  };

  // Update a student's decision
  const updateStudentDecision = (studentId: string, field: string, value: any) => {
    setDecisions((prev) => ({
      ...prev,
      [studentId]: {
        ...prev[studentId],
        [field]: value
      }
    }));
  };

  // Bulk Apply Action
  const handleBulkSetAction = (action: 'PROMOTE' | 'RETAIN' | 'EXCLUDE') => {
    setDecisions((prev) => {
      const updated: any = { ...prev };
      Object.keys(updated).forEach((id) => {
        updated[id].action = action;
      });
      return updated;
    });
  };

  // Execute Bulk Promotion
  const handleExecuteBulk = async () => {
    setExecuting(true);
    setError(null);

    const decisionsList = Object.keys(decisions).map((studentId) => {
      const d = decisions[studentId];
      return {
        studentId,
        action: d.action,
        targetRollNumber: d.targetRollNumber,
        targetSectionId: targetSectionId || undefined,
        feeOverrideApproved: d.feeOverrideApproved,
        feeOverrideReason: d.feeOverrideReason,
        attendanceOverrideApproved: d.attendanceOverrideApproved,
        remarks: d.remarks
      };
    });

    try {
      const res = await api.promotionsTransfers.executeBulkPromotion({
        title: `Annual Promotion: ${previewData.sourceClassName} to ${previewData.targetClassName} (${previewData.targetSessionName})`,
        sourceSessionId,
        sourceClassId,
        sourceSectionId: sourceSectionId || undefined,
        targetSessionId,
        targetClassId,
        targetSectionId: targetSectionId || undefined,
        decisions: decisionsList
      });

      if (res.success) {
        setExecutionResult(res);
        setStep(4);
        onCompleted(res.batchId);
      } else {
        setError('Execution failed');
      }
    } catch (err: any) {
      setError(err.message || 'Failed to execute bulk promotion');
    } finally {
      setExecuting(false);
    }
  };

  // Compute live step 3 summary
  const decisionsListValues = Object.values(decisions) as Array<{
    action: 'PROMOTE' | 'RETAIN' | 'GRADUATE' | 'EXCLUDE';
    targetRollNumber: string;
    feeOverrideApproved: boolean;
    feeOverrideReason: string;
    attendanceOverrideApproved: boolean;
    remarks: string;
  }>;
  const summaryCounts = {
    promote: decisionsListValues.filter((d) => d.action === 'PROMOTE').length,
    retain: decisionsListValues.filter((d) => d.action === 'RETAIN').length,
    graduate: decisionsListValues.filter((d) => d.action === 'GRADUATE').length,
    exclude: decisionsListValues.filter((d) => d.action === 'EXCLUDE').length
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-5xl rounded-2xl shadow-2xl overflow-hidden my-6 flex flex-col max-h-[92vh]">
        {/* Wizard Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-500/10 rounded-xl border border-indigo-500/20 text-indigo-400">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Batch Student Promotion Engine</h2>
              <p className="text-xs text-slate-400">
                End-of-term academic session progression, criteria evaluation, and atomic placement
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Wizard Step Progress Tracker */}
        <div className="px-6 py-3 border-b border-slate-800 bg-slate-950/30 flex items-center justify-between">
          {[
            { num: 1, title: 'Session & Parameters' },
            { num: 2, title: 'Dry Run & Decisions' },
            { num: 3, title: 'Confirmation Summary' },
            { num: 4, title: 'Execution Output' }
          ].map((s, idx) => (
            <div key={s.num} className="flex items-center gap-2">
              <div
                className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold transition-colors ${
                  step === s.num
                    ? 'bg-indigo-600 text-white ring-4 ring-indigo-500/20'
                    : step > s.num
                    ? 'bg-emerald-600 text-white'
                    : 'bg-slate-800 text-slate-400'
                }`}
              >
                {step > s.num ? <Check className="w-4 h-4" /> : s.num}
              </div>
              <span className={`text-xs font-medium hidden sm:inline ${step === s.num ? 'text-white' : 'text-slate-400'}`}>
                {s.title}
              </span>
              {idx < 3 && <ChevronRight className="w-4 h-4 text-slate-600 hidden sm:inline ml-2" />}
            </div>
          ))}
        </div>

        {/* Body Content */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {error && (
            <div className="p-3.5 bg-rose-500/10 border border-rose-500/20 text-rose-300 rounded-xl text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* STEP 1: CONFIGURATION */}
          {step === 1 && (
            <div className="space-y-6 max-w-4xl mx-auto">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Source Card */}
                <div className="bg-slate-800/40 border border-slate-700/60 rounded-xl p-5 space-y-4">
                  <div className="flex items-center gap-2 text-indigo-400 text-xs font-bold uppercase tracking-wider">
                    <span className="w-2 h-2 rounded-full bg-indigo-500" />
                    Source Academic Assignment
                  </div>

                  <div>
                    <label className="block text-xs text-slate-300 mb-1 font-medium">Source Academic Session *</label>
                    <select
                      value={sourceSessionId}
                      onChange={(e) => setSourceSessionId(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                    >
                      {sessions.map((s) => (
                        <option key={s.id} value={s.id}>
                          {s.name} {s.isActive ? '(Current Active Session)' : ''}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs text-slate-300 mb-1 font-medium">Source Class *</label>
                    <select
                      value={sourceClassId}
                      onChange={(e) => handleSourceClassChange(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                    >
                      <option value="">-- Select Class --</option>
                      {classes.map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs text-slate-300 mb-1 font-medium">Source Section (Optional)</label>
                    <select
                      value={sourceSectionId}
                      onChange={(e) => setSourceSectionId(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                    >
                      <option value="">All Sections in Class</option>
                      {sourceSections.map((sec) => (
                        <option key={sec.id} value={sec.id}>
                          Section {sec.name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Target Card */}
                <div className="bg-slate-800/40 border border-slate-700/60 rounded-xl p-5 space-y-4">
                  <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold uppercase tracking-wider">
                    <span className="w-2 h-2 rounded-full bg-emerald-500" />
                    Target Destination Assignment
                  </div>

                  <div>
                    <label className="block text-xs text-slate-300 mb-1 font-medium">Target Academic Session *</label>
                    <select
                      value={targetSessionId}
                      onChange={(e) => setTargetSessionId(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                    >
                      {sessions.map((s) => (
                        <option key={s.id} value={s.id}>
                          {s.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs text-slate-300 mb-1 font-medium">Target Class *</label>
                    <select
                      value={targetClassId}
                      onChange={(e) => setTargetClassId(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                    >
                      <option value="">-- Select Target Class --</option>
                      {classes.map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs text-slate-300 mb-1 font-medium">Target Section</label>
                    <select
                      value={targetSectionId}
                      onChange={(e) => setTargetSectionId(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                    >
                      <option value="">Retain Equivalent Section</option>
                      {targetSections.map((sec) => (
                        <option key={sec.id} value={sec.id}>
                          Section {sec.name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              {/* Policy Thresholds Card */}
              <div className="bg-slate-800/30 border border-slate-700/50 rounded-xl p-5 space-y-4">
                <h3 className="text-xs uppercase tracking-wider font-bold text-slate-300 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-indigo-400" />
                  Academic Eligibility Criteria & Rules
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
                  <div>
                    <label className="block text-slate-400 mb-1">Minimum GPA Threshold</label>
                    <input
                      type="number"
                      step="0.1"
                      min="0"
                      max="4.0"
                      value={minGpa}
                      onChange={(e) => setMinGpa(parseFloat(e.target.value) || 0)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-white"
                    />
                    <span className="text-[10px] text-slate-500">Passing cut-off for promotion</span>
                  </div>

                  <div>
                    <label className="block text-slate-400 mb-1">Min Attendance Requirement (%)</label>
                    <input
                      type="number"
                      min="0"
                      max="100"
                      value={minAttendanceRate}
                      onChange={(e) => setMinAttendanceRate(parseInt(e.target.value, 10) || 0)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-white"
                    />
                    <span className="text-[10px] text-slate-500">Flags attendance warning if below</span>
                  </div>

                  <div>
                    <label className="block text-slate-400 mb-1">Financial Clearance Rule</label>
                    <div className="pt-2">
                      <label className="inline-flex items-center gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={requireFeeClearance}
                          onChange={(e) => setRequireFeeClearance(e.target.checked)}
                          className="w-4 h-4 rounded text-indigo-600 bg-slate-900 border-slate-700"
                        />
                        <span className="text-slate-300 font-medium">Require Zero Fee Dues</span>
                      </label>
                    </div>
                    <span className="text-[10px] text-slate-500">Flags students with unpaid dues</span>
                  </div>
                </div>
              </div>

              <div className="flex justify-end pt-4">
                <button
                  onClick={handleRunPreview}
                  disabled={previewLoading || !sourceClassId || !targetClassId}
                  className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white rounded-xl text-xs font-semibold flex items-center gap-2 transition-colors shadow-lg shadow-indigo-600/20"
                >
                  {previewLoading ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <Sparkles className="w-4 h-4" />
                  )}
                  Run Eligibility Evaluation & Dry-Run Preview
                </button>
              </div>
            </div>
          )}

          {/* STEP 2: DRY-RUN TABLE & DECISION OVERRIDES */}
          {step === 2 && previewData && (
            <div className="space-y-4">
              {/* Top Banner Stats */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="bg-slate-800/40 border border-slate-700/60 rounded-xl p-3 text-center">
                  <div className="text-[10px] uppercase font-bold text-slate-400">Total Evaluated</div>
                  <div className="text-xl font-bold text-white mt-0.5">{previewData.summary.totalStudents}</div>
                </div>
                <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-xl p-3 text-center">
                  <div className="text-[10px] uppercase font-bold text-emerald-400">Eligible to Promote</div>
                  <div className="text-xl font-bold text-emerald-300 mt-0.5">{previewData.summary.eligibleCount}</div>
                </div>
                <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl p-3 text-center">
                  <div className="text-[10px] uppercase font-bold text-amber-400">Fee / Attn. Warnings</div>
                  <div className="text-xl font-bold text-amber-300 mt-0.5">
                    {previewData.summary.warningFeesCount + previewData.summary.warningAttendanceCount}
                  </div>
                </div>
                <div className="bg-rose-500/10 border border-rose-500/20 rounded-xl p-3 text-center">
                  <div className="text-[10px] uppercase font-bold text-rose-400">Failed / Retain</div>
                  <div className="text-xl font-bold text-rose-300 mt-0.5">{previewData.summary.failedCount}</div>
                </div>
              </div>

              {/* Quick Actions Bar */}
              <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-950/40 p-3 rounded-xl border border-slate-800 text-xs">
                <div className="text-slate-400">
                  Transition: <span className="text-white font-semibold">{previewData.sourceClassName}</span> ({previewData.sourceSessionName}){' '}
                  <ArrowRight className="w-3 h-3 inline text-slate-500 mx-1" />{' '}
                  <span className="text-emerald-400 font-semibold">{previewData.targetClassName}</span> ({previewData.targetSessionName})
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-slate-400 text-[11px]">Quick Action:</span>
                  <button
                    onClick={() => handleBulkSetAction('PROMOTE')}
                    className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-[11px] font-medium"
                  >
                    Set All Promote
                  </button>
                  <button
                    onClick={() => handleBulkSetAction('EXCLUDE')}
                    className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-[11px] font-medium"
                  >
                    Set All Exclude
                  </button>
                </div>
              </div>

              {/* Student Decisions Table */}
              <div className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-900/50">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-slate-950/80 text-slate-400 uppercase text-[10px]">
                    <tr>
                      <th className="px-3 py-3">Student & Roll</th>
                      <th className="px-3 py-3">Academic GPA</th>
                      <th className="px-3 py-3">Attendance</th>
                      <th className="px-3 py-3">Fee Standing</th>
                      <th className="px-3 py-3">Evaluation Result</th>
                      <th className="px-3 py-3">Assigned Roll</th>
                      <th className="px-3 py-3">Decision</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {previewData.students.map((st: any) => {
                      const dec = decisions[st.studentId] || {
                        action: 'PROMOTE',
                        targetRollNumber: st.assignedRollNumber,
                        feeOverrideApproved: false
                      };

                      return (
                        <tr key={st.studentId} className="hover:bg-slate-800/30">
                          <td className="px-3 py-3">
                            <div className="font-bold text-white">{st.studentName}</div>
                            <div className="text-[11px] text-slate-400 font-mono">
                              {st.admissionNumber} • Roll: {st.currentRollNumber}
                            </div>
                          </td>
                          <td className="px-3 py-3">
                            <div className="font-bold text-slate-200">{st.standing?.cumulativeGPA ? st.standing.cumulativeGPA.toFixed(2) : '0.00'}</div>
                            <div className="text-[10px] text-slate-400">
                              {st.standing?.passedAllCore ? (
                                <span className="text-emerald-400">All Core Passed</span>
                              ) : (
                                <span className="text-rose-400">{st.standing?.failedExams || 0} Exams Failed</span>
                              )}
                            </div>
                          </td>
                          <td className="px-3 py-3">
                            <div
                              className={`font-semibold ${
                                (st.standing?.attendancePercentage ?? 0) >= 75 ? 'text-emerald-400' : 'text-amber-400'
                              }`}
                            >
                              {st.standing?.attendancePercentage ?? 0}%
                            </div>
                            <div className="text-[10px] text-slate-500">{st.standing?.attendanceStanding || 'Good'}</div>
                          </td>
                          <td className="px-3 py-3">
                            {st.standing?.hasOutstandingFees ? (
                              <div>
                                <div className="text-rose-400 font-semibold">${st.standing.totalDueFees} Due</div>
                                <label className="inline-flex items-center gap-1 mt-1 text-[10px] text-amber-300 cursor-pointer">
                                  <input
                                    type="checkbox"
                                    checked={dec.feeOverrideApproved}
                                    onChange={(e) =>
                                      updateStudentDecision(st.studentId, 'feeOverrideApproved', e.target.checked)
                                    }
                                    className="w-3 h-3 text-amber-500 rounded bg-slate-800 border-slate-700"
                                  />
                                  <span>Override fee hold</span>
                                </label>
                              </div>
                            ) : (
                              <span className="text-emerald-400 font-medium flex items-center gap-1">
                                <CheckCircle2 className="w-3 h-3" />
                                Cleared
                              </span>
                            )}
                          </td>
                          <td className="px-3 py-3">
                            <span
                              className={`px-2 py-0.5 rounded-full text-[10px] font-semibold uppercase ${
                                st.eligibilityStatus === 'ELIGIBLE_PROMOTION'
                                  ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                                  : st.eligibilityStatus === 'WARNING_FEES'
                                  ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                                  : st.eligibilityStatus === 'WARNING_ATTENDANCE'
                                  ? 'bg-yellow-500/10 text-yellow-400 border border-yellow-500/20'
                                  : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                              }`}
                            >
                              {(st.eligibilityStatus || 'PENDING').replace(/_/g, ' ')}
                            </span>
                          </td>
                          <td className="px-3 py-3">
                            <input
                              type="text"
                              value={dec.targetRollNumber}
                              onChange={(e) =>
                                updateStudentDecision(st.studentId, 'targetRollNumber', e.target.value)
                              }
                              className="w-20 bg-slate-900 border border-slate-700 rounded px-2 py-1 text-xs text-white font-mono"
                            />
                          </td>
                          <td className="px-3 py-3">
                            <select
                              value={dec.action}
                              onChange={(e) =>
                                updateStudentDecision(st.studentId, 'action', e.target.value)
                              }
                              className={`bg-slate-900 border rounded px-2 py-1 text-xs font-semibold ${
                                dec.action === 'PROMOTE'
                                  ? 'text-emerald-400 border-emerald-500/40'
                                  : dec.action === 'RETAIN'
                                  ? 'text-amber-400 border-amber-500/40'
                                  : dec.action === 'GRADUATE'
                                  ? 'text-purple-400 border-purple-500/40'
                                  : 'text-slate-400 border-slate-700'
                              }`}
                            >
                              <option value="PROMOTE">PROMOTE</option>
                              <option value="RETAIN">RETAIN (Repeat)</option>
                              <option value="GRADUATE">GRADUATE</option>
                              <option value="EXCLUDE">EXCLUDE</option>
                            </select>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              {/* Navigation footer */}
              <div className="flex justify-between items-center pt-3 border-t border-slate-800">
                <button
                  onClick={() => setStep(1)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs"
                >
                  Back to Parameters
                </button>
                <button
                  onClick={() => setStep(3)}
                  className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold flex items-center gap-2"
                >
                  Review Summary & Pre-commit Check
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 3: SUMMARY & CONFIRMATION */}
          {step === 3 && previewData && (
            <div className="space-y-6 max-w-2xl mx-auto py-4">
              <div className="bg-slate-800/40 border border-slate-700/60 rounded-2xl p-6 space-y-4 text-center">
                <div className="w-12 h-12 bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 rounded-2xl flex items-center justify-center mx-auto">
                  <ShieldCheck className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-bold text-white">Review Bulk Promotion Transaction</h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  You are about to commit promotion decisions for{' '}
                  <span className="font-bold text-white">{previewData?.students?.length || 0} students</span> from{' '}
                  <span className="text-indigo-400 font-bold">{previewData.sourceClassName}</span> to{' '}
                  <span className="text-emerald-400 font-bold">{previewData.targetClassName}</span> for academic session{' '}
                  <span className="text-white font-bold">{previewData.targetSessionName}</span>.
                </p>

                <div className="grid grid-cols-4 gap-3 bg-slate-900/60 p-4 rounded-xl border border-slate-800 text-xs">
                  <div>
                    <div className="text-emerald-400 text-lg font-bold">{summaryCounts.promote}</div>
                    <div className="text-[10px] text-slate-400 uppercase font-semibold">Promote</div>
                  </div>
                  <div>
                    <div className="text-amber-400 text-lg font-bold">{summaryCounts.retain}</div>
                    <div className="text-[10px] text-slate-400 uppercase font-semibold">Retain (Repeat)</div>
                  </div>
                  <div>
                    <div className="text-purple-400 text-lg font-bold">{summaryCounts.graduate}</div>
                    <div className="text-[10px] text-slate-400 uppercase font-semibold">Graduate</div>
                  </div>
                  <div>
                    <div className="text-slate-400 text-lg font-bold">{summaryCounts.exclude}</div>
                    <div className="text-[10px] text-slate-500 uppercase font-semibold">Excluded</div>
                  </div>
                </div>

                <div className="p-3 bg-amber-500/10 border border-amber-500/20 text-amber-300 rounded-xl text-xs text-left flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                  <p className="leading-relaxed">
                    Historical enrollment records will be marked as <span className="font-mono font-bold">promoted</span> and
                    preserved indefinitely. New active enrollments will be created in the target session without altering historical attendance or exam records.
                  </p>
                </div>
              </div>

              <div className="flex justify-between items-center">
                <button
                  onClick={() => setStep(2)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs"
                >
                  Adjust Decisions
                </button>
                <button
                  onClick={handleExecuteBulk}
                  disabled={executing}
                  className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-lg shadow-emerald-600/20"
                >
                  {executing ? <RefreshCw className="w-4 h-4 animate-spin" /> : <CheckCircle2 className="w-4 h-4" />}
                  Confirm & Execute Promotion Batch
                </button>
              </div>
            </div>
          )}

          {/* STEP 4: RESULT */}
          {step === 4 && executionResult && (
            <div className="space-y-6 max-w-xl mx-auto py-8 text-center">
              <div className="w-16 h-16 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-full flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-white">Batch Promotion Successfully Executed</h3>
                <p className="text-xs text-slate-400 mt-1">Batch Reference: <span className="font-mono text-indigo-400">{executionResult.batchId}</span></p>
              </div>

              <div className="bg-slate-800/40 border border-slate-700/60 rounded-xl p-4 text-xs space-y-2">
                <div className="flex justify-between text-slate-300">
                  <span>Total Processed:</span>
                  <span className="font-bold text-white">{executionResult.summary.totalSubmitted}</span>
                </div>
                <div className="flex justify-between text-emerald-400">
                  <span>Promoted to New Class:</span>
                  <span className="font-bold">{executionResult.summary.promotedCount}</span>
                </div>
                <div className="flex justify-between text-amber-400">
                  <span>Retained in Current Level:</span>
                  <span className="font-bold">{executionResult.summary.retainedCount}</span>
                </div>
                {executionResult.summary.graduatedCount > 0 && (
                  <div className="flex justify-between text-purple-400">
                    <span>Graduated:</span>
                    <span className="font-bold">{executionResult.summary.graduatedCount}</span>
                  </div>
                )}
              </div>

              <button
                onClick={onClose}
                className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold"
              >
                Close & Refresh Records
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
