import React, { useState } from 'react';
import {
  X,
  Shuffle,
  AlertCircle,
  CheckCircle2,
  Building,
  Calendar,
  Layers,
  ArrowRight
} from 'lucide-react';
import { api } from '../../services/api';
import { SchoolClass, Section, StudentProfile } from '../../types';
import { LoadingSpinner } from '../ui/LoadingSpinner';

interface InternalTransferModalProps {
  students: StudentProfile[];
  classes: SchoolClass[];
  sections: Section[];
  preselectedStudentId?: string;
  onClose: () => void;
  onCompleted: () => void;
}

export const InternalTransferModal: React.FC<InternalTransferModalProps> = ({
  students,
  classes,
  sections,
  preselectedStudentId,
  onClose,
  onCompleted
}) => {
  const [studentId, setStudentId] = useState(preselectedStudentId || (students?.[0]?.id ?? ''));
  const selectedStudent = (students || []).find((s) => s.id === studentId);

  const [transferType, setTransferType] = useState<'SECTION_TRANSFER' | 'CLASS_TRANSFER'>('SECTION_TRANSFER');
  const [targetClassId, setTargetClassId] = useState(selectedStudent?.classId || '');
  const [targetSectionId, setTargetSectionId] = useState('');
  const [targetRollNumber, setTargetRollNumber] = useState('');
  const [effectiveDate, setEffectiveDate] = useState(new Date().toISOString().split('T')[0]);
  const [reason, setReason] = useState('');
  const [libraryCleared, setLibraryCleared] = useState(true);
  const [feesCleared, setFeesCleared] = useState(true);

  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Filter target sections
  const effectiveClassId = transferType === 'CLASS_TRANSFER' ? targetClassId : (selectedStudent?.classId || targetClassId);
  const availableSections = (sections || []).filter((s) => s.classId === effectiveClassId);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!studentId || !targetSectionId || !reason) {
      setError('Please select target section and provide reason for transfer.');
      return;
    }

    setError(null);
    setSubmitting(true);

    try {
      const res = await api.promotionsTransfers.transferInternal({
        studentId,
        transferType,
        targetClassId: transferType === 'CLASS_TRANSFER' ? targetClassId : undefined,
        targetSectionId,
        targetRollNumber: targetRollNumber || undefined,
        reason,
        effectiveDate,
        libraryCleared,
        feesCleared
      });

      if (res.success) {
        onCompleted();
      } else {
        setError('Transfer failed.');
      }
    } catch (err: any) {
      setError(err.message || 'Failed to transfer student');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-xl rounded-2xl shadow-2xl overflow-hidden my-6">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-500/10 rounded-xl border border-indigo-500/20 text-indigo-400">
              <Shuffle className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Internal Student Transfer</h2>
              <p className="text-xs text-slate-400">Reassign student across sections or classes within session</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {error && (
            <div className="p-3 bg-rose-500/10 border border-rose-500/20 text-rose-300 rounded-xl text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Student Selector */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Select Student *</label>
            <select
              value={studentId}
              onChange={(e) => setStudentId(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
            >
              {students.map((st) => (
                <option key={st.id} value={st.id}>
                  {st.name} ({st.admissionNumber}) — {st.className} ({st.sectionName})
                </option>
              ))}
            </select>
          </div>

          {selectedStudent && (
            <div className="p-3 bg-slate-800/40 rounded-xl border border-slate-700/60 flex items-center justify-between text-xs">
              <div>
                <span className="text-slate-400">Current Assignment:</span>{' '}
                <span className="font-bold text-white">{selectedStudent.className} — {selectedStudent.sectionName}</span>
              </div>
              <div className="text-slate-400">
                Roll #{selectedStudent.rollNumber || 'N/A'}
              </div>
            </div>
          )}

          {/* Transfer Type */}
          <div className="grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => setTransferType('SECTION_TRANSFER')}
              className={`p-3 rounded-xl border text-xs font-semibold text-center transition-all ${
                transferType === 'SECTION_TRANSFER'
                  ? 'bg-indigo-600/20 border-indigo-500 text-white'
                  : 'bg-slate-800/40 border-slate-700 text-slate-400'
              }`}
            >
              Section Transfer (Same Class)
            </button>
            <button
              type="button"
              onClick={() => setTransferType('CLASS_TRANSFER')}
              className={`p-3 rounded-xl border text-xs font-semibold text-center transition-all ${
                transferType === 'CLASS_TRANSFER'
                  ? 'bg-indigo-600/20 border-indigo-500 text-white'
                  : 'bg-slate-800/40 border-slate-700 text-slate-400'
              }`}
            >
              Class & Section Transfer
            </button>
          </div>

          {/* Target Placement Fields */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {transferType === 'CLASS_TRANSFER' && (
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Target Class *</label>
                <select
                  value={targetClassId}
                  onChange={(e) => setTargetClassId(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
                >
                  <option value="">-- Select Class --</option>
                  {classes.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>
            )}

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Target Section *</label>
              <select
                value={targetSectionId}
                onChange={(e) => setTargetSectionId(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
              >
                <option value="">-- Select Section --</option>
                {availableSections.map((sec) => (
                  <option key={sec.id} value={sec.id}>
                    Section {sec.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Target Roll Number (Optional)</label>
              <input
                type="text"
                value={targetRollNumber}
                onChange={(e) => setTargetRollNumber(e.target.value)}
                placeholder="Auto-generated if left blank"
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Effective Date *</label>
              <input
                type="date"
                value={effectiveDate}
                onChange={(e) => setEffectiveDate(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Reason for Transfer *</label>
            <input
              type="text"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="e.g. Academic elective change, peer environment balancing, parent request"
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
            />
          </div>

          <div className="flex gap-6 text-xs text-slate-300 pt-2">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={libraryCleared}
                onChange={(e) => setLibraryCleared(e.target.checked)}
                className="w-4 h-4 text-indigo-600 rounded bg-slate-900 border-slate-700"
              />
              <span>Library Cleared</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={feesCleared}
                onChange={(e) => setFeesCleared(e.target.checked)}
                className="w-4 h-4 text-indigo-600 rounded bg-slate-900 border-slate-700"
              />
              <span>Accounts & Fees Cleared</span>
            </label>
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5"
            >
              {submitting ? <LoadingSpinner size="sm" /> : <CheckCircle2 className="w-4 h-4" />}
              Execute Transfer
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
