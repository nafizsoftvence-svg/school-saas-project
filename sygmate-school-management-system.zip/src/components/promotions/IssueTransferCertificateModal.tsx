import React, { useState, useEffect } from 'react';
import {
  X,
  FileBadge,
  AlertCircle,
  CheckCircle2,
  AlertTriangle,
  Building,
  Calendar,
  ShieldCheck,
  Award
} from 'lucide-react';
import { api } from '../../services/api';
import { StudentProfile, TransferCertificate } from '../../types';
import { LoadingSpinner } from '../ui/LoadingSpinner';

interface IssueTransferCertificateModalProps {
  students: StudentProfile[];
  preselectedStudentId?: string;
  onClose: () => void;
  onSuccess: (certificate: TransferCertificate) => void;
}

export const IssueTransferCertificateModal: React.FC<IssueTransferCertificateModalProps> = ({
  students,
  preselectedStudentId,
  onClose,
  onSuccess
}) => {
  const [studentId, setStudentId] = useState(preselectedStudentId || (students?.[0]?.id ?? ''));
  const selectedStudent = (students || []).find((s) => s.id === studentId);

  const [dateOfLeaving, setDateOfLeaving] = useState(new Date().toISOString().split('T')[0]);
  const [reasonForLeaving, setReasonForLeaving] = useState('Parent relocation and family transfer');
  const [targetSchoolName, setTargetSchoolName] = useState('');
  const [generalConduct, setGeneralConduct] = useState<'Exemplary' | 'Excellent' | 'Good' | 'Satisfactory'>('Excellent');

  // Clearance checklist
  const [libraryCleared, setLibraryCleared] = useState(true);
  const [feesCleared, setFeesCleared] = useState(true);
  const [labSportsCleared, setLabSportsCleared] = useState(true);
  const [clearanceOverride, setClearanceOverride] = useState(false);
  const [remarks, setRemarks] = useState('');

  const [standing, setStanding] = useState<any>(null);
  const [loadingStanding, setLoadingStanding] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (studentId) {
      fetchStanding(studentId);
    }
  }, [studentId]);

  const fetchStanding = async (id: string) => {
    setLoadingStanding(true);
    try {
      const res = await api.promotionsTransfers.getStudentStanding(id);
      if (res.success) {
        setStanding(res.standing);
        if (res.standing?.hasOutstandingFees) {
          setFeesCleared(false);
        } else {
          setFeesCleared(true);
        }
      }
    } catch (e) {
      // non-fatal
    } finally {
      setLoadingStanding(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!studentId || !reasonForLeaving) {
      setError('Please provide student and reason for leaving.');
      return;
    }

    if (standing?.hasOutstandingFees && !feesCleared && !clearanceOverride) {
      setError('Student has outstanding dues. You must settle fees or check the administrative clearance override to proceed.');
      return;
    }

    setError(null);
    setSubmitting(true);

    try {
      const res = await api.promotionsTransfers.issueTransferCertificate({
        studentId,
        dateOfLeaving,
        reasonForLeaving,
        targetSchoolName: targetSchoolName || undefined,
        generalConduct,
        libraryCleared,
        feesCleared,
        labSportsCleared,
        clearanceOverride,
        remarks: remarks || undefined
      });

      if (res.success) {
        onSuccess(res.certificate);
      } else {
        setError('Failed to issue Transfer Certificate');
      }
    } catch (err: any) {
      setError(err.message || 'Error issuing certificate');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden my-6">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-emerald-500/10 rounded-xl border border-emerald-500/20 text-emerald-400">
              <FileBadge className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Issue Official Transfer Certificate (TC)</h2>
              <p className="text-xs text-slate-400">Formal institutional withdrawal, clearance certification & TC generation</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {error && (
            <div className="p-3 bg-rose-500/10 border border-rose-500/20 text-rose-300 rounded-xl text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Student Selector */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Select Student *</label>
            <select
              value={studentId}
              onChange={(e) => setStudentId(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
            >
              {students.map((st) => (
                <option key={st.id} value={st.id}>
                  {st.name} ({st.admissionNumber}) — {st.className} ({st.sectionName})
                </option>
              ))}
            </select>
          </div>

          {/* Diagnostics Card */}
          {standing && (
            <div className="bg-slate-800/40 border border-slate-700/60 rounded-xl p-3.5 text-xs flex items-center justify-between">
              <div>
                <span className="text-slate-400">Attendance:</span>{' '}
                <span className="font-bold text-white">{standing?.attendancePercentage ?? 0}%</span>
              </div>
              <div>
                <span className="text-slate-400">GPA:</span>{' '}
                <span className="font-bold text-indigo-400">{(standing?.cumulativeGPA ?? 0).toFixed(2)}</span>
              </div>
              <div>
                <span className="text-slate-400">Fee Balance:</span>{' '}
                <span className={`font-bold ${standing?.hasOutstandingFees ? 'text-rose-400' : 'text-emerald-400'}`}>
                  ${standing?.totalDueFees ?? 0}
                </span>
              </div>
            </div>
          )}

          {/* Parameters */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Date of Leaving *</label>
              <input
                type="date"
                value={dateOfLeaving}
                onChange={(e) => setDateOfLeaving(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">General Conduct Evaluation *</label>
              <select
                value={generalConduct}
                onChange={(e) => setGeneralConduct(e.target.value as any)}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
              >
                <option value="Exemplary">Exemplary</option>
                <option value="Excellent">Excellent</option>
                <option value="Good">Good</option>
                <option value="Satisfactory">Satisfactory</option>
              </select>
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-medium text-slate-300 mb-1">Reason for Leaving *</label>
              <input
                type="text"
                value={reasonForLeaving}
                onChange={(e) => setReasonForLeaving(e.target.value)}
                placeholder="e.g. Relocation to another state / admission to higher institution"
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-medium text-slate-300 mb-1">Target School / College (Optional)</label>
              <input
                type="text"
                value={targetSchoolName}
                onChange={(e) => setTargetSchoolName(e.target.value)}
                placeholder="e.g. St. Jude High School, Cambridge Academy"
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
              />
            </div>
          </div>

          {/* Clearance Verification Checklist */}
          <div className="bg-slate-800/30 border border-slate-700/50 rounded-xl p-4 space-y-3 text-xs">
            <div className="text-[10px] uppercase font-bold text-slate-300 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-indigo-400" />
              Institutional Clearance Certification Checklist
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
              <label className="flex items-center gap-2 cursor-pointer bg-slate-900/60 p-2.5 rounded-lg border border-slate-800">
                <input
                  type="checkbox"
                  checked={libraryCleared}
                  onChange={(e) => setLibraryCleared(e.target.checked)}
                  className="w-4 h-4 text-emerald-600 rounded bg-slate-900 border-slate-700"
                />
                <span className="text-slate-200">Library Cleared</span>
              </label>

              <label className="flex items-center gap-2 cursor-pointer bg-slate-900/60 p-2.5 rounded-lg border border-slate-800">
                <input
                  type="checkbox"
                  checked={feesCleared}
                  onChange={(e) => setFeesCleared(e.target.checked)}
                  className="w-4 h-4 text-emerald-600 rounded bg-slate-900 border-slate-700"
                />
                <span className="text-slate-200">Accounts & Dues</span>
              </label>

              <label className="flex items-center gap-2 cursor-pointer bg-slate-900/60 p-2.5 rounded-lg border border-slate-800">
                <input
                  type="checkbox"
                  checked={labSportsCleared}
                  onChange={(e) => setLabSportsCleared(e.target.checked)}
                  className="w-4 h-4 text-emerald-600 rounded bg-slate-900 border-slate-700"
                />
                <span className="text-slate-200">Labs & Sports</span>
              </label>
            </div>

            {standing?.hasOutstandingFees && !feesCleared && (
              <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-lg text-amber-300">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={clearanceOverride}
                    onChange={(e) => setClearanceOverride(e.target.checked)}
                    className="w-4 h-4 text-amber-500 rounded bg-slate-900 border-slate-700"
                  />
                  <span className="font-semibold">
                    Registrar Special Override: Issue TC unconditionally despite fee balance
                  </span>
                </label>
              </div>
            )}
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Remarks for Certificate</label>
            <input
              type="text"
              value={remarks}
              onChange={(e) => setRemarks(e.target.value)}
              placeholder="e.g. Conduct was exemplary throughout attendance"
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
            />
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5"
            >
              {submitting ? <LoadingSpinner size="sm" /> : <FileBadge className="w-4 h-4" />}
              Issue Transfer Certificate
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
