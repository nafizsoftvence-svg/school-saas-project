import React, { useEffect, useState } from 'react';
import {
  X,
  Layers,
  GraduationCap,
  Calendar,
  Clock,
  ArrowRight,
  ShieldAlert,
  CheckCircle2,
  FileText,
  Award,
  AlertCircle,
  FileBadge,
  User,
  History,
  RotateCcw
} from 'lucide-react';
import { api } from '../../services/api';
import { LoadingSpinner } from '../ui/LoadingSpinner';
import { TransferCertificateViewerModal } from './TransferCertificateViewerModal';
import { TransferCertificate } from '../../types';

interface StudentAcademicTimelineModalProps {
  studentId: string;
  onClose: () => void;
  onPromotionReverted?: () => void;
}

export const StudentAcademicTimelineModal: React.FC<StudentAcademicTimelineModalProps> = ({
  studentId,
  onClose,
  onPromotionReverted
}) => {
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  const [selectedTC, setSelectedTC] = useState<TransferCertificate | null>(null);
  const [revertingId, setRevertingId] = useState<string | null>(null);
  const [revertReason, setRevertReason] = useState('');
  const [showRevertConfirm, setShowRevertConfirm] = useState(false);

  const fetchTimeline = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await api.promotionsTransfers.getStudentTimeline(studentId);
      if (res.success) {
        setData(res);
      } else {
        setError('Failed to load student academic timeline');
      }
    } catch (err: any) {
      setError(err.message || 'Error loading timeline');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (studentId) {
      fetchTimeline();
    }
  }, [studentId]);

  const handleRevertPromotion = async (recordId: string) => {
    try {
      const res = await api.promotionsTransfers.revertPromotion(recordId, revertReason);
      if (res.success) {
        setShowRevertConfirm(false);
        setRevertingId(null);
        setRevertReason('');
        await fetchTimeline();
        if (onPromotionReverted) onPromotionReverted();
      }
    } catch (err: any) {
      alert(err.message || 'Failed to revert promotion');
    }
  };

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
        <div className="bg-slate-900 border border-slate-700 w-full max-w-4xl rounded-2xl shadow-2xl overflow-hidden my-6 flex flex-col max-h-[90vh]">
          {/* Header */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/60">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-indigo-500/10 rounded-xl border border-indigo-500/20 text-indigo-400">
                <History className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  Academic Timeline & History
                  {data?.student && (
                    <span className="text-xs px-2 py-0.5 rounded-full bg-slate-800 border border-slate-700 text-slate-300 font-mono">
                      {data.student.admissionNumber}
                    </span>
                  )}
                </h2>
                <p className="text-xs text-slate-400">
                  {data?.student?.name ? `${data.student.name} • Class ${data.student.className || ''}` : 'Loading student lifecycle records...'}
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Modal Content Area */}
          <div className="p-6 overflow-y-auto space-y-6 flex-1">
            {loading ? (
              <div className="py-16 flex justify-center">
                <LoadingSpinner size="lg" message="Compiling lifetime academic records..." />
              </div>
            ) : error ? (
              <div className="p-4 bg-rose-500/10 border border-rose-500/20 text-rose-300 rounded-xl text-sm flex items-center gap-2">
                <AlertCircle className="w-4 h-4" />
                {error}
              </div>
            ) : data ? (
              <>
                {/* Student Bio Summary Card */}
                <div className="bg-slate-800/40 border border-slate-700/60 rounded-xl p-4 sm:p-5 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-300 font-bold text-lg">
                      {data.student.name?.charAt(0) || 'S'}
                    </div>
                    <div>
                      <h3 className="font-bold text-white text-base">{data.student.name}</h3>
                      <p className="text-xs text-slate-400">
                        Roll #{data.student.rollNumber || 'N/A'} • {data.student.className} ({data.student.sectionName || 'N/A'})
                      </p>
                      <div className="flex items-center gap-2 mt-1">
                        <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium uppercase tracking-wider ${
                          data.student.status === 'active'
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                            : data.student.status === 'graduated'
                            ? 'bg-purple-500/10 text-purple-400 border border-purple-500/20'
                            : data.student.status === 'transferred'
                            ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20'
                            : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                        }`}>
                          {data.student.status}
                        </span>
                        <span className="text-[11px] text-slate-400">
                          Current Session: <span className="text-slate-200">{data.student.academicSessionName || '2025-2026'}</span>
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Standing Metrics */}
                  {data.standing && (
                    <div className="flex items-center gap-4 bg-slate-900/80 px-4 py-2.5 rounded-lg border border-slate-700/80 text-xs">
                      <div className="text-center">
                        <div className="text-slate-400 text-[10px] uppercase font-semibold">Cumul. GPA</div>
                        <div className="font-bold text-indigo-400 text-sm">{Number(data.standing?.cumulativeGPA ?? 0).toFixed(2)}</div>
                      </div>
                      <div className="w-px h-6 bg-slate-700" />
                      <div className="text-center">
                        <div className="text-slate-400 text-[10px] uppercase font-semibold">Attendance</div>
                        <div className={`font-bold text-sm ${(data.standing?.attendancePercentage ?? 0) >= 75 ? 'text-emerald-400' : 'text-amber-400'}`}>
                          {data.standing?.attendancePercentage ?? 0}%
                        </div>
                      </div>
                      <div className="w-px h-6 bg-slate-700" />
                      <div className="text-center">
                        <div className="text-slate-400 text-[10px] uppercase font-semibold">Fee Dues</div>
                        <div className={`font-bold text-sm ${data.standing.hasOutstandingFees ? 'text-rose-400' : 'text-emerald-400'}`}>
                          ${data.standing.totalDueFees}
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* Section 1: Academic Enrollments Chronology */}
                <div className="space-y-3">
                  <h4 className="text-xs uppercase tracking-wider font-semibold text-slate-400 flex items-center gap-2">
                    <Layers className="w-4 h-4 text-indigo-400" />
                    Academic Session Enrollments
                  </h4>

                  <div className="relative border-l-2 border-indigo-500/30 ml-4 pl-6 space-y-6">
                    {data.enrollments.map((enr: any, idx: number) => {
                      const isActive = enr.status === 'active';
                      return (
                        <div key={enr.id || idx} className="relative">
                          {/* Dot */}
                          <div
                            className={`absolute -left-[31px] top-1 w-4 h-4 rounded-full border-2 ${
                              isActive
                                ? 'bg-indigo-600 border-indigo-400 ring-4 ring-indigo-500/20'
                                : 'bg-slate-900 border-slate-600'
                            }`}
                          />
                          <div className="bg-slate-800/30 border border-slate-700/60 rounded-xl p-4 hover:border-slate-600 transition-colors">
                            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                              <div>
                                <div className="flex items-center gap-2">
                                  <span className="font-bold text-white text-sm">
                                    {enr.className} — {enr.sectionName || 'Section A'}
                                  </span>
                                  <span
                                    className={`text-[10px] font-semibold px-2 py-0.5 rounded-full uppercase ${
                                      isActive
                                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                                        : enr.status === 'promoted'
                                        ? 'bg-indigo-500/10 text-indigo-400 border border-indigo-500/20'
                                        : enr.status === 'transferred'
                                        ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                                        : 'bg-slate-800 text-slate-400 border border-slate-700'
                                    }`}
                                  >
                                    {enr.status}
                                  </span>
                                </div>
                                <p className="text-xs text-slate-400 mt-0.5">
                                  Academic Session: <span className="text-slate-200 font-medium">{enr.academicSessionName}</span> • Roll #{enr.rollNumber || 'N/A'}
                                </p>
                              </div>
                              <div className="text-right text-[11px] text-slate-400">
                                <div>Enrolled: <span className="text-slate-300">{enr.enrollmentDate}</span></div>
                                {enr.completionDate && (
                                  <div>Completed: <span className="text-slate-300">{enr.completionDate}</span></div>
                                )}
                              </div>
                            </div>

                            {enr.academicPerformanceSummary && (
                              <div className="mt-3 pt-3 border-t border-slate-700/40 grid grid-cols-3 gap-2 text-xs">
                                <div>
                                  <span className="text-slate-400 text-[10px]">Session GPA:</span>{' '}
                                  <span className="font-bold text-slate-200">{enr.academicPerformanceSummary.gpa}</span>
                                </div>
                                <div>
                                  <span className="text-slate-400 text-[10px]">Percentage:</span>{' '}
                                  <span className="font-bold text-slate-200">{enr.academicPerformanceSummary.percentage}%</span>
                                </div>
                                <div>
                                  <span className="text-slate-400 text-[10px]">Exam Status:</span>{' '}
                                  <span className="font-bold text-emerald-400">{enr.academicPerformanceSummary.resultStatus}</span>
                                </div>
                              </div>
                            )}

                            {enr.remarks && (
                              <p className="mt-2 text-[11px] text-slate-400 italic bg-slate-900/40 p-2 rounded border border-slate-800">
                                Remarks: {enr.remarks}
                              </p>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Section 2: Promotion Records & Rollback Action */}
                {((data?.promotions?.length || 0) > 0) && (
                  <div className="space-y-3 pt-2">
                    <h4 className="text-xs uppercase tracking-wider font-semibold text-slate-400 flex items-center gap-2">
                      <Award className="w-4 h-4 text-purple-400" />
                      Promotion Records & Transactions
                    </h4>

                    <div className="space-y-2">
                      {data.promotions.map((p: any) => (
                        <div
                          key={p.id}
                          className="bg-slate-800/20 border border-slate-700/60 rounded-xl p-3.5 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 text-xs"
                        >
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-semibold text-white">
                                {p.fromClassName} ({p.fromSessionName})
                              </span>
                              <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
                              <span className="font-semibold text-indigo-400">
                                {p.toClassName} ({p.toSessionName})
                              </span>
                              <span
                                className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${
                                  p.status === 'COMPLETED'
                                    ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                                    : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                                }`}
                              >
                                {p.status}
                              </span>
                            </div>
                            <p className="text-[11px] text-slate-400 mt-1">
                              Action: <span className="text-slate-300 font-medium">{p.promotionType}</span> • Executed by{' '}
                              <span className="text-slate-300">{p.promotedByName}</span> on{' '}
                              <span className="text-slate-300">{p.promotedAt ? p.promotedAt.split('T')[0] : 'N/A'}</span>
                            </p>
                            {p.feeStatusAtPromotion?.overrideApproved && (
                              <p className="text-[10px] text-amber-400 mt-0.5">
                                Note: Fee clearance was administratively overridden.
                              </p>
                            )}
                          </div>

                          {p.status === 'COMPLETED' && (
                            <button
                              onClick={() => {
                                setRevertingId(p.id);
                                setShowRevertConfirm(true);
                              }}
                              className="px-2.5 py-1.5 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors"
                            >
                              <RotateCcw className="w-3.5 h-3.5" />
                              Revert Promotion
                            </button>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Section 3: Issued Transfer Certificates */}
                {((data?.transferCertificates?.length || 0) > 0) && (
                  <div className="space-y-3 pt-2">
                    <h4 className="text-xs uppercase tracking-wider font-semibold text-slate-400 flex items-center gap-2">
                      <FileBadge className="w-4 h-4 text-emerald-400" />
                      Official Transfer Certificates (TC)
                    </h4>

                    <div className="space-y-2">
                      {(data.transferCertificates || []).map((tc: any) => (
                        <div
                          key={tc.id}
                          className="bg-slate-800/30 border border-slate-700/60 rounded-xl p-3.5 flex items-center justify-between gap-3 text-xs"
                        >
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-white font-mono">{tc.tcNumber}</span>
                              <span className="text-slate-400">• Issued: {tc.issueDate}</span>
                            </div>
                            <p className="text-slate-400 text-[11px] mt-0.5">
                              Reason: {tc.reasonForLeaving} • Conduct: {tc.generalConduct}
                            </p>
                          </div>
                          <button
                            onClick={() => setSelectedTC(tc)}
                            className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-medium flex items-center gap-1.5 transition-colors"
                          >
                            <FileText className="w-3.5 h-3.5" />
                            View Certificate
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Section 4: Status Transition Audit History */}
                {((data?.statusHistory?.length || 0) > 0) && (
                  <div className="space-y-3 pt-2">
                    <h4 className="text-xs uppercase tracking-wider font-semibold text-slate-400 flex items-center gap-2">
                      <Clock className="w-4 h-4 text-amber-400" />
                      Status Lifecycle Transitions
                    </h4>

                    <div className="overflow-x-auto rounded-xl border border-slate-800">
                      <table className="w-full text-left text-xs text-slate-300">
                        <thead className="bg-slate-950/80 text-slate-400 uppercase text-[10px]">
                          <tr>
                            <th className="px-3 py-2.5">Date</th>
                            <th className="px-3 py-2.5">Transition</th>
                            <th className="px-3 py-2.5">Reason</th>
                            <th className="px-3 py-2.5">Authorizing Admin</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-800 bg-slate-900/40">
                          {data.statusHistory.map((sh: any) => (
                            <tr key={sh.id} className="hover:bg-slate-800/30">
                              <td className="px-3 py-2 text-slate-400 font-mono text-[11px]">{sh.effectiveDate}</td>
                              <td className="px-3 py-2">
                                <div className="flex items-center gap-1.5">
                                  <span className="font-mono text-slate-400">{sh.fromStatus}</span>
                                  <ArrowRight className="w-3 h-3 text-slate-500" />
                                  <span className="font-bold text-white font-mono">{sh.toStatus}</span>
                                </div>
                              </td>
                              <td className="px-3 py-2 text-slate-300 max-w-xs truncate">{sh.reason}</td>
                              <td className="px-3 py-2 text-slate-400">{sh.changedByName}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
              </>
            ) : null}
          </div>

          {/* Revert Confirmation Modal Overlay */}
          {showRevertConfirm && revertingId && (
            <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
              <div className="bg-slate-900 border border-slate-700 w-full max-w-md rounded-xl p-6 space-y-4">
                <div className="flex items-center gap-3 text-rose-400">
                  <AlertCircle className="w-6 h-6" />
                  <h3 className="font-bold text-base text-white">Confirm Promotion Revert</h3>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Are you sure you want to rollback this student's promotion? This will reactivate their previous academic enrollment and restore their original class/section/roll assignment.
                </p>
                <div>
                  <label className="block text-xs text-slate-400 mb-1">Administrative Reason for Rollback</label>
                  <input
                    type="text"
                    value={revertReason}
                    onChange={(e) => setRevertReason(e.target.value)}
                    placeholder="e.g. Inadvertently promoted before supplementary exams"
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div className="flex justify-end gap-2 pt-2">
                  <button
                    onClick={() => {
                      setShowRevertConfirm(false);
                      setRevertingId(null);
                    }}
                    className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => handleRevertPromotion(revertingId)}
                    className="px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-xs font-semibold"
                  >
                    Execute Rollback
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Footer */}
          <div className="px-6 py-3 border-t border-slate-800 bg-slate-950/60 flex justify-end">
            <button
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-medium transition-colors"
            >
              Close Window
            </button>
          </div>
        </div>
      </div>

      {/* Sub-Modal: Transfer Certificate Document View */}
      {selectedTC && (
        <TransferCertificateViewerModal
          certificate={selectedTC}
          onClose={() => setSelectedTC(null)}
        />
      )}
    </>
  );
};
