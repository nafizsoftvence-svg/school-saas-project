import React, { useState, useEffect, useMemo } from 'react';
import {
  FileSpreadsheet,
  Calendar,
  Layers,
  GraduationCap,
  Coins,
  Clock,
  Check,
  X,
  AlertCircle,
  Sparkles,
  Info,
  DollarSign,
  HelpCircle
} from 'lucide-react';
import { Modal } from '../ui/Modal.js';
import { Button } from '../ui/Button.js';
import { Input } from '../ui/Input.js';
import { Select } from '../ui/Select.js';
import { LoadingSpinner } from '../ui/LoadingSpinner.js';
import { useToast } from '../../context/ToastContext.js';
import { useSettings } from '../../context/SettingsContext.js';
import { api } from '../../services/api.js';
import {
  FeeStructure,
  FeeType,
  FeeFrequency,
  FeeStructureStatus,
  FeeCategory,
  AcademicSession,
  SchoolClass,
  Section,
  CreateFeeStructurePayload,
  UpdateFeeStructurePayload
} from '../../types/index.js';

interface FeeStructureFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  structureToEdit?: FeeStructure | null;
  onSuccess: () => void;
  feeTypes: FeeType[];
  academicSessions: AcademicSession[];
  classes: SchoolClass[];
  sections: Section[];
  onOpenCreateFeeType?: () => void;
}

export const FeeStructureFormModal: React.FC<FeeStructureFormModalProps> = ({
  isOpen,
  onClose,
  structureToEdit,
  onSuccess,
  feeTypes,
  academicSessions,
  classes,
  sections,
  onOpenCreateFeeType
}) => {
  const { addToast } = useToast();
  const { settings } = useSettings();

  const isEditing = !!structureToEdit;

  // Form State
  const [name, setName] = useState<string>('');
  const [feeTypeId, setFeeTypeId] = useState<string>('');
  const [academicSessionId, setAcademicSessionId] = useState<string>('');
  const [classId, setClassId] = useState<string>('');
  const [sectionId, setSectionId] = useState<string>('ALL_SECTIONS');
  const [amount, setAmount] = useState<string>('');
  const [currency, setCurrency] = useState<string>('USD');
  const [dueDate, setDueDate] = useState<string>('');
  const [frequency, setFrequency] = useState<FeeFrequency>('YEARLY');
  const [feeCategory, setFeeCategory] = useState<FeeCategory>('MANDATORY');
  const [status, setStatus] = useState<FeeStructureStatus>('ACTIVE');
  const [description, setDescription] = useState<string>('');
  const [notes, setNotes] = useState<string>('');

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Available sections for the currently selected class
  const availableSections = useMemo(() => {
    if (!classId) return [];
    const selectedClass = (classes || []).find((c) => c?.id === classId);
    if (!selectedClass || !selectedClass.sectionIds) return [];
    return (sections || []).filter((s) => selectedClass.sectionIds.includes(s.id));
  }, [classId, classes, sections]);

  // Pre-fill form when editing or opening
  useEffect(() => {
    if (structureToEdit) {
      setName(structureToEdit.name);
      setFeeTypeId(structureToEdit.feeTypeId);
      setAcademicSessionId(structureToEdit.academicSessionId);
      setClassId(structureToEdit.classId);
      setSectionId(structureToEdit.applicableToAllSections || !structureToEdit.sectionId ? 'ALL_SECTIONS' : structureToEdit.sectionId);
      setAmount(structureToEdit.amount.toString());
      setCurrency(structureToEdit.currency || settings?.currency || 'USD');
      setDueDate(structureToEdit.dueDate);
      setFrequency(structureToEdit.frequency);
      setFeeCategory(structureToEdit.feeCategory || (structureToEdit.isMandatory ? 'MANDATORY' : 'OPTIONAL'));
      setStatus(structureToEdit.status);
      setDescription(structureToEdit.description || '');
      setNotes(structureToEdit.notes || '');
    } else {
      // Default initialization
      const defaultSession = (academicSessions || []).find((s) => s.isCurrent) || academicSessions?.[0];
      const defaultClass = classes?.[0];
      const defaultType = (feeTypes || []).find((t) => t.status === 'ACTIVE');

      // Tomorrow or 1 month from now as default due date
      const d = new Date();
      d.setDate(d.getDate() + 30);
      const defaultDueDate = d.toISOString().split('T')[0];

      setName('');
      setFeeTypeId(defaultType ? defaultType.id : '');
      setAcademicSessionId(defaultSession ? defaultSession.id : '');
      setClassId(defaultClass ? defaultClass.id : '');
      setSectionId('ALL_SECTIONS');
      setAmount('');
      setCurrency(settings?.currency || 'USD');
      setDueDate(defaultDueDate);
      setFrequency('YEARLY');
      setFeeCategory('MANDATORY');
      setStatus('ACTIVE');
      setDescription('');
      setNotes('');
    }
    setErrors({});
  }, [structureToEdit, isOpen, academicSessions, classes, feeTypes, settings]);

  // Auto-generate a descriptive structure name when user selects class & fee type in Create mode
  const handleAutoSuggestName = (newFeeTypeId?: string, newClassId?: string) => {
    if (isEditing) return;
    const targetType = (feeTypes || []).find((t) => t?.id === (newFeeTypeId || feeTypeId));
    const targetClass = (classes || []).find((c) => c?.id === (newClassId || classId));
    if (targetType && targetClass && (!name || name.includes(targetType.name) || name.includes(targetClass.name))) {
      setName(`${targetClass.name} Annual ${targetType.name}`);
    }
  };

  const validate = (): boolean => {
    const err: Record<string, string> = {};

    if (!name.trim() || name.trim().length < 3) {
      err.name = 'Fee structure name is required (min 3 characters).';
    }

    if (!feeTypeId) {
      err.feeTypeId = 'Please select a valid fee type.';
    }

    if (!academicSessionId) {
      err.academicSessionId = 'Academic session is required.';
    }

    if (!classId) {
      err.classId = 'Target class is required.';
    }

    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount < 0) {
      err.amount = 'Amount must be a non-negative number (0 or greater).';
    }

    if (!dueDate || !/^\d{4}-\d{2}-\d{2}$/.test(dueDate)) {
      err.dueDate = 'Valid due date (YYYY-MM-DD) is required.';
    }

    if (!frequency) {
      err.frequency = 'Please select a fee collection frequency.';
    }

    setErrors(err);
    return Object.keys(err).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    try {
      setIsSubmitting(true);
      const isAllSections = sectionId === 'ALL_SECTIONS';
      const parsedAmount = parseFloat(amount);

      if (isEditing && structureToEdit) {
        const payload: UpdateFeeStructurePayload = {
          name: name.trim(),
          feeTypeId,
          academicSessionId,
          classId,
          sectionId: isAllSections ? null : sectionId,
          applicableToAllSections: isAllSections,
          amount: parsedAmount,
          currency,
          dueDate,
          frequency,
          isMandatory: feeCategory === 'MANDATORY',
          feeCategory,
          status,
          description: description.trim(),
          notes: notes.trim()
        };

        const res = await api.fees.updateFeeStructure(structureToEdit.id, payload);
        if (res.success && res.data) {
          addToast(`Fee structure '${res.data.name}' updated successfully.`, 'success');
          onSuccess();
          onClose();
        } else {
          addToast(res.error || 'Failed to update fee structure', 'error');
        }
      } else {
        const payload: CreateFeeStructurePayload = {
          name: name.trim(),
          feeTypeId,
          academicSessionId,
          classId,
          sectionId: isAllSections ? null : sectionId,
          applicableToAllSections: isAllSections,
          amount: parsedAmount,
          currency,
          dueDate,
          frequency,
          isMandatory: feeCategory === 'MANDATORY',
          feeCategory,
          status,
          description: description.trim(),
          notes: notes.trim()
        };

        const res = await api.fees.createFeeStructure(payload);
        if (res.success && res.data) {
          addToast(`Fee structure '${res.data.name}' created successfully.`, 'success');
          onSuccess();
          onClose();
        } else {
          addToast(res.error || 'Failed to create fee structure', 'error');
        }
      }
    } catch (err: any) {
      addToast(err.message || 'Error saving fee structure', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={
        <div className="flex items-center gap-2 text-white">
          <FileSpreadsheet className="w-5 h-5 text-indigo-400" />
          <span>{isEditing ? 'Edit Fee Structure' : 'Create New Fee Structure'}</span>
        </div>
      }
      description={
        isEditing
          ? 'Modify academic parameters, amount, frequency, and target audience for this fee structure.'
          : 'Define a new grade-wise fee structure, collection frequency, amount, and due date policy.'
      }
      size="xl"
      id="fee-structure-form-modal"
    >
      <form onSubmit={handleSubmit} className="space-y-5">
        {/* Section 1: Core Identification */}
        <div className="space-y-4 bg-slate-950/40 p-4 rounded-2xl border border-white/5">
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              Fee Structure Name <span className="text-rose-400">*</span>
            </label>
            <Input
              id="fee-structure-name-input"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g., Grade 10 Annual Academic Tuition Fee"
              error={errors.name}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider">
                  Fee Type <span className="text-rose-400">*</span>
                </label>
                {onOpenCreateFeeType && (
                  <button
                    type="button"
                    onClick={onOpenCreateFeeType}
                    className="text-[11px] text-indigo-400 hover:text-indigo-300 underline cursor-pointer"
                  >
                    + New Fee Type
                  </button>
                )}
              </div>
              <Select
                id="fee-structure-type-select"
                value={feeTypeId}
                onChange={(e) => {
                  setFeeTypeId(e.target.value);
                  handleAutoSuggestName(e.target.value, classId);
                }}
                error={errors.feeTypeId}
                options={[
                  { value: '', label: '-- Select Configured Fee Type --' },
                  ...feeTypes
                    .filter((t) => t.status === 'ACTIVE' || t.id === feeTypeId)
                    .map((t) => ({
                      value: t.id,
                      label: `${t.name} (${t.code}) - [${t.category}]`
                    }))
                ]}
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Academic Session <span className="text-rose-400">*</span>
              </label>
              <Select
                id="fee-structure-session-select"
                value={academicSessionId}
                onChange={(e) => setAcademicSessionId(e.target.value)}
                error={errors.academicSessionId}
                options={academicSessions.map((s) => ({
                  value: s.id,
                  label: `${s.sessionName}${s.isCurrent ? ' (Current Active Session)' : ''}`
                }))}
              />
            </div>
          </div>
        </div>

        {/* Section 2: Target Scope (Class & Section) */}
        <div className="space-y-4 bg-slate-950/40 p-4 rounded-2xl border border-white/5">
          <h4 className="text-xs font-bold text-indigo-300 uppercase tracking-wider flex items-center gap-1.5">
            <GraduationCap className="w-4 h-4" /> Target Student Scope
          </h4>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Class / Grade <span className="text-rose-400">*</span>
              </label>
              <Select
                id="fee-structure-class-select"
                value={classId}
                onChange={(e) => {
                  setClassId(e.target.value);
                  setSectionId('ALL_SECTIONS');
                  handleAutoSuggestName(feeTypeId, e.target.value);
                }}
                error={errors.classId}
                options={classes.map((c) => ({
                  value: c.id,
                  label: `${c.name} (${c.code || c.id})`
                }))}
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Target Section <span className="text-rose-400">*</span>
              </label>
              <Select
                id="fee-structure-section-select"
                value={sectionId}
                onChange={(e) => setSectionId(e.target.value)}
                options={[
                  { value: 'ALL_SECTIONS', label: 'All Sections in this Class (Universal)' },
                  ...availableSections.map((sec) => ({
                    value: sec.id,
                    label: `Section ${sec.name}`
                  }))
                ]}
              />
              <p className="text-[11px] text-slate-500 mt-1">
                {sectionId === 'ALL_SECTIONS'
                  ? 'Fee structure will apply universally across all sections of this grade.'
                  : 'Fee structure will only apply to students registered in this specific section.'}
              </p>
            </div>
          </div>
        </div>

        {/* Section 3: Financial Figures & Schedule */}
        <div className="space-y-4 bg-slate-950/40 p-4 rounded-2xl border border-white/5">
          <h4 className="text-xs font-bold text-indigo-300 uppercase tracking-wider flex items-center gap-1.5">
            <Coins className="w-4 h-4" /> Financial Figures & Schedule
          </h4>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Amount ({currency}) <span className="text-rose-400">*</span>
              </label>
              <div className="relative">
                <Input
                  id="fee-structure-amount-input"
                  type="number"
                  step="0.01"
                  min="0"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="0.00"
                  error={errors.amount}
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Frequency <span className="text-rose-400">*</span>
              </label>
              <Select
                id="fee-structure-frequency-select"
                value={frequency}
                onChange={(e) => setFrequency(e.target.value as FeeFrequency)}
                error={errors.frequency}
                options={[
                  { value: 'YEARLY', label: 'Yearly / Annual' },
                  { value: 'HALF_YEARLY', label: 'Half-Yearly (Semesterly)' },
                  { value: 'QUARTERLY', label: 'Quarterly' },
                  { value: 'MONTHLY', label: 'Monthly' },
                  { value: 'ONE_TIME', label: 'One-Time (Admission / Initial)' },
                  { value: 'CUSTOM', label: 'Custom Schedule' }
                ]}
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Due Date <span className="text-rose-400">*</span>
              </label>
              <Input
                id="fee-structure-duedate-input"
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                error={errors.dueDate}
              />
            </div>
          </div>
        </div>

        {/* Section 4: Mandatory vs Optional Policy & Initial Status */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-slate-950/40 p-4 rounded-2xl border border-white/5 space-y-2">
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              Fee Requirement Policy <span className="text-rose-400">*</span>
            </label>
            <div className="space-y-2">
              <label
                className={`p-3 rounded-xl border flex items-start gap-3 cursor-pointer transition-all ${
                  feeCategory === 'MANDATORY'
                    ? 'bg-indigo-500/10 border-indigo-500/40 text-white'
                    : 'bg-slate-900/40 border-white/5 text-slate-400 hover:bg-slate-800/40'
                }`}
              >
                <input
                  type="radio"
                  name="fee-policy"
                  checked={feeCategory === 'MANDATORY'}
                  onChange={() => setFeeCategory('MANDATORY')}
                  className="accent-indigo-500 mt-1"
                />
                <div>
                  <div className="font-semibold text-sm text-indigo-300">Mandatory Fee</div>
                  <div className="text-[11px] text-slate-400 leading-normal">
                    Assigned obligatorily to all matching enrolled students (e.g. Tuition, Exam, Lab).
                  </div>
                </div>
              </label>

              <label
                className={`p-3 rounded-xl border flex items-start gap-3 cursor-pointer transition-all ${
                  feeCategory === 'OPTIONAL'
                    ? 'bg-emerald-500/10 border-emerald-500/40 text-white'
                    : 'bg-slate-900/40 border-white/5 text-slate-400 hover:bg-slate-800/40'
                }`}
              >
                <input
                  type="radio"
                  name="fee-policy"
                  checked={feeCategory === 'OPTIONAL'}
                  onChange={() => setFeeCategory('OPTIONAL')}
                  className="accent-emerald-500 mt-1"
                />
                <div>
                  <div className="font-semibold text-sm text-emerald-300">Optional / Discretionary Fee</div>
                  <div className="text-[11px] text-slate-400 leading-normal">
                    Charged only upon student opt-in subscription (e.g. Bus Transport, Hostel, Clubs).
                  </div>
                </div>
              </label>
            </div>
          </div>

          <div className="bg-slate-950/40 p-4 rounded-2xl border border-white/5 space-y-3">
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider">
              Fee Structure Status
            </label>
            <Select
              id="fee-structure-status-select"
              value={status}
              onChange={(e) => setStatus(e.target.value as FeeStructureStatus)}
              options={[
                { value: 'ACTIVE', label: 'Active (Enabled & Live)' },
                { value: 'DRAFT', label: 'Draft (Under Preparation)' },
                { value: 'INACTIVE', label: 'Inactive (Temporarily Suspended)' },
                ...(isEditing ? [{ value: 'ARCHIVED', label: 'Archived (Historical Record)' }] : [])
              ]}
            />

            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Internal Remarks & Payment Notes
              </label>
              <textarea
                id="fee-structure-notes-textarea"
                rows={2}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="e.g., Payable in full or two scheduled installments before mid-term..."
                className="w-full px-3 py-2 bg-slate-950/70 border border-white/10 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all resize-none"
              />
            </div>
          </div>
        </div>

        {/* Section 5: Description */}
        <div>
          <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
            Public Structure Description
          </label>
          <textarea
            id="fee-structure-description-textarea"
            rows={2}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Detailed description of fee breakdown, curriculum coverage, and student benefits..."
            className="w-full px-3.5 py-2.5 bg-slate-950/70 border border-white/15 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all resize-none"
          />
        </div>

        {/* Action Buttons */}
        <div className="pt-4 border-t border-white/10 flex items-center justify-end gap-3">
          <Button
            type="button"
            variant="secondary"
            onClick={onClose}
            disabled={isSubmitting}
          >
            Cancel
          </Button>
          <Button
            id="save-fee-structure-btn"
            type="submit"
            variant="primary"
            disabled={isSubmitting}
            className="flex items-center gap-2 shadow-lg shadow-indigo-500/20"
          >
            {isSubmitting ? (
              <LoadingSpinner size="sm" />
            ) : (
              <>
                <Check className="w-4 h-4" />
                <span>{isEditing ? 'Save Changes' : 'Create Fee Structure'}</span>
              </>
            )}
          </Button>
        </div>
      </form>
    </Modal>
  );
};
