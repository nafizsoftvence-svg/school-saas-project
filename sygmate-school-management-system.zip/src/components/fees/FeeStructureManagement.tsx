import React, { useState, useEffect, useMemo } from 'react';
import {
  FileSpreadsheet,
  Plus,
  Search,
  Filter,
  RefreshCw,
  Edit2,
  Trash2,
  Archive,
  ArchiveRestore,
  Layers,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Clock,
  Eye,
  GraduationCap,
  Calendar,
  Coins,
  DollarSign,
  ChevronRight,
  MoreVertical,
  CheckSquare,
  Square,
  Shield,
  HelpCircle,
  Sparkles,
  BarChart3,
  SlidersHorizontal,
  X
} from 'lucide-react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '../ui/Card.js';
import { Button } from '../ui/Button.js';
import { Badge } from '../ui/Badge.js';
import { Modal } from '../ui/Modal.js';
import { Select } from '../ui/Select.js';
import { LoadingSpinner } from '../ui/LoadingSpinner.js';
import { EmptyState } from '../ui/EmptyState.js';
import { useToast } from '../../context/ToastContext.js';
import { api } from '../../services/api.js';
import {
  FeeStructure,
  FeeType,
  FeeStructureStatus,
  FeeFrequency,
  FeeCategory,
  AcademicSession,
  SchoolClass,
  Section,
  FeeStructureSummaryStats
} from '../../types/index.js';
import { FeeStructureFormModal } from './FeeStructureFormModal.js';
import { FeeStructureDetailModal } from './FeeStructureDetailModal.js';

interface FeeStructureManagementProps {
  onOpenCreateFeeType?: () => void;
}

const FREQUENCY_LABELS: Record<FeeFrequency, string> = {
  YEARLY: 'Annual / Yearly',
  HALF_YEARLY: 'Half-Yearly',
  QUARTERLY: 'Quarterly',
  MONTHLY: 'Monthly',
  ONE_TIME: 'One-Time',
  CUSTOM: 'Custom Schedule'
};

export const FeeStructureManagement: React.FC<FeeStructureManagementProps> = ({
  onOpenCreateFeeType
}) => {
  const { addToast } = useToast();

  // Primary Data
  const [structures, setStructures] = useState<FeeStructure[]>([]);
  const [feeTypes, setFeeTypes] = useState<FeeType[]>([]);
  const [academicSessions, setAcademicSessions] = useState<AcademicSession[]>([]);
  const [classes, setClasses] = useState<SchoolClass[]>([]);
  const [sections, setSections] = useState<Section[]>([]);
  const [stats, setStats] = useState<FeeStructureSummaryStats | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Filters State
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [sessionFilter, setSessionFilter] = useState<string>('ALL');
  const [classFilter, setClassFilter] = useState<string>('ALL');
  const [sectionFilter, setSectionFilter] = useState<string>('ALL');
  const [typeFilter, setTypeFilter] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [categoryFilter, setCategoryFilter] = useState<string>('ALL');
  const [frequencyFilter, setFrequencyFilter] = useState<string>('ALL');
  const [viewMode, setViewMode] = useState<'table' | 'cards'>('table');

  // Selection & Batch Operations
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [isBatchUpdating, setIsBatchUpdating] = useState<boolean>(false);

  // Modals
  const [isFormModalOpen, setIsFormModalOpen] = useState<boolean>(false);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState<boolean>(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState<boolean>(false);
  const [activeStructure, setActiveStructure] = useState<FeeStructure | null>(null);

  // Fetch all dependencies & fee structures
  const loadData = async () => {
    try {
      setIsLoading(true);
      const [structRes, typeRes, sessRes, classRes, secRes, statsRes] = await Promise.all([
        api.fees.getFeeStructures(),
        api.fees.getFeeTypes(),
        api.academic.getSessions(),
        api.academic.getClasses(),
        api.academic.getSections(),
        api.fees.getFeeStructureStats()
      ]);

      if (structRes.success && structRes.data) setStructures(structRes.data);
      if (typeRes.success && typeRes.data) setFeeTypes(typeRes.data);
      if (sessRes.success && sessRes.data) setAcademicSessions(sessRes.data);
      if (classRes.success && classRes.data) setClasses(classRes.data);
      if (secRes.success && secRes.data) setSections(secRes.data);
      if (statsRes.success && statsRes.data) setStats(statsRes.data);
    } catch (err: any) {
      addToast(err.message || 'Error loading fee structures', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // Filtered available sections based on selected class filter
  const classSections = useMemo(() => {
    if (classFilter === 'ALL') return [];
    const cls = (classes || []).find((c) => c?.id === classFilter);
    if (!cls || !cls.sectionIds) return [];
    return sections.filter((s) => cls.sectionIds.includes(s.id));
  }, [classFilter, classes, sections]);

  // Filtered structures list
  const filteredStructures = useMemo(() => {
    return structures.filter((s) => {
      if (sessionFilter !== 'ALL' && s.academicSessionId !== sessionFilter) return false;
      if (classFilter !== 'ALL' && s.classId !== classFilter) return false;
      if (sectionFilter !== 'ALL') {
        if (sectionFilter === 'ALL_SECTIONS') {
          if (!s.applicableToAllSections && s.sectionId) return false;
        } else {
          if (!s.applicableToAllSections && s.sectionId !== sectionFilter) return false;
        }
      }
      if (typeFilter !== 'ALL' && s.feeTypeId !== typeFilter) return false;
      if (statusFilter !== 'ALL' && s.status !== statusFilter) return false;
      if (categoryFilter !== 'ALL') {
        if (categoryFilter === 'MANDATORY' && !s.isMandatory && s.feeCategory !== 'MANDATORY') return false;
        if (categoryFilter === 'OPTIONAL' && s.isMandatory && s.feeCategory !== 'OPTIONAL') return false;
      }
      if (frequencyFilter !== 'ALL' && s.frequency !== frequencyFilter) return false;

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesName = (s.name || '').toLowerCase().includes(q);
        const matchesType = (s.feeTypeName || '').toLowerCase().includes(q);
        const matchesClass = (s.className || '').toLowerCase().includes(q);
        const matchesSection = (s.sectionName || '').toLowerCase().includes(q);
        const matchesSession = (s.academicSessionName || '').toLowerCase().includes(q);
        const matchesDesc = (s.description || '').toLowerCase().includes(q);
        if (!matchesName && !matchesType && !matchesClass && !matchesSection && !matchesSession && !matchesDesc) {
          return false;
        }
      }
      return true;
    });
  }, [
    structures,
    sessionFilter,
    classFilter,
    sectionFilter,
    typeFilter,
    statusFilter,
    categoryFilter,
    frequencyFilter,
    searchQuery
  ]);

  // Bulk Selection Handlers
  const handleSelectAll = () => {
    if (selectedIds.length === filteredStructures.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(filteredStructures.map((s) => s.id));
    }
  };

  const handleToggleSelect = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  // Status Change Handler
  const handleStatusTransition = async (structure: FeeStructure, newStatus: FeeStructureStatus) => {
    try {
      const res = await api.fees.updateFeeStructureStatus(structure.id, newStatus);
      if (res.success && res.data) {
        addToast(`Structure '${structure.name}' is now ${newStatus}.`, 'success');
        await loadData();
        if (activeStructure && activeStructure.id === structure.id) {
          setActiveStructure(res.data);
        }
      } else {
        addToast(res.error || 'Failed to update status', 'error');
      }
    } catch (err: any) {
      addToast(err.message || 'Error updating status', 'error');
    }
  };

  // Batch Status Transition
  const handleBatchStatus = async (newStatus: FeeStructureStatus) => {
    if (selectedIds.length === 0) return;
    try {
      setIsBatchUpdating(true);
      const res = await api.fees.batchUpdateFeeStructureStatus(selectedIds, newStatus);
      if (res.success) {
        addToast(res.message || `Updated selected structures to ${newStatus}.`, 'success');
        setSelectedIds([]);
        await loadData();
      } else {
        addToast(res.error || 'Failed to batch update status', 'error');
      }
    } catch (err: any) {
      addToast(err.message || 'Error executing batch action', 'error');
    } finally {
      setIsBatchUpdating(false);
    }
  };

  // Delete Handler
  const handleDeleteConfirm = async () => {
    if (!activeStructure) return;
    try {
      const res = await api.fees.deleteFeeStructure(activeStructure.id);
      if (res.success) {
        addToast(`Fee structure '${activeStructure.name}' deleted.`, 'success');
        setIsDeleteModalOpen(false);
        setActiveStructure(null);
        await loadData();
      } else {
        addToast(res.error || 'Failed to delete fee structure', 'error');
      }
    } catch (err: any) {
      addToast(err.message || 'Error deleting fee structure', 'error');
    }
  };

  const clearFilters = () => {
    setSearchQuery('');
    setSessionFilter('ALL');
    setClassFilter('ALL');
    setSectionFilter('ALL');
    setTypeFilter('ALL');
    setStatusFilter('ALL');
    setCategoryFilter('ALL');
    setFrequencyFilter('ALL');
  };

  return (
    <div id="fee-structure-management-container" className="space-y-6">
      {/* 1. Top KPI Summary Stats */}
      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
          <div className="p-4 rounded-2xl bg-slate-900/80 border border-white/10 flex flex-col justify-between">
            <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Total Structures</div>
            <div className="text-2xl font-black text-white font-mono mt-1">{stats.totalStructures}</div>
            <div className="text-[11px] text-slate-500 mt-1">{stats.totalFeeTypes} configured types</div>
          </div>

          <div className="p-4 rounded-2xl bg-slate-900/80 border border-emerald-500/20 flex flex-col justify-between">
            <div className="text-xs font-semibold text-emerald-400 uppercase tracking-wider">Active & Live</div>
            <div className="text-2xl font-black text-emerald-400 font-mono mt-1">{stats.activeStructures}</div>
            <div className="text-[11px] text-emerald-500/70 mt-1">Collecting fees</div>
          </div>

          <div className="p-4 rounded-2xl bg-slate-900/80 border border-amber-500/20 flex flex-col justify-between">
            <div className="text-xs font-semibold text-amber-400 uppercase tracking-wider">Drafts</div>
            <div className="text-2xl font-black text-amber-400 font-mono mt-1">{stats.draftStructures}</div>
            <div className="text-[11px] text-amber-500/70 mt-1">Under review</div>
          </div>

          <div className="p-4 rounded-2xl bg-slate-900/80 border border-indigo-500/20 flex flex-col justify-between">
            <div className="text-xs font-semibold text-indigo-400 uppercase tracking-wider">Mandatory</div>
            <div className="text-2xl font-black text-indigo-300 font-mono mt-1">{stats.mandatoryCount}</div>
            <div className="text-[11px] text-indigo-400/70 mt-1">Universal enrollment</div>
          </div>

          <div className="p-4 rounded-2xl bg-slate-900/80 border border-pink-500/20 flex flex-col justify-between">
            <div className="text-xs font-semibold text-pink-400 uppercase tracking-wider">Optional</div>
            <div className="text-2xl font-black text-pink-300 font-mono mt-1">{stats.optionalCount}</div>
            <div className="text-[11px] text-pink-400/70 mt-1">Opt-in subscriptions</div>
          </div>

          <div className="p-4 rounded-2xl bg-gradient-to-br from-slate-900 via-indigo-950/40 to-slate-900 border border-indigo-500/30 flex flex-col justify-between">
            <div className="text-xs font-semibold text-slate-300 uppercase tracking-wider">Est. Annual Value</div>
            <div className="text-xl font-black text-emerald-400 font-mono mt-1 truncate">
              ${stats.totalAnnualValueEstimate.toLocaleString(undefined, { maximumFractionDigits: 0 })}
            </div>
            <div className="text-[11px] text-slate-400 mt-1">Per active scholar unit</div>
          </div>
        </div>
      )}

      {/* 2. Comprehensive Filter Toolbar */}
      <div className="p-4 rounded-2xl bg-slate-900/70 border border-white/10 space-y-3 backdrop-blur-md">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
          {/* Search */}
          <div className="relative flex-1 min-w-[260px]">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              id="fee-structure-search-input"
              type="text"
              placeholder="Search by fee name, type, class, section, session..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-8 py-2 bg-slate-950/70 border border-white/10 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2 flex-wrap">
            <Button
              id="refresh-fee-structures-btn"
              variant="ghost"
              size="sm"
              onClick={loadData}
              className="text-slate-400 hover:text-white"
            >
              <RefreshCw className="w-4 h-4" />
            </Button>

            {onOpenCreateFeeType && (
              <Button
                id="open-fee-types-btn"
                variant="secondary"
                size="sm"
                onClick={onOpenCreateFeeType}
                className="flex items-center gap-1.5"
              >
                <Coins className="w-4 h-4 text-indigo-400" />
                <span>Manage Fee Types</span>
              </Button>
            )}

            <Button
              id="create-fee-structure-btn"
              variant="primary"
              size="sm"
              onClick={() => {
                setActiveStructure(null);
                setIsFormModalOpen(true);
              }}
              className="flex items-center gap-1.5 shadow-lg shadow-indigo-500/20"
            >
              <Plus className="w-4 h-4" />
              <span>Create Fee Structure</span>
            </Button>
          </div>
        </div>

        {/* Dropdown Filters Row */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 pt-2 border-t border-white/5">
          <div>
            <Select
              id="filter-session-select"
              value={sessionFilter}
              onChange={(e) => setSessionFilter(e.target.value)}
              options={[
                { value: 'ALL', label: 'All Sessions' },
                ...academicSessions.map((s) => ({
                  value: s.id,
                  label: s.sessionName
                }))
              ]}
            />
          </div>

          <div>
            <Select
              id="filter-class-select"
              value={classFilter}
              onChange={(e) => {
                setClassFilter(e.target.value);
                setSectionFilter('ALL');
              }}
              options={[
                { value: 'ALL', label: 'All Classes' },
                ...classes.map((c) => ({
                  value: c.id,
                  label: c.name
                }))
              ]}
            />
          </div>

          <div>
            <Select
              id="filter-section-select"
              value={sectionFilter}
              disabled={classFilter === 'ALL'}
              onChange={(e) => setSectionFilter(e.target.value)}
              options={[
                { value: 'ALL', label: 'All Sections' },
                { value: 'ALL_SECTIONS', label: 'Universal (All)' },
                ...classSections.map((sec) => ({
                  value: sec.id,
                  label: `Section ${sec.name}`
                }))
              ]}
            />
          </div>

          <div>
            <Select
              id="filter-type-select"
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
              options={[
                { value: 'ALL', label: 'All Fee Types' },
                ...feeTypes.map((t) => ({
                  value: t.id,
                  label: `${t.name} (${t.code})`
                }))
              ]}
            />
          </div>

          <div>
            <Select
              id="filter-frequency-select"
              value={frequencyFilter}
              onChange={(e) => setFrequencyFilter(e.target.value)}
              options={[
                { value: 'ALL', label: 'All Frequencies' },
                { value: 'YEARLY', label: 'Yearly' },
                { value: 'HALF_YEARLY', label: 'Half-Yearly' },
                { value: 'QUARTERLY', label: 'Quarterly' },
                { value: 'MONTHLY', label: 'Monthly' },
                { value: 'ONE_TIME', label: 'One-Time' },
                { value: 'CUSTOM', label: 'Custom' }
              ]}
            />
          </div>

          <div>
            <Select
              id="filter-status-select"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              options={[
                { value: 'ALL', label: 'All Status' },
                { value: 'ACTIVE', label: 'Active' },
                { value: 'DRAFT', label: 'Draft' },
                { value: 'INACTIVE', label: 'Inactive' },
                { value: 'ARCHIVED', label: 'Archived' }
              ]}
            />
          </div>
        </div>

        {/* Active Filters Summary & Clear */}
        {(searchQuery ||
          sessionFilter !== 'ALL' ||
          classFilter !== 'ALL' ||
          sectionFilter !== 'ALL' ||
          typeFilter !== 'ALL' ||
          statusFilter !== 'ALL' ||
          categoryFilter !== 'ALL' ||
          frequencyFilter !== 'ALL') && (
          <div className="flex items-center justify-between text-xs pt-1 text-slate-400">
            <span>
              Showing <strong className="text-white">{filteredStructures.length}</strong> of{' '}
              {structures.length} fee structures
            </span>
            <button
              onClick={clearFilters}
              className="text-indigo-400 hover:text-indigo-300 underline cursor-pointer"
            >
              Clear All Filters
            </button>
          </div>
        )}
      </div>

      {/* 3. Batch Action Bar when items are selected */}
      {selectedIds.length > 0 && (
        <div className="p-3 rounded-xl bg-indigo-950/60 border border-indigo-500/30 flex items-center justify-between gap-4 text-xs animate-in fade-in duration-150">
          <div className="flex items-center gap-2 text-indigo-200">
            <CheckSquare className="w-4 h-4 text-indigo-400" />
            <span>
              <strong className="text-white">{selectedIds.length}</strong> structure(s) selected
            </span>
          </div>

          <div className="flex items-center gap-2">
            <Button
              variant="secondary"
              size="sm"
              disabled={isBatchUpdating}
              onClick={() => handleBatchStatus('ACTIVE')}
              className="bg-emerald-500/10 text-emerald-300 border-emerald-500/30 hover:bg-emerald-500/20"
            >
              Batch Activate
            </Button>
            <Button
              variant="secondary"
              size="sm"
              disabled={isBatchUpdating}
              onClick={() => handleBatchStatus('INACTIVE')}
              className="bg-amber-500/10 text-amber-300 border-amber-500/30 hover:bg-amber-500/20"
            >
              Batch Inactivate
            </Button>
            <Button
              variant="secondary"
              size="sm"
              disabled={isBatchUpdating}
              onClick={() => handleBatchStatus('ARCHIVED')}
              className="bg-rose-500/10 text-rose-300 border-rose-500/30 hover:bg-rose-500/20"
            >
              Batch Archive
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setSelectedIds([])}
              className="text-slate-400 hover:text-white"
            >
              Deselect All
            </Button>
          </div>
        </div>
      )}

      {/* 4. Structures List (Table View) */}
      {isLoading ? (
        <div className="py-20 flex justify-center">
          <LoadingSpinner size="lg" message="Loading fee structures..." />
        </div>
      ) : filteredStructures.length === 0 ? (
        <EmptyState
          icon={FileSpreadsheet}
          title="No Fee Structures Found"
          description="No fee structures match your search criteria. Create a new fee structure to get started."
          actionLabel="Create Fee Structure"
          onAction={() => {
            setActiveStructure(null);
            setIsFormModalOpen(true);
          }}
        />
      ) : (
        <div className="bg-slate-900/70 rounded-2xl border border-white/10 overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-white/10 bg-slate-950/60 text-slate-400 font-semibold uppercase tracking-wider">
                  <th className="py-3.5 px-4 w-10">
                    <input
                      type="checkbox"
                      checked={
                        filteredStructures.length > 0 &&
                        selectedIds.length === filteredStructures.length
                      }
                      onChange={handleSelectAll}
                      className="accent-indigo-500 rounded cursor-pointer"
                    />
                  </th>
                  <th className="py-3.5 px-4 min-w-[220px]">Fee Structure Name</th>
                  <th className="py-3.5 px-4 min-w-[150px]">Fee Type</th>
                  <th className="py-3.5 px-4 min-w-[160px]">Academic Scope</th>
                  <th className="py-3.5 px-4 text-right min-w-[120px]">Amount</th>
                  <th className="py-3.5 px-4 min-w-[110px]">Frequency</th>
                  <th className="py-3.5 px-4 min-w-[100px]">Due Date</th>
                  <th className="py-3.5 px-4 min-w-[100px]">Policy</th>
                  <th className="py-3.5 px-4 min-w-[90px]">Status</th>
                  <th className="py-3.5 px-4 text-right min-w-[130px]">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {filteredStructures.map((s) => {
                  const isSelected = selectedIds.includes(s.id);
                  return (
                    <tr
                      key={s.id}
                      id={`fee-structure-row-${s.id}`}
                      className={`hover:bg-slate-800/40 transition-colors ${
                        isSelected ? 'bg-indigo-950/30' : ''
                      }`}
                    >
                      <td className="py-3.5 px-4">
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => handleToggleSelect(s.id)}
                          className="accent-indigo-500 rounded cursor-pointer"
                        />
                      </td>

                      {/* Name */}
                      <td className="py-3.5 px-4">
                        <div className="font-semibold text-white text-sm hover:text-indigo-300 cursor-pointer"
                          onClick={() => {
                            setActiveStructure(s);
                            setIsDetailModalOpen(true);
                          }}
                        >
                          {s.name}
                        </div>
                        {s.description && (
                          <div className="text-[11px] text-slate-400 line-clamp-1 mt-0.5">
                            {s.description}
                          </div>
                        )}
                      </td>

                      {/* Type */}
                      <td className="py-3.5 px-4">
                        <div className="font-medium text-slate-200">{s.feeTypeName}</div>
                        <span className="text-[10px] font-mono text-indigo-400 bg-indigo-500/10 px-1.5 py-0.5 rounded border border-indigo-500/20">
                          {s.feeTypeCode}
                        </span>
                      </td>

                      {/* Scope */}
                      <td className="py-3.5 px-4">
                        <div className="font-semibold text-slate-200">{s.className}</div>
                        <div className="text-[11px] text-slate-400">
                          {s.applicableToAllSections || !s.sectionId
                            ? 'All Sections'
                            : `Section ${s.sectionName}`}
                        </div>
                        <div className="text-[10px] text-slate-500">{s.academicSessionName}</div>
                      </td>

                      {/* Amount */}
                      <td className="py-3.5 px-4 text-right font-mono font-bold text-emerald-400 text-sm">
                        {s.currency} {s.amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </td>

                      {/* Frequency */}
                      <td className="py-3.5 px-4 text-slate-300">
                        {FREQUENCY_LABELS[s.frequency] || s.frequency}
                      </td>

                      {/* Due Date */}
                      <td className="py-3.5 px-4 font-mono text-slate-300">{s.dueDate}</td>

                      {/* Mandatory / Optional Policy */}
                      <td className="py-3.5 px-4">
                        {s.isMandatory || s.feeCategory === 'MANDATORY' ? (
                          <span className="inline-flex items-center text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-500/10 text-rose-300 border border-rose-500/30">
                            Mandatory
                          </span>
                        ) : (
                          <span className="inline-flex items-center text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-300 border border-emerald-500/30">
                            Optional
                          </span>
                        )}
                      </td>

                      {/* Status */}
                      <td className="py-3.5 px-4">
                        <Badge
                          variant={
                            s.status === 'ACTIVE'
                              ? 'success'
                              : s.status === 'DRAFT'
                              ? 'warning'
                              : s.status === 'INACTIVE'
                              ? 'secondary'
                              : 'danger'
                          }
                          className="text-[11px] font-bold"
                        >
                          {s.status}
                        </Badge>
                      </td>

                      {/* Actions */}
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1">
                          <Button
                            id={`view-fee-structure-${s.id}`}
                            variant="ghost"
                            size="sm"
                            onClick={() => {
                              setActiveStructure(s);
                              setIsDetailModalOpen(true);
                            }}
                            className="h-8 px-2 text-slate-400 hover:text-white"
                            title="View full specification"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </Button>

                          {s.status !== 'ARCHIVED' && (
                            <Button
                              id={`edit-fee-structure-${s.id}`}
                              variant="ghost"
                              size="sm"
                              onClick={() => {
                                setActiveStructure(s);
                                setIsFormModalOpen(true);
                              }}
                              className="h-8 px-2 text-slate-400 hover:text-white"
                              title="Edit fee structure"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </Button>
                          )}

                          {/* Quick Toggle Status */}
                          {s.status === 'DRAFT' && (
                            <Button
                              id={`activate-fee-structure-${s.id}`}
                              variant="ghost"
                              size="sm"
                              onClick={() => handleStatusTransition(s, 'ACTIVE')}
                              className="h-8 px-2 text-emerald-400 hover:text-emerald-300 hover:bg-emerald-500/10"
                              title="Activate fee structure"
                            >
                              <CheckCircle2 className="w-3.5 h-3.5" />
                            </Button>
                          )}

                          {s.status === 'ACTIVE' && (
                            <Button
                              id={`suspend-fee-structure-${s.id}`}
                              variant="ghost"
                              size="sm"
                              onClick={() => handleStatusTransition(s, 'INACTIVE')}
                              className="h-8 px-2 text-amber-400 hover:text-amber-300 hover:bg-amber-500/10"
                              title="Suspend / Inactivate"
                            >
                              <XCircle className="w-3.5 h-3.5" />
                            </Button>
                          )}

                          {s.status === 'INACTIVE' && (
                            <Button
                              id={`reactivate-fee-structure-${s.id}`}
                              variant="ghost"
                              size="sm"
                              onClick={() => handleStatusTransition(s, 'ACTIVE')}
                              className="h-8 px-2 text-emerald-400 hover:text-emerald-300 hover:bg-emerald-500/10"
                              title="Reactivate"
                            >
                              <CheckCircle2 className="w-3.5 h-3.5" />
                            </Button>
                          )}

                          {(s.status === 'DRAFT' || s.status === 'ARCHIVED') && (
                            <Button
                              id={`delete-fee-structure-${s.id}`}
                              variant="ghost"
                              size="sm"
                              onClick={() => {
                                setActiveStructure(s);
                                setIsDeleteModalOpen(true);
                              }}
                              className="h-8 px-2 text-rose-400 hover:text-rose-300 hover:bg-rose-500/10"
                              title="Delete permanently"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </Button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 5. Create / Edit Modal */}
      <FeeStructureFormModal
        isOpen={isFormModalOpen}
        onClose={() => {
          setIsFormModalOpen(false);
          setActiveStructure(null);
        }}
        structureToEdit={activeStructure}
        onSuccess={loadData}
        feeTypes={feeTypes}
        academicSessions={academicSessions}
        classes={classes}
        sections={sections}
        onOpenCreateFeeType={onOpenCreateFeeType}
      />

      {/* 6. Inspection Detail Modal */}
      <FeeStructureDetailModal
        isOpen={isDetailModalOpen}
        onClose={() => {
          setIsDetailModalOpen(false);
          setActiveStructure(null);
        }}
        structure={activeStructure}
        onEdit={(s) => {
          setActiveStructure(s);
          setIsFormModalOpen(true);
        }}
        onStatusChange={handleStatusTransition}
        onDelete={(s) => {
          setActiveStructure(s);
          setIsDeleteModalOpen(true);
        }}
      />

      {/* 7. Delete Confirmation Modal */}
      <Modal
        isOpen={isDeleteModalOpen}
        onClose={() => {
          setIsDeleteModalOpen(false);
          setActiveStructure(null);
        }}
        title={
          <div className="flex items-center gap-2 text-rose-400">
            <AlertCircle className="w-5 h-5" />
            <span>Delete Fee Structure</span>
          </div>
        }
        description="Are you sure you want to permanently delete this fee structure?"
        size="md"
        id="delete-fee-structure-modal"
      >
        <div className="space-y-4">
          <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/20 text-xs text-rose-300 leading-relaxed">
            Deleting fee structure <strong className="text-white font-semibold">'{activeStructure?.name}'</strong> will remove it from the database. This action cannot be undone.
          </div>

          <div className="pt-4 border-t border-white/10 flex items-center justify-end gap-3">
            <Button
              type="button"
              variant="secondary"
              onClick={() => {
                setIsDeleteModalOpen(false);
                setActiveStructure(null);
              }}
            >
              Cancel
            </Button>
            <Button
              id="confirm-delete-fee-structure-btn"
              type="button"
              variant="danger"
              onClick={handleDeleteConfirm}
              className="flex items-center gap-2"
            >
              <Trash2 className="w-4 h-4" />
              <span>Delete Structure</span>
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
