import React, { useState, useEffect } from 'react';
import { X, AlertTriangle, DollarSign, CheckCircle2, User } from 'lucide-react';
import { AppliedFineRecord, ApplyManualFinePayload, StudentFeeRecord } from '../../types/index.js';
import { api } from '../../services/api.js';
import { useToast } from '../../context/ToastContext.js';

interface ManualFineModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (result: { fineRecord: AppliedFineRecord; feeRecord: any }) => void;
  preselectedFeeRecord?: StudentFeeRecord | null;
}

export const ManualFineModal: React.FC<ManualFineModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  preselectedFeeRecord
}) => {
  const { showToast } = useToast();

  const [studentSearch, setStudentSearch] = useState('');
  const [students, setStudents] = useState<any[]>([]);
  const [selectedStudent, setSelectedStudent] = useState<any | null>(null);

  const [studentInvoices, setStudentInvoices] = useState<StudentFeeRecord[]>([]);
  const [selectedFeeRecordId, setSelectedFeeRecordId] = useState<string>('');

  const [fineType, setFineType] = useState<string>('LATE_PAYMENT');
  const [amount, setAmount] = useState<string>('25');
  const [reason, setReason] = useState<string>('Overdue Tuition Fee Late Surcharge');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [isLoadingInvoices, setIsLoadingInvoices] = useState<boolean>(false);

  useEffect(() => {
    if (isOpen) {
      if (preselectedFeeRecord) {
        setSelectedStudent({
          id: preselectedFeeRecord.studentId,
          fullName: preselectedFeeRecord.studentName,
          admissionNumber: preselectedFeeRecord.admissionNumber,
          className: preselectedFeeRecord.className
        });
        setSelectedFeeRecordId(preselectedFeeRecord.id);
        setStudentInvoices([preselectedFeeRecord]);
      } else {
        setSelectedStudent(null);
        setSelectedFeeRecordId('');
        setStudentInvoices([]);
        api.users
          .getStudents({ limit: 100 })
          .then((res: any) => {
            if (res?.data?.students) setStudents(res.data.students);
            else if (Array.isArray(res?.data)) setStudents(res.data);
          })
          .catch(() => {});
      }

      setFineType('LATE_PAYMENT');
      setAmount('25');
      setReason('Overdue Fee Surcharge');
    }
  }, [isOpen, preselectedFeeRecord]);

  const handleSelectStudent = async (student: any) => {
    setSelectedStudent(student);
    setSelectedFeeRecordId('');
    setIsLoadingInvoices(true);
    try {
      const res = await api.fees.getStudentFees({
        studentId: student.id,
        limit: 50
      });
      if (res.success && res.data) {
        const feesList: StudentFeeRecord[] = (res.data as any).fees || (res.data as any).data || (Array.isArray(res.data) ? res.data : []);
        const activeFees = feesList.filter((f) => f.status !== 'CANCELLED');
        setStudentInvoices(activeFees);
        if (activeFees && activeFees.length > 0) {
          setSelectedFeeRecordId(activeFees?.[0]?.id || '');
        }
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoadingInvoices(false);
    }
  };

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStudent || !selectedFeeRecordId) {
      showToast('Please select a student and an invoice', 'error');
      return;
    }

    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount <= 0) {
      showToast('Please enter a valid fine amount', 'error');
      return;
    }

    if (!reason.trim()) {
      showToast('Please provide a reason for levying this fine', 'error');
      return;
    }

    setIsSubmitting(true);
    try {
      const payload: ApplyManualFinePayload = {
        studentId: selectedStudent.id,
        feeRecordId: selectedFeeRecordId,
        amount: numAmount,
        reason: reason.trim(),
        fineType
      };

      const res = await api.fees.applyManualFine(payload);
      if (res.success && res.data) {
        showToast(`Fine of $${numAmount.toFixed(2)} applied to invoice`, 'success');
        onSuccess(res.data);
        onClose();
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to apply fine', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const filteredStudents = studentSearch
    ? students.filter(
        (s) =>
          s.fullName?.toLowerCase().includes(studentSearch.toLowerCase()) ||
          s.admissionNumber?.toLowerCase().includes(studentSearch.toLowerCase())
      )
    : students.slice(0, 6);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto"
      onClick={(e) => {
        if (e.target === e.currentTarget && !isSubmitting) onClose();
      }}
    >
      <div className="relative w-full max-w-lg bg-slate-900 border border-white/15 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 bg-slate-950/70">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-rose-500/15 border border-rose-500/30 flex items-center justify-center text-rose-400">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Levy Manual Fine / Penalty</h3>
              <p className="text-xs text-slate-400">Add an overdue or disciplinary fine to student fee</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
          {/* Select Student */}
          {!preselectedFeeRecord && (
            <div className="space-y-2">
              <label className="block text-xs font-semibold text-slate-300">
                1. Select Student <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                value={studentSearch}
                onChange={(e) => setStudentSearch(e.target.value)}
                placeholder="Search student..."
                className="w-full px-3 py-2 text-xs bg-slate-950 border border-white/10 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-rose-500"
              />
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-28 overflow-y-auto">
                {filteredStudents.map((st) => (
                  <button
                    key={st.id}
                    type="button"
                    onClick={() => handleSelectStudent(st)}
                    className={`text-left p-2.5 rounded-xl border text-xs transition-colors flex items-center justify-between ${
                      selectedStudent?.id === st.id
                        ? 'bg-rose-500/20 text-rose-300 border-rose-500/50 font-bold'
                        : 'bg-white/5 text-slate-300 border-white/10 hover:bg-white/10'
                    }`}
                  >
                    <div>
                      <p className="font-semibold text-white">{st.fullName}</p>
                      <p className="text-[10px] text-slate-400">{st.admissionNumber || st.className}</p>
                    </div>
                    {selectedStudent?.id === st.id && <CheckCircle2 className="w-4 h-4 text-rose-400" />}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Select Invoice */}
          {selectedStudent && (
            <div className="space-y-2">
              <label className="block text-xs font-semibold text-slate-300">
                2. Target Invoice <span className="text-rose-400">*</span>
              </label>
              {isLoadingInvoices ? (
                <div className="p-3 text-center text-xs text-slate-400">Loading student invoices...</div>
              ) : (
                <select
                  value={selectedFeeRecordId}
                  onChange={(e) => setSelectedFeeRecordId(e.target.value)}
                  required
                  className="w-full px-3 py-2 text-xs bg-slate-950 border border-white/10 rounded-xl text-white focus:outline-none focus:border-rose-500"
                >
                  {studentInvoices.map((inv) => (
                    <option key={inv.id} value={inv.id}>
                      {inv.invoiceNumber} - {inv.title} (Due: ${inv.dueAmount.toFixed(2)})
                    </option>
                  ))}
                </select>
              )}
            </div>
          )}

          {/* Fine Type & Amount */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Fine Category</label>
              <select
                value={fineType}
                onChange={(e) => setFineType(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-950 border border-white/10 rounded-xl text-white focus:outline-none focus:border-rose-500"
              >
                <option value="LATE_PAYMENT">Late Payment Surcharge</option>
                <option value="LIBRARY_OVERDUE">Library Overdue Book Fee</option>
                <option value="PROPERTY_DAMAGE">Campus / Lab Property Damage</option>
                <option value="DISCIPLINARY">Disciplinary Penalty</option>
                <option value="MANUAL_ADJUSTMENT">Administrative Adjustment</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Fine Amount ($) <span className="text-rose-400">*</span>
              </label>
              <div className="relative">
                <span className="absolute left-3 top-2.5 text-xs text-slate-400">$</span>
                <input
                  type="number"
                  step="0.01"
                  min="0.01"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="25"
                  required
                  className="w-full pl-8 pr-3 py-2 text-xs font-mono font-bold bg-slate-950 border border-white/10 rounded-xl text-rose-300 focus:outline-none focus:border-rose-500"
                />
              </div>
            </div>
          </div>

          {/* Reason */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Reason / Violation Details <span className="text-rose-400">*</span>
            </label>
            <textarea
              rows={2}
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="e.g. Overdue fee past due date by 14 days..."
              required
              className="w-full px-3 py-2 text-xs bg-slate-950 border border-white/10 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-rose-500"
            />
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-bold text-slate-400 hover:text-white bg-white/5 hover:bg-white/10 rounded-xl transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting || !selectedFeeRecordId}
              className="px-5 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-500 disabled:opacity-50 rounded-xl shadow-lg shadow-rose-600/20 transition-all cursor-pointer flex items-center gap-2"
            >
              {isSubmitting ? (
                <span>Levying Fine...</span>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Levy Fine</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
