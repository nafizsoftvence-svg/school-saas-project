import React, { useState, useEffect } from 'react';
import {
  X,
  CreditCard,
  CheckCircle2,
  AlertCircle,
  Calendar,
  DollarSign,
  FileText,
  User,
  Building,
  ArrowRight,
  ShieldAlert,
  Loader2,
  Clock,
  Sparkles
} from 'lucide-react';
import {
  StudentFeeRecord,
  PaymentMethodConfig,
  CollectFeePaymentPayload,
  CollectFeePaymentResponse,
  PaymentMethod
} from '../../types/index.js';
import { api } from '../../services/api.js';

interface CollectFeeModalProps {
  isOpen: boolean;
  onClose: () => void;
  feeRecord: StudentFeeRecord | null;
  onPaymentSuccess: (result: CollectFeePaymentResponse['data']) => void;
}

export const CollectFeeModal: React.FC<CollectFeeModalProps> = ({
  isOpen,
  onClose,
  feeRecord,
  onPaymentSuccess
}) => {
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethodConfig[]>([]);
  const [selectedMethod, setSelectedMethod] = useState<string>('CASH');
  const [amount, setAmount] = useState<string>('');
  const [paymentDate, setPaymentDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  );
  const [referenceNumber, setReferenceNumber] = useState<string>('');
  const [cardholderName, setCardholderName] = useState<string>('');
  const [notes, setNotes] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [idempotencyKey, setIdempotencyKey] = useState<string>('');

  // Fetch payment methods and reset form
  useEffect(() => {
    if (isOpen && feeRecord) {
      setErrorMessage(null);
      const remaining = Number(feeRecord.dueAmount ?? 0) > 0 ? Number(feeRecord.dueAmount) : 0;
      setAmount(remaining.toFixed(2));
      setPaymentDate(new Date().toISOString().split('T')[0]);
      setReferenceNumber('');
      setCardholderName('');
      setNotes('');
      setIdempotencyKey(`pay_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`);

      api.fees
        .getPaymentMethods()
        .then((res) => {
          if (res.success && res.data) {
            const activeMethods = res.data.filter((m) => m.isActive);
            setPaymentMethods(activeMethods);
            if (activeMethods.length > 0 && !activeMethods.some((m) => m.code === selectedMethod)) {
              setSelectedMethod(activeMethods?.[0]?.code || 'CASH');
            }
          }
        })
        .catch(() => {
          // Fallback methods
          setPaymentMethods([
            { id: '1', code: 'CASH', name: 'Cash', isActive: true, requiresReference: false, displayOrder: 1 },
            { id: '2', code: 'BANK_TRANSFER', name: 'Bank Transfer', isActive: true, requiresReference: true, displayOrder: 2 },
            { id: '3', code: 'CREDIT_CARD', name: 'Credit Card (POS)', isActive: true, requiresReference: true, displayOrder: 3 },
            { id: '4', code: 'DEBIT_CARD', name: 'Debit Card (POS)', isActive: true, requiresReference: true, displayOrder: 4 },
            { id: '5', code: 'CHEQUE', name: 'Cheque / Draft', isActive: true, requiresReference: true, displayOrder: 5 },
            { id: '6', code: 'MOBILE_BANKING', name: 'Mobile Banking / Wallet', isActive: true, requiresReference: true, displayOrder: 6 }
          ]);
        });
    }
  }, [isOpen, feeRecord]);

  if (!isOpen || !feeRecord) return null;

  const totalPayable = Number(feeRecord.netPayableAmount || feeRecord.totalAmount || 0);
  const currentPaid = Number(feeRecord.paidAmount || 0);
  const currentDue = Number(feeRecord.dueAmount || 0);

  const parsedAmount = parseFloat(amount) || 0;
  const newDue = Math.max(0, parseFloat((currentDue - parsedAmount).toFixed(2)));
  const willBeFullyPaid = newDue <= 0 && parsedAmount > 0;

  const currentMethodConfig = (paymentMethods || []).find((m) => m?.code === selectedMethod);

  const handleQuickAmount = (type: 'FULL' | 'HALF' | 'QUARTER') => {
    if (type === 'FULL') {
      setAmount(Number(currentDue).toFixed(2));
    } else if (type === 'HALF') {
      setAmount((currentDue / 2).toFixed(2));
    } else if (type === 'QUARTER') {
      setAmount((currentDue / 4).toFixed(2));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (parsedAmount <= 0) {
      setErrorMessage('Payment amount must be greater than $0.00.');
      return;
    }

    if (parsedAmount > currentDue + 0.01) {
      setErrorMessage(
        `Payment amount ($${Number(parsedAmount).toFixed(2)}) cannot exceed the remaining due balance ($${Number(currentDue).toFixed(2)}).`
      );
      return;
    }

    if (currentMethodConfig?.requiresReference && !referenceNumber.trim()) {
      setErrorMessage(
        `Reference / Transaction / Cheque Number is required for ${currentMethodConfig.name}.`
      );
      return;
    }

    setIsSubmitting(true);

    try {
      const payload: CollectFeePaymentPayload = {
        feeRecordId: feeRecord.id,
        amount: parsedAmount,
        paymentDate,
        paymentMethod: selectedMethod as PaymentMethod,
        referenceNumber: referenceNumber.trim() || undefined,
        cardholderName: cardholderName.trim() || undefined,
        notes: notes.trim() || undefined,
        idempotencyKey
      };

      const response = await api.fees.collectFeePayment(payload);

      if (response.success && response.data) {
        onPaymentSuccess(response.data);
        onClose();
      } else {
        setErrorMessage(response.error || 'Failed to process fee payment.');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'An unexpected error occurred while collecting payment.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto"
      onClick={(e) => {
        if (e.target === e.currentTarget && !isSubmitting) onClose();
      }}
    >
      <div className="relative w-full max-w-xl bg-slate-900 border border-white/15 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 bg-slate-950/80">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
              <CreditCard className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">
                Collect Student Fee Payment
              </h3>
              <p className="text-xs text-slate-400">
                Invoice #{feeRecord.invoiceNumber} &bull; {feeRecord.studentName}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            disabled={isSubmitting}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/10 transition-colors disabled:opacity-50 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Invoice Summary Card */}
        <div className="p-6 bg-slate-950/50 border-b border-white/10">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div className="p-3 bg-slate-900/80 rounded-xl border border-white/5">
              <p className="text-slate-400 text-[10px] uppercase font-semibold">Net Payable</p>
              <p className="text-sm font-bold text-white font-mono mt-0.5">
                ${Number(totalPayable ?? 0).toFixed(2)}
              </p>
            </div>
            <div className="p-3 bg-slate-900/80 rounded-xl border border-white/5">
              <p className="text-slate-400 text-[10px] uppercase font-semibold">Already Paid</p>
              <p className="text-sm font-bold text-emerald-400 font-mono mt-0.5">
                ${Number(currentPaid ?? 0).toFixed(2)}
              </p>
            </div>
            <div className="p-3 bg-amber-500/10 rounded-xl border border-amber-500/20 col-span-2">
              <p className="text-amber-400 text-[10px] uppercase font-semibold">Outstanding Due Balance</p>
              <p className="text-base font-extrabold text-amber-300 font-mono mt-0.5">
                ${Number(currentDue ?? 0).toFixed(2)}
              </p>
            </div>
          </div>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {errorMessage && (
            <div className="p-3.5 bg-rose-500/10 border border-rose-500/30 rounded-xl text-xs text-rose-300 flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-rose-200">Validation Error</p>
                <p>{errorMessage}</p>
              </div>
            </div>
          )}

          {/* Amount Field + Quick Presets */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold text-slate-300">
                Payment Amount ($ USD) <span className="text-rose-400">*</span>
              </label>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() => handleQuickAmount('FULL')}
                  className="px-2 py-0.5 text-[10px] font-semibold text-indigo-300 bg-indigo-500/10 hover:bg-indigo-500/20 border border-indigo-500/30 rounded transition-colors cursor-pointer"
                >
                  Full (${Number(currentDue ?? 0).toFixed(2)})
                </button>
                {currentDue > 10 && (
                  <button
                    type="button"
                    onClick={() => handleQuickAmount('HALF')}
                    className="px-2 py-0.5 text-[10px] font-semibold text-slate-300 bg-white/5 hover:bg-white/10 border border-white/10 rounded transition-colors cursor-pointer"
                  >
                    50% (${(Number(currentDue ?? 0) / 2).toFixed(2)})
                  </button>
                )}
              </div>
            </div>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400 font-bold">
                $
              </div>
              <input
                type="number"
                step="0.01"
                min="0.01"
                max={currentDue}
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.00"
                required
                className="w-full pl-8 pr-4 py-2.5 bg-slate-950 border border-white/15 rounded-xl text-white font-mono text-base font-semibold focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
              />
            </div>
            <p className="text-[11px] text-slate-400 mt-1 flex items-center justify-between">
              <span>Remaining balance after this payment:</span>
              <span className={`font-mono font-bold ${newDue <= 0 ? 'text-emerald-400' : 'text-amber-400'}`}>
                ${Number(newDue ?? 0).toFixed(2)} ({willBeFullyPaid ? 'Fully Paid' : 'Partially Paid'})
              </span>
            </p>
          </div>

          {/* Payment Method & Date */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Payment Method <span className="text-rose-400">*</span>
              </label>
              <select
                value={selectedMethod}
                onChange={(e) => setSelectedMethod(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-white/15 rounded-xl text-xs text-white focus:outline-none focus:border-indigo-500 cursor-pointer"
              >
                {paymentMethods.map((m) => (
                  <option key={m.code} value={m.code}>
                    {m.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Payment Date <span className="text-rose-400">*</span>
              </label>
              <input
                type="date"
                value={paymentDate}
                onChange={(e) => setPaymentDate(e.target.value)}
                max={new Date().toISOString().split('T')[0]}
                required
                className="w-full px-3 py-2 bg-slate-950 border border-white/15 rounded-xl text-xs text-white focus:outline-none focus:border-indigo-500"
              />
            </div>
          </div>

          {/* Reference Number & Cardholder Name */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Reference / Cheque / Slip #
                {currentMethodConfig?.requiresReference && (
                  <span className="text-rose-400"> *</span>
                )}
              </label>
              <input
                type="text"
                value={referenceNumber}
                onChange={(e) => setReferenceNumber(e.target.value)}
                placeholder={
                  selectedMethod === 'CHEQUE'
                    ? 'e.g. CHQ-99012'
                    : selectedMethod === 'BANK_TRANSFER'
                    ? 'e.g. WIRE-88741'
                    : 'e.g. POS Ref / Slip ID'
                }
                required={currentMethodConfig?.requiresReference}
                className="w-full px-3 py-2 bg-slate-950 border border-white/15 rounded-xl text-xs text-white focus:outline-none focus:border-indigo-500 font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Payer / Cardholder Name <span className="text-slate-400 font-normal">(Optional)</span>
              </label>
              <input
                type="text"
                value={cardholderName}
                onChange={(e) => setCardholderName(e.target.value)}
                placeholder="e.g. John Doe (Parent)"
                className="w-full px-3 py-2 bg-slate-950 border border-white/15 rounded-xl text-xs text-white focus:outline-none focus:border-indigo-500"
              />
            </div>
          </div>

          {/* Remarks & Cashier Notes */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Collector Notes / Remarks <span className="text-slate-400 font-normal">(Optional)</span>
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Collected at front desk finance counter, receipt handed to student"
              className="w-full px-3 py-2 bg-slate-950 border border-white/15 rounded-xl text-xs text-white focus:outline-none focus:border-indigo-500"
            />
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="px-4 py-2 text-xs font-semibold text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting || parsedAmount <= 0}
              className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 rounded-xl shadow-lg shadow-emerald-600/20 transition-all cursor-pointer"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Processing Payment...
                </>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  Confirm & Collect ${parsedAmount > 0 ? Number(parsedAmount).toFixed(2) : '0.00'}
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
