import React, { useState } from 'react';
import { X, Percent, ArrowDownRight, DollarSign } from 'lucide-react';
import { StudentFeeRecord } from '../../types/index.js';
import { api } from '../../services/api.js';
import { useToast } from '../../context/ToastContext.js';

interface ApplyDiscountModalProps {
  isOpen: boolean;
  onClose: () => void;
  feeRecord: StudentFeeRecord | null;
  onSuccess: (updated: StudentFeeRecord) => void;
}

export const ApplyDiscountModal: React.FC<ApplyDiscountModalProps> = ({
  isOpen,
  onClose,
  feeRecord,
  onSuccess
}) => {
  const { showToast } = useToast();
  const [discountAmount, setDiscountAmount] = useState<string>(
    feeRecord ? feeRecord.discountAmount.toString() : '0'
  );
  const [discountReason, setDiscountReason] = useState<string>(
    feeRecord?.discountReason || ''
  );
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Update defaults when feeRecord opens
  React.useEffect(() => {
    if (feeRecord) {
      setDiscountAmount(feeRecord.discountAmount.toString());
      setDiscountReason(feeRecord.discountReason || '');
    }
  }, [feeRecord]);

  if (!isOpen || !feeRecord) return null;

  const parsedDiscount = parseFloat(discountAmount) || 0;
  const maxAllowedDiscount = feeRecord.totalAmount + (feeRecord.fineAmount || 0);
  const projectedNetPayable = Math.max(0, feeRecord.totalAmount - parsedDiscount + (feeRecord.fineAmount || 0));
  const projectedRemainingDue = Math.max(0, projectedNetPayable - feeRecord.paidAmount);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (isNaN(parsedDiscount) || parsedDiscount < 0) {
      showToast('Discount amount must be a positive number or zero.', 'error');
      return;
    }

    if (parsedDiscount > maxAllowedDiscount) {
      showToast(`Discount cannot exceed the total charges ($${Number(maxAllowedDiscount ?? 0).toFixed(2)}).`, 'error');
      return;
    }

    if (!discountReason.trim()) {
      showToast('Please provide an official reason or approval note for this discount.', 'error');
      return;
    }

    setIsSubmitting(true);
    try {
      const updated = await api.fees.applyDiscount(feeRecord.id, {
        discountAmount: parsedDiscount,
        discountReason: discountReason.trim()
      });
      showToast(`Successfully updated discount for invoice ${feeRecord.invoiceNumber}.`, 'success');
      onSuccess(updated);
      onClose();
    } catch (err: any) {
      showToast(err.message || 'Failed to apply discount.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="relative w-full max-w-md bg-slate-900 border border-white/15 rounded-2xl shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 bg-slate-950/70">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <ArrowDownRight className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">Apply Fee Discount</h3>
              <p className="text-[11px] text-slate-400">Invoice: {feeRecord.invoiceNumber}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-white/10 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {/* Target Student Info */}
          <div className="p-3 bg-white/[0.02] border border-white/10 rounded-xl text-xs space-y-1">
            <p className="font-bold text-white">{feeRecord.studentName}</p>
            <p className="text-slate-400">
              {feeRecord.className} &bull; {feeRecord.title} &bull; Base Fee: ${Number(feeRecord.totalAmount ?? 0).toFixed(2)}
            </p>
          </div>

          {/* Discount Amount */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              Discount Amount ($) *
            </label>
            <div className="relative">
              <DollarSign className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
              <input
                type="number"
                min="0"
                max={maxAllowedDiscount}
                step="0.01"
                value={discountAmount}
                onChange={(e) => setDiscountAmount(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-xs bg-slate-950 border border-white/15 rounded-xl text-white font-mono focus:outline-none focus:border-emerald-500"
                required
              />
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              Max allowable discount: ${Number(maxAllowedDiscount ?? 0).toFixed(2)}
            </p>
          </div>

          {/* Discount Approval Reason */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              Approval Reason / Concession Note *
            </label>
            <textarea
              rows={2}
              placeholder="e.g., Sibling discount approved by Principal / Scholarship concession"
              value={discountReason}
              onChange={(e) => setDiscountReason(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-950 border border-white/15 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 resize-none"
              required
            />
          </div>

          {/* Live Financial Projection Card */}
          <div className="p-3.5 bg-slate-950/80 border border-white/10 rounded-xl space-y-2 text-xs">
            <p className="font-bold text-slate-300 uppercase tracking-wider text-[10px]">
              Financial Impact Preview
            </p>
            <div className="flex justify-between text-slate-300">
              <span>Gross Fee:</span>
              <span className="font-mono text-slate-200">${Number(feeRecord.totalAmount ?? 0).toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-emerald-400 font-semibold">
              <span>New Discount:</span>
              <span className="font-mono">-${Number(parsedDiscount ?? 0).toFixed(2)}</span>
            </div>
            <div className="pt-2 border-t border-white/10 flex justify-between font-bold text-white">
              <span>New Net Payable:</span>
              <span className="font-mono text-indigo-300">${Number(projectedNetPayable ?? 0).toFixed(2)}</span>
            </div>
            <div className="flex justify-between font-bold">
              <span className="text-slate-300">New Balance Due:</span>
              <span className="font-mono text-amber-400">${Number(projectedRemainingDue ?? 0).toFixed(2)}</span>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white bg-white/5 hover:bg-white/10 rounded-xl transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="inline-flex items-center gap-2 px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 rounded-xl shadow-lg shadow-emerald-600/30 transition-all disabled:opacity-50 cursor-pointer"
            >
              {isSubmitting ? 'Saving...' : 'Apply Discount'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
