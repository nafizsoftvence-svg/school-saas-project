import React, { useState } from 'react';
import { X, ShieldCheck, CheckCircle2, AlertTriangle } from 'lucide-react';
import { AppliedFineRecord, WaiveFinePayload } from '../../types/index.js';
import { api } from '../../services/api.js';
import { useToast } from '../../context/ToastContext.js';

interface WaiveFineModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (updatedRecord: AppliedFineRecord) => void;
  fineRecord: AppliedFineRecord | null;
}

export const WaiveFineModal: React.FC<WaiveFineModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  fineRecord
}) => {
  const { showToast } = useToast();
  const [waiveReason, setWaiveReason] = useState('Principal Discretionary Fine Waiver');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen || !fineRecord) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!waiveReason.trim()) {
      showToast('Please specify a mandatory reason for waiving this fine', 'error');
      return;
    }

    setIsSubmitting(true);
    try {
      const payload: WaiveFinePayload = {
        reason: waiveReason.trim()
      };
      const res = await api.fees.waiveFine(fineRecord.id, payload);
      if (res.success && res.data) {
        showToast(`Fine of $${Number(fineRecord.amount ?? 0).toFixed(2)} successfully waived`, 'success');
        onSuccess(res.data);
        onClose();
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to waive fine', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto"
      onClick={(e) => {
        if (e.target === e.currentTarget && !isSubmitting) onClose();
      }}
    >
      <div className="relative w-full max-w-md bg-slate-900 border border-white/15 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 bg-slate-950/70">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-teal-500/15 border border-teal-500/30 flex items-center justify-center text-teal-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Waive Fine Penalty</h3>
              <p className="text-xs text-slate-400">Exempt penalty and recalculate net balance</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="p-3 bg-white/5 border border-white/10 rounded-xl space-y-1 text-xs">
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Student:</span>
              <span className="font-bold text-white">{fineRecord.studentName}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Invoice:</span>
              <span className="font-mono text-slate-200">{fineRecord.invoiceNumber}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Penalty Amount:</span>
              <span className="font-mono font-bold text-rose-400">${Number(fineRecord.amount ?? 0).toFixed(2)}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Original Reason:</span>
              <span className="text-slate-300">{fineRecord.reason}</span>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Waiver Justification / Authorization <span className="text-rose-400">*</span>
            </label>
            <textarea
              rows={3}
              value={waiveReason}
              onChange={(e) => setWaiveReason(e.target.value)}
              placeholder="e.g. Bank processing delay confirmed; cleared by Bursar..."
              required
              className="w-full px-3 py-2 text-xs bg-slate-950 border border-white/10 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-teal-500"
            />
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-bold text-slate-400 hover:text-white bg-white/5 hover:bg-white/10 rounded-xl transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2 text-xs font-bold text-white bg-teal-600 hover:bg-teal-500 disabled:opacity-50 rounded-xl shadow-lg shadow-teal-600/20 transition-all cursor-pointer flex items-center gap-2"
            >
              {isSubmitting ? (
                <span>Waiving Fine...</span>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Waive Fine Penalty</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
