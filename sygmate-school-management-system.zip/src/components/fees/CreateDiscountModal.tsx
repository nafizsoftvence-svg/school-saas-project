import React, { useState, useEffect } from 'react';
import { X, Percent, DollarSign, Calendar, Sparkles, CheckCircle2, AlertCircle } from 'lucide-react';
import {
  FeeDiscountRule,
  CreateDiscountRulePayload,
  AcademicSession,
  SchoolClass,
  Section,
  FeeType
} from '../../types/index.js';
import { api } from '../../services/api.js';
import { useToast } from '../../context/ToastContext.js';

interface CreateDiscountModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (newDiscount: FeeDiscountRule) => void;
  discountToEdit?: FeeDiscountRule | null;
  sessions: AcademicSession[];
  classes: SchoolClass[];
  sections: Section[];
  feeTypes: FeeType[];
}

export const CreateDiscountModal: React.FC<CreateDiscountModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  discountToEdit,
  sessions,
  classes,
  sections,
  feeTypes
}) => {
  const { showToast } = useToast();

  const [name, setName] = useState('');
  const [code, setCode] = useState('');
  const [discountType, setDiscountType] = useState<'FIXED' | 'PERCENTAGE'>('PERCENTAGE');
  const [value, setValue] = useState<string>('15');
  const [scope, setScope] = useState<'ALL' | 'STUDENT' | 'CLASS' | 'SECTION' | 'FEE_TYPE'>('ALL');
  const [academicSessionId, setAcademicSessionId] = useState('');
  const [applicableFeeType, setApplicableFeeType] = useState('ALL');
  const [classId, setClassId] = useState('');
  const [sectionId, setSectionId] = useState('');
  const [studentSearch, setStudentSearch] = useState('');
  const [selectedStudentId, setSelectedStudentId] = useState('');
  const [studentsList, setStudentsList] = useState<any[]>([]);
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [description, setDescription] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (isOpen) {
      if (discountToEdit) {
        setName(discountToEdit.name);
        setCode(discountToEdit.code);
        setDiscountType(discountToEdit.discountType);
        setValue(discountToEdit.value.toString());
        setScope(discountToEdit.scope);
        setAcademicSessionId(discountToEdit.academicSessionId);
        setApplicableFeeType(discountToEdit.applicableFeeType || 'ALL');
        setClassId(discountToEdit.classId || '');
        setSectionId(discountToEdit.sectionId || '');
        setSelectedStudentId(discountToEdit.studentId || '');
        setStartDate(discountToEdit.startDate);
        setEndDate(discountToEdit.endDate);
        setDescription(discountToEdit.description || '');
      } else {
        setName('');
        setCode(`DISC-${Math.floor(100 + Math.random() * 900)}`);
        setDiscountType('PERCENTAGE');
        setValue('10');
        setScope('ALL');
        setAcademicSessionId(sessions?.[0]?.id || 'session-2026-2027');
        setApplicableFeeType('ALL');
        setClassId('');
        setSectionId('');
        setSelectedStudentId('');
        setStartDate(new Date().toISOString().slice(0, 10));
        setEndDate('2027-06-30');
        setDescription('');
      }

      // Fetch students for selection if needed
      api.users
        .getStudents({ limit: 100 })
        .then((res: any) => {
          if (res?.data?.students) {
            setStudentsList(res.data.students);
          } else if (Array.isArray(res?.data)) {
            setStudentsList(res.data);
          }
        })
        .catch(() => {});
    }
  }, [isOpen, discountToEdit, sessions]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      showToast('Please provide a discount rule name', 'error');
      return;
    }

    const numVal = parseFloat(value);
    if (isNaN(numVal) || numVal <= 0) {
      showToast('Please enter a valid positive discount amount or percentage', 'error');
      return;
    }

    if (discountType === 'PERCENTAGE' && numVal > 100) {
      showToast('Percentage discount cannot exceed 100%', 'error');
      return;
    }

    if (scope === 'CLASS' && !classId) {
      showToast('Please select the target class', 'error');
      return;
    }

    if (scope === 'STUDENT' && !selectedStudentId) {
      showToast('Please select the target student', 'error');
      return;
    }

    setIsSubmitting(true);
    try {
      if (discountToEdit) {
        const res = await api.fees.updateDiscount(discountToEdit.id, {
          name: name.trim(),
          discountType,
          value: numVal,
          scope,
          applicableFeeType,
          academicSessionId,
          startDate,
          endDate,
          classId: classId || undefined,
          sectionId: sectionId || undefined,
          studentId: selectedStudentId || undefined,
          description: description.trim()
        });
        if (res.success && res.data) {
          showToast(`Discount rule ${res.data.name} updated successfully`, 'success');
          onSuccess(res.data);
          onClose();
        }
      } else {
        const payload: CreateDiscountRulePayload = {
          code: code.trim() || undefined,
          name: name.trim(),
          discountType,
          value: numVal,
          scope,
          applicableFeeType,
          academicSessionId,
          startDate,
          endDate,
          classId: classId || undefined,
          sectionId: sectionId || undefined,
          studentId: selectedStudentId || undefined,
          description: description.trim()
        };
        const res = await api.fees.createDiscount(payload);
        if (res.success && res.data) {
          showToast(`Discount rule ${res.data.name} created successfully`, 'success');
          onSuccess(res.data);
          onClose();
        }
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to save discount rule', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const filteredStudents = studentSearch
    ? studentsList.filter(
        (s) =>
          s.fullName?.toLowerCase().includes(studentSearch.toLowerCase()) ||
          s.admissionNumber?.toLowerCase().includes(studentSearch.toLowerCase())
      )
    : studentsList.slice(0, 8);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="relative w-full max-w-xl bg-slate-900 border border-white/15 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 bg-slate-950/70">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Percent className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">
                {discountToEdit ? 'Edit Discount Rule' : 'Create Configurable Discount'}
              </h3>
              <p className="text-xs text-slate-400">Set criteria, value, and eligibility scope</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
          {/* Rule Name & Code */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Discount Rule Name <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Sibling Concession 15%"
                required
                className="w-full px-3 py-2 text-xs bg-slate-950 border border-white/10 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Code</label>
              <input
                type="text"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="e.g. SIB-15"
                className="w-full px-3 py-2 text-xs font-mono bg-slate-950 border border-white/10 rounded-xl text-emerald-400 placeholder-slate-500 focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          {/* Discount Type & Value */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3 bg-white/5 border border-white/10 rounded-xl">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Calculation Type</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setDiscountType('PERCENTAGE')}
                  className={`px-3 py-2 text-xs font-bold rounded-lg border transition-all flex items-center justify-center gap-1.5 ${
                    discountType === 'PERCENTAGE'
                      ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50 shadow-sm shadow-emerald-500/20'
                      : 'bg-slate-950 text-slate-400 border-white/10 hover:border-white/20'
                  }`}
                >
                  <Percent className="w-3.5 h-3.5" /> Percentage (%)
                </button>
                <button
                  type="button"
                  onClick={() => setDiscountType('FIXED')}
                  className={`px-3 py-2 text-xs font-bold rounded-lg border transition-all flex items-center justify-center gap-1.5 ${
                    discountType === 'FIXED'
                      ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50 shadow-sm shadow-emerald-500/20'
                      : 'bg-slate-950 text-slate-400 border-white/10 hover:border-white/20'
                  }`}
                >
                  <DollarSign className="w-3.5 h-3.5" /> Fixed Amount ($)
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Discount Value <span className="text-rose-400">*</span>
              </label>
              <div className="relative">
                <span className="absolute left-3 top-2.5 text-xs text-slate-400">
                  {discountType === 'PERCENTAGE' ? '%' : '$'}
                </span>
                <input
                  type="number"
                  step="0.01"
                  min="0.01"
                  max={discountType === 'PERCENTAGE' ? '100' : undefined}
                  value={value}
                  onChange={(e) => setValue(e.target.value)}
                  placeholder={discountType === 'PERCENTAGE' ? '15' : '150'}
                  required
                  className="w-full pl-8 pr-3 py-2 text-xs font-mono font-bold bg-slate-950 border border-white/10 rounded-xl text-emerald-300 focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>
          </div>

          {/* Scope & Applicable Fee Type */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Eligibility Scope</label>
              <select
                value={scope}
                onChange={(e: any) => setScope(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-950 border border-white/10 rounded-xl text-white focus:outline-none focus:border-emerald-500"
              >
                <option value="ALL">All Students (School-wide)</option>
                <option value="CLASS">Class / Grade-wide</option>
                <option value="SECTION">Section-wide</option>
                <option value="STUDENT">Specific Individual Student</option>
                <option value="FEE_TYPE">Fee Type Specific</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Applicable Fee Category</label>
              <select
                value={applicableFeeType}
                onChange={(e) => setApplicableFeeType(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-950 border border-white/10 rounded-xl text-white focus:outline-none focus:border-emerald-500"
              >
                <option value="ALL">All Fee Types</option>
                {feeTypes.map((ft) => (
                  <option key={ft.id} value={ft.name}>
                    {ft.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Scope specifics: Class / Section */}
          {(scope === 'CLASS' || scope === 'SECTION') && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3 bg-indigo-500/5 border border-indigo-500/20 rounded-xl">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Target Class</label>
                <select
                  value={classId}
                  onChange={(e) => setClassId(e.target.value)}
                  required
                  className="w-full px-3 py-2 text-xs bg-slate-950 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500"
                >
                  <option value="">Select Class...</option>
                  {classes.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>

              {scope === 'SECTION' && (
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Target Section</label>
                  <select
                    value={sectionId}
                    onChange={(e) => setSectionId(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-slate-950 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500"
                  >
                    <option value="">All Sections in Class</option>
                    {sections
                      .filter((s) => !classId || s.classId === classId)
                      .map((sec) => (
                        <option key={sec.id} value={sec.id}>
                          {sec.name}
                        </option>
                      ))}
                  </select>
                </div>
              )}
            </div>
          )}

          {/* Scope specifics: Specific Student */}
          {scope === 'STUDENT' && (
            <div className="p-3 bg-indigo-500/5 border border-indigo-500/20 rounded-xl space-y-2">
              <label className="block text-xs font-semibold text-slate-300">
                Select Recipient Student <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                value={studentSearch}
                onChange={(e) => setStudentSearch(e.target.value)}
                placeholder="Search student by name or admission no..."
                className="w-full px-3 py-1.5 text-xs bg-slate-950 border border-white/10 rounded-lg text-white placeholder-slate-500 focus:outline-none"
              />
              <div className="max-h-32 overflow-y-auto space-y-1">
                {filteredStudents.map((st) => (
                  <button
                    key={st.id}
                    type="button"
                    onClick={() => {
                      setSelectedStudentId(st.id);
                      setStudentSearch(st.fullName);
                    }}
                    className={`w-full text-left px-3 py-1.5 rounded-lg text-xs flex items-center justify-between transition-colors ${
                      selectedStudentId === st.id
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold'
                        : 'bg-white/5 text-slate-300 hover:bg-white/10'
                    }`}
                  >
                    <span>{st.fullName}</span>
                    <span className="font-mono text-[10px] text-slate-400">
                      {st.admissionNumber || st.className}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Academic Session & Validity Dates */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Academic Session</label>
              <select
                value={academicSessionId}
                onChange={(e) => setAcademicSessionId(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-950 border border-white/10 rounded-xl text-white focus:outline-none focus:border-emerald-500"
              >
                {sessions.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Start Date</label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-950 border border-white/10 rounded-xl text-white focus:outline-none focus:border-emerald-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">End Date</label>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-950 border border-white/10 rounded-xl text-white focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">Description / Policy Notes</label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="e.g. Sibling discount policy as per Governing Board Resolution 2026-B..."
              className="w-full px-3 py-2 text-xs bg-slate-950 border border-white/10 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
            />
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-bold text-slate-400 hover:text-white bg-white/5 hover:bg-white/10 rounded-xl transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 rounded-xl shadow-lg shadow-emerald-600/20 transition-all cursor-pointer flex items-center gap-2"
            >
              {isSubmitting ? (
                <span>Saving Rule...</span>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{discountToEdit ? 'Update Discount' : 'Create Discount Rule'}</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
