import React, { useState } from 'react';
import {
  X,
  AlertTriangle,
  Ban,
  Receipt,
  RotateCcw,
  Loader2,
  DollarSign,
  User,
  FileText
} from 'lucide-react';
import { FeePaymentTransaction, ReverseFeePaymentResponse } from '../../types/index.js';
import { api } from '../../services/api.js';

interface PaymentReversalModalProps {
  isOpen: boolean;
  onClose: () => void;
  transaction: FeePaymentTransaction | null;
  onReversalSuccess: (data: ReverseFeePaymentResponse['data']) => void;
}

export const PaymentReversalModal: React.FC<PaymentReversalModalProps> = ({
  isOpen,
  onClose,
  transaction,
  onReversalSuccess
}) => {
  const [reason, setReason] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  if (!isOpen || !transaction) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!reason.trim() || reason.trim().length < 3) {
      setErrorMessage('Please provide a mandatory reversal reason (at least 3 characters).');
      return;
    }

    setIsSubmitting(true);

    try {
      const response = await api.fees.reversePayment(transaction.id, {
        reason: reason.trim()
      });

      if (response.success && response.data) {
        onReversalSuccess(response.data);
        onClose();
      } else {
        setErrorMessage(response.error || 'Failed to void/reverse payment transaction.');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'An unexpected error occurred while voiding payment.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto"
      onClick={(e) => {
        if (e.target === e.currentTarget && !isSubmitting) onClose();
      }}
    >
      <div className="relative w-full max-w-lg bg-slate-900 border border-rose-500/30 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-rose-500/20 bg-rose-950/40">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400">
              <Ban className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">
                Void / Reverse Fee Payment
              </h3>
              <p className="text-xs text-rose-300/80">
                Receipt #{transaction.receiptNumber} &bull; Txn Ref {transaction.transactionId}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            disabled={isSubmitting}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/10 transition-colors disabled:opacity-50 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Warning Notice */}
        <div className="p-4 bg-rose-500/10 border-b border-rose-500/20 text-xs text-rose-200 flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
          <div>
            <p className="font-bold text-rose-100">Financial History Preservation Notice</p>
            <p className="mt-0.5 text-rose-200/90 leading-relaxed">
              This action will mark the receipt as <strong>VOID / REVERSED</strong> and automatically increase the student&apos;s remaining due invoice balance by <strong>${Number(transaction?.amountPaid ?? 0).toFixed(2)}</strong>. This transaction will not be deleted, preserving audit compliance.
            </p>
          </div>
        </div>

        {/* Transaction Summary Card */}
        <div className="p-6 bg-slate-950/60 border-b border-white/10 space-y-2 text-xs">
          <div className="grid grid-cols-2 gap-3">
            <div className="p-3 bg-slate-900/80 rounded-xl border border-white/5">
              <p className="text-slate-400 text-[10px] uppercase font-semibold">Student Name</p>
              <p className="font-bold text-white mt-0.5">{transaction.studentName}</p>
            </div>
            <div className="p-3 bg-slate-900/80 rounded-xl border border-white/5">
              <p className="text-slate-400 text-[10px] uppercase font-semibold">Invoice Ref</p>
              <p className="font-mono text-indigo-300 mt-0.5">{transaction.invoiceNumber || 'N/A'}</p>
            </div>
            <div className="p-3 bg-slate-900/80 rounded-xl border border-white/5">
              <p className="text-slate-400 text-[10px] uppercase font-semibold">Payment Mode</p>
              <p className="font-medium text-slate-200 mt-0.5">{transaction.paymentMethodLabel || transaction.paymentMethod}</p>
            </div>
            <div className="p-3 bg-rose-500/10 rounded-xl border border-rose-500/20">
              <p className="text-rose-400 text-[10px] uppercase font-semibold">Amount to Void</p>
              <p className="font-mono font-bold text-rose-300 text-sm mt-0.5">
                ${Number(transaction?.amountPaid ?? 0).toFixed(2)}
              </p>
            </div>
          </div>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {errorMessage && (
            <div className="p-3.5 bg-rose-500/10 border border-rose-500/30 rounded-xl text-xs text-rose-300 flex items-start gap-2.5">
              <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-rose-200">Reversal Error</p>
                <p>{errorMessage}</p>
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Mandatory Reason for Reversal <span className="text-rose-400">*</span>
            </label>
            <textarea
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              rows={3}
              placeholder="e.g. Bounced cheque #CHQ-9901, duplicate counter entry recorded in error, or authorized refund request approved by Finance Director..."
              required
              className="w-full px-3 py-2 bg-slate-950 border border-white/15 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-rose-500"
            />
            <p className="text-[11px] text-slate-400 mt-1">
              This explanation will be permanently recorded in the financial audit log.
            </p>
          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="px-4 py-2 text-xs font-semibold text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting || !reason.trim()}
              className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-bold text-white bg-rose-600 hover:bg-rose-500 disabled:opacity-50 rounded-xl shadow-lg shadow-rose-600/20 transition-all cursor-pointer"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Voiding Payment...
                </>
              ) : (
                <>
                  <Ban className="w-4 h-4" />
                  Confirm Void & Recalculate Balance
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
