import React, { useState, useEffect, useMemo } from 'react';
import {
  Coins,
  Plus,
  Search,
  Filter,
  Tag,
  Edit2,
  Trash2,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Shield,
  Layers,
  Sparkles,
  HelpCircle,
  Check,
  X,
  RefreshCw,
  FolderPlus
} from 'lucide-react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '../ui/Card.js';
import { Button } from '../ui/Button.js';
import { Badge } from '../ui/Badge.js';
import { Modal } from '../ui/Modal.js';
import { Input } from '../ui/Input.js';
import { Select } from '../ui/Select.js';
import { LoadingSpinner } from '../ui/LoadingSpinner.js';
import { EmptyState } from '../ui/EmptyState.js';
import { useToast } from '../../context/ToastContext.js';
import { api } from '../../services/api.js';
import {
  FeeType,
  FeeTypeStatus,
  FeeTypeCategory,
  CreateFeeTypePayload,
  UpdateFeeTypePayload
} from '../../types/index.js';

interface FeeTypesManagerProps {
  onTypeCreatedOrUpdated?: () => void;
}

const CATEGORY_COLORS: Record<FeeTypeCategory, string> = {
  ACADEMIC: 'bg-indigo-500/10 text-indigo-400 border-indigo-500/30',
  FACILITY: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
  TRANSPORT: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
  HOSTEL: 'bg-purple-500/10 text-purple-400 border-purple-500/30',
  EXTRACURRICULAR: 'bg-pink-500/10 text-pink-400 border-pink-500/30',
  ADMINISTRATIVE: 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30',
  MISCELLANEOUS: 'bg-slate-500/10 text-slate-400 border-slate-500/30'
};

export const FeeTypesManager: React.FC<FeeTypesManagerProps> = ({ onTypeCreatedOrUpdated }) => {
  const { addToast } = useToast();
  const [feeTypes, setFeeTypes] = useState<FeeType[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [categoryFilter, setCategoryFilter] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');

  // Modal States
  const [isCreateModalOpen, setIsCreateModalOpen] = useState<boolean>(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState<boolean>(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState<boolean>(false);
  const [selectedType, setSelectedType] = useState<FeeType | null>(null);

  // Form State
  const [formData, setFormData] = useState<{
    name: string;
    code: string;
    category: FeeTypeCategory;
    description: string;
    status: FeeTypeStatus;
  }>({
    name: '',
    code: '',
    category: 'ACADEMIC',
    description: '',
    status: 'ACTIVE'
  });
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  const fetchFeeTypes = async () => {
    try {
      setIsLoading(true);
      const res = await api.fees.getFeeTypes();
      if (res.success && res.data) {
        setFeeTypes(res.data);
      } else {
        addToast(res.error || 'Failed to load fee types', 'error');
      }
    } catch (err: any) {
      addToast(err.message || 'Error fetching fee types', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchFeeTypes();
  }, []);

  const filteredTypes = useMemo(() => {
    return feeTypes.filter((t) => {
      if (categoryFilter !== 'ALL' && t.category !== categoryFilter) return false;
      if (statusFilter !== 'ALL' && t.status !== statusFilter) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesName = (t.name || '').toLowerCase().includes(q);
        const matchesCode = (t.code || '').toLowerCase().includes(q);
        const matchesDesc = (t.description || '').toLowerCase().includes(q);
        if (!matchesName && !matchesCode && !matchesDesc) return false;
      }
      return true;
    });
  }, [feeTypes, categoryFilter, statusFilter, searchQuery]);

  const openCreateModal = () => {
    setFormData({
      name: '',
      code: '',
      category: 'ACADEMIC',
      description: '',
      status: 'ACTIVE'
    });
    setFormErrors({});
    setIsCreateModalOpen(true);
  };

  const openEditModal = (type: FeeType) => {
    setSelectedType(type);
    setFormData({
      name: type.name,
      code: type.code,
      category: type.category,
      description: type.description || '',
      status: type.status
    });
    setFormErrors({});
    setIsEditModalOpen(true);
  };

  const openDeleteModal = (type: FeeType) => {
    setSelectedType(type);
    setIsDeleteModalOpen(true);
  };

  const handleNameChange = (val: string) => {
    const autoCode = val
      .toUpperCase()
      .trim()
      .replace(/[^A-Z0-9]/g, '_')
      .replace(/_+/g, '_')
      .substring(0, 16);

    setFormData((prev) => ({
      ...prev,
      name: val,
      code: !selectedType || !selectedType.isDefault ? (prev.code === '' || prev.code === autoCode.slice(0, -1) ? autoCode : prev.code) : prev.code
    }));
  };

  const validateForm = (): boolean => {
    const errors: Record<string, string> = {};
    if (!formData.name.trim() || formData.name.trim().length < 2) {
      errors.name = 'Fee type name must be at least 2 characters.';
    }
    if (!formData.code.trim() || formData.code.trim().length < 2) {
      errors.code = 'Fee type code must be at least 2 characters (e.g., ADM_FEE).';
    }
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleCreateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    try {
      setIsSubmitting(true);
      const payload: CreateFeeTypePayload = {
        name: formData.name.trim(),
        code: formData.code.trim().toUpperCase(),
        category: formData.category,
        description: formData.description.trim(),
        status: formData.status
      };

      const res = await api.fees.createFeeType(payload);
      if (res.success && res.data) {
        addToast(`Fee type '${res.data.name}' created successfully.`, 'success');
        setIsCreateModalOpen(false);
        await fetchFeeTypes();
        if (onTypeCreatedOrUpdated) onTypeCreatedOrUpdated();
      } else {
        addToast(res.error || 'Failed to create fee type', 'error');
      }
    } catch (err: any) {
      addToast(err.message || 'Error creating fee type', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleEditSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedType || !validateForm()) return;

    try {
      setIsSubmitting(true);
      const payload: UpdateFeeTypePayload = {
        name: formData.name.trim(),
        code: selectedType.isDefault ? undefined : formData.code.trim().toUpperCase(),
        category: formData.category,
        description: formData.description.trim(),
        status: formData.status
      };

      const res = await api.fees.updateFeeType(selectedType.id, payload);
      if (res.success && res.data) {
        addToast(`Fee type '${res.data.name}' updated successfully.`, 'success');
        setIsEditModalOpen(false);
        await fetchFeeTypes();
        if (onTypeCreatedOrUpdated) onTypeCreatedOrUpdated();
      } else {
        addToast(res.error || 'Failed to update fee type', 'error');
      }
    } catch (err: any) {
      addToast(err.message || 'Error updating fee type', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleToggleStatus = async (type: FeeType) => {
    const newStatus: FeeTypeStatus = type.status === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE';
    try {
      const res = await api.fees.updateFeeTypeStatus(type.id, newStatus);
      if (res.success && res.data) {
        addToast(`Fee type '${type.name}' status set to ${newStatus}.`, 'success');
        await fetchFeeTypes();
        if (onTypeCreatedOrUpdated) onTypeCreatedOrUpdated();
      } else {
        addToast(res.error || 'Failed to toggle status', 'error');
      }
    } catch (err: any) {
      addToast(err.message || 'Error updating status', 'error');
    }
  };

  const handleDeleteConfirm = async () => {
    if (!selectedType) return;
    try {
      setIsSubmitting(true);
      const res = await api.fees.deleteFeeType(selectedType.id);
      if (res.success) {
        addToast(`Fee type '${selectedType.name}' deleted.`, 'success');
        setIsDeleteModalOpen(false);
        await fetchFeeTypes();
        if (onTypeCreatedOrUpdated) onTypeCreatedOrUpdated();
      } else {
        addToast(res.error || 'Failed to delete fee type', 'error');
      }
    } catch (err: any) {
      addToast(err.message || 'Error deleting fee type', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div id="fee-types-manager-container" className="space-y-6">
      {/* Top Controls Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900/60 p-4 rounded-2xl border border-white/10 backdrop-blur-md">
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative min-w-[240px]">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              id="fee-types-search-input"
              type="text"
              placeholder="Search fee types by name, code..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-slate-950/70 border border-white/10 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <div className="w-44">
            <Select
              id="fee-types-category-filter"
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              options={[
                { value: 'ALL', label: 'All Categories' },
                { value: 'ACADEMIC', label: 'Academic' },
                { value: 'FACILITY', label: 'Facility' },
                { value: 'TRANSPORT', label: 'Transport' },
                { value: 'HOSTEL', label: 'Hostel' },
                { value: 'EXTRACURRICULAR', label: 'Extracurricular' },
                { value: 'ADMINISTRATIVE', label: 'Administrative' },
                { value: 'MISCELLANEOUS', label: 'Miscellaneous' }
              ]}
            />
          </div>

          <div className="w-36">
            <Select
              id="fee-types-status-filter"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              options={[
                { value: 'ALL', label: 'All Status' },
                { value: 'ACTIVE', label: 'Active Only' },
                { value: 'INACTIVE', label: 'Inactive Only' }
              ]}
            />
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Button
            id="refresh-fee-types-btn"
            variant="ghost"
            size="sm"
            onClick={fetchFeeTypes}
            className="text-slate-400 hover:text-white"
          >
            <RefreshCw className="w-4 h-4" />
          </Button>
          <Button
            id="create-custom-fee-type-btn"
            variant="primary"
            size="sm"
            onClick={openCreateModal}
            className="flex items-center gap-2 shadow-lg shadow-indigo-500/20"
          >
            <Plus className="w-4 h-4" />
            <span>Create Custom Fee Type</span>
          </Button>
        </div>
      </div>

      {/* Grid of Fee Types */}
      {isLoading ? (
        <div className="py-20 flex justify-center">
          <LoadingSpinner size="lg" message="Loading configurable fee types..." />
        </div>
      ) : filteredTypes.length === 0 ? (
        <EmptyState
          icon={Coins}
          title="No Fee Types Found"
          description="No fee types match your current search filters or category selection."
          actionLabel="Create Custom Fee Type"
          onAction={openCreateModal}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {filteredTypes.map((type) => {
            const categoryClass = CATEGORY_COLORS[type.category] || CATEGORY_COLORS.MISCELLANEOUS;
            return (
              <div
                key={type.id}
                id={`fee-type-card-${type.id}`}
                className={`p-5 rounded-2xl border transition-all flex flex-col justify-between ${
                  type.status === 'ACTIVE'
                    ? 'bg-slate-900/70 border-white/10 hover:border-indigo-500/40 hover:bg-slate-800/60 shadow-lg shadow-black/20'
                    : 'bg-slate-950/40 border-white/5 opacity-70'
                }`}
              >
                <div>
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="font-semibold text-white text-base">{type.name}</h4>
                        {type.isDefault ? (
                          <span className="inline-flex items-center gap-1 text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                            <Shield className="w-2.5 h-2.5" /> System Default
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                            <Sparkles className="w-2.5 h-2.5" /> Custom
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-2 mt-1">
                        <code className="text-xs font-mono font-bold text-slate-300 bg-black/40 px-2 py-0.5 rounded border border-white/10">
                          {type.code}
                        </code>
                        <span className={`text-[11px] font-medium px-2 py-0.5 rounded-full border ${categoryClass}`}>
                          {type.category}
                        </span>
                      </div>
                    </div>

                    <Badge
                      variant={type.status === 'ACTIVE' ? 'success' : 'secondary'}
                      className="text-xs font-semibold"
                    >
                      {type.status}
                    </Badge>
                  </div>

                  <p className="text-xs text-slate-400 line-clamp-3 leading-relaxed mb-4">
                    {type.description || 'No specific description provided for this fee category.'}
                  </p>
                </div>

                <div className="pt-3 border-t border-white/10 flex items-center justify-between gap-2 text-xs">
                  <span className="text-slate-500">
                    ID: <span className="font-mono text-slate-400">{type.id}</span>
                  </span>

                  <div className="flex items-center gap-1">
                    <Button
                      id={`edit-fee-type-${type.id}`}
                      variant="ghost"
                      size="sm"
                      onClick={() => openEditModal(type)}
                      className="h-8 px-2 text-slate-300 hover:text-white"
                      title="Edit fee type"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </Button>

                    <Button
                      id={`toggle-fee-type-${type.id}`}
                      variant="ghost"
                      size="sm"
                      onClick={() => handleToggleStatus(type)}
                      className={`h-8 px-2 ${
                        type.status === 'ACTIVE'
                          ? 'text-amber-400 hover:text-amber-300'
                          : 'text-emerald-400 hover:text-emerald-300'
                      }`}
                      title={type.status === 'ACTIVE' ? 'Deactivate fee type' : 'Activate fee type'}
                    >
                      {type.status === 'ACTIVE' ? (
                        <XCircle className="w-3.5 h-3.5" />
                      ) : (
                        <CheckCircle2 className="w-3.5 h-3.5" />
                      )}
                    </Button>

                    {!type.isDefault && (
                      <Button
                        id={`delete-fee-type-${type.id}`}
                        variant="ghost"
                        size="sm"
                        onClick={() => openDeleteModal(type)}
                        className="h-8 px-2 text-rose-400 hover:text-rose-300 hover:bg-rose-500/10"
                        title="Delete custom fee type"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Create Fee Type Modal */}
      <Modal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        title={
          <div className="flex items-center gap-2 text-white">
            <Coins className="w-5 h-5 text-indigo-400" />
            <span>Create Custom Fee Type</span>
          </div>
        }
        description="Configure a new school fee type for tuition, facilities, transport, or custom items."
        size="lg"
        id="create-fee-type-modal"
      >
        <form onSubmit={handleCreateSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              Fee Type Name <span className="text-rose-400">*</span>
            </label>
            <Input
              id="fee-type-name-input"
              value={formData.name}
              onChange={(e) => handleNameChange(e.target.value)}
              placeholder="e.g., Robotics & STEM Lab Fee"
              error={formErrors.name}
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Fee Type Code <span className="text-rose-400">*</span>
              </label>
              <Input
                id="fee-type-code-input"
                value={formData.code}
                onChange={(e) =>
                  setFormData((prev) => ({
                    ...prev,
                    code: e.target.value.toUpperCase().replace(/[^A-Z0-9_]/g, '_')
                  }))
                }
                placeholder="e.g., ROBOTICS_FEE"
                error={formErrors.code}
              />
              <p className="text-[11px] text-slate-500 mt-1">
                Unique identifier used for invoicing & accounting records.
              </p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Category <span className="text-rose-400">*</span>
              </label>
              <Select
                id="fee-type-category-select"
                value={formData.category}
                onChange={(e) =>
                  setFormData((prev) => ({ ...prev, category: e.target.value as FeeTypeCategory }))
                }
                options={[
                  { value: 'ACADEMIC', label: 'Academic (Tuition, Lab, Exam)' },
                  { value: 'FACILITY', label: 'Facility (Library, Smart Class)' },
                  { value: 'TRANSPORT', label: 'Transport (Bus, Transit)' },
                  { value: 'HOSTEL', label: 'Hostel & Boarding' },
                  { value: 'EXTRACURRICULAR', label: 'Extracurricular & Sports' },
                  { value: 'ADMINISTRATIVE', label: 'Administrative & Admission' },
                  { value: 'MISCELLANEOUS', label: 'Miscellaneous / Other' }
                ]}
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              Description & Purpose
            </label>
            <textarea
              id="fee-type-description-textarea"
              rows={3}
              value={formData.description}
              onChange={(e) => setFormData((prev) => ({ ...prev, description: e.target.value }))}
              placeholder="Explain the coverage, materials, or student services provided by this fee type..."
              className="w-full px-3.5 py-2.5 bg-slate-950/70 border border-white/15 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all resize-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              Initial Status
            </label>
            <div className="flex gap-4">
              <label className="flex items-center gap-2 text-sm text-slate-300 cursor-pointer">
                <input
                  type="radio"
                  name="fee-type-status"
                  checked={formData.status === 'ACTIVE'}
                  onChange={() => setFormData((prev) => ({ ...prev, status: 'ACTIVE' }))}
                  className="accent-indigo-500 w-4 h-4"
                />
                <span>Active (Available for Fee Structures)</span>
              </label>
              <label className="flex items-center gap-2 text-sm text-slate-300 cursor-pointer">
                <input
                  type="radio"
                  name="fee-type-status"
                  checked={formData.status === 'INACTIVE'}
                  onChange={() => setFormData((prev) => ({ ...prev, status: 'INACTIVE' }))}
                  className="accent-indigo-500 w-4 h-4"
                />
                <span>Inactive (Hidden from Structure Builder)</span>
              </label>
            </div>
          </div>

          <div className="pt-4 border-t border-white/10 flex items-center justify-end gap-3">
            <Button
              type="button"
              variant="secondary"
              onClick={() => setIsCreateModalOpen(false)}
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button
              id="submit-create-fee-type-btn"
              type="submit"
              variant="primary"
              disabled={isSubmitting}
              className="flex items-center gap-2"
            >
              {isSubmitting ? (
                <LoadingSpinner size="sm" />
              ) : (
                <>
                  <Check className="w-4 h-4" />
                  <span>Create Fee Type</span>
                </>
              )}
            </Button>
          </div>
        </form>
      </Modal>

      {/* Edit Fee Type Modal */}
      <Modal
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        title={
          <div className="flex items-center gap-2 text-white">
            <Edit2 className="w-5 h-5 text-indigo-400" />
            <span>Edit Fee Type: {selectedType?.name}</span>
          </div>
        }
        description="Update fee type metadata, category classification, and operational status."
        size="lg"
        id="edit-fee-type-modal"
      >
        <form onSubmit={handleEditSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              Fee Type Name <span className="text-rose-400">*</span>
            </label>
            <Input
              id="edit-fee-type-name-input"
              value={formData.name}
              onChange={(e) => setFormData((prev) => ({ ...prev, name: e.target.value }))}
              error={formErrors.name}
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Fee Type Code {selectedType?.isDefault && '(Locked for System Types)'}
              </label>
              <Input
                id="edit-fee-type-code-input"
                value={formData.code}
                disabled={selectedType?.isDefault}
                onChange={(e) =>
                  setFormData((prev) => ({
                    ...prev,
                    code: e.target.value.toUpperCase().replace(/[^A-Z0-9_]/g, '_')
                  }))
                }
                error={formErrors.code}
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Category <span className="text-rose-400">*</span>
              </label>
              <Select
                id="edit-fee-type-category-select"
                value={formData.category}
                onChange={(e) =>
                  setFormData((prev) => ({ ...prev, category: e.target.value as FeeTypeCategory }))
                }
                options={[
                  { value: 'ACADEMIC', label: 'Academic (Tuition, Lab, Exam)' },
                  { value: 'FACILITY', label: 'Facility (Library, Smart Class)' },
                  { value: 'TRANSPORT', label: 'Transport (Bus, Transit)' },
                  { value: 'HOSTEL', label: 'Hostel & Boarding' },
                  { value: 'EXTRACURRICULAR', label: 'Extracurricular & Sports' },
                  { value: 'ADMINISTRATIVE', label: 'Administrative & Admission' },
                  { value: 'MISCELLANEOUS', label: 'Miscellaneous / Other' }
                ]}
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              Description & Purpose
            </label>
            <textarea
              id="edit-fee-type-description-textarea"
              rows={3}
              value={formData.description}
              onChange={(e) => setFormData((prev) => ({ ...prev, description: e.target.value }))}
              className="w-full px-3.5 py-2.5 bg-slate-950/70 border border-white/15 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all resize-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              Status
            </label>
            <div className="flex gap-4">
              <label className="flex items-center gap-2 text-sm text-slate-300 cursor-pointer">
                <input
                  type="radio"
                  name="edit-fee-type-status"
                  checked={formData.status === 'ACTIVE'}
                  onChange={() => setFormData((prev) => ({ ...prev, status: 'ACTIVE' }))}
                  className="accent-indigo-500 w-4 h-4"
                />
                <span>Active</span>
              </label>
              <label className="flex items-center gap-2 text-sm text-slate-300 cursor-pointer">
                <input
                  type="radio"
                  name="edit-fee-type-status"
                  checked={formData.status === 'INACTIVE'}
                  onChange={() => setFormData((prev) => ({ ...prev, status: 'INACTIVE' }))}
                  className="accent-indigo-500 w-4 h-4"
                />
                <span>Inactive</span>
              </label>
            </div>
          </div>

          <div className="pt-4 border-t border-white/10 flex items-center justify-end gap-3">
            <Button
              type="button"
              variant="secondary"
              onClick={() => setIsEditModalOpen(false)}
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button
              id="submit-edit-fee-type-btn"
              type="submit"
              variant="primary"
              disabled={isSubmitting}
              className="flex items-center gap-2"
            >
              {isSubmitting ? (
                <LoadingSpinner size="sm" />
              ) : (
                <>
                  <Check className="w-4 h-4" />
                  <span>Save Changes</span>
                </>
              )}
            </Button>
          </div>
        </form>
      </Modal>

      {/* Delete Fee Type Modal */}
      <Modal
        isOpen={isDeleteModalOpen}
        onClose={() => setIsDeleteModalOpen(false)}
        title={
          <div className="flex items-center gap-2 text-rose-400">
            <AlertCircle className="w-5 h-5" />
            <span>Delete Fee Type</span>
          </div>
        }
        description="Are you sure you want to permanently delete this custom fee type?"
        size="md"
        id="delete-fee-type-modal"
      >
        <div className="space-y-4">
          <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/20 text-xs text-rose-300 leading-relaxed">
            Deleting fee type <strong className="text-white font-semibold">'{selectedType?.name}'</strong> ({selectedType?.code}) will remove it from the system. If fee structures are currently using it, deletion will be blocked to safeguard financial integrity.
          </div>

          <div className="pt-4 border-t border-white/10 flex items-center justify-end gap-3">
            <Button
              type="button"
              variant="secondary"
              onClick={() => setIsDeleteModalOpen(false)}
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button
              id="confirm-delete-fee-type-btn"
              type="button"
              variant="danger"
              onClick={handleDeleteConfirm}
              disabled={isSubmitting}
              className="flex items-center gap-2"
            >
              {isSubmitting ? (
                <LoadingSpinner size="sm" />
              ) : (
                <>
                  <Trash2 className="w-4 h-4" />
                  <span>Delete Fee Type</span>
                </>
              )}
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
