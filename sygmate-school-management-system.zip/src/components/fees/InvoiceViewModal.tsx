import React, { useRef, useState, useEffect, useMemo } from 'react';
import {
  X,
  Printer,
  FileText,
  Calendar,
  User,
  Building,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Ban,
  DollarSign,
  ArrowDownRight,
  ShieldCheck,
  Receipt,
  Download
} from 'lucide-react';
import { InvoiceDetailResponse, FeePaymentStatus, StudentFeeRecord } from '../../types/index.js';
import { api } from '../../services/api.js';
import { downloadElementPdf, triggerSafePrint } from '../../utils/printPdf.js';

interface InvoiceViewModalProps {
  isOpen: boolean;
  onClose: () => void;
  invoiceData?: InvoiceDetailResponse | StudentFeeRecord | null;
  invoiceNumber?: string | null;
  feeRecordId?: string | null;
  isLoading?: boolean;
  onCollectPayment?: (fee: StudentFeeRecord) => void;
  onPayFee?: (fee: StudentFeeRecord) => void;
  onViewReceipt?: (receiptNumberOrTxnId: string) => void;
}

export const InvoiceViewModal: React.FC<InvoiceViewModalProps> = ({
  isOpen,
  onClose,
  invoiceData: initialInvoiceData,
  invoiceNumber,
  feeRecordId,
  isLoading: initialLoading = false,
  onCollectPayment,
  onPayFee,
  onViewReceipt
}) => {
  const printableRef = useRef<HTMLDivElement>(null);
  const [fetchedData, setFetchedData] = useState<InvoiceDetailResponse | null>(null);
  const [loading, setLoading] = useState<boolean>(false);

  useEffect(() => {
    if (isOpen && !initialInvoiceData) {
      if (invoiceNumber) {
        setLoading(true);
        api.fees
          .getInvoiceByNumber(invoiceNumber)
          .then((res) => {
            if (res.success && res.data) {
              setFetchedData(res.data);
            }
          })
          .catch((err) => {
            console.error('Failed to load invoice by number', err);
          })
          .finally(() => {
            setLoading(false);
          });
      } else if (feeRecordId) {
        setLoading(true);
        api.fees
          .getStudentFeeById(feeRecordId)
          .then((res) => {
            if (res.success && res.data) {
              setFetchedData(res.data);
            }
          })
          .catch((err) => {
            console.error('Failed to load invoice by fee record ID', err);
          })
          .finally(() => {
            setLoading(false);
          });
      }
    } else if (!isOpen) {
      setFetchedData(null);
    }
  }, [isOpen, invoiceNumber, feeRecordId, initialInvoiceData]);

  const invoiceData: InvoiceDetailResponse | null = useMemo(() => {
    const raw = initialInvoiceData || fetchedData;
    if (!raw) return null;

    // Check if standard InvoiceDetailResponse
    if (typeof raw === 'object' && 'fee' in raw && (raw as any).fee) {
      const resp = raw as InvoiceDetailResponse;
      return {
        fee: resp.fee,
        student: resp.student || {
          id: resp.fee.studentId || '',
          name: resp.fee.studentName || 'Student',
          admissionNumber: resp.fee.admissionNumber || 'N/A',
          rollNumber: '01',
          className: resp.fee.className || 'N/A',
          sectionName: resp.fee.sectionName || 'N/A',
          academicSessionName: resp.fee.academicSessionName || '2026-2027 Academic Year'
        },
        schoolInfo: resp.schoolInfo || {
          schoolName: 'Sygmate International Academy',
          schoolCode: 'SIA-HQ-01',
          affiliationNumber: 'CBSE-INTL-2026-9901',
          address: '450 Innovation Parkway, Silicon Valley, CA',
          contactEmail: 'bursar@sygmateschools.edu',
          contactPhone: '+1 (555) 890-4321',
          currency: 'USD',
          currencySymbol: '$'
        },
        transactions: resp.transactions || [],
        breakdown: resp.breakdown || {
          originalAmount: resp.fee.totalAmount || 0,
          discountAmount: resp.fee.discountAmount || 0,
          scholarshipAmount: resp.fee.scholarshipAmount || 0,
          waiverAmount: resp.fee.waiverAmount || 0,
          fineAmount: resp.fee.fineAmount || 0,
          netPayableAmount: resp.fee.netPayableAmount || resp.fee.totalAmount || 0,
          totalPaid: resp.fee.paidAmount || 0,
          remainingDue: resp.fee.dueAmount || 0,
          isOverdue: resp.fee.status === 'OVERDUE',
          daysOverdue: 0
        }
      };
    }

    // Check if raw StudentFeeRecord was passed directly
    if (typeof raw === 'object' && ('invoiceNumber' in raw || 'studentId' in raw || 'totalAmount' in raw)) {
      const feeRec = raw as any;
      return {
        fee: feeRec,
        student: {
          id: feeRec.studentId || '',
          name: feeRec.studentName || 'Student',
          admissionNumber: feeRec.admissionNumber || 'N/A',
          rollNumber: feeRec.rollNumber || '01',
          className: feeRec.className || 'N/A',
          sectionName: feeRec.sectionName || 'N/A',
          academicSessionName: feeRec.academicSessionName || '2026-2027 Academic Year'
        },
        schoolInfo: {
          schoolName: 'Sygmate International Academy',
          schoolCode: 'SIA-HQ-01',
          affiliationNumber: 'CBSE-INTL-2026-9901',
          address: '450 Innovation Parkway, Silicon Valley, CA',
          contactEmail: 'bursar@sygmateschools.edu',
          contactPhone: '+1 (555) 890-4321',
          currency: 'USD',
          currencySymbol: '$'
        },
        transactions: [],
        breakdown: {
          originalAmount: feeRec.totalAmount || 0,
          discountAmount: feeRec.discountAmount || 0,
          scholarshipAmount: feeRec.scholarshipAmount || 0,
          waiverAmount: feeRec.waiverAmount || 0,
          fineAmount: feeRec.fineAmount || 0,
          netPayableAmount: feeRec.netPayableAmount || feeRec.totalAmount || 0,
          totalPaid: feeRec.paidAmount || 0,
          remainingDue: feeRec.dueAmount || 0,
          isOverdue: feeRec.status === 'OVERDUE',
          daysOverdue: 0
        }
      };
    }

    return null;
  }, [initialInvoiceData, fetchedData]);

  const [isExporting, setIsExporting] = useState(false);

  if (!isOpen) return null;

  const isLoading = initialLoading || loading;

  const handlePrint = async () => {
    if (!printableRef.current) {
      window.print();
      return;
    }

    try {
      setIsExporting(true);
      const invoiceNumber = invoiceData?.fee?.invoiceNumber || (invoiceData as any)?.invoiceNumber || 'INV';
      const cleanInv = String(invoiceNumber).replace(/[^a-zA-Z0-9_-]/g, '_');
      const filename = `Invoice_${cleanInv}_${new Date().toISOString().split('T')[0]}.pdf`;

      await downloadElementPdf(printableRef.current, filename, {
        orientation: 'portrait'
      });

      await triggerSafePrint({
        elementOrId: printableRef.current,
        fallbackTitle: `Invoice_${cleanInv}`
      });
    } catch (err) {
      console.error('Invoice print/PDF error:', err);
      try {
        window.print();
      } catch {
        // ignore
      }
    } finally {
      setIsExporting(false);
    }
  };

  const getStatusBadge = (status?: FeePaymentStatus) => {
    switch (status) {
      case 'PAID':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
            <CheckCircle2 className="w-3.5 h-3.5" />
            PAID IN FULL
          </span>
        );
      case 'PARTIAL':
      case 'PARTIALLY_PAID':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-500/15 text-amber-400 border border-amber-500/30">
            <Clock className="w-3.5 h-3.5" />
            PARTIALLY PAID
          </span>
        );
      case 'OVERDUE':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-rose-500/15 text-rose-400 border border-rose-500/30">
            <AlertTriangle className="w-3.5 h-3.5" />
            OVERDUE
          </span>
        );
      case 'DRAFT':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-slate-500/15 text-slate-400 border border-slate-500/30">
            <Clock className="w-3.5 h-3.5" />
            DRAFT
          </span>
        );
      case 'CANCELLED':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-gray-500/15 text-gray-400 border border-gray-500/30 line-through">
            <Ban className="w-3.5 h-3.5" />
            CANCELLED
          </span>
        );
      case 'DUE':
      case 'UNPAID':
      default:
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-indigo-500/15 text-indigo-400 border border-indigo-500/30">
            <AlertTriangle className="w-3.5 h-3.5" />
            UNPAID
          </span>
        );
    }
  };

  const displayInvoiceNumber = invoiceData?.fee?.invoiceNumber || invoiceNumber || 'N/A';
  const feeDueAmount = Number(invoiceData?.fee?.dueAmount ?? invoiceData?.breakdown?.remainingDue ?? 0);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="relative w-full max-w-3xl bg-slate-900 border border-white/15 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Modal Top Bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 bg-slate-950/70">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-indigo-500/15 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
              <Receipt className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                Fee Invoice Details
                {displayInvoiceNumber !== 'N/A' && (
                  <span className="text-xs font-mono font-medium text-slate-400 px-2 py-0.5 rounded bg-white/5 border border-white/10">
                    {displayInvoiceNumber}
                  </span>
                )}
              </h3>
              <p className="text-xs text-slate-400">Official student fee invoice statement</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {invoiceData?.fee && feeDueAmount > 0 && onCollectPayment && (
              <button
                onClick={() => onCollectPayment(invoiceData.fee)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg shadow-sm shadow-emerald-600/20 transition-colors cursor-pointer"
              >
                <DollarSign className="w-3.5 h-3.5" />
                Collect Payment (${feeDueAmount.toFixed(2)})
              </button>
            )}
            {invoiceData?.fee && feeDueAmount > 0 && onPayFee && (
              <button
                onClick={() => onPayFee(invoiceData.fee)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg shadow-sm shadow-indigo-600/20 transition-colors cursor-pointer"
              >
                <DollarSign className="w-3.5 h-3.5" />
                Pay Online (${feeDueAmount.toFixed(2)})
              </button>
            )}
            <button
              onClick={handlePrint}
              disabled={!invoiceData || isLoading || isExporting}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-200 bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg transition-colors cursor-pointer disabled:opacity-50"
            >
              <Printer className="w-3.5 h-3.5 text-indigo-400" />
              {isExporting ? 'Generating PDF...' : 'Print / Save PDF'}
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white hover:bg-white/10 rounded-lg transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Content */}
        <div className="p-6 overflow-y-auto max-h-[calc(85vh-120px)] space-y-6" ref={printableRef}>
          {isLoading || !invoiceData || !invoiceData.fee ? (
            <div className="py-16 text-center text-slate-400">
              {isLoading ? (
                <>
                  <div className="w-8 h-8 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
                  <p className="text-xs">Loading invoice statement...</p>
                </>
              ) : (
                <>
                  <FileText className="w-8 h-8 text-slate-500 mx-auto mb-2 opacity-50" />
                  <p className="text-xs">Invoice record details are not available or could not be loaded.</p>
                </>
              )}
            </div>
          ) : (
            <>
              {/* Printable Invoice Container */}
              <div className="bg-slate-950/60 border border-white/10 rounded-xl p-6 space-y-6">
                {/* School Header */}
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center pb-6 border-b border-white/10 gap-4">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <Building className="w-5 h-5 text-indigo-400" />
                      <h4 className="text-lg font-bold text-white tracking-wide">
                        {invoiceData.schoolInfo?.schoolName || 'Sygmate International Academy'}
                      </h4>
                    </div>
                    <p className="text-xs text-slate-400 max-w-md">
                      {invoiceData.schoolInfo?.address || 'Silicon Valley Campus'}
                    </p>
                    <div className="flex flex-wrap gap-x-4 gap-y-1 mt-1 text-[11px] text-slate-400">
                      <span>Tel: {invoiceData.schoolInfo?.contactPhone || '+1 (555) 890-4321'}</span>
                      <span>Email: {invoiceData.schoolInfo?.contactEmail || 'finance@sygmate-academy.edu'}</span>
                      {invoiceData.schoolInfo?.affiliationNumber && (
                        <span>Affiliation: {invoiceData.schoolInfo.affiliationNumber}</span>
                      )}
                    </div>
                  </div>
                  <div className="text-right sm:self-start">
                    <div className="mb-2">{getStatusBadge(invoiceData.fee?.status)}</div>
                    <p className="text-xs font-semibold text-slate-300">
                      Issued:{' '}
                      <span className="font-normal text-slate-400">
                        {invoiceData.fee?.createdAt ? new Date(invoiceData.fee.createdAt).toLocaleDateString() : 'N/A'}
                      </span>
                    </p>
                    <p className="text-xs font-semibold text-slate-300">
                      Due Date:{' '}
                      <span
                        className={`font-normal ${
                          invoiceData.breakdown?.isOverdue ? 'text-rose-400 font-bold' : 'text-slate-400'
                        }`}
                      >
                        {invoiceData.fee?.dueDate || 'N/A'}
                      </span>
                    </p>
                  </div>
                </div>

                {/* Student & Invoice Meta Dossier */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-white/[0.02] border border-white/5 rounded-xl p-4">
                  {/* Student Details */}
                  <div className="space-y-1.5">
                    <p className="text-[11px] font-bold uppercase tracking-wider text-indigo-400 flex items-center gap-1.5">
                      <User className="w-3.5 h-3.5" /> Billed Student
                    </p>
                    <p className="text-sm font-bold text-white">{invoiceData.student?.name || invoiceData.fee?.studentName}</p>
                    <div className="grid grid-cols-2 gap-x-2 gap-y-1 text-xs text-slate-300">
                      <p>
                        <span className="text-slate-400">Admission No:</span>{' '}
                        <span className="font-mono text-slate-200">{invoiceData.student?.admissionNumber || invoiceData.fee?.admissionNumber || 'N/A'}</span>
                      </p>
                      <p>
                        <span className="text-slate-400">Roll No:</span>{' '}
                        <span className="font-mono text-slate-200">{invoiceData.student?.rollNumber || '01'}</span>
                      </p>
                      <p>
                        <span className="text-slate-400">Class:</span>{' '}
                        <span className="text-slate-200">{invoiceData.student?.className || invoiceData.fee?.className || 'N/A'}</span>
                      </p>
                      <p>
                        <span className="text-slate-400">Section:</span>{' '}
                        <span className="text-slate-200">{invoiceData.student?.sectionName || invoiceData.fee?.sectionName || 'General'}</span>
                      </p>
                    </div>
                  </div>

                  {/* Academic Session & Guardian */}
                  <div className="space-y-1.5">
                    <p className="text-[11px] font-bold uppercase tracking-wider text-indigo-400 flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5" /> Session & Guardian Details
                    </p>
                    <p className="text-xs text-slate-300">
                      <span className="text-slate-400">Academic Session:</span>{' '}
                      <span className="font-semibold text-slate-200">
                        {invoiceData.student?.academicSessionName || invoiceData.fee?.academicSessionName || 'Current Session'}
                      </span>
                    </p>
                    {invoiceData.student?.guardianName ? (
                      <div className="text-xs text-slate-300 space-y-0.5">
                        <p>
                          <span className="text-slate-400">Guardian:</span>{' '}
                          <span className="text-slate-200">{invoiceData.student.guardianName}</span>
                          {invoiceData.student.guardianRelation && (
                            <span className="text-[11px] text-slate-400 ml-1">
                              ({invoiceData.student.guardianRelation})
                            </span>
                          )}
                        </p>
                        {invoiceData.student.guardianPhone && (
                          <p>
                            <span className="text-slate-400">Phone:</span>{' '}
                            <span className="text-slate-200">{invoiceData.student.guardianPhone}</span>
                          </p>
                        )}
                      </div>
                    ) : (
                      <p className="text-xs text-slate-400 italic">No primary guardian linked</p>
                    )}
                  </div>
                </div>

                {/* Overdue Warning Alert */}
                {invoiceData.breakdown?.isOverdue && (
                  <div className="flex items-center gap-3 p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-xs text-rose-300">
                    <AlertTriangle className="w-5 h-5 text-rose-400 flex-shrink-0" />
                    <div>
                      <p className="font-bold text-rose-200">
                        Invoice is Overdue by {invoiceData.breakdown.daysOverdue || 0} day(s)
                      </p>
                      <p className="text-[11px] text-rose-300/80">
                        Payment was due on {invoiceData.fee?.dueDate}. Please settle the remaining balance promptly.
                      </p>
                    </div>
                  </div>
                )}

                {/* Fee Items Table */}
                <div>
                  <h5 className="text-xs font-bold uppercase tracking-wider text-slate-300 mb-2.5 flex items-center gap-1.5">
                    <FileText className="w-3.5 h-3.5 text-indigo-400" /> Fee Breakdown
                  </h5>
                  <div className="border border-white/10 rounded-xl overflow-hidden bg-slate-900/50">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-white/5 border-b border-white/10 text-slate-300 font-semibold">
                        <tr>
                          <th className="px-4 py-3">Description</th>
                          <th className="px-3 py-3">Fee Type</th>
                          <th className="px-3 py-3">Frequency</th>
                          <th className="px-4 py-3 text-right">Amount</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/5 text-slate-300">
                        <tr>
                          <td className="px-4 py-3 font-medium text-white">
                            <div>
                              <span>{invoiceData.fee?.title || 'Academic Tuition'}</span>
                              {invoiceData.fee?.description && (
                                <p className="text-[11px] text-slate-400 font-normal mt-0.5">
                                  {invoiceData.fee.description}
                                </p>
                              )}
                            </div>
                          </td>
                          <td className="px-3 py-3">
                            <span className="px-2 py-0.5 rounded text-[10px] font-medium bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
                              {invoiceData.fee?.feeType || 'Tuition'}
                            </span>
                          </td>
                          <td className="px-3 py-3 text-slate-400">
                            {invoiceData.fee?.frequency || 'ONE_TIME'}
                          </td>
                          <td className="px-4 py-3 text-right font-mono font-medium text-white">
                            ${Number(invoiceData.fee?.totalAmount ?? 0).toFixed(2)}
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Financial Summary Calculation Card */}
                <div className="bg-slate-900/80 border border-white/10 rounded-xl p-4 space-y-2.5">
                  <div className="flex justify-between text-xs text-slate-300">
                    <span>Original Base Amount:</span>
                    <span className="font-mono text-slate-200">
                      ${Number(invoiceData.breakdown?.originalAmount ?? invoiceData.fee?.totalAmount ?? 0).toFixed(2)}
                    </span>
                  </div>

                  {(Number(invoiceData.breakdown?.discountAmount ?? invoiceData.fee?.discountAmount ?? 0) > 0) && (
                    <div className="flex justify-between text-xs text-emerald-400">
                      <span className="flex items-center gap-1">
                        <ArrowDownRight className="w-3.5 h-3.5" /> Discount
                        {invoiceData.fee?.discountReason && (
                          <span className="text-[10px] text-emerald-400/80 font-normal">
                            ({invoiceData.fee.discountReason})
                          </span>
                        )}
                        :
                      </span>
                      <span className="font-mono font-semibold">
                        -${Number(invoiceData.breakdown?.discountAmount ?? invoiceData.fee?.discountAmount ?? 0).toFixed(2)}
                      </span>
                    </div>
                  )}

                  {(Number(invoiceData.breakdown?.scholarshipAmount ?? invoiceData.fee?.scholarshipAmount ?? 0) > 0) && (
                    <div className="flex justify-between text-xs text-cyan-400">
                      <span className="flex items-center gap-1">
                        <ArrowDownRight className="w-3.5 h-3.5" /> Scholarship Grant
                        {invoiceData.fee?.scholarshipName && (
                          <span className="text-[10px] text-cyan-400/80 font-normal">
                            ({invoiceData.fee.scholarshipName})
                          </span>
                        )}
                        :
                      </span>
                      <span className="font-mono font-semibold">
                        -${Number(invoiceData.breakdown?.scholarshipAmount ?? invoiceData.fee?.scholarshipAmount ?? 0).toFixed(2)}
                      </span>
                    </div>
                  )}

                  {(Number(invoiceData.breakdown?.waiverAmount ?? invoiceData.fee?.waiverAmount ?? 0) > 0) && (
                    <div className="flex justify-between text-xs text-teal-400">
                      <span className="flex items-center gap-1">
                        <ArrowDownRight className="w-3.5 h-3.5" /> Approved Fee Waiver
                        {invoiceData.fee?.waiverReason && (
                          <span className="text-[10px] text-teal-400/80 font-normal">
                            ({invoiceData.fee.waiverReason})
                          </span>
                        )}
                        :
                      </span>
                      <span className="font-mono font-semibold">
                        -${Number(invoiceData.breakdown?.waiverAmount ?? invoiceData.fee?.waiverAmount ?? 0).toFixed(2)}
                      </span>
                    </div>
                  )}

                  {(Number(invoiceData.breakdown?.fineAmount ?? invoiceData.fee?.fineAmount ?? 0) > 0) && (
                    <div className="flex justify-between text-xs text-rose-400">
                      <span>
                        Late Fine / Penalty
                        {invoiceData.fee?.fineReason && (
                          <span className="text-[10px] text-rose-400/80 font-normal ml-1">
                            ({invoiceData.fee.fineReason})
                          </span>
                        )}
                        :
                      </span>
                      <span className="font-mono font-semibold">
                        +${Number(invoiceData.breakdown?.fineAmount ?? invoiceData.fee?.fineAmount ?? 0).toFixed(2)}
                      </span>
                    </div>
                  )}

                  <div className="pt-2 border-t border-white/10 flex justify-between text-xs font-semibold text-white">
                    <span>Net Payable Amount:</span>
                    <span className="font-mono text-indigo-300">
                      ${Number(invoiceData.breakdown?.netPayableAmount ?? invoiceData.fee?.netPayableAmount ?? invoiceData.fee?.totalAmount ?? 0).toFixed(2)}
                    </span>
                  </div>

                  <div className="flex justify-between text-xs text-emerald-400">
                    <span>Total Amount Paid:</span>
                    <span className="font-mono font-semibold">
                      ${Number(invoiceData.breakdown?.totalPaid ?? invoiceData.fee?.paidAmount ?? 0).toFixed(2)}
                    </span>
                  </div>

                  <div className="pt-2 border-t border-white/10 flex justify-between items-center text-sm font-bold">
                    <span className="text-white">Remaining Balance Due:</span>
                    <span
                      className={`font-mono text-base ${
                        feeDueAmount > 0 ? 'text-amber-400' : 'text-emerald-400'
                      }`}
                    >
                      ${feeDueAmount.toFixed(2)}
                    </span>
                  </div>
                </div>

                {/* Transactions Record (If Payments Exist) */}
                {invoiceData.transactions && invoiceData.transactions.length > 0 && (
                  <div>
                    <h5 className="text-xs font-bold uppercase tracking-wider text-slate-300 mb-2.5 flex items-center gap-1.5">
                      <Receipt className="w-3.5 h-3.5 text-emerald-400" /> Payment History
                    </h5>
                    <div className="border border-white/10 rounded-xl overflow-hidden bg-slate-900/50">
                      <table className="w-full text-left text-xs">
                        <thead className="bg-white/5 border-b border-white/10 text-slate-300 font-semibold">
                          <tr>
                            <th className="px-3 py-2">Receipt No</th>
                            <th className="px-3 py-2">Date</th>
                            <th className="px-3 py-2">Method</th>
                            <th className="px-3 py-2 text-right">Amount</th>
                            <th className="px-3 py-2 text-center">Status</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-white/5 text-slate-300">
                          {invoiceData.transactions.map((tx) => (
                            <tr key={tx.id}>
                              <td className="px-3 py-2 font-mono">
                                {onViewReceipt ? (
                                  <button
                                    onClick={() => onViewReceipt(tx.receiptNumber || tx.id)}
                                    className="text-indigo-400 hover:text-indigo-300 hover:underline font-bold cursor-pointer"
                                  >
                                    {tx.receiptNumber || tx.id}
                                  </button>
                                ) : (
                                  <span className="text-indigo-300">{tx.receiptNumber || tx.id}</span>
                                )}
                              </td>
                              <td className="px-3 py-2 text-slate-400">
                                {new Date(tx.paymentDate || tx.createdAt).toLocaleDateString()}
                              </td>
                              <td className="px-3 py-2 text-slate-300">{tx.paymentMethodLabel || tx.paymentMethod}</td>
                              <td className="px-3 py-2 text-right font-mono font-semibold text-emerald-400">
                                ${(tx.amountPaid || tx.amount || 0).toFixed(2)}
                              </td>
                              <td className="px-3 py-2 text-center">
                                <span
                                  className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                                    tx.isReversed || tx.paymentStatus === 'REVERSED' || tx.status === 'REVERSED'
                                      ? 'bg-rose-500/10 text-rose-400 border-rose-500/20'
                                      : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                                  }`}
                                >
                                  {tx.isReversed || tx.paymentStatus === 'REVERSED' || tx.status === 'REVERSED'
                                    ? 'VOIDED'
                                    : 'SUCCESS'}
                                </span>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                {/* Footer Notes & Legal Verification Notice */}
                <div className="pt-4 border-t border-white/10 text-[11px] text-slate-400 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
                  <div className="flex items-center gap-1.5 text-slate-400">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    <span>System Generated Official School Invoice &bull; Authorized by Accounts Dept.</span>
                  </div>
                  <span className="font-mono text-slate-400">
                    Invoice ID: {invoiceData.fee?.id || 'N/A'}
                  </span>
                </div>
              </div>
            </>
          )}
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-white/10 bg-slate-950/70">
          <div className="text-xs text-slate-400">
            {invoiceData?.fee?.notes && (
              <p className="truncate max-w-sm">
                <span className="font-semibold text-slate-300">Notes:</span> {invoiceData.fee.notes}
              </p>
            )}
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-white bg-white/10 hover:bg-white/15 rounded-xl transition-colors cursor-pointer"
          >
            Close Statement
          </button>
        </div>
      </div>
    </div>
  );
};

