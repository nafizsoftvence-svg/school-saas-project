import React, { useState, useEffect } from 'react';
import { X, ShieldCheck, DollarSign, Percent, FileText, CheckCircle2, AlertTriangle, User } from 'lucide-react';
import { FeeWaiver, CreateWaiverPayload, StudentFeeRecord } from '../../types/index.js';
import { api } from '../../services/api.js';
import { useToast } from '../../context/ToastContext.js';

interface GrantWaiverModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (newWaiver: FeeWaiver) => void;
  preselectedFeeRecord?: StudentFeeRecord | null;
}

export const GrantWaiverModal: React.FC<GrantWaiverModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  preselectedFeeRecord
}) => {
  const { showToast } = useToast();

  const [studentSearch, setStudentSearch] = useState('');
  const [students, setStudents] = useState<any[]>([]);
  const [selectedStudent, setSelectedStudent] = useState<any | null>(null);

  const [studentInvoices, setStudentInvoices] = useState<StudentFeeRecord[]>([]);
  const [selectedFeeRecordId, setSelectedFeeRecordId] = useState<string>('');

  const [waiverType, setWaiverType] = useState<'FULL' | 'PARTIAL_FIXED' | 'PARTIAL_PERCENTAGE'>('FULL');
  const [value, setValue] = useState<string>('');
  const [reason, setReason] = useState<string>('');
  const [notes, setNotes] = useState<string>('');
  const [autoApprove, setAutoApprove] = useState<boolean>(true);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [isLoadingInvoices, setIsLoadingInvoices] = useState<boolean>(false);

  useEffect(() => {
    if (isOpen) {
      if (preselectedFeeRecord) {
        setSelectedStudent({
          id: preselectedFeeRecord.studentId,
          fullName: preselectedFeeRecord.studentName,
          admissionNumber: preselectedFeeRecord.admissionNumber,
          className: preselectedFeeRecord.className
        });
        setSelectedFeeRecordId(preselectedFeeRecord.id);
        setStudentInvoices([preselectedFeeRecord]);
      } else {
        setSelectedStudent(null);
        setSelectedFeeRecordId('');
        setStudentInvoices([]);
        // Fetch students
        api.users
          .getStudents({ limit: 100 })
          .then((res: any) => {
            if (res?.data?.students) setStudents(res.data.students);
            else if (Array.isArray(res?.data)) setStudents(res.data);
          })
          .catch(() => {});
      }

      setWaiverType('FULL');
      setValue('');
      setReason('');
      setNotes('');
      setAutoApprove(true);
    }
  }, [isOpen, preselectedFeeRecord]);

  // When student selected, load their open invoices
  const handleSelectStudent = async (student: any) => {
    setSelectedStudent(student);
    setSelectedFeeRecordId('');
    setIsLoadingInvoices(true);
    try {
      const res = await api.fees.getStudentFees({
        studentId: student.id,
        limit: 50
      });
      if (res.success && res.data) {
        const feesList: StudentFeeRecord[] = (res.data as any).fees || (res.data as any).data || (Array.isArray(res.data) ? res.data : []);
        const activeFees = feesList.filter((f) => f.status !== 'CANCELLED' && f.dueAmount > 0);
        setStudentInvoices(activeFees);
        if (activeFees && activeFees.length > 0) {
          setSelectedFeeRecordId(activeFees?.[0]?.id || '');
        }
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoadingInvoices(false);
    }
  };

  if (!isOpen) return null;

  const currentInvoice = (studentInvoices || []).find((f) => f?.id === selectedFeeRecordId);

  // Compute preview waiver amount
  let previewAmount = 0;
  if (currentInvoice) {
    const grossDue = currentInvoice.totalAmount - (currentInvoice.discountAmount || 0) - (currentInvoice.scholarshipAmount || 0);
    if (waiverType === 'FULL') {
      previewAmount = grossDue;
    } else if (waiverType === 'PARTIAL_PERCENTAGE') {
      const p = parseFloat(value) || 0;
      previewAmount = Math.round((currentInvoice.totalAmount * (p / 100)) * 100) / 100;
    } else {
      const v = parseFloat(value) || 0;
      previewAmount = Math.min(grossDue, v);
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStudent || !selectedFeeRecordId) {
      showToast('Please select a student and an invoice', 'error');
      return;
    }

    if (!reason.trim()) {
      showToast('Please enter the justification reason for this waiver', 'error');
      return;
    }

    if (waiverType !== 'FULL') {
      const v = parseFloat(value);
      if (isNaN(v) || v <= 0) {
        showToast('Please enter a valid waiver value', 'error');
        return;
      }
    }

    setIsSubmitting(true);
    try {
      const payload: CreateWaiverPayload = {
        studentId: selectedStudent.id,
        feeRecordId: selectedFeeRecordId,
        waiverType,
        value: waiverType !== 'FULL' ? parseFloat(value) : undefined,
        reason: reason.trim(),
        notes: notes.trim() || undefined,
        autoApprove
      };

      const res = await api.fees.createWaiver(payload);
      if (res.success && res.data) {
        showToast(
          autoApprove
            ? `Waiver granted & approved ($${res.data.amount.toFixed(2)})`
            : `Waiver request submitted (${res.data.waiverNumber})`,
          'success'
        );
        onSuccess(res.data);
        onClose();
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to grant fee waiver', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const filteredStudents = studentSearch
    ? students.filter(
        (s) =>
          s.fullName?.toLowerCase().includes(studentSearch.toLowerCase()) ||
          s.admissionNumber?.toLowerCase().includes(studentSearch.toLowerCase())
      )
    : students.slice(0, 6);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto"
      onClick={(e) => {
        if (e.target === e.currentTarget && !isSubmitting) onClose();
      }}
    >
      <div className="relative w-full max-w-xl bg-slate-900 border border-white/15 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 bg-slate-950/70">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-teal-500/15 border border-teal-500/30 flex items-center justify-center text-teal-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Grant / Request Fee Waiver</h3>
              <p className="text-xs text-slate-400">Exempt full or partial student invoice balances</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
          {/* Step 1: Student Selection */}
          {!preselectedFeeRecord && (
            <div className="space-y-2">
              <label className="block text-xs font-semibold text-slate-300">
                1. Select Student <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                value={studentSearch}
                onChange={(e) => setStudentSearch(e.target.value)}
                placeholder="Search student by name or admission number..."
                className="w-full px-3 py-2 text-xs bg-slate-950 border border-white/10 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-teal-500"
              />
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-28 overflow-y-auto">
                {filteredStudents.map((st) => (
                  <button
                    key={st.id}
                    type="button"
                    onClick={() => handleSelectStudent(st)}
                    className={`text-left p-2.5 rounded-xl border text-xs transition-colors flex items-center justify-between ${
                      selectedStudent?.id === st.id
                        ? 'bg-teal-500/20 text-teal-300 border-teal-500/50 font-bold'
                        : 'bg-white/5 text-slate-300 border-white/10 hover:bg-white/10'
                    }`}
                  >
                    <div>
                      <p className="font-semibold text-white">{st.fullName}</p>
                      <p className="text-[10px] text-slate-400">{st.admissionNumber || st.className}</p>
                    </div>
                    {selectedStudent?.id === st.id && <CheckCircle2 className="w-4 h-4 text-teal-400" />}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Step 2: Choose Student Invoice */}
          {selectedStudent && (
            <div className="space-y-2">
              <label className="block text-xs font-semibold text-slate-300">
                2. Target Fee Invoice <span className="text-rose-400">*</span>
              </label>
              {isLoadingInvoices ? (
                <div className="p-3 text-center text-xs text-slate-400">Loading student invoices...</div>
              ) : studentInvoices.length === 0 ? (
                <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-xl text-xs text-amber-300">
                  No unpaid invoices found for {selectedStudent.fullName}.
                </div>
              ) : (
                <select
                  value={selectedFeeRecordId}
                  onChange={(e) => setSelectedFeeRecordId(e.target.value)}
                  required
                  className="w-full px-3 py-2 text-xs bg-slate-950 border border-white/10 rounded-xl text-white focus:outline-none focus:border-teal-500"
                >
                  {studentInvoices.map((inv) => (
                    <option key={inv.id} value={inv.id}>
                      {inv.invoiceNumber} - {inv.title} (Due: ${inv.dueAmount.toFixed(2)} | Total: $
                      {inv.totalAmount.toFixed(2)})
                    </option>
                  ))}
                </select>
              )}
            </div>
          )}

          {/* Step 3: Waiver Type & Value */}
          <div className="p-4 bg-white/5 border border-white/10 rounded-xl space-y-3">
            <label className="block text-xs font-semibold text-slate-300">3. Waiver Type & Amount</label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setWaiverType('FULL')}
                className={`px-3 py-2 text-xs font-bold rounded-lg border transition-all text-center ${
                  waiverType === 'FULL'
                    ? 'bg-teal-500/20 text-teal-300 border-teal-500/50 shadow-sm shadow-teal-500/20'
                    : 'bg-slate-950 text-slate-400 border-white/10 hover:border-white/20'
                }`}
              >
                100% Full Waiver
              </button>
              <button
                type="button"
                onClick={() => {
                  setWaiverType('PARTIAL_PERCENTAGE');
                  if (!value) setValue('50');
                }}
                className={`px-3 py-2 text-xs font-bold rounded-lg border transition-all text-center ${
                  waiverType === 'PARTIAL_PERCENTAGE'
                    ? 'bg-teal-500/20 text-teal-300 border-teal-500/50 shadow-sm shadow-teal-500/20'
                    : 'bg-slate-950 text-slate-400 border-white/10 hover:border-white/20'
                }`}
              >
                Partial (%)
              </button>
              <button
                type="button"
                onClick={() => {
                  setWaiverType('PARTIAL_FIXED');
                  if (!value) setValue('250');
                }}
                className={`px-3 py-2 text-xs font-bold rounded-lg border transition-all text-center ${
                  waiverType === 'PARTIAL_FIXED'
                    ? 'bg-teal-500/20 text-teal-300 border-teal-500/50 shadow-sm shadow-teal-500/20'
                    : 'bg-slate-950 text-slate-400 border-white/10 hover:border-white/20'
                }`}
              >
                Fixed Amount ($)
              </button>
            </div>

            {waiverType !== 'FULL' && (
              <div className="pt-2">
                <label className="block text-xs text-slate-400 mb-1">
                  {waiverType === 'PARTIAL_PERCENTAGE' ? 'Percentage (1 - 100%)' : 'Fixed Dollar Amount ($)'}
                </label>
                <input
                  type="number"
                  step="0.01"
                  min="0.01"
                  max={waiverType === 'PARTIAL_PERCENTAGE' ? '100' : undefined}
                  value={value}
                  onChange={(e) => setValue(e.target.value)}
                  placeholder={waiverType === 'PARTIAL_PERCENTAGE' ? '50' : '250'}
                  required
                  className="w-full px-3 py-2 text-xs font-mono font-bold bg-slate-950 border border-white/10 rounded-xl text-teal-300 focus:outline-none focus:border-teal-500"
                />
              </div>
            )}

            {/* Calculated Preview */}
            {currentInvoice && (
              <div className="flex items-center justify-between pt-2 border-t border-white/10 text-xs">
                <span className="text-slate-400">Total Waiver Deduction:</span>
                <span className="font-mono font-bold text-teal-400 text-sm">
                  -${previewAmount.toFixed(2)}
                </span>
              </div>
            )}
          </div>

          {/* Reason & Documentation */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Justification Reason <span className="text-rose-400">*</span>
            </label>
            <input
              type="text"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="e.g. Humanitarian Hardship / Principal's Discretionary Relief"
              required
              className="w-full px-3 py-2 text-xs bg-slate-950 border border-white/10 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-teal-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">Administrative Notes</label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Approved under Board Resolution 442; documentation on file..."
              className="w-full px-3 py-2 text-xs bg-slate-950 border border-white/10 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-teal-500"
            />
          </div>

          {/* Direct Approval Toggle */}
          <div className="flex items-center gap-3 p-3 bg-white/5 border border-white/10 rounded-xl">
            <input
              type="checkbox"
              id="autoApprove"
              checked={autoApprove}
              onChange={(e) => setAutoApprove(e.target.checked)}
              className="w-4 h-4 rounded text-teal-600 bg-slate-950 border-white/20 focus:ring-0"
            />
            <label htmlFor="autoApprove" className="text-xs text-slate-300 cursor-pointer">
              <span className="font-semibold text-white">Approve and Apply Immediately</span>
              <p className="text-[11px] text-slate-400">
                Instantly adjust the invoice balance and recalculate net payable.
              </p>
            </label>
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-bold text-slate-400 hover:text-white bg-white/5 hover:bg-white/10 rounded-xl transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting || !selectedFeeRecordId}
              className="px-5 py-2 text-xs font-bold text-white bg-teal-600 hover:bg-teal-500 disabled:opacity-50 rounded-xl shadow-lg shadow-teal-600/20 transition-all cursor-pointer flex items-center gap-2"
            >
              {isSubmitting ? (
                <span>Processing Waiver...</span>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Grant Waiver</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
