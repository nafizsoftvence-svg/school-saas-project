import React from 'react';
import {
  FileSpreadsheet,
  Calendar,
  Layers,
  GraduationCap,
  Coins,
  Clock,
  CheckCircle2,
  AlertCircle,
  Shield,
  Tag,
  Edit2,
  Trash2,
  Archive,
  ArchiveRestore,
  User,
  Info,
  DollarSign,
  X
} from 'lucide-react';
import { Modal } from '../ui/Modal.js';
import { Button } from '../ui/Button.js';
import { Badge } from '../ui/Badge.js';
import { FeeStructure, FeeStructureStatus } from '../../types/index.js';

interface FeeStructureDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  structure: FeeStructure | null;
  onEdit: (structure: FeeStructure) => void;
  onStatusChange: (structure: FeeStructure, newStatus: FeeStructureStatus) => void;
  onDelete: (structure: FeeStructure) => void;
}

const STATUS_BADGE_MAP: Record<FeeStructureStatus, { variant: 'success' | 'warning' | 'secondary' | 'danger'; label: string }> = {
  ACTIVE: { variant: 'success', label: 'Active (Live)' },
  DRAFT: { variant: 'warning', label: 'Draft (In Preparation)' },
  INACTIVE: { variant: 'secondary', label: 'Inactive (Suspended)' },
  ARCHIVED: { variant: 'danger', label: 'Archived (Historical)' }
};

export const FeeStructureDetailModal: React.FC<FeeStructureDetailModalProps> = ({
  isOpen,
  onClose,
  structure,
  onEdit,
  onStatusChange,
  onDelete
}) => {
  if (!structure) return null;

  const statusConfig = STATUS_BADGE_MAP[structure.status] || { variant: 'secondary', label: structure.status };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={
        <div className="flex items-center gap-2 text-white">
          <FileSpreadsheet className="w-5 h-5 text-indigo-400" />
          <span>Fee Structure Specification</span>
        </div>
      }
      description={`System ID: ${structure.id}`}
      size="lg"
      id="fee-structure-detail-modal"
    >
      <div className="space-y-6">
        {/* Header Hero Box */}
        <div className="p-5 rounded-2xl bg-gradient-to-br from-slate-900 via-indigo-950/40 to-slate-900 border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="text-xs font-mono font-bold text-indigo-300 bg-indigo-500/20 px-2 py-0.5 rounded border border-indigo-500/30">
                {structure.feeTypeCode}
              </span>
              <Badge variant={statusConfig.variant} className="text-xs">
                {statusConfig.label}
              </Badge>
              {structure.isMandatory || structure.feeCategory === 'MANDATORY' ? (
                <span className="text-xs font-bold text-rose-300 bg-rose-500/20 px-2 py-0.5 rounded border border-rose-500/30">
                  Mandatory
                </span>
              ) : (
                <span className="text-xs font-bold text-emerald-300 bg-emerald-500/20 px-2 py-0.5 rounded border border-emerald-500/30">
                  Optional
                </span>
              )}
            </div>
            <h3 className="text-xl font-bold text-white tracking-tight">{structure.name}</h3>
            <p className="text-xs text-slate-400 mt-1">{structure.feeTypeName}</p>
          </div>

          <div className="text-right sm:border-l sm:border-white/10 sm:pl-6">
            <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Fee Amount</div>
            <div className="text-2xl font-black text-emerald-400 font-mono">
              {structure.currency} {structure.amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <div className="text-xs text-slate-400 font-medium capitalize mt-0.5">
              Per {(structure.frequency || 'TERM').toLowerCase().replace('_', '-')}
            </div>
          </div>
        </div>

        {/* Breakdown Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="p-4 rounded-xl bg-slate-950/60 border border-white/5 space-y-3">
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
              <GraduationCap className="w-4 h-4 text-indigo-400" /> Academic & Target Scope
            </h4>
            <div className="space-y-2 text-xs">
              <div className="flex justify-between py-1 border-b border-white/5">
                <span className="text-slate-400">Academic Session:</span>
                <span className="font-semibold text-white">{structure.academicSessionName}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-white/5">
                <span className="text-slate-400">Target Grade / Class:</span>
                <span className="font-semibold text-white">{structure.className}</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-400">Section Scope:</span>
                <span className="font-semibold text-white">
                  {structure.applicableToAllSections || !structure.sectionId
                    ? 'All Sections (Universal)'
                    : `Section ${structure.sectionName}`}
                </span>
              </div>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-slate-950/60 border border-white/5 space-y-3">
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
              <Calendar className="w-4 h-4 text-indigo-400" /> Billing & Payment Terms
            </h4>
            <div className="space-y-2 text-xs">
              <div className="flex justify-between py-1 border-b border-white/5">
                <span className="text-slate-400">Collection Frequency:</span>
                <span className="font-semibold text-white capitalize">
                  {(structure.frequency || 'TERM').replace(/_/g, ' ')}
                </span>
              </div>
              <div className="flex justify-between py-1 border-b border-white/5">
                <span className="text-slate-400">Standard Due Date:</span>
                <span className="font-semibold text-white font-mono">{structure.dueDate}</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-400">Requirement Policy:</span>
                <span className="font-semibold text-white">
                  {structure.isMandatory ? 'Mandatory (Universal)' : 'Optional (Subscribed)'}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Description & Notes */}
        {(structure.description || structure.notes) && (
          <div className="p-4 rounded-xl bg-slate-950/60 border border-white/5 space-y-3">
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
              <Info className="w-4 h-4 text-indigo-400" /> Description & Administrative Notes
            </h4>
            {structure.description && (
              <div>
                <span className="text-[11px] font-semibold text-slate-400">Coverage Description:</span>
                <p className="text-xs text-slate-300 mt-1 leading-relaxed">{structure.description}</p>
              </div>
            )}
            {structure.notes && (
              <div>
                <span className="text-[11px] font-semibold text-slate-400">Administrative Notes:</span>
                <p className="text-xs text-slate-300 mt-1 leading-relaxed italic bg-slate-900/50 p-2.5 rounded-lg border border-white/5">
                  {structure.notes}
                </p>
              </div>
            )}
          </div>
        )}

        {/* Audit Meta */}
        <div className="p-3 rounded-xl bg-slate-950/40 border border-white/5 flex flex-wrap items-center justify-between text-[11px] text-slate-500 gap-2">
          <span>Created: {new Date(structure.createdAt).toLocaleString()}</span>
          <span>Last Updated: {new Date(structure.updatedAt).toLocaleString()}</span>
        </div>

        {/* Modal Actions */}
        <div className="pt-4 border-t border-white/10 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            {structure.status === 'DRAFT' && (
              <Button
                variant="primary"
                size="sm"
                onClick={() => onStatusChange(structure, 'ACTIVE')}
                className="bg-emerald-600 hover:bg-emerald-500"
              >
                <CheckCircle2 className="w-3.5 h-3.5 mr-1.5" /> Publish & Activate
              </Button>
            )}
            {structure.status === 'ACTIVE' && (
              <Button
                variant="secondary"
                size="sm"
                onClick={() => onStatusChange(structure, 'INACTIVE')}
                className="text-amber-400 hover:text-amber-300"
              >
                Suspend / Inactivate
              </Button>
            )}
            {structure.status === 'INACTIVE' && (
              <Button
                variant="secondary"
                size="sm"
                onClick={() => onStatusChange(structure, 'ACTIVE')}
                className="text-emerald-400 hover:text-emerald-300"
              >
                Reactivate Structure
              </Button>
            )}
            {structure.status !== 'ARCHIVED' && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => onStatusChange(structure, 'ARCHIVED')}
                className="text-slate-400 hover:text-rose-300 hover:bg-rose-500/10"
              >
                <Archive className="w-3.5 h-3.5 mr-1.5" /> Archive
              </Button>
            )}
            {structure.status === 'ARCHIVED' && (
              <Button
                variant="secondary"
                size="sm"
                onClick={() => onStatusChange(structure, 'DRAFT')}
                className="text-indigo-400 hover:text-indigo-300"
              >
                <ArchiveRestore className="w-3.5 h-3.5 mr-1.5" /> Restore to Draft
              </Button>
            )}
          </div>

          <div className="flex items-center gap-2">
            {structure.status !== 'ARCHIVED' && (
              <Button
                variant="secondary"
                size="sm"
                onClick={() => {
                  onClose();
                  onEdit(structure);
                }}
                className="flex items-center gap-1.5"
              >
                <Edit2 className="w-3.5 h-3.5" />
                <span>Edit Structure</span>
              </Button>
            )}
            {(structure.status === 'DRAFT' || structure.status === 'ARCHIVED') && (
              <Button
                variant="danger"
                size="sm"
                onClick={() => {
                  onClose();
                  onDelete(structure);
                }}
                className="flex items-center gap-1.5"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete</span>
              </Button>
            )}
            <Button variant="secondary" size="sm" onClick={onClose}>
              Close
            </Button>
          </div>
        </div>
      </div>
    </Modal>
  );
};
