import React, { useRef, useState, useEffect } from 'react';
import {
  X,
  Printer,
  Download,
  FileText,
  Building,
  User,
  Calendar,
  CreditCard,
  CheckCircle2,
  AlertTriangle,
  Clock,
  ArrowDownRight,
  TrendingDown,
  TrendingUp,
  ShieldCheck,
  Filter,
  RefreshCw,
  Search
} from 'lucide-react';
import { StudentAccountStatement, StudentStatementEntry } from '../../types/index.js';
import { api } from '../../services/api.js';
import { downloadTablePdf, triggerSafePrint } from '../../utils/printPdf.js';

interface StudentStatementModalProps {
  isOpen: boolean;
  onClose: () => void;
  studentId: string | null;
  academicSessionId?: string;
}

export const StudentStatementModal: React.FC<StudentStatementModalProps> = ({
  isOpen,
  onClose,
  studentId,
  academicSessionId
}) => {
  const [statement, setStatement] = useState<StudentAccountStatement | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [startDate, setStartDate] = useState<string>('');
  const [endDate, setEndDate] = useState<string>('');
  const [filterType, setFilterType] = useState<string>('ALL');
  const printableRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen && studentId) {
      fetchStatement();
    } else {
      setStatement(null);
      setError(null);
    }
  }, [isOpen, studentId, academicSessionId]);

  const fetchStatement = async () => {
    if (!studentId) return;
    try {
      setLoading(true);
      setError(null);
      const res = await api.fees.getStudentAccountStatement(studentId, {
        academicSessionId: academicSessionId && academicSessionId !== 'ALL' ? academicSessionId : undefined,
        startDate: startDate || undefined,
        endDate: endDate || undefined
      });
      if (res.success && res.data) {
        setStatement(res.data);
      } else {
        setError(res.error || 'Failed to load financial statement.');
      }
    } catch (err: any) {
      setError(err.message || 'An error occurred while loading statement.');
    } finally {
      setLoading(false);
    }
  };

  const [isExporting, setIsExporting] = useState(false);

  const handlePrint = async () => {
    if (!statement) return;
    try {
      setIsExporting(true);
      const headers = ['Date', 'Reference No', 'Type', 'Description', 'Fee Title', 'Debit', 'Credit', 'Balance'];
      const rows = statement.entries.map((entry) => [
        new Date(entry.date).toLocaleDateString(),
        entry.referenceNo || '',
        entry.type || '',
        entry.description || '',
        entry.feeTitle || '',
        entry.debit ? `$${Number(entry.debit).toFixed(2)}` : '$0.00',
        entry.credit ? `$${Number(entry.credit).toFixed(2)}` : '$0.00',
        `$${Number(entry.runningBalance ?? 0).toFixed(2)}`
      ]);

      const studentName = statement.student?.name || 'Student';
      const cleanName = studentName.replace(/\s+/g, '_');
      const filename = `Statement_${cleanName}_${new Date().toISOString().split('T')[0]}.pdf`;

      await downloadTablePdf({
        title: `Official Student Ledger Statement — ${studentName}`,
        subtitle: `Admission No: ${statement.student?.admissionNumber || ''} | Class: ${statement.student?.className || ''} | Outstanding: $${Number(statement.summary?.currentDue ?? 0).toFixed(2)}`,
        columns: headers,
        data: rows,
        filename,
        orientation: 'landscape'
      });

      await triggerSafePrint({
        elementOrId: printableRef.current || undefined,
        fallbackTitle: `Statement_${cleanName}`
      });
    } catch (err) {
      console.error('Statement print/PDF error:', err);
      try {
        window.print();
      } catch {
        // ignore
      }
    } finally {
      setIsExporting(false);
    }
  };

  const handleDownloadCsv = () => {
    if (!statement) return;
    const headers = ['Date', 'Reference No', 'Type', 'Description', 'Fee Title', 'Debit (+)', 'Credit (-)', 'Running Balance'];
    const rows = statement.entries.map((entry) => [
      new Date(entry.date).toLocaleDateString(),
      `"${entry.referenceNo}"`,
      `"${entry.type}"`,
      `"${(entry.description || '').replace(/"/g, '""')}"`,
      `"${entry.feeTitle || ''}"`,
      entry.debit ? Number(entry.debit).toFixed(2) : '0.00',
      entry.credit ? Number(entry.credit).toFixed(2) : '0.00',
      Number(entry.runningBalance ?? 0).toFixed(2)
    ]);

    const summaryRows = [
      [],
      ['STUDENT ACCOUNT STATEMENT SUMMARY'],
      ['Student Name', `"${statement.student?.name || ''}"`],
      ['Admission No', `"${statement.student?.admissionNumber || ''}"`],
      ['Class & Section', `"${statement.student?.className || ''} - ${statement.student?.sectionName || ''}"`],
      ['Session', `"${statement.period?.sessionName || ''}"`],
      ['Generated At', `"${new Date(statement.period?.generatedAt || Date.now()).toLocaleString()}"`],
      ['Total Invoiced / Billed', Number(statement.summary?.totalBilled ?? 0).toFixed(2)],
      ['Total Concessions (Discounts/Scholarships/Waivers)', (Number(statement.summary?.totalDiscounts ?? 0) + Number(statement.summary?.totalScholarships ?? 0) + Number(statement.summary?.totalWaivers ?? 0)).toFixed(2)],
      ['Total Late Fines', Number(statement.summary?.totalFines ?? 0).toFixed(2)],
      ['Net Payable Amount', Number(statement.summary?.netPayable ?? 0).toFixed(2)],
      ['Total Paid Settled', Number(statement.summary?.totalPaid ?? 0).toFixed(2)],
      ['Current Outstanding Due', Number(statement.summary?.currentDue ?? 0).toFixed(2)],
      ['Account Status', statement.summary?.status || 'UNKNOWN'],
      []
    ];

    const csvContent =
      'data:text/csv;charset=utf-8,' +
      summaryRows.map((r) => r.join(',')).join('\n') +
      [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute(
      'download',
      `Statement_${statement.student.admissionNumber}_${new Date().toISOString().split('T')[0]}.csv`
    );
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (!isOpen) return null;

  const filteredEntries = (statement?.entries || []).filter((entry) => {
    if (filterType === 'ALL') return true;
    if (filterType === 'DEBITS') return entry.debit > 0;
    if (filterType === 'CREDITS') return entry.credit > 0;
    if (filterType === 'PAYMENTS') return entry.type === 'PAYMENT_RECEIVED' || entry.type === 'PAYMENT_REVERSED';
    if (filterType === 'INVOICES') return entry.type === 'INVOICE_GENERATED';
    if (filterType === 'CONCESSIONS')
      return entry.type === 'DISCOUNT_APPLIED' || entry.type === 'SCHOLARSHIP_APPLIED' || entry.type === 'WAIVER_APPLIED';
    return true;
  });

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-sm overflow-y-auto"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="relative w-full max-w-5xl bg-slate-900 border border-white/15 rounded-2xl shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Top Action Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 bg-slate-950/80 shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                Official Student Financial Statement
                {statement && statement.summary?.status && (
                  <span
                    className={`px-2 py-0.5 text-[10px] font-extrabold uppercase rounded border ${
                      statement.summary.status === 'CLEARED'
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                        : statement.summary.status === 'OVERDUE'
                        ? 'bg-rose-500/20 text-rose-300 border-rose-500/30'
                        : 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                    }`}
                  >
                    {(statement.summary.status || '').replace(/_/g, ' ')}
                  </span>
                )}
              </h3>
              <p className="text-xs text-slate-400">
                {statement
                  ? `${statement.student.name} • Admission No: ${statement.student.admissionNumber}`
                  : 'Loading account statement...'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={fetchStatement}
              disabled={loading}
              className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-white/10 transition-colors disabled:opacity-50 cursor-pointer"
              title="Refresh Statement"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
            <button
              onClick={handlePrint}
              disabled={!statement || loading || isExporting}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 rounded-xl transition-colors cursor-pointer shadow-sm shadow-indigo-600/20"
              title="Print Official Statement"
            >
              <Printer className="w-3.5 h-3.5" />
              {isExporting ? 'Generating PDF...' : 'Print / Save PDF'}
            </button>
            <button
              onClick={handleDownloadCsv}
              disabled={!statement || loading}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-200 bg-white/5 hover:bg-white/10 border border-white/10 disabled:opacity-50 rounded-xl transition-colors cursor-pointer"
              title="Export to CSV"
            >
              <Download className="w-3.5 h-3.5" />
              Export CSV
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Filter Controls Bar */}
        <div className="px-6 py-3 bg-slate-950/40 border-b border-white/5 flex flex-wrap items-center justify-between gap-3 text-xs shrink-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-slate-400 font-medium flex items-center gap-1">
              <Filter className="w-3.5 h-3.5" /> Filter Ledger:
            </span>
            <div className="inline-flex bg-slate-900 border border-white/10 rounded-lg p-0.5">
              {['ALL', 'INVOICES', 'PAYMENTS', 'CONCESSIONS', 'DEBITS', 'CREDITS'].map((type) => (
                <button
                  key={type}
                  onClick={() => setFilterType(type)}
                  className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-all cursor-pointer ${
                    filterType === type ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {type}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-2">
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="px-2.5 py-1 bg-slate-900 border border-white/10 rounded-lg text-slate-200 text-xs focus:outline-hidden focus:border-indigo-500"
              placeholder="Start Date"
            />
            <span className="text-slate-500">to</span>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="px-2.5 py-1 bg-slate-900 border border-white/10 rounded-lg text-slate-200 text-xs focus:outline-hidden focus:border-indigo-500"
              placeholder="End Date"
            />
            {(startDate || endDate) && (
              <button
                onClick={() => {
                  setStartDate('');
                  setEndDate('');
                }}
                className="text-[11px] text-indigo-400 hover:underline cursor-pointer"
              >
                Clear
              </button>
            )}
            <button
              onClick={fetchStatement}
              className="px-3 py-1 bg-white/10 hover:bg-white/15 text-white font-medium rounded-lg text-xs transition-colors cursor-pointer"
            >
              Apply
            </button>
          </div>
        </div>

        {/* Modal Scrollable Content */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6 bg-slate-900/60">
          {loading ? (
            <div className="flex flex-col items-center justify-center py-20 text-slate-400 space-y-3">
              <div className="w-8 h-8 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" />
              <p className="text-xs">Generating verified financial account statement...</p>
            </div>
          ) : error ? (
            <div className="p-6 text-center text-rose-400 bg-rose-500/10 border border-rose-500/20 rounded-xl">
              <AlertTriangle className="w-8 h-8 mx-auto mb-2 opacity-80" />
              <p className="font-semibold text-sm">{error}</p>
              <button
                onClick={fetchStatement}
                className="mt-3 px-4 py-1.5 bg-rose-500 text-white rounded-lg text-xs font-semibold cursor-pointer hover:bg-rose-600"
              >
                Retry
              </button>
            </div>
          ) : statement ? (
            <div ref={printableRef} className="space-y-6">
              {/* Official Document Header */}
              <div className="p-6 bg-slate-950 border border-white/10 rounded-2xl relative overflow-hidden">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 pb-4 border-b border-white/10">
                  <div className="flex items-center gap-3.5">
                    <div className="w-12 h-12 rounded-xl bg-indigo-600 flex items-center justify-center text-white font-black text-xl shadow-lg shadow-indigo-600/30">
                      SIA
                    </div>
                    <div>
                      <h2 className="text-lg font-black text-white tracking-tight">
                        SYGMATE INTERNATIONAL ACADEMY
                      </h2>
                      <p className="text-xs text-slate-400">
                        Office of Finance & Bursar &bull; Student Account Statement
                      </p>
                      <p className="text-[11px] text-slate-400 font-mono">
                        Generated: {new Date(statement.period.generatedAt).toLocaleString()}
                      </p>
                    </div>
                  </div>

                  <div className="text-left md:text-right font-mono text-xs">
                    <p className="text-slate-400 font-sans text-[11px] uppercase tracking-wider font-semibold">
                      Academic Period
                    </p>
                    <p className="font-bold text-indigo-300">{statement.period.sessionName}</p>
                    <p className="text-slate-400 text-[11px]">
                      Ledger Range: {statement.period.startDate || 'Term Start'} &rarr; {statement.period.endDate || 'Current'}
                    </p>
                  </div>
                </div>

                {/* Student & Guardian Info Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 text-xs">
                  <div className="p-3 bg-white/[0.02] border border-white/5 rounded-xl space-y-1">
                    <p className="text-[10px] font-bold text-indigo-400 uppercase tracking-wider flex items-center gap-1">
                      <User className="w-3 h-3" /> Student Profile
                    </p>
                    <p className="text-sm font-bold text-white">{statement.student.name}</p>
                    <div className="grid grid-cols-2 gap-2 text-slate-300 pt-1">
                      <p>
                        <span className="text-slate-400">Admission No:</span>{' '}
                        <strong className="text-white font-mono">{statement.student.admissionNumber}</strong>
                      </p>
                      <p>
                        <span className="text-slate-400">Class & Section:</span>{' '}
                        <strong className="text-white">
                          {statement.student.className} {statement.student.sectionName ? `(${statement.student.sectionName})` : ''}
                        </strong>
                      </p>
                      <p>
                        <span className="text-slate-400">Roll No:</span>{' '}
                        <strong className="text-white font-mono">{statement.student.rollNumber || 'N/A'}</strong>
                      </p>
                      <p>
                        <span className="text-slate-400">Academic Year:</span>{' '}
                        <strong className="text-white">{statement.student.academicSessionName}</strong>
                      </p>
                    </div>
                  </div>

                  <div className="p-3 bg-white/[0.02] border border-white/5 rounded-xl space-y-1">
                    <p className="text-[10px] font-bold text-indigo-400 uppercase tracking-wider flex items-center gap-1">
                      <Building className="w-3 h-3" /> Guardian & Billing Address
                    </p>
                    <p className="text-sm font-bold text-white">{statement.student.guardianName || 'Primary Guardian'}</p>
                    <div className="space-y-0.5 text-slate-300 pt-1">
                      <p>
                        <span className="text-slate-400">Phone:</span>{' '}
                        <span className="text-slate-200">{statement.student.guardianPhone || 'N/A'}</span>
                      </p>
                      <p>
                        <span className="text-slate-400">Email:</span>{' '}
                        <span className="text-slate-200">{statement.student.guardianEmail || 'N/A'}</span>
                      </p>
                      <p className="truncate">
                        <span className="text-slate-400">Address:</span>{' '}
                        <span className="text-slate-200">{statement.student.address || 'Campus Residence'}</span>
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Financial Summary Metric Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
                <div className="p-3.5 bg-slate-950 border border-white/10 rounded-xl space-y-1">
                  <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Total Billed</p>
                  <p className="text-base font-extrabold font-mono text-white">
                    ${Number(statement.summary?.totalBilled ?? 0).toFixed(2)}
                  </p>
                  <p className="text-[10px] text-slate-400">{statement.summary?.invoicesCount ?? 0} Invoices</p>
                </div>

                <div className="p-3.5 bg-slate-950 border border-white/10 rounded-xl space-y-1">
                  <p className="text-[10px] font-bold uppercase tracking-wider text-emerald-400">Concessions</p>
                  <p className="text-base font-extrabold font-mono text-emerald-400">
                    -$
                    {(
                      Number(statement.summary?.totalDiscounts ?? 0) +
                      Number(statement.summary?.totalScholarships ?? 0) +
                      Number(statement.summary?.totalWaivers ?? 0)
                    ).toFixed(2)}
                  </p>
                  <p className="text-[10px] text-emerald-400/80">Discounts & Waivers</p>
                </div>

                <div className="p-3.5 bg-slate-950 border border-white/10 rounded-xl space-y-1">
                  <p className="text-[10px] font-bold uppercase tracking-wider text-rose-400">Late Fines</p>
                  <p className="text-base font-extrabold font-mono text-rose-400">
                    +${Number(statement.summary?.totalFines ?? 0).toFixed(2)}
                  </p>
                  <p className="text-[10px] text-rose-400/80">Overdue Penalties</p>
                </div>

                <div className="p-3.5 bg-slate-950 border border-indigo-500/30 bg-indigo-500/5 rounded-xl space-y-1">
                  <p className="text-[10px] font-bold uppercase tracking-wider text-indigo-300">Net Payable</p>
                  <p className="text-base font-extrabold font-mono text-indigo-300">
                    ${Number(statement.summary?.netPayable ?? 0).toFixed(2)}
                  </p>
                  <p className="text-[10px] text-indigo-300/80">Adjusted Obligation</p>
                </div>

                <div className="p-3.5 bg-slate-950 border border-emerald-500/30 bg-emerald-500/5 rounded-xl space-y-1">
                  <p className="text-[10px] font-bold uppercase tracking-wider text-emerald-300">Total Settled</p>
                  <p className="text-base font-extrabold font-mono text-emerald-300">
                    ${Number(statement.summary?.totalPaid ?? 0).toFixed(2)}
                  </p>
                  <p className="text-[10px] text-emerald-300/80">{statement.summary?.paymentsCount ?? 0} Payments</p>
                </div>

                <div
                  className={`p-3.5 bg-slate-950 border rounded-xl space-y-1 ${
                    (statement.summary?.currentDue ?? 0) > 0
                      ? 'border-amber-500/30 bg-amber-500/5'
                      : 'border-emerald-500/30 bg-emerald-500/5'
                  }`}
                >
                  <p
                    className={`text-[10px] font-bold uppercase tracking-wider ${
                      (statement.summary?.currentDue ?? 0) > 0 ? 'text-amber-400' : 'text-emerald-400'
                    }`}
                  >
                    Current Due
                  </p>
                  <p
                    className={`text-base font-extrabold font-mono ${
                      (statement.summary?.currentDue ?? 0) > 0 ? 'text-amber-300' : 'text-emerald-300'
                    }`}
                  >
                    ${Number(statement.summary?.currentDue ?? 0).toFixed(2)}
                  </p>
                  <p
                    className={`text-[10px] font-bold ${
                      statement.summary.currentDue > 0 ? 'text-amber-400' : 'text-emerald-400'
                    }`}
                  >
                    {statement.summary.currentDue > 0 ? 'Action Required' : 'Account Cleared'}
                  </p>
                </div>
              </div>

              {/* Chronological Financial Ledger Table */}
              <div className="border border-white/10 rounded-2xl overflow-hidden bg-slate-950 shadow-xl">
                <div className="px-5 py-3.5 bg-slate-900 border-b border-white/10 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-indigo-400" />
                    <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                      Chronological Activity Ledger
                    </h4>
                  </div>
                  <span className="text-xs text-slate-400 font-mono">
                    Showing {filteredEntries.length} of {statement.entries?.length || 0} records
                  </span>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="border-b border-white/10 bg-white/[0.02] text-slate-400 font-bold uppercase text-[10px] tracking-wider">
                        <th className="px-4 py-3">Date</th>
                        <th className="px-3 py-3">Reference No</th>
                        <th className="px-3 py-3">Activity Type</th>
                        <th className="px-4 py-3">Description & Particulars</th>
                        <th className="px-3 py-3 text-right">Debit (+)</th>
                        <th className="px-3 py-3 text-right">Credit (-)</th>
                        <th className="px-4 py-3 text-right">Running Balance</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5 text-slate-300 font-sans">
                      {filteredEntries.length === 0 ? (
                        <tr>
                          <td colSpan={7} className="px-4 py-12 text-center text-slate-400">
                            No ledger transactions match the active filter criteria.
                          </td>
                        </tr>
                      ) : (
                        filteredEntries.map((entry) => {
                          const isDebit = entry.debit > 0;
                          const isCredit = entry.credit > 0;
                          const isReversal = entry.type === 'PAYMENT_REVERSED';

                          return (
                            <tr
                              key={entry.id}
                              className={`hover:bg-white/[0.02] transition-colors ${
                                isReversal ? 'bg-rose-500/5' : ''
                              }`}
                            >
                              <td className="px-4 py-3 font-mono text-[11px] text-slate-400 whitespace-nowrap">
                                {new Date(entry.date).toLocaleDateString([], {
                                  year: 'numeric',
                                  month: 'short',
                                  day: '2-digit'
                                })}
                              </td>
                              <td className="px-3 py-3 font-mono font-semibold text-slate-200 whitespace-nowrap">
                                {entry.referenceNo}
                              </td>
                              <td className="px-3 py-3 whitespace-nowrap">
                                <span
                                  className={`px-2 py-0.5 rounded text-[10px] font-bold tracking-wide ${
                                    entry.type === 'INVOICE_GENERATED'
                                      ? 'bg-blue-500/10 text-blue-300 border border-blue-500/20'
                                      : entry.type === 'PAYMENT_RECEIVED'
                                      ? 'bg-emerald-500/10 text-emerald-300 border border-emerald-500/20'
                                      : entry.type === 'PAYMENT_REVERSED'
                                      ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                                      : entry.type === 'FINE_APPLIED'
                                      ? 'bg-rose-500/10 text-rose-300 border border-rose-500/20'
                                      : 'bg-indigo-500/10 text-indigo-300 border border-indigo-500/20'
                                  }`}
                                >
                                  {(entry.type || 'TRANSACTION').replace(/_/g, ' ')}
                                </span>
                              </td>
                              <td className="px-4 py-3">
                                <p className="font-semibold text-slate-200">{entry.description}</p>
                                {entry.feeTitle && (
                                  <p className="text-[11px] text-slate-400">
                                    Head: <span className="text-slate-300">{entry.feeTitle}</span>
                                  </p>
                                )}
                              </td>
                              <td className="px-3 py-3 text-right font-mono font-semibold text-rose-400">
                                {isDebit ? `$${Number(entry.debit ?? 0).toFixed(2)}` : '—'}
                              </td>
                              <td className="px-3 py-3 text-right font-mono font-semibold text-emerald-400">
                                {isCredit ? `-$${Number(entry.credit ?? 0).toFixed(2)}` : '—'}
                              </td>
                              <td
                                className={`px-4 py-3 text-right font-mono font-bold ${
                                  (entry.runningBalance ?? 0) > 0
                                    ? 'text-amber-400'
                                    : entry.runningBalance === 0
                                    ? 'text-emerald-400'
                                    : 'text-indigo-400'
                                }`}
                              >
                                ${Number(entry.runningBalance ?? 0).toFixed(2)}
                              </td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                    <tfoot className="border-t-2 border-white/10 bg-slate-900 font-mono text-xs">
                      <tr>
                        <td colSpan={4} className="px-4 py-3 font-bold text-right text-slate-300">
                          Final Balance Due:
                        </td>
                        <td className="px-3 py-3 text-right font-bold text-rose-400">
                          ${statement.entries.reduce((acc, e) => acc + (e.debit || 0), 0).toFixed(2)}
                        </td>
                        <td className="px-3 py-3 text-right font-bold text-emerald-400">
                          -${statement.entries.reduce((acc, e) => acc + (e.credit || 0), 0).toFixed(2)}
                        </td>
                        <td
                          className={`px-4 py-3 text-right font-black text-sm ${
                            (statement.summary?.currentDue ?? 0) > 0 ? 'text-amber-400' : 'text-emerald-400'
                          }`}
                        >
                          ${Number(statement.summary?.currentDue ?? 0).toFixed(2)}
                        </td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              </div>

              {/* Statement Certification & Disclaimer */}
              <div className="p-4 bg-slate-950/60 border border-white/5 rounded-xl flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-indigo-400 shrink-0" />
                  <p>
                    Verified digital ledger record generated by Sygmate Institutional Finance Subsystem.
                  </p>
                </div>
                <div className="text-right text-[11px]">
                  <p className="font-semibold text-slate-300">Comptroller of Financial Affairs</p>
                  <p className="text-slate-500">Sygmate International Academy</p>
                </div>
              </div>
            </div>
          ) : null}
        </div>

        {/* Bottom Footer */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-white/10 bg-slate-950/80 shrink-0">
          <p className="text-xs text-slate-400">
            For fee reconciliation queries, email <span className="text-indigo-400 font-mono">finance@sygmateschools.edu</span>
          </p>
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-white bg-white/10 hover:bg-white/15 rounded-xl transition-colors cursor-pointer"
          >
            Close Statement
          </button>
        </div>
      </div>
    </div>
  );
};
