import React, { useState, useEffect } from 'react';
import {
  X,
  Bell,
  MessageSquare,
  Mail,
  Send,
  AlertTriangle,
  CheckCircle2,
  Clock,
  User,
  DollarSign,
  FileText,
  Sparkles,
  Info,
  ShieldAlert
} from 'lucide-react';
import {
  FeeDueStudentItem,
  ReminderChannel,
  ReminderType,
  SendFeeReminderPayload
} from '../../types/index.js';
import { api } from '../../services/api.js';
import { useToast } from '../../context/ToastContext.js';

interface SendReminderModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedItems: FeeDueStudentItem[];
  onSuccess: () => void;
}

export const SendReminderModal: React.FC<SendReminderModalProps> = ({
  isOpen,
  onClose,
  selectedItems,
  onSuccess
}) => {
  const { showToast } = useToast();
  const [channel, setChannel] = useState<ReminderChannel>('IN_APP_NOTIFICATION');
  const [reminderType, setReminderType] = useState<ReminderType>('OVERDUE_FIRST_NOTICE');
  const [customTitle, setCustomTitle] = useState<string>('');
  const [customMessage, setCustomMessage] = useState<string>('');
  const [adminNotes, setAdminNotes] = useState<string>('');
  const [isSending, setIsSending] = useState<boolean>(false);

  const totalOutstanding = (selectedItems || []).reduce((acc, item) => acc + item.dueAmount, 0);
  const overdueCount = (selectedItems || []).filter((i) => i.daysOverdue > 0).length;

  // Auto-generate template text when type or selected items change
  useEffect(() => {
    if (!isOpen || !selectedItems || selectedItems.length === 0) return;

    const sample = selectedItems?.[0];
    if (!sample) return;
    const isSingle = selectedItems.length === 1;

    if (reminderType === 'DUE_SOON') {
      setCustomTitle(
        isSingle
          ? `Upcoming Fee Payment Reminder: ${sample.invoiceNumber}`
          : 'Upcoming Term Fee Payment Reminder'
      );
      setCustomMessage(
        isSingle
          ? `Dear Parent/Guardian of ${sample.studentName}, please be reminded that fee invoice #${sample.invoiceNumber} (${sample.feeType}) amounting to $${sample.dueAmount.toFixed(2)} is due on ${sample.dueDate}. Kindly submit payment before the due date.`
          : 'Dear Parent/Guardian, this is a reminder for your upcoming school fee payment due in the coming days. Please visit the portal to complete the payment.'
      );
    } else if (reminderType === 'OVERDUE_FIRST_NOTICE') {
      setCustomTitle(
        isSingle
          ? `OVERDUE NOTICE: Fee Invoice #${sample.invoiceNumber} (${sample.feeType})`
          : 'OVERDUE NOTICE: Outstanding Fee Payment Required'
      );
      setCustomMessage(
        isSingle
          ? `Dear Parent/Guardian of ${sample.studentName}, fee invoice #${sample.invoiceNumber} ($${sample.dueAmount.toFixed(2)}) is overdue by ${sample.daysOverdue} days (Due Date: ${sample.dueDate}). Please settle the outstanding balance promptly to avoid late penalties.`
          : 'Dear Parent/Guardian, our records indicate that your tuition/fee invoice has passed its due date. Please remit the outstanding balance through the school portal at your earliest convenience.'
      );
    } else if (reminderType === 'OVERDUE_SECOND_NOTICE') {
      setCustomTitle(
        isSingle
          ? `SECOND NOTICE: Overdue Balance on #${sample.invoiceNumber}`
          : 'SECOND NOTICE: Urgent Outstanding Fee Settlement'
      );
      setCustomMessage(
        isSingle
          ? `URGENT: Outstanding balance of $${sample.dueAmount.toFixed(2)} for ${sample.studentName} (Invoice #${sample.invoiceNumber}) remains unpaid (${sample.daysOverdue} days past due). Please arrange immediate payment or contact the finance bursar.`
          : 'URGENT: Multiple fee dues remain outstanding on your student account. Please make immediate arrangements for settlement.'
      );
    } else if (reminderType === 'FINAL_DEMAND') {
      setCustomTitle(
        isSingle
          ? `FINAL DEMAND NOTICE: Unpaid Fee Invoice #${sample.invoiceNumber}`
          : 'FINAL DEMAND NOTICE: Immediate Fee Clearance Required'
      );
      setCustomMessage(
        isSingle
          ? `FINAL NOTICE: Fee invoice #${sample.invoiceNumber} for ${sample.studentName} ($${Number(sample.dueAmount ?? 0).toFixed(2)}) is critically overdue (${sample.daysOverdue} days). Continued non-payment may result in academic withholding. Immediate payment required.`
          : 'FINAL NOTICE: Immediate fee clearance is required for your enrolled student(s). Please settle all outstanding invoices immediately.'
      );
    } else {
      setCustomTitle('Official School Fee Account Notice');
      setCustomMessage(
        isSingle
          ? `Dear Guardian, please review the outstanding fee balance of $${Number(sample.dueAmount ?? 0).toFixed(2)} on invoice #${sample.invoiceNumber} for ${sample.studentName}.`
          : 'Dear Guardian, please review the outstanding fee balance on your student account.'
      );
    }
  }, [isOpen, reminderType, selectedItems]);

  if (!isOpen) return null;

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedItems.length === 0) {
      showToast('Please select at least one fee record.', 'error');
      return;
    }

    setIsSending(true);
    try {
      const payload: SendFeeReminderPayload = {
        feeRecordIds: selectedItems.map((i) => i.feeRecordId),
        channel,
        reminderType,
        customTitle: customTitle.trim(),
        customMessage: customMessage.trim(),
        notes: adminNotes.trim()
      };

      const res = await api.fees.sendDueReminders(payload);
      if (res.success) {
        showToast(
          res.message || `Dispatched ${selectedItems.length} fee reminder(s) successfully.`,
          'success'
        );
        onSuccess();
        onClose();
      } else {
        showToast((res as any)?.error || 'Failed to dispatch reminders', 'error');
      }
    } catch (err: any) {
      showToast(err.message || 'Error occurred while sending reminders', 'error');
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div
      id="send-due-reminder-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200"
    >
      <div className="bg-slate-900 border border-white/10 rounded-2xl w-full max-w-2xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="p-5 border-b border-white/10 flex items-center justify-between bg-slate-900/90">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Bell className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                Dispatch Fee Due Reminders
                <span className="text-xs px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  {selectedItems.length} Selected
                </span>
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Send in-app notification alerts and record official follow-up logs
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <form onSubmit={handleSend} className="flex-1 overflow-y-auto p-6 space-y-5">
          {/* Target Summary Strip */}
          <div className="bg-slate-950/60 rounded-xl border border-white/10 p-4 grid grid-cols-3 gap-4 text-center">
            <div>
              <span className="text-[11px] text-slate-400 font-medium uppercase tracking-wider block">
                Target Accounts
              </span>
              <span className="text-base font-bold text-white mt-0.5 block">
                {selectedItems.length} Student{selectedItems.length > 1 ? 's' : ''}
              </span>
            </div>
            <div className="border-x border-white/10">
              <span className="text-[11px] text-slate-400 font-medium uppercase tracking-wider block">
                Total Outstanding
              </span>
              <span className="text-base font-bold text-amber-400 mt-0.5 block">
                ${totalOutstanding.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>
            <div>
              <span className="text-[11px] text-slate-400 font-medium uppercase tracking-wider block">
                Past Due Invoices
              </span>
              <span className="text-base font-bold text-rose-400 mt-0.5 block">
                {overdueCount} Overdue
              </span>
            </div>
          </div>

          {/* Channel Selector */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-slate-300 flex items-center justify-between">
              <span>Notification Dispatch Channel</span>
              <span className="text-[11px] text-indigo-400 font-normal">Real-Time In-App Alert</span>
            </label>
            <div className="grid grid-cols-3 gap-3">
              <button
                type="button"
                onClick={() => setChannel('IN_APP_NOTIFICATION')}
                className={`flex items-center gap-2.5 p-3 rounded-xl border text-left transition-all cursor-pointer ${
                  channel === 'IN_APP_NOTIFICATION'
                    ? 'bg-indigo-600/20 border-indigo-500 text-white shadow-lg shadow-indigo-500/10'
                    : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10'
                }`}
              >
                <Bell className="w-4 h-4 text-indigo-400 shrink-0" />
                <div>
                  <span className="text-xs font-bold block">In-App Alert</span>
                  <span className="text-[10px] text-slate-400 block">Portal Notification</span>
                </div>
              </button>

              <button
                type="button"
                onClick={() => setChannel('EMAIL_PREVIEW')}
                className={`flex items-center gap-2.5 p-3 rounded-xl border text-left transition-all cursor-pointer ${
                  channel === 'EMAIL_PREVIEW'
                    ? 'bg-indigo-600/20 border-indigo-500 text-white shadow-lg shadow-indigo-500/10'
                    : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10'
                }`}
              >
                <Mail className="w-4 h-4 text-emerald-400 shrink-0" />
                <div>
                  <span className="text-xs font-bold block">Email Notice</span>
                  <span className="text-[10px] text-slate-400 block">Electronic statement</span>
                </div>
              </button>

              <button
                type="button"
                onClick={() => setChannel('SMS_PREVIEW')}
                className={`flex items-center gap-2.5 p-3 rounded-xl border text-left transition-all cursor-pointer ${
                  channel === 'SMS_PREVIEW'
                    ? 'bg-indigo-600/20 border-indigo-500 text-white shadow-lg shadow-indigo-500/10'
                    : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10'
                }`}
              >
                <MessageSquare className="w-4 h-4 text-amber-400 shrink-0" />
                <div>
                  <span className="text-xs font-bold block">SMS Dispatch</span>
                  <span className="text-[10px] text-slate-400 block">Mobile text notice</span>
                </div>
              </button>
            </div>
          </div>

          {/* Reminder Notice Type */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-slate-300">Notice Severity & Tone</label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {[
                { id: 'DUE_SOON', label: 'Due Soon', color: 'border-blue-500/40 text-blue-300' },
                { id: 'OVERDUE_FIRST_NOTICE', label: '1st Notice', color: 'border-amber-500/40 text-amber-300' },
                { id: 'OVERDUE_SECOND_NOTICE', label: '2nd Urgent', color: 'border-orange-500/40 text-orange-300' },
                { id: 'FINAL_DEMAND', label: 'Final Demand', color: 'border-rose-500/40 text-rose-300' }
              ].map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => setReminderType(t.id as ReminderType)}
                  className={`py-2 px-3 rounded-xl text-xs font-bold border transition-all cursor-pointer text-center ${
                    reminderType === t.id
                      ? 'bg-white/15 border-white text-white shadow-sm'
                      : `bg-slate-950/40 ${t.color} hover:bg-white/5`
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>
          </div>

          {/* Subject / Title */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-300">Notification Subject / Title</label>
            <input
              type="text"
              value={customTitle}
              onChange={(e) => setCustomTitle(e.target.value)}
              required
              className="w-full bg-slate-950/70 border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-indigo-500"
              placeholder="Enter reminder headline..."
            />
          </div>

          {/* Message Body */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-300">Message Content</label>
            <textarea
              value={customMessage}
              onChange={(e) => setCustomMessage(e.target.value)}
              required
              rows={3}
              className="w-full bg-slate-950/70 border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-indigo-500 leading-relaxed"
              placeholder="Write the message text..."
            />
          </div>

          {/* Admin Internal Log Notes */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-400">
              Audit Notes <span className="text-[11px] font-normal text-slate-500">(Optional internal note)</span>
            </label>
            <input
              type="text"
              value={adminNotes}
              onChange={(e) => setAdminNotes(e.target.value)}
              className="w-full bg-slate-950/70 border border-white/10 rounded-xl px-3.5 py-2 text-xs text-slate-300 placeholder:text-slate-600 focus:outline-none focus:border-indigo-500"
              placeholder="e.g., Routine monthly overdue reminder cycle dispatched by Bursar Office"
            />
          </div>

          {/* Preview Box */}
          <div className="bg-indigo-950/20 border border-indigo-500/20 rounded-xl p-3.5 flex items-start gap-3">
            <Info className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
            <div className="text-xs text-slate-300 space-y-1">
              <span className="font-semibold text-indigo-300 block">Dispatch Confirmation:</span>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                This action will instantly post in-app alert notifications directly to the student and linked guardian portal dashboards, record a formal timestamp in the reminder audit ledger, and notify parents of their balance.
              </p>
            </div>
          </div>

          {/* Modal Footer */}
          <div className="pt-2 flex items-center justify-end gap-3 border-t border-white/10">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white rounded-xl transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSending}
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl shadow-lg shadow-indigo-600/30 transition-all cursor-pointer disabled:opacity-50"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{isSending ? 'Dispatching...' : `Dispatch to ${selectedItems.length} Account(s)`}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
