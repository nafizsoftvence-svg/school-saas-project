import React, { useState } from 'react';
import { X, AlertTriangle, DollarSign } from 'lucide-react';
import { StudentFeeRecord } from '../../types/index.js';
import { api } from '../../services/api.js';
import { useToast } from '../../context/ToastContext.js';

interface ApplyFineModalProps {
  isOpen: boolean;
  onClose: () => void;
  feeRecord: StudentFeeRecord | null;
  onSuccess: (updated: StudentFeeRecord) => void;
}

export const ApplyFineModal: React.FC<ApplyFineModalProps> = ({
  isOpen,
  onClose,
  feeRecord,
  onSuccess
}) => {
  const { showToast } = useToast();
  const [fineAmount, setFineAmount] = useState<string>(
    feeRecord?.fineAmount ? feeRecord.fineAmount.toString() : '0'
  );
  const [fineReason, setFineReason] = useState<string>(
    feeRecord?.fineReason || ''
  );
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  React.useEffect(() => {
    if (feeRecord) {
      setFineAmount(feeRecord.fineAmount ? feeRecord.fineAmount.toString() : '0');
      setFineReason(feeRecord.fineReason || '');
    }
  }, [feeRecord]);

  if (!isOpen || !feeRecord) return null;

  const parsedFine = parseFloat(fineAmount) || 0;
  const projectedNetPayable = Math.max(0, feeRecord.totalAmount - feeRecord.discountAmount + parsedFine);
  const projectedRemainingDue = Math.max(0, projectedNetPayable - feeRecord.paidAmount);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (isNaN(parsedFine) || parsedFine < 0) {
      showToast('Fine amount must be a positive number or zero.', 'error');
      return;
    }

    setIsSubmitting(true);
    try {
      const updated = await api.fees.applyFine(feeRecord.id, {
        fineAmount: parsedFine,
        fineReason: fineReason.trim() || undefined
      });
      showToast(`Successfully updated fine on invoice ${feeRecord.invoiceNumber}.`, 'success');
      onSuccess(updated);
      onClose();
    } catch (err: any) {
      showToast(err.message || 'Failed to adjust fine.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="relative w-full max-w-md bg-slate-900 border border-white/15 rounded-2xl shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 bg-slate-950/70">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-rose-500/15 border border-rose-500/30 flex items-center justify-center text-rose-400">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">Adjust Late Fine / Charge</h3>
              <p className="text-[11px] text-slate-400">Invoice: {feeRecord.invoiceNumber}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-white/10 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {/* Target Student Info */}
          <div className="p-3 bg-white/[0.02] border border-white/10 rounded-xl text-xs space-y-1">
            <p className="font-bold text-white">{feeRecord.studentName}</p>
            <p className="text-slate-400">
              {feeRecord.className} &bull; {feeRecord.title} &bull; Due Date: {feeRecord.dueDate}
            </p>
          </div>

          {/* Fine Amount */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              Fine / Surcharge Amount ($) *
            </label>
            <div className="relative">
              <DollarSign className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
              <input
                type="number"
                min="0"
                step="0.01"
                value={fineAmount}
                onChange={(e) => setFineAmount(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-xs bg-slate-950 border border-white/15 rounded-xl text-white font-mono focus:outline-none focus:border-rose-500"
                required
              />
            </div>
          </div>

          {/* Fine Reason */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">
              Fine Description / Reason (Optional)
            </label>
            <textarea
              rows={2}
              placeholder="e.g., Overdue penalty past 30 days / Library book damage charge"
              value={fineReason}
              onChange={(e) => setFineReason(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-950 border border-white/15 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-rose-500 resize-none"
            />
          </div>

          {/* Live Financial Projection Card */}
          <div className="p-3.5 bg-slate-950/80 border border-white/10 rounded-xl space-y-2 text-xs">
            <p className="font-bold text-slate-300 uppercase tracking-wider text-[10px]">
              Financial Impact Preview
            </p>
            <div className="flex justify-between text-slate-300">
              <span>Gross Base Fee:</span>
              <span className="font-mono text-slate-200">${Number(feeRecord.totalAmount ?? 0).toFixed(2)}</span>
            </div>
            {Number(feeRecord.discountAmount ?? 0) > 0 && (
              <div className="flex justify-between text-emerald-400">
                <span>Discount:</span>
                <span className="font-mono">-${Number(feeRecord.discountAmount ?? 0).toFixed(2)}</span>
              </div>
            )}
            <div className="flex justify-between text-rose-400 font-semibold">
              <span>Late Fine:</span>
              <span className="font-mono">+${Number(parsedFine ?? 0).toFixed(2)}</span>
            </div>
            <div className="pt-2 border-t border-white/10 flex justify-between font-bold text-white">
              <span>New Net Payable:</span>
              <span className="font-mono text-indigo-300">${Number(projectedNetPayable ?? 0).toFixed(2)}</span>
            </div>
            <div className="flex justify-between font-bold">
              <span className="text-slate-300">New Balance Due:</span>
              <span className="font-mono text-amber-400">${Number(projectedRemainingDue ?? 0).toFixed(2)}</span>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white bg-white/5 hover:bg-white/10 rounded-xl transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="inline-flex items-center gap-2 px-5 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-500 rounded-xl shadow-lg shadow-rose-600/30 transition-all disabled:opacity-50 cursor-pointer"
            >
              {isSubmitting ? 'Saving...' : 'Save Fine Adjustment'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
