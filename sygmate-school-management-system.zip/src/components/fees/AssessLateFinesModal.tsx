import React, { useState } from 'react';
import { X, AlertTriangle, Play, CheckCircle2, Eye, ShieldAlert, Sparkles } from 'lucide-react';
import {
  FeeFineRule,
  AssessLateFinesPayload,
  AssessLateFinesResponse,
  AcademicSession
} from '../../types/index.js';
import { api } from '../../services/api.js';
import { useToast } from '../../context/ToastContext.js';

interface AssessLateFinesModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (result: AssessLateFinesResponse['data']) => void;
  fineRules: FeeFineRule[];
  sessions: AcademicSession[];
}

export const AssessLateFinesModal: React.FC<AssessLateFinesModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  fineRules,
  sessions
}) => {
  const { showToast } = useToast();

  const [selectedRuleId, setSelectedRuleId] = useState<string>(fineRules?.[0]?.id || '');
  const [selectedSessionId, setSelectedSessionId] = useState<string>(sessions?.[0]?.id || '');
  const [assessmentDate, setAssessmentDate] = useState<string>(new Date().toISOString().slice(0, 10));

  const [isRunningDryRun, setIsRunningDryRun] = useState<boolean>(false);
  const [isRunningCommit, setIsRunningCommit] = useState<boolean>(false);
  const [previewResult, setPreviewResult] = useState<AssessLateFinesResponse['data'] | null>(null);

  if (!isOpen) return null;

  const handleDryRun = async () => {
    setIsRunningDryRun(true);
    try {
      const payload: AssessLateFinesPayload = {
        fineRuleId: selectedRuleId || undefined,
        academicSessionId: selectedSessionId || undefined,
        assessmentDate,
        dryRun: true
      };
      const res = await api.fees.assessLateFines(payload);
      if (res.success && res.data) {
        setPreviewResult(res.data);
        showToast(
          `Dry run: ${res.data.evaluatedCount} overdue invoices found. Potential fine: $${res.data.totalFineAssessed.toFixed(2)}`,
          'info'
        );
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to simulate late assessment', 'error');
    } finally {
      setIsRunningDryRun(false);
    }
  };

  const handleCommitAssessment = async () => {
    setIsRunningCommit(true);
    try {
      const payload: AssessLateFinesPayload = {
        fineRuleId: selectedRuleId || undefined,
        academicSessionId: selectedSessionId || undefined,
        assessmentDate,
        dryRun: false
      };
      const res = await api.fees.assessLateFines(payload);
      if (res.success && res.data) {
        showToast(
          `Successfully applied late fines to ${res.data.evaluatedCount} invoice(s)! Total: $${res.data.totalFineAssessed.toFixed(2)}`,
          'success'
        );
        onSuccess(res.data);
        onClose();
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to assess and apply late fines', 'error');
    } finally {
      setIsRunningCommit(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto"
      onClick={(e) => {
        if (e.target === e.currentTarget && !isRunningCommit && !isRunningDryRun) onClose();
      }}
    >
      <div className="relative w-full max-w-2xl bg-slate-900 border border-white/15 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 bg-slate-950/70">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-rose-500/15 border border-rose-500/30 flex items-center justify-center text-rose-400">
              <Play className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Automated Late Fee Assessment Engine</h3>
              <p className="text-xs text-slate-400">
                Scan overdue student fees beyond grace period and levy late penalties
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Configuration Body */}
        <div className="p-6 space-y-5 max-h-[80vh] overflow-y-auto">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Select Policy Rule</label>
              <select
                value={selectedRuleId}
                onChange={(e) => setSelectedRuleId(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-950 border border-white/10 rounded-xl text-white focus:outline-none focus:border-rose-500"
              >
                <option value="">Default Active Rule</option>
                {fineRules
                  .filter((r) => r.status === 'ACTIVE')
                  .map((r) => (
                    <option key={r.id} value={r.id}>
                      {r.ruleName} ({r.fineType} - ${r.amount})
                    </option>
                  ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Academic Session</label>
              <select
                value={selectedSessionId}
                onChange={(e) => setSelectedSessionId(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-950 border border-white/10 rounded-xl text-white focus:outline-none focus:border-rose-500"
              >
                <option value="">All Sessions</option>
                {sessions.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Assessment Date</label>
              <input
                type="date"
                value={assessmentDate}
                onChange={(e) => setAssessmentDate(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-950 border border-white/10 rounded-xl text-white focus:outline-none focus:border-rose-500"
              />
            </div>
          </div>

          {/* Action Row for Simulation */}
          <div className="flex items-center justify-between p-4 bg-white/5 border border-white/10 rounded-xl">
            <div className="text-xs">
              <span className="font-bold text-white">Simulate Calculation (Dry Run)</span>
              <p className="text-[11px] text-slate-400">
                Safely calculate all overdue invoices without making permanent database modifications.
              </p>
            </div>
            <button
              type="button"
              onClick={handleDryRun}
              disabled={isRunningDryRun || isRunningCommit}
              className="px-4 py-2 text-xs font-bold text-slate-200 bg-white/10 hover:bg-white/20 disabled:opacity-50 rounded-xl transition-all flex items-center gap-2 cursor-pointer"
            >
              {isRunningDryRun ? (
                <span>Simulating...</span>
              ) : (
                <>
                  <Eye className="w-4 h-4 text-cyan-400" />
                  <span>Run Preview Simulation</span>
                </>
              )}
            </button>
          </div>

          {/* Preview Results Table */}
          {previewResult && (
            <div className="space-y-3 p-4 bg-slate-950/80 border border-white/10 rounded-xl">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                    Assessment Preview Summary
                  </h4>
                  <p className="text-[11px] text-slate-400">
                    Policy: <span className="text-white">{previewResult.ruleApplied.ruleName}</span> | Grace Period:{' '}
                    <span className="text-white">{previewResult.ruleApplied.gracePeriodDays} days</span>
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-[11px] text-slate-400">Total Fines</p>
                  <p className="font-mono text-base font-bold text-rose-400">
                    ${previewResult.totalFineAssessed.toFixed(2)}
                  </p>
                </div>
              </div>

              {(previewResult?.assessedFines?.length || 0) === 0 ? (
                <div className="p-4 text-center text-xs text-slate-400 bg-white/5 rounded-lg">
                  No unpaid invoices are currently past the grace period cutoff date.
                </div>
              ) : (
                <div className="max-h-48 overflow-y-auto space-y-1.5 pr-1">
                  {previewResult.assessedFines.map((f) => (
                    <div
                      key={f.id}
                      className="p-2.5 bg-white/5 border border-white/5 rounded-lg text-xs flex items-center justify-between"
                    >
                      <div>
                        <p className="font-semibold text-white">{f.studentName}</p>
                        <p className="text-[10px] text-slate-400">
                          {f.invoiceNumber} • {f.className} • Overdue:{' '}
                          <span className="text-rose-300 font-bold">{f.daysOverdue} days</span>
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="font-mono font-bold text-rose-400">+${f.amount.toFixed(2)}</p>
                        <p className="text-[10px] text-slate-400">New Due: ${f.newDueAmount.toFixed(2)}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Execution Warning */}
          <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-xs text-rose-300 flex items-start gap-2.5">
            <ShieldAlert className="w-4 h-4 text-rose-400 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-rose-200">Enforcement Notice</p>
              <p className="text-[11px] text-rose-300/80 mt-0.5">
                Executing the assessment will immediately apply fines to the affected invoices and log immutable
                audit records. All guardian and student portal views will reflect the updated balances.
              </p>
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-bold text-slate-400 hover:text-white bg-white/5 hover:bg-white/10 rounded-xl transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleCommitAssessment}
              disabled={isRunningCommit || isRunningDryRun}
              className="px-5 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-500 disabled:opacity-50 rounded-xl shadow-lg shadow-rose-600/20 transition-all cursor-pointer flex items-center gap-2"
            >
              {isRunningCommit ? (
                <span>Executing Assessment...</span>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Execute Assessment & Apply Fines</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
