import React, { useState, useEffect } from 'react';
import { X, Award, DollarSign, Percent, Calendar, CheckCircle2, User, Sparkles } from 'lucide-react';
import {
  FeeScholarship,
  CreateScholarshipPayload,
  AcademicSession,
  FeeType
} from '../../types/index.js';
import { api } from '../../services/api.js';
import { useToast } from '../../context/ToastContext.js';

interface GrantScholarshipModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (newScholarship: FeeScholarship) => void;
  scholarshipToEdit?: FeeScholarship | null;
  sessions: AcademicSession[];
  feeTypes: FeeType[];
}

export const GrantScholarshipModal: React.FC<GrantScholarshipModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  scholarshipToEdit,
  sessions,
  feeTypes
}) => {
  const { showToast } = useToast();

  const [studentSearch, setStudentSearch] = useState('');
  const [students, setStudents] = useState<any[]>([]);
  const [selectedStudent, setSelectedStudent] = useState<any | null>(null);

  const [scholarshipName, setScholarshipName] = useState('');
  const [scholarshipType, setScholarshipType] = useState<
    'MERIT' | 'NEED_BASED' | 'SPORTS' | 'SPECIAL_TALENT' | 'GOVERNMENT_ENDOWMENT'
  >('MERIT');
  const [coverageType, setCoverageType] = useState<'PERCENTAGE' | 'FIXED_AMOUNT'>('PERCENTAGE');
  const [value, setValue] = useState<string>('50');
  const [academicSessionId, setAcademicSessionId] = useState('');
  const [applicableFeeType, setApplicableFeeType] = useState('ALL');
  const [sponsorName, setSponsorName] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [description, setDescription] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (isOpen) {
      if (scholarshipToEdit) {
        setScholarshipName(scholarshipToEdit.scholarshipName);
        setScholarshipType(scholarshipToEdit.scholarshipType);
        setCoverageType(scholarshipToEdit.coverageType);
        setValue(scholarshipToEdit.value.toString());
        setAcademicSessionId(scholarshipToEdit.academicSessionId);
        setApplicableFeeType(scholarshipToEdit.applicableFeeType || 'ALL');
        setSponsorName(scholarshipToEdit.sponsorName || '');
        setStartDate(scholarshipToEdit.startDate);
        setEndDate(scholarshipToEdit.endDate);
        setDescription(scholarshipToEdit.description || '');
        setSelectedStudent({
          id: scholarshipToEdit.studentId,
          fullName: scholarshipToEdit.studentName,
          admissionNumber: scholarshipToEdit.admissionNumber,
          className: scholarshipToEdit.className
        });
      } else {
        setScholarshipName('Academic Excellence Merit Grant');
        setScholarshipType('MERIT');
        setCoverageType('PERCENTAGE');
        setValue('50');
        setAcademicSessionId(sessions?.[0]?.id || 'session-2026-2027');
        setApplicableFeeType('ALL');
        setSponsorName('Sygmate Board of Trustees');
        setStartDate(new Date().toISOString().slice(0, 10));
        setEndDate('2027-06-30');
        setDescription('');
        setSelectedStudent(null);
      }

      api.users
        .getStudents({ limit: 100 })
        .then((res: any) => {
          if (res?.data?.students) setStudents(res.data.students);
          else if (Array.isArray(res?.data)) setStudents(res.data);
        })
        .catch(() => {});
    }
  }, [isOpen, scholarshipToEdit, sessions]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStudent) {
      showToast('Please select a recipient student', 'error');
      return;
    }

    if (!scholarshipName.trim()) {
      showToast('Please specify the scholarship name', 'error');
      return;
    }

    const numVal = parseFloat(value);
    if (isNaN(numVal) || numVal <= 0) {
      showToast('Please enter a valid scholarship value', 'error');
      return;
    }

    if (coverageType === 'PERCENTAGE' && numVal > 100) {
      showToast('Percentage coverage cannot exceed 100%', 'error');
      return;
    }

    setIsSubmitting(true);
    try {
      if (scholarshipToEdit) {
        const res = await api.fees.updateScholarship(scholarshipToEdit.id, {
          scholarshipName: scholarshipName.trim(),
          scholarshipType,
          coverageType,
          value: numVal,
          academicSessionId,
          applicableFeeType,
          sponsorName: sponsorName.trim() || undefined,
          startDate,
          endDate,
          description: description.trim() || undefined
        });
        if (res.success && res.data) {
          showToast(`Scholarship ${res.data.scholarshipName} updated successfully`, 'success');
          onSuccess(res.data);
          onClose();
        }
      } else {
        const payload: CreateScholarshipPayload = {
          studentId: selectedStudent.id,
          scholarshipName: scholarshipName.trim(),
          scholarshipType,
          coverageType,
          value: numVal,
          academicSessionId,
          applicableFeeType,
          sponsorName: sponsorName.trim() || undefined,
          startDate,
          endDate,
          description: description.trim() || undefined
        };
        const res = await api.fees.createScholarship(payload);
        if (res.success && res.data) {
          showToast(`Scholarship awarded to ${selectedStudent.fullName}`, 'success');
          onSuccess(res.data);
          onClose();
        }
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to save scholarship grant', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const filteredStudents = studentSearch
    ? students.filter(
        (s) =>
          s.fullName?.toLowerCase().includes(studentSearch.toLowerCase()) ||
          s.admissionNumber?.toLowerCase().includes(studentSearch.toLowerCase())
      )
    : students.slice(0, 6);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto"
      onClick={(e) => {
        if (e.target === e.currentTarget && !isSubmitting) onClose();
      }}
    >
      <div className="relative w-full max-w-xl bg-slate-900 border border-white/15 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 bg-slate-950/70">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">
                {scholarshipToEdit ? 'Edit Scholarship Award' : 'Grant Student Scholarship'}
              </h3>
              <p className="text-xs text-slate-400">Award merit grants, endowments & need-based funding</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto">
          {/* Step 1: Select Student */}
          {!scholarshipToEdit ? (
            <div className="space-y-2">
              <label className="block text-xs font-semibold text-slate-300">
                1. Select Beneficiary Student <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                value={studentSearch}
                onChange={(e) => setStudentSearch(e.target.value)}
                placeholder="Search student by name or admission number..."
                className="w-full px-3 py-2 text-xs bg-slate-950 border border-white/10 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
              />
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-28 overflow-y-auto">
                {filteredStudents.map((st) => (
                  <button
                    key={st.id}
                    type="button"
                    onClick={() => setSelectedStudent(st)}
                    className={`text-left p-2.5 rounded-xl border text-xs transition-colors flex items-center justify-between ${
                      selectedStudent?.id === st.id
                        ? 'bg-amber-500/20 text-amber-300 border-amber-500/50 font-bold'
                        : 'bg-white/5 text-slate-300 border-white/10 hover:bg-white/10'
                    }`}
                  >
                    <div>
                      <p className="font-semibold text-white">{st.fullName}</p>
                      <p className="text-[10px] text-slate-400">{st.admissionNumber || st.className}</p>
                    </div>
                    {selectedStudent?.id === st.id && <CheckCircle2 className="w-4 h-4 text-amber-400" />}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="p-3 bg-white/5 border border-white/10 rounded-xl flex items-center justify-between">
              <div>
                <p className="text-xs text-slate-400">Awarded To</p>
                <p className="text-sm font-bold text-white">{scholarshipToEdit.studentName}</p>
              </div>
              <span className="px-2 py-0.5 rounded text-[11px] font-mono text-amber-400 bg-amber-500/10 border border-amber-500/30">
                {scholarshipToEdit.admissionNumber}
              </span>
            </div>
          )}

          {/* Scholarship Title & Category */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Scholarship Name <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                value={scholarshipName}
                onChange={(e) => setScholarshipName(e.target.value)}
                placeholder="e.g. Merit Honors 50%"
                required
                className="w-full px-3 py-2 text-xs bg-slate-950 border border-white/10 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Scholarship Type</label>
              <select
                value={scholarshipType}
                onChange={(e: any) => setScholarshipType(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-950 border border-white/10 rounded-xl text-white focus:outline-none focus:border-amber-500"
              >
                <option value="MERIT">Merit / Academic Ranking</option>
                <option value="NEED_BASED">Need-Based Financial Aid</option>
                <option value="SPORTS">Sports & Athletics Honor</option>
                <option value="SPECIAL_TALENT">Creative Arts & Special Talent</option>
                <option value="GOVERNMENT_ENDOWMENT">Government / Corporate Endowment</option>
              </select>
            </div>
          </div>

          {/* Coverage & Value */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3 bg-white/5 border border-white/10 rounded-xl">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Coverage Formula</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setCoverageType('PERCENTAGE')}
                  className={`px-3 py-2 text-xs font-bold rounded-lg border transition-all flex items-center justify-center gap-1.5 ${
                    coverageType === 'PERCENTAGE'
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500/50 shadow-sm shadow-amber-500/20'
                      : 'bg-slate-950 text-slate-400 border-white/10 hover:border-white/20'
                  }`}
                >
                  <Percent className="w-3.5 h-3.5" /> Percentage (%)
                </button>
                <button
                  type="button"
                  onClick={() => setCoverageType('FIXED_AMOUNT')}
                  className={`px-3 py-2 text-xs font-bold rounded-lg border transition-all flex items-center justify-center gap-1.5 ${
                    coverageType === 'FIXED_AMOUNT'
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500/50 shadow-sm shadow-amber-500/20'
                      : 'bg-slate-950 text-slate-400 border-white/10 hover:border-white/20'
                  }`}
                >
                  <DollarSign className="w-3.5 h-3.5" /> Fixed ($)
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Coverage Value <span className="text-rose-400">*</span>
              </label>
              <div className="relative">
                <span className="absolute left-3 top-2.5 text-xs text-slate-400">
                  {coverageType === 'PERCENTAGE' ? '%' : '$'}
                </span>
                <input
                  type="number"
                  step="0.01"
                  min="0.01"
                  max={coverageType === 'PERCENTAGE' ? '100' : undefined}
                  value={value}
                  onChange={(e) => setValue(e.target.value)}
                  placeholder="50"
                  required
                  className="w-full pl-8 pr-3 py-2 text-xs font-mono font-bold bg-slate-950 border border-white/10 rounded-xl text-amber-300 focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>
          </div>

          {/* Sponsor & Applicable Fee Category */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Sponsor / Foundation Name</label>
              <input
                type="text"
                value={sponsorName}
                onChange={(e) => setSponsorName(e.target.value)}
                placeholder="e.g. Sygmate Alumni Memorial Trust"
                className="w-full px-3 py-2 text-xs bg-slate-950 border border-white/10 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Applicable Fee Category</label>
              <select
                value={applicableFeeType}
                onChange={(e) => setApplicableFeeType(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-950 border border-white/10 rounded-xl text-white focus:outline-none focus:border-amber-500"
              >
                <option value="ALL">All Applicable Fee Types</option>
                {feeTypes.map((ft) => (
                  <option key={ft.id} value={ft.name}>
                    {ft.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Academic Session & Validity Dates */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Session</label>
              <select
                value={academicSessionId}
                onChange={(e) => setAcademicSessionId(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-950 border border-white/10 rounded-xl text-white focus:outline-none focus:border-amber-500"
              >
                {sessions.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Effective Start</label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-950 border border-white/10 rounded-xl text-white focus:outline-none focus:border-amber-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Effective End</label>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-950 border border-white/10 rounded-xl text-white focus:outline-none focus:border-amber-500"
              />
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">Grant Citation & Terms</label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="e.g. Awarded for securing 1st rank in annual science Olympiad..."
              className="w-full px-3 py-2 text-xs bg-slate-950 border border-white/10 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
            />
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-bold text-slate-400 hover:text-white bg-white/5 hover:bg-white/10 rounded-xl transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting || !selectedStudent}
              className="px-5 py-2 text-xs font-bold text-white bg-amber-600 hover:bg-amber-500 disabled:opacity-50 rounded-xl shadow-lg shadow-amber-600/20 transition-all cursor-pointer flex items-center gap-2"
            >
              {isSubmitting ? (
                <span>Saving Scholarship...</span>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{scholarshipToEdit ? 'Update Scholarship' : 'Award Scholarship'}</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
