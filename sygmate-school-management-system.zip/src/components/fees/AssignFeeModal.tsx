import React, { useState, useEffect } from 'react';
import {
  X,
  Plus,
  Users,
  User,
  GraduationCap,
  Calendar,
  AlertTriangle,
  CheckCircle2,
  Coins,
  ArrowRight,
  Info,
  DollarSign,
  Search
} from 'lucide-react';
import {
  AcademicSession,
  SchoolClass,
  Section,
  StudentProfile,
  FeeStructure,
  ApplicableFeeStructureItem,
  AssignStudentFeePayload,
  AssignStudentFeeResponse
} from '../../types/index.js';
import { api } from '../../services/api.js';
import { useToast } from '../../context/ToastContext.js';

interface AssignFeeModalProps {
  isOpen: boolean;
  onClose: () => void;
  sessions: AcademicSession[];
  classes: SchoolClass[];
  onSuccess: (result: AssignStudentFeeResponse) => void;
}

export const AssignFeeModal: React.FC<AssignFeeModalProps> = ({
  isOpen,
  onClose,
  sessions,
  classes,
  onSuccess
}) => {
  const { showToast } = useToast();

  const [assignmentType, setAssignmentType] = useState<'INDIVIDUAL' | 'CLASS' | 'SECTION'>('CLASS');
  const [selectedSessionId, setSelectedSessionId] = useState<string>('');
  const [selectedClassId, setSelectedClassId] = useState<string>('');
  const [selectedSectionId, setSelectedSectionId] = useState<string>('');
  const [selectedStudentId, setSelectedStudentId] = useState<string>('');

  // Sections of selected class
  const [availableSections, setAvailableSections] = useState<Section[]>([]);
  // Students of selected class/section
  const [availableStudents, setAvailableStudents] = useState<Array<{ id: string; name: string; admissionNumber?: string; rollNumber?: string }>>([]);
  const [studentSearchQuery, setStudentSearchQuery] = useState<string>('');

  // Applicable Fee Structures preview
  const [applicableItems, setApplicableItems] = useState<ApplicableFeeStructureItem[]>([]);
  const [selectedStructureIds, setSelectedStructureIds] = useState<string[]>([]);
  const [autoDetermine, setAutoDetermine] = useState<boolean>(true);
  const [isLoadingStructures, setIsLoadingStructures] = useState<boolean>(false);

  // Custom Options
  const [customDueDate, setCustomDueDate] = useState<string>('');
  const [discountAmount, setDiscountAmount] = useState<string>('');
  const [discountReason, setDiscountReason] = useState<string>('');
  const [notes, setNotes] = useState<string>('');

  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Initialize active session & class
  useEffect(() => {
    if (isOpen) {
      const activeSession = (sessions || []).find((s) => s.status === 'ACTIVE') || sessions?.[0];
      if (activeSession) {
        setSelectedSessionId(activeSession.id);
      }
      if (classes && classes.length > 0) {
        setSelectedClassId(classes?.[0]?.id || '');
      }
    }
  }, [isOpen, sessions, classes]);

  // Load sections when class changes
  useEffect(() => {
    if (!selectedClassId) {
      setAvailableSections([]);
      setSelectedSectionId('');
      return;
    }
    const currentCls = (classes || []).find((c) => c.id === selectedClassId);
    if (currentCls && Array.isArray(currentCls.sections)) {
      setAvailableSections(currentCls.sections);
      if (currentCls.sections.length > 0) {
        setSelectedSectionId(currentCls.sections?.[0]?.id || '');
      } else {
        setSelectedSectionId('');
      }
    } else {
      setAvailableSections([]);
      setSelectedSectionId('');
    }
  }, [selectedClassId, classes]);

  // Load students for Individual scope
  useEffect(() => {
    if (assignmentType !== 'INDIVIDUAL' || !selectedClassId) {
      setAvailableStudents([]);
      setSelectedStudentId('');
      return;
    }

    const fetchStudents = async () => {
      try {
        const res = await api.getStudents({
          classId: selectedClassId,
          sectionId: selectedSectionId || undefined
        });
        const studentList = res?.data || (Array.isArray(res) ? res : []);
        if (studentList && studentList.length > 0) {
          const formatted = studentList.map((s: any) => ({
            id: s.profile?.id || s.id,
            name: s.name,
            admissionNumber: s.profile?.admissionNumber,
            rollNumber: s.profile?.rollNumber
          }));
          setAvailableStudents(formatted);
          if (formatted && formatted.length > 0) {
            setSelectedStudentId(formatted?.[0]?.id || '');
          }
        } else {
          setAvailableStudents([]);
          setSelectedStudentId('');
        }
      } catch (err) {
        console.error('Failed to load students for fee assignment', err);
      }
    };

    fetchStudents();
  }, [assignmentType, selectedClassId, selectedSectionId]);

  // Load applicable fee structures whenever session/class/section/student changes
  useEffect(() => {
    if (!selectedSessionId || !selectedClassId) {
      setApplicableItems([]);
      setSelectedStructureIds([]);
      return;
    }

    const fetchStructures = async () => {
      setIsLoadingStructures(true);
      try {
        const res = await api.fees.getApplicableStructures({
          academicSessionId: selectedSessionId,
          classId: selectedClassId,
          sectionId: selectedSectionId || undefined,
          studentId: assignmentType === 'INDIVIDUAL' ? selectedStudentId : undefined
        });
        const rawItems = (res as any)?.data ?? res;
        const items: ApplicableFeeStructureItem[] = Array.isArray(rawItems)
          ? rawItems
          : Array.isArray((rawItems as any)?.items)
          ? (rawItems as any).items
          : [];
        setApplicableItems(items);
        // By default select all unassigned structures
        const unassignedIds = items
          .filter((item: ApplicableFeeStructureItem) => !item.isAlreadyAssigned)
          .map((item: ApplicableFeeStructureItem) => item.structure.id);
        setSelectedStructureIds(unassignedIds);
      } catch (err) {
        console.error('Failed to fetch applicable fee structures', err);
      } finally {
        setIsLoadingStructures(false);
      }
    };

    fetchStructures();
  }, [selectedSessionId, selectedClassId, selectedSectionId, selectedStudentId, assignmentType]);

  if (!isOpen) return null;

  const filteredStudents = (Array.isArray(availableStudents) ? availableStudents : []).filter(
    (s) =>
      (s.name || '').toLowerCase().includes((studentSearchQuery || '').toLowerCase()) ||
      (s.admissionNumber ? s.admissionNumber.toLowerCase().includes((studentSearchQuery || '').toLowerCase()) : false)
  );

  const toggleStructureSelection = (id: string) => {
    setSelectedStructureIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleSelectAllStructures = () => {
    const safeApplicableItems = Array.isArray(applicableItems) ? applicableItems : [];
    const unassigned = safeApplicableItems
      .filter((i) => !i.isAlreadyAssigned)
      .map((i) => i.structure.id);
    if (selectedStructureIds.length === unassigned.length) {
      setSelectedStructureIds([]);
    } else {
      setSelectedStructureIds(unassigned);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!selectedSessionId) {
      showToast('Please select an Academic Session.', 'error');
      return;
    }
    if (!selectedClassId) {
      showToast('Please select a Class.', 'error');
      return;
    }
    if (assignmentType === 'SECTION' && !selectedSectionId) {
      showToast('Please select a Section for Section assignment.', 'error');
      return;
    }
    if (assignmentType === 'INDIVIDUAL' && !selectedStudentId) {
      showToast('Please select a Student for Individual fee assignment.', 'error');
      return;
    }
    if (selectedStructureIds.length === 0) {
      showToast('Please select at least one fee structure to assign.', 'error');
      return;
    }

    const parsedDiscount = discountAmount ? parseFloat(discountAmount) : 0;
    if (isNaN(parsedDiscount) || parsedDiscount < 0) {
      showToast('Discount amount must be a non-negative number.', 'error');
      return;
    }

    setIsSubmitting(true);
    try {
      const payload: AssignStudentFeePayload = {
        assignmentType,
        academicSessionId: selectedSessionId,
        classId: selectedClassId,
        sectionId: selectedSectionId || undefined,
        studentId: assignmentType === 'INDIVIDUAL' ? selectedStudentId : undefined,
        feeStructureIds: selectedStructureIds,
        autoDetermineApplicable: false,
        customDueDate: customDueDate || undefined,
        discountAmount: parsedDiscount > 0 ? parsedDiscount : undefined,
        discountReason: parsedDiscount > 0 ? discountReason || 'Admin Assigned Discount' : undefined,
        notes: notes || undefined
      };

      const res = await api.fees.assignStudentFees(payload);
      const result = (res as any)?.data || res;

      if ((res as any)?.success === false) {
        throw new Error((res as any)?.error || 'Failed to assign fees');
      }

      showToast(
        `Successfully generated ${result?.assignedCount || 0} invoice(s)! ${
          result?.skippedCount && result.skippedCount > 0
            ? `(${result.skippedCount} duplicates skipped)`
            : ''
        }`,
        'success'
      );
      onSuccess(result);
      onClose();
    } catch (err: any) {
      showToast(err.message || 'Failed to assign fees.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="relative w-full max-w-3xl bg-slate-900 border border-white/15 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 bg-slate-950/70">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/15 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
              <Coins className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Assign Fees & Generate Invoices</h3>
              <p className="text-xs text-slate-400">
                Bulk or individual fee invoice generation with duplicate prevention
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-white/10 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6 max-h-[calc(85vh-130px)] overflow-y-auto">
          {/* Step 1: Assignment Scope Selection */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-2">
              1. Select Assignment Scope
            </label>
            <div className="grid grid-cols-3 gap-3">
              <button
                type="button"
                onClick={() => setAssignmentType('CLASS')}
                className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer flex flex-col gap-1.5 ${
                  assignmentType === 'CLASS'
                    ? 'bg-indigo-500/15 border-indigo-500/40 text-white shadow-lg shadow-indigo-500/10'
                    : 'bg-white/[0.02] border-white/10 text-slate-400 hover:bg-white/5'
                }`}
              >
                <div className="flex items-center gap-2">
                  <GraduationCap className="w-4 h-4 text-indigo-400" />
                  <span className="text-xs font-bold">Entire Class</span>
                </div>
                <p className="text-[11px] text-slate-400">Assign to all active students in class</p>
              </button>

              <button
                type="button"
                onClick={() => setAssignmentType('SECTION')}
                className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer flex flex-col gap-1.5 ${
                  assignmentType === 'SECTION'
                    ? 'bg-indigo-500/15 border-indigo-500/40 text-white shadow-lg shadow-indigo-500/10'
                    : 'bg-white/[0.02] border-white/10 text-slate-400 hover:bg-white/5'
                }`}
              >
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4 text-indigo-400" />
                  <span className="text-xs font-bold">Entire Section</span>
                </div>
                <p className="text-[11px] text-slate-400">Assign to all students in section</p>
              </button>

              <button
                type="button"
                onClick={() => setAssignmentType('INDIVIDUAL')}
                className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer flex flex-col gap-1.5 ${
                  assignmentType === 'INDIVIDUAL'
                    ? 'bg-indigo-500/15 border-indigo-500/40 text-white shadow-lg shadow-indigo-500/10'
                    : 'bg-white/[0.02] border-white/10 text-slate-400 hover:bg-white/5'
                }`}
              >
                <div className="flex items-center gap-2">
                  <User className="w-4 h-4 text-indigo-400" />
                  <span className="text-xs font-bold">Individual Student</span>
                </div>
                <p className="text-[11px] text-slate-400">Assign to single specific student</p>
              </button>
            </div>
          </div>

          {/* Step 2: Session, Class, Section, and Student Pickers */}
          <div className="p-4 bg-white/[0.02] border border-white/10 rounded-xl space-y-4">
            <p className="text-xs font-bold uppercase tracking-wider text-slate-300">
              2. Target Academic Group
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {/* Academic Session */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Academic Session *
                </label>
                <select
                  value={selectedSessionId}
                  onChange={(e) => setSelectedSessionId(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-950 border border-white/15 rounded-xl text-white focus:outline-none focus:border-indigo-500"
                  required
                >
                  <option value="">Select Session</option>
                  {sessions.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name} {s.status === 'ACTIVE' ? '(Active)' : ''}
                    </option>
                  ))}
                </select>
              </div>

              {/* Class */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Target Class *</label>
                <select
                  value={selectedClassId}
                  onChange={(e) => setSelectedClassId(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-950 border border-white/15 rounded-xl text-white focus:outline-none focus:border-indigo-500"
                  required
                >
                  <option value="">Select Class</option>
                  {classes.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Section */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Target Section {assignmentType === 'SECTION' ? '*' : '(Optional)'}
                </label>
                <select
                  value={selectedSectionId}
                  onChange={(e) => setSelectedSectionId(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-950 border border-white/15 rounded-xl text-white focus:outline-none focus:border-indigo-500"
                  required={assignmentType === 'SECTION'}
                >
                  <option value="">All Sections</option>
                  {availableSections.map((sec) => (
                    <option key={sec.id} value={sec.id}>
                      Section {sec.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Individual Student Picker if INDIVIDUAL */}
            {assignmentType === 'INDIVIDUAL' && (
              <div className="pt-2 border-t border-white/10 space-y-2">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-medium text-slate-300">
                    Select Student * ({filteredStudents.length} available)
                  </label>
                  <div className="relative w-48">
                    <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-400" />
                    <input
                      type="text"
                      placeholder="Search student..."
                      value={studentSearchQuery}
                      onChange={(e) => setStudentSearchQuery(e.target.value)}
                      className="w-full pl-8 pr-2 py-1 text-xs bg-slate-950 border border-white/10 rounded-lg text-white placeholder-slate-500 focus:outline-none"
                    />
                  </div>
                </div>

                {availableStudents.length === 0 ? (
                  <p className="text-xs text-amber-400 italic py-2">
                    No active students enrolled in this class/section.
                  </p>
                ) : (
                  <select
                    value={selectedStudentId}
                    onChange={(e) => setSelectedStudentId(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-slate-950 border border-white/15 rounded-xl text-white focus:outline-none focus:border-indigo-500"
                    required
                  >
                    <option value="">-- Choose Student --</option>
                    {filteredStudents.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name} (Adm: {s.admissionNumber || 'N/A'}, Roll: {s.rollNumber || '01'})
                      </option>
                    ))}
                  </select>
                )}
              </div>
            )}
          </div>

          {/* Step 3: Applicable Fee Structures Preview & Selection */}
          <div className="p-4 bg-white/[0.02] border border-white/10 rounded-xl space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-bold uppercase tracking-wider text-slate-300">
                  3. Active Fee Structures ({applicableItems.length} found)
                </p>
                <p className="text-[11px] text-slate-400">
                  Automatically determined from active fee structures for this academic session & class
                </p>
              </div>
              {applicableItems.length > 0 && (
                <button
                  type="button"
                  onClick={handleSelectAllStructures}
                  className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 cursor-pointer"
                >
                  Toggle All Valid
                </button>
              )}
            </div>

            {isLoadingStructures ? (
              <div className="py-8 text-center text-slate-400">
                <div className="w-6 h-6 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin mx-auto mb-2" />
                <p className="text-xs">Loading applicable fee structures...</p>
              </div>
            ) : applicableItems.length === 0 ? (
              <div className="py-6 text-center text-slate-400 border border-dashed border-white/10 rounded-xl">
                <Info className="w-6 h-6 mx-auto mb-1.5 text-slate-400" />
                <p className="text-xs font-medium text-slate-300">No active fee structures configured</p>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Configure active fee structures in Super Admin &rarr; Fee Structure first.
                </p>
              </div>
            ) : (
              <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                {applicableItems.map((item) => {
                  const isSelected = selectedStructureIds.includes(item.structure.id);
                  const isDuplicate = item.isAlreadyAssigned;

                  return (
                    <div
                      key={item.structure.id}
                      onClick={() => {
                        if (!isDuplicate) toggleStructureSelection(item.structure.id);
                      }}
                      className={`p-3 rounded-xl border flex items-center justify-between transition-all ${
                        isDuplicate
                          ? 'bg-amber-500/5 border-amber-500/20 opacity-75 cursor-not-allowed'
                          : isSelected
                          ? 'bg-indigo-500/10 border-indigo-500/40 cursor-pointer'
                          : 'bg-slate-950/60 border-white/10 hover:border-white/20 cursor-pointer'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <input
                          type="checkbox"
                          checked={isSelected}
                          disabled={isDuplicate}
                          onChange={() => {}}
                          className="w-4 h-4 rounded text-indigo-600 bg-slate-900 border-white/20 focus:ring-0"
                        />
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold text-white">
                              {item.structure.name}
                            </span>
                            <span className="px-2 py-0.5 rounded text-[10px] font-medium bg-white/5 border border-white/10 text-slate-300">
                              {item.structure.frequency}
                            </span>
                            {item.structure.isMandatory && (
                              <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-rose-500/15 text-rose-400 border border-rose-500/20">
                                Mandatory
                              </span>
                            )}
                          </div>
                          <p className="text-[11px] text-slate-400">
                            Due: {item.structure.dueDate} &bull; Category: {item.structure.feeCategory}
                          </p>
                        </div>
                      </div>

                      <div className="text-right">
                        <p className="text-sm font-mono font-bold text-white">
                          ${item.structure.amount.toFixed(2)}
                        </p>
                        {isDuplicate && (
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold text-amber-400">
                            <AlertTriangle className="w-3 h-3" /> Already Assigned (
                            {item.assignedInvoiceNumber})
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Step 4: Due Date, Discounts (Individual), and Notes */}
          <div className="p-4 bg-white/[0.02] border border-white/10 rounded-xl space-y-4">
            <p className="text-xs font-bold uppercase tracking-wider text-slate-300">
              4. Customization & Adjustments
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Custom Due Date Override */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Custom Due Date Override (Optional)
                </label>
                <input
                  type="date"
                  value={customDueDate}
                  onChange={(e) => setCustomDueDate(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-950 border border-white/15 rounded-xl text-white focus:outline-none focus:border-indigo-500"
                />
                <p className="text-[11px] text-slate-400 mt-1">
                  Leave blank to inherit default due date from fee structure
                </p>
              </div>

              {/* Administrative Notes */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Invoice Notes (Optional)
                </label>
                <input
                  type="text"
                  placeholder="e.g., Term 1 academic installment"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-950 border border-white/15 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>

            {/* Individual Discount Support */}
            {assignmentType === 'INDIVIDUAL' && (
              <div className="pt-3 border-t border-white/10 grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Direct Discount Amount ($)
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    placeholder="0.00"
                    value={discountAmount}
                    onChange={(e) => setDiscountAmount(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-slate-950 border border-white/15 rounded-xl text-white font-mono placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Discount Approval Reason
                  </label>
                  <input
                    type="text"
                    placeholder="e.g., Sibling concession / Merit grant"
                    value={discountReason}
                    onChange={(e) => setDiscountReason(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-slate-950 border border-white/15 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-between pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white bg-white/5 hover:bg-white/10 rounded-xl transition-colors cursor-pointer"
            >
              Cancel
            </button>

            <button
              type="submit"
              disabled={isSubmitting || selectedStructureIds.length === 0}
              className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-500 rounded-xl shadow-lg shadow-indigo-600/30 transition-all disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
            >
              {isSubmitting ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Generating Invoices...</span>
                </>
              ) : (
                <>
                  <Coins className="w-4 h-4" />
                  <span>
                    Generate Invoices ({selectedStructureIds.length} structure(s))
                  </span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
