import React, { useState } from 'react';
import { X, Percent, CheckCircle2, AlertTriangle, Layers, ArrowRight, DollarSign } from 'lucide-react';
import { FeeDiscountRule, ApplyDiscountBatchResponse } from '../../types/index.js';
import { api } from '../../services/api.js';
import { useToast } from '../../context/ToastContext.js';

interface BatchApplyDiscountModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (result: ApplyDiscountBatchResponse['data']) => void;
  discount: FeeDiscountRule | null;
}

export const BatchApplyDiscountModal: React.FC<BatchApplyDiscountModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  discount
}) => {
  const { showToast } = useToast();
  const [isApplying, setIsApplying] = useState(false);
  const [resultData, setResultData] = useState<ApplyDiscountBatchResponse['data'] | null>(null);

  if (!isOpen || !discount) return null;

  const handleApply = async () => {
    setIsApplying(true);
    try {
      const res = await api.fees.applyDiscountBatch(discount.id, {});
      if (res.success && res.data) {
        setResultData(res.data);
        const count = res.data.appliedCount ?? res.data.updatedCount ?? 0;
        const total = res.data.totalAmountDiscounted ?? res.data.totalAmountApplied ?? 0;
        showToast(
          `Successfully applied discount to ${count} invoice(s)! Total: $${total.toFixed(2)}`,
          'success'
        );
        onSuccess(res.data);
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to apply discount batch', 'error');
    } finally {
      setIsApplying(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto"
      onClick={(e) => {
        if (e.target === e.currentTarget && !isApplying) onClose();
      }}
    >
      <div className="relative w-full max-w-lg bg-slate-900 border border-white/15 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 bg-slate-950/70">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-indigo-500/15 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Batch Apply Discount</h3>
              <p className="text-xs text-slate-400">Apply rule to all matching open student invoices</p>
            </div>
          </div>
          <button
            onClick={onClose}
            disabled={isApplying}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4">
          {/* Target Discount Information */}
          <div className="p-4 bg-white/5 border border-white/10 rounded-xl space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white">{discount.name}</span>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                {discount.code}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs text-slate-300 pt-2 border-t border-white/5">
              <div>
                <span className="text-slate-400">Value:</span>{' '}
                <span className="font-bold text-emerald-400">
                  {discount.discountType === 'PERCENTAGE' ? `${discount.value}%` : `$${discount.value}`}
                </span>
              </div>
              <div>
                <span className="text-slate-400">Scope:</span>{' '}
                <span className="font-semibold text-white">{discount.scope}</span>
              </div>
              <div>
                <span className="text-slate-400">Fee Type:</span>{' '}
                <span className="text-slate-200">{discount.applicableFeeType || 'ALL'}</span>
              </div>
              <div>
                <span className="text-slate-400">Session:</span>{' '}
                <span className="text-slate-200">{discount.academicSessionName}</span>
              </div>
            </div>
          </div>

          {!resultData ? (
            <div className="space-y-3">
              <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-xl text-xs text-amber-300 flex items-start gap-2.5">
                <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold text-amber-200">How Batch Application Works</p>
                  <p className="text-[11px] text-amber-300/80 mt-0.5">
                    This will scan all unpaid & due student invoices matching this discount rule’s criteria
                    (session, class, fee type) and apply the deduction immediately. All invoice totals will be
                    server-recalculated. Already applied records will be skipped.
                  </p>
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-xs font-bold text-slate-400 hover:text-white bg-white/5 hover:bg-white/10 rounded-xl transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleApply}
                  disabled={isApplying}
                  className="px-5 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 rounded-xl shadow-lg shadow-indigo-600/20 transition-all cursor-pointer flex items-center gap-2"
                >
                  {isApplying ? (
                    <span>Applying Discount...</span>
                  ) : (
                    <>
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Run Batch Application</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-4 text-center py-2">
              <div className="w-12 h-12 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-base font-bold text-white">Batch Run Completed</h4>
                <p className="text-xs text-slate-300 mt-1">
                  Updated <span className="font-bold text-emerald-400">{resultData.updatedCount}</span> fee
                  invoice(s) with total deduction of{' '}
                  <span className="font-bold text-emerald-400">${resultData.totalAmountApplied.toFixed(2)}</span>.
                </p>
              </div>
              <button
                type="button"
                onClick={onClose}
                className="w-full px-4 py-2.5 text-xs font-bold text-white bg-slate-800 hover:bg-slate-700 rounded-xl transition-colors cursor-pointer"
              >
                Close Window
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
