import React, { useState, useEffect } from 'react';
import { X, AlertTriangle, DollarSign, Percent, Clock, CheckCircle2 } from 'lucide-react';
import { FeeFineRule, CreateFineRulePayload, FeeType } from '../../types/index.js';
import { api } from '../../services/api.js';
import { useToast } from '../../context/ToastContext.js';

interface CreateFineRuleModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (newRule: FeeFineRule) => void;
  ruleToEdit?: FeeFineRule | null;
  feeTypes: FeeType[];
}

export const CreateFineRuleModal: React.FC<CreateFineRuleModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  ruleToEdit,
  feeTypes
}) => {
  const { showToast } = useToast();

  const [ruleName, setRuleName] = useState('');
  const [fineType, setFineType] = useState<'FIXED' | 'PERCENTAGE' | 'DAILY_FIXED'>('DAILY_FIXED');
  const [amount, setAmount] = useState<string>('5');
  const [gracePeriodDays, setGracePeriodDays] = useState<string>('7');
  const [maxFineLimit, setMaxFineLimit] = useState<string>('100');
  const [applicableFeeType, setApplicableFeeType] = useState('ALL');
  const [description, setDescription] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (isOpen) {
      if (ruleToEdit) {
        setRuleName(ruleToEdit.ruleName);
        setFineType(ruleToEdit.fineType);
        setAmount(ruleToEdit.amount.toString());
        setGracePeriodDays(ruleToEdit.gracePeriodDays.toString());
        setMaxFineLimit(ruleToEdit.maxFineLimit ? ruleToEdit.maxFineLimit.toString() : '');
        setApplicableFeeType(ruleToEdit.applicableFeeType || 'ALL');
        setDescription(ruleToEdit.description || '');
      } else {
        setRuleName('Standard Late Fee Policy');
        setFineType('DAILY_FIXED');
        setAmount('5');
        setGracePeriodDays('7');
        setMaxFineLimit('100');
        setApplicableFeeType('ALL');
        setDescription('Standard policy assessed for unpaid tuition fees after grace period.');
      }
    }
  }, [isOpen, ruleToEdit]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!ruleName.trim()) {
      showToast('Please specify the policy rule name', 'error');
      return;
    }

    const numAmount = parseFloat(amount);
    const numGrace = parseInt(gracePeriodDays, 10);
    const numMax = maxFineLimit ? parseFloat(maxFineLimit) : undefined;

    if (isNaN(numAmount) || numAmount <= 0) {
      showToast('Please enter a valid fine amount or percentage rate', 'error');
      return;
    }

    if (isNaN(numGrace) || numGrace < 0) {
      showToast('Grace period days must be 0 or greater', 'error');
      return;
    }

    setIsSubmitting(true);
    try {
      if (ruleToEdit) {
        const res = await api.fees.updateFineRule(ruleToEdit.id, {
          ruleName: ruleName.trim(),
          fineType,
          amount: numAmount,
          gracePeriodDays: numGrace,
          maxFineLimit: numMax,
          applicableFeeType,
          description: description.trim() || undefined
        });
        if (res.success && res.data) {
          showToast(`Fine policy ${res.data.ruleName} updated`, 'success');
          onSuccess(res.data);
          onClose();
        }
      } else {
        const payload: CreateFineRulePayload = {
          ruleName: ruleName.trim(),
          fineType,
          amount: numAmount,
          gracePeriodDays: numGrace,
          maxFineLimit: numMax,
          applicableFeeType,
          description: description.trim() || undefined
        };
        const res = await api.fees.createFineRule(payload);
        if (res.success && res.data) {
          showToast(`Fine policy rule ${res.data.ruleName} created`, 'success');
          onSuccess(res.data);
          onClose();
        }
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to save fine rule', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto"
      onClick={(e) => {
        if (e.target === e.currentTarget && !isSubmitting) onClose();
      }}
    >
      <div className="relative w-full max-w-lg bg-slate-900 border border-white/15 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 bg-slate-950/70">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-rose-500/15 border border-rose-500/30 flex items-center justify-center text-rose-400">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">
                {ruleToEdit ? 'Edit Late Fine Policy' : 'Create Late Fine Rule'}
              </h3>
              <p className="text-xs text-slate-400">Configure overdue penalties, grace days & caps</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Policy Name <span className="text-rose-400">*</span>
            </label>
            <input
              type="text"
              value={ruleName}
              onChange={(e) => setRuleName(e.target.value)}
              placeholder="e.g. Standard Late Tuition Policy ($5/day)"
              required
              className="w-full px-3 py-2 text-xs bg-slate-950 border border-white/10 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-rose-500"
            />
          </div>

          {/* Fine Type Selector */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">Penalty Calculation Formula</label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setFineType('DAILY_FIXED')}
                className={`p-2 rounded-xl border text-xs font-bold transition-all flex flex-col items-center gap-1 ${
                  fineType === 'DAILY_FIXED'
                    ? 'bg-rose-500/20 text-rose-300 border-rose-500/50'
                    : 'bg-slate-950 text-slate-400 border-white/10 hover:border-white/20'
                }`}
              >
                <Clock className="w-4 h-4" />
                <span>Daily Fixed ($/day)</span>
              </button>
              <button
                type="button"
                onClick={() => setFineType('FIXED')}
                className={`p-2 rounded-xl border text-xs font-bold transition-all flex flex-col items-center gap-1 ${
                  fineType === 'FIXED'
                    ? 'bg-rose-500/20 text-rose-300 border-rose-500/50'
                    : 'bg-slate-950 text-slate-400 border-white/10 hover:border-white/20'
                }`}
              >
                <DollarSign className="w-4 h-4" />
                <span>One-time Flat ($)</span>
              </button>
              <button
                type="button"
                onClick={() => setFineType('PERCENTAGE')}
                className={`p-2 rounded-xl border text-xs font-bold transition-all flex flex-col items-center gap-1 ${
                  fineType === 'PERCENTAGE'
                    ? 'bg-rose-500/20 text-rose-300 border-rose-500/50'
                    : 'bg-slate-950 text-slate-400 border-white/10 hover:border-white/20'
                }`}
              >
                <Percent className="w-4 h-4" />
                <span>Percentage (%)</span>
              </button>
            </div>
          </div>

          {/* Amount & Grace Period */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Fine Value / Rate <span className="text-rose-400">*</span>
              </label>
              <div className="relative">
                <span className="absolute left-3 top-2 text-xs text-slate-400">
                  {fineType === 'PERCENTAGE' ? '%' : '$'}
                </span>
                <input
                  type="number"
                  step="0.01"
                  min="0.01"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="5"
                  required
                  className="w-full pl-8 pr-3 py-2 text-xs font-mono font-bold bg-slate-950 border border-white/10 rounded-xl text-rose-300 focus:outline-none focus:border-rose-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Grace Period (Days) <span className="text-rose-400">*</span>
              </label>
              <input
                type="number"
                min="0"
                value={gracePeriodDays}
                onChange={(e) => setGracePeriodDays(e.target.value)}
                placeholder="7"
                required
                className="w-full px-3 py-2 text-xs font-mono font-bold bg-slate-950 border border-white/10 rounded-xl text-white focus:outline-none focus:border-rose-500"
              />
            </div>
          </div>

          {/* Max Cap & Fee Type */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Max Fine Ceiling Cap ($)</label>
              <input
                type="number"
                step="0.01"
                min="0"
                value={maxFineLimit}
                onChange={(e) => setMaxFineLimit(e.target.value)}
                placeholder="e.g. 100 (Optional)"
                className="w-full px-3 py-2 text-xs font-mono bg-slate-950 border border-white/10 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-rose-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Applicable Fee Category</label>
              <select
                value={applicableFeeType}
                onChange={(e) => setApplicableFeeType(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-950 border border-white/10 rounded-xl text-white focus:outline-none focus:border-rose-500"
              >
                <option value="ALL">All Fee Types</option>
                {feeTypes.map((ft) => (
                  <option key={ft.id} value={ft.name}>
                    {ft.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">Policy Description</label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="e.g. Late fee assessed daily after due date plus 7 days grace..."
              className="w-full px-3 py-2 text-xs bg-slate-950 border border-white/10 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-rose-500"
            />
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-bold text-slate-400 hover:text-white bg-white/5 hover:bg-white/10 rounded-xl transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-500 disabled:opacity-50 rounded-xl shadow-lg shadow-rose-600/20 transition-all cursor-pointer flex items-center gap-2"
            >
              {isSubmitting ? (
                <span>Saving Policy...</span>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{ruleToEdit ? 'Update Fine Policy' : 'Create Fine Rule'}</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
