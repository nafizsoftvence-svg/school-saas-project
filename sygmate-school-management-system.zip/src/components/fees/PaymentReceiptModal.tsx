import React, { useRef, useState } from 'react';
import {
  X,
  Printer,
  Download,
  Receipt,
  Building,
  User,
  Calendar,
  CreditCard,
  CheckCircle2,
  AlertTriangle,
  ShieldCheck,
  Ban,
  Clock,
  ArrowDownRight
} from 'lucide-react';
import { FeePaymentReceipt } from '../../types/index.js';
import { downloadElementPdf, triggerSafePrint } from '../../utils/printPdf.js';

interface PaymentReceiptModalProps {
  isOpen: boolean;
  onClose: () => void;
  receiptData: FeePaymentReceipt | null;
  isLoading?: boolean;
}

export const PaymentReceiptModal: React.FC<PaymentReceiptModalProps> = ({
  isOpen,
  onClose,
  receiptData,
  isLoading = false
}) => {
  const printableRef = useRef<HTMLDivElement>(null);
  const [isExporting, setIsExporting] = useState(false);

  if (!isOpen) return null;

  const handlePrint = async () => {
    if (!printableRef.current) {
      window.print();
      return;
    }

    try {
      setIsExporting(true);
      const cleanNum = (receiptData?.receiptNumber || 'receipt').replace(/[^a-zA-Z0-9_-]/g, '_');
      await triggerSafePrint({
        elementOrId: printableRef.current,
        fallbackTitle: `Receipt_${cleanNum}`
      });
    } catch (err) {
      console.error('Receipt print error:', err);
      try {
        window.print();
      } catch {
        // ignore
      }
    } finally {
      setIsExporting(false);
    }
  };

  const handleDownload = async () => {
    if (!receiptData || !printableRef.current) return;
    try {
      setIsExporting(true);
      const cleanNum = (receiptData.receiptNumber || 'receipt').replace(/[^a-zA-Z0-9_-]/g, '_');
      const filename = `FeeReceipt_${cleanNum}_${new Date().toISOString().split('T')[0]}.pdf`;

      await downloadElementPdf(printableRef.current, filename, {
        orientation: 'portrait'
      });
    } catch (err) {
      console.error('Receipt download error:', err);
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="relative w-full max-w-2xl bg-slate-900 border border-white/15 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Modal Top Bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 bg-slate-950/70">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-indigo-500/20 border border-indigo-500/30 text-indigo-400">
              <Receipt className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                Official Fee Payment Receipt
                {receiptData?.paymentDetails?.isReversed ? (
                  <span className="px-2 py-0.5 text-[10px] font-extrabold uppercase rounded bg-rose-500/20 text-rose-300 border border-rose-500/30">
                    VOID / REVERSED
                  </span>
                ) : (
                  <span className="px-2 py-0.5 text-[10px] font-extrabold uppercase rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                    PAID / SETTLED
                  </span>
                )}
              </h3>
              <p className="text-xs text-slate-400 font-mono">
                {receiptData ? receiptData.receiptNumber : 'Loading receipt details...'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              disabled={!receiptData || isLoading || isExporting}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 rounded-xl transition-colors cursor-pointer shadow-sm shadow-indigo-600/20"
              title="Print Receipt"
            >
              <Printer className="w-3.5 h-3.5" />
              Print
            </button>
            <button
              onClick={handleDownload}
              disabled={!receiptData || isLoading || isExporting}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-200 bg-white/5 hover:bg-white/10 border border-white/10 disabled:opacity-50 rounded-xl transition-colors cursor-pointer"
              title="Download PDF Copy"
            >
              <Download className="w-3.5 h-3.5" />
              {isExporting ? 'Generating...' : 'Download PDF'}
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto max-h-[calc(85vh-120px)] bg-slate-900/60">
          {isLoading || !receiptData || !receiptData.paymentDetails ? (
            <div className="flex flex-col items-center justify-center py-16 text-slate-400 space-y-3">
              <div className="w-8 h-8 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" />
              <p className="text-xs">Loading payment receipt details...</p>
            </div>
          ) : (
            <div
              ref={printableRef}
              className={`space-y-5 bg-slate-950 border ${
                receiptData.paymentDetails?.isReversed
                  ? 'border-rose-500/30'
                  : 'border-white/10'
              } rounded-2xl p-6 relative overflow-hidden`}
            >
              {/* Watermark for Reversed Payments */}
              {receiptData.paymentDetails?.isReversed && (
                <div className="absolute inset-0 pointer-events-none flex items-center justify-center z-0 opacity-10">
                  <span className="text-7xl md:text-9xl font-black uppercase text-rose-500 transform -rotate-45 select-none">
                    VOID
                  </span>
                </div>
              )}

              {/* School Header */}
              <div className="relative z-10 flex flex-col sm:flex-row justify-between items-start sm:items-center pb-4 border-b border-white/10 gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-indigo-600 to-indigo-800 flex items-center justify-center text-white font-black text-xl shadow-lg shadow-indigo-500/20">
                    SIA
                  </div>
                  <div>
                    <h4 className="text-base font-extrabold text-white">
                      {receiptData.schoolInfo?.name || 'Sygmate International Academy'}
                    </h4>
                    <p className="text-xs text-slate-400">
                      {receiptData.schoolInfo?.address || 'Silicon Valley Campus'}
                    </p>
                    <p className="text-[11px] text-slate-400">
                      Affiliation: {receiptData.schoolInfo?.affiliationNumber || 'CBSE-INTL-2026-9901'} &bull; Tel: {receiptData.schoolInfo?.phone || '+1 (555) 890-4321'}
                    </p>
                  </div>
                </div>

                <div className="text-left sm:text-right font-mono">
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 mb-1">
                    <Receipt className="w-3.5 h-3.5" />
                    {receiptData.receiptNumber || 'N/A'}
                  </div>
                  <p className="text-[11px] text-slate-400">
                    Txn Ref: {receiptData.transactionId || 'N/A'}
                  </p>
                  <p className="text-[11px] text-slate-400">
                    Date: {receiptData.paymentDetails?.paymentDate ? new Date(receiptData.paymentDetails.paymentDate).toLocaleDateString() : 'N/A'} at{' '}
                    {receiptData.paymentDetails?.paymentDate ? new Date(receiptData.paymentDetails.paymentDate).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : ''}
                  </p>
                </div>
              </div>

              {/* Reversal Banner Alert if voided */}
              {receiptData.paymentDetails?.isReversed && (
                <div className="relative z-10 p-3.5 bg-rose-500/10 border border-rose-500/30 rounded-xl text-xs text-rose-300 space-y-1">
                  <div className="flex items-center gap-2 font-bold text-rose-200">
                    <Ban className="w-4 h-4 text-rose-400" />
                    THIS PAYMENT RECEIPT HAS BEEN VOIDED / REVERSED
                  </div>
                  <p className="text-[11px] text-rose-300/90">
                    <span className="font-semibold text-rose-200">Reversal Reason:</span>{' '}
                    {receiptData.paymentDetails?.reversalReason || 'Administrative balance adjustment'}
                  </p>
                  {receiptData.paymentDetails?.reversedAt && (
                    <p className="text-[10px] text-rose-400/80">
                      Processed on {new Date(receiptData.paymentDetails.reversedAt).toLocaleString()} by{' '}
                      {receiptData.paymentDetails?.reversedByName || 'Administrator'}
                    </p>
                  )}
                </div>
              )}

              {/* Student & Invoice Meta Grid */}
              <div className="relative z-10 grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-slate-900/60 rounded-xl border border-white/5">
                <div className="space-y-1.5 text-xs">
                  <p className="text-slate-400 font-semibold uppercase tracking-wider text-[10px] flex items-center gap-1 text-indigo-400">
                    <User className="w-3 h-3" /> Student Particulars
                  </p>
                  <p className="text-sm font-bold text-white">
                    {receiptData.studentInfo?.name || 'Student'}
                  </p>
                  <p className="text-slate-300">
                    <span className="text-slate-400">Admission No:</span>{' '}
                    <span className="font-mono text-white">{receiptData.studentInfo?.admissionNumber || 'N/A'}</span>
                  </p>
                  <p className="text-slate-300">
                    <span className="text-slate-400">Class & Section:</span>{' '}
                    <span className="text-white">{receiptData.studentInfo?.className || 'N/A'} - {receiptData.studentInfo?.sectionName || 'General'}</span>
                  </p>
                  {receiptData.guardianInfo && (
                    <p className="text-slate-300">
                      <span className="text-slate-400">Guardian:</span>{' '}
                      <span className="text-white">{receiptData.guardianInfo?.name} ({receiptData.guardianInfo?.relation || 'Parent'})</span>
                    </p>
                  )}
                </div>

                <div className="space-y-1.5 text-xs">
                  <p className="text-slate-400 font-semibold uppercase tracking-wider text-[10px] flex items-center gap-1 text-indigo-400">
                    <Building className="w-3 h-3" /> Invoice & Academic Scope
                  </p>
                  <p className="text-sm font-bold text-white">
                    {receiptData.feeInfo?.title || 'Fee Invoice'}
                  </p>
                  <p className="text-slate-300">
                    <span className="text-slate-400">Invoice Number:</span>{' '}
                    <span className="font-mono text-indigo-300">{receiptData.feeInfo?.invoiceNumber || 'INV-2026'}</span>
                  </p>
                  <p className="text-slate-300">
                    <span className="text-slate-400">Academic Session:</span>{' '}
                    <span className="text-white">{receiptData.feeInfo?.academicSession || 'Current Academic Session'}</span>
                  </p>
                  <p className="text-slate-300">
                    <span className="text-slate-400">Fee Classification:</span>{' '}
                    <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-white/10 text-slate-200">
                      {receiptData.feeInfo?.feeType || 'Tuition'}
                    </span>
                  </p>
                </div>
              </div>

              {/* Financial Ledger Calculation Table */}
              <div className="relative z-10 border border-white/10 rounded-xl overflow-hidden bg-slate-900/40">
                <table className="w-full text-left text-xs">
                  <thead className="bg-white/5 border-b border-white/10 text-slate-300 font-semibold">
                    <tr>
                      <th className="px-4 py-2.5">Particulars</th>
                      <th className="px-4 py-2.5 text-right">Calculation</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5 text-slate-300">
                    <tr>
                      <td className="px-4 py-2 text-slate-300">Total Assigned Fee Amount</td>
                      <td className="px-4 py-2 text-right font-mono text-slate-200">
                        ${Number(receiptData.feeInfo?.totalFee ?? 0).toFixed(2)}
                      </td>
                    </tr>
                    {(receiptData.feeInfo?.discount ?? 0) > 0 && (
                      <tr>
                        <td className="px-4 py-2 text-emerald-400 flex items-center gap-1">
                          <ArrowDownRight className="w-3.5 h-3.5" /> Authorized Discount Deduction
                        </td>
                        <td className="px-4 py-2 text-right font-mono font-semibold text-emerald-400">
                          -${Number(receiptData.feeInfo?.discount ?? 0).toFixed(2)}
                        </td>
                      </tr>
                    )}
                    {(receiptData.feeInfo?.fine || 0) > 0 && (
                      <tr>
                        <td className="px-4 py-2 text-rose-400">Late Fine / Adjustment Surcharge</td>
                        <td className="px-4 py-2 text-right font-mono font-semibold text-rose-400">
                          +${Number(receiptData.feeInfo?.fine ?? 0).toFixed(2)}
                        </td>
                      </tr>
                    )}
                    <tr className="bg-white/[0.02]">
                      <td className="px-4 py-2 font-semibold text-slate-200">Net Payable Amount</td>
                      <td className="px-4 py-2 text-right font-mono font-semibold text-indigo-300">
                        ${Number(receiptData.feeInfo?.netPayable ?? 0).toFixed(2)}
                      </td>
                    </tr>
                    <tr>
                      <td className="px-4 py-2 text-slate-400">Previously Settled Amount</td>
                      <td className="px-4 py-2 text-right font-mono text-slate-400">
                        ${Number(receiptData.feeInfo?.previouslyPaid ?? 0).toFixed(2)}
                      </td>
                    </tr>
                    <tr className="bg-emerald-500/10 font-bold border-y border-emerald-500/20">
                      <td className="px-4 py-3 text-emerald-300 flex items-center gap-1.5">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        AMOUNT PAID THIS TRANSACTION
                      </td>
                      <td className="px-4 py-3 text-right font-mono text-base text-emerald-300">
                        ${Number(receiptData.feeInfo?.amountPaidNow ?? 0).toFixed(2)}
                      </td>
                    </tr>
                    <tr className="bg-white/[0.04]">
                      <td className="px-4 py-2.5 font-bold text-white">Remaining Balance Due</td>
                      <td
                        className={`px-4 py-2.5 text-right font-mono font-bold text-sm ${
                          (receiptData.feeInfo?.remainingDue ?? 0) > 0 ? 'text-amber-400' : 'text-emerald-400'
                        }`}
                      >
                        ${Number(receiptData.feeInfo?.remainingDue ?? 0).toFixed(2)}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Payment Details Footer Grid */}
              <div className="relative z-10 grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 text-xs">
                <div className="p-3 bg-slate-900/60 rounded-xl border border-white/5 space-y-1.5">
                  <p className="text-slate-400 font-semibold uppercase tracking-wider text-[10px] flex items-center gap-1 text-indigo-400">
                    <CreditCard className="w-3 h-3" /> Settlement Details
                  </p>
                  <p className="text-slate-200">
                    <span className="text-slate-400">Payment Mode:</span>{' '}
                    <span className="font-semibold text-white">
                      {receiptData.paymentDetails?.paymentMethodLabel || receiptData.paymentDetails?.paymentMethod || 'CASH'}
                    </span>
                  </p>
                  {receiptData.paymentDetails?.referenceNumber && (
                    <p className="text-slate-200">
                      <span className="text-slate-400">Ref / Cheque #:</span>{' '}
                      <span className="font-mono text-indigo-300">
                        {receiptData.paymentDetails.referenceNumber}
                      </span>
                    </p>
                  )}
                  <p className="text-slate-200">
                    <span className="text-slate-400">Collected By:</span>{' '}
                    <span className="text-white">
                      {receiptData.paymentDetails?.collectedBy || 'School Accounts Cashier'}
                    </span>
                  </p>
                  {receiptData.paymentDetails?.notes && (
                    <p className="text-slate-400 text-[11px]">
                      <span className="text-slate-400 font-semibold">Remarks:</span>{' '}
                      {receiptData.paymentDetails.notes}
                    </p>
                  )}
                </div>

                <div className="p-3 bg-slate-900/60 rounded-xl border border-white/5 flex flex-col justify-between items-center text-center">
                  <div className="space-y-1">
                    <ShieldCheck className="w-6 h-6 text-emerald-400 mx-auto" />
                    <p className="text-[11px] font-bold text-slate-200">
                      Official Seal of Accounts
                    </p>
                    <p className="text-[10px] text-slate-400">
                      Digitally Verified by Sygmate Bursar Department
                    </p>
                  </div>
                  <div className="w-full pt-3 border-t border-white/10 mt-2">
                    <p className="text-[10px] text-slate-400 font-mono">
                      Auth ID: {receiptData.transactionId}
                    </p>
                  </div>
                </div>
              </div>

              {/* Bottom Verification Note */}
              <div className="relative z-10 text-center pt-2 text-[10px] text-slate-400 border-t border-white/5">
                This is a computer-generated official receipt. No physical signature is required. For inquiries, contact {receiptData.schoolInfo.email}.
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-white/10 bg-slate-950/70">
          <div className="text-xs text-slate-400">
            {receiptData && (
              <span>
                Status:{' '}
                <strong className={receiptData.paymentDetails.isReversed ? 'text-rose-400' : 'text-emerald-400'}>
                  {receiptData.paymentDetails.isReversed ? 'Voided / Reversed' : 'Official Verified Settlement'}
                </strong>
              </span>
            )}
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-white bg-white/10 hover:bg-white/15 rounded-xl transition-colors cursor-pointer"
          >
            Close Receipt
          </button>
        </div>
      </div>
    </div>
  );
};
