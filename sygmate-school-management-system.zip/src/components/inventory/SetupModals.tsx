import React, { useState, useEffect } from 'react';
import { X, Layers, Scale, Building, Tag, Check, AlertCircle } from 'lucide-react';
import {
  InventoryCategory,
  InventoryUnit,
  InventoryLocation,
  AssetCategory
} from '../../types';

// ==========================================
// 1. CATEGORY MODAL
// ==========================================
interface CategoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (payload: { code: string; name: string; description?: string; status?: 'ACTIVE' | 'INACTIVE' }) => Promise<void>;
  category?: InventoryCategory | null;
}

export const CategoryModal: React.FC<CategoryModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  category
}) => {
  const isEditing = !!category;
  const [code, setCode] = useState('');
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [status, setStatus] = useState<'ACTIVE' | 'INACTIVE'>('ACTIVE');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (category) {
      setCode(category.code || '');
      setName(category.name || '');
      setDescription(category.description || '');
      setStatus(category.status || 'ACTIVE');
    } else {
      setCode('');
      setName('');
      setDescription('');
      setStatus('ACTIVE');
    }
    setError(null);
  }, [category, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!code.trim() || !name.trim()) {
      setError('Category code and name are required');
      return;
    }
    try {
      setSubmitting(true);
      setError(null);
      await onSubmit({
        code: code.trim().toUpperCase(),
        name: name.trim(),
        description: description.trim() || undefined,
        status
      });
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to save category');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between p-4 border-b border-slate-800">
          <div className="flex items-center space-x-2">
            <Layers className="w-4 h-4 text-indigo-400" />
            <h3 className="text-sm font-semibold text-white">
              {isEditing ? `Edit Category: ${category.name}` : 'New Inventory Category'}
            </h3>
          </div>
          <button onClick={onClose} className="p-1 rounded text-slate-400 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          {error && (
            <div className="p-2.5 rounded bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs">
              {error}
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Category Code <span className="text-rose-400">*</span>
            </label>
            <input
              type="text"
              required
              placeholder="e.g. STAT, LAB, TXT"
              value={code}
              onChange={(e) => setCode(e.target.value.toUpperCase())}
              className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700 text-slate-100 font-mono"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Category Name <span className="text-rose-400">*</span>
            </label>
            <input
              type="text"
              required
              placeholder="e.g. Office & Classroom Stationery"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700 text-slate-100"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">Description</label>
            <textarea
              rows={2}
              placeholder="Intended goods and items classified in this category..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700 text-slate-100"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">Status</label>
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value as 'ACTIVE' | 'INACTIVE')}
              className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700 text-slate-200"
            >
              <option value="ACTIVE">Active</option>
              <option value="INACTIVE">Inactive</option>
            </select>
          </div>

          <div className="flex justify-end space-x-2 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 text-xs text-slate-400 hover:text-white bg-slate-800 rounded-lg"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-4 py-1.5 text-xs font-semibold bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg disabled:opacity-50"
            >
              {submitting ? 'Saving...' : isEditing ? 'Save' : 'Create Category'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

// ==========================================
// 2. UNIT MODAL
// ==========================================
interface UnitModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (payload: { shortCode: string; name: string; description?: string; status?: 'ACTIVE' | 'INACTIVE' }) => Promise<void>;
  unit?: InventoryUnit | null;
}

export const UnitModal: React.FC<UnitModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  unit
}) => {
  const isEditing = !!unit;
  const [shortCode, setShortCode] = useState('');
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [status, setStatus] = useState<'ACTIVE' | 'INACTIVE'>('ACTIVE');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (unit) {
      setShortCode(unit.shortCode || '');
      setName(unit.name || '');
      setDescription(unit.description || '');
      setStatus(unit.status || 'ACTIVE');
    } else {
      setShortCode('');
      setName('');
      setDescription('');
      setStatus('ACTIVE');
    }
    setError(null);
  }, [unit, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!shortCode.trim() || !name.trim()) {
      setError('Short code and unit name are required');
      return;
    }
    try {
      setSubmitting(true);
      setError(null);
      await onSubmit({
        shortCode: shortCode.trim().toUpperCase(),
        name: name.trim(),
        description: description.trim() || undefined,
        status
      });
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to save unit');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between p-4 border-b border-slate-800">
          <div className="flex items-center space-x-2">
            <Scale className="w-4 h-4 text-purple-400" />
            <h3 className="text-sm font-semibold text-white">
              {isEditing ? `Edit Unit: ${unit.name}` : 'New Unit of Measurement'}
            </h3>
          </div>
          <button onClick={onClose} className="p-1 rounded text-slate-400 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          {error && (
            <div className="p-2.5 rounded bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs">
              {error}
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Short Code <span className="text-rose-400">*</span>
            </label>
            <input
              type="text"
              required
              placeholder="e.g. PCS, BOX, PACK, KG, LTR, SET"
              value={shortCode}
              onChange={(e) => setShortCode(e.target.value.toUpperCase())}
              className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700 text-slate-100 font-mono"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Unit Full Name <span className="text-rose-400">*</span>
            </label>
            <input
              type="text"
              required
              placeholder="e.g. Pieces, Boxes, Packets"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700 text-slate-100"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">Description</label>
            <textarea
              rows={2}
              placeholder="Measurement notes..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700 text-slate-100"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">Status</label>
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value as 'ACTIVE' | 'INACTIVE')}
              className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700 text-slate-200"
            >
              <option value="ACTIVE">Active</option>
              <option value="INACTIVE">Inactive</option>
            </select>
          </div>

          <div className="flex justify-end space-x-2 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 text-xs text-slate-400 hover:text-white bg-slate-800 rounded-lg"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-4 py-1.5 text-xs font-semibold bg-purple-600 hover:bg-purple-500 text-white rounded-lg disabled:opacity-50"
            >
              {submitting ? 'Saving...' : isEditing ? 'Save' : 'Create Unit'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

// ==========================================
// 3. LOCATION MODAL
// ==========================================
interface LocationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (payload: { code: string; name: string; department?: string; responsibleStaffName?: string; status?: 'ACTIVE' | 'INACTIVE' }) => Promise<void>;
  location?: InventoryLocation | null;
}

export const LocationModal: React.FC<LocationModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  location
}) => {
  const isEditing = !!location;
  const [code, setCode] = useState('');
  const [name, setName] = useState('');
  const [department, setDepartment] = useState('');
  const [responsibleStaffName, setResponsibleStaffName] = useState('');
  const [status, setStatus] = useState<'ACTIVE' | 'INACTIVE'>('ACTIVE');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (location) {
      setCode(location.code || '');
      setName(location.name || '');
      setDepartment(location.department || '');
      setResponsibleStaffName(location.responsibleStaffName || '');
      setStatus(location.status || 'ACTIVE');
    } else {
      setCode('');
      setName('');
      setDepartment('');
      setResponsibleStaffName('');
      setStatus('ACTIVE');
    }
    setError(null);
  }, [location, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!code.trim() || !name.trim()) {
      setError('Location code and name are required');
      return;
    }
    try {
      setSubmitting(true);
      setError(null);
      await onSubmit({
        code: code.trim().toUpperCase(),
        name: name.trim(),
        department: department.trim() || undefined,
        responsibleStaffName: responsibleStaffName.trim() || undefined,
        status
      });
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to save location');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between p-4 border-b border-slate-800">
          <div className="flex items-center space-x-2">
            <Building className="w-4 h-4 text-blue-400" />
            <h3 className="text-sm font-semibold text-white">
              {isEditing ? `Edit Store: ${location.name}` : 'New Store / Location'}
            </h3>
          </div>
          <button onClick={onClose} className="p-1 rounded text-slate-400 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          {error && (
            <div className="p-2.5 rounded bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs">
              {error}
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Location Code <span className="text-rose-400">*</span>
            </label>
            <input
              type="text"
              required
              placeholder="e.g. WH-01, LAB-SCI, IT-SRV"
              value={code}
              onChange={(e) => setCode(e.target.value.toUpperCase())}
              className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700 text-slate-100 font-mono"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Location / Facility Name <span className="text-rose-400">*</span>
            </label>
            <input
              type="text"
              required
              placeholder="e.g. Central Science Lab Store"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700 text-slate-100"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Associated Department
            </label>
            <input
              type="text"
              placeholder="e.g. Science, Facilities, IT"
              value={department}
              onChange={(e) => setDepartment(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700 text-slate-100"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Responsible Custodian / Staff Name
            </label>
            <input
              type="text"
              placeholder="e.g. Dr. Robert Vance"
              value={responsibleStaffName}
              onChange={(e) => setResponsibleStaffName(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700 text-slate-100"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">Status</label>
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value as 'ACTIVE' | 'INACTIVE')}
              className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700 text-slate-200"
            >
              <option value="ACTIVE">Active</option>
              <option value="INACTIVE">Inactive</option>
            </select>
          </div>

          <div className="flex justify-end space-x-2 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 text-xs text-slate-400 hover:text-white bg-slate-800 rounded-lg"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-4 py-1.5 text-xs font-semibold bg-blue-600 hover:bg-blue-500 text-white rounded-lg disabled:opacity-50"
            >
              {submitting ? 'Saving...' : isEditing ? 'Save' : 'Create Location'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
