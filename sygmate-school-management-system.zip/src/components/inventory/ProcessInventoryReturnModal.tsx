import React, { useState, useEffect } from 'react';
import {
  X,
  RotateCcw,
  AlertCircle,
  Package,
  Building,
  CheckCircle,
  Layers,
  ShieldAlert
} from 'lucide-react';
import {
  StockIssue,
  InventoryLocation,
  ReturnCondition,
  RecordInventoryReturnPayload
} from '../../types';
import { api } from '../../services/api';

interface ProcessInventoryReturnModalProps {
  isOpen: boolean;
  onClose: () => void;
  preselectedIssue?: StockIssue | null;
  issues: StockIssue[];
  locations: InventoryLocation[];
  onSuccess: (message: string) => void;
}

interface ReturnLineState {
  issueItemId: string;
  itemId: string;
  itemName: string;
  itemCode: string;
  unitShortCode: string;
  quantityIssued: number;
  previouslyReturned: number;
  maxEligibleReturn: number;
  quantityToReturn: number | '';
  condition: ReturnCondition;
  notes: string;
}

export const ProcessInventoryReturnModal: React.FC<ProcessInventoryReturnModalProps> = ({
  isOpen,
  onClose,
  preselectedIssue,
  issues,
  locations,
  onSuccess
}) => {
  const [selectedIssueId, setSelectedIssueId] = useState(preselectedIssue?.id || issues[0]?.id || '');
  const [returnLocationId, setReturnLocationId] = useState(
    preselectedIssue?.locationId || locations[0]?.id || ''
  );
  const [returnDate, setReturnDate] = useState(new Date().toISOString().split('T')[0]);
  const [returnedBy, setReturnedBy] = useState(preselectedIssue?.recipientName || '');
  const [reason, setReason] = useState('');
  const [notes, setNotes] = useState('');

  const [lines, setLines] = useState<ReturnLineState[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const selectedIssue = issues.find((i) => i.id === selectedIssueId) || preselectedIssue;

  useEffect(() => {
    if (isOpen) {
      setError(null);
      const targetIssue = issues.find((i) => i.id === selectedIssueId) || preselectedIssue;
      if (targetIssue) {
        setReturnLocationId(targetIssue.locationId);
        setReturnedBy(targetIssue.recipientName);
        const initialLines: ReturnLineState[] = targetIssue.items.map((item) => {
          const maxEligible = Math.max(0, item.quantityIssued - item.returnedQuantity);
          return {
            issueItemId: item.id,
            itemId: item.itemId,
            itemName: item.itemName,
            itemCode: item.itemCode,
            unitShortCode: item.unitShortCode,
            quantityIssued: item.quantityIssued,
            previouslyReturned: item.returnedQuantity,
            maxEligibleReturn: maxEligible,
            quantityToReturn: 0,
            condition: 'GOOD',
            notes: ''
          };
        });
        setLines(initialLines);
      }
    }
  }, [isOpen, selectedIssueId, issues, preselectedIssue]);

  if (!isOpen) return null;

  const handleQtyChange = (idx: number, val: string) => {
    const num = val === '' ? '' : Math.max(0, parseInt(val, 10));
    const newLines = [...lines];
    newLines[idx].quantityToReturn = isNaN(num as number) ? 0 : num;
    setLines(newLines);
  };

  const handleConditionChange = (idx: number, condition: ReturnCondition) => {
    const newLines = [...lines];
    newLines[idx].condition = condition;
    setLines(newLines);
  };

  const handleLineNotesChange = (idx: number, val: string) => {
    const newLines = [...lines];
    newLines[idx].notes = val;
    setLines(newLines);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!selectedIssue) {
      setError('Please select an original stock issue record.');
      return;
    }

    if (!reason.trim()) {
      setError('Please provide a reason for returning these items.');
      return;
    }

    const activeLines = lines.filter((l) => typeof l.quantityToReturn === 'number' && l.quantityToReturn > 0);
    if (activeLines.length === 0) {
      setError('Please specify a positive quantity to return for at least one item.');
      return;
    }

    for (const line of activeLines) {
      if (Number(line.quantityToReturn) > line.maxEligibleReturn) {
        setError(
          `Cannot return ${line.quantityToReturn} ${line.unitShortCode} of '${line.itemName}'. Maximum remaining eligible return is ${line.maxEligibleReturn} ${line.unitShortCode}.`
        );
        return;
      }
    }

    try {
      setSubmitting(true);

      const payload: RecordInventoryReturnPayload = {
        issueId: selectedIssue.id,
        returnLocationId,
        returnDate,
        returnedBy: returnedBy.trim() || selectedIssue.recipientName,
        returnedByName: returnedBy.trim() || selectedIssue.recipientName,
        reason: reason.trim(),
        notes: notes.trim() || undefined,
        items: activeLines.map((l) => ({
          issueItemId: l.issueItemId,
          quantity: Number(l.quantityToReturn),
          condition: l.condition,
          notes: l.notes.trim() || undefined
        }))
      };

      const res = await api.inventory.recordInventoryReturn(payload);
      onSuccess(res.message || 'Inventory return processed successfully.');
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to process inventory return.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm overflow-y-auto">
      <div className="w-full max-w-3xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="p-6 border-b border-slate-800 flex items-center justify-between bg-slate-900/80">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
              <RotateCcw className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">Process Inventory Return</h3>
              <p className="text-xs text-slate-400">
                Accept unused or damaged items returned from staff, teachers, or departments
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {error && (
            <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Issue Selector & Meta */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Reference Issue Transaction <span className="text-rose-400">*</span>
              </label>
              <select
                disabled={!!preselectedIssue}
                value={selectedIssueId}
                onChange={(e) => setSelectedIssueId(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl bg-slate-800/80 border border-slate-700 text-white focus:outline-none disabled:opacity-60"
              >
                {issues.map((i) => (
                  <option key={i.id} value={i.id}>
                    {i.issueNumber} ({i.departmentName} - {i.recipientName})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Receiving Store / Location <span className="text-rose-400">*</span>
              </label>
              <select
                value={returnLocationId}
                onChange={(e) => setReturnLocationId(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl bg-slate-800/80 border border-slate-700 text-white focus:outline-none"
              >
                {locations.map((loc) => (
                  <option key={loc.id} value={loc.id}>
                    {loc.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">Return Date</label>
              <input
                type="date"
                value={returnDate}
                onChange={(e) => setReturnDate(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl bg-slate-800/80 border border-slate-700 text-white focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Returned By (Person / Staff) <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                placeholder="Name of returning staff member or representative..."
                value={returnedBy}
                onChange={(e) => setReturnedBy(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl bg-slate-800/80 border border-slate-700 text-white focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Reason for Return <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                placeholder="e.g. Unused stock after workshop, excess stationery, defective batch..."
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl bg-slate-800/80 border border-slate-700 text-white focus:outline-none"
              />
            </div>
          </div>

          {/* Line items table */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                <Layers className="w-4 h-4 text-amber-400" />
                Items Eligible For Return
              </span>
              <span className="text-[11px] text-slate-400">
                Items in GOOD condition are restocked to inventory. Damaged items are quarantined.
              </span>
            </div>

            <div className="border border-slate-800 rounded-xl overflow-hidden">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-800/70 text-slate-400 border-b border-slate-800">
                  <tr>
                    <th className="py-2.5 px-3 font-semibold">Item & SKU</th>
                    <th className="py-2.5 px-3 font-semibold text-center w-24">Eligible</th>
                    <th className="py-2.5 px-3 font-semibold text-center w-28">Return Qty</th>
                    <th className="py-2.5 px-3 font-semibold w-36">Condition</th>
                    <th className="py-2.5 px-3 font-semibold">Notes</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {lines.map((line, idx) => (
                    <tr key={idx} className="bg-slate-900/40">
                      <td className="p-2.5">
                        <div className="font-semibold text-white">{line.itemName}</div>
                        <div className="text-[11px] text-slate-400 font-mono">{line.itemCode}</div>
                      </td>
                      <td className="p-2.5 text-center font-mono">
                        <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-semibold border border-slate-700">
                          {line.maxEligibleReturn} {line.unitShortCode}
                        </span>
                      </td>
                      <td className="p-2.5">
                        <div className="flex items-center gap-1 justify-center">
                          <input
                            type="number"
                            min="0"
                            max={line.maxEligibleReturn}
                            value={line.quantityToReturn}
                            onChange={(e) => handleQtyChange(idx, e.target.value)}
                            className="w-16 px-2 py-1 text-xs rounded-lg bg-slate-800 border border-slate-700 text-center font-mono text-white focus:outline-none focus:border-amber-500"
                          />
                          <span className="text-slate-400 font-mono text-xs">{line.unitShortCode}</span>
                        </div>
                      </td>
                      <td className="p-2.5">
                        <select
                          value={line.condition}
                          onChange={(e) => handleConditionChange(idx, e.target.value as ReturnCondition)}
                          className={`w-full px-2 py-1 text-xs rounded-lg border font-semibold focus:outline-none ${
                            line.condition === 'GOOD'
                              ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
                              : 'bg-rose-500/10 border-rose-500/30 text-rose-400'
                          }`}
                        >
                          <option value="GOOD">Good (Restock)</option>
                          <option value="DAMAGED">Damaged (Quarantine)</option>
                          <option value="PARTIALLY_DAMAGED">Partially Damaged</option>
                          <option value="UNUSABLE">Unusable (Scrap)</option>
                        </select>
                      </td>
                      <td className="p-2.5">
                        <input
                          type="text"
                          placeholder="Condition notes..."
                          value={line.notes}
                          onChange={(e) => handleLineNotesChange(idx, e.target.value)}
                          className="w-full px-2 py-1 text-xs rounded-lg bg-slate-800 border border-slate-700 text-white focus:outline-none"
                        />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">Additional General Notes</label>
            <textarea
              rows={2}
              placeholder="e.g. Returned to shelf B-4, verified by central stock keeper..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl bg-slate-800/80 border border-slate-700 text-white focus:outline-none"
            />
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-end space-x-3 pt-4 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-5 py-2 text-xs font-bold rounded-xl bg-amber-600 hover:bg-amber-500 text-white transition-colors disabled:opacity-50 flex items-center gap-1.5 shadow-lg shadow-amber-900/30"
            >
              <RotateCcw className="w-4 h-4" />
              {submitting ? 'Processing Return...' : 'Accept Return & Update Stock'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
