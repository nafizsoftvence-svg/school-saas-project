import React, { useState } from 'react';
import { Printer, X, FileText, CheckCircle2 } from 'lucide-react';
import { downloadTablePdf, triggerSafePrint } from '../../utils/printPdf.js';

interface ReportPrintModalProps {
  isOpen: boolean;
  onClose: () => void;
  reportTitle: string;
  reportSubtitle?: string;
  dateRangeLabel: string;
  filterSummary?: string[];
  summaryKPIs?: Array<{ label: string; value: string | number }>;
  columns: Array<{ header: string; key: string; align?: 'left' | 'center' | 'right' }>;
  data: Array<Record<string, any>>;
  footerNotes?: string;
}

export const ReportPrintModal: React.FC<ReportPrintModalProps> = ({
  isOpen,
  onClose,
  reportTitle,
  reportSubtitle,
  dateRangeLabel,
  filterSummary = [],
  summaryKPIs = [],
  columns,
  data,
  footerNotes
}) => {
  const [isExporting, setIsExporting] = useState(false);

  if (!isOpen) return null;

  const handlePrint = async () => {
    try {
      setIsExporting(true);
      const filename = `${reportTitle.toLowerCase().replace(/[^a-z0-9]/g, '_')}_${new Date().toISOString().split('T')[0]}.pdf`;
      const filterText = filterSummary.length > 0 ? filterSummary.join(' | ') : dateRangeLabel;

      await downloadTablePdf({
        title: reportTitle,
        subtitle: reportSubtitle,
        filterSummary: filterText,
        columns: columns.map(c => ({ header: c.header, dataKey: c.key })),
        data,
        filename
      });

      await triggerSafePrint({
        elementOrId: 'printable-inventory-report',
        fallbackTitle: reportTitle
      });
    } catch (err) {
      console.error('Inventory print/PDF error:', err);
      try {
        window.print();
      } catch {
        // ignore
      }
    } finally {
      setIsExporting(false);
    }
  };

  const todayStr = new Date().toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      {/* Screen container */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-5xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden print:p-0 print:border-none print:shadow-none print:bg-white print:text-black">
        {/* Top Action Bar (Hidden during print) */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800 bg-slate-900/90 print:hidden">
          <div className="flex items-center space-x-2">
            <FileText className="w-5 h-5 text-indigo-400" />
            <div>
              <h3 className="text-sm font-semibold text-white">Print / Export Preview</h3>
              <p className="text-xs text-slate-400">Formatted for standard legal & letter paper printing</p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={handlePrint}
              disabled={isExporting}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors shadow-sm"
            >
              <Printer className="w-4 h-4" />
              {isExporting ? 'Generating PDF...' : 'Print / Save PDF'}
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Document Body */}
        <div
          id="printable-inventory-report"
          className="flex-1 overflow-y-auto p-8 space-y-6 bg-slate-950/40 print:bg-white print:text-slate-900 print:overflow-visible print:p-6"
        >
          {/* Institutional Letterhead */}
          <div className="border-b border-slate-700/60 pb-5 print:border-slate-300">
            <div className="flex items-start justify-between">
              <div>
                <h1 className="text-xl font-bold tracking-tight text-white print:text-slate-900">
                  SYGMATE INTERNATIONAL ACADEMY
                </h1>
                <p className="text-xs font-medium text-slate-400 print:text-slate-600">
                  Institutional Inventory & Asset Management Division
                </p>
                <div className="mt-2 text-sm font-semibold text-indigo-400 print:text-indigo-900">
                  {reportTitle}
                </div>
                {reportSubtitle && (
                  <p className="text-xs text-slate-400 print:text-slate-600 mt-0.5">{reportSubtitle}</p>
                )}
              </div>
              <div className="text-right text-xs text-slate-400 print:text-slate-600 space-y-1">
                <div><span className="font-semibold text-slate-300 print:text-slate-800">Generated:</span> {todayStr}</div>
                <div><span className="font-semibold text-slate-300 print:text-slate-800">Date Range:</span> {dateRangeLabel}</div>
                <div><span className="font-semibold text-slate-300 print:text-slate-800">System Source:</span> Sygmate ERP authoritative database</div>
              </div>
            </div>

            {/* Filter Summary Tags */}
            {filterSummary.length > 0 && (
              <div className="mt-4 flex flex-wrap gap-2 text-[11px] text-slate-400 print:text-slate-600">
                <span className="font-semibold text-slate-300 print:text-slate-700">Active Criteria:</span>
                {filterSummary.map((f, idx) => (
                  <span key={idx} className="bg-slate-800/60 print:bg-slate-100 px-2 py-0.5 rounded text-slate-300 print:text-slate-700">
                    {f}
                  </span>
                ))}
              </div>
            )}
          </div>

          {/* Summary KPIs Grid */}
          {summaryKPIs.length > 0 && (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 p-4 rounded-xl bg-slate-900/60 border border-slate-800 print:bg-slate-50 print:border-slate-200">
              {summaryKPIs.map((kpi, idx) => (
                <div key={idx} className="space-y-0.5">
                  <div className="text-[11px] font-medium text-slate-400 print:text-slate-500 uppercase tracking-wider">
                    {kpi.label}
                  </div>
                  <div className="text-lg font-bold font-mono text-white print:text-slate-900 tabular-nums">
                    {kpi.value}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Main Table */}
          <div className="border border-slate-800 rounded-xl overflow-hidden print:border-slate-300">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-900 print:bg-slate-100 text-slate-300 print:text-slate-700 border-b border-slate-800 print:border-slate-300">
                  <th className="py-2.5 px-3 font-semibold text-center w-10">#</th>
                  {columns.map((col) => (
                    <th
                      key={col.key}
                      className={`py-2.5 px-3 font-semibold ${
                        col.align === 'right' ? 'text-right' : col.align === 'center' ? 'text-center' : 'text-left'
                      }`}
                    >
                      {col.header}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 print:divide-slate-200">
                {data.length === 0 ? (
                  <tr>
                    <td colSpan={columns.length + 1} className="py-6 text-center text-slate-400 print:text-slate-500">
                      No records match the selected reporting criteria.
                    </td>
                  </tr>
                ) : (
                  data.map((row, idx) => (
                    <tr
                      key={idx}
                      className="hover:bg-slate-800/20 print:hover:bg-transparent text-slate-300 print:text-slate-800"
                    >
                      <td className="py-2 px-3 text-center text-slate-500 font-mono">{idx + 1}</td>
                      {columns.map((col) => (
                        <td
                          key={col.key}
                          className={`py-2 px-3 ${
                            col.align === 'right'
                              ? 'text-right font-mono tabular-nums'
                              : col.align === 'center'
                              ? 'text-center'
                              : 'text-left'
                          }`}
                        >
                          {row[col.key] !== undefined && row[col.key] !== null ? String(row[col.key]) : '—'}
                        </td>
                      ))}
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          {/* Footer & Reconciliation note */}
          <div className="pt-4 border-t border-slate-800 print:border-slate-200 flex flex-col sm:flex-row items-center justify-between text-[11px] text-slate-500 print:text-slate-600 gap-2">
            <div className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>Certified Authoritative Institutional Data · Reconciled Against Primary Ledgers</span>
            </div>
            <div>
              {footerNotes || `Report total: ${data.length} records.`}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
