import React, { useState, useEffect } from 'react';
import {
  X,
  FileText,
  Calendar,
  Building,
  User,
  ArrowDownLeft,
  ArrowUpRight,
  ArrowLeftRight,
  RotateCcw,
  Sliders,
  CheckCircle,
  Package,
  Layers,
  Clock
} from 'lucide-react';
import { StockTransaction, StockMovement } from '../../types';
import { api } from '../../services/api';

interface StockTransactionDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  transactionId: string | null;
}

export const StockTransactionDetailModal: React.FC<StockTransactionDetailModalProps> = ({
  isOpen,
  onClose,
  transactionId
}) => {
  const [loading, setLoading] = useState(false);
  const [transaction, setTransaction] = useState<StockTransaction | null>(null);
  const [movements, setMovements] = useState<StockMovement[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen && transactionId) {
      setLoading(true);
      setError(null);
      api.inventory.getStockTransactionById(transactionId)
        .then(res => {
          if (res?.transaction) {
            setTransaction(res.transaction);
            setMovements(res.movements || []);
          }
        })
        .catch(err => {
          setError(err.message || 'Failed to load transaction details');
        })
        .finally(() => setLoading(false));
    } else {
      setTransaction(null);
      setMovements([]);
    }
  }, [isOpen, transactionId]);

  if (!isOpen) return null;

  const getTypeBadge = (type: string) => {
    switch (type) {
      case 'OPENING_STOCK':
        return <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">Opening Stock</span>;
      case 'PURCHASE_RECEIPT':
      case 'INWARD':
        return <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">Stock Inward</span>;
      case 'CONSUMPTION_ISSUE':
      case 'OUTWARD':
        return <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-500/10 text-rose-400 border border-rose-500/20">Stock Outward</span>;
      case 'STORE_TRANSFER':
        return <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-500/10 text-blue-400 border border-blue-500/20">Store Transfer</span>;
      case 'RETURN_INWARD':
        return <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/20">Stock Return</span>;
      case 'PHYSICAL_ADJUSTMENT':
        return <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-purple-500/10 text-purple-400 border border-purple-500/20">Physical Adjustment</span>;
      default:
        return <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-500/10 text-slate-400 border border-slate-500/20">{type}</span>;
    }
  };

  const getMovementTypeBadge = (mType: string) => {
    if (mType.includes('IN') || mType === 'ADJUST_ADD' || mType === 'OPENING') {
      return (
        <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1 w-fit">
          <ArrowDownLeft className="w-3 h-3" />
          {mType}
        </span>
      );
    }
    return (
      <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-rose-500/10 text-rose-400 border border-rose-500/20 flex items-center gap-1 w-fit">
        <ArrowUpRight className="w-3 h-3" />
        {mType}
      </span>
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm overflow-y-auto">
      <div className="w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-6">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800 bg-slate-900/80">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-base font-bold text-white tracking-tight">Stock Transaction Voucher</h3>
                {transaction && getTypeBadge(transaction.transactionType)}
              </div>
              <p className="text-xs font-mono text-indigo-400 mt-0.5">
                {transaction?.transactionNumber || 'Loading...'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {loading && (
            <div className="py-12 flex flex-col items-center justify-center space-y-3">
              <div className="w-8 h-8 border-2 border-indigo-500/30 border-t-indigo-500 rounded-full animate-spin" />
              <p className="text-xs text-slate-400">Loading transaction ledger...</p>
            </div>
          )}

          {error && (
            <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs">
              {error}
            </div>
          )}

          {!loading && transaction && (
            <>
              {/* Transaction Key Details Grid */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-4 rounded-xl bg-slate-950 border border-slate-800/80">
                <div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase">Transaction Date</span>
                  <p className="text-xs font-medium text-white mt-0.5 flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-slate-400" />
                    {transaction.transactionDate}
                  </p>
                </div>

                <div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase">Reference #</span>
                  <p className="text-xs font-mono text-indigo-300 mt-0.5">
                    {transaction.referenceNumber || 'N/A'}
                  </p>
                </div>

                <div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase">Created By</span>
                  <p className="text-xs font-medium text-white mt-0.5 flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-slate-400" />
                    {transaction.createdByName}
                  </p>
                </div>

                <div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase">Status</span>
                  <p className="text-xs font-medium text-emerald-400 mt-0.5 flex items-center gap-1.5">
                    <CheckCircle className="w-3.5 h-3.5" />
                    {transaction.status}
                  </p>
                </div>
              </div>

              {/* Extra Metadata if Available */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                {transaction.sourceLocationName && (
                  <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
                    <span className="text-[10px] uppercase font-bold text-slate-400">Source Store</span>
                    <p className="text-white font-medium mt-0.5">{transaction.sourceLocationName}</p>
                  </div>
                )}
                {transaction.destinationLocationName && (
                  <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
                    <span className="text-[10px] uppercase font-bold text-slate-400">Destination Store</span>
                    <p className="text-white font-medium mt-0.5">{transaction.destinationLocationName}</p>
                  </div>
                )}
                {transaction.supplierName && (
                  <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
                    <span className="text-[10px] uppercase font-bold text-slate-400">Vendor / Supplier</span>
                    <p className="text-white font-medium mt-0.5">{transaction.supplierName}</p>
                  </div>
                )}
                {transaction.issuedToName && (
                  <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
                    <span className="text-[10px] uppercase font-bold text-slate-400">Issued To ({transaction.issuedToType})</span>
                    <p className="text-white font-medium mt-0.5">{transaction.issuedToName}</p>
                  </div>
                )}
              </div>

              {transaction.remarks && (
                <div className="p-3 rounded-xl bg-slate-950/40 border border-slate-800">
                  <span className="text-[10px] uppercase font-bold text-slate-400">Audit Remarks</span>
                  <p className="text-xs text-slate-300 mt-0.5 italic">{transaction.remarks}</p>
                </div>
              )}

              {/* Double-Entry Linked Movement Records */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                    <Layers className="w-3.5 h-3.5 text-indigo-400" />
                    Ledger Movements ({movements.length})
                  </h4>
                  <span className="text-[11px] text-slate-400 font-mono">Immutable Log</span>
                </div>

                <div className="rounded-xl border border-slate-800 overflow-hidden bg-slate-950">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-900/80 border-b border-slate-800 text-[11px] text-slate-400 uppercase font-semibold">
                      <tr>
                        <th className="py-2.5 px-3">Movement Type</th>
                        <th className="py-2.5 px-3">Location</th>
                        <th className="py-2.5 px-3">Quantity</th>
                        <th className="py-2.5 px-3">Stock Before</th>
                        <th className="py-2.5 px-3">Stock After</th>
                        <th className="py-2.5 px-3">Unit Cost</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800 text-slate-300">
                      {movements.map(m => (
                        <tr key={m.id} className="hover:bg-slate-900/50">
                          <td className="py-2.5 px-3">{getMovementTypeBadge(m.movementType)}</td>
                          <td className="py-2.5 px-3 font-medium text-white">{m.locationName}</td>
                          <td className="py-2.5 px-3 font-mono font-bold text-white">
                            {m.quantity} {m.unitShortCode}
                          </td>
                          <td className="py-2.5 px-3 font-mono text-slate-400">{m.balanceBefore}</td>
                          <td className="py-2.5 px-3 font-mono font-semibold text-indigo-400">{m.balanceAfter}</td>
                          <td className="py-2.5 px-3 font-mono text-slate-400">
                            {m.unitCost ? `$${m.unitCost.toFixed(2)}` : '—'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          )}

          {/* Footer */}
          <div className="flex justify-end pt-4 border-t border-slate-800">
            <button
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold rounded-xl bg-slate-800 hover:bg-slate-700 text-white transition-colors"
            >
              Close Voucher
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
