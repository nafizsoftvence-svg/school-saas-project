import React, { useState } from 'react';
import {
  X,
  CheckCircle,
  AlertCircle,
  Package,
  Layers,
  ArrowUpRight,
  ShieldAlert,
  Building2
} from 'lucide-react';
import {
  IssueRequest,
  ExecuteStockIssuePayload,
  InventoryLocation,
  InventoryItem
} from '../../types';

interface ExecuteIssueModalProps {
  isOpen: boolean;
  onClose: () => void;
  request?: IssueRequest | null;
  items: InventoryItem[];
  locations: InventoryLocation[];
  departments: Array<{ id: string; name: string }>;
  staffMembers: Array<{ id: string; name: string }>;
  teachers: Array<{ id: string; name: string }>;
  onSubmit: (payload: ExecuteStockIssuePayload) => Promise<void>;
}

export const ExecuteIssueModal: React.FC<ExecuteIssueModalProps> = ({
  isOpen,
  onClose,
  request,
  items,
  locations,
  departments,
  staffMembers,
  teachers,
  onSubmit
}) => {
  const [sourceLocationId, setSourceLocationId] = useState(
    request?.sourceLocationId || locations[0]?.id || ''
  );
  const [recipientType, setRecipientType] = useState<any>(
    request?.recipientType || 'DEPARTMENT'
  );
  const [recipientId, setRecipientId] = useState(request?.recipientId || '');
  const [recipientName, setRecipientName] = useState(request?.recipientName || '');
  const [departmentId, setDepartmentId] = useState(request?.departmentId || '');
  const [purpose, setPurpose] = useState(request?.purpose || '');
  const [notes, setNotes] = useState('');

  // Items to issue
  const [issueLines, setIssueLines] = useState<
    Array<{
      itemId: string;
      itemName: string;
      itemCode: string;
      availableStock: number;
      remainingToIssue: number;
      quantityToIssue: number;
      unitShortCode: string;
    }>
  >(() => {
    if (request) {
      return request.items.map((i) => {
        const invItem = items.find((it) => it.id === i.itemId);
        const remaining = i.quantityApproved - i.quantityIssued;
        return {
          itemId: i.itemId,
          itemName: i.itemName,
          itemCode: i.itemCode,
          availableStock: invItem?.currentStock || 0,
          remainingToIssue: remaining,
          quantityToIssue: Math.min(remaining, invItem?.currentStock || 0),
          unitShortCode: i.unitShortCode
        };
      });
    }
    const firstItem = items[0];
    return [
      {
        itemId: firstItem?.id || '',
        itemName: firstItem?.name || '',
        itemCode: firstItem?.itemCode || '',
        availableStock: firstItem?.currentStock || 0,
        remainingToIssue: 9999,
        quantityToIssue: 1,
        unitShortCode: firstItem?.unitShortCode || 'PCS'
      }
    ];
  });

  const [submitting, setSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const updateLineQty = (idx: number, qty: number) => {
    setIssueLines(
      issueLines.map((line, i) => (i === idx ? { ...line, quantityToIssue: qty } : line))
    );
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!sourceLocationId) {
      setErrorMessage('Please select the source store / warehouse.');
      return;
    }
    if (!recipientId || !recipientName) {
      setErrorMessage('Please select a valid recipient.');
      return;
    }

    // Validate quantities
    for (const line of issueLines) {
      if (line.quantityToIssue <= 0) {
        setErrorMessage(`Issue quantity for '${line.itemName}' must be greater than zero.`);
        return;
      }
      if (line.quantityToIssue > line.availableStock) {
        setErrorMessage(
          `Cannot issue ${line.quantityToIssue} of '${line.itemName}'. Only ${line.availableStock} ${line.unitShortCode} available in stock. Negative stock is forbidden.`
        );
        return;
      }
      if (request && line.quantityToIssue > line.remainingToIssue) {
        setErrorMessage(
          `Cannot issue ${line.quantityToIssue} of '${line.itemName}'. Only ${line.remainingToIssue} units remain approved on request ${request.requestNumber}.`
        );
        return;
      }
    }

    setSubmitting(true);
    try {
      const selectedDept = departments.find((d) => d.id === departmentId);

      await onSubmit({
        issueRequestId: request?.id,
        sourceLocationId,
        recipientType,
        recipientId,
        recipientName,
        departmentId: departmentId || undefined,
        departmentName: selectedDept?.name,
        purpose: purpose.trim() || undefined,
        notes: notes.trim() || undefined,
        idempotencyKey: `exec-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        items: issueLines.map((l) => ({
          itemId: l.itemId,
          quantityToIssue: l.quantityToIssue
        }))
      });

      onClose();
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to dispatch stock issue');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
      <div className="w-full max-w-3xl bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl flex flex-col max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-800/40">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              <ArrowUpRight className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white tracking-tight">
                {request ? `Dispatch Stock for ${request.requestNumber}` : 'Direct Stock Issue'}
              </h2>
              <p className="text-xs text-slate-400">
                Atomically deduct items from physical warehouse balance and record delivery.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-5 space-y-5">
          {errorMessage && (
            <div className="p-3.5 rounded-xl bg-rose-500/15 border border-rose-500/30 flex items-center gap-3 text-rose-300 text-xs">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Info Banner */}
          <div className="p-3 rounded-xl bg-slate-800/40 border border-slate-700/60 flex items-center justify-between text-xs">
            <span className="text-slate-300">
              <strong className="text-white">Recipient:</strong> {recipientName || 'Unassigned'} ({recipientType})
            </span>
            <span className="text-slate-400">
              <strong className="text-white">Source Store:</strong>{' '}
              {locations.find((l) => l.id === sourceLocationId)?.name || 'Not Selected'}
            </span>
          </div>

          {/* Items to dispatch table */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                <Layers className="w-3.5 h-3.5 text-emerald-400" /> Items for Stock Deduction
              </h3>
            </div>

            <div className="border border-slate-800 rounded-xl overflow-hidden">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-800/80 text-slate-400 text-[11px] font-semibold border-b border-slate-800">
                  <tr>
                    <th className="p-3">Item & Code</th>
                    <th className="p-3 text-right">Available Stock</th>
                    {request && <th className="p-3 text-right">Remaining Approved</th>}
                    <th className="p-3 text-right w-36">Quantity to Issue</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {issueLines.map((line, idx) => (
                    <tr key={idx} className="hover:bg-slate-800/30">
                      <td className="p-3">
                        <div className="font-semibold text-white">{line.itemName}</div>
                        <div className="font-mono text-[10px] text-indigo-400">{line.itemCode}</div>
                      </td>
                      <td className="p-3 text-right">
                        <span
                          className={`font-semibold ${
                            line.availableStock > 0 ? 'text-slate-200' : 'text-rose-400'
                          }`}
                        >
                          {line.availableStock} {line.unitShortCode}
                        </span>
                      </td>
                      {request && (
                        <td className="p-3 text-right text-slate-300 font-semibold">
                          {line.remainingToIssue} {line.unitShortCode}
                        </td>
                      )}
                      <td className="p-3 text-right">
                        <input
                          type="number"
                          min="1"
                          max={Math.min(line.availableStock, line.remainingToIssue)}
                          value={line.quantityToIssue}
                          onChange={(e) => updateLineQty(idx, parseInt(e.target.value, 10) || 0)}
                          className="w-24 px-2.5 py-1 text-right text-xs rounded-lg bg-slate-900 border border-slate-700 text-white font-semibold focus:outline-none focus:border-emerald-500"
                        />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Dispatch Notes */}
          <div>
            <label className="block text-[11px] font-medium text-slate-300 mb-1">
              Dispatch Verification & Delivery Notes
            </label>
            <textarea
              rows={2}
              placeholder="e.g. Received by Department Representative with physical gate pass verification..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl glass-input border border-slate-700/80 bg-slate-800/90 text-white focus:outline-none focus:border-emerald-500"
            />
          </div>
        </form>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 flex items-center justify-between bg-slate-800/30">
          <div className="flex items-center gap-1.5 text-[11px] text-amber-400">
            <ShieldAlert className="w-3.5 h-3.5" />
            Stock balances will be permanently and atomically deducted.
          </div>
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              disabled={submitting}
              className="px-4 py-2 text-xs font-semibold rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSubmit}
              disabled={submitting}
              className="px-5 py-2 text-xs font-semibold rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-950 flex items-center gap-2 transition-colors disabled:opacity-50"
            >
              <CheckCircle className="w-3.5 h-3.5" />
              {submitting ? 'Executing Stock Out...' : 'Confirm & Issue Stock'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
