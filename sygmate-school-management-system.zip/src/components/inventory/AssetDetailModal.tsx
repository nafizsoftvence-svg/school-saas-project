import React, { useState } from 'react';
import {
  X,
  ShieldCheck,
  Tag,
  Building,
  DollarSign,
  Calendar,
  Clock,
  FileText,
  Paperclip,
  Plus,
  Trash2,
  CheckCircle,
  AlertCircle,
  ExternalLink,
  Edit2
} from 'lucide-react';
import {
  Asset,
  AssetHistory,
  AssetDocument,
  AssetStatus
} from '../../types';
import { api } from '../../services/api';

interface AssetDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  asset: Asset | null;
  onEditAsset: (asset: Asset) => void;
  onOpenStatusModal: (asset: Asset) => void;
  onRefreshAsset: (updatedAsset: Asset) => void;
}

export const AssetDetailModal: React.FC<AssetDetailModalProps> = ({
  isOpen,
  onClose,
  asset,
  onEditAsset,
  onOpenStatusModal,
  onRefreshAsset
}) => {
  const [activeTab, setActiveTab] = useState<'info' | 'history' | 'documents'>('info');

  // Document attachment form state
  const [showAttachDoc, setShowAttachDoc] = useState(false);
  const [docTitle, setDocTitle] = useState('');
  const [docType, setDocType] = useState('INVOICE');
  const [docFileName, setDocFileName] = useState('');
  const [uploadingDoc, setUploadingDoc] = useState(false);
  const [docError, setDocError] = useState<string | null>(null);

  if (!isOpen || !asset) return null;

  const getStatusBadge = (status: AssetStatus) => {
    switch (status) {
      case 'ACTIVE':
      case 'AVAILABLE':
        return <span className="inline-flex items-center px-2.5 py-0.5 text-xs font-semibold rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">Active</span>;
      case 'ASSIGNED':
        return <span className="inline-flex items-center px-2.5 py-0.5 text-xs font-semibold rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/20">Assigned</span>;
      case 'UNDER_REPAIR':
        return <span className="inline-flex items-center px-2.5 py-0.5 text-xs font-semibold rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20">Under Repair</span>;
      case 'DAMAGED':
        return <span className="inline-flex items-center px-2.5 py-0.5 text-xs font-semibold rounded-full bg-rose-500/10 text-rose-400 border border-rose-500/20">Damaged</span>;
      case 'LOST':
        return <span className="inline-flex items-center px-2.5 py-0.5 text-xs font-semibold rounded-full bg-red-600/20 text-red-300 border border-red-500/30">Lost</span>;
      default:
        return <span className="inline-flex items-center px-2.5 py-0.5 text-xs font-semibold rounded-full bg-slate-500/10 text-slate-400 border border-slate-500/20">{status}</span>;
    }
  };

  const handleAttachDocument = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!docTitle.trim() || !docFileName.trim()) {
      setDocError('Document title and file name are required');
      return;
    }

    try {
      setUploadingDoc(true);
      setDocError(null);

      const res = await api.inventory.attachAssetDocument(asset.id, {
        title: docTitle.trim(),
        documentType: docType,
        fileName: docFileName.trim(),
        fileUrl: `/uploads/assets/${encodeURIComponent(docFileName.trim())}`
      });

      if (res.asset) {
        onRefreshAsset(res.asset);
      }

      setDocTitle('');
      setDocFileName('');
      setShowAttachDoc(false);
    } catch (err: any) {
      setDocError(err.message || 'Failed to attach document');
    } finally {
      setUploadingDoc(false);
    }
  };

  const handleDeleteDocument = async (docId: string) => {
    if (!window.confirm('Are you sure you want to remove this attached document?')) return;
    try {
      const res = await api.inventory.deleteAssetDocument(asset.id, docId);
      if (res.asset) {
        onRefreshAsset(res.asset);
      }
    } catch (err: any) {
      alert(err.message || 'Failed to delete document');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm overflow-y-auto">
      <div className="w-full max-w-3xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="p-6 border-b border-slate-800 bg-slate-900/80">
          <div className="flex items-start justify-between">
            <div className="space-y-1.5">
              <div className="flex items-center space-x-3">
                <span className="font-mono text-sm px-2.5 py-1 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-bold">
                  {asset.assetTag}
                </span>
                {getStatusBadge(asset.status)}
              </div>
              <h3 className="text-xl font-bold text-white mt-1">{asset.name}</h3>
              <p className="text-xs text-slate-400">
                {[asset.brand, asset.model, asset.categoryName].filter(Boolean).join(' • ')}
              </p>
            </div>
            <div className="flex items-center space-x-2">
              <button
                onClick={() => {
                  onClose();
                  onEditAsset(asset);
                }}
                className="px-3 py-1.5 text-xs rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors flex items-center gap-1.5"
              >
                <Edit2 className="w-3.5 h-3.5" />
                Edit
              </button>
              <button
                onClick={() => onOpenStatusModal(asset)}
                className="px-3 py-1.5 text-xs rounded-lg bg-blue-600 hover:bg-blue-500 text-white transition-colors flex items-center gap-1.5 shadow-sm shadow-blue-950"
              >
                <Clock className="w-3.5 h-3.5" />
                Update Status
              </button>
              <button
                onClick={onClose}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Sub-Tabs */}
          <div className="flex space-x-2 mt-6 pt-4 border-t border-slate-800/80">
            <button
              onClick={() => setActiveTab('info')}
              className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 ${
                activeTab === 'info'
                  ? 'bg-emerald-600 text-white'
                  : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              Asset Specifications
            </button>
            <button
              onClick={() => setActiveTab('history')}
              className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 ${
                activeTab === 'history'
                  ? 'bg-emerald-600 text-white'
                  : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              <Clock className="w-3.5 h-3.5" />
              Custody & Lifecycle ({asset.history?.length || 0})
            </button>
            <button
              onClick={() => setActiveTab('documents')}
              className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 ${
                activeTab === 'documents'
                  ? 'bg-emerald-600 text-white'
                  : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              <Paperclip className="w-3.5 h-3.5" />
              Documents & Warranties ({asset.documents?.length || 0})
            </button>
          </div>
        </div>

        {/* Tab Content */}
        <div className="p-6 max-h-[60vh] overflow-y-auto">
          {/* 1. INFO TAB */}
          {activeTab === 'info' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                <div className="p-3.5 rounded-xl bg-slate-800/40 border border-slate-800 space-y-1">
                  <span className="text-[11px] font-medium text-slate-400">Classification</span>
                  <div className="text-sm font-semibold text-white">{asset.categoryName}</div>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-800/40 border border-slate-800 space-y-1">
                  <span className="text-[11px] font-medium text-slate-400">Serial Number</span>
                  <div className="text-sm font-mono font-semibold text-white">
                    {asset.serialNumber || 'None Recorded'}
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-800/40 border border-slate-800 space-y-1">
                  <span className="text-[11px] font-medium text-slate-400">Physical Location</span>
                  <div className="text-sm font-semibold text-white">{asset.locationName}</div>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-800/40 border border-slate-800 space-y-1">
                  <span className="text-[11px] font-medium text-slate-400">Assigned Department</span>
                  <div className="text-sm font-semibold text-white">
                    {asset.department || 'General Administration'}
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-800/40 border border-slate-800 space-y-1">
                  <span className="text-[11px] font-medium text-slate-400">Purchase Cost</span>
                  <div className="text-sm font-mono font-semibold text-emerald-400">
                    ${Number(asset.purchaseCost).toLocaleString()}
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-800/40 border border-slate-800 space-y-1">
                  <span className="text-[11px] font-medium text-slate-400">Acquisition Date</span>
                  <div className="text-sm font-mono text-white">
                    {asset.purchaseDate || 'Not Specified'}
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-800/40 border border-slate-800 space-y-1">
                  <span className="text-[11px] font-medium text-slate-400">Warranty Validity</span>
                  <div className="text-sm font-mono text-white">
                    {asset.warrantyEnd ? `Until ${asset.warrantyEnd}` : 'No Warranty Recorded'}
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-800/40 border border-slate-800 space-y-1">
                  <span className="text-[11px] font-medium text-slate-400">Associated Supplier</span>
                  <div className="text-sm font-medium text-white">
                    {asset.supplierName || 'Direct / None'}
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-800/40 border border-slate-800 space-y-1">
                  <span className="text-[11px] font-medium text-slate-400">Registration Timestamp</span>
                  <div className="text-xs font-mono text-slate-300">
                    {new Date(asset.createdAt).toLocaleDateString()}
                  </div>
                </div>
              </div>

              {asset.description && (
                <div className="p-4 rounded-xl bg-slate-800/40 border border-slate-800 space-y-2">
                  <span className="text-xs font-semibold text-slate-300">Detailed Description & Specifications</span>
                  <p className="text-xs text-slate-400 leading-relaxed">{asset.description}</p>
                </div>
              )}
            </div>
          )}

          {/* 2. HISTORY TAB */}
          {activeTab === 'history' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-300">
                  Audit & Operational State Transitions
                </span>
                <button
                  onClick={() => onOpenStatusModal(asset)}
                  className="px-3 py-1 text-xs font-semibold rounded-lg bg-blue-600 hover:bg-blue-500 text-white transition-colors"
                >
                  Transition Status
                </button>
              </div>

              {!asset.history || asset.history.length === 0 ? (
                <div className="p-8 text-center text-slate-400 text-sm">
                  No lifecycle history logged for this asset.
                </div>
              ) : (
                <div className="relative pl-6 border-l-2 border-slate-800 space-y-6">
                  {asset.history.map((h: AssetHistory) => (
                    <div key={h.id} className="relative group">
                      <div className="absolute -left-[31px] top-1 w-3.5 h-3.5 rounded-full bg-slate-800 border-2 border-emerald-500 group-hover:scale-110 transition-transform" />
                      <div className="p-3.5 rounded-xl bg-slate-800/40 border border-slate-800 space-y-1.5">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <span className="text-xs font-semibold text-white">{h.action}</span>
                            {h.toStatus && getStatusBadge(h.toStatus)}
                          </div>
                          <span className="text-[11px] font-mono text-slate-500">
                            {new Date(h.timestamp).toLocaleString()}
                          </span>
                        </div>
                        {h.remarks && (
                          <p className="text-xs text-slate-400 bg-slate-900/50 p-2 rounded border border-slate-800/60">
                            {h.remarks}
                          </p>
                        )}
                        <div className="text-[11px] text-slate-500">
                          Recorded by: <span className="text-slate-400 font-medium">{h.performedByName}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* 3. DOCUMENTS TAB */}
          {activeTab === 'documents' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-xs font-semibold text-white">Document Attachments</span>
                  <p className="text-[11px] text-slate-400">Invoices, warranty certificates, calibration sheets, manuals</p>
                </div>
                {!showAttachDoc && (
                  <button
                    onClick={() => setShowAttachDoc(true)}
                    className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white transition-colors flex items-center gap-1.5"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    Attach Document
                  </button>
                )}
              </div>

              {/* Upload form */}
              {showAttachDoc && (
                <form
                  onSubmit={handleAttachDocument}
                  className="p-4 rounded-xl bg-slate-800/70 border border-slate-700/80 space-y-3"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-white">Add Document Metadata</span>
                    <button
                      type="button"
                      onClick={() => setShowAttachDoc(false)}
                      className="text-slate-400 hover:text-white"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  {docError && (
                    <div className="p-2 rounded bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs">
                      {docError}
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <label className="block text-[11px] text-slate-300 mb-1">Document Title</label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Purchase Invoice #1024"
                        value={docTitle}
                        onChange={(e) => setDocTitle(e.target.value)}
                        className="w-full px-3 py-1.5 text-xs rounded-lg glass-input border border-slate-700 text-slate-100"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] text-slate-300 mb-1">Classification Type</label>
                      <select
                        value={docType}
                        onChange={(e) => setDocType(e.target.value)}
                        className="w-full px-3 py-1.5 text-xs rounded-lg glass-input border border-slate-700 text-slate-200"
                      >
                        <option value="INVOICE">Tax Invoice</option>
                        <option value="WARRANTY">Warranty Card / Agreement</option>
                        <option value="MANUAL">Operating Manual</option>
                        <option value="MAINTENANCE">Maintenance Log</option>
                        <option value="OTHER">Other Institutional Record</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-[11px] text-slate-300 mb-1">File Name</label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. invoice-1024.pdf"
                        value={docFileName}
                        onChange={(e) => setDocFileName(e.target.value)}
                        className="w-full px-3 py-1.5 text-xs rounded-lg glass-input border border-slate-700 text-slate-100"
                      />
                    </div>
                  </div>

                  <div className="flex justify-end space-x-2 pt-2">
                    <button
                      type="button"
                      onClick={() => setShowAttachDoc(false)}
                      className="px-3 py-1 text-xs rounded-lg bg-slate-700 text-slate-300 hover:text-white"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={uploadingDoc}
                      className="px-4 py-1 text-xs font-semibold rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white disabled:opacity-50"
                    >
                      {uploadingDoc ? 'Attaching...' : 'Attach Document'}
                    </button>
                  </div>
                </form>
              )}

              {/* Documents List */}
              <div className="divide-y divide-slate-800">
                {!asset.documents || asset.documents.length === 0 ? (
                  <div className="p-8 text-center text-slate-400 text-sm">
                    No documents attached to this asset.
                  </div>
                ) : (
                  asset.documents.map((doc: AssetDocument) => (
                    <div
                      key={doc.id}
                      className="py-3 flex items-center justify-between hover:bg-slate-800/30 px-2 rounded-lg transition-colors"
                    >
                      <div className="flex items-center space-x-3">
                        <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400">
                          <FileText className="w-4 h-4" />
                        </div>
                        <div>
                          <div className="text-xs font-semibold text-white flex items-center gap-2">
                            {doc.title}
                            <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700">
                              {doc.documentType}
                            </span>
                          </div>
                          <div className="text-[11px] text-slate-400 flex items-center space-x-2">
                            <span>{doc.fileName}</span>
                            <span>•</span>
                            <span>Uploaded {new Date(doc.uploadedAt).toLocaleDateString()}</span>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => handleDeleteDocument(doc.id)}
                          className="p-1.5 rounded-lg hover:bg-rose-500/10 text-slate-400 hover:text-rose-400 transition-colors"
                          title="Delete Document"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
