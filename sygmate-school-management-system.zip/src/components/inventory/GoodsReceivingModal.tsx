/**
 * Goods Receiving Modal (Part 14D)
 *
 * Implements authoritative Goods Receiving against an approved PO.
 * Enforces:
 * - Physical stock increases ONLY upon successful Goods Receiving (via StockService)
 * - Strict verification against remaining quantity ordered (blocks over-receiving)
 * - Discrepancy & rejection handling (damaged items rejected with reason do not increase stock)
 * - Optional immediate capital asset creation
 */

import React, { useState } from 'react';
import {
  X,
  PackageCheck,
  AlertTriangle,
  Building,
  CheckCircle2,
  Calendar,
  FileText,
  Boxes,
  ShieldAlert
} from 'lucide-react';
import {
  PurchaseOrder,
  InventoryLocation,
  ReceiveGoodsPayload
} from '../../types';

interface GoodsReceivingModalProps {
  isOpen: boolean;
  purchaseOrder: PurchaseOrder | null;
  locations: InventoryLocation[];
  onClose: () => void;
  onSubmit: (poId: string, payload: ReceiveGoodsPayload) => Promise<void>;
}

export const GoodsReceivingModal: React.FC<GoodsReceivingModalProps> = ({
  isOpen,
  purchaseOrder,
  locations,
  onClose,
  onSubmit
}) => {
  const [receivingLocationId, setReceivingLocationId] = useState(
    purchaseOrder?.deliveryLocationId || locations[0]?.id || ''
  );
  const [receiptDate, setReceiptDate] = useState(new Date().toISOString().split('T')[0]);
  const [invoiceNumber, setInvoiceNumber] = useState('');
  const [deliveryNoteNumber, setDeliveryNoteNumber] = useState('');
  const [remarks, setRemarks] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // Line item receiving state
  const [lineItems, setLineItems] = useState(
    (purchaseOrder?.items || []).map(item => ({
      poItemId: item.id,
      itemName: item.itemName,
      itemCode: item.itemCode,
      quantityOrdered: item.quantityOrdered,
      quantityAlreadyReceived: item.quantityReceived || 0,
      quantityRemaining: item.quantityRemaining,
      // Default to receiving remaining quantity
      quantityReceived: item.quantityRemaining,
      quantityAccepted: item.quantityRemaining,
      quantityRejected: 0,
      rejectionReason: '',
      itemCondition: 'GOOD' as 'GOOD' | 'DAMAGED' | 'EXPIRED' | 'WRONG_SPEC'
    }))
  );

  if (!isOpen || !purchaseOrder) return null;

  const handleReceivedChange = (index: number, val: number) => {
    const updated = [...lineItems];
    const target = updated[index];
    const safeVal = Math.max(0, val);
    target.quantityReceived = safeVal;
    // Default accepted to received minus rejected
    target.quantityAccepted = Math.max(0, safeVal - target.quantityRejected);
    setLineItems(updated);
  };

  const handleRejectedChange = (index: number, val: number) => {
    const updated = [...lineItems];
    const target = updated[index];
    const safeVal = Math.max(0, val);
    target.quantityRejected = safeVal;
    target.quantityAccepted = Math.max(0, target.quantityReceived - safeVal);
    setLineItems(updated);
  };

  const handleRejectionReasonChange = (index: number, reason: string) => {
    const updated = [...lineItems];
    updated[index].rejectionReason = reason;
    setLineItems(updated);
  };

  const handleConditionChange = (index: number, condition: any) => {
    const updated = [...lineItems];
    updated[index].itemCondition = condition;
    setLineItems(updated);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (!receivingLocationId) {
      setFormError('Please select a receiving warehouse/location.');
      return;
    }

    // Validation: Check total received across lines
    const totalReceived = lineItems.reduce((sum, item) => sum + item.quantityReceived, 0);
    if (totalReceived <= 0) {
      setFormError('Total quantity received across all lines must be greater than zero.');
      return;
    }

    // Validation: Over-receiving check
    for (const item of lineItems) {
      if (item.quantityReceived > item.quantityRemaining) {
        setFormError(
          `Cannot receive ${item.quantityReceived} units of '${item.itemName}'. Maximum remaining on order is ${item.quantityRemaining}.`
        );
        return;
      }
      if (item.quantityRejected > 0 && !item.rejectionReason.trim()) {
        setFormError(`Please enter a rejection reason for rejected units of '${item.itemName}'.`);
        return;
      }
    }

    try {
      setIsSubmitting(true);
      const payload: ReceiveGoodsPayload = {
        receivingLocationId,
        receiptDate: new Date(receiptDate).toISOString(),
        invoiceNumber: invoiceNumber.trim() || undefined,
        referenceNumber: deliveryNoteNumber.trim() || undefined,
        remarks: remarks.trim() || undefined,
        items: lineItems
          .filter(item => item.quantityReceived > 0)
          .map(item => ({
            poItemId: item.poItemId,
            quantityReceived: item.quantityReceived,
            quantityAccepted: item.quantityAccepted,
            quantityRejected: item.quantityRejected,
            rejectionReason: item.rejectionReason.trim() || undefined,
            itemCondition: item.itemCondition
          }))
      };

      await onSubmit(purchaseOrder.id, payload);
      onClose();
    } catch (err: any) {
      setFormError(err.message || 'Failed to complete goods receiving.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const totalAcceptedSum = lineItems.reduce((sum, i) => sum + i.quantityAccepted, 0);
  const totalRejectedSum = lineItems.reduce((sum, i) => sum + i.quantityRejected, 0);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-850/50">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-emerald-400">
              <PackageCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                Receive Physical Goods
                <span className="font-mono text-xs px-2 py-0.5 rounded-md bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                  {purchaseOrder.poNumber}
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Supplier: <span className="text-slate-200 font-medium">{purchaseOrder.supplierName}</span> • Authoritative stock intake
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Notice Banner */}
        <div className="px-6 py-3 bg-amber-500/10 border-b border-amber-500/20 flex items-center gap-2.5 text-xs text-amber-300">
          <ShieldAlert className="w-4 h-4 flex-shrink-0" />
          <span>
            <strong>Inventory Rule:</strong> Physical stock levels will increase ONLY for accepted units upon completion of this intake. Rejected units will be quarantined.
          </span>
        </div>

        {formError && (
          <div className="mx-6 mt-4 p-3 bg-red-500/10 border border-red-500/20 rounded-xl flex items-center gap-2 text-xs text-red-400">
            <AlertTriangle className="w-4 h-4 flex-shrink-0" />
            <span>{formError}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Intake Metadata */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Receiving Warehouse / Location *
              </label>
              <div className="relative">
                <Building className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <select
                  value={receivingLocationId}
                  onChange={(e) => setReceivingLocationId(e.target.value)}
                  required
                  className="w-full pl-9 pr-3 py-2 text-xs rounded-xl bg-slate-800 border border-slate-700 text-white focus:outline-none focus:border-indigo-500"
                >
                  <option value="" disabled>Select Location</option>
                  {locations.map(loc => (
                    <option key={loc.id} value={loc.id}>
                      {loc.name} ({loc.code})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Receipt Date *
              </label>
              <div className="relative">
                <Calendar className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="date"
                  value={receiptDate}
                  onChange={(e) => setReceiptDate(e.target.value)}
                  required
                  className="w-full pl-9 pr-3 py-2 text-xs rounded-xl bg-slate-800 border border-slate-700 text-white focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Supplier Delivery Note #
              </label>
              <div className="relative">
                <FileText className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  placeholder="e.g. DN-89214"
                  value={deliveryNoteNumber}
                  onChange={(e) => setDeliveryNoteNumber(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs rounded-xl bg-slate-800 border border-slate-700 text-white focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Vendor Invoice # (Optional)
              </label>
              <div className="relative">
                <FileText className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  placeholder="e.g. INV-2026-44"
                  value={invoiceNumber}
                  onChange={(e) => setInvoiceNumber(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs rounded-xl bg-slate-800 border border-slate-700 text-white focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>
          </div>

          {/* Line Items Table */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                <Boxes className="w-3.5 h-3.5 text-indigo-400" />
                Items to Receive & Inspect
              </h3>
              <span className="text-[11px] text-slate-400">
                Remaining on PO must not be exceeded.
              </span>
            </div>

            <div className="border border-slate-700 rounded-xl overflow-hidden bg-slate-850/40">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-800/80 text-slate-400 text-[11px] uppercase tracking-wider border-b border-slate-700">
                  <tr>
                    <th className="py-2.5 px-3">Item Details</th>
                    <th className="py-2.5 px-3 text-center">Ordered</th>
                    <th className="py-2.5 px-3 text-center">Remaining</th>
                    <th className="py-2.5 px-3 w-28 text-center">Qty Received</th>
                    <th className="py-2.5 px-3 w-28 text-center text-emerald-400">Accepted (Stock In)</th>
                    <th className="py-2.5 px-3 w-28 text-center text-rose-400">Rejected</th>
                    <th className="py-2.5 px-3">Condition & Reason</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800 text-slate-200">
                  {lineItems.map((item, idx) => (
                    <tr key={item.poItemId} className="hover:bg-slate-800/30">
                      <td className="py-3 px-3">
                        <div className="font-semibold text-white">{item.itemName}</div>
                        <div className="font-mono text-[10px] text-indigo-400">{item.itemCode}</div>
                      </td>
                      <td className="py-3 px-3 text-center font-mono text-slate-400">
                        {item.quantityOrdered}
                      </td>
                      <td className="py-3 px-3 text-center font-mono font-semibold text-amber-400">
                        {item.quantityRemaining}
                      </td>
                      <td className="py-3 px-3">
                        <input
                          type="number"
                          min={0}
                          max={item.quantityRemaining}
                          value={item.quantityReceived}
                          onChange={(e) => handleReceivedChange(idx, parseInt(e.target.value, 10) || 0)}
                          className="w-full py-1.5 px-2 text-center rounded-lg bg-slate-800 border border-slate-700 font-mono text-xs text-white focus:outline-none focus:border-indigo-500"
                        />
                      </td>
                      <td className="py-3 px-3">
                        <div className="w-full py-1.5 px-2 text-center rounded-lg bg-emerald-500/10 border border-emerald-500/30 font-mono text-xs font-bold text-emerald-400">
                          {item.quantityAccepted}
                        </div>
                      </td>
                      <td className="py-3 px-3">
                        <input
                          type="number"
                          min={0}
                          max={item.quantityReceived}
                          value={item.quantityRejected}
                          onChange={(e) => handleRejectedChange(idx, parseInt(e.target.value, 10) || 0)}
                          className="w-full py-1.5 px-2 text-center rounded-lg bg-rose-500/10 border border-rose-500/30 font-mono text-xs text-rose-400 focus:outline-none focus:border-rose-500"
                        />
                      </td>
                      <td className="py-3 px-3 space-y-1.5">
                        <select
                          value={item.itemCondition}
                          onChange={(e) => handleConditionChange(idx, e.target.value)}
                          className="w-full py-1 px-2 text-[11px] rounded bg-slate-800 border border-slate-700 text-slate-200"
                        >
                          <option value="GOOD">Good Condition</option>
                          <option value="DAMAGED">Damaged in Transit</option>
                          <option value="EXPIRED">Expired / Short Expiry</option>
                          <option value="WRONG_SPEC">Wrong Specifications</option>
                        </select>
                        {item.quantityRejected > 0 && (
                          <input
                            type="text"
                            placeholder="Rejection reason required..."
                            value={item.rejectionReason}
                            onChange={(e) => handleRejectionReasonChange(idx, e.target.value)}
                            required
                            className="w-full py-1 px-2 text-[11px] rounded bg-rose-950/40 border border-rose-800/80 text-rose-200 placeholder-rose-400/60"
                          />
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Remarks */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              Receiving Notes / Quality Inspection Remarks
            </label>
            <textarea
              rows={2}
              value={remarks}
              onChange={(e) => setRemarks(e.target.value)}
              placeholder="e.g. Delivered via DHL courier, boxes inspected and verified without external leakage."
              className="w-full p-3 text-xs rounded-xl bg-slate-800 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
            />
          </div>

          {/* Footer Summary & Action */}
          <div className="pt-4 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-4 text-xs">
              <div className="flex items-center gap-1.5 text-emerald-400 font-semibold">
                <CheckCircle2 className="w-4 h-4" />
                <span>+ {totalAcceptedSum} Units Stock In</span>
              </div>
              {totalRejectedSum > 0 && (
                <div className="flex items-center gap-1.5 text-rose-400 font-semibold">
                  <AlertTriangle className="w-4 h-4" />
                  <span>{totalRejectedSum} Units Rejected</span>
                </div>
              )}
            </div>

            <div className="flex items-center gap-3 w-full sm:w-auto">
              <button
                type="button"
                onClick={onClose}
                disabled={isSubmitting}
                className="flex-1 sm:flex-none px-4 py-2 text-xs font-semibold rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmitting || totalAcceptedSum + totalRejectedSum === 0}
                className="flex-1 sm:flex-none px-5 py-2 text-xs font-semibold rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-950 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <PackageCheck className="w-4 h-4" />
                {isSubmitting ? 'Recording Goods Receipt...' : 'Confirm Goods Intake'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
