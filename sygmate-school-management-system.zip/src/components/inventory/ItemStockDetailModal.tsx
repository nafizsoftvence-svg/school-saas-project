import React, { useState, useEffect } from 'react';
import {
  X,
  Package,
  Building,
  Layers,
  ArrowDownLeft,
  ArrowUpRight,
  TrendingDown,
  AlertTriangle,
  CheckCircle,
  Clock,
  Plus
} from 'lucide-react';
import { InventoryItem, ItemStockBalance, StockMovement } from '../../types';
import { api } from '../../services/api';

interface ItemStockDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  itemId: string | null;
  onQuickAction?: (mode: 'IN' | 'OUT' | 'TRANSFER' | 'ADJUST', item: InventoryItem, locationId?: string) => void;
}

export const ItemStockDetailModal: React.FC<ItemStockDetailModalProps> = ({
  isOpen,
  onClose,
  itemId,
  onQuickAction
}) => {
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState<{
    item: InventoryItem;
    totalQuantity: number;
    locationBalances: ItemStockBalance[];
    recentMovements: StockMovement[];
  } | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen && itemId) {
      setLoading(true);
      setError(null);
      api.inventory.getItemStockDetail(itemId)
        .then(res => {
          const detail = (res as any)?.data ?? res;
          if (detail) setData(detail);
        })
        .catch(err => {
          setError(err.message || 'Failed to load item stock details');
        })
        .finally(() => setLoading(false));
    } else {
      setData(null);
    }
  }, [isOpen, itemId]);

  if (!isOpen) return null;

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'IN_STOCK':
        return (
          <span className="px-2 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1">
            <CheckCircle className="w-3 h-3" />
            In Stock
          </span>
        );
      case 'LOW_STOCK':
        return (
          <span className="px-2 py-0.5 rounded-full text-xs font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/20 flex items-center gap-1">
            <AlertTriangle className="w-3 h-3" />
            Low Stock
          </span>
        );
      case 'REORDER_REQUIRED':
        return (
          <span className="px-2 py-0.5 rounded-full text-xs font-semibold bg-orange-500/10 text-orange-400 border border-orange-500/20 flex items-center gap-1">
            <TrendingDown className="w-3 h-3" />
            Reorder Level
          </span>
        );
      case 'OUT_OF_STOCK':
        return (
          <span className="px-2 py-0.5 rounded-full text-xs font-semibold bg-rose-500/10 text-rose-400 border border-rose-500/20 flex items-center gap-1">
            <X className="w-3 h-3" />
            Out of Stock
          </span>
        );
      default:
        return null;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm overflow-y-auto">
      <div className="w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-6">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800 bg-slate-900/80">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
              <Package className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white tracking-tight">
                {data?.item?.name || 'Stock Level Overview'}
              </h3>
              <p className="text-xs text-slate-400 font-mono">
                SKU: {data?.item?.itemCode} • Category: {data?.item?.categoryName || 'General'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {loading && (
            <div className="py-12 flex flex-col items-center justify-center space-y-3">
              <div className="w-8 h-8 border-2 border-indigo-500/30 border-t-indigo-500 rounded-full animate-spin" />
              <p className="text-xs text-slate-400">Loading store balances...</p>
            </div>
          )}

          {error && (
            <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs">
              {error}
            </div>
          )}

          {!loading && data && (
            <>
              {/* Top Aggregate KPI Card */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-4 rounded-xl bg-slate-950 border border-slate-800">
                <div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase">Total Stock (All Stores)</span>
                  <p className="text-xl font-bold font-mono text-white mt-0.5">
                    {data.totalQuantity ?? 0} <span className="text-xs font-normal text-slate-400">{data.item?.unitShortCode || 'units'}</span>
                  </p>
                </div>

                <div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase">Unit Price</span>
                  <p className="text-xl font-bold font-mono text-emerald-400 mt-0.5">
                    ${data.item?.unitPrice ? data.item.unitPrice.toFixed(2) : '0.00'}
                  </p>
                </div>

                <div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase">Total Inventory Value</span>
                  <p className="text-xl font-bold font-mono text-indigo-400 mt-0.5">
                    ${((data.totalQuantity || 0) * (data.item?.unitPrice || 0)).toFixed(2)}
                  </p>
                </div>

                <div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase">Reorder Threshold</span>
                  <p className="text-xl font-bold font-mono text-amber-400 mt-0.5">
                    {data.item?.reorderLevel || 0}
                  </p>
                </div>
              </div>

              {/* Location Balances Table */}
              <div>
                <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2.5 flex items-center gap-1.5">
                  <Building className="w-3.5 h-3.5 text-indigo-400" />
                  Store Balances Breakdown
                </h4>

                <div className="rounded-xl border border-slate-800 overflow-hidden bg-slate-950">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-900/80 border-b border-slate-800 text-[11px] text-slate-400 uppercase font-semibold">
                      <tr>
                        <th className="py-2.5 px-3">Location / Store</th>
                        <th className="py-2.5 px-3">Quantity</th>
                        <th className="py-2.5 px-3">Status</th>
                        <th className="py-2.5 px-3">Valuation</th>
                        <th className="py-2.5 px-3 text-right">Quick Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800 text-slate-300">
                      {(data.locationBalances?.length || 0) === 0 ? (
                        <tr>
                          <td colSpan={5} className="py-4 text-center text-slate-500">
                            No stock recorded in any store yet.
                          </td>
                        </tr>
                      ) : (
                        data.locationBalances.map(bal => (
                          <tr key={bal.id} className="hover:bg-slate-900/50">
                            <td className="py-2.5 px-3">
                              <span className="font-medium text-white">{bal.locationName}</span>
                              <span className="text-[10px] font-mono text-slate-400 block">{bal.locationCode}</span>
                            </td>
                            <td className="py-2.5 px-3 font-mono font-bold text-white">
                              {bal.quantity} {bal.unitShortCode || data.item?.unitShortCode || 'units'}
                            </td>
                            <td className="py-2.5 px-3">
                              {getStatusBadge(bal.stockStatus)}
                            </td>
                            <td className="py-2.5 px-3 font-mono text-slate-300">
                              ${(bal.quantity * (data.item?.unitPrice || bal.unitPrice || 0)).toFixed(2)}
                            </td>
                            <td className="py-2.5 px-3 text-right space-x-1">
                              {onQuickAction && data.item && (
                                <>
                                  <button
                                    onClick={() => {
                                      onClose();
                                      onQuickAction('IN', data.item, bal.locationId);
                                    }}
                                    className="px-2 py-1 text-[11px] font-semibold rounded bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20"
                                  >
                                    + In
                                  </button>
                                  <button
                                    onClick={() => {
                                      onClose();
                                      onQuickAction('OUT', data.item, bal.locationId);
                                    }}
                                    className="px-2 py-1 text-[11px] font-semibold rounded bg-rose-500/10 text-rose-400 hover:bg-rose-500/20"
                                  >
                                    - Out
                                  </button>
                                  <button
                                    onClick={() => {
                                      onClose();
                                      onQuickAction('TRANSFER', data.item, bal.locationId);
                                    }}
                                    className="px-2 py-1 text-[11px] font-semibold rounded bg-blue-500/10 text-blue-400 hover:bg-blue-500/20"
                                  >
                                    Transfer
                                  </button>
                                  <button
                                    onClick={() => {
                                      onClose();
                                      onQuickAction('ADJUST', data.item, bal.locationId);
                                    }}
                                    className="px-2 py-1 text-[11px] font-semibold rounded bg-purple-500/10 text-purple-400 hover:bg-purple-500/20"
                                  >
                                    Adjust
                                  </button>
                                </>
                              )}
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Recent Movement Activity */}
              <div>
                <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2.5 flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-indigo-400" />
                  Recent Ledger Movements ({data.recentMovements?.length || 0})
                </h4>

                <div className="rounded-xl border border-slate-800 overflow-hidden bg-slate-950">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-900/80 border-b border-slate-800 text-[11px] text-slate-400 uppercase font-semibold">
                      <tr>
                        <th className="py-2.5 px-3">Date</th>
                        <th className="py-2.5 px-3">Type</th>
                        <th className="py-2.5 px-3">Location</th>
                        <th className="py-2.5 px-3">Qty</th>
                        <th className="py-2.5 px-3">Balance After</th>
                        <th className="py-2.5 px-3">User</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800 text-slate-300">
                      {(data.recentMovements?.length || 0) === 0 ? (
                        <tr>
                          <td colSpan={6} className="py-4 text-center text-slate-500">
                            No ledger movements recorded yet.
                          </td>
                        </tr>
                      ) : (
                        data.recentMovements.slice(0, 5).map(m => (
                          <tr key={m.id} className="hover:bg-slate-900/50">
                            <td className="py-2 px-3 font-mono text-slate-400">{m.date || m.timestamp || (m as any).transactionDate || '-'}</td>
                            <td className="py-2 px-3">
                              <span className="font-semibold text-slate-200">{m.movementType}</span>
                            </td>
                            <td className="py-2 px-3 font-medium text-white">{m.locationName}</td>
                            <td className="py-2 px-3 font-mono font-bold text-white">
                              {(m as any).quantity ?? ((m.quantityIn || 0) > 0 ? `+${m.quantityIn}` : (m.quantityOut || 0) > 0 ? `-${m.quantityOut}` : 0)} {m.unitShortCode || data.item?.unitShortCode || 'units'}
                            </td>
                            <td className="py-2 px-3 font-mono text-indigo-400 font-semibold">{m.balanceAfter}</td>
                            <td className="py-2 px-3 text-slate-400">{m.userName || (m as any).createdByName || 'System'}</td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          )}

          {/* Footer */}
          <div className="flex justify-end pt-4 border-t border-slate-800">
            <button
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold rounded-xl bg-slate-800 hover:bg-slate-700 text-white transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
