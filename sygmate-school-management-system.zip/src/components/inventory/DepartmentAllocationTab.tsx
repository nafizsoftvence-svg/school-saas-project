import React, { useState, useEffect } from 'react';
import {
  Building,
  ShieldCheck,
  Package,
  Users,
  Search,
  Filter,
  RefreshCw,
  Plus,
  Eye,
  ArrowRight,
  RotateCcw,
  Tag,
  DollarSign,
  AlertCircle,
  Truck,
  Layers,
  Clock
} from 'lucide-react';
import {
  Department,
  Asset,
  StockIssue,
  DepartmentAllocationSummary,
  AssetStatus
} from '../../types';
import { api } from '../../services/api';

interface DepartmentAllocationTabProps {
  departments: Department[];
  onOpenAssetDetails: (asset: Asset) => void;
  onOpenBulkAllocation: () => void;
  showNotification: (msg: string, isError?: boolean) => void;
}

export const DepartmentAllocationTab: React.FC<DepartmentAllocationTabProps> = ({
  departments,
  onOpenAssetDetails,
  onOpenBulkAllocation,
  showNotification
}) => {
  const [selectedDeptId, setSelectedDeptId] = useState<string>(departments[0]?.id || 'ALL');
  const [summaries, setSummaries] = useState<DepartmentAllocationSummary[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [subTab, setSubTab] = useState<'assets' | 'issues' | 'custodians'>('assets');

  const loadDepartmentData = async () => {
    try {
      setLoading(true);
      const data = await api.inventory.getDepartmentAllocations(selectedDeptId);
      const rawData = (data as any)?.data ?? data;
      const list = Array.isArray(rawData) ? rawData : [];
      setSummaries(list);
    } catch (err: any) {
      showNotification(err.message || 'Failed to load department allocations', true);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadDepartmentData();
  }, [selectedDeptId]);

  const safeSummaries = Array.isArray(summaries) ? summaries : [];

  const currentSummary = safeSummaries[0] || {
    departmentId: '',
    departmentName: '',
    departmentCode: '',
    totalAssetsCount: 0,
    activeAssetsCount: 0,
    totalAssetValuation: 0,
    activeCustodiansCount: 0,
    totalIssuesCount: 0,
    totalItemsIssued: 0,
    pendingReturnsCount: 0,
    assets: [],
    issues: [],
    custodians: []
  };

  // Aggregated totals across all summaries
  const totalAssetsAcross = safeSummaries.reduce((sum, s) => sum + (s.totalAssetsCount || 0), 0);
  const totalValuationAcross = safeSummaries.reduce((sum, s) => sum + (s.totalAssetValuation || 0), 0);
  const totalCustodiansAcross = safeSummaries.reduce((sum, s) => sum + (s.activeCustodiansCount || 0), 0);
  const totalIssuesAcross = safeSummaries.reduce((sum, s) => sum + (s.totalIssuesCount || 0), 0);

  // Filtered department assets
  const filteredAssets = (selectedDeptId === 'ALL' ? safeSummaries.flatMap((s) => s.assets || []) : (currentSummary.assets || [])).filter((a) => {
    if (!searchTerm.trim()) return true;
    const q = searchTerm.trim().toLowerCase();
    return (
      (a.name || '').toLowerCase().includes(q) ||
      (a.assetTag || '').toLowerCase().includes(q) ||
      (a.currentAssigneeName && a.currentAssigneeName.toLowerCase().includes(q)) ||
      (a.categoryName && a.categoryName.toLowerCase().includes(q)) ||
      (a.locationName && a.locationName.toLowerCase().includes(q))
    );
  });

  // Filtered department stock issues
  const filteredIssues = (selectedDeptId === 'ALL' ? safeSummaries.flatMap((s) => s.issues || []) : (currentSummary.issues || [])).filter((i) => {
    if (!searchTerm.trim()) return true;
    const q = searchTerm.trim().toLowerCase();
    return (
      (i.issueNumber || '').toLowerCase().includes(q) ||
      (i.recipientName || '').toLowerCase().includes(q) ||
      (i.departmentName || '').toLowerCase().includes(q) ||
      (i.purpose || '').toLowerCase().includes(q)
    );
  });

  // Filtered custodians
  const filteredCustodians = (selectedDeptId === 'ALL' ? safeSummaries.flatMap((s) => s.custodians || []) : (currentSummary.custodians || [])).filter((c) => {
    if (!searchTerm.trim()) return true;
    const q = searchTerm.trim().toLowerCase();
    return (c.name || '').toLowerCase().includes(q);
  });

  const getStatusBadge = (status: AssetStatus) => {
    switch (status) {
      case 'ASSIGNED':
        return (
          <span className="inline-flex items-center px-2 py-0.5 text-xs font-semibold rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/20">
            Assigned
          </span>
        );
      case 'AVAILABLE':
      case 'ACTIVE':
        return (
          <span className="inline-flex items-center px-2 py-0.5 text-xs font-semibold rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            Available
          </span>
        );
      case 'UNDER_REPAIR':
        return (
          <span className="inline-flex items-center px-2 py-0.5 text-xs font-semibold rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20">
            Under Repair
          </span>
        );
      case 'DAMAGED':
        return (
          <span className="inline-flex items-center px-2 py-0.5 text-xs font-semibold rounded-full bg-rose-500/10 text-rose-400 border border-rose-500/20">
            Damaged
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center px-2 py-0.5 text-xs font-semibold rounded-full bg-slate-500/10 text-slate-400">
            {status}
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Controls */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Building className="w-6 h-6 text-purple-400" />
            Department Allocation & Custody Workflow
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Traceable departmental asset registers, inventory consumption, and active personal custody
          </p>
        </div>

        <div className="flex items-center space-x-2.5">
          <button
            onClick={loadDepartmentData}
            disabled={loading}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors disabled:opacity-50"
            title="Refresh"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>

          <button
            onClick={onOpenBulkAllocation}
            className="px-4 py-2 text-xs font-bold rounded-xl bg-purple-600 hover:bg-purple-500 text-white transition-colors flex items-center gap-1.5 shadow-lg shadow-purple-900/30"
          >
            <Plus className="w-4 h-4" />
            Bulk Asset Allocation
          </button>
        </div>
      </div>

      {/* Department Selector */}
      <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center space-x-3 w-full sm:w-auto">
          <span className="text-xs font-bold text-slate-300 uppercase tracking-wider whitespace-nowrap">
            Department:
          </span>
          <select
            value={selectedDeptId}
            onChange={(e) => setSelectedDeptId(e.target.value)}
            className="px-3.5 py-2 text-xs font-semibold rounded-xl bg-slate-800 border border-slate-700 text-white focus:outline-none focus:border-purple-500 min-w-[260px]"
          >
            <option value="ALL">All School Departments (Consolidated)</option>
            {departments.map((dept) => (
              <option key={dept.id} value={dept.id}>
                {dept.name} ({dept.code})
              </option>
            ))}
          </select>
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-500" />
          <input
            type="text"
            placeholder="Search within department..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl bg-slate-800/80 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
          />
        </div>
      </div>

      {/* KPI Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-center justify-between">
          <div>
            <div className="text-[11px] font-medium text-slate-400">Assigned Assets</div>
            <div className="text-2xl font-bold text-blue-400 mt-1">
              {selectedDeptId === 'ALL' ? totalAssetsAcross : currentSummary.totalAssetsCount}
            </div>
            <div className="text-[10px] text-slate-500 mt-0.5">
              Valuation: ${Math.round(selectedDeptId === 'ALL' ? totalValuationAcross : currentSummary.totalAssetValuation).toLocaleString()}
            </div>
          </div>
          <div className="p-3 rounded-xl bg-blue-500/10 text-blue-400 border border-blue-500/20">
            <ShieldCheck className="w-5 h-5" />
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-center justify-between">
          <div>
            <div className="text-[11px] font-medium text-slate-400">Active Custodians</div>
            <div className="text-2xl font-bold text-emerald-400 mt-1">
              {selectedDeptId === 'ALL' ? totalCustodiansAcross : currentSummary.activeCustodiansCount}
            </div>
            <div className="text-[10px] text-slate-500 mt-0.5">Staff & faculty members</div>
          </div>
          <div className="p-3 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            <Users className="w-5 h-5" />
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-center justify-between">
          <div>
            <div className="text-[11px] font-medium text-slate-400">Stock Issues</div>
            <div className="text-2xl font-bold text-purple-400 mt-1">
              {selectedDeptId === 'ALL' ? totalIssuesAcross : currentSummary.totalIssuesCount}
            </div>
            <div className="text-[10px] text-slate-500 mt-0.5">
              {selectedDeptId === 'ALL'
                ? 'Department dispatches'
                : `${currentSummary.totalItemsIssued} consumable units`}
            </div>
          </div>
          <div className="p-3 rounded-xl bg-purple-500/10 text-purple-400 border border-purple-500/20">
            <Truck className="w-5 h-5" />
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-center justify-between">
          <div>
            <div className="text-[11px] font-medium text-slate-400">Pending Return Orders</div>
            <div className="text-2xl font-bold text-amber-400 mt-1">
              {selectedDeptId === 'ALL'
                ? summaries.reduce((s, d) => s + d.pendingReturnsCount, 0)
                : currentSummary.pendingReturnsCount}
            </div>
            <div className="text-[10px] text-slate-500 mt-0.5">Dispatches open for return</div>
          </div>
          <div className="p-3 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
            <RotateCcw className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Sub Tabs */}
      <div className="flex border-b border-slate-800 space-x-2">
        <button
          onClick={() => setSubTab('assets')}
          className={`pb-3 px-4 text-xs font-semibold flex items-center gap-2 border-b-2 transition-colors ${
            subTab === 'assets'
              ? 'border-purple-500 text-purple-400'
              : 'border-transparent text-slate-400 hover:text-white'
          }`}
        >
          <ShieldCheck className="w-4 h-4" />
          Department Assets ({filteredAssets.length})
        </button>

        <button
          onClick={() => setSubTab('issues')}
          className={`pb-3 px-4 text-xs font-semibold flex items-center gap-2 border-b-2 transition-colors ${
            subTab === 'issues'
              ? 'border-blue-500 text-blue-400'
              : 'border-transparent text-slate-400 hover:text-white'
          }`}
        >
          <Package className="w-4 h-4" />
          Consumable Stock Issues ({filteredIssues.length})
        </button>

        <button
          onClick={() => setSubTab('custodians')}
          className={`pb-3 px-4 text-xs font-semibold flex items-center gap-2 border-b-2 transition-colors ${
            subTab === 'custodians'
              ? 'border-emerald-500 text-emerald-400'
              : 'border-transparent text-slate-400 hover:text-white'
          }`}
        >
          <Users className="w-4 h-4" />
          Active Custodians ({filteredCustodians.length})
        </button>
      </div>

      {/* 1. ASSETS TABLE */}
      {subTab === 'assets' && (
        <div className="border border-slate-800 rounded-2xl overflow-hidden bg-slate-900/50">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-800/80 text-slate-400 border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4 font-semibold">Asset Tag</th>
                  <th className="py-3 px-4 font-semibold">Asset Name & Specifications</th>
                  <th className="py-3 px-4 font-semibold">Category</th>
                  <th className="py-3 px-4 font-semibold">Custodian / Assignee</th>
                  <th className="py-3 px-4 font-semibold">Physical Location</th>
                  <th className="py-3 px-4 font-semibold">Condition</th>
                  <th className="py-3 px-4 font-semibold">Status</th>
                  <th className="py-3 px-4 font-semibold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {filteredAssets.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-8 text-center text-slate-500">
                      No assets allocated to this department matching criteria.
                    </td>
                  </tr>
                ) : (
                  filteredAssets.map((asset) => (
                    <tr key={asset.id} className="hover:bg-slate-800/30 transition-colors">
                      <td className="py-3 px-4 font-mono font-bold text-blue-400">{asset.assetTag}</td>
                      <td className="py-3 px-4">
                        <div className="font-semibold text-white">{asset.name}</div>
                        <div className="text-[11px] text-slate-400">
                          {[asset.brand, asset.model, asset.serialNumber ? `S/N: ${asset.serialNumber}` : null]
                            .filter(Boolean)
                            .join(' • ')}
                        </div>
                      </td>
                      <td className="py-3 px-4 text-slate-300">{asset.categoryName}</td>
                      <td className="py-3 px-4">
                        <div className="font-semibold text-white">
                          {asset.currentAssigneeName || 'Department Shared'}
                        </div>
                        <div className="text-[11px] text-slate-500 font-mono">
                          {asset.currentAssigneeType || 'UNASSIGNED'}
                        </div>
                      </td>
                      <td className="py-3 px-4 text-slate-300">{asset.locationName}</td>
                      <td className="py-3 px-4">
                        <span className="font-semibold text-slate-300">{asset.condition || 'GOOD'}</span>
                      </td>
                      <td className="py-3 px-4">{getStatusBadge(asset.status)}</td>
                      <td className="py-3 px-4 text-right">
                        <button
                          onClick={() => onOpenAssetDetails(asset)}
                          className="px-2.5 py-1 text-xs font-semibold rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors inline-flex items-center gap-1"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          View
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 2. STOCK ISSUES TABLE */}
      {subTab === 'issues' && (
        <div className="border border-slate-800 rounded-2xl overflow-hidden bg-slate-900/50">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-800/80 text-slate-400 border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4 font-semibold">Issue #</th>
                  <th className="py-3 px-4 font-semibold">Department</th>
                  <th className="py-3 px-4 font-semibold">Recipient / Room</th>
                  <th className="py-3 px-4 font-semibold">Purpose</th>
                  <th className="py-3 px-4 font-semibold text-center">Items Dispatched</th>
                  <th className="py-3 px-4 font-semibold">Date</th>
                  <th className="py-3 px-4 font-semibold">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {filteredIssues.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-8 text-center text-slate-500">
                      No stock issue transactions recorded for this department.
                    </td>
                  </tr>
                ) : (
                  filteredIssues.map((issue) => (
                    <tr key={issue.id} className="hover:bg-slate-800/30 transition-colors">
                      <td className="py-3 px-4 font-mono font-bold text-emerald-400">{issue.issueNumber}</td>
                      <td className="py-3 px-4 text-slate-200 font-medium">{issue.departmentName}</td>
                      <td className="py-3 px-4 text-white font-semibold">{issue.recipientName}</td>
                      <td className="py-3 px-4 text-slate-300 max-w-xs truncate">{issue.purpose}</td>
                      <td className="py-3 px-4 text-center font-mono">
                        <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700 font-semibold">
                          {(issue.items || []).reduce((s, it) => s + (it.quantityIssued || 0), 0)} units
                        </span>
                      </td>
                      <td className="py-3 px-4 text-slate-300">
                        {new Date(issue.issueDate).toLocaleDateString()}
                      </td>
                      <td className="py-3 px-4">
                        <span className="px-2 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                          {issue.status}
                        </span>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 3. CUSTODIANS TABLE */}
      {subTab === 'custodians' && (
        <div className="border border-slate-800 rounded-2xl overflow-hidden bg-slate-900/50">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-800/80 text-slate-400 border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4 font-semibold">Custodian Name</th>
                  <th className="py-3 px-4 font-semibold">Role / Type</th>
                  <th className="py-3 px-4 font-semibold text-center">Assigned Assets Count</th>
                  <th className="py-3 px-4 font-semibold text-right">Custody Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {filteredCustodians.length === 0 ? (
                  <tr>
                    <td colSpan={4} className="py-8 text-center text-slate-500">
                      No individual custodians currently hold active asset assignments in this department.
                    </td>
                  </tr>
                ) : (
                  filteredCustodians.map((c, idx) => (
                    <tr key={idx} className="hover:bg-slate-800/30 transition-colors">
                      <td className="py-3 px-4 font-semibold text-white flex items-center gap-2">
                        <div className="w-7 h-7 rounded-full bg-purple-500/10 text-purple-400 border border-purple-500/20 flex items-center justify-center font-bold">
                          {c.name.charAt(0)}
                        </div>
                        {c.name}
                      </td>
                      <td className="py-3 px-4 text-slate-300 font-mono">{c.role || 'STAFF'}</td>
                      <td className="py-3 px-4 text-center font-mono">
                        <span className="px-2.5 py-1 rounded-lg bg-blue-500/10 text-blue-400 border border-blue-500/20 font-bold">
                          {c.assignedAssetsCount} {c.assignedAssetsCount === 1 ? 'Asset' : 'Assets'}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <span className="inline-flex items-center px-2 py-0.5 text-xs font-semibold rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                          Active Custody
                        </span>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
