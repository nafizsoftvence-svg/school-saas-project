import React from 'react';
import {
  Package,
  ShieldCheck,
  DollarSign,
  AlertTriangle,
  Building,
  Truck,
  Plus,
  ArrowRight,
  Clock,
  Sparkles,
  Layers,
  MapPin,
  Tag,
  BarChart3
} from 'lucide-react';
import {
  InventoryDashboardStats,
  InventoryItem,
  Asset
} from '../../types';

interface InventoryDashboardTabProps {
  stats: InventoryDashboardStats | null;
  loading: boolean;
  onNavigateTab: (tab: 'items' | 'stock' | 'issues' | 'departments' | 'procurement' | 'assets' | 'suppliers' | 'setup' | 'reports') => void;
  onOpenNewItemModal: () => void;
  onOpenNewAssetModal: () => void;
  onOpenNewSupplierModal: () => void;
  onSelectAsset?: (asset: Asset) => void;
}

export const InventoryDashboardTab: React.FC<InventoryDashboardTabProps> = ({
  stats,
  loading,
  onNavigateTab,
  onOpenNewItemModal,
  onOpenNewAssetModal,
  onOpenNewSupplierModal,
  onSelectAsset
}) => {
  if (loading && !stats) {
    return (
      <div className="flex items-center justify-center p-12 text-slate-400">
        <div className="w-8 h-8 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin mr-3" />
        Loading inventory intelligence overview...
      </div>
    );
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      maximumFractionDigits: 0
    }).format(amount);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'ACTIVE':
      case 'AVAILABLE':
        return <span className="px-2 py-0.5 text-xs font-semibold rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">Active</span>;
      case 'ASSIGNED':
        return <span className="px-2 py-0.5 text-xs font-semibold rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/20">Assigned</span>;
      case 'UNDER_REPAIR':
        return <span className="px-2 py-0.5 text-xs font-semibold rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20">Under Repair</span>;
      case 'DAMAGED':
      case 'LOST':
        return <span className="px-2 py-0.5 text-xs font-semibold rounded-full bg-rose-500/10 text-rose-400 border border-rose-500/20">{status}</span>;
      default:
        return <span className="px-2 py-0.5 text-xs font-semibold rounded-full bg-slate-500/10 text-slate-400 border border-slate-500/20">{status}</span>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Quick Action Ribbon */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-4 rounded-xl glass-panel border border-slate-800">
        <div className="flex items-center space-x-3">
          <div className="p-2.5 rounded-lg bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-white">Inventory & Asset Command Center</h3>
            <p className="text-xs text-slate-400">Institutional logistics, asset tags, stock thresholds, and suppliers</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={onOpenNewItemModal}
            className="px-3.5 py-1.5 text-xs font-semibold rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white transition-colors flex items-center gap-1.5 shadow-sm shadow-indigo-950"
          >
            <Plus className="w-3.5 h-3.5" />
            New Item
          </button>
          <button
            onClick={onOpenNewAssetModal}
            className="px-3.5 py-1.5 text-xs font-semibold rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white transition-colors flex items-center gap-1.5 shadow-sm shadow-emerald-950"
          >
            <Plus className="w-3.5 h-3.5" />
            Register Asset
          </button>
          <button
            onClick={onOpenNewSupplierModal}
            className="px-3.5 py-1.5 text-xs font-semibold rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors flex items-center gap-1.5"
          >
            <Plus className="w-3.5 h-3.5" />
            Add Supplier
          </button>
          <button
            onClick={() => onNavigateTab('stock')}
            className="px-3.5 py-1.5 text-xs font-semibold rounded-lg bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/30 transition-colors flex items-center gap-1.5"
          >
            <Layers className="w-3.5 h-3.5" />
            Stock Control
          </button>
          <button
            onClick={() => onNavigateTab('issues')}
            className="px-3.5 py-1.5 text-xs font-semibold rounded-lg bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 border border-blue-500/30 transition-colors flex items-center gap-1.5"
          >
            <Package className="w-3.5 h-3.5" />
            Issue & Return
          </button>
          <button
            onClick={() => onNavigateTab('departments')}
            className="px-3.5 py-1.5 text-xs font-semibold rounded-lg bg-purple-600/20 hover:bg-purple-600/30 text-purple-300 border border-purple-500/30 transition-colors flex items-center gap-1.5"
          >
            <Building className="w-3.5 h-3.5" />
            Departments
          </button>
          <button
            onClick={() => onNavigateTab('reports')}
            className="px-3.5 py-1.5 text-xs font-semibold rounded-lg bg-indigo-600/30 hover:bg-indigo-600/40 text-indigo-200 border border-indigo-500/40 transition-colors flex items-center gap-1.5"
          >
            <BarChart3 className="w-3.5 h-3.5" />
            Reports & Analytics
          </button>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        {/* Total Items */}
        <div
          onClick={() => onNavigateTab('items')}
          className="p-4 rounded-xl glass-card border border-slate-800 hover:border-indigo-500/40 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-slate-400">Inventory Items</span>
            <div className="p-2 rounded-lg bg-indigo-500/10 text-indigo-400 group-hover:scale-105 transition-transform">
              <Package className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-white mb-1">
            {stats?.totalItems || 0}
          </div>
          <div className="text-xs text-slate-400 flex items-center justify-between">
            <span>{stats?.activeItems || 0} active</span>
            <ArrowRight className="w-3 h-3 text-slate-500 group-hover:text-indigo-400 transition-colors" />
          </div>
        </div>

        {/* Total Assets */}
        <div
          onClick={() => onNavigateTab('assets')}
          className="p-4 rounded-xl glass-card border border-slate-800 hover:border-emerald-500/40 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-slate-400">Registered Assets</span>
            <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400 group-hover:scale-105 transition-transform">
              <ShieldCheck className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-white mb-1">
            {stats?.totalAssets || 0}
          </div>
          <div className="text-xs text-slate-400 flex items-center justify-between">
            <span>{stats?.activeAssets || 0} in active use</span>
            <ArrowRight className="w-3 h-3 text-slate-500 group-hover:text-emerald-400 transition-colors" />
          </div>
        </div>

        {/* Asset Valuation */}
        <div
          onClick={() => onNavigateTab('reports')}
          className="p-4 rounded-xl glass-card border border-slate-800 hover:border-violet-500/40 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-slate-400">Asset Valuation</span>
            <div className="p-2 rounded-lg bg-violet-500/10 text-violet-400 group-hover:scale-105 transition-transform">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-white mb-1">
            {formatCurrency(stats?.totalAssetValuation || 0)}
          </div>
          <div className="text-xs text-slate-400 flex items-center justify-between">
            <span>Recorded purchase cost</span>
            <ArrowRight className="w-3 h-3 text-slate-500 group-hover:text-violet-400 transition-colors" />
          </div>
        </div>

        {/* Low Stock Alert */}
        <div
          onClick={() => onNavigateTab('items')}
          className="p-4 rounded-xl glass-card border border-slate-800 hover:border-amber-500/40 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-slate-400">Reorder Thresholds</span>
            <div className="p-2 rounded-lg bg-amber-500/10 text-amber-400 group-hover:scale-105 transition-transform">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-amber-400 mb-1">
            {stats?.lowStockThresholdItems || 0}
          </div>
          <div className="text-xs text-slate-400 flex items-center justify-between">
            <span>Monitored items</span>
            <ArrowRight className="w-3 h-3 text-slate-500 group-hover:text-amber-400 transition-colors" />
          </div>
        </div>

        {/* Locations */}
        <div
          onClick={() => onNavigateTab('setup')}
          className="p-4 rounded-xl glass-card border border-slate-800 hover:border-blue-500/40 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-slate-400">Stores & Locations</span>
            <div className="p-2 rounded-lg bg-blue-500/10 text-blue-400 group-hover:scale-105 transition-transform">
              <Building className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-white mb-1">
            {stats?.totalLocations || 0}
          </div>
          <div className="text-xs text-slate-400 flex items-center justify-between">
            <span>Institutional stores</span>
            <ArrowRight className="w-3 h-3 text-slate-500 group-hover:text-blue-400 transition-colors" />
          </div>
        </div>

        {/* Suppliers */}
        <div
          onClick={() => onNavigateTab('suppliers')}
          className="p-4 rounded-xl glass-card border border-slate-800 hover:border-teal-500/40 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-slate-400">Vendors / Suppliers</span>
            <div className="p-2 rounded-lg bg-teal-500/10 text-teal-400 group-hover:scale-105 transition-transform">
              <Truck className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-white mb-1">
            {stats?.totalSuppliers || 0}
          </div>
          <div className="text-xs text-slate-400 flex items-center justify-between">
            <span>Active vendors</span>
            <ArrowRight className="w-3 h-3 text-slate-500 group-hover:text-teal-400 transition-colors" />
          </div>
        </div>
      </div>

      {/* Two Column Section: Recent Items & Recent Assets */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Inventory Items */}
        <div className="rounded-xl glass-panel border border-slate-800 overflow-hidden">
          <div className="flex items-center justify-between p-4 border-b border-slate-800/80 bg-slate-900/40">
            <div className="flex items-center space-x-2">
              <Package className="w-4 h-4 text-indigo-400" />
              <h4 className="text-sm font-semibold text-white">Recent Inventory Items</h4>
            </div>
            <button
              onClick={() => onNavigateTab('items')}
              className="text-xs font-medium text-indigo-400 hover:text-indigo-300 flex items-center gap-1 transition-colors"
            >
              View all items
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="divide-y divide-slate-800/60">
            {!stats?.recentItems || stats.recentItems.length === 0 ? (
              <div className="p-8 text-center text-slate-400 text-sm">
                No inventory items registered yet.
              </div>
            ) : (
              stats.recentItems.map((item: InventoryItem) => (
                <div key={item.id} className="p-4 hover:bg-slate-800/20 transition-colors flex items-center justify-between">
                  <div className="space-y-1">
                    <div className="flex items-center space-x-2">
                      <span className="font-mono text-xs px-2 py-0.5 rounded bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 font-medium">
                        {item.itemCode}
                      </span>
                      <span className="text-sm font-semibold text-white">{item.name}</span>
                    </div>
                    <div className="flex items-center space-x-3 text-xs text-slate-400">
                      <span className="flex items-center gap-1">
                        <Layers className="w-3 h-3 text-slate-500" />
                        {item.categoryName}
                      </span>
                      <span>•</span>
                      <span>Unit: {item.unitShortCode}</span>
                      {item.locationName && (
                        <>
                          <span>•</span>
                          <span className="flex items-center gap-1">
                            <MapPin className="w-3 h-3 text-slate-500" />
                            {item.locationName}
                          </span>
                        </>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    {getStatusBadge(item.status)}
                    <span className="text-xs text-slate-300 font-mono font-medium">
                      ${Number(item.unitPrice).toFixed(2)}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Recent Assets Registered */}
        <div className="rounded-xl glass-panel border border-slate-800 overflow-hidden">
          <div className="flex items-center justify-between p-4 border-b border-slate-800/80 bg-slate-900/40">
            <div className="flex items-center space-x-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <h4 className="text-sm font-semibold text-white">Recently Registered Assets</h4>
            </div>
            <button
              onClick={() => onNavigateTab('assets')}
              className="text-xs font-medium text-emerald-400 hover:text-emerald-300 flex items-center gap-1 transition-colors"
            >
              View asset register
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="divide-y divide-slate-800/60">
            {!stats?.recentAssets || stats.recentAssets.length === 0 ? (
              <div className="p-8 text-center text-slate-400 text-sm">
                No assets registered yet.
              </div>
            ) : (
              stats.recentAssets.map((asset: Asset) => (
                <div
                  key={asset.id}
                  onClick={() => onSelectAsset && onSelectAsset(asset)}
                  className="p-4 hover:bg-slate-800/20 transition-colors flex items-center justify-between cursor-pointer group"
                >
                  <div className="space-y-1">
                    <div className="flex items-center space-x-2">
                      <span className="font-mono text-xs px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-medium">
                        {asset.assetTag}
                      </span>
                      <span className="text-sm font-semibold text-white group-hover:text-emerald-300 transition-colors">
                        {asset.name}
                      </span>
                    </div>
                    <div className="flex items-center space-x-3 text-xs text-slate-400">
                      <span className="flex items-center gap-1">
                        <Tag className="w-3 h-3 text-slate-500" />
                        {asset.categoryName}
                      </span>
                      <span>•</span>
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-slate-500" />
                        {asset.locationName}
                      </span>
                      {asset.brand && (
                        <>
                          <span>•</span>
                          <span>{asset.brand}</span>
                        </>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    {getStatusBadge(asset.status)}
                    <span className="text-xs font-mono font-medium text-slate-300">
                      ${Number(asset.purchaseCost).toLocaleString()}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
