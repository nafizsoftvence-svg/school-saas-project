import React, { useState } from 'react';
import {
  X,
  RotateCcw,
  AlertCircle,
  Package,
  Layers,
  Building2,
  ShieldCheck,
  AlertTriangle
} from 'lucide-react';
import {
  StockIssue,
  CreateInventoryReturnPayload,
  InventoryLocation,
  InventoryItem,
  InventoryReturnCondition,
  IssueRecipientType
} from '../../types';

interface CreateReturnModalProps {
  isOpen: boolean;
  onClose: () => void;
  originalIssue?: StockIssue | null;
  items: InventoryItem[];
  locations: InventoryLocation[];
  departments: Array<{ id: string; name: string }>;
  staffMembers: Array<{ id: string; name: string }>;
  teachers: Array<{ id: string; name: string }>;
  onSubmit: (payload: CreateInventoryReturnPayload) => Promise<void>;
}

export const CreateReturnModal: React.FC<CreateReturnModalProps> = ({
  isOpen,
  onClose,
  originalIssue,
  items,
  locations,
  departments,
  staffMembers,
  teachers,
  onSubmit
}) => {
  const [returnLocationId, setReturnLocationId] = useState(
    originalIssue?.sourceLocationId || locations[0]?.id || ''
  );
  const [returnedByType, setReturnedByType] = useState<IssueRecipientType>(
    originalIssue?.recipientType || 'DEPARTMENT'
  );
  const [returnedById, setReturnedById] = useState(originalIssue?.recipientId || '');
  const [returnedByName, setReturnedByName] = useState(originalIssue?.recipientName || '');
  const [departmentId, setDepartmentId] = useState(originalIssue?.departmentId || '');
  const [reason, setReason] = useState('');
  const [notes, setNotes] = useState('');

  const [returnLines, setReturnLines] = useState<
    Array<{
      itemId: string;
      itemName: string;
      itemCode: string;
      eligibleReturnQty: number;
      quantity: number;
      condition: InventoryReturnCondition;
      reason?: string;
      unitShortCode: string;
    }>
  >(() => {
    if (originalIssue) {
      return originalIssue.items.map((i) => {
        const eligible = i.quantityIssued - i.quantityReturned;
        return {
          itemId: i.itemId,
          itemName: i.itemName,
          itemCode: i.itemCode,
          eligibleReturnQty: eligible,
          quantity: Math.min(eligible, 1),
          condition: 'GOOD',
          unitShortCode: i.unitShortCode
        };
      });
    }
    const firstItem = items[0];
    return [
      {
        itemId: firstItem?.id || '',
        itemName: firstItem?.name || '',
        itemCode: firstItem?.itemCode || '',
        eligibleReturnQty: 9999,
        quantity: 1,
        condition: 'GOOD',
        unitShortCode: firstItem?.unitShortCode || 'PCS'
      }
    ];
  });

  const [submitting, setSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const updateLine = (idx: number, field: string, val: any) => {
    setReturnLines(
      returnLines.map((line, i) => (i === idx ? { ...line, [field]: val } : line))
    );
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!returnLocationId) {
      setErrorMessage('Please select the return warehouse/location.');
      return;
    }
    if (!returnedById || !returnedByName) {
      setErrorMessage('Please specify who is returning the items.');
      return;
    }
    if (!reason.trim()) {
      setErrorMessage('Please provide a reason for the return.');
      return;
    }

    // Validate quantities
    for (const line of returnLines) {
      if (line.quantity <= 0) {
        setErrorMessage(`Return quantity for '${line.itemName}' must be greater than zero.`);
        return;
      }
      if (originalIssue && line.quantity > line.eligibleReturnQty) {
        setErrorMessage(
          `Cannot return ${line.quantity} of '${line.itemName}'. Only ${line.eligibleReturnQty} units are eligible from Issue ${originalIssue.issueNumber}.`
        );
        return;
      }
    }

    setSubmitting(true);
    try {
      const selectedDept = departments.find((d) => d.id === departmentId);

      await onSubmit({
        originalIssueId: originalIssue?.id,
        returnLocationId,
        returnedByType,
        returnedById,
        returnedByName,
        departmentId: departmentId || undefined,
        departmentName: selectedDept?.name,
        reason: reason.trim(),
        notes: notes.trim() || undefined,
        idempotencyKey: `ret-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        items: returnLines.map((l) => ({
          itemId: l.itemId,
          quantity: l.quantity,
          condition: l.condition,
          reason: l.reason
        }))
      });

      onClose();
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to process inventory return');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
      <div className="w-full max-w-3xl bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl flex flex-col max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-800/40">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
              <RotateCcw className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white tracking-tight">
                {originalIssue ? `Process Return for ${originalIssue.issueNumber}` : 'Record Stock Return'}
              </h2>
              <p className="text-xs text-slate-400">
                Return unused or damaged inventory stock back into school warehouse custody.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-5 space-y-5">
          {errorMessage && (
            <div className="p-3.5 rounded-xl bg-rose-500/15 border border-rose-500/30 flex items-center gap-3 text-rose-300 text-xs">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Section 1: Location and Returnee */}
          <div className="p-4 rounded-xl bg-slate-800/30 border border-slate-800 space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-[11px] font-medium text-slate-300 mb-1">
                  Receiving Store / Warehouse <span className="text-rose-400">*</span>
                </label>
                <select
                  value={returnLocationId}
                  onChange={(e) => setReturnLocationId(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl glass-input border border-slate-700/80 bg-slate-800/90 text-white focus:outline-none focus:border-amber-500"
                >
                  {locations.map((l) => (
                    <option key={l.id} value={l.id}>
                      {l.name} ({l.code})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-medium text-slate-300 mb-1">
                  Returned By Entity
                </label>
                <input
                  type="text"
                  disabled
                  value={`${returnedByName} (${returnedByType})`}
                  className="w-full px-3 py-2 text-xs rounded-xl bg-slate-900 border border-slate-700/80 text-slate-300"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-medium text-slate-300 mb-1">
                Return Reason / Explanation <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Unused exam paper reams returned after term finals"
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl glass-input border border-slate-700/80 bg-slate-800/90 text-white focus:outline-none focus:border-amber-500"
              />
            </div>
          </div>

          {/* Section 2: Items Table */}
          <div className="space-y-2">
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
              <Layers className="w-3.5 h-3.5 text-amber-400" /> Items for Return
            </h3>

            <div className="border border-slate-800 rounded-xl overflow-hidden">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-800/80 text-slate-400 text-[11px] font-semibold border-b border-slate-800">
                  <tr>
                    <th className="p-3">Item & Code</th>
                    {originalIssue && <th className="p-3 text-right">Max Eligible</th>}
                    <th className="p-3 text-right w-28">Quantity</th>
                    <th className="p-3 w-40">Condition</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {returnLines.map((line, idx) => (
                    <tr key={idx} className="hover:bg-slate-800/30">
                      <td className="p-3">
                        <div className="font-semibold text-white">{line.itemName}</div>
                        <div className="font-mono text-[10px] text-amber-400">{line.itemCode}</div>
                      </td>
                      {originalIssue && (
                        <td className="p-3 text-right font-semibold text-slate-300">
                          {line.eligibleReturnQty} {line.unitShortCode}
                        </td>
                      )}
                      <td className="p-3 text-right">
                        <input
                          type="number"
                          min="1"
                          max={originalIssue ? line.eligibleReturnQty : undefined}
                          value={line.quantity}
                          onChange={(e) => updateLine(idx, 'quantity', parseInt(e.target.value, 10) || 0)}
                          className="w-20 px-2 py-1 text-right text-xs rounded-lg bg-slate-900 border border-slate-700 text-white font-semibold focus:outline-none focus:border-amber-500"
                        />
                      </td>
                      <td className="p-3">
                        <select
                          value={line.condition}
                          onChange={(e) => updateLine(idx, 'condition', e.target.value)}
                          className="w-full px-2 py-1 text-xs rounded-lg bg-slate-900 border border-slate-700 text-white focus:outline-none focus:border-amber-500"
                        >
                          <option value="GOOD">Good (Restock)</option>
                          <option value="DAMAGED">Damaged (Quarantine)</option>
                          <option value="UNUSABLE">Unusable (Scrap)</option>
                        </select>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-medium text-slate-300 mb-1">
              Inspection Notes / Verification
            </label>
            <textarea
              rows={2}
              placeholder="e.g. Verified by Warehouse Officer, packages intact..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl glass-input border border-slate-700/80 bg-slate-800/90 text-white focus:outline-none focus:border-amber-500"
            />
          </div>
        </form>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 flex items-center justify-between bg-slate-800/30">
          <div className="text-[11px] text-slate-400">
            Items in <strong className="text-emerald-400">Good</strong> condition will atomically increase warehouse inventory stock.
          </div>
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              disabled={submitting}
              className="px-4 py-2 text-xs font-semibold rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSubmit}
              disabled={submitting}
              className="px-5 py-2 text-xs font-semibold rounded-xl bg-amber-600 hover:bg-amber-500 text-white shadow-lg shadow-amber-950 flex items-center gap-2 transition-colors disabled:opacity-50"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              {submitting ? 'Processing Return...' : 'Confirm Return'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
