/**
 * Create Purchase Request Modal (Part 14D)
 *
 * Allows staff / department heads / administrators to submit purchase requests.
 */

import React, { useState } from 'react';
import {
  X,
  FilePlus,
  Plus,
  Trash2,
  AlertTriangle,
  Building,
  Flag,
  Calendar,
  Layers
} from 'lucide-react';
import {
  InventoryItem,
  Supplier,
  InventoryLocation,
  CreatePurchaseRequestPayload,
  PurchasePriority
} from '../../types';

interface CreatePurchaseRequestModalProps {
  isOpen: boolean;
  items: InventoryItem[];
  suppliers: Supplier[];
  locations: InventoryLocation[];
  onClose: () => void;
  onSubmit: (payload: CreatePurchaseRequestPayload) => Promise<void>;
}

export const CreatePurchaseRequestModal: React.FC<CreatePurchaseRequestModalProps> = ({
  isOpen,
  items,
  suppliers,
  locations,
  onClose,
  onSubmit
}) => {
  const safeItems = Array.isArray(items) ? items : [];

  const [departmentName, setDepartmentName] = useState('Academics');
  const [purpose, setPurpose] = useState('');
  const [priority, setPriority] = useState<PurchasePriority>('MEDIUM');
  const [requiredByDate, setRequiredByDate] = useState('');
  const [targetLocationId, setTargetLocationId] = useState(locations[0]?.id || '');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  const [requestItems, setRequestItems] = useState<
    Array<{
      itemId: string;
      quantity: number;
      estimatedUnitCost: number;
      preferredSupplierId?: string;
      notes?: string;
    }>
  >([
    {
      itemId: safeItems[0]?.id || '',
      quantity: 10,
      estimatedUnitCost: safeItems[0]?.unitPrice || 0,
      preferredSupplierId: '',
      notes: ''
    }
  ]);

  if (!isOpen) return null;

  const handleAddItemRow = () => {
    const defaultItem = safeItems[0];
    setRequestItems(prev => [
      ...prev,
      {
        itemId: defaultItem?.id || '',
        quantity: 1,
        estimatedUnitCost: defaultItem?.unitPrice || 0,
        preferredSupplierId: '',
        notes: ''
      }
    ]);
  };

  const handleRemoveItemRow = (index: number) => {
    if (requestItems.length <= 1) return;
    setRequestItems(prev => prev.filter((_, idx) => idx !== index));
  };

  const handleItemChange = (index: number, itemId: string) => {
    const selected = safeItems.find(i => i.id === itemId);
    const updated = [...requestItems];
    updated[index].itemId = itemId;
    if (selected && selected.unitPrice) {
      updated[index].estimatedUnitCost = selected.unitPrice;
    }
    setRequestItems(updated);
  };

  const handleQuantityChange = (index: number, qty: number) => {
    const updated = [...requestItems];
    updated[index].quantity = Math.max(1, qty);
    setRequestItems(updated);
  };

  const handleCostChange = (index: number, cost: number) => {
    const updated = [...requestItems];
    updated[index].estimatedUnitCost = Math.max(0, cost);
    setRequestItems(updated);
  };

  const handleSupplierChange = (index: number, supplierId: string) => {
    const updated = [...requestItems];
    updated[index].preferredSupplierId = supplierId || undefined;
    setRequestItems(updated);
  };

  const handleNotesChange = (index: number, notes: string) => {
    const updated = [...requestItems];
    updated[index].notes = notes;
    setRequestItems(updated);
  };

  const totalEstimated = requestItems.reduce(
    (sum, line) => sum + line.quantity * line.estimatedUnitCost,
    0
  );

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (!purpose.trim()) {
      setFormError('Please state the purpose / justification for this requisition.');
      return;
    }

    if (requestItems.length === 0) {
      setFormError('Please add at least one line item to the requisition.');
      return;
    }

    try {
      setIsSubmitting(true);
      const payload: CreatePurchaseRequestPayload = {
        departmentName: departmentName.trim() || undefined,
        purpose: purpose.trim(),
        priority,
        requiredByDate: requiredByDate ? new Date(requiredByDate).toISOString() : undefined,
        targetLocationId: targetLocationId || undefined,
        items: requestItems.map(item => ({
          itemId: item.itemId,
          quantity: item.quantity,
          estimatedUnitCost: item.estimatedUnitCost,
          preferredSupplierId: item.preferredSupplierId || undefined,
          notes: item.notes?.trim() || undefined
        }))
      };

      await onSubmit(payload);
      onClose();
    } catch (err: any) {
      setFormError(err.message || 'Failed to submit purchase request.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-3xl bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-850/50">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-500/10 border border-indigo-500/20 rounded-xl text-indigo-400">
              <FilePlus className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Create Purchase Requisition</h2>
              <p className="text-xs text-slate-400">
                Submit an internal requisition for departmental review and financial authorization.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {formError && (
          <div className="mx-6 mt-4 p-3 bg-red-500/10 border border-red-500/20 rounded-xl flex items-center gap-2 text-xs text-red-400">
            <AlertTriangle className="w-4 h-4 flex-shrink-0" />
            <span>{formError}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {/* Metadata Row */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Department / Program
              </label>
              <div className="relative">
                <Building className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  value={departmentName}
                  onChange={(e) => setDepartmentName(e.target.value)}
                  placeholder="e.g. Science Department"
                  className="w-full pl-9 pr-3 py-2 text-xs rounded-xl bg-slate-800 border border-slate-700 text-white focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Priority Level *
              </label>
              <div className="relative">
                <Flag className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <select
                  value={priority}
                  onChange={(e) => setPriority(e.target.value as PurchasePriority)}
                  className="w-full pl-9 pr-3 py-2 text-xs rounded-xl bg-slate-800 border border-slate-700 text-white focus:outline-none focus:border-indigo-500"
                >
                  <option value="LOW">Low</option>
                  <option value="MEDIUM">Medium</option>
                  <option value="HIGH">High</option>
                  <option value="URGENT">Urgent / Critical</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Date Required By
              </label>
              <div className="relative">
                <Calendar className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="date"
                  value={requiredByDate}
                  onChange={(e) => setRequiredByDate(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs rounded-xl bg-slate-800 border border-slate-700 text-white focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>
          </div>

          {/* Purpose & Target Facility */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Justification & Purpose *
              </label>
              <textarea
                rows={2}
                required
                value={purpose}
                onChange={(e) => setPurpose(e.target.value)}
                placeholder="State why these materials are requested (e.g. Science lab chemistry experiments term 2)."
                className="w-full p-2.5 text-xs rounded-xl bg-slate-800 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Target Facility / Storage Location
              </label>
              <div className="relative">
                <Layers className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <select
                  value={targetLocationId}
                  onChange={(e) => setTargetLocationId(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs rounded-xl bg-slate-800 border border-slate-700 text-white focus:outline-none focus:border-indigo-500"
                >
                  <option value="">Default Location</option>
                  {locations.map(loc => (
                    <option key={loc.id} value={loc.id}>
                      {loc.name} ({loc.code})
                    </option>
                  ))}
                </select>
              </div>
              <p className="text-[11px] text-slate-400 mt-1">
                Where items should be stationed once delivered and inspected.
              </p>
            </div>
          </div>

          {/* Line Items */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                Requisition Items
              </h3>
              <button
                type="button"
                onClick={handleAddItemRow}
                className="px-2.5 py-1 text-xs font-semibold rounded-lg bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-400 border border-indigo-500/30 flex items-center gap-1.5 transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                Add Item Line
              </button>
            </div>

            <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
              {requestItems.map((line, idx) => (
                <div
                  key={idx}
                  className="p-3 bg-slate-800/60 border border-slate-700 rounded-xl grid grid-cols-1 md:grid-cols-12 gap-2 items-center"
                >
                  <div className="md:col-span-4">
                    <label className="text-[10px] text-slate-400 uppercase font-semibold block mb-0.5">Item *</label>
                    <select
                      value={line.itemId}
                      onChange={(e) => handleItemChange(idx, e.target.value)}
                      className="w-full py-1.5 px-2 text-xs rounded-lg bg-slate-900 border border-slate-700 text-white focus:outline-none focus:border-indigo-500"
                    >
                      {safeItems.map(item => (
                        <option key={item.id} value={item.id}>
                          {item.name} ({item.itemCode})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="md:col-span-2">
                    <label className="text-[10px] text-slate-400 uppercase font-semibold block mb-0.5">Quantity *</label>
                    <input
                      type="number"
                      min={1}
                      value={line.quantity}
                      onChange={(e) => handleQuantityChange(idx, parseInt(e.target.value, 10) || 1)}
                      className="w-full py-1.5 px-2 text-xs text-center rounded-lg bg-slate-900 border border-slate-700 text-white font-mono focus:outline-none focus:border-indigo-500"
                    />
                  </div>

                  <div className="md:col-span-2">
                    <label className="text-[10px] text-slate-400 uppercase font-semibold block mb-0.5">Est. Unit $</label>
                    <input
                      type="number"
                      min={0}
                      step="0.01"
                      value={line.estimatedUnitCost}
                      onChange={(e) => handleCostChange(idx, parseFloat(e.target.value) || 0)}
                      className="w-full py-1.5 px-2 text-xs text-center rounded-lg bg-slate-900 border border-slate-700 text-white font-mono focus:outline-none focus:border-indigo-500"
                    />
                  </div>

                  <div className="md:col-span-3">
                    <label className="text-[10px] text-slate-400 uppercase font-semibold block mb-0.5">Vendor (Optional)</label>
                    <select
                      value={line.preferredSupplierId || ''}
                      onChange={(e) => handleSupplierChange(idx, e.target.value)}
                      className="w-full py-1.5 px-2 text-xs rounded-lg bg-slate-900 border border-slate-700 text-white focus:outline-none focus:border-indigo-500"
                    >
                      <option value="">Any Vendor</option>
                      {suppliers.map(s => (
                        <option key={s.id} value={s.id}>
                          {s.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="md:col-span-1 flex justify-end pt-3 md:pt-0">
                    <button
                      type="button"
                      onClick={() => handleRemoveItemRow(idx)}
                      disabled={requestItems.length <= 1}
                      className="p-1.5 text-slate-400 hover:text-rose-400 disabled:opacity-30 rounded-lg hover:bg-slate-700 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Footer Action */}
          <div className="pt-4 border-t border-slate-800 flex items-center justify-between">
            <div>
              <div className="text-[11px] text-slate-400 uppercase font-semibold">Total Estimated Value</div>
              <div className="text-lg font-bold font-mono text-emerald-400">
                ${totalEstimated.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </div>
            </div>

            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={onClose}
                disabled={isSubmitting}
                className="px-4 py-2 text-xs font-semibold rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmitting}
                className="px-5 py-2 text-xs font-semibold rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-950 transition-all flex items-center gap-2 disabled:opacity-50"
              >
                <FilePlus className="w-4 h-4" />
                {isSubmitting ? 'Submitting...' : 'Submit Requisition'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
