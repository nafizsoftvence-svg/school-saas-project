/**
 * Supplier Procurement History Modal (Part 14D)
 *
 * Displays rich vendor procurement analytics, order fulfillment rate,
 * past purchase orders, and goods receiving history.
 */

import React, { useState, useEffect } from 'react';
import {
  X,
  Truck,
  TrendingUp,
  ShoppingCart,
  PackageCheck,
  DollarSign,
  Calendar,
  AlertTriangle,
  Building2,
  CheckCircle2,
  Boxes
} from 'lucide-react';
import { api } from '../../services/api';
import { Supplier, PurchaseOrder, GoodsReceipt } from '../../types';

interface SupplierHistoryModalProps {
  isOpen: boolean;
  supplier: Supplier | null;
  onClose: () => void;
}

export const SupplierHistoryModal: React.FC<SupplierHistoryModalProps> = ({
  isOpen,
  supplier,
  onClose
}) => {
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<{
    supplier: Supplier;
    metrics: {
      totalOrders: number;
      openOrders: number;
      completedOrders: number;
      partiallyReceivedOrders: number;
      totalOrderedQty: number;
      totalReceivedQty: number;
      fulfillmentRatePercentage: number;
      totalOrderValue: number;
    };
    recentPurchaseOrders: PurchaseOrder[];
    recentGoodsReceipts: GoodsReceipt[];
  } | null>(null);

  useEffect(() => {
    if (!isOpen || !supplier) return;
    let isMounted = true;
    setLoading(true);
    api.inventory
      .getSupplierProcurementHistory(supplier.id)
      .then(res => {
        if (isMounted) setData(res);
      })
      .catch(err => {
        console.error('Failed to load supplier procurement history', err);
      })
      .finally(() => {
        if (isMounted) setLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, [isOpen, supplier?.id]);

  if (!isOpen || !supplier) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-3xl bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-850/50">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-teal-500/10 border border-teal-500/20 rounded-xl text-teal-400">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                {supplier.name}
                <span className="font-mono text-xs px-2 py-0.5 rounded-md bg-teal-500/10 text-teal-400 border border-teal-500/20">
                  {supplier.supplierCode}
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Procurement & Fulfillment Track Record
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6 max-h-[75vh] overflow-y-auto">
          {loading ? (
            <div className="py-12 text-center text-slate-400">
              <div className="w-8 h-8 border-4 border-teal-500 border-t-transparent rounded-full animate-spin mx-auto mb-2" />
              Loading supplier fulfillment metrics...
            </div>
          ) : !data ? (
            <div className="py-8 text-center text-rose-400 text-xs">
              Unable to load supplier metrics.
            </div>
          ) : (
            <>
              {/* Metrics Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3 bg-slate-800/60 border border-slate-700/80 rounded-xl">
                  <div className="text-[10px] uppercase font-bold text-slate-400">Total Orders</div>
                  <div className="text-xl font-bold font-mono text-white mt-1">
                    {data.metrics.totalOrders}
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    {data.metrics.openOrders} active
                  </div>
                </div>

                <div className="p-3 bg-slate-800/60 border border-slate-700/80 rounded-xl">
                  <div className="text-[10px] uppercase font-bold text-slate-400">Fulfillment Rate</div>
                  <div className="text-xl font-bold font-mono text-emerald-400 mt-1">
                    {data.metrics.fulfillmentRatePercentage}%
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    {data.metrics.totalReceivedQty} / {data.metrics.totalOrderedQty} units
                  </div>
                </div>

                <div className="p-3 bg-slate-800/60 border border-slate-700/80 rounded-xl">
                  <div className="text-[10px] uppercase font-bold text-slate-400">Completed Orders</div>
                  <div className="text-xl font-bold font-mono text-indigo-400 mt-1">
                    {data.metrics.completedOrders}
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    100% delivered
                  </div>
                </div>

                <div className="p-3 bg-slate-800/60 border border-slate-700/80 rounded-xl">
                  <div className="text-[10px] uppercase font-bold text-slate-400">Total PO Value</div>
                  <div className="text-xl font-bold font-mono text-amber-400 mt-1">
                    ${data.metrics.totalOrderValue.toLocaleString()}
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    Lifetime volume
                  </div>
                </div>
              </div>

              {/* Recent POs */}
              <div className="space-y-2">
                <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                  <ShoppingCart className="w-3.5 h-3.5 text-indigo-400" />
                  Recent Purchase Orders
                </h3>
                {(data.recentPurchaseOrders?.length || 0) === 0 ? (
                  <p className="text-xs text-slate-500 py-2">No purchase orders placed with this vendor.</p>
                ) : (
                  <div className="border border-slate-800 rounded-xl overflow-hidden bg-slate-850/30">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-slate-800/60 text-slate-400 text-[10px] uppercase">
                        <tr>
                          <th className="py-2 px-3">PO #</th>
                          <th className="py-2 px-3">Date</th>
                          <th className="py-2 px-3 text-right">Amount</th>
                          <th className="py-2 px-3 text-center">Status</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800 text-slate-200">
                        {data.recentPurchaseOrders.map(po => (
                          <tr key={po.id}>
                            <td className="py-2 px-3 font-mono font-semibold text-indigo-400">
                              {po.poNumber}
                            </td>
                            <td className="py-2 px-3 text-slate-400">
                              {new Date(po.orderDate).toLocaleDateString()}
                            </td>
                            <td className="py-2 px-3 text-right font-mono font-semibold">
                              ${Number(po.grandTotal ?? 0).toFixed(2)}
                            </td>
                            <td className="py-2 px-3 text-center">
                              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 border border-slate-700">
                                {po.status.replace(/_/g, ' ')}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>

              {/* Recent Goods Receipts */}
              <div className="space-y-2">
                <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                  <PackageCheck className="w-3.5 h-3.5 text-emerald-400" />
                  Recent Goods Receiving History (GRNs)
                </h3>
                {(data.recentGoodsReceipts?.length || 0) === 0 ? (
                  <p className="text-xs text-slate-500 py-2">No goods received yet from this vendor.</p>
                ) : (
                  <div className="border border-slate-800 rounded-xl overflow-hidden bg-slate-850/30">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-slate-800/60 text-slate-400 text-[10px] uppercase">
                        <tr>
                          <th className="py-2 px-3">GRN #</th>
                          <th className="py-2 px-3">PO #</th>
                          <th className="py-2 px-3">Date</th>
                          <th className="py-2 px-3 text-center">Accepted</th>
                          <th className="py-2 px-3 text-center">Rejected</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800 text-slate-200">
                        {data.recentGoodsReceipts.map(gr => (
                          <tr key={gr.id}>
                            <td className="py-2 px-3 font-mono font-semibold text-emerald-400">
                              {gr.receiptNumber}
                            </td>
                            <td className="py-2 px-3 font-mono text-slate-400">
                              {gr.poNumber}
                            </td>
                            <td className="py-2 px-3 text-slate-400">
                              {new Date(gr.receiptDate).toLocaleDateString()}
                            </td>
                            <td className="py-2 px-3 text-center font-mono font-semibold text-emerald-400">
                              +{gr.totalAcceptedQty}
                            </td>
                            <td className="py-2 px-3 text-center font-mono text-rose-400">
                              {gr.totalRejectedQty > 0 ? gr.totalRejectedQty : '-'}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </>
          )}
        </div>

        <div className="p-4 border-t border-slate-800 flex justify-end bg-slate-850/40">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
