import React, { useState } from 'react';
import {
  X,
  Plus,
  Trash2,
  Package,
  AlertCircle,
  Building,
  User,
  Calendar,
  Layers
} from 'lucide-react';
import {
  InventoryItem,
  InventoryLocation,
  Department,
  StaffProfile,
  IssueRequestPriority,
  OrganizationalDestinationType,
  CreateIssueRequestPayload
} from '../../types';
import { api } from '../../services/api';

interface CreateIssueRequestModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: InventoryItem[];
  locations: InventoryLocation[];
  departments: Department[];
  staffMembers: StaffProfile[];
  onSuccess: (message: string) => void;
}

interface ItemRow {
  itemId: string;
  requestedQuantity: number | '';
  notes: string;
}

export const CreateIssueRequestModal: React.FC<CreateIssueRequestModalProps> = ({
  isOpen,
  onClose,
  items,
  locations,
  departments,
  staffMembers,
  onSuccess
}) => {
  const [priority, setPriority] = useState<IssueRequestPriority>('MEDIUM');
  const [requiredDate, setRequiredDate] = useState('');
  const [departmentId, setDepartmentId] = useState(departments[0]?.id || '');
  const [destinationType, setDestinationType] = useState<OrganizationalDestinationType>('DEPARTMENT');
  const [destinationId, setDestinationId] = useState('');
  const [destinationName, setDestinationName] = useState('');
  const [locationId, setLocationId] = useState(locations[0]?.id || '');
  const [purpose, setPurpose] = useState('');
  const [notes, setNotes] = useState('');
  const safeItems = Array.isArray(items) ? items : [];
  const stockableItems = safeItems.filter((i) => i.isStockable !== false);
  const [rows, setRows] = useState<ItemRow[]>([
    { itemId: stockableItems[0]?.id || '', requestedQuantity: 1, notes: '' }
  ]);

  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;
  const selectedDept = departments.find((d) => d.id === departmentId);

  const handleAddRow = () => {
    const unselected = stockableItems.find((item) => !rows.some((r) => r.itemId === item.id));
    setRows([...rows, { itemId: unselected ? unselected.id : stockableItems[0]?.id || '', requestedQuantity: 1, notes: '' }]);
  };

  const handleRemoveRow = (index: number) => {
    if (rows.length === 1) return;
    setRows(rows.filter((_, i) => i !== index));
  };

  const handleRowChange = (index: number, field: keyof ItemRow, val: any) => {
    const newRows = [...rows];
    newRows[index] = { ...newRows[index], [field]: val };
    setRows(newRows);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!purpose.trim()) {
      setError('Please provide a business or educational purpose for this issue request.');
      return;
    }

    if (rows.length === 0) {
      setError('Please add at least one line item.');
      return;
    }

    for (const row of rows) {
      if (!row.itemId) {
        setError('Please select an item for all rows.');
        return;
      }
      if (typeof row.requestedQuantity !== 'number' || row.requestedQuantity <= 0) {
        setError('Requested quantity must be at least 1 for all items.');
        return;
      }
    }

    // Check duplicate items in rows
    const itemIds = rows.map((r) => r.itemId);
    if (new Set(itemIds).size !== itemIds.length) {
      setError('Duplicate items detected in request. Please combine quantities into a single row.');
      return;
    }

    try {
      setSubmitting(true);

      const payload: CreateIssueRequestPayload = {
        priority,
        requiredDate: requiredDate || undefined,
        departmentId: departmentId || undefined,
        departmentName: selectedDept ? selectedDept.name : 'General Administration',
        destinationType,
        destinationId: destinationId || undefined,
        destinationName: destinationName.trim() || (selectedDept ? selectedDept.name : 'Department Facility'),
        locationId,
        purpose: purpose.trim(),
        notes: notes.trim() || undefined,
        items: rows.map((r) => ({
          itemId: r.itemId,
          requestedQuantity: Number(r.requestedQuantity),
          notes: r.notes.trim() || undefined
        }))
      };

      const res = await api.inventory.createIssueRequest(payload);
      onSuccess(res.message || 'Issue request created successfully.');
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to submit issue request.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm overflow-y-auto">
      <div className="w-full max-w-4xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="p-6 border-b border-slate-800 flex items-center justify-between bg-slate-900/80">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-xl bg-blue-500/10 text-blue-400 border border-blue-500/20">
              <Package className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">Create Inventory Issue Request</h3>
              <p className="text-xs text-slate-400">
                Submit an item requisition for staff, teachers, departments, or classrooms
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {error && (
            <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Section 1: General Request Details */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Priority Level <span className="text-rose-400">*</span>
              </label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value as IssueRequestPriority)}
                className="w-full px-3 py-2 text-xs rounded-xl bg-slate-800/80 border border-slate-700 text-white focus:outline-none focus:border-blue-500"
              >
                <option value="LOW">Low Priority (Routine Stock)</option>
                <option value="MEDIUM">Medium Priority (Standard)</option>
                <option value="HIGH">High Priority (Urgent Class Need)</option>
                <option value="URGENT">Urgent (Immediate Exam/Lab)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Source Warehouse / Store <span className="text-rose-400">*</span>
              </label>
              <select
                value={locationId}
                onChange={(e) => setLocationId(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl bg-slate-800/80 border border-slate-700 text-white focus:outline-none focus:border-blue-500"
              >
                {locations.map((loc) => (
                  <option key={loc.id} value={loc.id}>
                    {loc.name} ({loc.code})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">Required Date</label>
              <input
                type="date"
                value={requiredDate}
                onChange={(e) => setRequiredDate(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl bg-slate-800/80 border border-slate-700 text-white focus:outline-none focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Requesting Department <span className="text-rose-400">*</span>
              </label>
              <select
                value={departmentId}
                onChange={(e) => {
                  setDepartmentId(e.target.value);
                  const d = departments.find((dept) => dept.id === e.target.value);
                  if (d && destinationType === 'DEPARTMENT') {
                    setDestinationName(d.name);
                  }
                }}
                className="w-full px-3 py-2 text-xs rounded-xl bg-slate-800/80 border border-slate-700 text-white focus:outline-none focus:border-blue-500"
              >
                {departments.map((dept) => (
                  <option key={dept.id} value={dept.id}>
                    {dept.name} ({dept.code})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Destination Type <span className="text-rose-400">*</span>
              </label>
              <select
                value={destinationType}
                onChange={(e) => {
                  const val = e.target.value as OrganizationalDestinationType;
                  setDestinationType(val);
                  if (val === 'DEPARTMENT' && selectedDept) {
                    setDestinationName(selectedDept.name);
                  }
                }}
                className="w-full px-3 py-2 text-xs rounded-xl bg-slate-800/80 border border-slate-700 text-white focus:outline-none focus:border-blue-500"
              >
                <option value="DEPARTMENT">Department Facility / Lab</option>
                <option value="TEACHER">Teacher / Faculty</option>
                <option value="STAFF">Administrative Staff</option>
                <option value="OFFICE">Office / Room</option>
                <option value="LOCATION">Classroom / Hall</option>
                <option value="OTHER">Other Organizational Unit</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Destination / Recipient Detail <span className="text-rose-400">*</span>
              </label>
              {destinationType === 'STAFF' || destinationType === 'TEACHER' ? (
                <select
                  value={destinationId}
                  onChange={(e) => {
                    setDestinationId(e.target.value);
                    const st = staffMembers.find((s) => s.id === e.target.value || s.userId === e.target.value);
                    if (st) setDestinationName(`${st.firstName} ${st.lastName}`);
                  }}
                  className="w-full px-3 py-2 text-xs rounded-xl bg-slate-800/80 border border-slate-700 text-white focus:outline-none focus:border-blue-500"
                >
                  <option value="">Select Staff / Teacher</option>
                  {staffMembers.map((s) => (
                    <option key={s.id} value={s.userId || s.id}>
                      {s.firstName} {s.lastName} ({s.staffId || s.designationName || 'Staff'})
                    </option>
                  ))}
                </select>
              ) : (
                <input
                  type="text"
                  placeholder="e.g. Computer Science Lab 1, Room 204"
                  value={destinationName}
                  onChange={(e) => setDestinationName(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl bg-slate-800/80 border border-slate-700 text-white focus:outline-none focus:border-blue-500"
                />
              )}
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Purpose & Justification <span className="text-rose-400">*</span>
            </label>
            <input
              type="text"
              placeholder="e.g. Semester examinations printing and laboratory test supplies"
              value={purpose}
              onChange={(e) => setPurpose(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl bg-slate-800/80 border border-slate-700 text-white focus:outline-none focus:border-blue-500"
            />
          </div>

          {/* Section 2: Requisition Items */}
          <div className="space-y-3 pt-2">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                <Layers className="w-4 h-4 text-blue-400" />
                Requested Inventory Items ({rows.length})
              </h4>
              <button
                type="button"
                onClick={handleAddRow}
                className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors flex items-center gap-1.5"
              >
                <Plus className="w-3.5 h-3.5" />
                Add Item Line
              </button>
            </div>

            <div className="border border-slate-800 rounded-xl overflow-hidden">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-800/70 text-slate-400 border-b border-slate-800">
                  <tr>
                    <th className="py-2.5 px-3 font-semibold">Item & SKU</th>
                    <th className="py-2.5 px-3 font-semibold w-32">Unit</th>
                    <th className="py-2.5 px-3 font-semibold w-32">Req. Qty</th>
                    <th className="py-2.5 px-3 font-semibold">Line Notes</th>
                    <th className="py-2.5 px-3 w-10"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {rows.map((row, index) => {
                    const selectedItem = stockableItems.find((i) => i.id === row.itemId);
                    return (
                      <tr key={index} className="bg-slate-900/40 hover:bg-slate-800/20">
                        <td className="p-2.5">
                          <select
                            value={row.itemId}
                            onChange={(e) => handleRowChange(index, 'itemId', e.target.value)}
                            className="w-full px-2.5 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none"
                          >
                            {stockableItems.map((item) => (
                              <option key={item.id} value={item.id}>
                                {item.name} ({item.itemCode})
                              </option>
                            ))}
                          </select>
                        </td>
                        <td className="p-2.5">
                          <span className="font-mono text-xs px-2 py-1 rounded bg-slate-800 text-slate-300">
                            {selectedItem?.unitShortCode || 'PCS'}
                          </span>
                        </td>
                        <td className="p-2.5">
                          <input
                            type="number"
                            min="1"
                            value={row.requestedQuantity}
                            onChange={(e) =>
                              handleRowChange(
                                index,
                                'requestedQuantity',
                                e.target.value === '' ? '' : Math.max(1, parseInt(e.target.value, 10))
                              )
                            }
                            className="w-full px-2.5 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-white text-xs font-mono focus:outline-none"
                          />
                        </td>
                        <td className="p-2.5">
                          <input
                            type="text"
                            placeholder="Optional notes..."
                            value={row.notes}
                            onChange={(e) => handleRowChange(index, 'notes', e.target.value)}
                            className="w-full px-2.5 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-white text-xs focus:outline-none"
                          />
                        </td>
                        <td className="p-2.5 text-center">
                          {rows.length > 1 && (
                            <button
                              type="button"
                              onClick={() => handleRemoveRow(index)}
                              className="p-1.5 rounded text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 transition-colors"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">Additional General Notes</label>
            <textarea
              rows={2}
              placeholder="Any specific delivery instructions or budget codes..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl bg-slate-800/80 border border-slate-700 text-white focus:outline-none focus:border-blue-500"
            />
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end space-x-3 pt-4 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-5 py-2 text-xs font-bold rounded-xl bg-blue-600 hover:bg-blue-500 text-white transition-colors disabled:opacity-50 flex items-center gap-1.5 shadow-lg shadow-blue-900/30"
            >
              {submitting ? 'Submitting...' : 'Submit Issue Request'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
