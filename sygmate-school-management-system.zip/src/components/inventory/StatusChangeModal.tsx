import React, { useState } from 'react';
import { X, Clock, Check, AlertCircle } from 'lucide-react';
import { Asset, AssetStatus } from '../../types';

interface StatusChangeModalProps {
  isOpen: boolean;
  onClose: () => void;
  asset: Asset | null;
  onSubmit: (assetId: string, status: AssetStatus, remarks?: string) => Promise<void>;
}

export const StatusChangeModal: React.FC<StatusChangeModalProps> = ({
  isOpen,
  onClose,
  asset,
  onSubmit
}) => {
  const [status, setStatus] = useState<AssetStatus>(asset?.status || 'IN_SERVICE');
  const [remarks, setRemarks] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen || !asset) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setSubmitting(true);
      setError(null);
      await onSubmit(asset.id, status, remarks.trim() || undefined);
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to update asset status');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800 bg-slate-900/60">
          <div className="flex items-center space-x-2">
            <Clock className="w-4 h-4 text-blue-400" />
            <div>
              <h3 className="text-sm font-semibold text-white">Update Asset Operational Status</h3>
              <p className="text-xs text-slate-400">
                {asset.assetTag} • {asset.name}
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded text-slate-400 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          {error && (
            <div className="p-2.5 rounded bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs flex items-center gap-1.5">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Select New Operational Status
            </label>
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value as AssetStatus)}
              className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700 text-slate-200"
            >
              <option value="ACTIVE">Active (In Production / Use)</option>
              <option value="AVAILABLE">Available (In Storage / Ready for Allocation)</option>
              <option value="ASSIGNED">Assigned (Allocated to Department / Custodian)</option>
              <option value="UNDER_REPAIR">Under Repair (Maintenance / Servicing)</option>
              <option value="DAMAGED">Damaged (Requires Assessment)</option>
              <option value="LOST">Lost / Unaccounted For</option>
              <option value="RETIRED">Retired (End-of-Life)</option>
              <option value="DISPOSED">Disposed (Sold / Scrapped / Donated)</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Status Change Reason / Audit Remarks
            </label>
            <textarea
              rows={3}
              placeholder="e.g. Sent to authorized service center for motherboard diagnostics; ticket #SRV-4421..."
              value={remarks}
              onChange={(e) => setRemarks(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700 text-slate-100 placeholder-slate-500"
            />
          </div>

          <div className="flex justify-end space-x-2 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-1.5 text-xs text-slate-400 hover:text-white bg-slate-800 rounded-lg"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-4 py-1.5 text-xs font-semibold bg-blue-600 hover:bg-blue-500 text-white rounded-lg flex items-center gap-1.5 disabled:opacity-50"
            >
              <Check className="w-3.5 h-3.5" />
              {submitting ? 'Updating...' : 'Commit Status'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
