/**
 * Create Purchase Order Modal (Part 14D)
 *
 * Allows creation of direct purchase orders or conversion from approved requests.
 */

import React, { useState } from 'react';
import {
  X,
  ShoppingCart,
  Plus,
  Trash2,
  AlertTriangle,
  Building,
  Calendar,
  Layers,
  Percent,
  FileText
} from 'lucide-react';
import {
  InventoryItem,
  Supplier,
  InventoryLocation,
  CreatePurchaseOrderPayload
} from '../../types';

interface CreatePurchaseOrderModalProps {
  isOpen: boolean;
  items: InventoryItem[];
  suppliers: Supplier[];
  locations: InventoryLocation[];
  onClose: () => void;
  onSubmit: (payload: CreatePurchaseOrderPayload) => Promise<void>;
}

export const CreatePurchaseOrderModal: React.FC<CreatePurchaseOrderModalProps> = ({
  isOpen,
  items,
  suppliers,
  locations,
  onClose,
  onSubmit
}) => {
  const safeItems = Array.isArray(items) ? items : [];

  const [supplierId, setSupplierId] = useState(suppliers[0]?.id || '');
  const [deliveryLocationId, setDeliveryLocationId] = useState(locations[0]?.id || '');
  const [departmentName, setDepartmentName] = useState('Procurement');
  const [expectedDeliveryDate, setExpectedDeliveryDate] = useState('');
  const [paymentTerms, setPaymentTerms] = useState('NET 30');
  const [deliveryInstructions, setDeliveryInstructions] = useState('');
  const [notes, setNotes] = useState('');
  const [shippingCost, setShippingCost] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  const [orderItems, setOrderItems] = useState<
    Array<{
      itemId: string;
      quantityOrdered: number;
      unitPrice: number;
      discountPercentage?: number;
      taxPercentage?: number;
      notes?: string;
    }>
  >([
    {
      itemId: safeItems[0]?.id || '',
      quantityOrdered: 20,
      unitPrice: safeItems[0]?.unitPrice || 0,
      discountPercentage: 0,
      taxPercentage: 0,
      notes: ''
    }
  ]);

  if (!isOpen) return null;

  const handleAddItemRow = () => {
    const defaultItem = safeItems[0];
    setOrderItems(prev => [
      ...prev,
      {
        itemId: defaultItem?.id || '',
        quantityOrdered: 10,
        unitPrice: defaultItem?.unitPrice || 0,
        discountPercentage: 0,
        taxPercentage: 0,
        notes: ''
      }
    ]);
  };

  const handleRemoveItemRow = (index: number) => {
    if (orderItems.length <= 1) return;
    setOrderItems(prev => prev.filter((_, idx) => idx !== index));
  };

  const handleItemChange = (index: number, itemId: string) => {
    const selected = safeItems.find(i => i.id === itemId);
    const updated = [...orderItems];
    updated[index].itemId = itemId;
    if (selected && selected.unitPrice) {
      updated[index].unitPrice = selected.unitPrice;
    }
    setOrderItems(updated);
  };

  const handleQuantityChange = (index: number, qty: number) => {
    const updated = [...orderItems];
    updated[index].quantityOrdered = Math.max(1, qty);
    setOrderItems(updated);
  };

  const handlePriceChange = (index: number, price: number) => {
    const updated = [...orderItems];
    updated[index].unitPrice = Math.max(0, price);
    setOrderItems(updated);
  };

  const handleDiscountChange = (index: number, disc: number) => {
    const updated = [...orderItems];
    updated[index].discountPercentage = Math.min(100, Math.max(0, disc));
    setOrderItems(updated);
  };

  const handleTaxChange = (index: number, tax: number) => {
    const updated = [...orderItems];
    updated[index].taxPercentage = Math.min(100, Math.max(0, tax));
    setOrderItems(updated);
  };

  // Subtotal & Grand Total Calculations
  let subtotal = 0;
  let totalDiscount = 0;
  let totalTax = 0;

  orderItems.forEach(line => {
    const base = line.quantityOrdered * line.unitPrice;
    const disc = base * ((line.discountPercentage || 0) / 100);
    const afterDisc = base - disc;
    const tx = afterDisc * ((line.taxPercentage || 0) / 100);
    subtotal += base;
    totalDiscount += disc;
    totalTax += tx;
  });

  const grandTotal = subtotal - totalDiscount + totalTax + shippingCost;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (!supplierId) {
      setFormError('Please select a vendor / supplier.');
      return;
    }

    if (orderItems.length === 0) {
      setFormError('Please add at least one line item to the order.');
      return;
    }

    try {
      setIsSubmitting(true);
      const payload: CreatePurchaseOrderPayload = {
        supplierId,
        deliveryLocationId: deliveryLocationId || undefined,
        departmentName: departmentName.trim() || undefined,
        expectedDeliveryDate: expectedDeliveryDate ? new Date(expectedDeliveryDate).toISOString() : undefined,
        paymentTerms: paymentTerms.trim() || undefined,
        deliveryInstructions: deliveryInstructions.trim() || undefined,
        notes: notes.trim() || undefined,
        shippingCost: shippingCost > 0 ? shippingCost : undefined,
        items: orderItems.map(item => ({
          itemId: item.itemId,
          quantityOrdered: item.quantityOrdered,
          unitPrice: item.unitPrice,
          discountPercentage: item.discountPercentage || 0,
          taxPercentage: item.taxPercentage || 0,
          notes: item.notes?.trim() || undefined
        }))
      };

      await onSubmit(payload);
      onClose();
    } catch (err: any) {
      setFormError(err.message || 'Failed to create purchase order.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-850/50">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-500/10 border border-indigo-500/20 rounded-xl text-indigo-400">
              <ShoppingCart className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Create Purchase Order (PO)</h2>
              <p className="text-xs text-slate-400">
                Generate an official contractual order for authorized vendor procurement.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {formError && (
          <div className="mx-6 mt-4 p-3 bg-red-500/10 border border-red-500/20 rounded-xl flex items-center gap-2 text-xs text-red-400">
            <AlertTriangle className="w-4 h-4 flex-shrink-0" />
            <span>{formError}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {/* Top Parameters */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Vendor / Supplier *
              </label>
              <div className="relative">
                <Building className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <select
                  value={supplierId}
                  onChange={(e) => setSupplierId(e.target.value)}
                  required
                  className="w-full pl-9 pr-3 py-2 text-xs rounded-xl bg-slate-800 border border-slate-700 text-white focus:outline-none focus:border-indigo-500"
                >
                  {suppliers.map(s => (
                    <option key={s.id} value={s.id}>
                      {s.name} ({s.supplierCode})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Delivery Location
              </label>
              <div className="relative">
                <Layers className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <select
                  value={deliveryLocationId}
                  onChange={(e) => setDeliveryLocationId(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs rounded-xl bg-slate-800 border border-slate-700 text-white focus:outline-none focus:border-indigo-500"
                >
                  <option value="">Default Location</option>
                  {locations.map(loc => (
                    <option key={loc.id} value={loc.id}>
                      {loc.name} ({loc.code})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Expected Delivery Date
              </label>
              <div className="relative">
                <Calendar className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="date"
                  value={expectedDeliveryDate}
                  onChange={(e) => setExpectedDeliveryDate(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs rounded-xl bg-slate-800 border border-slate-700 text-white focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Payment Terms
              </label>
              <input
                type="text"
                value={paymentTerms}
                onChange={(e) => setPaymentTerms(e.target.value)}
                placeholder="e.g. NET 30, On Delivery, 50% Advance"
                className="w-full px-3 py-2 text-xs rounded-xl bg-slate-800 border border-slate-700 text-white focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Department
              </label>
              <input
                type="text"
                value={departmentName}
                onChange={(e) => setDepartmentName(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl bg-slate-800 border border-slate-700 text-white focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Freight / Shipping Charge ($)
              </label>
              <input
                type="number"
                min={0}
                step="0.01"
                value={shippingCost}
                onChange={(e) => setShippingCost(Math.max(0, parseFloat(e.target.value) || 0))}
                className="w-full px-3 py-2 text-xs rounded-xl bg-slate-800 border border-slate-700 text-white font-mono focus:outline-none focus:border-indigo-500"
              />
            </div>
          </div>

          {/* Line Items */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                Order Items & Pricing
              </h3>
              <button
                type="button"
                onClick={handleAddItemRow}
                className="px-2.5 py-1 text-xs font-semibold rounded-lg bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-400 border border-indigo-500/30 flex items-center gap-1.5 transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                Add Line Item
              </button>
            </div>

            <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
              {orderItems.map((line, idx) => (
                <div
                  key={idx}
                  className="p-3 bg-slate-800/60 border border-slate-700 rounded-xl grid grid-cols-1 md:grid-cols-12 gap-2 items-center"
                >
                  <div className="md:col-span-4">
                    <label className="text-[10px] text-slate-400 uppercase font-semibold block mb-0.5">Item *</label>
                    <select
                      value={line.itemId}
                      onChange={(e) => handleItemChange(idx, e.target.value)}
                      className="w-full py-1.5 px-2 text-xs rounded-lg bg-slate-900 border border-slate-700 text-white focus:outline-none focus:border-indigo-500"
                    >
                      {safeItems.map(item => (
                        <option key={item.id} value={item.id}>
                          {item.name} ({item.itemCode})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="md:col-span-2">
                    <label className="text-[10px] text-slate-400 uppercase font-semibold block mb-0.5">Qty *</label>
                    <input
                      type="number"
                      min={1}
                      value={line.quantityOrdered}
                      onChange={(e) => handleQuantityChange(idx, parseInt(e.target.value, 10) || 1)}
                      className="w-full py-1.5 px-2 text-xs text-center rounded-lg bg-slate-900 border border-slate-700 text-white font-mono focus:outline-none focus:border-indigo-500"
                    />
                  </div>

                  <div className="md:col-span-2">
                    <label className="text-[10px] text-slate-400 uppercase font-semibold block mb-0.5">Unit Price ($)</label>
                    <input
                      type="number"
                      min={0}
                      step="0.01"
                      value={line.unitPrice}
                      onChange={(e) => handlePriceChange(idx, parseFloat(e.target.value) || 0)}
                      className="w-full py-1.5 px-2 text-xs text-center rounded-lg bg-slate-900 border border-slate-700 text-white font-mono focus:outline-none focus:border-indigo-500"
                    />
                  </div>

                  <div className="md:col-span-1.5">
                    <label className="text-[10px] text-slate-400 uppercase font-semibold block mb-0.5">Disc %</label>
                    <input
                      type="number"
                      min={0}
                      max={100}
                      value={line.discountPercentage}
                      onChange={(e) => handleDiscountChange(idx, parseFloat(e.target.value) || 0)}
                      className="w-full py-1.5 px-2 text-xs text-center rounded-lg bg-slate-900 border border-slate-700 text-white font-mono focus:outline-none focus:border-indigo-500"
                    />
                  </div>

                  <div className="md:col-span-1.5">
                    <label className="text-[10px] text-slate-400 uppercase font-semibold block mb-0.5">Tax %</label>
                    <input
                      type="number"
                      min={0}
                      max={100}
                      value={line.taxPercentage}
                      onChange={(e) => handleTaxChange(idx, parseFloat(e.target.value) || 0)}
                      className="w-full py-1.5 px-2 text-xs text-center rounded-lg bg-slate-900 border border-slate-700 text-white font-mono focus:outline-none focus:border-indigo-500"
                    />
                  </div>

                  <div className="md:col-span-1 flex justify-end pt-3 md:pt-0">
                    <button
                      type="button"
                      onClick={() => handleRemoveItemRow(idx)}
                      disabled={orderItems.length <= 1}
                      className="p-1.5 text-slate-400 hover:text-rose-400 disabled:opacity-30 rounded-lg hover:bg-slate-700 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Special Instructions */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              Delivery Instructions & Special Terms
            </label>
            <input
              type="text"
              value={deliveryInstructions}
              onChange={(e) => setDeliveryInstructions(e.target.value)}
              placeholder="e.g. Deliver to Gate 2, inspect with storekeeper Mr. Jenkins before unloading."
              className="w-full px-3 py-2 text-xs rounded-xl bg-slate-800 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
            />
          </div>

          {/* Footer Financial Breakdown */}
          <div className="pt-4 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-6 text-xs text-slate-300">
              <div>
                <span className="text-slate-400">Subtotal:</span>{' '}
                <span className="font-mono font-semibold">${subtotal.toFixed(2)}</span>
              </div>
              {totalDiscount > 0 && (
                <div className="text-emerald-400">
                  <span>Discount:</span>{' '}
                  <span className="font-mono font-semibold">-${totalDiscount.toFixed(2)}</span>
                </div>
              )}
              {totalTax > 0 && (
                <div>
                  <span className="text-slate-400">Tax:</span>{' '}
                  <span className="font-mono font-semibold">+${totalTax.toFixed(2)}</span>
                </div>
              )}
              <div>
                <span className="text-slate-400 uppercase text-[11px] font-bold">Total:</span>{' '}
                <span className="font-mono text-base font-bold text-white">${grandTotal.toFixed(2)}</span>
              </div>
            </div>

            <div className="flex items-center gap-3 w-full sm:w-auto">
              <button
                type="button"
                onClick={onClose}
                disabled={isSubmitting}
                className="flex-1 sm:flex-none px-4 py-2 text-xs font-semibold rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmitting}
                className="flex-1 sm:flex-none px-5 py-2 text-xs font-semibold rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-950 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <ShoppingCart className="w-4 h-4" />
                {isSubmitting ? 'Creating Order...' : 'Generate Purchase Order'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
