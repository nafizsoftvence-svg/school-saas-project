import React, { useState, useEffect } from 'react';
import { X, Truck, Check, AlertCircle } from 'lucide-react';
import {
  Supplier,
  CreateSupplierPayload,
  UpdateSupplierPayload
} from '../../types';

interface SupplierModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (payload: CreateSupplierPayload | UpdateSupplierPayload) => Promise<void>;
  supplier?: Supplier | null;
}

export const SupplierModal: React.FC<SupplierModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  supplier
}) => {
  const isEditing = !!supplier;

  const [supplierCode, setSupplierCode] = useState('');
  const [name, setName] = useState('');
  const [contactPerson, setContactPerson] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('');
  const [taxNumber, setTaxNumber] = useState('');
  const [notes, setNotes] = useState('');
  const [status, setStatus] = useState<'ACTIVE' | 'INACTIVE'>('ACTIVE');

  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (supplier) {
      setSupplierCode(supplier.supplierCode || '');
      setName(supplier.name || '');
      setContactPerson(supplier.contactPerson || '');
      setEmail(supplier.email || '');
      setPhone(supplier.phone || '');
      setAddress(supplier.address || '');
      setCity(supplier.city || '');
      setTaxNumber(supplier.taxNumber || '');
      setNotes(supplier.notes || '');
      setStatus(supplier.status || 'ACTIVE');
    } else {
      setSupplierCode('');
      setName('');
      setContactPerson('');
      setEmail('');
      setPhone('');
      setAddress('');
      setCity('');
      setTaxNumber('');
      setNotes('');
      setStatus('ACTIVE');
    }
    setError(null);
  }, [supplier, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Company/Supplier name is required');
      return;
    }
    if (!contactPerson.trim()) {
      setError('Contact person is required');
      return;
    }
    if (!phone.trim()) {
      setError('Phone number is required');
      return;
    }
    if (!email.trim()) {
      setError('Email address is required');
      return;
    }

    try {
      setSubmitting(true);
      setError(null);

      const payload: any = {
        name: name.trim(),
        contactPerson: contactPerson.trim(),
        email: email.trim(),
        phone: phone.trim(),
        address: address.trim() || undefined,
        city: city.trim() || undefined,
        taxNumber: taxNumber.trim() || undefined,
        notes: notes.trim() || undefined,
        status
      };

      if (supplierCode.trim()) {
        payload.supplierCode = supplierCode.trim().toUpperCase();
      }

      await onSubmit(payload);
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to save supplier');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm overflow-y-auto">
      <div className="w-full max-w-xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800 bg-slate-900/60">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-xl bg-teal-500/10 text-teal-400 border border-teal-500/20">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-white">
                {isEditing ? `Edit Vendor: ${supplier.name}` : 'Register New Vendor / Supplier'}
              </h3>
              <p className="text-xs text-slate-400">
                {isEditing ? `Code: ${supplier.supplierCode}` : 'Institutional procurement vendor'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
          {error && (
            <div className="p-3 rounded-lg bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Supplier Code */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Vendor Code <span className="text-slate-500 font-normal">(optional, auto if blank)</span>
              </label>
              <input
                type="text"
                placeholder="e.g. SUP-2026-0001"
                value={supplierCode}
                onChange={(e) => setSupplierCode(e.target.value.toUpperCase())}
                className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700/80 focus:outline-none focus:border-teal-500 text-slate-100 font-mono"
              />
            </div>

            {/* Name */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Vendor / Company Name <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Apex Office Supplies Ltd."
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700/80 focus:outline-none focus:border-teal-500 text-slate-100"
              />
            </div>

            {/* Contact Person */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Contact Person Name <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Sarah Jenkins"
                value={contactPerson}
                onChange={(e) => setContactPerson(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700/80 focus:outline-none focus:border-teal-500 text-slate-100"
              />
            </div>

            {/* Phone */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Phone Number <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                required
                placeholder="e.g. +1 (555) 234-5678"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700/80 focus:outline-none focus:border-teal-500 text-slate-100"
              />
            </div>

            {/* Email */}
            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Email Address <span className="text-rose-400">*</span>
              </label>
              <input
                type="email"
                required
                placeholder="e.g. sales@apexsupplies.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700/80 focus:outline-none focus:border-teal-500 text-slate-100"
              />
            </div>

            {/* Address */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Physical / Office Address
              </label>
              <input
                type="text"
                placeholder="e.g. 100 Industrial Parkway, Suite 4"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700/80 focus:outline-none focus:border-teal-500 text-slate-100"
              />
            </div>

            {/* City */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                City / Region
              </label>
              <input
                type="text"
                placeholder="e.g. Metro City"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700/80 focus:outline-none focus:border-teal-500 text-slate-100"
              />
            </div>

            {/* Tax Number */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Tax Identification / GST Number
              </label>
              <input
                type="text"
                placeholder="e.g. TAX-99482711"
                value={taxNumber}
                onChange={(e) => setTaxNumber(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700/80 focus:outline-none focus:border-teal-500 text-slate-100 font-mono"
              />
            </div>

            {/* Status */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Vendor Status
              </label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as 'ACTIVE' | 'INACTIVE')}
                className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700/80 focus:outline-none focus:border-teal-500 text-slate-200"
              >
                <option value="ACTIVE">Active Vendor</option>
                <option value="INACTIVE">Inactive / Blacklisted</option>
              </select>
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Internal Notes / Terms of Supply
            </label>
            <textarea
              rows={2}
              placeholder="e.g. Net 30 payment terms, 10% educational institution discount..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700/80 focus:outline-none focus:border-teal-500 text-slate-100"
            />
          </div>

          {/* Buttons */}
          <div className="flex items-center justify-end space-x-3 pt-4 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-5 py-2 text-xs font-semibold text-white bg-teal-600 hover:bg-teal-500 rounded-lg transition-colors flex items-center gap-1.5 shadow-sm shadow-teal-950 disabled:opacity-50"
            >
              <Check className="w-4 h-4" />
              {submitting ? 'Saving...' : isEditing ? 'Save Changes' : 'Register Vendor'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
