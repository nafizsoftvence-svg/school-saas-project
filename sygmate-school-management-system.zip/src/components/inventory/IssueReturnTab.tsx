import React, { useState, useEffect } from 'react';
import {
  Package,
  Layers,
  Search,
  Filter,
  RefreshCw,
  Plus,
  Eye,
  CheckCircle,
  XCircle,
  Clock,
  ArrowUpRight,
  RotateCcw,
  AlertTriangle,
  Building,
  User,
  Calendar,
  Truck,
  FileText,
  X
} from 'lucide-react';
import {
  InventoryItem,
  InventoryLocation,
  Department,
  StaffProfile,
  IssueRequest,
  StockIssue,
  InventoryReturn,
  IssueRequestStatus,
  StockIssueStatus
} from '../../types';
import { api } from '../../services/api';
import { CreateIssueRequestModal } from './CreateIssueRequestModal';
import { IssueApprovalModal } from './IssueApprovalModal';
import { ExecuteStockIssueModal } from './ExecuteStockIssueModal';
import { ProcessInventoryReturnModal } from './ProcessInventoryReturnModal';

interface IssueReturnTabProps {
  items: InventoryItem[];
  locations: InventoryLocation[];
  departments: Department[];
  staffMembers: StaffProfile[];
  onRefreshParent: () => void;
  showNotification: (msg: string, isError?: boolean) => void;
}

export const IssueReturnTab: React.FC<IssueReturnTabProps> = ({
  items,
  locations,
  departments,
  staffMembers,
  onRefreshParent,
  showNotification
}) => {
  const [subTab, setSubTab] = useState<'requests' | 'issues' | 'returns'>('requests');

  // Datasets
  const [requests, setRequests] = useState<IssueRequest[]>([]);
  const [issues, setIssues] = useState<StockIssue[]>([]);
  const [returns, setReturns] = useState<InventoryReturn[]>([]);
  const [loading, setLoading] = useState(false);

  // Filters
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDept, setSelectedDept] = useState('ALL');
  const [selectedLoc, setSelectedLoc] = useState('ALL');
  const [selectedStatus, setSelectedStatus] = useState('ALL');

  // Modal triggers
  const [isCreateRequestOpen, setIsCreateRequestOpen] = useState(false);
  const [isApprovalOpen, setIsApprovalOpen] = useState(false);
  const [selectedRequestForReview, setSelectedRequestForReview] = useState<IssueRequest | null>(null);

  const [isExecuteIssueOpen, setIsExecuteIssueOpen] = useState(false);
  const [selectedRequestForExecute, setSelectedRequestForExecute] = useState<IssueRequest | null>(null);

  const [isProcessReturnOpen, setIsProcessReturnOpen] = useState(false);
  const [selectedIssueForReturn, setSelectedIssueForReturn] = useState<StockIssue | null>(null);

  // Detail Modal
  const [selectedDetailObject, setSelectedDetailObject] = useState<{
    type: 'request' | 'issue' | 'return';
    data: any;
  } | null>(null);

  const loadData = async () => {
    try {
      setLoading(true);
      const [reqData, issData, retData] = await Promise.all([
        api.inventory.getIssueRequests().catch(() => ({ data: [] })),
        api.inventory.getStockIssues().catch(() => ({ data: [] })),
        api.inventory.getInventoryReturns().catch(() => ({ data: [] }))
      ]);

      const extractArray = (res: any) => {
        if (!res) return [];
        if (Array.isArray(res)) return res;
        if (Array.isArray(res.data)) return res.data;
        if (Array.isArray(res.items)) return res.items;
        return [];
      };

      setRequests(extractArray(reqData));
      setIssues(extractArray(issData));
      setReturns(extractArray(retData));
    } catch (err: any) {
      showNotification(err.message || 'Failed to load issue/return records', true);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const safeRequests = Array.isArray(requests) ? requests : [];
  const safeIssues = Array.isArray(issues) ? issues : [];
  const safeReturns = Array.isArray(returns) ? returns : [];

  // Filtered datasets
  const filteredRequests = safeRequests.filter((r) => {
    if (selectedDept !== 'ALL' && r.departmentId !== selectedDept) return false;
    if (selectedLoc !== 'ALL' && r.locationId !== selectedLoc) return false;
    if (selectedStatus !== 'ALL' && r.status !== selectedStatus) return false;
    if (searchTerm.trim()) {
      const q = searchTerm.trim().toLowerCase();
      const match =
        (r.requestNumber || '').toLowerCase().includes(q) ||
        (r.requestedByName || '').toLowerCase().includes(q) ||
        (r.destinationName || '').toLowerCase().includes(q) ||
        (r.departmentName || '').toLowerCase().includes(q) ||
        (r.purpose || '').toLowerCase().includes(q) ||
        (Array.isArray(r.items) && r.items.some((i) => (i.itemName || '').toLowerCase().includes(q) || (i.itemCode || '').toLowerCase().includes(q)));
      if (!match) return false;
    }
    return true;
  });

  const filteredIssues = safeIssues.filter((i) => {
    if (selectedDept !== 'ALL' && i.departmentId !== selectedDept) return false;
    if (selectedLoc !== 'ALL' && i.locationId !== selectedLoc) return false;
    if (selectedStatus !== 'ALL' && i.status !== selectedStatus) return false;
    if (searchTerm.trim()) {
      const q = searchTerm.trim().toLowerCase();
      const match =
        (i.issueNumber || '').toLowerCase().includes(q) ||
        (i.recipientName || '').toLowerCase().includes(q) ||
        (i.departmentName || '').toLowerCase().includes(q) ||
        (i.issueRequestNumber && i.issueRequestNumber.toLowerCase().includes(q)) ||
        (Array.isArray(i.items) && i.items.some((item) => (item.itemName || '').toLowerCase().includes(q) || (item.itemCode || '').toLowerCase().includes(q)));
      if (!match) return false;
    }
    return true;
  });

  const filteredReturns = safeReturns.filter((r) => {
    if (selectedLoc !== 'ALL' && r.locationId !== selectedLoc) return false;
    if (searchTerm.trim()) {
      const q = searchTerm.trim().toLowerCase();
      const match =
        (r.returnNumber || '').toLowerCase().includes(q) ||
        (r.issueNumber || '').toLowerCase().includes(q) ||
        (r.returnedByName || '').toLowerCase().includes(q) ||
        (r.departmentName || '').toLowerCase().includes(q) ||
        (r.reason || '').toLowerCase().includes(q) ||
        (Array.isArray(r.items) && r.items.some((item) => (item.itemName || '').toLowerCase().includes(q) || (item.itemCode || '').toLowerCase().includes(q)));
      if (!match) return false;
    }
    return true;
  });

  // KPI Calculations
  const pendingRequestsCount = safeRequests.filter(
    (r) => r.status === 'SUBMITTED' || r.status === 'UNDER_REVIEW'
  ).length;
  const approvedRequestsCount = safeRequests.filter(
    (r) => r.status === 'APPROVED' || r.status === 'PARTIALLY_ISSUED'
  ).length;
  const activeDispatchesCount = safeIssues.length;
  const totalReturnsCount = safeReturns.length;

  const getRequestStatusBadge = (status: IssueRequestStatus) => {
    switch (status) {
      case 'SUBMITTED':
      case 'UNDER_REVIEW':
        return (
          <span className="inline-flex items-center px-2 py-0.5 text-xs font-semibold rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20">
            <Clock className="w-3 h-3 mr-1" />
            Under Review
          </span>
        );
      case 'APPROVED':
        return (
          <span className="inline-flex items-center px-2 py-0.5 text-xs font-semibold rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            <CheckCircle className="w-3 h-3 mr-1" />
            Approved
          </span>
        );
      case 'PARTIALLY_ISSUED':
        return (
          <span className="inline-flex items-center px-2 py-0.5 text-xs font-semibold rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/20">
            <Truck className="w-3 h-3 mr-1" />
            Partially Issued
          </span>
        );
      case 'FULLY_ISSUED':
      case 'COMPLETED':
        return (
          <span className="inline-flex items-center px-2 py-0.5 text-xs font-semibold rounded-full bg-purple-500/10 text-purple-400 border border-purple-500/20">
            Completed
          </span>
        );
      case 'REJECTED':
        return (
          <span className="inline-flex items-center px-2 py-0.5 text-xs font-semibold rounded-full bg-rose-500/10 text-rose-400 border border-rose-500/20">
            <XCircle className="w-3 h-3 mr-1" />
            Rejected
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center px-2 py-0.5 text-xs font-semibold rounded-full bg-slate-500/10 text-slate-400">
            {status}
          </span>
        );
    }
  };

  const getIssueStatusBadge = (status: StockIssueStatus) => {
    switch (status) {
      case 'ISSUED':
        return (
          <span className="inline-flex items-center px-2 py-0.5 text-xs font-semibold rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            Dispatched
          </span>
        );
      case 'PARTIALLY_RETURNED':
        return (
          <span className="inline-flex items-center px-2 py-0.5 text-xs font-semibold rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20">
            Partially Returned
          </span>
        );
      case 'FULLY_RETURNED':
        return (
          <span className="inline-flex items-center px-2 py-0.5 text-xs font-semibold rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/20">
            Fully Returned
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center px-2 py-0.5 text-xs font-semibold rounded-full bg-slate-500/10 text-slate-400">
            {status}
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Action Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Package className="w-6 h-6 text-blue-400" />
            Inventory Issue & Return Workflow
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Authoritative requisition requests, controlled multi-item stock dispatches, and inventory returns
          </p>
        </div>

        <div className="flex items-center space-x-2.5">
          <button
            onClick={() => {
              loadData();
              onRefreshParent();
            }}
            disabled={loading}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors disabled:opacity-50"
            title="Refresh Data"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>

          <button
            onClick={() => {
              setSelectedRequestForExecute(null);
              setIsExecuteIssueOpen(true);
            }}
            className="px-3.5 py-2 text-xs font-semibold rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors flex items-center gap-1.5"
          >
            <ArrowUpRight className="w-3.5 h-3.5 text-emerald-400" />
            Direct Issue
          </button>

          <button
            onClick={() => setIsCreateRequestOpen(true)}
            className="px-4 py-2 text-xs font-bold rounded-xl bg-blue-600 hover:bg-blue-500 text-white transition-colors flex items-center gap-1.5 shadow-lg shadow-blue-900/30"
          >
            <Plus className="w-4 h-4" />
            New Requisition Request
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-center justify-between">
          <div>
            <div className="text-[11px] font-medium text-slate-400">Awaiting Review</div>
            <div className="text-2xl font-bold text-amber-400 mt-1">{pendingRequestsCount}</div>
            <div className="text-[10px] text-slate-500 mt-0.5">Requisition requests submitted</div>
          </div>
          <div className="p-3 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
            <Clock className="w-5 h-5" />
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-center justify-between">
          <div>
            <div className="text-[11px] font-medium text-slate-400">Ready for Dispatch</div>
            <div className="text-2xl font-bold text-emerald-400 mt-1">{approvedRequestsCount}</div>
            <div className="text-[10px] text-slate-500 mt-0.5">Approved & partially issued</div>
          </div>
          <div className="p-3 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            <CheckCircle className="w-5 h-5" />
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-center justify-between">
          <div>
            <div className="text-[11px] font-medium text-slate-400">Total Stock Issues</div>
            <div className="text-2xl font-bold text-blue-400 mt-1">{activeDispatchesCount}</div>
            <div className="text-[10px] text-slate-500 mt-0.5">Dispatches executed</div>
          </div>
          <div className="p-3 rounded-xl bg-blue-500/10 text-blue-400 border border-blue-500/20">
            <Truck className="w-5 h-5" />
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-center justify-between">
          <div>
            <div className="text-[11px] font-medium text-slate-400">Inventory Returns</div>
            <div className="text-2xl font-bold text-purple-400 mt-1">{totalReturnsCount}</div>
            <div className="text-[10px] text-slate-500 mt-0.5">Unused / returned items</div>
          </div>
          <div className="p-3 rounded-xl bg-purple-500/10 text-purple-400 border border-purple-500/20">
            <RotateCcw className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Sub-Tabs Navigation */}
      <div className="flex border-b border-slate-800 space-x-2">
        <button
          onClick={() => {
            setSubTab('requests');
            setSelectedStatus('ALL');
          }}
          className={`pb-3 px-4 text-xs font-semibold flex items-center gap-2 border-b-2 transition-colors ${
            subTab === 'requests'
              ? 'border-blue-500 text-blue-400'
              : 'border-transparent text-slate-400 hover:text-white'
          }`}
        >
          <FileText className="w-4 h-4" />
          Requisition Requests ({requests.length})
        </button>

        <button
          onClick={() => {
            setSubTab('issues');
            setSelectedStatus('ALL');
          }}
          className={`pb-3 px-4 text-xs font-semibold flex items-center gap-2 border-b-2 transition-colors ${
            subTab === 'issues'
              ? 'border-emerald-500 text-emerald-400'
              : 'border-transparent text-slate-400 hover:text-white'
          }`}
        >
          <Truck className="w-4 h-4" />
          Stock Dispatches & Issues ({issues.length})
        </button>

        <button
          onClick={() => {
            setSubTab('returns');
            setSelectedStatus('ALL');
          }}
          className={`pb-3 px-4 text-xs font-semibold flex items-center gap-2 border-b-2 transition-colors ${
            subTab === 'returns'
              ? 'border-amber-500 text-amber-400'
              : 'border-transparent text-slate-400 hover:text-white'
          }`}
        >
          <RotateCcw className="w-4 h-4" />
          Inventory Returns ({returns.length})
        </button>
      </div>

      {/* Filter Bar */}
      <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-500" />
          <input
            type="text"
            placeholder="Search records, items, persons..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-xs rounded-xl bg-slate-800/80 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
          />
        </div>

        <div>
          <select
            value={selectedDept}
            onChange={(e) => setSelectedDept(e.target.value)}
            className="w-full px-3 py-2 text-xs rounded-xl bg-slate-800/80 border border-slate-700 text-white focus:outline-none focus:border-blue-500"
          >
            <option value="ALL">All Departments</option>
            {departments.map((dept) => (
              <option key={dept.id} value={dept.id}>
                {dept.name}
              </option>
            ))}
          </select>
        </div>

        <div>
          <select
            value={selectedLoc}
            onChange={(e) => setSelectedLoc(e.target.value)}
            className="w-full px-3 py-2 text-xs rounded-xl bg-slate-800/80 border border-slate-700 text-white focus:outline-none focus:border-blue-500"
          >
            <option value="ALL">All Stores / Locations</option>
            {locations.map((loc) => (
              <option key={loc.id} value={loc.id}>
                {loc.name}
              </option>
            ))}
          </select>
        </div>

        <div>
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="w-full px-3 py-2 text-xs rounded-xl bg-slate-800/80 border border-slate-700 text-white focus:outline-none focus:border-blue-500"
          >
            <option value="ALL">All Statuses</option>
            {subTab === 'requests' && (
              <>
                <option value="SUBMITTED">Under Review / Submitted</option>
                <option value="APPROVED">Approved</option>
                <option value="PARTIALLY_ISSUED">Partially Issued</option>
                <option value="COMPLETED">Completed</option>
                <option value="REJECTED">Rejected</option>
              </>
            )}
            {subTab === 'issues' && (
              <>
                <option value="ISSUED">Dispatched / Issued</option>
                <option value="PARTIALLY_RETURNED">Partially Returned</option>
                <option value="FULLY_RETURNED">Fully Returned</option>
              </>
            )}
          </select>
        </div>
      </div>

      {/* 1. REQUISITION REQUESTS TABLE */}
      {subTab === 'requests' && (
        <div className="border border-slate-800 rounded-2xl overflow-hidden bg-slate-900/50">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-800/80 text-slate-400 border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4 font-semibold">Request #</th>
                  <th className="py-3 px-4 font-semibold">Requester</th>
                  <th className="py-3 px-4 font-semibold">Department & Destination</th>
                  <th className="py-3 px-4 font-semibold">Warehouse Store</th>
                  <th className="py-3 px-4 font-semibold text-center">Items</th>
                  <th className="py-3 px-4 font-semibold">Priority</th>
                  <th className="py-3 px-4 font-semibold">Status</th>
                  <th className="py-3 px-4 font-semibold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {filteredRequests.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-8 text-center text-slate-500">
                      No requisition requests found matching your filter criteria.
                    </td>
                  </tr>
                ) : (
                  filteredRequests.map((req) => (
                    <tr key={req.id} className="hover:bg-slate-800/30 transition-colors">
                      <td className="py-3 px-4 font-mono font-bold text-blue-400">{req.requestNumber}</td>
                      <td className="py-3 px-4">
                        <div className="font-semibold text-white">{req.requestedByName}</div>
                        <div className="text-[11px] text-slate-500">
                          {new Date(req.requestDate).toLocaleDateString()}
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-medium text-slate-200">{req.departmentName}</div>
                        <div className="text-[11px] text-slate-400">{req.destinationName}</div>
                      </td>
                      <td className="py-3 px-4 text-slate-300">{req.locationName}</td>
                      <td className="py-3 px-4 text-center">
                        <span className="font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-semibold border border-slate-700">
                          {req.items?.length || 0} items
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <span
                          className={`text-[11px] font-semibold px-2 py-0.5 rounded-full ${
                            req.priority === 'URGENT'
                              ? 'bg-red-500/10 text-red-400 border border-red-500/20'
                              : req.priority === 'HIGH'
                              ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                              : 'bg-slate-800 text-slate-300'
                          }`}
                        >
                          {req.priority}
                        </span>
                      </td>
                      <td className="py-3 px-4">{getRequestStatusBadge(req.status)}</td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end space-x-1.5">
                          <button
                            onClick={() => setSelectedDetailObject({ type: 'request', data: req })}
                            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
                            title="View Requisition"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>

                          {(req.status === 'SUBMITTED' || req.status === 'UNDER_REVIEW') && (
                            <button
                              onClick={() => {
                                setSelectedRequestForReview(req);
                                setIsApprovalOpen(true);
                              }}
                              className="px-2.5 py-1 text-xs font-semibold rounded-lg bg-purple-600/20 hover:bg-purple-600/30 text-purple-300 border border-purple-500/30 transition-colors flex items-center gap-1"
                              title="Review / Approve"
                            >
                              <CheckCircle className="w-3.5 h-3.5" />
                              Review
                            </button>
                          )}

                          {(req.status === 'APPROVED' || req.status === 'PARTIALLY_ISSUED') && (
                            <button
                              onClick={() => {
                                setSelectedRequestForExecute(req);
                                setIsExecuteIssueOpen(true);
                              }}
                              className="px-2.5 py-1 text-xs font-semibold rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white transition-colors flex items-center gap-1 shadow-sm"
                              title="Execute Stock Issue"
                            >
                              <ArrowUpRight className="w-3.5 h-3.5" />
                              Issue
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 2. STOCK ISSUES / DISPATCHES TABLE */}
      {subTab === 'issues' && (
        <div className="border border-slate-800 rounded-2xl overflow-hidden bg-slate-900/50">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-800/80 text-slate-400 border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4 font-semibold">Issue Number</th>
                  <th className="py-3 px-4 font-semibold">Requisition Ref</th>
                  <th className="py-3 px-4 font-semibold">Department & Recipient</th>
                  <th className="py-3 px-4 font-semibold">Source Store</th>
                  <th className="py-3 px-4 font-semibold text-center">Items Dispatched</th>
                  <th className="py-3 px-4 font-semibold">Issue Date</th>
                  <th className="py-3 px-4 font-semibold">Status</th>
                  <th className="py-3 px-4 font-semibold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {filteredIssues.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-8 text-center text-slate-500">
                      No stock issue transactions found matching your criteria.
                    </td>
                  </tr>
                ) : (
                  filteredIssues.map((issue) => (
                    <tr key={issue.id} className="hover:bg-slate-800/30 transition-colors">
                      <td className="py-3 px-4 font-mono font-bold text-emerald-400">{issue.issueNumber}</td>
                      <td className="py-3 px-4 font-mono text-slate-400">
                        {issue.issueRequestNumber || 'Direct Issue'}
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-semibold text-white">{issue.departmentName}</div>
                        <div className="text-[11px] text-slate-400">{issue.recipientName}</div>
                      </td>
                      <td className="py-3 px-4 text-slate-300">{issue.locationName}</td>
                      <td className="py-3 px-4 text-center font-mono">
                        <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-200 border border-slate-700 font-semibold">
                          {(issue.items || []).reduce((sum, item) => sum + (item.quantityIssued || 0), 0)} units ({(issue.items || []).length} lines)
                        </span>
                      </td>
                      <td className="py-3 px-4 text-slate-300">
                        {new Date(issue.issueDate).toLocaleDateString()}
                      </td>
                      <td className="py-3 px-4">{getIssueStatusBadge(issue.status)}</td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end space-x-1.5">
                          <button
                            onClick={() => setSelectedDetailObject({ type: 'issue', data: issue })}
                            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
                            title="View Dispatch Details"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>

                          {issue.status !== 'FULLY_RETURNED' && (
                            <button
                              onClick={() => {
                                setSelectedIssueForReturn(issue);
                                setIsProcessReturnOpen(true);
                              }}
                              className="px-2.5 py-1 text-xs font-semibold rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30 transition-colors flex items-center gap-1"
                              title="Process Return"
                            >
                              <RotateCcw className="w-3.5 h-3.5" />
                              Return Stock
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 3. INVENTORY RETURNS TABLE */}
      {subTab === 'returns' && (
        <div className="border border-slate-800 rounded-2xl overflow-hidden bg-slate-900/50">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-800/80 text-slate-400 border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4 font-semibold">Return #</th>
                  <th className="py-3 px-4 font-semibold">Ref Issue #</th>
                  <th className="py-3 px-4 font-semibold">Returned By</th>
                  <th className="py-3 px-4 font-semibold">Receiving Store</th>
                  <th className="py-3 px-4 font-semibold text-center">Returned Qty</th>
                  <th className="py-3 px-4 font-semibold">Reason</th>
                  <th className="py-3 px-4 font-semibold">Return Date</th>
                  <th className="py-3 px-4 font-semibold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {filteredReturns.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-8 text-center text-slate-500">
                      No inventory returns recorded yet.
                    </td>
                  </tr>
                ) : (
                  filteredReturns.map((ret) => (
                    <tr key={ret.id} className="hover:bg-slate-800/30 transition-colors">
                      <td className="py-3 px-4 font-mono font-bold text-amber-400">{ret.returnNumber}</td>
                      <td className="py-3 px-4 font-mono text-emerald-400">{ret.issueNumber}</td>
                      <td className="py-3 px-4">
                        <div className="font-semibold text-white">{ret.returnedByName}</div>
                        <div className="text-[11px] text-slate-500">{ret.departmentName}</div>
                      </td>
                      <td className="py-3 px-4 text-slate-300">{ret.locationName}</td>
                      <td className="py-3 px-4 text-center font-mono">
                        <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-200 border border-slate-700 font-semibold">
                          {(ret.items || []).reduce((sum, item) => sum + (item.quantityReturned || 0), 0)} units
                        </span>
                      </td>
                      <td className="py-3 px-4 text-slate-300 truncate max-w-xs">{ret.reason}</td>
                      <td className="py-3 px-4 text-slate-300">
                        {new Date(ret.returnDate).toLocaleDateString()}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <button
                          onClick={() => setSelectedDetailObject({ type: 'return', data: ret })}
                          className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
                          title="View Return Details"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* DETAIL MODAL */}
      {selectedDetailObject && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm overflow-y-auto">
          <div className="w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-8">
            <div className="p-6 border-b border-slate-800 flex items-center justify-between bg-slate-900/80">
              <div className="flex items-center space-x-3">
                <div className="p-2.5 rounded-xl bg-blue-500/10 text-blue-400 border border-blue-500/20">
                  <Package className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white capitalize">
                    {selectedDetailObject.type === 'request'
                      ? `Requisition ${selectedDetailObject.data.requestNumber}`
                      : selectedDetailObject.type === 'issue'
                      ? `Stock Dispatch ${selectedDetailObject.data.issueNumber}`
                      : `Inventory Return ${selectedDetailObject.data.returnNumber}`}
                  </h3>
                  <p className="text-xs text-slate-400">
                    Detailed line items and historical audit tracking
                  </p>
                </div>
              </div>
              <button
                onClick={() => setSelectedDetailObject(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 p-3.5 rounded-xl bg-slate-800/40 border border-slate-800 text-xs">
                <div>
                  <span className="text-[11px] text-slate-400">Department</span>
                  <div className="font-semibold text-white mt-0.5">
                    {selectedDetailObject.data.departmentName}
                  </div>
                </div>
                <div>
                  <span className="text-[11px] text-slate-400">Store Location</span>
                  <div className="font-semibold text-white mt-0.5">
                    {selectedDetailObject.data.locationName}
                  </div>
                </div>
                <div>
                  <span className="text-[11px] text-slate-400">Date</span>
                  <div className="font-semibold text-white mt-0.5">
                    {new Date(
                      selectedDetailObject.data.requestDate ||
                        selectedDetailObject.data.issueDate ||
                        selectedDetailObject.data.returnDate
                    ).toLocaleDateString()}
                  </div>
                </div>
              </div>

              {selectedDetailObject.data.purpose && (
                <div>
                  <span className="text-xs font-semibold text-slate-400">Purpose / Justification</span>
                  <p className="text-xs text-slate-200 mt-1 p-2.5 rounded-lg bg-slate-800/40 border border-slate-800">
                    {selectedDetailObject.data.purpose}
                  </p>
                </div>
              )}

              {selectedDetailObject.data.reason && (
                <div>
                  <span className="text-xs font-semibold text-slate-400">Return Reason</span>
                  <p className="text-xs text-slate-200 mt-1 p-2.5 rounded-lg bg-slate-800/40 border border-slate-800">
                    {selectedDetailObject.data.reason}
                  </p>
                </div>
              )}

              {/* Items Table */}
              <div className="space-y-2 pt-2">
                <span className="text-xs font-bold text-white uppercase tracking-wider">Line Items</span>
                <div className="border border-slate-800 rounded-xl overflow-hidden">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-800/70 text-slate-400 border-b border-slate-800">
                      <tr>
                        <th className="py-2 px-3 font-semibold">Item & Code</th>
                        <th className="py-2 px-3 font-semibold text-center">Quantity</th>
                        {selectedDetailObject.type === 'return' && (
                          <th className="py-2 px-3 font-semibold text-center">Condition</th>
                        )}
                        <th className="py-2 px-3 font-semibold">Notes</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800">
                      {(selectedDetailObject.data?.items || []).map((it: any) => (
                        <tr key={it.id} className="bg-slate-900/40">
                          <td className="p-2.5">
                            <div className="font-semibold text-white">{it.itemName}</div>
                            <div className="text-[11px] text-slate-500 font-mono">{it.itemCode}</div>
                          </td>
                          <td className="p-2.5 text-center font-mono">
                            {it.requestedQuantity !== undefined && (
                              <div>
                                Req: {it.requestedQuantity} | App: {it.approvedQuantity} | Issued: {it.issuedQuantity}
                              </div>
                            )}
                            {it.quantityIssued !== undefined && (
                              <div>
                                Issued: {it.quantityIssued} | Ret: {it.returnedQuantity} | Rem: {it.remainingQuantity}
                              </div>
                            )}
                            {it.quantityReturned !== undefined && (
                              <div>{it.quantityReturned} {it.unitShortCode}</div>
                            )}
                          </td>
                          {selectedDetailObject.type === 'return' && (
                            <td className="p-2.5 text-center">
                              <span
                                className={`text-[11px] font-semibold px-2 py-0.5 rounded-full ${
                                  it.condition === 'GOOD'
                                    ? 'bg-emerald-500/10 text-emerald-400'
                                    : 'bg-rose-500/10 text-rose-400'
                                }`}
                              >
                                {it.condition}
                              </span>
                            </td>
                          )}
                          <td className="p-2.5 text-slate-400">{it.notes || '—'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            <div className="p-4 border-t border-slate-800 flex justify-end">
              <button
                onClick={() => setSelectedDetailObject(null)}
                className="px-4 py-2 text-xs font-semibold rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CREATE REQUISITION MODAL */}
      <CreateIssueRequestModal
        isOpen={isCreateRequestOpen}
        onClose={() => setIsCreateRequestOpen(false)}
        items={items}
        locations={locations}
        departments={departments}
        staffMembers={staffMembers}
        onSuccess={(msg) => {
          showNotification(msg);
          loadData();
          onRefreshParent();
        }}
      />

      {/* APPROVAL MODAL */}
      <IssueApprovalModal
        isOpen={isApprovalOpen}
        onClose={() => {
          setIsApprovalOpen(false);
          setSelectedRequestForReview(null);
        }}
        request={selectedRequestForReview}
        onSuccess={(msg) => {
          showNotification(msg);
          loadData();
          onRefreshParent();
        }}
      />

      {/* EXECUTE STOCK ISSUE MODAL */}
      <ExecuteStockIssueModal
        isOpen={isExecuteIssueOpen}
        onClose={() => {
          setIsExecuteIssueOpen(false);
          setSelectedRequestForExecute(null);
        }}
        preselectedRequest={selectedRequestForExecute}
        items={items}
        locations={locations}
        departments={departments}
        staffMembers={staffMembers}
        onSuccess={(msg) => {
          showNotification(msg);
          loadData();
          onRefreshParent();
        }}
      />

      {/* PROCESS INVENTORY RETURN MODAL */}
      <ProcessInventoryReturnModal
        isOpen={isProcessReturnOpen}
        onClose={() => {
          setIsProcessReturnOpen(false);
          setSelectedIssueForReturn(null);
        }}
        preselectedIssue={selectedIssueForReturn}
        issues={issues}
        locations={locations}
        onSuccess={(msg) => {
          showNotification(msg);
          loadData();
          onRefreshParent();
        }}
      />
    </div>
  );
};
