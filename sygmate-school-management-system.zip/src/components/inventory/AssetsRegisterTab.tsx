import React, { useState } from 'react';
import {
  ShieldCheck,
  Search,
  Filter,
  Plus,
  Edit2,
  Trash2,
  FileText,
  Clock,
  Eye,
  RefreshCw,
  Building,
  Tag,
  DollarSign,
  AlertCircle
} from 'lucide-react';
import {
  Asset,
  AssetCategory,
  InventoryLocation,
  Supplier,
  AssetStatus
} from '../../types';

interface AssetsRegisterTabProps {
  assets: Asset[];
  categories: AssetCategory[];
  locations: InventoryLocation[];
  suppliers: Supplier[];
  loading: boolean;
  onRefresh: () => void;
  onOpenNewAssetModal: () => void;
  onViewAssetDetails: (asset: Asset) => void;
  onEditAsset: (asset: Asset) => void;
  onOpenStatusModal: (asset: Asset) => void;
  onDeleteAsset: (id: string) => void;
}

export const AssetsRegisterTab: React.FC<AssetsRegisterTabProps> = ({
  assets,
  categories,
  locations,
  suppliers,
  loading,
  onRefresh,
  onOpenNewAssetModal,
  onViewAssetDetails,
  onEditAsset,
  onOpenStatusModal,
  onDeleteAsset
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('ALL');
  const [selectedStatus, setSelectedStatus] = useState('ALL');
  const [selectedLocation, setSelectedLocation] = useState('ALL');
  const [selectedSupplier, setSelectedSupplier] = useState('ALL');

  // Filter client-side
  const filteredAssets = assets.filter(asset => {
    if (selectedCategory !== 'ALL' && asset.categoryId !== selectedCategory) return false;
    if (selectedStatus !== 'ALL' && asset.status !== selectedStatus) return false;
    if (selectedLocation !== 'ALL' && asset.locationId !== selectedLocation) return false;
    if (selectedSupplier !== 'ALL' && asset.supplierId !== selectedSupplier) return false;

    if (searchTerm.trim()) {
      const q = searchTerm.trim().toLowerCase();
      const match =
        asset.name.toLowerCase().includes(q) ||
        asset.assetTag.toLowerCase().includes(q) ||
        (asset.serialNumber && asset.serialNumber.toLowerCase().includes(q)) ||
        (asset.brand && asset.brand.toLowerCase().includes(q)) ||
        (asset.model && asset.model.toLowerCase().includes(q)) ||
        (asset.categoryName && asset.categoryName.toLowerCase().includes(q)) ||
        (asset.locationName && asset.locationName.toLowerCase().includes(q));
      if (!match) return false;
    }
    return true;
  });

  const totalFilteredValue = filteredAssets.reduce((sum, a) => sum + (Number(a.purchaseCost) || 0), 0);

  const getStatusBadge = (status: AssetStatus) => {
    switch (status) {
      case 'ACTIVE':
      case 'AVAILABLE':
        return <span className="inline-flex items-center px-2 py-0.5 text-xs font-semibold rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">Active</span>;
      case 'ASSIGNED':
        return <span className="inline-flex items-center px-2 py-0.5 text-xs font-semibold rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/20">Assigned</span>;
      case 'UNDER_REPAIR':
        return <span className="inline-flex items-center px-2 py-0.5 text-xs font-semibold rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20">Under Repair</span>;
      case 'DAMAGED':
        return <span className="inline-flex items-center px-2 py-0.5 text-xs font-semibold rounded-full bg-rose-500/10 text-rose-400 border border-rose-500/20">Damaged</span>;
      case 'LOST':
        return <span className="inline-flex items-center px-2 py-0.5 text-xs font-semibold rounded-full bg-red-600/20 text-red-300 border border-red-500/30">Lost</span>;
      case 'RETIRED':
      case 'DISPOSED':
        return <span className="inline-flex items-center px-2 py-0.5 text-xs font-semibold rounded-full bg-slate-500/10 text-slate-400 border border-slate-500/20">{status}</span>;
      default:
        return <span className="inline-flex items-center px-2 py-0.5 text-xs font-semibold rounded-full bg-slate-500/10 text-slate-400">{status}</span>;
    }
  };

  return (
    <div className="space-y-4">
      {/* Header and Controls */}
      <div className="p-4 rounded-xl glass-panel border border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-semibold text-white flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
              Institutional Asset Register
            </h3>
            <p className="text-xs text-slate-400">
              Fixed asset tags, hardware lifecycle history, warranty tracking, and custody verification
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={onRefresh}
              disabled={loading}
              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors disabled:opacity-50"
              title="Refresh asset register"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-emerald-400' : ''}`} />
            </button>
            <button
              onClick={onOpenNewAssetModal}
              className="px-3.5 py-2 text-xs font-semibold rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white transition-colors flex items-center gap-1.5 shadow-sm shadow-emerald-950"
            >
              <Plus className="w-4 h-4" />
              Register New Asset
            </button>
          </div>
        </div>

        {/* Filter bar */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-3 pt-2 border-t border-slate-800/60">
          {/* Search */}
          <div className="relative md:col-span-2">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search by tag (AST-...), serial #, name, brand..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-4 py-2 text-xs rounded-lg glass-input border border-slate-700/80 focus:outline-none focus:border-emerald-500 text-slate-100 placeholder-slate-500"
            />
          </div>

          {/* Category Filter */}
          <div>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700/80 focus:outline-none focus:border-emerald-500 text-slate-200"
            >
              <option value="ALL">All Categories</option>
              {categories.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          {/* Status Filter */}
          <div>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700/80 focus:outline-none focus:border-emerald-500 text-slate-200"
            >
              <option value="ALL">All Statuses</option>
              <option value="ACTIVE">Active</option>
              <option value="AVAILABLE">Available</option>
              <option value="ASSIGNED">Assigned</option>
              <option value="UNDER_REPAIR">Under Repair</option>
              <option value="DAMAGED">Damaged</option>
              <option value="LOST">Lost</option>
              <option value="RETIRED">Retired</option>
              <option value="DISPOSED">Disposed</option>
            </select>
          </div>

          {/* Location Filter */}
          <div>
            <select
              value={selectedLocation}
              onChange={(e) => setSelectedLocation(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700/80 focus:outline-none focus:border-emerald-500 text-slate-200"
            >
              <option value="ALL">All Locations</option>
              {locations.map((l) => (
                <option key={l.id} value={l.id}>
                  {l.name}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Asset Table */}
      <div className="rounded-xl glass-panel border border-slate-800 overflow-hidden shadow-sm">
        <div className="p-3 bg-slate-900/60 border-b border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center space-x-3">
            <span>Showing <strong className="text-white font-medium">{filteredAssets.length}</strong> assets</span>
            <span>•</span>
            <span>Valuation: <strong className="text-emerald-400 font-mono font-medium">${totalFilteredValue.toLocaleString()}</strong></span>
          </div>
          {(searchTerm || selectedCategory !== 'ALL' || selectedStatus !== 'ALL' || selectedLocation !== 'ALL') && (
            <button
              onClick={() => {
                setSearchTerm('');
                setSelectedCategory('ALL');
                setSelectedStatus('ALL');
                setSelectedLocation('ALL');
                setSelectedSupplier('ALL');
              }}
              className="text-emerald-400 hover:text-emerald-300 transition-colors"
            >
              Clear filters
            </button>
          )}
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-900/80 border-b border-slate-800 text-slate-400 uppercase tracking-wider font-semibold text-[11px]">
              <tr>
                <th className="py-3 px-4">Asset Tag & Name</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4">Serial Number</th>
                <th className="py-3 px-4">Location / Dept</th>
                <th className="py-3 px-4">Purchase Date</th>
                <th className="py-3 px-4">Cost</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {filteredAssets.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-400">
                    <ShieldCheck className="w-10 h-10 text-slate-600 mx-auto mb-2" />
                    <p className="text-sm font-medium text-slate-300">No assets found</p>
                    <p className="text-xs text-slate-500 mt-1">Try adjusting search parameters or register an institutional asset.</p>
                  </td>
                </tr>
              ) : (
                filteredAssets.map((asset) => (
                  <tr key={asset.id} className="hover:bg-slate-800/25 transition-colors">
                    <td className="py-3 px-4">
                      <div className="space-y-0.5">
                        <div className="flex items-center space-x-2">
                          <span className="font-mono text-xs font-semibold px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                            {asset.assetTag}
                          </span>
                          <span className="font-semibold text-white">{asset.name}</span>
                        </div>
                        {(asset.brand || asset.model) && (
                          <div className="text-[11px] text-slate-400">
                            {[asset.brand, asset.model].filter(Boolean).join(' • ')}
                          </div>
                        )}
                      </div>
                    </td>
                    <td className="py-3 px-4 font-medium text-slate-200">
                      {asset.categoryName}
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-300">
                      {asset.serialNumber || <span className="text-slate-500 italic">None</span>}
                    </td>
                    <td className="py-3 px-4">
                      <div className="text-slate-200 font-medium">{asset.locationName}</div>
                      {asset.department && (
                        <div className="text-[11px] text-slate-400">{asset.department}</div>
                      )}
                    </td>
                    <td className="py-3 px-4 text-slate-300 font-mono">
                      {asset.purchaseDate || 'N/A'}
                    </td>
                    <td className="py-3 px-4 font-mono font-semibold text-slate-200">
                      ${Number(asset.purchaseCost).toLocaleString()}
                    </td>
                    <td className="py-3 px-4">
                      {getStatusBadge(asset.status)}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end space-x-1.5">
                        <button
                          onClick={() => onViewAssetDetails(asset)}
                          className="p-1.5 rounded-lg hover:bg-slate-700/60 text-emerald-400 hover:text-emerald-300 transition-colors"
                          title="View Details & History"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => onOpenStatusModal(asset)}
                          className="p-1.5 rounded-lg hover:bg-blue-500/10 text-slate-400 hover:text-blue-400 transition-colors"
                          title="Change Status"
                        >
                          <Clock className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => onEditAsset(asset)}
                          className="p-1.5 rounded-lg hover:bg-slate-700/60 text-slate-400 hover:text-slate-200 transition-colors"
                          title="Edit Asset"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => {
                            if (window.confirm(`Are you sure you want to delete asset '${asset.name}' (${asset.assetTag})?`)) {
                              onDeleteAsset(asset.id);
                            }
                          }}
                          className="p-1.5 rounded-lg hover:bg-rose-500/10 text-slate-400 hover:text-rose-400 transition-colors"
                          title="Delete Asset"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
