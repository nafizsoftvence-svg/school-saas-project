import React, { useState, useEffect } from 'react';
import {
  X,
  Package,
  AlertCircle,
  CheckCircle,
  Truck,
  Building,
  User,
  ArrowUpRight,
  Layers
} from 'lucide-react';
import {
  InventoryItem,
  InventoryLocation,
  Department,
  StaffProfile,
  IssueRequest,
  OrganizationalDestinationType,
  ExecuteStockIssuePayload
} from '../../types';
import { api } from '../../services/api';

interface ExecuteStockIssueModalProps {
  isOpen: boolean;
  onClose: () => void;
  preselectedRequest?: IssueRequest | null;
  items: InventoryItem[];
  locations: InventoryLocation[];
  departments: Department[];
  staffMembers: StaffProfile[];
  onSuccess: (message: string) => void;
}

interface IssueLineState {
  itemId: string;
  itemName: string;
  itemCode: string;
  unitShortCode: string;
  maxApproved: number;
  availableStock: number;
  quantityToIssue: number | '';
  notes: string;
}

export const ExecuteStockIssueModal: React.FC<ExecuteStockIssueModalProps> = ({
  isOpen,
  onClose,
  preselectedRequest,
  items,
  locations,
  departments,
  staffMembers,
  onSuccess
}) => {
  const [locationId, setLocationId] = useState(preselectedRequest?.locationId || locations[0]?.id || '');
  const [departmentId, setDepartmentId] = useState(preselectedRequest?.departmentId || departments[0]?.id || '');
  const [departmentName, setDepartmentName] = useState(preselectedRequest?.departmentName || departments[0]?.name || '');
  const [recipientType, setRecipientType] = useState<OrganizationalDestinationType>(
    preselectedRequest?.destinationType || 'DEPARTMENT'
  );
  const [recipientId, setRecipientId] = useState(preselectedRequest?.destinationId || '');
  const [recipientName, setRecipientName] = useState(preselectedRequest?.destinationName || '');
  const [purpose, setPurpose] = useState(preselectedRequest?.purpose || '');
  const [notes, setNotes] = useState('');
  const [issueDate, setIssueDate] = useState(new Date().toISOString().split('T')[0]);

  const [lines, setLines] = useState<IssueLineState[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Initialize lines when modal opens or preselectedRequest changes
  useEffect(() => {
    if (isOpen) {
      setError(null);
      if (preselectedRequest) {
        setLocationId(preselectedRequest.locationId);
        setDepartmentId(preselectedRequest.departmentId || '');
        setDepartmentName(preselectedRequest.departmentName);
        setRecipientType(preselectedRequest.destinationType);
        setRecipientId(preselectedRequest.destinationId || '');
        setRecipientName(preselectedRequest.destinationName);
        setPurpose(preselectedRequest.purpose);

        // Fetch live balances for each item in the request
        const initialLines: IssueLineState[] = preselectedRequest.items.map((item) => {
          const remaining = Math.max(0, item.approvedQuantity - item.issuedQuantity);
          return {
            itemId: item.itemId,
            itemName: item.itemName,
            itemCode: item.itemCode,
            unitShortCode: item.unitShortCode,
            maxApproved: remaining,
            availableStock: item.availableQuantityAtRequest || 0,
            quantityToIssue: remaining > 0 ? remaining : 0,
            notes: ''
          };
        });
        setLines(initialLines);
      } else {
        const safeItems = Array.isArray(items) ? items : [];
        const defaultItem = safeItems.filter((i) => i.isStockable !== false)[0];
        setLines([
          {
            itemId: defaultItem?.id || '',
            itemName: defaultItem?.name || '',
            itemCode: defaultItem?.itemCode || '',
            unitShortCode: defaultItem?.unitShortCode || 'PCS',
            maxApproved: 999999,
            availableStock: 0,
            quantityToIssue: 1,
            notes: ''
          }
        ]);
      }
    }
  }, [isOpen, preselectedRequest, items]);

  if (!isOpen) return null;

  const handleQtyChange = (index: number, val: string) => {
    const num = val === '' ? '' : Math.max(0, parseInt(val, 10));
    const newLines = [...lines];
    newLines[index].quantityToIssue = isNaN(num as number) ? 0 : num;
    setLines(newLines);
  };

  const handleLineNotesChange = (index: number, val: string) => {
    const newLines = [...lines];
    newLines[index].notes = val;
    setLines(newLines);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const activeLines = lines.filter((l) => typeof l.quantityToIssue === 'number' && l.quantityToIssue > 0);
    if (activeLines.length === 0) {
      setError('Please specify a positive quantity to issue for at least one item.');
      return;
    }

    if (preselectedRequest) {
      for (const line of activeLines) {
        if (Number(line.quantityToIssue) > line.maxApproved) {
          setError(
            `Issue quantity for '${line.itemName}' (${line.quantityToIssue}) exceeds remaining approved quota (${line.maxApproved}).`
          );
          return;
        }
      }
    }

    try {
      setSubmitting(true);

      const payload: ExecuteStockIssuePayload = {
        issueRequestId: preselectedRequest?.id,
        locationId,
        departmentId: departmentId || undefined,
        departmentName: departmentName || 'General Administration',
        recipientType,
        recipientId: recipientId || undefined,
        recipientName: recipientName.trim() || 'Department Custodian',
        purpose: purpose.trim() || 'Stock dispatch',
        notes: notes.trim() || undefined,
        issueDate: issueDate || new Date().toISOString(),
        items: activeLines.map((l) => ({
          itemId: l.itemId,
          quantity: Number(l.quantityToIssue),
          notes: l.notes.trim() || undefined
        }))
      };

      const res = await api.inventory.executeStockIssue(payload);
      onSuccess(res.message || 'Stock issue executed successfully.');
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to execute stock issue.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm overflow-y-auto">
      <div className="w-full max-w-3xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="p-6 border-b border-slate-800 flex items-center justify-between bg-slate-900/80">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <Truck className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">Execute Stock Dispatch & Issue</h3>
              <p className="text-xs text-slate-400">
                {preselectedRequest
                  ? `Fulfill Requisition ${preselectedRequest.requestNumber} for ${preselectedRequest.destinationName}`
                  : 'Direct authorized inventory dispatch from store'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {error && (
            <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Meta */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">Dispatching Store</label>
              <select
                disabled={!!preselectedRequest}
                value={locationId}
                onChange={(e) => setLocationId(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl bg-slate-800/80 border border-slate-700 text-white focus:outline-none disabled:opacity-60"
              >
                {locations.map((loc) => (
                  <option key={loc.id} value={loc.id}>
                    {loc.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">Recipient Department</label>
              <select
                disabled={!!preselectedRequest}
                value={departmentId}
                onChange={(e) => {
                  setDepartmentId(e.target.value);
                  const d = departments.find((dept) => dept.id === e.target.value);
                  if (d) setDepartmentName(d.name);
                }}
                className="w-full px-3 py-2 text-xs rounded-xl bg-slate-800/80 border border-slate-700 text-white focus:outline-none disabled:opacity-60"
              >
                {departments.map((dept) => (
                  <option key={dept.id} value={dept.id}>
                    {dept.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">Issue Date</label>
              <input
                type="date"
                value={issueDate}
                onChange={(e) => setIssueDate(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl bg-slate-800/80 border border-slate-700 text-white focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Recipient / Custodian Name <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                placeholder="Staff, teacher, or department representative..."
                value={recipientName}
                onChange={(e) => setRecipientName(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl bg-slate-800/80 border border-slate-700 text-white focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">Purpose</label>
              <input
                type="text"
                placeholder="Operational purpose..."
                value={purpose}
                onChange={(e) => setPurpose(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl bg-slate-800/80 border border-slate-700 text-white focus:outline-none"
              />
            </div>
          </div>

          {/* Line items table */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                <Layers className="w-4 h-4 text-emerald-400" />
                Line Items To Dispatch
              </span>
              {preselectedRequest && (
                <span className="text-[11px] text-slate-400">
                  Partial fulfillment supported. Unissued balance remains open on request.
                </span>
              )}
            </div>

            <div className="border border-slate-800 rounded-xl overflow-hidden">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-800/70 text-slate-400 border-b border-slate-800">
                  <tr>
                    <th className="py-2.5 px-3 font-semibold">Item & SKU</th>
                    {preselectedRequest && (
                      <th className="py-2.5 px-3 font-semibold text-center w-24">Remaining</th>
                    )}
                    <th className="py-2.5 px-3 font-semibold text-center w-32">Issue Quantity</th>
                    <th className="py-2.5 px-3 font-semibold">Line Notes</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {lines.map((line, idx) => (
                    <tr key={idx} className="bg-slate-900/40">
                      <td className="p-2.5">
                        <div className="font-semibold text-white">{line.itemName}</div>
                        <div className="text-[11px] text-slate-400 font-mono">{line.itemCode}</div>
                      </td>
                      {preselectedRequest && (
                        <td className="p-2.5 text-center font-mono">
                          <span className="px-2 py-0.5 rounded bg-blue-500/10 text-blue-400 font-semibold border border-blue-500/20">
                            {line.maxApproved} {line.unitShortCode}
                          </span>
                        </td>
                      )}
                      <td className="p-2.5">
                        <div className="flex items-center gap-1.5 justify-center">
                          <input
                            type="number"
                            min="0"
                            max={preselectedRequest ? line.maxApproved : undefined}
                            value={line.quantityToIssue}
                            onChange={(e) => handleQtyChange(idx, e.target.value)}
                            className="w-20 px-2 py-1 text-xs rounded-lg bg-slate-800 border border-slate-700 text-center font-mono text-white focus:outline-none focus:border-emerald-500"
                          />
                          <span className="text-slate-400 font-mono text-xs">{line.unitShortCode}</span>
                        </div>
                      </td>
                      <td className="p-2.5">
                        <input
                          type="text"
                          placeholder="Optional line notes..."
                          value={line.notes}
                          onChange={(e) => handleLineNotesChange(idx, e.target.value)}
                          className="w-full px-2 py-1 text-xs rounded-lg bg-slate-800 border border-slate-700 text-white focus:outline-none"
                        />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">Dispatch Notes / Gate Pass Info</label>
            <textarea
              rows={2}
              placeholder="e.g. Received in good order, signature on physical handover slip..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl bg-slate-800/80 border border-slate-700 text-white focus:outline-none"
            />
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-end space-x-3 pt-4 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-5 py-2 text-xs font-bold rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white transition-colors disabled:opacity-50 flex items-center gap-1.5 shadow-lg shadow-emerald-900/30"
            >
              <ArrowUpRight className="w-4 h-4" />
              {submitting ? 'Executing Stock Out...' : 'Confirm Stock Dispatch'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
