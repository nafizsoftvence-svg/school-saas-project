import React, { useState, useEffect } from 'react';
import { X, ShieldCheck, Check, AlertCircle } from 'lucide-react';
import {
  Asset,
  AssetCategory,
  InventoryLocation,
  Supplier,
  AssetStatus,
  CreateAssetPayload,
  UpdateAssetPayload
} from '../../types';

interface AssetModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (payload: CreateAssetPayload | UpdateAssetPayload) => Promise<void>;
  asset?: Asset | null;
  categories: AssetCategory[];
  locations: InventoryLocation[];
  suppliers: Supplier[];
}

export const AssetModal: React.FC<AssetModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  asset,
  categories,
  locations,
  suppliers
}) => {
  const isEditing = !!asset;

  const [assetTag, setAssetTag] = useState('');
  const [name, setName] = useState('');
  const [categoryId, setCategoryId] = useState('');
  const [brand, setBrand] = useState('');
  const [model, setModel] = useState('');
  const [serialNumber, setSerialNumber] = useState('');
  const [purchaseDate, setPurchaseDate] = useState('');
  const [purchaseCost, setPurchaseCost] = useState<number>(0);
  const [supplierId, setSupplierId] = useState('');
  const [warrantyStart, setWarrantyStart] = useState('');
  const [warrantyEnd, setWarrantyEnd] = useState('');
  const [locationId, setLocationId] = useState('');
  const [department, setDepartment] = useState('');
  const [status, setStatus] = useState<AssetStatus>('ACTIVE');
  const [description, setDescription] = useState('');

  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (asset) {
      setAssetTag(asset.assetTag || '');
      setName(asset.name || '');
      setCategoryId(asset.categoryId || '');
      setBrand(asset.brand || '');
      setModel(asset.model || '');
      setSerialNumber(asset.serialNumber || '');
      setPurchaseDate(asset.purchaseDate || '');
      setPurchaseCost(asset.purchaseCost || 0);
      setSupplierId(asset.supplierId || '');
      setWarrantyStart(asset.warrantyStart || '');
      setWarrantyEnd(asset.warrantyEnd || '');
      setLocationId(asset.locationId || '');
      setDepartment(asset.department || '');
      setStatus(asset.status || 'ACTIVE');
      setDescription(asset.description || '');
    } else {
      setAssetTag('');
      setName('');
      setCategoryId(categories[0]?.id || '');
      setBrand('');
      setModel('');
      setSerialNumber('');
      setPurchaseDate(new Date().toISOString().split('T')[0]);
      setPurchaseCost(0);
      setSupplierId('');
      setWarrantyStart('');
      setWarrantyEnd('');
      setLocationId(locations[0]?.id || '');
      setDepartment('');
      setStatus('ACTIVE');
      setDescription('');
    }
    setError(null);
  }, [asset, categories, locations, suppliers, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Asset name is required');
      return;
    }
    if (!categoryId) {
      setError('Asset category is required');
      return;
    }
    if (!locationId) {
      setError('Location is required');
      return;
    }

    try {
      setSubmitting(true);
      setError(null);

      const payload: any = {
        name: name.trim(),
        categoryId,
        brand: brand.trim() || undefined,
        model: model.trim() || undefined,
        serialNumber: serialNumber.trim() || undefined,
        purchaseDate: purchaseDate || undefined,
        purchaseCost: Number(purchaseCost) || 0,
        supplierId: supplierId || undefined,
        warrantyStart: warrantyStart || undefined,
        warrantyEnd: warrantyEnd || undefined,
        locationId,
        department: department.trim() || undefined,
        description: description.trim() || undefined,
        status
      };

      if (assetTag.trim()) {
        payload.assetTag = assetTag.trim().toUpperCase();
      }

      await onSubmit(payload);
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to save asset');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm overflow-y-auto">
      <div className="w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800 bg-slate-900/60">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-white">
                {isEditing ? `Edit Asset: ${asset.name}` : 'Register Institutional Asset'}
              </h3>
              <p className="text-xs text-slate-400">
                {isEditing ? `Tag: ${asset.assetTag}` : 'Generates AST-YYYY-NNNN if tag is left empty'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
          {error && (
            <div className="p-3 rounded-lg bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Asset Tag */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Asset Tag <span className="text-slate-500 font-normal">(optional barcode/tag)</span>
              </label>
              <input
                type="text"
                placeholder="e.g. AST-2026-0001 (auto if empty)"
                value={assetTag}
                onChange={(e) => setAssetTag(e.target.value.toUpperCase())}
                className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700/80 focus:outline-none focus:border-emerald-500 text-slate-100 font-mono"
              />
            </div>

            {/* Asset Name */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Asset Name <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Dell OptiPlex 7090 Desktop"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700/80 focus:outline-none focus:border-emerald-500 text-slate-100"
              />
            </div>

            {/* Category */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Asset Category <span className="text-rose-400">*</span>
              </label>
              <select
                required
                value={categoryId}
                onChange={(e) => setCategoryId(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700/80 focus:outline-none focus:border-emerald-500 text-slate-200"
              >
                <option value="">Select Category...</option>
                {categories.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Location */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Institutional Location <span className="text-rose-400">*</span>
              </label>
              <select
                required
                value={locationId}
                onChange={(e) => setLocationId(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700/80 focus:outline-none focus:border-emerald-500 text-slate-200"
              >
                <option value="">Select Location...</option>
                {locations.map((l) => (
                  <option key={l.id} value={l.id}>
                    {l.name} ({l.code})
                  </option>
                ))}
              </select>
            </div>

            {/* Department */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Assigned Department
              </label>
              <input
                type="text"
                placeholder="e.g. Computer Science, Administration"
                value={department}
                onChange={(e) => setDepartment(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700/80 focus:outline-none focus:border-emerald-500 text-slate-100"
              />
            </div>

            {/* Brand */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Brand / Manufacturer
              </label>
              <input
                type="text"
                placeholder="e.g. Dell, Sony, Olympus"
                value={brand}
                onChange={(e) => setBrand(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700/80 focus:outline-none focus:border-emerald-500 text-slate-100"
              />
            </div>

            {/* Model */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Model Number
              </label>
              <input
                type="text"
                placeholder="e.g. OptiPlex 7090 i7 / 16GB"
                value={model}
                onChange={(e) => setModel(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700/80 focus:outline-none focus:border-emerald-500 text-slate-100"
              />
            </div>

            {/* Serial Number */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Hardware Serial Number
              </label>
              <input
                type="text"
                placeholder="e.g. CN-0G1234-70163-95K-01AB"
                value={serialNumber}
                onChange={(e) => setSerialNumber(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700/80 focus:outline-none focus:border-emerald-500 text-slate-100 font-mono"
              />
            </div>

            {/* Purchase Cost */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Purchase Cost ($)
              </label>
              <input
                type="number"
                min="0"
                step="0.01"
                value={purchaseCost}
                onChange={(e) => setPurchaseCost(parseFloat(e.target.value) || 0)}
                className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700/80 focus:outline-none focus:border-emerald-500 text-slate-100 font-mono"
              />
            </div>

            {/* Purchase Date */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Purchase Date
              </label>
              <input
                type="date"
                value={purchaseDate}
                onChange={(e) => setPurchaseDate(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700/80 focus:outline-none focus:border-emerald-500 text-slate-100"
              />
            </div>

            {/* Supplier */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Vendor / Supplier
              </label>
              <select
                value={supplierId}
                onChange={(e) => setSupplierId(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700/80 focus:outline-none focus:border-emerald-500 text-slate-200"
              >
                <option value="">Unlinked Supplier</option>
                {suppliers.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name} ({s.supplierCode})
                  </option>
                ))}
              </select>
            </div>

            {/* Status */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Operational Status
              </label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as AssetStatus)}
                className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700/80 focus:outline-none focus:border-emerald-500 text-slate-200"
              >
                <option value="ACTIVE">Active (In Use)</option>
                <option value="AVAILABLE">Available (In Storage)</option>
                <option value="ASSIGNED">Assigned (To Staff/Class)</option>
                <option value="UNDER_REPAIR">Under Repair</option>
                <option value="DAMAGED">Damaged</option>
                <option value="LOST">Lost</option>
                <option value="RETIRED">Retired</option>
                <option value="DISPOSED">Disposed</option>
              </select>
            </div>

            {/* Warranty Start */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Warranty Start Date
              </label>
              <input
                type="date"
                value={warrantyStart}
                onChange={(e) => setWarrantyStart(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700/80 focus:outline-none focus:border-emerald-500 text-slate-100"
              />
            </div>

            {/* Warranty End */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Warranty Expiry Date
              </label>
              <input
                type="date"
                value={warrantyEnd}
                onChange={(e) => setWarrantyEnd(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700/80 focus:outline-none focus:border-emerald-500 text-slate-100"
              />
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Description / Notes
            </label>
            <textarea
              rows={2}
              placeholder="Hardware specifications, power ratings, assigned user, or special maintenance considerations..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700/80 focus:outline-none focus:border-emerald-500 text-slate-100"
            />
          </div>

          {/* Buttons */}
          <div className="flex items-center justify-end space-x-3 pt-4 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-5 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg transition-colors flex items-center gap-1.5 shadow-sm shadow-emerald-950 disabled:opacity-50"
            >
              <Check className="w-4 h-4" />
              {submitting ? 'Saving...' : isEditing ? 'Save Changes' : 'Register Asset'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
