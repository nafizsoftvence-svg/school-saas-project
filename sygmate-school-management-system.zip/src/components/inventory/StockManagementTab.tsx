import React, { useState, useEffect } from 'react';
import {
  Package,
  ArrowDownLeft,
  ArrowUpRight,
  ArrowLeftRight,
  RotateCcw,
  Sliders,
  Building,
  TrendingDown,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Search,
  Filter,
  RefreshCw,
  FileText,
  Layers,
  Calendar,
  Download,
  Eye,
  Plus
} from 'lucide-react';
import {
  InventoryItem,
  InventoryCategory,
  InventoryLocation,
  Supplier,
  ItemStockBalance,
  StockMovement,
  StockTransaction,
  StockSummary,
  StockStatus,
  StockMovementType,
  StockTransactionType
} from '../../types';
import { api } from '../../services/api';
import { StockTransactionModal, StockModalMode } from './StockTransactionModal';
import { StockTransactionDetailModal } from './StockTransactionDetailModal';
import { ItemStockDetailModal } from './ItemStockDetailModal';

interface StockManagementTabProps {
  items: InventoryItem[];
  categories: InventoryCategory[];
  locations: InventoryLocation[];
  suppliers: Supplier[];
  onRefreshParent: () => void;
  showNotification: (msg: string, isError?: boolean) => void;
}

export const StockManagementTab: React.FC<StockManagementTabProps> = ({
  items,
  categories,
  locations,
  suppliers,
  onRefreshParent,
  showNotification
}) => {
  // Subtab navigation
  const [subTab, setSubTab] = useState<'balances' | 'ledger' | 'transactions'>('balances');

  const safeItems = Array.isArray(items) ? items : [];

  // Datasets
  const [summary, setSummary] = useState<StockSummary | null>(null);
  const [balances, setBalances] = useState<ItemStockBalance[]>([]);
  const [movements, setMovements] = useState<StockMovement[]>([]);
  const [transactions, setTransactions] = useState<StockTransaction[]>([]);
  const [loading, setLoading] = useState(false);

  // Filters for Balances
  const [balanceSearch, setBalanceSearch] = useState('');
  const [balanceCategory, setBalanceCategory] = useState('ALL');
  const [balanceLocation, setBalanceLocation] = useState('ALL');
  const [balanceStatus, setBalanceStatus] = useState<'ALL' | StockStatus>('ALL');

  // Filters for Ledger
  const [ledgerSearch, setLedgerSearch] = useState('');
  const [ledgerLocation, setLedgerLocation] = useState('ALL');
  const [ledgerType, setLedgerType] = useState<'ALL' | StockMovementType>('ALL');
  const [ledgerStartDate, setLedgerStartDate] = useState('');
  const [ledgerEndDate, setLedgerEndDate] = useState('');

  // Filters for Transactions
  const [txnSearch, setTxnSearch] = useState('');
  const [txnType, setTxnType] = useState<'ALL' | StockTransactionType>('ALL');
  const [txnLocation, setTxnLocation] = useState('ALL');

  // Modals
  const [isTxnModalOpen, setIsTxnModalOpen] = useState(false);
  const [txnModalMode, setTxnModalMode] = useState<StockModalMode>('IN');
  const [selectedItemForModal, setSelectedItemForModal] = useState<InventoryItem | null>(null);
  const [selectedLocationForModal, setSelectedLocationForModal] = useState<InventoryLocation | null>(null);

  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [selectedTxnId, setSelectedTxnId] = useState<string | null>(null);

  const [isItemStockModalOpen, setIsItemStockModalOpen] = useState(false);
  const [selectedItemIdForStock, setSelectedItemIdForStock] = useState<string | null>(null);

  // Load stock data
  const loadStockData = async () => {
    try {
      setLoading(true);
      const [sumRes, balRes, movRes, txnRes] = await Promise.all([
        api.inventory.getStockSummary().catch(() => null),
        api.inventory.getStockBalances({ limit: 100 }).catch(() => ({ data: [] })),
        api.inventory.getStockLedger({ limit: 50 }).catch(() => ({ data: [] })),
        api.inventory.getStockTransactions({ limit: 50 }).catch(() => ({ data: [] }))
      ]);

      if (sumRes) setSummary((sumRes as any)?.data ?? sumRes);
      if (balRes?.data) setBalances(balRes.data);
      if (movRes?.data) setMovements(movRes.data);
      if (txnRes?.data) setTransactions(txnRes.data);
    } catch (err: any) {
      showNotification(err.message || 'Failed to load stock records', true);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadStockData();
  }, []);

  const openTxnModal = (
    mode: StockModalMode,
    item?: InventoryItem | null,
    locationId?: string
  ) => {
    setTxnModalMode(mode);
    setSelectedItemForModal(item || null);
    if (locationId) {
      const loc = locations.find(l => l.id === locationId);
      setSelectedLocationForModal(loc || null);
    } else {
      setSelectedLocationForModal(null);
    }
    setIsTxnModalOpen(true);
  };

  const handleTxnSuccess = (msg: string) => {
    showNotification(msg);
    loadStockData();
    onRefreshParent();
  };

  // Filtered Balances
  const filteredBalances = balances.filter(b => {
    if (balanceCategory !== 'ALL') {
      const itm = safeItems.find(i => i.id === b.itemId);
      if (itm?.categoryId !== balanceCategory) return false;
    }
    if (balanceLocation !== 'ALL' && b.locationId !== balanceLocation) return false;
    if (balanceStatus !== 'ALL' && b.stockStatus !== balanceStatus) return false;

    if (balanceSearch.trim()) {
      const q = balanceSearch.trim().toLowerCase();
      const match =
        b.itemName.toLowerCase().includes(q) ||
        b.itemCode.toLowerCase().includes(q) ||
        b.locationName.toLowerCase().includes(q);
      if (!match) return false;
    }
    return true;
  });

  // Filtered Ledger
  const filteredMovements = movements.filter(m => {
    if (ledgerLocation !== 'ALL' && m.locationId !== ledgerLocation) return false;
    if (ledgerType !== 'ALL' && m.movementType !== ledgerType) return false;
    if (ledgerStartDate && m.transactionDate < ledgerStartDate) return false;
    if (ledgerEndDate && m.transactionDate > ledgerEndDate) return false;

    if (ledgerSearch.trim()) {
      const q = ledgerSearch.trim().toLowerCase();
      const match =
        m.itemName.toLowerCase().includes(q) ||
        m.itemCode.toLowerCase().includes(q) ||
        m.locationName.toLowerCase().includes(q) ||
        (m.referenceNumber && m.referenceNumber.toLowerCase().includes(q)) ||
        m.createdByName.toLowerCase().includes(q);
      if (!match) return false;
    }
    return true;
  });

  // Filtered Transactions
  const filteredTransactions = transactions.filter(t => {
    if (txnType !== 'ALL' && t.transactionType !== txnType) return false;
    if (txnLocation !== 'ALL') {
      if (t.sourceLocationId !== txnLocation && t.destinationLocationId !== txnLocation) {
        return false;
      }
    }
    if (txnSearch.trim()) {
      const q = txnSearch.trim().toLowerCase();
      const match =
        t.transactionNumber.toLowerCase().includes(q) ||
        (t.referenceNumber && t.referenceNumber.toLowerCase().includes(q)) ||
        (t.supplierName && t.supplierName.toLowerCase().includes(q)) ||
        (t.issuedToName && t.issuedToName.toLowerCase().includes(q)) ||
        t.createdByName.toLowerCase().includes(q);
      if (!match) return false;
    }
    return true;
  });

  // Export Balances to CSV
  const exportBalancesCSV = () => {
    const headers = ['Item Code', 'Item Name', 'Store Location', 'Quantity', 'Unit', 'Status', 'Min Stock', 'Reorder Level'];
    const rows = filteredBalances.map(b => [
      `"${b.itemCode}"`,
      `"${b.itemName.replace(/"/g, '""')}"`,
      `"${b.locationName.replace(/"/g, '""')}"`,
      b.quantity,
      `"${b.unitShortCode}"`,
      b.stockStatus,
      b.minStockLevel,
      b.reorderLevel
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `stock_balances_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getStatusBadge = (status: StockStatus) => {
    switch (status) {
      case 'IN_STOCK':
        return (
          <span className="inline-flex items-center px-2 py-0.5 text-xs font-semibold rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            <CheckCircle className="w-3 h-3 mr-1" />
            In Stock
          </span>
        );
      case 'LOW_STOCK':
        return (
          <span className="inline-flex items-center px-2 py-0.5 text-xs font-semibold rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20">
            <AlertTriangle className="w-3 h-3 mr-1" />
            Low Stock
          </span>
        );
      case 'REORDER_REQUIRED':
        return (
          <span className="inline-flex items-center px-2 py-0.5 text-xs font-semibold rounded-full bg-orange-500/10 text-orange-400 border border-orange-500/20">
            <TrendingDown className="w-3 h-3 mr-1" />
            Reorder Alert
          </span>
        );
      case 'OUT_OF_STOCK':
        return (
          <span className="inline-flex items-center px-2 py-0.5 text-xs font-semibold rounded-full bg-rose-500/10 text-rose-400 border border-rose-500/20">
            <XCircle className="w-3 h-3 mr-1" />
            Out of Stock
          </span>
        );
    }
  };

  const getMovementBadge = (mType: StockMovementType) => {
    if (mType.includes('IN') || mType === 'ADJUSTMENT_INCREASE' || mType === 'OPENING_STOCK' || mType === 'RETURN') {
      return (
        <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 gap-1">
          <ArrowDownLeft className="w-3 h-3" />
          {mType}
        </span>
      );
    }
    return (
      <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold bg-rose-500/10 text-rose-400 border border-rose-500/20 gap-1">
        <ArrowUpRight className="w-3 h-3" />
        {mType}
      </span>
    );
  };

  return (
    <div className="space-y-6">
      {/* Top Overview KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3.5">
        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Total Stock</span>
            <Package className="w-4 h-4 text-indigo-400" />
          </div>
          <p className="text-2xl font-bold font-mono text-white">
            {summary?.totalStockedQuantity || 0}
          </p>
          <span className="text-[11px] text-slate-400">Total units across all stores</span>
        </div>

        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Stock Valuation</span>
            <Building className="w-4 h-4 text-emerald-400" />
          </div>
          <p className="text-2xl font-bold font-mono text-emerald-400">
            ${(summary?.totalStockValuation || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </p>
          <span className="text-[11px] text-slate-400">Inventory book value</span>
        </div>

        <div
          onClick={() => {
            setSubTab('balances');
            setBalanceStatus(balanceStatus === 'IN_STOCK' ? 'ALL' : 'IN_STOCK');
          }}
          className={`p-4 rounded-xl border cursor-pointer transition-all ${
            balanceStatus === 'IN_STOCK'
              ? 'bg-emerald-500/10 border-emerald-500/30'
              : 'bg-slate-900 border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[11px] font-semibold uppercase tracking-wider">In Stock</span>
            <CheckCircle className="w-4 h-4 text-emerald-400" />
          </div>
          <p className="text-2xl font-bold font-mono text-emerald-400">
            {summary?.inStockCount || 0}
          </p>
          <span className="text-[11px] text-slate-400">Healthy stock levels</span>
        </div>

        <div
          onClick={() => {
            setSubTab('balances');
            setBalanceStatus(balanceStatus === 'LOW_STOCK' ? 'ALL' : 'LOW_STOCK');
          }}
          className={`p-4 rounded-xl border cursor-pointer transition-all ${
            balanceStatus === 'LOW_STOCK'
              ? 'bg-amber-500/10 border-amber-500/30'
              : 'bg-slate-900 border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Low Stock</span>
            <AlertTriangle className="w-4 h-4 text-amber-400" />
          </div>
          <p className="text-2xl font-bold font-mono text-amber-400">
            {summary?.lowStockCount || 0}
          </p>
          <span className="text-[11px] text-slate-400">Below minimum threshold</span>
        </div>

        <div
          onClick={() => {
            setSubTab('balances');
            setBalanceStatus(balanceStatus === 'OUT_OF_STOCK' ? 'ALL' : 'OUT_OF_STOCK');
          }}
          className={`p-4 rounded-xl border cursor-pointer transition-all ${
            balanceStatus === 'OUT_OF_STOCK'
              ? 'bg-rose-500/10 border-rose-500/30'
              : 'bg-slate-900 border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[11px] font-semibold uppercase tracking-wider">Out of Stock</span>
            <XCircle className="w-4 h-4 text-rose-400" />
          </div>
          <p className="text-2xl font-bold font-mono text-rose-400">
            {summary?.outOfStockCount || 0}
          </p>
          <span className="text-[11px] text-slate-400">Immediate replenishment required</span>
        </div>
      </div>

      {/* Action Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-4 rounded-xl bg-slate-900 border border-slate-800">
        {/* Navigation Subtabs */}
        <div className="flex items-center space-x-1 p-1 bg-slate-950 rounded-xl border border-slate-800">
          <button
            onClick={() => setSubTab('balances')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 ${
              subTab === 'balances'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Package className="w-3.5 h-3.5" />
            Store Balances
            <span className="px-1.5 py-0.2 rounded-full text-[10px] font-mono bg-slate-800">
              {filteredBalances.length}
            </span>
          </button>

          <button
            onClick={() => setSubTab('ledger')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 ${
              subTab === 'ledger'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            Audit Ledger
            <span className="px-1.5 py-0.2 rounded-full text-[10px] font-mono bg-slate-800">
              {filteredMovements.length}
            </span>
          </button>

          <button
            onClick={() => setSubTab('transactions')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 ${
              subTab === 'transactions'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            Vouchers
            <span className="px-1.5 py-0.2 rounded-full text-[10px] font-mono bg-slate-800">
              {filteredTransactions.length}
            </span>
          </button>
        </div>

        {/* Quick Operations Button Group */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => openTxnModal('IN')}
            className="px-3 py-2 text-xs font-semibold rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white transition-all shadow-sm flex items-center gap-1.5"
          >
            <ArrowDownLeft className="w-3.5 h-3.5" />
            + Stock In
          </button>

          <button
            onClick={() => openTxnModal('OUT')}
            className="px-3 py-2 text-xs font-semibold rounded-xl bg-rose-600 hover:bg-rose-500 text-white transition-all shadow-sm flex items-center gap-1.5"
          >
            <ArrowUpRight className="w-3.5 h-3.5" />
            - Stock Out
          </button>

          <button
            onClick={() => openTxnModal('TRANSFER')}
            className="px-3 py-2 text-xs font-semibold rounded-xl bg-blue-600 hover:bg-blue-500 text-white transition-all shadow-sm flex items-center gap-1.5"
          >
            <ArrowLeftRight className="w-3.5 h-3.5" />
            ⇄ Transfer
          </button>

          <button
            onClick={() => openTxnModal('RETURN')}
            className="px-3 py-2 text-xs font-semibold rounded-xl bg-amber-600 hover:bg-amber-500 text-white transition-all shadow-sm flex items-center gap-1.5"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            ↶ Return
          </button>

          <button
            onClick={() => openTxnModal('ADJUST')}
            className="px-3 py-2 text-xs font-semibold rounded-xl bg-purple-600 hover:bg-purple-500 text-white transition-all shadow-sm flex items-center gap-1.5"
          >
            <Sliders className="w-3.5 h-3.5" />
            ⚖ Adjust
          </button>

          <button
            onClick={() => openTxnModal('OPENING')}
            className="px-3 py-2 text-xs font-semibold rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-all flex items-center gap-1.5"
            title="Initialize opening balance for item"
          >
            <Plus className="w-3.5 h-3.5" />
            Opening Stock
          </button>

          <button
            onClick={loadStockData}
            disabled={loading}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors disabled:opacity-50"
            title="Refresh Stock Data"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-indigo-400' : ''}`} />
          </button>
        </div>
      </div>

      {/* ========================================================= */}
      {/* SUBTAB 1: STORE BALANCES MATRIX */}
      {/* ========================================================= */}
      {subTab === 'balances' && (
        <div className="space-y-4">
          {/* Filters Bar */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 p-3.5 rounded-xl bg-slate-900 border border-slate-800">
            {/* Search */}
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Search item, SKU, store..."
                value={balanceSearch}
                onChange={e => setBalanceSearch(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl glass-input border border-slate-700 text-white placeholder-slate-500"
              />
            </div>

            {/* Category */}
            <div>
              <select
                value={balanceCategory}
                onChange={e => setBalanceCategory(e.target.value)}
                className="w-full px-3 py-1.5 text-xs rounded-xl glass-input border border-slate-700 text-white bg-slate-950"
              >
                <option value="ALL">All Categories</option>
                {categories.map(c => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
            </div>

            {/* Location */}
            <div>
              <select
                value={balanceLocation}
                onChange={e => setBalanceLocation(e.target.value)}
                className="w-full px-3 py-1.5 text-xs rounded-xl glass-input border border-slate-700 text-white bg-slate-950"
              >
                <option value="ALL">All Storage Locations</option>
                {locations.map(l => (
                  <option key={l.id} value={l.id}>{l.name} ({l.code})</option>
                ))}
              </select>
            </div>

            {/* Stock Status */}
            <div>
              <select
                value={balanceStatus}
                onChange={e => setBalanceStatus(e.target.value as any)}
                className="w-full px-3 py-1.5 text-xs rounded-xl glass-input border border-slate-700 text-white bg-slate-950"
              >
                <option value="ALL">All Stock Statuses</option>
                <option value="IN_STOCK">In Stock</option>
                <option value="LOW_STOCK">Low Stock</option>
                <option value="REORDER_REQUIRED">Reorder Alert</option>
                <option value="OUT_OF_STOCK">Out of Stock</option>
              </select>
            </div>

            {/* Export CSV */}
            <div>
              <button
                onClick={exportBalancesCSV}
                className="w-full py-1.5 px-3 text-xs font-semibold rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors flex items-center justify-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                Export CSV
              </button>
            </div>
          </div>

          {/* Balances Table */}
          <div className="rounded-xl border border-slate-800 overflow-hidden bg-slate-900">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-950/80 border-b border-slate-800 text-[11px] text-slate-400 uppercase font-semibold">
                  <tr>
                    <th className="py-3 px-4">Item & Code</th>
                    <th className="py-3 px-4">Storage Location</th>
                    <th className="py-3 px-4">Stock In-Hand</th>
                    <th className="py-3 px-4">Stock Status</th>
                    <th className="py-3 px-4">Min / Reorder</th>
                    <th className="py-3 px-4">Book Value</th>
                    <th className="py-3 px-4 text-right">Quick Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800 text-slate-300">
                  {filteredBalances.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="py-8 text-center text-slate-500">
                        No stock records matching the current filters.
                      </td>
                    </tr>
                  ) : (
                    filteredBalances.map(bal => {
                      const itemObj = safeItems.find(i => i.id === bal.itemId);
                      const unitVal = itemObj?.unitPrice || 0;
                      return (
                        <tr key={bal.id} className="hover:bg-slate-800/50 transition-colors">
                          <td className="py-3 px-4">
                            <div className="flex items-center space-x-2.5">
                              <div className="p-2 rounded-lg bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                                <Package className="w-4 h-4" />
                              </div>
                              <div>
                                <button
                                  onClick={() => {
                                    setSelectedItemIdForStock(bal.itemId);
                                    setIsItemStockModalOpen(true);
                                  }}
                                  className="font-semibold text-white hover:text-indigo-400 transition-colors text-left"
                                >
                                  {bal.itemName}
                                </button>
                                <span className="font-mono text-[10px] text-indigo-400 block">{bal.itemCode}</span>
                              </div>
                            </div>
                          </td>

                          <td className="py-3 px-4">
                            <span className="font-medium text-white flex items-center gap-1.5">
                              <Building className="w-3.5 h-3.5 text-slate-400" />
                              {bal.locationName}
                            </span>
                            <span className="text-[10px] font-mono text-slate-500 block">{bal.locationCode}</span>
                          </td>

                          <td className="py-3 px-4">
                            <span className="text-sm font-bold font-mono text-white">
                              {bal.quantity}
                            </span>
                            <span className="text-xs text-slate-400 ml-1">{bal.unitShortCode}</span>
                          </td>

                          <td className="py-3 px-4">
                            {getStatusBadge(bal.stockStatus)}
                          </td>

                          <td className="py-3 px-4 font-mono text-xs">
                            <span className="text-slate-400">Min: {bal.minStockLevel}</span>
                            <span className="text-amber-400 block">Reorder: {bal.reorderLevel}</span>
                          </td>

                          <td className="py-3 px-4 font-mono text-xs text-slate-300">
                            ${(bal.quantity * unitVal).toFixed(2)}
                          </td>

                          <td className="py-3 px-4 text-right">
                            <div className="flex items-center justify-end space-x-1">
                              <button
                                onClick={() => openTxnModal('IN', itemObj, bal.locationId)}
                                className="px-2 py-1 text-[11px] font-semibold rounded bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20"
                                title="Receive stock"
                              >
                                + In
                              </button>
                              <button
                                onClick={() => openTxnModal('OUT', itemObj, bal.locationId)}
                                className="px-2 py-1 text-[11px] font-semibold rounded bg-rose-500/10 text-rose-400 hover:bg-rose-500/20"
                                title="Issue stock"
                              >
                                - Out
                              </button>
                              <button
                                onClick={() => openTxnModal('TRANSFER', itemObj, bal.locationId)}
                                className="px-2 py-1 text-[11px] font-semibold rounded bg-blue-500/10 text-blue-400 hover:bg-blue-500/20"
                                title="Transfer to other store"
                              >
                                ⇄
                              </button>
                              <button
                                onClick={() => openTxnModal('ADJUST', itemObj, bal.locationId)}
                                className="px-2 py-1 text-[11px] font-semibold rounded bg-purple-500/10 text-purple-400 hover:bg-purple-500/20"
                                title="Physical stock count reconciliation"
                              >
                                ⚖
                              </button>
                              <button
                                onClick={() => {
                                  setSelectedItemIdForStock(bal.itemId);
                                  setIsItemStockModalOpen(true);
                                }}
                                className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800"
                                title="View multi-store stock details"
                              >
                                <Eye className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* SUBTAB 2: AUDIT LEDGER */}
      {/* ========================================================= */}
      {subTab === 'ledger' && (
        <div className="space-y-4">
          {/* Filters Bar */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 p-3.5 rounded-xl bg-slate-900 border border-slate-800">
            {/* Search */}
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Search ledger by item, ref, user..."
                value={ledgerSearch}
                onChange={e => setLedgerSearch(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl glass-input border border-slate-700 text-white placeholder-slate-500"
              />
            </div>

            {/* Movement Type */}
            <div>
              <select
                value={ledgerType}
                onChange={e => setLedgerType(e.target.value as any)}
                className="w-full px-3 py-1.5 text-xs rounded-xl glass-input border border-slate-700 text-white bg-slate-950"
              >
                <option value="ALL">All Movement Types</option>
                <option value="OPENING">Opening Stock</option>
                <option value="PURCHASE_IN">Purchase Receipt</option>
                <option value="ISSUE_OUT">Issue Outward</option>
                <option value="TRANSFER_IN">Transfer In</option>
                <option value="TRANSFER_OUT">Transfer Out</option>
                <option value="RETURN_IN">Return Inward</option>
                <option value="ADJUST_ADD">Adjustment (+)</option>
                <option value="ADJUST_SUB">Adjustment (-)</option>
              </select>
            </div>

            {/* Location */}
            <div>
              <select
                value={ledgerLocation}
                onChange={e => setLedgerLocation(e.target.value)}
                className="w-full px-3 py-1.5 text-xs rounded-xl glass-input border border-slate-700 text-white bg-slate-950"
              >
                <option value="ALL">All Store Locations</option>
                {locations.map(l => (
                  <option key={l.id} value={l.id}>{l.name} ({l.code})</option>
                ))}
              </select>
            </div>

            {/* Date Range Start */}
            <div>
              <input
                type="date"
                value={ledgerStartDate}
                onChange={e => setLedgerStartDate(e.target.value)}
                className="w-full px-3 py-1.5 text-xs rounded-xl glass-input border border-slate-700 text-white"
                placeholder="Start Date"
              />
            </div>

            {/* Date Range End */}
            <div>
              <input
                type="date"
                value={ledgerEndDate}
                onChange={e => setLedgerEndDate(e.target.value)}
                className="w-full px-3 py-1.5 text-xs rounded-xl glass-input border border-slate-700 text-white"
                placeholder="End Date"
              />
            </div>
          </div>

          {/* Ledger Table */}
          <div className="rounded-xl border border-slate-800 overflow-hidden bg-slate-900">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-950/80 border-b border-slate-800 text-[11px] text-slate-400 uppercase font-semibold">
                  <tr>
                    <th className="py-3 px-4">Date</th>
                    <th className="py-3 px-4">Movement Type</th>
                    <th className="py-3 px-4">Item & Code</th>
                    <th className="py-3 px-4">Store Location</th>
                    <th className="py-3 px-4">Qty</th>
                    <th className="py-3 px-4">Before / After</th>
                    <th className="py-3 px-4">Reference / Audit</th>
                    <th className="py-3 px-4 text-right">User</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800 text-slate-300">
                  {filteredMovements.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="py-8 text-center text-slate-500">
                        No ledger movements recorded matching the filters.
                      </td>
                    </tr>
                  ) : (
                    filteredMovements.map(m => (
                      <tr key={m.id} className="hover:bg-slate-800/50 transition-colors">
                        <td className="py-3 px-4 font-mono text-slate-400 whitespace-nowrap">
                          {m.transactionDate}
                        </td>

                        <td className="py-3 px-4">
                          {getMovementBadge(m.movementType)}
                        </td>

                        <td className="py-3 px-4">
                          <span className="font-semibold text-white block">{m.itemName}</span>
                          <span className="font-mono text-[10px] text-indigo-400">{m.itemCode}</span>
                        </td>

                        <td className="py-3 px-4">
                          <span className="font-medium text-white">{m.locationName}</span>
                        </td>

                        <td className="py-3 px-4 font-mono font-bold text-white whitespace-nowrap">
                          {m.quantity} {m.unitShortCode}
                        </td>

                        <td className="py-3 px-4 font-mono text-xs whitespace-nowrap">
                          <span className="text-slate-500">{m.balanceBefore}</span>
                          <span className="text-slate-400 mx-1">→</span>
                          <span className="text-indigo-400 font-semibold">{m.balanceAfter}</span>
                        </td>

                        <td className="py-3 px-4 text-xs">
                          {m.referenceNumber ? (
                            <span className="font-mono text-indigo-300 block">{m.referenceNumber}</span>
                          ) : (
                            <span className="text-slate-500 block">N/A</span>
                          )}
                          {m.remarks && <span className="text-[11px] text-slate-400 italic block">{m.remarks}</span>}
                        </td>

                        <td className="py-3 px-4 text-right text-slate-400 text-xs whitespace-nowrap">
                          {m.createdByName}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* SUBTAB 3: TRANSACTION VOUCHERS */}
      {/* ========================================================= */}
      {subTab === 'transactions' && (
        <div className="space-y-4">
          {/* Filters Bar */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-3.5 rounded-xl bg-slate-900 border border-slate-800">
            {/* Search */}
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Search voucher #, vendor, user..."
                value={txnSearch}
                onChange={e => setTxnSearch(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl glass-input border border-slate-700 text-white placeholder-slate-500"
              />
            </div>

            {/* Transaction Type */}
            <div>
              <select
                value={txnType}
                onChange={e => setTxnType(e.target.value as any)}
                className="w-full px-3 py-1.5 text-xs rounded-xl glass-input border border-slate-700 text-white bg-slate-950"
              >
                <option value="ALL">All Transaction Types</option>
                <option value="OPENING_STOCK">Opening Stock</option>
                <option value="PURCHASE_RECEIPT">Purchase Receipt</option>
                <option value="CONSUMPTION_ISSUE">Consumption Issue</option>
                <option value="STORE_TRANSFER">Store Transfer</option>
                <option value="RETURN_INWARD">Return Inward</option>
                <option value="PHYSICAL_ADJUSTMENT">Physical Adjustment</option>
              </select>
            </div>

            {/* Store Location */}
            <div>
              <select
                value={txnLocation}
                onChange={e => setTxnLocation(e.target.value)}
                className="w-full px-3 py-1.5 text-xs rounded-xl glass-input border border-slate-700 text-white bg-slate-950"
              >
                <option value="ALL">All Store Locations</option>
                {locations.map(l => (
                  <option key={l.id} value={l.id}>{l.name} ({l.code})</option>
                ))}
              </select>
            </div>
          </div>

          {/* Vouchers Table */}
          <div className="rounded-xl border border-slate-800 overflow-hidden bg-slate-900">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-950/80 border-b border-slate-800 text-[11px] text-slate-400 uppercase font-semibold">
                  <tr>
                    <th className="py-3 px-4">Voucher Number</th>
                    <th className="py-3 px-4">Date</th>
                    <th className="py-3 px-4">Type</th>
                    <th className="py-3 px-4">Source / Dest Store</th>
                    <th className="py-3 px-4">Party / Department</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800 text-slate-300">
                  {filteredTransactions.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="py-8 text-center text-slate-500">
                        No transactions recorded matching the filters.
                      </td>
                    </tr>
                  ) : (
                    filteredTransactions.map(txn => (
                      <tr key={txn.id} className="hover:bg-slate-800/50 transition-colors">
                        <td className="py-3 px-4 font-mono font-semibold text-indigo-400">
                          {txn.transactionNumber}
                        </td>

                        <td className="py-3 px-4 font-mono text-slate-400">
                          {txn.transactionDate}
                        </td>

                        <td className="py-3 px-4">
                          <span className="font-semibold text-slate-200">{txn.transactionType}</span>
                        </td>

                        <td className="py-3 px-4">
                          {txn.sourceLocationName && txn.destinationLocationName ? (
                            <span>{txn.sourceLocationName} → {txn.destinationLocationName}</span>
                          ) : (
                            <span>{txn.sourceLocationName || txn.destinationLocationName || '—'}</span>
                          )}
                        </td>

                        <td className="py-3 px-4 text-slate-300">
                          {txn.supplierName || txn.issuedToName || '—'}
                        </td>

                        <td className="py-3 px-4">
                          <span className="px-2 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                            {txn.status}
                          </span>
                        </td>

                        <td className="py-3 px-4 text-right">
                          <button
                            onClick={() => {
                              setSelectedTxnId(txn.id);
                              setIsDetailModalOpen(true);
                            }}
                            className="px-2.5 py-1 text-xs font-semibold rounded-lg bg-indigo-500/10 text-indigo-400 hover:bg-indigo-500/20 transition-colors inline-flex items-center gap-1"
                          >
                            <Eye className="w-3.5 h-3.5" />
                            View Voucher
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Transaction Entry Modal (In/Out/Transfer/Return/Adjust/Opening) */}
      <StockTransactionModal
        isOpen={isTxnModalOpen}
        onClose={() => setIsTxnModalOpen(false)}
        mode={txnModalMode}
        items={items}
        locations={locations}
        suppliers={suppliers}
        preselectedItem={selectedItemForModal}
        preselectedLocation={selectedLocationForModal}
        onSuccess={handleTxnSuccess}
      />

      {/* Transaction Detail Voucher Modal */}
      <StockTransactionDetailModal
        isOpen={isDetailModalOpen}
        onClose={() => {
          setIsDetailModalOpen(false);
          setSelectedTxnId(null);
        }}
        transactionId={selectedTxnId}
      />

      {/* Item Multi-Store Stock Modal */}
      <ItemStockDetailModal
        isOpen={isItemStockModalOpen}
        onClose={() => {
          setIsItemStockModalOpen(false);
          setSelectedItemIdForStock(null);
        }}
        itemId={selectedItemIdForStock}
        onQuickAction={(mode, itm, locId) => openTxnModal(mode, itm, locId)}
      />
    </div>
  );
};
