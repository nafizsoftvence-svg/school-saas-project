import React, { useState } from 'react';
import {
  Truck,
  Search,
  Plus,
  Edit2,
  Trash2,
  Phone,
  Mail,
  MapPin,
  FileText,
  RefreshCw,
  Building2,
  ExternalLink
} from 'lucide-react';
import { Supplier } from '../../types';
import { SupplierHistoryModal } from './SupplierHistoryModal';

interface SuppliersTabProps {
  suppliers: Supplier[];
  loading: boolean;
  onRefresh: () => void;
  onOpenNewSupplierModal: () => void;
  onEditSupplier: (supplier: Supplier) => void;
  onDeleteSupplier: (id: string) => void;
}

export const SuppliersTab: React.FC<SuppliersTabProps> = ({
  suppliers,
  loading,
  onRefresh,
  onOpenNewSupplierModal,
  onEditSupplier,
  onDeleteSupplier
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('ALL');
  const [historySupplier, setHistorySupplier] = useState<Supplier | null>(null);

  const filteredSuppliers = suppliers.filter(sup => {
    if (selectedStatus !== 'ALL' && sup.status !== selectedStatus) return false;

    if (searchTerm.trim()) {
      const q = searchTerm.trim().toLowerCase();
      const match =
        sup.name.toLowerCase().includes(q) ||
        sup.supplierCode.toLowerCase().includes(q) ||
        sup.contactPerson.toLowerCase().includes(q) ||
        sup.email.toLowerCase().includes(q) ||
        sup.phone.toLowerCase().includes(q) ||
        (sup.city && sup.city.toLowerCase().includes(q));
      if (!match) return false;
    }
    return true;
  });

  return (
    <div className="space-y-4">
      {/* Header and Controls */}
      <div className="p-4 rounded-xl glass-panel border border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-semibold text-white flex items-center gap-2">
              <Truck className="w-5 h-5 text-teal-400" />
              Institutional Vendor & Supplier Registry
            </h3>
            <p className="text-xs text-slate-400">
              Master supplier contacts, contracts, tax IDs, and procurement service relationships
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={onRefresh}
              disabled={loading}
              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors disabled:opacity-50"
              title="Refresh suppliers"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-teal-400' : ''}`} />
            </button>
            <button
              onClick={onOpenNewSupplierModal}
              className="px-3.5 py-2 text-xs font-semibold rounded-lg bg-teal-600 hover:bg-teal-500 text-white transition-colors flex items-center gap-1.5 shadow-sm shadow-teal-950"
            >
              <Plus className="w-4 h-4" />
              Add New Supplier
            </button>
          </div>
        </div>

        {/* Filter bar */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 border-t border-slate-800/60">
          <div className="relative sm:col-span-2">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search vendor name, code, contact person, email, city..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-4 py-2 text-xs rounded-lg glass-input border border-slate-700/80 focus:outline-none focus:border-teal-500 text-slate-100 placeholder-slate-500"
            />
          </div>

          <div>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700/80 focus:outline-none focus:border-teal-500 text-slate-200"
            >
              <option value="ALL">All Statuses</option>
              <option value="ACTIVE">Active</option>
              <option value="INACTIVE">Inactive</option>
            </select>
          </div>
        </div>
      </div>

      {/* Supplier Grid Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredSuppliers.length === 0 ? (
          <div className="col-span-full py-12 text-center text-slate-400 p-8 glass-panel rounded-xl border border-slate-800">
            <Truck className="w-10 h-10 text-slate-600 mx-auto mb-2" />
            <p className="text-sm font-medium text-slate-300">No suppliers registered</p>
            <p className="text-xs text-slate-500 mt-1">Add a vendor to link assets and future purchase workflows.</p>
          </div>
        ) : (
          filteredSuppliers.map((supplier) => (
            <div
              key={supplier.id}
              className="p-5 rounded-xl glass-card border border-slate-800 hover:border-teal-500/30 transition-all space-y-4 flex flex-col justify-between"
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between">
                  <div>
                    <span className="font-mono text-xs px-2 py-0.5 rounded bg-teal-500/10 text-teal-400 border border-teal-500/20 font-medium">
                      {supplier.supplierCode}
                    </span>
                    <h4 className="text-sm font-semibold text-white mt-1.5">{supplier.name}</h4>
                    <p className="text-xs text-slate-400">Attn: {supplier.contactPerson}</p>
                  </div>
                  <span
                    className={`px-2 py-0.5 text-xs font-semibold rounded-full border ${
                      supplier.status === 'ACTIVE'
                        ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                        : 'bg-slate-500/10 text-slate-400 border-slate-500/20'
                    }`}
                  >
                    {supplier.status}
                  </span>
                </div>

                <div className="space-y-1.5 text-xs text-slate-300 border-t border-slate-800/80 pt-3">
                  <div className="flex items-center space-x-2 text-slate-300">
                    <Phone className="w-3.5 h-3.5 text-slate-500 flex-shrink-0" />
                    <span>{supplier.phone}</span>
                  </div>
                  <div className="flex items-center space-x-2 text-slate-300">
                    <Mail className="w-3.5 h-3.5 text-slate-500 flex-shrink-0" />
                    <span className="truncate">{supplier.email}</span>
                  </div>
                  {supplier.address && (
                    <div className="flex items-center space-x-2 text-slate-300">
                      <MapPin className="w-3.5 h-3.5 text-slate-500 flex-shrink-0" />
                      <span className="truncate">{supplier.address}{supplier.city ? `, ${supplier.city}` : ''}</span>
                    </div>
                  )}
                  {supplier.taxNumber && (
                    <div className="flex items-center space-x-2 text-slate-400">
                      <FileText className="w-3.5 h-3.5 text-slate-500 flex-shrink-0" />
                      <span className="font-mono text-[11px]">Tax/GST: {supplier.taxNumber}</span>
                    </div>
                  )}
                </div>

                {supplier.notes && (
                  <p className="text-xs text-slate-400 bg-slate-900/50 p-2.5 rounded-lg border border-slate-800/80">
                    {supplier.notes}
                  </p>
                )}
              </div>

              <div className="flex items-center justify-end space-x-2 border-t border-slate-800/80 pt-3">
                <button
                  onClick={() => setHistorySupplier(supplier)}
                  className="px-2.5 py-1 text-xs rounded-lg bg-teal-500/10 hover:bg-teal-500/20 text-teal-300 border border-teal-500/30 transition-colors flex items-center gap-1"
                  title="View Procurement Orders & Fulfillment Metrics"
                >
                  <ExternalLink className="w-3 h-3" />
                  Orders
                </button>
                <button
                  onClick={() => onEditSupplier(supplier)}
                  className="px-2.5 py-1 text-xs rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors flex items-center gap-1"
                >
                  <Edit2 className="w-3 h-3" />
                  Edit
                </button>
                <button
                  onClick={() => {
                    if (window.confirm(`Are you sure you want to delete supplier '${supplier.name}'?`)) {
                      onDeleteSupplier(supplier.id);
                    }
                  }}
                  className="px-2.5 py-1 text-xs rounded-lg hover:bg-rose-500/10 text-slate-400 hover:text-rose-400 transition-colors flex items-center gap-1"
                >
                  <Trash2 className="w-3 h-3" />
                  Delete
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      <SupplierHistoryModal
        isOpen={!!historySupplier}
        supplier={historySupplier}
        onClose={() => setHistorySupplier(null)}
      />
    </div>
  );
};
