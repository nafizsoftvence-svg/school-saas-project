import React, { useState, useEffect } from 'react';
import { X, Package, Check, AlertCircle } from 'lucide-react';
import {
  InventoryItem,
  InventoryCategory,
  InventoryUnit,
  InventoryLocation,
  ItemType,
  InventoryItemStatus,
  CreateInventoryItemPayload,
  UpdateInventoryItemPayload
} from '../../types';

interface ItemModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (payload: CreateInventoryItemPayload | UpdateInventoryItemPayload) => Promise<void>;
  item?: InventoryItem | null;
  categories: InventoryCategory[];
  units: InventoryUnit[];
  locations: InventoryLocation[];
}

export const ItemModal: React.FC<ItemModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  item,
  categories,
  units,
  locations
}) => {
  const isEditing = !!item;

  const [itemCode, setItemCode] = useState('');
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [categoryId, setCategoryId] = useState('');
  const [unitId, setUnitId] = useState('');
  const [itemType, setItemType] = useState<ItemType>('CONSUMABLE');
  const [brand, setBrand] = useState('');
  const [model, setModel] = useState('');
  const [barcode, setBarcode] = useState('');
  const [locationId, setLocationId] = useState('');
  const [minStockLevel, setMinStockLevel] = useState<number>(0);
  const [reorderLevel, setReorderLevel] = useState<number>(0);
  const [maxStockLevel, setMaxStockLevel] = useState<number | undefined>(undefined);
  const [unitPrice, setUnitPrice] = useState<number>(0);
  const [status, setStatus] = useState<InventoryItemStatus>('ACTIVE');
  const [isStockable, setIsStockable] = useState(true);

  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (item) {
      setItemCode(item.itemCode || '');
      setName(item.name || '');
      setDescription(item.description || '');
      setCategoryId(item.categoryId || '');
      setUnitId(item.unitId || '');
      setItemType(item.itemType || 'CONSUMABLE');
      setBrand(item.brand || '');
      setModel(item.model || '');
      setBarcode(item.barcode || '');
      setLocationId(item.locationId || '');
      setMinStockLevel(item.minStockLevel || 0);
      setReorderLevel(item.reorderLevel || 0);
      setMaxStockLevel(item.maxStockLevel);
      setUnitPrice(item.unitPrice || 0);
      setStatus(item.status || 'ACTIVE');
      setIsStockable(item.isStockable !== false);
    } else {
      setItemCode('');
      setName('');
      setDescription('');
      setCategoryId(categories[0]?.id || '');
      setUnitId(units[0]?.id || '');
      setItemType('CONSUMABLE');
      setBrand('');
      setModel('');
      setBarcode('');
      setLocationId(locations[0]?.id || '');
      setMinStockLevel(5);
      setReorderLevel(10);
      setMaxStockLevel(undefined);
      setUnitPrice(0);
      setStatus('ACTIVE');
      setIsStockable(true);
    }
    setError(null);
  }, [item, categories, units, locations, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Item name is required');
      return;
    }
    if (!categoryId) {
      setError('Category is required');
      return;
    }
    if (!unitId) {
      setError('Unit of measurement is required');
      return;
    }

    try {
      setSubmitting(true);
      setError(null);

      const payload: any = {
        name: name.trim(),
        categoryId,
        unitId,
        itemType,
        brand: brand.trim() || undefined,
        model: model.trim() || undefined,
        barcode: barcode.trim() || undefined,
        description: description.trim() || undefined,
        locationId: locationId || undefined,
        minStockLevel: Number(minStockLevel) || 0,
        reorderLevel: Number(reorderLevel) || 0,
        maxStockLevel: maxStockLevel !== undefined ? Number(maxStockLevel) : undefined,
        unitPrice: Number(unitPrice) || 0,
        status,
        isStockable
      };

      if (itemCode.trim()) {
        payload.itemCode = itemCode.trim().toUpperCase();
      }

      await onSubmit(payload);
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to save inventory item');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm overflow-y-auto">
      <div className="w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800 bg-slate-900/60">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
              <Package className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-white">
                {isEditing ? `Edit Item: ${item.name}` : 'Add New Inventory Item'}
              </h3>
              <p className="text-xs text-slate-400">
                {isEditing ? `SKU: ${item.itemCode}` : 'Auto-generates institutional SKU if left blank'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
          {error && (
            <div className="p-3 rounded-lg bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Item Code / SKU */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Item Code / SKU <span className="text-slate-500 font-normal">(optional)</span>
              </label>
              <input
                type="text"
                placeholder="e.g. SKU-2026-0001 (auto if empty)"
                value={itemCode}
                onChange={(e) => setItemCode(e.target.value.toUpperCase())}
                className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700/80 focus:outline-none focus:border-indigo-500 text-slate-100 font-mono"
              />
            </div>

            {/* Name */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Item Name <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                required
                placeholder="e.g. A4 Whiteboard Markers (Pack of 12)"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700/80 focus:outline-none focus:border-indigo-500 text-slate-100"
              />
            </div>

            {/* Category */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Category <span className="text-rose-400">*</span>
              </label>
              <select
                required
                value={categoryId}
                onChange={(e) => setCategoryId(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700/80 focus:outline-none focus:border-indigo-500 text-slate-200"
              >
                <option value="">Select Category...</option>
                {categories.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Unit */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Unit of Measure (UOM) <span className="text-rose-400">*</span>
              </label>
              <select
                required
                value={unitId}
                onChange={(e) => setUnitId(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700/80 focus:outline-none focus:border-indigo-500 text-slate-200"
              >
                <option value="">Select Unit...</option>
                {units.map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.name} ({u.shortCode})
                  </option>
                ))}
              </select>
            </div>

            {/* Item Type */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Item Classification Type
              </label>
              <select
                value={itemType}
                onChange={(e) => setItemType(e.target.value as ItemType)}
                className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700/80 focus:outline-none focus:border-indigo-500 text-slate-200"
              >
                <option value="CONSUMABLE">Consumable Goods</option>
                <option value="NON_CONSUMABLE">Non-Consumable Goods</option>
                <option value="STOCK_ITEM">Stock / Inventory Item</option>
                <option value="SERVICE">Service</option>
              </select>
            </div>

            {/* Location */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Default Store Location
              </label>
              <select
                value={locationId}
                onChange={(e) => setLocationId(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700/80 focus:outline-none focus:border-indigo-500 text-slate-200"
              >
                <option value="">Unassigned Location</option>
                {locations.map((l) => (
                  <option key={l.id} value={l.id}>
                    {l.name} ({l.code})
                  </option>
                ))}
              </select>
            </div>

            {/* Brand */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Brand / Manufacturer
              </label>
              <input
                type="text"
                placeholder="e.g. Staedtler, Dell, Oxford"
                value={brand}
                onChange={(e) => setBrand(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700/80 focus:outline-none focus:border-indigo-500 text-slate-100"
              />
            </div>

            {/* Model */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Model / Specification
              </label>
              <input
                type="text"
                placeholder="e.g. Lumocolor 351, 80 GSM"
                value={model}
                onChange={(e) => setModel(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700/80 focus:outline-none focus:border-indigo-500 text-slate-100"
              />
            </div>

            {/* Barcode */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Barcode / EAN
              </label>
              <input
                type="text"
                placeholder="e.g. 8901234567890"
                value={barcode}
                onChange={(e) => setBarcode(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700/80 focus:outline-none focus:border-indigo-500 text-slate-100 font-mono"
              />
            </div>

            {/* Unit Price */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Estimated Unit Price ($)
              </label>
              <input
                type="number"
                min="0"
                step="0.01"
                value={unitPrice}
                onChange={(e) => setUnitPrice(parseFloat(e.target.value) || 0)}
                className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700/80 focus:outline-none focus:border-indigo-500 text-slate-100 font-mono"
              />
            </div>

            {/* Min Stock Level */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Minimum Stock Level (Safety Buffer)
              </label>
              <input
                type="number"
                min="0"
                value={minStockLevel}
                onChange={(e) => setMinStockLevel(parseInt(e.target.value, 10) || 0)}
                className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700/80 focus:outline-none focus:border-indigo-500 text-slate-100 font-mono"
              />
            </div>

            {/* Reorder Level */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Reorder Threshold Level
              </label>
              <input
                type="number"
                min="0"
                value={reorderLevel}
                onChange={(e) => setReorderLevel(parseInt(e.target.value, 10) || 0)}
                className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700/80 focus:outline-none focus:border-indigo-500 text-slate-100 font-mono"
              />
            </div>
          </div>

          {/* Stock Tracking Toggle */}
          <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 flex items-start space-x-3">
            <input
              type="checkbox"
              id="isStockableCheckbox"
              checked={isStockable}
              onChange={(e) => setIsStockable(e.target.checked)}
              className="mt-0.5 rounded border-slate-700 bg-slate-900 text-indigo-600 focus:ring-indigo-500 w-4 h-4 cursor-pointer"
            />
            <label htmlFor="isStockableCheckbox" className="text-xs cursor-pointer select-none">
              <span className="font-semibold text-slate-200 block">Track Stock Levels (Stockable Item)</span>
              <span className="text-slate-400 text-[11px] block mt-0.5">
                Enable this to maintain physical quantities, record receipts/issues/transfers, and trigger low-stock alerts.
              </span>
            </label>
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Description / Notes
            </label>
            <textarea
              rows={2}
              placeholder="Provide technical specifications, intended department usage, or storage requirements..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700/80 focus:outline-none focus:border-indigo-500 text-slate-100"
            />
          </div>

          {/* Status */}
          {isEditing && (
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Lifecycle Status
              </label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as InventoryItemStatus)}
                className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700/80 focus:outline-none focus:border-indigo-500 text-slate-200"
              >
                <option value="ACTIVE">Active (In Current Use)</option>
                <option value="INACTIVE">Inactive (Temporarily Paused)</option>
                <option value="DISCONTINUED">Discontinued</option>
              </select>
            </div>
          )}

          {/* Buttons */}
          <div className="flex items-center justify-end space-x-3 pt-4 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="px-5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg transition-colors flex items-center gap-1.5 shadow-sm shadow-indigo-950 disabled:opacity-50"
            >
              <Check className="w-4 h-4" />
              {submitting ? 'Saving...' : isEditing ? 'Save Changes' : 'Create Item'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
