import React, { useState } from 'react';
import {
  X,
  ShieldCheck,
  CheckSquare,
  Square,
  Search,
  AlertCircle,
  Building,
  User,
  Calendar,
  Layers,
  Tag
} from 'lucide-react';
import {
  Asset,
  Department,
  InventoryLocation,
  StaffProfile,
  AssigneeType,
  AssetCondition,
  BulkAssetAllocationPayload
} from '../../types';
import { api } from '../../services/api';

interface BulkAssetAllocationModalProps {
  isOpen: boolean;
  onClose: () => void;
  availableAssets: Asset[];
  departments: Department[];
  locations: InventoryLocation[];
  staffMembers: StaffProfile[];
  onSuccess: (message: string) => void;
}

export const BulkAssetAllocationModal: React.FC<BulkAssetAllocationModalProps> = ({
  isOpen,
  onClose,
  availableAssets,
  departments,
  locations,
  staffMembers,
  onSuccess
}) => {
  const [selectedAssetIds, setSelectedAssetIds] = useState<string[]>([]);
  const [assetSearch, setAssetSearch] = useState('');

  const [assigneeType, setAssigneeType] = useState<AssigneeType>('STAFF');
  const [assigneeId, setAssigneeId] = useState('');
  const [assigneeName, setAssigneeName] = useState('');
  const [department, setDepartment] = useState(departments[0]?.name || '');
  const [locationId, setLocationId] = useState(locations[0]?.id || '');
  const [assignedDate, setAssignedDate] = useState(new Date().toISOString().split('T')[0]);
  const [expectedReturnDate, setExpectedReturnDate] = useState('');
  const [conditionAtHandover, setConditionAtHandover] = useState<AssetCondition>('GOOD');
  const [handoverNotes, setHandoverNotes] = useState('');

  // Accessories Checklist
  const [accessories, setAccessories] = useState<{ [key: string]: boolean }>({
    'Power Adapter / Charger': true,
    'Carry Bag / Sleeve': false,
    'Optical Mouse': false,
    'Security Cable Lock': false,
    'HDMI / Display Adapter': false
  });

  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  // Filter available assets (only status AVAILABLE or ACTIVE)
  const safeAvailableAssets = Array.isArray(availableAssets) ? availableAssets : [];
  const assignableAssets = safeAvailableAssets.filter(
    (a) => a.status === 'AVAILABLE' || a.status === 'ACTIVE'
  );

  const filteredAssets = assignableAssets.filter((a) => {
    if (!assetSearch.trim()) return true;
    const q = assetSearch.trim().toLowerCase();
    return (
      a.name.toLowerCase().includes(q) ||
      a.assetTag.toLowerCase().includes(q) ||
      (a.categoryName && a.categoryName.toLowerCase().includes(q)) ||
      (a.locationName && a.locationName.toLowerCase().includes(q))
    );
  });

  const handleToggleAsset = (id: string) => {
    if (selectedAssetIds.includes(id)) {
      setSelectedAssetIds(selectedAssetIds.filter((item) => item !== id));
    } else {
      setSelectedAssetIds([...selectedAssetIds, id]);
    }
  };

  const handleSelectAll = () => {
    if (selectedAssetIds.length === filteredAssets.length) {
      setSelectedAssetIds([]);
    } else {
      setSelectedAssetIds(filteredAssets.map((a) => a.id));
    }
  };

  const handleToggleAccessory = (acc: string) => {
    setAccessories({
      ...accessories,
      [acc]: !accessories[acc]
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (selectedAssetIds.length === 0) {
      setError('Please select at least one asset to allocate.');
      return;
    }

    if (!assigneeName.trim()) {
      setError('Assignee / Custodian name is required.');
      return;
    }

    try {
      setSubmitting(true);

      const targetLoc = locations.find((l) => l.id === locationId);
      const includedAccessories = Object.entries(accessories)
        .filter(([_, included]) => included)
        .map(([name]) => name);

      const payload: BulkAssetAllocationPayload = {
        assetIds: selectedAssetIds,
        assigneeType,
        assigneeId: assigneeId.trim() || 'dept-shared',
        assigneeName: assigneeName.trim(),
        department: department.trim() || undefined,
        locationId: locationId || undefined,
        locationName: targetLoc ? targetLoc.name : undefined,
        assignedDate: assignedDate || new Date().toISOString(),
        expectedReturnDate: expectedReturnDate || undefined,
        conditionAtHandover,
        handoverNotes: handoverNotes.trim() || undefined,
        accessories: includedAccessories
      };

      const res = await api.inventory.bulkAllocateAssets(payload);
      onSuccess(res.message || `Successfully allocated ${res.data?.successfulCount || 0} assets.`);
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to bulk allocate assets.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm overflow-y-auto">
      <div className="w-full max-w-4xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="p-6 border-b border-slate-800 flex items-center justify-between bg-slate-900/80">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-xl bg-purple-500/10 text-purple-400 border border-purple-500/20">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">Bulk Institutional Asset Allocation</h3>
              <p className="text-xs text-slate-400">
                Allocate multiple physical assets while maintaining individual serial & custody records
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {error && (
            <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Asset Selection Table */}
          <div className="space-y-3">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
              <div className="flex items-center space-x-2">
                <span className="text-xs font-bold text-white uppercase tracking-wider">
                  Select Assets ({selectedAssetIds.length} of {assignableAssets.length} Selected)
                </span>
                <button
                  type="button"
                  onClick={handleSelectAll}
                  className="text-xs text-purple-400 hover:underline font-semibold"
                >
                  {selectedAssetIds.length === filteredAssets.length ? 'Deselect All' : 'Select All Filtered'}
                </button>
              </div>

              <div className="relative w-full sm:w-64">
                <Search className="w-3.5 h-3.5 absolute left-3 top-2 text-slate-500" />
                <input
                  type="text"
                  placeholder="Filter available assets..."
                  value={assetSearch}
                  onChange={(e) => setAssetSearch(e.target.value)}
                  className="w-full pl-8 pr-3 py-1 text-xs rounded-lg bg-slate-800 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                />
              </div>
            </div>

            <div className="border border-slate-800 rounded-xl overflow-hidden max-h-52 overflow-y-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-800/80 text-slate-400 sticky top-0 border-b border-slate-800">
                  <tr>
                    <th className="py-2 px-3 w-8"></th>
                    <th className="py-2 px-3 font-semibold">Asset Tag</th>
                    <th className="py-2 px-3 font-semibold">Asset Name</th>
                    <th className="py-2 px-3 font-semibold">Category</th>
                    <th className="py-2 px-3 font-semibold">Location</th>
                    <th className="py-2 px-3 font-semibold">Condition</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {filteredAssets.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-6 text-center text-slate-500">
                        No available assets matching filter.
                      </td>
                    </tr>
                  ) : (
                    filteredAssets.map((asset) => {
                      const isSelected = selectedAssetIds.includes(asset.id);
                      return (
                        <tr
                          key={asset.id}
                          onClick={() => handleToggleAsset(asset.id)}
                          className={`cursor-pointer transition-colors ${
                            isSelected ? 'bg-purple-900/20 text-white' : 'hover:bg-slate-800/30'
                          }`}
                        >
                          <td className="py-2 px-3">
                            {isSelected ? (
                              <CheckSquare className="w-4 h-4 text-purple-400" />
                            ) : (
                              <Square className="w-4 h-4 text-slate-600" />
                            )}
                          </td>
                          <td className="py-2 px-3 font-mono font-bold text-blue-400">{asset.assetTag}</td>
                          <td className="py-2 px-3 font-medium text-white">{asset.name}</td>
                          <td className="py-2 px-3 text-slate-300">{asset.categoryName}</td>
                          <td className="py-2 px-3 text-slate-300">{asset.locationName}</td>
                          <td className="py-2 px-3 text-slate-300 font-semibold">{asset.condition || 'GOOD'}</td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Allocation Custodian Details */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">Assignee Type</label>
              <select
                value={assigneeType}
                onChange={(e) => {
                  const val = e.target.value as AssigneeType;
                  setAssigneeType(val);
                  if (val === 'DEPARTMENT') {
                    setAssigneeName(department);
                  }
                }}
                className="w-full px-3 py-2 text-xs rounded-xl bg-slate-800/80 border border-slate-700 text-white focus:outline-none focus:border-purple-500"
              >
                <option value="STAFF">Administrative Staff</option>
                <option value="TEACHER">Faculty / Teacher</option>
                <option value="DEPARTMENT">Department Custody</option>
                <option value="LOCATION">Room / Lab Facility</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Target Assignee / Custodian <span className="text-rose-400">*</span>
              </label>
              {assigneeType === 'STAFF' || assigneeType === 'TEACHER' ? (
                <select
                  value={assigneeId}
                  onChange={(e) => {
                    setAssigneeId(e.target.value);
                    const st = staffMembers.find((s) => s.id === e.target.value || s.userId === e.target.value);
                    if (st) setAssigneeName(`${st.firstName} ${st.lastName}`);
                  }}
                  className="w-full px-3 py-2 text-xs rounded-xl bg-slate-800/80 border border-slate-700 text-white focus:outline-none focus:border-purple-500"
                >
                  <option value="">Select Staff / Teacher</option>
                  {staffMembers.map((s) => (
                    <option key={s.id} value={s.userId || s.id}>
                      {s.firstName} {s.lastName} ({s.designationName || 'Staff'})
                    </option>
                  ))}
                </select>
              ) : (
                <input
                  type="text"
                  placeholder="e.g. Computer Science Lab 1"
                  value={assigneeName}
                  onChange={(e) => setAssigneeName(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl bg-slate-800/80 border border-slate-700 text-white focus:outline-none focus:border-purple-500"
                />
              )}
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">Department</label>
              <select
                value={department}
                onChange={(e) => {
                  setDepartment(e.target.value);
                  if (assigneeType === 'DEPARTMENT') setAssigneeName(e.target.value);
                }}
                className="w-full px-3 py-2 text-xs rounded-xl bg-slate-800/80 border border-slate-700 text-white focus:outline-none focus:border-purple-500"
              >
                {departments.map((dept) => (
                  <option key={dept.id} value={dept.name}>
                    {dept.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">Physical Station / Room</label>
              <select
                value={locationId}
                onChange={(e) => setLocationId(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl bg-slate-800/80 border border-slate-700 text-white focus:outline-none focus:border-purple-500"
              >
                {locations.map((loc) => (
                  <option key={loc.id} value={loc.id}>
                    {loc.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">Assignment Date</label>
              <input
                type="date"
                value={assignedDate}
                onChange={(e) => setAssignedDate(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl bg-slate-800/80 border border-slate-700 text-white focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">Expected Return Date</label>
              <input
                type="date"
                value={expectedReturnDate}
                onChange={(e) => setExpectedReturnDate(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl bg-slate-800/80 border border-slate-700 text-white focus:outline-none"
              />
            </div>
          </div>

          {/* Accessories Checklist */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-2">
              Bundled Accessories Checked at Handover
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 p-3.5 rounded-xl bg-slate-800/40 border border-slate-800">
              {Object.entries(accessories).map(([acc, isChecked]) => (
                <label
                  key={acc}
                  onClick={() => handleToggleAccessory(acc)}
                  className="flex items-center space-x-2 text-xs text-slate-200 cursor-pointer select-none"
                >
                  {isChecked ? (
                    <CheckSquare className="w-4 h-4 text-purple-400" />
                  ) : (
                    <Square className="w-4 h-4 text-slate-600" />
                  )}
                  <span>{acc}</span>
                </label>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">Handover & Custody Notes</label>
            <textarea
              rows={2}
              placeholder="e.g. Clean condition verified, issued for academic session 2026-2027..."
              value={handoverNotes}
              onChange={(e) => setHandoverNotes(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-xl bg-slate-800/80 border border-slate-700 text-white focus:outline-none focus:border-purple-500"
            />
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end space-x-3 pt-4 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting || selectedAssetIds.length === 0}
              className="px-5 py-2 text-xs font-bold rounded-xl bg-purple-600 hover:bg-purple-500 text-white transition-colors disabled:opacity-50 flex items-center gap-1.5 shadow-lg shadow-purple-900/30"
            >
              <ShieldCheck className="w-4 h-4" />
              {submitting
                ? 'Allocating Assets...'
                : `Confirm Handover of ${selectedAssetIds.length} Assets`}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
