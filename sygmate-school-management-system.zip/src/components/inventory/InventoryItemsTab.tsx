import React, { useState } from 'react';
import {
  Package,
  Search,
  Filter,
  Plus,
  Edit2,
  Trash2,
  CheckCircle,
  XCircle,
  AlertTriangle,
  RefreshCw,
  Building,
  Layers,
  ChevronDown,
  ArrowDownLeft,
  ArrowUpRight,
  Eye,
  Boxes
} from 'lucide-react';
import {
  InventoryItem,
  InventoryCategory,
  InventoryLocation,
  Supplier,
  ItemType,
  InventoryItemStatus
} from '../../types';
import { StockTransactionModal, StockModalMode } from './StockTransactionModal';
import { ItemStockDetailModal } from './ItemStockDetailModal';

interface InventoryItemsTabProps {
  items: InventoryItem[];
  categories: InventoryCategory[];
  locations: InventoryLocation[];
  suppliers?: Supplier[];
  loading: boolean;
  onRefresh: () => void;
  onOpenNewItemModal: () => void;
  onEditItem: (item: InventoryItem) => void;
  onUpdateItemStatus: (id: string, status: InventoryItemStatus) => void;
  onDeleteItem: (id: string) => void;
}

export const InventoryItemsTab: React.FC<InventoryItemsTabProps> = ({
  items,
  categories,
  locations,
  suppliers = [],
  loading,
  onRefresh,
  onOpenNewItemModal,
  onEditItem,
  onUpdateItemStatus,
  onDeleteItem
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('ALL');
  const [selectedItemType, setSelectedItemType] = useState('ALL');
  const [selectedStatus, setSelectedStatus] = useState('ALL');
  const [selectedLocation, setSelectedLocation] = useState('ALL');

  // Stock Modals State
  const [isTxnModalOpen, setIsTxnModalOpen] = useState(false);
  const [txnMode, setTxnMode] = useState<StockModalMode>('IN');
  const [selectedItemForTxn, setSelectedItemForTxn] = useState<InventoryItem | null>(null);

  const [isStockDetailOpen, setIsStockDetailOpen] = useState(false);
  const [stockDetailItemId, setStockDetailItemId] = useState<string | null>(null);

  // Filter items client-side for immediate responsiveness
  const safeItems = Array.isArray(items) ? items : [];
  const filteredItems = safeItems.filter(item => {
    if (selectedCategory !== 'ALL' && item.categoryId !== selectedCategory) return false;
    if (selectedItemType !== 'ALL' && item.itemType !== selectedItemType) return false;
    if (selectedStatus !== 'ALL' && item.status !== selectedStatus) return false;
    if (selectedLocation !== 'ALL' && item.locationId !== selectedLocation) return false;

    if (searchTerm.trim()) {
      const q = searchTerm.trim().toLowerCase();
      const match =
        item.name.toLowerCase().includes(q) ||
        item.itemCode.toLowerCase().includes(q) ||
        (item.brand && item.brand.toLowerCase().includes(q)) ||
        (item.model && item.model.toLowerCase().includes(q)) ||
        (item.barcode && item.barcode.toLowerCase().includes(q)) ||
        (item.categoryName && item.categoryName.toLowerCase().includes(q));
      if (!match) return false;
    }
    return true;
  });

  const getStatusBadge = (status: InventoryItemStatus) => {
    switch (status) {
      case 'ACTIVE':
        return (
          <span className="inline-flex items-center px-2 py-0.5 text-xs font-semibold rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            Active
          </span>
        );
      case 'INACTIVE':
        return (
          <span className="inline-flex items-center px-2 py-0.5 text-xs font-semibold rounded-full bg-slate-500/10 text-slate-400 border border-slate-500/20">
            Inactive
          </span>
        );
      case 'DISCONTINUED':
        return (
          <span className="inline-flex items-center px-2 py-0.5 text-xs font-semibold rounded-full bg-rose-500/10 text-rose-400 border border-rose-500/20">
            Discontinued
          </span>
        );
    }
  };

  const getItemTypeBadge = (itemType: ItemType) => {
    switch (itemType) {
      case 'CONSUMABLE':
        return <span className="text-[11px] text-amber-400 font-medium">Consumable</span>;
      case 'NON_CONSUMABLE':
        return <span className="text-[11px] text-blue-400 font-medium">Non-Consumable</span>;
      case 'STOCK_ITEM':
        return <span className="text-[11px] text-purple-400 font-medium">Stock Item</span>;
      case 'SERVICE':
        return <span className="text-[11px] text-teal-400 font-medium">Service</span>;
      default:
        return <span className="text-[11px] text-slate-400 font-medium">{itemType}</span>;
    }
  };

  return (
    <div className="space-y-4">
      {/* Header and Filter Controls */}
      <div className="p-4 rounded-xl glass-panel border border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-semibold text-white flex items-center gap-2">
              <Package className="w-5 h-5 text-indigo-400" />
              Inventory Item Catalog
            </h3>
            <p className="text-xs text-slate-400">
              Manage master item codes, units of measurement, categories, and stock reorder parameters
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={onRefresh}
              disabled={loading}
              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors disabled:opacity-50"
              title="Refresh inventory items"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-indigo-400' : ''}`} />
            </button>
            <button
              onClick={() => {
                setSelectedItemForTxn(null);
                setTxnMode('IN');
                setIsTxnModalOpen(true);
              }}
              className="px-3.5 py-2 text-xs font-semibold rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white transition-colors flex items-center gap-1.5 shadow-sm shadow-emerald-950"
            >
              <ArrowDownLeft className="w-4 h-4" />
              + Stock In
            </button>
            <button
              onClick={onOpenNewItemModal}
              className="px-3.5 py-2 text-xs font-semibold rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white transition-colors flex items-center gap-1.5 shadow-sm shadow-indigo-950"
            >
              <Plus className="w-4 h-4" />
              Add New Item
            </button>
          </div>
        </div>

        {/* Filter bar */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-3 pt-2 border-t border-slate-800/60">
          {/* Search Bar */}
          <div className="relative md:col-span-2">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search by name, SKU, brand, model..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-4 py-2 text-xs rounded-lg glass-input border border-slate-700/80 focus:outline-none focus:border-indigo-500 text-slate-100 placeholder-slate-500"
            />
          </div>

          {/* Category Filter */}
          <div>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700/80 focus:outline-none focus:border-indigo-500 text-slate-200"
            >
              <option value="ALL">All Categories</option>
              {categories.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          {/* Item Type Filter */}
          <div>
            <select
              value={selectedItemType}
              onChange={(e) => setSelectedItemType(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700/80 focus:outline-none focus:border-indigo-500 text-slate-200"
            >
              <option value="ALL">All Item Types</option>
              <option value="CONSUMABLE">Consumable</option>
              <option value="NON_CONSUMABLE">Non-Consumable</option>
              <option value="STOCK_ITEM">Stock Item</option>
              <option value="SERVICE">Service</option>
            </select>
          </div>

          {/* Status Filter */}
          <div>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-lg glass-input border border-slate-700/80 focus:outline-none focus:border-indigo-500 text-slate-200"
            >
              <option value="ALL">All Statuses</option>
              <option value="ACTIVE">Active</option>
              <option value="INACTIVE">Inactive</option>
              <option value="DISCONTINUED">Discontinued</option>
            </select>
          </div>
        </div>
      </div>

      {/* Items Table */}
      <div className="rounded-xl glass-panel border border-slate-800 overflow-hidden shadow-sm">
        <div className="p-3 bg-slate-900/60 border-b border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <span>Showing <strong className="text-white font-medium">{filteredItems.length}</strong> inventory items</span>
          {(searchTerm || selectedCategory !== 'ALL' || selectedItemType !== 'ALL' || selectedStatus !== 'ALL') && (
            <button
              onClick={() => {
                setSearchTerm('');
                setSelectedCategory('ALL');
                setSelectedItemType('ALL');
                setSelectedStatus('ALL');
                setSelectedLocation('ALL');
              }}
              className="text-indigo-400 hover:text-indigo-300 transition-colors"
            >
              Clear filters
            </button>
          )}
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-900/80 border-b border-slate-800 text-slate-400 uppercase tracking-wider font-semibold text-[11px]">
              <tr>
                <th className="py-3 px-4">Item SKU & Name</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4">Type</th>
                <th className="py-3 px-4">Unit</th>
                <th className="py-3 px-4">Current Stock</th>
                <th className="py-3 px-4">Thresholds (Min / Reorder)</th>
                <th className="py-3 px-4">Location</th>
                <th className="py-3 px-4">Unit Price</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {filteredItems.length === 0 ? (
                <tr>
                  <td colSpan={10} className="py-12 text-center text-slate-400">
                    <Package className="w-10 h-10 text-slate-600 mx-auto mb-2" />
                    <p className="text-sm font-medium text-slate-300">No inventory items found</p>
                    <p className="text-xs text-slate-500 mt-1">Try adjusting search parameters or register a new item.</p>
                  </td>
                </tr>
              ) : (
                filteredItems.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-800/25 transition-colors">
                    <td className="py-3 px-4">
                      <div className="space-y-0.5">
                        <div className="flex items-center space-x-2">
                          <span className="font-mono text-xs font-semibold px-2 py-0.5 rounded bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                            {item.itemCode}
                          </span>
                          <span className="font-semibold text-white">{item.name}</span>
                        </div>
                        {(item.brand || item.model) && (
                          <div className="text-[11px] text-slate-400">
                            {[item.brand, item.model].filter(Boolean).join(' • ')}
                          </div>
                        )}
                      </div>
                    </td>
                    <td className="py-3 px-4 font-medium text-slate-200">
                      {item.categoryName}
                    </td>
                    <td className="py-3 px-4">
                      {getItemTypeBadge(item.itemType)}
                    </td>
                    <td className="py-3 px-4 font-mono font-medium text-slate-300">
                      {item.unitShortCode}
                    </td>
                    <td className="py-3 px-4">
                      {item.isStockable !== false ? (
                        <button
                          onClick={() => {
                            setStockDetailItemId(item.id);
                            setIsStockDetailOpen(true);
                          }}
                          className="flex items-center space-x-1 font-mono text-xs text-left group"
                          title="Click to view store-by-store stock breakdown"
                        >
                          <span className={`font-bold ${
                            (item.currentStock || 0) <= 0
                              ? 'text-rose-400'
                              : (item.currentStock || 0) <= (item.reorderLevel || 0)
                              ? 'text-amber-400'
                              : 'text-emerald-400'
                          }`}>
                            {item.currentStock ?? 0}
                          </span>
                          <span className="text-slate-400 text-[11px]">{item.unitShortCode}</span>
                          <Eye className="w-3 h-3 text-slate-500 group-hover:text-indigo-400 ml-1 transition-colors" />
                        </button>
                      ) : (
                        <span className="text-[11px] text-slate-500 italic">Non-stockable</span>
                      )}
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-400">
                      <span className="text-slate-200">{item.minStockLevel}</span> / <span className="text-amber-400">{item.reorderLevel}</span>
                    </td>
                    <td className="py-3 px-4 text-slate-300">
                      {item.locationName || <span className="text-slate-500 italic">Unassigned</span>}
                    </td>
                    <td className="py-3 px-4 font-mono font-semibold text-slate-200">
                      ${Number(item.unitPrice).toFixed(2)}
                    </td>
                    <td className="py-3 px-4">
                      {getStatusBadge(item.status)}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end space-x-1.5">
                        {item.isStockable !== false && (
                          <>
                            <button
                              onClick={() => {
                                setSelectedItemForTxn(item);
                                setTxnMode('IN');
                                setIsTxnModalOpen(true);
                              }}
                              className="px-2 py-1 text-[11px] font-semibold rounded bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 transition-colors"
                              title="Stock Inward Receipt"
                            >
                              + In
                            </button>
                            <button
                              onClick={() => {
                                setSelectedItemForTxn(item);
                                setTxnMode('OUT');
                                setIsTxnModalOpen(true);
                              }}
                              className="px-2 py-1 text-[11px] font-semibold rounded bg-rose-500/10 text-rose-400 hover:bg-rose-500/20 transition-colors"
                              title="Stock Outward Issue"
                            >
                              - Out
                            </button>
                          </>
                        )}
                        <button
                          onClick={() => onEditItem(item)}
                          className="p-1.5 rounded-lg hover:bg-slate-700/60 text-slate-400 hover:text-slate-200 transition-colors"
                          title="Edit Item"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        {item.status === 'ACTIVE' ? (
                          <button
                            onClick={() => onUpdateItemStatus(item.id, 'INACTIVE')}
                            className="p-1.5 rounded-lg hover:bg-amber-500/10 text-slate-400 hover:text-amber-400 transition-colors"
                            title="Deactivate Item"
                          >
                            <XCircle className="w-3.5 h-3.5" />
                          </button>
                        ) : (
                          <button
                            onClick={() => onUpdateItemStatus(item.id, 'ACTIVE')}
                            className="p-1.5 rounded-lg hover:bg-emerald-500/10 text-slate-400 hover:text-emerald-400 transition-colors"
                            title="Activate Item"
                          >
                            <CheckCircle className="w-3.5 h-3.5" />
                          </button>
                        )}
                        <button
                          onClick={() => {
                            if (window.confirm(`Are you sure you want to delete inventory item '${item.name}'?`)) {
                              onDeleteItem(item.id);
                            }
                          }}
                          className="p-1.5 rounded-lg hover:bg-rose-500/10 text-slate-400 hover:text-rose-400 transition-colors"
                          title="Delete Item"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Stock Transaction Modal */}
      <StockTransactionModal
        isOpen={isTxnModalOpen}
        onClose={() => setIsTxnModalOpen(false)}
        mode={txnMode}
        items={items}
        locations={locations}
        suppliers={suppliers}
        preselectedItem={selectedItemForTxn}
        onSuccess={() => {
          onRefresh();
        }}
      />

      {/* Item Multi-Store Stock Modal */}
      <ItemStockDetailModal
        isOpen={isStockDetailOpen}
        onClose={() => {
          setIsStockDetailOpen(false);
          setStockDetailItemId(null);
        }}
        itemId={stockDetailItemId}
        onQuickAction={(mode, itm, locId) => {
          setSelectedItemForTxn(itm);
          setTxnMode(mode);
          setIsTxnModalOpen(true);
        }}
      />
    </div>
  );
};
