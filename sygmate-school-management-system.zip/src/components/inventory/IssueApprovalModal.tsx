import React, { useState } from 'react';
import {
  X,
  CheckCircle,
  XCircle,
  AlertCircle,
  Package,
  Building,
  User,
  Clock,
  ShieldCheck
} from 'lucide-react';
import { IssueRequest, ReviewIssueRequestPayload } from '../../types';
import { api } from '../../services/api';

interface IssueApprovalModalProps {
  isOpen: boolean;
  onClose: () => void;
  request: IssueRequest | null;
  onSuccess: (message: string) => void;
}

export const IssueApprovalModal: React.FC<IssueApprovalModalProps> = ({
  isOpen,
  onClose,
  request,
  onSuccess
}) => {
  const [decision, setDecision] = useState<'APPROVE' | 'REJECT'>('APPROVE');
  const [reviewNotes, setReviewNotes] = useState('');
  const [rejectionReason, setRejectionReason] = useState('');
  const [itemApprovals, setItemApprovals] = useState<{ [itemId: string]: number }>({});
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Initialize line item approved quantities
  React.useEffect(() => {
    if (request) {
      const initial: { [itemId: string]: number } = {};
      request.items.forEach((item) => {
        initial[item.itemId] = item.approvedQuantity || item.requestedQuantity;
      });
      setItemApprovals(initial);
      setDecision('APPROVE');
      setReviewNotes('');
      setRejectionReason('');
      setError(null);
    }
  }, [request]);

  if (!isOpen || !request) return null;

  const handleQtyChange = (itemId: string, maxQty: number, val: string) => {
    const num = val === '' ? 0 : parseInt(val, 10);
    const validNum = isNaN(num) ? 0 : Math.max(0, Math.min(maxQty, num));
    setItemApprovals({
      ...itemApprovals,
      [itemId]: validNum
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (decision === 'REJECT' && !rejectionReason.trim()) {
      setError('Please provide a reason for rejecting this issue request.');
      return;
    }

    try {
      setSubmitting(true);

      const payload: ReviewIssueRequestPayload = {
        decision,
        reviewNotes: reviewNotes.trim() || undefined,
        rejectionReason: decision === 'REJECT' ? rejectionReason.trim() : undefined,
        itemApprovals:
          decision === 'APPROVE'
            ? Object.entries(itemApprovals).map(([itemId, approvedQuantity]) => ({
                itemId,
                approvedQuantity: Number(approvedQuantity) || 0
              }))
            : undefined
      };

      const res = await api.inventory.reviewIssueRequest(request.id, payload);
      onSuccess(res.message || 'Issue request reviewed successfully.');
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to review issue request.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm overflow-y-auto">
      <div className="w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="p-6 border-b border-slate-800 flex items-center justify-between bg-slate-900/80">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-xl bg-purple-500/10 text-purple-400 border border-purple-500/20">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">Review Issue Request</h3>
              <p className="text-xs text-slate-400">
                {request.requestNumber} • Requested by {request.requestedByName} ({request.departmentName})
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {error && (
            <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Requisition Meta */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-3.5 rounded-xl bg-slate-800/40 border border-slate-800 text-xs">
            <div>
              <span className="text-[11px] text-slate-400">Priority</span>
              <div className="font-semibold text-white mt-0.5">{request.priority}</div>
            </div>
            <div>
              <span className="text-[11px] text-slate-400">Destination</span>
              <div className="font-semibold text-white mt-0.5 truncate">{request.destinationName}</div>
            </div>
            <div>
              <span className="text-[11px] text-slate-400">Store / Location</span>
              <div className="font-semibold text-white mt-0.5 truncate">{request.locationName}</div>
            </div>
            <div>
              <span className="text-[11px] text-slate-400">Request Date</span>
              <div className="font-semibold text-white mt-0.5">
                {new Date(request.requestDate).toLocaleDateString()}
              </div>
            </div>
          </div>

          <div>
            <span className="text-xs font-semibold text-slate-400">Purpose</span>
            <p className="text-xs text-slate-200 mt-1 p-2.5 rounded-lg bg-slate-800/30 border border-slate-800">
              {request.purpose}
            </p>
          </div>

          {/* Decision Selector */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-2">Review Decision</label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setDecision('APPROVE')}
                className={`p-3 rounded-xl border text-xs font-semibold flex items-center justify-center gap-2 transition-colors ${
                  decision === 'APPROVE'
                    ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
                    : 'bg-slate-800/50 border-slate-700 text-slate-400 hover:text-white'
                }`}
              >
                <CheckCircle className="w-4 h-4" />
                Approve Requisition
              </button>
              <button
                type="button"
                onClick={() => setDecision('REJECT')}
                className={`p-3 rounded-xl border text-xs font-semibold flex items-center justify-center gap-2 transition-colors ${
                  decision === 'REJECT'
                    ? 'bg-rose-500/10 border-rose-500/30 text-rose-400'
                    : 'bg-slate-800/50 border-slate-700 text-slate-400 hover:text-white'
                }`}
              >
                <XCircle className="w-4 h-4" />
                Reject Requisition
              </button>
            </div>
          </div>

          {/* Items Approval Table */}
          {decision === 'APPROVE' && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-white uppercase tracking-wider">
                  Line Items Approval Quota
                </span>
                <span className="text-[11px] text-slate-400">You may adjust approved quantities for partial issue</span>
              </div>

              <div className="border border-slate-800 rounded-xl overflow-hidden">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-800/70 text-slate-400 border-b border-slate-800">
                    <tr>
                      <th className="py-2.5 px-3 font-semibold">Item & SKU</th>
                      <th className="py-2.5 px-3 font-semibold text-center w-24">Requested</th>
                      <th className="py-2.5 px-3 font-semibold text-center w-24">Store Stock</th>
                      <th className="py-2.5 px-3 font-semibold text-center w-28">Approve Qty</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {request.items.map((item) => {
                      const approvedVal = itemApprovals[item.itemId] ?? item.requestedQuantity;
                      const hasSufficient = item.availableQuantityAtRequest >= approvedVal;
                      return (
                        <tr key={item.id} className="bg-slate-900/40">
                          <td className="p-2.5">
                            <div className="font-semibold text-white">{item.itemName}</div>
                            <div className="text-[11px] text-slate-400 font-mono">{item.itemCode}</div>
                          </td>
                          <td className="p-2.5 text-center font-mono">
                            {item.requestedQuantity} {item.unitShortCode}
                          </td>
                          <td className="p-2.5 text-center font-mono">
                            <span
                              className={`px-2 py-0.5 rounded text-[11px] font-semibold ${
                                item.availableQuantityAtRequest > 0
                                  ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                                  : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                              }`}
                            >
                              {item.availableQuantityAtRequest} {item.unitShortCode}
                            </span>
                          </td>
                          <td className="p-2.5">
                            <input
                              type="number"
                              min="0"
                              max={item.requestedQuantity}
                              value={approvedVal}
                              onChange={(e) =>
                                handleQtyChange(item.itemId, item.requestedQuantity, e.target.value)
                              }
                              className="w-full px-2 py-1 text-xs rounded-lg bg-slate-800 border border-slate-700 text-center font-mono text-white focus:outline-none focus:border-blue-500"
                            />
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Notes or Reason */}
          {decision === 'APPROVE' ? (
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">Approval Remarks</label>
              <textarea
                rows={2}
                placeholder="Optional instructions for warehouse dispatch..."
                value={reviewNotes}
                onChange={(e) => setReviewNotes(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl bg-slate-800/80 border border-slate-700 text-white focus:outline-none focus:border-blue-500"
              />
            </div>
          ) : (
            <div>
              <label className="block text-xs font-semibold text-rose-400 mb-1.5">
                Rejection Reason <span className="text-rose-500">*</span>
              </label>
              <textarea
                rows={2}
                required
                placeholder="Please state why this request cannot be fulfilled at this time..."
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl bg-slate-800/80 border border-rose-500/30 text-white focus:outline-none focus:border-rose-500"
              />
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex items-center justify-end space-x-3 pt-4 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className={`px-5 py-2 text-xs font-bold rounded-xl text-white transition-colors disabled:opacity-50 flex items-center gap-1.5 shadow-lg ${
                decision === 'APPROVE'
                  ? 'bg-emerald-600 hover:bg-emerald-500 shadow-emerald-900/30'
                  : 'bg-rose-600 hover:bg-rose-500 shadow-rose-900/30'
              }`}
            >
              {submitting
                ? 'Processing...'
                : decision === 'APPROVE'
                ? 'Confirm & Approve'
                : 'Confirm & Reject'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
