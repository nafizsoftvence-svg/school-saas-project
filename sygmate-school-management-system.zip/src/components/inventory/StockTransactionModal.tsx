import React, { useState, useEffect } from 'react';
import {
  X,
  Package,
  ArrowDownLeft,
  ArrowUpRight,
  ArrowLeftRight,
  RotateCcw,
  Sliders,
  AlertCircle,
  Building,
  Calendar,
  CheckCircle,
  FileText
} from 'lucide-react';
import {
  InventoryItem,
  InventoryLocation,
  Supplier,
  ItemStockBalance,
  OpeningStockPayload,
  StockInPayload,
  StockOutPayload,
  StockTransferPayload,
  StockReturnPayload,
  StockAdjustmentPayload,
  StockTransactionType,
  StockAdjustmentReason
} from '../../types';
import { api } from '../../services/api';

export type StockModalMode = 'IN' | 'OUT' | 'TRANSFER' | 'RETURN' | 'ADJUST' | 'OPENING';

interface StockTransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  mode: StockModalMode;
  items: InventoryItem[];
  locations: InventoryLocation[];
  suppliers: Supplier[];
  preselectedItem?: InventoryItem | null;
  preselectedLocation?: InventoryLocation | null;
  onSuccess: (message: string) => void;
}

export const StockTransactionModal: React.FC<StockTransactionModalProps> = ({
  isOpen,
  onClose,
  mode,
  items,
  locations,
  suppliers,
  preselectedItem,
  preselectedLocation,
  onSuccess
}) => {
  // Common Fields
  const [selectedItemId, setSelectedItemId] = useState('');
  const [selectedLocationId, setSelectedLocationId] = useState('');
  const [quantity, setQuantity] = useState<number | ''>('');
  const [transactionDate, setTransactionDate] = useState(new Date().toISOString().split('T')[0]);
  const [referenceNumber, setReferenceNumber] = useState('');
  const [remarks, setRemarks] = useState('');

  // Mode Specific Fields
  const [unitCost, setUnitCost] = useState<number | ''>('');
  const [supplierId, setSupplierId] = useState('');
  const [batchNumber, setBatchNumber] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [issuedToType, setIssuedToType] = useState<'STAFF' | 'DEPARTMENT' | 'STUDENT' | 'MAINTENANCE' | 'OTHER'>('DEPARTMENT');
  const [issuedToName, setIssuedToName] = useState('');
  const [destinationLocationId, setDestinationLocationId] = useState('');
  const [returnFromType, setReturnFromType] = useState<'STAFF' | 'DEPARTMENT' | 'STUDENT' | 'OTHER'>('DEPARTMENT');
  const [returnFromName, setReturnFromName] = useState('');
  const [itemCondition, setItemCondition] = useState<'GOOD' | 'DAMAGED' | 'EXPIRED' | 'UNUSABLE'>('GOOD');
  const [countedQuantity, setCountedQuantity] = useState<number | ''>('');
  const [adjustmentReason, setAdjustmentReason] = useState<StockAdjustmentReason>('PHYSICAL_COUNT_RECONCILIATION');

  // Real-time stock balance checking for safety
  const [availableStock, setAvailableStock] = useState<number | null>(null);
  const [stockChecking, setStockChecking] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Filter only stockable items
  const safeItems = Array.isArray(items) ? items : [];
  const stockableItems = safeItems.filter(i => i.isStockable !== false);

  // Reset / initialize state on open
  useEffect(() => {
    if (isOpen) {
      const defaultItem = preselectedItem || stockableItems[0];
      const defaultLoc = preselectedLocation || locations[0];

      setSelectedItemId(defaultItem ? defaultItem.id : '');
      setSelectedLocationId(defaultLoc ? defaultLoc.id : '');
      setDestinationLocationId(
        locations.find(l => l.id !== (defaultLoc ? defaultLoc.id : ''))?.id || ''
      );
      setQuantity('');
      setTransactionDate(new Date().toISOString().split('T')[0]);
      setReferenceNumber('');
      setRemarks('');
      setUnitCost(defaultItem?.unitPrice || '');
      setSupplierId(suppliers[0]?.id || '');
      setBatchNumber('');
      setExpiryDate('');
      setIssuedToType('DEPARTMENT');
      setIssuedToName('');
      setReturnFromType('DEPARTMENT');
      setReturnFromName('');
      setItemCondition('GOOD');
      setCountedQuantity('');
      setAdjustmentReason('PHYSICAL_COUNT_RECONCILIATION');
      setError(null);
    }
  }, [isOpen, mode, preselectedItem, preselectedLocation]);

  // Fetch current live stock for selected item and location
  useEffect(() => {
    if (selectedItemId && selectedLocationId && isOpen) {
      setStockChecking(true);
      api.inventory.getStockBalances({
        itemId: selectedItemId,
        locationId: selectedLocationId,
        limit: 1
      })
        .then(res => {
          const balanceItems = Array.isArray(res?.data?.data)
            ? res.data.data
            : Array.isArray(res?.data)
            ? (res.data as any)
            : [];
          if (balanceItems.length > 0) {
            setAvailableStock(balanceItems[0].quantity);
            if (mode === 'ADJUST' && countedQuantity === '') {
              setCountedQuantity(balanceItems[0].quantity);
            }
          } else {
            setAvailableStock(0);
            if (mode === 'ADJUST' && countedQuantity === '') {
              setCountedQuantity(0);
            }
          }
        })
        .catch(() => setAvailableStock(0))
        .finally(() => setStockChecking(false));
    } else {
      setAvailableStock(null);
    }
  }, [selectedItemId, selectedLocationId, isOpen, mode]);

  if (!isOpen) return null;

  const selectedItem = items.find(i => i.id === selectedItemId);
  const selectedLocation = locations.find(l => l.id === selectedLocationId);

  // Dynamic titles & icons
  const getModalConfig = () => {
    switch (mode) {
      case 'OPENING':
        return {
          title: 'Record Opening Stock',
          subtitle: 'Initialize baseline inventory quantities for a storage location',
          icon: Package,
          accentColor: 'indigo',
          buttonLabel: 'Save Opening Stock'
        };
      case 'IN':
        return {
          title: 'Stock Inward (Receipt)',
          subtitle: 'Record incoming shipment, purchase delivery, or institutional donation',
          icon: ArrowDownLeft,
          accentColor: 'emerald',
          buttonLabel: 'Receive Stock'
        };
      case 'OUT':
        return {
          title: 'Stock Outward (Issue)',
          subtitle: 'Issue consumable supplies or inventory to staff, department, or student',
          icon: ArrowUpRight,
          accentColor: 'rose',
          buttonLabel: 'Issue Stock'
        };
      case 'TRANSFER':
        return {
          title: 'Stock Location Transfer',
          subtitle: 'Relocate items atomically from one store / facility to another',
          icon: ArrowLeftRight,
          accentColor: 'blue',
          buttonLabel: 'Transfer Stock'
        };
      case 'RETURN':
        return {
          title: 'Stock Return',
          subtitle: 'Accept previously issued items back into the designated store',
          icon: RotateCcw,
          accentColor: 'amber',
          buttonLabel: 'Process Return'
        };
      case 'ADJUST':
        return {
          title: 'Stock Count Adjustment',
          subtitle: 'Reconcile physical stock count variance with recorded database balance',
          icon: Sliders,
          accentColor: 'purple',
          buttonLabel: 'Apply Adjustment'
        };
    }
  };

  const config = getModalConfig();
  const IconComponent = config.icon;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!selectedItemId) {
      setError('Please select an item');
      return;
    }
    if (!selectedLocationId) {
      setError('Please select a store / location');
      return;
    }

    try {
      setSubmitting(true);

      if (mode === 'OPENING') {
        const qtyNum = Number(quantity);
        if (isNaN(qtyNum) || qtyNum < 0) {
          setError('Opening stock quantity must be 0 or greater');
          setSubmitting(false);
          return;
        }
        const payload: OpeningStockPayload = {
          itemId: selectedItemId,
          locationId: selectedLocationId,
          quantity: qtyNum,
          unitCost: unitCost !== '' ? Number(unitCost) : undefined,
          batchNumber: batchNumber.trim() || undefined,
          expiryDate: expiryDate || undefined,
          remarks: remarks.trim() || undefined
        };
        await api.inventory.recordOpeningStock(payload);
        onSuccess(`Opening stock of ${qtyNum} recorded for '${selectedItem?.name}'.`);
      } else if (mode === 'IN') {
        const qtyNum = Number(quantity);
        if (isNaN(qtyNum) || qtyNum <= 0) {
          setError('Receipt quantity must be greater than zero');
          setSubmitting(false);
          return;
        }
        const payload: StockInPayload = {
          itemId: selectedItemId,
          locationId: selectedLocationId,
          quantity: qtyNum,
          unitCost: unitCost !== '' ? Number(unitCost) : undefined,
          supplierId: supplierId || undefined,
          referenceNumber: referenceNumber.trim() || undefined,
          batchNumber: batchNumber.trim() || undefined,
          expiryDate: expiryDate || undefined,
          transactionDate,
          remarks: remarks.trim() || undefined
        };
        await api.inventory.recordStockIn(payload);
        onSuccess(`Received ${qtyNum} units of '${selectedItem?.name}' into ${selectedLocation?.name}.`);
      } else if (mode === 'OUT') {
        const qtyNum = Number(quantity);
        if (isNaN(qtyNum) || qtyNum <= 0) {
          setError('Issue quantity must be greater than zero');
          setSubmitting(false);
          return;
        }
        if (availableStock !== null && qtyNum > availableStock) {
          setError(`Cannot issue ${qtyNum}. Only ${availableStock} units available in ${selectedLocation?.name}.`);
          setSubmitting(false);
          return;
        }
        const payload: StockOutPayload = {
          itemId: selectedItemId,
          locationId: selectedLocationId,
          quantity: qtyNum,
          issuedToType,
          issuedToName: issuedToName.trim() || undefined,
          referenceNumber: referenceNumber.trim() || undefined,
          transactionDate,
          remarks: remarks.trim() || undefined
        };
        await api.inventory.recordStockOut(payload);
        onSuccess(`Issued ${qtyNum} units of '${selectedItem?.name}' from ${selectedLocation?.name}.`);
      } else if (mode === 'TRANSFER') {
        const qtyNum = Number(quantity);
        if (isNaN(qtyNum) || qtyNum <= 0) {
          setError('Transfer quantity must be greater than zero');
          setSubmitting(false);
          return;
        }
        if (!destinationLocationId) {
          setError('Destination store is required');
          setSubmitting(false);
          return;
        }
        if (selectedLocationId === destinationLocationId) {
          setError('Source and destination stores cannot be identical');
          setSubmitting(false);
          return;
        }
        if (availableStock !== null && qtyNum > availableStock) {
          setError(`Cannot transfer ${qtyNum}. Only ${availableStock} units available at source location.`);
          setSubmitting(false);
          return;
        }
        const destLoc = locations.find(l => l.id === destinationLocationId);
        const payload: StockTransferPayload = {
          itemId: selectedItemId,
          sourceLocationId: selectedLocationId,
          destinationLocationId,
          quantity: qtyNum,
          referenceNumber: referenceNumber.trim() || undefined,
          transactionDate,
          remarks: remarks.trim() || undefined
        };
        await api.inventory.recordStockTransfer(payload);
        onSuccess(`Transferred ${qtyNum} units of '${selectedItem?.name}' from ${selectedLocation?.name} to ${destLoc?.name}.`);
      } else if (mode === 'RETURN') {
        const qtyNum = Number(quantity);
        if (isNaN(qtyNum) || qtyNum <= 0) {
          setError('Return quantity must be greater than zero');
          setSubmitting(false);
          return;
        }
        const payload: StockReturnPayload = {
          itemId: selectedItemId,
          locationId: selectedLocationId,
          quantity: qtyNum,
          returnFromType,
          returnFromName: returnFromName.trim() || undefined,
          itemCondition,
          referenceNumber: referenceNumber.trim() || undefined,
          transactionDate,
          remarks: remarks.trim() || undefined
        };
        await api.inventory.recordStockReturn(payload);
        onSuccess(`Returned ${qtyNum} units of '${selectedItem?.name}' back to ${selectedLocation?.name}.`);
      } else if (mode === 'ADJUST') {
        const countedNum = Number(countedQuantity);
        if (isNaN(countedNum) || countedNum < 0) {
          setError('Physical counted quantity must be 0 or greater');
          setSubmitting(false);
          return;
        }
        if (!adjustmentReason) {
          setError('Adjustment reason is mandatory');
          setSubmitting(false);
          return;
        }
        const payload: StockAdjustmentPayload = {
          itemId: selectedItemId,
          locationId: selectedLocationId,
          countedQuantity: countedNum,
          adjustmentReason,
          referenceNumber: referenceNumber.trim() || undefined,
          transactionDate,
          remarks: remarks.trim() || undefined
        };
        await api.inventory.recordStockAdjustment(payload);
        onSuccess(`Physical count adjusted to ${countedNum} units for '${selectedItem?.name}'.`);
      }

      onClose();
    } catch (err: any) {
      setError(err.message || 'Transaction failed. Please check inputs and try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm overflow-y-auto">
      <div className="w-full max-w-xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-6">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800 bg-slate-900/80">
          <div className="flex items-center space-x-3">
            <div className={`p-2.5 rounded-xl bg-${config.accentColor}-500/10 text-${config.accentColor}-400 border border-${config.accentColor}-500/20`}>
              <IconComponent className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white tracking-tight">{config.title}</h3>
              <p className="text-xs text-slate-400">{config.subtitle}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs flex items-center space-x-2">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Item Selector */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Stockable Item <span className="text-rose-400">*</span>
            </label>
            <select
              value={selectedItemId}
              onChange={e => setSelectedItemId(e.target.value)}
              disabled={!!preselectedItem}
              className="w-full px-3.5 py-2 text-xs rounded-xl glass-input border border-slate-700 focus:outline-none focus:border-indigo-500 text-slate-100 bg-slate-950"
            >
              <option value="">Select an Item...</option>
              {stockableItems.map(item => (
                <option key={item.id} value={item.id}>
                  {item.name} ({item.itemCode}) — {item.categoryName || 'Item'}
                </option>
              ))}
            </select>
          </div>

          {/* Location & Stock Display */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                {mode === 'TRANSFER' ? 'Source Store' : 'Storage Location'} <span className="text-rose-400">*</span>
              </label>
              <select
                value={selectedLocationId}
                onChange={e => setSelectedLocationId(e.target.value)}
                className="w-full px-3.5 py-2 text-xs rounded-xl glass-input border border-slate-700 focus:outline-none focus:border-indigo-500 text-slate-100 bg-slate-950"
              >
                <option value="">Select Store...</option>
                {locations.map(loc => (
                  <option key={loc.id} value={loc.id}>
                    {loc.name} ({loc.code})
                  </option>
                ))}
              </select>
            </div>

            {/* Current Stock Banner */}
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex flex-col justify-center">
              <span className="text-[10px] uppercase font-bold text-slate-400">Current In-Store Balance</span>
              <div className="flex items-center space-x-2 mt-0.5">
                <span className="text-lg font-bold text-white font-mono">
                  {stockChecking ? '...' : (availableStock !== null ? availableStock : '—')}
                </span>
                <span className="text-xs text-slate-400">
                  {selectedItem?.unitShortCode || 'units'}
                </span>
                {availableStock !== null && availableStock <= (selectedItem?.minStockLevel || 0) && (
                  <span className="px-1.5 py-0.5 text-[10px] rounded font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/20">
                    Low
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Destination Location for Transfer */}
          {mode === 'TRANSFER' && (
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Destination Store <span className="text-rose-400">*</span>
              </label>
              <select
                value={destinationLocationId}
                onChange={e => setDestinationLocationId(e.target.value)}
                className="w-full px-3.5 py-2 text-xs rounded-xl glass-input border border-slate-700 focus:outline-none focus:border-indigo-500 text-slate-100 bg-slate-950"
              >
                <option value="">Select Destination Store...</option>
                {locations.filter(l => l.id !== selectedLocationId).map(loc => (
                  <option key={loc.id} value={loc.id}>
                    {loc.name} ({loc.code})
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Quantity or Counted Quantity */}
          {mode !== 'ADJUST' ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Quantity ({selectedItem?.unitShortCode || 'Units'}) <span className="text-rose-400">*</span>
                </label>
                <input
                  type="number"
                  min="0.01"
                  step="any"
                  placeholder="e.g. 50"
                  value={quantity}
                  onChange={e => setQuantity(e.target.value === '' ? '' : Number(e.target.value))}
                  className="w-full px-3.5 py-2 text-xs rounded-xl glass-input border border-slate-700 focus:outline-none focus:border-indigo-500 text-slate-100"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Transaction Date
                </label>
                <input
                  type="date"
                  value={transactionDate}
                  onChange={e => setTransactionDate(e.target.value)}
                  className="w-full px-3.5 py-2 text-xs rounded-xl glass-input border border-slate-700 focus:outline-none focus:border-indigo-500 text-slate-100"
                />
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Physical Counted Quantity <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="any"
                    placeholder="Enter verified count"
                    value={countedQuantity}
                    onChange={e => setCountedQuantity(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full px-3.5 py-2 text-xs rounded-xl glass-input border border-slate-700 focus:outline-none focus:border-indigo-500 text-slate-100"
                  />
                </div>

                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex flex-col justify-center">
                  <span className="text-[10px] uppercase font-bold text-slate-400">Calculated Variance</span>
                  <div className="flex items-center space-x-2 mt-0.5">
                    <span className={`text-base font-bold font-mono ${
                      countedQuantity !== '' && availableStock !== null
                        ? Number(countedQuantity) - availableStock > 0
                          ? 'text-emerald-400'
                          : Number(countedQuantity) - availableStock < 0
                          ? 'text-rose-400'
                          : 'text-slate-300'
                        : 'text-slate-500'
                    }`}>
                      {countedQuantity !== '' && availableStock !== null
                        ? `${Number(countedQuantity) - availableStock >= 0 ? '+' : ''}${Math.round((Number(countedQuantity) - availableStock) * 100) / 100}`
                        : '—'}
                    </span>
                    <span className="text-xs text-slate-400">
                      {selectedItem?.unitShortCode || 'units'}
                    </span>
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Adjustment Reason <span className="text-rose-400">*</span>
                </label>
                <select
                  value={adjustmentReason}
                  onChange={e => setAdjustmentReason(e.target.value as StockAdjustmentReason)}
                  className="w-full px-3.5 py-2 text-xs rounded-xl glass-input border border-slate-700 focus:outline-none focus:border-indigo-500 text-slate-100 bg-slate-950"
                >
                  <option value="PHYSICAL_COUNT_RECONCILIATION">Physical Count Reconciliation</option>
                  <option value="DAMAGED_GOODS">Damaged Goods Write-off</option>
                  <option value="EXPIRED_STOCK">Expired Stock Write-off</option>
                  <option value="THEFT_OR_LOSS">Theft / Unexplained Loss</option>
                  <option value="INVENTORY_AUDIT">Formal Institutional Audit</option>
                  <option value="FOUND_STOCK">Found / Unregistered Surplus</option>
                  <option value="OTHER">Other Reason</option>
                </select>
              </div>
            </div>
          )}

          {/* IN Specific: Unit Cost & Supplier */}
          {mode === 'IN' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Unit Cost ($ / unit)
                </label>
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  placeholder="e.g. 12.50"
                  value={unitCost}
                  onChange={e => setUnitCost(e.target.value === '' ? '' : Number(e.target.value))}
                  className="w-full px-3.5 py-2 text-xs rounded-xl glass-input border border-slate-700 focus:outline-none focus:border-indigo-500 text-slate-100"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Supplier / Vendor
                </label>
                <select
                  value={supplierId}
                  onChange={e => setSupplierId(e.target.value)}
                  className="w-full px-3.5 py-2 text-xs rounded-xl glass-input border border-slate-700 focus:outline-none focus:border-indigo-500 text-slate-100 bg-slate-950"
                >
                  <option value="">Direct / Institutional Purchase</option>
                  {suppliers.map(s => (
                    <option key={s.id} value={s.id}>
                      {s.name} ({s.supplierCode})
                    </option>
                  ))}
                </select>
              </div>
            </div>
          )}

          {/* OUT Specific: Issued To */}
          {mode === 'OUT' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Issued Target
                </label>
                <select
                  value={issuedToType}
                  onChange={e => setIssuedToType(e.target.value as any)}
                  className="w-full px-3.5 py-2 text-xs rounded-xl glass-input border border-slate-700 focus:outline-none focus:border-indigo-500 text-slate-100 bg-slate-950"
                >
                  <option value="DEPARTMENT">Department</option>
                  <option value="STAFF">Faculty / Staff Member</option>
                  <option value="STUDENT">Student</option>
                  <option value="MAINTENANCE">Facility Maintenance</option>
                  <option value="OTHER">Other Purpose</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Recipient Name / Department
                </label>
                <input
                  type="text"
                  placeholder="e.g. Science Dept, John Doe"
                  value={issuedToName}
                  onChange={e => setIssuedToName(e.target.value)}
                  className="w-full px-3.5 py-2 text-xs rounded-xl glass-input border border-slate-700 focus:outline-none focus:border-indigo-500 text-slate-100"
                />
              </div>
            </div>
          )}

          {/* RETURN Specific */}
          {mode === 'RETURN' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Returned From
                </label>
                <input
                  type="text"
                  placeholder="e.g. Science Lab, Staff Name"
                  value={returnFromName}
                  onChange={e => setReturnFromName(e.target.value)}
                  className="w-full px-3.5 py-2 text-xs rounded-xl glass-input border border-slate-700 focus:outline-none focus:border-indigo-500 text-slate-100"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Item Condition
                </label>
                <select
                  value={itemCondition}
                  onChange={e => setItemCondition(e.target.value as any)}
                  className="w-full px-3.5 py-2 text-xs rounded-xl glass-input border border-slate-700 focus:outline-none focus:border-indigo-500 text-slate-100 bg-slate-950"
                >
                  <option value="GOOD">Good / Restockable</option>
                  <option value="DAMAGED">Damaged / Needs Repair</option>
                  <option value="EXPIRED">Expired</option>
                  <option value="UNUSABLE">Unusable / Write-off</option>
                </select>
              </div>
            </div>
          )}

          {/* Batch & Expiry (Optional for IN or OPENING) */}
          {(mode === 'IN' || mode === 'OPENING') && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Batch / Lot Number (Optional)
                </label>
                <input
                  type="text"
                  placeholder="e.g. BATCH-2026-A"
                  value={batchNumber}
                  onChange={e => setBatchNumber(e.target.value)}
                  className="w-full px-3.5 py-2 text-xs rounded-xl glass-input border border-slate-700 focus:outline-none focus:border-indigo-500 text-slate-100"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Expiry Date (Optional)
                </label>
                <input
                  type="date"
                  value={expiryDate}
                  onChange={e => setExpiryDate(e.target.value)}
                  className="w-full px-3.5 py-2 text-xs rounded-xl glass-input border border-slate-700 focus:outline-none focus:border-indigo-500 text-slate-100"
                />
              </div>
            </div>
          )}

          {/* Reference Number & Remarks */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Reference / Invoice / Slip #
              </label>
              <input
                type="text"
                placeholder="e.g. INV-9041, SLIP-102"
                value={referenceNumber}
                onChange={e => setReferenceNumber(e.target.value)}
                className="w-full px-3.5 py-2 text-xs rounded-xl glass-input border border-slate-700 focus:outline-none focus:border-indigo-500 text-slate-100"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Remarks / Audit Note
              </label>
              <input
                type="text"
                placeholder="Optional notes..."
                value={remarks}
                onChange={e => setRemarks(e.target.value)}
                className="w-full px-3.5 py-2 text-xs rounded-xl glass-input border border-slate-700 focus:outline-none focus:border-indigo-500 text-slate-100"
              />
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-end space-x-3 pt-4 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              disabled={submitting}
              className="px-4 py-2 text-xs font-semibold rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting || stockChecking}
              className={`px-5 py-2 text-xs font-semibold rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white transition-all shadow-md shadow-indigo-950 flex items-center space-x-2 disabled:opacity-50`}
            >
              {submitting ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>Processing...</span>
                </>
              ) : (
                <>
                  <CheckCircle className="w-4 h-4" />
                  <span>{config.buttonLabel}</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
