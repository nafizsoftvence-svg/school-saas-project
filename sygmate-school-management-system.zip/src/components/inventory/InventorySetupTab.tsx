import React, { useState } from 'react';
import {
  Layers,
  Scale,
  Building,
  ShieldAlert,
  Plus,
  Edit2,
  Trash2,
  CheckCircle,
  Tag,
  Building2,
  MapPin,
  RefreshCw
} from 'lucide-react';
import {
  InventoryCategory,
  InventoryUnit,
  InventoryLocation,
  AssetCategory
} from '../../types';

interface InventorySetupTabProps {
  categories: InventoryCategory[];
  units: InventoryUnit[];
  locations: InventoryLocation[];
  assetCategories: AssetCategory[];
  loading: boolean;
  onRefresh: () => void;
  onOpenCategoryModal: (category?: InventoryCategory) => void;
  onDeleteCategory: (id: string) => void;
  onOpenUnitModal: (unit?: InventoryUnit) => void;
  onDeleteUnit: (id: string) => void;
  onOpenLocationModal: (location?: InventoryLocation) => void;
  onDeleteLocation: (id: string) => void;
  onOpenAssetCategoryModal: (cat?: AssetCategory) => void;
}

export const InventorySetupTab: React.FC<InventorySetupTabProps> = ({
  categories,
  units,
  locations,
  assetCategories,
  loading,
  onRefresh,
  onOpenCategoryModal,
  onDeleteCategory,
  onOpenUnitModal,
  onDeleteUnit,
  onOpenLocationModal,
  onDeleteLocation,
  onOpenAssetCategoryModal
}) => {
  const [subSection, setSubSection] = useState<'categories' | 'units' | 'locations' | 'assetCategories'>('categories');

  return (
    <div className="space-y-4">
      {/* Header and Sub-Navigation */}
      <div className="p-4 rounded-xl glass-panel border border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-semibold text-white flex items-center gap-2">
              <Layers className="w-5 h-5 text-indigo-400" />
              Inventory & Asset Foundation Setup
            </h3>
            <p className="text-xs text-slate-400">
              Configure master categories, units of measurement, physical store locations, and asset classifications
            </p>
          </div>
          <button
            onClick={onRefresh}
            disabled={loading}
            className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors disabled:opacity-50 self-start sm:self-auto"
            title="Refresh setup data"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-indigo-400' : ''}`} />
          </button>
        </div>

        {/* Sub-Tabs Selector */}
        <div className="flex flex-wrap gap-2 pt-2 border-t border-slate-800/60">
          <button
            onClick={() => setSubSection('categories')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-2 ${
              subSection === 'categories'
                ? 'bg-indigo-600 text-white'
                : 'bg-slate-800/80 hover:bg-slate-800 text-slate-300 border border-slate-700/60'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            Item Categories ({categories.length})
          </button>
          <button
            onClick={() => setSubSection('units')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-2 ${
              subSection === 'units'
                ? 'bg-indigo-600 text-white'
                : 'bg-slate-800/80 hover:bg-slate-800 text-slate-300 border border-slate-700/60'
            }`}
          >
            <Scale className="w-3.5 h-3.5" />
            Units of Measure ({units.length})
          </button>
          <button
            onClick={() => setSubSection('locations')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-2 ${
              subSection === 'locations'
                ? 'bg-indigo-600 text-white'
                : 'bg-slate-800/80 hover:bg-slate-800 text-slate-300 border border-slate-700/60'
            }`}
          >
            <Building className="w-3.5 h-3.5" />
            Stores & Locations ({locations.length})
          </button>
          <button
            onClick={() => setSubSection('assetCategories')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-2 ${
              subSection === 'assetCategories'
                ? 'bg-indigo-600 text-white'
                : 'bg-slate-800/80 hover:bg-slate-800 text-slate-300 border border-slate-700/60'
            }`}
          >
            <Tag className="w-3.5 h-3.5" />
            Asset Categories ({assetCategories.length})
          </button>
        </div>
      </div>

      {/* 1. Item Categories Sub-Section */}
      {subSection === 'categories' && (
        <div className="rounded-xl glass-panel border border-slate-800 overflow-hidden">
          <div className="p-4 bg-slate-900/40 border-b border-slate-800 flex items-center justify-between">
            <div>
              <h4 className="text-sm font-semibold text-white">Inventory Item Categories</h4>
              <p className="text-xs text-slate-400">Classify consumable items, books, uniforms, sports gear, etc.</p>
            </div>
            <button
              onClick={() => onOpenCategoryModal()}
              className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white transition-colors flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              Add Category
            </button>
          </div>

          <div className="divide-y divide-slate-800/60">
            {categories.length === 0 ? (
              <div className="p-8 text-center text-slate-400 text-sm">
                No categories defined.
              </div>
            ) : (
              categories.map((cat) => (
                <div key={cat.id} className="p-4 hover:bg-slate-800/20 transition-colors flex items-center justify-between">
                  <div className="space-y-1">
                    <div className="flex items-center space-x-2">
                      <span className="font-mono text-xs px-2 py-0.5 rounded bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 font-medium">
                        {cat.code}
                      </span>
                      <span className="text-sm font-semibold text-white">{cat.name}</span>
                    </div>
                    {cat.description && (
                      <p className="text-xs text-slate-400">{cat.description}</p>
                    )}
                  </div>
                  <div className="flex items-center space-x-2">
                    <span
                      className={`px-2 py-0.5 text-xs font-semibold rounded-full border ${
                        cat.status === 'ACTIVE'
                          ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                          : 'bg-slate-500/10 text-slate-400 border-slate-500/20'
                      }`}
                    >
                      {cat.status}
                    </span>
                    <button
                      onClick={() => onOpenCategoryModal(cat)}
                      className="p-1.5 rounded-lg hover:bg-slate-700/60 text-slate-400 hover:text-slate-200 transition-colors"
                      title="Edit Category"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => {
                        if (window.confirm(`Delete category '${cat.name}'?`)) {
                          onDeleteCategory(cat.id);
                        }
                      }}
                      className="p-1.5 rounded-lg hover:bg-rose-500/10 text-slate-400 hover:text-rose-400 transition-colors"
                      title="Delete Category"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* 2. Units of Measurement Sub-Section */}
      {subSection === 'units' && (
        <div className="rounded-xl glass-panel border border-slate-800 overflow-hidden">
          <div className="p-4 bg-slate-900/40 border-b border-slate-800 flex items-center justify-between">
            <div>
              <h4 className="text-sm font-semibold text-white">Units of Measurement (UOM)</h4>
              <p className="text-xs text-slate-400">Standard measurement units for inventory goods (e.g. PCS, BOX, PACK, KG)</p>
            </div>
            <button
              onClick={() => onOpenUnitModal()}
              className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white transition-colors flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              Add Unit
            </button>
          </div>

          <div className="divide-y divide-slate-800/60">
            {units.length === 0 ? (
              <div className="p-8 text-center text-slate-400 text-sm">
                No units of measurement configured.
              </div>
            ) : (
              units.map((unit) => (
                <div key={unit.id} className="p-4 hover:bg-slate-800/20 transition-colors flex items-center justify-between">
                  <div className="space-y-1">
                    <div className="flex items-center space-x-2">
                      <span className="font-mono text-xs px-2.5 py-0.5 rounded bg-purple-500/10 text-purple-400 border border-purple-500/20 font-bold">
                        {unit.shortCode}
                      </span>
                      <span className="text-sm font-semibold text-white">{unit.name}</span>
                    </div>
                    {unit.description && (
                      <p className="text-xs text-slate-400">{unit.description}</p>
                    )}
                  </div>
                  <div className="flex items-center space-x-2">
                    <span
                      className={`px-2 py-0.5 text-xs font-semibold rounded-full border ${
                        unit.status === 'ACTIVE'
                          ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                          : 'bg-slate-500/10 text-slate-400 border-slate-500/20'
                      }`}
                    >
                      {unit.status}
                    </span>
                    <button
                      onClick={() => onOpenUnitModal(unit)}
                      className="p-1.5 rounded-lg hover:bg-slate-700/60 text-slate-400 hover:text-slate-200 transition-colors"
                      title="Edit Unit"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => {
                        if (window.confirm(`Delete unit '${unit.name}' (${unit.shortCode})?`)) {
                          onDeleteUnit(unit.id);
                        }
                      }}
                      className="p-1.5 rounded-lg hover:bg-rose-500/10 text-slate-400 hover:text-rose-400 transition-colors"
                      title="Delete Unit"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* 3. Stores & Locations Sub-Section */}
      {subSection === 'locations' && (
        <div className="rounded-xl glass-panel border border-slate-800 overflow-hidden">
          <div className="p-4 bg-slate-900/40 border-b border-slate-800 flex items-center justify-between">
            <div>
              <h4 className="text-sm font-semibold text-white">Institutional Stores & Facilities</h4>
              <p className="text-xs text-slate-400">Physical warehouses, storerooms, labs, and staff custodian assignments</p>
            </div>
            <button
              onClick={() => onOpenLocationModal()}
              className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white transition-colors flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              Add Location
            </button>
          </div>

          <div className="divide-y divide-slate-800/60">
            {locations.length === 0 ? (
              <div className="p-8 text-center text-slate-400 text-sm">
                No locations configured.
              </div>
            ) : (
              locations.map((loc) => (
                <div key={loc.id} className="p-4 hover:bg-slate-800/20 transition-colors flex items-center justify-between">
                  <div className="space-y-1">
                    <div className="flex items-center space-x-2">
                      <span className="font-mono text-xs px-2 py-0.5 rounded bg-blue-500/10 text-blue-400 border border-blue-500/20 font-medium">
                        {loc.code}
                      </span>
                      <span className="text-sm font-semibold text-white">{loc.name}</span>
                    </div>
                    <div className="flex items-center space-x-3 text-xs text-slate-400">
                      {loc.department && (
                        <span>Dept: <strong className="text-slate-300 font-medium">{loc.department}</strong></span>
                      )}
                      {loc.responsibleStaffName && (
                        <>
                          <span>•</span>
                          <span>Custodian: <strong className="text-slate-300 font-medium">{loc.responsibleStaffName}</strong></span>
                        </>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span
                      className={`px-2 py-0.5 text-xs font-semibold rounded-full border ${
                        loc.status === 'ACTIVE'
                          ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                          : 'bg-slate-500/10 text-slate-400 border-slate-500/20'
                      }`}
                    >
                      {loc.status}
                    </span>
                    <button
                      onClick={() => onOpenLocationModal(loc)}
                      className="p-1.5 rounded-lg hover:bg-slate-700/60 text-slate-400 hover:text-slate-200 transition-colors"
                      title="Edit Location"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => {
                        if (window.confirm(`Delete location '${loc.name}'?`)) {
                          onDeleteLocation(loc.id);
                        }
                      }}
                      className="p-1.5 rounded-lg hover:bg-rose-500/10 text-slate-400 hover:text-rose-400 transition-colors"
                      title="Delete Location"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* 4. Asset Categories Sub-Section */}
      {subSection === 'assetCategories' && (
        <div className="rounded-xl glass-panel border border-slate-800 overflow-hidden">
          <div className="p-4 bg-slate-900/40 border-b border-slate-800 flex items-center justify-between">
            <div>
              <h4 className="text-sm font-semibold text-white">Asset Classification Categories</h4>
              <p className="text-xs text-slate-400">Classify institutional capital assets (e.g. IT Equipment, Furniture, Vehicles, Lab Gear)</p>
            </div>
            <button
              onClick={() => onOpenAssetCategoryModal()}
              className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white transition-colors flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              Add Asset Category
            </button>
          </div>

          <div className="divide-y divide-slate-800/60">
            {assetCategories.length === 0 ? (
              <div className="p-8 text-center text-slate-400 text-sm">
                No asset categories defined.
              </div>
            ) : (
              assetCategories.map((acat) => (
                <div key={acat.id} className="p-4 hover:bg-slate-800/20 transition-colors flex items-center justify-between">
                  <div className="space-y-1">
                    <div className="flex items-center space-x-2">
                      <span className="font-mono text-xs px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-medium">
                        {acat.code}
                      </span>
                      <span className="text-sm font-semibold text-white">{acat.name}</span>
                    </div>
                    {acat.description && (
                      <p className="text-xs text-slate-400">{acat.description}</p>
                    )}
                  </div>
                  <div className="flex items-center space-x-2">
                    <span
                      className={`px-2 py-0.5 text-xs font-semibold rounded-full border ${
                        acat.status === 'ACTIVE'
                          ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                          : 'bg-slate-500/10 text-slate-400 border-slate-500/20'
                      }`}
                    >
                      {acat.status}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
};
