/**
 * Procurement Management Tab (Part 14D)
 *
 * Implements the full procurement workflow UI:
 * 1. Summary KPI cards (Requisitions, Open Orders, Fulfillment, Total Spend)
 * 2. Tabbed sub-views:
 *    - Purchase Requests (Submit, Review/Approve, Convert to PO)
 *    - Purchase Orders (Create, Approve, Send to Supplier, Receive Physical Goods, Cancel)
 *    - Goods Receipts / GRN Log (Authoritative audit trail of received goods and inspections)
 *    - Vendor Performance & Procurement Analytics
 */

import React, { useState, useEffect } from 'react';
import {
  FileText,
  ShoppingCart,
  PackageCheck,
  TrendingUp,
  Plus,
  Search,
  Filter,
  RefreshCw,
  Clock,
  CheckCircle2,
  XCircle,
  Truck,
  Building,
  Calendar,
  AlertTriangle,
  ArrowRight,
  ShieldCheck,
  Boxes,
  DollarSign,
  Eye,
  Send,
  Ban
} from 'lucide-react';
import { api } from '../../services/api';
import {
  PurchaseRequest,
  PurchaseOrder,
  GoodsReceipt,
  ProcurementDashboardSummary,
  InventoryItem,
  Supplier,
  InventoryLocation,
  CreatePurchaseRequestPayload,
  CreatePurchaseOrderPayload,
  ReceiveGoodsPayload
} from '../../types';
import { GoodsReceivingModal } from './GoodsReceivingModal';
import { CreatePurchaseRequestModal } from './CreatePurchaseRequestModal';
import { CreatePurchaseOrderModal } from './CreatePurchaseOrderModal';

interface ProcurementTabProps {
  items: InventoryItem[];
  suppliers: Supplier[];
  locations: InventoryLocation[];
  onNotification: (msg: string, isError?: boolean) => void;
  onRefreshAllData?: () => void;
}

export const ProcurementTab: React.FC<ProcurementTabProps> = ({
  items,
  suppliers,
  locations,
  onNotification,
  onRefreshAllData
}) => {
  const [subView, setSubView] = useState<'requests' | 'orders' | 'receiving' | 'vendors'>('orders');
  const [loading, setLoading] = useState(false);
  const [dashboard, setDashboard] = useState<ProcurementDashboardSummary | null>(null);

  // Lists
  const [purchaseRequests, setPurchaseRequests] = useState<PurchaseRequest[]>([]);
  const [purchaseOrders, setPurchaseOrders] = useState<PurchaseOrder[]>([]);
  const [goodsReceipts, setGoodsReceipts] = useState<GoodsReceipt[]>([]);

  // Search & Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');

  // Modals
  const [isPRModalOpen, setIsPRModalOpen] = useState(false);
  const [isPOModalOpen, setIsPOModalOpen] = useState(false);
  const [selectedPOForReceiving, setSelectedPOForReceiving] = useState<PurchaseOrder | null>(null);

  // Details expansion
  const [expandedRequestId, setExpandedRequestId] = useState<string | null>(null);
  const [expandedOrderId, setExpandedOrderId] = useState<string | null>(null);
  const [expandedReceiptId, setExpandedReceiptId] = useState<string | null>(null);

  // Load Data
  const loadProcurementData = async () => {
    try {
      setLoading(true);
      const [dashRes, prRes, poRes, grRes] = await Promise.all([
        api.inventory.getProcurementDashboard().catch(() => null),
        api.inventory.getPurchaseRequests({ limit: 100 }).catch(() => ({ data: [] })),
        api.inventory.getPurchaseOrders({ limit: 100 }).catch(() => ({ data: [] })),
        api.inventory.getGoodsReceipts({ limit: 100 }).catch(() => ({ data: [] }))
      ]);

      const extractArray = (res: any) => {
        if (!res) return [];
        if (Array.isArray(res)) return res;
        if (Array.isArray(res.data)) return res.data;
        if (Array.isArray(res.items)) return res.items;
        return [];
      };

      if (dashRes) setDashboard((dashRes as any)?.data ?? dashRes);
      setPurchaseRequests(extractArray(prRes));
      setPurchaseOrders(extractArray(poRes));
      setGoodsReceipts(extractArray(grRes));
    } catch (err: any) {
      onNotification(err.message || 'Failed to load procurement data', true);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadProcurementData();
  }, []);

  const safeItems = Array.isArray(items) ? items : [];
  const safeSuppliers = Array.isArray(suppliers) ? suppliers : [];
  const safeLocations = Array.isArray(locations) ? locations : [];
  const safePurchaseOrders = Array.isArray(purchaseOrders) ? purchaseOrders : [];
  const safePurchaseRequests = Array.isArray(purchaseRequests) ? purchaseRequests : [];
  const safeGoodsReceipts = Array.isArray(goodsReceipts) ? goodsReceipts : [];

  // Request Handlers
  const handleCreatePurchaseRequest = async (payload: CreatePurchaseRequestPayload) => {
    try {
      const res = await api.inventory.createPurchaseRequest(payload);
      onNotification(res.message || 'Purchase request created successfully.');
      loadProcurementData();
    } catch (err: any) {
      onNotification(err.message || 'Failed to submit purchase request', true);
    }
  };

  const handleReviewPurchaseRequest = async (id: string, decision: 'APPROVE' | 'REJECT', notes?: string) => {
    try {
      const res = await api.inventory.reviewPurchaseRequest(id, { decision, reviewNotes: notes });
      onNotification(res.message || `Purchase request ${decision.toLowerCase()}d.`);
      loadProcurementData();
    } catch (err: any) {
      onNotification(err.message || 'Failed to review purchase request', true);
    }
  };

  const handleConvertToPO = async (prId: string, supplierId?: string) => {
    try {
      const defaultSupplier = supplierId || suppliers[0]?.id;
      if (!defaultSupplier) {
        onNotification('Please select or register a vendor first', true);
        return;
      }
      const res = await api.inventory.convertRequestToPO(prId, { supplierId: defaultSupplier });
      const poNum = (res as any)?.data?.poNumber || (res as any)?.poNumber || 'New PO';
      onNotification(`PO ${poNum} generated successfully from requisition.`);
      setSubView('orders');
      loadProcurementData();
    } catch (err: any) {
      onNotification(err.message || 'Failed to convert request to PO', true);
    }
  };

  // PO Handlers
  const handleCreatePurchaseOrder = async (payload: CreatePurchaseOrderPayload) => {
    try {
      const res = await api.inventory.createPurchaseOrder(payload);
      onNotification(res.message || 'Purchase order created successfully.');
      loadProcurementData();
    } catch (err: any) {
      onNotification(err.message || 'Failed to create purchase order', true);
    }
  };

  const handleReviewPO = async (id: string, decision: 'APPROVE' | 'REJECT') => {
    try {
      const res = await api.inventory.reviewPurchaseOrder(id, { decision });
      onNotification(res.message || `Purchase order ${decision.toLowerCase()}d.`);
      loadProcurementData();
    } catch (err: any) {
      onNotification(err.message || 'Failed to review PO', true);
    }
  };

  const handleSendPO = async (id: string) => {
    try {
      const res = await api.inventory.markPurchaseOrderSent(id);
      onNotification(res.message || 'PO marked sent to supplier.');
      loadProcurementData();
    } catch (err: any) {
      onNotification(err.message || 'Failed to send PO', true);
    }
  };

  const handleCancelPO = async (id: string) => {
    const reason = window.prompt('Enter reason for cancelling this order:') || 'Order cancelled by administrator';
    try {
      const res = await api.inventory.cancelPurchaseOrder(id, reason);
      onNotification(res.message || 'PO cancelled.');
      loadProcurementData();
    } catch (err: any) {
      onNotification(err.message || 'Failed to cancel PO', true);
    }
  };

  // Goods Receiving Submit
  const handleReceiveGoods = async (poId: string, payload: ReceiveGoodsPayload) => {
    try {
      const res = await api.inventory.receiveGoods(poId, payload);
      onNotification(res.message || 'Goods received and physical inventory updated.');
      loadProcurementData();
      if (onRefreshAllData) onRefreshAllData();
    } catch (err: any) {
      onNotification(err.message || 'Failed to process goods receiving', true);
      throw err;
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Open POs */}
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Open Purchase Orders
            </span>
            <div className="p-2 bg-indigo-500/10 border border-indigo-500/20 rounded-xl text-indigo-400">
              <ShoppingCart className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-white">
              {dashboard?.openPoCount ?? safePurchaseOrders.filter(p => ['APPROVED', 'SENT_TO_SUPPLIER', 'PARTIALLY_RECEIVED'].includes(p.status)).length}
            </span>
            <span className="text-xs text-slate-400">active commitments</span>
          </div>
          <div className="mt-2 text-[11px] text-indigo-400 flex items-center gap-1">
            <span>{safePurchaseOrders.filter(p => p.status === 'PARTIALLY_RECEIVED').length} partially received</span>
          </div>
        </div>

        {/* Pending Requisitions */}
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Pending Requisitions
            </span>
            <div className="p-2 bg-amber-500/10 border border-amber-500/20 rounded-xl text-amber-400">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-white">
              {dashboard?.pendingRequestCount ?? safePurchaseRequests.filter(r => ['SUBMITTED', 'UNDER_REVIEW'].includes(r.status)).length}
            </span>
            <span className="text-xs text-slate-400">awaiting approval</span>
          </div>
          <div className="mt-2 text-[11px] text-amber-400 flex items-center gap-1">
            <span>{safePurchaseRequests.filter(r => r.status === 'APPROVED').length} ready for PO</span>
          </div>
        </div>

        {/* Goods Receipts Logged */}
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Goods Receipts (GRNs)
            </span>
            <div className="p-2 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-emerald-400">
              <PackageCheck className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-white">
              {goodsReceipts.length}
            </span>
            <span className="text-xs text-slate-400">stock intake batches</span>
          </div>
          <div className="mt-2 text-[11px] text-emerald-400 flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Strict quality inspection</span>
          </div>
        </div>

        {/* Total Spend */}
        <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Total Order Commitments
            </span>
            <div className="p-2 bg-purple-500/10 border border-purple-500/20 rounded-xl text-purple-400">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-white">
              ${(dashboard?.totalProcurementSpent ?? purchaseOrders.reduce((sum, po) => sum + po.grandTotal, 0)).toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
            </span>
          </div>
          <div className="mt-2 text-[11px] text-purple-400">
            Across {purchaseOrders.length} total orders
          </div>
        </div>
      </div>

      {/* Sub-view Navigation Bar & Action Buttons */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 border-b border-slate-800 pb-3">
        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto">
          <button
            onClick={() => setSubView('orders')}
            className={`px-3.5 py-1.5 text-xs font-semibold rounded-xl transition-all flex items-center gap-2 whitespace-nowrap ${
              subView === 'orders'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <ShoppingCart className="w-3.5 h-3.5" />
            Purchase Orders
            <span className="px-1.5 py-0.2 rounded-full text-[10px] font-mono bg-slate-800 border border-slate-700">
              {purchaseOrders.length}
            </span>
          </button>

          <button
            onClick={() => setSubView('requests')}
            className={`px-3.5 py-1.5 text-xs font-semibold rounded-xl transition-all flex items-center gap-2 whitespace-nowrap ${
              subView === 'requests'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            Purchase Requests
            <span className="px-1.5 py-0.2 rounded-full text-[10px] font-mono bg-slate-800 border border-slate-700">
              {purchaseRequests.length}
            </span>
          </button>

          <button
            onClick={() => setSubView('receiving')}
            className={`px-3.5 py-1.5 text-xs font-semibold rounded-xl transition-all flex items-center gap-2 whitespace-nowrap ${
              subView === 'receiving'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <PackageCheck className="w-3.5 h-3.5" />
            Goods Receipts (GRN)
            <span className="px-1.5 py-0.2 rounded-full text-[10px] font-mono bg-slate-800 border border-slate-700">
              {goodsReceipts.length}
            </span>
          </button>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={loadProcurementData}
            disabled={loading}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors"
            title="Refresh procurement data"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-indigo-400' : ''}`} />
          </button>

          <button
            onClick={() => setIsPRModalOpen(true)}
            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            <Plus className="w-3.5 h-3.5 text-amber-400" />
            New Requisition
          </button>

          <button
            onClick={() => setIsPOModalOpen(true)}
            className="px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-lg shadow-indigo-950 flex items-center gap-1.5 transition-all"
          >
            <Plus className="w-3.5 h-3.5" />
            Create Purchase Order
          </button>
        </div>
      </div>

      {/* SUBVIEW 1: PURCHASE ORDERS */}
      {subView === 'orders' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="relative w-full sm:w-72">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Search PO #, supplier, notes..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-xs rounded-xl bg-slate-800 border border-slate-700 text-white focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="px-3 py-2 text-xs rounded-xl bg-slate-800 border border-slate-700 text-slate-300 focus:outline-none focus:border-indigo-500"
              >
                <option value="ALL">All Statuses</option>
                <option value="PENDING_APPROVAL">Pending Approval</option>
                <option value="APPROVED">Approved</option>
                <option value="SENT_TO_SUPPLIER">Sent to Supplier</option>
                <option value="PARTIALLY_RECEIVED">Partially Received</option>
                <option value="FULLY_RECEIVED">Fully Received</option>
                <option value="CANCELLED">Cancelled</option>
              </select>
            </div>
          </div>

          {/* Orders Table */}
          <div className="border border-slate-800 rounded-2xl overflow-hidden bg-slate-900 shadow-xl">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-850/80 text-slate-400 text-[11px] uppercase tracking-wider border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4">PO Number</th>
                  <th className="py-3 px-4">Supplier</th>
                  <th className="py-3 px-4">Order Date</th>
                  <th className="py-3 px-4 text-center">Items</th>
                  <th className="py-3 px-4 text-right">Grand Total</th>
                  <th className="py-3 px-4 text-center">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80 text-slate-200">
                {safePurchaseOrders
                  .filter(po => {
                    const matchSearch =
                      po.poNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
                      po.supplierName.toLowerCase().includes(searchQuery.toLowerCase()) ||
                      (po.notes && po.notes.toLowerCase().includes(searchQuery.toLowerCase()));
                    const matchStatus = statusFilter === 'ALL' || po.status === statusFilter;
                    return matchSearch && matchStatus;
                  })
                  .map(po => {
                    const isExpanded = expandedOrderId === po.id;
                    const canReceive = ['APPROVED', 'SENT_TO_SUPPLIER', 'PARTIALLY_RECEIVED'].includes(po.status);

                    return (
                      <React.Fragment key={po.id}>
                        <tr className="hover:bg-slate-800/40 transition-colors">
                          <td className="py-3 px-4">
                            <div className="font-mono font-bold text-indigo-400 flex items-center gap-1.5">
                              {po.poNumber}
                            </div>
                            <div className="text-[10px] text-slate-400">Created by {po.createdByName}</div>
                          </td>
                          <td className="py-3 px-4">
                            <div className="font-medium text-white">{po.supplierName}</div>
                            <div className="text-[10px] text-slate-400">Terms: {po.paymentTerms || 'Standard'}</div>
                          </td>
                          <td className="py-3 px-4 text-slate-300">
                            {new Date(po.orderDate).toLocaleDateString()}
                          </td>
                          <td className="py-3 px-4 text-center font-mono">
                            <span className="px-2 py-0.5 rounded-full bg-slate-800 border border-slate-700 text-slate-300">
                              {po.items?.length || 0} lines
                            </span>
                          </td>
                          <td className="py-3 px-4 text-right font-mono font-semibold text-white">
                            ${Number(po.grandTotal ?? 0).toFixed(2)}
                          </td>
                          <td className="py-3 px-4 text-center">
                            <span
                              className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider border ${
                                po.status === 'FULLY_RECEIVED'
                                  ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                                  : po.status === 'PARTIALLY_RECEIVED'
                                  ? 'bg-amber-500/10 text-amber-400 border-amber-500/20'
                                  : po.status === 'SENT_TO_SUPPLIER'
                                  ? 'bg-blue-500/10 text-blue-400 border-blue-500/20'
                                  : po.status === 'APPROVED'
                                  ? 'bg-teal-500/10 text-teal-400 border-teal-500/20'
                                  : po.status === 'CANCELLED'
                                  ? 'bg-rose-500/10 text-rose-400 border-rose-500/20'
                                  : 'bg-slate-700/50 text-slate-300 border-slate-600'
                              }`}
                            >
                              {po.status.replace(/_/g, ' ')}
                            </span>
                          </td>
                          <td className="py-3 px-4 text-right space-x-1.5 whitespace-nowrap">
                            {/* Toggle items */}
                            <button
                              onClick={() => setExpandedOrderId(isExpanded ? null : po.id)}
                              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
                              title="Toggle line items"
                            >
                              <Eye className="w-3.5 h-3.5" />
                            </button>

                            {/* Approval buttons */}
                            {po.status === 'PENDING_APPROVAL' && (
                              <>
                                <button
                                  onClick={() => handleReviewPO(po.id, 'APPROVE')}
                                  className="px-2 py-1 rounded-lg bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-400 border border-emerald-500/30 text-[11px] font-semibold transition-colors"
                                >
                                  Approve
                                </button>
                                <button
                                  onClick={() => handleReviewPO(po.id, 'REJECT')}
                                  className="px-2 py-1 rounded-lg bg-rose-600/20 hover:bg-rose-600/30 text-rose-400 border border-rose-500/30 text-[11px] font-semibold transition-colors"
                                >
                                  Reject
                                </button>
                              </>
                            )}

                            {/* Mark sent */}
                            {po.status === 'APPROVED' && (
                              <button
                                onClick={() => handleSendPO(po.id)}
                                className="px-2 py-1 rounded-lg bg-blue-600/20 hover:bg-blue-600/30 text-blue-400 border border-blue-500/30 text-[11px] font-semibold transition-colors"
                              >
                                Send to Supplier
                              </button>
                            )}

                            {/* Physical Goods Receiving */}
                            {canReceive && (
                              <button
                                onClick={() => setSelectedPOForReceiving(po)}
                                className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-bold shadow-md shadow-emerald-950 transition-all inline-flex items-center gap-1"
                              >
                                <PackageCheck className="w-3.5 h-3.5" />
                                Receive Goods
                              </button>
                            )}

                            {/* Cancel PO */}
                            {['PENDING_APPROVAL', 'APPROVED', 'SENT_TO_SUPPLIER'].includes(po.status) && (
                              <button
                                onClick={() => handleCancelPO(po.id)}
                                className="p-1.5 rounded-lg bg-slate-800 hover:bg-rose-950/40 text-slate-400 hover:text-rose-400 transition-colors"
                                title="Cancel Order"
                              >
                                <Ban className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </td>
                        </tr>

                        {/* Expanded details row */}
                        {isExpanded && (
                          <tr className="bg-slate-950/60 border-y border-slate-800">
                            <td colSpan={7} className="p-4">
                              <div className="space-y-3">
                                <div className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                                  <Boxes className="w-3.5 h-3.5 text-indigo-400" />
                                  Ordered Line Items & Fulfillment Status
                                </div>
                                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
                                  {po.items.map(item => (
                                    <div
                                      key={item.id}
                                      className="p-3 bg-slate-900 border border-slate-800 rounded-xl space-y-1.5 text-xs"
                                    >
                                      <div className="flex justify-between items-start">
                                        <div className="font-semibold text-white">{item.itemName}</div>
                                        <span className="font-mono text-indigo-400 text-[10px]">{item.itemCode}</span>
                                      </div>
                                      <div className="flex justify-between text-slate-400 text-[11px]">
                                        <span>Ordered: <strong className="text-white">{item.quantityOrdered}</strong></span>
                                        <span>Received: <strong className="text-emerald-400">{item.quantityReceived}</strong></span>
                                        <span>Remaining: <strong className="text-amber-400">{item.quantityRemaining}</strong></span>
                                      </div>
                                      <div className="text-[11px] text-slate-400">
                                        Unit Price: ${Number(item.unitPrice ?? 0).toFixed(2)} • Line Total: ${Number(item.totalPrice ?? (item.quantityOrdered * (item.unitPrice || 0))).toFixed(2)}
                                      </div>
                                    </div>
                                  ))}
                                </div>
                                {po.deliveryInstructions && (
                                  <div className="text-[11px] text-slate-400 bg-slate-900/60 p-2 rounded-lg border border-slate-800">
                                    <strong>Delivery Instructions:</strong> {po.deliveryInstructions}
                                  </div>
                                )}
                              </div>
                            </td>
                          </tr>
                        )}
                      </React.Fragment>
                    );
                  })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* SUBVIEW 2: PURCHASE REQUESTS */}
      {subView === 'requests' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="relative w-full sm:w-72">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Search PR #, department, purpose..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-xs rounded-xl bg-slate-800 border border-slate-700 text-white focus:outline-none focus:border-indigo-500"
              />
            </div>
          </div>

          <div className="border border-slate-800 rounded-2xl overflow-hidden bg-slate-900 shadow-xl">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-850/80 text-slate-400 text-[11px] uppercase tracking-wider border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4">Request #</th>
                  <th className="py-3 px-4">Department</th>
                  <th className="py-3 px-4">Priority</th>
                  <th className="py-3 px-4">Purpose</th>
                  <th className="py-3 px-4 text-center">Items</th>
                  <th className="py-3 px-4 text-right">Est. Amount</th>
                  <th className="py-3 px-4 text-center">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80 text-slate-200">
                {safePurchaseRequests
                  .filter(pr => {
                    const q = searchQuery.toLowerCase();
                    return (
                      pr.requestNumber.toLowerCase().includes(q) ||
                      pr.departmentName.toLowerCase().includes(q) ||
                      pr.purpose.toLowerCase().includes(q)
                    );
                  })
                  .map(pr => {
                    const isExpanded = expandedRequestId === pr.id;

                    return (
                      <React.Fragment key={pr.id}>
                        <tr className="hover:bg-slate-800/40 transition-colors">
                          <td className="py-3 px-4 font-mono font-bold text-amber-400">
                            {pr.requestNumber}
                          </td>
                          <td className="py-3 px-4">
                            <div className="font-medium text-white">{pr.departmentName}</div>
                            <div className="text-[10px] text-slate-400">Req by {pr.requesterName}</div>
                          </td>
                          <td className="py-3 px-4">
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                pr.priority === 'URGENT'
                                  ? 'bg-rose-500/20 text-rose-300'
                                  : pr.priority === 'HIGH'
                                  ? 'bg-amber-500/20 text-amber-300'
                                  : 'bg-slate-800 text-slate-300'
                              }`}
                            >
                              {pr.priority}
                            </span>
                          </td>
                          <td className="py-3 px-4 text-slate-300 max-w-xs truncate" title={pr.purpose}>
                            {pr.purpose}
                          </td>
                          <td className="py-3 px-4 text-center font-mono">
                            {pr.items?.length || 0} lines
                          </td>
                          <td className="py-3 px-4 text-right font-mono font-semibold text-emerald-400">
                            ${Number(pr.totalEstimatedAmount ?? 0).toFixed(2)}
                          </td>
                          <td className="py-3 px-4 text-center">
                            <span
                              className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider border ${
                                pr.status === 'APPROVED'
                                  ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                                  : pr.status === 'CONVERTED_TO_PO'
                                  ? 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20'
                                  : pr.status === 'REJECTED'
                                  ? 'bg-rose-500/10 text-rose-400 border-rose-500/20'
                                  : 'bg-amber-500/10 text-amber-400 border-amber-500/20'
                              }`}
                            >
                              {pr.status.replace(/_/g, ' ')}
                            </span>
                          </td>
                          <td className="py-3 px-4 text-right space-x-1.5 whitespace-nowrap">
                            <button
                              onClick={() => setExpandedRequestId(isExpanded ? null : pr.id)}
                              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300"
                              title="Toggle line items"
                            >
                              <Eye className="w-3.5 h-3.5" />
                            </button>

                            {['SUBMITTED', 'DRAFT'].includes(pr.status) && (
                              <>
                                <button
                                  onClick={() => handleReviewPurchaseRequest(pr.id, 'APPROVE')}
                                  className="px-2 py-1 rounded-lg bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-400 border border-emerald-500/30 text-[11px] font-semibold"
                                >
                                  Approve
                                </button>
                                <button
                                  onClick={() => handleReviewPurchaseRequest(pr.id, 'REJECT')}
                                  className="px-2 py-1 rounded-lg bg-rose-600/20 hover:bg-rose-600/30 text-rose-400 border border-rose-500/30 text-[11px] font-semibold"
                                >
                                  Reject
                                </button>
                              </>
                            )}

                            {pr.status === 'APPROVED' && (
                              <button
                                onClick={() => handleConvertToPO(pr.id)}
                                className="px-2.5 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-[11px] font-bold shadow-md shadow-indigo-950 inline-flex items-center gap-1"
                              >
                                <ShoppingCart className="w-3.5 h-3.5" />
                                Convert to PO
                              </button>
                            )}
                          </td>
                        </tr>

                        {isExpanded && (
                          <tr className="bg-slate-950/60 border-y border-slate-800">
                            <td colSpan={8} className="p-4">
                              <div className="space-y-3">
                                <div className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                                  Requested Requisition Lines
                                </div>
                                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
                                  {pr.items.map(item => (
                                    <div
                                      key={item.id}
                                      className="p-3 bg-slate-900 border border-slate-800 rounded-xl space-y-1 text-xs"
                                    >
                                      <div className="font-semibold text-white">{item.itemName}</div>
                                      <div className="font-mono text-amber-400 text-[10px]">{item.itemCode}</div>
                                      <div className="flex justify-between text-slate-400 text-[11px]">
                                        <span>Quantity: {item.quantity}</span>
                                        <span>Est. Cost: ${Number(item.estimatedUnitCost ?? 0).toFixed(2)}</span>
                                        <span className="text-white font-semibold">${Number(item.totalEstimatedCost ?? (item.quantity * (item.estimatedUnitCost || 0))).toFixed(2)}</span>
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            </td>
                          </tr>
                        )}
                      </React.Fragment>
                    );
                  })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* SUBVIEW 3: GOODS RECEIPTS (GRN LOG) */}
      {subView === 'receiving' && (
        <div className="space-y-4">
          <div className="border border-slate-800 rounded-2xl overflow-hidden bg-slate-900 shadow-xl">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-850/80 text-slate-400 text-[11px] uppercase tracking-wider border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4">GRN #</th>
                  <th className="py-3 px-4">PO Number</th>
                  <th className="py-3 px-4">Supplier</th>
                  <th className="py-3 px-4">Warehouse Location</th>
                  <th className="py-3 px-4">Intake Date</th>
                  <th className="py-3 px-4 text-center">Accepted Units (Stock In)</th>
                  <th className="py-3 px-4 text-center">Rejected Units</th>
                  <th className="py-3 px-4 text-right">Inspector</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80 text-slate-200">
                {safeGoodsReceipts.map(grn => {
                  const isExpanded = expandedReceiptId === grn.id;

                  return (
                    <React.Fragment key={grn.id}>
                      <tr
                        onClick={() => setExpandedReceiptId(isExpanded ? null : grn.id)}
                        className="hover:bg-slate-800/40 transition-colors cursor-pointer"
                      >
                        <td className="py-3 px-4 font-mono font-bold text-emerald-400">
                          {grn.receiptNumber}
                        </td>
                        <td className="py-3 px-4 font-mono text-indigo-400">
                          {grn.poNumber}
                        </td>
                        <td className="py-3 px-4 font-medium text-white">
                          {grn.supplierName}
                        </td>
                        <td className="py-3 px-4 text-slate-300">
                          {grn.receivingLocationName}
                        </td>
                        <td className="py-3 px-4 text-slate-300">
                          {new Date(grn.receiptDate).toLocaleDateString()}
                        </td>
                        <td className="py-3 px-4 text-center">
                          <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-mono font-bold">
                            +{grn.totalAcceptedQty}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-center">
                          {grn.totalRejectedQty > 0 ? (
                            <span className="px-2.5 py-0.5 rounded-full bg-rose-500/10 text-rose-400 border border-rose-500/20 font-mono font-bold">
                              {grn.totalRejectedQty}
                            </span>
                          ) : (
                            <span className="text-slate-500 font-mono">0</span>
                          )}
                        </td>
                        <td className="py-3 px-4 text-right text-slate-400">
                          {grn.receivedByName}
                        </td>
                      </tr>

                      {isExpanded && (
                        <tr className="bg-slate-950/60 border-y border-slate-800">
                          <td colSpan={8} className="p-4">
                            <div className="space-y-3">
                              <div className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                                <PackageCheck className="w-3.5 h-3.5 text-emerald-400" />
                                Goods Receipt Line Details
                              </div>
                              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
                                {grn.items.map(item => (
                                  <div
                                    key={item.id}
                                    className="p-3 bg-slate-900 border border-slate-800 rounded-xl space-y-1 text-xs"
                                  >
                                    <div className="font-semibold text-white">{item.itemName}</div>
                                    <div className="flex justify-between text-slate-400 text-[11px]">
                                      <span>Received: <strong className="text-white">{item.quantityReceived}</strong></span>
                                      <span>Accepted: <strong className="text-emerald-400">{item.quantityAccepted}</strong></span>
                                      {item.quantityRejected > 0 && (
                                        <span>Rejected: <strong className="text-rose-400">{item.quantityRejected}</strong></span>
                                      )}
                                    </div>
                                    {item.rejectionReason && (
                                      <div className="text-[10px] text-rose-400 italic">
                                        Rejection note: {item.rejectionReason}
                                      </div>
                                    )}
                                  </div>
                                ))}
                              </div>
                              {grn.remarks && (
                                <div className="text-[11px] text-slate-400 bg-slate-900/60 p-2 rounded-lg border border-slate-800">
                                  <strong>Inspection Remarks:</strong> {grn.remarks}
                                </div>
                              )}
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* MODALS */}
      <CreatePurchaseRequestModal
        isOpen={isPRModalOpen}
        items={items}
        suppliers={suppliers}
        locations={locations}
        onClose={() => setIsPRModalOpen(false)}
        onSubmit={handleCreatePurchaseRequest}
      />

      <CreatePurchaseOrderModal
        isOpen={isPOModalOpen}
        items={items}
        suppliers={suppliers}
        locations={locations}
        onClose={() => setIsPOModalOpen(false)}
        onSubmit={handleCreatePurchaseOrder}
      />

      <GoodsReceivingModal
        isOpen={!!selectedPOForReceiving}
        purchaseOrder={selectedPOForReceiving}
        locations={locations}
        onClose={() => setSelectedPOForReceiving(null)}
        onSubmit={handleReceiveGoods}
      />
    </div>
  );
};
