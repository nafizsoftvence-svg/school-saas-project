import React, { useState, useRef, useEffect } from 'react';
import { User, LogOut, ChevronDown, Check, Compass } from 'lucide-react';
import { useAuth } from '../../context/AuthContext.js';
import { UserRole } from '../../types/index.js';

interface UserProfileMenuProps {
  onNavigateProfile: () => void;
}

export const UserProfileMenu: React.FC<UserProfileMenuProps> = ({ onNavigateProfile }) => {
  const [isOpen, setIsOpen] = useState(false);
  const { user, role, logout, switchDemoRole } = useAuth();
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    if (isOpen) document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isOpen]);

  if (!user) return null;

  const initials = `${user.firstName?.[0] || 'U'}${user.lastName?.[0] || ''}`;

  const roleBadges: Record<UserRole, { label: string; bg: string; text: string; border: string }> = {
    SUPER_ADMIN: {
      label: 'Platform Super Admin',
      bg: 'bg-purple-50 text-purple-800 border-purple-200',
      text: 'text-purple-800',
      border: 'border-purple-200'
    },
    ADMIN: {
      label: 'School Admin',
      bg: 'bg-blue-50 text-blue-800 border-blue-200',
      text: 'text-blue-800',
      border: 'border-blue-200'
    },
    TEACHER: {
      label: 'Teacher',
      bg: 'bg-blue-50 text-blue-800 border-blue-200',
      text: 'text-blue-800',
      border: 'border-blue-200'
    },
    STUDENT: {
      label: 'Student',
      bg: 'bg-emerald-50 text-emerald-800 border-emerald-200',
      text: 'text-emerald-800',
      border: 'border-emerald-200'
    },
    GUARDIAN: {
      label: 'Parent / Guardian',
      bg: 'bg-amber-50 text-amber-900 border-amber-200',
      text: 'text-amber-900',
      border: 'border-amber-200'
    }
  };

  const badge = roleBadges[role || 'GUARDIAN'] || roleBadges.GUARDIAN;

  return (
    <div className="relative" ref={menuRef}>
      <button
        id="user-profile-menu-btn"
        onClick={() => setIsOpen((prev) => !prev)}
        className="flex items-center gap-2.5 p-1.5 sm:px-3 sm:py-2 rounded-2xl bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-800 transition-all focus:outline-none focus:ring-2 focus:ring-blue-600 cursor-pointer shadow-xs"
        aria-label="Open profile menu"
      >
        <div className="w-8 h-8 rounded-xl bg-blue-600 border border-blue-700 text-white flex items-center justify-center font-bold text-xs shadow-xs">
          {initials}
        </div>
        <div className="hidden sm:flex flex-col text-left">
          <span className="text-xs font-bold text-slate-900 leading-tight">
            {user.firstName} {user.lastName}
          </span>
          <span className="text-[10px] text-slate-500 font-mono leading-tight">{user.username}</span>
        </div>
        <ChevronDown className="w-3.5 h-3.5 text-slate-500 hidden sm:block" />
      </button>

      {isOpen && (
        <div
          id="user-profile-dropdown"
          className="absolute right-0 mt-2 w-76 rounded-2xl bg-white border border-slate-200 shadow-xl z-50 overflow-hidden animate-in fade-in zoom-in-95 duration-150 p-2.5"
        >
          {/* User Details */}
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/90 mb-2">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-600 border border-blue-700 text-white flex items-center justify-center font-bold text-sm shadow-xs">
                {initials}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-bold text-slate-900 truncate">
                  {user.firstName} {user.lastName}
                </p>
                <p className="text-xs text-slate-600 truncate font-mono">{user.email}</p>
                <span
                  className={`inline-block mt-1 px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider border ${badge.bg}`}
                >
                  {badge.label}
                </span>
              </div>
            </div>
          </div>

          {/* Active Theme Status */}
          <div className="px-3 py-2 rounded-xl bg-blue-50/70 border border-blue-200/60 flex items-center justify-between text-xs mb-2">
            <div className="flex items-center gap-2 text-blue-900 font-semibold">
              <Compass className="w-3.5 h-3.5 text-blue-600" />
              <span>Theme: Nordic Crisp Light</span>
            </div>
            <span className="w-2 h-2 rounded-full bg-blue-600" />
          </div>

          <div className="h-px bg-slate-200 my-1.5" />

          {/* Persona Switcher Quick Action */}
          <div className="px-2 py-1 text-[10px] font-bold text-slate-500 uppercase tracking-wider">
            Switch Sandbox Persona
          </div>
          <div className="space-y-0.5 mb-2">
            {(['SUPER_ADMIN', 'ADMIN', 'TEACHER', 'STUDENT', 'GUARDIAN'] as UserRole[]).map((r) => {
              const isCurrent = role === r;
              const names: Record<UserRole, string> = {
                SUPER_ADMIN: 'Platform Super Admin (Dr. Arthur Sterling)',
                ADMIN: 'School Admin (Elena Rostova)',
                TEACHER: 'Teacher (Prof. Sarah Jenkins)',
                STUDENT: 'Student (Alex Rivera)',
                GUARDIAN: 'Guardian/Parent (Carlos Rivera)'
              };
              return (
                <button
                  key={r}
                  id={`persona-switch-${r}`}
                  onClick={() => {
                    switchDemoRole(r);
                    setIsOpen(false);
                  }}
                  className={`w-full flex items-center justify-between px-3 py-1.5 rounded-xl text-xs transition-all cursor-pointer ${
                    isCurrent
                      ? 'bg-blue-50 text-blue-700 font-bold border border-blue-200 shadow-2xs'
                      : 'text-slate-700 hover:bg-slate-100 hover:text-slate-900'
                  }`}
                >
                  <span className="truncate">{names[r]}</span>
                  {isCurrent && <Check className="w-3.5 h-3.5 text-blue-600 stroke-[3] flex-shrink-0" />}
                </button>
              );
            })}
          </div>

          <div className="h-px bg-slate-200 my-1.5" />

          {/* Navigation Options */}
          <button
            id="view-profile-btn"
            onClick={() => {
              setIsOpen(false);
              onNavigateProfile();
            }}
            className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-semibold text-slate-700 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
          >
            <User className="w-4 h-4 text-slate-500" />
            <span>Profile &amp; Permissions</span>
          </button>

          <button
            id="logout-btn"
            onClick={() => {
              setIsOpen(false);
              logout();
            }}
            className="w-full flex items-center gap-2.5 px-3 py-2 text-xs font-semibold text-rose-700 hover:text-rose-800 hover:bg-rose-50 rounded-xl transition-colors cursor-pointer"
          >
            <LogOut className="w-4 h-4 text-rose-600" />
            <span>Logout Session</span>
          </button>
        </div>
      )}
    </div>
  );
};
