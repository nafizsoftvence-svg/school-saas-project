import React, { useState, useEffect } from 'react';
import {
  ChevronDown,
  ChevronRight,
  LogOut,
  X,
  Compass
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext.js';
import { useSettings } from '../../context/SettingsContext.js';
import { getNavItemsForRole, NavItem } from '../../config/navigation.js';

interface SidebarProps {
  currentView: string;
  currentSubTab?: string;
  onNavigate: (viewId: string, subTabId?: string) => void;
  isOpen: boolean;
  onClose: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentView,
  currentSubTab,
  onNavigate,
  isOpen,
  onClose
}) => {
  const { role, logout } = useAuth();
  const { settings, activeSession } = useSettings();

  const navItems = getNavItemsForRole(role);

  // Helper to find which Main Tab with subtabs owns the active view
  const findParentMainTabId = (view: string): string | null => {
    if (!view || view === 'default') return null;
    const items = navItems || [];
    const matched = items.find((item) => {
      if (item.id === view) return true;
      if (item.children && item.children.some((child) => child.id === view)) return true;
      if (item.id.replace(/^admin-/, '') === view.replace(/^admin-/, '')) return true;
      return false;
    });
    return matched && matched.children && matched.children.length > 0 ? matched.id : null;
  };

  // Track the single expanded Main Tab ID: only ONE main tab can be expanded at a time
  const [expandedTabId, setExpandedTabId] = useState<string | null>(() => findParentMainTabId(currentView));

  // Auto-open the active Main Tab whenever the active route changes (or on refresh/mount)
  useEffect(() => {
    const parentId = findParentMainTabId(currentView);
    setExpandedTabId(parentId);
  }, [currentView, role]);

  // Toggle accordion expansion for a specific main tab (single-open)
  const toggleExpand = (itemId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setExpandedTabId((prev) => (prev === itemId ? null : itemId));
  };

  const handleMainTabClick = (item: NavItem) => {
    const hasChildren = Boolean(item.children && item.children.length > 0);
    const isCurrentlyActive =
      currentView === item.id ||
      Boolean(item.children?.some((child) => child.id === currentView));
    const isExpanded = expandedTabId === item.id;

    if (hasChildren) {
      if (isCurrentlyActive) {
        // Clicking the currently active, expanded Main Tab collapses it normally
        setExpandedTabId(isExpanded ? null : item.id);
      } else {
        // Opening another Main Tab automatically expands it (which collapses the previous one)
        setExpandedTabId(item.id);
        onNavigate(item.id, item.defaultSubTab || item.children![0].id);
        onClose();
      }
    } else {
      // Main tabs without subtabs remain normal links: collapse any open accordion and navigate
      setExpandedTabId(null);
      onNavigate(item.id);
      onClose();
    }
  };

  const handleSubTabClick = (parentId: string, subTabId: string) => {
    setExpandedTabId(parentId);
    onNavigate(parentId, subTabId);
    onClose();
  };

  const roleLabel =
    role === 'SUPER_ADMIN'
      ? 'Super Admin Portal'
      : role === 'TEACHER'
      ? 'Teacher Portal'
      : role === 'GUARDIAN'
      ? 'Parent/Guardian Portal'
      : 'Student Portal';

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 z-40 bg-slate-900/40 backdrop-blur-xs lg:hidden transition-opacity"
          onClick={onClose}
          aria-hidden="true"
        />
      )}

      {/* Sidebar Panel with Nordic Crisp Light Theme */}
      <aside
        id="app-sidebar"
        className={`fixed top-0 bottom-0 left-0 z-40 w-64 bg-white border-r border-slate-200 flex flex-col transition-transform duration-300 ease-in-out lg:translate-x-0 shadow-xs ${
          isOpen ? 'translate-x-0 shadow-2xl' : '-translate-x-full'
        }`}
      >
        {/* Brand Header */}
        <div className="p-5 flex items-center justify-between border-b border-slate-200">
          <div className="flex items-center gap-3">
            {settings?.logoUrl ? (
              <img
                src={settings.logoUrl}
                alt="School Logo"
                className="w-9 h-9 rounded-xl object-contain bg-slate-50 p-1 border border-slate-200"
                referrerPolicy="no-referrer"
              />
            ) : (
              <div className="w-9 h-9 bg-blue-600 rounded-xl flex items-center justify-center shadow-xs text-white font-black text-lg border border-blue-700">
                {settings?.schoolName ? settings.schoolName.charAt(0).toUpperCase() : 'S'}
              </div>
            )}
            <div>
              <span className="text-sm font-black tracking-tight text-slate-900 flex items-center gap-1">
                {settings?.schoolCode || 'SYGMATE'}
                <span className="w-1.5 h-1.5 rounded-full bg-blue-600 inline-block" />
              </span>
              <p className="text-[10px] uppercase font-bold tracking-widest text-slate-500 truncate max-w-[120px]">
                {settings?.schoolName || 'School OS'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 lg:hidden cursor-pointer"
            aria-label="Close sidebar"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Portal Identifier Tag */}
        <div className="px-5 pt-4 pb-2">
          <div className="text-[11px] font-bold text-slate-500 uppercase tracking-widest px-2 flex items-center gap-1.5">
            <Compass className="w-3.5 h-3.5 text-blue-600" />
            <span>{roleLabel}</span>
          </div>
        </div>

        {/* Navigation Items (Scrollable) */}
        <nav className="flex-1 px-3 py-2 space-y-1 overflow-y-auto custom-scrollbar">
          {(navItems || []).map((item) => {
            const Icon = item.icon;
            const hasChildren = Boolean(item.children && item.children.length > 0);
            const isParentActive =
              currentView === item.id ||
              Boolean(item.children?.some((child) => child.id === currentView)) ||
              item.id.replace(/^admin-/, '') === currentView.replace(/^admin-/, '');
            const isExpanded = expandedTabId === item.id;

            return (
              <div key={item.id} className="space-y-0.5">
                {/* Level 1: Main Tab */}
                <button
                  id={`sidebar-link-${item.id}`}
                  onClick={() => handleMainTabClick(item)}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold transition-all duration-150 cursor-pointer group ${
                    isParentActive
                      ? 'bg-blue-50 text-blue-700 border border-blue-200/90 shadow-2xs font-bold'
                      : 'text-slate-700 hover:text-slate-950 hover:bg-slate-100/80 font-medium'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0 flex-1 text-left">
                    <Icon
                      className={`w-4 h-4 flex-shrink-0 transition-colors ${
                        isParentActive ? 'text-blue-600' : 'text-slate-500 group-hover:text-slate-800'
                      }`}
                    />
                    <span className="truncate">{item.label}</span>
                  </div>

                  {/* Right Action: Chevron if has children, or Active Dot if leaf */}
                  {hasChildren ? (
                    <span
                      onClick={(e) => toggleExpand(item.id, e)}
                      className="p-1 -mr-1 rounded-md text-slate-400 hover:text-slate-700 hover:bg-slate-200/70 transition-colors cursor-pointer"
                      title={isExpanded ? 'Collapse' : 'Expand'}
                    >
                      {isExpanded ? (
                        <ChevronDown className="w-3.5 h-3.5 text-slate-700" />
                      ) : (
                        <ChevronRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-slate-700" />
                      )}
                    </span>
                  ) : (
                    isParentActive && (
                      <span className="w-1.5 h-1.5 bg-blue-600 rounded-full flex-shrink-0 ml-2" />
                    )
                  )}
                </button>

                {/* Level 2: Subtabs (Indented Under Main Tab) */}
                {hasChildren && isExpanded && (
                  <div className="ml-4 pl-3 py-1 space-y-1 border-l-2 border-blue-200 my-1 animate-in fade-in duration-150">
                    {item.children!.map((child) => {
                      const SubIcon = child.icon;
                      const isChildActive =
                        isParentActive &&
                        (currentSubTab === child.id ||
                          (!currentSubTab && child.id === (item.defaultSubTab || item.children![0].id)));

                      return (
                        <button
                          key={child.id}
                          id={`sidebar-sublink-${item.id}-${child.id}`}
                          onClick={() => handleSubTabClick(item.id, child.id)}
                          className={`w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-[11px] transition-all duration-150 cursor-pointer text-left ${
                            isChildActive
                              ? 'bg-blue-50 text-blue-700 border border-blue-200 font-semibold shadow-2xs'
                              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100 font-medium'
                          }`}
                        >
                          {SubIcon ? (
                            <SubIcon
                              className={`w-3.5 h-3.5 flex-shrink-0 ${
                                isChildActive ? 'text-blue-600' : 'text-slate-400'
                              }`}
                            />
                          ) : (
                            <span
                              className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${
                                isChildActive ? 'bg-blue-600' : 'bg-slate-300'
                              }`}
                            />
                          )}
                          <span className="truncate">{child.label}</span>
                          {isChildActive && (
                            <span className="w-1.5 h-1.5 bg-blue-600 rounded-full ml-auto" />
                          )}
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </nav>

        {/* System Footer Info & Logout */}
        <div className="p-4 border-t border-slate-200 space-y-2">
          <div className="px-3 py-2 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between">
            <div>
              <p className="text-[10px] text-slate-500 uppercase tracking-wider font-bold">Active Session</p>
              <p className="text-xs font-bold text-slate-800 truncate max-w-[140px]">
                {activeSession?.sessionName || 'No Active Session'}
              </p>
            </div>
            <div
              className={`w-2 h-2 rounded-full flex-shrink-0 ${
                activeSession ? 'bg-emerald-600' : 'bg-amber-500'
              }`}
            />
          </div>

          <button
            id="sidebar-logout-btn"
            onClick={() => logout()}
            className="w-full flex items-center gap-3 px-3.5 py-2.5 bg-rose-50 hover:bg-rose-100 text-rose-700 hover:text-rose-800 border border-rose-200 rounded-xl transition-all text-xs font-semibold cursor-pointer"
          >
            <LogOut className="w-4 h-4 text-rose-600" />
            <span>Logout System</span>
          </button>
        </div>
      </aside>
    </>
  );
};
