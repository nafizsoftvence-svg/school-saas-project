import React, { useState } from 'react';
import { Menu, Building, Sparkles, Mail, Compass, ChevronDown, Globe, Shield } from 'lucide-react';
import { useAuth } from '../../context/AuthContext.js';
import { useSettings } from '../../context/SettingsContext.js';
import { NotificationDropdown } from './NotificationDropdown.js';
import { UserProfileMenu } from './UserProfileMenu.js';
import { UserRole } from '../../types/index.js';

interface HeaderProps {
  onToggleSidebar: () => void;
  onNavigateProfile: () => void;
  onNavigateInbox?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onToggleSidebar, onNavigateProfile, onNavigateInbox }) => {
  const { role, switchDemoRole, activeSchool, userSchools, isPlatformAdmin, switchActiveSchool } = useAuth();
  const { settings, activeSession } = useSettings();
  const [showSchoolDropdown, setShowSchoolDropdown] = useState(false);

  const schoolName = activeSchool?.name || settings?.schoolName || 'Sygmate International Academy';
  const schoolCode = activeSchool?.code || settings?.schoolCode || 'SIA-2026';
  const sessionName = activeSession?.sessionName || '2026-2027';

  return (
    <header
      id="app-header"
      className="sticky top-0 z-30 h-16 lg:h-20 bg-white/95 backdrop-blur-md border-b border-slate-200 px-4 sm:px-8 lg:px-10 flex items-center justify-between gap-4 shadow-xs"
    >
      {/* Left Area: Toggle & School Context */}
      <div className="flex items-center gap-4">
        <button
          id="sidebar-toggle-btn"
          onClick={onToggleSidebar}
          className="p-2 -ml-2 rounded-xl text-slate-600 hover:text-slate-900 hover:bg-slate-100 lg:hidden focus:outline-none focus:ring-2 focus:ring-blue-600 cursor-pointer"
          aria-label="Toggle navigation sidebar"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div className="relative">
          <button
            onClick={() => {
              if ((userSchools && userSchools.length > 1) || isPlatformAdmin) {
                setShowSchoolDropdown((prev) => !prev);
              }
            }}
            className={`hidden sm:flex items-center gap-3 text-xs font-medium text-slate-700 p-1.5 -ml-1.5 rounded-xl transition-colors text-left ${
              (userSchools && userSchools.length > 1) || isPlatformAdmin
                ? 'hover:bg-slate-100 cursor-pointer'
                : 'cursor-default'
            }`}
          >
            {settings?.logoUrl ? (
              <img
                src={settings.logoUrl}
                alt="School Logo"
                className="w-9 h-9 rounded-xl object-contain bg-slate-50 p-1 border border-slate-200"
                referrerPolicy="no-referrer"
              />
            ) : (
              <div className="p-2 rounded-xl bg-blue-50 text-blue-700 border border-blue-200 font-bold">
                <Building className="w-4 h-4" />
              </div>
            )}
            <div>
              <div className="font-bold text-slate-900 tracking-tight flex items-center gap-2">
                <span className="truncate max-w-[180px] sm:max-w-xs">{schoolName}</span>
                <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 border border-blue-200">
                  {sessionName}
                </span>
                {((userSchools && userSchools.length > 1) || isPlatformAdmin) && (
                  <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                )}
              </div>
              <div className="flex items-center gap-2 text-[10px] text-slate-500 font-mono">
                <span>Code: {schoolCode}</span>
                {isPlatformAdmin && (
                  <span className="text-[9px] px-1.5 py-0.2 rounded bg-purple-50 text-purple-700 border border-purple-200 font-sans font-semibold">
                    Platform Super Admin
                  </span>
                )}
                {role === 'ADMIN' && (
                  <span className="text-[9px] px-1.5 py-0.2 rounded bg-blue-50 text-blue-700 border border-blue-200 font-sans font-semibold">
                    School Admin
                  </span>
                )}
              </div>
            </div>
          </button>

          {/* School Dropdown Menu for Multi-School Users & Super Admin */}
          {showSchoolDropdown && (
            <div className="absolute left-0 mt-2 w-72 bg-white rounded-2xl border border-slate-200 shadow-xl p-2 z-50 animate-in fade-in">
              <div className="px-3 py-2 border-b border-slate-100 text-xs font-semibold text-slate-500 uppercase tracking-wider flex items-center justify-between">
                <span>Switch School Tenant</span>
                <Globe className="w-3.5 h-3.5 text-blue-600" />
              </div>
              <div className="py-1 max-h-60 overflow-y-auto space-y-1">
                {userSchools.map((s) => {
                  const isCurrent = activeSchool?.id === s.id;
                  return (
                    <button
                      key={s.id}
                      onClick={async () => {
                        setShowSchoolDropdown(false);
                        await switchActiveSchool(s.id);
                      }}
                      className={`w-full flex items-center justify-between p-2.5 rounded-xl text-left text-xs transition-colors cursor-pointer ${
                        isCurrent
                          ? 'bg-blue-50 text-blue-900 font-bold border border-blue-200'
                          : 'hover:bg-slate-50 text-slate-700'
                      }`}
                    >
                      <div>
                        <div className="font-semibold">{s.name}</div>
                        <div className="text-[10px] text-slate-500 font-mono">{s.code}</div>
                      </div>
                      {isCurrent && (
                        <span className="text-[10px] bg-blue-600 text-white font-semibold px-2 py-0.5 rounded-full">
                          Active
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Right Area: Fast Role Switcher, Nordic Theme Tag, Notifications, User Profile */}
      <div className="flex items-center gap-2 sm:gap-3">
        {/* Fast Persona Switcher for effortless demoing & multi-role testing */}
        <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl border border-slate-200 shadow-2xs">
          <div className="hidden md:flex items-center gap-1 px-2 text-[10px] font-bold text-slate-500 uppercase tracking-wider">
            <Sparkles className="w-3 h-3 text-blue-600" />
            <span>Role:</span>
          </div>
          {(['SUPER_ADMIN', 'ADMIN', 'TEACHER', 'STUDENT', 'GUARDIAN'] as UserRole[]).map((r) => {
            const isActive = role === r;
            const labels: Record<string, string> = {
              SUPER_ADMIN: 'Platform Super Admin',
              ADMIN: 'School Admin',
              TEACHER: 'Teacher',
              STUDENT: 'Student',
              GUARDIAN: 'Guardian/Parent'
            };
            return (
              <button
                key={r}
                id={`header-switch-${r}`}
                onClick={() => switchDemoRole(r)}
                className={`px-2 sm:px-2.5 py-1 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                  isActive
                    ? 'bg-blue-600 text-white shadow-xs font-semibold border border-blue-700'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-white'
                }`}
              >
                {labels[r]}
              </button>
            );
          })}
        </div>

        {/* Nordic Crisp Light Tag */}
        <div className="hidden xl:flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-blue-50 border border-blue-200 text-[11px] font-semibold text-blue-700 shadow-2xs">
          <Compass className="w-3.5 h-3.5 text-blue-600" />
          <span>Multi-Tenant SaaS</span>
        </div>

        {/* Direct Messages & Inbox Quick Button */}
        {onNavigateInbox && (
          <button
            id="header-inbox-btn"
            onClick={onNavigateInbox}
            className="p-2 text-slate-700 hover:text-slate-900 rounded-xl hover:bg-slate-100 border border-slate-200 transition-colors relative cursor-pointer shadow-2xs"
            title="Open Messaging Inbox"
          >
            <Mail className="w-4 h-4 sm:w-4.5 sm:h-4.5" />
          </button>
        )}

        {/* Notifications */}
        <NotificationDropdown />

        {/* Divider */}
        <div className="h-6 w-px bg-slate-200 mx-0.5 hidden sm:block" />

        {/* User Profile */}
        <UserProfileMenu onNavigateProfile={onNavigateProfile} />
      </div>
    </header>
  );
};
