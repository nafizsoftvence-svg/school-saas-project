import React from 'react';
import { ChevronRight } from 'lucide-react';

export interface BreadcrumbItem {
  label: string;
  onClick?: () => void;
  active?: boolean;
}

export interface BreadcrumbProps {
  items: BreadcrumbItem[];
  portalName?: string;
  id?: string;
}

export const Breadcrumb: React.FC<BreadcrumbProps> = ({ items = [], portalName, id = 'app-breadcrumb' }) => {
  return (
    <nav id={id} aria-label="Breadcrumb" className="flex items-center space-x-1.5 text-xs text-slate-600">
      {portalName && (
        <div className="flex items-center gap-1.5">
          <span className="font-bold text-blue-700">{portalName}</span>
          <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
        </div>
      )}

      {(items || []).map((item, idx) => {
        const isLast = idx === (items || []).length - 1 || item.active;
        return (
          <div key={idx} className="flex items-center gap-1.5">
            {item.onClick && !isLast ? (
              <button
                onClick={item.onClick}
                className="text-slate-600 hover:text-slate-950 font-medium transition-colors underline-offset-4 hover:underline cursor-pointer"
              >
                {item.label}
              </button>
            ) : (
              <span className={isLast ? 'font-bold text-slate-900' : 'text-slate-600 font-medium'}>
                {item.label}
              </span>
            )}
            {!isLast && <ChevronRight className="w-3.5 h-3.5 text-slate-400" />}
          </div>
        );
      })}
    </nav>
  );
};
