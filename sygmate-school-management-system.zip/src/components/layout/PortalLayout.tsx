import React, { useState } from 'react';
import { Sidebar } from './Sidebar.js';
import { Header } from './Header.js';
import { Breadcrumb, BreadcrumbItem } from './Breadcrumb.js';
import { useAuth } from '../../context/AuthContext.js';

interface PortalLayoutProps {
  children: React.ReactNode;
  currentView: string;
  currentSubTab?: string;
  onNavigate: (viewId: string, subTabId?: string) => void;
  breadcrumbs?: BreadcrumbItem[];
  pageTitle?: string;
  pageDescription?: string;
  pageAction?: React.ReactNode;
}

export const PortalLayout: React.FC<PortalLayoutProps> = ({
  children,
  currentView,
  currentSubTab,
  onNavigate,
  breadcrumbs = [],
  pageTitle,
  pageDescription,
  pageAction
}) => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { role } = useAuth();

  const portalName =
    role === 'SUPER_ADMIN'
      ? 'Platform Super Admin Portal'
      : role === 'ADMIN'
      ? 'School Admin Portal'
      : role === 'TEACHER'
      ? 'Teacher Portal'
      : role === 'GUARDIAN'
      ? 'Parent / Guardian Portal'
      : 'Student Portal';

  return (
    <div
      className="min-h-screen bg-slate-50 text-slate-900 flex flex-col antialiased font-sans relative overflow-x-hidden"
      style={{
        background: 'radial-gradient(circle at top right, #f1f5f9, #f8fafc)'
      }}
    >
      {/* Subtle Nordic Atmospheric Glow */}
      <div className="fixed top-[-10%] right-[-5%] w-[500px] h-[500px] bg-sky-500/5 rounded-full blur-[120px] pointer-events-none z-0" />
      <div className="fixed bottom-[-10%] left-[-5%] w-[400px] h-[400px] bg-slate-400/5 rounded-full blur-[100px] pointer-events-none z-0" />

      {/* Sidebar Navigation */}
      <Sidebar
        currentView={currentView}
        currentSubTab={currentSubTab}
        onNavigate={onNavigate}
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
      />

      {/* Main Content Area */}
      <div className="lg:pl-64 flex flex-col min-h-screen relative z-10">
        {/* Top Header */}
        <Header
          onToggleSidebar={() => setSidebarOpen((prev) => !prev)}
          onNavigateProfile={() => onNavigate('profile')}
          onNavigateInbox={() =>
            onNavigate(
              role === 'SUPER_ADMIN'
                ? 'admin-inbox'
                : role === 'TEACHER'
                ? 'teacher-inbox'
                : role === 'GUARDIAN'
                ? 'guardian-inbox'
                : 'student-inbox'
            )
          }
        />

        {/* Page Content Container */}
        <main className="flex-1 p-4 sm:p-6 lg:p-10 max-w-7xl w-full mx-auto space-y-6">
          {/* Breadcrumb & Action Row */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <Breadcrumb items={breadcrumbs} portalName={portalName} />
            {pageAction && <div className="flex items-center gap-2 self-start sm:self-auto">{pageAction}</div>}
          </div>

          {/* Page Header (if title specified) */}
          {pageTitle && (
            <div className="border-b border-slate-200 pb-4">
              <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">{pageTitle}</h1>
              {pageDescription && <p className="text-xs sm:text-sm text-slate-600 mt-1 font-medium">{pageDescription}</p>}
            </div>
          )}

          {/* Main View Body */}
          <div className="animate-in fade-in-50 duration-200">{children}</div>
        </main>

        {/* System Footer */}
        <footer className="mt-auto border-t border-slate-200 bg-white/95 px-6 py-4 text-center text-xs text-slate-600">
          <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
            <span>© 2026 Sygmate International Academy. Multi-Role Management System.</span>
            <span className="font-mono text-[11px] text-slate-500">Architecture Foundation • Nordic Crisp Light</span>
          </div>
        </footer>
      </div>
    </div>
  );
};
