import React, { useState } from 'react';
import { Download, Printer, FileSpreadsheet, FileText, CheckCircle2, AlertCircle } from 'lucide-react';
import { Button } from '../ui/Button.js';
import { api } from '../../services/api.js';
import { downloadTablePdf, triggerSafePrint } from '../../utils/printPdf.js';

export interface ExportColumn {
  header: string;
  key: string;
  formatter?: (value: any, row: any) => string;
}

interface StudentReportsExportToolbarProps {
  reportTitle: string;
  data: any[];
  columns: ExportColumn[];
  filterContext?: Record<string, any>;
  schoolName?: string;
  onPrintPreview?: () => void;
  disabled?: boolean;
}

export const StudentReportsExportToolbar: React.FC<StudentReportsExportToolbarProps> = ({
  reportTitle,
  data,
  columns,
  filterContext = {},
  schoolName = 'Sygmate Academy of Science & Arts',
  onPrintPreview,
  disabled = false
}) => {
  const [isExporting, setIsExporting] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);

  const formatValue = (col: ExportColumn, row: any) => {
    const val = row[col.key];
    if (col.formatter) {
      return col.formatter(val, row);
    }
    if (val === null || val === undefined) return '';
    return String(val);
  };

  const handleExportCSV = async (format: 'CSV' | 'EXCEL') => {
    if (!data || data.length === 0) {
      alert('No data available to export.');
      return;
    }

    try {
      setIsExporting(true);
      const separator = format === 'EXCEL' ? '\t' : ',';
      const extension = format === 'EXCEL' ? 'xls' : 'csv';
      const mimeType = format === 'EXCEL' ? 'application/vnd.ms-excel;charset=utf-8' : 'text/csv;charset=utf-8;';

      const headers = columns.map((c) => c.header);
      const rows = data.map((row) =>
        columns.map((col) => {
          const raw = formatValue(col, row);
          const sanitized = raw.replace(/"/g, '""');
          return sanitized.includes(',') || sanitized.includes('\n') || sanitized.includes('"')
            ? `"${sanitized}"`
            : sanitized;
        })
      );

      const filterSummary = Object.entries(filterContext)
        .filter(([_, v]) => v && v !== 'ALL')
        .map(([k, v]) => `${k}: ${v}`)
        .join(' | ');

      const metadataLines = [
        `School: ${schoolName}`,
        `Report: ${reportTitle}`,
        `Generated Date: ${new Date().toLocaleDateString()} ${new Date().toLocaleTimeString()}`,
        `Applied Scope: ${filterSummary || 'All Authorized Records'}`,
        `Total Records: ${data.length}`,
        ''
      ];

      const csvContent = [
        ...metadataLines,
        headers.join(separator),
        ...rows.map((r) => r.join(separator))
      ].join('\n');

      // Add UTF-8 BOM so Excel opens accented characters properly
      const blob = new Blob(['\uFEFF' + csvContent], { type: mimeType });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      const cleanTitle = reportTitle.toLowerCase().replace(/[^a-z0-9]/g, '_');
      link.download = `${cleanTitle}_${new Date().toISOString().split('T')[0]}.${extension}`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      // Audit export server-side
      await api.studentReports.auditExport({
        reportType: reportTitle,
        format,
        filterContext,
        recordCount: data.length
      });

      setNotice(`Successfully exported ${data.length} records to ${format}. Audit log recorded.`);
      setTimeout(() => setNotice(null), 4000);
    } catch (err: any) {
      console.error('Export error:', err);
      alert('Failed to export data.');
    } finally {
      setIsExporting(false);
    }
  };

  const handlePrint = async () => {
    if (onPrintPreview) {
      onPrintPreview();
      return;
    }

    if (!data || data.length === 0) {
      alert('No data available to print.');
      return;
    }

    try {
      setIsExporting(true);
      const headers = columns.map((c) => c.header);
      const rows = data.map((row) =>
        columns.map((col) => formatValue(col, row))
      );

      const filterSummary = Object.entries(filterContext)
        .filter(([_, v]) => v && v !== 'ALL')
        .map(([k, v]) => `${k}: ${v}`)
        .join(' | ');

      const cleanTitle = reportTitle.replace(/_/g, ' ');
      const filename = `${reportTitle.toLowerCase().replace(/[^a-z0-9]/g, '_')}_${new Date().toISOString().split('T')[0]}.pdf`;

      // 1. Audit export server-side
      try {
        await api.studentReports.auditExport({
          reportType: reportTitle,
          format: 'PRINT',
          filterContext,
          recordCount: data.length
        });
      } catch (auditErr) {
        console.warn('Audit export failed:', auditErr);
      }

      // 2. Generate and download high-quality vector PDF
      await downloadTablePdf({
        title: cleanTitle,
        schoolName,
        filterSummary: filterSummary || 'All Filtered Records',
        columns: headers,
        data: rows,
        filename,
        orientation: columns.length > 5 ? 'landscape' : 'portrait'
      });

      // 3. Trigger safe print dialog
      await triggerSafePrint({
        fallbackTitle: cleanTitle
      });

      setNotice(`Successfully generated PDF & opened print preview (${data.length} records).`);
      setTimeout(() => setNotice(null), 4000);
    } catch (err: any) {
      console.error('Print/PDF error:', err);
      try {
        window.print();
      } catch {
        // ignore
      }
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-slate-50 border border-slate-200 rounded-xl p-3 my-3">
      <div className="flex items-center gap-2">
        <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">Export & Output:</span>
        <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-indigo-50 text-indigo-700 border border-indigo-200">
          {data.length} {data.length === 1 ? 'Record' : 'Records'} Ready
        </span>
        {notice && (
          <span className="text-xs text-emerald-600 font-medium flex items-center gap-1 animate-pulse">
            <CheckCircle2 className="w-3.5 h-3.5" />
            {notice}
          </span>
        )}
      </div>

      <div className="flex items-center gap-2 w-full sm:w-auto">
        <Button
          type="button"
          variant="outline"
          size="sm"
          disabled={disabled || isExporting || data.length === 0}
          onClick={() => handleExportCSV('CSV')}
          className="flex items-center gap-1.5 text-xs text-slate-700 hover:bg-slate-100"
        >
          <FileText className="w-3.5 h-3.5 text-emerald-600" />
          Export CSV
        </Button>

        <Button
          type="button"
          variant="outline"
          size="sm"
          disabled={disabled || isExporting || data.length === 0}
          onClick={() => handleExportCSV('EXCEL')}
          className="flex items-center gap-1.5 text-xs text-slate-700 hover:bg-slate-100"
        >
          <FileSpreadsheet className="w-3.5 h-3.5 text-indigo-600" />
          Export Excel
        </Button>

        <Button
          type="button"
          variant="outline"
          size="sm"
          disabled={disabled || data.length === 0}
          onClick={handlePrint}
          className="flex items-center gap-1.5 text-xs text-slate-700 hover:bg-slate-100"
        >
          <Printer className="w-3.5 h-3.5 text-slate-600" />
          Print / PDF
        </Button>
      </div>
    </div>
  );
};
