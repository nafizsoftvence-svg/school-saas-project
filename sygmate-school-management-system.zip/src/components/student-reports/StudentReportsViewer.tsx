import React, { useState, useEffect } from 'react';
import {
  BarChart3,
  Users,
  Layers,
  FileSpreadsheet,
  CheckCircle2,
  Clock,
  AlertCircle,
  CreditCard,
  FileCheck,
  TrendingUp,
  Award,
  ArrowRight,
  ShieldCheck,
  Building,
  GraduationCap
} from 'lucide-react';
import { Button } from '../ui/Button.js';
import { StudentReportsExportToolbar, ExportColumn } from './StudentReportsExportToolbar.js';
import { api } from '../../services/api.js';
import {
  StudentReportsSummaryData,
  ClassWiseReportItem,
  StatusReportData,
  AcademicAssignmentReportItem,
  AcademicSession,
  SchoolClass,
  Section
} from '../../types/index.js';

interface StudentReportsViewerProps {
  sessions: AcademicSession[];
  classes: SchoolClass[];
  sections: Section[];
  activeSessionId?: string;
  onViewStudentProfile: (studentId: string) => void;
}

type ReportSubTab =
  | 'summary'
  | 'class-wise'
  | 'status-audit'
  | 'admissions'
  | 'assignments'
  | 'promotions-transfers';

export const StudentReportsViewer: React.FC<StudentReportsViewerProps> = ({
  sessions,
  classes,
  sections,
  activeSessionId,
  onViewStudentProfile
}) => {
  const [activeTab, setActiveTab] = useState<ReportSubTab>('summary');
  const [loading, setLoading] = useState(false);

  // Data states
  const [summaryData, setSummaryData] = useState<StudentReportsSummaryData | null>(null);
  const [classWiseData, setClassWiseData] = useState<ClassWiseReportItem[]>([]);
  const [statusData, setStatusData] = useState<StatusReportData | null>(null);
  const [admissionsData, setAdmissionsData] = useState<any[]>([]);
  const [assignmentsData, setAssignmentsData] = useState<AcademicAssignmentReportItem[]>([]);
  const [promotionsData, setPromotionsData] = useState<any[]>([]);
  const [transfersData, setTransfersData] = useState<any[]>([]);

  // Sub-filter for specific tabs
  const [selectedClassId, setSelectedClassId] = useState<string>('ALL');
  const [selectedSessionId, setSelectedSessionId] = useState<string>(activeSessionId || 'ALL');

  useEffect(() => {
    loadActiveTabData();
  }, [activeTab, selectedClassId, selectedSessionId]);

  const loadActiveTabData = async () => {
    setLoading(true);
    try {
      const sessionParam = selectedSessionId !== 'ALL' ? selectedSessionId : undefined;
      const classParam = selectedClassId !== 'ALL' ? selectedClassId : undefined;

      switch (activeTab) {
        case 'summary': {
          const res = await api.studentReports.getSummary({
            academicSessionId: sessionParam,
            classId: classParam
          });
          if (res.success) setSummaryData(res.data);
          break;
        }

        case 'class-wise': {
          const res = await api.studentReports.getClassWiseReport({
            academicSessionId: sessionParam,
            classId: classParam
          });
          if (res.success) setClassWiseData(res.data);
          break;
        }

        case 'status-audit': {
          const res = await api.studentReports.getStatusReport({
            academicSessionId: sessionParam,
            classId: classParam
          });
          if (res.success) setStatusData(res.data);
          break;
        }

        case 'admissions': {
          const res = await api.studentReports.getAdmissionsReport({
            academicSessionId: sessionParam,
            classId: classParam
          });
          if (res.success) setAdmissionsData(res.data);
          break;
        }

        case 'assignments': {
          const res = await api.studentReports.getAcademicAssignmentsReport({
            academicSessionId: sessionParam,
            classId: classParam
          });
          if (res.success) setAssignmentsData(res.data);
          break;
        }

        case 'promotions-transfers': {
          const [promRes, transRes] = await Promise.all([
            api.studentReports.getPromotionsReport({ sourceSessionId: sessionParam }),
            api.studentReports.getTransfersReport({})
          ]);
          if (promRes.success) setPromotionsData(promRes.data);
          if (transRes.success) setTransfersData(transRes.data);
          break;
        }
      }
    } catch (err) {
      console.error('Failed to load report data:', err);
    } finally {
      setLoading(false);
    }
  };

  // Export column definitions for each tab
  const classWiseColumns: ExportColumn[] = [
    { header: 'Class Name', key: 'className' },
    { header: 'Total Students', key: 'totalStudents' },
    { header: 'Active Students', key: 'activeStudents' },
    { header: 'Male Students', key: 'maleCount' },
    { header: 'Female Students', key: 'femaleCount' }
  ];

  const statusColumns: ExportColumn[] = [
    { header: 'Admission #', key: 'admissionNumber' },
    { header: 'Student Name', key: 'fullName' },
    { header: 'Class', key: 'className' },
    { header: 'Current Status', key: 'status' },
    { header: 'Previous Status', key: 'previousStatus' },
    { header: 'Effective Date', key: 'lastStatusChangeDate' },
    { header: 'Reason', key: 'lastStatusReason' },
    { header: 'Authorized By', key: 'changedBy' }
  ];

  const admissionsColumns: ExportColumn[] = [
    { header: 'Admission #', key: 'admissionNumber' },
    { header: 'Student Name', key: 'fullName' },
    { header: 'Admission Date', key: 'admissionDate' },
    { header: 'Enrollment Date', key: 'enrollmentDate' },
    { header: 'Class', key: 'className' },
    { header: 'Section', key: 'sectionName' },
    { header: 'Guardian Name', key: 'guardianName' },
    { header: 'Guardian Phone', key: 'guardianPhone' },
    { header: 'Status', key: 'status' }
  ];

  const assignmentColumns: ExportColumn[] = [
    { header: 'Enrollment ID', key: 'enrollmentId' },
    { header: 'Admission #', key: 'admissionNumber' },
    { header: 'Student Name', key: 'studentName' },
    { header: 'Session', key: 'academicSessionName' },
    { header: 'Class', key: 'className' },
    { header: 'Section', key: 'sectionName' },
    { header: 'Roll #', key: 'rollNumber' },
    { header: 'Enrollment Date', key: 'enrollmentDate' },
    { header: 'Current Assignment', key: 'isCurrentAssignment', formatter: (val) => (val ? 'Yes' : 'Historical') }
  ];

  const promotionsColumns: ExportColumn[] = [
    { header: 'Student Name', key: 'studentName' },
    { header: 'Admission #', key: 'admissionNumber' },
    { header: 'From Session', key: 'fromSessionName' },
    { header: 'From Class', key: 'fromClassName' },
    { header: 'To Session', key: 'toSessionName' },
    { header: 'To Class', key: 'toClassName' },
    { header: 'Action', key: 'action' }
  ];

  return (
    <div className="space-y-4">
      {/* Sub Tab Navigation */}
      <div className="flex items-center gap-1 border-b border-slate-200 overflow-x-auto pb-1">
        <button
          type="button"
          onClick={() => setActiveTab('summary')}
          className={`px-3.5 py-2 text-xs font-semibold rounded-t-lg transition-colors whitespace-nowrap flex items-center gap-1.5 ${
            activeTab === 'summary'
              ? 'bg-indigo-50/80 text-indigo-700 border-b-2 border-indigo-600'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
          }`}
        >
          <BarChart3 className="w-3.5 h-3.5" />
          Executive Summary
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('class-wise')}
          className={`px-3.5 py-2 text-xs font-semibold rounded-t-lg transition-colors whitespace-nowrap flex items-center gap-1.5 ${
            activeTab === 'class-wise'
              ? 'bg-indigo-50/80 text-indigo-700 border-b-2 border-indigo-600'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          Class & Section Distribution
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('status-audit')}
          className={`px-3.5 py-2 text-xs font-semibold rounded-t-lg transition-colors whitespace-nowrap flex items-center gap-1.5 ${
            activeTab === 'status-audit'
              ? 'bg-indigo-50/80 text-indigo-700 border-b-2 border-indigo-600'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
          }`}
        >
          <ShieldCheck className="w-3.5 h-3.5" />
          Status History & Audit
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('admissions')}
          className={`px-3.5 py-2 text-xs font-semibold rounded-t-lg transition-colors whitespace-nowrap flex items-center gap-1.5 ${
            activeTab === 'admissions'
              ? 'bg-indigo-50/80 text-indigo-700 border-b-2 border-indigo-600'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
          }`}
        >
          <GraduationCap className="w-3.5 h-3.5" />
          Admissions & Enrollment Ledger
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('assignments')}
          className={`px-3.5 py-2 text-xs font-semibold rounded-t-lg transition-colors whitespace-nowrap flex items-center gap-1.5 ${
            activeTab === 'assignments'
              ? 'bg-indigo-50/80 text-indigo-700 border-b-2 border-indigo-600'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
          }`}
        >
          <Users className="w-3.5 h-3.5" />
          Academic Assignments
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('promotions-transfers')}
          className={`px-3.5 py-2 text-xs font-semibold rounded-t-lg transition-colors whitespace-nowrap flex items-center gap-1.5 ${
            activeTab === 'promotions-transfers'
              ? 'bg-indigo-50/80 text-indigo-700 border-b-2 border-indigo-600'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
          }`}
        >
          <TrendingUp className="w-3.5 h-3.5" />
          Promotions & Transfers
        </button>
      </div>

      {/* Scope Controls */}
      <div className="flex items-center gap-3 bg-slate-50/80 p-2.5 rounded-xl border border-slate-200 text-xs">
        <span className="font-semibold text-slate-600">Report Scope:</span>
        <div className="flex items-center gap-2">
          <select
            value={selectedSessionId}
            onChange={(e) => setSelectedSessionId(e.target.value)}
            className="text-xs py-1 px-2 border border-slate-300 rounded-md bg-white text-slate-700"
          >
            <option value="ALL">All Academic Sessions</option>
            {sessions.map((s) => (
              <option key={s.id} value={s.id}>
                {s.sessionName} {s.isCurrent ? '(Active)' : ''}
              </option>
            ))}
          </select>

          <select
            value={selectedClassId}
            onChange={(e) => setSelectedClassId(e.target.value)}
            className="text-xs py-1 px-2 border border-slate-300 rounded-md bg-white text-slate-700"
          >
            <option value="ALL">All Classes</option>
            {classes.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>

          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={loadActiveTabData}
            disabled={loading}
            className="h-7 text-xs text-indigo-600 hover:text-indigo-800"
          >
            {loading ? 'Refreshing...' : 'Refresh'}
          </Button>
        </div>
      </div>

      {/* TAB 1: EXECUTIVE SUMMARY */}
      {activeTab === 'summary' && (
        <div className="space-y-4">
          {summaryData && (
            <>
              {/* Top Metric Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
                <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs">
                  <p className="text-3xs uppercase font-bold text-slate-400">Total Enrolled</p>
                  <p className="text-xl font-bold text-slate-800 mt-1">{summaryData.totalStudents}</p>
                </div>

                <div className="bg-white p-3.5 rounded-xl border border-emerald-100 shadow-2xs">
                  <p className="text-3xs uppercase font-bold text-emerald-600">Active</p>
                  <p className="text-xl font-bold text-emerald-700 mt-1">{summaryData.activeStudents}</p>
                </div>

                <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs">
                  <p className="text-3xs uppercase font-bold text-slate-400">Inactive</p>
                  <p className="text-xl font-bold text-slate-700 mt-1">{summaryData.inactiveStudents}</p>
                </div>

                <div className="bg-white p-3.5 rounded-xl border border-rose-100 shadow-2xs">
                  <p className="text-3xs uppercase font-bold text-rose-500">Suspended</p>
                  <p className="text-xl font-bold text-rose-600 mt-1">{summaryData.suspendedStudents}</p>
                </div>

                <div className="bg-white p-3.5 rounded-xl border border-amber-100 shadow-2xs">
                  <p className="text-3xs uppercase font-bold text-amber-500">Withdrawn</p>
                  <p className="text-xl font-bold text-amber-600 mt-1">{summaryData.withdrawnStudents}</p>
                </div>

                <div className="bg-white p-3.5 rounded-xl border border-purple-100 shadow-2xs">
                  <p className="text-3xs uppercase font-bold text-purple-500">Transferred</p>
                  <p className="text-xl font-bold text-purple-600 mt-1">{summaryData.transferredStudents}</p>
                </div>

                <div className="bg-white p-3.5 rounded-xl border border-blue-100 shadow-2xs">
                  <p className="text-3xs uppercase font-bold text-blue-500">Graduated</p>
                  <p className="text-xl font-bold text-blue-600 mt-1">{summaryData.graduatedStudents}</p>
                </div>
              </div>

              {/* Compliance & Ratios */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* Gender Ratio */}
                <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-3">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-semibold text-slate-800 flex items-center gap-1.5">
                      <Users className="w-4 h-4 text-indigo-600" />
                      Gender Demographics
                    </h4>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-xs text-slate-600">
                      <span>Male</span>
                      <span className="font-semibold text-slate-800">
                        {summaryData.genderDistribution.male} (
                        {summaryData.totalStudents > 0
                          ? Math.round((summaryData.genderDistribution.male / summaryData.totalStudents) * 100)
                          : 0}
                        %)
                      </span>
                    </div>
                    <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                      <div
                        className="bg-indigo-600 h-full rounded-full"
                        style={{
                          width: `${
                            summaryData.totalStudents > 0
                              ? (summaryData.genderDistribution.male / summaryData.totalStudents) * 100
                              : 0
                          }%`
                        }}
                      />
                    </div>

                    <div className="flex justify-between text-xs text-slate-600 pt-1">
                      <span>Female</span>
                      <span className="font-semibold text-slate-800">
                        {summaryData.genderDistribution.female} (
                        {summaryData.totalStudents > 0
                          ? Math.round((summaryData.genderDistribution.female / summaryData.totalStudents) * 100)
                          : 0}
                        %)
                      </span>
                    </div>
                    <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                      <div
                        className="bg-emerald-500 h-full rounded-full"
                        style={{
                          width: `${
                            summaryData.totalStudents > 0
                              ? (summaryData.genderDistribution.female / summaryData.totalStudents) * 100
                              : 0
                          }%`
                        }}
                      />
                    </div>
                  </div>
                </div>

                {/* Document Compliance */}
                <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-3">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-semibold text-slate-800 flex items-center gap-1.5">
                      <FileCheck className="w-4 h-4 text-emerald-600" />
                      Document Compliance
                    </h4>
                    <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                      {summaryData.documentCompliance.percentVerified}% Verified
                    </span>
                  </div>
                  <div className="space-y-1.5 text-xs">
                    <div className="flex justify-between text-slate-600">
                      <span>Verified & Complete:</span>
                      <span className="font-semibold text-emerald-700">
                        {summaryData.documentCompliance.verifiedCount}
                      </span>
                    </div>
                    <div className="flex justify-between text-slate-600">
                      <span>Pending Verification:</span>
                      <span className="font-semibold text-amber-600">
                        {summaryData.documentCompliance.pendingCount}
                      </span>
                    </div>
                    <div className="flex justify-between text-slate-600">
                      <span>Incomplete / Missing:</span>
                      <span className="font-semibold text-rose-600">
                        {summaryData.documentCompliance.incompleteCount}
                      </span>
                    </div>
                  </div>
                </div>

                {/* ID Card Issuance */}
                <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-3">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-semibold text-slate-800 flex items-center gap-1.5">
                      <CreditCard className="w-4 h-4 text-indigo-600" />
                      ID Card Issuance
                    </h4>
                    <span className="text-xs font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded">
                      {summaryData.idCardIssuance.percentIssued}% Issued
                    </span>
                  </div>
                  <div className="space-y-1.5 text-xs">
                    <div className="flex justify-between text-slate-600">
                      <span>Issued & Active:</span>
                      <span className="font-semibold text-indigo-700">
                        {summaryData.idCardIssuance.issuedCount}
                      </span>
                    </div>
                    <div className="flex justify-between text-slate-600">
                      <span>Cards Pending Issuance:</span>
                      <span className="font-semibold text-slate-500">
                        {summaryData.idCardIssuance.pendingCount}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Class Breakdown List */}
              <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-2xs">
                <div className="p-3 bg-slate-50/80 border-b border-slate-200">
                  <h4 className="text-xs font-semibold text-slate-800">Class Enrollment Breakdown</h4>
                </div>
                <table className="w-full text-left text-xs text-slate-600">
                  <thead>
                    <tr className="border-b border-slate-200 bg-slate-50/50 text-slate-500 text-3xs uppercase font-bold">
                      <th className="py-2.5 px-4">Class</th>
                      <th className="py-2.5 px-4">Total Students</th>
                      <th className="py-2.5 px-4">Active Students</th>
                      <th className="py-2.5 px-4">Active Ratio</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {summaryData.classBreakdown.map((item) => (
                      <tr key={item.classId} className="hover:bg-slate-50/50">
                        <td className="py-2 px-4 font-semibold text-slate-800">{item.className}</td>
                        <td className="py-2 px-4 font-medium">{item.studentCount}</td>
                        <td className="py-2 px-4 text-emerald-700 font-semibold">{item.activeCount}</td>
                        <td className="py-2 px-4">
                          <span className="inline-flex items-center px-2 py-0.5 rounded text-2xs bg-slate-100 text-slate-700 font-medium">
                            {item.studentCount > 0 ? Math.round((item.activeCount / item.studentCount) * 100) : 0}%
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </>
          )}
        </div>
      )}

      {/* TAB 2: CLASS & SECTION DISTRIBUTION */}
      {activeTab === 'class-wise' && (
        <div className="space-y-4">
          <StudentReportsExportToolbar
            reportTitle="Class_and_Section_Distribution_Report"
            data={classWiseData}
            columns={classWiseColumns}
            filterContext={{ session: selectedSessionId, class: selectedClassId }}
          />

          <div className="space-y-3">
            {classWiseData.map((cls) => (
              <div key={cls.classId} className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-2xs">
                <div className="p-3.5 bg-slate-50/80 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <Building className="w-4 h-4 text-indigo-600" />
                    <span className="font-bold text-slate-900 text-xs">{cls.className}</span>
                    <span className="text-2xs bg-slate-200/80 text-slate-700 px-2 py-0.5 rounded-full font-medium">
                      Grade {cls.gradeLevel}
                    </span>
                  </div>
                  <div className="flex items-center gap-3 text-xs">
                    <span className="text-slate-600">
                      Total Students: <strong className="text-slate-900">{cls.totalStudents}</strong>
                    </span>
                    <span className="text-emerald-700">
                      Active: <strong>{cls.activeStudents}</strong>
                    </span>
                    <span className="text-slate-500">
                      M: {cls.maleCount} | F: {cls.femaleCount}
                    </span>
                  </div>
                </div>

                {/* Sections List */}
                <div className="p-3 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
                  {cls.sections.map((sec) => (
                    <div key={sec.sectionId} className="bg-slate-50/70 border border-slate-200/80 rounded-lg p-2.5">
                      <div className="flex items-center justify-between">
                        <span className="font-semibold text-slate-800 text-xs">{sec.sectionName}</span>
                        <span className="text-3xs font-semibold bg-indigo-50 text-indigo-700 px-1.5 py-0.5 rounded border border-indigo-200">
                          {sec.studentCount} / {sec.capacity || 40} Capacity
                        </span>
                      </div>
                      <div className="mt-2 text-2xs text-slate-500 flex justify-between">
                        <span>Active Roster: {sec.activeCount}</span>
                        <span>
                          {sec.capacity > 0 ? Math.round((sec.studentCount / sec.capacity) * 100) : 0}% Filled
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: STATUS AUDIT REPORT */}
      {activeTab === 'status-audit' && (
        <div className="space-y-4">
          {statusData && (
            <>
              <StudentReportsExportToolbar
                reportTitle="Student_Status_Audit_Report"
                data={statusData.all}
                columns={statusColumns}
                filterContext={{ session: selectedSessionId, class: selectedClassId }}
              />

              <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-2xs">
                <div className="p-3 bg-slate-50/80 border-b border-slate-200 flex items-center justify-between">
                  <h4 className="text-xs font-semibold text-slate-800">
                    Status Transition History & Administrative Records ({statusData?.all?.length || 0} Total)
                  </h4>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs text-slate-600">
                    <thead>
                      <tr className="bg-slate-50/50 border-b border-slate-200 text-slate-500 text-3xs uppercase font-bold">
                        <th className="py-2.5 px-3">Student</th>
                        <th className="py-2.5 px-3">Adm #</th>
                        <th className="py-2.5 px-3">Class</th>
                        <th className="py-2.5 px-3">Status</th>
                        <th className="py-2.5 px-3">Previous</th>
                        <th className="py-2.5 px-3">Effective Date</th>
                        <th className="py-2.5 px-3">Reason / Remarks</th>
                        <th className="py-2.5 px-3">Authorized By</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {statusData.all.map((item) => (
                        <tr key={item.id} className="hover:bg-slate-50/50">
                          <td className="py-2 px-3 font-semibold text-slate-900">
                            <button
                              type="button"
                              onClick={() => onViewStudentProfile(item.id)}
                              className="hover:text-indigo-600 underline text-left"
                            >
                              {item.fullName}
                            </button>
                          </td>
                          <td className="py-2 px-3 font-mono text-xs text-slate-800">{item.admissionNumber}</td>
                          <td className="py-2 px-3">{item.className}</td>
                          <td className="py-2 px-3">
                            <span className="inline-flex items-center px-1.5 py-0.5 rounded text-2xs font-semibold bg-emerald-50 text-emerald-700">
                              {item.status}
                            </span>
                          </td>
                          <td className="py-2 px-3 text-slate-400">{item.previousStatus}</td>
                          <td className="py-2 px-3 text-slate-600">{item.lastStatusChangeDate}</td>
                          <td className="py-2 px-3 text-slate-700 max-w-xs truncate">{item.lastStatusReason}</td>
                          <td className="py-2 px-3 font-medium text-slate-800">{item.changedBy}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          )}
        </div>
      )}

      {/* TAB 4: ADMISSIONS REPORT */}
      {activeTab === 'admissions' && (
        <div className="space-y-4">
          <StudentReportsExportToolbar
            reportTitle="Admissions_and_Enrollment_Ledger"
            data={admissionsData}
            columns={admissionsColumns}
            filterContext={{ session: selectedSessionId, class: selectedClassId }}
          />

          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-2xs">
            <div className="p-3 bg-slate-50/80 border-b border-slate-200">
              <h4 className="text-xs font-semibold text-slate-800">
                Official Admissions Ledger ({admissionsData.length} Students)
              </h4>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-600">
                <thead>
                  <tr className="bg-slate-50/50 border-b border-slate-200 text-slate-500 text-3xs uppercase font-bold">
                    <th className="py-2.5 px-3">Adm #</th>
                    <th className="py-2.5 px-3">Student Name</th>
                    <th className="py-2.5 px-3">Admission Date</th>
                    <th className="py-2.5 px-3">Enrollment Date</th>
                    <th className="py-2.5 px-3">Class & Section</th>
                    <th className="py-2.5 px-3">Guardian Contact</th>
                    <th className="py-2.5 px-3">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {admissionsData.map((item) => (
                    <tr key={item.id} className="hover:bg-slate-50/50">
                      <td className="py-2 px-3 font-mono font-medium text-slate-800">{item.admissionNumber}</td>
                      <td className="py-2 px-3 font-semibold text-slate-900">
                        <button
                          type="button"
                          onClick={() => onViewStudentProfile(item.id)}
                          className="hover:text-indigo-600 underline text-left"
                        >
                          {item.fullName}
                        </button>
                      </td>
                      <td className="py-2 px-3">{item.admissionDate}</td>
                      <td className="py-2 px-3">{item.enrollmentDate}</td>
                      <td className="py-2 px-3">
                        {item.className} - {item.sectionName}
                      </td>
                      <td className="py-2 px-3">
                        <p className="font-medium text-slate-800">{item.guardianName}</p>
                        <p className="text-3xs text-slate-500">{item.guardianPhone}</p>
                      </td>
                      <td className="py-2 px-3 font-semibold text-emerald-700">{item.status}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: ACADEMIC ASSIGNMENTS REPORT */}
      {activeTab === 'assignments' && (
        <div className="space-y-4">
          <StudentReportsExportToolbar
            reportTitle="Academic_Class_and_Section_Assignments"
            data={assignmentsData}
            columns={assignmentColumns}
            filterContext={{ session: selectedSessionId, class: selectedClassId }}
          />

          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-2xs">
            <div className="p-3 bg-slate-50/80 border-b border-slate-200">
              <h4 className="text-xs font-semibold text-slate-800">
                Student Academic Session Assignments ({assignmentsData.length} Records)
              </h4>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-600">
                <thead>
                  <tr className="bg-slate-50/50 border-b border-slate-200 text-slate-500 text-3xs uppercase font-bold">
                    <th className="py-2.5 px-3">Adm #</th>
                    <th className="py-2.5 px-3">Student Name</th>
                    <th className="py-2.5 px-3">Academic Session</th>
                    <th className="py-2.5 px-3">Class</th>
                    <th className="py-2.5 px-3">Section</th>
                    <th className="py-2.5 px-3">Roll #</th>
                    <th className="py-2.5 px-3">Enrollment Date</th>
                    <th className="py-2.5 px-3">Type</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {assignmentsData.map((item) => (
                    <tr key={item.enrollmentId} className="hover:bg-slate-50/50">
                      <td className="py-2 px-3 font-mono text-slate-800">{item.admissionNumber}</td>
                      <td className="py-2 px-3 font-semibold text-slate-900">
                        <button
                          type="button"
                          onClick={() => onViewStudentProfile(item.studentId)}
                          className="hover:text-indigo-600 underline text-left"
                        >
                          {item.studentName}
                        </button>
                      </td>
                      <td className="py-2 px-3">{item.academicSessionName}</td>
                      <td className="py-2 px-3">{item.className}</td>
                      <td className="py-2 px-3">{item.sectionName}</td>
                      <td className="py-2 px-3 font-medium text-slate-800">{item.rollNumber || 'N/A'}</td>
                      <td className="py-2 px-3">{item.enrollmentDate}</td>
                      <td className="py-2 px-3">
                        <span
                          className={`inline-flex items-center px-1.5 py-0.5 rounded text-2xs font-semibold ${
                            item.isCurrentAssignment
                              ? 'bg-emerald-50 text-emerald-700'
                              : 'bg-slate-100 text-slate-600'
                          }`}
                        >
                          {item.isCurrentAssignment ? 'Current' : 'Historical'}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 6: PROMOTIONS & TRANSFERS */}
      {activeTab === 'promotions-transfers' && (
        <div className="space-y-4">
          <StudentReportsExportToolbar
            reportTitle="Student_Promotions_and_Transfers"
            data={promotionsData}
            columns={promotionsColumns}
            filterContext={{ session: selectedSessionId }}
          />

          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-2xs">
            <div className="p-3 bg-slate-50/80 border-b border-slate-200">
              <h4 className="text-xs font-semibold text-slate-800">
                Session Promotion Records ({promotionsData.length} Records)
              </h4>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-600">
                <thead>
                  <tr className="bg-slate-50/50 border-b border-slate-200 text-slate-500 text-3xs uppercase font-bold">
                    <th className="py-2.5 px-3">Adm #</th>
                    <th className="py-2.5 px-3">Student Name</th>
                    <th className="py-2.5 px-3">From Session & Class</th>
                    <th className="py-2.5 px-3">To Session & Class</th>
                    <th className="py-2.5 px-3">Action</th>
                    <th className="py-2.5 px-3">Standing</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {promotionsData.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-8 text-center text-slate-400 text-xs">
                        No promotion records found for selected scope.
                      </td>
                    </tr>
                  ) : (
                    promotionsData.map((p) => (
                      <tr key={p.id} className="hover:bg-slate-50/50">
                        <td className="py-2 px-3 font-mono text-slate-800">{p.admissionNumber}</td>
                        <td className="py-2 px-3 font-semibold text-slate-900">{p.studentName}</td>
                        <td className="py-2 px-3">
                          {p.fromSessionName} ({p.fromClassName})
                        </td>
                        <td className="py-2 px-3 font-medium text-indigo-700">
                          {p.toSessionName} ({p.toClassName})
                        </td>
                        <td className="py-2 px-3">
                          <span className="inline-flex items-center px-1.5 py-0.5 rounded text-2xs font-semibold bg-emerald-50 text-emerald-700">
                            {p.action}
                          </span>
                        </td>
                        <td className="py-2 px-3 text-slate-600">
                          {p.academicStanding?.standingGrade || 'Passed'}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
