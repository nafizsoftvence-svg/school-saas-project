import React from 'react';
import {
  User,
  CheckCircle2,
  AlertCircle,
  Clock,
  CreditCard,
  FileCheck,
  ChevronRight,
  ExternalLink,
  ShieldAlert,
  ArrowUpDown,
  Eye
} from 'lucide-react';
import { Button } from '../ui/Button.js';
import { StudentReportItem } from '../../types/index.js';

interface StudentDirectoryTableProps {
  students: StudentReportItem[];
  selectedStudentIds: Set<string>;
  onToggleSelect: (studentId: string) => void;
  onToggleSelectAll: () => void;
  onSelectEntireQuery?: () => void;
  totalMatchingQuery?: number;
  allQuerySelected?: boolean;
  onOpenBulkModal: () => void;
  onViewStudentProfile: (studentId: string) => void;
  onSort: (column: string) => void;
  currentSortBy?: string;
  currentSortOrder?: 'asc' | 'desc';
  isLoading?: boolean;
}

export const StudentDirectoryTable: React.FC<StudentDirectoryTableProps> = ({
  students,
  selectedStudentIds,
  onToggleSelect,
  onToggleSelectAll,
  onSelectEntireQuery,
  totalMatchingQuery = 0,
  allQuerySelected = false,
  onOpenBulkModal,
  onViewStudentProfile,
  onSort,
  currentSortBy,
  currentSortOrder = 'asc',
  isLoading = false
}) => {
  const isAllVisibleSelected =
    students.length > 0 && students.every((s) => selectedStudentIds.has(s.id));
  const isSomeVisibleSelected =
    students.some((s) => selectedStudentIds.has(s.id)) && !isAllVisibleSelected;

  const renderStatusBadge = (status: string) => {
    const s = (status || '').toLowerCase();
    switch (s) {
      case 'active':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mr-1.5"></span>
            Active
          </span>
        );
      case 'inactive':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold bg-slate-100 text-slate-700 border border-slate-200">
            <span className="w-1.5 h-1.5 rounded-full bg-slate-400 mr-1.5"></span>
            Inactive
          </span>
        );
      case 'suspended':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold bg-rose-50 text-rose-700 border border-rose-200">
            <span className="w-1.5 h-1.5 rounded-full bg-rose-500 mr-1.5"></span>
            Suspended
          </span>
        );
      case 'withdrawn':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold bg-amber-50 text-amber-700 border border-amber-200">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-500 mr-1.5"></span>
            Withdrawn
          </span>
        );
      case 'graduated':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-200">
            <span className="w-1.5 h-1.5 rounded-full bg-blue-500 mr-1.5"></span>
            Graduated
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold bg-slate-50 text-slate-600 border border-slate-200">
            {status}
          </span>
        );
    }
  };

  const renderDocBadge = (student: StudentReportItem) => {
    const { documentStatus, documentCount, verifiedDocumentCount } = student;
    if (documentStatus === 'verified' || documentStatus === 'complete') {
      return (
        <span
          className="inline-flex items-center gap-1 text-2xs px-2 py-0.5 rounded font-medium bg-emerald-50 text-emerald-700 border border-emerald-200"
          title={`${verifiedDocumentCount} / ${documentCount} verified`}
        >
          <FileCheck className="w-3 h-3" />
          Verified ({verifiedDocumentCount}/{documentCount})
        </span>
      );
    }
    if (documentStatus === 'pending_verification') {
      return (
        <span
          className="inline-flex items-center gap-1 text-2xs px-2 py-0.5 rounded font-medium bg-amber-50 text-amber-700 border border-amber-200"
          title={`${documentCount} documents uploaded, pending review`}
        >
          <Clock className="w-3 h-3" />
          Pending ({documentCount})
        </span>
      );
    }
    return (
      <span
        className="inline-flex items-center gap-1 text-2xs px-2 py-0.5 rounded font-medium bg-rose-50 text-rose-700 border border-rose-200"
        title="Missing mandatory compliance documents"
      >
        <AlertCircle className="w-3 h-3" />
        Incomplete ({documentCount})
      </span>
    );
  };

  const renderIdCardBadge = (student: StudentReportItem) => {
    const { idCardStatus, idCardNumber } = student;
    if (idCardStatus === 'issued' || idCardStatus === 'active') {
      return (
        <span
          className="inline-flex items-center gap-1 text-2xs px-2 py-0.5 rounded font-medium bg-indigo-50 text-indigo-700 border border-indigo-200"
          title={idCardNumber ? `Card #: ${idCardNumber}` : 'Card active'}
        >
          <CreditCard className="w-3 h-3" />
          Issued
        </span>
      );
    }
    if (idCardStatus === 'blocked' || idCardStatus === 'expired') {
      return (
        <span className="inline-flex items-center gap-1 text-2xs px-2 py-0.5 rounded font-medium bg-rose-50 text-rose-700 border border-rose-200">
          <ShieldAlert className="w-3 h-3" />
          Blocked
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 text-2xs px-2 py-0.5 rounded font-medium bg-slate-100 text-slate-500 border border-slate-200">
        <CreditCard className="w-3 h-3 opacity-60" />
        Not Issued
      </span>
    );
  };

  return (
    <div className="bg-white border border-slate-200 rounded-2xl shadow-xs overflow-hidden">
      {/* Bulk Action Sticky Bar */}
      {selectedStudentIds.size > 0 && (
        <div className="bg-indigo-900 text-white px-4 py-2.5 flex flex-wrap items-center justify-between gap-3 animate-in fade-in duration-150">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold bg-indigo-800 text-indigo-100 px-2 py-0.5 rounded-md">
              {selectedStudentIds.size}
            </span>
            <span className="text-xs font-medium text-indigo-100">
              {selectedStudentIds.size === 1 ? 'student selected' : 'students selected'}
            </span>
            {totalMatchingQuery > students.length && onSelectEntireQuery && (
              <button
                type="button"
                onClick={onSelectEntireQuery}
                className="text-xs font-semibold underline text-amber-300 hover:text-amber-200 ml-2"
              >
                {allQuerySelected
                  ? 'Selected entire search query'
                  : `Select all ${totalMatchingQuery} matching query`}
              </button>
            )}
          </div>

          <div className="flex items-center gap-2">
            <Button
              type="button"
              variant="primary"
              size="sm"
              onClick={onOpenBulkModal}
              className="bg-indigo-500 hover:bg-indigo-400 text-white border-0 text-xs font-semibold shadow-xs"
            >
              Bulk Actions ({selectedStudentIds.size})
            </Button>
            <button
              type="button"
              onClick={() => onToggleSelectAll()}
              className="text-xs text-indigo-200 hover:text-white underline ml-1"
            >
              Clear Selection
            </button>
          </div>
        </div>
      )}

      {/* Table Content */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs text-slate-600 border-collapse">
          <thead>
            <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-700 uppercase tracking-wider text-3xs font-bold">
              <th className="py-3 px-3 w-10 text-center">
                <input
                  type="checkbox"
                  checked={isAllVisibleSelected}
                  ref={(el) => {
                    if (el) el.indeterminate = isSomeVisibleSelected;
                  }}
                  onChange={onToggleSelectAll}
                  className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                />
              </th>
              <th
                className="py-3 px-3 cursor-pointer hover:text-slate-900 select-none"
                onClick={() => onSort('fullName')}
              >
                <div className="flex items-center gap-1">
                  <span>Student Identity</span>
                  <ArrowUpDown className="w-3 h-3 text-slate-400" />
                </div>
              </th>
              <th
                className="py-3 px-3 cursor-pointer hover:text-slate-900 select-none"
                onClick={() => onSort('admissionNumber')}
              >
                <div className="flex items-center gap-1">
                  <span>Adm / Roll #</span>
                  <ArrowUpDown className="w-3 h-3 text-slate-400" />
                </div>
              </th>
              <th
                className="py-3 px-3 cursor-pointer hover:text-slate-900 select-none"
                onClick={() => onSort('className')}
              >
                <div className="flex items-center gap-1">
                  <span>Class & Section</span>
                  <ArrowUpDown className="w-3 h-3 text-slate-400" />
                </div>
              </th>
              <th className="py-3 px-3">Guardian</th>
              <th
                className="py-3 px-3 cursor-pointer hover:text-slate-900 select-none"
                onClick={() => onSort('status')}
              >
                <div className="flex items-center gap-1">
                  <span>Status</span>
                  <ArrowUpDown className="w-3 h-3 text-slate-400" />
                </div>
              </th>
              <th className="py-3 px-3">Documents</th>
              <th className="py-3 px-3">ID Card</th>
              <th className="py-3 px-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {isLoading ? (
              <tr>
                <td colSpan={9} className="py-12 text-center text-slate-400 text-xs">
                  <div className="inline-block animate-spin rounded-full h-6 w-6 border-2 border-indigo-600 border-t-transparent mb-2"></div>
                  <p>Loading student directory records...</p>
                </td>
              </tr>
            ) : students.length === 0 ? (
              <tr>
                <td colSpan={9} className="py-12 text-center text-slate-400 text-xs">
                  No students match your query criteria.
                </td>
              </tr>
            ) : (
              students.map((student) => {
                const isSelected = selectedStudentIds.has(student.id);
                return (
                  <tr
                    key={student.id}
                    className={`hover:bg-slate-50/70 transition-colors ${
                      isSelected ? 'bg-indigo-50/40' : ''
                    }`}
                  >
                    <td className="py-2.5 px-3 text-center">
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => onToggleSelect(student.id)}
                        className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                      />
                    </td>

                    {/* Student Identity */}
                    <td className="py-2.5 px-3">
                      <div className="flex items-center gap-2.5">
                        {student.avatarUrl ? (
                          <img
                            src={student.avatarUrl}
                            alt={student.fullName}
                            referrerPolicy="no-referrer"
                            className="w-8 h-8 rounded-full object-cover border border-slate-200"
                          />
                        ) : (
                          <div className="w-8 h-8 rounded-full bg-slate-100 border border-slate-200 flex items-center justify-center text-slate-600 font-semibold text-xs uppercase">
                            {student.firstName?.[0] || 'S'}
                            {student.lastName?.[0] || ''}
                          </div>
                        )}
                        <div>
                          <p className="font-semibold text-slate-900 text-xs hover:text-indigo-600 transition-colors cursor-pointer"
                             onClick={() => onViewStudentProfile(student.id)}
                          >
                            {student.fullName}
                          </p>
                          <p className="text-3xs text-slate-500">
                            {student.gender ? `${student.gender} • ` : ''}
                            {student.bloodGroup ? `${student.bloodGroup} • ` : ''}
                            ID: {student.id.slice(0, 8)}
                          </p>
                        </div>
                      </div>
                    </td>

                    {/* Adm / Roll # */}
                    <td className="py-2.5 px-3 whitespace-nowrap">
                      <p className="font-medium text-slate-800 font-mono text-xs">
                        {student.admissionNumber}
                      </p>
                      <p className="text-3xs text-slate-500">
                        Roll: <span className="font-medium text-slate-700">{student.rollNumber || 'Unassigned'}</span>
                      </p>
                    </td>

                    {/* Class & Section */}
                    <td className="py-2.5 px-3 whitespace-nowrap">
                      <p className="font-medium text-slate-800">
                        {student.className || 'Unassigned'}
                      </p>
                      <p className="text-3xs text-slate-500">
                        Section: {student.sectionName || 'N/A'}
                      </p>
                    </td>

                    {/* Guardian */}
                    <td className="py-2.5 px-3">
                      <p className="text-slate-800 font-medium truncate max-w-[130px]">
                        {student.guardianName || 'N/A'}
                      </p>
                      <p className="text-3xs text-slate-500 truncate max-w-[130px]">
                        {student.guardianPhone || student.guardianRelation || 'No contact'}
                      </p>
                    </td>

                    {/* Status */}
                    <td className="py-2.5 px-3 whitespace-nowrap">
                      {renderStatusBadge(student.status)}
                    </td>

                    {/* Documents */}
                    <td className="py-2.5 px-3 whitespace-nowrap">
                      {renderDocBadge(student)}
                    </td>

                    {/* ID Card */}
                    <td className="py-2.5 px-3 whitespace-nowrap">
                      {renderIdCardBadge(student)}
                    </td>

                    {/* Actions */}
                    <td className="py-2.5 px-3 text-right whitespace-nowrap">
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => onViewStudentProfile(student.id)}
                        className="text-3xs h-7 px-2 text-slate-700 hover:text-indigo-600 hover:bg-slate-100 flex items-center gap-1 ml-auto"
                        title="View Full Student Dossier"
                      >
                        <Eye className="w-3 h-3" />
                        <span>Profile</span>
                      </Button>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
