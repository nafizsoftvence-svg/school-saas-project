import React, { useState } from 'react';
import {
  Search,
  Filter,
  X,
  RotateCcw,
  Calendar,
  Layers,
  GraduationCap,
  ShieldCheck,
  CreditCard,
  FileCheck,
  Users,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { Button } from '../ui/Button.js';
import { Input } from '../ui/Input.js';
import { Select } from '../ui/Select.js';
import { SchoolClass, Section, AcademicSession } from '../../types/index.js';

export interface FilterState {
  search: string;
  academicSessionId: string;
  classId: string;
  sectionId: string;
  status: string;
  enrollmentStatus: string;
  gender: string;
  bloodGroup: string;
  admissionDateFrom: string;
  admissionDateTo: string;
  enrollmentDateFrom: string;
  enrollmentDateTo: string;
  documentStatus: string;
  idCardStatus: string;
}

interface StudentSearchFilterBarProps {
  filters: FilterState;
  onChange: (newFilters: FilterState) => void;
  onApply: () => void;
  onReset: () => void;
  sessions: AcademicSession[];
  classes: SchoolClass[];
  sections: Section[];
  isLoading?: boolean;
}

export const StudentSearchFilterBar: React.FC<StudentSearchFilterBarProps> = ({
  filters,
  onChange,
  onApply,
  onReset,
  sessions = [],
  classes = [],
  sections = [],
  isLoading = false
}) => {
  const [showAdvanced, setShowAdvanced] = useState(false);

  // Cascading sections for chosen class
  const availableSections = filters.classId && filters.classId !== 'ALL'
    ? (sections || []).filter((s) => s.classId === filters.classId)
    : (sections || []);

  const updateField = (field: keyof FilterState, value: string) => {
    const updated = { ...filters, [field]: value };
    // If classId changes and selected section does not belong to new class, reset sectionId
    if (field === 'classId' && value !== 'ALL') {
      const secBelongs = (sections || []).some((s) => s.classId === value && s.id === updated.sectionId);
      if (!secBelongs) updated.sectionId = 'ALL';
    }
    onChange(updated);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      onApply();
    }
  };

  // Active filters list for chips
  const activeChips = [
    filters.search && { key: 'search', label: `Search: "${filters.search}"` },
    filters.academicSessionId !== 'ALL' && {
      key: 'academicSessionId',
      label: `Session: ${(sessions || []).find((s) => s?.id === filters.academicSessionId)?.sessionName || filters.academicSessionId}`
    },
    filters.classId !== 'ALL' && {
      key: 'classId',
      label: `Class: ${(classes || []).find((c) => c?.id === filters.classId)?.name || filters.classId}`
    },
    filters.sectionId !== 'ALL' && {
      key: 'sectionId',
      label: `Section: ${(sections || []).find((s) => s?.id === filters.sectionId)?.name || filters.sectionId}`
    },
    filters.status !== 'ALL' && { key: 'status', label: `Status: ${filters.status}` },
    filters.enrollmentStatus !== 'ALL' && { key: 'enrollmentStatus', label: `Enrollment: ${filters.enrollmentStatus}` },
    filters.gender !== 'ALL' && { key: 'gender', label: `Gender: ${filters.gender}` },
    filters.bloodGroup !== 'ALL' && { key: 'bloodGroup', label: `Blood: ${filters.bloodGroup}` },
    filters.documentStatus !== 'ALL' && { key: 'documentStatus', label: `Docs: ${filters.documentStatus}` },
    filters.idCardStatus !== 'ALL' && { key: 'idCardStatus', label: `ID Card: ${filters.idCardStatus}` },
    filters.admissionDateFrom && { key: 'admissionDateFrom', label: `Adm >= ${filters.admissionDateFrom}` },
    filters.admissionDateTo && { key: 'admissionDateTo', label: `Adm <= ${filters.admissionDateTo}` },
    filters.enrollmentDateFrom && { key: 'enrollmentDateFrom', label: `Enr >= ${filters.enrollmentDateFrom}` },
    filters.enrollmentDateTo && { key: 'enrollmentDateTo', label: `Enr <= ${filters.enrollmentDateTo}` }
  ].filter(Boolean) as Array<{ key: keyof FilterState; label: string }>;

  return (
    <div className="bg-white border border-slate-200 rounded-2xl shadow-xs p-4 sm:p-5 mb-5 transition-all">
      {/* Search Input Row & Primary Actions */}
      <div className="flex flex-col lg:flex-row items-stretch lg:items-center gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
          <Input
            value={filters.search}
            onChange={(e) => updateField('search', e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Search by student name, ID, admission #, roll, phone, email, guardian..."
            className="pl-10 pr-9 py-2 text-sm w-full bg-slate-50/50 hover:bg-slate-50 focus:bg-white"
          />
          {filters.search && (
            <button
              type="button"
              onClick={() => {
                updateField('search', '');
                onApply();
              }}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-0.5"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Core Dropdowns on primary bar */}
        <div className="flex items-center gap-2 flex-wrap">
          <div className="w-36">
            <Select
              value={filters.classId}
              onChange={(e) => updateField('classId', e.target.value)}
              className="text-xs py-1.5 h-9"
            >
              <option value="ALL">All Classes</option>
              {classes.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </Select>
          </div>

          <div className="w-32">
            <Select
              value={filters.sectionId}
              onChange={(e) => updateField('sectionId', e.target.value)}
              className="text-xs py-1.5 h-9"
              disabled={filters.classId === 'ALL'}
            >
              <option value="ALL">All Sections</option>
              {availableSections.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </Select>
          </div>

          <div className="w-32">
            <Select
              value={filters.status}
              onChange={(e) => updateField('status', e.target.value)}
              className="text-xs py-1.5 h-9"
            >
              <option value="ALL">All Statuses</option>
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
              <option value="suspended">Suspended</option>
              <option value="withdrawn">Withdrawn</option>
              <option value="graduated">Graduated</option>
            </Select>
          </div>

          <Button
            type="button"
            variant="primary"
            size="sm"
            onClick={onApply}
            disabled={isLoading}
            className="h-9 px-4 text-xs font-medium"
          >
            {isLoading ? 'Filtering...' : 'Apply Filters'}
          </Button>

          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => setShowAdvanced(!showAdvanced)}
            className="h-9 px-3 text-xs font-medium flex items-center gap-1 text-slate-700 hover:bg-slate-50"
          >
            <Filter className="w-3.5 h-3.5 text-slate-500" />
            <span>More Filters</span>
            {showAdvanced ? (
              <ChevronUp className="w-3.5 h-3.5 ml-0.5 text-slate-400" />
            ) : (
              <ChevronDown className="w-3.5 h-3.5 ml-0.5 text-slate-400" />
            )}
          </Button>

          {activeChips.length > 0 && (
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={onReset}
              className="h-9 px-2.5 text-xs text-slate-500 hover:text-rose-600 hover:bg-rose-50 flex items-center gap-1"
              title="Reset all filters to defaults"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Reset
            </Button>
          )}
        </div>
      </div>

      {/* Advanced Filter Drawer */}
      {showAdvanced && (
        <div className="mt-4 pt-4 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 bg-slate-50/60 p-4 rounded-xl">
          {/* Academic Session */}
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1">Academic Session</label>
            <Select
              value={filters.academicSessionId}
              onChange={(e) => updateField('academicSessionId', e.target.value)}
              className="text-xs h-8"
            >
              <option value="ALL">All Academic Sessions</option>
              {sessions.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.sessionName} {s.isCurrent ? '(Active)' : ''}
                </option>
              ))}
            </Select>
          </div>

          {/* Gender */}
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1">Gender</label>
            <Select
              value={filters.gender}
              onChange={(e) => updateField('gender', e.target.value)}
              className="text-xs h-8"
            >
              <option value="ALL">All Genders</option>
              <option value="male">Male</option>
              <option value="female">Female</option>
              <option value="other">Other</option>
            </Select>
          </div>

          {/* Blood Group */}
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1">Blood Group</label>
            <Select
              value={filters.bloodGroup}
              onChange={(e) => updateField('bloodGroup', e.target.value)}
              className="text-xs h-8"
            >
              <option value="ALL">All Blood Groups</option>
              <option value="A+">A+</option>
              <option value="A-">A-</option>
              <option value="B+">B+</option>
              <option value="B-">B-</option>
              <option value="O+">O+</option>
              <option value="O-">O-</option>
              <option value="AB+">AB+</option>
              <option value="AB-">AB-</option>
            </Select>
          </div>

          {/* Enrollment Status */}
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1">Enrollment Status</label>
            <Select
              value={filters.enrollmentStatus}
              onChange={(e) => updateField('enrollmentStatus', e.target.value)}
              className="text-xs h-8"
            >
              <option value="ALL">All Enrollment Statuses</option>
              <option value="active">Active</option>
              <option value="pending">Pending</option>
              <option value="suspended">Suspended</option>
              <option value="transferred">Transferred</option>
              <option value="graduated">Graduated</option>
              <option value="withdrawn">Withdrawn</option>
            </Select>
          </div>

          {/* Document Compliance */}
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1">Document Status</label>
            <Select
              value={filters.documentStatus}
              onChange={(e) => updateField('documentStatus', e.target.value)}
              className="text-xs h-8"
            >
              <option value="ALL">All Document Statuses</option>
              <option value="verified">Verified & Complete</option>
              <option value="pending_verification">Pending Verification</option>
              <option value="incomplete">Incomplete / Missing</option>
            </Select>
          </div>

          {/* ID Card Status */}
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1">ID Card Status</label>
            <Select
              value={filters.idCardStatus}
              onChange={(e) => updateField('idCardStatus', e.target.value)}
              className="text-xs h-8"
            >
              <option value="ALL">All Card Statuses</option>
              <option value="issued">Issued / Active</option>
              <option value="not_issued">Not Issued</option>
              <option value="blocked">Blocked / Lost</option>
            </Select>
          </div>

          {/* Admission Date Range */}
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1">Admission Date Range</label>
            <div className="flex items-center gap-1.5">
              <input
                type="date"
                value={filters.admissionDateFrom}
                onChange={(e) => updateField('admissionDateFrom', e.target.value)}
                className="w-full text-xs py-1 px-2 border border-slate-300 rounded-md bg-white"
                placeholder="From"
              />
              <span className="text-slate-400 text-xs">-</span>
              <input
                type="date"
                value={filters.admissionDateTo}
                onChange={(e) => updateField('admissionDateTo', e.target.value)}
                className="w-full text-xs py-1 px-2 border border-slate-300 rounded-md bg-white"
                placeholder="To"
              />
            </div>
          </div>

          {/* Enrollment Date Range */}
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1">Enrollment Date Range</label>
            <div className="flex items-center gap-1.5">
              <input
                type="date"
                value={filters.enrollmentDateFrom}
                onChange={(e) => updateField('enrollmentDateFrom', e.target.value)}
                className="w-full text-xs py-1 px-2 border border-slate-300 rounded-md bg-white"
                placeholder="From"
              />
              <span className="text-slate-400 text-xs">-</span>
              <input
                type="date"
                value={filters.enrollmentDateTo}
                onChange={(e) => updateField('enrollmentDateTo', e.target.value)}
                className="w-full text-xs py-1 px-2 border border-slate-300 rounded-md bg-white"
                placeholder="To"
              />
            </div>
          </div>
        </div>
      )}

      {/* Active Filter Chips */}
      {activeChips.length > 0 && (
        <div className="flex items-center flex-wrap gap-1.5 mt-3 pt-3 border-t border-slate-100">
          <span className="text-xs text-slate-400 font-medium mr-1">Active filters:</span>
          {activeChips.map((chip) => (
            <span
              key={chip.key}
              className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-slate-100 text-slate-700 border border-slate-200"
            >
              {chip.label}
              <button
                type="button"
                onClick={() => {
                  updateField(chip.key, chip.key === 'classId' || chip.key === 'sectionId' || chip.key === 'academicSessionId' || chip.key === 'status' || chip.key === 'enrollmentStatus' || chip.key === 'gender' || chip.key === 'bloodGroup' || chip.key === 'documentStatus' || chip.key === 'idCardStatus' ? 'ALL' : '');
                  onApply();
                }}
                className="hover:text-slate-900 rounded-full hover:bg-slate-200 p-0.5 transition-colors"
              >
                <X className="w-3 h-3" />
              </button>
            </span>
          ))}
          <button
            type="button"
            onClick={onReset}
            className="text-xs text-indigo-600 hover:text-indigo-800 font-medium underline ml-1"
          >
            Clear all
          </button>
        </div>
      )}
    </div>
  );
};
