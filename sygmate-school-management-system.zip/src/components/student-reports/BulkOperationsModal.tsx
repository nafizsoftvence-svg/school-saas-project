import React, { useState } from 'react';
import {
  ShieldAlert,
  AlertTriangle,
  CheckCircle2,
  Users,
  CreditCard,
  ArrowRightLeft,
  Archive,
  RefreshCw,
  X
} from 'lucide-react';
import { Modal } from '../ui/Modal.js';
import { Button } from '../ui/Button.js';
import { Select } from '../ui/Select.js';
import { Input } from '../ui/Input.js';
import { Alert } from '../ui/Alert.js';
import { LoadingSpinner } from '../ui/LoadingSpinner.js';
import { api } from '../../services/api.js';
import { StudentReportItem, SchoolClass, Section } from '../../types/index.js';

interface BulkOperationsModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedStudents: StudentReportItem[];
  classes: SchoolClass[];
  sections: Section[];
  onSuccess: () => void;
}

type BulkActionType = 'STATUS_UPDATE' | 'SECTION_REASSIGN' | 'GENERATE_ID_CARDS' | 'ARCHIVE';

export const BulkOperationsModal: React.FC<BulkOperationsModalProps> = ({
  isOpen,
  onClose,
  selectedStudents,
  classes,
  sections,
  onSuccess
}) => {
  const [actionType, setActionType] = useState<BulkActionType>('STATUS_UPDATE');
  const [targetStatus, setTargetStatus] = useState<string>('active');
  const [targetClassId, setTargetClassId] = useState<string>('');
  const [targetSectionId, setTargetSectionId] = useState<string>('');
  const [reason, setReason] = useState<string>('');
  const [confirmedSafe, setConfirmedSafe] = useState<boolean>(false);

  const [executing, setExecuting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [resultNotice, setResultNotice] = useState<string | null>(null);

  // Filter sections based on selected class
  const availableSections = targetClassId
    ? sections.filter((s) => s.classId === targetClassId)
    : sections;

  const handleExecute = async () => {
    if (!reason.trim()) {
      setError('A valid audit reason is strictly required before executing bulk operations.');
      return;
    }

    if (actionType === 'SECTION_REASSIGN' && !targetSectionId) {
      setError('Please select a target section for reassignment.');
      return;
    }

    if (!confirmedSafe) {
      setError('Please verify and confirm the safety checkbox.');
      return;
    }

    try {
      setExecuting(true);
      setError(null);

      const studentIds = selectedStudents.map((s) => s.id);
      const res = await api.studentReports.executeBulkAction({
        action: actionType,
        studentIds,
        targetStatus: actionType === 'ARCHIVE' ? 'inactive' : targetStatus,
        targetClassId: targetClassId || undefined,
        targetSectionId: targetSectionId || undefined,
        reason: reason.trim()
      });

      if (res.success) {
        setResultNotice(res.message);
        setTimeout(() => {
          onSuccess();
          onClose();
        }, 1500);
      } else {
        setError(res.message || 'Operation failed');
      }
    } catch (err: any) {
      setError(err.message || 'Bulk operation failed to complete.');
    } finally {
      setExecuting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={
        <div className="flex items-center gap-2 text-slate-800">
          <ShieldAlert className="w-5 h-5 text-indigo-600" />
          <span>Execute Bulk Student Operation</span>
        </div>
      }
      maxWidth="max-w-2xl"
    >
      <div className="space-y-4">
        {/* Selected count banner */}
        <div className="flex items-center justify-between bg-indigo-50/70 border border-indigo-200/80 rounded-xl p-3.5">
          <div className="flex items-center gap-2.5">
            <Users className="w-5 h-5 text-indigo-600" />
            <div>
              <p className="text-sm font-semibold text-indigo-900">
                {selectedStudents.length} {selectedStudents.length === 1 ? 'Student' : 'Students'} Selected
              </p>
              <p className="text-xs text-indigo-700">
                Action will be applied synchronously across all selected records.
              </p>
            </div>
          </div>
          <span className="text-xs font-bold uppercase tracking-wider bg-indigo-200/60 text-indigo-900 px-2 py-1 rounded">
            Batch Mode
          </span>
        </div>

        {/* Selected students preview pill list */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1.5">
            Affected Student Sample ({selectedStudents.length} total)
          </label>
          <div className="max-h-28 overflow-y-auto bg-slate-50 border border-slate-200 rounded-lg p-2 flex flex-wrap gap-1.5">
            {selectedStudents.map((s) => (
              <span
                key={s.id}
                className="inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-md bg-white border border-slate-200 text-slate-700 shadow-2xs"
              >
                <span className="font-medium">{s.fullName}</span>
                <span className="text-slate-400">({s.admissionNumber})</span>
              </span>
            ))}
          </div>
        </div>

        {/* Action Type Selector */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1.5">Select Bulk Action</label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            <button
              type="button"
              onClick={() => {
                setActionType('STATUS_UPDATE');
                setConfirmedSafe(false);
              }}
              className={`flex flex-col items-center justify-center p-3 rounded-xl border text-center transition-all ${
                actionType === 'STATUS_UPDATE'
                  ? 'bg-indigo-50/80 border-indigo-500 text-indigo-950 ring-2 ring-indigo-200'
                  : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
              }`}
            >
              <RefreshCw className="w-4 h-4 text-indigo-600 mb-1" />
              <span className="text-xs font-semibold">Change Status</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setActionType('SECTION_REASSIGN');
                setConfirmedSafe(false);
              }}
              className={`flex flex-col items-center justify-center p-3 rounded-xl border text-center transition-all ${
                actionType === 'SECTION_REASSIGN'
                  ? 'bg-indigo-50/80 border-indigo-500 text-indigo-950 ring-2 ring-indigo-200'
                  : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
              }`}
            >
              <ArrowRightLeft className="w-4 h-4 text-emerald-600 mb-1" />
              <span className="text-xs font-semibold">Reassign Section</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setActionType('GENERATE_ID_CARDS');
                setConfirmedSafe(false);
              }}
              className={`flex flex-col items-center justify-center p-3 rounded-xl border text-center transition-all ${
                actionType === 'GENERATE_ID_CARDS'
                  ? 'bg-indigo-50/80 border-indigo-500 text-indigo-950 ring-2 ring-indigo-200'
                  : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
              }`}
            >
              <CreditCard className="w-4 h-4 text-amber-600 mb-1" />
              <span className="text-xs font-semibold">Generate ID Cards</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setActionType('ARCHIVE');
                setConfirmedSafe(false);
              }}
              className={`flex flex-col items-center justify-center p-3 rounded-xl border text-center transition-all ${
                actionType === 'ARCHIVE'
                  ? 'bg-indigo-50/80 border-indigo-500 text-indigo-950 ring-2 ring-indigo-200'
                  : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
              }`}
            >
              <Archive className="w-4 h-4 text-rose-600 mb-1" />
              <span className="text-xs font-semibold">Bulk Archive</span>
            </button>
          </div>
        </div>

        {/* Action-Specific Parameters */}
        {actionType === 'STATUS_UPDATE' && (
          <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-2">
            <label className="block text-xs font-semibold text-slate-700">Target Student Status</label>
            <Select
              value={targetStatus}
              onChange={(e) => setTargetStatus(e.target.value)}
              className="text-xs bg-white"
            >
              <option value="active">Active (Standard Standing)</option>
              <option value="inactive">Inactive (Administrative Hold)</option>
              <option value="suspended">Suspended (Disciplinary Hold)</option>
              <option value="withdrawn">Withdrawn (Voluntary Departure)</option>
              <option value="graduated">Graduated / Alumni</option>
            </Select>
            <p className="text-2xs text-slate-500">
              Each student's previous status will be securely saved into their student status history ledger.
            </p>
          </div>
        )}

        {actionType === 'SECTION_REASSIGN' && (
          <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Target Class (Optional override)</label>
              <Select
                value={targetClassId}
                onChange={(e) => {
                  setTargetClassId(e.target.value);
                  setTargetSectionId('');
                }}
                className="text-xs bg-white"
              >
                <option value="">Keep Existing Student Class</option>
                {classes.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </Select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Target Section *</label>
              <Select
                value={targetSectionId}
                onChange={(e) => setTargetSectionId(e.target.value)}
                className="text-xs bg-white"
              >
                <option value="">Select Target Section</option>
                {availableSections.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name} ({s.roomNumber ? `Room ${s.roomNumber}` : 'Standard'})
                  </option>
                ))}
              </Select>
            </div>
          </div>
        )}

        {actionType === 'GENERATE_ID_CARDS' && (
          <div className="bg-amber-50/70 p-3.5 rounded-xl border border-amber-200 text-xs text-amber-900 space-y-1">
            <p className="font-semibold flex items-center gap-1.5 text-amber-800">
              <CreditCard className="w-4 h-4" />
              Batch ID Card Generator
            </p>
            <p>
              This operation will check each selected student. For students without an existing card, an official card number and QR token will be generated. Existing cards will be updated to ISSUED.
            </p>
          </div>
        )}

        {actionType === 'ARCHIVE' && (
          <div className="bg-rose-50/70 p-3.5 rounded-xl border border-rose-200 text-xs text-rose-900 space-y-1">
            <p className="font-semibold flex items-center gap-1.5 text-rose-800">
              <AlertTriangle className="w-4 h-4" />
              High Impact Operation: Archive
            </p>
            <p>
              Archiving students sets their enrollment status to 'inactive' and preserves all historical academic and financial records. They will not be counted in active class rosters.
            </p>
          </div>
        )}

        {/* Mandatory Reason Input */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            Mandatory Audit Reason / Notes *
          </label>
          <Input
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            placeholder="e.g. End-of-term administrative review, section rebalancing, batch issuance"
            className="text-xs py-2 w-full"
          />
          <p className="text-2xs text-slate-500 mt-1">
            This reason is recorded immutably in the institution's Audit Trail Logs.
          </p>
        </div>

        {/* Verification Checkbox */}
        <div className="flex items-start gap-2 pt-1">
          <input
            type="checkbox"
            id="confirmBulkSafe"
            checked={confirmedSafe}
            onChange={(e) => setConfirmedSafe(e.target.checked)}
            className="mt-0.5 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
          />
          <label htmlFor="confirmBulkSafe" className="text-xs text-slate-700 leading-snug cursor-pointer">
            I confirm that I have verified the selected student list ({selectedStudents.length} students) and authorize this bulk change.
          </label>
        </div>

        {/* Alerts */}
        {error && (
          <Alert variant="danger" className="text-xs py-2">
            {error}
          </Alert>
        )}

        {resultNotice && (
          <Alert variant="success" className="text-xs py-2">
            {resultNotice}
          </Alert>
        )}

        {/* Action Buttons */}
        <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={onClose}
            disabled={executing}
          >
            Cancel
          </Button>

          <Button
            type="button"
            variant="primary"
            size="sm"
            onClick={handleExecute}
            disabled={executing || !confirmedSafe || !reason.trim()}
            className="flex items-center gap-1.5"
          >
            {executing ? (
              <>
                <LoadingSpinner size="sm" />
                <span>Executing Batch...</span>
              </>
            ) : (
              <span>Execute for {selectedStudents.length} Students</span>
            )}
          </Button>
        </div>
      </div>
    </Modal>
  );
};
