import React, { useState, useEffect } from 'react';
import {
  X,
  ChevronRight,
  ChevronLeft,
  Save,
  CheckCircle2,
  AlertTriangle,
  AlertCircle,
  Upload,
  Trash2,
  FileText,
  User,
  Phone,
  Mail,
  MapPin,
  Calendar,
  School,
  ShieldAlert,
  Search,
  Check,
  GraduationCap,
  Sparkles,
  DollarSign
} from 'lucide-react';
import { api } from '../../services/api';
import {
  AdmissionApplication,
  AdmissionDocument,
  AdmissionApplicationStatus,
  SchoolClass,
  Section,
  AcademicSession,
  Guardian,
  DuplicateStudentMatch,
  DuplicateStudentCheckResult,
  FeeStructure
} from '../../types';

interface AdmissionApplicationWizardModalProps {
  isOpen: boolean;
  onClose: () => void;
  applicationToEdit?: AdmissionApplication | null;
  enquiryToConvert?: any | null;
  onSuccess: (app: AdmissionApplication, enrolled?: boolean) => void;
}

const STEPS = [
  { id: 1, title: 'Student Info', subtitle: 'Personal & demographics' },
  { id: 2, title: 'Guardian Info', subtitle: 'Parent & emergency' },
  { id: 3, title: 'Placement', subtitle: 'Class, section & fees' },
  { id: 4, title: 'Documents', subtitle: 'Certificates & identity' },
  { id: 5, title: 'Review & Enroll', subtitle: 'Validation & submission' }
];

export const AdmissionApplicationWizardModal: React.FC<AdmissionApplicationWizardModalProps> = ({
  isOpen,
  onClose,
  applicationToEdit,
  enquiryToConvert,
  onSuccess
}) => {
  const [currentStep, setCurrentStep] = useState(1);
  const [classes, setClasses] = useState<SchoolClass[]>([]);
  const [sections, setSections] = useState<Section[]>([]);
  const [sessions, setSessions] = useState<AcademicSession[]>([]);
  const [guardians, setGuardians] = useState<Guardian[]>([]);
  const [guardianSearch, setGuardianSearch] = useState('');
  const [feeStructures, setFeeStructures] = useState<FeeStructure[]>([]);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Duplicate check state
  const [checkingDuplicates, setCheckingDuplicates] = useState(false);
  const [duplicateMatches, setDuplicateMatches] = useState<DuplicateStudentMatch[]>([]);
  const [bypassDuplicateWarning, setBypassDuplicateWarning] = useState(false);

  // Form State
  const [formData, setFormData] = useState({
    // Step 1: Student
    firstName: '',
    middleName: '',
    lastName: '',
    dateOfBirth: '',
    gender: 'male',
    bloodGroup: '',
    nationality: 'United States',
    religion: '',
    category: 'General',
    email: '',
    phone: '',
    address: '',
    presentAddress: '',
    permanentAddress: '',
    city: '',
    postalCode: '',
    avatarUrl: '',
    previousSchoolName: '',
    previousClass: '',
    previousMarksPercentage: '',
    previousSchoolBoard: '',
    transferCertificateNumber: '',

    // Step 2: Guardian
    guardianMode: 'new' as 'new' | 'existing',
    guardianId: '',
    guardianName: '',
    guardianRelation: 'Father',
    guardianPhone: '',
    guardianEmail: '',
    guardianAddress: '',
    guardianOccupation: '',
    emergencyContact: '',
    fatherName: '',
    fatherPhone: '',
    fatherEmail: '',
    fatherOccupation: '',
    motherName: '',
    motherPhone: '',
    motherEmail: '',
    motherOccupation: '',

    // Step 3: Placement
    academicSessionId: '',
    classId: '',
    sectionId: '',
    preferredRollNumber: '',
    autoAssignRoll: true,
    applicationDate: new Date().toISOString().split('T')[0],
    admissionDate: new Date().toISOString().split('T')[0],
    admissionFeeStructureId: '',
    assignAdmissionFee: true,

    // Step 4: Documents
    documents: [] as AdmissionDocument[],

    // Meta
    enquiryId: '',
    enquiryNumber: ''
  });

  // Load Reference Data
  useEffect(() => {
    if (!isOpen) return;

    const loadMeta = async () => {
      try {
        const [clsRes, sessRes, secRes, guardRes, feeRes] = await Promise.all([
          api.getClasses(),
          api.getAcademicSessions(),
          api.getSections(),
          api.getGuardians ? api.getGuardians() : Promise.resolve({ success: true, data: [] }),
          api.fees ? api.fees.getFeeStructures() : Promise.resolve({ success: true, data: [] })
        ]);

        if (clsRes.success && clsRes.data) setClasses(clsRes.data);
        if (sessRes.success && sessRes.data) setSessions(sessRes.data);
        if (secRes.success && secRes.data) setSections(secRes.data);
        if (guardRes.success && guardRes.data) setGuardians(guardRes.data);
        if (feeRes.success && feeRes.data) setFeeStructures(feeRes.data);
      } catch (err) {
        console.error('Failed to load metadata', err);
      }
    };
    loadMeta();
  }, [isOpen]);

  // Pre-fill on open (edit or convert or fresh)
  useEffect(() => {
    if (!isOpen) return;
    setCurrentStep(1);
    setError(null);
    setDuplicateMatches([]);
    setBypassDuplicateWarning(false);

    if (applicationToEdit) {
      setFormData({
        firstName: applicationToEdit.firstName || '',
        middleName: applicationToEdit.middleName || '',
        lastName: applicationToEdit.lastName || '',
        dateOfBirth: applicationToEdit.dateOfBirth || '',
        gender: applicationToEdit.gender || 'male',
        bloodGroup: applicationToEdit.bloodGroup || '',
        nationality: applicationToEdit.nationality || 'United States',
        religion: applicationToEdit.religion || '',
        category: applicationToEdit.category || 'General',
        email: applicationToEdit.email || '',
        phone: applicationToEdit.phone || '',
        address: applicationToEdit.address || '',
        presentAddress: applicationToEdit.presentAddress || applicationToEdit.address || '',
        permanentAddress: applicationToEdit.permanentAddress || applicationToEdit.address || '',
        city: applicationToEdit.city || '',
        postalCode: applicationToEdit.postalCode || '',
        avatarUrl: applicationToEdit.avatarUrl || '',
        previousSchoolName: applicationToEdit.previousSchoolName || '',
        previousClass: applicationToEdit.previousClass || '',
        previousMarksPercentage: applicationToEdit.previousMarksPercentage ? String(applicationToEdit.previousMarksPercentage) : '',
        previousSchoolBoard: applicationToEdit.previousSchoolBoard || '',
        transferCertificateNumber: applicationToEdit.transferCertificateNumber || '',

        guardianMode: applicationToEdit.guardianMode || 'new',
        guardianId: applicationToEdit.guardianId || '',
        guardianName: applicationToEdit.guardianName || '',
        guardianRelation: applicationToEdit.guardianRelation || 'Father',
        guardianPhone: applicationToEdit.guardianPhone || '',
        guardianEmail: applicationToEdit.guardianEmail || '',
        guardianAddress: applicationToEdit.guardianAddress || applicationToEdit.address || '',
        guardianOccupation: applicationToEdit.guardianOccupation || '',
        emergencyContact: applicationToEdit.emergencyContact || applicationToEdit.guardianPhone || '',
        fatherName: applicationToEdit.fatherName || '',
        fatherPhone: applicationToEdit.fatherPhone || '',
        fatherEmail: applicationToEdit.fatherEmail || '',
        fatherOccupation: applicationToEdit.fatherOccupation || '',
        motherName: applicationToEdit.motherName || '',
        motherPhone: applicationToEdit.motherPhone || '',
        motherEmail: applicationToEdit.motherEmail || '',
        motherOccupation: applicationToEdit.motherOccupation || '',

        academicSessionId: applicationToEdit.academicSessionId || '',
        classId: applicationToEdit.classId || '',
        sectionId: applicationToEdit.sectionId || '',
        preferredRollNumber: applicationToEdit.preferredRollNumber || '',
        autoAssignRoll: !applicationToEdit.preferredRollNumber,
        applicationDate: applicationToEdit.applicationDate || new Date().toISOString().split('T')[0],
        admissionDate: applicationToEdit.admissionDate || new Date().toISOString().split('T')[0],
        admissionFeeStructureId: applicationToEdit.admissionFeeStructureId || '',
        assignAdmissionFee: applicationToEdit.assignAdmissionFee !== false,

        documents: applicationToEdit.documents || [],
        enquiryId: applicationToEdit.enquiryId || '',
        enquiryNumber: applicationToEdit.enquiryNumber || ''
      });
    } else if (enquiryToConvert) {
      // Pre-fill from enquiry
      const nameParts = (enquiryToConvert.studentName || '').trim().split(' ');
      const firstName = nameParts[0] || 'Applicant';
      const lastName = nameParts.length > 1 ? nameParts.slice(1).join(' ') : 'Student';

      setFormData({
        firstName,
        middleName: '',
        lastName,
        dateOfBirth: enquiryToConvert.dateOfBirth || '',
        gender: enquiryToConvert.gender || 'male',
        bloodGroup: '',
        nationality: 'United States',
        religion: '',
        category: 'General',
        email: enquiryToConvert.email || '',
        phone: enquiryToConvert.phone || '',
        address: enquiryToConvert.address || '',
        presentAddress: enquiryToConvert.address || '',
        permanentAddress: enquiryToConvert.address || '',
        city: '',
        postalCode: '',
        avatarUrl: '',
        previousSchoolName: '',
        previousClass: '',
        previousMarksPercentage: '',
        previousSchoolBoard: '',
        transferCertificateNumber: '',

        guardianMode: 'new',
        guardianId: '',
        guardianName: enquiryToConvert.parentName || '',
        guardianRelation: enquiryToConvert.relationship || 'Father',
        guardianPhone: enquiryToConvert.phone || '',
        guardianEmail: enquiryToConvert.email || '',
        guardianAddress: enquiryToConvert.address || '',
        guardianOccupation: '',
        emergencyContact: enquiryToConvert.phone || '',
        fatherName: enquiryToConvert.parentName || '',
        fatherPhone: enquiryToConvert.phone || '',
        fatherEmail: enquiryToConvert.email || '',
        fatherOccupation: '',
        motherName: '',
        motherPhone: '',
        motherEmail: '',
        motherOccupation: '',

        academicSessionId: enquiryToConvert.academicSessionId || '',
        classId: enquiryToConvert.applyingClassId || '',
        sectionId: '',
        preferredRollNumber: '',
        autoAssignRoll: true,
        applicationDate: new Date().toISOString().split('T')[0],
        admissionDate: new Date().toISOString().split('T')[0],
        admissionFeeStructureId: '',
        assignAdmissionFee: true,

        documents: [],
        enquiryId: enquiryToConvert.id || '',
        enquiryNumber: enquiryToConvert.enquiryNumber || ''
      });
    } else {
      // Fresh new application
      setFormData({
        firstName: '',
        middleName: '',
        lastName: '',
        dateOfBirth: '',
        gender: 'male',
        bloodGroup: '',
        nationality: 'United States',
        religion: '',
        category: 'General',
        email: '',
        phone: '',
        address: '',
        presentAddress: '',
        permanentAddress: '',
        city: '',
        postalCode: '',
        avatarUrl: '',
        previousSchoolName: '',
        previousClass: '',
        previousMarksPercentage: '',
        previousSchoolBoard: '',
        transferCertificateNumber: '',

        guardianMode: 'new',
        guardianId: '',
        guardianName: '',
        guardianRelation: 'Father',
        guardianPhone: '',
        guardianEmail: '',
        guardianAddress: '',
        guardianOccupation: '',
        emergencyContact: '',
        fatherName: '',
        fatherPhone: '',
        fatherEmail: '',
        fatherOccupation: '',
        motherName: '',
        motherPhone: '',
        motherEmail: '',
        motherOccupation: '',

        academicSessionId: '',
        classId: '',
        sectionId: '',
        preferredRollNumber: '',
        autoAssignRoll: true,
        applicationDate: new Date().toISOString().split('T')[0],
        admissionDate: new Date().toISOString().split('T')[0],
        admissionFeeStructureId: '',
        assignAdmissionFee: true,

        documents: [],
        enquiryId: '',
        enquiryNumber: ''
      });
    }
  }, [isOpen, applicationToEdit, enquiryToConvert]);

  // Set default class, session, section if unselected
  useEffect(() => {
    if (isOpen && classes && classes.length > 0 && !formData.classId) {
      setFormData(prev => ({ ...prev, classId: classes?.[0]?.id || '' }));
    }
    if (isOpen && sessions && sessions.length > 0 && !formData.academicSessionId) {
      const active = (sessions || []).find(s => s.status === 'active') || sessions?.[0];
      if (active) {
        setFormData(prev => ({ ...prev, academicSessionId: active.id }));
      }
    }
  }, [isOpen, classes, sessions]);

  // Update section options when class changes
  const availableSections = (sections || []).filter(s => s.classId === formData.classId);

  useEffect(() => {
    if (availableSections && availableSections.length > 0 && !formData.sectionId) {
      setFormData(prev => ({ ...prev, sectionId: availableSections?.[0]?.id || '' }));
    }
  }, [formData.classId, availableSections]);

  // Filter existing guardians for search
  const filteredGuardians = guardians.filter(g => {
    if (!guardianSearch.trim()) return true;
    const q = guardianSearch.toLowerCase();
    return g.name.toLowerCase().includes(q) || g.phone.includes(q) || g.email.toLowerCase().includes(q);
  });

  const handleSelectExistingGuardian = (guardian: Guardian) => {
    setFormData(prev => ({
      ...prev,
      guardianMode: 'existing',
      guardianId: guardian.id,
      guardianName: guardian.name,
      guardianRelation: guardian.relationship || 'Parent',
      guardianPhone: guardian.phone || '',
      guardianEmail: guardian.email || '',
      guardianAddress: guardian.address || '',
      guardianOccupation: guardian.occupation || '',
      emergencyContact: guardian.phone || prev.emergencyContact
    }));
  };

  // Run duplicate check when entering Step 5
  const triggerDuplicateCheck = async () => {
    try {
      setCheckingDuplicates(true);
      const res = await api.admissions.checkDuplicates({
        email: formData.email,
        firstName: formData.firstName,
        lastName: formData.lastName,
        dateOfBirth: formData.dateOfBirth,
        guardianPhone: formData.guardianPhone,
        transferCertificateNumber: formData.transferCertificateNumber,
        excludeApplicationId: applicationToEdit ? applicationToEdit.id : undefined
      });

      if (res.success && res.data) {
        setDuplicateMatches(res.data.matches || []);
      }
    } catch (err) {
      console.error('Error running duplicate check', err);
    } finally {
      setCheckingDuplicates(false);
    }
  };

  const handleNextStep = () => {
    setError(null);

    // Validation per step
    if (currentStep === 1) {
      if (!formData.firstName.trim() || !formData.lastName.trim()) {
        setError('First Name and Last Name are required.');
        return;
      }
      if (!formData.dateOfBirth) {
        setError('Date of Birth is required.');
        return;
      }
    } else if (currentStep === 2) {
      if (!formData.guardianName.trim() || !formData.guardianPhone.trim()) {
        setError('Primary Guardian Name and Contact Phone are required.');
        return;
      }
    } else if (currentStep === 3) {
      if (!formData.classId || !formData.academicSessionId) {
        setError('Target Class and Academic Session must be selected.');
        return;
      }
    } else if (currentStep === 4) {
      // Trigger duplicate check right as we move to Step 5
      triggerDuplicateCheck();
    }

    setCurrentStep(prev => Math.min(5, prev + 1));
  };

  const handlePrevStep = () => {
    setError(null);
    setCurrentStep(prev => Math.max(1, prev - 1));
  };

  // Document management
  const handleAddDocument = (category: string, name: string) => {
    if (!name.trim()) return;
    const newDoc: AdmissionDocument = {
      id: `doc-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      name: name.trim(),
      category: category as any,
      type: 'application/pdf',
      url: `https://storage.sygmate.edu/admissions/docs/${Date.now()}_${name.replace(/\s+/g, '_')}.pdf`,
      size: '154 KB',
      uploadedAt: new Date().toISOString()
    };
    setFormData(prev => ({
      ...prev,
      documents: [...prev.documents, newDoc]
    }));
  };

  const handleRemoveDocument = (docId: string) => {
    setFormData(prev => ({
      ...prev,
      documents: prev.documents.filter(d => d.id !== docId)
    }));
  };

  // Submission Handlers
  const handleSave = async (submitStatus: 'DRAFT' | 'SUBMITTED', enrollImmediately: boolean = false) => {
    if (!formData.firstName.trim() || !formData.lastName.trim() || !formData.classId || !formData.academicSessionId) {
      setError('Please fill in required student and placement information.');
      return;
    }

    try {
      setLoading(true);
      setError(null);

      const payload = {
        ...formData,
        status: submitStatus,
        bypassDuplicateWarning
      };

      let savedApp: AdmissionApplication;

      if (applicationToEdit) {
        const updateRes = await api.admissions.updateApplication(applicationToEdit.id, payload);
        if (!updateRes.success || !updateRes.data) {
          setError(updateRes.error || 'Failed to update application.');
          setLoading(false);
          return;
        }
        savedApp = updateRes.data;
      } else {
        const createRes = await api.admissions.createApplication(payload);
        if (!createRes.success || !createRes.data) {
          setError(createRes.error || 'Failed to save application.');
          setLoading(false);
          return;
        }
        savedApp = createRes.data;
      }

      // If user chose instant approval & enrollment
      if (enrollImmediately) {
        const enrollRes = await api.admissions.approveAndEnroll(savedApp.id);
        if (enrollRes.success && enrollRes.data) {
          onSuccess(enrollRes.data.application, true);
          onClose();
          return;
        } else {
          setError(enrollRes.error || 'Application saved, but automatic enrollment failed.');
          setLoading(false);
          return;
        }
      }

      onSuccess(savedApp, false);
      onClose();
    } catch (err: any) {
      setError(err.message || 'An unexpected error occurred during submission.');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col max-h-[92vh] overflow-hidden my-4">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-indigo-100 dark:bg-indigo-900/60 text-indigo-700 dark:text-indigo-300">
                {applicationToEdit ? `Edit Application: ${applicationToEdit.applicationNumber}` : 'New Student Admission'}
              </span>
              {enquiryToConvert && (
                <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 dark:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300 flex items-center gap-1">
                  <Sparkles className="w-3 h-3" />
                  <span>From Enquiry {enquiryToConvert.enquiryNumber}</span>
                </span>
              )}
            </div>
            <h2 className="text-xl font-bold text-slate-900 dark:text-white mt-1">
              Student Admission & Academic Enrollment Wizard
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step Progress Bar */}
        <div className="px-6 py-3 border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
          <div className="grid grid-cols-5 gap-2">
            {STEPS.map(step => {
              const isCurrent = currentStep === step.id;
              const isPast = currentStep > step.id;
              return (
                <div
                  key={step.id}
                  onClick={() => {
                    if (isPast) setCurrentStep(step.id);
                  }}
                  className={`flex items-center gap-2 p-2 rounded-xl transition cursor-pointer ${
                    isCurrent
                      ? 'bg-indigo-50 dark:bg-indigo-950/50 border border-indigo-200 dark:border-indigo-800 text-indigo-700 dark:text-indigo-300'
                      : isPast
                      ? 'text-emerald-600 dark:text-emerald-400 hover:bg-slate-50 dark:hover:bg-slate-800/50'
                      : 'text-slate-400 dark:text-slate-600 opacity-60 cursor-not-allowed'
                  }`}
                >
                  <div
                    className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                      isCurrent
                        ? 'bg-indigo-600 text-white'
                        : isPast
                        ? 'bg-emerald-600 text-white'
                        : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    {isPast ? <Check className="w-3.5 h-3.5" /> : step.id}
                  </div>
                  <div className="hidden sm:block text-left min-w-0">
                    <p className="text-xs font-semibold truncate leading-tight">{step.title}</p>
                    <p className="text-[10px] opacity-75 truncate">{step.subtitle}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Error Alert */}
        {error && (
          <div className="mx-6 mt-3 p-3.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 flex items-center gap-3 text-rose-700 dark:text-rose-400 text-sm">
            <AlertCircle className="w-5 h-5 flex-shrink-0" />
            <p>{error}</p>
          </div>
        )}

        {/* Wizard Step Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* STEP 1: STUDENT INFORMATION */}
          {currentStep === 1 && (
            <div className="space-y-6">
              <div>
                <h3 className="text-sm font-semibold text-slate-900 dark:text-white uppercase tracking-wider mb-1">
                  Applicant Demographics
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Enter identity and biographical information for the student master record.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    First Name <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.firstName}
                    onChange={e => setFormData({ ...formData, firstName: e.target.value })}
                    placeholder="e.g. Liam"
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Middle Name
                  </label>
                  <input
                    type="text"
                    value={formData.middleName}
                    onChange={e => setFormData({ ...formData, middleName: e.target.value })}
                    placeholder="e.g. Alexander"
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Last Name <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.lastName}
                    onChange={e => setFormData({ ...formData, lastName: e.target.value })}
                    placeholder="e.g. Reynolds"
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Date of Birth <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="date"
                    required
                    value={formData.dateOfBirth}
                    onChange={e => setFormData({ ...formData, dateOfBirth: e.target.value })}
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Gender
                  </label>
                  <select
                    value={formData.gender}
                    onChange={e => setFormData({ ...formData, gender: e.target.value })}
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  >
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                    <option value="other">Other</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Blood Group
                  </label>
                  <select
                    value={formData.bloodGroup}
                    onChange={e => setFormData({ ...formData, bloodGroup: e.target.value })}
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  >
                    <option value="">Select blood group...</option>
                    <option value="A+">A+</option>
                    <option value="A-">A-</option>
                    <option value="B+">B+</option>
                    <option value="B-">B-</option>
                    <option value="AB+">AB+</option>
                    <option value="AB-">AB-</option>
                    <option value="O+">O+</option>
                    <option value="O-">O-</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Nationality
                  </label>
                  <input
                    type="text"
                    value={formData.nationality}
                    onChange={e => setFormData({ ...formData, nationality: e.target.value })}
                    placeholder="United States"
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Student Personal Email
                  </label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={e => setFormData({ ...formData, email: e.target.value })}
                    placeholder="student@example.com (optional)"
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Student Personal Phone
                  </label>
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={e => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="+1 (555) 000-0000"
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Present Residential Address
                  </label>
                  <input
                    type="text"
                    value={formData.presentAddress}
                    onChange={e =>
                      setFormData({
                        ...formData,
                        presentAddress: e.target.value,
                        address: e.target.value
                      })
                    }
                    placeholder="124 Cedar Avenue, Apt 4B"
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    City & Zip Code
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      value={formData.city}
                      onChange={e => setFormData({ ...formData, city: e.target.value })}
                      placeholder="Boston"
                      className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                    />
                    <input
                      type="text"
                      value={formData.postalCode}
                      onChange={e => setFormData({ ...formData, postalCode: e.target.value })}
                      placeholder="02108"
                      className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Prior Academic History */}
              <div className="pt-4 border-t border-slate-200 dark:border-slate-800">
                <h3 className="text-sm font-semibold text-slate-900 dark:text-white uppercase tracking-wider mb-1">
                  Prior Academic History
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mb-3">
                  Details from transfer certificate or previously attended school.
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                      Previous School Name
                    </label>
                    <input
                      type="text"
                      value={formData.previousSchoolName}
                      onChange={e => setFormData({ ...formData, previousSchoolName: e.target.value })}
                      placeholder="St. Mary's Academy"
                      className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                      Previous Class / Grade
                    </label>
                    <input
                      type="text"
                      value={formData.previousClass}
                      onChange={e => setFormData({ ...formData, previousClass: e.target.value })}
                      placeholder="Grade 8"
                      className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                      Transfer Certificate No.
                    </label>
                    <input
                      type="text"
                      value={formData.transferCertificateNumber}
                      onChange={e => setFormData({ ...formData, transferCertificateNumber: e.target.value })}
                      placeholder="TC-2025-9012"
                      className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* STEP 2: GUARDIAN INFORMATION */}
          {currentStep === 2 && (
            <div className="space-y-6">
              <div>
                <h3 className="text-sm font-semibold text-slate-900 dark:text-white uppercase tracking-wider mb-1">
                  Parent / Legal Guardian Record
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Link an existing registered guardian or register new primary contacts for this student.
                </p>
              </div>

              {/* Mode Toggle */}
              <div className="flex items-center gap-3 p-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 w-fit">
                <button
                  type="button"
                  onClick={() => setFormData({ ...formData, guardianMode: 'new', guardianId: '' })}
                  className={`px-4 py-1.5 text-xs font-semibold rounded-lg transition ${
                    formData.guardianMode === 'new'
                      ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-sm'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                  }`}
                >
                  Create New Guardian
                </button>
                <button
                  type="button"
                  onClick={() => setFormData({ ...formData, guardianMode: 'existing' })}
                  className={`px-4 py-1.5 text-xs font-semibold rounded-lg transition ${
                    formData.guardianMode === 'existing'
                      ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-sm'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                  }`}
                >
                  Select Existing Guardian
                </button>
              </div>

              {/* Existing Guardian Lookup */}
              {formData.guardianMode === 'existing' && (
                <div className="p-4 rounded-xl bg-indigo-50/50 dark:bg-indigo-950/20 border border-indigo-100 dark:border-indigo-900/40 space-y-3">
                  <div className="relative">
                    <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                    <input
                      type="text"
                      value={guardianSearch}
                      onChange={e => setGuardianSearch(e.target.value)}
                      placeholder="Search existing guardians by name, phone, or email..."
                      className="w-full pl-9 pr-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                    />
                  </div>

                  <div className="max-h-48 overflow-y-auto space-y-1.5">
                    {filteredGuardians.length === 0 ? (
                      <p className="text-xs text-slate-500 py-3 text-center">No matching guardians found.</p>
                    ) : (
                      filteredGuardians.map(g => {
                        const isSelected = formData.guardianId === g.id;
                        return (
                          <div
                            key={g.id}
                            onClick={() => handleSelectExistingGuardian(g)}
                            className={`p-2.5 rounded-lg border flex items-center justify-between cursor-pointer transition ${
                              isSelected
                                ? 'bg-indigo-600 text-white border-indigo-600'
                                : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 hover:border-indigo-300 text-slate-900 dark:text-white'
                            }`}
                          >
                            <div>
                              <p className="text-xs font-semibold">{g.name} ({g.relationship})</p>
                              <p className={`text-[11px] ${isSelected ? 'text-indigo-100' : 'text-slate-500 dark:text-slate-400'}`}>
                                Phone: {g.phone} • Email: {g.email}
                              </p>
                            </div>
                            {isSelected && <Check className="w-4 h-4" />}
                          </div>
                        );
                      })
                    )}
                  </div>
                </div>
              )}

              {/* Primary Guardian Fields */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Primary Guardian Name <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.guardianName}
                    onChange={e => setFormData({ ...formData, guardianName: e.target.value })}
                    placeholder="e.g. David Reynolds"
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Relationship <span className="text-rose-500">*</span>
                  </label>
                  <select
                    value={formData.guardianRelation}
                    onChange={e => setFormData({ ...formData, guardianRelation: e.target.value })}
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  >
                    <option value="Father">Father</option>
                    <option value="Mother">Mother</option>
                    <option value="Legal Guardian">Legal Guardian</option>
                    <option value="Grandparent">Grandparent</option>
                    <option value="Relative">Relative</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Guardian Phone <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="tel"
                    required
                    value={formData.guardianPhone}
                    onChange={e =>
                      setFormData({
                        ...formData,
                        guardianPhone: e.target.value,
                        emergencyContact: formData.emergencyContact || e.target.value
                      })
                    }
                    placeholder="+1 (617) 555-0199"
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Guardian Email
                  </label>
                  <input
                    type="email"
                    value={formData.guardianEmail}
                    onChange={e => setFormData({ ...formData, guardianEmail: e.target.value })}
                    placeholder="guardian@example.com"
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Occupation
                  </label>
                  <input
                    type="text"
                    value={formData.guardianOccupation}
                    onChange={e => setFormData({ ...formData, guardianOccupation: e.target.value })}
                    placeholder="Software Engineer"
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Emergency Contact Number
                  </label>
                  <input
                    type="tel"
                    value={formData.emergencyContact}
                    onChange={e => setFormData({ ...formData, emergencyContact: e.target.value })}
                    placeholder="+1 (617) 555-0188"
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>
              </div>
            </div>
          )}

          {/* STEP 3: ACADEMIC PLACEMENT & FEES */}
          {currentStep === 3 && (
            <div className="space-y-6">
              <div>
                <h3 className="text-sm font-semibold text-slate-900 dark:text-white uppercase tracking-wider mb-1">
                  Academic Placement & Enrollment Configuration
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Designate academic session, class, section, roll assignment rule, and admission fee structure.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Target Academic Session <span className="text-rose-500">*</span>
                  </label>
                  <select
                    required
                    value={formData.academicSessionId}
                    onChange={e => setFormData({ ...formData, academicSessionId: e.target.value })}
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  >
                    {sessions.map(s => (
                      <option key={s.id} value={s.id}>
                        {s.name} {s.status === 'active' ? '(Current Active)' : ''}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Admitting Class <span className="text-rose-500">*</span>
                  </label>
                  <select
                    required
                    value={formData.classId}
                    onChange={e => {
                      const newClassId = e.target.value;
                      const matchedSections = (sections || []).filter(s => s.classId === newClassId);
                      setFormData({
                        ...formData,
                        classId: newClassId,
                        sectionId: matchedSections.length > 0 ? matchedSections?.[0]?.id || '' : ''
                      });
                    }}
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  >
                    {classes.map(c => (
                      <option key={c.id} value={c.id}>
                        {c.name} ({c.code})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Class Section <span className="text-rose-500">*</span>
                  </label>
                  <select
                    required
                    value={formData.sectionId}
                    onChange={e => setFormData({ ...formData, sectionId: e.target.value })}
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  >
                    {availableSections.length === 0 ? (
                      <option value="">No sections defined for this class</option>
                    ) : (
                      availableSections.map(sec => (
                        <option key={sec.id} value={sec.id}>
                          Section {sec.name} (Room: {sec.roomNumber || 'TBD'})
                        </option>
                      ))
                    )}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Official Admission Date
                  </label>
                  <input
                    type="date"
                    value={formData.admissionDate}
                    onChange={e => setFormData({ ...formData, admissionDate: e.target.value })}
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>

                <div className="sm:col-span-2 p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-xs font-semibold text-slate-900 dark:text-white">Roll Number Assignment</p>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400">
                        Automatically assign the next consecutive roll number in section, or specify manually.
                      </p>
                    </div>
                    <label className="flex items-center gap-2 text-xs font-medium text-slate-700 dark:text-slate-300 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formData.autoAssignRoll}
                        onChange={e => setFormData({ ...formData, autoAssignRoll: e.target.checked })}
                        className="w-4 h-4 text-indigo-600 rounded border-slate-300 focus:ring-indigo-500"
                      />
                      <span>Auto-assign next sequential roll number</span>
                    </label>
                  </div>

                  {!formData.autoAssignRoll && (
                    <div className="max-w-xs">
                      <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400 mb-1">
                        Specific Roll Number (e.g. R-12)
                      </label>
                      <input
                        type="text"
                        value={formData.preferredRollNumber}
                        onChange={e => setFormData({ ...formData, preferredRollNumber: e.target.value })}
                        placeholder="R-01"
                        className="w-full px-3 py-1.5 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                      />
                    </div>
                  )}
                </div>

                <div className="sm:col-span-2 p-4 rounded-xl bg-emerald-50/60 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-800/40 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <DollarSign className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                      <div>
                        <p className="text-xs font-semibold text-emerald-900 dark:text-emerald-200">
                          Initial Fee Structure Assignment
                        </p>
                        <p className="text-[11px] text-emerald-700 dark:text-emerald-400">
                          Automatically create an initial student fee invoice upon official enrollment.
                        </p>
                      </div>
                    </div>
                    <label className="flex items-center gap-2 text-xs font-medium text-emerald-800 dark:text-emerald-300 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={formData.assignAdmissionFee}
                        onChange={e => setFormData({ ...formData, assignAdmissionFee: e.target.checked })}
                        className="w-4 h-4 text-emerald-600 rounded border-emerald-300 focus:ring-emerald-500"
                      />
                      <span>Assign admission fees on enrollment</span>
                    </label>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* STEP 4: DOCUMENT VAULT */}
          {currentStep === 4 && (
            <div className="space-y-6">
              <div>
                <h3 className="text-sm font-semibold text-slate-900 dark:text-white uppercase tracking-wider mb-1">
                  Document Vault & Verification Attachments
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Upload verification documents (Birth Certificate, TC, Previous Marks, ID Proof, Immunization Records).
                </p>
              </div>

              {/* Quick Add Presets */}
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-3">
                <p className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Quick Attach Standard Requirement Documents:
                </p>
                <div className="flex flex-wrap gap-2">
                  {[
                    { cat: 'birth_certificate', label: '+ Birth Certificate' },
                    { cat: 'transfer_certificate', label: '+ Transfer Certificate' },
                    { cat: 'transcript', label: '+ Prior Report Card' },
                    { cat: 'id_proof', label: '+ Passport / Photo ID' },
                    { cat: 'medical_record', label: '+ Immunization Record' }
                  ].map(preset => (
                    <button
                      key={preset.cat}
                      type="button"
                      onClick={() => handleAddDocument(preset.cat, `${formData.firstName || 'Student'} - ${preset.label.replace('+ ', '')}`)}
                      className="px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 hover:border-indigo-500 hover:text-indigo-600 dark:hover:text-indigo-400 rounded-lg transition"
                    >
                      {preset.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Uploaded Documents List */}
              <div className="space-y-2">
                <p className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Attached Application Documents ({formData?.documents?.length || 0}):
                </p>

                {(formData?.documents?.length || 0) === 0 ? (
                  <div className="p-8 text-center border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-xl">
                    <FileText className="w-8 h-8 text-slate-400 mx-auto mb-2 opacity-50" />
                    <p className="text-xs text-slate-500">No documents attached yet.</p>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      Use the quick-attach buttons above or upload scanned files.
                    </p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {(formData?.documents || []).map(doc => (
                      <div
                        key={doc.id}
                        className="p-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 flex items-center justify-between gap-2"
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <div className="w-8 h-8 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center flex-shrink-0">
                            <FileText className="w-4 h-4" />
                          </div>
                          <div className="min-w-0">
                            <p className="text-xs font-medium text-slate-900 dark:text-white truncate">{doc.name}</p>
                            <span className="text-[10px] uppercase font-semibold text-slate-500 dark:text-slate-400">
                              {(doc.category || 'DOCUMENT').replace(/_/g, ' ')}
                            </span>
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => handleRemoveDocument(doc.id)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-950/40 transition"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* STEP 5: REVIEW, DUPLICATE CHECK & ENROLL */}
          {currentStep === 5 && (
            <div className="space-y-6">
              <div>
                <h3 className="text-sm font-semibold text-slate-900 dark:text-white uppercase tracking-wider mb-1">
                  Final Application Review & Integrity Verification
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Review applicant profile, verify duplicate match results, and finalize admission status.
                </p>
              </div>

              {/* Duplicate Detection Alert Box */}
              {checkingDuplicates ? (
                <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 flex items-center gap-3 text-xs text-slate-600 dark:text-slate-400">
                  <div className="w-4 h-4 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin" />
                  <span>Scanning existing master records for duplicate students or phone conflicts...</span>
                </div>
              ) : duplicateMatches.length > 0 ? (
                <div className="p-4 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/60 space-y-3">
                  <div className="flex items-center gap-2 text-amber-800 dark:text-amber-300 font-semibold text-sm">
                    <AlertTriangle className="w-4 h-4 text-amber-600" />
                    <span>Potential Duplicate Student Detected ({duplicateMatches.length} match):</span>
                  </div>
                  <div className="space-y-2">
                    {duplicateMatches.map((match, idx) => (
                      <div
                        key={idx}
                        className="text-xs p-2.5 rounded-lg bg-white/70 dark:bg-slate-900/60 border border-amber-200 dark:border-amber-800/40 text-amber-900 dark:text-amber-200"
                      >
                        <p className="font-semibold">{match.details}</p>
                        <p className="text-[11px] text-amber-700 dark:text-amber-400 mt-0.5">
                          Matched Record: {match.name} • {match.identifier} {match.className ? `(${match.className})` : ''}
                        </p>
                      </div>
                    ))}
                  </div>

                  <label className="flex items-center gap-2 pt-1 text-xs font-medium text-amber-900 dark:text-amber-200 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={bypassDuplicateWarning}
                      onChange={e => setBypassDuplicateWarning(e.target.checked)}
                      className="w-4 h-4 text-amber-600 rounded border-amber-400 focus:ring-amber-500"
                    />
                    <span>I acknowledge this match and confirm this is an intentional, distinct applicant.</span>
                  </label>
                </div>
              ) : (
                <div className="p-3.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/50 flex items-center gap-2.5 text-xs text-emerald-800 dark:text-emerald-300">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Integrity verification passed. No duplicate student records or phone collisions detected.</span>
                </div>
              )}

              {/* Review Cards Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Student Summary */}
                <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 space-y-2">
                  <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-700/60 pb-2">
                    <span className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                      Student Identity
                    </span>
                    <button
                      type="button"
                      onClick={() => setCurrentStep(1)}
                      className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline"
                    >
                      Edit
                    </button>
                  </div>
                  <div className="text-xs space-y-1 text-slate-600 dark:text-slate-300">
                    <p><span className="font-medium text-slate-900 dark:text-white">Full Name:</span> {formData.firstName} {formData.middleName} {formData.lastName}</p>
                    <p><span className="font-medium text-slate-900 dark:text-white">DOB & Gender:</span> {formData.dateOfBirth} ({formData.gender})</p>
                    <p><span className="font-medium text-slate-900 dark:text-white">Blood Group:</span> {formData.bloodGroup || 'Not specified'}</p>
                    <p><span className="font-medium text-slate-900 dark:text-white">Contact Phone:</span> {formData.phone || 'None provided'}</p>
                    <p><span className="font-medium text-slate-900 dark:text-white">Residential:</span> {formData.presentAddress || formData.city || 'N/A'}</p>
                  </div>
                </div>

                {/* Placement Summary */}
                <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 space-y-2">
                  <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-700/60 pb-2">
                    <span className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                      Academic Placement
                    </span>
                    <button
                      type="button"
                      onClick={() => setCurrentStep(3)}
                      className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline"
                    >
                      Edit
                    </button>
                  </div>
                  <div className="text-xs space-y-1 text-slate-600 dark:text-slate-300">
                    <p><span className="font-medium text-slate-900 dark:text-white">Target Class:</span> {(classes || []).find(c => c?.id === formData.classId)?.name || formData.classId}</p>
                    <p><span className="font-medium text-slate-900 dark:text-white">Section:</span> {(availableSections || []).find(s => s?.id === formData.sectionId)?.name || 'Default Section'}</p>
                    <p><span className="font-medium text-slate-900 dark:text-white">Academic Session:</span> {(sessions || []).find(s => s?.id === formData.academicSessionId)?.name || 'Active'}</p>
                    <p><span className="font-medium text-slate-900 dark:text-white">Roll Number:</span> {formData.autoAssignRoll ? 'Auto-assigned by system' : formData.preferredRollNumber}</p>
                    <p><span className="font-medium text-slate-900 dark:text-white">Admission Fees:</span> {formData.assignAdmissionFee ? 'Auto-generate invoice' : 'Skip fee invoice'}</p>
                  </div>
                </div>

                {/* Guardian Summary */}
                <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 space-y-2">
                  <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-700/60 pb-2">
                    <span className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                      Guardian Record
                    </span>
                    <button
                      type="button"
                      onClick={() => setCurrentStep(2)}
                      className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline"
                    >
                      Edit
                    </button>
                  </div>
                  <div className="text-xs space-y-1 text-slate-600 dark:text-slate-300">
                    <p><span className="font-medium text-slate-900 dark:text-white">Name:</span> {formData.guardianName} ({formData.guardianRelation})</p>
                    <p><span className="font-medium text-slate-900 dark:text-white">Phone:</span> {formData.guardianPhone}</p>
                    <p><span className="font-medium text-slate-900 dark:text-white">Email:</span> {formData.guardianEmail || 'N/A'}</p>
                    <p><span className="font-medium text-slate-900 dark:text-white">Mode:</span> {formData.guardianMode === 'existing' ? 'Linked Existing Profile' : 'New Registration'}</p>
                  </div>
                </div>

                {/* Documents Summary */}
                <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 space-y-2">
                  <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-700/60 pb-2">
                    <span className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                      Attached Documents
                    </span>
                    <button
                      type="button"
                      onClick={() => setCurrentStep(4)}
                      className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline"
                    >
                      Edit
                    </button>
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-300">
                    {formData?.documents?.length || 0} verified document(s) uploaded and attached.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Wizard Footer Controls */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40">
          <div>
            {currentStep > 1 && (
              <button
                type="button"
                onClick={handlePrevStep}
                disabled={loading}
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>Back</span>
              </button>
            )}
          </div>

          <div className="flex items-center gap-2">
            {/* Save as Draft */}
            <button
              type="button"
              onClick={() => handleSave('DRAFT', false)}
              disabled={loading}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-700 dark:text-slate-300 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 border border-slate-300 dark:border-slate-700 rounded-xl transition disabled:opacity-50"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Save as Draft</span>
            </button>

            {currentStep < 5 ? (
              <button
                type="button"
                onClick={handleNextStep}
                className="inline-flex items-center gap-1.5 px-5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition shadow-sm"
              >
                <span>Continue</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            ) : (
              <>
                {/* Submit Application */}
                <button
                  type="button"
                  onClick={() => handleSave('SUBMITTED', false)}
                  disabled={loading || (duplicateMatches.length > 0 && !bypassDuplicateWarning)}
                  className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition shadow-sm disabled:opacity-50"
                >
                  <Check className="w-4 h-4" />
                  <span>Submit Application</span>
                </button>

                {/* Instant Transactional Approve & Enroll */}
                <button
                  type="button"
                  onClick={() => handleSave('SUBMITTED', true)}
                  disabled={loading || (duplicateMatches.length > 0 && !bypassDuplicateWarning)}
                  className="inline-flex items-center gap-1.5 px-5 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl transition shadow-sm disabled:opacity-50"
                >
                  <GraduationCap className="w-4 h-4" />
                  <span>{loading ? 'Processing...' : 'Submit, Approve & Enroll Now!'}</span>
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
