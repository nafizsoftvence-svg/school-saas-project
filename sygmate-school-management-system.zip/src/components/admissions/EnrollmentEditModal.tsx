import React, { useState } from 'react';
import { X, Save, AlertCircle, Hash, UserCheck, AlertTriangle } from 'lucide-react';
import { api } from '../../services/api';
import { AcademicEnrollment } from '../../types';

interface EnrollmentEditModalProps {
  isOpen: boolean;
  onClose: () => void;
  enrollment: AcademicEnrollment | null;
  onSuccess: (updated: AcademicEnrollment) => void;
}

export const EnrollmentEditModal: React.FC<EnrollmentEditModalProps> = ({
  isOpen,
  onClose,
  enrollment,
  onSuccess
}) => {
  const [activeTab, setActiveTab] = useState<'roll' | 'status'>('roll');
  const [newRollNumber, setNewRollNumber] = useState('');
  const [targetStatus, setTargetStatus] = useState('active');
  const [remarks, setRemarks] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  React.useEffect(() => {
    if (enrollment) {
      setNewRollNumber(enrollment.rollNumber || '');
      setTargetStatus(enrollment.status || 'active');
      setRemarks(enrollment.remarks || '');
      setError(null);
    }
  }, [enrollment]);

  if (!isOpen || !enrollment) return null;

  const handleUpdateRoll = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRollNumber.trim()) {
      setError('Please provide a valid roll number.');
      return;
    }

    try {
      setLoading(true);
      setError(null);
      const res = await api.admissions.updateEnrollmentRollNumber(enrollment.id, newRollNumber.trim());
      if (res.success && res.data) {
        onSuccess(res.data);
        onClose();
      } else {
        setError(res.error || 'Failed to update roll number.');
      }
    } catch (err: any) {
      setError(err.message || 'Error updating roll number.');
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateStatus = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setLoading(true);
      setError(null);
      const res = await api.admissions.updateEnrollmentStatus(enrollment.id, targetStatus, remarks);
      if (res.success && res.data) {
        onSuccess(res.data);
        onClose();
      } else {
        setError(res.error || 'Failed to update enrollment status.');
      }
    } catch (err: any) {
      setError(err.message || 'Error updating status.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="relative w-full max-w-lg bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Manage Student Enrollment
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {enrollment.studentName} • {enrollment.className} ({enrollment.sectionName}) • Adm: {enrollment.studentAdmissionNumber}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Toggle */}
        <div className="flex border-b border-slate-200 dark:border-slate-800 px-6 bg-white dark:bg-slate-900">
          <button
            type="button"
            onClick={() => setActiveTab('roll')}
            className={`py-2.5 px-4 text-xs font-semibold border-b-2 transition ${
              activeTab === 'roll'
                ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
                : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Reassign Roll Number
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('status')}
            className={`py-2.5 px-4 text-xs font-semibold border-b-2 transition ${
              activeTab === 'status'
                ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
                : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Enrollment Status
          </button>
        </div>

        {error && (
          <div className="mx-6 mt-4 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 flex items-center gap-2.5 text-rose-700 dark:text-rose-400 text-xs">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            <p>{error}</p>
          </div>
        )}

        <div className="p-6">
          {activeTab === 'roll' ? (
            <form onSubmit={handleUpdateRoll} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Current Roll Number
                </label>
                <input
                  type="text"
                  disabled
                  value={enrollment.rollNumber}
                  className="w-full px-3 py-2 text-sm rounded-lg bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-500 cursor-not-allowed"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  New Roll Number <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <Hash className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    required
                    value={newRollNumber}
                    onChange={e => setNewRollNumber(e.target.value)}
                    placeholder="e.g. R-05"
                    className="w-full pl-9 pr-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                  The system will automatically verify that no other student in {enrollment.className} ({enrollment.sectionName}) holds this roll number.
                </p>
              </div>

              <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition disabled:opacity-50"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>{loading ? 'Saving...' : 'Update Roll Number'}</span>
                </button>
              </div>
            </form>
          ) : (
            <form onSubmit={handleUpdateStatus} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Enrollment Status
                </label>
                <select
                  value={targetStatus}
                  onChange={e => setTargetStatus(e.target.value)}
                  className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                >
                  <option value="active">Active (Standard Enrollment)</option>
                  <option value="transferred">Transferred (TC Issued)</option>
                  <option value="suspended">Suspended (Disciplinary)</option>
                  <option value="withdrawn">Withdrawn (Parent Request)</option>
                  <option value="graduated">Graduated (Completed Final Class)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Administrative Remarks / Justification
                </label>
                <textarea
                  rows={2}
                  value={remarks}
                  onChange={e => setRemarks(e.target.value)}
                  placeholder="Record justification for status change..."
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none resize-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition disabled:opacity-50"
                >
                  <UserCheck className="w-3.5 h-3.5" />
                  <span>{loading ? 'Saving...' : 'Update Status'}</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
