import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Save,
  AlertCircle,
  Phone,
  Mail,
  User,
  MapPin,
  Calendar,
  Clock,
  HelpCircle,
  ArrowRight,
  School,
  Flag,
  AlertTriangle,
  History,
  ShieldCheck,
  CheckCircle2,
  Tag
} from 'lucide-react';
import { api } from '../../services/api';
import {
  SchoolClass,
  AcademicSession,
  EnquirySourceConfig,
  EnquiryDuplicateMatch,
  EnquiryPriority,
  FrontOfficeEnquiryStatus
} from '../../types';

interface AdmissionEnquiryModalProps {
  isOpen: boolean;
  onClose: () => void;
  enquiryToEdit?: any | null;
  onSuccess: (enquiry: any) => void;
  onConvertToAdmission?: (enquiry: any) => void;
}

export const AdmissionEnquiryModal: React.FC<AdmissionEnquiryModalProps> = ({
  isOpen,
  onClose,
  enquiryToEdit,
  onSuccess,
  onConvertToAdmission
}) => {
  const [classes, setClasses] = useState<SchoolClass[]>([]);
  const [sessions, setSessions] = useState<AcademicSession[]>([]);
  const [sources, setSources] = useState<EnquirySourceConfig[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Duplicate detection state
  const [duplicateMatches, setDuplicateMatches] = useState<EnquiryDuplicateMatch[]>([]);
  const [checkingDuplicates, setCheckingDuplicates] = useState(false);
  const duplicateTimerRef = useRef<any>(null);

  // Active tab for history vs form if editing
  const [activeTab, setActiveTab] = useState<'details' | 'history'>('details');

  const [formData, setFormData] = useState({
    studentName: '',
    dateOfBirth: '',
    gender: 'male',
    applyingClassId: '',
    academicSessionId: '',
    previousSchool: '',
    enquiryType: 'Admission',
    parentName: '',
    relationship: 'Father',
    phone: '',
    alternatePhone: '',
    email: '',
    address: '',
    source: 'WALK_IN',
    priority: 'MEDIUM' as EnquiryPriority,
    status: 'NEW' as FrontOfficeEnquiryStatus,
    followUpDate: '',
    followUpTime: '',
    notes: ''
  });

  useEffect(() => {
    if (!isOpen) return;

    const loadMeta = async () => {
      try {
        const [clsRes, sessRes, sourcesRes] = await Promise.all([
          api.getClasses(),
          api.getAcademicSessions(),
          api.frontOffice.getEnquirySources().catch(() => ({ success: false, data: [] }))
        ]);
        if (clsRes.success && clsRes.data) setClasses(clsRes.data);
        if (sessRes.success && sessRes.data) setSessions(sessRes.data);
        if (sourcesRes.success && sourcesRes.data && sourcesRes.data.length > 0) {
          setSources(sourcesRes.data);
        }
      } catch (err) {
        console.error('Failed to load classes, sessions, or sources', err);
      }
    };
    loadMeta();

    if (enquiryToEdit) {
      setFormData({
        studentName: enquiryToEdit.studentName || '',
        dateOfBirth: enquiryToEdit.dateOfBirth || '',
        gender: enquiryToEdit.gender || 'male',
        applyingClassId: enquiryToEdit.applyingClassId || '',
        academicSessionId: enquiryToEdit.academicSessionId || '',
        previousSchool: enquiryToEdit.previousSchool || '',
        enquiryType: enquiryToEdit.enquiryType || 'Admission',
        parentName: enquiryToEdit.parentName || '',
        relationship: enquiryToEdit.relationship || 'Father',
        phone: enquiryToEdit.phone || '',
        alternatePhone: enquiryToEdit.alternatePhone || '',
        email: enquiryToEdit.email || '',
        address: enquiryToEdit.address || '',
        source: enquiryToEdit.source || 'WALK_IN',
        priority: enquiryToEdit.priority || 'MEDIUM',
        status: enquiryToEdit.status || 'NEW',
        followUpDate: enquiryToEdit.followUpDate || '',
        followUpTime: enquiryToEdit.followUpTime || '',
        notes: enquiryToEdit.notes || ''
      });
    } else {
      setFormData({
        studentName: '',
        dateOfBirth: '',
        gender: 'male',
        applyingClassId: '',
        academicSessionId: '',
        previousSchool: '',
        enquiryType: 'Admission',
        parentName: '',
        relationship: 'Father',
        phone: '',
        alternatePhone: '',
        email: '',
        address: '',
        source: 'WALK_IN',
        priority: 'MEDIUM',
        status: 'NEW',
        followUpDate: '',
        followUpTime: '',
        notes: ''
      });
    }
    setError(null);
    setDuplicateMatches([]);
    setActiveTab('details');
  }, [isOpen, enquiryToEdit]);

  // Set default class & session once loaded if empty
  useEffect(() => {
    if (!enquiryToEdit && isOpen) {
      if (!formData.applyingClassId && classes && classes.length > 0) {
        setFormData(prev => ({ ...prev, applyingClassId: classes[0].id || '' }));
      }
      if (!formData.academicSessionId && sessions && sessions.length > 0) {
        const active = (sessions || []).find(s => s.status === 'active') || sessions?.[0];
        if (active) {
          setFormData(prev => ({ ...prev, academicSessionId: active.id }));
        }
      }
    }
  }, [classes, sessions, isOpen, enquiryToEdit]);

  // Debounced duplicate detection
  useEffect(() => {
    if (!isOpen) return;
    if (duplicateTimerRef.current) {
      clearTimeout(duplicateTimerRef.current);
    }

    const hasCheckableField =
      (formData.phone && formData.phone.trim().length >= 6) ||
      (formData.email && formData.email.trim().includes('@')) ||
      (formData.studentName && formData.studentName.trim().length >= 4);

    if (!hasCheckableField) {
      setDuplicateMatches([]);
      return;
    }

    duplicateTimerRef.current = setTimeout(async () => {
      try {
        setCheckingDuplicates(true);
        const res = await api.frontOffice.checkEnquiryDuplicates({
          phone: formData.phone.trim() || undefined,
          email: formData.email.trim() || undefined,
          studentName: formData.studentName.trim() || undefined,
          parentName: formData.parentName.trim() || undefined,
          excludeId: enquiryToEdit?.id
        });
        if (res.success && res.data && res.data.hasDuplicates) {
          setDuplicateMatches(res.data.matches);
        } else {
          setDuplicateMatches([]);
        }
      } catch (err) {
        console.warn('Duplicate check error', err);
      } finally {
        setCheckingDuplicates(false);
      }
    }, 500);

    return () => {
      if (duplicateTimerRef.current) clearTimeout(duplicateTimerRef.current);
    };
  }, [formData.phone, formData.email, formData.studentName, isOpen, enquiryToEdit?.id]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.studentName.trim() || !formData.parentName.trim() || !formData.phone.trim()) {
      setError('Student Name, Parent Name, and Contact Phone are required.');
      return;
    }
    if (!formData.applyingClassId) {
      setError('Please select an applying class.');
      return;
    }

    try {
      setLoading(true);
      setError(null);

      if (enquiryToEdit) {
        // Use frontOffice update to preserve all history & new fields
        const res = await api.frontOffice.updateEnquiry(enquiryToEdit.id, formData);
        if (res.success && res.data) {
          onSuccess(res.data);
          onClose();
        } else {
          setError(res.error || 'Failed to update enquiry.');
        }
      } else {
        const res = await api.frontOffice.createEnquiry(formData);
        if (res.success && res.data) {
          onSuccess(res.data);
          onClose();
        } else {
          setError(res.error || 'Failed to log enquiry.');
        }
      }
    } catch (err: any) {
      setError(err.message || 'An unexpected error occurred.');
    } finally {
      setLoading(false);
    }
  };

  const statusHistory = enquiryToEdit?.statusHistory || [];
  const assignmentHistory = enquiryToEdit?.assignmentHistory || [];
  const followUps = enquiryToEdit?.followUps || [];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-8">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/50">
          <div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">
              {enquiryToEdit ? `Enquiry: ${enquiryToEdit.enquiryNumber}` : 'Log Front Office Admission Enquiry'}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Record prospect details, contact channels, lead priority, and scheduled follow-ups.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switch if editing */}
        {enquiryToEdit && (
          <div className="flex border-b border-slate-200 dark:border-slate-800 px-6 bg-slate-50/30 dark:bg-slate-850/30">
            <button
              type="button"
              onClick={() => setActiveTab('details')}
              className={`py-2.5 px-4 text-xs font-semibold border-b-2 transition ${
                activeTab === 'details'
                  ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
                  : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              Enquiry Details
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('history')}
              className={`py-2.5 px-4 text-xs font-semibold border-b-2 flex items-center gap-1.5 transition ${
                activeTab === 'history'
                  ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
                  : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              <History className="w-3.5 h-3.5" />
              <span>Timeline & History</span>
              {(statusHistory.length > 0 || assignmentHistory.length > 0) && (
                <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-indigo-100 dark:bg-indigo-900/60 text-indigo-700 dark:text-indigo-300">
                  {statusHistory.length + assignmentHistory.length}
                </span>
              )}
            </button>
          </div>
        )}

        {error && (
          <div className="mx-6 mt-4 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 flex items-center gap-3 text-rose-700 dark:text-rose-400 text-xs">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            <p>{error}</p>
          </div>
        )}

        {/* Duplicate detection warning banner */}
        {duplicateMatches.length > 0 && (
          <div className="mx-6 mt-4 p-3.5 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/60 text-xs text-amber-800 dark:text-amber-300 space-y-1.5">
            <div className="flex items-center gap-2 font-bold">
              <AlertTriangle className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" />
              <span>Potential Existing Records Found ({duplicateMatches.length})</span>
              {checkingDuplicates && <span className="text-[10px] animate-pulse">Checking...</span>}
            </div>
            <div className="max-h-24 overflow-y-auto space-y-1 pl-6">
              {duplicateMatches.map((m, idx) => (
                <div key={idx} className="flex items-center justify-between text-[11px] bg-white/60 dark:bg-slate-900/60 p-1.5 rounded-lg">
                  <div>
                    <span className="font-semibold">{m.name}</span>{' '}
                    <span className="text-slate-500">({m.details})</span>
                  </div>
                  <div className="flex items-center gap-1.5 font-mono text-[10px]">
                    <span className="px-1.5 py-0.5 rounded bg-amber-200 dark:bg-amber-900 text-amber-900 dark:text-amber-200 font-bold">
                      {m.matchedEntity}
                    </span>
                    <span className="text-slate-500">{m.similarityScore}% match</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'history' ? (
          <div className="p-6 space-y-5 max-h-[75vh] overflow-y-auto text-xs">
            {/* Status History */}
            <div>
              <h4 className="font-bold text-slate-800 dark:text-slate-200 mb-2 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-indigo-500" />
                Pipeline Status Progression
              </h4>
              {statusHistory.length === 0 ? (
                <p className="text-slate-400 italic">No status transitions recorded yet.</p>
              ) : (
                <div className="space-y-2 border-l-2 border-indigo-200 dark:border-indigo-900 ml-2 pl-3">
                  {statusHistory.map((sh: any, i: number) => (
                    <div key={i} className="relative pb-2">
                      <div className="absolute -left-[19px] top-1 w-2.5 h-2.5 rounded-full bg-indigo-600 ring-4 ring-white dark:ring-slate-900" />
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-semibold text-[10px]">
                          {sh.fromStatus}
                        </span>
                        <ArrowRight className="w-3 h-3 text-slate-400" />
                        <span className="px-2 py-0.5 rounded bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 font-bold text-[10px]">
                          {sh.toStatus}
                        </span>
                        <span className="text-slate-400 text-[10px] ml-auto">
                          {new Date(sh.changedAt).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })}
                        </span>
                      </div>
                      <p className="text-slate-500 text-[11px] mt-1">
                        Updated by <span className="font-semibold text-slate-700 dark:text-slate-300">{sh.changedByName}</span>
                        {sh.remarks ? ` — "${sh.remarks}"` : ''}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Assignment History */}
            <div className="pt-3 border-t border-slate-200 dark:border-slate-800">
              <h4 className="font-bold text-slate-800 dark:text-slate-200 mb-2 flex items-center gap-1.5">
                <User className="w-4 h-4 text-blue-500" />
                Staff Assignment History
              </h4>
              {assignmentHistory.length === 0 ? (
                <p className="text-slate-400 italic">No reassignment history.</p>
              ) : (
                <div className="space-y-2 border-l-2 border-blue-200 dark:border-blue-900 ml-2 pl-3">
                  {assignmentHistory.map((ah: any, i: number) => (
                    <div key={i} className="relative pb-2">
                      <div className="absolute -left-[19px] top-1 w-2.5 h-2.5 rounded-full bg-blue-600 ring-4 ring-white dark:ring-slate-900" />
                      <p className="font-semibold text-slate-800 dark:text-slate-200">
                        Assigned to: {ah.toStaffName}
                      </p>
                      <p className="text-slate-500 text-[11px]">
                        By {ah.assignedByName} on{' '}
                        {new Date(ah.assignedAt).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })}
                        {ah.notes ? ` — "${ah.notes}"` : ''}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Past Follow-ups */}
            <div className="pt-3 border-t border-slate-200 dark:border-slate-800">
              <h4 className="font-bold text-slate-800 dark:text-slate-200 mb-2 flex items-center gap-1.5">
                <Phone className="w-4 h-4 text-emerald-500" />
                Follow-Up History ({followUps.length})
              </h4>
              {followUps.length === 0 ? (
                <p className="text-slate-400 italic">No previous follow-up interactions logged.</p>
              ) : (
                <div className="space-y-2.5">
                  {followUps.map((f: any, i: number) => (
                    <div key={i} className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-800">
                      <div className="flex items-center justify-between text-[11px] mb-1">
                        <span className="font-bold text-slate-800 dark:text-slate-200">
                          {f.contactOutcome.replace(/_/g, ' ')}
                        </span>
                        <span className="text-slate-400">
                          {f.followUpDate} {f.followUpTime || ''}
                        </span>
                      </div>
                      {f.notes && <p className="text-slate-600 dark:text-slate-400 italic">"{f.notes}"</p>}
                      <div className="flex items-center gap-2 mt-1.5 text-[10px] text-slate-500">
                        <span>Method: {f.contactMethod || 'Phone'}</span>
                        <span>•</span>
                        <span>Logged by: {f.createdByName || 'Staff'}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        ) : (
          /* Form Details */
          <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
            {/* Student Info */}
            <div>
              <h3 className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider mb-2.5">
                1. Prospective Student Information
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Student Full Name <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                    <input
                      type="text"
                      required
                      value={formData.studentName}
                      onChange={e => setFormData({ ...formData, studentName: e.target.value })}
                      placeholder="e.g. Oliver Vance"
                      className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Date of Birth
                  </label>
                  <input
                    type="date"
                    value={formData.dateOfBirth}
                    onChange={e => setFormData({ ...formData, dateOfBirth: e.target.value })}
                    className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Gender
                  </label>
                  <select
                    value={formData.gender}
                    onChange={e => setFormData({ ...formData, gender: e.target.value })}
                    className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  >
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                    <option value="other">Other</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Applying Class <span className="text-rose-500">*</span>
                  </label>
                  <select
                    required
                    value={formData.applyingClassId}
                    onChange={e => setFormData({ ...formData, applyingClassId: e.target.value })}
                    className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  >
                    <option value="">Select target class...</option>
                    {classes.map(c => (
                      <option key={c.id} value={c.id}>
                        {c.name} ({c.code})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Academic Session
                  </label>
                  <select
                    value={formData.academicSessionId}
                    onChange={e => setFormData({ ...formData, academicSessionId: e.target.value })}
                    className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  >
                    {sessions.map(s => (
                      <option key={s.id} value={s.id}>
                        {s.name} {s.status === 'active' ? '(Current Active)' : ''}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Previous School / Institution
                  </label>
                  <div className="relative">
                    <School className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                    <input
                      type="text"
                      value={formData.previousSchool}
                      onChange={e => setFormData({ ...formData, previousSchool: e.target.value })}
                      placeholder="e.g. St. Jude Elementary"
                      className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Parent / Guardian Info */}
            <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
              <h3 className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider mb-2.5">
                2. Parent / Guardian Contact Information
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Parent / Guardian Name <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                    <input
                      type="text"
                      required
                      value={formData.parentName}
                      onChange={e => setFormData({ ...formData, parentName: e.target.value })}
                      placeholder="e.g. Marcus Vance"
                      className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Relationship
                  </label>
                  <select
                    value={formData.relationship}
                    onChange={e => setFormData({ ...formData, relationship: e.target.value })}
                    className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  >
                    <option value="Father">Father</option>
                    <option value="Mother">Mother</option>
                    <option value="Legal Guardian">Legal Guardian</option>
                    <option value="Relative">Relative</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Primary Phone <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative">
                    <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                    <input
                      type="tel"
                      required
                      value={formData.phone}
                      onChange={e => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="+1 (617) 555-0811"
                      className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Alternate Phone
                  </label>
                  <div className="relative">
                    <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                    <input
                      type="tel"
                      value={formData.alternatePhone}
                      onChange={e => setFormData({ ...formData, alternatePhone: e.target.value })}
                      placeholder="e.g. Office / Secondary Phone"
                      className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Email Address
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                    <input
                      type="email"
                      value={formData.email}
                      onChange={e => setFormData({ ...formData, email: e.target.value })}
                      placeholder="parent@example.com"
                      className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Residential Address
                  </label>
                  <div className="relative">
                    <MapPin className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                    <input
                      type="text"
                      value={formData.address}
                      onChange={e => setFormData({ ...formData, address: e.target.value })}
                      placeholder="Street, City, State, Postal Code"
                      className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Tracking, Priority, and Source */}
            <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
              <h3 className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider mb-2.5">
                3. Channel, Priority & Follow-up Milestones
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Inflow Source
                  </label>
                  <select
                    value={formData.source}
                    onChange={e => setFormData({ ...formData, source: e.target.value })}
                    className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  >
                    {sources.length > 0 ? (
                      sources.filter(s => s.isActive).map(s => (
                        <option key={s.id} value={s.code}>
                          {s.name}
                        </option>
                      ))
                    ) : (
                      <>
                        <option value="WALK_IN">Walk-in Visit</option>
                        <option value="WEBSITE">Website Portal</option>
                        <option value="PHONE">Phone Call</option>
                        <option value="REFERRAL">Referral / Word of Mouth</option>
                        <option value="SOCIAL_MEDIA">Social Media</option>
                        <option value="EMAIL">Direct Email</option>
                        <option value="EXPO_EVENT">Expo / Education Fair</option>
                        <option value="OTHER">Other</option>
                      </>
                    )}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Enquiry Type
                  </label>
                  <select
                    value={formData.enquiryType}
                    onChange={e => setFormData({ ...formData, enquiryType: e.target.value })}
                    className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  >
                    <option value="Admission">Standard Admission</option>
                    <option value="Transfer">Mid-Term Transfer</option>
                    <option value="Scholarship">Scholarship Inquiry</option>
                    <option value="Information">General Prospectus</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1">
                    <Flag className="w-3.5 h-3.5 text-indigo-500" />
                    <span>Lead Priority</span>
                  </label>
                  <select
                    value={formData.priority}
                    onChange={e => setFormData({ ...formData, priority: e.target.value as EnquiryPriority })}
                    className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none font-semibold"
                  >
                    <option value="LOW">Low</option>
                    <option value="MEDIUM">Medium</option>
                    <option value="HIGH">High (Hot Lead)</option>
                    <option value="URGENT">Urgent / Decision Today</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Pipeline Status
                  </label>
                  <select
                    value={formData.status}
                    onChange={e => setFormData({ ...formData, status: e.target.value as FrontOfficeEnquiryStatus })}
                    className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none font-semibold"
                  >
                    <option value="NEW">New Prospect</option>
                    <option value="CONTACTED">Contacted</option>
                    <option value="FOLLOW_UP_REQUIRED">Follow-up Required</option>
                    <option value="FOLLOW_UP_IN_PROGRESS">Follow-up In Progress</option>
                    <option value="INTERESTED">Interested / Warm</option>
                    <option value="APPLICATION_STARTED">Application Started</option>
                    <option value="QUALIFIED">Qualified</option>
                    <option value="CONVERTED">Converted to Admission</option>
                    <option value="NOT_INTERESTED">Not Interested</option>
                    <option value="LOST">Lost</option>
                    <option value="CLOSED">Closed / Archive</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Follow-up Date
                  </label>
                  <input
                    type="date"
                    value={formData.followUpDate}
                    onChange={e => setFormData({ ...formData, followUpDate: e.target.value })}
                    className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Follow-up Time
                  </label>
                  <input
                    type="time"
                    value={formData.followUpTime}
                    onChange={e => setFormData({ ...formData, followUpTime: e.target.value })}
                    className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>

                <div className="sm:col-span-3">
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Front Office Notes & Parent Requirements
                  </label>
                  <textarea
                    rows={2}
                    value={formData.notes}
                    onChange={e => setFormData({ ...formData, notes: e.target.value })}
                    placeholder="Record conversation details, academic background, fee questions, or specific interests..."
                    className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none resize-none"
                  />
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center justify-between pt-3 border-t border-slate-200 dark:border-slate-800">
              {enquiryToEdit && enquiryToEdit.status !== 'CONVERTED' && onConvertToAdmission ? (
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onConvertToAdmission(enquiryToEdit);
                  }}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/40 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 border border-emerald-200 dark:border-emerald-800 rounded-xl transition"
                >
                  <span>Convert to Application</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              ) : (
                <div />
              )}

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-3.5 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="inline-flex items-center gap-1.5 px-4 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 rounded-xl shadow-sm transition disabled:opacity-50"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>{loading ? 'Saving...' : enquiryToEdit ? 'Save Changes' : 'Log Enquiry'}</span>
                </button>
              </div>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
