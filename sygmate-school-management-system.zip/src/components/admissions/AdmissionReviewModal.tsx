import React, { useState } from 'react';
import {
  X,
  CheckCircle,
  XCircle,
  Clock,
  User,
  Phone,
  Mail,
  MapPin,
  Calendar,
  GraduationCap,
  FileText,
  AlertTriangle,
  History,
  Check,
  ShieldCheck,
  Sparkles,
  ArrowRight
} from 'lucide-react';
import { api } from '../../services/api';
import { AdmissionApplication, AdmissionApplicationStatus, StudentProfile, AcademicEnrollment } from '../../types';

interface AdmissionReviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  application: AdmissionApplication | null;
  onUpdated: (app: AdmissionApplication, enrolledData?: { studentProfile: StudentProfile; enrollment: AcademicEnrollment; admissionNumber: string; rollNumber: string }) => void;
}

export const AdmissionReviewModal: React.FC<AdmissionReviewModalProps> = ({
  isOpen,
  onClose,
  application,
  onUpdated
}) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showRejectInput, setShowRejectInput] = useState(false);
  const [rejectionReason, setRejectionReason] = useState('');
  const [reviewRemarks, setReviewRemarks] = useState('');

  // Enrollment success announcement card
  const [enrolledInfo, setEnrolledInfo] = useState<{
    admissionNumber: string;
    rollNumber: string;
    studentName: string;
  } | null>(null);

  if (!isOpen || !application) return null;

  const handleStatusChange = async (targetStatus: AdmissionApplicationStatus) => {
    try {
      setLoading(true);
      setError(null);

      if (targetStatus === 'REJECTED' && (!rejectionReason || rejectionReason.trim().length < 5)) {
        setError('Please provide a specific rejection reason (at least 5 characters).');
        setLoading(false);
        return;
      }

      const res = await api.admissions.updateApplicationStatus(application.id, {
        targetStatus,
        reason: targetStatus === 'REJECTED' ? rejectionReason : reviewRemarks,
        reviewRemarks: reviewRemarks || undefined
      });

      if (res.success && res.data) {
        onUpdated(res.data);
        setShowRejectInput(false);
        setRejectionReason('');
        setReviewRemarks('');
      } else {
        setError(res.error || 'Failed to update application status.');
      }
    } catch (err: any) {
      setError(err.message || 'Error changing status.');
    } finally {
      setLoading(false);
    }
  };

  const handleApproveAndEnroll = async () => {
    try {
      setLoading(true);
      setError(null);

      const res = await api.admissions.approveAndEnroll(application.id);
      if (res.success && res.data) {
        setEnrolledInfo({
          admissionNumber: res.data.admissionNumber,
          rollNumber: res.data.rollNumber,
          studentName: application.fullName
        });
        onUpdated(res.data.application, res.data);
      } else {
        setError(res.error || 'Failed to enroll student.');
      }
    } catch (err: any) {
      setError(err.message || 'Error processing enrollment.');
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status: AdmissionApplicationStatus) => {
    switch (status) {
      case 'ENROLLED':
      case 'ACTIVE':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
            <Check className="w-3.5 h-3.5" />
            <span>Enrolled & Active</span>
          </span>
        );
      case 'APPROVED':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-blue-100 dark:bg-blue-950/60 text-blue-800 dark:text-blue-300 border border-blue-200 dark:border-blue-800">
            <CheckCircle className="w-3.5 h-3.5" />
            <span>Approved</span>
          </span>
        );
      case 'UNDER_REVIEW':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 border border-amber-200 dark:border-amber-800">
            <Clock className="w-3.5 h-3.5" />
            <span>Under Review</span>
          </span>
        );
      case 'REJECTED':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-rose-100 dark:bg-rose-950/60 text-rose-800 dark:text-rose-300 border border-rose-200 dark:border-rose-800">
            <XCircle className="w-3.5 h-3.5" />
            <span>Rejected</span>
          </span>
        );
      case 'DRAFT':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
            <span>Draft</span>
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-indigo-100 dark:bg-indigo-950/60 text-indigo-800 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
            <span>Submitted</span>
          </span>
        );
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col max-h-[92vh] overflow-hidden my-4">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold text-sm">
              <GraduationCap className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                  Application Dossier: {application.applicationNumber}
                </h2>
                {getStatusBadge(application.status)}
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Applied on {application.applicationDate} • Session: {application.academicSessionName}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Error notification */}
        {error && (
          <div className="mx-6 mt-3 p-3.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 flex items-center gap-3 text-rose-700 dark:text-rose-400 text-sm">
            <AlertTriangle className="w-5 h-5 flex-shrink-0" />
            <p>{error}</p>
          </div>
        )}

        {/* Enrolled Confirmation Banner */}
        {enrolledInfo && (
          <div className="mx-6 mt-3 p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 flex items-start gap-3">
            <div className="w-8 h-8 rounded-full bg-emerald-600 text-white flex items-center justify-center flex-shrink-0 mt-0.5">
              <Check className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-emerald-900 dark:text-emerald-200">
                Student Successfully Enrolled!
              </h4>
              <p className="text-xs text-emerald-800 dark:text-emerald-300 mt-0.5">
                {enrolledInfo.studentName} has been admitted. Master profile and academic enrollment records generated.
              </p>
              <div className="flex items-center gap-4 mt-2">
                <span className="text-xs font-semibold px-2.5 py-1 bg-white dark:bg-slate-900 rounded-md text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                  Admission No: <strong>{enrolledInfo.admissionNumber}</strong>
                </span>
                <span className="text-xs font-semibold px-2.5 py-1 bg-white dark:bg-slate-900 rounded-md text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                  Roll No: <strong>{enrolledInfo.rollNumber}</strong>
                </span>
              </div>
            </div>
          </div>
        )}

        {/* Dossier Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Top Applicant Banner */}
          <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3.5">
              <div className="w-14 h-14 rounded-2xl bg-indigo-600 text-white flex items-center justify-center text-xl font-bold uppercase shadow-sm">
                {application.firstName?.[0] || application.fullName?.[0] || 'A'}
                {application.lastName?.[0] || ''}
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  {application.fullName || `${application.firstName || ''} ${application.lastName || ''}`.trim() || 'Applicant'}
                </h3>
                <p className="text-xs text-slate-600 dark:text-slate-400">
                  {(application.gender || 'N/A').toUpperCase()} • DOB: {application.dateOfBirth || 'N/A'} • Blood Group: {application.bloodGroup || 'N/A'}
                </p>
                <p className="text-xs text-indigo-600 dark:text-indigo-400 font-medium mt-0.5">
                  Target: {application.className} {application.sectionName ? `(Section ${application.sectionName})` : ''}
                </p>
              </div>
            </div>

            {application.admittedAdmissionNumber && (
              <div className="text-right sm:border-l sm:border-slate-200 dark:sm:border-slate-700 sm:pl-4">
                <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">
                  Enrolled Student ID
                </span>
                <p className="text-sm font-bold text-emerald-600 dark:text-emerald-400">
                  {application.admittedAdmissionNumber}
                </p>
                <p className="text-xs text-slate-500">
                  Roll: {application.assignedRollNumber || 'N/A'}
                </p>
              </div>
            )}
          </div>

          {/* Details Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Student & Academic Info */}
            <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-850 space-y-3">
              <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                <span>Student Demographics & Prior School</span>
              </h4>
              <div className="text-xs space-y-2 text-slate-600 dark:text-slate-300">
                <div className="flex justify-between">
                  <span className="text-slate-400">Nationality:</span>
                  <span className="font-medium text-slate-900 dark:text-white">{application.nationality}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Religion / Category:</span>
                  <span className="font-medium text-slate-900 dark:text-white">
                    {application.religion || 'N/A'} / {application.category || 'General'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Student Contact:</span>
                  <span className="font-medium text-slate-900 dark:text-white">
                    {application.phone || application.email || 'None provided'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Residential Address:</span>
                  <span className="font-medium text-slate-900 dark:text-white text-right max-w-[60%]">
                    {application.presentAddress || application.address || 'N/A'}
                  </span>
                </div>
                <div className="flex justify-between border-t border-slate-100 dark:border-slate-800 pt-2">
                  <span className="text-slate-400">Previous School:</span>
                  <span className="font-medium text-slate-900 dark:text-white">
                    {application.previousSchoolName || 'None'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Previous Class / TC:</span>
                  <span className="font-medium text-slate-900 dark:text-white">
                    {application.previousClass || 'N/A'} • TC: {application.transferCertificateNumber || 'N/A'}
                  </span>
                </div>
              </div>
            </div>

            {/* Parent & Guardian Info */}
            <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-850 space-y-3">
              <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-1.5">
                <Phone className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                <span>Parent / Guardian Contacts</span>
              </h4>
              <div className="text-xs space-y-2 text-slate-600 dark:text-slate-300">
                <div className="flex justify-between">
                  <span className="text-slate-400">Guardian Name:</span>
                  <span className="font-medium text-slate-900 dark:text-white">
                    {application.guardianName} ({application.guardianRelation})
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Primary Phone:</span>
                  <a href={`tel:${application.guardianPhone}`} className="font-medium text-indigo-600 dark:text-indigo-400 hover:underline">
                    {application.guardianPhone}
                  </a>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Email Address:</span>
                  <a href={`mailto:${application.guardianEmail}`} className="font-medium text-indigo-600 dark:text-indigo-400 hover:underline">
                    {application.guardianEmail || 'N/A'}
                  </a>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Emergency Phone:</span>
                  <span className="font-medium text-slate-900 dark:text-white">
                    {application.emergencyContact || application.guardianPhone}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Occupation:</span>
                  <span className="font-medium text-slate-900 dark:text-white">
                    {application.guardianOccupation || 'N/A'}
                  </span>
                </div>
                <div className="flex justify-between border-t border-slate-100 dark:border-slate-800 pt-2">
                  <span className="text-slate-400">Guardian Record Type:</span>
                  <span className="font-medium text-slate-900 dark:text-white">
                    {application.guardianMode === 'existing' ? 'Linked Existing Profile' : 'New Registered Profile'}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Documents Section */}
          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-850 space-y-3">
            <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-1.5">
              <FileText className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
              <span>Attached Verification Documents ({application?.documents?.length || 0})</span>
            </h4>

            {(application?.documents?.length || 0) === 0 ? (
              <p className="text-xs text-slate-400 italic py-2">No documents attached to this application.</p>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                {(application?.documents || []).map(doc => (
                  <div
                    key={doc.id}
                    className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-700/80 bg-slate-50/50 dark:bg-slate-800/40 flex items-center gap-2.5"
                  >
                    <FileText className="w-4 h-4 text-indigo-600 flex-shrink-0" />
                    <div className="min-w-0">
                      <p className="text-xs font-medium text-slate-900 dark:text-white truncate">{doc.name}</p>
                      <span className="text-[10px] uppercase font-semibold text-slate-500">
                        {(doc.category || 'DOCUMENT').replace(/_/g, ' ')}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Status Timeline History */}
          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-850 space-y-3">
            <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-1.5">
              <History className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
              <span>Status Audit & Review History</span>
            </h4>

            <div className="space-y-3 border-l-2 border-slate-200 dark:border-slate-700 pl-4 ml-1.5">
              {application.statusHistory.map((item, idx) => (
                <div key={idx} className="relative text-xs space-y-0.5">
                  <div className="absolute -left-[21px] top-1 w-2.5 h-2.5 rounded-full bg-indigo-600 border-2 border-white dark:border-slate-900" />
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-slate-900 dark:text-white">
                      {item.fromStatus} → {item.toStatus}
                    </span>
                    <span className="text-slate-400 text-[11px]">
                      {new Date(item.changedAt).toLocaleString()}
                    </span>
                  </div>
                  <p className="text-slate-600 dark:text-slate-400">{item.reason}</p>
                  <p className="text-[11px] text-slate-400">By: {item.changedBy}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Rejection Input Box if triggered */}
          {showRejectInput && (
            <div className="p-4 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 space-y-3">
              <div className="flex items-center gap-2 text-rose-800 dark:text-rose-300 font-semibold text-xs">
                <XCircle className="w-4 h-4" />
                <span>Specify Mandatory Rejection Reason:</span>
              </div>
              <textarea
                rows={2}
                value={rejectionReason}
                onChange={e => setRejectionReason(e.target.value)}
                placeholder="e.g. Incomplete documentation, age criteria not met, class quota full..."
                className="w-full px-3 py-2 text-xs rounded-lg border border-rose-300 dark:border-rose-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-rose-500 resize-none"
              />
              <div className="flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowRejectInput(false)}
                  className="px-3 py-1.5 text-xs text-slate-600 dark:text-slate-400 hover:bg-white dark:hover:bg-slate-800 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={() => handleStatusChange('REJECTED')}
                  disabled={loading || !rejectionReason.trim()}
                  className="px-4 py-1.5 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-lg disabled:opacity-50"
                >
                  Confirm Rejection
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Modal Action Controls Footer */}
        <div className="flex flex-wrap items-center justify-between gap-3 px-6 py-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40">
          <div className="flex items-center gap-2">
            {/* If currently under review, allow rejecting */}
            {application.status !== 'ENROLLED' && application.status !== 'REJECTED' && (
              <button
                type="button"
                onClick={() => setShowRejectInput(true)}
                disabled={loading}
                className="px-3 py-1.5 text-xs font-medium text-rose-700 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-100 dark:hover:bg-rose-900/60 border border-rose-200 dark:border-rose-800 rounded-xl transition"
              >
                Reject Application
              </button>
            )}
          </div>

          <div className="flex items-center gap-2">
            {/* Move to Under Review if Submitted */}
            {application.status === 'SUBMITTED' && (
              <button
                type="button"
                onClick={() => handleStatusChange('UNDER_REVIEW')}
                disabled={loading}
                className="px-4 py-2 text-xs font-semibold text-amber-700 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/40 hover:bg-amber-100 border border-amber-200 dark:border-amber-800 rounded-xl transition"
              >
                Mark Under Review
              </button>
            )}

            {/* Move to Approved if Under Review */}
            {application.status === 'UNDER_REVIEW' && (
              <button
                type="button"
                onClick={() => handleStatusChange('APPROVED')}
                disabled={loading}
                className="px-4 py-2 text-xs font-semibold text-blue-700 dark:text-blue-300 bg-blue-50 dark:bg-blue-950/40 hover:bg-blue-100 border border-blue-200 dark:border-blue-800 rounded-xl transition"
              >
                Approve Application
              </button>
            )}

            {/* Authoritative Enroll Now if Approved or Under Review */}
            {application.status !== 'ENROLLED' && application.status !== 'REJECTED' && (
              <button
                type="button"
                onClick={handleApproveAndEnroll}
                disabled={loading}
                className="inline-flex items-center gap-2 px-5 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 rounded-xl shadow-sm transition disabled:opacity-50"
              >
                <GraduationCap className="w-4 h-4" />
                <span>{loading ? 'Enrolling Student...' : 'Approve & Complete Academic Enrollment Now'}</span>
              </button>
            )}

            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
