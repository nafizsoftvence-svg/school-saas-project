import React, { useRef, useState } from 'react';
import {
  Printer,
  Download,
  X,
  Award,
  CheckCircle2,
  AlertCircle,
  Calendar,
  User,
  Building,
  GraduationCap,
  Sparkles,
  ShieldCheck,
  Percent,
  Check,
  Flame
} from 'lucide-react';
import { Modal } from '../ui/Modal.js';
import { Button } from '../ui/Button.js';
import { Badge } from '../ui/Badge.js';
import { ReportCardDetail } from '../../types/index.js';
import { downloadElementPdf, triggerSafePrint } from '../../utils/printPdf.js';

interface ReportCardPrintModalProps {
  isOpen: boolean;
  onClose: () => void;
  reportCard: ReportCardDetail | null;
}

export const ReportCardPrintModal: React.FC<ReportCardPrintModalProps> = ({
  isOpen,
  onClose,
  reportCard
}) => {
  const printContainerRef = useRef<HTMLDivElement>(null);
  const [isExporting, setIsExporting] = useState(false);

  if (!reportCard) return null;

  const {
    result,
    school,
    student,
    gradingScale,
    attendance: rawAttendance,
    merit,
    teacherRemarks,
    principalRemarks,
    issueDate,
    verificationHash
  } = reportCard;

  const attendance = rawAttendance || {
    attendancePercentage: 100,
    presentDays: 0,
    totalWorkingDays: 0,
    absentDays: 0,
    lateDays: 0
  };

  const handlePrint = async () => {
    try {
      setIsExporting(true);
      const cleanStudentName = student.name.replace(/\s+/g, '_');
      const cleanExam = (result.examName || 'Examination').replace(/[^a-zA-Z0-9_-]/g, '_');
      const filename = `ReportCard_${cleanStudentName}_${cleanExam}.pdf`;

      await downloadElementPdf('official-report-card-sheet', filename, {
        orientation: 'portrait'
      });

      await triggerSafePrint({
        elementOrId: 'official-report-card-sheet',
        fallbackTitle: `ReportCard_${cleanStudentName}`
      });
    } catch (err) {
      console.error('Report card print/PDF error:', err);
      try {
        window.print();
      } catch {
        // ignore
      }
    } finally {
      setIsExporting(false);
    }
  };

  const isDistinction = result.summary.resultStatus === 'DISTINCTION';
  const isPassed = result.summary.resultStatus === 'PASSED' || isDistinction;
  const subjectList: any[] = (result as any).subjects || (result as any).subjectScores || [];

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Official Academic Report Card"
      size="2xl"
    >
      <div className="space-y-6">
        {/* Action Header bar inside modal */}
        <div className="flex items-center justify-between bg-slate-900/80 p-4 rounded-xl border border-white/10 no-print">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-indigo-500/20 text-indigo-400 rounded-lg">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <p className="text-sm font-semibold text-white">
                {student.name} • {student.className} ({student.sectionName})
              </p>
              <p className="text-xs text-slate-400">
                {result.examName} • {result.academicSessionName}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={onClose}
              className="text-slate-300 hover:text-white"
            >
              Close
            </Button>
            <Button
              variant="primary"
              size="sm"
              onClick={handlePrint}
              disabled={isExporting}
              className="bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white shadow-lg shadow-indigo-600/30"
            >
              <Printer className="w-4 h-4 mr-2" />
              {isExporting ? 'Generating PDF...' : 'Print / Save PDF'}
            </Button>
          </div>
        </div>

        {/* The Printable Report Card Sheet */}
        <div
          ref={printContainerRef}
          id="official-report-card-sheet"
          className="bg-white text-slate-900 rounded-2xl p-6 sm:p-10 border-2 border-indigo-200 shadow-2xl space-y-6 print:border-none print:shadow-none print:p-0 print:m-0"
          style={{ minHeight: '840px' }}
        >
          {/* Header & School Crest */}
          <div className="flex flex-col sm:flex-row items-center justify-between pb-6 border-b-2 border-indigo-900/20 gap-4 text-center sm:text-left">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-2xl bg-indigo-900 text-white flex items-center justify-center font-black text-2xl shadow-md border-2 border-indigo-700">
                {school.logoUrl ? (
                  <img
                    src={school.logoUrl}
                    alt={school.name}
                    className="w-full h-full object-cover rounded-2xl"
                  />
                ) : (
                  <span>SYG</span>
                )}
              </div>
              <div>
                <h2 className="text-xl sm:text-2xl font-black text-indigo-950 tracking-tight">
                  {school.name}
                </h2>
                <p className="text-xs text-slate-600 font-medium max-w-md">
                  {school.address}
                </p>
                <div className="flex items-center gap-3 text-[11px] text-slate-500 font-medium mt-1 justify-center sm:justify-start">
                  <span>Affiliation: {school.affiliationNumber}</span>
                  <span>•</span>
                  <span>{school.website}</span>
                  <span>•</span>
                  <span>{school.email}</span>
                </div>
              </div>
            </div>

            <div className="text-center sm:text-right bg-indigo-50/80 px-4 py-3 rounded-xl border border-indigo-100 min-w-[180px]">
              <span className="text-[10px] font-bold uppercase tracking-widest text-indigo-700 block">
                Official Transcript
              </span>
              <span className="text-sm font-extrabold text-indigo-950 block mt-0.5">
                {result.examName}
              </span>
              <span className="text-xs text-indigo-800 font-semibold block">
                Session: {result.academicSessionName}
              </span>
            </div>
          </div>

          {/* Student Dossier Matrix */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs">
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Student Name</span>
              <span className="font-bold text-slate-900 text-sm mt-0.5 block">{student.name}</span>
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Admission / ID</span>
              <span className="font-semibold text-slate-800 mt-0.5 block font-mono">{student.admissionNumber}</span>
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Class & Section</span>
              <span className="font-bold text-indigo-900 mt-0.5 block">{student.className} — {student.sectionName}</span>
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Roll Number</span>
              <span className="font-semibold text-slate-800 mt-0.5 block font-mono">#{student.rollNumber}</span>
            </div>

            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Guardian / Parent</span>
              <span className="font-medium text-slate-700 mt-0.5 block">{student.guardianName || 'Dr. Arthur Sterling'}</span>
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Date of Birth</span>
              <span className="font-medium text-slate-700 mt-0.5 block">{student.dateOfBirth || '2009-05-18'}</span>
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Merit Position</span>
              <span className="font-bold text-indigo-900 mt-0.5 block">
                {merit.classRank ? `Class Rank: #${merit.classRank} / ${merit.totalClassStudents || 30}` : 'Unranked'}
              </span>
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Attendance Rate</span>
              <span className="font-bold text-emerald-700 mt-0.5 block">
                {attendance.attendancePercentage}% ({attendance.presentDays}/{attendance.totalWorkingDays} days)
              </span>
            </div>
          </div>

          {/* Subject-Wise Detailed Performance Table */}
          <div className="overflow-x-auto rounded-xl border border-slate-200 shadow-sm">
            <table className="w-full text-xs text-left">
              <thead className="bg-indigo-950 text-white font-bold uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="py-3 px-3.5">#</th>
                  <th className="py-3 px-3.5">Subject</th>
                  <th className="py-3 px-2 text-center">Full Marks</th>
                  <th className="py-3 px-2 text-center">Pass Marks</th>
                  <th className="py-3 px-2 text-center">Theory</th>
                  <th className="py-3 px-2 text-center">Practical</th>
                  <th className="py-3 px-2 text-center">Obtained</th>
                  <th className="py-3 px-2 text-center">Percentage</th>
                  <th className="py-3 px-2 text-center">Grade</th>
                  <th className="py-3 px-2 text-center">Grade Pt</th>
                  <th className="py-3 px-3 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 font-medium">
                {subjectList.map((sub: any, idx: number) => {
                  const isSubPassed = sub.isPassed !== undefined ? sub.isPassed : (sub.status === 'PASSED' || (sub.grade && sub.grade !== 'F'));
                  return (
                    <tr
                      key={sub.subjectId || idx}
                      className={idx % 2 === 0 ? 'bg-white' : 'bg-slate-50/70'}
                    >
                      <td className="py-2.5 px-3.5 text-slate-400 font-mono">{idx + 1}</td>
                      <td className="py-2.5 px-3.5 font-bold text-slate-900">
                        {sub.subjectName}
                        {sub.subjectCode && (
                          <span className="text-[10px] text-slate-500 font-normal ml-1 font-mono">
                            ({sub.subjectCode})
                          </span>
                        )}
                      </td>
                      <td className="py-2.5 px-2 text-center text-slate-600 font-mono">{sub.fullMarks}</td>
                      <td className="py-2.5 px-2 text-center text-slate-500 font-mono">{sub.passMarks}</td>
                      <td className="py-2.5 px-2 text-center text-slate-700 font-mono">
                        {sub.theoryMarks !== undefined ? sub.theoryMarks : '-'}
                      </td>
                      <td className="py-2.5 px-2 text-center text-slate-700 font-mono">
                        {sub.practicalMarks !== undefined ? sub.practicalMarks : '-'}
                      </td>
                      <td className="py-2.5 px-2 text-center font-bold text-indigo-950 font-mono text-sm">
                        {sub.obtainedMarks}
                      </td>
                      <td className="py-2.5 px-2 text-center text-slate-700 font-mono">
                        {sub.percentage}%
                      </td>
                      <td className="py-2.5 px-2 text-center font-bold text-slate-900">
                        <span className="inline-block px-2 py-0.5 bg-indigo-50 border border-indigo-200 rounded text-indigo-950">
                          {sub.grade}
                        </span>
                      </td>
                      <td className="py-2.5 px-2 text-center font-bold text-slate-800 font-mono">
                        {Number(sub.gradePoint ?? 0).toFixed(2)}
                      </td>
                      <td className="py-2.5 px-3 text-center font-bold">
                        {isSubPassed ? (
                          <span className="text-emerald-700 inline-flex items-center gap-1">
                            <Check className="w-3 h-3" /> Pass
                          </span>
                        ) : (
                          <span className="text-rose-600 inline-flex items-center gap-1">
                            <X className="w-3 h-3" /> Fail
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
              <tfoot className="bg-slate-100/90 font-bold text-slate-900 border-t-2 border-slate-300">
                <tr>
                  <td colSpan={2} className="py-3 px-3.5 uppercase tracking-wider text-[11px] text-indigo-950">
                    Grand Total / Aggregates
                  </td>
                  <td className="py-3 px-2 text-center font-mono text-sm">{result.summary?.totalFullMarks ?? 0}</td>
                  <td className="py-3 px-2 text-center text-slate-400 font-mono">-</td>
                  <td className="py-3 px-2 text-center text-slate-400 font-mono">-</td>
                  <td className="py-3 px-2 text-center text-slate-400 font-mono">-</td>
                  <td className="py-3 px-2 text-center font-mono text-sm text-indigo-950">
                    {result.summary?.totalObtainedMarks ?? 0}
                  </td>
                  <td className="py-3 px-2 text-center font-mono text-sm text-indigo-950">
                    {result.summary?.overallPercentage ?? 0}%
                  </td>
                  <td className="py-3 px-2 text-center font-black text-sm text-indigo-950">
                    {result.summary?.overallGrade || '—'}
                  </td>
                  <td className="py-3 px-2 text-center font-black text-sm text-indigo-950 font-mono">
                    {Number(result.summary?.gpa ?? 0).toFixed(2)}
                  </td>
                  <td className="py-3 px-3 text-center">
                    <span
                      className={`inline-block px-2.5 py-0.5 rounded text-[11px] font-black uppercase tracking-wider ${
                        isPassed
                          ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                          : 'bg-rose-100 text-rose-800 border border-rose-300'
                      }`}
                    >
                      {result.summary?.resultStatus || 'PENDING'}
                    </span>
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>

          {/* Academic Highlights & Key Performance Indicators */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3.5 bg-indigo-50/70 border border-indigo-100 rounded-xl text-center">
              <span className="text-[10px] font-bold uppercase text-indigo-600 block">Cumulative GPA</span>
              <span className="text-xl font-black text-indigo-950 block mt-0.5 font-mono">
                {Number(result.summary?.gpa ?? 0).toFixed(2)} / 4.00
              </span>
              <span className="text-[10px] font-semibold text-indigo-700">Grade: {result.summary?.overallGrade || '—'}</span>
            </div>

            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl text-center">
              <span className="text-[10px] font-bold uppercase text-slate-500 block">Overall Percentage</span>
              <span className="text-xl font-black text-slate-900 block mt-0.5 font-mono">
                {result.summary?.overallPercentage ?? 0}%
              </span>
              <span className="text-[10px] font-medium text-slate-600">
                {result.summary?.totalObtainedMarks ?? 0} / {result.summary?.totalFullMarks ?? 0} Marks
              </span>
            </div>

            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl text-center">
              <span className="text-[10px] font-bold uppercase text-slate-500 block">Merit & Rank</span>
              <span className="text-xl font-black text-slate-900 block mt-0.5">
                {merit.classRank ? `Rank #${merit.classRank}` : 'Top 10%'}
              </span>
              <span className="text-[10px] font-medium text-slate-600">
                Section Rank: #{merit.sectionRank || 1}
              </span>
            </div>

            <div className="p-3.5 bg-emerald-50 border border-emerald-100 rounded-xl text-center">
              <span className="text-[10px] font-bold uppercase text-emerald-600 block">Final Academic Standing</span>
              <span className="text-xl font-black text-emerald-950 block mt-0.5">
                {result.summary?.resultStatus || 'PENDING'}
              </span>
              <span className="text-[10px] font-medium text-emerald-700">
                Passed {result.summary?.passedSubjects ?? (result.summary as any)?.passedSubjectsCount ?? subjectList.filter((s: any) => s.isPassed || s.status === 'PASSED').length} of {result.summary?.totalSubjects ?? subjectList.length} Subjects
              </span>
            </div>
          </div>

          {/* Grading Scale Legend & Attendance Bar */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200">
              <h4 className="text-[11px] font-bold text-slate-800 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <GraduationCap className="w-3.5 h-3.5 text-indigo-700" />
                Grading Scale System
              </h4>
              <div className="grid grid-cols-4 gap-1 text-[10px] text-center font-mono">
                {gradingScale.slice(0, 8).map((scale) => (
                  <div key={scale.id} className="p-1 bg-white rounded border border-slate-200">
                    <span className="font-bold text-indigo-900 block">{scale.grade}</span>
                    <span className="text-slate-500 block">{scale.minPercentage}%+</span>
                    <span className="text-slate-700 font-semibold block">{Number(scale.gradePoint ?? 0).toFixed(1)} GP</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200">
              <h4 className="text-[11px] font-bold text-slate-800 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-indigo-700" />
                Attendance Record
              </h4>
              <div className="space-y-1.5 text-xs text-slate-700">
                <div className="flex justify-between items-center">
                  <span>Total Working Days:</span>
                  <span className="font-bold font-mono">{attendance.totalWorkingDays}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span>Days Present:</span>
                  <span className="font-bold font-mono text-emerald-700">{attendance.presentDays}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span>Days Absent / Late:</span>
                  <span className="font-bold font-mono text-rose-700">{attendance.absentDays} / {attendance.lateDays}</span>
                </div>
                <div className="w-full bg-slate-200 rounded-full h-2 mt-1">
                  <div
                    className="bg-emerald-600 h-2 rounded-full"
                    style={{ width: `${Math.min(100, attendance.attendancePercentage)}%` }}
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Remarks Section */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200">
              <span className="text-[10px] font-bold uppercase text-slate-400 block mb-1">
                Class Teacher Remarks
              </span>
              <p className="text-slate-800 italic leading-relaxed">
                "{teacherRemarks || 'Demonstrates exceptional dedication, clarity of concepts, and active classroom leadership throughout this term.'}"
              </p>
            </div>
            <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200">
              <span className="text-[10px] font-bold uppercase text-slate-400 block mb-1">
                Principal & Academic Board Remarks
              </span>
              <p className="text-slate-800 italic leading-relaxed">
                "{principalRemarks || 'Promoted with high academic distinction. Recommended for honor roll commendation.'}"
              </p>
            </div>
          </div>

          {/* Verification & Signatures */}
          <div className="pt-6 border-t-2 border-slate-200 grid grid-cols-3 gap-6 text-center text-xs">
            <div className="space-y-8">
              <div className="h-10 flex items-end justify-center">
                <span className="font-serif italic text-sm text-slate-600">Mrs. H. Montgomery</span>
              </div>
              <div className="border-t border-slate-400 pt-1">
                <span className="text-[11px] font-bold text-slate-700 uppercase tracking-wider block">
                  Class Teacher
                </span>
                <span className="text-[10px] text-slate-500">Signature</span>
              </div>
            </div>

            <div className="space-y-8">
              <div className="h-10 flex items-end justify-center">
                <div className="p-1.5 bg-slate-100 rounded-lg border border-slate-300 font-mono text-[9px] text-slate-600">
                  <span className="font-bold block text-[8px] text-slate-400 uppercase">Verification Hash</span>
                  {verificationHash || 'SYG-VER-2026-99A1'}
                </div>
              </div>
              <div className="border-t border-slate-400 pt-1">
                <span className="text-[11px] font-bold text-slate-700 uppercase tracking-wider block">
                  Controller of Exams
                </span>
                <span className="text-[10px] text-slate-500">Official Seal</span>
              </div>
            </div>

            <div className="space-y-8">
              <div className="h-10 flex items-end justify-center">
                <span className="font-serif italic text-sm text-indigo-900 font-bold">Dr. Eleanor Vance</span>
              </div>
              <div className="border-t border-slate-400 pt-1">
                <span className="text-[11px] font-bold text-slate-700 uppercase tracking-wider block">
                  Principal
                </span>
                <span className="text-[10px] text-slate-500">Signature & Date: {issueDate.slice(0, 10)}</span>
              </div>
            </div>
          </div>

          {/* Footer watermark */}
          <div className="text-center text-[10px] text-slate-400 pt-2 border-t border-slate-100">
            This document is generated by Sygmate School Management System. Authenticity verifiable with institutional database hash.
          </div>
        </div>
      </div>
    </Modal>
  );
};
