import React, { useState, useEffect } from 'react';
import {
  Search,
  Filter,
  RefreshCw,
  Eye,
  RotateCcw,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Award,
  Users,
  BookOpen,
  Send,
  Lock,
  Unlock,
  AlertCircle,
  FileCheck2,
  Printer,
  X
} from 'lucide-react';
import { api } from '../../services/api.js';
import { useToast } from '../../context/ToastContext.js';
import {
  ExamMarksSubmission,
  ExamMarksSubmissionStatus,
  AcademicSession,
  SchoolClass,
  Section,
  Subject
} from '../../types/index.js';

interface AdminMarksReviewViewProps {
  academicSessions: AcademicSession[];
  classes: SchoolClass[];
  sections: Section[];
  subjects: Subject[];
}

export const AdminMarksReviewView: React.FC<AdminMarksReviewViewProps> = ({
  academicSessions,
  classes,
  sections,
  subjects
}) => {
  const { addToast } = useToast();
  const [loading, setLoading] = useState<boolean>(true);
  const [submissions, setSubmissions] = useState<ExamMarksSubmission[]>([]);
  const [stats, setStats] = useState({
    total: 0,
    not_started: 0,
    draft: 0,
    submitted: 0,
    returned: 0,
    approved: 0
  });

  // Filter parameters
  const [sessionFilter, setSessionFilter] = useState<string>('ALL');
  const [classFilter, setClassFilter] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [searchTerm, setSearchTerm] = useState<string>('');

  // Selected Submission for Detailed Inspection Modal
  const [selectedSubmission, setSelectedSubmission] = useState<ExamMarksSubmission | null>(null);

  // Return to Teacher Modal
  const [returnModalItem, setReturnModalItem] = useState<ExamMarksSubmission | null>(null);
  const [returnReason, setReturnReason] = useState<string>('');
  const [submittingReturn, setSubmittingReturn] = useState<boolean>(false);

  const fetchSubmissions = async () => {
    try {
      setLoading(true);
      const res = await api.examinations.getAdminMarksSubmissions({
        academicSessionId: sessionFilter !== 'ALL' ? sessionFilter : undefined,
        classId: classFilter !== 'ALL' ? classFilter : undefined,
        status: statusFilter !== 'ALL' ? (statusFilter as ExamMarksSubmissionStatus) : undefined,
        search: searchTerm.trim() || undefined
      });

      if (res.data) {
        setSubmissions(res.data);
        if (res.stats) setStats(res.stats);
      }
    } catch (err: any) {
      addToast({
        type: 'error',
        title: 'Failed to Load Submissions',
        message: err.message || 'Could not retrieve marks submissions matrix.'
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSubmissions();
  }, [sessionFilter, classFilter, statusFilter, searchTerm]);

  // Handle Return Submission
  const handleConfirmReturn = async () => {
    if (!returnModalItem) return;
    if (!returnReason.trim()) {
      addToast({
        type: 'warning',
        title: 'Reason Required',
        message: 'Please provide a clear reason for returning the marksheet to the teacher.'
      });
      return;
    }

    try {
      setSubmittingReturn(true);
      const res = await api.examinations.returnMarksToTeacher(returnModalItem.id, returnReason);
      if (res.success) {
        addToast({
          type: 'success',
          title: 'Marksheet Returned',
          message: `Marksheet for "${returnModalItem.subjectName}" returned to ${returnModalItem.teacherName}.`
        });
        setReturnModalItem(null);
        setReturnReason('');
        fetchSubmissions();
      }
    } catch (err: any) {
      addToast({
        type: 'error',
        title: 'Return Failed',
        message: err.message || 'Could not return marksheet.'
      });
    } finally {
      setSubmittingReturn(false);
    }
  };

  // Handle Unlock to Draft
  const handleUnlock = async (submissionId: string) => {
    try {
      const res = await api.examinations.unlockMarks(submissionId);
      if (res.success) {
        addToast({
          type: 'success',
          title: 'Marksheet Unlocked',
          message: 'Marksheet status changed back to Draft.'
        });
        fetchSubmissions();
      }
    } catch (err: any) {
      addToast({
        type: 'error',
        title: 'Unlock Failed',
        message: err.message || 'Could not unlock marksheet.'
      });
    }
  };

  return (
    <div className="space-y-6 animate-fade-in pb-12">
      {/* KPI Stats Header */}
      <div className="grid grid-cols-2 md:grid-cols-6 gap-3.5">
        <div className="p-4 rounded-2xl bg-slate-900/60 border border-white/10 backdrop-blur-xl">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Total Matrix</span>
          <p className="text-2xl font-black text-white mt-1">{stats.total}</p>
          <span className="text-[10px] text-slate-500 block">All Exam Subjects</span>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/60 border border-white/10 backdrop-blur-xl">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Not Started</span>
          <p className="text-2xl font-black text-slate-400 mt-1">{stats.not_started}</p>
          <span className="text-[10px] text-slate-500 block">Pending Teacher Entry</span>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/60 border border-white/10 backdrop-blur-xl">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">In Draft</span>
          <p className="text-2xl font-black text-amber-400 mt-1">{stats.draft}</p>
          <span className="text-[10px] text-amber-500/80 block">Partially Entered</span>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/60 border border-white/10 backdrop-blur-xl">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Submitted</span>
          <p className="text-2xl font-black text-emerald-400 mt-1">{stats.submitted}</p>
          <span className="text-[10px] text-emerald-500/80 block">Awaiting Verification</span>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/60 border border-white/10 backdrop-blur-xl">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Correction Req.</span>
          <p className="text-2xl font-black text-rose-400 mt-1">{stats.returned}</p>
          <span className="text-[10px] text-rose-500/80 block">Returned to Teacher</span>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/60 border border-white/10 backdrop-blur-xl">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Approved</span>
          <p className="text-2xl font-black text-purple-400 mt-1">{stats.approved}</p>
          <span className="text-[10px] text-purple-500/80 block">Published Ready</span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-slate-900/60 rounded-3xl p-4 border border-white/10 backdrop-blur-2xl shadow-xl flex flex-wrap items-center justify-between gap-4">
        <div className="relative flex-1 min-w-[220px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by subject, exam, teacher, or class..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-950/60 text-white placeholder-slate-500 pl-9 pr-4 py-2 rounded-xl text-xs border border-white/10 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 transition"
          />
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          {/* Status Filter */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-slate-950/60 text-slate-200 px-3 py-2 rounded-xl text-xs border border-white/10 focus:border-indigo-500 focus:outline-none transition cursor-pointer"
          >
            <option value="ALL">All Statuses</option>
            <option value="not_started">Not Started</option>
            <option value="draft">Draft In-Progress</option>
            <option value="submitted">Submitted</option>
            <option value="returned">Correction Requested</option>
            <option value="approved">Approved</option>
          </select>

          {/* Class Filter */}
          <select
            value={classFilter}
            onChange={(e) => setClassFilter(e.target.value)}
            className="bg-slate-950/60 text-slate-200 px-3 py-2 rounded-xl text-xs border border-white/10 focus:border-indigo-500 focus:outline-none transition cursor-pointer"
          >
            <option value="ALL">All Classes</option>
            {(classes || []).map((cls) => (
              <option key={cls.id} value={cls.id}>
                Class {cls.name}
              </option>
            ))}
          </select>

          {/* Session Filter */}
          <select
            value={sessionFilter}
            onChange={(e) => setSessionFilter(e.target.value)}
            className="bg-slate-950/60 text-slate-200 px-3 py-2 rounded-xl text-xs border border-white/10 focus:border-indigo-500 focus:outline-none transition cursor-pointer"
          >
            <option value="ALL">All Sessions</option>
            {(academicSessions || []).map((sess) => (
              <option key={sess.id} value={sess.id}>
                {sess.name}
              </option>
            ))}
          </select>

          <button
            onClick={fetchSubmissions}
            disabled={loading}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10 text-xs transition cursor-pointer"
            title="Refresh Matrix"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Submissions Table */}
      <div className="bg-slate-900/60 rounded-3xl border border-white/10 overflow-hidden backdrop-blur-2xl shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-white/10 bg-white/[0.02] text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                <th className="py-4 px-4">Subject & Code</th>
                <th className="py-4 px-4">Exam Cycle</th>
                <th className="py-4 px-4">Class & Section</th>
                <th className="py-4 px-4">Assigned Teacher</th>
                <th className="py-4 px-4 text-center">Marks (Pass / Full)</th>
                <th className="py-4 px-4 text-center">Progress</th>
                <th className="py-4 px-4 text-center">Status</th>
                <th className="py-4 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 text-xs">
              {loading ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-400">
                    <div className="w-8 h-8 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin mx-auto mb-2" />
                    <span>Loading marks submissions matrix...</span>
                  </td>
                </tr>
              ) : submissions.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-500">
                    <BookOpen className="w-8 h-8 mx-auto mb-2 opacity-40" />
                    <p className="text-sm font-semibold">No marks submission records match your filter.</p>
                  </td>
                </tr>
              ) : (
                submissions.map((sub) => {
                  const percent = sub.totalStudents > 0 ? Math.round((sub.enteredCount / sub.totalStudents) * 100) : 0;

                  return (
                    <tr key={sub.id} className="hover:bg-white/[0.02] transition-colors">
                      {/* Subject */}
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-white tracking-tight">{sub.subjectName}</span>
                          {sub.subjectCode && (
                            <span className="px-1.5 py-0.5 rounded bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 text-[10px] font-mono">
                              {sub.subjectCode}
                            </span>
                          )}
                        </div>
                        <span className="text-[10px] text-slate-400 block mt-0.5">Date: {sub.examDate || 'TBD'}</span>
                      </td>

                      {/* Exam */}
                      <td className="py-3 px-4">
                        <p className="font-semibold text-slate-200">{sub.examName}</p>
                        <span className="text-[10px] text-slate-400">{sub.academicSessionName}</span>
                      </td>

                      {/* Class */}
                      <td className="py-3 px-4">
                        <span className="px-2 py-0.5 rounded-md bg-white/5 text-slate-200 border border-white/10 font-mono font-semibold">
                          Class {sub.className}
                        </span>
                        <span className="text-[10px] text-slate-400 block mt-0.5">{sub.sectionName || 'All Sections'}</span>
                      </td>

                      {/* Teacher */}
                      <td className="py-3 px-4 text-slate-300">
                        <div className="flex items-center gap-2">
                          <Users className="w-3.5 h-3.5 text-indigo-400" />
                          <span className="font-semibold text-white">{sub.teacherName || 'Unassigned'}</span>
                        </div>
                        {sub.submittedAt && (
                          <span className="text-[10px] text-emerald-400 block mt-0.5">
                            Sub: {new Date(sub.submittedAt).toLocaleDateString()}
                          </span>
                        )}
                      </td>

                      {/* Marks Info */}
                      <td className="py-3 px-4 text-center">
                        <span className="text-amber-400 font-bold">{sub.passMarks}</span>
                        <span className="text-slate-500"> / </span>
                        <span className="text-white font-bold">{sub.fullMarks}</span>
                      </td>

                      {/* Progress */}
                      <td className="py-3 px-4 text-center">
                        <div className="w-24 mx-auto space-y-1">
                          <div className="flex justify-between text-[10px]">
                            <span className="text-slate-400">{sub.enteredCount}/{sub.totalStudents}</span>
                            <span className="font-mono text-white">{percent}%</span>
                          </div>
                          <div className="w-full bg-slate-950 rounded-full h-1.5 overflow-hidden border border-white/5">
                            <div
                              className={`h-full rounded-full ${
                                percent === 100 ? 'bg-emerald-500' : percent > 0 ? 'bg-indigo-500' : 'bg-slate-700'
                              }`}
                              style={{ width: `${percent}%` }}
                            />
                          </div>
                        </div>
                      </td>

                      {/* Status */}
                      <td className="py-3 px-4 text-center">
                        <span
                          className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider border ${
                            sub.status === 'submitted'
                              ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30'
                              : sub.status === 'approved'
                              ? 'bg-purple-500/10 text-purple-300 border-purple-500/30'
                              : sub.status === 'returned'
                              ? 'bg-rose-500/10 text-rose-300 border-rose-500/30 animate-pulse'
                              : sub.status === 'draft'
                              ? 'bg-amber-500/10 text-amber-300 border-amber-500/30'
                              : 'bg-slate-800 text-slate-400 border-slate-700'
                          }`}
                        >
                          {sub.status === 'not_started'
                            ? 'Not Started'
                            : sub.status === 'draft'
                            ? 'Draft'
                            : sub.status === 'submitted'
                            ? 'Submitted'
                            : sub.status === 'returned'
                            ? 'Returned'
                            : 'Approved'}
                        </span>
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {/* Inspect / View Marks */}
                          {sub.marks && sub.marks.length > 0 ? (
                            <button
                              onClick={() => setSelectedSubmission(sub)}
                              className="px-2.5 py-1 rounded-lg bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-300 border border-indigo-500/20 text-xs font-semibold transition cursor-pointer flex items-center gap-1"
                              title="Inspect student marks"
                            >
                              <Eye className="w-3.5 h-3.5" />
                              <span>View Marks</span>
                            </button>
                          ) : (
                            <span className="text-[10px] text-slate-500 italic pr-2">No data</span>
                          )}

                          {/* Return to Teacher */}
                          {sub.status === 'submitted' && (
                            <button
                              onClick={() => {
                                setReturnModalItem(sub);
                                setReturnReason('');
                              }}
                              className="px-2.5 py-1 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/20 text-xs font-semibold transition cursor-pointer flex items-center gap-1"
                              title="Request correction from teacher"
                            >
                              <RotateCcw className="w-3.5 h-3.5" />
                              <span>Return</span>
                            </button>
                          )}

                          {/* Unlock */}
                          {sub.status === 'submitted' && (
                            <button
                              onClick={() => handleUnlock(sub.id)}
                              className="p-1 rounded-lg bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white border border-white/10 transition cursor-pointer"
                              title="Unlock to Draft"
                            >
                              <Unlock className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Return to Teacher Modal */}
      {returnModalItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
          <div className="bg-slate-900 border border-white/15 rounded-3xl max-w-lg w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center gap-3 text-rose-400">
              <div className="p-3 bg-rose-500/10 rounded-2xl border border-rose-500/20">
                <RotateCcw className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Return Marksheet to Teacher</h3>
                <p className="text-xs text-slate-400">
                  {returnModalItem.subjectName} • Teacher: {returnModalItem.teacherName}
                </p>
              </div>
            </div>

            <p className="text-xs text-slate-300">
              Returning this marksheet unlocks it in the Teacher's portal, notifying them to make corrections and re-submit.
            </p>

            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider">
                Reason / Correction Instructions <span className="text-rose-400">*</span>
              </label>
              <textarea
                rows={3}
                value={returnReason}
                onChange={(e) => setReturnReason(e.target.value)}
                placeholder="e.g. Please verify student #12's marks, score seems outside expected distribution..."
                className="w-full bg-slate-950/60 text-white placeholder-slate-500 p-3 rounded-xl text-xs border border-white/10 focus:border-rose-500 focus:outline-none focus:ring-1 focus:ring-rose-500 transition"
              />
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setReturnModalItem(null)}
                disabled={submittingReturn}
                className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-semibold transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmReturn}
                disabled={submittingReturn || !returnReason.trim()}
                className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-lg shadow-rose-600/30 transition flex items-center gap-2 cursor-pointer disabled:opacity-50"
              >
                <RotateCcw className="w-4 h-4" />
                <span>{submittingReturn ? 'Returning...' : 'Return Marksheet'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Inspect Student Marks Modal */}
      {selectedSubmission && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
          <div className="bg-slate-900 border border-white/15 rounded-3xl max-w-4xl w-full max-h-[85vh] flex flex-col p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-lg font-bold text-white tracking-tight">{selectedSubmission.subjectName}</h3>
                  <span className="px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 text-xs font-mono font-bold">
                    {selectedSubmission.subjectCode || 'SUBJ'}
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-0.5">
                  {selectedSubmission.examName} • Class {selectedSubmission.className} ({selectedSubmission.sectionName}) • Submitted by {selectedSubmission.teacherName}
                </p>
              </div>

              <button
                onClick={() => setSelectedSubmission(null)}
                className="p-1 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Quick Metrics Bar */}
            <div className="grid grid-cols-4 gap-3 text-xs bg-white/[0.02] p-3 rounded-2xl border border-white/5">
              <div>
                <span className="text-slate-400 block text-[10px] uppercase font-semibold">Evaluated</span>
                <span className="text-white font-bold text-sm">{selectedSubmission.marks?.length || 0} Students</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px] uppercase font-semibold">Pass / Fail</span>
                <span className="text-emerald-400 font-bold text-sm">
                  {selectedSubmission.passedCount} Pass <span className="text-slate-500 font-normal">/</span> <span className="text-rose-400">{selectedSubmission.failedCount} Fail</span>
                </span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px] uppercase font-semibold">Average Marks</span>
                <span className="text-indigo-300 font-bold text-sm">{selectedSubmission.averageMarks} / {selectedSubmission.fullMarks}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px] uppercase font-semibold">Absent / Exempt</span>
                <span className="text-amber-400 font-bold text-sm">{selectedSubmission.absentCount} / {selectedSubmission.exemptCount}</span>
              </div>
            </div>

            {/* Marks Table */}
            <div className="flex-1 overflow-y-auto rounded-2xl border border-white/10 bg-slate-950/40">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="sticky top-0 bg-slate-900 border-b border-white/10 text-[11px] font-bold text-slate-400 uppercase">
                  <tr>
                    <th className="py-2.5 px-3 text-center w-12">#</th>
                    <th className="py-2.5 px-3 text-center w-16">Roll</th>
                    <th className="py-2.5 px-3">Student Name</th>
                    <th className="py-2.5 px-3 text-center w-28">Marks ({selectedSubmission.fullMarks})</th>
                    <th className="py-2.5 px-3 text-center w-24">Result</th>
                    <th className="py-2.5 px-3">Remarks</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {(selectedSubmission.marks || []).map((m, idx) => (
                    <tr key={m.studentId} className="hover:bg-white/[0.02]">
                      <td className="py-2 px-3 text-center font-mono text-slate-500">{idx + 1}</td>
                      <td className="py-2 px-3 text-center font-mono font-bold text-white">{m.rollNumber}</td>
                      <td className="py-2 px-3 font-semibold text-white">{m.studentName}</td>
                      <td className="py-2 px-3 text-center font-mono font-bold text-sm">
                        {m.isAbsent ? (
                          <span className="text-rose-400">ABS</span>
                        ) : m.isExempt ? (
                          <span className="text-amber-400">EXM</span>
                        ) : m.obtainedMarks !== null ? (
                          <span className={m.isPassed ? 'text-emerald-400' : 'text-rose-400'}>{m.obtainedMarks}</span>
                        ) : (
                          <span className="text-slate-600">—</span>
                        )}
                      </td>
                      <td className="py-2 px-3 text-center">
                        {m.isAbsent ? (
                          <span className="text-[10px] font-bold text-rose-400">ABSENT</span>
                        ) : m.isExempt ? (
                          <span className="text-[10px] font-bold text-amber-400">EXEMPT</span>
                        ) : m.isPassed ? (
                          <span className="text-[10px] font-bold text-emerald-400">PASSED</span>
                        ) : (
                          <span className="text-[10px] font-bold text-rose-400">FAILED</span>
                        )}
                      </td>
                      <td className="py-2 px-3 text-slate-400 text-[11px]">{m.remarks || '—'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Footer with close button */}
            <div className="flex items-center justify-end pt-2 border-t border-white/10">
              <button
                onClick={() => setSelectedSubmission(null)}
                className="px-5 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-white text-xs font-semibold transition cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
