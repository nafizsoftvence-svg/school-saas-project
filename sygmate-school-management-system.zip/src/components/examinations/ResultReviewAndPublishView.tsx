import React, { useEffect, useState, useCallback, useMemo } from 'react';
import {
  FileCheck,
  CheckCircle2,
  AlertCircle,
  AlertTriangle,
  Send,
  Eye,
  RefreshCw,
  Search,
  Filter,
  Lock,
  Unlock,
  ShieldCheck,
  Undo2,
  ChevronRight,
  BookOpen,
  GraduationCap,
  Calendar,
  Layers,
  ArrowUpDown,
  History,
  Check,
  X,
  Sparkles,
  Info,
  Clock,
  UserCheck,
  Globe,
  Bell
} from 'lucide-react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '../ui/Card.js';
import { Button } from '../ui/Button.js';
import { Badge } from '../ui/Badge.js';
import { Alert } from '../ui/Alert.js';
import { Modal } from '../ui/Modal.js';
import { Input } from '../ui/Input.js';
import { Select } from '../ui/Select.js';
import { LoadingSpinner } from '../ui/LoadingSpinner.js';
import { EmptyState } from '../ui/EmptyState.js';
import { useToast } from '../../context/ToastContext.js';
import { useAuth } from '../../context/AuthContext.js';
import { api } from '../../services/api.js';
import {
  StudentExamResult,
  ResultWorkflowStatus,
  ResultReviewFilterParams,
  ResultReviewResponse,
  ResultReviewSummaryStats,
  ResultStatusHistoryItem,
  ChangeResultStatusPayload,
  BulkChangeResultStatusPayload,
  ReturnCorrectionPayload,
  BulkApproveResultsPayload,
  PublishResultsPayload,
  UnpublishReopenPayload,
  Examination,
  SchoolClass,
  Section,
  Subject,
  AcademicSession
} from '../../types/index.js';

export const ResultReviewAndPublishView: React.FC = () => {
  const { addToast } = useToast();
  const { user } = useAuth();
  const isSuperAdmin = user?.role === 'SUPER_ADMIN';

  // Filter States
  const [filterSession, setFilterSession] = useState<string>('ALL');
  const [filterExam, setFilterExam] = useState<string>('ALL');
  const [filterClass, setFilterClass] = useState<string>('ALL');
  const [filterSection, setFilterSection] = useState<string>('ALL');
  const [filterSubject, setFilterSubject] = useState<string>('ALL');
  const [filterWorkflowStatus, setFilterWorkflowStatus] = useState<string>('ALL');
  const [filterResultStatus, setFilterResultStatus] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(25);

  // Loaded Data
  const [results, setResults] = useState<StudentExamResult[]>([]);
  const [totalCount, setTotalCount] = useState<number>(0);
  const [stats, setStats] = useState<ResultReviewSummaryStats | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [refreshing, setRefreshing] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // Metadata dropdowns
  const [availableSessions, setAvailableSessions] = useState<Array<{ id: string; name: string }>>([]);
  const [availableExams, setAvailableExams] = useState<Array<{ id: string; name: string; type?: string; className?: string }>>([]);
  const [availableClasses, setAvailableClasses] = useState<Array<{ id: string; name: string }>>([]);
  const [availableSections, setAvailableSections] = useState<Array<{ id: string; name: string; classId?: string }>>([]);
  const [availableSubjects, setAvailableSubjects] = useState<Array<{ id: string; name: string; code?: string }>>([]);

  // Multi-Selection State
  const [selectedResultIds, setSelectedResultIds] = useState<string[]>([]);

  // Modals & Action States
  const [inspectedResult, setInspectedResult] = useState<StudentExamResult | null>(null);
  const [isInspectModalOpen, setIsInspectModalOpen] = useState<boolean>(false);
  const [isHistoryModalOpen, setIsHistoryModalOpen] = useState<boolean>(false);

  // Single Status Change Modal
  const [isStatusChangeModalOpen, setIsStatusChangeModalOpen] = useState<boolean>(false);
  const [targetSingleResult, setTargetSingleResult] = useState<StudentExamResult | null>(null);
  const [targetNextStatus, setTargetNextStatus] = useState<ResultWorkflowStatus>('UNDER_REVIEW');
  const [statusChangeReason, setStatusChangeReason] = useState<string>('');
  const [statusChangeNotes, setStatusChangeNotes] = useState<string>('');

  // Return for Correction Modal
  const [isCorrectionModalOpen, setIsCorrectionModalOpen] = useState<boolean>(false);
  const [correctionTargetIds, setCorrectionTargetIds] = useState<string[]>([]);
  const [correctionReason, setCorrectionReason] = useState<string>('');
  const [correctionNotes, setCorrectionNotes] = useState<string>('');

  // Publish Modal
  const [isPublishModalOpen, setIsPublishModalOpen] = useState<boolean>(false);
  const [publishTargetIds, setPublishTargetIds] = useState<string[]>([]);
  const [publishDate, setPublishDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [notifyPortals, setNotifyPortals] = useState<boolean>(true);

  // Unpublish / Reopen Modal (Super Admin)
  const [isReopenModalOpen, setIsReopenModalOpen] = useState<boolean>(false);
  const [reopenTargetIds, setReopenTargetIds] = useState<string[]>([]);
  const [reopenReason, setReopenReason] = useState<string>('');

  // Submitting state
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Load results from backend
  const fetchResults = useCallback(async (isSilent = false) => {
    try {
      if (!isSilent) setLoading(true);
      else setRefreshing(true);
      setError(null);

      const params: ResultReviewFilterParams = {
        academicSessionId: filterSession !== 'ALL' ? filterSession : undefined,
        examId: filterExam !== 'ALL' ? filterExam : undefined,
        classId: filterClass !== 'ALL' ? filterClass : undefined,
        sectionId: filterSection !== 'ALL' ? filterSection : undefined,
        subjectId: filterSubject !== 'ALL' ? filterSubject : undefined,
        workflowStatus: filterWorkflowStatus !== 'ALL' ? (filterWorkflowStatus as ResultWorkflowStatus) : undefined,
        resultStatus: filterResultStatus !== 'ALL' ? (filterResultStatus as any) : undefined,
        search: searchQuery.trim() ? searchQuery.trim() : undefined,
        page: currentPage,
        limit: pageSize
      };

      const res = await api.examinations.getResultsReview(params);
      if (res.success && res.data) {
        const reviewData: any = res.data;
        const items = Array.isArray(reviewData) ? reviewData : Array.isArray(reviewData.data) ? reviewData.data : [];
        setResults(items);
        setTotalCount(reviewData.total ?? (res as any).total ?? items.length);
        if (reviewData.stats) setStats(reviewData.stats);
        else if ((res as any).stats) setStats((res as any).stats);

        const sessions = reviewData.availableSessions || (res as any).availableSessions;
        if (Array.isArray(sessions)) setAvailableSessions(sessions);

        const exams = reviewData.availableExams || (res as any).availableExams;
        if (Array.isArray(exams)) setAvailableExams(exams);

        const classes = reviewData.availableClasses || (res as any).availableClasses;
        if (Array.isArray(classes)) setAvailableClasses(classes);

        const sections = reviewData.availableSections || (res as any).availableSections;
        if (Array.isArray(sections)) setAvailableSections(sections);

        const subjects = reviewData.availableSubjects || (res as any).availableSubjects;
        if (Array.isArray(subjects)) setAvailableSubjects(subjects);
      } else {
        setError(res.error || 'Failed to retrieve examination results.');
      }
    } catch (err: any) {
      console.error('Error fetching result review data:', err);
      setError(err?.message || 'Server error loading examination review data.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [
    filterSession,
    filterExam,
    filterClass,
    filterSection,
    filterSubject,
    filterWorkflowStatus,
    filterResultStatus,
    searchQuery,
    currentPage,
    pageSize
  ]);

  useEffect(() => {
    fetchResults();
  }, [fetchResults]);

  // Handle section dropdown options filtered by selected class
  const filteredSections = useMemo(() => {
    if (filterClass === 'ALL') return availableSections;
    return availableSections.filter((s) => !s.classId || s.classId === filterClass);
  }, [availableSections, filterClass]);

  // Select all checkbox logic
  const isAllSelected = useMemo(() => {
    if (results.length === 0) return false;
    return results.every((r) => selectedResultIds.includes(r.id));
  }, [results, selectedResultIds]);

  const toggleSelectAll = () => {
    if (isAllSelected) {
      setSelectedResultIds([]);
    } else {
      setSelectedResultIds((results || []).map((r) => r.id));
    }
  };

  const toggleSelectResult = (id: string) => {
    setSelectedResultIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  // Selected Results details
  const selectedResultsList = useMemo(() => {
    return results.filter((r) => selectedResultIds.includes(r.id));
  }, [results, selectedResultIds]);

  const selectedApprovedCount = useMemo(() => {
    return selectedResultsList.filter((r) => r.workflowStatus === 'APPROVED').length;
  }, [selectedResultsList]);

  const selectedEligibleForApprovalCount = useMemo(() => {
    return selectedResultsList.filter(
      (r) => r.workflowStatus === 'CALCULATED' || r.workflowStatus === 'UNDER_REVIEW'
    ).length;
  }, [selectedResultsList]);

  // Workflow Status badge formatter
  const renderWorkflowStatusBadge = (status?: ResultWorkflowStatus, isLocked?: boolean) => {
    const st = status || 'CALCULATED';
    switch (st) {
      case 'DRAFT':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-800 text-slate-300 border border-slate-700">
            DRAFT
          </span>
        );
      case 'CALCULATED':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-sky-500/20 text-sky-300 border border-sky-500/30">
            <Sparkles className="w-3 h-3 text-sky-400" />
            CALCULATED
          </span>
        );
      case 'UNDER_REVIEW':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/30 animate-pulse">
            <Clock className="w-3 h-3 text-amber-400" />
            UNDER REVIEW
          </span>
        );
      case 'CORRECTION_REQUIRED':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-500/20 text-rose-300 border border-rose-500/30">
            <AlertTriangle className="w-3 h-3 text-rose-400" />
            CORRECTION REQUIRED
          </span>
        );
      case 'APPROVED':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            APPROVED
            {isLocked && <Lock className="w-3 h-3 text-emerald-400/70" />}
          </span>
        );
      case 'PUBLISHED':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
            <Globe className="w-3.5 h-3.5 text-indigo-400" />
            PUBLISHED
            {isLocked && <Lock className="w-3 h-3 text-indigo-400/70" />}
          </span>
        );
      case 'ARCHIVED':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-zinc-800/90 text-zinc-400 border border-zinc-700">
            ARCHIVED
          </span>
        );
      default:
        return <Badge variant="neutral">{st}</Badge>;
    }
  };

  // Result Status Badge (Pass/Fail/Distinction)
  const renderResultStatusBadge = (resStatus: string) => {
    switch (resStatus) {
      case 'DISTINCTION':
        return <Badge variant="primary" className="bg-amber-500/20 text-amber-300 border-amber-500/30">DISTINCTION</Badge>;
      case 'PASSED':
        return <Badge variant="success" className="bg-emerald-500/20 text-emerald-300 border-emerald-500/30">PASSED</Badge>;
      case 'FAILED':
        return <Badge variant="danger" className="bg-rose-500/20 text-rose-300 border-rose-500/30">FAILED</Badge>;
      default:
        return <Badge variant="neutral">{resStatus}</Badge>;
    }
  };

  // =========================================================================
  // ACTIONS: Single Status Change
  // =========================================================================
  const openSingleStatusChange = (result: StudentExamResult, nextStatus: ResultWorkflowStatus) => {
    setTargetSingleResult(result);
    setTargetNextStatus(nextStatus);
    setStatusChangeReason('');
    setStatusChangeNotes('');
    setIsStatusChangeModalOpen(true);
  };

  const handleExecuteSingleStatusChange = async () => {
    if (!targetSingleResult) return;

    if (targetNextStatus === 'CORRECTION_REQUIRED' && (!statusChangeReason || statusChangeReason.trim().length < 5)) {
      addToast('Please provide a specific explanation (at least 5 characters) for why correction is required.', 'error');
      return;
    }

    try {
      setIsSubmitting(true);
      const res = await api.examinations.changeResultStatus(targetSingleResult.id, {
        targetStatus: targetNextStatus,
        reason: statusChangeReason.trim() || undefined,
        notes: statusChangeNotes.trim() || undefined
      });

      if (res.success) {
        addToast(`Result status changed to ${targetNextStatus}!`, 'success');
        setIsStatusChangeModalOpen(false);
        fetchResults(true);
      } else {
        addToast(res.error || 'Failed to update result status.', 'error');
      }
    } catch (err: any) {
      addToast(err?.message || 'Server error changing result status.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  // =========================================================================
  // ACTIONS: Bulk Move to "Under Review"
  // =========================================================================
  const handleBulkMoveToUnderReview = async () => {
    if (selectedResultIds.length === 0) return;

    try {
      setIsSubmitting(true);
      const res = await api.examinations.bulkChangeResultStatus({
        resultIds: selectedResultIds,
        targetStatus: 'UNDER_REVIEW',
        notes: 'Bulk moved to administrative review stage'
      });

      if (res.success) {
        addToast(`Successfully moved ${res.data?.updatedCount || selectedResultIds.length} results to Under Review!`, 'success');
        setSelectedResultIds([]);
        fetchResults(true);
      } else {
        addToast(res.error || 'Failed to update results.', 'error');
      }
    } catch (err: any) {
      addToast(err?.message || 'Error updating results.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  // =========================================================================
  // ACTIONS: Bulk Approve Results
  // =========================================================================
  const handleBulkApprove = async () => {
    if (selectedResultIds.length === 0) return;

    try {
      setIsSubmitting(true);
      const res = await api.examinations.bulkApproveResults({
        resultIds: selectedResultIds,
        notes: 'Administrative institutional verification and approval'
      });

      if (res.success) {
        addToast(
          `Successfully approved and locked ${res.data?.approvedCount || 0} examination results!`,
          'success'
        );
        setSelectedResultIds([]);
        fetchResults(true);
      } else {
        addToast(res.error || 'Failed to approve results.', 'error');
      }
    } catch (err: any) {
      addToast(err?.message || 'Error approving results.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  // =========================================================================
  // ACTIONS: Return for Correction (Single or Bulk)
  // =========================================================================
  const openCorrectionModal = (targetIds: string[]) => {
    setCorrectionTargetIds(targetIds);
    setCorrectionReason('');
    setCorrectionNotes('');
    setIsCorrectionModalOpen(true);
  };

  const handleExecuteReturnCorrection = async () => {
    if (correctionTargetIds.length === 0) return;

    if (!correctionReason || correctionReason.trim().length < 5) {
      addToast('A specific explanation (at least 5 characters) explaining what needs correction is required.', 'error');
      return;
    }

    try {
      setIsSubmitting(true);
      const res = await api.examinations.returnResultsForCorrection({
        resultIds: correctionTargetIds,
        reason: correctionReason.trim(),
        notes: correctionNotes.trim() || undefined
      });

      if (res.success) {
        addToast(
          `Returned ${res.data?.updatedCount || correctionTargetIds.length} result(s) to teachers for correction.`,
          'warning'
        );
        setIsCorrectionModalOpen(false);
        setSelectedResultIds([]);
        fetchResults(true);
      } else {
        addToast(res.error || 'Failed to return results for correction.', 'error');
      }
    } catch (err: any) {
      addToast(err?.message || 'Error returning results for correction.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  // =========================================================================
  // ACTIONS: Publish Results (Super Admin / Admin with Permission)
  // =========================================================================
  const openPublishModal = (targetIds?: string[]) => {
    if (targetIds && targetIds.length > 0) {
      setPublishTargetIds(targetIds);
    } else if (selectedResultIds.length > 0) {
      setPublishTargetIds(selectedResultIds);
    } else {
      setPublishTargetIds([]);
    }
    setPublishDate(new Date().toISOString().split('T')[0]);
    setNotifyPortals(true);
    setIsPublishModalOpen(true);
  };

  const handleExecutePublish = async () => {
    try {
      setIsSubmitting(true);

      const payload: PublishResultsPayload = {
        resultIds: publishTargetIds.length > 0 ? publishTargetIds : undefined,
        examId: publishTargetIds.length === 0 && filterExam !== 'ALL' ? filterExam : undefined,
        classId: publishTargetIds.length === 0 && filterClass !== 'ALL' ? filterClass : undefined,
        sectionId: publishTargetIds.length === 0 && filterSection !== 'ALL' ? filterSection : undefined,
        publishDate,
        notifyStudentsAndParents: notifyPortals
      };

      const res = await api.examinations.publishResults(payload);

      if (res.success) {
        addToast(
          `Successfully published ${res.data?.publishedCount || 0} approved results to Student and Guardian portals!`,
          'success'
        );
        setIsPublishModalOpen(false);
        setSelectedResultIds([]);
        fetchResults(true);
      } else {
        addToast(
          res.error || 'Failed to publish results. Please ensure results are in APPROVED status before publishing.',
          'error'
        );
      }
    } catch (err: any) {
      addToast(err?.message || 'Error publishing examination results.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  // =========================================================================
  // ACTIONS: Super Admin Reopen / Unpublish
  // =========================================================================
  const openReopenModal = (targetIds: string[]) => {
    setReopenTargetIds(targetIds);
    setReopenReason('');
    setIsReopenModalOpen(true);
  };

  const handleExecuteReopen = async () => {
    if (reopenTargetIds.length === 0) return;

    if (!reopenReason || reopenReason.trim().length < 5) {
      addToast('An institutional audit reason (at least 5 characters) is required to reopen published results.', 'error');
      return;
    }

    try {
      setIsSubmitting(true);
      const res = await api.examinations.unpublishReopenResults({
        resultIds: reopenTargetIds,
        reason: reopenReason.trim()
      });

      if (res.success) {
        addToast(
          `Successfully reopened ${res.data?.reopenedCount || reopenTargetIds.length} published results for administrative revision.`,
          'success'
        );
        setIsReopenModalOpen(false);
        setSelectedResultIds([]);
        fetchResults(true);
      } else {
        addToast(res.error || 'Failed to reopen results.', 'error');
      }
    } catch (err: any) {
      addToast(err?.message || 'Error reopening results.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Quick Inspector
  const handleInspectResult = (result: StudentExamResult) => {
    setInspectedResult(result);
    setIsInspectModalOpen(true);
  };

  // Quick Audit History Viewer
  const handleViewHistory = (result: StudentExamResult) => {
    setInspectedResult(result);
    setIsHistoryModalOpen(true);
  };

  return (
    <div className="space-y-6 animate-in fade-in-50 duration-200">
      {/* 1. Header & Quick Stat Telemetry */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 bg-indigo-500/10 border border-indigo-500/20 rounded-xl text-indigo-400">
              <FileCheck className="w-5 h-5" />
            </span>
            <h2 className="text-xl font-bold text-white tracking-tight">
              Result Review, Institutional Approval & Publishing
            </h2>
            <Badge variant="primary" className="bg-indigo-500/20 text-indigo-300 border-indigo-500/30 text-xs">
              Part 6E Engine
            </Badge>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Review calculated student GPA and subject scores, audit marking integrity, approve academic results, and securely publish to Student & Parent Portals.
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <Button
            id="btn-refresh-review-results"
            variant="outline"
            size="sm"
            onClick={() => fetchResults(true)}
            disabled={refreshing || loading}
            className="border-white/10 text-slate-300 hover:bg-slate-800"
          >
            <RefreshCw className={`w-4 h-4 mr-1.5 ${refreshing ? 'animate-spin text-indigo-400' : ''}`} />
            Refresh
          </Button>

          {/* Primary Action: Publish Results */}
          <Button
            id="btn-open-publish-dialog"
            variant="primary"
            size="sm"
            onClick={() => openPublishModal()}
            className="bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-600/30"
          >
            <Send className="w-4 h-4 mr-1.5" />
            Publish Approved Results
          </Button>
        </div>
      </div>

      {/* 2. KPI Telemetry Summary Cards */}
      {stats && (
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
          <div
            onClick={() => setFilterWorkflowStatus('ALL')}
            className={`p-3 rounded-xl border transition-all cursor-pointer ${
              filterWorkflowStatus === 'ALL'
                ? 'bg-slate-800/90 border-indigo-500 ring-1 ring-indigo-500/50'
                : 'bg-slate-900/60 border-white/5 hover:border-white/20'
            }`}
          >
            <p className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">Total Calculated</p>
            <p className="text-xl font-bold text-white mt-0.5">{stats.total}</p>
            <p className="text-[10px] text-slate-500 mt-0.5">All Cohorts</p>
          </div>

          <div
            onClick={() => setFilterWorkflowStatus('UNDER_REVIEW')}
            className={`p-3 rounded-xl border transition-all cursor-pointer ${
              filterWorkflowStatus === 'UNDER_REVIEW'
                ? 'bg-amber-950/40 border-amber-500 ring-1 ring-amber-500/50'
                : 'bg-slate-900/60 border-white/5 hover:border-amber-500/30'
            }`}
          >
            <p className="text-[11px] font-medium text-amber-400 uppercase tracking-wider">Under Review</p>
            <p className="text-xl font-bold text-amber-300 mt-0.5">{stats.underReview}</p>
            <p className="text-[10px] text-slate-500 mt-0.5">Pending Approval</p>
          </div>

          <div
            onClick={() => setFilterWorkflowStatus('CORRECTION_REQUIRED')}
            className={`p-3 rounded-xl border transition-all cursor-pointer ${
              filterWorkflowStatus === 'CORRECTION_REQUIRED'
                ? 'bg-rose-950/40 border-rose-500 ring-1 ring-rose-500/50'
                : 'bg-slate-900/60 border-white/5 hover:border-rose-500/30'
            }`}
          >
            <p className="text-[11px] font-medium text-rose-400 uppercase tracking-wider">Corrections</p>
            <p className="text-xl font-bold text-rose-300 mt-0.5">{stats.correctionRequired}</p>
            <p className="text-[10px] text-slate-500 mt-0.5">With Teachers</p>
          </div>

          <div
            onClick={() => setFilterWorkflowStatus('APPROVED')}
            className={`p-3 rounded-xl border transition-all cursor-pointer ${
              filterWorkflowStatus === 'APPROVED'
                ? 'bg-emerald-950/40 border-emerald-500 ring-1 ring-emerald-500/50'
                : 'bg-slate-900/60 border-white/5 hover:border-emerald-500/30'
            }`}
          >
            <p className="text-[11px] font-medium text-emerald-400 uppercase tracking-wider">Approved</p>
            <p className="text-xl font-bold text-emerald-300 mt-0.5">{stats.approved}</p>
            <p className="text-[10px] text-slate-500 mt-0.5">Ready to Publish</p>
          </div>

          <div
            onClick={() => setFilterWorkflowStatus('PUBLISHED')}
            className={`p-3 rounded-xl border transition-all cursor-pointer ${
              filterWorkflowStatus === 'PUBLISHED'
                ? 'bg-indigo-950/40 border-indigo-500 ring-1 ring-indigo-500/50'
                : 'bg-slate-900/60 border-white/5 hover:border-indigo-500/30'
            }`}
          >
            <p className="text-[11px] font-medium text-indigo-400 uppercase tracking-wider">Published</p>
            <p className="text-xl font-bold text-indigo-300 mt-0.5">{stats.published}</p>
            <p className="text-[10px] text-slate-500 mt-0.5">Live on Portals</p>
          </div>

          <div className="p-3 rounded-xl bg-slate-900/60 border border-white/5">
            <p className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">Pass Rate</p>
            <p className="text-xl font-bold text-emerald-400 mt-0.5">
              {stats.total > 0 ? `${Math.round(((stats.passedCount + stats.distinctionCount) / stats.total) * 100)}%` : '0%'}
            </p>
            <p className="text-[10px] text-slate-500 mt-0.5">{stats.passedCount + stats.distinctionCount} of {stats.total}</p>
          </div>

          <div className="p-3 rounded-xl bg-slate-900/60 border border-white/5">
            <p className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">Avg GPA</p>
            <p className="text-xl font-bold text-sky-400 mt-0.5">{Number(stats?.averageGpa ?? 0).toFixed(2)}</p>
            <p className="text-[10px] text-slate-500 mt-0.5">Scale of 4.0</p>
          </div>

          <div className="p-3 rounded-xl bg-slate-900/60 border border-white/5">
            <p className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">Avg Score</p>
            <p className="text-xl font-bold text-purple-400 mt-0.5">{Number(stats?.averagePercentage ?? 0).toFixed(1)}%</p>
            <p className="text-[10px] text-slate-500 mt-0.5">High: {Number(stats?.highestGpa ?? 0).toFixed(2)} GPA</p>
          </div>
        </div>
      )}

      {/* 3. Comprehensive Multi-Facet Filter Bar */}
      <Card className="bg-slate-900/70 border-white/10">
        <CardContent className="p-4 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
            {/* Academic Session */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">Academic Session</label>
              <Select
                id="select-review-session"
                value={filterSession}
                onChange={(e) => {
                  setFilterSession(e.target.value);
                  setCurrentPage(1);
                }}
                className="w-full bg-slate-800/90 border-white/10 text-xs py-1.5"
              >
                <option value="ALL">All Academic Sessions</option>
                {(availableSessions || []).map((s) => (
                  <option key={s.id} value={s.id}>{s.name}</option>
                ))}
              </Select>
            </div>

            {/* Examination */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">Examination</label>
              <Select
                id="select-review-exam"
                value={filterExam}
                onChange={(e) => {
                  setFilterExam(e.target.value);
                  setCurrentPage(1);
                }}
                className="w-full bg-slate-800/90 border-white/10 text-xs py-1.5"
              >
                <option value="ALL">All Examinations</option>
                {(availableExams || []).map((e) => (
                  <option key={e.id} value={e.id}>{e.name} {e.className ? `(${e.className})` : ''}</option>
                ))}
              </Select>
            </div>

            {/* Class */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">Class / Cohort</label>
              <Select
                id="select-review-class"
                value={filterClass}
                onChange={(e) => {
                  setFilterClass(e.target.value);
                  setFilterSection('ALL');
                  setCurrentPage(1);
                }}
                className="w-full bg-slate-800/90 border-white/10 text-xs py-1.5"
              >
                <option value="ALL">All Classes</option>
                {(availableClasses || []).map((c) => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </Select>
            </div>

            {/* Section */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">Section</label>
              <Select
                id="select-review-section"
                value={filterSection}
                onChange={(e) => {
                  setFilterSection(e.target.value);
                  setCurrentPage(1);
                }}
                className="w-full bg-slate-800/90 border-white/10 text-xs py-1.5"
              >
                <option value="ALL">All Sections</option>
                {(filteredSections || []).map((sec) => (
                  <option key={sec.id} value={sec.id}>{sec.name}</option>
                ))}
              </Select>
            </div>

            {/* Subject */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">Subject</label>
              <Select
                id="select-review-subject"
                value={filterSubject}
                onChange={(e) => {
                  setFilterSubject(e.target.value);
                  setCurrentPage(1);
                }}
                className="w-full bg-slate-800/90 border-white/10 text-xs py-1.5"
              >
                <option value="ALL">All Subjects</option>
                {(availableSubjects || []).map((sub) => (
                  <option key={sub.id} value={sub.id}>{sub.name} {sub.code ? `(${sub.code})` : ''}</option>
                ))}
              </Select>
            </div>

            {/* Workflow Status */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">Workflow Status</label>
              <Select
                id="select-review-workflow-status"
                value={filterWorkflowStatus}
                onChange={(e) => {
                  setFilterWorkflowStatus(e.target.value);
                  setCurrentPage(1);
                }}
                className="w-full bg-slate-800/90 border-white/10 text-xs py-1.5"
              >
                <option value="ALL">All Statuses</option>
                <option value="DRAFT">Draft</option>
                <option value="CALCULATED">Calculated</option>
                <option value="UNDER_REVIEW">Under Review</option>
                <option value="CORRECTION_REQUIRED">Correction Required</option>
                <option value="APPROVED">Approved</option>
                <option value="PUBLISHED">Published</option>
                <option value="ARCHIVED">Archived</option>
              </Select>
            </div>
          </div>

          {/* Search and Secondary Filter Row */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2 border-t border-white/5">
            <div className="relative w-full sm:w-80">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <Input
                id="input-search-results"
                placeholder="Search student, roll number, admission..."
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setCurrentPage(1);
                }}
                className="pl-9 bg-slate-800/90 border-white/10 text-xs py-1.5 h-9"
              />
            </div>

            <div className="flex items-center gap-2 flex-wrap w-full sm:w-auto justify-end">
              <span className="text-xs text-slate-400">Academic Standing:</span>
              <button
                type="button"
                onClick={() => {
                  setFilterResultStatus('ALL');
                  setCurrentPage(1);
                }}
                className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all ${
                  filterResultStatus === 'ALL'
                    ? 'bg-slate-700 text-white'
                    : 'text-slate-400 hover:text-white bg-slate-800/50'
                }`}
              >
                All
              </button>
              <button
                type="button"
                onClick={() => {
                  setFilterResultStatus('DISTINCTION');
                  setCurrentPage(1);
                }}
                className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all ${
                  filterResultStatus === 'DISTINCTION'
                    ? 'bg-amber-600 text-white shadow'
                    : 'text-amber-400 hover:bg-amber-950/40 bg-slate-800/50'
                }`}
              >
                Distinction
              </button>
              <button
                type="button"
                onClick={() => {
                  setFilterResultStatus('PASSED');
                  setCurrentPage(1);
                }}
                className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all ${
                  filterResultStatus === 'PASSED'
                    ? 'bg-emerald-600 text-white shadow'
                    : 'text-emerald-400 hover:bg-emerald-950/40 bg-slate-800/50'
                }`}
              >
                Passed
              </button>
              <button
                type="button"
                onClick={() => {
                  setFilterResultStatus('FAILED');
                  setCurrentPage(1);
                }}
                className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all ${
                  filterResultStatus === 'FAILED'
                    ? 'bg-rose-600 text-white shadow'
                    : 'text-rose-400 hover:bg-rose-950/40 bg-slate-800/50'
                }`}
              >
                Failed
              </button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 4. Bulk Actions Header Toolbar (When items are selected) */}
      {selectedResultIds.length > 0 && (
        <div className="flex items-center justify-between gap-4 p-3.5 bg-indigo-950/40 border border-indigo-500/30 rounded-2xl animate-in slide-in-from-top-2">
          <div className="flex items-center gap-3">
            <span className="flex items-center justify-center w-6 h-6 rounded-full bg-indigo-600 text-white text-xs font-bold">
              {selectedResultIds.length}
            </span>
            <span className="text-sm font-medium text-indigo-200">
              Students Selected across cohort
            </span>
            {selectedApprovedCount > 0 && (
              <Badge variant="success" className="bg-emerald-500/20 text-emerald-300 border-emerald-500/30 text-xs">
                {selectedApprovedCount} Approved (Ready to Publish)
              </Badge>
            )}
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {/* Bulk Move to Under Review */}
            <Button
              variant="outline"
              size="sm"
              onClick={handleBulkMoveToUnderReview}
              disabled={isSubmitting}
              className="border-amber-500/30 text-amber-300 hover:bg-amber-950/40 text-xs"
            >
              <Clock className="w-3.5 h-3.5 mr-1" />
              Mark Under Review
            </Button>

            {/* Bulk Return for Correction */}
            <Button
              variant="outline"
              size="sm"
              onClick={() => openCorrectionModal(selectedResultIds)}
              disabled={isSubmitting}
              className="border-rose-500/30 text-rose-300 hover:bg-rose-950/40 text-xs"
            >
              <Undo2 className="w-3.5 h-3.5 mr-1" />
              Return for Correction ({selectedResultIds.length})
            </Button>

            {/* Bulk Approve */}
            {selectedEligibleForApprovalCount > 0 && (
              <Button
                variant="primary"
                size="sm"
                onClick={handleBulkApprove}
                disabled={isSubmitting}
                className="bg-emerald-600 hover:bg-emerald-500 text-white text-xs shadow"
              >
                <ShieldCheck className="w-3.5 h-3.5 mr-1" />
                Approve & Lock ({selectedEligibleForApprovalCount})
              </Button>
            )}

            {/* Bulk Publish */}
            {selectedApprovedCount > 0 && (
              <Button
                variant="primary"
                size="sm"
                onClick={() => openPublishModal(selectedResultIds)}
                disabled={isSubmitting}
                className="bg-indigo-600 hover:bg-indigo-500 text-white text-xs shadow"
              >
                <Send className="w-3.5 h-3.5 mr-1" />
                Publish Approved ({selectedApprovedCount})
              </Button>
            )}

            {/* Super Admin Bulk Reopen */}
            {isSuperAdmin && selectedResultsList.some((r) => r.workflowStatus === 'PUBLISHED') && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => openReopenModal(selectedResultIds)}
                disabled={isSubmitting}
                className="border-purple-500/30 text-purple-300 hover:bg-purple-950/40 text-xs"
              >
                <Unlock className="w-3.5 h-3.5 mr-1" />
                Reopen Published
              </Button>
            )}
          </div>
        </div>
      )}

      {/* 5. Main Results Data Table */}
      <Card className="bg-slate-900/70 border-white/10 overflow-hidden">
        <div className="overflow-x-auto">
          {loading ? (
            <div className="p-12 flex flex-col items-center justify-center">
              <LoadingSpinner size="lg" className="text-indigo-400 mb-3" />
              <p className="text-sm text-slate-400">Loading student results and grading workflow...</p>
            </div>
          ) : results.length === 0 ? (
            <EmptyState
              icon={<FileCheck className="w-12 h-12 text-slate-500" />}
              title="No Calculated Examination Results"
              description="No student results match the current filters. Switch filters or calculate results first in Grade & Result Calculation."
              actionLabel="Reset Filters"
              onAction={() => {
                setFilterSession('ALL');
                setFilterExam('ALL');
                setFilterClass('ALL');
                setFilterSection('ALL');
                setFilterSubject('ALL');
                setFilterWorkflowStatus('ALL');
                setFilterResultStatus('ALL');
                setSearchQuery('');
              }}
            />
          ) : (
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-white/10 bg-slate-950/60 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                  <th className="py-3 px-4 w-10">
                    <input
                      type="checkbox"
                      checked={isAllSelected}
                      onChange={toggleSelectAll}
                      className="rounded border-slate-700 bg-slate-900 text-indigo-600 focus:ring-indigo-500 w-4 h-4 cursor-pointer"
                    />
                  </th>
                  <th className="py-3 px-4">Student</th>
                  <th className="py-3 px-3">Exam & Class</th>
                  <th className="py-3 px-3">Subject Breakdown</th>
                  <th className="py-3 px-3 text-right">Marks</th>
                  <th className="py-3 px-3 text-right">Percentage</th>
                  <th className="py-3 px-3 text-center">Grade</th>
                  <th className="py-3 px-3 text-center">GPA (4.0)</th>
                  <th className="py-3 px-3 text-center">Status</th>
                  <th className="py-3 px-3 text-center">Workflow</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 text-xs text-slate-300">
                {(results || []).map((result) => {
                  const isSelected = selectedResultIds.includes(result.id);
                  const isLocked = result.isLocked;
                  const currentStatus = result.workflowStatus || 'CALCULATED';

                  return (
                    <tr
                      key={result.id}
                      className={`hover:bg-slate-800/40 transition-colors ${
                        isSelected ? 'bg-indigo-950/20' : ''
                      }`}
                    >
                      {/* Checkbox */}
                      <td className="py-3 px-4">
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => toggleSelectResult(result.id)}
                          className="rounded border-slate-700 bg-slate-900 text-indigo-600 focus:ring-indigo-500 w-4 h-4 cursor-pointer"
                        />
                      </td>

                      {/* Student */}
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2.5">
                          <div className="w-8 h-8 rounded-full bg-slate-800 border border-white/10 flex items-center justify-center font-bold text-indigo-400 text-xs shrink-0">
                            {result.studentName.charAt(0)}
                          </div>
                          <div>
                            <p className="font-semibold text-white">{result.studentName}</p>
                            <p className="text-[11px] text-slate-400">
                              Adm: {result.admissionNumber} {result.rollNumber ? `• Roll: ${result.rollNumber}` : ''}
                            </p>
                          </div>
                        </div>
                      </td>

                      {/* Exam & Class */}
                      <td className="py-3 px-3">
                        <p className="font-medium text-slate-200">{result.examName}</p>
                        <p className="text-[11px] text-slate-400">
                          {result.className} {result.sectionName ? `(${result.sectionName})` : ''}
                        </p>
                      </td>

                      {/* Subject Scores Preview Badges */}
                      <td className="py-3 px-3">
                        <div className="flex items-center gap-1 flex-wrap max-w-xs">
                          {(result.subjectScores || []).slice(0, 4).map((sub) => (
                            <span
                              key={sub.subjectId}
                              title={`${sub.subjectName}: ${sub.obtainedMarks}/${sub.fullMarks} (${sub.grade} - ${sub.gradePoint} GP)`}
                              className={`px-1.5 py-0.5 rounded text-[10px] font-medium border ${
                                sub.isAbsent
                                  ? 'bg-zinc-800/80 text-zinc-400 border-zinc-700'
                                  : sub.isPassed
                                  ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/20'
                                  : 'bg-rose-500/10 text-rose-300 border-rose-500/20'
                              }`}
                            >
                              {sub.subjectCode || sub.subjectName.substring(0, 4)}: {sub.grade}
                            </span>
                          ))}
                          {(result.subjectScores || []).length > 4 && (
                            <span
                              onClick={() => handleInspectResult(result)}
                              className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-slate-800 text-slate-400 border border-white/10 hover:text-white cursor-pointer"
                            >
                              +{(result.subjectScores || []).length - 4} more
                            </span>
                          )}
                        </div>
                      </td>

                      {/* Full & Obtained Marks */}
                      <td className="py-3 px-3 text-right">
                        <span className="font-semibold text-white">
                          {result.summary.totalObtainedMarks}
                        </span>
                        <span className="text-slate-500 text-[11px]">
                          /{result.summary.totalFullMarks}
                        </span>
                      </td>

                      {/* Percentage */}
                      <td className="py-3 px-3 text-right font-medium text-slate-200">
                        {Number(result.summary?.overallPercentage ?? 0).toFixed(1)}%
                      </td>

                      {/* Grade */}
                      <td className="py-3 px-3 text-center">
                        <span className="inline-block px-2 py-0.5 rounded font-bold text-xs bg-slate-800 border border-white/10 text-white">
                          {result.summary?.overallGrade}
                        </span>
                      </td>

                      {/* GPA */}
                      <td className="py-3 px-3 text-center">
                        <span className="font-bold text-sky-400 text-xs">
                          {Number(result.summary?.gpa ?? 0).toFixed(2)}
                        </span>
                      </td>

                      {/* Academic Result Status */}
                      <td className="py-3 px-3 text-center">
                        {renderResultStatusBadge(result.summary.resultStatus)}
                      </td>

                      {/* Workflow Status */}
                      <td className="py-3 px-3 text-center">
                        {renderWorkflowStatusBadge(currentStatus, isLocked)}
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {/* Inspect / Marksheet Details */}
                          <button
                            type="button"
                            onClick={() => handleInspectResult(result)}
                            title="Inspect Detailed Marksheet & Subject Scores"
                            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                          >
                            <Eye className="w-4 h-4" />
                          </button>

                          {/* View Audit Trail */}
                          <button
                            type="button"
                            onClick={() => handleViewHistory(result)}
                            title="View Status Audit Trail"
                            className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-300 hover:bg-indigo-950/40 transition-colors"
                          >
                            <History className="w-4 h-4" />
                          </button>

                          {/* Quick Action: Approve */}
                          {(currentStatus === 'CALCULATED' || currentStatus === 'UNDER_REVIEW') && (
                            <button
                              type="button"
                              onClick={() => openSingleStatusChange(result, 'APPROVED')}
                              title="Approve & Lock Result"
                              className="p-1.5 rounded-lg text-emerald-400 hover:text-emerald-300 hover:bg-emerald-950/40 transition-colors"
                            >
                              <ShieldCheck className="w-4 h-4" />
                            </button>
                          )}

                          {/* Quick Action: Return for Correction */}
                          {currentStatus !== 'PUBLISHED' && currentStatus !== 'CORRECTION_REQUIRED' && (
                            <button
                              type="button"
                              onClick={() => openCorrectionModal([result.id])}
                              title="Return for Correction"
                              className="p-1.5 rounded-lg text-rose-400 hover:text-rose-300 hover:bg-rose-950/40 transition-colors"
                            >
                              <Undo2 className="w-4 h-4" />
                            </button>
                          )}

                          {/* Quick Action: Publish */}
                          {currentStatus === 'APPROVED' && (
                            <button
                              type="button"
                              onClick={() => openPublishModal([result.id])}
                              title="Publish Result to Student & Parent Portals"
                              className="p-1.5 rounded-lg text-indigo-400 hover:text-indigo-300 hover:bg-indigo-950/40 transition-colors"
                            >
                              <Send className="w-4 h-4" />
                            </button>
                          )}

                          {/* Super Admin: Reopen Published Result */}
                          {isSuperAdmin && currentStatus === 'PUBLISHED' && (
                            <button
                              type="button"
                              onClick={() => openReopenModal([result.id])}
                              title="Super Admin: Unlock & Reopen for Correction"
                              className="p-1.5 rounded-lg text-purple-400 hover:text-purple-300 hover:bg-purple-950/40 transition-colors"
                            >
                              <Unlock className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>

        {/* Pagination Toolbar */}
        {!loading && totalCount > 0 && (
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-3.5 border-t border-white/10 bg-slate-950/40 text-xs text-slate-400">
            <div>
              Showing <span className="font-semibold text-white">{(currentPage - 1) * pageSize + 1}</span> to{' '}
              <span className="font-semibold text-white">
                {Math.min(currentPage * pageSize, totalCount)}
              </span>{' '}
              of <span className="font-semibold text-white">{totalCount}</span> results
            </div>

            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="border-white/10 text-slate-300 hover:bg-slate-800 text-xs px-2.5 py-1"
              >
                Previous
              </Button>
              <span className="px-2 font-medium text-slate-300">
                Page {currentPage} of {Math.ceil(totalCount / pageSize) || 1}
              </span>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage((p) => p + 1)}
                disabled={currentPage >= Math.ceil(totalCount / pageSize)}
                className="border-white/10 text-slate-300 hover:bg-slate-800 text-xs px-2.5 py-1"
              >
                Next
              </Button>
            </div>
          </div>
        )}
      </Card>

      {/* ========================================================================= */}
      {/* MODAL 1: DETAILED MARKSHEET INSPECTOR */}
      {/* ========================================================================= */}
      {isInspectModalOpen && inspectedResult && (
        <Modal
          isOpen={isInspectModalOpen}
          onClose={() => setIsInspectModalOpen(false)}
          title={`Academic Result Breakdown: ${inspectedResult.studentName}`}
          className="max-w-4xl bg-slate-900 border-white/10 text-white"
        >
          <div className="space-y-6">
            {/* Student & Exam Header Badge Card */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 p-4 rounded-2xl bg-slate-950/60 border border-white/10">
              <div>
                <p className="text-xs text-slate-400">Student & Identification</p>
                <p className="text-base font-bold text-white mt-0.5">{inspectedResult.studentName}</p>
                <p className="text-xs text-slate-400">
                  Adm No: <span className="text-slate-200">{inspectedResult.admissionNumber}</span>
                  {inspectedResult.rollNumber ? ` • Roll: ${inspectedResult.rollNumber}` : ''}
                </p>
              </div>

              <div>
                <p className="text-xs text-slate-400">Examination & Cohort</p>
                <p className="text-sm font-semibold text-indigo-300 mt-0.5">{inspectedResult.examName}</p>
                <p className="text-xs text-slate-400">
                  {inspectedResult.className} • {inspectedResult.sectionName} • {inspectedResult.academicYear}
                </p>
              </div>

              <div>
                <p className="text-xs text-slate-400">Current Workflow State</p>
                <div className="mt-1 flex items-center gap-2">
                  {renderWorkflowStatusBadge(inspectedResult.workflowStatus, inspectedResult.isLocked)}
                  {renderResultStatusBadge(inspectedResult.summary.resultStatus)}
                </div>
              </div>
            </div>

            {/* Subject-Wise Marks & Grade Table */}
            <div>
              <div className="flex items-center justify-between mb-2.5">
                <h4 className="text-sm font-bold text-white flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-indigo-400" />
                  Subject Score Breakdown & Weightage
                </h4>
                <span className="text-xs text-slate-400">
                  {inspectedResult?.subjectScores?.length || 0} Subjects Evaluated
                </span>
              </div>

              <div className="rounded-xl border border-white/10 overflow-hidden">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-950/80 border-b border-white/10 text-slate-400 font-semibold uppercase text-[10px]">
                      <th className="py-2.5 px-3">Subject</th>
                      <th className="py-2.5 px-2 text-right">Full Marks</th>
                      <th className="py-2.5 px-2 text-right">Pass Marks</th>
                      <th className="py-2.5 px-2 text-right">Obtained</th>
                      <th className="py-2.5 px-2 text-right">Percentage</th>
                      <th className="py-2.5 px-2 text-center">Grade</th>
                      <th className="py-2.5 px-2 text-center">GP</th>
                      <th className="py-2.5 px-3 text-center">Pass/Fail</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5 text-slate-300">
                    {(inspectedResult.subjectScores || []).map((score) => (
                      <tr key={score.subjectId} className="hover:bg-slate-800/30">
                        <td className="py-2.5 px-3">
                          <p className="font-semibold text-white">{score.subjectName}</p>
                          {score.subjectCode && (
                            <p className="text-[10px] text-slate-500">{score.subjectCode}</p>
                          )}
                        </td>
                        <td className="py-2.5 px-2 text-right font-medium text-slate-400">{score.fullMarks}</td>
                        <td className="py-2.5 px-2 text-right text-slate-400">{score.passMarks}</td>
                        <td className="py-2.5 px-2 text-right font-bold text-white">
                          {score.isAbsent ? (
                            <span className="text-rose-400">ABSENT</span>
                          ) : score.isExempt ? (
                            <span className="text-amber-400">EXEMPT</span>
                          ) : (
                            score.obtainedMarks
                          )}
                        </td>
                        <td className="py-2.5 px-2 text-right text-slate-200">
                          {Number(score?.percentage ?? 0).toFixed(1)}%
                        </td>
                        <td className="py-2.5 px-2 text-center font-bold text-white">{score.grade}</td>
                        <td className="py-2.5 px-2 text-center font-bold text-sky-400">
                          {Number(score?.gradePoint ?? 0).toFixed(1)}
                        </td>
                        <td className="py-2.5 px-3 text-center">
                          {score.isPassed ? (
                            <Badge variant="success" className="bg-emerald-500/20 text-emerald-300 border-emerald-500/30 text-[10px]">
                              PASS
                            </Badge>
                          ) : (
                            <Badge variant="danger" className="bg-rose-500/20 text-rose-300 border-rose-500/30 text-[10px]">
                              FAIL
                            </Badge>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot>
                    <tr className="bg-slate-950/80 border-t border-white/10 font-bold text-xs text-white">
                      <td className="py-3 px-3">Total Aggregate</td>
                      <td className="py-3 px-2 text-right text-slate-400">{inspectedResult.summary?.totalFullMarks}</td>
                      <td className="py-3 px-2 text-right text-slate-400">—</td>
                      <td className="py-3 px-2 text-right text-indigo-300 text-sm">
                        {inspectedResult.summary?.totalObtainedMarks}
                      </td>
                      <td className="py-3 px-2 text-right text-purple-300">
                        {Number(inspectedResult.summary?.overallPercentage ?? 0).toFixed(1)}%
                      </td>
                      <td className="py-3 px-2 text-center text-amber-300">{inspectedResult.summary?.overallGrade}</td>
                      <td className="py-3 px-2 text-center text-sky-400 text-sm">{Number(inspectedResult.summary?.gpa ?? 0).toFixed(2)}</td>
                      <td className="py-3 px-3 text-center">
                        {renderResultStatusBadge(inspectedResult.summary.resultStatus)}
                      </td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </div>

            {/* Audit Correction note if present */}
            {inspectedResult.correctionRequested && inspectedResult.correctionReason && (
              <Alert variant="danger" className="bg-rose-950/40 border-rose-500/30 text-rose-200">
                <p className="font-semibold text-xs text-rose-300">Correction Reason Logged:</p>
                <p className="text-xs mt-1">{inspectedResult.correctionReason}</p>
                {inspectedResult.correctionRequestedByName && (
                  <p className="text-[10px] text-rose-400 mt-1">
                    Requested by {inspectedResult.correctionRequestedByName} on{' '}
                    {inspectedResult.correctionRequestedAt ? new Date(inspectedResult.correctionRequestedAt).toLocaleString() : ''}
                  </p>
                )}
              </Alert>
            )}

            {/* Status Transition History Trail Summary */}
            {((inspectedResult?.statusHistory?.length || 0) > 0) && (
              <div className="p-3.5 rounded-xl bg-slate-950/40 border border-white/5">
                <h5 className="text-xs font-bold text-slate-300 mb-2 flex items-center gap-1.5">
                  <History className="w-3.5 h-3.5 text-indigo-400" />
                  Audit Trail ({inspectedResult?.statusHistory?.length || 0} status events recorded)
                </h5>
                <div className="space-y-2">
                  {(inspectedResult.statusHistory || []).slice(-3).map((item) => (
                    <div key={item.id} className="flex items-start justify-between text-[11px] border-b border-white/5 pb-1.5 last:border-0 last:pb-0">
                      <div>
                        <span className="font-medium text-white">{item.fromStatus}</span> →{' '}
                        <span className="font-semibold text-indigo-300">{item.toStatus}</span>
                        {item.reason && <p className="text-slate-400 mt-0.5 italic">"{item.reason}"</p>}
                      </div>
                      <div className="text-right text-slate-500 text-[10px]">
                        <p>{item.changedByUserName} ({item.changedByUserRole})</p>
                        <p>{new Date(item.timestamp).toLocaleString()}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Action Buttons inside inspector */}
            <div className="flex items-center justify-between pt-4 border-t border-white/10">
              <div className="flex items-center gap-2">
                {inspectedResult.workflowStatus !== 'PUBLISHED' && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setIsInspectModalOpen(false);
                      openCorrectionModal([inspectedResult.id]);
                    }}
                    className="border-rose-500/30 text-rose-300 hover:bg-rose-950/40 text-xs"
                  >
                    <Undo2 className="w-3.5 h-3.5 mr-1" />
                    Return for Correction
                  </Button>
                )}

                {(inspectedResult.workflowStatus === 'CALCULATED' || inspectedResult.workflowStatus === 'UNDER_REVIEW') && (
                  <Button
                    variant="primary"
                    size="sm"
                    onClick={() => {
                      setIsInspectModalOpen(false);
                      openSingleStatusChange(inspectedResult, 'APPROVED');
                    }}
                    className="bg-emerald-600 hover:bg-emerald-500 text-white text-xs shadow"
                  >
                    <ShieldCheck className="w-3.5 h-3.5 mr-1" />
                    Approve Result
                  </Button>
                )}

                {inspectedResult.workflowStatus === 'APPROVED' && (
                  <Button
                    variant="primary"
                    size="sm"
                    onClick={() => {
                      setIsInspectModalOpen(false);
                      openPublishModal([inspectedResult.id]);
                    }}
                    className="bg-indigo-600 hover:bg-indigo-500 text-white text-xs shadow"
                  >
                    <Send className="w-3.5 h-3.5 mr-1" />
                    Publish to Portals
                  </Button>
                )}
              </div>

              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsInspectModalOpen(false)}
                className="border-white/10 text-slate-300 hover:bg-slate-800 text-xs"
              >
                Close
              </Button>
            </div>
          </div>
        </Modal>
      )}

      {/* ========================================================================= */}
      {/* MODAL 2: FULL STATUS AUDIT TRAIL */}
      {/* ========================================================================= */}
      {isHistoryModalOpen && inspectedResult && (
        <Modal
          isOpen={isHistoryModalOpen}
          onClose={() => setIsHistoryModalOpen(false)}
          title={`Status Audit Trail: ${inspectedResult.studentName}`}
          className="max-w-2xl bg-slate-900 border-white/10 text-white"
        >
          <div className="space-y-4">
            <p className="text-xs text-slate-400">
              Immutable institutional record of all status transitions, administrative approvals, returned corrections, and portal publication actions.
            </p>

            <div className="space-y-3 max-h-96 overflow-y-auto pr-1">
              {(inspectedResult.statusHistory || []).map((history, idx) => (
                <div
                  key={history.id || idx}
                  className="p-3 rounded-xl bg-slate-950/60 border border-white/10 space-y-1.5"
                >
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-slate-400">{history.fromStatus}</span>
                      <ChevronRight className="w-3.5 h-3.5 text-slate-500" />
                      <span className="font-bold text-indigo-300">{history.toStatus}</span>
                    </div>
                    <span className="text-[10px] text-slate-500">
                      {new Date(history.timestamp).toLocaleString()}
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-white/5">
                    <span>
                      Changed By: <span className="text-white font-medium">{history.changedByUserName}</span> ({history.changedByUserRole})
                    </span>
                  </div>

                  {history.reason && (
                    <div className="p-2 rounded-lg bg-rose-950/30 border border-rose-500/20 text-rose-200 text-xs mt-1">
                      <span className="font-semibold text-rose-300">Reason: </span>
                      {history.reason}
                    </div>
                  )}

                  {history.notes && (
                    <p className="text-[11px] text-slate-400 italic">
                      Notes: {history.notes}
                    </p>
                  )}
                </div>
              ))}
            </div>

            <div className="flex justify-end pt-3 border-t border-white/10">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsHistoryModalOpen(false)}
                className="border-white/10 text-slate-300 hover:bg-slate-800 text-xs"
              >
                Close Trail
              </Button>
            </div>
          </div>
        </Modal>
      )}

      {/* ========================================================================= */}
      {/* MODAL 3: SINGLE STATUS TRANSITION CONFIRMATION */}
      {/* ========================================================================= */}
      {isStatusChangeModalOpen && targetSingleResult && (
        <Modal
          isOpen={isStatusChangeModalOpen}
          onClose={() => setIsStatusChangeModalOpen(false)}
          title={`Confirm Status Transition: ${targetNextStatus}`}
          className="max-w-md bg-slate-900 border-white/10 text-white"
        >
          <div className="space-y-4">
            <p className="text-xs text-slate-400">
              Transition student result for <strong className="text-white">{targetSingleResult.studentName}</strong> ({targetSingleResult.admissionNumber}) from{' '}
              <span className="text-indigo-400 font-semibold">{targetSingleResult.workflowStatus || 'CALCULATED'}</span> to{' '}
              <span className="text-emerald-400 font-bold">{targetNextStatus}</span>.
            </p>

            {targetNextStatus === 'APPROVED' && (
              <Alert variant="info" className="bg-emerald-950/40 border-emerald-500/30 text-emerald-200 text-xs">
                <ShieldCheck className="w-4 h-4 mr-1 text-emerald-400 shrink-0 inline" />
                Approving this result will lock it against further grade modifications by teachers. It can then be published to student and parent portals.
              </Alert>
            )}

            {targetNextStatus === 'CORRECTION_REQUIRED' && (
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Correction Reason (Mandatory)*
                </label>
                <textarea
                  rows={3}
                  value={statusChangeReason}
                  onChange={(e) => setStatusChangeReason(e.target.value)}
                  placeholder="Explain clearly what discrepancy or mark correction is required..."
                  className="w-full rounded-xl bg-slate-800 border border-white/10 text-white text-xs p-2.5 focus:border-indigo-500 focus:outline-none"
                />
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Internal Audit Notes (Optional)
              </label>
              <Input
                value={statusChangeNotes}
                onChange={(e) => setStatusChangeNotes(e.target.value)}
                placeholder="Optional notes for institutional record"
                className="bg-slate-800 border-white/10 text-xs"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-white/10">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsStatusChangeModalOpen(false)}
                disabled={isSubmitting}
                className="border-white/10 text-slate-300 hover:bg-slate-800 text-xs"
              >
                Cancel
              </Button>
              <Button
                variant="primary"
                size="sm"
                onClick={handleExecuteSingleStatusChange}
                disabled={isSubmitting}
                className="bg-indigo-600 hover:bg-indigo-500 text-white text-xs"
              >
                {isSubmitting ? <LoadingSpinner size="sm" className="mr-1" /> : <Check className="w-3.5 h-3.5 mr-1" />}
                Confirm Transition
              </Button>
            </div>
          </div>
        </Modal>
      )}

      {/* ========================================================================= */}
      {/* MODAL 4: RETURN FOR CORRECTION MODAL */}
      {/* ========================================================================= */}
      {isCorrectionModalOpen && (
        <Modal
          isOpen={isCorrectionModalOpen}
          onClose={() => setIsCorrectionModalOpen(false)}
          title={`Return ${correctionTargetIds.length} Result(s) for Correction`}
          className="max-w-lg bg-slate-900 border-white/10 text-white"
        >
          <div className="space-y-4">
            <p className="text-xs text-slate-400">
              Returning results sets status to <span className="text-rose-400 font-semibold">CORRECTION_REQUIRED</span> and unblocks subject teachers to re-open and revise their mark submissions.
            </p>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Specific Reason for Return (Mandatory, min 5 chars)*
              </label>
              <textarea
                rows={4}
                value={correctionReason}
                onChange={(e) => setCorrectionReason(e.target.value)}
                placeholder="e.g. Mathematics practical component marks mismatch with physical attendance sheet. Please re-verify student marksheet..."
                className="w-full rounded-xl bg-slate-800 border border-white/10 text-white text-xs p-3 focus:border-rose-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Additional Notes
              </label>
              <Input
                value={correctionNotes}
                onChange={(e) => setCorrectionNotes(e.target.value)}
                placeholder="Optional follow-up notes or deadline"
                className="bg-slate-800 border-white/10 text-xs"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-white/10">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsCorrectionModalOpen(false)}
                disabled={isSubmitting}
                className="border-white/10 text-slate-300 hover:bg-slate-800 text-xs"
              >
                Cancel
              </Button>
              <Button
                variant="primary"
                size="sm"
                onClick={handleExecuteReturnCorrection}
                disabled={isSubmitting || correctionReason.trim().length < 5}
                className="bg-rose-600 hover:bg-rose-500 text-white text-xs shadow"
              >
                {isSubmitting ? <LoadingSpinner size="sm" className="mr-1" /> : <Undo2 className="w-3.5 h-3.5 mr-1" />}
                Return for Correction
              </Button>
            </div>
          </div>
        </Modal>
      )}

      {/* ========================================================================= */}
      {/* MODAL 5: RESULT PUBLISHING DIALOG */}
      {/* ========================================================================= */}
      {isPublishModalOpen && (
        <Modal
          isOpen={isPublishModalOpen}
          onClose={() => setIsPublishModalOpen(false)}
          title="Official Examination Result Publishing"
          className="max-w-lg bg-slate-900 border-white/10 text-white"
        >
          <div className="space-y-4">
            <p className="text-xs text-slate-400">
              Publishing examination results makes marks, grades, GPAs, and subject performance official and immediately visible in the <strong className="text-white">Student Portal</strong> and <strong className="text-white">Parent / Guardian Portal</strong>.
            </p>

            <Alert variant="warning" className="bg-amber-950/40 border-amber-500/30 text-amber-200 text-xs">
              <Lock className="w-4 h-4 mr-1 text-amber-400 shrink-0 inline" />
              <strong>Institutional Policy Enforcement:</strong> Only examination results with status <span className="font-bold text-white">APPROVED</span> can be published. Any results still in Draft, Calculated, Under Review, or Correction Required will be strictly prevented from premature publication.
            </Alert>

            {publishTargetIds.length > 0 ? (
              <div className="p-3 rounded-xl bg-slate-950/60 border border-white/5 space-y-1">
                <p className="text-xs font-semibold text-white">Selected Results Scope:</p>
                <p className="text-xs text-slate-400">
                  Total Target: <span className="text-white font-bold">{publishTargetIds.length}</span> students
                </p>
              </div>
            ) : (
              <div className="p-3 rounded-xl bg-slate-950/60 border border-white/5 space-y-1">
                <p className="text-xs font-semibold text-white">Target Scope (Active Filters):</p>
                <p className="text-xs text-slate-400">
                  Exam: <span className="text-indigo-300 font-medium">{filterExam !== 'ALL' ? filterExam : 'All Matching Filter'}</span> • Class: <span className="text-indigo-300 font-medium">{filterClass !== 'ALL' ? filterClass : 'All Classes'}</span>
                </p>
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Official Publication Date*
              </label>
              <Input
                type="date"
                value={publishDate}
                onChange={(e) => setPublishDate(e.target.value)}
                className="bg-slate-800 border-white/10 text-xs"
              />
            </div>

            <div className="flex items-center gap-2 pt-2">
              <input
                type="checkbox"
                id="check-notify-portals"
                checked={notifyPortals}
                onChange={(e) => setNotifyPortals(e.target.checked)}
                className="rounded border-slate-700 bg-slate-900 text-indigo-600 focus:ring-indigo-500 w-4 h-4 cursor-pointer"
              />
              <label htmlFor="check-notify-portals" className="text-xs font-medium text-slate-200 cursor-pointer">
                Send automated in-app result announcements to enrolled students & linked guardians
              </label>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-white/10">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsPublishModalOpen(false)}
                disabled={isSubmitting}
                className="border-white/10 text-slate-300 hover:bg-slate-800 text-xs"
              >
                Cancel
              </Button>
              <Button
                variant="primary"
                size="sm"
                onClick={handleExecutePublish}
                disabled={isSubmitting}
                className="bg-emerald-600 hover:bg-emerald-500 text-white text-xs shadow-lg shadow-emerald-600/30"
              >
                {isSubmitting ? <LoadingSpinner size="sm" className="mr-1" /> : <Send className="w-3.5 h-3.5 mr-1" />}
                Publish Approved Results
              </Button>
            </div>
          </div>
        </Modal>
      )}

      {/* ========================================================================= */}
      {/* MODAL 6: SUPER ADMIN REOPEN / UNPUBLISH */}
      {/* ========================================================================= */}
      {isReopenModalOpen && (
        <Modal
          isOpen={isReopenModalOpen}
          onClose={() => setIsReopenModalOpen(false)}
          title="Super Admin: Unlock & Reopen Published Results"
          className="max-w-lg bg-slate-900 border-white/10 text-white"
        >
          <div className="space-y-4">
            <Alert variant="danger" className="bg-rose-950/40 border-rose-500/30 text-rose-200 text-xs">
              <AlertTriangle className="w-4 h-4 mr-1 text-rose-400 shrink-0 inline" />
              <strong>Warning:</strong> Reopening published results will unpublish them from the Student & Guardian portals and transition them back to <span className="font-bold text-white">UNDER_REVIEW</span> for critical administrative corrections.
            </Alert>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Audit Reason for Reopening (Mandatory)*
              </label>
              <textarea
                rows={3}
                value={reopenReason}
                onChange={(e) => setReopenReason(e.target.value)}
                placeholder="Institutional justification for unpublishing official results..."
                className="w-full rounded-xl bg-slate-800 border border-white/10 text-white text-xs p-3 focus:border-rose-500 focus:outline-none"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-white/10">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsReopenModalOpen(false)}
                disabled={isSubmitting}
                className="border-white/10 text-slate-300 hover:bg-slate-800 text-xs"
              >
                Cancel
              </Button>
              <Button
                variant="primary"
                size="sm"
                onClick={handleExecuteReopen}
                disabled={isSubmitting || reopenReason.trim().length < 5}
                className="bg-rose-600 hover:bg-rose-500 text-white text-xs shadow"
              >
                {isSubmitting ? <LoadingSpinner size="sm" className="mr-1" /> : <Unlock className="w-3.5 h-3.5 mr-1" />}
                Confirm Reopen & Unlock
              </Button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
