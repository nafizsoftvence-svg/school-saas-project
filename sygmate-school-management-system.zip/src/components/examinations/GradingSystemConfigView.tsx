import React, { useEffect, useState } from 'react';
import {
  GraduationCap,
  Plus,
  Edit2,
  Trash2,
  RotateCcw,
  CheckCircle2,
  XCircle,
  AlertCircle,
  AlertTriangle,
  HelpCircle,
  Sparkles,
  Save,
  Check,
  X
} from 'lucide-react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '../ui/Card.js';
import { Button } from '../ui/Button.js';
import { Badge } from '../ui/Badge.js';
import { Alert } from '../ui/Alert.js';
import { Modal } from '../ui/Modal.js';
import { Input } from '../ui/Input.js';
import { LoadingSpinner } from '../ui/LoadingSpinner.js';
import { EmptyState } from '../ui/EmptyState.js';
import { useToast } from '../../context/ToastContext.js';
import { api } from '../../services/api.js';
import { GradingScaleItem } from '../../types/index.js';

export const GradingSystemConfigView: React.FC = () => {
  const { addToast } = useToast();

  const [gradingScale, setGradingScale] = useState<GradingScaleItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // Modal states
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [modalMode, setModalMode] = useState<'create' | 'edit'>('create');
  const [editingGradeName, setEditingGradeName] = useState<string | null>(null);

  // Delete modal
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState<boolean>(false);
  const [deletingRule, setDeletingRule] = useState<GradingScaleItem | null>(null);

  // Reset confirmation modal
  const [isResetModalOpen, setIsResetModalOpen] = useState<boolean>(false);

  // Form data
  const [formData, setFormData] = useState<{
    grade: string;
    minPercentage: string;
    maxPercentage: string;
    gradePoint: string;
    description: string;
    isPassing: boolean;
  }>({
    grade: '',
    minPercentage: '',
    maxPercentage: '',
    gradePoint: '',
    description: '',
    isPassing: true
  });
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});

  // Fetch scale from backend
  const loadGradingScale = async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await api.examinations.getGradingScale();
      if (res.success && res.data) {
        setGradingScale(res.data);
      } else {
        setError(res.error || 'Failed to load grading scale.');
      }
    } catch (err: any) {
      setError(err?.message || 'Server error loading grading scale.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadGradingScale();
  }, []);

  // Open Create Modal
  const handleOpenCreateModal = () => {
    setModalMode('create');
    setEditingGradeName(null);
    setFormData({
      grade: '',
      minPercentage: '',
      maxPercentage: '',
      gradePoint: '',
      description: '',
      isPassing: true
    });
    setFormErrors({});
    setIsModalOpen(true);
  };

  // Open Edit Modal
  const handleOpenEditModal = (rule: GradingScaleItem) => {
    setModalMode('edit');
    setEditingGradeName(rule.grade);
    setFormData({
      grade: rule.grade,
      minPercentage: rule.minPercentage.toString(),
      maxPercentage: rule.maxPercentage.toString(),
      gradePoint: rule.gradePoint.toString(),
      description: rule.description || '',
      isPassing: rule.isPassing !== false
    });
    setFormErrors({});
    setIsModalOpen(true);
  };

  // Validate form client-side
  const validateForm = (): boolean => {
    const errors: Record<string, string> = {};

    if (!formData.grade.trim()) {
      errors.grade = 'Grade name is required (e.g. A+, A, B, etc).';
    }

    const min = parseFloat(formData.minPercentage);
    const max = parseFloat(formData.maxPercentage);
    const gp = parseFloat(formData.gradePoint);

    if (isNaN(min) || min < 0 || min > 100) {
      errors.minPercentage = 'Min % must be a number between 0 and 100.';
    }

    if (isNaN(max) || max < 0 || max > 100) {
      errors.maxPercentage = 'Max % must be a number between 0 and 100.';
    }

    if (!isNaN(min) && !isNaN(max) && min > max) {
      errors.minPercentage = `Min % (${min}%) cannot exceed Max % (${max}%).`;
    }

    if (isNaN(gp) || gp < 0) {
      errors.gradePoint = 'Grade point must be a non-negative number.';
    }

    // Check for client-side overlapping
    if (!isNaN(min) && !isNaN(max)) {
      const otherRules = gradingScale.filter(
        (r) => modalMode === 'create' || r.grade.toUpperCase() !== (editingGradeName || '').toUpperCase()
      );
      for (const rule of otherRules) {
        if (min <= rule.maxPercentage && max >= rule.minPercentage) {
          errors.minPercentage = `Range overlaps with grade ${rule.grade} (${rule.minPercentage}%–${rule.maxPercentage}%).`;
          break;
        }
      }
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  // Handle Save
  const handleSaveRule = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    try {
      setIsSubmitting(true);
      const payload: Partial<GradingScaleItem> = {
        grade: formData.grade.trim().toUpperCase(),
        minPercentage: parseFloat(formData.minPercentage),
        maxPercentage: parseFloat(formData.maxPercentage),
        gradePoint: parseFloat(formData.gradePoint),
        description: formData.description.trim(),
        isPassing: formData.isPassing
      };

      if (modalMode === 'create') {
        const res = await api.examinations.createGradeRule(payload);
        if (res.success && res.data) {
          addToast(`Grade rule "${payload.grade}" created successfully!`, 'success');
          setGradingScale(res.data);
          setIsModalOpen(false);
        } else {
          addToast(res.error || 'Failed to create grade rule.', 'error');
        }
      } else if (editingGradeName) {
        const res = await api.examinations.updateGradeRule(editingGradeName, payload);
        if (res.success && res.data) {
          addToast(`Grade rule "${payload.grade}" updated successfully!`, 'success');
          setGradingScale(res.data);
          setIsModalOpen(false);
        } else {
          addToast(res.error || 'Failed to update grade rule.', 'error');
        }
      }
    } catch (err: any) {
      addToast(err?.message || 'Server error saving grade rule.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle Delete
  const handleDeleteRule = async () => {
    if (!deletingRule) return;

    try {
      setIsSubmitting(true);
      const res = await api.examinations.deleteGradeRule(deletingRule.grade);
      if (res.success && res.data) {
        addToast(`Grade rule "${deletingRule.grade}" deleted.`, 'info');
        setGradingScale(res.data);
        setIsDeleteModalOpen(false);
        setDeletingRule(null);
      } else {
        addToast(res.error || 'Failed to delete grade rule.', 'error');
      }
    } catch (err: any) {
      addToast(err?.message || 'Server error deleting grade rule.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle Reset to Default
  const handleResetToDefault = async () => {
    try {
      setIsSubmitting(true);
      const res = await api.examinations.resetDefaultGradingScale();
      if (res.success && res.data) {
        addToast('Grading scale has been reset to institutional default (4.0 GPA).', 'success');
        setGradingScale(res.data);
        setIsResetModalOpen(false);
      } else {
        addToast(res.error || 'Failed to reset grading scale.', 'error');
      }
    } catch (err: any) {
      addToast(err?.message || 'Server error resetting scale.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in-50 duration-200">
      {/* Header & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900/60 p-6 rounded-2xl border border-white/10 backdrop-blur-md">
        <div className="space-y-1">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-500/10 border border-indigo-500/20 rounded-xl text-indigo-400">
              <GraduationCap className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white tracking-tight">
                Institutional Grading System & GPA Policy
              </h2>
              <p className="text-xs text-slate-400">
                Configure grade boundaries, quality point weights, pass/fail thresholds, and evaluation descriptions.
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3 flex-wrap">
          <Button
            id="btn-reset-grading-scale"
            variant="outline"
            size="sm"
            onClick={() => setIsResetModalOpen(true)}
            className="border-white/10 text-slate-300 hover:bg-slate-800"
          >
            <RotateCcw className="w-4 h-4 mr-2 text-amber-400" />
            Reset to Default
          </Button>

          <Button
            id="btn-add-grade-rule"
            variant="primary"
            size="sm"
            onClick={handleOpenCreateModal}
            className="bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-600/30"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Grade Rule
          </Button>
        </div>
      </div>

      {/* Policy Information Banner */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-slate-900/40 border-white/10">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs text-slate-400">Active Grade Tiers</div>
              <div className="text-lg font-bold text-white">{gradingScale.length} Defined Rules</div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-900/40 border-white/10">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-sky-500/10 text-sky-400">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs text-slate-400">Max Grade Point</div>
              <div className="text-lg font-bold text-white">
                {gradingScale.length > 0 ? Math.max(...gradingScale.map((g) => g.gradePoint)).toFixed(1) : '4.0'} GPA
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-900/40 border-white/10">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-indigo-500/10 text-indigo-400">
              <HelpCircle className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs text-slate-400">Passing Minimum</div>
              <div className="text-lg font-bold text-white">
                {(() => {
                  const passing = gradingScale.filter((g) => g.isPassing);
                  if (passing.length === 0) return '0%';
                  const minPass = Math.min(...passing.map((g) => g.minPercentage));
                  return `${minPass}%`;
                })()}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Error state */}
      {error && (
        <Alert variant="destructive" title="Error Loading Scale">
          {error}
        </Alert>
      )}

      {/* Scale Table */}
      <Card className="bg-slate-900/40 border-white/10 overflow-hidden">
        <CardHeader className="border-b border-white/10 pb-4">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-lg font-bold text-white">Grading Scale Rules</CardTitle>
              <CardDescription className="text-xs text-slate-400">
                Evaluation criteria mapped automatically during marksheet and GPA result calculation
              </CardDescription>
            </div>
            <span className="text-xs px-2.5 py-1 rounded-full bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 font-medium">
              Priority Sorted (High to Low)
            </span>
          </div>
        </CardHeader>

        <CardContent className="p-0">
          {loading ? (
            <div className="py-16 flex flex-col items-center justify-center space-y-3">
              <LoadingSpinner size="lg" />
              <p className="text-xs text-slate-400">Loading grading rules...</p>
            </div>
          ) : gradingScale.length === 0 ? (
            <EmptyState
              icon={<GraduationCap className="w-10 h-10 text-slate-500" />}
              title="No Grading Rules Defined"
              description="Click Add Grade Rule or Reset to Default to populate the institutional grading scale."
              actionLabel="Reset to Default Scale"
              onAction={() => setIsResetModalOpen(true)}
            />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-white/10 bg-slate-950/50 text-xs font-semibold text-slate-400 uppercase tracking-wider">
                    <th className="py-3.5 px-4">#</th>
                    <th className="py-3.5 px-4">Grade</th>
                    <th className="py-3.5 px-4">Percentage Range</th>
                    <th className="py-3.5 px-4">Grade Point (GP)</th>
                    <th className="py-3.5 px-4">Pass / Fail Status</th>
                    <th className="py-3.5 px-4">Evaluation Remarks</th>
                    <th className="py-3.5 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5 text-sm text-slate-300">
                  {(gradingScale || []).map((rule, idx) => (
                    <tr
                      key={rule.grade}
                      className="hover:bg-white/[0.02] transition-colors group"
                    >
                      <td className="py-3 px-4 text-xs font-mono text-slate-500">
                        {idx + 1}
                      </td>
                      <td className="py-3 px-4">
                        <span className={`inline-flex items-center justify-center font-bold px-2.5 py-1 rounded-lg text-sm ${
                          rule.grade.startsWith('A')
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                            : rule.grade.startsWith('B')
                            ? 'bg-sky-500/20 text-sky-300 border border-sky-500/30'
                            : rule.grade.startsWith('C')
                            ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                            : rule.grade.startsWith('D')
                            ? 'bg-orange-500/20 text-orange-300 border border-orange-500/30'
                            : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                        }`}>
                          {rule.grade}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-mono text-xs text-white">
                          {rule.minPercentage}% — {rule.maxPercentage}%
                        </div>
                        <div className="w-32 bg-slate-800 h-1.5 rounded-full overflow-hidden mt-1.5">
                          <div
                            className={`h-full rounded-full ${
                              rule.isPassing ? 'bg-indigo-500' : 'bg-rose-500'
                            }`}
                            style={{
                              marginLeft: `${rule.minPercentage}%`,
                              width: `${Math.max(4, rule.maxPercentage - rule.minPercentage)}%`
                            }}
                          />
                        </div>
                      </td>
                      <td className="py-3 px-4 font-mono font-bold text-white">
                        {rule.gradePoint.toFixed(2)}
                      </td>
                      <td className="py-3 px-4">
                        {rule.isPassing ? (
                          <Badge variant="success" className="bg-emerald-500/20 text-emerald-300 border-emerald-500/30 flex items-center gap-1 w-fit">
                            <CheckCircle2 className="w-3 h-3" />
                            <span>PASS</span>
                          </Badge>
                        ) : (
                          <Badge variant="destructive" className="bg-rose-500/20 text-rose-300 border-rose-500/30 flex items-center gap-1 w-fit">
                            <XCircle className="w-3 h-3" />
                            <span>FAIL</span>
                          </Badge>
                        )}
                      </td>
                      <td className="py-3 px-4 text-xs text-slate-400 max-w-xs truncate">
                        {rule.description || '—'}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <Button
                            id={`btn-edit-grade-${rule.grade}`}
                            variant="ghost"
                            size="sm"
                            onClick={() => handleOpenEditModal(rule)}
                            className="text-slate-400 hover:text-white hover:bg-slate-800 p-1.5 h-8 w-8"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </Button>
                          <Button
                            id={`btn-delete-grade-${rule.grade}`}
                            variant="ghost"
                            size="sm"
                            onClick={() => {
                              setDeletingRule(rule);
                              setIsDeleteModalOpen(true);
                            }}
                            className="text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 p-1.5 h-8 w-8"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Modal: Create / Edit Rule */}
      <Modal
        id="modal-grade-rule"
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        size="md"
        title={
          <div className="flex items-center gap-3 text-white">
            <div className="p-2 bg-indigo-500/20 rounded-xl text-indigo-400">
              <GraduationCap className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold">
                {modalMode === 'create' ? 'Add New Grade Rule' : `Edit Grade Rule "${editingGradeName}"`}
              </h3>
              <p className="text-xs text-slate-400">Set grade name, score boundaries, and quality point weight</p>
            </div>
          </div>
        }
      >
        <form onSubmit={handleSaveRule} className="p-6 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Grade Name <span className="text-rose-400">*</span>
              </label>
              <Input
                id="input-grade-name"
                placeholder="e.g. A+, A, B+, B"
                value={formData.grade}
                onChange={(e) => setFormData({ ...formData, grade: e.target.value })}
                error={formErrors.grade}
                disabled={isSubmitting}
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Grade Point (GP) <span className="text-rose-400">*</span>
              </label>
              <Input
                id="input-grade-point"
                type="number"
                step="0.01"
                min="0"
                max="10"
                placeholder="e.g. 4.0, 3.7, 3.0"
                value={formData.gradePoint}
                onChange={(e) => setFormData({ ...formData, gradePoint: e.target.value })}
                error={formErrors.gradePoint}
                disabled={isSubmitting}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Minimum Percentage (%) <span className="text-rose-400">*</span>
              </label>
              <Input
                id="input-min-percentage"
                type="number"
                step="0.01"
                min="0"
                max="100"
                placeholder="e.g. 80"
                value={formData.minPercentage}
                onChange={(e) => setFormData({ ...formData, minPercentage: e.target.value })}
                error={formErrors.minPercentage}
                disabled={isSubmitting}
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Maximum Percentage (%) <span className="text-rose-400">*</span>
              </label>
              <Input
                id="input-max-percentage"
                type="number"
                step="0.01"
                min="0"
                max="100"
                placeholder="e.g. 89.99 or 100"
                value={formData.maxPercentage}
                onChange={(e) => setFormData({ ...formData, maxPercentage: e.target.value })}
                error={formErrors.maxPercentage}
                disabled={isSubmitting}
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              Evaluation Description
            </label>
            <Input
              id="input-grade-description"
              placeholder="e.g. Excellent Performance, Satisfactory Pass"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              disabled={isSubmitting}
            />
          </div>

          <div className="pt-2">
            <label className="flex items-center gap-3 p-3 bg-slate-950/60 rounded-xl border border-white/10 cursor-pointer hover:bg-slate-900">
              <input
                id="checkbox-is-passing"
                type="checkbox"
                checked={formData.isPassing}
                onChange={(e) => setFormData({ ...formData, isPassing: e.target.checked })}
                className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 bg-slate-900 border-white/20"
                disabled={isSubmitting}
              />
              <div>
                <div className="text-sm font-semibold text-white">Qualifies as Passing Grade</div>
                <div className="text-xs text-slate-400">
                  When unchecked, students scoring within this bracket will be marked as FAILED in the subject.
                </div>
              </div>
            </label>
          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
            <Button
              type="button"
              variant="outline"
              onClick={() => setIsModalOpen(false)}
              disabled={isSubmitting}
              className="border-white/10 text-slate-300"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              variant="primary"
              disabled={isSubmitting}
              className="bg-indigo-600 hover:bg-indigo-500 text-white"
            >
              {isSubmitting ? <LoadingSpinner size="sm" /> : <Save className="w-4 h-4 mr-2" />}
              {modalMode === 'create' ? 'Create Grade Rule' : 'Save Changes'}
            </Button>
          </div>
        </form>
      </Modal>

      {/* Modal: Delete Confirmation */}
      <Modal
        id="modal-delete-grade-rule"
        isOpen={isDeleteModalOpen}
        onClose={() => setIsDeleteModalOpen(false)}
        size="sm"
        title={
          <div className="flex items-center gap-3 text-rose-400">
            <div className="p-2 bg-rose-500/20 rounded-xl">
              <Trash2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">Delete Grade Rule</h3>
              <p className="text-xs text-slate-400">Grading scale policy change</p>
            </div>
          </div>
        }
      >
        <div className="p-6 space-y-4">
          <p className="text-sm text-slate-300">
            Are you sure you want to remove Grade Rule{' '}
            <strong className="text-white font-semibold">"{deletingRule?.grade}"</strong> ({deletingRule?.minPercentage}%–{deletingRule?.maxPercentage}%)?
          </p>

          <Alert variant="warning" title="Recalculation Impact">
            Deleting this grade tier will cause future marks calculation in this range to fall back to adjacent rules.
          </Alert>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
            <Button
              type="button"
              variant="outline"
              onClick={() => setIsDeleteModalOpen(false)}
              disabled={isSubmitting}
              className="border-white/10 text-slate-300"
            >
              Cancel
            </Button>
            <Button
              type="button"
              variant="destructive"
              onClick={handleDeleteRule}
              disabled={isSubmitting}
              className="bg-rose-600 hover:bg-rose-500 text-white"
            >
              {isSubmitting ? <LoadingSpinner size="sm" /> : <Trash2 className="w-4 h-4 mr-2" />}
              Confirm Deletion
            </Button>
          </div>
        </div>
      </Modal>

      {/* Modal: Reset Confirmation */}
      <Modal
        id="modal-reset-grading-scale"
        isOpen={isResetModalOpen}
        onClose={() => setIsResetModalOpen(false)}
        size="sm"
        title={
          <div className="flex items-center gap-3 text-amber-400">
            <div className="p-2 bg-amber-500/20 rounded-xl">
              <RotateCcw className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">Reset to Institutional Default</h3>
              <p className="text-xs text-slate-400">Standard 4.0 GPA Grading Policy</p>
            </div>
          </div>
        }
      >
        <div className="p-6 space-y-4">
          <p className="text-sm text-slate-300">
            This will reset all custom grade rules to the standard 9-tier scale (A+ 90-100%, A 80-89%, B+ 75-79%, B 70-74%, B- 65-69%, C+ 60-64%, C 50-59%, D 40-49%, F 0-39%).
          </p>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
            <Button
              type="button"
              variant="outline"
              onClick={() => setIsResetModalOpen(false)}
              disabled={isSubmitting}
              className="border-white/10 text-slate-300"
            >
              Cancel
            </Button>
            <Button
              type="button"
              variant="primary"
              onClick={handleResetToDefault}
              disabled={isSubmitting}
              className="bg-amber-600 hover:bg-amber-500 text-white"
            >
              {isSubmitting ? <LoadingSpinner size="sm" /> : <RotateCcw className="w-4 h-4 mr-2" />}
              Confirm Reset
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
