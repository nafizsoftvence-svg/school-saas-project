import React, { useEffect, useState, useMemo } from 'react';
import {
  Calculator,
  RefreshCw,
  Search,
  Filter,
  CheckCircle2,
  XCircle,
  AlertCircle,
  AlertTriangle,
  Award,
  BookOpen,
  Users,
  ChevronRight,
  Sparkles,
  GraduationCap,
  Calendar,
  FileSpreadsheet,
  Download,
  Info,
  Clock,
  Layers,
  ArrowUpDown
} from 'lucide-react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '../ui/Card.js';
import { Button } from '../ui/Button.js';
import { Badge } from '../ui/Badge.js';
import { Alert } from '../ui/Alert.js';
import { Modal } from '../ui/Modal.js';
import { Input } from '../ui/Input.js';
import { Select } from '../ui/Select.js';
import { LoadingSpinner } from '../ui/LoadingSpinner.js';
import { EmptyState } from '../ui/EmptyState.js';
import { useToast } from '../../context/ToastContext.js';
import { api } from '../../services/api.js';
import {
  StudentExamResult,
  CalculationReadinessInfo,
  ResultCalculationSummaryStats,
  Examination,
  SchoolClass,
  AcademicSession
} from '../../types/index.js';

export const ResultCalculationView: React.FC = () => {
  const { addToast } = useToast();

  // Selection states
  const [selectedSessionId, setSelectedSessionId] = useState<string>('ALL');
  const [selectedExamId, setSelectedExamId] = useState<string>('');
  const [selectedClassId, setSelectedClassId] = useState<string>('ALL');
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Loaded metadata
  const [academicSessions, setAcademicSessions] = useState<AcademicSession[]>([]);
  const [examinations, setExaminations] = useState<Examination[]>([]);
  const [classes, setClasses] = useState<SchoolClass[]>([]);

  // Calculation Readiness & Status
  const [readinessInfo, setReadinessInfo] = useState<CalculationReadinessInfo | null>(null);
  const [loadingReadiness, setLoadingReadiness] = useState<boolean>(false);

  // Calculated Results state
  const [results, setResults] = useState<StudentExamResult[]>([]);
  const [stats, setStats] = useState<ResultCalculationSummaryStats | null>(null);
  const [loadingResults, setLoadingResults] = useState<boolean>(false);
  const [isCalculating, setIsCalculating] = useState<boolean>(false);

  // Calculation Confirmation Modal
  const [isConfirmCalculateOpen, setIsConfirmCalculateOpen] = useState<boolean>(false);
  const [forceRecalculate, setForceRecalculate] = useState<boolean>(false);

  // Detail Modal
  const [selectedResult, setSelectedResult] = useState<StudentExamResult | null>(null);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState<boolean>(false);

  // Load initial dropdowns
  useEffect(() => {
    const fetchInitialData = async () => {
      try {
        const [sessionsRes, examsRes, classesRes] = await Promise.all([
          api.academic.getSessions(),
          api.examinations.getExaminations({ includeArchived: false }),
          api.academic.getClasses()
        ]);

        if (sessionsRes.success && sessionsRes.data) {
          const sessArr: AcademicSession[] = Array.isArray(sessionsRes.data) ? sessionsRes.data : [];
          setAcademicSessions(sessArr);
          const activeSess = sessArr.find((s) => s.isCurrent);
          if (activeSess) setSelectedSessionId(activeSess.id);
        }

        if (classesRes.success && classesRes.data) {
          setClasses(classesRes.data);
        }

        if (examsRes.success && examsRes.data) {
          const examList: Examination[] = Array.isArray(examsRes.data) ? examsRes.data : (examsRes.data as any).data || [];
          setExaminations(examList);
          if (examList && examList.length > 0) {
            setSelectedExamId(examList?.[0]?.id || '');
          }
        }
      } catch (err: any) {
        console.error('Error fetching calculation view dependencies:', err);
      }
    };

    fetchInitialData();
  }, []);

  // Filter exams by selected session
  const filteredExams = useMemo(() => {
    if (selectedSessionId === 'ALL') return examinations;
    return examinations.filter((e) => e.academicSessionId === selectedSessionId);
  }, [examinations, selectedSessionId]);

  // Load readiness status whenever selectedExamId changes
  useEffect(() => {
    if (!selectedExamId) {
      setReadinessInfo(null);
      return;
    }

    const fetchReadiness = async () => {
      try {
        setLoadingReadiness(true);
        const res = await api.examinations.getCalculationStatus(selectedExamId);
        if (res.success && res.data) {
          setReadinessInfo(res.data);
        }
      } catch (err: any) {
        console.error('Error fetching readiness:', err);
      } finally {
        setLoadingReadiness(false);
      }
    };

    fetchReadiness();
  }, [selectedExamId]);

  // Fetch results list
  const loadResults = async () => {
    if (!selectedExamId) return;

    try {
      setLoadingResults(true);
      const res = await api.examinations.getResultsPreview({
        academicSessionId: selectedSessionId !== 'ALL' ? selectedSessionId : undefined,
        examId: selectedExamId,
        classId: selectedClassId !== 'ALL' ? selectedClassId : undefined,
        status: selectedStatus !== 'ALL' ? selectedStatus : undefined,
        search: searchQuery.trim() || undefined
      });

      if (res.success && res.data) {
        const items = Array.isArray(res.data) ? res.data : Array.isArray((res.data as any).data) ? (res.data as any).data : [];
        setResults(items);
        if ((res as any).stats) {
          setStats((res as any).stats);
        } else if ((res.data as any).stats) {
          setStats((res.data as any).stats);
        }
      }
    } catch (err: any) {
      console.error('Error loading results preview:', err);
    } finally {
      setLoadingResults(false);
    }
  };

  useEffect(() => {
    if (selectedExamId) {
      loadResults();
    }
  }, [selectedExamId, selectedSessionId, selectedClassId, selectedStatus, searchQuery]);

  // Trigger Calculation
  const handleExecuteCalculation = async () => {
    if (!selectedExamId) return;

    try {
      setIsCalculating(true);
      const res = await api.examinations.calculateResults({
        examId: selectedExamId,
        classId: selectedClassId !== 'ALL' ? selectedClassId : undefined,
        forceRecalculate
      });

      if (res.success && res.data) {
        addToast(res.message || 'Results and GPA calculated successfully!', 'success');
        setIsConfirmCalculateOpen(false);

        // Reload readiness & results preview
        const readinessRes = await api.examinations.getCalculationStatus(selectedExamId);
        if (readinessRes.success && readinessRes.data) {
          setReadinessInfo(readinessRes.data);
        }
        await loadResults();
      } else {
        addToast(res.error || 'Failed to calculate results.', 'error');
      }
    } catch (err: any) {
      addToast(err?.message || 'Server error calculating results.', 'error');
    } finally {
      setIsCalculating(false);
    }
  };

  // Open Marksheet Detail Modal
  const handleViewDetail = async (result: StudentExamResult) => {
    setSelectedResult(result);
    setIsDetailModalOpen(true);
  };

  const selectedExam = (examinations || []).find((e) => e.id === selectedExamId);

  return (
    <div className="space-y-6 animate-in fade-in-50 duration-200">
      {/* 1. Header & Filters */}
      <div className="bg-slate-900/60 p-6 rounded-2xl border border-white/10 backdrop-blur-md space-y-6">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-500/10 border border-indigo-500/20 rounded-xl text-indigo-400">
              <Calculator className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white tracking-tight">
                Grade, GPA & Result Calculation Engine
              </h2>
              <p className="text-xs text-slate-400">
                Compute obtained marks, percentage, quality points, GPA and passing status from approved marksheets.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 flex-wrap">
            <Button
              id="btn-refresh-calculation"
              variant="outline"
              size="sm"
              onClick={() => {
                if (selectedExamId) {
                  loadResults();
                }
              }}
              disabled={loadingResults || isCalculating}
              className="border-white/10 text-slate-300 hover:bg-slate-800"
            >
              <RefreshCw className={`w-4 h-4 mr-2 ${loadingResults ? 'animate-spin' : ''}`} />
              Refresh
            </Button>

            <Button
              id="btn-run-calculation"
              variant="primary"
              size="sm"
              onClick={() => setIsConfirmCalculateOpen(true)}
              disabled={!selectedExamId || isCalculating || (readinessInfo && readinessInfo.submittedSubjectsCount === 0)}
              className="bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-600/30"
            >
              {isCalculating ? <LoadingSpinner size="sm" /> : <Calculator className="w-4 h-4 mr-2" />}
              {readinessInfo && readinessInfo.calculatedResultsCount > 0 ? 'Recalculate Results' : 'Calculate Results & GPA'}
            </Button>
          </div>
        </div>

        {/* Selection bar */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-2 border-t border-white/5">
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              Academic Session
            </label>
            <Select
              id="select-calc-session"
              value={selectedSessionId}
              onChange={(e) => setSelectedSessionId(e.target.value)}
              className="bg-slate-950/60 border-white/10 text-sm"
            >
              <option value="ALL">All Academic Sessions</option>
              {(academicSessions || []).map((sess) => (
                <option key={sess.id} value={sess.id}>
                  {sess.name} {sess.isCurrent ? '(Current)' : ''}
                </option>
              ))}
            </Select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              Target Examination <span className="text-rose-400">*</span>
            </label>
            <Select
              id="select-calc-exam"
              value={selectedExamId}
              onChange={(e) => setSelectedExamId(e.target.value)}
              className="bg-slate-950/60 border-white/10 text-sm"
            >
              {filteredExams.length === 0 ? (
                <option value="">No examinations available</option>
              ) : (
                (filteredExams || []).map((exam) => (
                  <option key={exam.id} value={exam.id}>
                    {exam.name} ({exam.className || 'General'})
                  </option>
                ))
              )}
            </Select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              Class Cohort
            </label>
            <Select
              id="select-calc-class"
              value={selectedClassId}
              onChange={(e) => setSelectedClassId(e.target.value)}
              className="bg-slate-950/60 border-white/10 text-sm"
            >
              <option value="ALL">All Classes in Exam</option>
              {(classes || []).map((cls) => (
                <option key={cls.id} value={cls.id}>
                  {cls.name}
                </option>
              ))}
            </Select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              Result Status Filter
            </label>
            <Select
              id="select-calc-status"
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="bg-slate-950/60 border-white/10 text-sm"
            >
              <option value="ALL">All Result Statuses</option>
              <option value="PASSED">Passed Only</option>
              <option value="DISTINCTION">Distinction (≥85%)</option>
              <option value="FAILED">Failed Subjects</option>
            </Select>
          </div>
        </div>
      </div>

      {/* 2. Readiness Status Card */}
      {readinessInfo && (
        <Card className="bg-slate-900/40 border-white/10">
          <CardContent className="p-5">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="text-base font-bold text-white">Calculation Readiness Dossier: {readinessInfo.examName}</h3>
                  {readinessInfo.isReadyForCalculation ? (
                    <Badge variant="success" className="bg-emerald-500/20 text-emerald-300 border-emerald-500/30">
                      <CheckCircle2 className="w-3 h-3 mr-1 inline" /> Ready to Calculate
                    </Badge>
                  ) : (
                    <Badge variant="warning" className="bg-amber-500/20 text-amber-300 border-amber-500/30">
                      <AlertTriangle className="w-3 h-3 mr-1 inline" /> Marks Submissions Pending
                    </Badge>
                  )}
                </div>
                <p className="text-xs text-slate-400">
                  {readinessInfo.submittedSubjectsCount} of {readinessInfo.totalConfiguredSubjects} subjects submitted marks. {readinessInfo.totalEligibleStudents} eligible students in cohort.
                </p>
              </div>

              <div className="flex items-center gap-2 flex-wrap">
                <div className="px-3 py-1.5 bg-slate-950/60 rounded-xl border border-white/10 text-center">
                  <div className="text-[10px] uppercase font-semibold text-slate-400">Submitted</div>
                  <div className="text-sm font-bold text-emerald-400">{readinessInfo.submittedSubjectsCount}</div>
                </div>
                <div className="px-3 py-1.5 bg-slate-950/60 rounded-xl border border-white/10 text-center">
                  <div className="text-[10px] uppercase font-semibold text-slate-400">Draft / Returned</div>
                  <div className="text-sm font-bold text-amber-400">{readinessInfo.draftSubjectsCount}</div>
                </div>
                <div className="px-3 py-1.5 bg-slate-950/60 rounded-xl border border-white/10 text-center">
                  <div className="text-[10px] uppercase font-semibold text-slate-400">Unstarted</div>
                  <div className="text-sm font-bold text-rose-400">{readinessInfo.unstartedSubjectsCount}</div>
                </div>
                <div className="px-3 py-1.5 bg-indigo-500/10 rounded-xl border border-indigo-500/20 text-center">
                  <div className="text-[10px] uppercase font-semibold text-indigo-300">Calculated</div>
                  <div className="text-sm font-bold text-white">{readinessInfo.calculatedResultsCount} / {readinessInfo.totalEligibleStudents}</div>
                </div>
              </div>
            </div>

            {/* Pending Subjects Pill List */}
            {readinessInfo.pendingSubjects && readinessInfo.pendingSubjects.length > 0 && (
              <div className="mt-4 pt-4 border-t border-white/5">
                <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                  Subject Marks Submission Status:
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2">
                  {(readinessInfo.pendingSubjects || []).map((sub) => (
                    <div
                      key={sub.subjectId}
                      className="p-2.5 rounded-xl bg-slate-950/40 border border-white/5 flex items-center justify-between text-xs"
                    >
                      <div className="truncate pr-2">
                        <div className="font-semibold text-white truncate">{sub.subjectName}</div>
                        <div className="text-[10px] text-slate-400">{sub.teacherName}</div>
                      </div>
                      <span
                        className={`px-2 py-0.5 rounded-md font-semibold text-[10px] uppercase ${
                          sub.status === 'submitted' || sub.status === 'approved'
                            ? 'bg-emerald-500/20 text-emerald-300'
                            : sub.status === 'draft'
                            ? 'bg-amber-500/20 text-amber-300'
                            : 'bg-rose-500/20 text-rose-300'
                        }`}
                      >
                        {sub.status}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* 3. Summary Statistics Cards */}
      {stats && (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          <Card className="bg-slate-900/40 border-white/10">
            <CardContent className="p-4">
              <div className="text-xs text-slate-400">Total Evaluated</div>
              <div className="text-xl font-bold text-white mt-1">{stats.totalCalculated}</div>
              <div className="text-[10px] text-slate-500 mt-0.5">Students calculated</div>
            </CardContent>
          </Card>

          <Card className="bg-slate-900/40 border-white/10">
            <CardContent className="p-4">
              <div className="text-xs text-emerald-400">Passed Students</div>
              <div className="text-xl font-bold text-emerald-400 mt-1">{stats.passedCount}</div>
              <div className="text-[10px] text-slate-500 mt-0.5">
                {stats.totalCalculated > 0 ? `${((stats.passedCount / stats.totalCalculated) * 100).toFixed(0)}% pass rate` : '0%'}
              </div>
            </CardContent>
          </Card>

          <Card className="bg-slate-900/40 border-white/10">
            <CardContent className="p-4">
              <div className="text-xs text-sky-400">Distinctions</div>
              <div className="text-xl font-bold text-sky-400 mt-1">{stats.distinctionCount}</div>
              <div className="text-[10px] text-slate-500 mt-0.5">Score ≥ 85%</div>
            </CardContent>
          </Card>

          <Card className="bg-slate-900/40 border-white/10">
            <CardContent className="p-4">
              <div className="text-xs text-rose-400">Failed Records</div>
              <div className="text-xl font-bold text-rose-400 mt-1">{stats.failedCount}</div>
              <div className="text-[10px] text-slate-500 mt-0.5">1+ failed subjects</div>
            </CardContent>
          </Card>

          <Card className="bg-slate-900/40 border-white/10">
            <CardContent className="p-4">
              <div className="text-xs text-indigo-300">Average GPA</div>
              <div className="text-xl font-bold text-indigo-400 mt-1">{stats.averageGpa.toFixed(2)}</div>
              <div className="text-[10px] text-slate-500 mt-0.5">Scale 0.00 – 4.00</div>
            </CardContent>
          </Card>

          <Card className="bg-slate-900/40 border-white/10">
            <CardContent className="p-4">
              <div className="text-xs text-amber-300">Avg Percentage</div>
              <div className="text-xl font-bold text-amber-400 mt-1">{stats.averagePercentage.toFixed(1)}%</div>
              <div className="text-[10px] text-slate-500 mt-0.5">High: {stats.highestGpa.toFixed(2)} GP</div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* 4. Results Preview Table */}
      <Card className="bg-slate-900/40 border-white/10 overflow-hidden">
        <CardHeader className="border-b border-white/10 pb-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <CardTitle className="text-lg font-bold text-white">Student Results & Marksheet Preview</CardTitle>
              <CardDescription className="text-xs text-slate-400">
                Preliminary calculated results awaiting official administration sign-off & publishing
              </CardDescription>
            </div>

            <div className="w-full sm:w-64">
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <Input
                  id="input-search-results"
                  placeholder="Search student or roll #..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9 bg-slate-950/60 border-white/10 text-xs h-9"
                />
              </div>
            </div>
          </div>
        </CardHeader>

        <CardContent className="p-0">
          {loadingResults ? (
            <div className="py-16 flex flex-col items-center justify-center space-y-3">
              <LoadingSpinner size="lg" />
              <p className="text-xs text-slate-400">Loading calculated marks and GPAs...</p>
            </div>
          ) : results.length === 0 ? (
            <EmptyState
              icon={<Calculator className="w-10 h-10 text-slate-500" />}
              title="No Results Calculated Yet"
              description="Click 'Calculate Results & GPA' above to execute automatic evaluation of student marks."
              actionLabel={readinessInfo?.isReadyForCalculation ? 'Execute Calculation' : undefined}
              onAction={() => setIsConfirmCalculateOpen(true)}
            />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-white/10 bg-slate-950/50 text-xs font-semibold text-slate-400 uppercase tracking-wider">
                    <th className="py-3.5 px-4">Student</th>
                    <th className="py-3.5 px-4">Admission / Roll</th>
                    <th className="py-3.5 px-4">Class & Section</th>
                    <th className="py-3.5 px-4">Total Marks</th>
                    <th className="py-3.5 px-4">Percentage</th>
                    <th className="py-3.5 px-4">Grade</th>
                    <th className="py-3.5 px-4">GPA</th>
                    <th className="py-3.5 px-4">Subject Status</th>
                    <th className="py-3.5 px-4">Final Result</th>
                    <th className="py-3.5 px-4 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5 text-sm text-slate-300">
                  {(results || []).map((res) => (
                    <tr
                      key={res.id}
                      className="hover:bg-white/[0.02] transition-colors group cursor-pointer"
                      onClick={() => handleViewDetail(res)}
                    >
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 flex items-center justify-center font-bold text-xs uppercase overflow-hidden">
                            {res.avatarUrl ? (
                              <img src={res.avatarUrl} alt={res.studentName} className="w-full h-full object-cover" />
                            ) : (
                              res.studentName.slice(0, 2)
                            )}
                          </div>
                          <div>
                            <div className="font-semibold text-white">{res.studentName}</div>
                            {res.summary.isIncomplete && (
                              <span className="text-[10px] text-amber-400 flex items-center gap-0.5">
                                <AlertTriangle className="w-2.5 h-2.5" /> Marks Incomplete
                              </span>
                            )}
                          </div>
                        </div>
                      </td>

                      <td className="py-3 px-4 font-mono text-xs text-slate-400">
                        <div>{res.admissionNumber}</div>
                        <div className="text-[10px] text-slate-500">Roll: {res.rollNumber}</div>
                      </td>

                      <td className="py-3 px-4 text-xs text-slate-300">
                        <div>{res.className}</div>
                        <div className="text-[10px] text-slate-400">{res.sectionName}</div>
                      </td>

                      <td className="py-3 px-4 font-mono text-xs">
                        <span className="font-bold text-white">{res.summary.totalObtainedMarks}</span>
                        <span className="text-slate-500"> / {res.summary.totalFullMarks}</span>
                      </td>

                      <td className="py-3 px-4 font-mono text-xs font-semibold text-white">
                        {res.summary.overallPercentage.toFixed(1)}%
                      </td>

                      <td className="py-3 px-4">
                        <span className={`inline-flex items-center justify-center font-bold px-2 py-0.5 rounded-md text-xs ${
                          res.summary.overallGrade.startsWith('A')
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                            : res.summary.overallGrade.startsWith('B')
                            ? 'bg-sky-500/20 text-sky-300 border border-sky-500/30'
                            : res.summary.overallGrade.startsWith('C')
                            ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                            : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                        }`}>
                          {res.summary.overallGrade}
                        </span>
                      </td>

                      <td className="py-3 px-4 font-mono text-sm font-bold text-indigo-300">
                        {res.summary.gpa.toFixed(2)}
                      </td>

                      <td className="py-3 px-4 text-xs">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="text-emerald-400">{res.summary.passedSubjects} Pass</span>
                          {res.summary.failedSubjects > 0 && (
                            <span className="text-rose-400 font-semibold">• {res.summary.failedSubjects} Fail</span>
                          )}
                          {res.summary.absentSubjects > 0 && (
                            <span className="text-amber-400">• {res.summary.absentSubjects} Abs</span>
                          )}
                          {res.summary.exemptSubjects > 0 && (
                            <span className="text-purple-400">• {res.summary.exemptSubjects} Exm</span>
                          )}
                        </div>
                      </td>

                      <td className="py-3 px-4">
                        {res.summary.resultStatus === 'DISTINCTION' ? (
                          <Badge variant="success" className="bg-sky-500/20 text-sky-300 border-sky-500/30 flex items-center gap-1 w-fit">
                            <Sparkles className="w-3 h-3" />
                            <span>DISTINCTION</span>
                          </Badge>
                        ) : res.summary.resultStatus === 'PASSED' ? (
                          <Badge variant="success" className="bg-emerald-500/20 text-emerald-300 border-emerald-500/30 flex items-center gap-1 w-fit">
                            <CheckCircle2 className="w-3 h-3" />
                            <span>PASSED</span>
                          </Badge>
                        ) : (
                          <Badge variant="destructive" className="bg-rose-500/20 text-rose-300 border-rose-500/30 flex items-center gap-1 w-fit">
                            <XCircle className="w-3 h-3" />
                            <span>FAILED</span>
                          </Badge>
                        )}
                      </td>

                      <td className="py-3 px-4 text-right">
                        <Button
                          id={`btn-view-result-${res.id}`}
                          variant="outline"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleViewDetail(res);
                          }}
                          className="border-white/10 text-slate-300 hover:text-white hover:bg-slate-800 text-xs py-1 px-2.5 h-8"
                        >
                          Marksheet
                          <ChevronRight className="w-3.5 h-3.5 ml-1" />
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* 5. Modal: Calculation Confirmation */}
      <Modal
        id="modal-confirm-calculation"
        isOpen={isConfirmCalculateOpen}
        onClose={() => setIsConfirmCalculateOpen(false)}
        size="md"
        title={
          <div className="flex items-center gap-3 text-white">
            <div className="p-2 bg-indigo-500/20 rounded-xl text-indigo-400">
              <Calculator className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold">Calculate Results & GPA</h3>
              <p className="text-xs text-slate-400">{selectedExam?.name}</p>
            </div>
          </div>
        }
      >
        <div className="p-6 space-y-4">
          <p className="text-sm text-slate-300">
            This operation will evaluate all submitted marksheets for{' '}
            <strong className="text-white font-semibold">"{selectedExam?.name}"</strong>, compute percentage totals, apply grade boundaries from the institutional grading scale, and calculate credit-weighted GPAs for all enrolled students.
          </p>

          {readinessInfo && (readinessInfo.draftSubjectsCount > 0 || readinessInfo.unstartedSubjectsCount > 0) && (
            <Alert variant="warning" title="Incomplete Marks Warning">
              There are {readinessInfo.draftSubjectsCount + readinessInfo.unstartedSubjectsCount} subject(s) with pending or unsubmitted teacher marks. Students will receive pending status for those missing subjects.
            </Alert>
          )}

          <div className="pt-2">
            <label className="flex items-center gap-3 p-3 bg-slate-950/60 rounded-xl border border-white/10 cursor-pointer hover:bg-slate-900">
              <input
                id="checkbox-force-recalculate"
                type="checkbox"
                checked={forceRecalculate}
                onChange={(e) => setForceRecalculate(e.target.checked)}
                className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 bg-slate-900 border-white/20"
                disabled={isCalculating}
              />
              <div>
                <div className="text-sm font-semibold text-white">Force Complete Recalculation</div>
                <div className="text-xs text-slate-400">
                  Overwrite any previously generated provisional result records for this examination cycle.
                </div>
              </div>
            </label>
          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
            <Button
              type="button"
              variant="outline"
              onClick={() => setIsConfirmCalculateOpen(false)}
              disabled={isCalculating}
              className="border-white/10 text-slate-300"
            >
              Cancel
            </Button>
            <Button
              type="button"
              variant="primary"
              onClick={handleExecuteCalculation}
              disabled={isCalculating}
              className="bg-indigo-600 hover:bg-indigo-500 text-white"
            >
              {isCalculating ? <LoadingSpinner size="sm" /> : <Calculator className="w-4 h-4 mr-2" />}
              {isCalculating ? 'Computing GPAs...' : 'Start Calculation'}
            </Button>
          </div>
        </div>
      </Modal>

      {/* 6. Modal: Detailed Student Marksheet Breakdown */}
      <Modal
        id="modal-marksheet-detail"
        isOpen={isDetailModalOpen}
        onClose={() => setIsDetailModalOpen(false)}
        size="lg"
        title={
          <div className="flex items-center gap-3 text-white">
            <div className="p-2 bg-indigo-500/20 rounded-xl text-indigo-400">
              <GraduationCap className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold">Provisional Marksheet Breakdown</h3>
              <p className="text-xs text-slate-400">{selectedResult?.studentName} • {selectedResult?.examName}</p>
            </div>
          </div>
        }
      >
        {selectedResult && (
          <div className="p-6 space-y-6">
            {/* Student Card */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 bg-slate-950/60 rounded-xl border border-white/10 text-xs">
              <div>
                <div className="text-slate-400">Admission No:</div>
                <div className="font-semibold text-white font-mono">{selectedResult.admissionNumber}</div>
              </div>
              <div>
                <div className="text-slate-400">Roll Number:</div>
                <div className="font-semibold text-white font-mono">{selectedResult.rollNumber}</div>
              </div>
              <div>
                <div className="text-slate-400">Class & Section:</div>
                <div className="font-semibold text-white">{selectedResult.className} - {selectedResult.sectionName}</div>
              </div>
              <div>
                <div className="text-slate-400">Academic Session:</div>
                <div className="font-semibold text-white">{selectedResult.academicSessionName}</div>
              </div>
            </div>

            {/* Performance Summary Metrics */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3 bg-slate-950/40 rounded-xl border border-white/5 text-center">
                <div className="text-[10px] uppercase font-semibold text-slate-400">Total Marks</div>
                <div className="text-lg font-bold text-white mt-0.5">
                  {selectedResult.summary.totalObtainedMarks} <span className="text-xs text-slate-400">/ {selectedResult.summary.totalFullMarks}</span>
                </div>
              </div>

              <div className="p-3 bg-slate-950/40 rounded-xl border border-white/5 text-center">
                <div className="text-[10px] uppercase font-semibold text-slate-400">Overall Percentage</div>
                <div className="text-lg font-bold text-white mt-0.5">{selectedResult.summary.overallPercentage.toFixed(2)}%</div>
              </div>

              <div className="p-3 bg-slate-950/40 rounded-xl border border-white/5 text-center">
                <div className="text-[10px] uppercase font-semibold text-slate-400">Cumulative GPA</div>
                <div className="text-lg font-bold text-indigo-400 mt-0.5">{selectedResult.summary.gpa.toFixed(2)}</div>
              </div>

              <div className="p-3 bg-slate-950/40 rounded-xl border border-white/5 text-center">
                <div className="text-[10px] uppercase font-semibold text-slate-400">Evaluation Result</div>
                <div className="text-lg font-bold mt-0.5">
                  <span className={
                    selectedResult.summary.resultStatus === 'FAILED' ? 'text-rose-400' : 'text-emerald-400'
                  }>
                    {selectedResult.summary.resultStatus}
                  </span>
                </div>
              </div>
            </div>

            {/* Subject Scores Table */}
            <div>
              <h4 className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">Subject Performance Roster</h4>
              <div className="overflow-x-auto rounded-xl border border-white/10">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-950/80 border-b border-white/10 text-slate-400 uppercase font-semibold">
                      <th className="py-2.5 px-3">Subject</th>
                      <th className="py-2.5 px-3">Code</th>
                      <th className="py-2.5 px-3">Credits</th>
                      <th className="py-2.5 px-3">Full / Pass</th>
                      <th className="py-2.5 px-3">Obtained</th>
                      <th className="py-2.5 px-3">Percentage</th>
                      <th className="py-2.5 px-3">Grade</th>
                      <th className="py-2.5 px-3">GP</th>
                      <th className="py-2.5 px-3">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5 text-slate-300 bg-slate-900/40">
                    {(selectedResult.subjectScores || []).map((sub) => (
                      <tr key={sub.subjectId} className="hover:bg-white/[0.02]">
                        <td className="py-2.5 px-3 font-medium text-white">{sub.subjectName}</td>
                        <td className="py-2.5 px-3 font-mono text-slate-400">{sub.subjectCode}</td>
                        <td className="py-2.5 px-3 font-mono text-slate-400">{sub.credits}</td>
                        <td className="py-2.5 px-3 font-mono text-slate-400">{sub.fullMarks} / {sub.passMarks}</td>
                        <td className="py-2.5 px-3 font-mono font-bold text-white">{sub.obtainedMarks}</td>
                        <td className="py-2.5 px-3 font-mono">{sub.percentage.toFixed(1)}%</td>
                        <td className="py-2.5 px-3">
                          <span className={`px-1.5 py-0.5 rounded font-bold ${
                            sub.grade === 'EX'
                              ? 'bg-purple-500/20 text-purple-300'
                              : sub.grade === 'AB'
                              ? 'bg-amber-500/20 text-amber-300'
                              : sub.grade.startsWith('A')
                              ? 'bg-emerald-500/20 text-emerald-300'
                              : sub.grade.startsWith('B')
                              ? 'bg-sky-500/20 text-sky-300'
                              : sub.grade.startsWith('C')
                              ? 'bg-amber-500/20 text-amber-300'
                              : 'bg-rose-500/20 text-rose-300'
                          }`}>
                            {sub.grade}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 font-mono font-semibold">{sub.gradePoint.toFixed(2)}</td>
                        <td className="py-2.5 px-3">
                          {sub.isPassing ? (
                            <span className="text-emerald-400 font-semibold flex items-center gap-1">
                              <CheckCircle2 className="w-3 h-3" /> Pass
                            </span>
                          ) : (
                            <span className="text-rose-400 font-semibold flex items-center gap-1">
                              <XCircle className="w-3 h-3" /> Fail
                            </span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Progress Notes */}
            {selectedResult.academicProgressNotes && (
              <div className="p-3 bg-indigo-500/10 rounded-xl border border-indigo-500/20 text-xs text-indigo-300 flex items-start gap-2">
                <Info className="w-4 h-4 shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold">Calculation Dossier: </span>
                  {selectedResult.academicProgressNotes}
                </div>
              </div>
            )}

            <div className="flex items-center justify-end pt-4 border-t border-white/10">
              <Button
                type="button"
                variant="outline"
                onClick={() => setIsDetailModalOpen(false)}
                className="border-white/10 text-slate-300"
              >
                Close Preview
              </Button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};
