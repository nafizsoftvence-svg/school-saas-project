import React, { useEffect, useState, useCallback, useMemo } from 'react';
import {
  FileText,
  Printer,
  Eye,
  Download,
  Search,
  Filter,
  RefreshCw,
  Award,
  CheckCircle2,
  AlertCircle,
  AlertTriangle,
  GraduationCap,
  Sparkles,
  Users,
  ChevronRight,
  Layers,
  Calendar,
  CheckSquare,
  Square,
  FileSpreadsheet
} from 'lucide-react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '../ui/Card.js';
import { Button } from '../ui/Button.js';
import { Badge } from '../ui/Badge.js';
import { Alert } from '../ui/Alert.js';
import { Input } from '../ui/Input.js';
import { Select } from '../ui/Select.js';
import { LoadingSpinner } from '../ui/LoadingSpinner.js';
import { EmptyState } from '../ui/EmptyState.js';
import { useToast } from '../../context/ToastContext.js';
import { api } from '../../services/api.js';
import {
  StudentExamResult,
  ReportCardDetail,
  AcademicSession,
  SchoolClass,
  Section,
  Examination
} from '../../types/index.js';
import { ReportCardPrintModal } from './ReportCardPrintModal.js';

export const ReportCardsManagerView: React.FC = () => {
  const { addToast } = useToast();

  // Filters
  const [filterSession, setFilterSession] = useState<string>('ALL');
  const [filterExam, setFilterExam] = useState<string>('ALL');
  const [filterClass, setFilterClass] = useState<string>('ALL');
  const [filterSection, setFilterSection] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Data states
  const [results, setResults] = useState<StudentExamResult[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [refreshing, setRefreshing] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // Metadata dropdowns
  const [availableSessions, setAvailableSessions] = useState<Array<{ id: string; name: string }>>([]);
  const [availableExams, setAvailableExams] = useState<Array<{ id: string; name: string; type?: string; className?: string }>>([]);
  const [availableClasses, setAvailableClasses] = useState<Array<{ id: string; name: string }>>([]);
  const [availableSections, setAvailableSections] = useState<Array<{ id: string; name: string; classId?: string }>>([]);

  // Multi-selection for bulk operations
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  // Modal / Preview state
  const [previewResultId, setPreviewResultId] = useState<string | null>(null);
  const [previewReportCard, setPreviewReportCard] = useState<ReportCardDetail | null>(null);
  const [isLoadingDetail, setIsLoadingDetail] = useState<boolean>(false);

  // Bulk Print Dialog State
  const [isBulkPrintOpen, setIsBulkPrintOpen] = useState<boolean>(false);
  const [bulkReportCards, setBulkReportCards] = useState<ReportCardDetail[]>([]);
  const [loadingBulk, setLoadingBulk] = useState<boolean>(false);

  // Load Metadata
  const loadMetadata = useCallback(async () => {
    try {
      const [sessionsRes, examsRes, classesRes, sectionsRes] = await Promise.all([
        api.academic.getSessions(),
        api.examinations.getExaminations(),
        api.academic.getClasses(),
        api.academic.getSections()
      ]);

      if (sessionsRes.success && sessionsRes.data) {
        const raw = Array.isArray(sessionsRes.data) ? sessionsRes.data : (sessionsRes.data as any).data || [];
        const sessionList = raw.map((s: AcademicSession) => ({
          id: s.id,
          name: s.name || s.id
        }));
        setAvailableSessions(sessionList);
      }

      if (examsRes.success && examsRes.data) {
        const rawList = Array.isArray(examsRes.data) ? examsRes.data : (examsRes.data as any).data || [];
        const examList = rawList.map((e: Examination) => ({
          id: e.id,
          name: e.name,
          type: e.examType,
          className: e.className
        }));
        setAvailableExams(examList);
      }

      if (classesRes.success && classesRes.data) {
        const raw = Array.isArray(classesRes.data) ? classesRes.data : (classesRes.data as any).data || [];
        const classList = raw.map((c: SchoolClass) => ({
          id: c.id,
          name: c.name
        }));
        setAvailableClasses(classList);
      }

      if (sectionsRes.success && sectionsRes.data) {
        const raw = Array.isArray(sectionsRes.data) ? sectionsRes.data : (sectionsRes.data as any).data || [];
        const secList = raw.map((s: Section) => ({
          id: s.id,
          name: s.name,
          classId: s.classId
        }));
        setAvailableSections(secList);
      }
    } catch (err: any) {
      console.error('Error loading metadata for report cards:', err);
    }
  }, []);

  // Fetch Report Cards (approved / published only)
  const fetchReportCards = useCallback(async (isSilent = false) => {
    if (!isSilent) setLoading(true);
    else setRefreshing(true);
    setError(null);

    try {
      const params: any = {
        limit: 100
      };
      if (filterSession !== 'ALL') params.academicSessionId = filterSession;
      if (filterExam !== 'ALL') params.examId = filterExam;
      if (filterClass !== 'ALL') params.classId = filterClass;
      if (filterSection !== 'ALL') params.sectionId = filterSection;
      if (searchQuery.trim()) params.search = searchQuery.trim();

      const res = await api.examinations.getReportCardsList(params);
      if (res.success && res.data) {
        setResults(res.data);
      } else {
        setError(res.error || 'Failed to fetch report cards.');
      }
    } catch (err: any) {
      setError(err?.message || 'Network error fetching report cards.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [filterSession, filterExam, filterClass, filterSection, searchQuery]);

  useEffect(() => {
    loadMetadata();
  }, [loadMetadata]);

  useEffect(() => {
    fetchReportCards();
  }, [fetchReportCards]);

  // Open Preview for single student report card
  const handleOpenPreview = async (resultId: string) => {
    setPreviewResultId(resultId);
    setIsLoadingDetail(true);
    try {
      const res = await api.examinations.getReportCardDetail(resultId);
      if (res.success && res.data) {
        setPreviewReportCard(res.data);
      } else {
        addToast(res.error || 'Failed to load report card details.', 'error');
      }
    } catch (err: any) {
      addToast(err?.message || 'Error loading report card.', 'error');
    } finally {
      setIsLoadingDetail(false);
    }
  };

  // Selection handlers
  const handleToggleSelect = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleToggleSelectAll = () => {
    if (selectedIds.length === (results || []).length) {
      setSelectedIds([]);
    } else {
      setSelectedIds((results || []).map((r) => r.id));
    }
  };

  // Bulk Print Handler
  const handleBulkPrint = async () => {
    if (selectedIds.length === 0) {
      addToast('Please select at least one report card to print.', 'info');
      return;
    }

    setLoadingBulk(true);
    setIsBulkPrintOpen(true);
    try {
      const cards: ReportCardDetail[] = [];
      for (const id of selectedIds) {
        const res = await api.examinations.getReportCardDetail(id);
        if (res.success && res.data) {
          cards.push(res.data);
        }
      }
      setBulkReportCards(cards);
    } catch (err: any) {
      addToast('Failed to compile bulk report cards.', 'error');
    } finally {
      setLoadingBulk(false);
    }
  };

  // Filter sections by class
  const filteredSections = useMemo(() => {
    if (filterClass === 'ALL') return availableSections || [];
    return (availableSections || []).filter((s) => !s.classId || s.classId === filterClass);
  }, [availableSections, filterClass]);

  // Telemetry Aggregations
  const stats = useMemo(() => {
    const total = (results || []).length;
    const passed = (results || []).filter((r) => r.summary?.resultStatus === 'PASSED' || r.summary?.resultStatus === 'DISTINCTION').length;
    const distinctions = (results || []).filter((r) => r.summary?.resultStatus === 'DISTINCTION').length;
    const avgGpa = total > 0 ? (results.reduce((acc, r) => acc + (r.summary?.gpa || 0), 0) / total).toFixed(2) : '0.00';
    const highestMarks = total > 0 ? Math.max(...results.map((r) => r.summary?.totalObtainedMarks || 0)) : 0;
    return { total, passed, distinctions, avgGpa, highestMarks };
  }, [results]);

  return (
    <div className="space-y-6">
      {/* Telemetry Cards Header */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <div className="p-4 rounded-2xl bg-slate-900/60 border border-white/10">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Eligible Cards
            </span>
            <FileText className="w-4 h-4 text-indigo-400" />
          </div>
          <span className="text-2xl font-bold text-white mt-2 block">{stats.total}</span>
          <span className="text-[11px] text-emerald-400 font-medium mt-0.5 block">
            Approved / Published
          </span>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/60 border border-white/10">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Passed Rate
            </span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <span className="text-2xl font-bold text-white mt-2 block">
            {stats.total > 0 ? `${((stats.passed / stats.total) * 100).toFixed(1)}%` : '0%'}
          </span>
          <span className="text-[11px] text-slate-400 mt-0.5 block">
            {stats.passed} of {stats.total} students
          </span>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/60 border border-white/10">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Distinctions
            </span>
            <Award className="w-4 h-4 text-amber-400" />
          </div>
          <span className="text-2xl font-bold text-white mt-2 block">{stats.distinctions}</span>
          <span className="text-[11px] text-amber-400 font-medium mt-0.5 block">
            GPA 3.75+ or ≥85%
          </span>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/60 border border-white/10">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Average GPA
            </span>
            <Sparkles className="w-4 h-4 text-sky-400" />
          </div>
          <span className="text-2xl font-bold text-white mt-2 block">{stats.avgGpa}</span>
          <span className="text-[11px] text-slate-400 mt-0.5 block">Across filtered batch</span>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/60 border border-white/10">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Top Obtained
            </span>
            <GraduationCap className="w-4 h-4 text-purple-400" />
          </div>
          <span className="text-2xl font-bold text-white mt-2 block">{stats.highestMarks}</span>
          <span className="text-[11px] text-purple-400 font-medium mt-0.5 block">Highest Score</span>
        </div>
      </div>

      {/* Filter & Action Toolbar */}
      <Card className="border-white/10 bg-slate-900/60 backdrop-blur-sm">
        <CardContent className="p-4 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-3">
            <div>
              <label className="text-xs font-semibold text-slate-400 block mb-1">Academic Session</label>
              <Select
                value={filterSession}
                onChange={(e) => setFilterSession(e.target.value)}
                className="w-full text-xs"
              >
                <option value="ALL">All Academic Sessions</option>
                {(availableSessions || []).map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </Select>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-400 block mb-1">Examination</label>
              <Select
                value={filterExam}
                onChange={(e) => setFilterExam(e.target.value)}
                className="w-full text-xs"
              >
                <option value="ALL">All Examinations</option>
                {(availableExams || []).map((e) => (
                  <option key={e.id} value={e.id}>
                    {e.name} {e.className ? `(${e.className})` : ''}
                  </option>
                ))}
              </Select>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-400 block mb-1">Class</label>
              <Select
                value={filterClass}
                onChange={(e) => {
                  setFilterClass(e.target.value);
                  setFilterSection('ALL');
                }}
                className="w-full text-xs"
              >
                <option value="ALL">All Classes</option>
                {(availableClasses || []).map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </Select>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-400 block mb-1">Section</label>
              <Select
                value={filterSection}
                onChange={(e) => setFilterSection(e.target.value)}
                className="w-full text-xs"
              >
                <option value="ALL">All Sections</option>
                {(filteredSections || []).map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </Select>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-400 block mb-1">Search Student</label>
              <div className="relative">
                <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <Input
                  type="text"
                  placeholder="Name or Roll..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-8 text-xs h-9"
                />
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-white/5">
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => fetchReportCards(true)}
                disabled={refreshing}
                className="text-slate-300 hover:text-white"
              >
                <RefreshCw className={`w-3.5 h-3.5 mr-1.5 ${refreshing ? 'animate-spin' : ''}`} />
                Refresh
              </Button>
              {selectedIds.length > 0 && (
                <span className="text-xs font-semibold text-indigo-400 bg-indigo-500/10 px-2.5 py-1 rounded-lg border border-indigo-500/20">
                  {selectedIds.length} Selected
                </span>
              )}
            </div>

            <div className="flex items-center gap-2">
              <Button
                variant="primary"
                size="sm"
                disabled={selectedIds.length === 0}
                onClick={handleBulkPrint}
                className="bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-600/30 disabled:opacity-50"
              >
                <Printer className="w-4 h-4 mr-2" />
                Bulk Print ({selectedIds.length})
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Report Cards Table */}
      <Card className="border-white/10 bg-slate-900/60 backdrop-blur-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-950/80 text-slate-400 uppercase tracking-wider font-semibold text-[11px] border-b border-white/10">
              <tr>
                <th className="p-3.5 w-10 text-center">
                  <button
                    type="button"
                    onClick={handleToggleSelectAll}
                    className="text-slate-400 hover:text-white transition-colors"
                  >
                    {selectedIds.length > 0 && selectedIds.length === results.length ? (
                      <CheckSquare className="w-4 h-4 text-indigo-400" />
                    ) : (
                      <Square className="w-4 h-4" />
                    )}
                  </button>
                </th>
                <th className="py-3.5 px-3">Student Dossier</th>
                <th className="py-3.5 px-3">Class & Section</th>
                <th className="py-3.5 px-3">Exam Name</th>
                <th className="py-3.5 px-3 text-center">Marks</th>
                <th className="py-3.5 px-3 text-center">Percentage</th>
                <th className="py-3.5 px-3 text-center">GPA</th>
                <th className="py-3.5 px-3 text-center">Grade</th>
                <th className="py-3.5 px-3 text-center">Standing</th>
                <th className="py-3.5 px-3 text-center">Status</th>
                <th className="py-3.5 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 font-medium text-slate-300">
              {loading ? (
                <tr>
                  <td colSpan={11} className="py-12 text-center">
                    <LoadingSpinner size="md" />
                    <p className="text-xs text-slate-400 mt-2">Loading verified report cards...</p>
                  </td>
                </tr>
              ) : results.length === 0 ? (
                <tr>
                  <td colSpan={11} className="py-12 text-center">
                    <EmptyState
                      icon={FileText}
                      title="No Report Cards Found"
                      description="Only student results that have been Approved or Published by the Examination Board can generate official report cards."
                    />
                  </td>
                </tr>
              ) : (
                results.map((r) => {
                  const isSelected = selectedIds.includes(r.id);
                  const isDistinction = r.summary?.resultStatus === 'DISTINCTION';
                  const isPassed = r.summary?.resultStatus === 'PASSED' || isDistinction;

                  return (
                    <tr
                      key={r.id}
                      className={`hover:bg-white/[0.02] transition-colors ${
                        isSelected ? 'bg-indigo-500/5' : ''
                      }`}
                    >
                      <td className="p-3.5 text-center">
                        <button
                          type="button"
                          onClick={() => handleToggleSelect(r.id)}
                          className="text-slate-400 hover:text-white transition-colors"
                        >
                          {isSelected ? (
                            <CheckSquare className="w-4 h-4 text-indigo-400" />
                          ) : (
                            <Square className="w-4 h-4" />
                          )}
                        </button>
                      </td>
                      <td className="py-3.5 px-3">
                        <div className="flex items-center gap-2.5">
                          <div className="w-8 h-8 rounded-full bg-slate-800 border border-white/10 flex items-center justify-center font-bold text-slate-300 overflow-hidden text-xs">
                            {r.avatarUrl ? (
                              <img src={r.avatarUrl} alt={r.studentName} className="w-full h-full object-cover" />
                            ) : (
                              r.studentName.slice(0, 2).toUpperCase()
                            )}
                          </div>
                          <div>
                            <span className="font-bold text-white block">{r.studentName}</span>
                            <span className="text-[10px] text-slate-400 font-mono">
                              Adm: {r.admissionNumber || 'ADM-01'} • Roll #{r.rollNumber || '01'}
                            </span>
                          </div>
                        </div>
                      </td>
                      <td className="py-3.5 px-3">
                        <span className="text-white font-semibold block">{r.className}</span>
                        <span className="text-[10px] text-slate-400 block">{r.sectionName}</span>
                      </td>
                      <td className="py-3.5 px-3">
                        <span className="text-slate-200 block font-medium">{r.examName}</span>
                        <span className="text-[10px] text-slate-400 block">{r.academicSessionName}</span>
                      </td>
                      <td className="py-3.5 px-3 text-center font-mono font-bold text-white">
                        {r.summary?.totalObtainedMarks ?? 0} / {r.summary?.totalFullMarks ?? 0}
                      </td>
                      <td className="py-3.5 px-3 text-center font-mono text-slate-200">
                        {r.summary?.overallPercentage ?? 0}%
                      </td>
                      <td className="py-3.5 px-3 text-center font-mono font-black text-indigo-400">
                        {Number(r.summary?.gpa ?? 0).toFixed(2)}
                      </td>
                      <td className="py-3.5 px-3 text-center">
                        <span className="inline-block px-2 py-0.5 rounded bg-slate-800 border border-white/10 font-bold text-white">
                          {r.summary?.overallGrade || '—'}
                        </span>
                      </td>
                      <td className="py-3.5 px-3 text-center">
                        <Badge
                          variant={isPassed ? 'success' : 'danger'}
                          className={
                            isDistinction
                              ? 'bg-amber-500/20 text-amber-300 border-amber-500/30 font-bold'
                              : isPassed
                              ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                              : 'bg-rose-500/20 text-rose-300 border-rose-500/30'
                          }
                        >
                          {r.summary?.resultStatus || 'PENDING'}
                        </Badge>
                      </td>
                      <td className="py-3.5 px-3 text-center">
                        <Badge
                          variant="neutral"
                          className={
                            r.workflowStatus === 'PUBLISHED'
                              ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                              : 'bg-indigo-500/10 text-indigo-400 border-indigo-500/30'
                          }
                        >
                          {r.workflowStatus}
                        </Badge>
                      </td>
                      <td className="py-3.5 px-3 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleOpenPreview(r.id)}
                            className="h-7 px-2.5 text-xs text-indigo-300 hover:text-white border-indigo-500/30 hover:bg-indigo-500/10"
                          >
                            <Eye className="w-3.5 h-3.5 mr-1" />
                            Preview
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Single Report Card Modal */}
      <ReportCardPrintModal
        isOpen={!!previewResultId && !!previewReportCard}
        onClose={() => {
          setPreviewResultId(null);
          setPreviewReportCard(null);
        }}
        reportCard={previewReportCard}
      />

      {/* Bulk Print Modal Compilation */}
      {isBulkPrintOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-sm p-4 sm:p-6 flex flex-col items-center">
          <div className="w-full max-w-4xl bg-slate-900 border border-white/10 rounded-2xl p-6 space-y-6 shadow-2xl">
            <div className="flex items-center justify-between pb-4 border-b border-white/10">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-indigo-500/20 text-indigo-400 rounded-xl">
                  <Printer className="w-6 h-6" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-white">
                    Bulk Print Batch ({bulkReportCards.length} Report Cards)
                  </h2>
                  <p className="text-xs text-slate-400">
                    Review and print compiled academic transcripts.
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setIsBulkPrintOpen(false)}
                >
                  Close
                </Button>
                <Button
                  variant="primary"
                  size="sm"
                  onClick={() => window.print()}
                  className="bg-indigo-600 hover:bg-indigo-500 text-white"
                >
                  <Printer className="w-4 h-4 mr-2" />
                  Print Entire Batch
                </Button>
              </div>
            </div>

            {loadingBulk ? (
              <div className="py-16 text-center">
                <LoadingSpinner size="lg" />
                <p className="text-sm text-slate-400 mt-3">Compiling selected report cards...</p>
              </div>
            ) : (
              <div className="space-y-8">
                {(bulkReportCards || []).map((rc, idx) => (
                  <div
                    key={rc.result?.id || idx}
                    className="p-6 bg-white text-slate-900 rounded-xl border border-slate-300 shadow-sm print:break-after-page space-y-4"
                  >
                    <div className="flex justify-between border-b pb-3 items-center">
                      <div>
                        <h3 className="font-extrabold text-lg text-indigo-950">{rc.school?.name}</h3>
                        <p className="text-xs text-slate-600">{rc.student?.name} • {rc.student?.className} ({rc.student?.sectionName}) • Roll #{rc.student?.rollNumber}</p>
                      </div>
                      <div className="text-right">
                        <span className="font-bold text-indigo-900 text-sm block">{rc.result?.examName}</span>
                        <span className="text-xs text-slate-600 block">GPA: {Number(rc.result?.summary?.gpa ?? 0).toFixed(2)} | Grade: {rc.result?.summary?.overallGrade || '—'}</span>
                      </div>
                    </div>
                    <div className="overflow-x-auto">
                      <table className="w-full text-xs text-left">
                        <thead className="bg-slate-100 font-bold">
                          <tr>
                            <th className="py-1.5 px-2">Subject</th>
                            <th className="py-1.5 px-2 text-center">Full Marks</th>
                            <th className="py-1.5 px-2 text-center">Obtained</th>
                            <th className="py-1.5 px-2 text-center">Percentage</th>
                            <th className="py-1.5 px-2 text-center">Grade</th>
                            <th className="py-1.5 px-2 text-center">Grade Pt</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-200">
                          {(rc.result?.subjects || []).map((sub, sidx) => (
                            <tr key={sidx}>
                              <td className="py-1 px-2 font-medium">{sub.subjectName}</td>
                              <td className="py-1 px-2 text-center">{sub.fullMarks}</td>
                              <td className="py-1 px-2 text-center font-bold">{sub.obtainedMarks}</td>
                              <td className="py-1 px-2 text-center">{sub.percentage}%</td>
                              <td className="py-1 px-2 text-center font-bold">{sub.grade}</td>
                              <td className="py-1 px-2 text-center">{Number(sub.gradePoint ?? 0).toFixed(2)}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                    <div className="flex justify-between items-center pt-2 text-xs text-slate-600 border-t">
                      <span>Result: <strong>{rc.result?.summary?.resultStatus || '—'}</strong></span>
                      <span>Total: <strong>{rc.result?.summary?.totalObtainedMarks ?? 0} / {rc.result?.summary?.totalFullMarks ?? 0}</strong> ({rc.result?.summary?.overallPercentage ?? 0}%)</span>
                      <span>Class Rank: <strong>#{rc.merit?.classRank || 1}</strong></span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
