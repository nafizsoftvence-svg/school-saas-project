import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  CalendarDays,
  Clock,
  MapPin,
  User,
  Users,
  Search,
  Filter,
  Plus,
  RefreshCw,
  Edit2,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  AlertCircle,
  Building,
  BookOpen,
  Calendar,
  Layers,
  ChevronRight,
  Sparkles,
  Printer,
  Download,
  Check,
  X,
  UserCheck,
  LayoutGrid,
  List,
  ShieldAlert,
  ArrowRight,
  ShieldCheck
} from 'lucide-react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '../ui/Card.js';
import { Button } from '../ui/Button.js';
import { Badge } from '../ui/Badge.js';
import { Modal } from '../ui/Modal.js';
import { Input } from '../ui/Input.js';
import { Select } from '../ui/Select.js';
import { LoadingSpinner } from '../ui/LoadingSpinner.js';
import { EmptyState } from '../ui/EmptyState.js';
import { Alert } from '../ui/Alert.js';
import { useToast } from '../../context/ToastContext.js';
import { useSettings } from '../../context/SettingsContext.js';
import { api } from '../../services/api.js';
import {
  ExamScheduleItem,
  ExamStatus,
  AcademicSession,
  SchoolClass,
  Section,
  Subject,
  Examination,
  ExamScheduleConflict,
  CreateExamSchedulePayload,
  UpdateExamSchedulePayload
} from '../../types/index.js';

interface ExamScheduleMasterViewProps {
  academicSessions: AcademicSession[];
  classes: SchoolClass[];
  sections: Section[];
  subjects: Subject[];
  examinations: Examination[];
  teachers: Array<{ id: string; name: string; designation: string; department: string }>;
  onRefreshParent?: () => void;
}

export const ExamScheduleMasterView: React.FC<ExamScheduleMasterViewProps> = ({
  academicSessions,
  classes,
  sections,
  subjects,
  examinations,
  teachers,
  onRefreshParent
}) => {
  const { addToast } = useToast();
  const { formatDate } = useSettings();

  // Data states
  const [schedules, setSchedules] = useState<ExamScheduleItem[]>([]);
  const [stats, setStats] = useState({
    total: 0,
    scheduled: 0,
    ongoing: 0,
    completed: 0,
    postponed: 0,
    cancelled: 0
  });
  const [distinctRooms, setDistinctRooms] = useState<string[]>([]);
  const [distinctDates, setDistinctDates] = useState<string[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [refreshing, setRefreshing] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // Filters
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filterSession, setFilterSession] = useState<string>('ALL');
  const [filterExam, setFilterExam] = useState<string>('ALL');
  const [filterClass, setFilterClass] = useState<string>('ALL');
  const [filterSection, setFilterSection] = useState<string>('ALL');
  const [filterSubject, setFilterSubject] = useState<string>('ALL');
  const [filterTeacher, setFilterTeacher] = useState<string>('ALL');
  const [filterRoom, setFilterRoom] = useState<string>('ALL');
  const [filterStatus, setFilterStatus] = useState<string>('ALL');
  const [filterDate, setFilterDate] = useState<string>('');

  // View mode
  const [viewTab, setViewTab] = useState<'table' | 'timeline' | 'rooms' | 'roster'>('table');

  // Modals
  const [isAddModalOpen, setIsAddModalOpen] = useState<boolean>(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState<boolean>(false);
  const [isReassignModalOpen, setIsReassignModalOpen] = useState<boolean>(false);
  const [isStatusModalOpen, setIsStatusModalOpen] = useState<boolean>(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState<boolean>(false);
  const [isPrintModalOpen, setIsPrintModalOpen] = useState<boolean>(false);
  const [isConflictCheckModalOpen, setIsConflictCheckModalOpen] = useState<boolean>(false);

  // Selected schedule slot
  const [selectedSchedule, setSelectedSchedule] = useState<ExamScheduleItem | null>(null);
  const [targetStatus, setTargetStatus] = useState<ExamStatus>('scheduled');
  const [selectedTeacherId, setSelectedTeacherId] = useState<string>('');

  // Form payload
  const [formData, setFormData] = useState<{
    examId: string;
    subjectId: string;
    classId: string;
    sectionId: string;
    academicSessionId: string;
    examDate: string;
    startTime: string;
    endTime: string;
    durationMinutes: number;
    roomNumber: string;
    fullMarks: number;
    passMarks: number;
    invigilatorTeacherId: string;
    instructions: string;
    status: ExamStatus;
  }>({
    examId: '',
    subjectId: '',
    classId: '',
    sectionId: 'ALL',
    academicSessionId: '',
    examDate: '',
    startTime: '09:00 AM',
    endTime: '11:30 AM',
    durationMinutes: 150,
    roomNumber: 'Main Examination Hall',
    fullMarks: 100,
    passMarks: 40,
    invigilatorTeacherId: '',
    instructions: '',
    status: 'scheduled'
  });

  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const [liveConflicts, setLiveConflicts] = useState<ExamScheduleConflict[]>([]);
  const [isCheckingConflict, setIsCheckingConflict] = useState<boolean>(false);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Load schedules
  const loadSchedules = useCallback(async (isSilent = false) => {
    try {
      if (!isSilent) setLoading(true);
      else setRefreshing(true);
      setError(null);

      const res = await api.examinations.getSchedules({
        academicSessionId: filterSession !== 'ALL' ? filterSession : undefined,
        examId: filterExam !== 'ALL' ? filterExam : undefined,
        classId: filterClass !== 'ALL' ? filterClass : undefined,
        sectionId: filterSection !== 'ALL' ? filterSection : undefined,
        subjectId: filterSubject !== 'ALL' ? filterSubject : undefined,
        teacherId: filterTeacher !== 'ALL' ? filterTeacher : undefined,
        roomNumber: filterRoom !== 'ALL' ? filterRoom : undefined,
        status: filterStatus !== 'ALL' ? filterStatus : undefined,
        date: filterDate || undefined,
        search: searchQuery.trim() || undefined
      });

      if (res.success && res.data) {
        setSchedules(res.data.data || []);
        if (res.data.stats) setStats(res.data.stats);
        if (res.data.filterOptions) {
          setDistinctRooms(res.data.filterOptions.distinctRooms || []);
          setDistinctDates(res.data.filterOptions.distinctDates || []);
        }
      }
    } catch (err: any) {
      console.error('Failed to load exam schedules:', err);
      setError(err?.message || 'Failed to load master exam schedules.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [
    filterSession,
    filterExam,
    filterClass,
    filterSection,
    filterSubject,
    filterTeacher,
    filterRoom,
    filterStatus,
    filterDate,
    searchQuery
  ]);

  useEffect(() => {
    loadSchedules();
  }, [loadSchedules]);

  // Derived sections for chosen class in modal
  const availableModalSections = useMemo(() => {
    if (!formData.classId) return [];
    return sections.filter((s) => s.classId === formData.classId);
  }, [formData.classId, sections]);

  // Derived subjects for chosen class in modal
  const availableModalSubjects = useMemo(() => {
    if (!formData.classId) return [];
    return subjects.filter((s) => s.classId === formData.classId);
  }, [formData.classId, subjects]);

  // Active exam selection sync in modal
  const handleExamChange = (examId: string) => {
    const exam = (examinations || []).find((e) => e?.id === examId);
    if (exam) {
      setFormData((prev) => ({
        ...prev,
        examId: exam.id,
        classId: exam.classId,
        sectionId: exam.sectionId || 'ALL',
        academicSessionId: exam.academicSessionId,
        examDate: exam.startDate || prev.examDate,
        instructions: exam.instructions || prev.instructions
      }));
    } else {
      setFormData((prev) => ({ ...prev, examId }));
    }
  };

  // Perform Live Conflict Check
  const runLiveConflictCheck = useCallback(
    async (currentPayload: typeof formData, scheduleIdToExclude?: string) => {
      if (!currentPayload.examId || !currentPayload.subjectId || !currentPayload.examDate) {
        setLiveConflicts([]);
        return;
      }

      setIsCheckingConflict(true);
      try {
        const res = await api.examinations.validateScheduleConflict({
          scheduleId: scheduleIdToExclude,
          examId: currentPayload.examId,
          subjectId: currentPayload.subjectId,
          classId: currentPayload.classId,
          sectionId: currentPayload.sectionId,
          examDate: currentPayload.examDate,
          startTime: currentPayload.startTime,
          endTime: currentPayload.endTime,
          roomNumber: currentPayload.roomNumber,
          invigilatorTeacherId: currentPayload.invigilatorTeacherId,
          fullMarks: Number(currentPayload.fullMarks),
          passMarks: Number(currentPayload.passMarks)
        });

        if (res.success && res.data) {
          setLiveConflicts(res.data.conflicts || []);
        }
      } catch (err) {
        console.error('Error during conflict check:', err);
      } finally {
        setIsCheckingConflict(false);
      }
    },
    []
  );

  // Debounced live conflict check on form edits
  useEffect(() => {
    if (isAddModalOpen || isEditModalOpen) {
      const timer = setTimeout(() => {
        runLiveConflictCheck(formData, selectedSchedule?.id);
      }, 350);
      return () => clearTimeout(timer);
    }
  }, [
    formData.examId,
    formData.subjectId,
    formData.examDate,
    formData.startTime,
    formData.endTime,
    formData.roomNumber,
    formData.invigilatorTeacherId,
    formData.classId,
    formData.sectionId,
    formData.fullMarks,
    formData.passMarks,
    isAddModalOpen,
    isEditModalOpen,
    selectedSchedule?.id,
    runLiveConflictCheck
  ]);

  // Open Add Schedule Modal
  const handleOpenAddModal = () => {
    const firstExam = (examinations || []).find((e) => e.status !== 'archived') || examinations?.[0];
    const defaultSession = firstExam?.academicSessionId || academicSessions?.[0]?.id || '';
    const defaultClass = firstExam?.classId || classes?.[0]?.id || '';
    const availableSubjs = (subjects || []).filter((s) => s.classId === defaultClass);
    const today = firstExam?.startDate || new Date().toISOString().split('T')[0];

    setFormData({
      examId: firstExam?.id || '',
      subjectId: availableSubjs?.[0]?.id || '',
      classId: defaultClass,
      sectionId: firstExam?.sectionId || 'ALL',
      academicSessionId: defaultSession,
      examDate: today,
      startTime: '09:00 AM',
      endTime: '11:30 AM',
      durationMinutes: 150,
      roomNumber: 'Main Examination Hall',
      fullMarks: 100,
      passMarks: 40,
      invigilatorTeacherId: teachers?.[0]?.id || '',
      instructions: firstExam?.instructions || '',
      status: 'scheduled'
    });
    setFormErrors({});
    setLiveConflicts([]);
    setSelectedSchedule(null);
    setIsAddModalOpen(true);
  };

  // Open Edit Schedule Modal
  const handleOpenEditModal = (schedule: ExamScheduleItem) => {
    setSelectedSchedule(schedule);
    setFormData({
      examId: schedule.examId,
      subjectId: schedule.subjectId,
      classId: schedule.classId,
      sectionId: schedule.sectionId || 'ALL',
      academicSessionId: schedule.academicSessionId,
      examDate: schedule.examDate,
      startTime: schedule.startTime,
      endTime: schedule.endTime,
      durationMinutes: schedule.durationMinutes || 120,
      roomNumber: schedule.roomNumber || 'Main Examination Hall',
      fullMarks: schedule.fullMarks,
      passMarks: schedule.passMarks,
      invigilatorTeacherId: schedule.invigilatorTeacherId || '',
      instructions: schedule.instructions || '',
      status: schedule.status
    });
    setFormErrors({});
    setLiveConflicts([]);
    setIsEditModalOpen(true);
  };

  // Open Quick Reassign Modal
  const handleOpenReassignModal = (schedule: ExamScheduleItem) => {
    setSelectedSchedule(schedule);
    setSelectedTeacherId(schedule.invigilatorTeacherId || '');
    setIsReassignModalOpen(true);
  };

  // Open Quick Status Modal
  const handleOpenStatusModal = (schedule: ExamScheduleItem) => {
    setSelectedSchedule(schedule);
    setTargetStatus(schedule.status);
    setIsStatusModalOpen(true);
  };

  // Open Delete Modal
  const handleOpenDeleteModal = (schedule: ExamScheduleItem) => {
    setSelectedSchedule(schedule);
    setIsDeleteModalOpen(true);
  };

  // Validate form
  const validateForm = (): boolean => {
    const errors: Record<string, string> = {};
    if (!formData.examId) errors.examId = 'Please select an examination.';
    if (!formData.subjectId) errors.subjectId = 'Please select a subject.';
    if (!formData.examDate) errors.examDate = 'Exam date is required.';
    if (!formData.startTime) errors.startTime = 'Start time is required.';
    if (!formData.endTime) errors.endTime = 'End time is required.';
    if (Number(formData.fullMarks) <= 0) errors.fullMarks = 'Full marks must be greater than 0.';
    if (Number(formData.passMarks) < 0 || Number(formData.passMarks) > Number(formData.fullMarks)) {
      errors.passMarks = 'Pass marks cannot exceed full marks and cannot be negative.';
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  // Submit Create Schedule Slot
  const handleCreateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    if (liveConflicts && liveConflicts.length > 0) {
      addToast(`Cannot schedule: ${liveConflicts?.[0]?.message || 'Conflict detected'}`, 'error');
      return;
    }

    setIsSubmitting(true);
    try {
      const payload: CreateExamSchedulePayload = {
        examId: formData.examId,
        subjectId: formData.subjectId,
        classId: formData.classId,
        sectionId: formData.sectionId,
        academicSessionId: formData.academicSessionId,
        examDate: formData.examDate,
        startTime: formData.startTime,
        endTime: formData.endTime,
        durationMinutes: Number(formData.durationMinutes),
        roomNumber: formData.roomNumber,
        fullMarks: Number(formData.fullMarks),
        passMarks: Number(formData.passMarks),
        invigilatorTeacherId: formData.invigilatorTeacherId || undefined,
        instructions: formData.instructions,
        status: formData.status
      };

      const res = await api.examinations.createSchedule(payload);
      if (res.success) {
        addToast(res.message || 'Exam schedule slot created successfully!', 'success');
        setIsAddModalOpen(false);
        loadSchedules(true);
        if (onRefreshParent) onRefreshParent();
      } else {
        addToast(res.error || 'Failed to create exam schedule slot.', 'error');
      }
    } catch (err: any) {
      addToast(err?.message || 'Error creating exam schedule slot.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Submit Update Schedule Slot
  const handleUpdateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSchedule || !validateForm()) return;

    if (liveConflicts && liveConflicts.length > 0) {
      addToast(`Cannot update schedule: ${liveConflicts?.[0]?.message || 'Conflict detected'}`, 'error');
      return;
    }

    setIsSubmitting(true);
    try {
      const payload: UpdateExamSchedulePayload = {
        examDate: formData.examDate,
        startTime: formData.startTime,
        endTime: formData.endTime,
        durationMinutes: Number(formData.durationMinutes),
        roomNumber: formData.roomNumber,
        sectionId: formData.sectionId,
        fullMarks: Number(formData.fullMarks),
        passMarks: Number(formData.passMarks),
        invigilatorTeacherId: formData.invigilatorTeacherId || undefined,
        instructions: formData.instructions,
        status: formData.status
      };

      const res = await api.examinations.updateSchedule(selectedSchedule.id, payload);
      if (res.success) {
        addToast(res.message || 'Schedule updated successfully!', 'success');
        setIsEditModalOpen(false);
        loadSchedules(true);
        if (onRefreshParent) onRefreshParent();
      } else {
        addToast(res.error || 'Failed to update schedule.', 'error');
      }
    } catch (err: any) {
      addToast(err?.message || 'Error updating schedule.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Submit Quick Invigilator Reassignment
  const handleReassignSubmit = async () => {
    if (!selectedSchedule) return;
    setIsSubmitting(true);
    try {
      const res = await api.examinations.assignScheduleInvigilator(
        selectedSchedule.id,
        selectedTeacherId || undefined
      );
      if (res.success) {
        addToast(res.message || 'Invigilator assigned successfully!', 'success');
        setIsReassignModalOpen(false);
        loadSchedules(true);
        if (onRefreshParent) onRefreshParent();
      } else {
        addToast(res.error || 'Failed to assign invigilator.', 'error');
      }
    } catch (err: any) {
      addToast(err?.message || 'Error assigning invigilator.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Submit Quick Status Transition
  const handleStatusSubmit = async () => {
    if (!selectedSchedule) return;
    setIsSubmitting(true);
    try {
      const res = await api.examinations.updateScheduleStatus(selectedSchedule.id, targetStatus);
      if (res.success) {
        addToast(res.message || `Status changed to ${targetStatus}`, 'success');
        setIsStatusModalOpen(false);
        loadSchedules(true);
        if (onRefreshParent) onRefreshParent();
      } else {
        addToast(res.error || 'Failed to update status.', 'error');
      }
    } catch (err: any) {
      addToast(err?.message || 'Error updating status.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Submit Delete Slot
  const handleDeleteSubmit = async () => {
    if (!selectedSchedule) return;
    setIsSubmitting(true);
    try {
      const res = await api.examinations.deleteSchedule(selectedSchedule.id);
      if (res.success) {
        addToast(res.message || 'Schedule slot deleted successfully!', 'success');
        setIsDeleteModalOpen(false);
        loadSchedules(true);
        if (onRefreshParent) onRefreshParent();
      } else {
        addToast(res.error || 'Failed to delete schedule slot.', 'error');
      }
    } catch (err: any) {
      addToast(err?.message || 'Error deleting schedule slot.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Status badge styling helper
  const getStatusBadge = (status: ExamStatus) => {
    switch (status) {
      case 'scheduled':
        return <Badge variant="info" className="gap-1 font-medium"><Clock className="w-3 h-3" /> Scheduled</Badge>;
      case 'ongoing':
        return <Badge variant="warning" className="gap-1 font-medium animate-pulse"><Sparkles className="w-3 h-3" /> Ongoing</Badge>;
      case 'completed':
        return <Badge variant="success" className="gap-1 font-medium"><CheckCircle2 className="w-3 h-3" /> Completed</Badge>;
      case 'postponed':
        return <Badge variant="warning" className="gap-1 font-medium"><AlertTriangle className="w-3 h-3" /> Postponed</Badge>;
      case 'cancelled':
        return <Badge variant="danger" className="gap-1 font-medium"><X className="w-3 h-3" /> Cancelled</Badge>;
      default:
        return <Badge variant="neutral">{status}</Badge>;
    }
  };

  // Group schedules by date for Timeline view
  const schedulesByDate = useMemo(() => {
    const grouped: Record<string, ExamScheduleItem[]> = {};
    for (const item of schedules) {
      if (!grouped[item.examDate]) grouped[item.examDate] = [];
      grouped[item.examDate].push(item);
    }
    return grouped;
  }, [schedules]);

  // Group schedules by Room for Room Occupancy view
  const schedulesByRoom = useMemo(() => {
    const grouped: Record<string, ExamScheduleItem[]> = {};
    for (const item of schedules) {
      const room = item.roomNumber || 'Unassigned Room';
      if (!grouped[room]) grouped[room] = [];
      grouped[room].push(item);
    }
    return grouped;
  }, [schedules]);

  // Group schedules by Invigilator for Roster view
  const schedulesByTeacher = useMemo(() => {
    const grouped: Record<string, { teacherName: string; designation?: string; items: ExamScheduleItem[] }> = {};
    for (const item of schedules) {
      const key = item.invigilatorTeacherId || item.invigilatorName || 'Unassigned Faculty';
      if (!grouped[key]) {
        grouped[key] = {
          teacherName: item.invigilatorName || 'Unassigned Faculty',
          items: []
        };
      }
      grouped[key].items.push(item);
    }
    return grouped;
  }, [schedules]);

  // Run full conflict diagnostic across all active schedules
  const globalConflicts = useMemo(() => {
    const conflicts: Array<{
      item1: ExamScheduleItem;
      item2: ExamScheduleItem;
      type: 'ROOM_CLASH' | 'TEACHER_CLASH' | 'CLASS_CLASH';
      message: string;
    }> = [];

    for (let i = 0; i < schedules.length; i++) {
      for (let j = i + 1; j < schedules.length; j++) {
        const a = schedules[i];
        const b = schedules[j];

        if (a.status === 'cancelled' || b.status === 'cancelled') continue;
        if (a.examDate !== b.examDate) continue;

        // Check time overlap
        // Simple approximate overlap check
        if (a.startTime === b.startTime) {
          if (a.roomNumber && b.roomNumber && a.roomNumber.toLowerCase() === b.roomNumber.toLowerCase()) {
            conflicts.push({
              item1: a,
              item2: b,
              type: 'ROOM_CLASH',
              message: `Room Conflict: Both "${a.subjectName}" and "${b.subjectName}" are booked in Room "${a.roomNumber}" at ${a.startTime} on ${a.examDate}.`
            });
          }
          if (a.invigilatorTeacherId && b.invigilatorTeacherId && a.invigilatorTeacherId === b.invigilatorTeacherId) {
            conflicts.push({
              item1: a,
              item2: b,
              type: 'TEACHER_CLASH',
              message: `Faculty Conflict: ${a.invigilatorName || 'Faculty'} is assigned to both "${a.subjectName}" and "${b.subjectName}" at ${a.startTime}.`
            });
          }
          if (a.classId === b.classId && (a.sectionId === 'ALL' || b.sectionId === 'ALL' || a.sectionId === b.sectionId)) {
            conflicts.push({
              item1: a,
              item2: b,
              type: 'CLASS_CLASH',
              message: `Class Conflict: Class ${a.className} has two exams ("${a.subjectName}" and "${b.subjectName}") simultaneously at ${a.startTime}.`
            });
          }
        }
      }
    }
    return conflicts;
  }, [schedules]);

  return (
    <div className="space-y-6">
      {/* Top Header & Quick Metrics */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold text-slate-900 dark:text-white tracking-tight">
              Master Examination Schedules & Timetable
            </h2>
            <Badge variant="primary" className="text-xs">
              Part 6B Conflict Engine Active
            </Badge>
          </div>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Centrally manage timetables, room assignments, invigilation duty rosters, and automated clash prevention.
          </p>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          <Button
            variant="outline"
            size="sm"
            onClick={() => loadSchedules(true)}
            disabled={refreshing}
            className="gap-2"
          >
            <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin' : ''}`} />
            Refresh
          </Button>

          <Button
            variant="outline"
            size="sm"
            onClick={() => setIsPrintModalOpen(true)}
            disabled={schedules.length === 0}
            className="gap-2"
          >
            <Printer className="w-4 h-4" />
            Print Timetable
          </Button>

          <Button
            variant="outline"
            size="sm"
            onClick={() => setIsConflictCheckModalOpen(true)}
            className={`gap-2 ${globalConflicts.length > 0 ? 'text-amber-600 border-amber-300 dark:border-amber-700 bg-amber-50 dark:bg-amber-950/40' : ''}`}
          >
            {globalConflicts.length > 0 ? (
              <>
                <ShieldAlert className="w-4 h-4 text-amber-600 animate-pulse" />
                <span>{globalConflicts.length} Conflict Warnings</span>
              </>
            ) : (
              <>
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>Check Conflicts</span>
              </>
            )}
          </Button>

          <Button
            variant="primary"
            size="sm"
            onClick={handleOpenAddModal}
            className="gap-2 shadow-sm"
          >
            <Plus className="w-4 h-4" />
            Schedule New Exam
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <Card className="bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <CardContent className="p-3.5 flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Total Slots</p>
              <p className="text-2xl font-bold text-slate-900 dark:text-white mt-0.5">{stats.total}</p>
            </div>
            <div className="p-2.5 rounded-xl bg-indigo-500/10 text-indigo-600 dark:text-indigo-400">
              <CalendarDays className="w-5 h-5" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <CardContent className="p-3.5 flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-sky-600 dark:text-sky-400 uppercase tracking-wider">Scheduled</p>
              <p className="text-2xl font-bold text-sky-700 dark:text-sky-300 mt-0.5">{stats.scheduled}</p>
            </div>
            <div className="p-2.5 rounded-xl bg-sky-500/10 text-sky-600 dark:text-sky-400">
              <Clock className="w-5 h-5" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <CardContent className="p-3.5 flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-amber-600 dark:text-amber-400 uppercase tracking-wider">Ongoing</p>
              <p className="text-2xl font-bold text-amber-700 dark:text-amber-300 mt-0.5">{stats.ongoing}</p>
            </div>
            <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400">
              <Sparkles className="w-5 h-5" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <CardContent className="p-3.5 flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider">Completed</p>
              <p className="text-2xl font-bold text-emerald-700 dark:text-emerald-300 mt-0.5">{stats.completed}</p>
            </div>
            <div className="p-2.5 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
              <CheckCircle2 className="w-5 h-5" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <CardContent className="p-3.5 flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-orange-600 dark:text-orange-400 uppercase tracking-wider">Postponed</p>
              <p className="text-2xl font-bold text-orange-700 dark:text-orange-300 mt-0.5">{stats.postponed}</p>
            </div>
            <div className="p-2.5 rounded-xl bg-orange-500/10 text-orange-600 dark:text-orange-400">
              <AlertTriangle className="w-5 h-5" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <CardContent className="p-3.5 flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-rose-600 dark:text-rose-400 uppercase tracking-wider">Cancelled</p>
              <p className="text-2xl font-bold text-rose-700 dark:text-rose-300 mt-0.5">{stats.cancelled}</p>
            </div>
            <div className="p-2.5 rounded-xl bg-rose-500/10 text-rose-600 dark:text-rose-400">
              <X className="w-5 h-5" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Global Conflict Warning Banner if any clashes detected */}
      {globalConflicts.length > 0 && (
        <Alert variant="warning" className="border-amber-400 dark:border-amber-800">
          <div className="flex items-start gap-3">
            <ShieldAlert className="w-5 h-5 text-amber-600 mt-0.5 flex-shrink-0" />
            <div className="flex-1">
              <h4 className="text-sm font-semibold text-amber-900 dark:text-amber-200">
                {globalConflicts.length} Potential Schedule Conflicts Detected
              </h4>
              <p className="text-xs text-amber-700 dark:text-amber-300 mt-0.5">
                {globalConflicts?.[0]?.message}
              </p>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setIsConflictCheckModalOpen(true)}
              className="text-xs text-amber-900 dark:text-amber-200 border-amber-300 dark:border-amber-700 hover:bg-amber-100 dark:hover:bg-amber-900/50"
            >
              Inspect All ({globalConflicts.length})
            </Button>
          </div>
        </Alert>
      )}

      {/* Filter Toolbar & View Switcher */}
      <Card className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
        <CardContent className="p-4 space-y-3">
          {/* Row 1: Search & View Modes */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search by subject, code, exam name, room, or teacher..."
                className="w-full pl-9 pr-4 py-2 text-sm bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:text-white"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* View switcher tabs */}
            <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl self-start md:self-auto">
              <button
                onClick={() => setViewTab('table')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  viewTab === 'table'
                    ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                <List className="w-3.5 h-3.5" />
                <span>Master Table</span>
              </button>

              <button
                onClick={() => setViewTab('timeline')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  viewTab === 'timeline'
                    ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                <Calendar className="w-3.5 h-3.5" />
                <span>By Date</span>
              </button>

              <button
                onClick={() => setViewTab('rooms')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  viewTab === 'rooms'
                    ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                <Building className="w-3.5 h-3.5" />
                <span>By Room</span>
              </button>

              <button
                onClick={() => setViewTab('roster')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  viewTab === 'roster'
                    ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                <UserCheck className="w-3.5 h-3.5" />
                <span>Invigilators</span>
              </button>
            </div>
          </div>

          {/* Row 2: Secondary Dropdown Filters */}
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-7 gap-2.5 pt-2 border-t border-slate-100 dark:border-slate-800">
            {/* Session */}
            <div>
              <label className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">Session</label>
              <select
                value={filterSession}
                onChange={(e) => setFilterSession(e.target.value)}
                className="w-full text-xs py-1.5 px-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500 dark:text-white"
              >
                <option value="ALL">All Sessions</option>
                {(academicSessions || []).map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name} {s.isActive ? '(Active)' : ''}
                  </option>
                ))}
              </select>
            </div>

            {/* Exam */}
            <div>
              <label className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">Exam</label>
              <select
                value={filterExam}
                onChange={(e) => setFilterExam(e.target.value)}
                className="w-full text-xs py-1.5 px-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500 dark:text-white"
              >
                <option value="ALL">All Exams</option>
                {(examinations || []).map((e) => (
                  <option key={e.id} value={e.id}>
                    {e.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Class */}
            <div>
              <label className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">Class</label>
              <select
                value={filterClass}
                onChange={(e) => {
                  setFilterClass(e.target.value);
                  setFilterSection('ALL');
                }}
                className="w-full text-xs py-1.5 px-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500 dark:text-white"
              >
                <option value="ALL">All Classes</option>
                {(classes || []).map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Section */}
            <div>
              <label className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">Section</label>
              <select
                value={filterSection}
                onChange={(e) => setFilterSection(e.target.value)}
                disabled={filterClass === 'ALL'}
                className="w-full text-xs py-1.5 px-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500 dark:text-white disabled:opacity-50"
              >
                <option value="ALL">All Sections</option>
                {(sections || [])
                  .filter((s) => filterClass === 'ALL' || s.classId === filterClass)
                  .map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name}
                    </option>
                  ))}
              </select>
            </div>

            {/* Room */}
            <div>
              <label className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">Room / Hall</label>
              <select
                value={filterRoom}
                onChange={(e) => setFilterRoom(e.target.value)}
                className="w-full text-xs py-1.5 px-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500 dark:text-white"
              >
                <option value="ALL">All Rooms</option>
                {(distinctRooms || []).map((r) => (
                  <option key={r} value={r}>
                    {r}
                  </option>
                ))}
              </select>
            </div>

            {/* Teacher / Invigilator */}
            <div>
              <label className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">Invigilator</label>
              <select
                value={filterTeacher}
                onChange={(e) => setFilterTeacher(e.target.value)}
                className="w-full text-xs py-1.5 px-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500 dark:text-white"
              >
                <option value="ALL">All Faculty</option>
                {(teachers || []).map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Status */}
            <div>
              <label className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">Status</label>
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="w-full text-xs py-1.5 px-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500 dark:text-white"
              >
                <option value="ALL">All Statuses</option>
                <option value="scheduled">Scheduled</option>
                <option value="ongoing">Ongoing</option>
                <option value="completed">Completed</option>
                <option value="postponed">Postponed</option>
                <option value="cancelled">Cancelled</option>
              </select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Main Content Area */}
      {loading ? (
        <div className="py-20 flex justify-center">
          <LoadingSpinner size="lg" message="Loading master examination timetable..." />
        </div>
      ) : error ? (
        <Alert variant="danger">
          <div className="flex items-center justify-between">
            <span>{error}</span>
            <Button size="sm" variant="outline" onClick={() => loadSchedules()}>
              Retry
            </Button>
          </div>
        </Alert>
      ) : schedules.length === 0 ? (
        <EmptyState
          icon={CalendarDays}
          title="No Exam Schedules Found"
          description={
            searchQuery || filterSession !== 'ALL' || filterExam !== 'ALL' || filterClass !== 'ALL'
              ? 'No scheduled exams match your selected filters. Try clearing some filters.'
              : 'There are no active exam schedules created yet. Start by allocating exam subjects into timetable slots.'
          }
          action={
            <Button variant="primary" onClick={handleOpenAddModal} className="gap-2">
              <Plus className="w-4 h-4" />
              Schedule Exam Slot
            </Button>
          }
        />
      ) : (
        <>
          {/* TAB 1: MASTER TABLE VIEW */}
          {viewTab === 'table' && (
            <Card className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm text-slate-600 dark:text-slate-300">
                  <thead className="bg-slate-50 dark:bg-slate-800/80 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider border-b border-slate-200 dark:border-slate-700">
                    <tr>
                      <th className="py-3 px-4">Date & Time</th>
                      <th className="py-3 px-4">Subject & Code</th>
                      <th className="py-3 px-4">Class / Section</th>
                      <th className="py-3 px-4">Exam Name</th>
                      <th className="py-3 px-4">Room / Hall</th>
                      <th className="py-3 px-4">Invigilator</th>
                      <th className="py-3 px-4">Marks & Duration</th>
                      <th className="py-3 px-4">Status</th>
                      <th className="py-3 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-normal">
                    {(schedules || []).map((schedule) => (
                      <tr
                        key={schedule.id}
                        className="hover:bg-slate-50/60 dark:hover:bg-slate-800/50 transition-colors"
                      >
                        {/* Date & Time */}
                        <td className="py-3.5 px-4 whitespace-nowrap">
                          <div className="font-semibold text-slate-900 dark:text-white flex items-center gap-1.5">
                            <Calendar className="w-3.5 h-3.5 text-indigo-500" />
                            <span>{formatDate(schedule.examDate)}</span>
                          </div>
                          <div className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1.5 mt-0.5">
                            <Clock className="w-3 h-3 text-slate-400" />
                            <span>{schedule.startTime} - {schedule.endTime}</span>
                          </div>
                        </td>

                        {/* Subject */}
                        <td className="py-3.5 px-4">
                          <div className="font-semibold text-slate-900 dark:text-white">
                            {schedule.subjectName}
                          </div>
                          <div className="text-xs text-slate-500 dark:text-slate-400">
                            Code: <span className="font-mono">{schedule.subjectCode}</span>
                          </div>
                        </td>

                        {/* Class / Section */}
                        <td className="py-3.5 px-4 whitespace-nowrap">
                          <div className="font-medium text-slate-800 dark:text-slate-200">
                            {schedule.className}
                          </div>
                          <div className="text-xs text-slate-500 dark:text-slate-400">
                            Section: {schedule.sectionName || 'All Sections'}
                          </div>
                        </td>

                        {/* Exam Name */}
                        <td className="py-3.5 px-4 whitespace-nowrap">
                          <Badge variant="neutral" className="text-xs">
                            {schedule.examName}
                          </Badge>
                        </td>

                        {/* Room / Hall */}
                        <td className="py-3.5 px-4 whitespace-nowrap">
                          <div className="flex items-center gap-1.5 text-slate-700 dark:text-slate-300">
                            <Building className="w-3.5 h-3.5 text-slate-400" />
                            <span>{schedule.roomNumber || 'TBD'}</span>
                          </div>
                        </td>

                        {/* Invigilator */}
                        <td className="py-3.5 px-4">
                          {schedule.invigilatorName ? (
                            <div className="flex items-center gap-1.5 text-slate-800 dark:text-slate-200">
                              <User className="w-3.5 h-3.5 text-indigo-500" />
                              <span className="truncate max-w-[140px]" title={schedule.invigilatorName}>
                                {schedule.invigilatorName}
                              </span>
                            </div>
                          ) : (
                            <button
                              onClick={() => handleOpenReassignModal(schedule)}
                              className="text-xs text-amber-600 hover:text-amber-700 font-medium underline flex items-center gap-1"
                            >
                              <UserCheck className="w-3 h-3" />
                              Assign Invigilator
                            </button>
                          )}
                        </td>

                        {/* Marks & Duration */}
                        <td className="py-3.5 px-4 whitespace-nowrap">
                          <div className="text-xs text-slate-700 dark:text-slate-300">
                            <strong>{schedule.passMarks}</strong> / <strong>{schedule.fullMarks}</strong> marks
                          </div>
                          <div className="text-xs text-slate-500 dark:text-slate-400">
                            {schedule.durationMinutes || 120} mins
                          </div>
                        </td>

                        {/* Status */}
                        <td className="py-3.5 px-4 whitespace-nowrap">
                          <button
                            onClick={() => handleOpenStatusModal(schedule)}
                            title="Click to change status"
                            className="hover:opacity-80 transition-opacity"
                          >
                            {getStatusBadge(schedule.status)}
                          </button>
                        </td>

                        {/* Actions */}
                        <td className="py-3.5 px-4 text-right whitespace-nowrap">
                          <div className="flex items-center justify-end gap-1.5">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleOpenReassignModal(schedule)}
                              title="Reassign Faculty"
                              className="h-8 w-8 p-0 text-slate-500 hover:text-indigo-600"
                            >
                              <UserCheck className="w-3.5 h-3.5" />
                            </Button>

                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleOpenEditModal(schedule)}
                              title="Edit Schedule Slot"
                              className="h-8 w-8 p-0 text-slate-500 hover:text-blue-600"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </Button>

                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleOpenDeleteModal(schedule)}
                              title="Delete Slot"
                              className="h-8 w-8 p-0 text-slate-500 hover:text-rose-600"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
          )}

          {/* TAB 2: DAY-BY-DAY TIMELINE VIEW */}
          {viewTab === 'timeline' && (
            <div className="space-y-6">
              {Object.keys(schedulesByDate)
                .sort()
                .map((dateKey) => (
                  <Card key={dateKey} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                    <CardHeader className="bg-slate-50 dark:bg-slate-800/50 py-3.5 px-5 border-b border-slate-200 dark:border-slate-800 flex flex-row items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="p-2 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 font-bold text-sm">
                          <Calendar className="w-4 h-4" />
                        </div>
                        <div>
                          <CardTitle className="text-base font-bold text-slate-900 dark:text-white">
                            {formatDate(dateKey)}
                          </CardTitle>
                          <CardDescription className="text-xs">
                            {schedulesByDate[dateKey]?.length || 0} Exam Slot(s) Scheduled
                          </CardDescription>
                        </div>
                      </div>
                      <Badge variant="neutral">
                        {new Date(dateKey).toLocaleDateString(undefined, { weekday: 'long' })}
                      </Badge>
                    </CardHeader>
                    <CardContent className="p-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                      {(schedulesByDate[dateKey] || []).map((slot) => (
                        <div
                          key={slot.id}
                          className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 hover:border-indigo-300 dark:hover:border-indigo-700 transition-all space-y-2.5"
                        >
                          <div className="flex items-start justify-between gap-2">
                            <div>
                              <span className="text-[11px] font-semibold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider">
                                {slot.examName}
                              </span>
                              <h4 className="font-bold text-slate-900 dark:text-white text-sm">
                                {slot.subjectName} ({slot.subjectCode})
                              </h4>
                            </div>
                            {getStatusBadge(slot.status)}
                          </div>

                          <div className="text-xs space-y-1 text-slate-600 dark:text-slate-300 pt-1 border-t border-slate-200/60 dark:border-slate-700/60">
                            <div className="flex items-center justify-between">
                              <span className="text-slate-400">Class & Sec:</span>
                              <span className="font-medium text-slate-800 dark:text-slate-200">
                                {slot.className} ({slot.sectionName})
                              </span>
                            </div>
                            <div className="flex items-center justify-between">
                              <span className="text-slate-400">Time Slot:</span>
                              <span className="font-medium text-slate-800 dark:text-slate-200 flex items-center gap-1">
                                <Clock className="w-3 h-3 text-slate-400" />
                                {slot.startTime} - {slot.endTime}
                              </span>
                            </div>
                            <div className="flex items-center justify-between">
                              <span className="text-slate-400">Room / Hall:</span>
                              <span className="font-medium text-slate-800 dark:text-slate-200 flex items-center gap-1">
                                <Building className="w-3 h-3 text-slate-400" />
                                {slot.roomNumber || 'TBD'}
                              </span>
                            </div>
                            <div className="flex items-center justify-between">
                              <span className="text-slate-400">Invigilator:</span>
                              <span className="font-medium text-slate-800 dark:text-slate-200">
                                {slot.invigilatorName || 'Unassigned'}
                              </span>
                            </div>
                            <div className="flex items-center justify-between">
                              <span className="text-slate-400">Pass / Full:</span>
                              <span className="font-medium text-slate-800 dark:text-slate-200">
                                {slot.passMarks} / {slot.fullMarks} Marks
                              </span>
                            </div>
                          </div>

                          <div className="flex items-center justify-end gap-1.5 pt-2 border-t border-slate-200/60 dark:border-slate-700/60">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleOpenReassignModal(slot)}
                              className="text-xs h-7 px-2"
                            >
                              Reassign
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleOpenEditModal(slot)}
                              className="text-xs h-7 px-2 text-blue-600"
                            >
                              Edit
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleOpenDeleteModal(slot)}
                              className="text-xs h-7 px-2 text-rose-600"
                            >
                              Delete
                            </Button>
                          </div>
                        </div>
                      ))}
                    </CardContent>
                  </Card>
                ))}
            </div>
          )}

          {/* TAB 3: BY ROOM MATRIX */}
          {viewTab === 'rooms' && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {Object.keys(schedulesByRoom).map((roomKey) => (
                <Card key={roomKey} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                  <CardHeader className="bg-slate-50 dark:bg-slate-800/50 py-3.5 px-4 border-b border-slate-200 dark:border-slate-800 flex flex-row items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <div className="p-2 rounded-xl bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400">
                        <Building className="w-4 h-4" />
                      </div>
                      <div>
                        <CardTitle className="text-sm font-bold text-slate-900 dark:text-white">
                          {roomKey}
                        </CardTitle>
                        <CardDescription className="text-xs">
                          {schedulesByRoom[roomKey]?.length || 0} Allocated Exam Session(s)
                        </CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="p-3.5 divide-y divide-slate-100 dark:divide-slate-800 space-y-3">
                    {(schedulesByRoom[roomKey] || []).map((item) => (
                      <div key={item.id} className="pt-2 first:pt-0 space-y-1.5">
                        <div className="flex items-start justify-between gap-1">
                          <span className="font-semibold text-slate-900 dark:text-white text-xs">
                            {item.subjectName} ({item.className})
                          </span>
                          {getStatusBadge(item.status)}
                        </div>
                        <div className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center justify-between">
                          <span>{formatDate(item.examDate)}</span>
                          <span>{item.startTime} - {item.endTime}</span>
                        </div>
                        <div className="text-[11px] text-slate-600 dark:text-slate-300">
                          Invigilator: <strong>{item.invigilatorName || 'Unassigned'}</strong>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              ))}
            </div>
          )}

          {/* TAB 4: INVIGILATOR ROSTER */}
          {viewTab === 'roster' && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {Object.keys(schedulesByTeacher).map((tKey) => {
                const group = schedulesByTeacher[tKey];
                return (
                  <Card key={tKey} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                    <CardHeader className="bg-slate-50 dark:bg-slate-800/50 py-3.5 px-4 border-b border-slate-200 dark:border-slate-800 flex flex-row items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <div className="p-2 rounded-xl bg-teal-50 dark:bg-teal-950/60 text-teal-600 dark:text-teal-400">
                          <UserCheck className="w-4 h-4" />
                        </div>
                        <div>
                          <CardTitle className="text-sm font-bold text-slate-900 dark:text-white">
                            {group.teacherName}
                          </CardTitle>
                          <CardDescription className="text-xs">
                            {group.items?.length || 0} Assigned Invigilation Duty
                          </CardDescription>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="p-3.5 divide-y divide-slate-100 dark:divide-slate-800 space-y-3">
                      {(group.items || []).map((item) => (
                        <div key={item.id} className="pt-2 first:pt-0 space-y-1.5">
                          <div className="flex items-start justify-between gap-1">
                            <span className="font-semibold text-slate-900 dark:text-white text-xs">
                              {item.subjectName} - {item.className}
                            </span>
                            {getStatusBadge(item.status)}
                          </div>
                          <div className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center justify-between">
                            <span>{formatDate(item.examDate)}</span>
                            <span>{item.startTime} - {item.endTime}</span>
                          </div>
                          <div className="text-[11px] text-slate-600 dark:text-slate-300">
                            Hall: <strong>{item.roomNumber || 'Main Examination Hall'}</strong>
                          </div>
                        </div>
                      ))}
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </>
      )}

      {/* ========================================================================= */}
      {/* MODAL 1: ADD / SCHEDULE NEW EXAM SLOT */}
      {/* ========================================================================= */}
      <Modal
        isOpen={isAddModalOpen}
        onClose={() => !isSubmitting && setIsAddModalOpen(false)}
        title="Schedule New Examination Slot"
        size="lg"
      >
        <form onSubmit={handleCreateSubmit} className="space-y-4">
          {/* Live Conflict Warning Box */}
          {liveConflicts.length > 0 && (
            <Alert variant="danger" className="space-y-1.5 animate-shake">
              <div className="flex items-center gap-2 font-bold text-xs">
                <AlertTriangle className="w-4 h-4" />
                <span>Scheduling Conflict Warning ({liveConflicts.length})</span>
              </div>
              <ul className="list-disc pl-5 text-xs space-y-0.5">
                {(liveConflicts || []).map((c, idx) => (
                  <li key={idx}>{c.message}</li>
                ))}
              </ul>
            </Alert>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Exam selection */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Select Examination <span className="text-rose-500">*</span>
              </label>
              <select
                value={formData.examId}
                onChange={(e) => handleExamChange(e.target.value)}
                className="w-full text-xs py-2 px-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 dark:text-white"
                required
              >
                <option value="">-- Choose Exam --</option>
                {(examinations || []).map((e) => (
                  <option key={e.id} value={e.id}>
                    {e.name} ({e.className || 'General'})
                  </option>
                ))}
              </select>
              {formErrors.examId && <p className="text-xs text-rose-500 mt-0.5">{formErrors.examId}</p>}
            </div>

            {/* Subject selection */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Select Subject <span className="text-rose-500">*</span>
              </label>
              <select
                value={formData.subjectId}
                onChange={(e) => setFormData((p) => ({ ...p, subjectId: e.target.value }))}
                className="w-full text-xs py-2 px-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 dark:text-white"
                required
              >
                <option value="">-- Choose Subject --</option>
                {(availableModalSubjects || []).map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name} ({s.code})
                  </option>
                ))}
              </select>
              {formErrors.subjectId && <p className="text-xs text-rose-500 mt-0.5">{formErrors.subjectId}</p>}
            </div>

            {/* Exam Date */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Exam Date <span className="text-rose-500">*</span>
              </label>
              <Input
                type="date"
                value={formData.examDate}
                onChange={(e) => setFormData((p) => ({ ...p, examDate: e.target.value }))}
                required
              />
              {formErrors.examDate && <p className="text-xs text-rose-500 mt-0.5">{formErrors.examDate}</p>}
            </div>

            {/* Room / Hall */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Room / Hall Number
              </label>
              <Input
                type="text"
                placeholder="e.g. Hall A, Room 204"
                value={formData.roomNumber}
                onChange={(e) => setFormData((p) => ({ ...p, roomNumber: e.target.value }))}
              />
            </div>

            {/* Start Time */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Start Time <span className="text-rose-500">*</span>
              </label>
              <Input
                type="text"
                placeholder="e.g. 09:00 AM or 09:00"
                value={formData.startTime}
                onChange={(e) => setFormData((p) => ({ ...p, startTime: e.target.value }))}
                required
              />
              {formErrors.startTime && <p className="text-xs text-rose-500 mt-0.5">{formErrors.startTime}</p>}
            </div>

            {/* End Time */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                End Time <span className="text-rose-500">*</span>
              </label>
              <Input
                type="text"
                placeholder="e.g. 11:30 AM or 11:30"
                value={formData.endTime}
                onChange={(e) => setFormData((p) => ({ ...p, endTime: e.target.value }))}
                required
              />
              {formErrors.endTime && <p className="text-xs text-rose-500 mt-0.5">{formErrors.endTime}</p>}
            </div>

            {/* Full Marks */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Full Marks <span className="text-rose-500">*</span>
              </label>
              <Input
                type="number"
                min={1}
                value={formData.fullMarks}
                onChange={(e) => setFormData((p) => ({ ...p, fullMarks: Number(e.target.value) }))}
                required
              />
              {formErrors.fullMarks && <p className="text-xs text-rose-500 mt-0.5">{formErrors.fullMarks}</p>}
            </div>

            {/* Pass Marks */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Pass Marks <span className="text-rose-500">*</span>
              </label>
              <Input
                type="number"
                min={0}
                value={formData.passMarks}
                onChange={(e) => setFormData((p) => ({ ...p, passMarks: Number(e.target.value) }))}
                required
              />
              {formErrors.passMarks && <p className="text-xs text-rose-500 mt-0.5">{formErrors.passMarks}</p>}
            </div>

            {/* Invigilator Teacher */}
            <div className="md:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Assigned Faculty / Invigilator
              </label>
              <select
                value={formData.invigilatorTeacherId}
                onChange={(e) => setFormData((p) => ({ ...p, invigilatorTeacherId: e.target.value }))}
                className="w-full text-xs py-2 px-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 dark:text-white"
              >
                <option value="">-- No Invigilator Assigned (TBD) --</option>
                {(teachers || []).map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.name} ({t.designation})
                  </option>
                ))}
              </select>
            </div>

            {/* Instructions */}
            <div className="md:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Candidate Special Instructions
              </label>
              <Input
                type="text"
                placeholder="e.g. Scientific calculators allowed. Bring student ID."
                value={formData.instructions}
                onChange={(e) => setFormData((p) => ({ ...p, instructions: e.target.value }))}
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
            <Button
              type="button"
              variant="outline"
              onClick={() => setIsAddModalOpen(false)}
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              variant="primary"
              disabled={isSubmitting || liveConflicts.length > 0}
              className="gap-2"
            >
              {isSubmitting ? (
                <>
                  <LoadingSpinner size="sm" />
                  <span>Validating & Saving...</span>
                </>
              ) : (
                <>
                  <Check className="w-4 h-4" />
                  <span>Confirm Schedule</span>
                </>
              )}
            </Button>
          </div>
        </form>
      </Modal>

      {/* ========================================================================= */}
      {/* MODAL 2: EDIT SCHEDULE SLOT */}
      {/* ========================================================================= */}
      <Modal
        isOpen={isEditModalOpen}
        onClose={() => !isSubmitting && setIsEditModalOpen(false)}
        title={`Edit Schedule: ${selectedSchedule?.subjectName || ''}`}
        size="lg"
      >
        <form onSubmit={handleUpdateSubmit} className="space-y-4">
          {/* Live Conflict Warning Box */}
          {liveConflicts.length > 0 && (
            <Alert variant="danger" className="space-y-1.5 animate-shake">
              <div className="flex items-center gap-2 font-bold text-xs">
                <AlertTriangle className="w-4 h-4" />
                <span>Scheduling Conflict Warning ({liveConflicts.length})</span>
              </div>
              <ul className="list-disc pl-5 text-xs space-y-0.5">
                {(liveConflicts || []).map((c, idx) => (
                  <li key={idx}>{c.message}</li>
                ))}
              </ul>
            </Alert>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Exam Date */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Exam Date <span className="text-rose-500">*</span>
              </label>
              <Input
                type="date"
                value={formData.examDate}
                onChange={(e) => setFormData((p) => ({ ...p, examDate: e.target.value }))}
                required
              />
              {formErrors.examDate && <p className="text-xs text-rose-500 mt-0.5">{formErrors.examDate}</p>}
            </div>

            {/* Room / Hall */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Room / Hall Number
              </label>
              <Input
                type="text"
                placeholder="e.g. Hall A, Room 204"
                value={formData.roomNumber}
                onChange={(e) => setFormData((p) => ({ ...p, roomNumber: e.target.value }))}
              />
            </div>

            {/* Start Time */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Start Time <span className="text-rose-500">*</span>
              </label>
              <Input
                type="text"
                placeholder="e.g. 09:00 AM or 09:00"
                value={formData.startTime}
                onChange={(e) => setFormData((p) => ({ ...p, startTime: e.target.value }))}
                required
              />
            </div>

            {/* End Time */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                End Time <span className="text-rose-500">*</span>
              </label>
              <Input
                type="text"
                placeholder="e.g. 11:30 AM or 11:30"
                value={formData.endTime}
                onChange={(e) => setFormData((p) => ({ ...p, endTime: e.target.value }))}
                required
              />
            </div>

            {/* Full Marks */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Full Marks <span className="text-rose-500">*</span>
              </label>
              <Input
                type="number"
                min={1}
                value={formData.fullMarks}
                onChange={(e) => setFormData((p) => ({ ...p, fullMarks: Number(e.target.value) }))}
                required
              />
            </div>

            {/* Pass Marks */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Pass Marks <span className="text-rose-500">*</span>
              </label>
              <Input
                type="number"
                min={0}
                value={formData.passMarks}
                onChange={(e) => setFormData((p) => ({ ...p, passMarks: Number(e.target.value) }))}
                required
              />
            </div>

            {/* Status */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Slot Status
              </label>
              <select
                value={formData.status}
                onChange={(e) => setFormData((p) => ({ ...p, status: e.target.value as ExamStatus }))}
                className="w-full text-xs py-2 px-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 dark:text-white"
              >
                <option value="scheduled">Scheduled</option>
                <option value="ongoing">Ongoing</option>
                <option value="completed">Completed</option>
                <option value="postponed">Postponed</option>
                <option value="cancelled">Cancelled</option>
              </select>
            </div>

            {/* Invigilator Teacher */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Assigned Faculty / Invigilator
              </label>
              <select
                value={formData.invigilatorTeacherId}
                onChange={(e) => setFormData((p) => ({ ...p, invigilatorTeacherId: e.target.value }))}
                className="w-full text-xs py-2 px-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 dark:text-white"
              >
                <option value="">-- No Invigilator Assigned (TBD) --</option>
                {(teachers || []).map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.name} ({t.designation})
                  </option>
                ))}
              </select>
            </div>

            {/* Instructions */}
            <div className="md:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Candidate Special Instructions
              </label>
              <Input
                type="text"
                placeholder="e.g. Scientific calculators allowed. Bring student ID."
                value={formData.instructions}
                onChange={(e) => setFormData((p) => ({ ...p, instructions: e.target.value }))}
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
            <Button
              type="button"
              variant="outline"
              onClick={() => setIsEditModalOpen(false)}
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              variant="primary"
              disabled={isSubmitting || liveConflicts.length > 0}
              className="gap-2"
            >
              {isSubmitting ? (
                <>
                  <LoadingSpinner size="sm" />
                  <span>Updating Slot...</span>
                </>
              ) : (
                <>
                  <Check className="w-4 h-4" />
                  <span>Save Changes</span>
                </>
              )}
            </Button>
          </div>
        </form>
      </Modal>

      {/* ========================================================================= */}
      {/* MODAL 3: REASSIGN INVIGILATOR */}
      {/* ========================================================================= */}
      <Modal
        isOpen={isReassignModalOpen}
        onClose={() => !isSubmitting && setIsReassignModalOpen(false)}
        title="Assign / Reassign Faculty Invigilator"
        size="md"
      >
        <div className="space-y-4">
          <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-xl space-y-1 text-xs">
            <p>
              Exam: <strong className="text-slate-900 dark:text-white">{selectedSchedule?.examName}</strong>
            </p>
            <p>
              Subject: <strong className="text-slate-900 dark:text-white">{selectedSchedule?.subjectName} ({selectedSchedule?.subjectCode})</strong>
            </p>
            <p>
              Slot: <strong className="text-slate-900 dark:text-white">{selectedSchedule?.examDate} ({selectedSchedule?.startTime} - {selectedSchedule?.endTime})</strong> in <strong className="text-slate-900 dark:text-white">{selectedSchedule?.roomNumber || 'Main Hall'}</strong>
            </p>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Select Faculty Member
            </label>
            <select
              value={selectedTeacherId}
              onChange={(e) => setSelectedTeacherId(e.target.value)}
              className="w-full text-xs py-2 px-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 dark:text-white"
            >
              <option value="">-- Remove Invigilator / Unassigned --</option>
              {(teachers || []).map((t) => (
                <option key={t.id} value={t.id}>
                  {t.name} — {t.designation} ({t.department})
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
            <Button
              type="button"
              variant="outline"
              onClick={() => setIsReassignModalOpen(false)}
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button
              type="button"
              variant="primary"
              onClick={handleReassignSubmit}
              disabled={isSubmitting}
              className="gap-2"
            >
              {isSubmitting ? <LoadingSpinner size="sm" /> : <UserCheck className="w-4 h-4" />}
              <span>Save Assignment</span>
            </Button>
          </div>
        </div>
      </Modal>

      {/* ========================================================================= */}
      {/* MODAL 4: CHANGE STATUS */}
      {/* ========================================================================= */}
      <Modal
        isOpen={isStatusModalOpen}
        onClose={() => !isSubmitting && setIsStatusModalOpen(false)}
        title="Update Schedule Status"
        size="sm"
      >
        <div className="space-y-4">
          <p className="text-xs text-slate-600 dark:text-slate-300">
            Change execution status for{' '}
            <strong className="text-slate-900 dark:text-white">{selectedSchedule?.subjectName}</strong> on{' '}
            {selectedSchedule?.examDate}:
          </p>

          <div className="space-y-2">
            {(['scheduled', 'ongoing', 'completed', 'postponed', 'cancelled'] as ExamStatus[]).map((st) => (
              <label
                key={st}
                className={`flex items-center justify-between p-2.5 rounded-xl border cursor-pointer text-xs font-medium transition-all ${
                  targetStatus === st
                    ? 'border-indigo-500 bg-indigo-50/50 dark:bg-indigo-950/40 text-indigo-900 dark:text-indigo-200'
                    : 'border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300'
                }`}
              >
                <div className="flex items-center gap-2">
                  <input
                    type="radio"
                    name="targetStatus"
                    value={st}
                    checked={targetStatus === st}
                    onChange={() => setTargetStatus(st)}
                    className="text-indigo-600 focus:ring-indigo-500"
                  />
                  <span className="capitalize">{st}</span>
                </div>
                {getStatusBadge(st)}
              </label>
            ))}
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
            <Button
              type="button"
              variant="outline"
              onClick={() => setIsStatusModalOpen(false)}
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button
              type="button"
              variant="primary"
              onClick={handleStatusSubmit}
              disabled={isSubmitting}
              className="gap-2"
            >
              {isSubmitting ? <LoadingSpinner size="sm" /> : <Check className="w-4 h-4" />}
              <span>Apply Status</span>
            </Button>
          </div>
        </div>
      </Modal>

      {/* ========================================================================= */}
      {/* MODAL 5: DELETE SLOT CONFIRMATION */}
      {/* ========================================================================= */}
      <Modal
        isOpen={isDeleteModalOpen}
        onClose={() => !isSubmitting && setIsDeleteModalOpen(false)}
        title="Confirm Schedule Deletion"
        size="sm"
      >
        <div className="space-y-4">
          <div className="p-3 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/60 rounded-xl flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-rose-600 mt-0.5 flex-shrink-0" />
            <div className="text-xs text-rose-800 dark:text-rose-200">
              <p className="font-bold">Permanent Removal</p>
              <p className="mt-0.5">
                Are you sure you want to delete the schedule slot for{' '}
                <strong>"{selectedSchedule?.subjectName}"</strong> ({selectedSchedule?.examName}) on{' '}
                {selectedSchedule?.examDate}?
              </p>
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => setIsDeleteModalOpen(false)}
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button
              type="button"
              variant="danger"
              onClick={handleDeleteSubmit}
              disabled={isSubmitting}
              className="gap-2"
            >
              {isSubmitting ? <LoadingSpinner size="sm" /> : <Trash2 className="w-4 h-4" />}
              <span>Delete Slot</span>
            </Button>
          </div>
        </div>
      </Modal>

      {/* ========================================================================= */}
      {/* MODAL 6: CONFLICT DIAGNOSTICS VIEWER */}
      {/* ========================================================================= */}
      <Modal
        isOpen={isConflictCheckModalOpen}
        onClose={() => setIsConflictCheckModalOpen(false)}
        title="Examination Timetable Conflict Diagnostic"
        size="lg"
      >
        <div className="space-y-4">
          {globalConflicts.length === 0 ? (
            <div className="py-8 text-center space-y-2">
              <div className="w-12 h-12 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 flex items-center justify-center mx-auto">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <h4 className="text-base font-bold text-slate-900 dark:text-white">
                No Schedule Conflicts Detected
              </h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 max-w-md mx-auto">
                All {schedules.length} examination slots across classes, rooms, and faculty invigilators are valid with zero concurrent overlaps.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              <p className="text-xs text-slate-600 dark:text-slate-400">
                Found <strong>{globalConflicts.length}</strong> active potential conflicts requiring administrative review:
              </p>
              <div className="space-y-2 max-h-96 overflow-y-auto pr-1">
                {(globalConflicts || []).map((c, i) => (
                  <div
                    key={i}
                    className="p-3.5 rounded-xl border border-amber-300 dark:border-amber-700 bg-amber-50/50 dark:bg-amber-950/30 space-y-2 text-xs"
                  >
                    <div className="flex items-center gap-2 font-bold text-amber-900 dark:text-amber-200">
                      <ShieldAlert className="w-4 h-4 text-amber-600" />
                      <span>{(c.type || 'CONFLICT').replace(/_/g, ' ')}</span>
                    </div>
                    <p className="text-slate-700 dark:text-slate-300">{c.message}</p>
                    <div className="flex items-center gap-2 pt-1">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          setIsConflictCheckModalOpen(false);
                          handleOpenEditModal(c.item1);
                        }}
                        className="text-[11px] h-6 px-2 text-indigo-600"
                      >
                        Edit "{c.item1.subjectName}"
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          setIsConflictCheckModalOpen(false);
                          handleOpenEditModal(c.item2);
                        }}
                        className="text-[11px] h-6 px-2 text-indigo-600"
                      >
                        Edit "{c.item2.subjectName}"
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="flex items-center justify-end pt-3 border-t border-slate-100 dark:border-slate-800">
            <Button
              type="button"
              variant="outline"
              onClick={() => setIsConflictCheckModalOpen(false)}
            >
              Close Diagnostic
            </Button>
          </div>
        </div>
      </Modal>

      {/* ========================================================================= */}
      {/* MODAL 7: PRINT / ADMIT CARD PREVIEW */}
      {/* ========================================================================= */}
      <Modal
        isOpen={isPrintModalOpen}
        onClose={() => setIsPrintModalOpen(false)}
        title="Official Examination Master Timetable"
        size="lg"
      >
        <div className="space-y-4">
          <div className="border border-slate-200 dark:border-slate-700 rounded-2xl p-6 bg-white dark:bg-slate-900 text-slate-900 dark:text-white space-y-4">
            <div className="text-center border-b pb-4 border-slate-100 dark:border-slate-800">
              <h3 className="text-lg font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
                Official Examination Timetable & Hall Schedule
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Academic Session: {(academicSessions || []).find((s) => s?.isActive)?.name || 'Current'} • Generated on {new Date().toLocaleDateString()}
              </p>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-700 font-bold text-slate-500">
                    <th className="py-2 px-2">Date & Time</th>
                    <th className="py-2 px-2">Subject</th>
                    <th className="py-2 px-2">Class</th>
                    <th className="py-2 px-2">Exam Hall</th>
                    <th className="py-2 px-2">Invigilator</th>
                    <th className="py-2 px-2 text-right">Marks</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {(schedules || []).map((s) => (
                    <tr key={s.id}>
                      <td className="py-2 px-2 font-medium">
                        {formatDate(s.examDate)} <br />
                        <span className="text-slate-400 font-normal">{s.startTime} - {s.endTime}</span>
                      </td>
                      <td className="py-2 px-2">
                        <strong>{s.subjectName}</strong> <br />
                        <span className="text-slate-400">({s.subjectCode})</span>
                      </td>
                      <td className="py-2 px-2">{s.className}</td>
                      <td className="py-2 px-2">{s.roomNumber || 'Main Hall'}</td>
                      <td className="py-2 px-2">{s.invigilatorName || 'Assigned Faculty'}</td>
                      <td className="py-2 px-2 text-right">{s.passMarks} / {s.fullMarks}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="text-[11px] text-slate-400 pt-3 border-t border-slate-100 dark:border-slate-800 flex justify-between">
              <span>Verified by Examination Controller & Academic Dean</span>
              <span>Official School Timetable</span>
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-2">
            <Button variant="outline" onClick={() => setIsPrintModalOpen(false)}>
              Close
            </Button>
            <Button
              variant="primary"
              onClick={() => {
                window.print();
              }}
              className="gap-2"
            >
              <Printer className="w-4 h-4" />
              Print / Save PDF
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
