import React, { useEffect, useState, useCallback, useMemo } from 'react';
import {
  BarChart3,
  TrendingUp,
  BookOpen,
  User,
  Users,
  Award,
  Calendar,
  Layers,
  Search,
  Filter,
  RefreshCw,
  Printer,
  Download,
  CheckCircle2,
  AlertCircle,
  AlertTriangle,
  GraduationCap,
  Sparkles,
  ChevronRight,
  TrendingDown,
  Minus,
  FileSpreadsheet
} from 'lucide-react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '../ui/Card.js';
import { Button } from '../ui/Button.js';
import { Badge } from '../ui/Badge.js';
import { Alert } from '../ui/Alert.js';
import { Input } from '../ui/Input.js';
import { Select } from '../ui/Select.js';
import { LoadingSpinner } from '../ui/LoadingSpinner.js';
import { EmptyState } from '../ui/EmptyState.js';
import { useToast } from '../../context/ToastContext.js';
import { api } from '../../services/api.js';
import {
  ClassResultSummaryData,
  SubjectPerformanceReportResponse,
  StudentPerformanceHistoryResponse,
  AcademicSession,
  SchoolClass,
  Section,
  Examination,
  Subject
} from '../../types/index.js';

export const AcademicReportsDashboardView: React.FC = () => {
  const { addToast } = useToast();

  // Active Sub-Report Tab
  const [activeReportTab, setActiveReportTab] = useState<'class-summary' | 'subject-performance' | 'student-trajectory'>('class-summary');

  // Shared Filters
  const [filterSession, setFilterSession] = useState<string>('ALL');
  const [filterExam, setFilterExam] = useState<string>('ALL');
  const [filterClass, setFilterClass] = useState<string>('ALL');
  const [filterSection, setFilterSection] = useState<string>('ALL');
  const [filterSubject, setFilterSubject] = useState<string>('ALL');
  const [selectedStudentId, setSelectedStudentId] = useState<string>('');

  // Loaded Report Data States
  const [classSummary, setClassSummary] = useState<ClassResultSummaryData | null>(null);
  const [subjectReport, setSubjectReport] = useState<SubjectPerformanceReportResponse | null>(null);
  const [studentHistory, setStudentHistory] = useState<StudentPerformanceHistoryResponse | null>(null);

  // Loading States
  const [loading, setLoading] = useState<boolean>(true);
  const [refreshing, setRefreshing] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // Metadata dropdowns
  const [availableSessions, setAvailableSessions] = useState<Array<{ id: string; name: string }>>([]);
  const [availableExams, setAvailableExams] = useState<Array<{ id: string; name: string; type?: string; className?: string }>>([]);
  const [availableClasses, setAvailableClasses] = useState<Array<{ id: string; name: string }>>([]);
  const [availableSections, setAvailableSections] = useState<Array<{ id: string; name: string; classId?: string }>>([]);
  const [availableSubjects, setAvailableSubjects] = useState<Array<{ id: string; name: string }>>([]);
  const [availableStudents, setAvailableStudents] = useState<Array<{ id: string; name: string; admissionNumber?: string; className?: string }>>([]);

  // Load Metadata
  const loadMetadata = useCallback(async () => {
    try {
      const [sessionsRes, examsRes, classesRes, sectionsRes, subjectsRes, studentsRes] = await Promise.all([
        api.academic.getSessions(),
        api.examinations.getExaminations(),
        api.academic.getClasses(),
        api.academic.getSections(),
        api.academic.getSubjects(),
        api.users.getStudents({ limit: 100 } as any)
      ]);

      if (sessionsRes.success && sessionsRes.data) {
        const raw = Array.isArray(sessionsRes.data) ? sessionsRes.data : (sessionsRes.data as any).data || [];
        setAvailableSessions(raw.map((s: AcademicSession) => ({ id: s.id, name: s.name || s.id })));
      }
      if (examsRes.success && examsRes.data) {
        const rawList = Array.isArray(examsRes.data) ? examsRes.data : (examsRes.data as any).data || [];
        setAvailableExams(rawList.map((e: Examination) => ({ id: e.id, name: e.name, type: e.examType, className: e.className })));
        if (rawList.length > 0 && filterExam === 'ALL') {
          setFilterExam(rawList?.[0]?.id || '');
        }
      }
      if (classesRes.success && classesRes.data) {
        const raw = Array.isArray(classesRes.data) ? classesRes.data : (classesRes.data as any).data || [];
        setAvailableClasses(raw.map((c: SchoolClass) => ({ id: c.id, name: c.name })));
      }
      if (sectionsRes.success && sectionsRes.data) {
        const raw = Array.isArray(sectionsRes.data) ? sectionsRes.data : (sectionsRes.data as any).data || [];
        setAvailableSections(raw.map((s: Section) => ({ id: s.id, name: s.name, classId: s.classId })));
      }
      if (subjectsRes.success && subjectsRes.data) {
        const raw = Array.isArray(subjectsRes.data) ? subjectsRes.data : (subjectsRes.data as any).data || [];
        setAvailableSubjects(raw.map((sub: Subject) => ({ id: sub.id, name: sub.name })));
      }
      if (studentsRes.success && studentsRes.data) {
        const raw = Array.isArray(studentsRes.data) ? studentsRes.data : (studentsRes.data as any).data || [];
        const list = raw.map((st: any) => ({
          id: st.id,
          name: st.name || `${st.firstName || ''} ${st.lastName || ''}`.trim() || 'Student',
          admissionNumber: st.admissionNumber,
          className: st.className
        }));
        setAvailableStudents(list);
        if (list.length > 0 && !selectedStudentId) {
          setSelectedStudentId(list?.[0]?.id || '');
        }
      }
    } catch (err: any) {
      console.error('Error loading academic reports metadata:', err);
    }
  }, [filterExam, selectedStudentId]);

  // Fetch Class Summary Report
  const fetchClassSummary = useCallback(async (isSilent = false) => {
    if (!isSilent) setLoading(true);
    else setRefreshing(true);
    setError(null);

    try {
      const params: any = {};
      if (filterSession !== 'ALL') params.academicSessionId = filterSession;
      if (filterExam !== 'ALL') params.examId = filterExam;
      if (filterClass !== 'ALL') params.classId = filterClass;
      if (filterSection !== 'ALL') params.sectionId = filterSection;

      const res = await api.examinations.getClassResultSummary(params);
      if (res.success && res.data) {
        setClassSummary(res.data);
      } else {
        setError(res.error || 'Failed to load class summary report.');
      }
    } catch (err: any) {
      setError(err?.message || 'Network error fetching class summary.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [filterSession, filterExam, filterClass, filterSection]);

  // Fetch Subject Performance Report
  const fetchSubjectReport = useCallback(async (isSilent = false) => {
    if (!isSilent) setLoading(true);
    else setRefreshing(true);
    setError(null);

    try {
      const params: any = {};
      if (filterSession !== 'ALL') params.academicSessionId = filterSession;
      if (filterExam !== 'ALL') params.examId = filterExam;
      if (filterClass !== 'ALL') params.classId = filterClass;
      if (filterSection !== 'ALL') params.sectionId = filterSection;
      if (filterSubject !== 'ALL') params.subjectId = filterSubject;

      const res = await api.examinations.getSubjectPerformanceReport(params);
      if (res.success && res.data) {
        setSubjectReport(res.data);
      } else {
        setError(res.error || 'Failed to load subject performance report.');
      }
    } catch (err: any) {
      setError(err?.message || 'Network error fetching subject report.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [filterSession, filterExam, filterClass, filterSection, filterSubject]);

  // Fetch Student Performance History
  const fetchStudentHistory = useCallback(async (isSilent = false) => {
    if (!selectedStudentId) return;
    if (!isSilent) setLoading(true);
    else setRefreshing(true);
    setError(null);

    try {
      const res = await api.examinations.getStudentPerformanceHistory(selectedStudentId);
      if (res.success && res.data) {
        setStudentHistory(res.data);
      } else {
        setError(res.error || 'Failed to load student performance trajectory.');
      }
    } catch (err: any) {
      setError(err?.message || 'Network error fetching student trajectory.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [selectedStudentId]);

  useEffect(() => {
    loadMetadata();
  }, [loadMetadata]);

  useEffect(() => {
    if (activeReportTab === 'class-summary') {
      fetchClassSummary();
    } else if (activeReportTab === 'subject-performance') {
      fetchSubjectReport();
    } else if (activeReportTab === 'student-trajectory') {
      fetchStudentHistory();
    }
  }, [activeReportTab, fetchClassSummary, fetchSubjectReport, fetchStudentHistory]);

  const filteredSections = useMemo(() => {
    if (filterClass === 'ALL') return availableSections;
    return availableSections.filter((s) => !s.classId || s.classId === filterClass);
  }, [availableSections, filterClass]);

  return (
    <div className="space-y-6">
      {/* Sub-Navigation for Academic Reports */}
      <div className="flex items-center gap-2 border-b border-white/10 pb-4 flex-wrap">
        <button
          type="button"
          onClick={() => setActiveReportTab('class-summary')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            activeReportTab === 'class-summary'
              ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
              : 'bg-slate-900/60 text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <BarChart3 className="w-3.5 h-3.5" />
          <span>Class Summary & Grade Distribution</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveReportTab('subject-performance')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            activeReportTab === 'subject-performance'
              ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
              : 'bg-slate-900/60 text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <BookOpen className="w-3.5 h-3.5" />
          <span>Subject Performance & Difficulty Index</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveReportTab('student-trajectory')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            activeReportTab === 'student-trajectory'
              ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
              : 'bg-slate-900/60 text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <TrendingUp className="w-3.5 h-3.5" />
          <span>Student Progress Trajectory & Trends</span>
        </button>
      </div>

      {/* Filter Toolbar */}
      <Card className="border-white/10 bg-slate-900/60 backdrop-blur-sm">
        <CardContent className="p-4 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-3">
            <div>
              <label className="text-xs font-semibold text-slate-400 block mb-1">Academic Session</label>
              <Select
                value={filterSession}
                onChange={(e) => setFilterSession(e.target.value)}
                className="w-full text-xs"
              >
                <option value="ALL">All Academic Sessions</option>
                {(availableSessions || []).map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </Select>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-400 block mb-1">Target Examination</label>
              <Select
                value={filterExam}
                onChange={(e) => setFilterExam(e.target.value)}
                className="w-full text-xs"
              >
                <option value="ALL">All Examinations</option>
                {(availableExams || []).map((e) => (
                  <option key={e.id} value={e.id}>
                    {e.name} {e.className ? `(${e.className})` : ''}
                  </option>
                ))}
              </Select>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-400 block mb-1">Class Filter</label>
              <Select
                value={filterClass}
                onChange={(e) => {
                  setFilterClass(e.target.value);
                  setFilterSection('ALL');
                }}
                className="w-full text-xs"
              >
                <option value="ALL">All Classes</option>
                {(availableClasses || []).map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </Select>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-400 block mb-1">Section Filter</label>
              <Select
                value={filterSection}
                onChange={(e) => setFilterSection(e.target.value)}
                className="w-full text-xs"
              >
                <option value="ALL">All Sections</option>
                {(filteredSections || []).map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </Select>
            </div>

            {activeReportTab === 'subject-performance' ? (
              <div>
                <label className="text-xs font-semibold text-slate-400 block mb-1">Subject</label>
                <Select
                  value={filterSubject}
                  onChange={(e) => setFilterSubject(e.target.value)}
                  className="w-full text-xs"
                >
                  <option value="ALL">All Subjects</option>
                  {(availableSubjects || []).map((sub) => (
                    <option key={sub.id} value={sub.id}>
                      {sub.name}
                    </option>
                  ))}
                </Select>
              </div>
            ) : activeReportTab === 'student-trajectory' ? (
              <div>
                <label className="text-xs font-semibold text-slate-400 block mb-1">Select Student *</label>
                <Select
                  value={selectedStudentId}
                  onChange={(e) => setSelectedStudentId(e.target.value)}
                  className="w-full text-xs border-indigo-500/40"
                >
                  {(availableStudents || []).map((st) => (
                    <option key={st.id} value={st.id}>
                      {st.name} ({st.className || 'Grade'}) #{st.admissionNumber || st.id.slice(0, 4)}
                    </option>
                  ))}
                </Select>
              </div>
            ) : (
              <div className="flex items-end">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => window.print()}
                  className="w-full h-9 text-xs text-slate-300 hover:text-white"
                >
                  <Printer className="w-3.5 h-3.5 mr-1.5" />
                  Print Report
                </Button>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* ========================================================================= */}
      {/* 1. CLASS SUMMARY & GRADE DISTRIBUTION VIEW                                */}
      {/* ========================================================================= */}
      {activeReportTab === 'class-summary' && (
        <div className="space-y-6">
          {loading ? (
            <div className="py-16 text-center">
              <LoadingSpinner size="lg" />
              <p className="text-xs text-slate-400 mt-2">Computing class aggregates...</p>
            </div>
          ) : !classSummary || classSummary.totalStudents === 0 ? (
            <Card className="border-white/10 bg-slate-900/60 p-12 text-center">
              <EmptyState
                icon={BarChart3}
                title="No Class Summary Available"
                description="No approved results match the selected filter combination."
              />
            </Card>
          ) : (
            <>
              {/* Telemetry Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-3">
                <div className="p-4 rounded-2xl bg-slate-900/60 border border-white/10">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Appeared</span>
                  <span className="text-2xl font-bold text-white mt-1 block">{classSummary.appearedStudents}</span>
                  <span className="text-[11px] text-slate-500">of {classSummary.totalStudents} enrolled</span>
                </div>

                <div className="p-4 rounded-2xl bg-slate-900/60 border border-white/10">
                  <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider block">Pass Rate</span>
                  <span className="text-2xl font-bold text-emerald-400 mt-1 block">{classSummary.passPercentage}%</span>
                  <span className="text-[11px] text-slate-400">{classSummary.passedCount} students passed</span>
                </div>

                <div className="p-4 rounded-2xl bg-slate-900/60 border border-white/10">
                  <span className="text-[10px] font-bold text-amber-400 uppercase tracking-wider block">Distinctions</span>
                  <span className="text-2xl font-bold text-amber-300 mt-1 block">{classSummary.distinctionCount}</span>
                  <span className="text-[11px] text-slate-400">GPA ≥ 3.75</span>
                </div>

                <div className="p-4 rounded-2xl bg-slate-900/60 border border-white/10">
                  <span className="text-[10px] font-bold text-rose-400 uppercase tracking-wider block">Failed</span>
                  <span className="text-2xl font-bold text-rose-400 mt-1 block">{classSummary.failedCount}</span>
                  <span className="text-[11px] text-slate-400">{classSummary.failPercentage}% fail rate</span>
                </div>

                <div className="p-4 rounded-2xl bg-slate-900/60 border border-white/10">
                  <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-wider block">Average GPA</span>
                  <span className="text-2xl font-bold text-indigo-400 mt-1 block">{Number(classSummary.averageGpa ?? 0).toFixed(2)}</span>
                  <span className="text-[11px] text-slate-400">Mean: {classSummary.averagePercentage}%</span>
                </div>

                <div className="p-4 rounded-2xl bg-slate-900/60 border border-white/10">
                  <span className="text-[10px] font-bold text-purple-400 uppercase tracking-wider block">Highest Score</span>
                  <span className="text-2xl font-bold text-purple-300 mt-1 block">{classSummary.highestScore}</span>
                  <span className="text-[11px] text-slate-400">Lowest: {classSummary.lowestScore}</span>
                </div>
              </div>

              {/* Grade Distribution Histogram & Status Split */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Grade Distribution Bar Chart */}
                <Card className="lg:col-span-2 border-white/10 bg-slate-900/60">
                  <CardHeader className="pb-2 border-b border-white/10">
                    <CardTitle className="text-sm text-white flex items-center gap-2">
                      <BarChart3 className="w-4 h-4 text-indigo-400" />
                      Grade Distribution Breakdown
                    </CardTitle>
                    <CardDescription className="text-xs text-slate-400">
                      Frequency histogram across overall letter grades
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="p-6 space-y-4">
                    {(classSummary.gradeDistribution || []).map((item) => {
                      const maxCount = Math.max(...(classSummary.gradeDistribution || []).map((g) => g.count), 1);
                      const barWidth = `${(item.count / maxCount) * 100}%`;

                      return (
                        <div key={item.grade} className="space-y-1.5 text-xs">
                          <div className="flex justify-between items-center">
                            <div className="flex items-center gap-2 font-bold text-white">
                              <span className="w-8 px-1.5 py-0.5 rounded bg-slate-800 border border-white/10 text-center font-mono">
                                {item.grade}
                              </span>
                              <span className="text-slate-400 font-normal">
                                ({item.count} students)
                              </span>
                            </div>
                            <span className="font-mono font-bold text-slate-300">{item.percentage}%</span>
                          </div>
                          <div className="w-full bg-slate-800 rounded-full h-3 overflow-hidden">
                            <div
                              className={`h-3 rounded-full transition-all ${
                                item.grade === 'A+' || item.grade === 'A'
                                  ? 'bg-emerald-500'
                                  : item.grade === 'B+' || item.grade === 'B'
                                  ? 'bg-sky-500'
                                  : item.grade === 'C'
                                  ? 'bg-amber-500'
                                  : 'bg-rose-500'
                              }`}
                              style={{ width: barWidth }}
                            />
                          </div>
                        </div>
                      );
                    })}
                  </CardContent>
                </Card>

                {/* Top 5 Scorers */}
                <Card className="border-white/10 bg-slate-900/60">
                  <CardHeader className="pb-2 border-b border-white/10">
                    <CardTitle className="text-sm text-white flex items-center gap-2">
                      <Award className="w-4 h-4 text-amber-400" />
                      Class Honor Roll (Top Scorers)
                    </CardTitle>
                    <CardDescription className="text-xs text-slate-400">
                      Highest academic performers
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="p-4 divide-y divide-white/5">
                    {(classSummary.topPerformers || []).map((st, idx) => (
                      <div key={st.studentId || idx} className="py-2.5 flex items-center justify-between text-xs">
                        <div className="flex items-center gap-2.5">
                          <span
                            className={`w-6 h-6 rounded-full flex items-center justify-center font-black text-xs ${
                              idx === 0
                                ? 'bg-amber-500 text-slate-950'
                                : idx === 1
                                ? 'bg-slate-300 text-slate-950'
                                : idx === 2
                                ? 'bg-amber-700 text-white'
                                : 'bg-slate-800 text-slate-400'
                            }`}
                          >
                            {idx + 1}
                          </span>
                          <div>
                            <span className="font-bold text-white block">{st.studentName}</span>
                            <span className="text-[10px] text-slate-400 font-mono">Roll #{st.rollNumber}</span>
                          </div>
                        </div>
                        <div className="text-right">
                          <span className="font-bold text-indigo-400 font-mono text-sm block">
                            {Number(st.gpa ?? 0).toFixed(2)} GPA
                          </span>
                          <span className="text-[10px] text-slate-400 font-mono">
                            {st.obtainedMarks} pts ({st.percentage}%)
                          </span>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </div>
            </>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* 2. SUBJECT PERFORMANCE & DIFFICULTY INDEX VIEW                            */}
      {/* ========================================================================= */}
      {activeReportTab === 'subject-performance' && (
        <div className="space-y-6">
          {loading ? (
            <div className="py-16 text-center">
              <LoadingSpinner size="lg" />
              <p className="text-xs text-slate-400 mt-2">Analyzing subject metrics...</p>
            </div>
          ) : !subjectReport || !Array.isArray(subjectReport.subjects) || (subjectReport.subjects?.length || 0) === 0 ? (
            <Card className="border-white/10 bg-slate-900/60 p-12 text-center">
              <EmptyState
                icon={BookOpen}
                title="No Subject Performance Data"
                description="No approved results found for the selected subjects."
              />
            </Card>
          ) : (
            <>
              {/* Highlight Cards: Top Subject vs Challenging Subject */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 rounded-2xl bg-indigo-500/10 border border-indigo-500/20">
                  <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-wider block">
                    Subjects Evaluated
                  </span>
                  <span className="text-2xl font-bold text-white mt-1 block">
                    {subjectReport.overallSubjectCount} Subjects
                  </span>
                  <span className="text-xs text-slate-400 mt-0.5 block">
                    Across {subjectReport.examination?.name || 'Curriculum'}
                  </span>
                </div>

                <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20">
                  <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider block">
                    Top Performing Subject
                  </span>
                  <span className="text-xl font-bold text-emerald-300 mt-1 block">
                    {subjectReport.highestPassSubject || 'Mathematics'}
                  </span>
                  <span className="text-xs text-emerald-400/80 mt-0.5 block">
                    Highest pass rate & masteries
                  </span>
                </div>

                <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20">
                  <span className="text-[10px] font-bold text-rose-400 uppercase tracking-wider block">
                    Most Challenging Subject
                  </span>
                  <span className="text-xl font-bold text-rose-300 mt-1 block">
                    {subjectReport.lowestPassSubject || 'Physics'}
                  </span>
                  <span className="text-xs text-rose-400/80 mt-0.5 block">
                    Lowest average mark (Target for tutoring)
                  </span>
                </div>
              </div>

              {/* Subject Performance Detailed Table */}
              <Card className="border-white/10 bg-slate-900/60 backdrop-blur-sm overflow-hidden">
                <CardHeader className="pb-3 border-b border-white/10">
                  <CardTitle className="text-base text-white flex items-center gap-2">
                    <BookOpen className="w-4 h-4 text-indigo-400" />
                    Subject-Wise Performance & Difficulty Matrix
                  </CardTitle>
                </CardHeader>
                <div className="overflow-x-auto">
                  <table className="w-full text-xs text-left">
                    <thead className="bg-slate-950/80 text-slate-400 uppercase tracking-wider font-semibold text-[11px] border-b border-white/10">
                      <tr>
                        <th className="py-3.5 px-4">Subject</th>
                        <th className="py-3.5 px-3">Subject Teacher</th>
                        <th className="py-3.5 px-3 text-center">Appeared</th>
                        <th className="py-3.5 px-3 text-center">Pass Rate</th>
                        <th className="py-3.5 px-3 text-center">Average Marks</th>
                        <th className="py-3.5 px-3 text-center">Highest / Lowest</th>
                        <th className="py-3.5 px-3 text-center">Avg GP</th>
                        <th className="py-3.5 px-3 text-center">Difficulty Index</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5 font-medium text-slate-300">
                      {(subjectReport.subjects || []).map((sub) => {
                        const isHighPass = sub.passPercentage >= 85;
                        const isLowPass = sub.passPercentage < 65;

                        return (
                          <tr key={sub.subjectId} className="hover:bg-white/[0.02]">
                            <td className="py-3.5 px-4">
                              <span className="font-bold text-white block">{sub.subjectName}</span>
                              <span className="text-[10px] text-slate-400 font-mono">{sub.subjectCode}</span>
                            </td>
                            <td className="py-3.5 px-3">
                              <span className="text-slate-200 block font-medium">{sub.teacherName || 'Assigned Faculty'}</span>
                            </td>
                            <td className="py-3.5 px-3 text-center font-mono">{sub.appearedCount}</td>
                            <td className="py-3.5 px-3 text-center">
                              <span
                                className={`inline-block px-2 py-0.5 rounded font-bold font-mono ${
                                  isHighPass
                                    ? 'bg-emerald-500/20 text-emerald-300'
                                    : isLowPass
                                    ? 'bg-rose-500/20 text-rose-300'
                                    : 'bg-amber-500/20 text-amber-300'
                                }`}
                              >
                                {sub.passPercentage}%
                              </span>
                            </td>
                            <td className="py-3.5 px-3 text-center font-mono font-bold text-white">
                              {Number(sub.averageMarks ?? 0).toFixed(1)} / {sub.fullMarks}
                            </td>
                            <td className="py-3.5 px-3 text-center font-mono text-slate-300">
                              <span className="text-emerald-400 font-bold">{sub.highestMarks}</span> / <span className="text-rose-400">{sub.lowestMarks}</span>
                            </td>
                            <td className="py-3.5 px-3 text-center font-mono font-black text-indigo-400">
                              {Number(sub.averageGradePoint ?? 0).toFixed(2)}
                            </td>
                            <td className="py-3.5 px-3 text-center">
                              <span
                                className={`inline-block px-2.5 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                                  sub.difficultyIndex === 'HIGH'
                                    ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                                    : sub.difficultyIndex === 'MODERATE'
                                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                                    : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                                }`}
                              >
                                {sub.difficultyIndex}
                              </span>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </Card>
            </>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* 3. STUDENT PERFORMANCE TRAJECTORY & TRENDS VIEW                           */}
      {/* ========================================================================= */}
      {activeReportTab === 'student-trajectory' && (
        <div className="space-y-6">
          {loading ? (
            <div className="py-16 text-center">
              <LoadingSpinner size="lg" />
              <p className="text-xs text-slate-400 mt-2">Compiling student academic progression...</p>
            </div>
          ) : !studentHistory ? (
            <Card className="border-white/10 bg-slate-900/60 p-12 text-center">
              <EmptyState
                icon={User}
                title="Select a Student"
                description="Choose a student from the dropdown above to inspect multi-term GPA trajectories."
              />
            </Card>
          ) : (
            <>
              {/* Student Dossier Header Banner */}
              <div className="p-5 rounded-2xl bg-gradient-to-r from-indigo-900/40 via-slate-900/90 to-slate-900/90 border border-indigo-500/30 flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-2xl bg-indigo-600 text-white font-black text-xl flex items-center justify-center shadow-lg shadow-indigo-600/30">
                    {studentHistory.student?.avatarUrl ? (
                      <img src={studentHistory.student.avatarUrl} alt={studentHistory.student?.name} className="w-full h-full object-cover rounded-2xl" />
                    ) : (
                      (studentHistory.student?.name || 'ST').slice(0, 2).toUpperCase()
                    )}
                  </div>
                  <div>
                    <h2 className="text-lg font-bold text-white">{studentHistory.student?.name}</h2>
                    <p className="text-xs text-slate-400 font-mono">
                      Adm: {studentHistory.student?.admissionNumber} • Roll #{studentHistory.student?.rollNumber} • {studentHistory.student?.className} ({studentHistory.student?.sectionName})
                    </p>
                    <p className="text-[11px] text-indigo-300 mt-0.5">
                      Parent / Guardian: {studentHistory.student?.guardianName || 'Parent'}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="p-3 bg-slate-950/80 rounded-xl border border-white/10 text-center min-w-[100px]">
                    <span className="text-[10px] text-slate-400 uppercase font-semibold block">Cumulative GPA</span>
                    <span className="text-lg font-black text-indigo-400 font-mono">
                      {Number(studentHistory.cumulativeStats?.overallCumulativeGpa ?? 0).toFixed(2)}
                    </span>
                  </div>

                  <div className="p-3 bg-slate-950/80 rounded-xl border border-white/10 text-center min-w-[100px]">
                    <span className="text-[10px] text-slate-400 uppercase font-semibold block">Trajectory</span>
                    <div className="flex items-center justify-center gap-1 mt-0.5">
                      {studentHistory.cumulativeStats?.gpaTrend === 'IMPROVING' ? (
                        <span className="text-emerald-400 font-bold flex items-center text-xs">
                          <TrendingUp className="w-3.5 h-3.5 mr-1" /> +{studentHistory.cumulativeStats?.gpaDelta}
                        </span>
                      ) : studentHistory.cumulativeStats?.gpaTrend === 'DECLINING' ? (
                        <span className="text-rose-400 font-bold flex items-center text-xs">
                          <TrendingDown className="w-3.5 h-3.5 mr-1" /> {studentHistory.cumulativeStats?.gpaDelta}
                        </span>
                      ) : (
                        <span className="text-slate-400 font-bold flex items-center text-xs">
                          <Minus className="w-3.5 h-3.5 mr-1" /> Stable
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* Chronological Exam Milestones */}
              <Card className="border-white/10 bg-slate-900/60 backdrop-blur-sm overflow-hidden">
                <CardHeader className="pb-3 border-b border-white/10">
                  <CardTitle className="text-base text-white flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-indigo-400" />
                    Chronological Examination Milestones
                  </CardTitle>
                </CardHeader>
                <div className="overflow-x-auto">
                  <table className="w-full text-xs text-left">
                    <thead className="bg-slate-950/80 text-slate-400 uppercase tracking-wider font-semibold text-[11px] border-b border-white/10">
                      <tr>
                        <th className="py-3.5 px-4">Examination</th>
                        <th className="py-3.5 px-3">Session</th>
                        <th className="py-3.5 px-3 text-center">Marks Obtained</th>
                        <th className="py-3.5 px-3 text-center">Percentage</th>
                        <th className="py-3.5 px-3 text-center">GPA</th>
                        <th className="py-3.5 px-3 text-center">Grade</th>
                        <th className="py-3.5 px-3 text-center">Class Rank</th>
                        <th className="py-3.5 px-3 text-center">Standing</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5 font-medium text-slate-300">
                      {(studentHistory.examHistory || []).map((exam) => (
                        <tr key={exam.examId} className="hover:bg-white/[0.02]">
                          <td className="py-3.5 px-4 font-bold text-white">
                            {exam.examName}
                            <span className="text-[10px] text-slate-400 block font-normal">{exam.examType}</span>
                          </td>
                          <td className="py-3.5 px-3 font-mono">{exam.academicSessionName}</td>
                          <td className="py-3.5 px-3 text-center font-mono font-bold text-white">
                            {exam.totalObtainedMarks} / {exam.totalFullMarks}
                          </td>
                          <td className="py-3.5 px-3 text-center font-mono">{exam.overallPercentage}%</td>
                          <td className="py-3.5 px-3 text-center font-mono font-black text-indigo-400 text-sm">
                            {Number(exam.gpa ?? 0).toFixed(2)}
                          </td>
                          <td className="py-3.5 px-3 text-center font-bold text-white">
                            <span className="px-2 py-0.5 bg-slate-800 border border-white/10 rounded">
                              {exam.overallGrade}
                            </span>
                          </td>
                          <td className="py-3.5 px-3 text-center font-mono">
                            {exam.classRank ? `#${exam.classRank}` : '-'}
                          </td>
                          <td className="py-3.5 px-3 text-center">
                            <Badge
                              variant={exam.resultStatus === 'FAILED' ? 'danger' : 'success'}
                              className={
                                exam.resultStatus === 'DISTINCTION'
                                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                                  : exam.resultStatus === 'FAILED'
                                  ? 'bg-rose-500/20 text-rose-300 border-rose-500/30'
                                  : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                              }
                            >
                              {exam.resultStatus}
                            </Badge>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </Card>

              {/* Subject Progression Matrix */}
              <Card className="border-white/10 bg-slate-900/60 backdrop-blur-sm overflow-hidden">
                <CardHeader className="pb-3 border-b border-white/10">
                  <CardTitle className="text-base text-white flex items-center gap-2">
                    <BookOpen className="w-4 h-4 text-indigo-400" />
                    Subject Mastery & Progression Across Terms
                  </CardTitle>
                </CardHeader>
                <div className="p-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {(studentHistory.subjectTrends || []).map((st) => (
                    <div key={st.subjectName} className="p-4 rounded-xl bg-slate-950/60 border border-white/10 space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="font-bold text-white text-sm">{st.subjectName}</span>
                        <Badge
                          variant="neutral"
                          className={
                            st.trend === 'IMPROVING'
                              ? 'bg-emerald-500/20 text-emerald-300'
                              : st.trend === 'DECLINING'
                              ? 'bg-rose-500/20 text-rose-300'
                              : 'bg-slate-800 text-slate-300'
                          }
                        >
                          {st.trend}
                        </Badge>
                      </div>
                      <div className="flex justify-between items-center text-xs font-mono">
                        <span className="text-slate-400">Avg Marks:</span>
                        <span className="font-bold text-white">{Number(st.averageMarks ?? 0).toFixed(1)} pts</span>
                      </div>
                      <div className="flex justify-between items-center text-xs font-mono">
                        <span className="text-slate-400">Avg Grade Point:</span>
                        <span className="font-bold text-indigo-400">{Number(st.averageGradePoint ?? 0).toFixed(2)} GP</span>
                      </div>
                      <div className="pt-2 border-t border-white/5 flex gap-1 items-end h-10">
                        {(st.examScores || []).map((sc, sidx) => (
                          <div key={sidx} className="flex-1 flex flex-col items-center gap-1">
                            <div
                              className="w-full bg-indigo-500/60 rounded-t"
                              style={{ height: `${Math.max(15, (sc.obtainedMarks / 100) * 30)}px` }}
                              title={`${sc.examName}: ${sc.obtainedMarks} (${sc.grade})`}
                            />
                            <span className="text-[9px] text-slate-400 font-mono">{sc.grade}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            </>
          )}
        </div>
      )}
    </div>
  );
};
