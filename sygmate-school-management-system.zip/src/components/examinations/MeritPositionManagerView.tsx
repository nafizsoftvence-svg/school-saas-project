import React, { useEffect, useState, useCallback, useMemo } from 'react';
import {
  Award,
  Crown,
  Medal,
  Settings,
  RefreshCw,
  Search,
  Filter,
  ArrowUpDown,
  Download,
  Printer,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  Users,
  ChevronRight,
  TrendingUp,
  Layers,
  GraduationCap,
  Save,
  Check,
  Eye,
  Sliders
} from 'lucide-react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '../ui/Card.js';
import { Button } from '../ui/Button.js';
import { Badge } from '../ui/Badge.js';
import { Alert } from '../ui/Alert.js';
import { Modal } from '../ui/Modal.js';
import { Input } from '../ui/Input.js';
import { Select } from '../ui/Select.js';
import { LoadingSpinner } from '../ui/LoadingSpinner.js';
import { EmptyState } from '../ui/EmptyState.js';
import { useToast } from '../../context/ToastContext.js';
import { downloadTablePdf, triggerSafePrint } from '../../utils/printPdf.js';
import { api } from '../../services/api.js';
import {
  MeritRankingConfig,
  MeritRankItem,
  MeritListResponse,
  ReportCardDetail,
  AcademicSession,
  SchoolClass,
  Section,
  Examination
} from '../../types/index.js';
import { ReportCardPrintModal } from './ReportCardPrintModal.js';

export const MeritPositionManagerView: React.FC = () => {
  const { addToast } = useToast();

  // Filter States
  const [filterSession, setFilterSession] = useState<string>('ALL');
  const [filterExam, setFilterExam] = useState<string>('ALL');
  const [filterClass, setFilterClass] = useState<string>('ALL');
  const [filterSection, setFilterSection] = useState<string>('ALL');
  const [includeUnpublished, setIncludeUnpublished] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Data States
  const [meritData, setMeritData] = useState<MeritListResponse | null>(null);
  const [meritConfig, setMeritConfig] = useState<MeritRankingConfig | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [refreshing, setRefreshing] = useState<boolean>(false);
  const [calculating, setCalculating] = useState<boolean>(false);
  const [savingConfig, setSavingConfig] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // Metadata dropdowns
  const [availableSessions, setAvailableSessions] = useState<Array<{ id: string; name: string }>>([]);
  const [availableExams, setAvailableExams] = useState<Array<{ id: string; name: string; type?: string; className?: string }>>([]);
  const [availableClasses, setAvailableClasses] = useState<Array<{ id: string; name: string }>>([]);
  const [availableSections, setAvailableSections] = useState<Array<{ id: string; name: string; classId?: string }>>([]);

  // Modals
  const [isConfigModalOpen, setIsConfigModalOpen] = useState<boolean>(false);
  const [configForm, setConfigForm] = useState<MeritRankingConfig>({
    rankingCriteria: 'GPA',
    tieBreakerRule: 'STANDARD_COMPETITION',
    tieBreakerSecondary: 'TOTAL_MARKS',
    scope: 'CLASS',
    includeFailedStudents: false,
    minAttendancePercentage: 0,
    topNThreshold: 10
  });

  // Report card preview modal
  const [inspectedResultId, setInspectedResultId] = useState<string | null>(null);
  const [inspectedReportCard, setInspectedReportCard] = useState<ReportCardDetail | null>(null);

  // Load metadata
  const loadMetadata = useCallback(async () => {
    try {
      const [sessionsRes, examsRes, classesRes, sectionsRes, configRes] = await Promise.all([
        api.academic.getSessions(),
        api.examinations.getExaminations(),
        api.academic.getClasses(),
        api.academic.getSections(),
        api.examinations.getMeritConfig()
      ]);

      if (sessionsRes.success && sessionsRes.data) {
        const raw = Array.isArray(sessionsRes.data) ? sessionsRes.data : (sessionsRes.data as any).data || [];
        setAvailableSessions(raw.map((s: AcademicSession) => ({ id: s.id, name: s.name || s.id })));
      }
      if (examsRes.success && examsRes.data) {
        const rawList = Array.isArray(examsRes.data) ? examsRes.data : (examsRes.data as any).data || [];
        setAvailableExams(rawList.map((e: Examination) => ({ id: e.id, name: e.name, type: e.examType, className: e.className })));
        if (rawList.length > 0 && filterExam === 'ALL') {
          setFilterExam(rawList?.[0]?.id || '');
        }
      }
      if (classesRes.success && classesRes.data) {
        const raw = Array.isArray(classesRes.data) ? classesRes.data : (classesRes.data as any).data || [];
        setAvailableClasses(raw.map((c: SchoolClass) => ({ id: c.id, name: c.name })));
      }
      if (sectionsRes.success && sectionsRes.data) {
        const raw = Array.isArray(sectionsRes.data) ? sectionsRes.data : (sectionsRes.data as any).data || [];
        setAvailableSections(raw.map((s: Section) => ({ id: s.id, name: s.name, classId: s.classId })));
      }
      if (configRes.success && configRes.data) {
        setMeritConfig(configRes.data);
        setConfigForm(configRes.data);
      }
    } catch (err: any) {
      console.error('Error loading merit metadata:', err);
    }
  }, [filterExam]);

  // Fetch Merit List
  const fetchMeritList = useCallback(async (isSilent = false) => {
    if (!isSilent) setLoading(true);
    else setRefreshing(true);
    setError(null);

    try {
      const params: any = {};
      if (filterSession !== 'ALL') params.academicSessionId = filterSession;
      if (filterExam !== 'ALL') params.examId = filterExam;
      if (filterClass !== 'ALL') params.classId = filterClass;
      if (filterSection !== 'ALL') params.sectionId = filterSection;
      if (includeUnpublished) params.includeUnpublished = true;

      const res = await api.examinations.getMeritList(params);
      if (res.success && res.data) {
        setMeritData(res.data);
        if (res.data.rankingConfig) {
          setMeritConfig(res.data.rankingConfig);
        }
      } else {
        setError(res.error || 'Failed to load merit rankings.');
      }
    } catch (err: any) {
      setError(err?.message || 'Network error fetching merit list.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [filterSession, filterExam, filterClass, filterSection, includeUnpublished]);

  useEffect(() => {
    loadMetadata();
  }, [loadMetadata]);

  useEffect(() => {
    if (availableExams.length > 0) {
      fetchMeritList();
    }
  }, [fetchMeritList, availableExams.length]);

  // Trigger Merit Recalculation
  const handleCalculateMerit = async () => {
    if (filterExam === 'ALL') {
      addToast('Please select a specific examination to calculate merit rankings.', 'error');
      return;
    }

    setCalculating(true);
    try {
      const payload: any = { examId: filterExam };
      if (filterClass !== 'ALL') payload.classId = filterClass;
      if (filterSection !== 'ALL') payload.sectionId = filterSection;

      const res = await api.examinations.calculateMeritPositions(payload);
      if (res.success) {
        addToast(res.data?.message || 'Merit positions calculated successfully!', 'success');
        fetchMeritList(true);
      } else {
        addToast(res.error || 'Failed to calculate merit rankings.', 'error');
      }
    } catch (err: any) {
      addToast(err?.message || 'Server error running merit calculations.', 'error');
    } finally {
      setCalculating(false);
    }
  };

  // Save Configuration
  const handleSaveConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingConfig(true);
    try {
      const res = await api.examinations.updateMeritConfig(configForm);
      if (res.success && res.data) {
        setMeritConfig(res.data);
        addToast('Merit ranking configuration updated successfully!', 'success');
        setIsConfigModalOpen(false);
        fetchMeritList(true);
      } else {
        addToast(res.error || 'Failed to save config.', 'error');
      }
    } catch (err: any) {
      addToast(err?.message || 'Server error saving configuration.', 'error');
    } finally {
      setSavingConfig(false);
    }
  };

  // Open Preview for single student
  const handleOpenPreview = async (resultId: string) => {
    setInspectedResultId(resultId);
    try {
      const res = await api.examinations.getReportCardDetail(resultId);
      if (res.success && res.data) {
        setInspectedReportCard(res.data);
      } else {
        addToast(res.error || 'Failed to load report card details.', 'error');
      }
    } catch (err: any) {
      addToast(err?.message || 'Error loading report card.', 'error');
    }
  };

  // Export to CSV
  const handleExportCSV = () => {
    if (!meritData || !meritData.rankedStudents || meritData.rankedStudents.length === 0) {
      addToast('No merit rankings to export.', 'info');
      return;
    }

    const headers = ['Rank', 'Admission No', 'Roll No', 'Student Name', 'Class', 'Section', 'GPA', 'Total Marks', 'Full Marks', 'Percentage', 'Grade', 'Status', 'Tied'];
    const rows = meritData.rankedStudents.map((r) => [
      r.rank,
      r.admissionNumber,
      r.rollNumber,
      `"${r.studentName}"`,
      r.className,
      r.sectionName,
      Number(r.gpa ?? 0).toFixed(2),
      r.totalObtainedMarks,
      r.totalFullMarks,
      `${r.overallPercentage}%`,
      r.overallGrade,
      r.resultStatus,
      r.isTied ? 'Yes' : 'No'
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Merit_List_${meritData.examination?.name || 'Exam'}_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    addToast('Merit list exported as CSV!', 'success');
  };

  // Filtered rows for search
  const displayedRankings = useMemo(() => {
    if (!meritData?.rankedStudents) return [];
    if (!searchQuery.trim()) return meritData.rankedStudents;
    const q = searchQuery.toLowerCase();
    return meritData.rankedStudents.filter(
      (r) =>
        r.studentName.toLowerCase().includes(q) ||
        r.admissionNumber.toLowerCase().includes(q) ||
        r.rollNumber.toLowerCase().includes(q) ||
        r.className.toLowerCase().includes(q)
    );
  }, [meritData?.rankedStudents, searchQuery]);

  // Top 3 Podium
  const topThree = useMemo(() => {
    if (!meritData?.rankedStudents) return [];
    return meritData.rankedStudents.slice(0, 3);
  }, [meritData?.rankedStudents]);

  return (
    <div className="space-y-6">
      {/* Top 3 Honor Podium */}
      {topThree.length >= 3 && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* 2nd Place Silver */}
          <div className="order-2 md:order-1 p-5 rounded-2xl bg-gradient-to-b from-slate-800/80 to-slate-900/80 border border-slate-400/20 shadow-xl flex flex-col items-center text-center relative overflow-hidden">
            <div className="absolute top-2 right-2 px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-700 text-slate-200">
              Rank #2
            </div>
            <div className="w-16 h-16 rounded-full bg-slate-700 border-2 border-slate-300 flex items-center justify-center font-bold text-slate-100 text-xl shadow-lg relative my-2">
              <Medal className="w-8 h-8 text-slate-300" />
            </div>
            <h3 className="font-bold text-white text-base mt-1">{topThree[1]?.studentName}</h3>
            <p className="text-xs text-slate-400 font-mono">
              {topThree[1]?.className} ({topThree[1]?.sectionName}) • #{topThree[1]?.rollNumber}
            </p>
            <div className="mt-3 flex items-center gap-3 bg-slate-900/80 px-3 py-1.5 rounded-xl border border-white/5">
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-semibold block">GPA</span>
                <span className="text-sm font-black text-slate-200 font-mono">{Number(topThree[1]?.gpa ?? 0).toFixed(2)}</span>
              </div>
              <div className="w-px h-6 bg-white/10" />
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-semibold block">Marks</span>
                <span className="text-sm font-black text-slate-200 font-mono">{topThree[1]?.totalObtainedMarks}</span>
              </div>
              <div className="w-px h-6 bg-white/10" />
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-semibold block">Score</span>
                <span className="text-sm font-black text-slate-200 font-mono">{topThree[1]?.overallPercentage}%</span>
              </div>
            </div>
          </div>

          {/* 1st Place Gold Champion */}
          <div className="order-1 md:order-2 p-6 rounded-2xl bg-gradient-to-b from-amber-500/10 via-slate-900/90 to-slate-900/90 border-2 border-amber-500/40 shadow-2xl shadow-amber-500/10 flex flex-col items-center text-center relative overflow-hidden -translate-y-2">
            <div className="absolute top-2 right-2 px-2.5 py-0.5 rounded-full text-[10px] font-black bg-amber-500 text-slate-950 uppercase tracking-wider flex items-center gap-1">
              <Crown className="w-3 h-3" /> Champion
            </div>
            <div className="w-20 h-20 rounded-full bg-amber-500/20 border-4 border-amber-400 flex items-center justify-center font-bold text-amber-300 text-2xl shadow-xl shadow-amber-500/20 relative my-2">
              <Crown className="w-10 h-10 text-amber-400 animate-bounce" />
            </div>
            <h3 className="font-extrabold text-white text-lg mt-1">{topThree[0]?.studentName}</h3>
            <p className="text-xs text-amber-300/80 font-mono">
              {topThree[0]?.className} ({topThree[0]?.sectionName}) • #{topThree[0]?.rollNumber}
            </p>
            <div className="mt-4 flex items-center gap-4 bg-slate-950/80 px-4 py-2 rounded-xl border border-amber-500/20">
              <div>
                <span className="text-[10px] text-amber-400/80 uppercase font-bold block">GPA</span>
                <span className="text-base font-black text-amber-300 font-mono">{Number(topThree[0]?.gpa ?? 0).toFixed(2)}</span>
              </div>
              <div className="w-px h-7 bg-white/10" />
              <div>
                <span className="text-[10px] text-amber-400/80 uppercase font-bold block">Total Marks</span>
                <span className="text-base font-black text-amber-300 font-mono">{topThree[0]?.totalObtainedMarks}</span>
              </div>
              <div className="w-px h-7 bg-white/10" />
              <div>
                <span className="text-[10px] text-amber-400/80 uppercase font-bold block">Percentage</span>
                <span className="text-base font-black text-amber-300 font-mono">{topThree[0]?.overallPercentage}%</span>
              </div>
            </div>
          </div>

          {/* 3rd Place Bronze */}
          <div className="order-3 p-5 rounded-2xl bg-gradient-to-b from-slate-800/80 to-slate-900/80 border border-amber-700/30 shadow-xl flex flex-col items-center text-center relative overflow-hidden">
            <div className="absolute top-2 right-2 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-900/60 text-amber-300 border border-amber-700/30">
              Rank #3
            </div>
            <div className="w-16 h-16 rounded-full bg-amber-950/60 border-2 border-amber-600 flex items-center justify-center font-bold text-amber-500 text-xl shadow-lg relative my-2">
              <Medal className="w-8 h-8 text-amber-600" />
            </div>
            <h3 className="font-bold text-white text-base mt-1">{topThree[2]?.studentName}</h3>
            <p className="text-xs text-slate-400 font-mono">
              {topThree[2]?.className} ({topThree[2]?.sectionName}) • #{topThree[2]?.rollNumber}
            </p>
            <div className="mt-3 flex items-center gap-3 bg-slate-900/80 px-3 py-1.5 rounded-xl border border-white/5">
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-semibold block">GPA</span>
                <span className="text-sm font-black text-amber-200 font-mono">{Number(topThree[2].gpa ?? 0).toFixed(2)}</span>
              </div>
              <div className="w-px h-6 bg-white/10" />
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-semibold block">Marks</span>
                <span className="text-sm font-black text-amber-200 font-mono">{topThree[2].totalObtainedMarks}</span>
              </div>
              <div className="w-px h-6 bg-white/10" />
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-semibold block">Score</span>
                <span className="text-sm font-black text-amber-200 font-mono">{topThree[2].overallPercentage}%</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Filter & Engine Control Toolbar */}
      <Card className="border-white/10 bg-slate-900/60 backdrop-blur-sm">
        <CardContent className="p-4 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-3">
            <div>
              <label className="text-xs font-semibold text-slate-400 block mb-1">Academic Session</label>
              <Select
                value={filterSession}
                onChange={(e) => setFilterSession(e.target.value)}
                className="w-full text-xs"
              >
                <option value="ALL">All Academic Sessions</option>
                {(availableSessions || []).map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </Select>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-400 block mb-1">Target Examination *</label>
              <Select
                value={filterExam}
                onChange={(e) => setFilterExam(e.target.value)}
                className="w-full text-xs border-indigo-500/40"
              >
                <option value="ALL">Select Examination...</option>
                {(availableExams || []).map((e) => (
                  <option key={e.id} value={e.id}>
                    {e.name} {e.className ? `(${e.className})` : ''}
                  </option>
                ))}
              </Select>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-400 block mb-1">Class Filter</label>
              <Select
                value={filterClass}
                onChange={(e) => setFilterClass(e.target.value)}
                className="w-full text-xs"
              >
                <option value="ALL">All Classes</option>
                {(availableClasses || []).map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </Select>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-400 block mb-1">Section Filter</label>
              <Select
                value={filterSection}
                onChange={(e) => setFilterSection(e.target.value)}
                className="w-full text-xs"
              >
                <option value="ALL">All Sections</option>
                {(availableSections || []).map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </Select>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-400 block mb-1">Search Student</label>
              <div className="relative">
                <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <Input
                  type="text"
                  placeholder="Filter name, roll, ID..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-8 text-xs h-9"
                />
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-white/5">
            <div className="flex items-center gap-3">
              <Button
                variant="outline"
                size="sm"
                onClick={() => fetchMeritList(true)}
                disabled={refreshing}
                className="text-slate-300 hover:text-white"
              >
                <RefreshCw className={`w-3.5 h-3.5 mr-1.5 ${refreshing ? 'animate-spin' : ''}`} />
                Refresh
              </Button>

              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  if (meritConfig) setConfigForm(meritConfig);
                  setIsConfigModalOpen(true);
                }}
                className="text-indigo-300 hover:text-white border-indigo-500/30 hover:bg-indigo-500/10"
              >
                <Settings className="w-3.5 h-3.5 mr-1.5" />
                Ranking Rules ({meritConfig?.rankingCriteria || 'GPA'})
              </Button>

              <label className="flex items-center gap-1.5 text-xs text-slate-300 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={includeUnpublished}
                  onChange={(e) => setIncludeUnpublished(e.target.checked)}
                  className="rounded border-slate-700 text-indigo-600 focus:ring-0 bg-slate-800"
                />
                <span>Include Draft/Unapproved</span>
              </label>
            </div>

            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={handleExportCSV}
                className="text-slate-300 hover:text-white"
              >
                <Download className="w-3.5 h-3.5 mr-1.5" />
                Export CSV
              </Button>

              <Button
                variant="outline"
                size="sm"
                onClick={async () => {
                  if (!meritData?.rankedStudents || meritData.rankedStudents.length === 0) {
                    window.print();
                    return;
                  }
                  const cols = ['Rank', 'Admission No', 'Roll No', 'Student Name', 'Class & Sec', 'GPA', 'Marks', 'Percentage', 'Grade'];
                  const rows = meritData.rankedStudents.map((r) => [
                    `#${r.rank}${r.isTied ? ' (T)' : ''}`,
                    r.admissionNumber,
                    r.rollNumber || '-',
                    r.studentName,
                    `${r.className} - ${r.sectionName}`,
                    Number(r.gpa ?? 0).toFixed(2),
                    `${r.totalObtainedMarks} / ${r.totalFullMarks}`,
                    `${r.overallPercentage}%`,
                    r.overallGrade
                  ]);
                  const currentExamName = availableExams.find((e) => e.id === filterExam)?.name || 'All Examinations';
                  await downloadTablePdf({
                    title: `Official Examination Merit Rankings — ${currentExamName}`,
                    subtitle: `Criteria: ${meritConfig?.rankingCriteria || 'GPA'} | Total Ranked: ${meritData.rankedStudents.length}`,
                    columns: cols,
                    data: rows,
                    orientation: 'landscape'
                  });
                  await triggerSafePrint({
                    fallbackTitle: `Merit_Rankings_${currentExamName}`
                  });
                }}
                className="text-slate-300 hover:text-white"
              >
                <Printer className="w-3.5 h-3.5 mr-1.5" />
                Print / PDF List
              </Button>

              <Button
                variant="primary"
                size="sm"
                onClick={handleCalculateMerit}
                disabled={calculating || filterExam === 'ALL'}
                className="bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-600/30"
              >
                <Sparkles className={`w-4 h-4 mr-1.5 ${calculating ? 'animate-spin' : ''}`} />
                {calculating ? 'Calculating Positions...' : 'Calculate Merit Rankings'}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Merit Leaderboard Table */}
      <Card className="border-white/10 bg-slate-900/60 backdrop-blur-sm overflow-hidden">
        <CardHeader className="pb-3 border-b border-white/10 flex flex-row items-center justify-between">
          <div>
            <CardTitle className="text-base text-white flex items-center gap-2">
              <Award className="w-4 h-4 text-amber-400" />
              Official Merit Position Leaderboard
            </CardTitle>
            <CardDescription className="text-xs text-slate-400">
              Ranked by {meritConfig?.rankingCriteria || 'GPA'} • Tie-breaker: {meritConfig?.tieBreakerRule || 'STANDARD_COMPETITION'}
            </CardDescription>
          </div>
          {meritData && (
            <div className="flex items-center gap-2 text-xs text-slate-400">
              <span>Total Students: <strong className="text-white">{meritData.totalStudents}</strong></span>
              <span>•</span>
              <span>Passed: <strong className="text-emerald-400">{meritData.passedCount}</strong></span>
              <span>•</span>
              <span>Avg GPA: <strong className="text-sky-400">{Number(meritData.averageGpa ?? 0).toFixed(2)}</strong></span>
            </div>
          )}
        </CardHeader>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-950/80 text-slate-400 uppercase tracking-wider font-semibold text-[11px] border-b border-white/10">
              <tr>
                <th className="py-3.5 px-4 text-center">Rank</th>
                <th className="py-3.5 px-3">Student Details</th>
                <th className="py-3.5 px-3">Class & Section</th>
                <th className="py-3.5 px-3 text-center">GPA</th>
                <th className="py-3.5 px-3 text-center">Total Marks</th>
                <th className="py-3.5 px-3 text-center">Percentage</th>
                <th className="py-3.5 px-3 text-center">Grade</th>
                <th className="py-3.5 px-3 text-center">Standing</th>
                <th className="py-3.5 px-3 text-center">Tie Info</th>
                <th className="py-3.5 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 font-medium text-slate-300">
              {loading ? (
                <tr>
                  <td colSpan={10} className="py-12 text-center">
                    <LoadingSpinner size="md" />
                    <p className="text-xs text-slate-400 mt-2">Computing merit positions...</p>
                  </td>
                </tr>
              ) : displayedRankings.length === 0 ? (
                <tr>
                  <td colSpan={10} className="py-12 text-center">
                    <EmptyState
                      icon={Award}
                      title="No Merit Rankings Found"
                      description="Select an examination and click 'Calculate Merit Rankings' to generate the official academic honor roll."
                    />
                  </td>
                </tr>
              ) : (
                (displayedRankings || []).map((student) => {
                  const isTop1 = student.rank === 1;
                  const isTop2 = student.rank === 2;
                  const isTop3 = student.rank === 3;
                  const isPassed = student.resultStatus === 'PASSED' || student.resultStatus === 'DISTINCTION';

                  return (
                    <tr
                      key={student.resultId}
                      className={`hover:bg-white/[0.02] transition-colors ${
                        isTop1
                          ? 'bg-amber-500/10'
                          : isTop2
                          ? 'bg-slate-700/20'
                          : isTop3
                          ? 'bg-amber-900/10'
                          : ''
                      }`}
                    >
                      <td className="py-3.5 px-4 text-center font-bold">
                        {isTop1 ? (
                          <span className="inline-flex items-center justify-center w-7 h-7 rounded-full bg-amber-500 text-slate-950 font-black shadow-md shadow-amber-500/20">
                            1
                          </span>
                        ) : isTop2 ? (
                          <span className="inline-flex items-center justify-center w-7 h-7 rounded-full bg-slate-300 text-slate-950 font-black shadow-md">
                            2
                          </span>
                        ) : isTop3 ? (
                          <span className="inline-flex items-center justify-center w-7 h-7 rounded-full bg-amber-700 text-white font-black shadow-md">
                            3
                          </span>
                        ) : (
                          <span className="font-mono text-slate-400">#{student.rank}</span>
                        )}
                      </td>
                      <td className="py-3.5 px-3">
                        <div className="flex items-center gap-2.5">
                          <div className="w-8 h-8 rounded-full bg-slate-800 border border-white/10 flex items-center justify-center font-bold text-slate-300 text-xs">
                            {student.studentName.slice(0, 2).toUpperCase()}
                          </div>
                          <div>
                            <span className="font-bold text-white block">{student.studentName}</span>
                            <span className="text-[10px] text-slate-400 font-mono">
                              Adm: {student.admissionNumber} • Roll #{student.rollNumber}
                            </span>
                          </div>
                        </div>
                      </td>
                      <td className="py-3.5 px-3">
                        <span className="text-white font-semibold block">{student.className}</span>
                        <span className="text-[10px] text-slate-400 block">{student.sectionName}</span>
                      </td>
                      <td className="py-3.5 px-3 text-center font-mono font-black text-indigo-400 text-sm">
                        {Number(student.gpa ?? 0).toFixed(2)}
                      </td>
                      <td className="py-3.5 px-3 text-center font-mono font-bold text-white">
                        {student.totalObtainedMarks} / {student.totalFullMarks}
                      </td>
                      <td className="py-3.5 px-3 text-center font-mono text-slate-200">
                        {student.overallPercentage}%
                      </td>
                      <td className="py-3.5 px-3 text-center">
                        <span className="inline-block px-2 py-0.5 rounded bg-slate-800 border border-white/10 font-bold text-white">
                          {student.overallGrade}
                        </span>
                      </td>
                      <td className="py-3.5 px-3 text-center">
                        <Badge
                          variant={isPassed ? 'success' : 'danger'}
                          className={
                            student.resultStatus === 'DISTINCTION'
                              ? 'bg-amber-500/20 text-amber-300 border-amber-500/30 font-bold'
                              : isPassed
                              ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                              : 'bg-rose-500/20 text-rose-300 border-rose-500/30'
                          }
                        >
                          {student.resultStatus}
                        </Badge>
                      </td>
                      <td className="py-3.5 px-3 text-center">
                        {student.isTied ? (
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                            Tied
                          </span>
                        ) : (
                          <span className="text-[10px] text-slate-500">-</span>
                        )}
                      </td>
                      <td className="py-3.5 px-3 text-right">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleOpenPreview(student.resultId)}
                          className="h-7 px-2.5 text-xs text-indigo-300 hover:text-white border-indigo-500/30 hover:bg-indigo-500/10"
                        >
                          <Eye className="w-3.5 h-3.5 mr-1" />
                          Card
                        </Button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Merit Ranking Configuration Modal */}
      <Modal
        isOpen={isConfigModalOpen}
        onClose={() => setIsConfigModalOpen(false)}
        title="Merit & Position Ranking Engine Configuration"
        size="lg"
      >
        <form onSubmit={handleSaveConfig} className="space-y-5 text-xs">
          <div className="p-3 bg-indigo-500/10 border border-indigo-500/20 rounded-xl text-indigo-300 text-xs">
            Configure institutional policies for determining class ranks, section positions, and tie-breaking algorithms.
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="font-semibold text-slate-300 block mb-1">
                Primary Ranking Metric
              </label>
              <Select
                value={configForm.rankingCriteria}
                onChange={(e: any) =>
                  setConfigForm((prev) => ({ ...prev, rankingCriteria: e.target.value }))
                }
                className="w-full"
              >
                <option value="GPA">Grade Point Average (GPA)</option>
                <option value="TOTAL_MARKS">Total Marks Obtained</option>
                <option value="PERCENTAGE">Overall Percentage (%)</option>
                <option value="WEIGHTED_GPA">Weighted Credit GPA</option>
              </Select>
            </div>

            <div>
              <label className="font-semibold text-slate-300 block mb-1">
                Tie-Breaker Algorithm
              </label>
              <Select
                value={configForm.tieBreakerRule}
                onChange={(e: any) =>
                  setConfigForm((prev) => ({ ...prev, tieBreakerRule: e.target.value }))
                }
                className="w-full"
              >
                <option value="STANDARD_COMPETITION">Standard Competition (1, 2, 2, 4)</option>
                <option value="DENSE">Dense Ranking (1, 2, 2, 3)</option>
                <option value="ORDINAL">Ordinal Ranking (1, 2, 3, 4 with sub-criteria)</option>
                <option value="FRACTIONAL">Fractional / Averaged (1, 2.5, 2.5, 4)</option>
              </Select>
            </div>

            <div>
              <label className="font-semibold text-slate-300 block mb-1">
                Secondary Tie-Breaker Metric
              </label>
              <Select
                value={configForm.tieBreakerSecondary || 'TOTAL_MARKS'}
                onChange={(e: any) =>
                  setConfigForm((prev) => ({ ...prev, tieBreakerSecondary: e.target.value }))
                }
                className="w-full"
              >
                <option value="TOTAL_MARKS">Higher Total Marks</option>
                <option value="ATTENDANCE">Higher Attendance Percentage</option>
                <option value="SPECIFIC_SUBJECT">Highest Core Subject Marks</option>
              </Select>
            </div>

            <div>
              <label className="font-semibold text-slate-300 block mb-1">
                Ranking Calculation Scope
              </label>
              <Select
                value={configForm.scope}
                onChange={(e: any) =>
                  setConfigForm((prev) => ({ ...prev, scope: e.target.value }))
                }
                className="w-full"
              >
                <option value="CLASS">Class-Wide (All sections combined)</option>
                <option value="SECTION">Section-Specific</option>
                <option value="INSTITUTION">All-School Institution Wide</option>
              </Select>
            </div>
          </div>

          <div className="space-y-3 pt-3 border-t border-white/10">
            <label className="flex items-center gap-2 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={configForm.includeFailedStudents}
                onChange={(e) =>
                  setConfigForm((prev) => ({ ...prev, includeFailedStudents: e.target.checked }))
                }
                className="rounded border-slate-700 text-indigo-600 focus:ring-0 bg-slate-800"
              />
              <span className="text-slate-300 font-medium">
                Include Failed Students in Position Counts (places them at bottom)
              </span>
            </label>
          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => setIsConfigModalOpen(false)}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              variant="primary"
              size="sm"
              disabled={savingConfig}
              className="bg-indigo-600 hover:bg-indigo-500 text-white"
            >
              <Save className="w-4 h-4 mr-1.5" />
              {savingConfig ? 'Saving...' : 'Save Configuration'}
            </Button>
          </div>
        </form>
      </Modal>

      {/* Report card preview */}
      <ReportCardPrintModal
        isOpen={!!inspectedResultId && !!inspectedReportCard}
        onClose={() => {
          setInspectedResultId(null);
          setInspectedReportCard(null);
        }}
        reportCard={inspectedReportCard}
      />
    </div>
  );
};
