import React, { useState, useEffect, useRef } from 'react';
import {
  ArrowLeft,
  Save,
  Send,
  Search,
  CheckCircle2,
  AlertTriangle,
  Users,
  UserX,
  ShieldAlert,
  Award,
  TrendingUp,
  FileCheck2,
  Lock,
  RotateCcw,
  Sparkles,
  HelpCircle,
  Clock,
  Printer
} from 'lucide-react';
import { api } from '../../services/api.js';
import { useToast } from '../../context/ToastContext.js';
import { StudentMarkItem, ExamMarksSubmissionStatus } from '../../types/index.js';

interface TeacherMarksEntrySheetProps {
  examId: string;
  subjectId: string;
  onBack: () => void;
  onRefreshParent: () => void;
}

export const TeacherMarksEntrySheet: React.FC<TeacherMarksEntrySheetProps> = ({
  examId,
  subjectId,
  onBack,
  onRefreshParent
}) => {
  const { addToast } = useToast();
  const [loading, setLoading] = useState<boolean>(true);
  const [savingDraft, setSavingDraft] = useState<boolean>(false);
  const [submitting, setSubmitting] = useState<boolean>(false);

  // Loaded metadata
  const [examData, setExamData] = useState<any>(null);
  const [subjectData, setSubjectData] = useState<any>(null);
  const [submissionData, setSubmissionData] = useState<any>(null);
  const [currentStatus, setCurrentStatus] = useState<ExamMarksSubmissionStatus>('not_started');
  const [isEditable, setIsEditable] = useState<boolean>(true);

  // Student marks state
  const [students, setStudents] = useState<StudentMarkItem[]>([]);
  const [notes, setNotes] = useState<string>('');

  // UI Filters & Search
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [filterType, setFilterType] = useState<'all' | 'pending' | 'entered' | 'absent' | 'exempt'>('all');
  const [showSubmitModal, setShowSubmitModal] = useState<boolean>(false);

  // Input refs for keyboard navigation
  const inputRefs = useRef<{ [key: string]: HTMLInputElement | null }>({});

  const fetchMarksSheet = async () => {
    try {
      setLoading(true);
      const res = await api.examinations.getTeacherMarksSheet(examId, subjectId);
      if (res.data) {
        setExamData(res.data.exam);
        setSubjectData(res.data.subject);
        setSubmissionData(res.data.submission);
        setCurrentStatus(res.data.status);
        setIsEditable(res.data.isEditable);
        setStudents(res.data.students || []);
        setNotes(res.data.submission?.notes || '');
      }
    } catch (err: any) {
      addToast({
        type: 'error',
        title: 'Error Loading Marks Sheet',
        message: err.message || 'Failed to retrieve student marks list.'
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMarksSheet();
  }, [examId, subjectId]);

  // Handle Mark Change
  const handleMarkChange = (studentId: string, valStr: string) => {
    if (!isEditable) return;

    setStudents((prev) =>
      prev.map((stud) => {
        if (stud.studentId !== studentId) return stud;

        if (valStr.trim() === '') {
          return {
            ...stud,
            obtainedMarks: null,
            isPassed: undefined
          };
        }

        const num = parseFloat(valStr);
        const passMarks = subjectData?.passMarks || 40;
        const isPassed = !isNaN(num) ? num >= passMarks : undefined;

        return {
          ...stud,
          obtainedMarks: isNaN(num) ? null : num,
          isAbsent: false,
          isExempt: false,
          isPassed
        };
      })
    );
  };

  // Toggle Absent
  const handleToggleAbsent = (studentId: string) => {
    if (!isEditable) return;

    setStudents((prev) =>
      prev.map((stud) => {
        if (stud.studentId !== studentId) return stud;
        const nextAbsent = !stud.isAbsent;
        return {
          ...stud,
          isAbsent: nextAbsent,
          isExempt: nextAbsent ? false : stud.isExempt,
          obtainedMarks: nextAbsent ? null : stud.obtainedMarks,
          isPassed: nextAbsent ? false : undefined
        };
      })
    );
  };

  // Toggle Exempt
  const handleToggleExempt = (studentId: string) => {
    if (!isEditable) return;

    setStudents((prev) =>
      prev.map((stud) => {
        if (stud.studentId !== studentId) return stud;
        const nextExempt = !stud.isExempt;
        return {
          ...stud,
          isExempt: nextExempt,
          isAbsent: nextExempt ? false : stud.isAbsent,
          obtainedMarks: nextExempt ? null : stud.obtainedMarks,
          isPassed: undefined
        };
      })
    );
  };

  // Handle Remarks Change
  const handleRemarksChange = (studentId: string, remarksStr: string) => {
    if (!isEditable) return;
    setStudents((prev) =>
      prev.map((stud) => (stud.studentId === studentId ? { ...stud, remarks: remarksStr } : stud))
    );
  };

  // Keyboard navigation helper
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>, currentIndex: number) => {
    const visibleStudents = filteredStudents;
    if (e.key === 'Enter' || e.key === 'ArrowDown') {
      e.preventDefault();
      if (currentIndex + 1 < visibleStudents.length) {
        const nextStudId = visibleStudents[currentIndex + 1].studentId;
        inputRefs.current[nextStudId]?.focus();
        inputRefs.current[nextStudId]?.select();
      }
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (currentIndex - 1 >= 0) {
        const prevStudId = visibleStudents[currentIndex - 1].studentId;
        inputRefs.current[prevStudId]?.focus();
        inputRefs.current[prevStudId]?.select();
      }
    }
  };

  // Bulk action: Mark All Present
  const handleMarkAllPresent = () => {
    if (!isEditable) return;
    setStudents((prev) =>
      prev.map((stud) => ({
        ...stud,
        isAbsent: false,
        isExempt: false
      }))
    );
    addToast({
      type: 'info',
      title: 'Reset Attendance Flags',
      message: 'All students flagged as present.'
    });
  };

  // Save Draft
  const handleSaveDraft = async () => {
    try {
      setSavingDraft(true);
      const payload = {
        examId,
        subjectId,
        classId: examData?.classId,
        sectionId: examData?.sectionId,
        marks: students.map((s) => ({
          studentId: s.studentId,
          obtainedMarks: s.obtainedMarks,
          isAbsent: s.isAbsent,
          isExempt: s.isExempt,
          remarks: s.remarks
        })),
        notes
      };

      const res = await api.examinations.saveDraftMarks(payload);
      if (res.success) {
        addToast({
          type: 'success',
          title: 'Draft Saved',
          message: res.message || 'Marks draft saved successfully.'
        });
        setCurrentStatus('draft');
        onRefreshParent();
      }
    } catch (err: any) {
      addToast({
        type: 'error',
        title: 'Save Failed',
        message: err.message || 'Could not save draft.'
      });
    } finally {
      setSavingDraft(false);
    }
  };

  // Pre-validate before opening submission modal
  const handleOpenSubmitModal = () => {
    const fullMarks = subjectData?.fullMarks || 100;
    const invalidMarks = students.filter(
      (s) =>
        !s.isAbsent &&
        !s.isExempt &&
        s.obtainedMarks !== null &&
        (s.obtainedMarks < 0 || s.obtainedMarks > fullMarks)
    );

    if (invalidMarks.length > 0) {
      addToast({
        type: 'error',
        title: 'Invalid Marks Found',
        message: `Some students have marks outside 0 - ${fullMarks}. Please correct them.`
      });
      return;
    }

    const unrecorded = students.filter(
      (s) => !s.isAbsent && !s.isExempt && (s.obtainedMarks === null || s.obtainedMarks === undefined)
    );

    if (unrecorded.length > 0) {
      addToast({
        type: 'warning',
        title: 'Incomplete Marks Records',
        message: `${unrecorded.length} student(s) do not have marks recorded. Please enter marks or mark as Absent/Exempt before submitting.`
      });
      return;
    }

    setShowSubmitModal(true);
  };

  // Confirm Final Submission
  const handleConfirmSubmit = async () => {
    try {
      setSubmitting(true);
      const payload = {
        examId,
        subjectId,
        classId: examData?.classId,
        sectionId: examData?.sectionId,
        marks: students.map((s) => ({
          studentId: s.studentId,
          obtainedMarks: s.obtainedMarks,
          isAbsent: s.isAbsent,
          isExempt: s.isExempt,
          remarks: s.remarks
        })),
        notes
      };

      const res = await api.examinations.submitMarks(payload);
      if (res.success) {
        addToast({
          type: 'success',
          title: 'Marks Submitted',
          message: res.message || 'Marks submitted successfully to Administration.'
        });
        setCurrentStatus('submitted');
        setIsEditable(false);
        setShowSubmitModal(false);
        onRefreshParent();
        fetchMarksSheet();
      }
    } catch (err: any) {
      addToast({
        type: 'error',
        title: 'Submission Failed',
        message: err.message || 'Could not submit marks.'
      });
    } finally {
      setSubmitting(false);
    }
  };

  // Print Marks Table
  const handlePrint = () => {
    window.print();
  };

  // Calculations & Telemetry
  const fullMarks = subjectData?.fullMarks || 100;
  const passMarks = subjectData?.passMarks || 40;
  const totalStudents = students.length;
  const enteredCount = students.filter((s) => s.obtainedMarks !== null || s.isAbsent || s.isExempt).length;
  const absentCount = students.filter((s) => s.isAbsent).length;
  const exemptCount = students.filter((s) => s.isExempt).length;
  const scoredMarks = students.map((s) => s.obtainedMarks).filter((m): m is number => m !== null && m !== undefined);
  const passedCount = scoredMarks.filter((m) => m >= passMarks).length;
  const failedCount = scoredMarks.filter((m) => m < passMarks).length;
  const avgMarks = scoredMarks.length > 0 ? (scoredMarks.reduce((a, b) => a + b, 0) / scoredMarks.length).toFixed(1) : '0';
  const highestScore = scoredMarks.length > 0 ? Math.max(...scoredMarks) : 0;
  const lowestScore = scoredMarks.length > 0 ? Math.min(...scoredMarks) : 0;

  // Filter students for UI display
  const filteredStudents = students.filter((stud) => {
    const matchSearch =
      stud.studentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      stud.rollNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      stud.admissionNumber.toLowerCase().includes(searchTerm.toLowerCase());

    if (!matchSearch) return false;

    if (filterType === 'pending') {
      return stud.obtainedMarks === null && !stud.isAbsent && !stud.isExempt;
    }
    if (filterType === 'entered') {
      return stud.obtainedMarks !== null;
    }
    if (filterType === 'absent') {
      return stud.isAbsent;
    }
    if (filterType === 'exempt') {
      return stud.isExempt;
    }
    return true;
  });

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[450px] p-8 text-center bg-slate-950/60 rounded-3xl border border-white/10 backdrop-blur-xl">
        <div className="w-12 h-12 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin mb-4" />
        <p className="text-sm font-semibold text-slate-300">Loading Student Marks Sheet...</p>
        <p className="text-xs text-slate-500 mt-1">Verifying teacher authorization and pulling roster records...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-20 print:p-0 print:space-y-4">
      {/* Top Breadcrumb & Actions Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-slate-900/80 p-4 rounded-2xl border border-white/10 backdrop-blur-xl print:hidden">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/10 text-xs font-semibold transition cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Exam List</span>
          </button>

          <div className="h-5 w-px bg-white/10 hidden sm:block" />

          <div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-bold text-white tracking-tight">{subjectData?.name}</span>
              <span className="px-2 py-0.5 rounded-md bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-[10px] font-mono font-bold">
                {subjectData?.code || 'SUBJ'}
              </span>
            </div>
            <p className="text-xs text-slate-400">
              {examData?.name} • Class: {examData?.className} ({examData?.sectionName})
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          {/* Status Badge */}
          <div
            className={`px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1.5 border ${
              currentStatus === 'submitted'
                ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30'
                : currentStatus === 'approved'
                ? 'bg-purple-500/10 text-purple-300 border-purple-500/30'
                : currentStatus === 'returned'
                ? 'bg-rose-500/10 text-rose-300 border-rose-500/30 animate-pulse'
                : currentStatus === 'draft'
                ? 'bg-amber-500/10 text-amber-300 border-amber-500/30'
                : 'bg-slate-700/30 text-slate-400 border-slate-700'
            }`}
          >
            {currentStatus === 'submitted' ? (
              <CheckCircle2 className="w-3.5 h-3.5" />
            ) : currentStatus === 'returned' ? (
              <AlertTriangle className="w-3.5 h-3.5" />
            ) : currentStatus === 'approved' ? (
              <Award className="w-3.5 h-3.5" />
            ) : (
              <Clock className="w-3.5 h-3.5" />
            )}
            <span className="uppercase tracking-wider">
              {currentStatus === 'not_started'
                ? 'Not Started'
                : currentStatus === 'draft'
                ? 'Draft In-Progress'
                : currentStatus === 'submitted'
                ? 'Submitted'
                : currentStatus === 'returned'
                ? 'Correction Requested'
                : 'Approved'}
            </span>
          </div>

          <button
            onClick={handlePrint}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10 text-xs transition cursor-pointer"
            title="Print Marks Table"
          >
            <Printer className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Returned for correction banner */}
      {currentStatus === 'returned' && (
        <div className="bg-rose-500/10 border border-rose-500/30 rounded-2xl p-4 flex items-start gap-3 backdrop-blur-md">
          <AlertTriangle className="w-5 h-5 text-rose-400 flex-shrink-0 mt-0.5" />
          <div>
            <h4 className="text-sm font-bold text-rose-200">Admin Returned Marksheet for Correction</h4>
            <p className="text-xs text-rose-300/90 mt-0.5">
              <strong className="text-white">Admin Reason:</strong> {submissionData?.returnedReason || 'Please verify student marks and re-submit.'}
            </p>
            <p className="text-[11px] text-rose-400 mt-1">
              Returned on {submissionData?.returnedAt ? new Date(submissionData.returnedAt).toLocaleString() : 'Recently'} by {submissionData?.returnedBy || 'Admin'}. You may make corrections and re-submit.
            </p>
          </div>
        </div>
      )}

      {/* Submitted locked banner */}
      {currentStatus === 'submitted' && (
        <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-2xl p-4 flex items-start gap-3 backdrop-blur-md">
          <FileCheck2 className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
          <div>
            <h4 className="text-sm font-bold text-emerald-200">Marksheet Submitted to Administration</h4>
            <p className="text-xs text-emerald-300/90 mt-0.5">
              Submitted on {submissionData?.submittedAt ? new Date(submissionData.submittedAt).toLocaleString() : 'Recently'} by {submissionData?.submittedBy || 'Teacher'}.
            </p>
            <p className="text-[11px] text-emerald-400/80 mt-1">
              Record is locked for administrative review. If you need to make corrections, please request an unlock from the Super Admin.
            </p>
          </div>
        </div>
      )}

      {/* Exam & Subject Summary Card */}
      <div className="bg-slate-900/60 rounded-3xl p-6 border border-white/10 backdrop-blur-2xl shadow-xl">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="p-4 rounded-2xl bg-white/[0.03] border border-white/5">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Full Marks</span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl font-black text-white">{fullMarks}</span>
              <span className="text-xs text-slate-400">Total Marks</span>
            </div>
            <span className="text-[11px] text-slate-400 mt-1 block">Pass Threshold: <strong className="text-amber-400">{passMarks}</strong></span>
          </div>

          <div className="p-4 rounded-2xl bg-white/[0.03] border border-white/5">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Student Roster</span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl font-black text-white">{totalStudents}</span>
              <span className="text-xs text-slate-400">Registered</span>
            </div>
            <span className="text-[11px] text-emerald-400 mt-1 block">
              Entered: <strong>{enteredCount} / {totalStudents}</strong> ({totalStudents > 0 ? Math.round((enteredCount / totalStudents) * 100) : 0}%)
            </span>
          </div>

          <div className="p-4 rounded-2xl bg-white/[0.03] border border-white/5">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Class Performance</span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl font-black text-indigo-300">{avgMarks}</span>
              <span className="text-xs text-slate-400">Average</span>
            </div>
            <div className="flex items-center gap-3 text-[11px] text-slate-400 mt-1">
              <span>Pass: <strong className="text-emerald-400">{passedCount}</strong></span>
              <span>Fail: <strong className="text-rose-400">{failedCount}</strong></span>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-white/[0.03] border border-white/5">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Score Extremes</span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl font-black text-white">{highestScore}</span>
              <span className="text-xs text-slate-400">Highest</span>
            </div>
            <div className="flex items-center gap-3 text-[11px] text-slate-400 mt-1">
              <span>Lowest: <strong className="text-slate-300">{lowestScore}</strong></span>
              <span>Absent: <strong className="text-amber-400">{absentCount}</strong></span>
            </div>
          </div>
        </div>
      </div>

      {/* Controls & Filter Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900/60 p-4 rounded-2xl border border-white/10 backdrop-blur-xl print:hidden">
        {/* Search */}
        <div className="relative flex-1 min-w-[220px] max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search student by name, roll, or ID..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-950/60 text-white placeholder-slate-500 pl-9 pr-4 py-2 rounded-xl text-xs border border-white/10 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 transition"
          />
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <button
            onClick={() => setFilterType('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition cursor-pointer ${
              filterType === 'all'
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                : 'bg-white/5 text-slate-400 hover:text-white'
            }`}
          >
            All ({students.length})
          </button>
          <button
            onClick={() => setFilterType('pending')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition cursor-pointer ${
              filterType === 'pending'
                ? 'bg-amber-600 text-white shadow-lg shadow-amber-600/30'
                : 'bg-white/5 text-slate-400 hover:text-white'
            }`}
          >
            Pending ({students.filter((s) => s.obtainedMarks === null && !s.isAbsent && !s.isExempt).length})
          </button>
          <button
            onClick={() => setFilterType('entered')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition cursor-pointer ${
              filterType === 'entered'
                ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/30'
                : 'bg-white/5 text-slate-400 hover:text-white'
            }`}
          >
            Entered ({students.filter((s) => s.obtainedMarks !== null).length})
          </button>
          <button
            onClick={() => setFilterType('absent')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition cursor-pointer ${
              filterType === 'absent'
                ? 'bg-rose-600 text-white shadow-lg shadow-rose-600/30'
                : 'bg-white/5 text-slate-400 hover:text-white'
            }`}
          >
            Absent ({students.filter((s) => s.isAbsent).length})
          </button>
        </div>

        {/* Quick Helper Tools */}
        {isEditable && (
          <div className="flex items-center gap-2">
            <button
              onClick={handleMarkAllPresent}
              className="px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/10 text-xs font-semibold transition cursor-pointer flex items-center gap-1.5"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Mark All Present</span>
            </button>
          </div>
        )}
      </div>

      {/* Marks Table */}
      <div className="bg-slate-900/60 rounded-3xl border border-white/10 overflow-hidden backdrop-blur-2xl shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-white/10 bg-white/[0.02] text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                <th className="py-4 px-4 w-12 text-center">#</th>
                <th className="py-4 px-4 w-20 text-center">Roll</th>
                <th className="py-4 px-4">Student Name & ID</th>
                <th className="py-4 px-4 w-28">Section</th>
                <th className="py-4 px-4 w-36 text-center">
                  Marks (Max {fullMarks})
                </th>
                <th className="py-4 px-4 w-24 text-center">Absent</th>
                <th className="py-4 px-4 w-24 text-center">Exempt</th>
                <th className="py-4 px-4 min-w-[150px]">Remarks</th>
                <th className="py-4 px-4 w-24 text-center">Result</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 text-xs">
              {filteredStudents.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-slate-500">
                    <Users className="w-8 h-8 mx-auto mb-2 opacity-40" />
                    <p className="text-sm font-semibold">No students found</p>
                    <p className="text-xs">Adjust your search query or filter selection.</p>
                  </td>
                </tr>
              ) : (
                filteredStudents.map((stud, idx) => {
                  const isMarkEntered = stud.obtainedMarks !== null && stud.obtainedMarks !== undefined;
                  const isInvalid = isMarkEntered && (stud.obtainedMarks! < 0 || stud.obtainedMarks! > fullMarks);
                  const isPass = isMarkEntered && !stud.isAbsent && stud.obtainedMarks! >= passMarks;
                  const isFail = isMarkEntered && !stud.isAbsent && !stud.isExempt && stud.obtainedMarks! < passMarks;

                  return (
                    <tr
                      key={stud.studentId}
                      className={`hover:bg-white/[0.03] transition-colors ${
                        stud.isAbsent ? 'bg-rose-950/10' : stud.isExempt ? 'bg-amber-950/10' : ''
                      }`}
                    >
                      {/* Row Index */}
                      <td className="py-3 px-4 text-center font-mono text-slate-500">{idx + 1}</td>

                      {/* Roll Number */}
                      <td className="py-3 px-4 text-center font-mono font-bold text-white">
                        <span className="px-2 py-1 rounded-md bg-white/5 border border-white/10">
                          {stud.rollNumber}
                        </span>
                      </td>

                      {/* Student Info */}
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-3">
                          {stud.avatarUrl ? (
                            <img
                              src={stud.avatarUrl}
                              alt={stud.studentName}
                              className="w-8 h-8 rounded-full object-cover border border-white/15"
                              referrerPolicy="no-referrer"
                            />
                          ) : (
                            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-indigo-600 to-violet-500 flex items-center justify-center text-white font-bold text-xs border border-white/10">
                              {stud.studentName.charAt(0).toUpperCase()}
                            </div>
                          )}
                          <div>
                            <p className="font-semibold text-white tracking-tight">{stud.studentName}</p>
                            <p className="text-[10px] text-slate-400 font-mono">ID: {stud.admissionNumber}</p>
                          </div>
                        </div>
                      </td>

                      {/* Section */}
                      <td className="py-3 px-4 text-slate-300">
                        {stud.sectionName || examData?.sectionName || 'N/A'}
                      </td>

                      {/* Marks Input */}
                      <td className="py-3 px-4 text-center">
                        <div className="relative flex items-center justify-center">
                          <input
                            ref={(el) => {
                              inputRefs.current[stud.studentId] = el;
                            }}
                            type="number"
                            step="0.5"
                            min="0"
                            max={fullMarks}
                            disabled={!isEditable || stud.isAbsent || stud.isExempt}
                            value={
                              stud.isAbsent || stud.isExempt
                                ? ''
                                : stud.obtainedMarks !== null && stud.obtainedMarks !== undefined
                                ? stud.obtainedMarks
                                : ''
                            }
                            placeholder={stud.isAbsent ? 'ABS' : stud.isExempt ? 'EXM' : '—'}
                            onChange={(e) => handleMarkChange(stud.studentId, e.target.value)}
                            onKeyDown={(e) => handleKeyDown(e, idx)}
                            className={`w-24 px-3 py-1.5 rounded-xl font-mono text-sm font-bold text-center border transition focus:outline-none focus:ring-2 ${
                              !isEditable || stud.isAbsent || stud.isExempt
                                ? 'bg-slate-950/30 text-slate-500 border-white/5 cursor-not-allowed'
                                : isInvalid
                                ? 'bg-rose-500/20 text-rose-200 border-rose-500 focus:ring-rose-500'
                                : isPass
                                ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/40 focus:ring-emerald-500'
                                : isFail
                                ? 'bg-rose-500/10 text-rose-300 border-rose-500/30 focus:ring-rose-500'
                                : 'bg-slate-950/80 text-white border-white/15 focus:border-indigo-500 focus:ring-indigo-500'
                            }`}
                          />
                        </div>
                      </td>

                      {/* Absent Checkbox */}
                      <td className="py-3 px-4 text-center">
                        <label className="inline-flex items-center justify-center cursor-pointer">
                          <input
                            type="checkbox"
                            disabled={!isEditable}
                            checked={!!stud.isAbsent}
                            onChange={() => handleToggleAbsent(stud.studentId)}
                            className="w-4 h-4 rounded text-rose-500 bg-slate-900 border-white/20 focus:ring-rose-500 focus:ring-offset-slate-950 cursor-pointer disabled:opacity-50"
                          />
                        </label>
                      </td>

                      {/* Exempt Checkbox */}
                      <td className="py-3 px-4 text-center">
                        <label className="inline-flex items-center justify-center cursor-pointer">
                          <input
                            type="checkbox"
                            disabled={!isEditable}
                            checked={!!stud.isExempt}
                            onChange={() => handleToggleExempt(stud.studentId)}
                            className="w-4 h-4 rounded text-amber-500 bg-slate-900 border-white/20 focus:ring-amber-500 focus:ring-offset-slate-950 cursor-pointer disabled:opacity-50"
                          />
                        </label>
                      </td>

                      {/* Remarks */}
                      <td className="py-3 px-4">
                        <input
                          type="text"
                          disabled={!isEditable}
                          value={stud.remarks || ''}
                          placeholder={isEditable ? 'Optional notes...' : ''}
                          onChange={(e) => handleRemarksChange(stud.studentId, e.target.value)}
                          className="w-full bg-slate-950/40 text-slate-200 placeholder-slate-600 px-3 py-1.5 rounded-lg text-xs border border-white/10 focus:border-indigo-500 focus:outline-none transition disabled:opacity-60 disabled:bg-transparent disabled:border-transparent"
                        />
                      </td>

                      {/* Result Chip */}
                      <td className="py-3 px-4 text-center">
                        {stud.isAbsent ? (
                          <span className="px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30 text-[10px] font-bold uppercase">
                            Absent
                          </span>
                        ) : stud.isExempt ? (
                          <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-bold uppercase">
                            Exempt
                          </span>
                        ) : isPass ? (
                          <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold uppercase">
                            Pass
                          </span>
                        ) : isFail ? (
                          <span className="px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30 text-[10px] font-bold uppercase">
                            Fail
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-full bg-slate-800 text-slate-500 border border-slate-700 text-[10px] font-semibold uppercase">
                            Pending
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Teacher Remarks & Notes */}
      <div className="bg-slate-900/60 rounded-3xl p-6 border border-white/10 backdrop-blur-2xl shadow-xl print:hidden">
        <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
          Subject Teacher Examination Notes / Remarks
        </label>
        <textarea
          rows={2}
          disabled={!isEditable}
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          placeholder="Enter any general feedback, grade distribution notes, or observations for the Academic Head..."
          className="w-full bg-slate-950/60 text-white placeholder-slate-500 p-3 rounded-2xl text-xs border border-white/10 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 transition disabled:opacity-50"
        />
      </div>

      {/* Sticky Bottom Actions Bar */}
      <div className="fixed bottom-0 left-0 right-0 z-30 bg-slate-950/90 border-t border-white/10 backdrop-blur-2xl p-4 shadow-2xl print:hidden">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-4 text-xs">
            <span className="text-slate-400">
              Recorded: <strong className="text-white">{enteredCount}</strong> / {totalStudents} Students
            </span>
            <div className="h-4 w-px bg-white/10" />
            <span className="text-slate-400">
              Pass Rate: <strong className="text-emerald-400">{scoredMarks.length > 0 ? Math.round((passedCount / scoredMarks.length) * 100) : 0}%</strong>
            </span>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={onBack}
              className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/10 text-xs font-semibold transition cursor-pointer"
            >
              Cancel / Back
            </button>

            {isEditable && (
              <>
                <button
                  onClick={handleSaveDraft}
                  disabled={savingDraft || submitting}
                  className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white border border-white/15 text-xs font-bold transition flex items-center gap-2 cursor-pointer shadow-md disabled:opacity-50"
                >
                  <Save className="w-4 h-4 text-indigo-400" />
                  <span>{savingDraft ? 'Saving Draft...' : 'Save Draft'}</span>
                </button>

                <button
                  onClick={handleOpenSubmitModal}
                  disabled={savingDraft || submitting}
                  className="px-6 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs transition flex items-center gap-2 cursor-pointer shadow-lg shadow-indigo-600/30 disabled:opacity-50"
                >
                  <Send className="w-4 h-4" />
                  <span>Submit Marks to Admin</span>
                </button>
              </>
            )}

            {!isEditable && (
              <div className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/5 text-slate-400 border border-white/10 text-xs font-semibold">
                <Lock className="w-4 h-4 text-slate-500" />
                <span>Marks Locked</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Confirmation Modal for Final Marks Submission */}
      {showSubmitModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
          <div className="bg-slate-900 border border-white/15 rounded-3xl max-w-lg w-full p-6 shadow-2xl space-y-5">
            <div className="flex items-center gap-3 text-indigo-400">
              <div className="p-3 bg-indigo-500/10 rounded-2xl border border-indigo-500/20">
                <Send className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Confirm Final Marks Submission</h3>
                <p className="text-xs text-slate-400">{subjectData?.name} ({subjectData?.code})</p>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              You are about to submit the final examination marks for <strong>Class {examData?.className} ({examData?.sectionName})</strong>. Once submitted, records will be locked and forwarded to the Administration for verification.
            </p>

            {/* Summary Box */}
            <div className="p-4 rounded-2xl bg-white/[0.03] border border-white/5 space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-400">Total Students Evaluated:</span>
                <strong className="text-white">{students.length}</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Passing Students:</span>
                <strong className="text-emerald-400">{passedCount}</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Failing Students:</span>
                <strong className="text-rose-400">{failedCount}</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Absent / Exempt:</span>
                <strong className="text-amber-400">{absentCount} Absent, {exemptCount} Exempt</strong>
              </div>
              <div className="flex justify-between border-t border-white/10 pt-2 font-semibold">
                <span className="text-slate-300">Class Average Score:</span>
                <span className="text-indigo-300">{avgMarks} / {fullMarks}</span>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setShowSubmitModal(false)}
                disabled={submitting}
                className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-semibold transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmSubmit}
                disabled={submitting}
                className="px-6 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg shadow-indigo-600/30 transition flex items-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {submitting ? (
                  <>
                    <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Submitting...</span>
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4" />
                    <span>Confirm & Lock Submission</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
