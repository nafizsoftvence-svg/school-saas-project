import React from 'react';
import { Inbox } from 'lucide-react';
import { Button } from './Button.js';

export interface EmptyStateProps {
  icon?: React.ReactNode | React.ComponentType<{ className?: string }>;
  title: string;
  description: string;
  actionLabel?: string;
  onAction?: () => void;
  id?: string;
}

const renderEmptyStateIcon = (icon?: React.ReactNode | React.ComponentType<{ className?: string }>) => {
  if (!icon) return <Inbox className="w-7 h-7" />;
  if (React.isValidElement(icon)) {
    return icon;
  }
  if (typeof icon === 'function' || (typeof icon === 'object' && icon !== null && ('render' in icon || '$$typeof' in icon))) {
    const IconComp = icon as React.ComponentType<{ className?: string }>;
    return <IconComp className="w-7 h-7" />;
  }
  return <Inbox className="w-7 h-7" />;
};

export const EmptyState: React.FC<EmptyStateProps> = ({
  icon,
  title,
  description,
  actionLabel,
  onAction,
  id = 'empty-state'
}) => {
  return (
    <div
      id={id}
      className="p-10 flex flex-col items-center justify-center text-center rounded-2xl border border-slate-200 bg-white max-w-lg mx-auto shadow-xs"
    >
      <div className="w-14 h-14 rounded-2xl bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-600 mb-4 shadow-2xs">
        {renderEmptyStateIcon(icon)}
      </div>
      <h4 className="text-base font-bold text-slate-900 tracking-tight mb-1">{title}</h4>
      <p className="text-xs text-slate-600 max-w-sm mb-6 leading-relaxed font-medium">{description}</p>
      {actionLabel && onAction && (
        <Button size="sm" variant="primary" onClick={onAction}>
          {actionLabel}
        </Button>
      )}
    </div>
  );
};
