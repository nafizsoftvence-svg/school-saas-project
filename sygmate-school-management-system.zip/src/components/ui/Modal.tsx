import React, { useEffect } from 'react';
import { X } from 'lucide-react';
import { PortalTheme } from './Button.js';

export type ModalSize = 'xs' | 'sm' | 'md' | 'lg' | 'xl' | 'full';

export interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title?: React.ReactNode;
  description?: React.ReactNode;
  children: React.ReactNode;
  size?: ModalSize;
  portalTheme?: PortalTheme;
  icon?: React.ReactNode;
  footer?: React.ReactNode;
  closeOnEsc?: boolean;
  closeOnBackdropClick?: boolean;
  id?: string;
}

export const Modal: React.FC<ModalProps> = ({
  isOpen,
  onClose,
  title,
  description,
  children,
  size = 'md',
  portalTheme = 'default',
  icon,
  footer,
  closeOnEsc = true,
  closeOnBackdropClick = true,
  id = 'modal'
}) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && closeOnEsc) onClose();
    };
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => {
      document.body.style.overflow = 'unset';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, onClose, closeOnEsc]);

  if (!isOpen) return null;

  const sizeClasses: Record<ModalSize, string> = {
    xs: 'max-w-sm',
    sm: 'max-w-md',
    md: 'max-w-lg',
    lg: 'max-w-2xl',
    xl: 'max-w-4xl',
    full: 'max-w-6xl'
  };

  const getIconBadgeColor = () => {
    return 'bg-blue-50 text-blue-700 border border-blue-200';
  };

  return (
    <div
      id={`${id}-overlay`}
      role="dialog"
      aria-modal="true"
      aria-labelledby={title ? `${id}-title` : undefined}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto bg-slate-900/40 backdrop-blur-xs animate-in fade-in duration-200"
      onClick={(e) => {
        if (closeOnBackdropClick && e.target === e.currentTarget) {
          onClose();
        }
      }}
    >
      <div
        id={id}
        className={`w-full ${sizeClasses[size] || sizeClasses.md} rounded-3xl bg-white border border-slate-200 shadow-2xl flex flex-col overflow-hidden animate-in zoom-in-95 duration-200 my-8`}
      >
        {/* Modal Header */}
        {(title || description || icon) && (
          <div className="px-6 py-5 border-b border-slate-200 flex items-start justify-between gap-4 bg-slate-50/50">
            <div className="flex items-start gap-3.5">
              {icon && (
                <div className={`p-2 rounded-xl flex-shrink-0 mt-0.5 ${getIconBadgeColor()}`}>
                  {icon}
                </div>
              )}
              <div>
                {title && (
                  <h2
                    id={`${id}-title`}
                    className="text-base sm:text-lg font-bold text-slate-900 tracking-tight"
                  >
                    {title}
                  </h2>
                )}
                {description && (
                  <p className="text-xs text-slate-600 mt-1 leading-normal font-medium">
                    {description}
                  </p>
                )}
              </div>
            </div>
            <button
              id={`${id}-close-btn`}
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-xl text-slate-400 hover:text-slate-800 hover:bg-slate-200/60 transition-colors focus:outline-none focus:ring-2 focus:ring-blue-600 cursor-pointer flex-shrink-0"
              aria-label="Close dialog"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        )}

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto max-h-[72vh] text-slate-800 text-sm">
          {children}
        </div>

        {/* Optional Modal Footer */}
        {footer && (
          <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex items-center justify-end gap-3">
            {footer}
          </div>
        )}
      </div>
    </div>
  );
};
