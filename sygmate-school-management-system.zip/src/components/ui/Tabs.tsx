import React from 'react';

export interface TabItem {
  id: string;
  label: string;
  badge?: string | number;
  icon?: React.ReactNode | React.ComponentType<{ className?: string }>;
}

export interface TabsProps {
  tabs: TabItem[];
  activeTab: string;
  onChange: (tabId: string) => void;
  id?: string;
  variant?: 'pill' | 'underline';
}

const renderTabIcon = (icon?: React.ReactNode | React.ComponentType<{ className?: string }>) => {
  if (!icon) return null;
  if (React.isValidElement(icon)) {
    return <span className="w-4 h-4 flex items-center justify-center">{icon}</span>;
  }
  if (typeof icon === 'function' || (typeof icon === 'object' && icon !== null && ('render' in icon || '$$typeof' in icon))) {
    const IconComp = icon as React.ComponentType<{ className?: string }>;
    return <IconComp className="w-4 h-4" />;
  }
  return <span className="w-4 h-4 flex items-center justify-center">{icon as React.ReactNode}</span>;
};

export const Tabs: React.FC<TabsProps> = ({ tabs, activeTab, onChange, id = 'tabs', variant = 'pill' }) => {
  const safeTabs = tabs || [];
  if (variant === 'underline') {
    return (
      <div id={id} className="border-b border-slate-200 flex gap-6">
        {safeTabs.map((tab) => {
          const isActive = tab.id === activeTab;
          return (
            <button
              key={tab.id}
              id={`${id}-tab-${tab.id}`}
              onClick={() => onChange(tab.id)}
              className={`flex items-center gap-2 py-3 px-1 text-sm transition-all cursor-pointer border-b-2 ${
                isActive
                  ? 'border-sky-700 text-sky-950 font-bold'
                  : 'border-transparent text-slate-600 hover:text-slate-900 font-medium hover:border-slate-300'
              }`}
            >
              {renderTabIcon(tab.icon)}
              <span>{tab.label}</span>
              {tab.badge !== undefined && (
                <span
                  className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                    isActive
                      ? 'bg-sky-100 text-sky-900'
                      : 'bg-slate-100 text-slate-700'
                  }`}
                >
                  {tab.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>
    );
  }

  return (
    <div id={id} className="inline-flex p-1 bg-slate-100 border border-slate-200/90 rounded-2xl max-w-full overflow-x-auto shadow-2xs">
      {safeTabs.map((tab) => {
        const isActive = tab.id === activeTab;
        return (
          <button
            key={tab.id}
            id={`${id}-tab-${tab.id}`}
            onClick={() => onChange(tab.id)}
            className={`flex items-center gap-2 px-3.5 py-1.5 text-xs rounded-xl transition-all duration-150 cursor-pointer whitespace-nowrap ${
              isActive
                ? 'bg-sky-700 text-white shadow-xs border border-sky-800 font-bold'
                : 'text-slate-700 hover:text-slate-950 hover:bg-slate-200/80 font-medium'
            }`}
          >
            {renderTabIcon(tab.icon)}
            <span>{tab.label}</span>
            {tab.badge !== undefined && (
              <span
                className={`text-[10px] px-1.5 py-0.5 rounded-md font-mono font-bold ${
                  isActive ? 'bg-sky-900 text-white' : 'bg-slate-200 text-slate-800'
                }`}
              >
                {tab.badge}
              </span>
            )}
          </button>
        );
      })}
    </div>
  );
};
