import React, { forwardRef, useState } from 'react';
import { Eye, EyeOff, X, AlertCircle } from 'lucide-react';
import { PortalTheme } from './Button.js';

export type InputSize = 'sm' | 'md' | 'lg';

export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  id: string;
  label?: string;
  error?: string;
  helperText?: string;
  portalTheme?: PortalTheme;
  inputSize?: InputSize;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  clearable?: boolean;
  onClear?: () => void;
  required?: boolean;
}

export const Input = forwardRef<HTMLInputElement, InputProps>(
  (
    {
      id,
      label,
      error,
      helperText,
      portalTheme = 'default',
      inputSize = 'md',
      type = 'text',
      leftIcon,
      rightIcon,
      clearable = false,
      onClear,
      required = false,
      className = '',
      value,
      disabled,
      ...props
    },
    ref
  ) => {
    const [showPassword, setShowPassword] = useState(false);
    const isPasswordType = type === 'password';
    const computedType = isPasswordType ? (showPassword ? 'text' : 'password') : type;

    const sizeStyles: Record<InputSize, { input: string; leftPad: string; rightPad: string }> = {
      sm: {
        input: 'py-1.5 text-xs rounded-lg',
        leftPad: 'pl-8',
        rightPad: 'pr-8'
      },
      md: {
        input: 'py-2.5 text-sm rounded-xl',
        leftPad: 'pl-10',
        rightPad: 'pr-10'
      },
      lg: {
        input: 'py-3 text-base rounded-xl',
        leftPad: 'pl-11',
        rightPad: 'pr-11'
      }
    };

    const currentSize = sizeStyles[inputSize] || sizeStyles.md;
    const hasLeftIcon = Boolean(leftIcon);
    const hasRightContent = Boolean(rightIcon || isPasswordType || (clearable && value));

    return (
      <div className="w-full text-left">
        {label && (
          <label
            htmlFor={id}
            className="block text-xs font-semibold text-slate-800 uppercase tracking-wider mb-1.5"
          >
            {label}
            {required && <span className="text-rose-600 ml-1 font-bold">*</span>}
          </label>
        )}
        <div className="relative rounded-xl shadow-2xs">
          {leftIcon && (
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
              {leftIcon}
            </div>
          )}
          <input
            ref={ref}
            id={id}
            type={computedType}
            value={value}
            disabled={disabled}
            aria-invalid={error ? 'true' : 'false'}
            aria-describedby={error ? `${id}-error` : helperText ? `${id}-helper` : undefined}
            className={`block w-full border transition-all duration-150 focus:outline-none focus:ring-2 focus:ring-offset-0 disabled:bg-slate-100 disabled:text-slate-400 disabled:border-slate-200 disabled:cursor-not-allowed ${
              hasLeftIcon ? currentSize.leftPad : 'pl-3.5'
            } ${hasRightContent ? currentSize.rightPad : 'pr-3.5'} ${currentSize.input} ${
              error
                ? 'border-rose-400 bg-rose-50/60 text-rose-950 placeholder-rose-400 focus:border-rose-600 focus:ring-rose-500/20'
                : 'border-slate-300 bg-white text-slate-900 placeholder-slate-400 focus:border-blue-600 focus:ring-blue-600/20'
            } ${className}`}
            {...props}
          />
          <div className="absolute inset-y-0 right-0 pr-3 flex items-center gap-1.5">
            {clearable && value && !disabled && (
              <button
                type="button"
                onClick={onClear}
                className="text-slate-400 hover:text-slate-700 p-0.5 rounded-md transition-colors cursor-pointer"
                aria-label="Clear input"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
            {isPasswordType && !disabled && (
              <button
                type="button"
                onClick={() => setShowPassword((prev) => !prev)}
                className="text-slate-400 hover:text-slate-700 p-0.5 rounded-md transition-colors cursor-pointer"
                aria-label={showPassword ? 'Hide password' : 'Show password'}
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            )}
            {rightIcon && <div className="text-slate-400 flex items-center">{rightIcon}</div>}
          </div>
        </div>
        {error ? (
          <p id={`${id}-error`} className="mt-1.5 text-xs text-rose-600 font-semibold flex items-center gap-1">
            <AlertCircle className="w-3.5 h-3.5 flex-shrink-0" />
            <span>{error}</span>
          </p>
        ) : helperText ? (
          <p id={`${id}-helper`} className="mt-1.5 text-xs text-slate-600 font-medium">
            {helperText}
          </p>
        ) : null}
      </div>
    );
  }
);

Input.displayName = 'Input';
