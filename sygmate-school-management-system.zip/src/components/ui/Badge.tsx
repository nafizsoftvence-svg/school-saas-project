import React from 'react';

export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  variant?:
    | 'primary'
    | 'secondary'
    | 'success'
    | 'warning'
    | 'danger'
    | 'info'
    | 'neutral'
    | 'cyan'
    | 'purple'
    | 'emerald'
    | 'rose'
    | 'amber'
    | 'blue'
    | 'indigo';
  size?: 'sm' | 'md';
  dot?: boolean;
}

export const Badge: React.FC<BadgeProps> = ({
  children,
  variant = 'neutral',
  size = 'md',
  dot = false,
  className = '',
  id,
  ...props
}) => {
  const variantStyles: Record<string, string> = {
    primary: 'bg-sky-50 text-sky-800 border-sky-200',
    indigo: 'bg-sky-50 text-sky-800 border-sky-200',
    secondary: 'bg-slate-100 text-slate-800 border-slate-200',
    success: 'bg-emerald-50 text-emerald-800 border-emerald-200',
    emerald: 'bg-emerald-50 text-emerald-800 border-emerald-200',
    warning: 'bg-amber-50 text-amber-900 border-amber-200',
    amber: 'bg-amber-50 text-amber-900 border-amber-200',
    danger: 'bg-rose-50 text-rose-800 border-rose-200',
    rose: 'bg-rose-50 text-rose-800 border-rose-200',
    info: 'bg-sky-50 text-sky-800 border-sky-200',
    blue: 'bg-sky-50 text-sky-800 border-sky-200',
    purple: 'bg-purple-50 text-purple-800 border-purple-200',
    cyan: 'bg-cyan-50 text-cyan-800 border-cyan-200',
    neutral: 'bg-slate-100 text-slate-800 border-slate-200'
  };

  const dotColors: Record<string, string> = {
    primary: 'bg-indigo-400',
    indigo: 'bg-indigo-400',
    secondary: 'bg-slate-400',
    success: 'bg-emerald-400',
    emerald: 'bg-emerald-400',
    warning: 'bg-amber-400',
    amber: 'bg-amber-400',
    danger: 'bg-rose-400',
    rose: 'bg-rose-400',
    info: 'bg-blue-400',
    blue: 'bg-blue-400',
    purple: 'bg-purple-400',
    cyan: 'bg-cyan-400',
    neutral: 'bg-slate-400'
  };

  const sizeStyles = {
    sm: 'text-[10px] px-2 py-0.5 font-medium tracking-wide',
    md: 'text-xs px-2.5 py-1 font-semibold tracking-wide'
  };

  const currentVariant = variantStyles[variant as keyof typeof variantStyles] || variantStyles.neutral;
  const currentDot = dotColors[variant as keyof typeof dotColors] || dotColors.neutral;
  const currentSize = sizeStyles[size as keyof typeof sizeStyles] || sizeStyles.md;

  return (
    <span
      id={id}
      className={`inline-flex items-center gap-1.5 rounded-full border backdrop-blur-sm whitespace-nowrap leading-none ${currentSize} ${currentVariant} ${className}`}
      {...props}
    >
      {dot && <span className={`w-1.5 h-1.5 rounded-full ${currentDot} shadow-xs`} />}
      {children}
    </span>
  );
};
