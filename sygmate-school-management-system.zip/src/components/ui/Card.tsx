import React from 'react';
import { PortalTheme } from './Button.js';

export type CardVariant = 'default' | 'flat' | 'bordered' | 'interactive' | 'glow' | 'stat';

export interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  id?: string;
  variant?: CardVariant;
  portalTheme?: PortalTheme;
}

export const Card: React.FC<CardProps> = ({
  children,
  variant = 'default',
  portalTheme = 'default',
  className = '',
  id,
  ...props
}) => {
  const getGlowBorder = () => {
    switch (portalTheme) {
      case 'teacher':
        return 'bg-gradient-to-b from-emerald-500/10 to-white border-emerald-500/30 shadow-md';
      case 'student':
        return 'bg-gradient-to-b from-sky-500/10 to-white border-sky-500/30 shadow-md';
      case 'admin':
      default:
        return 'bg-gradient-to-b from-sky-500/10 to-white border-sky-500/30 shadow-md';
    }
  };

  const getStatTopBorder = () => {
    switch (portalTheme) {
      case 'teacher':
        return 'border-t-4 border-t-emerald-600';
      case 'student':
        return 'border-t-4 border-t-sky-600';
      case 'admin':
      default:
        return 'border-t-4 border-t-sky-700';
    }
  };

  const variantStyles: Record<CardVariant, string> = {
    default:
      'bg-white rounded-2xl border border-slate-200 text-slate-900 shadow-2xs',
    flat:
      'bg-slate-50/80 rounded-2xl border border-slate-200/90 text-slate-900',
    bordered:
      'bg-white rounded-2xl border-2 border-slate-200 text-slate-900 shadow-2xs',
    interactive:
      'bg-white rounded-2xl border border-slate-200 text-slate-900 shadow-2xs hover:shadow-md hover:border-slate-300 transition-all duration-200 cursor-pointer active:scale-[0.99]',
    glow:
      `rounded-2xl border backdrop-blur-xl text-slate-900 ${getGlowBorder()}`,
    stat:
      `bg-white rounded-2xl border border-slate-200 text-slate-900 shadow-2xs ${getStatTopBorder()}`
  };

  const chosenStyle = variantStyles[variant] || variantStyles.default;

  return (
    <div id={id} className={`${chosenStyle} overflow-hidden ${className}`} {...props}>
      {children}
    </div>
  );
};

export const CardHeader: React.FC<React.HTMLAttributes<HTMLDivElement>> = ({
  children,
  className = '',
  ...props
}) => (
  <div
    className={`px-6 py-4.5 border-b border-slate-200 flex items-center justify-between gap-4 bg-slate-50/40 ${className}`}
    {...props}
  >
    {children}
  </div>
);

export const CardTitle: React.FC<React.HTMLAttributes<HTMLHeadingElement>> = ({
  children,
  className = '',
  ...props
}) => (
  <h3 className={`text-base font-bold text-slate-900 tracking-tight ${className}`} {...props}>
    {children}
  </h3>
);

export const CardDescription: React.FC<React.HTMLAttributes<HTMLParagraphElement>> = ({
  children,
  className = '',
  ...props
}) => (
  <p className={`text-xs text-slate-600 mt-1 leading-normal font-medium ${className}`} {...props}>
    {children}
  </p>
);

export const CardContent: React.FC<React.HTMLAttributes<HTMLDivElement>> = ({
  children,
  className = '',
  ...props
}) => (
  <div className={`p-6 ${className}`} {...props}>
    {children}
  </div>
);

export const CardFooter: React.FC<React.HTMLAttributes<HTMLDivElement>> = ({
  children,
  className = '',
  ...props
}) => (
  <div
    className={`px-6 py-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between ${className}`}
    {...props}
  >
    {children}
  </div>
);
