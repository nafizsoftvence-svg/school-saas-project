import React, { useState, useMemo } from 'react';
import { ArrowUpDown, ArrowUp, ArrowDown } from 'lucide-react';
import { Pagination } from './Pagination.js';

export interface Column<T> {
  header: string;
  accessor?: keyof T | ((row: T) => React.ReactNode);
  className?: string;
  align?: 'left' | 'center' | 'right';
  sortable?: boolean;
  sortKey?: string | keyof T;
}

export interface TablePaginationConfig {
  currentPage: number;
  pageSize: number;
  totalItems: number;
  pageSizeOptions?: number[];
  onPageChange: (page: number) => void;
  onPageSizeChange?: (pageSize: number) => void;
  itemLabel?: string;
}

export interface TableProps<T> {
  columns: Column<T>[];
  data: T[];
  keyExtractor: (row: T, index: number) => string | number;
  isLoading?: boolean;
  emptyMessage?: string;
  onRowClick?: (row: T) => void;
  id?: string;
  
  // Sorting
  sortColumn?: string;
  sortDirection?: 'asc' | 'desc';
  onSort?: (sortKey: string, direction: 'asc' | 'desc') => void;
  
  // Pagination (Controlled or Auto)
  pagination?: TablePaginationConfig;
  autoPaginate?: boolean;
  pageSize?: number;
  pageSizeOptions?: number[];
  itemLabel?: string;
}

export function Table<T>({
  columns = [],
  data = [],
  keyExtractor,
  isLoading = false,
  emptyMessage = 'No records found in this view',
  onRowClick,
  id = 'data-table',
  sortColumn,
  sortDirection,
  onSort,
  pagination,
  autoPaginate = false,
  pageSize = 10,
  pageSizeOptions = [5, 10, 20, 50],
  itemLabel = 'records'
}: TableProps<T>) {
  // Internal State for Auto-Sorting & Auto-Pagination if external handler not passed
  const [internalSortKey, setInternalSortKey] = useState<string | null>(null);
  const [internalSortDirection, setInternalSortDirection] = useState<'asc' | 'desc'>('asc');
  const [internalPage, setInternalPage] = useState<number>(1);
  const [internalPageSize, setInternalPageSize] = useState<number>(pageSize);

  const activeSortKey = sortColumn !== undefined ? sortColumn : internalSortKey;
  const activeSortDirection = sortDirection !== undefined ? sortDirection : internalSortDirection;

  const handleHeaderClick = (col: Column<T>, index: number) => {
    if (!col.sortable && !col.sortKey) return;

    const key = String(col.sortKey || col.accessor || `col_${index}`);
    let newDirection: 'asc' | 'desc' = 'asc';

    if (activeSortKey === key) {
      newDirection = activeSortDirection === 'asc' ? 'desc' : 'asc';
    }

    if (onSort) {
      onSort(key, newDirection);
    } else {
      setInternalSortKey(key);
      setInternalSortDirection(newDirection);
    }
  };

  // Process data (Sort and Slice if Auto)
  const processedData = useMemo(() => {
    let result = [...(data || [])];

    // Auto sort if internal sorting active and no external onSort
    if (!onSort && activeSortKey) {
      result.sort((a: any, b: any) => {
        let aVal = a[activeSortKey];
        let bVal = b[activeSortKey];

        if (aVal === undefined || aVal === null) aVal = '';
        if (bVal === undefined || bVal === null) bVal = '';

        if (typeof aVal === 'string' && typeof bVal === 'string') {
          return activeSortDirection === 'asc'
            ? aVal.localeCompare(bVal)
            : bVal.localeCompare(aVal);
        }

        if (typeof aVal === 'number' && typeof bVal === 'number') {
          return activeSortDirection === 'asc' ? aVal - bVal : bVal - aVal;
        }

        return 0;
      });
    }

    return result;
  }, [data, activeSortKey, activeSortDirection, onSort]);

  // Determine display slice for pagination
  const displayData = useMemo(() => {
    if (pagination) {
      return data || []; // Caller handles slicing
    }
    if (autoPaginate) {
      const start = (internalPage - 1) * internalPageSize;
      return processedData.slice(start, start + internalPageSize);
    }
    return processedData;
  }, [data, processedData, pagination, autoPaginate, internalPage, internalPageSize]);

  // Total item count for pagination
  const totalCount = pagination ? pagination.totalItems : (data?.length || 0);
  const currentTotalPages = pagination
    ? Math.max(1, Math.ceil(pagination.totalItems / pagination.pageSize))
    : Math.max(1, Math.ceil(totalCount / internalPageSize));

  return (
    <div id={id} className="w-full rounded-2xl border border-slate-200 bg-white shadow-xs overflow-hidden flex flex-col">
      <div className="w-full overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-slate-200 bg-slate-50/90">
              {(columns || []).map((col, index) => {
                const isSortable = Boolean(col.sortable || col.sortKey);
                const colKey = String(col.sortKey || col.accessor || `col_${index}`);
                const isCurrentSorted = activeSortKey === colKey;

                return (
                  <th
                    key={index}
                    onClick={() => isSortable && handleHeaderClick(col, index)}
                    className={`py-3.5 px-4 text-xs font-bold text-slate-700 uppercase tracking-wider select-none ${
                      col.align === 'right' ? 'text-right' : col.align === 'center' ? 'text-center' : 'text-left'
                    } ${col.className || ''} ${
                      isSortable ? 'cursor-pointer hover:text-slate-950 transition-colors group' : ''
                    }`}
                  >
                    <div
                      className={`inline-flex items-center gap-1.5 ${
                        col.align === 'right'
                          ? 'justify-end'
                          : col.align === 'center'
                          ? 'justify-center'
                          : 'justify-start'
                      }`}
                    >
                      <span>{col.header}</span>
                      {isSortable && (
                        <span className="inline-flex items-center text-slate-400 group-hover:text-slate-700 transition-colors">
                          {isCurrentSorted ? (
                            activeSortDirection === 'asc' ? (
                              <ArrowUp className="w-3.5 h-3.5 text-blue-600" />
                            ) : (
                              <ArrowDown className="w-3.5 h-3.5 text-blue-600" />
                            )
                          ) : (
                            <ArrowUpDown className="w-3 h-3 opacity-40 group-hover:opacity-100" />
                          )}
                        </span>
                      )}
                    </div>
                  </th>
                );
              })}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-sm text-slate-800">
            {isLoading ? (
              <tr>
                <td colSpan={(columns || []).length} className="py-12 text-center text-slate-600">
                  <div className="flex items-center justify-center gap-3">
                    <div className="w-5 h-5 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
                    <span className="text-xs font-medium">Loading records...</span>
                  </div>
                </td>
              </tr>
            ) : (displayData || []).length === 0 ? (
              <tr>
                <td colSpan={(columns || []).length} className="py-12 text-center text-slate-600 font-medium text-xs">
                  {emptyMessage}
                </td>
              </tr>
            ) : (
              (displayData || []).map((row, rowIndex) => (
                <tr
                  key={keyExtractor(row, rowIndex)}
                  onClick={() => onRowClick?.(row)}
                  className={`transition-colors duration-150 ${
                    onRowClick ? 'hover:bg-slate-50 cursor-pointer' : 'hover:bg-slate-50/60'
                  }`}
                >
                  {(columns || []).map((col, colIndex) => {
                    let cellContent: React.ReactNode = null;
                    if (typeof col.accessor === 'function') {
                      cellContent = col.accessor(row);
                    } else if (col.accessor) {
                      cellContent = row[col.accessor] as unknown as React.ReactNode;
                    }
                    return (
                      <td
                        key={colIndex}
                        className={`py-3 px-4 ${
                          col.align === 'right' ? 'text-right' : col.align === 'center' ? 'text-center' : 'text-left'
                        } ${col.className || ''}`}
                      >
                        {cellContent}
                      </td>
                    );
                  })}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Render Pagination Footer if controlled or auto */}
      {!isLoading && pagination && (
        <Pagination
          currentPage={pagination.currentPage}
          totalPages={currentTotalPages}
          totalItems={pagination.totalItems}
          pageSize={pagination.pageSize}
          pageSizeOptions={pagination.pageSizeOptions || pageSizeOptions}
          onPageChange={pagination.onPageChange}
          onPageSizeChange={pagination.onPageSizeChange}
          itemLabel={pagination.itemLabel || itemLabel}
        />
      )}

      {!isLoading && !pagination && autoPaginate && totalCount > 0 && (
        <Pagination
          currentPage={internalPage}
          totalPages={currentTotalPages}
          totalItems={totalCount}
          pageSize={internalPageSize}
          pageSizeOptions={pageSizeOptions}
          onPageChange={(p) => setInternalPage(p)}
          onPageSizeChange={(sz) => {
            setInternalPageSize(sz);
            setInternalPage(1);
          }}
          itemLabel={itemLabel}
        />
      )}
    </div>
  );
}
