import React from 'react';
import { Loader2 } from 'lucide-react';

export type ButtonVariant =
  | 'primary'
  | 'secondary'
  | 'outline'
  | 'danger'
  | 'destructive'
  | 'ghost'
  | 'subtle'
  | 'success'
  | 'warning'
  | 'cyan'
  | 'glass';

export type ButtonSize = 'xs' | 'sm' | 'md' | 'lg';
export type PortalTheme = 'admin' | 'teacher' | 'student' | 'default';

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: ButtonSize;
  portalTheme?: PortalTheme;
  isLoading?: boolean;
  loading?: boolean;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  icon?: React.ReactNode;
  fullWidth?: boolean;
}

export const Button: React.FC<ButtonProps> = ({
  children,
  variant = 'primary',
  size = 'md',
  portalTheme = 'default',
  isLoading = false,
  loading = false,
  leftIcon,
  rightIcon,
  icon,
  fullWidth = false,
  className = '',
  disabled,
  id,
  type = 'button',
  ...props
}) => {
  const baseStyles =
    'inline-flex items-center justify-center font-medium rounded-xl transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 disabled:opacity-45 disabled:cursor-not-allowed select-none active:scale-[0.98] cursor-pointer focus:ring-offset-white dark:focus:ring-offset-slate-900';

  const sizeStyles: Record<ButtonSize, string> = {
    xs: 'text-xs px-2.5 py-1.5 gap-1.5 font-medium',
    sm: 'text-xs sm:text-sm px-3.5 py-1.5 gap-2 font-medium',
    md: 'text-sm px-4.5 py-2.5 gap-2 font-semibold',
    lg: 'text-base px-6 py-3 gap-2.5 font-semibold'
  };

  // Portal-aware theme primary variants
  const getPrimaryStyle = () => {
    switch (portalTheme) {
      case 'teacher':
        return 'bg-emerald-700 hover:bg-emerald-800 text-white shadow-xs focus:ring-emerald-600 border border-emerald-800';
      case 'student':
        return 'bg-sky-800 hover:bg-sky-900 text-white shadow-xs focus:ring-sky-700 border border-sky-900';
      case 'admin':
      default:
        return 'bg-sky-700 hover:bg-sky-800 text-white shadow-xs focus:ring-sky-600 border border-sky-800';
    }
  };

  const getSubtleStyle = () => {
    switch (portalTheme) {
      case 'teacher':
        return 'bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 focus:ring-emerald-600';
      case 'student':
        return 'bg-sky-50 hover:bg-sky-100 text-sky-800 border border-sky-200 focus:ring-sky-600';
      case 'admin':
      default:
        return 'bg-sky-50 hover:bg-sky-100 text-sky-800 border border-sky-200 focus:ring-sky-600';
    }
  };

  const variantStyles: Record<string, string> = {
    primary: getPrimaryStyle(),
    secondary:
      'bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-200/90 shadow-2xs focus:ring-slate-500',
    outline:
      'bg-white hover:bg-slate-50 text-slate-800 border border-slate-300 shadow-2xs focus:ring-sky-600',
    danger:
      'bg-rose-700 hover:bg-rose-800 text-white shadow-xs focus:ring-rose-600 border border-rose-800',
    destructive:
      'bg-rose-700 hover:bg-rose-800 text-white shadow-xs focus:ring-rose-600 border border-rose-800',
    ghost:
      'bg-transparent hover:bg-slate-100 text-slate-700 hover:text-slate-950 focus:ring-slate-400 border border-transparent',
    subtle: getSubtleStyle(),
    success:
      'bg-emerald-700 hover:bg-emerald-800 text-white shadow-xs focus:ring-emerald-600 border border-emerald-800',
    warning:
      'bg-amber-600 hover:bg-amber-700 text-white shadow-xs focus:ring-amber-600 border border-amber-700',
    cyan:
      'bg-sky-600 hover:bg-sky-700 text-white shadow-xs focus:ring-sky-600 border border-sky-700',
    glass:
      'bg-white hover:bg-slate-50 text-slate-800 border border-slate-200 shadow-2xs focus:ring-sky-600'
  };

  const currentVariant = variantStyles[variant] || variantStyles.primary;
  const currentSize = sizeStyles[size] || sizeStyles.md;
  const widthStyle = fullWidth ? 'w-full' : '';

  const isButtonLoading = Boolean(isLoading || loading);
  const effectiveLeftIcon = leftIcon || icon;

  return (
    <button
      id={id}
      type={type}
      className={`${baseStyles} ${currentSize} ${currentVariant} ${widthStyle} ${className}`}
      disabled={disabled || isButtonLoading}
      {...props}
    >
      {isButtonLoading ? (
        <Loader2 className="w-4 h-4 animate-spin text-current" />
      ) : (
        effectiveLeftIcon && <span className="flex-shrink-0 inline-flex items-center">{effectiveLeftIcon}</span>
      )}
      <span className="truncate">{children}</span>
      {!isButtonLoading && rightIcon && (
        <span className="flex-shrink-0 inline-flex items-center">{rightIcon}</span>
      )}
    </button>
  );
};
