import React from 'react';
import { CheckCircle2, AlertCircle, AlertTriangle, Info, Bell, X } from 'lucide-react';

export type AlertVariant =
  | 'info'
  | 'success'
  | 'warning'
  | 'error'
  | 'danger'
  | 'destructive'
  | 'warn'
  | 'neutral'
  | 'default';

export type AlertStyle = 'subtle' | 'filled' | 'outline' | 'banner';

export interface AlertProps {
  id?: string;
  variant?: AlertVariant;
  styleType?: AlertStyle;
  title?: string;
  message?: React.ReactNode;
  description?: React.ReactNode;
  children?: React.ReactNode;
  icon?: React.ReactNode;
  action?: React.ReactNode;
  onClose?: () => void;
  className?: string;
}

export const Alert: React.FC<AlertProps> = ({
  id,
  variant = 'info',
  styleType = 'subtle',
  title,
  message,
  description,
  children,
  icon: customIcon,
  action,
  onClose,
  className = ''
}) => {
  // Normalize synonyms
  let normVariant: 'info' | 'success' | 'warning' | 'error' | 'neutral' = 'info';
  const v = (variant || '').toLowerCase();
  if (v === 'error' || v === 'danger' || v === 'destructive') {
    normVariant = 'error';
  } else if (v === 'warning' || v === 'warn') {
    normVariant = 'warning';
  } else if (v === 'success') {
    normVariant = 'success';
  } else if (v === 'neutral') {
    normVariant = 'neutral';
  } else {
    normVariant = 'info';
  }

  // Default icons
  const defaultIcons = {
    info: <Info className="w-5 h-5 text-blue-600 dark:text-blue-400 flex-shrink-0" />,
    success: <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400 flex-shrink-0" />,
    warning: <AlertTriangle className="w-5 h-5 text-amber-600 dark:text-amber-400 flex-shrink-0" />,
    error: <AlertCircle className="w-5 h-5 text-rose-600 dark:text-rose-400 flex-shrink-0" />,
    neutral: <Bell className="w-5 h-5 text-slate-600 dark:text-slate-400 flex-shrink-0" />
  };

  const filledIcons = {
    info: <Info className="w-5 h-5 text-white flex-shrink-0" />,
    success: <CheckCircle2 className="w-5 h-5 text-white flex-shrink-0" />,
    warning: <AlertTriangle className="w-5 h-5 text-white flex-shrink-0" />,
    error: <AlertCircle className="w-5 h-5 text-white flex-shrink-0" />,
    neutral: <Bell className="w-5 h-5 text-white flex-shrink-0" />
  };

  // Styles per type
  const styleConfigs = {
    subtle: {
      info: 'bg-blue-50/80 border-blue-200 text-blue-900',
      success: 'bg-emerald-50/80 border-emerald-200 text-emerald-900',
      warning: 'bg-amber-50/80 border-amber-200 text-amber-900',
      error: 'bg-rose-50/80 border-rose-200 text-rose-900',
      neutral: 'bg-slate-50 border-slate-200 text-slate-800'
    },
    filled: {
      info: 'bg-blue-600 border-blue-600 text-white shadow-2xs',
      success: 'bg-emerald-600 border-emerald-600 text-white shadow-2xs',
      warning: 'bg-amber-600 border-amber-600 text-white shadow-2xs',
      error: 'bg-rose-600 border-rose-600 text-white shadow-2xs',
      neutral: 'bg-slate-800 border-slate-800 text-white shadow-2xs'
    },
    outline: {
      info: 'bg-white border-2 border-blue-600 text-blue-900',
      success: 'bg-white border-2 border-emerald-600 text-emerald-900',
      warning: 'bg-white border-2 border-amber-500 text-amber-900',
      error: 'bg-white border-2 border-rose-600 text-rose-900',
      neutral: 'bg-white border-2 border-slate-400 text-slate-800'
    },
    banner: {
      info: 'bg-blue-50/90 border-l-4 border-l-blue-600 border-y border-r border-blue-200 text-blue-950',
      success: 'bg-emerald-50/90 border-l-4 border-l-emerald-600 border-y border-r border-emerald-200 text-emerald-950',
      warning: 'bg-amber-50/90 border-l-4 border-l-amber-600 border-y border-r border-amber-200 text-amber-950',
      error: 'bg-rose-50/90 border-l-4 border-l-rose-600 border-y border-r border-rose-200 text-rose-950',
      neutral: 'bg-slate-50 border-l-4 border-l-slate-600 border-y border-r border-slate-200 text-slate-900'
    }
  };

  const titleColors = {
    subtle: {
      info: 'text-blue-950',
      success: 'text-emerald-950',
      warning: 'text-amber-950',
      error: 'text-rose-950',
      neutral: 'text-slate-950'
    },
    filled: {
      info: 'text-white',
      success: 'text-white',
      warning: 'text-white',
      error: 'text-white',
      neutral: 'text-white'
    },
    outline: {
      info: 'text-blue-950',
      success: 'text-emerald-950',
      warning: 'text-amber-950',
      error: 'text-rose-950',
      neutral: 'text-slate-950'
    },
    banner: {
      info: 'text-blue-950',
      success: 'text-emerald-950',
      warning: 'text-amber-950',
      error: 'text-rose-950',
      neutral: 'text-slate-950'
    }
  };

  const styleClass = styleConfigs[styleType]?.[normVariant] || styleConfigs.subtle.info;
  const titleClass = titleColors[styleType]?.[normVariant] || titleColors.subtle.info;
  const icon = customIcon || (styleType === 'filled' ? filledIcons[normVariant] : defaultIcons[normVariant]);
  const content = children || message || description;

  return (
    <div
      id={id}
      role="alert"
      className={`p-4 rounded-2xl border flex items-start gap-3.5 transition-all duration-200 ${styleClass} ${className}`}
    >
      <div className="mt-0.5">{icon}</div>
      <div className="flex-1 text-xs leading-relaxed">
        {title && <h5 className={`font-semibold text-sm mb-0.5 tracking-tight ${titleClass}`}>{title}</h5>}
        {content && <div className="opacity-95">{content}</div>}
        {action && <div className="mt-2.5 flex items-center gap-2">{action}</div>}
      </div>
      {onClose && (
        <button
          type="button"
          onClick={onClose}
          className="p-1 -mr-1 -mt-1 rounded-lg opacity-70 hover:opacity-100 hover:bg-black/5 dark:hover:bg-white/10 transition-all cursor-pointer flex-shrink-0"
          aria-label="Dismiss alert"
        >
          <X className="w-4 h-4" />
        </button>
      )}
    </div>
  );
};
