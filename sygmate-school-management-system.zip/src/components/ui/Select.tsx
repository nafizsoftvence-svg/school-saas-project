import React, { forwardRef } from 'react';
import { ChevronDown, AlertCircle } from 'lucide-react';
import { PortalTheme } from './Button.js';

export type SelectSize = 'sm' | 'md' | 'lg';

export interface SelectOption {
  value: string;
  label: string;
  disabled?: boolean;
  group?: string;
}

export interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  id: string;
  label?: string;
  error?: string;
  helperText?: string;
  options?: SelectOption[];
  portalTheme?: PortalTheme;
  selectSize?: SelectSize;
  placeholder?: string;
  leftIcon?: React.ReactNode;
  required?: boolean;
}

export const Select = forwardRef<HTMLSelectElement, SelectProps>(
  (
    {
      id,
      label,
      error,
      helperText,
      options = [],
      portalTheme = 'default',
      selectSize = 'md',
      placeholder,
      leftIcon,
      required = false,
      className = '',
      disabled,
      children,
      ...props
    },
    ref
  ) => {
    const sizeStyles: Record<SelectSize, { select: string; leftPad: string }> = {
      sm: {
        select: 'py-1.5 text-xs rounded-lg pr-8',
        leftPad: 'pl-8'
      },
      md: {
        select: 'py-2.5 text-sm rounded-xl pr-10',
        leftPad: 'pl-10'
      },
      lg: {
        select: 'py-3 text-base rounded-xl pr-11',
        leftPad: 'pl-11'
      }
    };

    const currentSize = sizeStyles[selectSize] || sizeStyles.md;
    const hasLeftIcon = Boolean(leftIcon);

    // Group options if any option has a group defined
    const hasGroups = options.some((opt) => opt.group);
    const groupedOptions = hasGroups
      ? options.reduce<Record<string, SelectOption[]>>((acc, opt) => {
          const groupName = opt.group || 'Other';
          if (!acc[groupName]) acc[groupName] = [];
          acc[groupName].push(opt);
          return acc;
        }, {})
      : null;

    return (
      <div className="w-full text-left">
        {label && (
          <label
            htmlFor={id}
            className="block text-xs font-semibold text-slate-800 uppercase tracking-wider mb-1.5"
          >
            {label}
            {required && <span className="text-rose-600 ml-1 font-bold">*</span>}
          </label>
        )}
        <div className="relative rounded-xl shadow-2xs">
          {leftIcon && (
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
              {leftIcon}
            </div>
          )}
          <select
            ref={ref}
            id={id}
            disabled={disabled}
            aria-invalid={error ? 'true' : 'false'}
            aria-describedby={error ? `${id}-error` : helperText ? `${id}-helper` : undefined}
            className={`block w-full border appearance-none transition-all duration-150 focus:outline-none focus:ring-2 focus:ring-offset-0 disabled:bg-slate-100 disabled:text-slate-400 disabled:border-slate-200 disabled:cursor-not-allowed cursor-pointer ${
              hasLeftIcon ? currentSize.leftPad : 'pl-3.5'
            } ${currentSize.select} ${
              error
                ? 'border-rose-400 bg-rose-50/60 text-rose-950 focus:border-rose-600 focus:ring-rose-500/20'
                : 'border-slate-300 bg-white text-slate-900 focus:border-blue-600 focus:ring-blue-600/20'
            } ${className}`}
            {...props}
          >
            {placeholder && (
              <option value="" disabled className="text-slate-400 bg-white">
                {placeholder}
              </option>
            )}

            {/* Support both explicit options prop and JSX children */}
            {children
              ? children
              : groupedOptions
              ? Object.entries(groupedOptions).map(([group, opts]) => (
                  <optgroup key={group} label={group} className="font-semibold bg-white text-slate-800">
                    {opts.map((opt) => (
                      <option
                        key={opt.value}
                        value={opt.value}
                        disabled={opt.disabled}
                        className="bg-white text-slate-900 font-normal"
                      >
                        {opt.label}
                      </option>
                    ))}
                  </optgroup>
                ))
              : options.map((opt) => (
                  <option
                    key={opt.value}
                    value={opt.value}
                    disabled={opt.disabled}
                    className="bg-white text-slate-900"
                  >
                    {opt.label}
                  </option>
                ))}
          </select>
          <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none text-slate-400">
            <ChevronDown className="w-4 h-4" />
          </div>
        </div>
        {error ? (
          <p id={`${id}-error`} className="mt-1.5 text-xs text-rose-600 font-semibold flex items-center gap-1">
            <AlertCircle className="w-3.5 h-3.5 flex-shrink-0" />
            <span>{error}</span>
          </p>
        ) : helperText ? (
          <p id={`${id}-helper`} className="mt-1.5 text-xs text-slate-600 font-medium">
            {helperText}
          </p>
        ) : null}
      </div>
    );
  }
);

Select.displayName = 'Select';
