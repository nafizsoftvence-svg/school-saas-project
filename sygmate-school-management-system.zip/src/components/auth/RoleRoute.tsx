import React from 'react';
import { useAuth } from '../../context/AuthContext.js';
import { UserRole } from '../../types/index.js';
import { UnauthorizedPage } from '../../pages/common/UnauthorizedPage.js';

interface RoleRouteProps {
  allowedRoles: UserRole[];
  children: React.ReactNode;
  onBackToPortal?: () => void;
}

export const RoleRoute: React.FC<RoleRouteProps> = ({ allowedRoles, children, onBackToPortal }) => {
  const { role } = useAuth();

  if (!role) {
    return <UnauthorizedPage requiredRole={allowedRoles} onBackToPortal={onBackToPortal} />;
  }

  const isAuthorized =
    allowedRoles.includes(role) ||
    (role === 'SUPER_ADMIN' && allowedRoles.includes('ADMIN'));

  if (!isAuthorized) {
    return <UnauthorizedPage requiredRole={allowedRoles} onBackToPortal={onBackToPortal} />;
  }

  return <>{children}</>;
};
