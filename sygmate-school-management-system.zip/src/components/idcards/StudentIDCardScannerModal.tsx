import React, { useState } from 'react';
import {
  X,
  QrCode,
  ShieldCheck,
  ShieldAlert,
  Search,
  CheckCircle2,
  AlertTriangle,
  User,
  Phone,
  Droplet,
  Calendar,
  Lock,
  Sparkles
} from 'lucide-react';

interface StudentIDCardScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const StudentIDCardScannerModal: React.FC<StudentIDCardScannerModalProps> = ({
  isOpen,
  onClose
}) => {
  const [tokenInput, setTokenInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any | null>(null);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleVerify = async (queryToken?: string) => {
    const term = (queryToken !== undefined ? queryToken : tokenInput).trim();
    if (!term) return;

    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const res = await fetch(`/api/documents-idcards/verify-card/${encodeURIComponent(term)}`);
      const data = await res.json();
      if (!res.ok && !data.verificationStatus) {
        throw new Error(data.error || 'Verification query failed');
      }
      setResult(data);
    } catch (err: any) {
      setError(err.message || 'Verification failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const sampleTokens = [
    { label: 'Liam Rivera (Active Valid)', token: 'ADM-2026-0842', color: 'emerald' },
    { label: 'Noah Vance (Blocked Lost)', token: 'IDC-2026-00846', color: 'rose' },
    { label: 'Maya Rivera (Generated Pass)', token: 'ADM-2026-0844', color: 'amber' }
  ];

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-500/20 text-indigo-400 flex items-center justify-center border border-indigo-500/30">
              <QrCode className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Campus Gate Access Scanner</h3>
              <p className="text-xs text-slate-400">Scan QR token, barcode, or enter admission number to verify identity</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          {/* Scanner Input */}
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3 top-3.5 text-slate-400" />
              <input
                type="text"
                value={tokenInput}
                onChange={(e) => setTokenInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleVerify()}
                placeholder="Scan QR token, Card # (e.g. IDC-2026-00842), or Admission #"
                className="w-full text-xs pl-9 pr-3 py-3 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono"
              />
            </div>
            <button
              type="button"
              onClick={() => handleVerify()}
              disabled={loading || !tokenInput.trim()}
              className="px-5 py-3 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl shadow transition disabled:opacity-50 flex items-center gap-1.5"
            >
              <ShieldCheck className="w-4 h-4" />
              {loading ? 'Scanning...' : 'Verify'}
            </button>
          </div>

          {/* Quick Demo Pre-fills */}
          <div className="flex items-center gap-2 flex-wrap text-xs">
            <span className="text-slate-600 font-medium">Quick Test:</span>
            {sampleTokens.map(s => (
              <button
                key={s.token}
                type="button"
                onClick={() => {
                  setTokenInput(s.token);
                  handleVerify(s.token);
                }}
                className={`text-[11px] font-mono px-2 py-0.5 rounded-lg border transition ${
                  s.color === 'emerald'
                    ? 'bg-emerald-50 border-emerald-200 text-emerald-800 hover:bg-emerald-100'
                    : (s.color === 'rose'
                        ? 'bg-rose-50 border-rose-200 text-rose-800 hover:bg-rose-100'
                        : 'bg-amber-50 border-amber-200 text-amber-800 hover:bg-amber-100')
                }`}
              >
                {s.label}
              </button>
            ))}
          </div>

          {/* Verification Result Display */}
          {error && (
            <div className="p-4 bg-rose-50 border border-rose-200 text-rose-800 rounded-xl text-xs flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {result && (
            <div className={`p-4 rounded-2xl border transition-all ${
              result.verificationStatus === 'VALID_ACCESS'
                ? 'bg-emerald-50/70 border-emerald-300'
                : (result.verificationStatus === 'BLOCKED_CARD'
                    ? 'bg-rose-50 border-rose-300'
                    : 'bg-amber-50 border-amber-300')
            }`}>
              {/* Status Banner */}
              <div className="flex items-center gap-3 pb-3 border-b border-slate-200/60">
                {result.verificationStatus === 'VALID_ACCESS' ? (
                  <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow">
                    <CheckCircle2 className="w-6 h-6" />
                  </div>
                ) : result.verificationStatus === 'BLOCKED_CARD' ? (
                  <div className="w-10 h-10 rounded-xl bg-rose-600 text-white flex items-center justify-center shadow animate-pulse">
                    <Lock className="w-6 h-6" />
                  </div>
                ) : (
                  <div className="w-10 h-10 rounded-xl bg-amber-600 text-white flex items-center justify-center shadow">
                    <AlertTriangle className="w-6 h-6" />
                  </div>
                )}

                <div>
                  <h4 className={`text-sm font-black uppercase tracking-wide ${
                    result.verificationStatus === 'VALID_ACCESS'
                      ? 'text-emerald-900'
                      : (result.verificationStatus === 'BLOCKED_CARD' ? 'text-rose-900' : 'text-amber-900')
                  }`}>
                    {result.verificationStatus === 'VALID_ACCESS'
                      ? 'ACCESS GRANTED — ACTIVE CREDENTIAL'
                      : (result.verificationStatus === 'BLOCKED_CARD'
                          ? 'SECURITY ALERT: CARD BLOCKED / REPORTED LOST'
                          : `VERIFICATION NOTICE: ${result.verificationStatus}`)}
                  </h4>
                  <p className="text-xs text-slate-600 mt-0.5">{result.message}</p>
                </div>
              </div>

              {/* Student Detail Card */}
              {result.student && (
                <div className="mt-3 flex items-start gap-4">
                  <div className="w-16 h-20 rounded-xl overflow-hidden border-2 border-white shadow bg-slate-100 shrink-0">
                    <img
                      src={result.student.avatarUrl || 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&q=80&w=256'}
                      alt={result.student.name}
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </div>

                  <div className="flex-1 space-y-1 text-xs">
                    <div className="flex justify-between items-start">
                      <h5 className="text-sm font-bold text-slate-900">{result.student.name}</h5>
                      <span className="font-mono text-[11px] font-bold text-slate-700">
                        {result.student.admissionNumber}
                      </span>
                    </div>

                    <p className="text-slate-600 font-semibold">
                      {result.student.className} {result.student.sectionName ? `• ${result.student.sectionName}` : ''}
                      {result.student.rollNumber ? ` (Roll: ${result.student.rollNumber})` : ''}
                    </p>

                    <div className="flex items-center gap-3 text-slate-600 pt-1">
                      {result.student.bloodGroup && (
                        <span className="flex items-center gap-1 font-bold text-rose-700 bg-rose-100 px-1.5 py-0.5 rounded text-[10px]">
                          <Droplet className="w-3 h-3 fill-rose-600" />
                          {result.student.bloodGroup}
                        </span>
                      )}
                      {result.student.emergencyContact && (
                        <span className="flex items-center gap-1 text-[11px]">
                          <Phone className="w-3 h-3 text-indigo-600" />
                          {result.student.emergencyContact}
                        </span>
                      )}
                    </div>

                    {result.card && (
                      <div className="mt-2 pt-2 border-t border-slate-200/80 text-[11px] text-slate-500 flex justify-between font-mono">
                        <span>Card: {result.card.cardNumber}</span>
                        <span>Valid Until: {result.card.expiryDate}</span>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
