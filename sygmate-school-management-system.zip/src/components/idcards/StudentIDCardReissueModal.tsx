import React, { useState } from 'react';
import { X, RefreshCw, AlertTriangle, CreditCard, ShieldAlert, CheckCircle2 } from 'lucide-react';
import { StudentIDCard } from '../../types';

interface StudentIDCardReissueModalProps {
  card: StudentIDCard;
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (updatedCard: StudentIDCard) => void;
}

export const StudentIDCardReissueModal: React.FC<StudentIDCardReissueModalProps> = ({
  card,
  isOpen,
  onClose,
  onSuccess
}) => {
  const [reasonCategory, setReasonCategory] = useState<'LOST' | 'DAMAGED' | 'DETAILS_UPDATE' | 'OTHER'>('LOST');
  const [reasonDetails, setReasonDetails] = useState('');
  const [applyReplacementFee, setApplyReplacementFee] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const nextReissueCount = (card.reissueCount || 0) + 1;
  const baseCardNumber = card.cardNumber.split('-R')[0];
  const projectedCardNumber = `${baseCardNumber}-R${nextReissueCount}`;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const fullReason = `${reasonCategory}: ${reasonDetails.trim() || 'Institutional card replacement requested.'}`;

    try {
      const token = localStorage.getItem('sygmate_auth_token') || localStorage.getItem('token');
      const res = await fetch(`/api/documents-idcards/id-cards/${card.id}/reissue`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {})
        },
        body: JSON.stringify({
          reason: fullReason,
          markIssued: true
        })
      });

      const isJson = (res.headers.get('content-type') || '').includes('application/json');
      const data = isJson ? await res.json() : null;
      if (!res.ok || !data?.success) {
        throw new Error(data?.error || `Failed to reissue card (HTTP ${res.status})`);
      }

      onSuccess(data.data);
      onClose();
    } catch (err: any) {
      setError(err.message || 'An error occurred while reissuing the card.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="px-6 py-4 bg-gradient-to-r from-amber-600 to-amber-700 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-white/15 flex items-center justify-center">
              <RefreshCw className="w-4 h-4 text-amber-100" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Reissue Student ID Card</h3>
              <p className="text-xs text-amber-100">Invalidates existing card and generates replacement credential</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-white/80 hover:text-white p-1 rounded-lg hover:bg-white/10 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-xl flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0 text-rose-500" />
              {error}
            </div>
          )}

          {/* Student & Card Summary Banner */}
          <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200/80 flex items-center justify-between text-xs">
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Student</span>
              <strong className="text-slate-800 text-sm">{card.studentName}</strong>
              <span className="text-slate-500 block text-[11px] font-mono">{card.admissionNumber}</span>
            </div>
            <div className="text-right">
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Current Card</span>
              <span className="font-mono font-bold text-slate-700">{card.cardNumber}</span>
              <span className="text-[11px] font-semibold text-indigo-600 block">
                → New: {projectedCardNumber}
              </span>
            </div>
          </div>

          {/* Reason Category */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              Reason for Replacement <span className="text-rose-500">*</span>
            </label>
            <div className="grid grid-cols-2 gap-2">
              {[
                { id: 'LOST', label: 'Card Lost / Stolen', icon: ShieldAlert },
                { id: 'DAMAGED', label: 'Physical Damage / Broken', icon: AlertTriangle },
                { id: 'DETAILS_UPDATE', label: 'Student Details / Photo Updated', icon: CreditCard },
                { id: 'OTHER', label: 'Other Administrative Reason', icon: RefreshCw }
              ].map(opt => (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => setReasonCategory(opt.id as any)}
                  className={`p-2.5 rounded-xl border text-left flex items-center gap-2 text-xs font-semibold transition ${
                    reasonCategory === opt.id
                      ? 'bg-amber-50/80 border-amber-400 text-amber-900 shadow-xs'
                      : 'border-slate-200 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <opt.icon className={`w-4 h-4 ${reasonCategory === opt.id ? 'text-amber-600' : 'text-slate-400'}`} />
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Additional Notes */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Incident Details & Remarks
            </label>
            <textarea
              rows={3}
              value={reasonDetails}
              onChange={(e) => setReasonDetails(e.target.value)}
              placeholder="e.g. Student reported lost ID card on campus shuttle Route 4 on Monday morning..."
              className="w-full text-xs p-3 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
            />
          </div>

          {/* Replacement Fee Toggle */}
          <div className="p-3 bg-amber-50/60 rounded-xl border border-amber-200 flex items-start gap-3">
            <input
              type="checkbox"
              id="replacementFee"
              checked={applyReplacementFee}
              onChange={(e) => setApplyReplacementFee(e.target.checked)}
              className="w-4 h-4 mt-0.5 rounded border-amber-300 text-amber-600 focus:ring-amber-500"
            />
            <label htmlFor="replacementFee" className="text-xs text-amber-950 cursor-pointer">
              <strong className="block font-semibold">Post $15.00 Card Replacement Fee to Student Account</strong>
              <span className="text-amber-800 text-[11px]">
                Standard school policy fee for lost credentials. Fee invoice will be automatically appended.
              </span>
            </label>
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 hover:bg-slate-100 rounded-xl transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="flex items-center gap-1.5 px-5 py-2 bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold rounded-xl shadow transition disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
              {loading ? 'Reissuing Card...' : 'Confirm Reissue & Print'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
