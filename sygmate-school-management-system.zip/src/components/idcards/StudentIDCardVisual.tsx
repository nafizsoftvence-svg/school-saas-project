import React, { useState, useRef } from 'react';
import {
  ShieldCheck,
  AlertTriangle,
  QrCode,
  RotateCw,
  Printer,
  Download,
  Phone,
  Droplet,
  MapPin,
  Calendar,
  Building2,
  CheckCircle2,
  Lock,
  Cpu,
  Sparkles
} from 'lucide-react';
import { StudentIDCard, StudentIDCardTemplateLayout } from '../../types';

interface StudentIDCardVisualProps {
  card: Partial<StudentIDCard>;
  scale?: number;
  interactive?: boolean;
  showFlipControls?: boolean;
  onPrint?: () => void;
  onDownload?: () => void;
  className?: string;
  forceSide?: 'front' | 'back';
}

export const StudentIDCardVisual: React.FC<StudentIDCardVisualProps> = ({
  card,
  scale = 1,
  interactive = true,
  showFlipControls = true,
  onPrint,
  onDownload,
  className = '',
  forceSide
}) => {
  const [isFlipped, setIsFlipped] = useState(forceSide === 'back');

  const activeSide = forceSide || (isFlipped ? 'back' : 'front');

  const {
    studentName = 'Student Name',
    admissionNumber = 'ADM-2026-0000',
    cardNumber = 'IDC-2026-00000',
    templateId = 'modern-vertical',
    status = 'ISSUED',
    academicSessionName = '2026-2027 Academic Year',
    className: studentClass = 'Grade 10',
    sectionName = 'Section A',
    rollNumber = 'G10-A-01',
    bloodGroup = 'O+',
    emergencyContact = '+1 (555) 012-3456',
    avatarUrl = 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&q=80&w=256',
    issueDate = '2026-08-20',
    expiryDate = '2027-06-30'
  } = card;

  const isBlocked = status === 'BLOCKED_LOST';
  const isLandscape = templateId === 'classic-horizontal' || templateId === 'smart-card';

  // Helper to generate a crisp stylized QR SVG
  const renderQrPattern = () => (
    <div className="w-14 h-14 bg-white p-1 rounded-md border border-slate-300 shadow-sm flex items-center justify-center relative overflow-hidden">
      <div className="w-full h-full grid grid-cols-5 grid-rows-5 gap-0.5">
        <div className="bg-slate-900 col-span-2 row-span-2 rounded-xs"></div>
        <div className="bg-slate-900"></div>
        <div className="bg-slate-900 col-span-2 row-span-2 rounded-xs"></div>
        <div className="bg-slate-900"></div>
        <div className="bg-transparent"></div>
        <div className="bg-slate-900"></div>
        <div className="bg-slate-900 col-span-2"></div>
        <div className="bg-slate-900 col-span-2 row-span-2 rounded-xs"></div>
        <div className="bg-transparent"></div>
        <div className="bg-slate-900"></div>
        <div className="bg-slate-900"></div>
      </div>
      <div className="absolute inset-0 flex items-center justify-center opacity-80 pointer-events-none">
        <div className="w-3.5 h-3.5 bg-indigo-600 rounded-xs flex items-center justify-center text-[7px] font-black text-white">
          S
        </div>
      </div>
    </div>
  );

  // Helper to render realistic Code-128 barcode
  const renderBarcode = () => (
    <div className="flex flex-col items-center justify-center bg-white px-2 py-0.5 rounded border border-slate-200">
      <div className="flex items-end h-5 gap-[1.5px]">
        {[3, 1, 2, 1, 3, 2, 1, 1, 3, 1, 2, 3, 1, 2, 1, 1, 3, 2, 1, 2, 3, 1, 2, 1, 3].map((h, idx) => (
          <div
            key={idx}
            className="bg-slate-900"
            style={{
              width: idx % 3 === 0 ? '2px' : '1px',
              height: `${12 + (h * 2)}px`
            }}
          />
        ))}
      </div>
      <span className="text-[7.5px] font-mono font-medium tracking-widest text-slate-700 mt-0.5">
        *{cardNumber}*
      </span>
    </div>
  );

  // -------------------------------------------------------------
  // LAYOUT 1: MODERN VERTICAL (Portrait Lanyard Badge)
  // -------------------------------------------------------------
  const renderModernVerticalFront = () => (
    <div className="w-[300px] h-[460px] bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden flex flex-col relative select-none font-sans">
      {/* Lanyard Slot Cutout */}
      <div className="absolute top-2 left-1/2 -translate-x-1/2 w-12 h-2.5 bg-slate-200 rounded-full border border-slate-300 shadow-inner z-20" />

      {/* Header Accent Band */}
      <div className="pt-6 pb-4 px-4 bg-gradient-to-r from-indigo-700 via-indigo-600 to-indigo-800 text-white relative">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-white/10 backdrop-blur-xs flex items-center justify-center border border-white/20">
              <Building2 className="w-5 h-5 text-indigo-100" />
            </div>
            <div>
              <h4 className="text-xs font-bold tracking-wider uppercase text-indigo-100">SYGMATE ACADEMY</h4>
              <p className="text-[9px] text-indigo-200 font-medium">Student Identity Credential</p>
            </div>
          </div>
          <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-white/20 text-white font-semibold">
            2026-27
          </span>
        </div>
      </div>

      {/* Main Body */}
      <div className="p-4 flex-1 flex flex-col items-center text-center">
        {/* Student Avatar with Border Badge */}
        <div className="relative mb-3 mt-1">
          <div className="w-24 h-24 rounded-2xl overflow-hidden border-2 border-indigo-600 shadow-md bg-slate-100">
            <img
              src={avatarUrl}
              alt={studentName}
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          {isBlocked ? (
            <div className="absolute -bottom-2 -right-1 bg-rose-600 text-white p-1 rounded-full shadow border-2 border-white">
              <Lock className="w-3.5 h-3.5" />
            </div>
          ) : (
            <div className="absolute -bottom-2 -right-1 bg-emerald-600 text-white p-1 rounded-full shadow border-2 border-white">
              <ShieldCheck className="w-3.5 h-3.5" />
            </div>
          )}
        </div>

        {/* Student Name & Academic Placement */}
        <h3 className="text-base font-bold text-slate-900 leading-tight">
          {studentName}
        </h3>
        <p className="text-xs font-semibold text-indigo-600 mt-0.5">
          {studentClass} • {sectionName}
        </p>

        {/* Badges strip */}
        <div className="flex items-center gap-1.5 mt-2">
          <span className="text-[10px] font-mono bg-slate-100 text-slate-700 px-2 py-0.5 rounded border border-slate-200 font-semibold">
            Roll: {rollNumber}
          </span>
          <span className="text-[10px] font-bold bg-rose-50 text-rose-700 px-2 py-0.5 rounded border border-rose-200 flex items-center gap-1">
            <Droplet className="w-2.5 h-2.5 fill-rose-600" />
            {bloodGroup}
          </span>
          {isBlocked ? (
            <span className="text-[9px] font-bold bg-rose-100 text-rose-800 px-2 py-0.5 rounded border border-rose-300 uppercase tracking-wide">
              BLOCKED
            </span>
          ) : (
            <span className="text-[9px] font-bold bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded border border-emerald-200 uppercase tracking-wide">
              {status}
            </span>
          )}
        </div>

        {/* Details Grid */}
        <div className="w-full grid grid-cols-2 gap-2 mt-3 text-left bg-slate-50 p-2.5 rounded-xl border border-slate-200/80 text-[10.5px]">
          <div>
            <span className="text-[9px] uppercase font-bold text-slate-600 tracking-wider block">Admission No</span>
            <span className="font-mono font-bold text-slate-800">{admissionNumber}</span>
          </div>
          <div>
            <span className="text-[9px] uppercase font-bold text-slate-600 tracking-wider block">Valid Thru</span>
            <span className="font-semibold text-slate-800">{expiryDate}</span>
          </div>
          <div className="col-span-2 pt-1 border-t border-slate-200 flex items-center justify-between">
            <div>
              <span className="text-[9px] uppercase font-bold text-slate-600 tracking-wider block">Emergency Contact</span>
              <span className="font-semibold text-slate-800 flex items-center gap-1">
                <Phone className="w-2.5 h-2.5 text-indigo-600" />
                {emergencyContact}
              </span>
            </div>
            {renderQrPattern()}
          </div>
        </div>

        {/* Barcode Footer */}
        <div className="mt-auto pt-2 w-full flex justify-center">
          {renderBarcode()}
        </div>
      </div>
    </div>
  );

  // -------------------------------------------------------------
  // LAYOUT 2: CLASSIC HORIZONTAL (Standard CR80 Landscape Badge)
  // -------------------------------------------------------------
  const renderClassicHorizontalFront = () => (
    <div className="w-[430px] h-[260px] bg-white rounded-xl shadow-xl border border-slate-200 overflow-hidden flex flex-col relative select-none font-sans">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-sky-700 via-sky-800 to-slate-900 text-white px-4 py-2.5 flex items-center justify-between border-b-2 border-amber-400">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 bg-white/10 rounded-full flex items-center justify-center border border-white/30">
            <Building2 className="w-4 h-4 text-sky-200" />
          </div>
          <div>
            <h4 className="text-xs font-extrabold tracking-wider text-white">SYGMATE ACADEMY</h4>
            <p className="text-[8.5px] text-sky-200 uppercase tracking-widest font-semibold">Official Student Identity Card</p>
          </div>
        </div>
        <div className="text-right">
          <span className="text-[9px] font-mono bg-sky-900/80 text-amber-300 font-bold px-1.5 py-0.5 rounded border border-amber-400/40">
            {cardNumber}
          </span>
        </div>
      </div>

      {/* Body: Left Photo, Right Information */}
      <div className="p-3 flex-1 flex gap-3.5 items-center">
        {/* Left: Photo & Barcode */}
        <div className="flex flex-col items-center">
          <div className="w-24 h-28 rounded-lg overflow-hidden border-2 border-sky-600 shadow bg-slate-100">
            <img
              src={avatarUrl}
              alt={studentName}
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          <span className="mt-1.5 text-[9.5px] font-mono font-bold text-slate-800">
            {admissionNumber}
          </span>
        </div>

        {/* Right Details */}
        <div className="flex-1 flex flex-col justify-between h-full">
          <div>
            <div className="flex items-start justify-between">
              <div>
                <h3 className="text-sm font-black text-slate-900 leading-snug">
                  {studentName}
                </h3>
                <p className="text-[11px] font-semibold text-sky-700">
                  {studentClass} • {sectionName} (Roll #{rollNumber})
                </p>
              </div>
              <span className="text-[9px] font-bold bg-rose-50 text-rose-700 px-1.5 py-0.5 rounded border border-rose-200 flex items-center gap-0.5">
                <Droplet className="w-2.5 h-2.5 fill-rose-600" />
                {bloodGroup}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-x-2 gap-y-1 mt-2 text-[10px] text-slate-700 bg-slate-50 p-2 rounded border border-slate-200">
              <div>
                <span className="text-[8px] uppercase font-bold text-slate-600 block">Session</span>
                <span className="font-semibold text-slate-800">{academicSessionName}</span>
              </div>
              <div>
                <span className="text-[8px] uppercase font-bold text-slate-600 block">Valid Until</span>
                <span className="font-semibold text-slate-800">{expiryDate}</span>
              </div>
              <div className="col-span-2 flex items-center justify-between pt-1 border-t border-slate-200">
                <span className="text-[8.5px] font-medium text-slate-600">
                  Emergency: <strong className="text-slate-800">{emergencyContact}</strong>
                </span>
                <span className={`text-[8.5px] font-bold px-1.5 py-0.2 rounded uppercase ${
                  isBlocked ? 'bg-rose-100 text-rose-700' : 'bg-emerald-100 text-emerald-800'
                }`}>
                  {status}
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between pt-1">
            {renderBarcode()}
            {renderQrPattern()}
          </div>
        </div>
      </div>
    </div>
  );

  // -------------------------------------------------------------
  // LAYOUT 3: MINIMALIST ACADEMIC (Monochrome / Emerald Accent)
  // -------------------------------------------------------------
  const renderMinimalistAcademicFront = () => (
    <div className="w-[300px] h-[460px] bg-slate-900 text-white rounded-2xl shadow-2xl border border-slate-800 overflow-hidden flex flex-col relative select-none font-sans">
      <div className="p-4 pb-2 flex items-center justify-between border-b border-slate-800">
        <div className="flex items-center gap-1.5">
          <div className="w-6 h-6 rounded bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-xs">
            ∑
          </div>
          <span className="text-xs font-mono font-bold tracking-wider text-slate-200">SYGMATE</span>
        </div>
        <span className="text-[9px] font-mono text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800 font-semibold">
          ACADEMIC PASS
        </span>
      </div>

      <div className="p-5 flex-1 flex flex-col items-center text-center">
        <div className="w-24 h-24 rounded-full p-1 bg-gradient-to-tr from-emerald-500 to-teal-400 mb-3 shadow-lg">
          <img
            src={avatarUrl}
            alt={studentName}
            className="w-full h-full object-cover rounded-full bg-slate-800"
            referrerPolicy="no-referrer"
          />
        </div>

        <h3 className="text-base font-bold text-white tracking-tight">{studentName}</h3>
        <p className="text-xs text-emerald-400 font-medium mt-0.5">
          {studentClass} • {sectionName}
        </p>

        <div className="w-full bg-slate-800/80 rounded-xl p-3 mt-4 text-left text-[11px] border border-slate-700 space-y-1.5">
          <div className="flex justify-between">
            <span className="text-slate-400">Admission No:</span>
            <span className="font-mono font-bold text-slate-100">{admissionNumber}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">Roll Number:</span>
            <span className="font-semibold text-slate-100">{rollNumber}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">Blood Group:</span>
            <span className="font-bold text-rose-400">{bloodGroup}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">Emergency:</span>
            <span className="font-semibold text-slate-100">{emergencyContact}</span>
          </div>
          <div className="flex justify-between pt-1 border-t border-slate-700">
            <span className="text-slate-400">Card ID:</span>
            <span className="font-mono text-emerald-400">{cardNumber}</span>
          </div>
        </div>

        <div className="mt-auto w-full pt-3 flex items-center justify-between">
          <div className="text-left">
            <span className="text-[8px] uppercase font-bold text-slate-500 block">Authorized Signature</span>
            <div className="h-6 flex items-end">
              <span className="font-serif italic text-sm text-emerald-400">A. Sterling</span>
            </div>
          </div>
          {renderQrPattern()}
        </div>
      </div>
    </div>
  );

  // -------------------------------------------------------------
  // LAYOUT 4: SMART CARD / BIOMETRIC PASS (High-Tech Hologram Style)
  // -------------------------------------------------------------
  const renderSmartCardFront = () => (
    <div className="w-[430px] h-[260px] bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 rounded-xl shadow-2xl border border-indigo-500/30 overflow-hidden flex flex-col relative select-none font-sans text-white">
      {/* Iridescent security holographic overlay sheen */}
      <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-indigo-500/5 to-cyan-500/10 pointer-events-none" />

      {/* Header */}
      <div className="p-3 pb-2 flex items-center justify-between border-b border-indigo-900/60 z-10">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-indigo-600/30 border border-indigo-400/40 flex items-center justify-center">
            <Cpu className="w-4 h-4 text-cyan-300" />
          </div>
          <div>
            <h4 className="text-xs font-bold tracking-wider text-cyan-300">SYGMATE SMART CAMPUS</h4>
            <p className="text-[8px] text-indigo-300 uppercase tracking-widest">Biometric Access & ID Credential</p>
          </div>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-[9px] font-mono text-cyan-300">RFID ENABLED</span>
        </div>
      </div>

      {/* Body */}
      <div className="p-3 flex-1 flex gap-4 items-center z-10">
        {/* Left: EMV Chip + Avatar */}
        <div className="flex flex-col items-center">
          <div className="relative">
            <div className="w-22 h-26 rounded-lg overflow-hidden border border-cyan-400/40 shadow bg-slate-800">
              <img
                src={avatarUrl}
                alt={studentName}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            {/* Simulated Smart Microchip */}
            <div className="absolute -bottom-2 -left-2 w-8 h-6 bg-gradient-to-br from-amber-200 via-amber-400 to-amber-500 rounded-xs border border-amber-600 shadow flex flex-col justify-center px-1">
              <div className="w-full h-[1px] bg-amber-700/60 mb-0.5"></div>
              <div className="w-full h-[1px] bg-amber-700/60"></div>
            </div>
          </div>
          <span className="text-[8.5px] font-mono text-cyan-200 mt-2">{admissionNumber}</span>
        </div>

        {/* Right Info */}
        <div className="flex-1 flex flex-col justify-between h-full">
          <div>
            <div className="flex justify-between items-start">
              <div>
                <h3 className="text-sm font-black text-white">{studentName}</h3>
                <p className="text-[10.5px] text-indigo-300 font-semibold">{studentClass} • {sectionName}</p>
              </div>
              <span className="text-[9px] font-bold bg-indigo-900/80 text-cyan-300 px-2 py-0.5 rounded border border-cyan-500/30">
                {bloodGroup}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-1.5 mt-2 text-[9.5px] bg-indigo-950/60 p-2 rounded-lg border border-indigo-800/60">
              <div>
                <span className="text-[8px] text-indigo-300 font-bold uppercase block">Roll No</span>
                <span className="font-semibold text-slate-100">{rollNumber}</span>
              </div>
              <div>
                <span className="text-[8px] text-indigo-300 font-bold uppercase block">Expires</span>
                <span className="font-semibold text-slate-100">{expiryDate}</span>
              </div>
              <div className="col-span-2 pt-1 border-t border-indigo-900 flex justify-between">
                <span className="text-slate-300">SOS: {emergencyContact}</span>
                <span className="text-emerald-400 font-bold">{status}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between pt-1">
            <div className="text-[8px] text-indigo-400 font-mono">
              TOKEN: {cardNumber}
            </div>
            {renderQrPattern()}
          </div>
        </div>
      </div>
    </div>
  );

  // -------------------------------------------------------------
  // REVERSE SIDE (CARD BACK - APPLIES ACROSS FORMATS)
  // -------------------------------------------------------------
  const renderCardBack = () => {
    if (isLandscape) {
      return (
        <div className="w-[430px] h-[260px] bg-slate-50 text-slate-800 rounded-xl shadow-xl border border-slate-200 p-4 flex flex-col justify-between select-none font-sans">
          <div>
            <div className="flex items-center justify-between border-b border-slate-200 pb-2">
              <div className="flex items-center gap-1.5">
                <Building2 className="w-4 h-4 text-indigo-600" />
                <span className="text-xs font-bold text-slate-900">SYGMATE ACADEMY RULES & SAFETY</span>
              </div>
              <span className="text-[9px] text-slate-600 font-mono">{cardNumber}</span>
            </div>

            <p className="text-[9.5px] text-slate-600 leading-relaxed mt-2">
              1. This identity card is institutional property and must be worn or presented upon entry into campus premises, examination halls, laboratories, and transport vehicles.<br/>
              2. Loss of this card must be immediately reported to the Administration Office.<br/>
              3. Unauthorized alteration, duplication, or transfer of this card will result in disciplinary action.
            </p>
          </div>

          <div className="bg-amber-50 border border-amber-200 p-2 rounded text-[9px] text-amber-900">
            <strong>Campus Dispatch Hotline:</strong> +1 (555) 012-3456 • <strong>Emergency Security:</strong> +1 (555) 012-9999<br/>
            <strong>Campus Address:</strong> 100 Academic Way, Cambridge, MA 02138
          </div>

          <div className="flex items-center justify-between pt-1 border-t border-slate-200">
            <div className="text-left">
              <span className="text-[8px] font-bold uppercase text-slate-600 block">Authorized Signatory</span>
              <span className="font-serif italic text-xs text-slate-800">Arthur Sterling, Ph.D.</span>
            </div>
            {renderBarcode()}
          </div>
        </div>
      );
    }

    // Portrait Back
    return (
      <div className="w-[300px] h-[460px] bg-slate-50 text-slate-800 rounded-2xl shadow-xl border border-slate-200 p-5 flex flex-col justify-between select-none font-sans">
        <div>
          {/* Lanyard Slot Cutout */}
          <div className="w-12 h-2.5 bg-slate-200 rounded-full border border-slate-300 shadow-inner mx-auto mb-4" />

          <div className="text-center border-b border-slate-200 pb-3">
            <h4 className="text-xs font-bold text-slate-900">TERMS & CONDITIONS</h4>
            <p className="text-[9px] text-slate-600 mt-0.5">Sygmate Academy of Excellence</p>
          </div>

          <div className="mt-3 space-y-2 text-[10px] text-slate-600 leading-relaxed">
            <p>• This institutional credential must be carried by the student during all school hours and official extracurricular trips.</p>
            <p>• It serves as official access authorization for library borrowing, examination halls, cafeteria debit, and school transport.</p>
            <p>• If found, please drop into any mailbox or return to the Student Affairs Desk.</p>
          </div>

          <div className="mt-4 p-2.5 bg-indigo-50/80 rounded-xl border border-indigo-100 text-[9.5px] text-indigo-900">
            <div className="font-bold flex items-center gap-1 mb-1">
              <MapPin className="w-3 h-3 text-indigo-600" />
              Main Campus Address
            </div>
            <p className="text-slate-600">100 Academic Way, Cambridge, MA 02138</p>
            <p className="text-slate-600 mt-0.5">Email: registrar@sygmate.edu</p>
          </div>
        </div>

        <div>
          <div className="border-t border-slate-200 pt-3 flex items-center justify-between">
            <div>
              <span className="text-[8px] uppercase font-bold text-slate-600 block">Registrar Signature</span>
              <span className="font-serif italic text-sm text-indigo-950 font-bold">Arthur Sterling</span>
            </div>
            <div className="w-9 h-9 rounded-full border border-indigo-300 flex items-center justify-center text-[7px] font-bold text-indigo-700 uppercase tracking-tighter text-center leading-none">
              SEAL<br/>2026
            </div>
          </div>

          <div className="mt-3 flex justify-center">
            {renderBarcode()}
          </div>
        </div>
      </div>
    );
  };

  // Select front layout
  const renderFront = () => {
    switch (templateId) {
      case 'classic-horizontal':
        return renderClassicHorizontalFront();
      case 'minimalist-academic':
        return renderMinimalistAcademicFront();
      case 'smart-card':
        return renderSmartCardFront();
      case 'modern-vertical':
      default:
        return renderModernVerticalFront();
    }
  };

  return (
    <div className={`flex flex-col items-center ${className}`}>
      {/* Card Stage with Scaling */}
      <div
        className="transition-transform duration-300 origin-center"
        style={{ transform: `scale(${scale})` }}
      >
        {activeSide === 'front' ? renderFront() : renderCardBack()}
      </div>

      {/* Interactive Controls Bar */}
      {interactive && showFlipControls && (
        <div className="mt-4 flex items-center gap-2 bg-white/90 backdrop-blur-xs px-3 py-1.5 rounded-full border border-slate-200 shadow-sm">
          <button
            type="button"
            onClick={() => setIsFlipped(prev => !prev)}
            className="flex items-center gap-1.5 text-xs font-semibold text-indigo-600 hover:text-indigo-800 px-2.5 py-1 rounded-full hover:bg-indigo-50 transition"
          >
            <RotateCw className="w-3.5 h-3.5" />
            {isFlipped ? 'Flip to Front' : 'Flip to Back'}
          </button>

          {onPrint && (
            <>
              <div className="w-[1px] h-4 bg-slate-200" />
              <button
                type="button"
                onClick={onPrint}
                className="flex items-center gap-1.5 text-xs font-semibold text-slate-700 hover:text-slate-900 px-2.5 py-1 rounded-full hover:bg-slate-100 transition"
                title="Print ID Card"
              >
                <Printer className="w-3.5 h-3.5 text-slate-500" />
                Print
              </button>
            </>
          )}

          {onDownload && (
            <>
              <div className="w-[1px] h-4 bg-slate-200" />
              <button
                type="button"
                onClick={onDownload}
                className="flex items-center gap-1.5 text-xs font-semibold text-slate-700 hover:text-slate-900 px-2.5 py-1 rounded-full hover:bg-slate-100 transition"
                title="Download Digital Pass"
              >
                <Download className="w-3.5 h-3.5 text-slate-500" />
                Download
              </button>
            </>
          )}
        </div>
      )}
    </div>
  );
};
