import React, { useState, useEffect } from 'react';
import { X, CreditCard, Users, Check, AlertTriangle, Sparkles, Layers } from 'lucide-react';
import { StudentIDCardTemplateLayout } from '../../types';

interface StudentIDCardGenerateModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  classes: Array<{ id: string; name: string }>;
  sections: Array<{ id: string; name: string; classId?: string }>;
  preselectedStudentId?: string;
  preselectedStudentName?: string;
}

export const StudentIDCardGenerateModal: React.FC<StudentIDCardGenerateModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  classes,
  sections,
  preselectedStudentId,
  preselectedStudentName
}) => {
  const [mode, setMode] = useState<'single' | 'bulk'>(preselectedStudentId ? 'single' : 'bulk');
  const [selectedClassId, setSelectedClassId] = useState<string>('');
  const [selectedSectionId, setSelectedSectionId] = useState<string>('');
  const [templateId, setTemplateId] = useState<StudentIDCardTemplateLayout>('modern-vertical');
  const [expiryDate, setExpiryDate] = useState<string>('2027-06-30');
  const [autoIssue, setAutoIssue] = useState<boolean>(true);
  const [customNotes, setCustomNotes] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (classes && classes.length > 0 && !selectedClassId) {
      setSelectedClassId(classes?.[0]?.id || '');
    }
  }, [classes]);

  if (!isOpen) return null;

  const filteredSections = selectedClassId
    ? (sections || []).filter(s => !s.classId || s.classId === selectedClassId)
    : (sections || []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const token = localStorage.getItem('sygmate_auth_token') || localStorage.getItem('token');
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {})
    };

    try {
      if (mode === 'single' && preselectedStudentId) {
        const res = await fetch('/api/documents-idcards/generate-single', {
          method: 'POST',
          headers,
          body: JSON.stringify({
            studentId: preselectedStudentId,
            templateId,
            expiryDate,
            customNotes,
            autoIssue
          })
        });
        const isJson = (res.headers.get('content-type') || '').includes('application/json');
        const data = isJson ? await res.json() : null;
        if (!res.ok || !data?.success) throw new Error(data?.error || `Failed to generate card (HTTP ${res.status})`);
      } else {
        const res = await fetch('/api/documents-idcards/generate-bulk', {
          method: 'POST',
          headers,
          body: JSON.stringify({
            classId: selectedClassId || undefined,
            sectionId: selectedSectionId || undefined,
            templateId,
            expiryDate
          })
        });
        const isJson = (res.headers.get('content-type') || '').includes('application/json');
        const data = isJson ? await res.json() : null;
        if (!res.ok || !data?.success) throw new Error(data?.error || `Failed to generate bulk cards (HTTP ${res.status})`);
      }

      onSuccess();
      onClose();
    } catch (err: any) {
      setError(err.message || 'An error occurred during card generation.');
    } finally {
      setLoading(false);
    }
  };

  const templatesList: Array<{ id: StudentIDCardTemplateLayout; title: string; desc: string; badge: string }> = [
    {
      id: 'modern-vertical',
      title: 'Modern Lanyard Badge',
      desc: 'Portrait format with lanyard cutout, photo, and dynamic QR scanner.',
      badge: 'Most Popular'
    },
    {
      id: 'classic-horizontal',
      title: 'Classic CR80 Landscape',
      desc: 'Standard wallet card landscape layout with barcode and security seal.',
      badge: 'Standard'
    },
    {
      id: 'minimalist-academic',
      title: 'Minimalist Academic Pass',
      desc: 'Clean editorial typography with registrar signature & high-contrast.',
      badge: 'Monochrome'
    },
    {
      id: 'smart-card',
      title: 'Smart Biometric Pass',
      desc: 'High-tech badge with simulated EMV smart-chip and NFC badge sheen.',
      badge: 'High-Security'
    }
  ];

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="px-6 py-4 bg-gradient-to-r from-indigo-600 to-indigo-700 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-white/15 flex items-center justify-center">
              <CreditCard className="w-4 h-4 text-indigo-100" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Generate Student ID Cards</h3>
              <p className="text-xs text-indigo-100">Create digital and print-ready identity credentials</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-white/80 hover:text-white p-1 rounded-lg hover:bg-white/10 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-xl flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0 text-rose-500" />
              {error}
            </div>
          )}

          {/* Mode Switcher */}
          {!preselectedStudentId && (
            <div className="flex gap-2 p-1 bg-slate-100 rounded-xl border border-slate-200">
              <button
                type="button"
                onClick={() => setMode('bulk')}
                className={`flex-1 flex items-center justify-center gap-2 py-2 text-xs font-bold rounded-lg transition ${
                  mode === 'bulk' ? 'bg-white text-indigo-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Users className="w-3.5 h-3.5" />
                Bulk Generate (Class / Section)
              </button>
              <button
                type="button"
                onClick={() => setMode('single')}
                className={`flex-1 flex items-center justify-center gap-2 py-2 text-xs font-bold rounded-lg transition ${
                  mode === 'single' ? 'bg-white text-indigo-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <CreditCard className="w-3.5 h-3.5" />
                Targeted Individual
              </button>
            </div>
          )}

          {/* Student Banner if preselected */}
          {preselectedStudentId && (
            <div className="p-3 bg-indigo-50 border border-indigo-200 rounded-xl flex items-center justify-between text-xs">
              <span className="font-semibold text-indigo-900">
                Generating card for: <strong>{preselectedStudentName || 'Selected Student'}</strong>
              </span>
              <span className="text-[10px] font-mono bg-indigo-200/70 text-indigo-800 px-2 py-0.5 rounded font-bold">
                Single Generation
              </span>
            </div>
          )}

          {/* Bulk Filters (Class & Section) */}
          {mode === 'bulk' && !preselectedStudentId && (
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Target Class <span className="text-rose-500">*</span>
                </label>
                <select
                  value={selectedClassId}
                  onChange={(e) => {
                    setSelectedClassId(e.target.value);
                    setSelectedSectionId('');
                  }}
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  required
                >
                  <option value="">All Active Classes</option>
                  {classes.map(c => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Section (Optional)
                </label>
                <select
                  value={selectedSectionId}
                  onChange={(e) => setSelectedSectionId(e.target.value)}
                  className="w-full text-xs p-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="">All Sections</option>
                  {filteredSections.map(s => (
                    <option key={s.id} value={s.id}>{s.name}</option>
                  ))}
                </select>
              </div>
            </div>
          )}

          {/* Card Template Style Picker */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-2">
              Select ID Card Template Layout <span className="text-rose-500">*</span>
            </label>
            <div className="grid grid-cols-2 gap-2.5">
              {templatesList.map(t => (
                <div
                  key={t.id}
                  onClick={() => setTemplateId(t.id)}
                  className={`p-3 rounded-xl border cursor-pointer transition relative ${
                    templateId === t.id
                      ? 'bg-indigo-50/60 border-indigo-500 shadow-xs'
                      : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold text-slate-800">{t.title}</h4>
                    <span className="text-[9px] font-semibold px-1.5 py-0.5 rounded bg-slate-100 text-slate-600">
                      {t.badge}
                    </span>
                  </div>
                  <p className="text-[10.5px] text-slate-500 mt-1 leading-normal">{t.desc}</p>
                  {templateId === t.id && (
                    <div className="absolute bottom-2 right-2 w-4 h-4 rounded-full bg-indigo-600 text-white flex items-center justify-center">
                      <Check className="w-2.5 h-2.5 stroke-[3]" />
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Validity & Expiry Date */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Card Expiry Date <span className="text-rose-500">*</span>
              </label>
              <input
                type="date"
                value={expiryDate}
                onChange={(e) => setExpiryDate(e.target.value)}
                className="w-full text-xs p-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Default Issuance Status
              </label>
              <div className="pt-2">
                <label className="flex items-center gap-2 text-xs font-semibold text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={autoIssue}
                    onChange={(e) => setAutoIssue(e.target.checked)}
                    className="w-4 h-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                  />
                  Mark immediately as Active / Issued
                </label>
              </div>
            </div>
          </div>

          {/* Custom Notes */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Custom Administrative Notes (Optional)
            </label>
            <input
              type="text"
              value={customNotes}
              onChange={(e) => setCustomNotes(e.target.value)}
              placeholder="e.g. Batch 2026-27 Inaugural Issuance"
              className="w-full text-xs p-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 hover:bg-slate-100 rounded-xl transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="flex items-center gap-1.5 px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl shadow transition disabled:opacity-50"
            >
              <CreditCard className="w-3.5 h-3.5" />
              {loading ? 'Processing...' : 'Generate ID Cards'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
