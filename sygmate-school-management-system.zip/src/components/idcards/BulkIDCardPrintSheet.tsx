import React, { useRef, useState } from 'react';
import { Printer, X, LayoutGrid, CheckSquare, Sparkles } from 'lucide-react';
import { StudentIDCard } from '../../types';
import { StudentIDCardVisual } from './StudentIDCardVisual';
import { downloadElementPdf, triggerSafePrint } from '../../utils/printPdf.js';

interface BulkIDCardPrintSheetProps {
  cards: StudentIDCard[];
  onClose: () => void;
}

export const BulkIDCardPrintSheet: React.FC<BulkIDCardPrintSheetProps> = ({
  cards,
  onClose
}) => {
  const [layoutMode, setLayoutMode] = React.useState<'grid-4' | 'grid-8' | 'single'>('grid-4');
  const [includeBack, setIncludeBack] = React.useState<boolean>(true);
  const [isExporting, setIsExporting] = useState<boolean>(false);

  const handlePrint = async () => {
    try {
      setIsExporting(true);
      const filename = `Student_ID_Cards_Batch_${cards.length}_${new Date().toISOString().split('T')[0]}.pdf`;

      await downloadElementPdf('printable-id-card-sheet', filename, {
        orientation: 'portrait'
      });

      await triggerSafePrint({
        elementOrId: 'printable-id-card-sheet',
        fallbackTitle: `Student_ID_Cards_Batch`
      });
    } catch (err) {
      console.error('ID card print error:', err);
      try {
        window.print();
      } catch {
        // ignore
      }
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-sm flex flex-col items-center justify-center p-4 overflow-y-auto">
      {/* Non-printable Control Toolbar */}
      <div className="print:hidden w-full max-w-5xl bg-white rounded-2xl shadow-2xl border border-slate-200 p-4 mb-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center border border-indigo-100">
            <Printer className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-900">ID Card Batch Printing Sheet</h2>
            <p className="text-xs text-slate-500">
              Ready to print {cards.length} student identity badge{cards.length > 1 ? 's' : ''} with exact standard dimensions and cut guides.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {/* Layout Mode Picker */}
          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl border border-slate-200 text-xs font-semibold">
            <button
              type="button"
              onClick={() => setLayoutMode('grid-4')}
              className={`px-3 py-1.5 rounded-lg transition ${
                layoutMode === 'grid-4' ? 'bg-white text-indigo-600 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              4 per Sheet
            </button>
            <button
              type="button"
              onClick={() => setLayoutMode('grid-8')}
              className={`px-3 py-1.5 rounded-lg transition ${
                layoutMode === 'grid-8' ? 'bg-white text-indigo-600 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              8 per Sheet
            </button>
            <button
              type="button"
              onClick={() => setLayoutMode('single')}
              className={`px-3 py-1.5 rounded-lg transition ${
                layoutMode === 'single' ? 'bg-white text-indigo-600 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Single Card
            </button>
          </div>

          {/* Reverse Side Checkbox */}
          <label className="flex items-center gap-2 text-xs font-semibold text-slate-700 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={includeBack}
              onChange={(e) => setIncludeBack(e.target.checked)}
              className="w-4 h-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
            />
            Include Card Back
          </label>

          <button
            type="button"
            onClick={handlePrint}
            disabled={isExporting}
            className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-xs font-bold px-4 py-2 rounded-xl shadow-md transition"
          >
            <Printer className="w-4 h-4" />
            {isExporting ? 'Generating PDF...' : 'Print / Save PDF'}
          </button>

          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-2 rounded-xl hover:bg-slate-100 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Printable Paper Canvas */}
      <div className="w-full max-w-5xl bg-white rounded-2xl shadow-xl p-8 overflow-y-auto max-h-[80vh] print:max-h-none print:shadow-none print:p-0 print:m-0 print:w-full">
        <style dangerouslySetInnerHTML={{
          __html: `
            @media print {
              body * {
                visibility: hidden;
              }
              #printable-id-card-sheet, #printable-id-card-sheet * {
                visibility: visible;
              }
              #printable-id-card-sheet {
                position: absolute;
                left: 0;
                top: 0;
                width: 100%;
                margin: 0;
                padding: 0;
              }
              @page {
                size: A4 portrait;
                margin: 10mm;
              }
            }
          `
        }} />

        <div id="printable-id-card-sheet" className="space-y-8 print:space-y-6">
          <div className={`grid gap-6 ${
            layoutMode === 'grid-8'
              ? 'grid-cols-2 md:grid-cols-4 print:grid-cols-4'
              : (layoutMode === 'single' ? 'grid-cols-1 max-w-md mx-auto' : 'grid-cols-1 md:grid-cols-2 print:grid-cols-2')
          }`}>
            {cards.map((card) => {
              const cardScale = layoutMode === 'grid-8' ? 0.75 : (layoutMode === 'grid-4' ? 0.9 : 1);

              return (
                <div key={card.id} className="flex flex-col items-center gap-3 p-3 border border-dashed border-slate-300 rounded-xl relative print:break-inside-avoid">
                  {/* Cutting Guides Corner Marks */}
                  <div className="absolute top-0 left-0 w-2.5 h-2.5 border-t-2 border-l-2 border-slate-400" />
                  <div className="absolute top-0 right-0 w-2.5 h-2.5 border-t-2 border-r-2 border-slate-400" />
                  <div className="absolute bottom-0 left-0 w-2.5 h-2.5 border-b-2 border-l-2 border-slate-400" />
                  <div className="absolute bottom-0 right-0 w-2.5 h-2.5 border-b-2 border-r-2 border-slate-400" />

                  {/* Card Front */}
                  <div className="flex flex-col items-center">
                    <span className="text-[10px] font-mono text-slate-600 print:hidden mb-1">
                      FRONT — {card.admissionNumber}
                    </span>
                    <StudentIDCardVisual
                      card={card}
                      scale={cardScale}
                      interactive={false}
                      showFlipControls={false}
                      forceSide="front"
                    />
                  </div>

                  {/* Optional Card Back */}
                  {includeBack && (
                    <div className="flex flex-col items-center mt-2 pt-2 border-t border-slate-200">
                      <span className="text-[10px] font-mono text-slate-600 print:hidden mb-1">
                        BACK — {card.admissionNumber}
                      </span>
                      <StudentIDCardVisual
                        card={card}
                        scale={cardScale}
                        interactive={false}
                        showFlipControls={false}
                        forceSide="back"
                      />
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
