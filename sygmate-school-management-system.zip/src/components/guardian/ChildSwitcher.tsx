import React from 'react';
import { Users, GraduationCap, CheckCircle } from 'lucide-react';
import { GuardianChildSummary } from '../../types/index.js';

interface ChildSwitcherProps {
  childrenList: GuardianChildSummary[];
  selectedChildId?: string;
  onSelectChild: (studentId: string) => void;
  className?: string;
}

export const ChildSwitcher: React.FC<ChildSwitcherProps> = ({
  childrenList,
  selectedChildId,
  onSelectChild,
  className = ''
}) => {
  if (!childrenList || (childrenList?.length || 0) <= 1) {
    return null;
  }

  return (
    <div
      id="guardian-child-switcher"
      className={`bg-white rounded-xl border border-slate-200/80 shadow-sm p-4 ${className}`}
    >
      <div className="flex items-center justify-between mb-3 px-1">
        <div className="flex items-center gap-2">
          <Users className="w-4 h-4 text-blue-600" />
          <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
            Switch Linked Scholar
          </h3>
        </div>
        <span className="text-[11px] font-medium text-slate-500">
          {childrenList?.length || 0} wards registered
        </span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
        {(childrenList || []).map((child) => {
          const isSelected = child.id === selectedChildId;
          return (
            <button
              key={child.id}
              type="button"
              id={`child-switch-btn-${child.id}`}
              onClick={() => onSelectChild(child.id)}
              className={`flex items-center gap-3 p-3 rounded-xl border text-left transition-all duration-150 ${
                isSelected
                  ? 'bg-blue-50/70 border-blue-500 shadow-sm ring-1 ring-blue-500'
                  : 'bg-slate-50/50 border-slate-200/80 hover:bg-slate-100/70 hover:border-slate-300'
              }`}
            >
              {/* Avatar */}
              <div className="relative shrink-0">
                {child.avatarUrl ? (
                  <img
                    src={child.avatarUrl}
                    alt={child.name}
                    className="w-10 h-10 rounded-xl object-cover border border-slate-200"
                    onError={(e) => {
                      (e.currentTarget as HTMLElement).style.display = 'none';
                      if (e.currentTarget.nextElementSibling) {
                        (e.currentTarget.nextElementSibling as HTMLElement).style.display = 'flex';
                      }
                    }}
                  />
                ) : null}
                <div
                  className={`w-10 h-10 rounded-xl bg-gradient-to-br from-blue-100 to-indigo-100 text-blue-700 font-bold text-sm flex items-center justify-center border border-slate-200 ${
                    child.avatarUrl ? 'hidden' : 'flex'
                  }`}
                >
                  {child.firstName?.[0] || child.name?.[0] || 'S'}
                </div>
                {isSelected && (
                  <div className="absolute -top-1 -right-1 bg-blue-600 text-white rounded-full p-0.5 shadow-sm">
                    <CheckCircle className="w-3 h-3" />
                  </div>
                )}
              </div>

              {/* Scholar Details */}
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-900 text-xs truncate">
                    {child.name}
                  </span>
                  {isSelected && (
                    <span className="text-[10px] font-bold text-blue-600 uppercase tracking-wider shrink-0 ml-1">
                      Active
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-1.5 text-[11px] text-slate-500 mt-0.5 truncate">
                  <GraduationCap className="w-3 h-3 text-slate-400 shrink-0" />
                  <span className="truncate">{child.className}</span>
                  <span>•</span>
                  <span className="font-mono">{child.admissionNumber}</span>
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
