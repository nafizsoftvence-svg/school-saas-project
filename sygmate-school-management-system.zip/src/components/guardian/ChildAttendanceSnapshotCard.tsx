import React from 'react';
import {
  Clock,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  FileText,
  CalendarCheck,
  ArrowRight
} from 'lucide-react';
import { GuardianChildAttendanceSnapshot } from '../../types/index.js';

interface ChildAttendanceSnapshotCardProps {
  snapshot?: GuardianChildAttendanceSnapshot;
  onNavigate?: (view: string) => void;
  className?: string;
}

export const ChildAttendanceSnapshotCard: React.FC<ChildAttendanceSnapshotCardProps> = ({
  snapshot,
  onNavigate,
  className = ''
}) => {
  if (!snapshot || !snapshot.hasAttendanceData) {
    return (
      <div
        id="attendance-snapshot-empty"
        className={`bg-white rounded-xl border border-slate-200/80 shadow-sm p-6 flex flex-col justify-between ${className}`}
      >
        <div className="flex items-center justify-between border-b border-slate-100 pb-4">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-emerald-50 text-emerald-600">
              <CalendarCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-base">Attendance Snapshot</h3>
              <p className="text-xs text-slate-500">Official institutional roll records</p>
            </div>
          </div>
          <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-slate-100 text-slate-600">
            Session
          </span>
        </div>

        <div className="py-8 text-center space-y-3">
          <div className="w-12 h-12 rounded-full bg-slate-50 border border-slate-200 flex items-center justify-center mx-auto text-slate-400">
            <Clock className="w-6 h-6" />
          </div>
          <p className="text-sm font-medium text-slate-700">No Attendance Records Yet</p>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Attendance marks will appear here once daily roll-call sessions are submitted by homeroom faculty.
          </p>
        </div>

        {onNavigate && (
          <div className="pt-4 border-t border-slate-100 flex justify-end">
            <button
              type="button"
              onClick={() => onNavigate('guardian-attendance')}
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-blue-600 hover:text-blue-700 hover:underline"
            >
              Open Attendance Ledger
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </div>
    );
  }

  const {
    attendancePercentage,
    statusEvaluation,
    presentCount,
    absentCount,
    lateCount,
    leaveCount,
    totalSchoolDays,
    lastMarkedDate,
    lastMarkedStatus
  } = snapshot;

  const getEvaluationBadge = () => {
    switch (statusEvaluation) {
      case 'EXCELLENT':
        return (
          <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
            Excellent Standing
          </span>
        );
      case 'GOOD':
        return (
          <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-blue-50 text-blue-700 border border-blue-200">
            Good Standing
          </span>
        );
      case 'SATISFACTORY':
        return (
          <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-amber-50 text-amber-700 border border-amber-200">
            Satisfactory
          </span>
        );
      default:
        return (
          <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-rose-50 text-rose-700 border border-rose-200">
            Attention Required
          </span>
        );
    }
  };

  const getProgressColor = (pct: number) => {
    if (pct >= 90) return 'bg-emerald-500';
    if (pct >= 80) return 'bg-blue-500';
    if (pct >= 75) return 'bg-amber-500';
    return 'bg-rose-500';
  };

  return (
    <div
      id="attendance-snapshot-card"
      className={`bg-white rounded-xl border border-slate-200/80 shadow-sm p-6 flex flex-col justify-between transition-all duration-200 hover:shadow-md ${className}`}
    >
      <div>
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 pb-4">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-emerald-50 text-emerald-600">
              <CalendarCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-base">Attendance Snapshot</h3>
              <p className="text-xs text-slate-500">Official institutional roll records</p>
            </div>
          </div>
          {getEvaluationBadge()}
        </div>

        {/* Big percentage & Progress Bar */}
        <div className="my-5 p-4 rounded-xl bg-slate-50/70 border border-slate-100 space-y-2.5">
          <div className="flex items-baseline justify-between">
            <span className="text-xs font-semibold text-slate-600">Overall Attendance Rate</span>
            <span className="text-3xl font-extrabold text-slate-900 tracking-tight">
              {Number(attendancePercentage ?? 0).toFixed(1)}%
            </span>
          </div>

          <div className="w-full bg-slate-200 h-2.5 rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-500 ${getProgressColor(
                attendancePercentage
              )}`}
              style={{ width: `${Math.min(100, Math.max(0, attendancePercentage))}%` }}
            />
          </div>

          <div className="flex items-center justify-between text-[11px] text-slate-500 pt-0.5">
            <span>Minimum school policy: 75%</span>
            <span>{totalSchoolDays} Recorded Days</span>
          </div>
        </div>

        {/* 4 Attendance Metrics */}
        <div className="grid grid-cols-4 gap-2">
          <div className="bg-emerald-50/60 p-2.5 rounded-lg border border-emerald-100 text-center">
            <div className="flex items-center justify-center gap-1 text-emerald-700 mb-0.5">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span className="text-[11px] font-semibold">Present</span>
            </div>
            <span className="text-lg font-bold text-emerald-800">{presentCount}</span>
          </div>

          <div className="bg-rose-50/60 p-2.5 rounded-lg border border-rose-100 text-center">
            <div className="flex items-center justify-center gap-1 text-rose-700 mb-0.5">
              <XCircle className="w-3.5 h-3.5" />
              <span className="text-[11px] font-semibold">Absent</span>
            </div>
            <span className="text-lg font-bold text-rose-800">{absentCount}</span>
          </div>

          <div className="bg-amber-50/60 p-2.5 rounded-lg border border-amber-100 text-center">
            <div className="flex items-center justify-center gap-1 text-amber-700 mb-0.5">
              <Clock className="w-3.5 h-3.5" />
              <span className="text-[11px] font-semibold">Late</span>
            </div>
            <span className="text-lg font-bold text-amber-800">{lateCount}</span>
          </div>

          <div className="bg-blue-50/60 p-2.5 rounded-lg border border-blue-100 text-center">
            <div className="flex items-center justify-center gap-1 text-blue-700 mb-0.5">
              <FileText className="w-3.5 h-3.5" />
              <span className="text-[11px] font-semibold">Leave</span>
            </div>
            <span className="text-lg font-bold text-blue-800">{leaveCount}</span>
          </div>
        </div>

        {/* Last marked footer */}
        {lastMarkedDate && (
          <div className="mt-3.5 text-xs text-slate-500 flex items-center justify-between px-1">
            <span>Last roll record:</span>
            <span className="font-semibold text-slate-700">
              {lastMarkedStatus} on {lastMarkedDate}
            </span>
          </div>
        )}
      </div>

      {/* Footer action */}
      {onNavigate && (
        <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between">
          <span className="text-xs text-slate-400">Monthly breakdown & leaves</span>
          <button
            type="button"
            id="btn-view-attendance-details"
            onClick={() => onNavigate('guardian-attendance')}
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-blue-600 hover:text-blue-700 transition-colors"
          >
            Attendance Calendar
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}
    </div>
  );
};
