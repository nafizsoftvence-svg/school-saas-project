import React from 'react';
import {
  CreditCard,
  CheckCircle,
  AlertOctagon,
  Clock,
  ArrowRight,
  Receipt,
  DollarSign
} from 'lucide-react';
import { GuardianChildFeesSnapshot } from '../../types/index.js';

interface ChildFeesSnapshotCardProps {
  snapshot?: GuardianChildFeesSnapshot;
  onNavigate?: (view: string) => void;
  className?: string;
}

export const ChildFeesSnapshotCard: React.FC<ChildFeesSnapshotCardProps> = ({
  snapshot,
  onNavigate,
  className = ''
}) => {
  if (!snapshot || !snapshot.hasFeeRecords) {
    return (
      <div
        id="fees-snapshot-empty"
        className={`bg-white rounded-xl border border-slate-200/80 shadow-sm p-6 flex flex-col justify-between ${className}`}
      >
        <div className="flex items-center justify-between border-b border-slate-100 pb-4">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-emerald-50 text-emerald-600">
              <CreditCard className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-base">Fee & Dues Overview</h3>
              <p className="text-xs text-slate-500">Official institutional billing ledger</p>
            </div>
          </div>
          <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-slate-100 text-slate-600">
            Account Status
          </span>
        </div>

        <div className="py-8 text-center space-y-3">
          <div className="w-12 h-12 rounded-full bg-slate-50 border border-slate-200 flex items-center justify-center mx-auto text-slate-400">
            <CheckCircle className="w-6 h-6 text-emerald-500" />
          </div>
          <p className="text-sm font-medium text-slate-700">No Outstanding Fee Records</p>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            All semester dues are clear or no fee invoices have been assessed for the current academic cycle.
          </p>
        </div>

        {onNavigate && (
          <div className="pt-4 border-t border-slate-100 flex justify-end">
            <button
              type="button"
              onClick={() => onNavigate('guardian-fees')}
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-blue-600 hover:text-blue-700 hover:underline"
            >
              Fee Invoices Ledger
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </div>
    );
  }

  const {
    totalFees,
    totalPaid,
    totalDue,
    totalOverdue,
    latestPaymentStatus,
    nextUpcomingDueDate,
    latestInvoiceNumber
  } = snapshot;

  const getStatusBadge = () => {
    switch (latestPaymentStatus) {
      case 'PAID':
        return (
          <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center gap-1">
            <CheckCircle className="w-3 h-3" />
            Settled in Full
          </span>
        );
      case 'OVERDUE':
        return (
          <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-rose-50 text-rose-700 border border-rose-200 flex items-center gap-1">
            <AlertOctagon className="w-3 h-3" />
            Overdue Balance
          </span>
        );
      case 'PARTIAL':
        return (
          <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-amber-50 text-amber-700 border border-amber-200 flex items-center gap-1">
            <Clock className="w-3 h-3" />
            Partially Paid
          </span>
        );
      default:
        return (
          <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-blue-50 text-blue-700 border border-blue-200">
            Payment Pending
          </span>
        );
    }
  };

  return (
    <div
      id="fees-snapshot-card"
      className={`bg-white rounded-xl border border-slate-200/80 shadow-sm p-6 flex flex-col justify-between transition-all duration-200 hover:shadow-md ${className}`}
    >
      <div>
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 pb-4">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-emerald-50 text-emerald-600">
              <CreditCard className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-base">Fee & Dues Overview</h3>
              <p className="text-xs text-slate-500">Official institutional billing ledger</p>
            </div>
          </div>
          {getStatusBadge()}
        </div>

        {/* Primary Dues Showcase */}
        <div className="my-5 p-4 rounded-xl bg-slate-50/70 border border-slate-100">
          <div className="flex items-baseline justify-between">
            <span className="text-xs font-semibold text-slate-600">Outstanding Balance</span>
            <span
              className={`text-3xl font-extrabold tracking-tight ${
                (totalDue ?? 0) > 0 ? 'text-rose-600' : 'text-emerald-600'
              }`}
            >
              ${Number(totalDue ?? 0).toFixed(2)}
            </span>
          </div>

          <div className="mt-3 pt-3 border-t border-slate-200/60 flex items-center justify-between text-xs text-slate-500">
            <span>
              Total Invoiced:{' '}
              <strong className="text-slate-800 font-semibold">${Number(totalFees ?? 0).toFixed(2)}</strong>
            </span>
            <span>
              Paid to Date:{' '}
              <strong className="text-emerald-700 font-semibold">${Number(totalPaid ?? 0).toFixed(2)}</strong>
            </span>
          </div>
        </div>

        {/* Breakdown of dues and overdue */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-slate-50 p-3 rounded-lg border border-slate-100">
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
              Overdue Amount
            </span>
            <div className="flex items-center gap-1.5 mt-0.5">
              <DollarSign className={`w-4 h-4 ${(totalOverdue ?? 0) > 0 ? 'text-rose-500' : 'text-slate-400'}`} />
              <span className={`text-base font-bold ${(totalOverdue ?? 0) > 0 ? 'text-rose-600' : 'text-slate-700'}`}>
                ${Number(totalOverdue ?? 0).toFixed(2)}
              </span>
            </div>
          </div>

          <div className="bg-slate-50 p-3 rounded-lg border border-slate-100">
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
              Next Due Date
            </span>
            <div className="flex items-center gap-1.5 mt-0.5">
              <Clock className="w-4 h-4 text-blue-500" />
              <span className="text-sm font-semibold text-slate-800">
                {nextUpcomingDueDate || 'None Pending'}
              </span>
            </div>
          </div>
        </div>

        {latestInvoiceNumber && (
          <div className="mt-3 text-xs text-slate-500 flex items-center justify-between px-1">
            <span>Latest Invoice Reference:</span>
            <span className="font-mono font-semibold text-slate-700">{latestInvoiceNumber}</span>
          </div>
        )}
      </div>

      {/* Footer Navigation */}
      {onNavigate && (
        <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between">
          <button
            type="button"
            onClick={() => onNavigate('guardian-payments')}
            className="inline-flex items-center gap-1 text-xs font-semibold text-slate-600 hover:text-slate-900 transition-colors"
          >
            <Receipt className="w-3.5 h-3.5 text-slate-400" />
            Payment Receipts
          </button>
          <button
            type="button"
            id="btn-view-fees-ledger"
            onClick={() => onNavigate('guardian-fees')}
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-blue-600 hover:text-blue-700 transition-colors"
          >
            Pay / View Invoices
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}
    </div>
  );
};
