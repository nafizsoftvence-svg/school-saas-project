import React from 'react';
import {
  User,
  GraduationCap,
  Hash,
  Award,
  Calendar,
  Layers,
  DoorOpen,
  Mail,
  Phone,
  ShieldCheck,
  ExternalLink,
  CreditCard
} from 'lucide-react';
import { GuardianChildSummary } from '../../types/index.js';

interface ChildOverviewCardProps {
  child: GuardianChildSummary;
  onNavigate?: (view: string) => void;
  className?: string;
}

export const ChildOverviewCard: React.FC<ChildOverviewCardProps> = ({
  child,
  onNavigate,
  className = ''
}) => {
  const getStatusBadge = (status?: string, enrollmentStatus?: string) => {
    const s = (status || enrollmentStatus || 'active').toLowerCase();
    if (s === 'active' || s === 'enrolled') {
      return (
        <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
          Active Scholar
        </span>
      );
    }
    return (
      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-100 text-slate-700 border border-slate-200">
        {status || enrollmentStatus || 'Registered'}
      </span>
    );
  };

  return (
    <div
      id={`child-overview-card-${child.id}`}
      className={`bg-white rounded-xl border border-slate-200/80 shadow-sm overflow-hidden transition-all duration-200 hover:shadow-md ${className}`}
    >
      {/* Top Banner Gradient Strip */}
      <div className="h-2.5 bg-gradient-to-r from-blue-600 via-indigo-600 to-cyan-500" />

      <div className="p-6">
        <div className="flex flex-col md:flex-row md:items-start justify-between gap-6">
          {/* Avatar and Primary Identity */}
          <div className="flex items-start gap-4">
            <div className="relative shrink-0">
              {child.avatarUrl ? (
                <img
                  src={child.avatarUrl}
                  alt={child.name}
                  className="w-20 h-20 rounded-2xl object-cover border-2 border-slate-100 shadow-sm"
                  onError={(e) => {
                    (e.currentTarget as HTMLElement).style.display = 'none';
                    if (e.currentTarget.nextElementSibling) {
                      (e.currentTarget.nextElementSibling as HTMLElement).style.display = 'flex';
                    }
                  }}
                />
              ) : null}
              <div
                className={`w-20 h-20 rounded-2xl bg-gradient-to-br from-blue-50 to-indigo-100 border-2 border-slate-100 flex items-center justify-center text-blue-600 font-bold text-2xl shadow-sm ${
                  child.avatarUrl ? 'hidden' : 'flex'
                }`}
              >
                {child.firstName?.[0] || child.name?.[0] || 'S'}
              </div>
              <div className="absolute -bottom-1 -right-1 bg-white p-0.5 rounded-full shadow-sm">
                <span className="block w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-white" />
              </div>
            </div>

            <div className="space-y-1.5">
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="text-xl font-bold text-slate-900 tracking-tight">
                  {child.name}
                </h2>
                {getStatusBadge(child.status, child.enrollmentStatus)}
              </div>

              <div className="flex flex-wrap items-center gap-y-1 gap-x-3 text-sm text-slate-500">
                <span className="flex items-center gap-1 font-mono font-medium text-slate-700 bg-slate-100 px-2 py-0.5 rounded">
                  <Hash className="w-3.5 h-3.5 text-slate-400" />
                  {child.admissionNumber}
                </span>
                <span className="text-slate-300">•</span>
                <span className="flex items-center gap-1">
                  <GraduationCap className="w-4 h-4 text-blue-600" />
                  <span className="font-semibold text-slate-800">{child.className}</span>
                  <span className="text-slate-500">({child.sectionName})</span>
                </span>
                <span className="text-slate-300">•</span>
                <span className="flex items-center gap-1 font-medium text-slate-700">
                  <Award className="w-3.5 h-3.5 text-amber-500" />
                  Roll: {child.rollNumber || 'N/A'}
                </span>
              </div>

              <p className="text-xs text-slate-500 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                Session: <span className="font-medium text-slate-700">{child.academicSessionName || '2026-2027 Academic Year'}</span>
              </p>
            </div>
          </div>

          {/* Quick Actions for this Child */}
          <div className="flex flex-wrap md:flex-col gap-2 shrink-0">
            {onNavigate && (
              <>
                <button
                  type="button"
                  id={`btn-view-dossier-${child.id}`}
                  onClick={() => onNavigate('guardian-academic-overview')}
                  className="inline-flex items-center justify-center gap-2 px-3.5 py-2 text-xs font-semibold text-blue-700 bg-blue-50/80 hover:bg-blue-100 border border-blue-200/80 rounded-lg transition-colors"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  Academic Dossier
                </button>
                <button
                  type="button"
                  id={`btn-message-teacher-${child.id}`}
                  onClick={() => onNavigate('guardian-inbox')}
                  className="inline-flex items-center justify-center gap-2 px-3.5 py-2 text-xs font-semibold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 rounded-lg transition-colors"
                >
                  <Mail className="w-3.5 h-3.5 text-indigo-600" />
                  Message Teachers
                </button>
                <button
                  type="button"
                  id={`btn-view-idcard-${child.id}`}
                  onClick={() => onNavigate('guardian-id-cards')}
                  className="inline-flex items-center justify-center gap-2 px-3.5 py-2 text-xs font-semibold text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg transition-colors"
                >
                  <CreditCard className="w-3.5 h-3.5 text-slate-500" />
                  Student ID Card
                </button>
              </>
            )}
          </div>
        </div>

        {/* Informational Grid */}
        <div className="mt-6 pt-5 border-t border-slate-100 grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="bg-slate-50/70 p-3 rounded-lg border border-slate-100">
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
              Classroom & Room
            </span>
            <div className="flex items-center gap-1.5 mt-1 text-sm font-semibold text-slate-800">
              <DoorOpen className="w-4 h-4 text-slate-500" />
              <span>{child.roomNumber || 'Room 302'}</span>
            </div>
          </div>

          <div className="bg-slate-50/70 p-3 rounded-lg border border-slate-100">
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
              Enrolled Subjects
            </span>
            <div className="flex items-center gap-1.5 mt-1 text-sm font-semibold text-slate-800">
              <Layers className="w-4 h-4 text-indigo-500" />
              <span>{child.totalSubjectsCount || 6} Subjects</span>
            </div>
          </div>

          <div className="bg-slate-50/70 p-3 rounded-lg border border-slate-100">
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
              Blood Group
            </span>
            <div className="flex items-center gap-1.5 mt-1 text-sm font-semibold text-slate-800">
              <ShieldCheck className="w-4 h-4 text-rose-500" />
              <span>{child.bloodGroup || 'O+'}</span>
            </div>
          </div>

          <div className="bg-slate-50/70 p-3 rounded-lg border border-slate-100">
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
              Faculty Class Mentor
            </span>
            <div className="flex items-center gap-1.5 mt-1 text-sm font-semibold text-slate-800 truncate" title={child.classTeacherName || 'Assigned Faculty'}>
              <User className="w-4 h-4 text-emerald-600 shrink-0" />
              <span className="truncate">{child.classTeacherName || 'Faculty Advisor'}</span>
            </div>
          </div>
        </div>

        {/* Mentor Contact Footer if available */}
        {child.classTeacherEmail && (
          <div className="mt-3 text-xs text-slate-500 flex flex-wrap items-center gap-4 bg-blue-50/40 px-3 py-2 rounded-lg border border-blue-100/60">
            <span className="font-medium text-slate-600">Mentor Contact:</span>
            <span className="flex items-center gap-1 text-slate-600">
              <Mail className="w-3.5 h-3.5 text-slate-400" />
              {child.classTeacherEmail}
            </span>
            {child.classTeacherPhone && (
              <span className="flex items-center gap-1 text-slate-600">
                <Phone className="w-3.5 h-3.5 text-slate-400" />
                {child.classTeacherPhone}
              </span>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
