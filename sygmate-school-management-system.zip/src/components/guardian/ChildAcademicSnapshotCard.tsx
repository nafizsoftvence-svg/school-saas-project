import React from 'react';
import {
  GraduationCap,
  Award,
  TrendingUp,
  BookOpen,
  ArrowRight,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { GuardianChildAcademicSnapshot } from '../../types/index.js';

interface ChildAcademicSnapshotCardProps {
  snapshot?: GuardianChildAcademicSnapshot;
  onNavigate?: (view: string) => void;
  className?: string;
}

export const ChildAcademicSnapshotCard: React.FC<ChildAcademicSnapshotCardProps> = ({
  snapshot,
  onNavigate,
  className = ''
}) => {
  if (!snapshot || !snapshot.hasPublishedResults || !snapshot.latestResult) {
    return (
      <div
        id="academic-snapshot-empty"
        className={`bg-white rounded-xl border border-slate-200/80 shadow-sm p-6 flex flex-col justify-between ${className}`}
      >
        <div className="flex items-center justify-between border-b border-slate-100 pb-4">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-blue-50 text-blue-600">
              <GraduationCap className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-base">Academic Snapshot</h3>
              <p className="text-xs text-slate-500">Official published examination metrics</p>
            </div>
          </div>
          <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-slate-100 text-slate-600">
            Current Session
          </span>
        </div>

        <div className="py-8 text-center space-y-3">
          <div className="w-12 h-12 rounded-full bg-slate-50 border border-slate-200 flex items-center justify-center mx-auto text-slate-400">
            <BookOpen className="w-6 h-6" />
          </div>
          <p className="text-sm font-medium text-slate-700">
            No Published Examination Results Yet
          </p>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Assessment scores and official semester report cards will appear here once finalized and formally published by school administration.
          </p>
        </div>

        {onNavigate && (
          <div className="pt-4 border-t border-slate-100 flex justify-end">
            <button
              type="button"
              onClick={() => onNavigate('guardian-results')}
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-blue-600 hover:text-blue-700 hover:underline"
            >
              View Examination Records
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </div>
    );
  }

  const { latestResult, cumulativeGPA, overallGrade, overallStanding, publishedResultsCount } = snapshot;

  const getStandingBadgeColor = (standing: string) => {
    const s = standing.toUpperCase();
    if (s.includes('DISTINCTION') || s.includes('HIGH')) {
      return 'bg-purple-50 text-purple-700 border-purple-200';
    }
    if (s.includes('HONOR') || s.includes('EXCELLENT')) {
      return 'bg-emerald-50 text-emerald-700 border-emerald-200';
    }
    if (s.includes('SATISFACTORY') || s.includes('GOOD')) {
      return 'bg-blue-50 text-blue-700 border-blue-200';
    }
    return 'bg-amber-50 text-amber-700 border-amber-200';
  };

  return (
    <div
      id="academic-snapshot-card"
      className={`bg-white rounded-xl border border-slate-200/80 shadow-sm p-6 flex flex-col justify-between transition-all duration-200 hover:shadow-md ${className}`}
    >
      <div>
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 pb-4">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-indigo-50 text-indigo-600">
              <GraduationCap className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-base">Academic Snapshot</h3>
              <p className="text-xs text-slate-500">{snapshot.academicSession}</p>
            </div>
          </div>
          <span className={`text-xs font-semibold px-2.5 py-1 rounded-full border ${getStandingBadgeColor(overallStanding)}`}>
            {overallStanding}
          </span>
        </div>

        {/* Primary Metric Badges */}
        <div className="grid grid-cols-3 gap-3 my-5">
          <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-100 text-center">
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
              Cumulative GPA
            </span>
            <span className="text-2xl font-extrabold text-slate-900 tracking-tight mt-0.5 block">
              {Number(cumulativeGPA ?? 0).toFixed(2)}
            </span>
            <span className="text-[10px] font-medium text-slate-500">
              Grade {overallGrade} Scale
            </span>
          </div>

          <div className="bg-blue-50/60 p-3.5 rounded-xl border border-blue-100/80 text-center">
            <span className="text-[11px] font-semibold text-blue-600 uppercase tracking-wider block">
              Latest Result
            </span>
            <span className="text-2xl font-extrabold text-blue-700 tracking-tight mt-0.5 block">
              {Number(latestResult?.percentage ?? 0).toFixed(1)}%
            </span>
            <span className="text-[10px] font-medium text-blue-600">
              Grade {latestResult.grade}
            </span>
          </div>

          <div className="bg-slate-50/80 p-3.5 rounded-xl border border-slate-100 text-center">
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
              Published Exams
            </span>
            <span className="text-2xl font-extrabold text-slate-900 tracking-tight mt-0.5 block">
              {publishedResultsCount}
            </span>
            <span className="text-[10px] font-medium text-slate-500">
              {latestResult.classRank ? `Rank #${latestResult.classRank}` : 'Verified'}
            </span>
          </div>
        </div>

        {/* Latest Exam Details Box */}
        <div className="bg-slate-50/50 rounded-xl border border-slate-200/60 p-4 space-y-3">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <span className="text-xs font-semibold text-slate-900 line-clamp-1">
                {latestResult.examName}
              </span>
              <p className="text-[11px] text-slate-500">
                {latestResult.term} • Published {latestResult.publishDate}
              </p>
            </div>
            {latestResult.isPassed ? (
              <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                <CheckCircle2 className="w-3 h-3" />
                Passed
              </span>
            ) : (
              <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-rose-700 bg-rose-50 px-2 py-0.5 rounded-md border border-rose-200">
                <AlertCircle className="w-3 h-3" />
                Requires Review
              </span>
            )}
          </div>

          {/* Subject Breakdown Preview */}
          {((latestResult?.subjectScores?.length || 0) > 0) && (
            <div className="space-y-1.5 pt-2 border-t border-slate-200/60">
              <span className="text-[11px] font-semibold text-slate-500 block">
                Subject Performance Highlights:
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {latestResult.subjectScores.slice(0, 4).map((subj) => (
                  <div
                    key={subj.subjectId}
                    className="flex items-center justify-between text-xs bg-white px-2.5 py-1.5 rounded-lg border border-slate-100"
                  >
                    <span className="font-medium text-slate-700 truncate mr-2" title={subj.subjectName}>
                      {subj.subjectName}
                    </span>
                    <div className="flex items-center gap-1.5 shrink-0">
                      <span className="font-mono text-slate-500 text-[11px]">
                        {subj.obtainedMarks}/{subj.maxMarks}
                      </span>
                      <span className="font-bold text-slate-800 bg-slate-100 px-1.5 py-0.5 rounded text-[10px]">
                        {subj.grade}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Footer link */}
      {onNavigate && (
        <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between">
          <span className="text-xs text-slate-400 flex items-center gap-1">
            <TrendingUp className="w-3.5 h-3.5 text-emerald-500" />
            Official Transcripts
          </span>
          <button
            type="button"
            id="btn-view-all-results"
            onClick={() => onNavigate('guardian-results')}
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-blue-600 hover:text-blue-700 transition-colors"
          >
            Full Grade Report
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}
    </div>
  );
};
