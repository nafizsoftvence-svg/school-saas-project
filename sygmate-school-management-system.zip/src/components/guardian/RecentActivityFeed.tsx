import React from 'react';
import {
  Activity,
  GraduationCap,
  CalendarCheck,
  CreditCard,
  Bell,
  ArrowRight,
  BookOpen
} from 'lucide-react';
import { GuardianChildActivityItem } from '../../types/index.js';

interface RecentActivityFeedProps {
  activities?: GuardianChildActivityItem[];
  onNavigate?: (view: string) => void;
  className?: string;
}

export const RecentActivityFeed: React.FC<RecentActivityFeedProps> = ({
  activities = [],
  onNavigate,
  className = ''
}) => {
  const getActivityIcon = (type: GuardianChildActivityItem['type']) => {
    switch (type) {
      case 'RESULT':
        return <GraduationCap className="w-4 h-4 text-purple-600" />;
      case 'ATTENDANCE':
        return <CalendarCheck className="w-4 h-4 text-emerald-600" />;
      case 'FEE':
        return <CreditCard className="w-4 h-4 text-blue-600" />;
      case 'HOMEWORK':
      case 'ASSIGNMENT':
        return <BookOpen className="w-4 h-4 text-indigo-600" />;
      default:
        return <Bell className="w-4 h-4 text-amber-600" />;
    }
  };

  const getBadgeClass = (variant: GuardianChildActivityItem['badgeVariant']) => {
    switch (variant) {
      case 'success':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'danger':
        return 'bg-rose-50 text-rose-700 border-rose-200';
      case 'warning':
        return 'bg-amber-50 text-amber-700 border-amber-200';
      case 'info':
        return 'bg-blue-50 text-blue-700 border-blue-200';
      default:
        return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  const formatTimestamp = (ts: string) => {
    try {
      const date = new Date(ts);
      if (isNaN(date.getTime())) return ts;
      return date.toLocaleDateString(undefined, {
        month: 'short',
        day: 'numeric',
        year: 'numeric'
      });
    } catch {
      return ts;
    }
  };

  return (
    <div
      id="guardian-recent-activity-feed"
      className={`bg-white rounded-xl border border-slate-200/80 shadow-sm p-6 ${className}`}
    >
      <div className="flex items-center justify-between border-b border-slate-100 pb-4 mb-4">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-lg bg-blue-50 text-blue-600">
            <Activity className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-slate-900 text-base">Recent Scholar Activity</h3>
            <p className="text-xs text-slate-500">Live timeline of academic, attendance, and fee events</p>
          </div>
        </div>
        <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-slate-100 text-slate-600">
          {activities?.length || 0} Events
        </span>
      </div>

      {(activities?.length || 0) === 0 ? (
        <div className="py-8 text-center text-slate-400 space-y-2">
          <Activity className="w-8 h-8 mx-auto stroke-1" />
          <p className="text-xs">No recent events logged for this scholar.</p>
        </div>
      ) : (
        <div className="divide-y divide-slate-100">
          {(activities || []).map((item) => (
            <div
              key={item.id}
              className="py-3 flex items-start justify-between gap-3 group transition-colors hover:bg-slate-50/60 -mx-3 px-3 rounded-lg"
            >
              <div className="flex items-start gap-3 min-w-0">
                <div className="p-2 rounded-lg bg-slate-50 border border-slate-100 shrink-0 mt-0.5">
                  {getActivityIcon(item.type)}
                </div>
                <div className="min-w-0 space-y-0.5">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h4 className="text-xs font-bold text-slate-900 truncate">{item.title}</h4>
                    <span
                      className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${getBadgeClass(
                        item.badgeVariant
                      )}`}
                    >
                      {item.badgeLabel}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 line-clamp-1">{item.description}</p>
                  <span className="text-[10px] text-slate-400 block">
                    {formatTimestamp(item.timestamp)}
                  </span>
                </div>
              </div>

              {item.linkView && onNavigate && (
                <button
                  type="button"
                  onClick={() => onNavigate(item.linkView!)}
                  className="shrink-0 p-1.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                  title="View details"
                >
                  <ArrowRight className="w-4 h-4" />
                </button>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
