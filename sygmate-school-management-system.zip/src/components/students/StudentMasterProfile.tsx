import React, { useState, useEffect, useRef } from 'react';
import {
  User,
  GraduationCap,
  Calendar,
  Phone,
  Mail,
  MapPin,
  HeartHandshake,
  FileText,
  Clock,
  Award,
  CreditCard,
  FolderLock,
  Camera,
  Trash2,
  Upload,
  Plus,
  CheckCircle2,
  AlertCircle,
  Shield,
  Layers,
  BookOpen,
  Sparkles,
  ExternalLink,
  Download,
  Eye,
  RefreshCw,
  Edit2
} from 'lucide-react';
import { StudentMasterDossier, StudentDocument } from '../../types/index.js';
import { Badge } from '../ui/Badge.js';
import { Button } from '../ui/Button.js';
import { Modal } from '../ui/Modal.js';
import { Input } from '../ui/Input.js';
import { Select } from '../ui/Select.js';
import { Alert } from '../ui/Alert.js';
import { ConfirmDialog } from '../ui/ConfirmDialog.js';
import { LoadingSpinner } from '../ui/LoadingSpinner.js';
import { api } from '../../services/api.js';

interface StudentMasterProfileProps {
  studentId: string;
  onEdit?: (student: any) => void;
  onSelectGuardian?: (guardianId: string) => void;
  allowEdit?: boolean;
  isSelfService?: boolean;
  onRefresh?: () => void;
}

export const StudentMasterProfile: React.FC<StudentMasterProfileProps> = ({
  studentId,
  onEdit,
  onSelectGuardian,
  allowEdit = true,
  isSelfService = false,
  onRefresh
}) => {
  const [dossier, setDossier] = useState<StudentMasterDossier | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<
    'overview' | 'academic' | 'personal' | 'family' | 'attendance' | 'exams' | 'fees' | 'documents' | 'audit'
  >('overview');

  // Photo Upload State
  const [isPhotoModalOpen, setIsPhotoModalOpen] = useState(false);
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const [photoSubmitting, setPhotoSubmitting] = useState(false);
  const [photoError, setPhotoError] = useState<string | null>(null);
  const [photoSuccess, setPhotoSuccess] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Document Upload State
  const [isDocModalOpen, setIsDocModalOpen] = useState(false);
  const [docTitle, setDocTitle] = useState('');
  const [docCategory, setDocCategory] = useState<
    'BIRTH_CERTIFICATE' | 'NATIONAL_ID' | 'TRANSFER_CERTIFICATE' | 'MEDICAL_RECORD' | 'PREVIOUS_TRANSCRIPT' | 'OTHER'
  >('OTHER');
  const [docFileBase64, setDocFileBase64] = useState<string>('');
  const [docFileName, setDocFileName] = useState('');
  const [docFileSize, setDocFileSize] = useState('');
  const [docSubmitting, setDocSubmitting] = useState(false);
  const [docError, setDocError] = useState<string | null>(null);
  const [docSuccess, setDocSuccess] = useState<string | null>(null);
  const docInputRef = useRef<HTMLInputElement>(null);

  // Document Deletion State
  const [docToDelete, setDocToDelete] = useState<StudentDocument | null>(null);
  const [deletingDoc, setDeletingDoc] = useState(false);

  // Self-Service Profile Contact Edit Modal
  const [isContactEditOpen, setIsContactEditOpen] = useState(false);
  const [contactPhone, setContactPhone] = useState('');
  const [contactAltPhone, setContactAltPhone] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [contactEmergency, setContactEmergency] = useState('');
  const [contactAddress, setContactAddress] = useState('');
  const [contactSaving, setContactSaving] = useState(false);
  const [contactError, setContactError] = useState<string | null>(null);
  const [contactSuccess, setContactSuccess] = useState<string | null>(null);

  const fetchDossier = async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await api.getStudentMasterDossier(studentId);
      if (res.success && res.data) {
        setDossier(res.data);
        const data = res.data;
        setContactPhone(data.phone || '');
        setContactAltPhone(data.alternativePhone || '');
        setContactEmail(data.email || '');
        setContactEmergency(data.emergencyContact || '');
        setContactAddress(data.presentAddress || data.address || '');
      } else {
        setError(res.error || 'Failed to retrieve student master dossier.');
      }
    } catch (err: any) {
      setError(err?.message || 'Network error fetching student dossier.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (studentId) {
      fetchDossier();
    }
  }, [studentId]);

  // Handle Photo Selection
  const handlePhotoSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
    if (!validTypes.includes(file.type)) {
      setPhotoError('Invalid image format. Only JPG, PNG, and WEBP are supported.');
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      setPhotoError('Photo size exceeds the maximum 5MB institutional limit.');
      return;
    }

    setPhotoError(null);
    const reader = new FileReader();
    reader.onload = (event) => {
      setPhotoPreview(event.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  // Upload or Update Photo
  const handlePhotoUploadSubmit = async () => {
    if (!photoPreview) {
      setPhotoError('Please select a photo first.');
      return;
    }

    try {
      setPhotoSubmitting(true);
      setPhotoError(null);
      setPhotoSuccess(null);

      const res = await api.uploadStudentPhoto(studentId, photoPreview);
      if (res.success) {
        setPhotoSuccess('Photo updated successfully.');
        setTimeout(() => {
          setIsPhotoModalOpen(false);
          setPhotoPreview(null);
          setPhotoSuccess(null);
        }, 1200);
        fetchDossier();
        if (onRefresh) onRefresh();
      } else {
        setPhotoError(res.error || 'Failed to upload photo.');
      }
    } catch (err: any) {
      setPhotoError(err.message || 'Error uploading photo.');
    } finally {
      setPhotoSubmitting(false);
    }
  };

  // Remove Photo
  const handlePhotoRemove = async () => {
    try {
      setPhotoSubmitting(true);
      setPhotoError(null);
      const res = await api.deleteStudentPhoto(studentId);
      if (res.success) {
        setPhotoSuccess('Photo removed successfully.');
        setTimeout(() => {
          setIsPhotoModalOpen(false);
          setPhotoPreview(null);
          setPhotoSuccess(null);
        }, 1200);
        fetchDossier();
        if (onRefresh) onRefresh();
      } else {
        setPhotoError(res.error || 'Failed to remove photo.');
      }
    } catch (err: any) {
      setPhotoError(err.message || 'Error removing photo.');
    } finally {
      setPhotoSubmitting(false);
    }
  };

  // Handle Document Selection
  const handleDocFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 10 * 1024 * 1024) {
      setDocError('Document file exceeds 10MB limit.');
      return;
    }

    setDocFileName(file.name);
    setDocFileSize(`${(file.size / 1024).toFixed(1)} KB`);
    if (!docTitle) {
      setDocTitle(file.name.replace(/\.[^/.]+$/, ''));
    }
    setDocError(null);

    const reader = new FileReader();
    reader.onload = (event) => {
      setDocFileBase64(event.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  // Upload Document Submit
  const handleDocUploadSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!docTitle.trim()) {
      setDocError('Please enter a document title.');
      return;
    }
    if (!docFileBase64) {
      setDocError('Please select a file to upload.');
      return;
    }

    try {
      setDocSubmitting(true);
      setDocError(null);
      setDocSuccess(null);

      const res = await api.uploadStudentDocument(studentId, {
        name: docTitle.trim(),
        title: docTitle.trim(),
        category: docCategory,
        type: docFileName.endsWith('.pdf') ? 'application/pdf' : 'image/jpeg',
        url: docFileBase64,
        fileName: docFileName,
        fileSize: docFileSize,
        fileUrl: docFileBase64
      });

      if (res.success) {
        setDocSuccess('Document uploaded successfully to student vault.');
        setTimeout(() => {
          setIsDocModalOpen(false);
          setDocTitle('');
          setDocFileBase64('');
          setDocFileName('');
          setDocSuccess(null);
        }, 1200);
        fetchDossier();
        if (onRefresh) onRefresh();
      } else {
        setDocError(res.error || 'Failed to upload document.');
      }
    } catch (err: any) {
      setDocError(err.message || 'Error uploading document.');
    } finally {
      setDocSubmitting(false);
    }
  };

  // Delete Document Submit
  const handleConfirmDeleteDoc = async () => {
    if (!docToDelete) return;

    try {
      setDeletingDoc(true);
      const res = await api.deleteStudentDocument(studentId, docToDelete.id);
      if (res.success) {
        setDocToDelete(null);
        fetchDossier();
        if (onRefresh) onRefresh();
      } else {
        alert(res.error || 'Failed to delete document.');
      }
    } catch (err: any) {
      alert(err.message || 'Error deleting document.');
    } finally {
      setDeletingDoc(false);
    }
  };

  // Self-Service Contact Update
  const handleSaveContact = async (e: React.FormEvent) => {
    e.preventDefault();
    setContactError(null);
    setContactSuccess(null);

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (contactEmail.trim() && !emailRegex.test(contactEmail.trim())) {
      setContactError('Please enter a valid email address.');
      return;
    }

    try {
      setContactSaving(true);
      const res = await api.updateMyProfile({
        phone: contactPhone,
        email: contactEmail,
        emergencyContact: contactEmergency,
        address: contactAddress
      });

      if (res.success) {
        setContactSuccess('Profile details updated successfully.');
        setTimeout(() => {
          setIsContactEditOpen(false);
          setContactSuccess(null);
        }, 1200);
        fetchDossier();
        if (onRefresh) onRefresh();
      } else {
        setContactError(res.error || 'Failed to update contact info.');
      }
    } catch (err: any) {
      setContactError(err.message || 'Network error updating details.');
    } finally {
      setContactSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center p-12 space-y-4">
        <LoadingSpinner size="lg" />
        <p className="text-slate-400 text-sm">Loading Student Master Dossier...</p>
      </div>
    );
  }

  if (error || !dossier) {
    return (
      <div className="p-6">
        <Alert variant="danger" title="Error Loading Student Dossier">
          {error || 'Student dossier record could not be loaded.'}
        </Alert>
        <div className="mt-4">
          <Button variant="secondary" onClick={fetchDossier} icon={<RefreshCw className="w-4 h-4" />}>
            Retry
          </Button>
        </div>
      </div>
    );
  }

  const profile = dossier;
  const academic = {
    className: dossier.className,
    sectionName: dossier.sectionName,
    sessionName: dossier.academicSessionName
  };
  const guardian = {
    id: dossier.guardianId,
    siblingStudents: dossier.siblings
  };
  const { enrolledSubjects, attendanceSummary, examinationSummary, feeSummary, documents, auditTrail } = dossier;

  return (
    <div className="space-y-6">
      {/* 1. MASTER HEADER IDENTITY BANNER */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-800 to-indigo-950 border border-slate-700/60 shadow-xl">
        <div className="flex flex-col md:flex-row items-center md:items-start justify-between gap-6">
          <div className="flex flex-col sm:flex-row items-center gap-5 text-center sm:text-left">
            {/* Avatar & Photo Trigger */}
            <div className="relative group">
              <div className="w-24 h-24 rounded-2xl bg-indigo-600/30 border-2 border-indigo-400/50 overflow-hidden flex items-center justify-center text-2xl font-bold text-indigo-200 shadow-lg">
                {profile.avatarUrl ? (
                  <img
                    src={profile.avatarUrl}
                    alt={`${profile.firstName} ${profile.lastName}`}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <span>
                    {profile.firstName?.[0] || 'S'}
                    {profile.lastName?.[0] || ''}
                  </span>
                )}
              </div>

              {allowEdit && (
                <button
                  type="button"
                  onClick={() => {
                    setPhotoPreview(profile.avatarUrl || null);
                    setPhotoError(null);
                    setPhotoSuccess(null);
                    setIsPhotoModalOpen(true);
                  }}
                  className="absolute inset-0 bg-black/60 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center text-white text-xs font-medium cursor-pointer"
                  title="Change Profile Photo"
                >
                  <Camera className="w-5 h-5 mb-1 text-indigo-300" />
                  <span>Update</span>
                </button>
              )}
            </div>

            {/* Core Identity Info */}
            <div className="space-y-1.5">
              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2.5">
                <h2 className="text-2xl font-bold text-white tracking-tight">
                  {profile.fullName || `${profile.firstName} ${profile.lastName}`}
                </h2>
                <Badge
                  variant={
                    profile.status === 'active' || (profile.status as any) === 'ACTIVE'
                      ? 'success'
                      : profile.status === 'graduated'
                      ? 'info'
                      : 'warning'
                  }
                  dot
                >
                  {profile.status?.toUpperCase() || 'ACTIVE'}
                </Badge>
              </div>

              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-3 text-xs text-slate-300">
                <span className="px-2.5 py-1 rounded-md bg-indigo-500/20 text-indigo-200 font-mono font-semibold border border-indigo-500/30">
                  Adm #{profile.admissionNumber}
                </span>
                <span className="px-2.5 py-1 rounded-md bg-white/10 text-slate-200 font-mono">
                  Roll #{profile.rollNumber || '—'}
                </span>
                <span className="flex items-center gap-1 text-slate-300">
                  <GraduationCap className="w-3.5 h-3.5 text-indigo-400" />
                  {academic?.className || profile.className} • {academic?.sectionName || profile.sectionName}
                </span>
                <span className="text-slate-400">({academic?.sessionName || profile.academicSessionName})</span>
              </div>

              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-4 pt-1 text-xs text-slate-400">
                {profile.email && (
                  <span className="flex items-center gap-1">
                    <Mail className="w-3.5 h-3.5 text-slate-400" />
                    {profile.email}
                  </span>
                )}
                {profile.phone && (
                  <span className="flex items-center gap-1">
                    <Phone className="w-3.5 h-3.5 text-slate-400" />
                    {profile.phone}
                  </span>
                )}
                {profile.city && (
                  <span className="flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-slate-400" />
                    {profile.city}
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center gap-2.5">
            {isSelfService ? (
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsContactEditOpen(true)}
                icon={<Edit2 className="w-3.5 h-3.5" />}
              >
                Edit Contact Details
              </Button>
            ) : onEdit ? (
              <Button
                variant="outline"
                size="sm"
                onClick={() => onEdit(profile)}
                icon={<Edit2 className="w-3.5 h-3.5" />}
              >
                Edit Full Profile
              </Button>
            ) : null}

            <Button
              variant="secondary"
              size="sm"
              onClick={fetchDossier}
              icon={<RefreshCw className="w-3.5 h-3.5" />}
            >
              Refresh
            </Button>
          </div>
        </div>

        {/* Quick KPI Stat Pills */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-5 border-t border-slate-700/60">
          <div className="p-3 rounded-xl bg-white/5 border border-white/5 space-y-0.5">
            <span className="text-[11px] font-medium text-slate-400 uppercase tracking-wider block">
              Attendance Standing
            </span>
            <div className="flex items-center justify-between">
              <span className="text-lg font-bold text-emerald-400">
                {attendanceSummary?.percentage || '100.0%'}
              </span>
              <Badge variant="success" size="sm">
                {attendanceSummary?.standing || 'GOOD'}
              </Badge>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-white/5 border border-white/5 space-y-0.5">
            <span className="text-[11px] font-medium text-slate-400 uppercase tracking-wider block">
              Academic GPA
            </span>
            <div className="flex items-center justify-between">
              <span className="text-lg font-bold text-indigo-300">
                {examinationSummary?.cumulativeGPA ? `${examinationSummary.cumulativeGPA} / 4.0` : '3.85'}
              </span>
              <span className="text-xs font-semibold px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-200">
                Grade {examinationSummary?.overallGrade || 'A'}
              </span>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-white/5 border border-white/5 space-y-0.5">
            <span className="text-[11px] font-medium text-slate-400 uppercase tracking-wider block">
              Fee Account
            </span>
            <div className="flex items-center justify-between">
              <span className="text-lg font-bold text-white">
                ${feeSummary?.totalDue !== undefined ? feeSummary.totalDue.toLocaleString() : '0.00'}
              </span>
              <Badge
                variant={feeSummary?.status === 'CLEARED' || (feeSummary?.totalDue || 0) <= 0 ? 'success' : 'warning'}
                size="sm"
              >
                {feeSummary?.status || 'CLEARED'}
              </Badge>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-white/5 border border-white/5 space-y-0.5">
            <span className="text-[11px] font-medium text-slate-400 uppercase tracking-wider block">
              Enrolled Subjects
            </span>
            <div className="flex items-center justify-between">
              <span className="text-lg font-bold text-teal-300">
                {enrolledSubjects?.length || 0}
              </span>
              <span className="text-xs text-slate-400">Registered</span>
            </div>
          </div>
        </div>
      </div>

      {/* 2. NAVIGATION TABS */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-2 border-b border-slate-700/60 text-xs font-medium">
        <button
          type="button"
          onClick={() => setActiveTab('overview')}
          className={`px-3.5 py-2 rounded-lg whitespace-nowrap transition-colors flex items-center gap-1.5 ${
            activeTab === 'overview'
              ? 'bg-indigo-600 text-white font-semibold'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>Overview</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('academic')}
          className={`px-3.5 py-2 rounded-lg whitespace-nowrap transition-colors flex items-center gap-1.5 ${
            activeTab === 'academic'
              ? 'bg-indigo-600 text-white font-semibold'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <GraduationCap className="w-3.5 h-3.5" />
          <span>Academic Track</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('personal')}
          className={`px-3.5 py-2 rounded-lg whitespace-nowrap transition-colors flex items-center gap-1.5 ${
            activeTab === 'personal'
              ? 'bg-indigo-600 text-white font-semibold'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <User className="w-3.5 h-3.5" />
          <span>Personal &amp; Address</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('family')}
          className={`px-3.5 py-2 rounded-lg whitespace-nowrap transition-colors flex items-center gap-1.5 ${
            activeTab === 'family'
              ? 'bg-indigo-600 text-white font-semibold'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <HeartHandshake className="w-3.5 h-3.5" />
          <span>Family &amp; Guardians</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('attendance')}
          className={`px-3.5 py-2 rounded-lg whitespace-nowrap transition-colors flex items-center gap-1.5 ${
            activeTab === 'attendance'
              ? 'bg-indigo-600 text-white font-semibold'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Clock className="w-3.5 h-3.5" />
          <span>Attendance</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('exams')}
          className={`px-3.5 py-2 rounded-lg whitespace-nowrap transition-colors flex items-center gap-1.5 ${
            activeTab === 'exams'
              ? 'bg-indigo-600 text-white font-semibold'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Award className="w-3.5 h-3.5" />
          <span>Exams &amp; GPA</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('fees')}
          className={`px-3.5 py-2 rounded-lg whitespace-nowrap transition-colors flex items-center gap-1.5 ${
            activeTab === 'fees'
              ? 'bg-indigo-600 text-white font-semibold'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <CreditCard className="w-3.5 h-3.5" />
          <span>Financial Records</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('documents')}
          className={`px-3.5 py-2 rounded-lg whitespace-nowrap transition-colors flex items-center gap-1.5 ${
            activeTab === 'documents'
              ? 'bg-indigo-600 text-white font-semibold'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <FolderLock className="w-3.5 h-3.5" />
          <span>Document Vault ({documents?.length || 0})</span>
        </button>

        {!isSelfService && (
          <button
            type="button"
            onClick={() => setActiveTab('audit')}
            className={`px-3.5 py-2 rounded-lg whitespace-nowrap transition-colors flex items-center gap-1.5 ${
              activeTab === 'audit'
                ? 'bg-indigo-600 text-white font-semibold'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Shield className="w-3.5 h-3.5" />
            <span>Audit History</span>
          </button>
        )}
      </div>

      {/* 3. TAB CONTENT PANELS */}
      <div className="space-y-6">
        {/* === TAB: OVERVIEW === */}
        {activeTab === 'overview' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Academic Track Summary */}
            <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-indigo-400 uppercase tracking-wider flex items-center gap-2">
                  <GraduationCap className="w-4 h-4" />
                  Academic Placement
                </h3>
                <span className="text-xs text-slate-400 font-mono">
                  Enrolled: {profile.admissionDate || '2026-08-01'}
                </span>
              </div>

              <div className="space-y-2.5 text-xs">
                <div className="flex justify-between py-1 border-b border-slate-800">
                  <span className="text-slate-400">Class &amp; Section:</span>
                  <span className="text-white font-semibold">
                    {profile.className} ({profile.sectionName})
                  </span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800">
                  <span className="text-slate-400">Academic Session:</span>
                  <span className="text-indigo-200">{profile.academicSessionName}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800">
                  <span className="text-slate-400">Admission Number:</span>
                  <span className="text-white font-mono">{profile.admissionNumber}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800">
                  <span className="text-slate-400">Roll Number:</span>
                  <span className="text-white font-mono">{profile.rollNumber || '—'}</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-400">Enrollment Status:</span>
                  <Badge variant="success" size="sm">
                    {profile.enrollmentStatus?.toUpperCase() || 'ACTIVE'}
                  </Badge>
                </div>
              </div>
            </div>

            {/* Primary Guardian Summary */}
            <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-teal-400 uppercase tracking-wider flex items-center gap-2">
                  <HeartHandshake className="w-4 h-4" />
                  Primary Guardian Profile
                </h3>
                {guardian?.id && onSelectGuardian && (
                  <button
                    type="button"
                    onClick={() => onSelectGuardian(guardian.id)}
                    className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center gap-1 font-medium"
                  >
                    <span>Family Portal</span>
                    <ExternalLink className="w-3 h-3" />
                  </button>
                )}
              </div>

              <div className="space-y-2.5 text-xs">
                <div className="flex justify-between py-1 border-b border-slate-800">
                  <span className="text-slate-400">Guardian Name:</span>
                  <span className="text-white font-semibold">{profile.guardianName || 'Guardian'}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800">
                  <span className="text-slate-400">Relationship:</span>
                  <span className="text-white">{profile.guardianRelation || 'Parent'}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800">
                  <span className="text-slate-400">Phone Number:</span>
                  <span className="text-teal-300 font-mono">{profile.guardianPhone || '—'}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-slate-800">
                  <span className="text-slate-400">Emergency Phone:</span>
                  <span className="text-rose-300 font-mono">
                    {profile.emergencyContact || profile.guardianPhone || '—'}
                  </span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-400">Occupation:</span>
                  <span className="text-white">{profile.guardianOccupation || '—'}</span>
                </div>
              </div>
            </div>

            {/* Current Semester Enrolled Subjects */}
            <div className="md:col-span-2 p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-indigo-400" />
                  Current Semester Subjects ({enrolledSubjects?.length || 0})
                </h3>
              </div>

              {enrolledSubjects && enrolledSubjects.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                  {enrolledSubjects.map((sub) => (
                    <div
                      key={sub.id}
                      className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/50 space-y-1.5"
                    >
                      <div className="flex justify-between items-center">
                        <span className="text-xs font-semibold text-white truncate">{sub.name}</span>
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300 font-mono">
                          {sub.code}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-400 flex justify-between">
                        <span>Instructor:</span>
                        <span className="text-slate-200">{sub.teacherName || 'Faculty'}</span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-slate-500 italic">No registered subjects found for this class roster.</p>
              )}
            </div>
          </div>
        )}

        {/* === TAB: ACADEMIC TRACK === */}
        {activeTab === 'academic' && (
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-6">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <GraduationCap className="w-5 h-5 text-indigo-400" />
              Full Academic Standing &amp; Placement
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700/50 space-y-1">
                <span className="text-xs text-slate-400">Class &amp; Grade Level</span>
                <p className="text-base font-bold text-white">{profile.className}</p>
                <span className="text-[11px] text-slate-500">Curricular Stage</span>
              </div>

              <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700/50 space-y-1">
                <span className="text-xs text-slate-400">Class Section</span>
                <p className="text-base font-bold text-indigo-300">{profile.sectionName}</p>
                <span className="text-[11px] text-slate-500">Cohort Group</span>
              </div>

              <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700/50 space-y-1">
                <span className="text-xs text-slate-400">Academic Session</span>
                <p className="text-base font-bold text-teal-300">{profile.academicSessionName}</p>
                <span className="text-[11px] text-slate-500">Active Term</span>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-white/5 border border-white/10 space-y-3">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                Registration Metadata
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 text-xs">
                <div>
                  <span className="text-slate-400 block mb-1">Admission Number:</span>
                  <span className="text-white font-mono font-semibold">{profile.admissionNumber}</span>
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Roll Number:</span>
                  <span className="text-white font-mono font-semibold">{profile.rollNumber || '—'}</span>
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Admission Date:</span>
                  <span className="text-white font-mono">{profile.admissionDate || '2026-08-01'}</span>
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Enrollment Date:</span>
                  <span className="text-white font-mono">{profile.enrollmentDate || '2026-08-01'}</span>
                </div>
              </div>
            </div>

            {/* Enrolled Subjects Detailed Table */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                Enrolled Subjects Curriculum ({enrolledSubjects?.length || 0})
              </h4>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-slate-800/80 text-slate-400 border-b border-slate-700">
                    <tr>
                      <th className="py-2.5 px-4 font-semibold">Subject Code</th>
                      <th className="py-2.5 px-4 font-semibold">Subject Name</th>
                      <th className="py-2.5 px-4 font-semibold">Assigned Teacher</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {enrolledSubjects && enrolledSubjects.length > 0 ? (
                      enrolledSubjects.map((sub) => (
                        <tr key={sub.id} className="hover:bg-slate-800/40">
                          <td className="py-2.5 px-4 font-mono text-indigo-300">{sub.code}</td>
                          <td className="py-2.5 px-4 font-medium text-white">{sub.name}</td>
                          <td className="py-2.5 px-4 text-slate-300">{sub.teacherName || 'Faculty'}</td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={3} className="py-4 text-center text-slate-500 italic">
                          No registered subjects.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* === TAB: PERSONAL & ADDRESS === */}
        {activeTab === 'personal' && (
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-6">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <User className="w-5 h-5 text-indigo-400" />
              Biographical &amp; Residential Records
            </h3>

            {/* Bio Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 text-xs">
              <div className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700/50">
                <span className="text-slate-400 block mb-1">Full Legal Name:</span>
                <span className="text-white font-semibold text-sm">
                  {profile.fullName || `${profile.firstName} ${profile.lastName}`}
                </span>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700/50">
                <span className="text-slate-400 block mb-1">Date of Birth:</span>
                <span className="text-white font-mono">{profile.dateOfBirth || '2010-06-15'}</span>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700/50">
                <span className="text-slate-400 block mb-1">Gender:</span>
                <span className="text-white capitalize">{profile.gender || 'Male'}</span>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700/50">
                <span className="text-slate-400 block mb-1">Blood Group:</span>
                <span className="text-rose-400 font-bold">{profile.bloodGroup || 'O+'}</span>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700/50">
                <span className="text-slate-400 block mb-1">Nationality:</span>
                <span className="text-white">{profile.nationality || 'United States'}</span>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700/50">
                <span className="text-slate-400 block mb-1">Religion / Category:</span>
                <span className="text-white">
                  {profile.religion || 'General'} • {profile.category || 'General'}
                </span>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700/50">
                <span className="text-slate-400 block mb-1">Primary Email:</span>
                <span className="text-indigo-300 font-mono">{profile.email}</span>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700/50">
                <span className="text-slate-400 block mb-1">Primary Phone:</span>
                <span className="text-white font-mono">{profile.phone || '—'}</span>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700/50">
                <span className="text-slate-400 block mb-1">Alternative Contact:</span>
                <span className="text-white font-mono">{profile.alternativePhone || '—'}</span>
              </div>
            </div>

            {/* Address Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs pt-4 border-t border-slate-800">
              <div className="p-4 rounded-xl bg-white/5 border border-white/10 space-y-2">
                <h4 className="font-bold text-teal-400 uppercase tracking-wider flex items-center gap-1.5">
                  <MapPin className="w-4 h-4" />
                  Present Residence Address
                </h4>
                <p className="text-white text-sm leading-relaxed">
                  {profile.presentAddress || profile.address || '124 College Avenue'}
                </p>
                <div className="flex gap-4 text-slate-400 text-xs pt-2 border-t border-white/5">
                  <span>City: {profile.city || 'Boston'}</span>
                  <span>State: {profile.state || 'MA'}</span>
                  <span>Postal Code: {profile.postalCode || '02115'}</span>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-white/5 border border-white/10 space-y-2">
                <h4 className="font-bold text-indigo-400 uppercase tracking-wider flex items-center gap-1.5">
                  <MapPin className="w-4 h-4" />
                  Permanent Official Address
                </h4>
                <p className="text-white text-sm leading-relaxed">
                  {profile.permanentAddress || profile.address || '124 College Avenue'}
                </p>
                <div className="flex gap-4 text-slate-400 text-xs pt-2 border-t border-white/5">
                  <span>City: {profile.city || 'Boston'}</span>
                  <span>Country: {profile.country || 'United States'}</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* === TAB: FAMILY & GUARDIANS === */}
        {activeTab === 'family' && (
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-6">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <HeartHandshake className="w-5 h-5 text-indigo-400" />
              Family &amp; Guardian Ecosystem
            </h3>

            {/* Primary Guardian Card */}
            <div className="p-5 rounded-xl bg-slate-800/60 border border-slate-700/60 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-bold text-teal-300">
                    {profile.guardianName || 'Primary Guardian'}
                  </h4>
                  <span className="text-xs text-slate-400">
                    Relationship: {profile.guardianRelation || 'Parent'}
                  </span>
                </div>
                <Badge variant="info">Primary Contact</Badge>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 text-xs">
                <div>
                  <span className="text-slate-400 block mb-0.5">Phone Contact:</span>
                  <span className="text-white font-mono font-semibold">{profile.guardianPhone || '—'}</span>
                </div>
                <div>
                  <span className="text-slate-400 block mb-0.5">Email Address:</span>
                  <span className="text-white font-mono">{profile.guardianEmail || '—'}</span>
                </div>
                <div>
                  <span className="text-slate-400 block mb-0.5">Occupation:</span>
                  <span className="text-white">{profile.guardianOccupation || '—'}</span>
                </div>
                <div>
                  <span className="text-slate-400 block mb-0.5">Emergency Phone:</span>
                  <span className="text-rose-400 font-mono font-semibold">
                    {profile.emergencyContact || profile.guardianPhone || '—'}
                  </span>
                </div>
              </div>
            </div>

            {/* Parents Bio Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div className="p-4 rounded-xl bg-white/5 border border-white/10 space-y-2">
                <h4 className="font-bold text-slate-300 uppercase tracking-wider">Father's Information</h4>
                <div className="space-y-1.5">
                  <div className="flex justify-between border-b border-white/5 pb-1">
                    <span className="text-slate-400">Full Name:</span>
                    <span className="text-white font-medium">{profile.fatherName || 'David Miller'}</span>
                  </div>
                  <div className="flex justify-between border-b border-white/5 pb-1">
                    <span className="text-slate-400">Phone:</span>
                    <span className="text-white font-mono">{profile.fatherPhone || '+1-617-555-0199'}</span>
                  </div>
                  <div className="flex justify-between border-b border-white/5 pb-1">
                    <span className="text-slate-400">Email:</span>
                    <span className="text-white font-mono">{profile.fatherEmail || 'david.miller@example.com'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Occupation:</span>
                    <span className="text-white">{profile.fatherOccupation || 'Civil Engineer'}</span>
                  </div>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-white/5 border border-white/10 space-y-2">
                <h4 className="font-bold text-slate-300 uppercase tracking-wider">Mother's Information</h4>
                <div className="space-y-1.5">
                  <div className="flex justify-between border-b border-white/5 pb-1">
                    <span className="text-slate-400">Full Name:</span>
                    <span className="text-white font-medium">{profile.motherName || 'Sarah Miller'}</span>
                  </div>
                  <div className="flex justify-between border-b border-white/5 pb-1">
                    <span className="text-slate-400">Phone:</span>
                    <span className="text-white font-mono">{profile.motherPhone || '+1-617-555-0198'}</span>
                  </div>
                  <div className="flex justify-between border-b border-white/5 pb-1">
                    <span className="text-slate-400">Email:</span>
                    <span className="text-white font-mono">{profile.motherEmail || 'sarah.miller@example.com'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Occupation:</span>
                    <span className="text-white">{profile.motherOccupation || 'Architect'}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Sibling Links if multi-student family */}
            {((guardian?.siblingStudents?.length || 0) > 0) && (
              <div className="p-4 rounded-xl bg-indigo-950/30 border border-indigo-500/20 space-y-2.5">
                <h4 className="text-xs font-bold text-indigo-300 uppercase tracking-wider flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" />
                  Enrolled Siblings in Sygmate Academy
                </h4>
                <div className="flex flex-wrap gap-2">
                  {(guardian?.siblingStudents || []).map((sib: any) => (
                    <div
                      key={sib.id}
                      className="px-3 py-1.5 rounded-lg bg-indigo-600/20 border border-indigo-500/30 text-indigo-200 text-xs flex items-center gap-2"
                    >
                      <span className="font-medium">{sib.name}</span>
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-white/10 text-slate-300 font-mono">
                        {sib.className}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* === TAB: ATTENDANCE & LEAVES === */}
        {activeTab === 'attendance' && (
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Clock className="w-5 h-5 text-indigo-400" />
                Attendance Summary &amp; History
              </h3>
              <Badge variant="success">Standing: {attendanceSummary?.standing || 'GOOD'}</Badge>
            </div>

            {/* Attendance Stat Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3 text-center">
              <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/50">
                <span className="text-[11px] text-slate-400 block mb-0.5">Total Days</span>
                <span className="text-lg font-bold text-white">{attendanceSummary?.totalDays || 0}</span>
              </div>
              <div className="p-3 rounded-xl bg-emerald-950/30 border border-emerald-500/30">
                <span className="text-[11px] text-emerald-300 block mb-0.5">Present</span>
                <span className="text-lg font-bold text-emerald-400">{attendanceSummary?.presentDays || 0}</span>
              </div>
              <div className="p-3 rounded-xl bg-rose-950/30 border border-rose-500/30">
                <span className="text-[11px] text-rose-300 block mb-0.5">Absent</span>
                <span className="text-lg font-bold text-rose-400">{attendanceSummary?.absentDays || 0}</span>
              </div>
              <div className="p-3 rounded-xl bg-amber-950/30 border border-amber-500/30">
                <span className="text-[11px] text-amber-300 block mb-0.5">Late</span>
                <span className="text-lg font-bold text-amber-400">{attendanceSummary?.lateDays || 0}</span>
              </div>
              <div className="p-3 rounded-xl bg-indigo-950/30 border border-indigo-500/30">
                <span className="text-[11px] text-indigo-300 block mb-0.5">Leaves</span>
                <span className="text-lg font-bold text-indigo-400">{attendanceSummary?.leaveDays || 0}</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/50">
                <span className="text-[11px] text-slate-400 block mb-0.5">Overall %</span>
                <span className="text-lg font-bold text-emerald-400">{attendanceSummary?.percentage || '100.0%'}</span>
              </div>
            </div>

            {/* Recent Attendance Records */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                Recent Daily Records Log
              </h4>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-slate-800/80 text-slate-400 border-b border-slate-700">
                    <tr>
                      <th className="py-2.5 px-4 font-semibold">Date</th>
                      <th className="py-2.5 px-4 font-semibold">Subject / Session</th>
                      <th className="py-2.5 px-4 font-semibold">Attendance Status</th>
                      <th className="py-2.5 px-4 font-semibold">Remarks</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {((attendanceSummary?.recentRecords?.length || 0) > 0) ? (
                      (attendanceSummary?.recentRecords || []).map((rec, idx) => (
                        <tr key={idx} className="hover:bg-slate-800/40">
                          <td className="py-2.5 px-4 font-mono text-white">{rec.date}</td>
                          <td className="py-2.5 px-4 text-slate-300">{rec.subjectName || 'Daily Homeroom'}</td>
                          <td className="py-2.5 px-4">
                            <Badge
                              variant={
                                rec.status === 'PRESENT'
                                  ? 'success'
                                  : rec.status === 'ABSENT'
                                  ? 'danger'
                                  : rec.status === 'LATE'
                                  ? 'warning'
                                  : 'info'
                              }
                              size="sm"
                            >
                              {rec.status}
                            </Badge>
                          </td>
                          <td className="py-2.5 px-4 text-slate-400">{rec.remarks || '—'}</td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={4} className="py-4 text-center text-slate-500 italic">
                          No recent attendance records logged.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* === TAB: EXAMS & GPA === */}
        {activeTab === 'exams' && (
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-6">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Award className="w-5 h-5 text-indigo-400" />
              Examination Performance &amp; Term GPA
            </h3>

            {/* Academic KPIs */}
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
              <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700/50 space-y-1">
                <span className="text-xs text-slate-400">Cumulative GPA</span>
                <p className="text-2xl font-bold text-indigo-300">
                  {examinationSummary?.cumulativeGPA || '3.85'} / 4.0
                </p>
                <span className="text-[11px] text-slate-500">Overall Standard</span>
              </div>

              <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700/50 space-y-1">
                <span className="text-xs text-slate-400">Overall Grade</span>
                <p className="text-2xl font-bold text-emerald-400">
                  {examinationSummary?.overallGrade || 'A'}
                </p>
                <span className="text-[11px] text-slate-500">Letter Evaluation</span>
              </div>

              <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700/50 space-y-1">
                <span className="text-xs text-slate-400">Exams Taken</span>
                <p className="text-2xl font-bold text-white">
                  {examinationSummary?.totalExams || 0}
                </p>
                <span className="text-[11px] text-slate-500">Term Evaluations</span>
              </div>

              <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700/50 space-y-1">
                <span className="text-xs text-slate-400">Passed / Failed</span>
                <p className="text-2xl font-bold text-teal-300">
                  {examinationSummary?.passedExams || 0} / {examinationSummary?.failedExams || 0}
                </p>
                <span className="text-[11px] text-slate-500">Subject Results</span>
              </div>
            </div>

            {/* Recent Results Table */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                Term Examination Results
              </h4>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-slate-800/80 text-slate-400 border-b border-slate-700">
                    <tr>
                      <th className="py-2.5 px-4 font-semibold">Exam Title</th>
                      <th className="py-2.5 px-4 font-semibold">Percentage</th>
                      <th className="py-2.5 px-4 font-semibold">GPA</th>
                      <th className="py-2.5 px-4 font-semibold">Grade</th>
                      <th className="py-2.5 px-4 font-semibold">Standing</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {((examinationSummary?.recentResults?.length || 0) > 0) ? (
                      (examinationSummary?.recentResults || []).map((r, i) => (
                        <tr key={i} className="hover:bg-slate-800/40">
                          <td className="py-2.5 px-4 font-medium text-white">{r.examName}</td>
                          <td className="py-2.5 px-4 font-mono text-indigo-300">{r.overallPercentage}%</td>
                          <td className="py-2.5 px-4 font-mono text-white">{r.gpa}</td>
                          <td className="py-2.5 px-4 font-bold text-emerald-400">{r.overallGrade}</td>
                          <td className="py-2.5 px-4">
                            <Badge variant={r.resultStatus === 'PASSED' ? 'success' : 'danger'} size="sm">
                              {r.resultStatus}
                            </Badge>
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={5} className="py-4 text-center text-slate-500 italic">
                          No published exam results for this student yet.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* === TAB: FINANCIAL RECORDS === */}
        {activeTab === 'fees' && (
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-indigo-400" />
                Fee Invoices &amp; Account Clearance
              </h3>
              <Badge variant={feeSummary?.status === 'CLEARED' ? 'success' : 'warning'}>
                Account: {feeSummary?.status || 'CLEARED'}
              </Badge>
            </div>

            {/* Account Financial Standing */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700/50 space-y-1">
                <span className="text-xs text-slate-400">Total Invoiced</span>
                <p className="text-2xl font-bold text-white">
                  ${feeSummary?.totalInvoiced?.toLocaleString() || '0.00'}
                </p>
                <span className="text-[11px] text-slate-500">Academic Year Total</span>
              </div>

              <div className="p-4 rounded-xl bg-emerald-950/20 border border-emerald-500/20 space-y-1">
                <span className="text-xs text-emerald-300">Total Paid</span>
                <p className="text-2xl font-bold text-emerald-400">
                  ${feeSummary?.totalPaid?.toLocaleString() || '0.00'}
                </p>
                <span className="text-[11px] text-slate-500">Cleared Invoices</span>
              </div>

              <div className="p-4 rounded-xl bg-rose-950/20 border border-rose-500/20 space-y-1">
                <span className="text-xs text-rose-300">Balance Due</span>
                <p className="text-2xl font-bold text-rose-400">
                  ${feeSummary?.totalDue?.toLocaleString() || '0.00'}
                </p>
                <span className="text-[11px] text-slate-500">Outstanding Balance</span>
              </div>
            </div>

            {/* Fee Invoices Table */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                Recent Invoices &amp; Fee Items
              </h4>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-slate-800/80 text-slate-400 border-b border-slate-700">
                    <tr>
                      <th className="py-2.5 px-4 font-semibold">Fee Title</th>
                      <th className="py-2.5 px-4 font-semibold">Due Date</th>
                      <th className="py-2.5 px-4 font-semibold">Amount</th>
                      <th className="py-2.5 px-4 font-semibold">Paid</th>
                      <th className="py-2.5 px-4 font-semibold">Balance</th>
                      <th className="py-2.5 px-4 font-semibold">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {((feeSummary?.recentFees?.length || 0) > 0) ? (
                      (feeSummary?.recentFees || []).map((fee) => (
                        <tr key={fee.id} className="hover:bg-slate-800/40">
                          <td className="py-2.5 px-4 font-medium text-white">{fee.feeTitle}</td>
                          <td className="py-2.5 px-4 font-mono text-slate-400">{fee.dueDate || '—'}</td>
                          <td className="py-2.5 px-4 font-mono text-white">${fee.amount.toLocaleString()}</td>
                          <td className="py-2.5 px-4 font-mono text-emerald-400">${fee.paidAmount.toLocaleString()}</td>
                          <td className="py-2.5 px-4 font-mono text-rose-400">${fee.dueAmount.toLocaleString()}</td>
                          <td className="py-2.5 px-4">
                            <Badge
                              variant={
                                fee.status === 'PAID'
                                  ? 'success'
                                  : fee.status === 'PARTIAL'
                                  ? 'warning'
                                  : 'danger'
                              }
                              size="sm"
                            >
                              {fee.status}
                            </Badge>
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={6} className="py-4 text-center text-slate-500 italic">
                          No fee records found for this student.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* === TAB: DOCUMENT VAULT === */}
        {activeTab === 'documents' && (
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <FolderLock className="w-5 h-5 text-indigo-400" />
                  Student Document Vault ({documents?.length || 0})
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Secure depository for birth certificates, transfer certificates, national IDs, and academic transcripts.
                </p>
              </div>

              {allowEdit && !isSelfService && (
                <Button
                  variant="primary"
                  size="sm"
                  onClick={() => {
                    setDocTitle('');
                    setDocFileBase64('');
                    setDocFileName('');
                    setDocFileSize('');
                    setDocError(null);
                    setDocSuccess(null);
                    setIsDocModalOpen(true);
                  }}
                  icon={<Plus className="w-4 h-4" />}
                >
                  Upload Document
                </Button>
              )}
            </div>

            {/* Document Cards */}
            {documents && documents.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                {documents.map((doc) => (
                  <div
                    key={doc.id}
                    className="p-4 rounded-xl bg-slate-800/60 border border-slate-700/60 flex flex-col justify-between space-y-3"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2.5">
                        <div className="w-9 h-9 rounded-lg bg-indigo-500/20 text-indigo-300 flex items-center justify-center">
                          <FileText className="w-5 h-5" />
                        </div>
                        <div>
                          <h4 className="text-xs font-bold text-white line-clamp-1">{doc.title}</h4>
                          <span className="text-[10px] text-slate-400 font-mono block">
                            {doc.fileSize || 'PDF Document'}
                          </span>
                        </div>
                      </div>

                      <Badge variant="secondary" size="sm">
                        {(doc.category || 'DOCUMENT').replace(/_/g, ' ')}
                      </Badge>
                    </div>

                    <div className="text-[11px] text-slate-400 pt-2 border-t border-slate-700/40 flex items-center justify-between">
                      <span>Uploaded {doc.uploadedAt?.split('T')[0] || '2026-08-01'}</span>
                      <div className="flex items-center gap-1">
                        {doc.fileUrl && (
                          <a
                            href={doc.fileUrl}
                            download={doc.fileName || `${doc.title}.pdf`}
                            className="p-1 rounded text-slate-400 hover:text-white transition-colors"
                            title="Download Document"
                          >
                            <Download className="w-3.5 h-3.5" />
                          </a>
                        )}

                        {allowEdit && !isSelfService && (
                          <button
                            type="button"
                            onClick={() => setDocToDelete(doc)}
                            className="p-1 rounded text-slate-400 hover:text-rose-400 transition-colors"
                            title="Delete Document"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-8 text-center rounded-xl bg-slate-800/30 border border-slate-800 space-y-2">
                <FileText className="w-8 h-8 text-slate-600 mx-auto" />
                <p className="text-xs text-slate-400">No verified documents currently in this student's vault.</p>
                {allowEdit && !isSelfService && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setIsDocModalOpen(true)}
                    className="mt-2"
                  >
                    Add First Document
                  </Button>
                )}
              </div>
            )}
          </div>
        )}

        {/* === TAB: AUDIT HISTORY === */}
        {activeTab === 'audit' && !isSelfService && (
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-6">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Shield className="w-5 h-5 text-indigo-400" />
              Administrative Audit Log &amp; Lifecycle Events
            </h3>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-800/80 text-slate-400 border-b border-slate-700">
                  <tr>
                    <th className="py-2.5 px-4 font-semibold">Timestamp</th>
                    <th className="py-2.5 px-4 font-semibold">Admin / User</th>
                    <th className="py-2.5 px-4 font-semibold">Action</th>
                    <th className="py-2.5 px-4 font-semibold">Audit Details</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {auditTrail && auditTrail.length > 0 ? (
                    auditTrail.map((log) => (
                      <tr key={log.id} className="hover:bg-slate-800/40">
                        <td className="py-2.5 px-4 font-mono text-slate-400">
                          {log.timestamp ? new Date(log.timestamp).toLocaleString() : '—'}
                        </td>
                        <td className="py-2.5 px-4 font-medium text-white">{log.userName || 'Admin'}</td>
                        <td className="py-2.5 px-4">
                          <Badge
                            variant={
                              log.action === 'CREATE'
                                ? 'success'
                                : log.action === 'UPDATE'
                                ? 'info'
                                : 'danger'
                            }
                            size="sm"
                          >
                            {log.action}
                          </Badge>
                        </td>
                        <td className="py-2.5 px-4 text-slate-300">{log.details}</td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={4} className="py-4 text-center text-slate-500 italic">
                        No audit events recorded for this student record.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* PHOTO UPLOAD / UPDATE MODAL */}
      <Modal
        isOpen={isPhotoModalOpen}
        onClose={() => {
          setIsPhotoModalOpen(false);
          setPhotoPreview(null);
          setPhotoError(null);
        }}
        title="Update Student Profile Photo"
        description="Select a JPG, PNG, or WEBP portrait photo (maximum file size: 5MB)."
      >
        <div className="space-y-4 text-xs">
          {photoError && <Alert variant="danger">{photoError}</Alert>}
          {photoSuccess && <Alert variant="success">{photoSuccess}</Alert>}

          <div className="flex flex-col items-center justify-center p-6 border-2 border-dashed border-slate-700 rounded-2xl bg-slate-800/40 text-center">
            {photoPreview ? (
              <div className="relative mb-3">
                <img
                  src={photoPreview}
                  alt="Preview"
                  className="w-28 h-28 rounded-2xl object-cover border-2 border-indigo-500/50 shadow-md"
                />
              </div>
            ) : (
              <Camera className="w-12 h-12 text-slate-500 mb-3" />
            )}

            <input
              ref={fileInputRef}
              type="file"
              accept="image/jpeg,image/jpg,image/png,image/webp"
              onChange={handlePhotoSelect}
              className="hidden"
            />

            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => fileInputRef.current?.click()}
              icon={<Upload className="w-3.5 h-3.5" />}
            >
              Choose Image File
            </Button>
            <span className="text-[11px] text-slate-400 mt-2">
              Formats: JPEG, PNG, WEBP (under 5MB)
            </span>
          </div>

          <div className="flex justify-between items-center pt-2">
            {profile.avatarUrl ? (
              <Button
                type="button"
                variant="danger"
                size="sm"
                onClick={handlePhotoRemove}
                disabled={photoSubmitting}
                icon={<Trash2 className="w-3.5 h-3.5" />}
              >
                Remove Current Photo
              </Button>
            ) : (
              <div />
            )}

            <div className="flex gap-2">
              <Button
                type="button"
                variant="secondary"
                size="sm"
                onClick={() => setIsPhotoModalOpen(false)}
                disabled={photoSubmitting}
              >
                Cancel
              </Button>
              <Button
                type="button"
                variant="primary"
                size="sm"
                onClick={handlePhotoUploadSubmit}
                loading={photoSubmitting}
                disabled={!photoPreview || photoSubmitting}
              >
                Save Photo
              </Button>
            </div>
          </div>
        </div>
      </Modal>

      {/* DOCUMENT UPLOAD MODAL */}
      <Modal
        isOpen={isDocModalOpen}
        onClose={() => setIsDocModalOpen(false)}
        title="Upload Student Document"
        description="Attach official records and transcripts to the institutional vault."
      >
        <form onSubmit={handleDocUploadSubmit} className="space-y-4 text-xs">
          {docError && <Alert variant="danger">{docError}</Alert>}
          {docSuccess && <Alert variant="success">{docSuccess}</Alert>}

          <Input
            label="Document Title *"
            value={docTitle}
            onChange={(e) => setDocTitle(e.target.value)}
            placeholder="e.g., Grade 9 Academic Transcript"
            required
          />

          <Select
            label="Document Category *"
            value={docCategory}
            onChange={(e) => setDocCategory(e.target.value as any)}
            options={[
              { value: 'BIRTH_CERTIFICATE', label: 'Birth Certificate' },
              { value: 'NATIONAL_ID', label: 'National ID / Passport' },
              { value: 'TRANSFER_CERTIFICATE', label: 'Transfer Certificate (TC)' },
              { value: 'MEDICAL_RECORD', label: 'Medical & Immunization Record' },
              { value: 'PREVIOUS_TRANSCRIPT', label: 'Previous Academic Transcript' },
              { value: 'OTHER', label: 'Other Official Document' }
            ]}
          />

          <div className="space-y-1.5">
            <label className="font-medium text-slate-300">File Attachment (PDF or Image) *</label>
            <input
              ref={docInputRef}
              type="file"
              accept=".pdf,image/jpeg,image/png,image/webp"
              onChange={handleDocFileSelect}
              className="hidden"
            />
            <div className="flex items-center gap-3">
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => docInputRef.current?.click()}
                icon={<Upload className="w-3.5 h-3.5" />}
              >
                Select File
              </Button>
              {docFileName && (
                <span className="text-xs text-indigo-300 font-mono truncate max-w-[200px]">
                  {docFileName} ({docFileSize})
                </span>
              )}
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-slate-700">
            <Button
              type="button"
              variant="secondary"
              size="sm"
              onClick={() => setIsDocModalOpen(false)}
              disabled={docSubmitting}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              variant="primary"
              size="sm"
              loading={docSubmitting}
              disabled={docSubmitting || !docFileBase64}
            >
              Upload to Vault
            </Button>
          </div>
        </form>
      </Modal>

      {/* CONFIRM DELETE DOCUMENT DIALOG */}
      <ConfirmDialog
        isOpen={Boolean(docToDelete)}
        onClose={() => setDocToDelete(null)}
        onConfirm={handleConfirmDeleteDoc}
        title="Delete Document"
        message={`Are you sure you want to delete the document "${docToDelete?.title}" from the student vault? This action cannot be undone.`}
        confirmText="Delete"
        variant="danger"
        loading={deletingDoc}
      />

      {/* SELF-SERVICE CONTACT EDIT MODAL */}
      <Modal
        isOpen={isContactEditOpen}
        onClose={() => setIsContactEditOpen(false)}
        title="Edit Contact &amp; Residential Details"
        description="Update your phone, email, emergency contact, and residential address."
      >
        <form onSubmit={handleSaveContact} className="space-y-4 text-xs">
          {contactError && <Alert variant="danger">{contactError}</Alert>}
          {contactSuccess && <Alert variant="success">{contactSuccess}</Alert>}

          <Input
            label="Primary Phone Number"
            value={contactPhone}
            onChange={(e) => setContactPhone(e.target.value)}
            placeholder="+1-617-555-0144"
          />

          <Input
            label="Student Email Address"
            type="email"
            value={contactEmail}
            onChange={(e) => setContactEmail(e.target.value)}
            placeholder="student@example.com"
          />

          <Input
            label="Emergency Contact Phone"
            value={contactEmergency}
            onChange={(e) => setContactEmergency(e.target.value)}
            placeholder="+1-617-555-0199"
          />

          <Input
            label="Residential Address"
            value={contactAddress}
            onChange={(e) => setContactAddress(e.target.value)}
            placeholder="124 College Avenue, Boston, MA"
          />

          <div className="flex justify-end gap-2 pt-2 border-t border-slate-700">
            <Button
              type="button"
              variant="secondary"
              size="sm"
              onClick={() => setIsContactEditOpen(false)}
              disabled={contactSaving}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              variant="primary"
              size="sm"
              loading={contactSaving}
            >
              Save Details
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
