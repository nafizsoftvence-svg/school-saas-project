/**
 * Part 15A — Document Detail & Version History Modal
 * Sygmate School Management System
 */

import React, { useState } from 'react';
import {
  X,
  FileText,
  CheckCircle2,
  XCircle,
  Clock,
  AlertTriangle,
  Download,
  Upload,
  History,
  ShieldCheck,
  Building2,
  User,
  GraduationCap,
  Users,
  Eye,
  Tag,
  Lock,
  Calendar,
  ExternalLink,
  Edit2,
  Archive,
  RefreshCw,
  Info
} from 'lucide-react';
import { ManagedDocument, User as AuthUser } from '../../types';
import { Button } from '../ui/Button';

interface DocumentDetailModalProps {
  document: ManagedDocument;
  currentUser: AuthUser | null;
  onClose: () => void;
  onUploadNewVersion: (doc: ManagedDocument) => void;
  onVerify: (doc: ManagedDocument, status: 'VERIFIED' | 'REJECTED', remarks?: string) => Promise<void>;
  onEditMetadata: (doc: ManagedDocument) => void;
  onArchive: (doc: ManagedDocument) => Promise<void>;
}

export const DocumentDetailModal: React.FC<DocumentDetailModalProps> = ({
  document,
  currentUser,
  onClose,
  onUploadNewVersion,
  onVerify,
  onEditMetadata,
  onArchive
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'preview' | 'versions'>('overview');
  const [isVerifying, setIsVerifying] = useState(false);
  const [verifyAction, setVerifyAction] = useState<'VERIFIED' | 'REJECTED' | null>(null);
  const [remarks, setRemarks] = useState('');
  const [submittingVerification, setSubmittingVerification] = useState(false);

  const canVerify = currentUser?.role === 'SUPER_ADMIN';
  const canArchive = currentUser?.role === 'SUPER_ADMIN';
  const canUploadVersion = currentUser?.role === 'SUPER_ADMIN' || currentUser?.role === 'TEACHER';

  const isExpired = document.expiryDate && new Date(document.expiryDate) < new Date();
  const isExpiringSoon =
    document.expiryDate &&
    !isExpired &&
    new Date(document.expiryDate) <= new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);

  const handleConfirmVerification = async () => {
    if (!verifyAction) return;
    setSubmittingVerification(true);
    try {
      await onVerify(document, verifyAction, remarks);
      setIsVerifying(false);
      setVerifyAction(null);
      setRemarks('');
    } catch (err) {
      console.error('Verification failed', err);
    } finally {
      setSubmittingVerification(false);
    }
  };

  const getEntityIcon = (entityType: string) => {
    switch (entityType) {
      case 'STUDENT':
        return <GraduationCap className="w-4 h-4 text-sky-400" />;
      case 'TEACHER':
      case 'STAFF':
        return <User className="w-4 h-4 text-purple-400" />;
      case 'GUARDIAN':
        return <Users className="w-4 h-4 text-amber-400" />;
      case 'SCHOOL':
      case 'DEPARTMENT':
        return <Building2 className="w-4 h-4 text-emerald-400" />;
      default:
        return <FileText className="w-4 h-4 text-slate-400" />;
    }
  };

  const getStatusBadge = (status: string, verificationStatus: string) => {
    if (isExpired) {
      return (
        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-rose-500/10 text-rose-400 border border-rose-500/20">
          <AlertTriangle className="w-3.5 h-3.5" />
          Expired
        </span>
      );
    }
    if (verificationStatus === 'VERIFIED') {
      return (
        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
          <CheckCircle2 className="w-3.5 h-3.5" />
          Verified
        </span>
      );
    }
    if (verificationStatus === 'REJECTED') {
      return (
        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-red-500/10 text-red-400 border border-red-500/20">
          <XCircle className="w-3.5 h-3.5" />
          Rejected
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/20">
        <Clock className="w-3.5 h-3.5" />
        Pending Review
      </span>
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-8 flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-start justify-between p-6 border-b border-slate-800 bg-slate-900/60">
          <div className="flex items-start gap-4">
            <div className="p-3 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 mt-1">
              <FileText className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="px-2 py-0.5 rounded text-xs font-medium bg-slate-800 text-slate-300 border border-slate-700">
                  {document.documentTypeName}
                </span>
                <span className="px-2 py-0.5 rounded text-xs font-medium bg-slate-800/80 text-indigo-300 border border-indigo-500/30">
                  {document.category}
                </span>
                {document.isConfidential && (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-medium bg-rose-500/10 text-rose-400 border border-rose-500/20">
                    <Lock className="w-3 h-3" /> Confidential
                  </span>
                )}
                {getStatusBadge(document.status, document.verificationStatus)}
              </div>
              <h2 className="text-xl font-bold text-white mt-1.5">{document.documentTitle}</h2>
              <div className="flex items-center gap-3 text-xs text-slate-400 mt-1 flex-wrap">
                <span className="flex items-center gap-1">
                  {getEntityIcon(document.entityType)}
                  <strong className="text-slate-200">{document.entityName || document.entityId}</strong>
                  {document.entityCode && <span className="text-slate-500">({document.entityCode})</span>}
                </span>
                <span>•</span>
                <span>Version: <strong className="text-slate-200">v{document.version}</strong></span>
                <span>•</span>
                <span>Updated: {new Date(document.updatedAt).toLocaleDateString()}</span>
              </div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-800 px-6 bg-slate-900/30">
          <button
            onClick={() => setActiveTab('overview')}
            className={`py-3 px-4 text-sm font-medium border-b-2 flex items-center gap-2 transition-colors ${
              activeTab === 'overview'
                ? 'border-indigo-500 text-indigo-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Info className="w-4 h-4" />
            Overview & Metadata
          </button>
          <button
            onClick={() => setActiveTab('preview')}
            className={`py-3 px-4 text-sm font-medium border-b-2 flex items-center gap-2 transition-colors ${
              activeTab === 'preview'
                ? 'border-indigo-500 text-indigo-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Eye className="w-4 h-4" />
            Document Viewer
          </button>
          <button
            onClick={() => setActiveTab('versions')}
            className={`py-3 px-4 text-sm font-medium border-b-2 flex items-center gap-2 transition-colors ${
              activeTab === 'versions'
                ? 'border-indigo-500 text-indigo-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <History className="w-4 h-4" />
            Version History ({document.versionHistory?.length || 1})
          </button>
        </div>

        {/* Tab Content */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Expiry / Verification Notice Banner */}
              {isExpired && (
                <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/20 flex items-start gap-3 text-rose-300 text-sm">
                  <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="font-semibold block text-rose-200">Document Expired</strong>
                    This credential expired on {new Date(document.expiryDate!).toLocaleDateString()}. A renewed version must be uploaded to maintain regulatory compliance.
                  </div>
                </div>
              )}
              {isExpiringSoon && (
                <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-start gap-3 text-amber-300 text-sm">
                  <Clock className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="font-semibold block text-amber-200">Expiring Soon</strong>
                    This document will expire on {new Date(document.expiryDate!).toLocaleDateString()} (within 30 days).
                  </div>
                </div>
              )}
              {document.verificationStatus === 'REJECTED' && document.rejectionReason && (
                <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/20 flex items-start gap-3 text-red-300 text-sm">
                  <XCircle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="font-semibold block text-red-200">Rejection Notice</strong>
                    {document.rejectionReason}
                  </div>
                </div>
              )}

              {/* Grid Metadata Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* File Details */}
                <div className="p-4 rounded-xl bg-slate-800/40 border border-slate-800 space-y-3">
                  <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                    <FileText className="w-3.5 h-3.5 text-indigo-400" />
                    Physical File Attributes
                  </h4>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div>
                      <span className="text-xs text-slate-500 block">File Name</span>
                      <span className="font-medium text-slate-200 truncate block" title={document.fileName}>
                        {document.fileName}
                      </span>
                    </div>
                    <div>
                      <span className="text-xs text-slate-500 block">File Size</span>
                      <span className="font-medium text-slate-200">{document.fileSize}</span>
                    </div>
                    <div>
                      <span className="text-xs text-slate-500 block">Format / MIME</span>
                      <span className="font-medium text-slate-200 uppercase">{document.fileType}</span>
                    </div>
                    <div>
                      <span className="text-xs text-slate-500 block">Active Version</span>
                      <span className="font-semibold text-indigo-400">v{document.version}</span>
                    </div>
                  </div>
                </div>

                {/* Registry & Dates */}
                <div className="p-4 rounded-xl bg-slate-800/40 border border-slate-800 space-y-3">
                  <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-indigo-400" />
                    Registry & Lifecycle Dates
                  </h4>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div>
                      <span className="text-xs text-slate-500 block">Reference Number</span>
                      <span className="font-medium text-slate-200 font-mono">
                        {document.referenceNumber || 'N/A'}
                      </span>
                    </div>
                    <div>
                      <span className="text-xs text-slate-500 block">Issue Date</span>
                      <span className="font-medium text-slate-200">
                        {document.issueDate ? new Date(document.issueDate).toLocaleDateString() : 'N/A'}
                      </span>
                    </div>
                    <div>
                      <span className="text-xs text-slate-500 block">Expiry Date</span>
                      <span className={`font-medium ${isExpired ? 'text-rose-400' : 'text-slate-200'}`}>
                        {document.expiryDate ? new Date(document.expiryDate).toLocaleDateString() : 'No Expiry'}
                      </span>
                    </div>
                    <div>
                      <span className="text-xs text-slate-500 block">Initial Upload Date</span>
                      <span className="font-medium text-slate-200">
                        {new Date(document.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Verification & Audit Details */}
              <div className="p-4 rounded-xl bg-slate-800/40 border border-slate-800 space-y-3">
                <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-indigo-400" />
                  Verification & Audit Trail
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-sm">
                  <div>
                    <span className="text-xs text-slate-500 block">Uploaded By</span>
                    <span className="font-medium text-slate-200">{document.createdByName || 'System'}</span>
                  </div>
                  <div>
                    <span className="text-xs text-slate-500 block">Verified / Reviewed By</span>
                    <span className="font-medium text-slate-200">{document.verifiedByName || 'Pending Review'}</span>
                  </div>
                  <div>
                    <span className="text-xs text-slate-500 block">Verification Timestamp</span>
                    <span className="font-medium text-slate-200">
                      {document.verifiedAt ? new Date(document.verifiedAt).toLocaleString() : 'N/A'}
                    </span>
                  </div>
                </div>
                {document.verificationRemarks && (
                  <div className="mt-2 pt-2 border-t border-slate-800 text-xs">
                    <span className="text-slate-500 block">Reviewer Remarks:</span>
                    <p className="text-slate-300 italic mt-0.5">{document.verificationRemarks}</p>
                  </div>
                )}
              </div>

              {/* Description & Internal Notes */}
              {(document.description || document.notes) && (
                <div className="p-4 rounded-xl bg-slate-800/40 border border-slate-800 space-y-2 text-sm">
                  {document.description && (
                    <div>
                      <span className="text-xs text-slate-500 block font-semibold">Description</span>
                      <p className="text-slate-300 mt-1">{document.description}</p>
                    </div>
                  )}
                  {document.notes && (
                    <div className="pt-2 border-t border-slate-800">
                      <span className="text-xs text-slate-500 block font-semibold">Institutional Notes</span>
                      <p className="text-slate-400 mt-1 text-xs">{document.notes}</p>
                    </div>
                  )}
                </div>
              )}

              {/* Tags */}
              {document.tags && document.tags.length > 0 && (
                <div className="flex items-center gap-2 flex-wrap">
                  <Tag className="w-3.5 h-3.5 text-slate-500" />
                  <span className="text-xs text-slate-500">Tags:</span>
                  {document.tags.map((t, idx) => (
                    <span
                      key={idx}
                      className="px-2 py-0.5 rounded text-xs bg-slate-800 text-slate-300 border border-slate-700"
                    >
                      {t}
                    </span>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeTab === 'preview' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 rounded-xl bg-slate-800/40 border border-slate-800">
                <div className="flex items-center gap-2 text-xs text-slate-300">
                  <FileText className="w-4 h-4 text-indigo-400" />
                  <span>Viewing file: <strong>{document.fileName}</strong> ({document.fileSize})</span>
                </div>
                <div className="flex items-center gap-2">
                  <a
                    href={document.fileUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="px-3 py-1 rounded-lg text-xs font-medium bg-slate-800 text-slate-200 hover:bg-slate-700 flex items-center gap-1.5 border border-slate-700"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    Open in New Window
                  </a>
                  <a
                    href={document.fileUrl}
                    download={document.fileName}
                    className="px-3 py-1 rounded-lg text-xs font-medium bg-indigo-600 text-white hover:bg-indigo-500 flex items-center gap-1.5 shadow"
                  >
                    <Download className="w-3.5 h-3.5" />
                    Download File
                  </a>
                </div>
              </div>

              {/* Embedded Document Frame */}
              <div className="w-full h-96 sm:h-[450px] rounded-xl border border-slate-800 bg-slate-950 flex flex-col items-center justify-center overflow-hidden relative">
                {document.fileUrl.startsWith('data:image') ||
                document.fileName.match(/\.(jpg|jpeg|png|webp|gif)$/i) ||
                document.fileUrl.includes('images.unsplash.com') ? (
                  <img
                    src={document.fileUrl}
                    alt={document.documentTitle}
                    className="max-h-full max-w-full object-contain p-2"
                  />
                ) : (
                  <div className="p-8 text-center space-y-4 max-w-md">
                    <div className="w-16 h-16 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 flex items-center justify-center mx-auto">
                      <FileText className="w-8 h-8" />
                    </div>
                    <div>
                      <h4 className="text-base font-bold text-white">{document.fileName}</h4>
                      <p className="text-xs text-slate-400 mt-1">
                        Secure digital preview stream active. Formats such as PDF and institutional docs are protected by institutional RBAC.
                      </p>
                    </div>
                    <div className="flex items-center justify-center gap-3">
                      <a
                        href={document.fileUrl}
                        download={document.fileName}
                        className="px-4 py-2 rounded-xl text-sm font-semibold bg-indigo-600 text-white hover:bg-indigo-500 flex items-center gap-2 shadow-lg"
                      >
                        <Download className="w-4 h-4" />
                        Download Document
                      </a>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {activeTab === 'versions' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-bold text-white">Immutable Version History</h4>
                  <p className="text-xs text-slate-400">
                    Complete archival audit trail of all previous submissions, revisions, and corrections.
                  </p>
                </div>
                {canUploadVersion && (
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => onUploadNewVersion(document)}
                    className="flex items-center gap-1.5"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    Upload Next Version
                  </Button>
                )}
              </div>

              <div className="space-y-3">
                {(document.versionHistory || []).map((ver) => (
                  <div
                    key={ver.version}
                    className={`p-4 rounded-xl border transition-all ${
                      ver.version === document.version
                        ? 'bg-indigo-950/20 border-indigo-500/40 ring-1 ring-indigo-500/20'
                        : 'bg-slate-800/30 border-slate-800'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex items-start gap-3">
                        <div
                          className={`w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold shrink-0 mt-0.5 ${
                            ver.version === document.version
                              ? 'bg-indigo-600 text-white'
                              : 'bg-slate-800 text-slate-300'
                          }`}
                        >
                          v{ver.version}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-semibold text-white text-sm">{ver.fileName}</span>
                            {ver.version === document.version && (
                              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                                Active Version
                              </span>
                            )}
                          </div>
                          <div className="flex items-center gap-3 text-xs text-slate-400 mt-1">
                            <span>Uploaded by: <strong className="text-slate-300">{ver.uploadedByName || ver.uploadedBy}</strong></span>
                            <span>•</span>
                            <span>{new Date(ver.uploadedAt).toLocaleString()}</span>
                            <span>•</span>
                            <span>{ver.fileSize}</span>
                          </div>
                          {ver.changeNotes && (
                            <p className="text-xs text-slate-300 bg-slate-900/60 p-2 rounded-lg border border-slate-800 mt-2">
                              {ver.changeNotes}
                            </p>
                          )}
                        </div>
                      </div>

                      <a
                        href={ver.fileUrl}
                        download={ver.fileName}
                        className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors shrink-0"
                        title="Download this version"
                      >
                        <Download className="w-4 h-4" />
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Verification Action Drawer (when toggled) */}
          {isVerifying && (
            <div className="p-4 rounded-xl bg-slate-800 border border-slate-700 space-y-4 animate-in fade-in slide-in-from-bottom-2">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-bold text-white flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-indigo-400" />
                  Confirm Verification Decision: {verifyAction === 'VERIFIED' ? 'Approve & Verify' : 'Reject Document'}
                </h4>
                <button
                  onClick={() => setIsVerifying(false)}
                  className="text-slate-400 hover:text-white text-xs"
                >
                  Cancel
                </button>
              </div>

              <div>
                <label className="text-xs text-slate-300 font-medium block mb-1">
                  {verifyAction === 'VERIFIED' ? 'Verification Remarks (Optional)' : 'Rejection Reason (Required)'}
                </label>
                <textarea
                  value={remarks}
                  onChange={(e) => setRemarks(e.target.value)}
                  placeholder={
                    verifyAction === 'VERIFIED'
                      ? 'Add any verification notes, registrar confirmation, or seal numbers...'
                      : 'State clearly why this document is rejected (e.g. illegible scan, missing stamp, expired)...'
                  }
                  rows={3}
                  className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="flex justify-end gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => setIsVerifying(false)}
                  disabled={submittingVerification}
                >
                  Cancel
                </Button>
                <Button
                  size="sm"
                  variant={verifyAction === 'VERIFIED' ? 'default' : 'danger'}
                  onClick={handleConfirmVerification}
                  disabled={submittingVerification || (verifyAction === 'REJECTED' && !remarks.trim())}
                >
                  {submittingVerification ? 'Submitting...' : verifyAction === 'VERIFIED' ? 'Confirm Verification' : 'Confirm Rejection'}
                </Button>
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-slate-800 bg-slate-900/60 flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-2">
            {canVerify && !isVerifying && (
              <>
                <Button
                  size="sm"
                  variant="default"
                  onClick={() => {
                    setVerifyAction('VERIFIED');
                    setIsVerifying(true);
                  }}
                  className="bg-emerald-600 hover:bg-emerald-500 text-white flex items-center gap-1.5"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  Verify
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => {
                    setVerifyAction('REJECTED');
                    setIsVerifying(true);
                  }}
                  className="text-red-400 hover:text-red-300 border-red-500/30 hover:bg-red-500/10 flex items-center gap-1.5"
                >
                  <XCircle className="w-4 h-4" />
                  Reject
                </Button>
              </>
            )}

            {canUploadVersion && (
              <Button
                size="sm"
                variant="outline"
                onClick={() => onUploadNewVersion(document)}
                className="flex items-center gap-1.5"
              >
                <Upload className="w-3.5 h-3.5" />
                New Version
              </Button>
            )}

            <Button
              size="sm"
              variant="outline"
              onClick={() => onEditMetadata(document)}
              className="flex items-center gap-1.5"
            >
              <Edit2 className="w-3.5 h-3.5" />
              Edit Metadata
            </Button>
          </div>

          <div className="flex items-center gap-2">
            {canArchive && document.status !== 'ARCHIVED' && (
              <Button
                size="sm"
                variant="outline"
                onClick={() => onArchive(document)}
                className="text-amber-400 hover:text-amber-300 border-amber-500/30 hover:bg-amber-500/10 flex items-center gap-1.5"
              >
                <Archive className="w-3.5 h-3.5" />
                Archive
              </Button>
            )}

            <a
              href={document.fileUrl}
              download={document.fileName}
              className="px-3.5 py-1.5 rounded-lg text-sm font-semibold bg-indigo-600 text-white hover:bg-indigo-500 flex items-center gap-1.5 shadow"
            >
              <Download className="w-4 h-4" />
              Download
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
