import React, { useState } from 'react';
import {
  X,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  ZoomIn,
  ZoomOut,
  RotateCw,
  Download,
  FileText,
  Calendar,
  User,
  ShieldCheck,
  Building2,
  Eye
} from 'lucide-react';
import { StudentDocument } from '../../types';

interface StudentDocumentReviewModalProps {
  document: StudentDocument;
  isOpen: boolean;
  onClose: () => void;
  onVerified: (updatedDoc: StudentDocument) => void;
}

export const StudentDocumentReviewModal: React.FC<StudentDocumentReviewModalProps> = ({
  document,
  isOpen,
  onClose,
  onVerified
}) => {
  const [zoom, setZoom] = useState(1);
  const [rotation, setRotation] = useState(0);
  const [rejecting, setRejecting] = useState(false);
  const [rejectionReason, setRejectionReason] = useState('Illegible or low-resolution scan');
  const [remarks, setRemarks] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleVerifyAction = async (status: 'VERIFIED' | 'REJECTED') => {
    setLoading(true);
    setError(null);

    try {
      const token = localStorage.getItem('sygmate_auth_token') || localStorage.getItem('token');
      const res = await fetch(`/api/documents-idcards/documents/${document.id}/verify`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {})
        },
        body: JSON.stringify({
          verificationStatus: status,
          remarks: remarks.trim() || undefined,
          rejectionReason: status === 'REJECTED' ? rejectionReason : undefined
        })
      });

      const isJson = (res.headers.get('content-type') || '').includes('application/json');
      const data = isJson ? await res.json() : null;
      if (!res.ok || !data?.success) {
        throw new Error(data?.error || `Failed to update document verification status (HTTP ${res.status})`);
      }

      onVerified(data.data);
      onClose();
    } catch (err: any) {
      setError(err.message || 'Error occurred while verifying document');
    } finally {
      setLoading(false);
    }
  };

  const status = (document.verificationStatus || 'PENDING_VERIFICATION').toUpperCase();

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-4xl h-[85vh] rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col animate-in fade-in zoom-in-95 duration-200">
        {/* Modal Header */}
        <div className="px-6 py-3.5 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-indigo-500/20 text-indigo-400 flex items-center justify-center border border-indigo-500/30">
              <FileText className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                {document.title || document.name}
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider ${
                  status === 'VERIFIED'
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                    : (status === 'REJECTED'
                        ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                        : 'bg-amber-500/20 text-amber-300 border border-amber-500/30')
                }`}>
                  {status}
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                {document.studentName ? `${document.studentName} (${document.admissionNumber})` : 'Student Document'} • {document.category || 'OTHER'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <a
              href={document.fileUrl || document.url}
              download={document.fileName || 'document.pdf'}
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-1 text-xs text-slate-300 hover:text-white px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 transition"
            >
              <Download className="w-3.5 h-3.5" />
              Download
            </a>
            <button
              type="button"
              onClick={onClose}
              className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Main Area: Left Preview (flex-1), Right Metadata & Actions (w-80) */}
        <div className="flex-1 flex overflow-hidden">
          {/* Left Preview Pane */}
          <div className="flex-1 bg-slate-100 relative flex flex-col items-center justify-center p-6 overflow-auto">
            {/* Viewer Controls floating strip */}
            <div className="absolute top-4 right-4 z-10 flex items-center gap-1 bg-white/90 backdrop-blur-xs px-2.5 py-1 rounded-xl shadow-md border border-slate-200">
              <button
                type="button"
                onClick={() => setZoom(prev => Math.min(prev + 0.25, 2.5))}
                className="p-1 hover:bg-slate-100 rounded text-slate-600 hover:text-slate-900"
                title="Zoom In"
              >
                <ZoomIn className="w-4 h-4" />
              </button>
              <span className="text-[11px] font-mono font-semibold text-slate-600 px-1">
                {Math.round(zoom * 100)}%
              </span>
              <button
                type="button"
                onClick={() => setZoom(prev => Math.max(prev - 0.25, 0.5))}
                className="p-1 hover:bg-slate-100 rounded text-slate-600 hover:text-slate-900"
                title="Zoom Out"
              >
                <ZoomOut className="w-4 h-4" />
              </button>
              <div className="w-[1px] h-3.5 bg-slate-200 mx-0.5" />
              <button
                type="button"
                onClick={() => setRotation(prev => (prev + 90) % 360)}
                className="p-1 hover:bg-slate-100 rounded text-slate-600 hover:text-slate-900"
                title="Rotate 90deg"
              >
                <RotateCw className="w-4 h-4" />
              </button>
            </div>

            {/* Simulated Document Canvas / Realistic Document Viewer */}
            <div
              className="bg-white shadow-2xl rounded-lg p-8 max-w-md w-full border border-slate-300 transition-transform duration-200 select-none text-slate-800 font-sans"
              style={{
                transform: `scale(${zoom}) rotate(${rotation}deg)`,
                transformOrigin: 'center center'
              }}
            >
              <div className="border-b-2 border-slate-900 pb-3 flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-black uppercase tracking-widest text-slate-900">
                    OFFICIAL CERTIFICATION RECORD
                  </h4>
                  <p className="text-[9px] text-slate-500 font-medium">Department of Student Registration</p>
                </div>
                <div className="w-10 h-10 rounded-full border-2 border-indigo-600 flex items-center justify-center text-[7.5px] font-bold text-indigo-700 text-center leading-none">
                  SEAL<br/>VERIFIED
                </div>
              </div>

              <div className="py-6 space-y-3 text-xs">
                <div className="p-2.5 bg-slate-50 rounded border border-slate-200">
                  <span className="text-[9px] font-bold text-slate-500 uppercase block">Document Title</span>
                  <span className="font-bold text-slate-900 text-sm">{document.title || document.name}</span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-[11px]">
                  <div>
                    <span className="text-[9px] text-slate-500 uppercase font-bold block">Document Number</span>
                    <span className="font-mono font-semibold">{document.documentNumber || 'DOC-2026-REG-98'}</span>
                  </div>
                  <div>
                    <span className="text-[9px] text-slate-500 uppercase font-bold block">Issuing Authority</span>
                    <span className="font-semibold">{document.issuingAuthority || 'Ministry of Education & Civil Registry'}</span>
                  </div>
                </div>

                <div className="p-3 bg-indigo-50/50 rounded border border-indigo-100 text-[10.5px] text-slate-700 leading-relaxed">
                  This document certifies that the academic and civil identity credentials for <strong>{document.studentName || 'Student'}</strong> (Admission #{document.admissionNumber || 'ADM-2026-0842'}) have been filed in institutional repository compliance with national educational standards.
                </div>
              </div>

              <div className="pt-4 border-t border-slate-200 flex items-center justify-between text-[9px] text-slate-500">
                <span>Ref: {document.id}</span>
                <span className="font-serif italic text-xs text-slate-700">Authorized Signature</span>
              </div>
            </div>
          </div>

          {/* Right Sidebar: Details & Verification Panel */}
          <div className="w-84 bg-white border-l border-slate-200 p-5 flex flex-col justify-between overflow-y-auto">
            <div className="space-y-4">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Document Metadata
              </h4>

              <div className="space-y-2.5 text-xs">
                <div>
                  <span className="text-[10px] uppercase font-semibold text-slate-400 block">Category</span>
                  <span className="font-semibold text-slate-800">{document.category || 'OTHER'}</span>
                </div>
                <div>
                  <span className="text-[10px] uppercase font-semibold text-slate-400 block">File Name & Size</span>
                  <span className="font-medium text-slate-700">{document.fileName || 'document.pdf'} ({document.fileSize || document.size || '245 KB'})</span>
                </div>
                <div>
                  <span className="text-[10px] uppercase font-semibold text-slate-400 block">Uploaded On</span>
                  <span className="font-medium text-slate-700">{new Date(document.uploadedAt).toLocaleDateString()}</span>
                </div>
                {document.verifiedByName && (
                  <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200 text-xs">
                    <span className="text-[10px] uppercase font-bold text-slate-500 block">Last Verified By</span>
                    <span className="font-semibold text-slate-800">{document.verifiedByName}</span>
                    {document.verifiedAt && (
                      <span className="text-[10.5px] text-slate-500 block">
                        {new Date(document.verifiedAt).toLocaleString()}
                      </span>
                    )}
                    {document.verificationRemarks && (
                      <p className="text-[11px] text-slate-600 mt-1 italic">
                        "{document.verificationRemarks}"
                      </p>
                    )}
                  </div>
                )}
              </div>

              {error && (
                <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-xl flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0 text-rose-500" />
                  {error}
                </div>
              )}

              {/* Rejection form expansion if clicked */}
              {rejecting && (
                <div className="p-3 bg-rose-50/70 border border-rose-200 rounded-xl space-y-2 text-xs">
                  <label className="block font-bold text-rose-900">
                    Select Rejection Reason <span className="text-rose-600">*</span>
                  </label>
                  <select
                    value={rejectionReason}
                    onChange={(e) => setRejectionReason(e.target.value)}
                    className="w-full text-xs p-2 rounded-lg border border-rose-300 bg-white"
                  >
                    <option value="Illegible or low-resolution scan">Illegible or low-resolution scan</option>
                    <option value="Expired document / Invalid date">Expired document / Invalid date</option>
                    <option value="Missing official seal or authorized signature">Missing official seal or authorized signature</option>
                    <option value="Student name mismatch with admission record">Student name mismatch with admission record</option>
                    <option value="Incomplete pages or cropped sections">Incomplete pages or cropped sections</option>
                    <option value="Wrong document category submitted">Wrong document category submitted</option>
                  </select>

                  <label className="block font-bold text-rose-900 pt-1">
                    Internal / Parent Remarks (Optional)
                  </label>
                  <textarea
                    rows={2}
                    value={remarks}
                    onChange={(e) => setRemarks(e.target.value)}
                    placeholder="e.g. Please re-scan original birth certificate in color..."
                    className="w-full text-xs p-2 rounded-lg border border-rose-300 bg-white"
                  />
                </div>
              )}
            </div>

            {/* Action Buttons */}
            <div className="pt-4 border-t border-slate-200 space-y-2">
              {!rejecting ? (
                <>
                  <button
                    type="button"
                    disabled={loading}
                    onClick={() => handleVerifyAction('VERIFIED')}
                    className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow flex items-center justify-center gap-1.5 transition disabled:opacity-50"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    Approve & Verify Document
                  </button>
                  <button
                    type="button"
                    disabled={loading}
                    onClick={() => setRejecting(true)}
                    className="w-full py-2.5 bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-bold rounded-xl border border-rose-200 flex items-center justify-center gap-1.5 transition disabled:opacity-50"
                  >
                    <XCircle className="w-4 h-4" />
                    Reject Document
                  </button>
                </>
              ) : (
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setRejecting(false)}
                    className="flex-1 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-xl transition"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    disabled={loading}
                    onClick={() => handleVerifyAction('REJECTED')}
                    className="flex-1 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-xl shadow transition disabled:opacity-50"
                  >
                    Confirm Rejection
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
