/**
 * Part 15A — Configurable Document Category & Type Modal
 * Sygmate School Management System
 */

import React, { useState } from 'react';
import {
  X,
  SlidersHorizontal,
  CheckCircle2,
  AlertTriangle,
  FileText,
  Calendar,
  Layers
} from 'lucide-react';
import {
  DocumentTypeConfig,
  DocumentEntityType,
  DocumentCategory,
  CreateDocumentTypePayload
} from '../../types';
import { Button } from '../ui/Button';

interface DocumentTypeConfigModalProps {
  existingType?: DocumentTypeConfig | null;
  onClose: () => void;
  onSuccess: (type: DocumentTypeConfig) => void;
}

export const DocumentTypeConfigModal: React.FC<DocumentTypeConfigModalProps> = ({
  existingType,
  onClose,
  onSuccess
}) => {
  const [name, setName] = useState(existingType?.name || '');
  const [code, setCode] = useState(existingType?.code || '');
  const [category, setCategory] = useState<DocumentCategory | string>(existingType?.category || 'IDENTIFICATION');
  const [applicableEntityType, setApplicableEntityType] = useState<DocumentEntityType | 'ALL'>(
    existingType?.applicableEntityType || 'ALL'
  );
  const [description, setDescription] = useState(existingType?.description || '');
  const [isRequired, setIsRequired] = useState(Boolean(existingType?.isRequired));
  const [hasExpiry, setHasExpiry] = useState(Boolean(existingType?.hasExpiry));
  const [defaultExpiryMonths, setDefaultExpiryMonths] = useState<number | ''>(
    existingType?.defaultExpiryMonths || 12
  );
  const [allowedExtensions, setAllowedExtensions] = useState<string>(
    existingType?.allowedExtensions?.join(', ') || 'pdf, jpg, jpeg, png, doc, docx'
  );
  const [maxSizeMb, setMaxSizeMb] = useState<number>(
    existingType?.maxSizeBytes ? Math.round(existingType.maxSizeBytes / (1024 * 1024)) : 15
  );

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!name.trim()) {
      setError('Document type name is required.');
      return;
    }

    const exts = allowedExtensions
      .split(',')
      .map((s) => s.trim().replace(/^\./, '').toLowerCase())
      .filter(Boolean);

    if (exts.length === 0) {
      setError('At least one allowed file extension must be specified.');
      return;
    }

    setIsSubmitting(true);
    try {
      const token = localStorage.getItem('sygmate_auth_token') || localStorage.getItem('token');
      const payload: CreateDocumentTypePayload = {
        name: name.trim(),
        code: code.trim() || undefined,
        category,
        applicableEntityType,
        description: description.trim(),
        isRequired,
        hasExpiry,
        defaultExpiryMonths: hasExpiry && defaultExpiryMonths ? Number(defaultExpiryMonths) : undefined,
        allowedExtensions: exts,
        maxSizeBytes: maxSizeMb * 1024 * 1024
      };

      const url = existingType ? `/api/documents/types/${existingType.id}` : '/api/documents/types';
      const method = existingType ? 'PUT' : 'POST';

      const res = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {})
        },
        body: JSON.stringify(payload)
      });

      const json = await res.json();
      if (!res.ok) {
        throw new Error(json.error || 'Failed to save document type configuration.');
      }

      onSuccess(json.data);
      onClose();
    } catch (err: any) {
      setError(err.message || 'An error occurred.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="relative w-full max-w-xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-slate-800 bg-slate-900/60">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400">
              <SlidersHorizontal className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">
                {existingType ? 'Edit Document Type' : 'Configure New Document Type'}
              </h3>
              <p className="text-xs text-slate-400">
                Define verification guidelines, applicable entities, and upload rules
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {error && (
          <div className="m-6 p-4 rounded-xl bg-red-500/10 border border-red-500/20 flex items-start gap-3 text-red-300 text-sm">
            <AlertTriangle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
            <div>{error}</div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
          {/* Name & Code */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-medium text-slate-300 block mb-1">
                Document Type Name <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Immunization Record"
                className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                required
              />
            </div>
            <div>
              <label className="text-xs font-medium text-slate-300 block mb-1">
                Unique Code (Optional)
              </label>
              <input
                type="text"
                value={code}
                onChange={(e) => setCode(e.target.value.toUpperCase())}
                placeholder="e.g. DOC_IMMUNIZATION"
                className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono"
              />
            </div>
          </div>

          {/* Category & Applicable Entity */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-medium text-slate-300 block mb-1">
                Document Category <span className="text-rose-400">*</span>
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                required
              >
                <option value="IDENTIFICATION">IDENTIFICATION</option>
                <option value="ACADEMIC">ACADEMIC</option>
                <option value="EMPLOYMENT">EMPLOYMENT</option>
                <option value="LEGAL">LEGAL</option>
                <option value="MEDICAL">MEDICAL</option>
                <option value="FINANCIAL">FINANCIAL</option>
                <option value="INSTITUTIONAL">INSTITUTIONAL</option>
                <option value="OTHER">OTHER</option>
              </select>
            </div>
            <div>
              <label className="text-xs font-medium text-slate-300 block mb-1">
                Applicable Entity Scope <span className="text-rose-400">*</span>
              </label>
              <select
                value={applicableEntityType}
                onChange={(e) => setApplicableEntityType(e.target.value as any)}
                className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                required
              >
                <option value="ALL">All Entities</option>
                <option value="STUDENT">Students Only</option>
                <option value="TEACHER">Teachers Only</option>
                <option value="STAFF">Staff / Non-Teaching</option>
                <option value="GUARDIAN">Guardians / Parents</option>
                <option value="SCHOOL">School Institutional</option>
                <option value="DEPARTMENT">Departments</option>
              </select>
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="text-xs font-medium text-slate-300 block mb-1">
              Description & Verification Guidelines
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Explain the required documents, stamps, or regulatory context..."
              rows={2}
              className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* File Rules */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-medium text-slate-300 block mb-1">
                Allowed File Formats (comma separated)
              </label>
              <input
                type="text"
                value={allowedExtensions}
                onChange={(e) => setAllowedExtensions(e.target.value)}
                placeholder="pdf, jpg, jpeg, png"
                className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono"
              />
            </div>
            <div>
              <label className="text-xs font-medium text-slate-300 block mb-1">
                Max Allowed File Size (MB)
              </label>
              <input
                type="number"
                min="1"
                max="50"
                value={maxSizeMb}
                onChange={(e) => setMaxSizeMb(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

          {/* Checkbox Controls */}
          <div className="space-y-3 pt-2">
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="isRequiredCheck"
                checked={isRequired}
                onChange={(e) => setIsRequired(e.target.checked)}
                className="w-4 h-4 rounded text-indigo-600 bg-slate-800 border-slate-700 focus:ring-indigo-500"
              />
              <label htmlFor="isRequiredCheck" className="text-xs text-slate-300 cursor-pointer">
                <strong>Mandatory Document:</strong> Required for enrollment/employment completion
              </label>
            </div>

            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="hasExpiryCheck"
                  checked={hasExpiry}
                  onChange={(e) => setHasExpiry(e.target.checked)}
                  className="w-4 h-4 rounded text-indigo-600 bg-slate-800 border-slate-700 focus:ring-indigo-500"
                />
                <label htmlFor="hasExpiryCheck" className="text-xs text-slate-300 cursor-pointer">
                  <strong>Track Expiry:</strong> Alert when credential expires or reaches 30-day renewal threshold
                </label>
              </div>

              {hasExpiry && (
                <div className="ml-6 flex items-center gap-3">
                  <span className="text-xs text-slate-400">Default validity period:</span>
                  <input
                    type="number"
                    min="1"
                    max="120"
                    value={defaultExpiryMonths}
                    onChange={(e) => setDefaultExpiryMonths(Number(e.target.value))}
                    className="w-24 px-2 py-1 rounded-lg bg-slate-800 border border-slate-700 text-white text-xs"
                  />
                  <span className="text-xs text-slate-400">months</span>
                </div>
              )}
            </div>
          </div>

          {/* Footer Actions */}
          <div className="flex justify-end gap-3 pt-4 border-t border-slate-800">
            <Button size="md" variant="outline" type="button" onClick={onClose} disabled={isSubmitting}>
              Cancel
            </Button>
            <Button
              size="md"
              variant="default"
              type="submit"
              disabled={isSubmitting || !name.trim()}
              className="bg-indigo-600 hover:bg-indigo-500 text-white shadow"
            >
              {isSubmitting ? 'Saving...' : existingType ? 'Update Type' : 'Create Document Type'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};
