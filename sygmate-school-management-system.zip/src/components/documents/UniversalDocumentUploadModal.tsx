/**
 * Part 15A — Universal Document Upload Modal
 * Supports Student, Staff, Teacher, Guardian, and Institutional School entities
 * Sygmate School Management System
 */

import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  X,
  Upload,
  FileText,
  AlertTriangle,
  CheckCircle2,
  Lock,
  Calendar,
  Building2,
  User,
  GraduationCap,
  Users,
  Search,
  Tag
} from 'lucide-react';
import {
  DocumentTypeConfig,
  DocumentEntityType,
  CreateDocumentPayload
} from '../../types';
import { Button } from '../ui/Button';

interface UniversalDocumentUploadModalProps {
  documentTypes: DocumentTypeConfig[];
  initialEntityType?: DocumentEntityType;
  initialEntityId?: string;
  initialEntityName?: string;
  onClose: () => void;
  onSuccess: (newDoc: any) => void;
}

export const UniversalDocumentUploadModal: React.FC<UniversalDocumentUploadModalProps> = ({
  documentTypes,
  initialEntityType = 'STUDENT',
  initialEntityId = '',
  initialEntityName = '',
  onClose,
  onSuccess
}) => {
  // Form State
  const [entityType, setEntityType] = useState<DocumentEntityType>(initialEntityType);
  const [entityId, setEntityId] = useState<string>(initialEntityId);
  const [entityName, setEntityName] = useState<string>(initialEntityName);
  const [documentTypeId, setDocumentTypeId] = useState<string>('');
  const [documentTitle, setDocumentTitle] = useState<string>('');
  const [description, setDescription] = useState<string>('');
  const [referenceNumber, setReferenceNumber] = useState<string>('');
  const [issueDate, setIssueDate] = useState<string>('');
  const [expiryDate, setExpiryDate] = useState<string>('');
  const [notes, setNotes] = useState<string>('');
  const [tagInput, setTagInput] = useState<string>('');
  const [tags, setTags] = useState<string[]>([]);
  const [isConfidential, setIsConfidential] = useState<boolean>(false);

  // File Upload State
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [fileDataUrl, setFileDataUrl] = useState<string>('');
  const [fileError, setFileError] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Searchable entities cache
  const [availableEntities, setAvailableEntities] = useState<Array<{ id: string; name: string; code?: string }>>([]);
  const [entitySearch, setEntitySearch] = useState<string>('');
  const [loadingEntities, setLoadingEntities] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [generalError, setGeneralError] = useState<string | null>(null);

  // Filter types applicable to currently selected entity
  const filteredDocTypes = useMemo(() => {
    return documentTypes.filter(
      (dt) => dt.applicableEntityType === entityType || dt.applicableEntityType === 'ALL'
    );
  }, [documentTypes, entityType]);

  // Selected doc type metadata
  const selectedDocType = useMemo(() => {
    return documentTypes.find((dt) => dt.id === documentTypeId);
  }, [documentTypes, documentTypeId]);

  // Auto-set title and expiry defaults when doc type changes
  useEffect(() => {
    if (selectedDocType) {
      if (!documentTitle || filteredDocTypes.some(t => t.name === documentTitle)) {
        setDocumentTitle(selectedDocType.name);
      }
      if (selectedDocType.hasExpiry && selectedDocType.defaultExpiryMonths && !expiryDate) {
        const d = new Date();
        d.setMonth(d.getMonth() + selectedDocType.defaultExpiryMonths);
        setExpiryDate(d.toISOString().split('T')[0]);
      }
    }
  }, [selectedDocType]);

  // Load entities based on entityType
  useEffect(() => {
    if (initialEntityId) {
      setEntityId(initialEntityId);
      setEntityName(initialEntityName);
      return;
    }

    const extractEntityArray = (json: any): any[] => {
      if (!json) return [];
      if (Array.isArray(json)) return json;
      if (Array.isArray(json.data)) return json.data;
      if (json.data && Array.isArray(json.data.items)) return json.data.items;
      if (Array.isArray(json.items)) return json.items;
      if (Array.isArray(json.students)) return json.students;
      if (Array.isArray(json.teachers)) return json.teachers;
      if (Array.isArray(json.staffProfiles)) return json.staffProfiles;
      if (Array.isArray(json.guardians)) return json.guardians;
      if (Array.isArray(json.departments)) return json.departments;
      return [];
    };

    const loadEntities = async () => {
      setLoadingEntities(true);
      try {
        const token = localStorage.getItem('sygmate_auth_token') || localStorage.getItem('token');
        const headers: Record<string, string> = {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {})
        };

        if (entityType === 'STUDENT') {
          let res = await fetch('/api/users/students?limit=100', { headers });
          if (!res.ok) {
            res = await fetch('/api/student?limit=100', { headers });
          }
          if (res.ok) {
            const json = await res.json();
            const list = extractEntityArray(json);
            const mapped = list.map((s: any) => ({
              id: s.id,
              name: s.fullName || `${s.firstName || ''} ${s.lastName || ''}`.trim() || 'Student',
              code: s.admissionNumber || s.rollNumber || 'Student'
            }));
            setAvailableEntities(mapped);
            if (mapped.length > 0 && !entityId) {
              setEntityId(mapped[0].id);
              setEntityName(mapped[0].name);
            }
          } else {
            setAvailableEntities([]);
          }
        } else if (entityType === 'TEACHER') {
          let res = await fetch('/api/users/teachers', { headers });
          if (!res.ok) {
            res = await fetch('/api/staff?staffType=TEACHING&limit=100', { headers });
          }
          if (res.ok) {
            const json = await res.json();
            const list = extractEntityArray(json);
            const mapped = list.map((t: any) => ({
              id: t.id,
              name: t.name || t.fullName || `${t.firstName || ''} ${t.lastName || ''}`.trim() || 'Teacher',
              code: t.employeeId || t.staffId || t.designation || 'Teacher'
            }));
            setAvailableEntities(mapped);
            if (mapped.length > 0 && !entityId) {
              setEntityId(mapped[0].id);
              setEntityName(mapped[0].name);
            }
          } else {
            setAvailableEntities([]);
          }
        } else if (entityType === 'STAFF') {
          let res = await fetch('/api/staff?limit=100', { headers });
          if (!res.ok) {
            res = await fetch('/api/users/teachers', { headers });
          }
          if (res.ok) {
            const json = await res.json();
            const list = extractEntityArray(json);
            const mapped = list.map((s: any) => ({
              id: s.id,
              name: s.fullName || s.name || `${s.firstName || ''} ${s.lastName || ''}`.trim() || 'Staff',
              code: s.staffId || s.employeeId || s.designationName || 'Staff'
            }));
            setAvailableEntities(mapped);
            if (mapped.length > 0 && !entityId) {
              setEntityId(mapped[0].id);
              setEntityName(mapped[0].name);
            }
          } else {
            setAvailableEntities([]);
          }
        } else if (entityType === 'GUARDIAN') {
          let res = await fetch('/api/users/guardians', { headers });
          if (!res.ok) {
            res = await fetch('/api/guardian/list', { headers });
          }
          if (res.ok) {
            const json = await res.json();
            const list = extractEntityArray(json);
            const mapped = list.map((g: any) => ({
              id: g.id,
              name: g.fullName || g.name || `${g.firstName || ''} ${g.lastName || ''}`.trim() || 'Guardian',
              code: g.relationship || 'Guardian'
            }));
            setAvailableEntities(mapped);
            if (mapped.length > 0 && !entityId) {
              setEntityId(mapped[0].id);
              setEntityName(mapped[0].name);
            }
          } else {
            setAvailableEntities([]);
          }
        } else if (entityType === 'SCHOOL') {
          setAvailableEntities([{ id: 'school-main', name: 'Sygmate International Academy', code: 'SIA-2026' }]);
          setEntityId('school-main');
          setEntityName('Sygmate International Academy');
        } else if (entityType === 'DEPARTMENT') {
          let res = await fetch('/api/academic/departments', { headers });
          if (!res.ok) {
            res = await fetch('/api/staff/meta/departments', { headers });
          }
          if (res.ok) {
            const json = await res.json();
            const list = extractEntityArray(json);
            const mapped = list.map((d: any) => ({
              id: d.id,
              name: d.name,
              code: d.code || 'DEPT'
            }));
            setAvailableEntities(mapped);
            if (mapped.length > 0 && !entityId) {
              setEntityId(mapped[0].id);
              setEntityName(mapped[0].name);
            }
          } else {
            setAvailableEntities([]);
          }
        }
      } catch (err) {
        console.error('Failed loading entities', err);
        setAvailableEntities([]);
      } finally {
        setLoadingEntities(false);
      }
    };

    loadEntities();
  }, [entityType, initialEntityId]);

  // Set default document type when available
  useEffect(() => {
    if (filteredDocTypes.length > 0 && !documentTypeId) {
      setDocumentTypeId(filteredDocTypes[0].id);
    }
  }, [filteredDocTypes, documentTypeId]);

  // Handle file selection & security validation
  const processFile = (file: File) => {
    setFileError(null);

    const maxBytes = selectedDocType?.maxSizeBytes || 15 * 1024 * 1024;
    const allowedExts = selectedDocType?.allowedExtensions || ['pdf', 'jpg', 'jpeg', 'png', 'webp', 'doc', 'docx'];

    const ext = file.name.split('.').pop()?.toLowerCase() || '';

    if (!allowedExts.includes(ext)) {
      setFileError(`Invalid format .${ext}. Permitted formats: ${allowedExts.join(', ')}`);
      return;
    }

    if (file.size > maxBytes) {
      const maxMb = (maxBytes / (1024 * 1024)).toFixed(1);
      setFileError(`File exceeds maximum size of ${maxMb} MB.`);
      return;
    }

    setSelectedFile(file);

    // Read Data URL for preview and base64 transmission
    const reader = new FileReader();
    reader.onload = (e) => {
      setFileDataUrl((e.target?.result as string) || '');
    };
    reader.readAsDataURL(file);
  };

  const handleFileDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleAddTag = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' || e.key === ',') {
      e.preventDefault();
      const val = tagInput.trim().replace(/^#/, '');
      if (val && !tags.includes(val)) {
        setTags([...tags, val]);
        setTagInput('');
      }
    }
  };

  const handleRemoveTag = (tagToRemove: string) => {
    setTags(tags.filter((t) => t !== tagToRemove));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setGeneralError(null);

    if (!entityId) {
      setGeneralError('Please select the associated entity for this document.');
      return;
    }

    if (!documentTypeId) {
      setGeneralError('Please specify the document category & type.');
      return;
    }

    if (!documentTitle.trim()) {
      setGeneralError('Document title is required.');
      return;
    }

    if (!selectedFile) {
      setGeneralError('Please select or upload a document file.');
      return;
    }

    setIsSubmitting(true);
    try {
      const token = localStorage.getItem('sygmate_auth_token') || localStorage.getItem('token');
      const payload: CreateDocumentPayload = {
        documentTypeId,
        entityType,
        entityId,
        entityName,
        documentTitle: documentTitle.trim(),
        description: description.trim() || undefined,
        referenceNumber: referenceNumber.trim() || undefined,
        issueDate: issueDate || undefined,
        expiryDate: expiryDate || undefined,
        fileName: selectedFile.name,
        fileData: fileDataUrl,
        fileType: selectedFile.type || selectedFile.name.split('.').pop() || 'application/pdf',
        fileSizeBytes: selectedFile.size,
        notes: notes.trim() || undefined,
        tags: tags.length > 0 ? tags : undefined,
        isConfidential
      };

      const res = await fetch('/api/documents', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {})
        },
        body: JSON.stringify(payload)
      });

      const json = await res.json();
      if (!res.ok) {
        throw new Error(json.error || 'Failed to upload document.');
      }

      onSuccess(json.data);
      onClose();
    } catch (err: any) {
      setGeneralError(err.message || 'An unexpected error occurred during document upload.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-slate-800 bg-slate-900/60">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400">
              <Upload className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">Upload & Register Document</h3>
              <p className="text-xs text-slate-400">
                Secure digital document repository with immutable version control
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Error Alert */}
        {generalError && (
          <div className="m-6 p-4 rounded-xl bg-red-500/10 border border-red-500/20 flex items-start gap-3 text-red-300 text-sm">
            <AlertTriangle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
            <div>{generalError}</div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="p-6 space-y-5 max-h-[75vh] overflow-y-auto">
          {/* Entity Scope Selector */}
          <div>
            <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider block mb-2">
              Entity Scope
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {[
                { type: 'STUDENT' as DocumentEntityType, label: 'Student', icon: GraduationCap },
                { type: 'TEACHER' as DocumentEntityType, label: 'Teacher / Staff', icon: User },
                { type: 'GUARDIAN' as DocumentEntityType, label: 'Parent / Guardian', icon: Users },
                { type: 'SCHOOL' as DocumentEntityType, label: 'School Institutional', icon: Building2 }
              ].map((scope) => {
                const Icon = scope.icon;
                const isSelected = entityType === scope.type;
                return (
                  <button
                    key={scope.type}
                    type="button"
                    onClick={() => {
                      setEntityType(scope.type);
                      setEntityId('');
                      setEntityName('');
                      setDocumentTypeId('');
                    }}
                    className={`p-3 rounded-xl border text-xs font-semibold flex flex-col items-center gap-1.5 transition-all ${
                      isSelected
                        ? 'bg-indigo-600/20 border-indigo-500 text-white shadow-sm'
                        : 'bg-slate-800/40 border-slate-700/60 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                    }`}
                  >
                    <Icon className={`w-4 h-4 ${isSelected ? 'text-indigo-400' : 'text-slate-500'}`} />
                    <span>{scope.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Entity Selector (when not school) */}
          {entityType !== 'SCHOOL' && (
            <div>
              <label className="text-xs font-medium text-slate-300 block mb-1">
                Select {entityType === 'STUDENT' ? 'Student' : entityType === 'GUARDIAN' ? 'Guardian' : 'Staff / Faculty Member'}
              </label>
              <select
                value={entityId}
                onChange={(e) => {
                  setEntityId(e.target.value);
                  const selected = availableEntities.find((ent) => ent.id === e.target.value);
                  if (selected) setEntityName(selected.name);
                }}
                disabled={Boolean(initialEntityId) || loadingEntities}
                className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                {availableEntities.map((ent) => (
                  <option key={ent.id} value={ent.id}>
                    {ent.name} {ent.code ? `(${ent.code})` : ''}
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Document Type Selector */}
          <div>
            <label className="text-xs font-medium text-slate-300 block mb-1">
              Document Category & Type <span className="text-rose-400">*</span>
            </label>
            <select
              value={documentTypeId}
              onChange={(e) => setDocumentTypeId(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              required
            >
              {filteredDocTypes.map((dt) => (
                <option key={dt.id} value={dt.id}>
                  [{dt.category}] {dt.name} {dt.isRequired ? '• (Mandatory)' : ''}
                </option>
              ))}
            </select>
            {selectedDocType && (
              <p className="text-xs text-slate-400 mt-1 italic">
                {selectedDocType.description}
              </p>
            )}
          </div>

          {/* Document Title & Reference Number */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-medium text-slate-300 block mb-1">
                Document Title <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                value={documentTitle}
                onChange={(e) => setDocumentTitle(e.target.value)}
                placeholder="e.g. Liam Johnson Birth Certificate"
                className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                required
              />
            </div>
            <div>
              <label className="text-xs font-medium text-slate-300 block mb-1">
                Reference / Certificate # (Optional)
              </label>
              <input
                type="text"
                value={referenceNumber}
                onChange={(e) => setReferenceNumber(e.target.value)}
                placeholder="e.g. BC-2010-994821"
                className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono"
              />
            </div>
          </div>

          {/* Issue Date & Expiry Date */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-medium text-slate-300 block mb-1">
                Issue Date (Optional)
              </label>
              <input
                type="date"
                value={issueDate}
                onChange={(e) => setIssueDate(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="text-xs font-medium text-slate-300 block mb-1 flex items-center justify-between">
                <span>Expiry Date</span>
                {selectedDocType?.hasExpiry && (
                  <span className="text-[10px] text-amber-400 font-medium">Expiry Tracked</span>
                )}
              </label>
              <input
                type="date"
                value={expiryDate}
                onChange={(e) => setExpiryDate(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

          {/* Secure File Dropzone */}
          <div>
            <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider block mb-1">
              File Attachment <span className="text-rose-400">*</span>
            </label>
            <div
              onDragOver={(e) => {
                e.preventDefault();
                setIsDragging(true);
              }}
              onDragLeave={() => setIsDragging(false)}
              onDrop={handleFileDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`p-6 rounded-2xl border-2 border-dashed cursor-pointer text-center transition-all ${
                isDragging
                  ? 'border-indigo-500 bg-indigo-500/10'
                  : selectedFile
                  ? 'border-emerald-500/50 bg-emerald-500/5'
                  : 'border-slate-700 hover:border-indigo-500/60 bg-slate-800/40 hover:bg-slate-800/70'
              }`}
            >
              <input
                ref={fileInputRef}
                type="file"
                className="hidden"
                accept={selectedDocType?.allowedExtensions?.map((e) => `.${e}`).join(',') || '.pdf,.jpg,.jpeg,.png,.doc,.docx'}
                onChange={(e) => {
                  if (e.target.files && e.target.files[0]) {
                    processFile(e.target.files[0]);
                  }
                }}
              />

              {selectedFile ? (
                <div className="flex items-center justify-center gap-3">
                  <div className="p-2.5 rounded-xl bg-emerald-500/10 text-emerald-400">
                    <CheckCircle2 className="w-6 h-6" />
                  </div>
                  <div className="text-left">
                    <span className="text-sm font-bold text-white block">{selectedFile.name}</span>
                    <span className="text-xs text-slate-400">
                      {(selectedFile.size / (1024 * 1024)).toFixed(2)} MB • Ready for Version 1 staging
                    </span>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedFile(null);
                      setFileDataUrl('');
                    }}
                    className="ml-auto text-xs"
                  >
                    Change File
                  </Button>
                </div>
              ) : (
                <div className="space-y-2">
                  <Upload className="w-8 h-8 text-indigo-400 mx-auto" />
                  <p className="text-sm font-semibold text-white">
                    Click to select file or drag & drop here
                  </p>
                  <p className="text-xs text-slate-400">
                    Allowed formats: {selectedDocType?.allowedExtensions?.join(', ') || 'PDF, JPG, PNG, DOCX'} • Max size: {((selectedDocType?.maxSizeBytes || 15 * 1024 * 1024) / (1024 * 1024)).toFixed(0)}MB
                  </p>
                </div>
              )}
            </div>

            {fileError && (
              <p className="text-xs text-rose-400 mt-1 flex items-center gap-1">
                <AlertTriangle className="w-3.5 h-3.5" />
                {fileError}
              </p>
            )}
          </div>

          {/* Tags & Confidentiality */}
          <div className="space-y-3">
            <div>
              <label className="text-xs font-medium text-slate-300 block mb-1">
                Tags (Press Enter to add)
              </label>
              <div className="flex items-center gap-2 flex-wrap p-2 rounded-xl bg-slate-800 border border-slate-700 min-h-[42px]">
                {tags.map((t) => (
                  <span
                    key={t}
                    className="px-2 py-0.5 rounded text-xs bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 flex items-center gap-1"
                  >
                    #{t}
                    <button
                      type="button"
                      onClick={() => handleRemoveTag(t)}
                      className="hover:text-white"
                    >
                      &times;
                    </button>
                  </span>
                ))}
                <input
                  type="text"
                  value={tagInput}
                  onChange={(e) => setTagInput(e.target.value)}
                  onKeyDown={handleAddTag}
                  placeholder={tags.length === 0 ? 'Type tag and press Enter...' : ''}
                  className="bg-transparent border-none text-xs text-white focus:outline-none flex-1 min-w-[120px]"
                />
              </div>
            </div>

            <div className="flex items-center gap-2 pt-1">
              <input
                type="checkbox"
                id="confidentialCheck"
                checked={isConfidential}
                onChange={(e) => setIsConfidential(e.target.checked)}
                className="w-4 h-4 rounded text-indigo-600 bg-slate-800 border-slate-700 focus:ring-indigo-500"
              />
              <label htmlFor="confidentialCheck" className="text-xs text-slate-300 flex items-center gap-1.5 cursor-pointer">
                <Lock className="w-3.5 h-3.5 text-rose-400" />
                Mark as Confidential (Restricts inspection exclusively to administrators and direct owner)
              </label>
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="text-xs font-medium text-slate-300 block mb-1">
              Internal Institutional Notes (Optional)
            </label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Add any internal archiving notes or verification guidelines..."
              rows={2}
              className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* Modal Actions */}
          <div className="flex justify-end gap-3 pt-4 border-t border-slate-800">
            <Button size="md" variant="outline" type="button" onClick={onClose} disabled={isSubmitting}>
              Cancel
            </Button>
            <Button
              size="md"
              variant="default"
              type="submit"
              disabled={isSubmitting || !selectedFile || !documentTitle.trim()}
              className="bg-indigo-600 hover:bg-indigo-500 text-white flex items-center gap-2 shadow-lg"
            >
              <Upload className="w-4 h-4" />
              {isSubmitting ? 'Uploading & Registering...' : 'Upload & Register Document'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};
