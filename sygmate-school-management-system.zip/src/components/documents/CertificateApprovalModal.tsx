/**
 * Part 15D — Certificate Leadership Approval Modal
 * Sygmate School Management System
 */

import React, { useState } from 'react';
import {
  CheckCircle2,
  XCircle,
  Award,
  Calendar,
  User,
  ShieldCheck,
  FileText,
  AlertCircle,
  Clock,
  Sparkles
} from 'lucide-react';
import { IssuedCertificate } from '../../types';
import { api } from '../../services/api';
import { Button } from '../ui/Button';

interface CertificateApprovalModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (updated: IssuedCertificate) => void;
  certificate: IssuedCertificate | null;
}

export const CertificateApprovalModal: React.FC<CertificateApprovalModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  certificate
}) => {
  const [decision, setDecision] = useState<'APPROVE' | 'REJECT'>('APPROVE');
  const [notes, setNotes] = useState('');
  const [rejectionReason, setRejectionReason] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  if (!isOpen || !certificate) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (decision === 'REJECT' && !rejectionReason.trim()) {
      setErrorMessage('Please provide a mandatory reason for rejecting this certificate.');
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await api.certificates.approve(certificate.id, {
        decision,
        notes: notes.trim() || undefined,
        rejectionReason: decision === 'REJECT' ? rejectionReason.trim() : undefined
      });
      onSuccess(res);
      onClose();
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to complete approval decision.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden my-6">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 bg-slate-950/80 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-emerald-500/10 text-emerald-400 rounded-xl border border-emerald-500/20">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Leadership Approval Review</h3>
              <p className="text-xs text-slate-400">
                Final authorization required before locking official certificate for student distribution.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg text-lg leading-none"
          >
            &times;
          </button>
        </div>

        {/* Certificate Snapshot & Verification Trail */}
        <div className="p-6 space-y-5">
          {/* Verification Status Card */}
          <div className="bg-blue-500/10 border border-blue-500/20 rounded-xl p-3.5 flex items-start gap-3">
            <ShieldCheck className="w-5 h-5 text-blue-400 shrink-0 mt-0.5" />
            <div className="text-xs space-y-1">
              <div className="font-bold text-blue-300">
                Verified by {certificate.verifiedByName || 'Authorized Reviewer'}
              </div>
              <div className="text-slate-300">
                {certificate.verificationNotes ? (
                  <span>"{certificate.verificationNotes}"</span>
                ) : (
                  <span>Prerequisite review and record reconciliation cleared successfully.</span>
                )}
              </div>
              {certificate.verifiedAt && (
                <div className="text-[11px] text-slate-400">
                  Verification Timestamp: {new Date(certificate.verifiedAt).toLocaleString()}
                </div>
              )}
            </div>
          </div>

          {/* Key Details */}
          <div className="bg-slate-950/60 rounded-xl p-4 border border-slate-800/80 grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <span className="text-slate-400 font-semibold uppercase tracking-wider block text-[10px]">
                Student Recipient
              </span>
              <span className="text-sm font-bold text-white block mt-0.5">
                {certificate.studentName}
              </span>
              <span className="text-slate-400 text-[11px]">
                {certificate.admissionNumber} · {certificate.className || 'Grade'} ({certificate.sectionName || 'Sec'})
              </span>
            </div>

            <div>
              <span className="text-slate-400 font-semibold uppercase tracking-wider block text-[10px]">
                Official Certificate Serial
              </span>
              <span className="text-sm font-mono font-bold text-indigo-400 block mt-0.5">
                {certificate.certificateNumber}
              </span>
              <span className="text-slate-400 text-[11px]">
                {certificate.certificateTypeName}
              </span>
            </div>

            <div className="sm:col-span-2 bg-slate-900/80 rounded-lg p-3 border border-slate-800">
              <span className="text-slate-400 font-semibold uppercase tracking-wider block text-[10px] mb-1">
                Rendered Certificate Citation
              </span>
              <p className="text-xs text-slate-200 italic leading-relaxed">
                "{certificate.renderedBody}"
              </p>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4 pt-2 border-t border-slate-800">
            {/* Decision Selector */}
            <div>
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
                Approval Decision <span className="text-rose-400">*</span>
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setDecision('APPROVE')}
                  className={`p-3 rounded-xl border flex items-center gap-2.5 font-bold text-xs transition-all ${
                    decision === 'APPROVE'
                      ? 'bg-emerald-600/15 border-emerald-500 text-emerald-300 shadow-sm'
                      : 'bg-slate-950/40 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>Approve for Issuance</span>
                </button>

                <button
                  type="button"
                  onClick={() => setDecision('REJECT')}
                  className={`p-3 rounded-xl border flex items-center gap-2.5 font-bold text-xs transition-all ${
                    decision === 'REJECT'
                      ? 'bg-rose-600/15 border-rose-500 text-rose-300 shadow-sm'
                      : 'bg-slate-950/40 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <XCircle className="w-4 h-4 text-rose-400" />
                  <span>Reject Approval</span>
                </button>
              </div>
            </div>

            {/* Rejection Reason (Mandatory if Reject) */}
            {decision === 'REJECT' && (
              <div className="space-y-1.5 animate-in fade-in duration-200">
                <label className="block text-xs font-bold text-rose-400 uppercase tracking-wider">
                  Mandatory Rejection Reason <span className="text-rose-400">*</span>
                </label>
                <textarea
                  value={rejectionReason}
                  onChange={(e) => setRejectionReason(e.target.value)}
                  placeholder="Explain why approval was denied..."
                  rows={3}
                  className="w-full bg-slate-950 border border-rose-800/80 rounded-xl p-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-rose-500"
                  required
                />
              </div>
            )}

            {/* Approval Notes */}
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider">
                Leadership Approval Citation / Notes
              </label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Optional approval notes for institutional registry..."
                rows={2}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
              />
            </div>

            {errorMessage && (
              <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-xs text-rose-400 font-medium">
                {errorMessage}
              </div>
            )}

            {/* Modal Actions */}
            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
              <Button
                type="button"
                variant="outline"
                size="md"
                onClick={onClose}
                disabled={isSubmitting}
                className="border-slate-700 text-slate-300 hover:bg-slate-800"
              >
                Cancel
              </Button>

              <Button
                type="submit"
                size="md"
                disabled={isSubmitting}
                className={
                  decision === 'APPROVE'
                    ? 'bg-emerald-600 hover:bg-emerald-500 text-white font-bold'
                    : 'bg-rose-600 hover:bg-rose-500 text-white font-bold'
                }
              >
                {isSubmitting
                  ? 'Submitting...'
                  : decision === 'APPROVE'
                  ? 'Authorize & Approve'
                  : 'Reject Approval'}
              </Button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
