/**
 * Part 15C — Certificate Type Configuration Modal
 * Sygmate School Management System
 */

import React, { useState, useEffect } from 'react';
import { X, Award, Settings, CheckCircle2, AlertCircle } from 'lucide-react';
import {
  CertificateTypeConfig,
  CertificateTemplate,
  CreateCertificateTypePayload,
  UpdateCertificateTypePayload
} from '../../types';
import { api } from '../../services/api';
import { Button } from '../ui/Button';

interface CertificateTypeModalProps {
  isOpen: boolean;
  onClose: () => void;
  certificateType?: CertificateTypeConfig | null;
  templates: CertificateTemplate[];
  onSuccess: (saved: CertificateTypeConfig) => void;
}

export const CertificateTypeModal: React.FC<CertificateTypeModalProps> = ({
  isOpen,
  onClose,
  certificateType,
  templates,
  onSuccess
}) => {
  const isEditing = !!certificateType;

  const [name, setName] = useState('');
  const [code, setCode] = useState('');
  const [description, setDescription] = useState('');
  const [numberingPrefix, setNumberingPrefix] = useState('CERT');
  const [numberingFormat, setNumberingFormat] = useState('{PREFIX}/{YYYY}/{SEQ:6}');
  const [defaultTemplateId, setDefaultTemplateId] = useState('');
  const [requiredFields, setRequiredFields] = useState<string[]>([
    'student_name',
    'admission_number',
    'class_name'
  ]);
  const [isActive, setIsActive] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  useEffect(() => {
    if (certificateType) {
      setName(certificateType.name);
      setCode(certificateType.code);
      setDescription(certificateType.description || '');
      setNumberingPrefix(certificateType.numberingPrefix || 'CERT');
      setNumberingFormat(certificateType.numberingFormat || '{PREFIX}/{YYYY}/{SEQ:6}');
      setDefaultTemplateId(certificateType.defaultTemplateId || '');
      setRequiredFields(certificateType.requiredFields || ['student_name', 'admission_number', 'class_name']);
      setIsActive(certificateType.isActive !== false);
    } else {
      setName('');
      setCode('');
      setDescription('');
      setNumberingPrefix('CERT');
      setNumberingFormat('{PREFIX}/{YYYY}/{SEQ:6}');
      setDefaultTemplateId(templates[0]?.id || '');
      setRequiredFields(['student_name', 'admission_number', 'class_name']);
      setIsActive(true);
    }
    setErrorMessage('');
  }, [certificateType, templates, isOpen]);

  const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setName(val);
    if (!isEditing && !code) {
      const generatedCode = val.toUpperCase().replace(/[^A-Z0-9]/g, '_');
      setCode(generatedCode);
      const prefix = val.replace(/[^a-zA-Z]/g, '').slice(0, 4).toUpperCase();
      if (prefix) setNumberingPrefix(prefix);
    }
  };

  const toggleRequiredField = (field: string) => {
    if (requiredFields.includes(field)) {
      setRequiredFields(requiredFields.filter(f => f !== field));
    } else {
      setRequiredFields([...requiredFields, field]);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setErrorMessage('Certificate type name is required.');
      return;
    }

    setIsSubmitting(true);
    setErrorMessage('');
    try {
      if (isEditing && certificateType) {
        const payload: UpdateCertificateTypePayload = {
          name: name.trim(),
          description: description.trim(),
          numberingPrefix: numberingPrefix.trim().toUpperCase(),
          numberingFormat: numberingFormat.trim(),
          defaultTemplateId: defaultTemplateId || undefined,
          requiredFields,
          isActive
        };
        const updated = await api.certificates.updateType(certificateType.id, payload);
        onSuccess((updated as any)?.data || updated);
      } else {
        const payload: CreateCertificateTypePayload = {
          name: name.trim(),
          code: (code || name.toUpperCase().replace(/[^A-Z0-9]/g, '_')).trim(),
          description: description.trim(),
          applicableEntityType: 'STUDENT',
          numberingPrefix: numberingPrefix.trim().toUpperCase(),
          numberingFormat: numberingFormat.trim(),
          defaultTemplateId: defaultTemplateId || undefined,
          requiredFields
        };
        const created = await api.certificates.createType(payload);
        onSuccess((created as any)?.data || created);
      }
      onClose();
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to save certificate type.');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden my-4">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/80">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-500/10 rounded-xl border border-indigo-500/20 text-indigo-400">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">
                {isEditing ? 'Configure Certificate Type' : 'Create Certificate Type'}
              </h3>
              <p className="text-xs text-slate-400">
                Define classification, serial prefix, and default layout template.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {errorMessage && (
            <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Type Name & Code */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
                Type Name <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Bonafide Certificate"
                value={name}
                onChange={handleNameChange}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
                Unique Code <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                required
                disabled={isEditing}
                placeholder="e.g. BONAFIDE_CERT"
                value={code}
                onChange={e => setCode(e.target.value.toUpperCase())}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-xs text-white font-mono placeholder-slate-500 focus:outline-none focus:border-indigo-500 disabled:opacity-60"
              />
            </div>
          </div>

          {/* Serial Numbering Prefix & Format */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
                Numbering Prefix <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                required
                placeholder="e.g. BONA, TC, CHAR"
                value={numberingPrefix}
                onChange={e => setNumberingPrefix(e.target.value.toUpperCase())}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-xs text-white font-mono placeholder-slate-500 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
                Pattern Format
              </label>
              <input
                type="text"
                value={numberingFormat}
                onChange={e => setNumberingFormat(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-xs text-white font-mono focus:outline-none focus:border-indigo-500"
              />
            </div>
          </div>

          {/* Default Template */}
          <div>
            <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
              Default Certificate Template
            </label>
            <select
              value={defaultTemplateId}
              onChange={e => setDefaultTemplateId(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-indigo-500"
            >
              <option value="">None / Select dynamically during generation</option>
              {templates.map(t => (
                <option key={t.id} value={t.id}>
                  {t.name} ({t.orientation} - {t.layoutDesign})
                </option>
              ))}
            </select>
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
              Institutional Description
            </label>
            <textarea
              rows={2}
              placeholder="e.g. Formal clearance document certifying completion of academic tenure..."
              value={description}
              onChange={e => setDescription(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
            />
          </div>

          {/* Required Fields Selector */}
          <div>
            <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
              Mandatory Student Fields for Issuance
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
              {[
                { id: 'student_name', label: 'Student Name' },
                { id: 'admission_number', label: 'Admission Number' },
                { id: 'class_name', label: 'Class / Grade' },
                { id: 'academic_session', label: 'Academic Session' },
                { id: 'roll_number', label: 'Roll Number' },
                { id: 'guardian_name', label: 'Guardian / Father' }
              ].map(f => (
                <label
                  key={f.id}
                  onClick={() => toggleRequiredField(f.id)}
                  className={`p-2 rounded-lg border cursor-pointer flex items-center gap-2 select-none transition-all ${
                    requiredFields.includes(f.id)
                      ? 'bg-indigo-600/15 border-indigo-500 text-white font-semibold'
                      : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={requiredFields.includes(f.id)}
                    onChange={() => {}}
                    className="rounded text-indigo-600 focus:ring-0"
                  />
                  <span>{f.label}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Active Switch */}
          {isEditing && (
            <div className="flex items-center gap-2 pt-1">
              <input
                type="checkbox"
                id="is-active-type"
                checked={isActive}
                onChange={e => setIsActive(e.target.checked)}
                className="rounded text-indigo-600 focus:ring-0"
              />
              <label htmlFor="is-active-type" className="text-xs text-slate-300 cursor-pointer">
                Active for new certificate generation
              </label>
            </div>
          )}

          {/* Form Actions */}
          <div className="pt-2 flex items-center justify-end gap-2">
            <Button variant="ghost" size="sm" type="button" onClick={onClose}>
              Cancel
            </Button>
            <Button
              variant="default"
              size="sm"
              type="submit"
              disabled={isSubmitting || !name.trim()}
              className="bg-indigo-600 hover:bg-indigo-500 text-white font-semibold"
            >
              {isSubmitting ? 'Saving...' : isEditing ? 'Update Type' : 'Create Type'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};
