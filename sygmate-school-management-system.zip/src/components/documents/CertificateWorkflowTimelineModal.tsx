/**
 * Part 15D — Certificate Workflow History & Verification Details Modal
 * Sygmate School Management System
 */

import React, { useEffect, useState } from 'react';
import {
  History,
  ShieldCheck,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Clock,
  User,
  ExternalLink,
  QrCode,
  Copy,
  Check,
  Award,
  Calendar
} from 'lucide-react';
import { IssuedCertificate, CertificateWorkflowEvent } from '../../types';
import { api } from '../../services/api';
import { Button } from '../ui/Button';

interface CertificateWorkflowTimelineModalProps {
  isOpen: boolean;
  onClose: () => void;
  certificate: IssuedCertificate | null;
}

export const CertificateWorkflowTimelineModal: React.FC<CertificateWorkflowTimelineModalProps> = ({
  isOpen,
  onClose,
  certificate
}) => {
  const [history, setHistory] = useState<CertificateWorkflowEvent[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!isOpen || !certificate) return;

    const loadHistory = async () => {
      setIsLoading(true);
      try {
        const events = await api.certificates.getWorkflowHistory(certificate.id);
        const list = Array.isArray(events)
          ? events
          : Array.isArray((events as any)?.data)
          ? (events as any).data
          : [];
        setHistory(list);
      } catch (err) {
        // Fallback to local snapshot workflow history if network error
        setHistory(certificate.workflowHistory || []);
      } finally {
        setIsLoading(false);
      }
    };

    loadHistory();
  }, [isOpen, certificate]);

  if (!isOpen || !certificate) return null;

  const handleCopyRef = () => {
    if (certificate.digitalVerificationReference) {
      navigator.clipboard.writeText(certificate.digitalVerificationReference);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const getEventBadge = (action: string) => {
    switch (action) {
      case 'GENERATED':
        return <span className="text-slate-300 font-semibold">Generated</span>;
      case 'SUBMITTED_FOR_VERIFICATION':
        return <span className="text-blue-400 font-semibold">Submitted for Verification</span>;
      case 'VERIFIED':
        return <span className="text-emerald-400 font-semibold">Verified</span>;
      case 'VERIFICATION_REJECTED':
        return <span className="text-rose-400 font-semibold">Verification Rejected</span>;
      case 'SUBMITTED_FOR_APPROVAL':
        return <span className="text-amber-400 font-semibold">Submitted for Approval</span>;
      case 'APPROVED':
        return <span className="text-emerald-400 font-semibold">Approved by Leadership</span>;
      case 'APPROVAL_REJECTED':
        return <span className="text-rose-400 font-semibold">Approval Rejected</span>;
      case 'ISSUED':
        return <span className="text-indigo-400 font-semibold">Officially Issued</span>;
      case 'REISSUED':
        return <span className="text-purple-400 font-semibold">Reissued (v{certificate.version})</span>;
      case 'REVOKED':
        return <span className="text-rose-500 font-semibold">Revoked</span>;
      case 'CANCELLED':
        return <span className="text-amber-500 font-semibold">Cancelled</span>;
      default:
        return <span className="text-slate-300 font-semibold">{action}</span>;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 w-full max-w-3xl rounded-2xl shadow-2xl overflow-hidden my-6 max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 bg-slate-950/80 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-500/10 text-indigo-400 rounded-xl border border-indigo-500/20">
              <History className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Workflow Timeline & Digital Audit Trail</h3>
              <p className="text-xs text-slate-400">
                End-to-end audit ledger for Certificate #{certificate.certificateNumber}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg text-lg leading-none"
          >
            &times;
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          {/* Certificate Quick Identity Banner */}
          <div className="bg-slate-950/60 rounded-xl p-4 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                {certificate.certificateTypeName}
              </div>
              <div className="text-base font-bold text-white mt-0.5">
                {certificate.studentName}
              </div>
              <div className="text-xs text-slate-400">
                {certificate.admissionNumber} · {certificate.academicSessionName}
              </div>
            </div>

            {/* Digital Verification Reference Token */}
            <div className="bg-slate-900 border border-slate-700/80 rounded-xl p-3 space-y-1">
              <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center justify-between">
                <span>Digital Verification Reference</span>
                <button
                  type="button"
                  onClick={handleCopyRef}
                  className="hover:text-indigo-400 transition-colors flex items-center gap-1 text-[10px]"
                >
                  {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>{copied ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
              <div className="font-mono text-xs font-bold text-indigo-300">
                {certificate.digitalVerificationReference || 'SEC-VER-PENDING'}
              </div>
              <a
                href={`/verify-certificate?ref=${certificate.digitalVerificationReference || certificate.certificateNumber}`}
                target="_blank"
                rel="noreferrer"
                className="text-[11px] text-blue-400 hover:underline flex items-center gap-1 pt-0.5"
              >
                <span>Open Public Verification Page</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>

          {/* Chronological Timeline */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
              Chronological Audit Events ({history.length})
            </h4>

            {isLoading ? (
              <div className="py-8 text-center text-xs text-slate-500">
                Loading workflow audit events...
              </div>
            ) : history.length === 0 ? (
              <div className="py-8 text-center text-xs text-slate-500 bg-slate-950/40 rounded-xl border border-slate-800">
                No external workflow events recorded yet.
              </div>
            ) : (
              <div className="relative pl-6 space-y-6 before:absolute before:left-2.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-800">
                {(Array.isArray(history) ? history : []).map((event, idx) => (
                  <div key={event.id || idx} className="relative group">
                    {/* Timeline Node Icon */}
                    <div className="absolute -left-6 top-1 w-5 h-5 rounded-full bg-slate-900 border-2 border-indigo-500 flex items-center justify-center text-[10px] font-bold text-indigo-400 shadow-sm">
                      {idx + 1}
                    </div>

                    <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-3.5 space-y-1.5">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 text-xs">
                        <div className="flex items-center gap-2">
                          {getEventBadge(event.action)}
                          <span className="text-slate-500">by</span>
                          <span className="text-slate-200 font-medium">
                            {event.actorName} ({event.actorRole})
                          </span>
                        </div>
                        <span className="text-[11px] text-slate-400 font-mono">
                          {new Date(event.timestamp).toLocaleString()}
                        </span>
                      </div>

                      {event.notes && (
                        <p className="text-xs text-slate-300 italic">
                          "{event.notes}"
                        </p>
                      )}

                      {event.reason && (
                        <div className="p-2 rounded bg-rose-500/10 border border-rose-500/20 text-xs text-rose-300">
                          <span className="font-semibold">Reason:</span> {event.reason}
                        </div>
                      )}

                      <div className="text-[10px] text-slate-500 flex items-center gap-2">
                        <span>State Transition:</span>
                        <code className="text-slate-400">{event.previousStatus}</code>
                        <span>&rarr;</span>
                        <code className="text-indigo-400">{event.newStatus}</code>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 border-t border-slate-800 bg-slate-950/80 flex items-center justify-end">
          <Button
            type="button"
            variant="outline"
            size="md"
            onClick={onClose}
            className="border-slate-700 text-slate-300 hover:bg-slate-800"
          >
            Close Timeline
          </Button>
        </div>
      </div>
    </div>
  );
};
