/**
 * Part 15C — Reissue Certificate Modal
 * Controlled reissuance workflow with mandatory reason tracking
 * Sygmate School Management System
 */

import React, { useState } from 'react';
import { X, RefreshCw, AlertCircle, ShieldAlert, Award } from 'lucide-react';
import { IssuedCertificate } from '../../types';
import { api } from '../../services/api';
import { Button } from '../ui/Button';

interface ReissueCertificateModalProps {
  isOpen: boolean;
  onClose: () => void;
  certificate: IssuedCertificate | null;
  onSuccess: (reissued: IssuedCertificate) => void;
}

export const ReissueCertificateModal: React.FC<ReissueCertificateModalProps> = ({
  isOpen,
  onClose,
  certificate,
  onSuccess
}) => {
  const [reason, setReason] = useState<string>('');
  const [remarks, setRemarks] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string>('');

  if (!isOpen || !certificate) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reason.trim()) {
      setErrorMessage('A comprehensive reason for reissuing this certificate is mandatory.');
      return;
    }

    setIsSubmitting(true);
    setErrorMessage('');
    try {
      const res = await api.certificates.reissue(certificate.id, {
        reissueReason: reason.trim(),
        remarks: remarks.trim() || undefined
      });
      onSuccess(res);
      onClose();
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to reissue certificate.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden my-4">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/80">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-purple-500/10 rounded-xl border border-purple-500/20 text-purple-400">
              <RefreshCw className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Reissue Official Certificate</h3>
              <p className="text-xs text-slate-400 font-mono">
                Original Serial: <strong className="text-purple-400">{certificate.certificateNumber}</strong> (v{certificate.version})
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {/* Target Student Info Card */}
          <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center justify-between text-xs">
            <div>
              <span className="text-slate-400 block">Recipient Student:</span>
              <strong className="text-white text-sm">{certificate.studentName}</strong>
              <span className="text-slate-400 font-mono ml-2">({certificate.admissionNumber})</span>
            </div>
            <span className="px-2.5 py-1 rounded bg-slate-800 text-slate-300 font-mono font-bold border border-slate-700">
              New: v{certificate.version + 1}
            </span>
          </div>

          {/* Audit Notice Warning */}
          <div className="p-3 rounded-xl bg-purple-500/10 border border-purple-500/20 text-purple-300 text-xs flex gap-2.5">
            <ShieldAlert className="w-4 h-4 text-purple-400 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-white">Controlled Reissue Policy</p>
              <p className="mt-0.5 text-slate-300 leading-relaxed">
                The original certificate record will be retained for institutional audit. A new unique certificate number will be generated and linked directly to the historical version.
              </p>
            </div>
          </div>

          {errorMessage && (
            <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Reason Input */}
          <div>
            <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
              Reissuance Reason <span className="text-rose-400">*</span>
            </label>
            <textarea
              rows={3}
              required
              placeholder="e.g. Legal correction of student name spelling following certified affidavit submission..."
              value={reason}
              onChange={e => setReason(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
            />
          </div>

          {/* Optional Updated Remarks */}
          <div>
            <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
              Updated Citation / Remarks (Optional)
            </label>
            <input
              type="text"
              placeholder={certificate.remarks || 'Updated special citation notes...'}
              value={remarks}
              onChange={e => setRemarks(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
            />
          </div>

          {/* Form Actions */}
          <div className="pt-2 flex items-center justify-end gap-2">
            <Button variant="ghost" size="sm" type="button" onClick={onClose}>
              Cancel
            </Button>
            <Button
              variant="default"
              size="sm"
              type="submit"
              disabled={isSubmitting || !reason.trim()}
              className="bg-purple-600 hover:bg-purple-500 text-white font-semibold"
            >
              {isSubmitting ? 'Reissuing...' : 'Confirm Reissue'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};
