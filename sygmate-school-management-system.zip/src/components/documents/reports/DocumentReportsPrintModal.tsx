/**
 * Part 15F — Document & Certificate Reports Print View Modal
 * Sygmate School Management System
 * Palette: Navy (#16263B), Blue (#1D64C9), Sky (#79C7FF), Surface (#FFFFFF)
 */

import React, { useState } from 'react';
import { X, Printer, Download, Award, FileText, CheckCircle2, ShieldCheck } from 'lucide-react';
import { Button } from '../../ui/Button.js';
import { downloadTablePdf, triggerSafePrint } from '../../../utils/printPdf.js';

interface DocumentReportsPrintModalProps {
  isOpen: boolean;
  onClose: () => void;
  reportTitle: string;
  reportSubtitle: string;
  generatedDate: string;
  summaryMetrics?: Array<{ label: string; value: string | number }>;
  columns: string[];
  data: Array<Record<string, any>>;
}

export const DocumentReportsPrintModal: React.FC<DocumentReportsPrintModalProps> = ({
  isOpen,
  onClose,
  reportTitle,
  reportSubtitle,
  generatedDate,
  summaryMetrics,
  columns,
  data
}) => {
  const [isExporting, setIsExporting] = useState(false);

  if (!isOpen) return null;

  const handlePrint = async () => {
    try {
      setIsExporting(true);
      const filename = `${reportTitle.toLowerCase().replace(/[^a-z0-9]/g, '_')}_${new Date().toISOString().split('T')[0]}.pdf`;

      await downloadTablePdf({
        title: reportTitle,
        subtitle: reportSubtitle,
        columns,
        data,
        filename
      });

      await triggerSafePrint({
        elementOrId: 'printable-document-report',
        fallbackTitle: reportTitle
      });
    } catch (err) {
      console.error('Print failed:', err);
      try {
        window.print();
      } catch {
        // ignore
      }
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm print:p-0 print:bg-white">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-5xl w-full max-h-[92vh] flex flex-col shadow-2xl overflow-hidden print:border-none print:shadow-none print:max-w-none print:max-h-none print:bg-white print:text-black">
        {/* Modal Header — Screen Only */}
        <div className="p-6 border-b border-slate-800 flex items-center justify-between bg-slate-900/90 print:hidden">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-indigo-500/10 text-indigo-400">
              <Printer className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Print-Friendly Report Preview</h2>
              <p className="text-xs text-slate-400">Formatted for standard A4 / Letter official printing</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button
              onClick={handlePrint}
              disabled={isExporting}
              className="bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white text-xs px-4 py-2 flex items-center gap-1.5 shadow-sm"
            >
              <Printer className="w-4 h-4" />
              {isExporting ? 'Generating PDF...' : 'Print / Save as PDF'}
            </Button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Content Area */}
        <div
          id="printable-document-report"
          className="flex-1 overflow-y-auto p-8 space-y-6 bg-slate-950/40 text-slate-200 print:overflow-visible print:p-6 print:text-black print:bg-white"
        >
          {/* Official Letterhead */}
          <div className="border-b-2 border-indigo-600/30 pb-5 flex items-center justify-between print:border-black">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-[#16263B] flex items-center justify-center text-[#79C7FF] font-bold text-xl border border-indigo-500/20 shadow-md">
                S
              </div>
              <div>
                <h1 className="text-xl font-black text-white print:text-black tracking-tight">
                  SYGMATE INTERNATIONAL ACADEMY
                </h1>
                <p className="text-xs text-slate-400 print:text-gray-600 font-medium">
                  Authoritative Document & Certificate Compliance Registry • Institutional Management
                </p>
              </div>
            </div>
            <div className="text-right text-xs text-slate-400 print:text-gray-600">
              <p className="font-semibold text-slate-300 print:text-black">Official Administrative Extract</p>
              <p>Generated: {generatedDate}</p>
            </div>
          </div>

          {/* Report Title & Scope */}
          <div className="space-y-1">
            <h2 className="text-lg font-extrabold text-white print:text-black">{reportTitle}</h2>
            <p className="text-xs text-slate-400 print:text-gray-600">{reportSubtitle}</p>
          </div>

          {/* Summary KPIs */}
          {summaryMetrics && summaryMetrics.length > 0 && (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 print:gap-2">
              {summaryMetrics.map((metric, idx) => (
                <div
                  key={idx}
                  className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 print:border-gray-300 print:bg-gray-50"
                >
                  <p className="text-[10px] font-semibold text-slate-400 print:text-gray-600 uppercase tracking-wider">
                    {metric.label}
                  </p>
                  <p className="text-xl font-bold text-white print:text-black mt-0.5">{metric.value}</p>
                </div>
              ))}
            </div>
          )}

          {/* Report Table */}
          <div className="border border-slate-800 rounded-2xl overflow-hidden print:border-gray-300">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-900/80 border-b border-slate-800 text-slate-400 print:bg-gray-100 print:text-black print:border-gray-300">
                  {columns.map((col, idx) => (
                    <th key={idx} className="p-3 font-semibold">
                      {col}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 print:divide-gray-200">
                {data.map((row, rowIdx) => (
                  <tr key={rowIdx} className="hover:bg-slate-900/30 print:hover:bg-transparent">
                    {columns.map((col, colIdx) => (
                      <td key={colIdx} className="p-3 text-slate-300 print:text-black">
                        {row[col] !== undefined ? String(row[col]) : '—'}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Official Sign-off Footer */}
          <div className="pt-8 border-t border-slate-800 print:border-gray-300 flex items-center justify-between text-[11px] text-slate-500 print:text-gray-500">
            <div>
              <p>Certified Official System Report</p>
              <p>Registry Reference: REG-{Date.now().toString(36).toUpperCase()}</p>
            </div>
            <div className="text-right">
              <p>Authorizing Registrar Signature: _______________________</p>
              <p className="mt-1">Sygmate School Document & Certificate Authority</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
