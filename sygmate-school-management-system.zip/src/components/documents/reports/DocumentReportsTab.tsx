/**
 * Part 15F — Document & Certificate Reports, Analytics & Compliance Tab
 * Sygmate School Management System
 *
 * Comprehensive cross-module intelligence, lifecycle analytics,
 * entity compliance reporting, expiry horizons, and reconciliation.
 */

import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  BarChart3,
  TrendingUp,
  FileText,
  Award,
  ShieldCheck,
  AlertTriangle,
  Clock,
  CheckCircle2,
  XCircle,
  Calendar,
  Filter,
  Download,
  Printer,
  RefreshCw,
  Search,
  ChevronRight,
  ChevronLeft,
  Scale,
  Users,
  Building2,
  GraduationCap,
  Sparkles,
  PieChart as PieChartIcon,
  Layers,
  ArrowRight,
  ExternalLink,
  ShieldAlert,
  SlidersHorizontal,
  History,
  Info,
  Database
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { Button } from '../../ui/Button.js';
import { LoadingSpinner } from '../../ui/LoadingSpinner.js';
import { api } from '../../../services/api.js';
import {
  DocumentAnalyticsDashboardData,
  DocumentComplianceReportItem,
  DocumentComplianceReportSummary,
  DocumentExpiryReportItem,
  DocumentExpiryReportSummary,
  CertificateAnalyticsDashboardData,
  CertificateLifecycleAnalytics,
  CertificateIssuanceReportItem,
  DocumentCertificateAuditItem,
  DocumentReportDateRangePreset,
  DocumentEntityType,
  DocumentCertificateReconciliationReport
} from '../../../types/index.js';
import { DocumentReportsPrintModal } from './DocumentReportsPrintModal.js';
import { DocumentReconciliationModal } from './DocumentReconciliationModal.js';
import { EntityDocumentChecklistModal } from '../EntityDocumentChecklistModal.js';

interface DocumentReportsTabProps {
  onOpenChecklistModal?: (entityType: DocumentEntityType, entityId: string, entityName?: string) => void;
  onOpenDocumentDetail?: (documentId: string) => void;
}

type ReportSubTab = 'overview' | 'compliance' | 'expiry' | 'certificates' | 'issuance' | 'audit';

const COLORS = ['#6366f1', '#a855f7', '#ec4899', '#3b82f6', '#10b981', '#f59e0b', '#06b6d4'];

export const DocumentReportsTab: React.FC<DocumentReportsTabProps> = ({
  onOpenChecklistModal,
  onOpenDocumentDetail
}) => {
  const [activeSubTab, setActiveSubTab] = useState<ReportSubTab>('overview');
  const [datePreset, setDatePreset] = useState<DocumentReportDateRangePreset>('LAST_30_DAYS');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Modals state
  const [isReconciliationModalOpen, setIsReconciliationModalOpen] = useState(false);
  const [reconciliationReport, setReconciliationReport] = useState<DocumentCertificateReconciliationReport | null>(null);
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);
  const [printModalConfig, setPrintModalConfig] = useState<{
    title: string;
    subtitle: string;
    metrics?: Array<{ label: string; value: string | number }>;
    columns: string[];
    data: Array<Record<string, any>>;
  }>({
    title: '',
    subtitle: '',
    columns: [],
    data: []
  });

  // Drilldown entity checklist
  const [selectedEntityForChecklist, setSelectedEntityForChecklist] = useState<{
    entityType: DocumentEntityType;
    entityId: string;
    entityName?: string;
  } | null>(null);

  // Sub-Tab 1: Overview & Document Analytics
  const [docAnalytics, setDocAnalytics] = useState<DocumentAnalyticsDashboardData | null>(null);

  // Sub-Tab 2: Document Compliance
  const [complianceItems, setComplianceItems] = useState<DocumentComplianceReportItem[]>([]);
  const [complianceSummary, setComplianceSummary] = useState<DocumentComplianceReportSummary | null>(null);
  const [complianceFilterEntity, setComplianceFilterEntity] = useState<DocumentEntityType | 'ALL'>('ALL');
  const [complianceFilterStatus, setComplianceFilterStatus] = useState<string>('ALL');
  const [complianceSearch, setComplianceSearch] = useState('');
  const [compliancePage, setCompliancePage] = useState(1);
  const [complianceTotalPages, setComplianceTotalPages] = useState(1);
  const [complianceTotal, setComplianceTotal] = useState(0);

  // Sub-Tab 3: Expiry & Renewal
  const [expiryItems, setExpiryItems] = useState<DocumentExpiryReportItem[]>([]);
  const [expirySummary, setExpirySummary] = useState<DocumentExpiryReportSummary | null>(null);
  const [expiryFilterEntity, setExpiryFilterEntity] = useState('ALL');
  const [expiryFilterUrgency, setExpiryFilterUrgency] = useState('ALL');
  const [expiryHorizon, setExpiryHorizon] = useState('90');
  const [expirySearch, setExpirySearch] = useState('');
  const [expiryPage, setExpiryPage] = useState(1);
  const [expiryTotalPages, setExpiryTotalPages] = useState(1);
  const [expiryTotal, setExpiryTotal] = useState(0);

  // Sub-Tab 4: Certificate Analytics & Lifecycle
  const [certAnalytics, setCertAnalytics] = useState<CertificateAnalyticsDashboardData | null>(null);
  const [certLifecycle, setCertLifecycle] = useState<CertificateLifecycleAnalytics | null>(null);

  // Sub-Tab 5: Certificate Issuance Logs
  const [issuanceItems, setIssuanceItems] = useState<CertificateIssuanceReportItem[]>([]);
  const [issuanceSearch, setIssuanceSearch] = useState('');
  const [issuanceFilterStatus, setIssuanceFilterStatus] = useState('ALL');
  const [issuancePage, setIssuancePage] = useState(1);
  const [issuanceTotalPages, setIssuanceTotalPages] = useState(1);
  const [issuanceTotal, setIssuanceTotal] = useState(0);

  // Sub-Tab 6: Audit Activity
  const [auditItems, setAuditItems] = useState<DocumentCertificateAuditItem[]>([]);
  const [auditFilterAction, setAuditFilterAction] = useState('ALL');
  const [auditSearch, setAuditSearch] = useState('');
  const [auditPage, setAuditPage] = useState(1);
  const [auditTotalPages, setAuditTotalPages] = useState(1);

  // 1. Fetch Overview Analytics
  const loadOverviewAnalytics = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await api.documentReports.getDocumentAnalytics({ preset: datePreset });
      if (res.success && res.data) {
        setDocAnalytics(res.data);
      } else {
        setError(res.error || 'Failed to load document analytics.');
      }
    } catch (err: any) {
      setError(err.message || 'Error loading analytics.');
    } finally {
      setLoading(false);
    }
  }, [datePreset]);

  // 2. Fetch Compliance Report
  const loadComplianceReport = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await api.documentReports.getDocumentCompliance({
        entityType: complianceFilterEntity !== 'ALL' ? complianceFilterEntity : undefined,
        complianceStatus: complianceFilterStatus !== 'ALL' ? (complianceFilterStatus as any) : undefined,
        search: complianceSearch.trim() || undefined,
        page: compliancePage,
        limit: 15
      });
      if (res.success && res.data) {
        setComplianceItems(res.data);
        if (res.summary) setComplianceSummary(res.summary);
        if (res.pagination) {
          setComplianceTotalPages(res.pagination.totalPages);
          setComplianceTotal(res.pagination.total);
        }
      }
    } catch (err: any) {
      setError(err.message || 'Error loading compliance report.');
    } finally {
      setLoading(false);
    }
  }, [complianceFilterEntity, complianceFilterStatus, complianceSearch, compliancePage]);

  // 3. Fetch Expiry Report
  const loadExpiryReport = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await api.documentReports.getDocumentExpiry({
        entityType: expiryFilterEntity !== 'ALL' ? expiryFilterEntity : undefined,
        urgency: expiryFilterUrgency !== 'ALL' ? expiryFilterUrgency : undefined,
        horizonDays: parseInt(expiryHorizon, 10) || 90,
        search: expirySearch.trim() || undefined,
        page: expiryPage,
        limit: 15
      });
      if (res.success && res.data) {
        setExpiryItems(res.data);
        if (res.summary) setExpirySummary(res.summary);
        if (res.pagination) {
          setExpiryTotalPages(res.pagination.totalPages);
          setExpiryTotal(res.pagination.total);
        }
      }
    } catch (err: any) {
      setError(err.message || 'Error loading expiry report.');
    } finally {
      setLoading(false);
    }
  }, [expiryFilterEntity, expiryFilterUrgency, expiryHorizon, expirySearch, expiryPage]);

  // 4. Fetch Certificate Analytics & Lifecycle
  const loadCertificateAnalytics = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const [resAnalytics, resLifecycle] = await Promise.all([
        api.documentReports.getCertificateAnalytics({ preset: datePreset }),
        api.documentReports.getCertificateLifecycle()
      ]);
      if (resAnalytics.success && resAnalytics.data) {
        setCertAnalytics(resAnalytics.data);
      }
      if (resLifecycle.success && resLifecycle.data) {
        setCertLifecycle(resLifecycle.data);
      }
    } catch (err: any) {
      setError(err.message || 'Error loading certificate analytics.');
    } finally {
      setLoading(false);
    }
  }, [datePreset]);

  // 5. Fetch Certificate Issuance Report
  const loadIssuanceReport = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await api.documentReports.getCertificateIssuance({
        search: issuanceSearch.trim() || undefined,
        status: issuanceFilterStatus !== 'ALL' ? issuanceFilterStatus : undefined,
        page: issuancePage,
        limit: 15
      });
      if (res.success && res.data) {
        setIssuanceItems(res.data);
        if (res.pagination) {
          setIssuanceTotalPages(res.pagination.totalPages);
          setIssuanceTotal(res.pagination.total);
        }
      }
    } catch (err: any) {
      setError(err.message || 'Error loading issuance report.');
    } finally {
      setLoading(false);
    }
  }, [issuanceSearch, issuanceFilterStatus, issuancePage]);

  // 6. Fetch Audit Activity
  const loadAuditActivity = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await api.documentReports.getAuditActivity({
        action: auditFilterAction !== 'ALL' ? auditFilterAction : undefined,
        search: auditSearch.trim() || undefined,
        page: auditPage,
        limit: 15
      });
      if (res.success && res.data) {
        setAuditItems(res.data);
        if (res.pagination) {
          setAuditTotalPages(res.pagination.totalPages);
        }
      }
    } catch (err: any) {
      setError(err.message || 'Error loading audit logs.');
    } finally {
      setLoading(false);
    }
  }, [auditFilterAction, auditSearch, auditPage]);

  // Route load based on active sub-tab
  useEffect(() => {
    // Log report viewing audit event
    api.documentReports.auditReportView(
      `Document Reports Tab: ${activeSubTab.toUpperCase()}`
    );

    if (activeSubTab === 'overview') {
      loadOverviewAnalytics();
    } else if (activeSubTab === 'compliance') {
      loadComplianceReport();
    } else if (activeSubTab === 'expiry') {
      loadExpiryReport();
    } else if (activeSubTab === 'certificates') {
      loadCertificateAnalytics();
    } else if (activeSubTab === 'issuance') {
      loadIssuanceReport();
    } else if (activeSubTab === 'audit') {
      loadAuditActivity();
    }
  }, [
    activeSubTab,
    loadOverviewAnalytics,
    loadComplianceReport,
    loadExpiryReport,
    loadCertificateAnalytics,
    loadIssuanceReport,
    loadAuditActivity
  ]);

  // Handle Export CSV
  const handleExportCSV = (reportType: string, filters: Record<string, any> = {}) => {
    const url = api.documentReports.getExportUrl(reportType, filters);
    window.location.href = url;
  };

  // Handle Open Print Preview
  const handleOpenPrintPreview = () => {
    const todayStr = new Date().toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });

    if (activeSubTab === 'compliance') {
      setPrintModalConfig({
        title: 'Institutional Document Compliance Audit Report',
        subtitle: `Filter: ${complianceFilterEntity} Scope • Status: ${complianceFilterStatus} • Total Entities: ${complianceTotal}`,
        metrics: [
          { label: 'Evaluated Entities', value: complianceSummary?.totalEntities || complianceTotal },
          { label: 'Avg Compliance', value: `${complianceSummary?.averageComplianceRate || 0}%` },
          { label: 'Fully Compliant', value: complianceSummary?.fullyCompliantCount || 0 },
          { label: 'Non-Compliant', value: complianceSummary?.nonCompliantCount || 0 }
        ],
        columns: ['Entity Name', 'Scope', 'Class / Department', 'Required Docs', 'Verified', 'Missing', 'Compliance Rate', 'Status'],
        data: complianceItems.map(i => ({
          'Entity Name': i.entityName,
          'Scope': i.entityType,
          'Class / Department': i.subGroup || '—',
          'Required Docs': i.totalApplicableRequired,
          'Verified': i.verifiedCount,
          'Missing': i.missingCount,
          'Compliance Rate': `${i.compliancePercentage}%`,
          'Status': i.complianceStatus
        }))
      });
    } else if (activeSubTab === 'expiry') {
      setPrintModalConfig({
        title: 'Institutional Document Expiry & Renewal Horizon Report',
        subtitle: `Horizon: ${expiryHorizon} Days • Scope: ${expiryFilterEntity} • Monitored Documents: ${expiryTotal}`,
        metrics: [
          { label: 'Total Monitored', value: expirySummary?.totalMonitored || expiryTotal },
          { label: 'Already Expired', value: expirySummary?.alreadyExpired || 0 },
          { label: 'Expiring in 7 Days', value: expirySummary?.expiringIn7Days || 0 },
          { label: 'Expiring in 30 Days', value: expirySummary?.expiringIn30Days || 0 }
        ],
        columns: ['Document Title', 'Owner Name', 'Scope', 'Category', 'Expiry Date', 'Days Remaining', 'Status', 'Urgency'],
        data: expiryItems.map(i => ({
          'Document Title': i.documentTitle,
          'Owner Name': i.entityName,
          'Scope': i.entityType,
          'Category': i.category,
          'Expiry Date': i.expiryDate,
          'Days Remaining': i.daysRemaining < 0 ? `${Math.abs(i.daysRemaining)}d Overdue` : `${i.daysRemaining}d left`,
          'Status': i.expiryStatus,
          'Urgency': i.urgency
        }))
      });
    } else if (activeSubTab === 'issuance') {
      setPrintModalConfig({
        title: 'Institutional Certificate Issuance Ledger Report',
        subtitle: `Authoritative official certificates records • Total Records: ${issuanceTotal}`,
        columns: ['Certificate Number', 'Student Name', 'Admission No', 'Type', 'Issue Date', 'Status', 'Verified By', 'Reference'],
        data: issuanceItems.map(i => ({
          'Certificate Number': i.certificateNumber,
          'Student Name': i.studentName,
          'Admission No': i.admissionNumber,
          'Type': i.certificateTypeName,
          'Issue Date': i.issueDate,
          'Status': i.status,
          'Verified By': i.verifiedByName || '—',
          'Reference': i.digitalVerificationReference
        }))
      });
    } else {
      setPrintModalConfig({
        title: 'Document & Certificate Management Executive Report',
        subtitle: `Period: ${datePreset} • Sygmate International Academy`,
        columns: ['Metric Description', 'Value'],
        data: [
          { 'Metric Description': 'Total Active Documents', 'Value': docAnalytics?.currentState.totalDocuments || 0 },
          { 'Metric Description': 'Verified Documents', 'Value': docAnalytics?.currentState.verified || 0 },
          { 'Metric Description': 'Pending Review', 'Value': docAnalytics?.currentState.pendingVerification || 0 },
          { 'Metric Description': 'Expired Documents', 'Value': docAnalytics?.currentState.expiredDocuments || 0 },
          { 'Metric Description': 'Total Issued Certificates', 'Value': certAnalytics?.currentState.issued || 0 }
        ]
      });
    }

    setIsPrintModalOpen(true);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Header */}
      <div className="bg-gradient-to-r from-[#16263B] via-indigo-950 to-[#16263B] border border-slate-800 rounded-3xl p-6 sm:p-8 relative overflow-hidden shadow-2xl">
        <div className="absolute right-0 top-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="p-3.5 rounded-2xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 shadow-inner">
              <BarChart3 className="w-8 h-8" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                  Document & Certificate Reports & Analytics
                </h1>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  PART 15F
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-1 max-w-2xl">
                Authoritative compliance reporting, verification workflow analytics, renewal horizons, and data reconciliation.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            {/* Date Preset Selector */}
            <div className="flex items-center gap-1.5 bg-slate-900/90 border border-slate-700/80 rounded-xl px-2.5 py-1.5 text-xs text-white">
              <Calendar className="w-3.5 h-3.5 text-indigo-400" />
              <select
                value={datePreset}
                onChange={e => setDatePreset(e.target.value as DocumentReportDateRangePreset)}
                className="bg-transparent text-white focus:outline-none cursor-pointer"
              >
                <option value="TODAY">Today</option>
                <option value="LAST_7_DAYS">Last 7 Days</option>
                <option value="THIS_MONTH">This Month</option>
                <option value="LAST_30_DAYS">Last 30 Days</option>
                <option value="THIS_QUARTER">This Quarter</option>
                <option value="THIS_YEAR">This Academic Year</option>
              </select>
            </div>

            {/* Reconciliation Button */}
            <Button
              onClick={() => setIsReconciliationModalOpen(true)}
              className="bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs border border-slate-700 flex items-center gap-1.5 shadow-sm"
            >
              <Scale className="w-3.5 h-3.5 text-sky-400" />
              Reconcile Data
            </Button>

            {/* Print Button */}
            <Button
              onClick={handleOpenPrintPreview}
              className="bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs border border-slate-700 flex items-center gap-1.5 shadow-sm"
            >
              <Printer className="w-3.5 h-3.5 text-indigo-400" />
              Print Report
            </Button>

            {/* Export CSV Button */}
            <Button
              onClick={() => {
                if (activeSubTab === 'compliance') {
                  handleExportCSV('compliance', { entityType: complianceFilterEntity, complianceStatus: complianceFilterStatus });
                } else if (activeSubTab === 'expiry') {
                  handleExportCSV('expiry', { entityType: expiryFilterEntity, urgency: expiryFilterUrgency, horizonDays: expiryHorizon });
                } else if (activeSubTab === 'issuance') {
                  handleExportCSV('issuance', { status: issuanceFilterStatus });
                } else if (activeSubTab === 'audit') {
                  handleExportCSV('audit', { action: auditFilterAction });
                } else {
                  handleExportCSV('compliance');
                }
              }}
              className="bg-indigo-600 hover:bg-indigo-500 text-white text-xs flex items-center gap-1.5 shadow"
            >
              <Download className="w-3.5 h-3.5" />
              Export CSV
            </Button>
          </div>
        </div>

        {/* Sub-Tabs Navigation */}
        <div className="mt-8 border-b border-slate-800/80 flex items-center gap-2 overflow-x-auto pb-px">
          {[
            { id: 'overview', label: 'Overview & Operational KPIs', icon: BarChart3 },
            { id: 'compliance', label: 'Document Compliance Report', icon: ShieldCheck, badge: complianceTotal || undefined },
            { id: 'expiry', label: 'Expiry & Renewal Horizons', icon: Clock, badge: expirySummary?.alreadyExpired || undefined },
            { id: 'certificates', label: 'Certificate Lifecycle Analytics', icon: Award },
            { id: 'issuance', label: 'Certificate Issuance Ledger', icon: FileText },
            { id: 'audit', label: 'Audit Trail & Activity Log', icon: History }
          ].map(tab => {
            const Icon = tab.icon;
            const isActive = activeSubTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveSubTab(tab.id as ReportSubTab)}
                className={`py-3 px-4 text-xs font-semibold rounded-t-xl transition-all whitespace-nowrap flex items-center gap-2 border-b-2 -mb-px ${
                  isActive
                    ? 'border-indigo-500 text-white bg-slate-800/50'
                    : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/20'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-indigo-400' : 'text-slate-500'}`} />
                <span>{tab.label}</span>
                {tab.badge !== undefined && (
                  <span
                    className={`px-1.5 py-0.2 rounded-full text-[10px] font-bold ${
                      isActive ? 'bg-indigo-500/20 text-indigo-300' : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {error && (
        <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
          <button
            onClick={() => {
              if (activeSubTab === 'overview') loadOverviewAnalytics();
              else if (activeSubTab === 'compliance') loadComplianceReport();
              else if (activeSubTab === 'expiry') loadExpiryReport();
            }}
            className="text-xs text-rose-400 hover:underline flex items-center gap-1"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            Retry
          </button>
        </div>
      )}

      {/* ============================================================== */}
      {/* 1. OVERVIEW & OPERATIONAL DASHBOARD */}
      {/* ============================================================== */}
      {activeSubTab === 'overview' && docAnalytics && (
        <div className="space-y-6">
          {/* Section A: Current-State KPIs */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Database className="w-4 h-4 text-indigo-400" />
                  Current-State Vault Ledger (Real-Time Database Records)
                </h3>
                <p className="text-xs text-slate-400">
                  Authoritative snapshot of active registered documents currently stored in the system.
                </p>
              </div>
              <span className="text-[11px] font-mono text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-0.5 rounded-full">
                Active Vault Records
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
              <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
                <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">
                  Total Active Docs
                </span>
                <p className="text-2xl font-black text-white">{docAnalytics.currentState.totalDocuments}</p>
                <p className="text-[10px] text-slate-500">Across all 5 scopes</p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900 border border-emerald-500/20 bg-emerald-500/5 space-y-1">
                <span className="text-[10px] font-semibold uppercase tracking-wider text-emerald-400">
                  Verified Clean
                </span>
                <p className="text-2xl font-black text-emerald-300">{docAnalytics.currentState.verified}</p>
                <p className="text-[10px] text-emerald-500/80">Approved authenticity</p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900 border border-amber-500/20 bg-amber-500/5 space-y-1">
                <span className="text-[10px] font-semibold uppercase tracking-wider text-amber-400">
                  Pending Review
                </span>
                <p className="text-2xl font-black text-amber-300">
                  {docAnalytics.currentState.pendingVerification}
                </p>
                <p className="text-[10px] text-amber-500/80">Awaiting verifier review</p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900 border border-rose-500/20 bg-rose-500/5 space-y-1">
                <span className="text-[10px] font-semibold uppercase tracking-wider text-rose-400">
                  Rejected Scans
                </span>
                <p className="text-2xl font-black text-rose-300">{docAnalytics.currentState.rejected}</p>
                <p className="text-[10px] text-rose-500/80">Re-upload required</p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900 border border-red-500/20 bg-red-500/5 space-y-1">
                <span className="text-[10px] font-semibold uppercase tracking-wider text-red-400">
                  Expired
                </span>
                <p className="text-2xl font-black text-red-300">{docAnalytics.currentState.expiredDocuments}</p>
                <p className="text-[10px] text-red-500/80">Past validity date</p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900 border border-orange-500/20 bg-orange-500/5 space-y-1">
                <span className="text-[10px] font-semibold uppercase tracking-wider text-orange-400">
                  Missing Required
                </span>
                <p className="text-2xl font-black text-orange-300">
                  {docAnalytics.currentState.missingRequiredDocuments}
                </p>
                <p className="text-[10px] text-orange-500/80">Unfulfilled checklists</p>
              </div>
            </div>
          </div>

          {/* Section B: Historical Period Activity */}
          <div className="space-y-3 pt-4 border-t border-slate-800">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-purple-400" />
                  Historical Activity ({docAnalytics.periodMetrics.preset})
                </h3>
                <p className="text-xs text-slate-400">
                  Event volume recorded between {new Date(docAnalytics.periodMetrics.startDate).toLocaleDateString()} and {new Date(docAnalytics.periodMetrics.endDate).toLocaleDateString()}.
                </p>
              </div>
              <span className="text-[11px] font-mono text-purple-400 bg-purple-500/10 border border-purple-500/20 px-2.5 py-0.5 rounded-full">
                Period Events
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
                <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">
                  Uploaded in Period
                </span>
                <p className="text-2xl font-black text-white">
                  {docAnalytics.periodMetrics.documentsUploaded}
                </p>
              </div>
              <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
                <span className="text-[10px] font-semibold uppercase tracking-wider text-emerald-400">
                  Verified in Period
                </span>
                <p className="text-2xl font-black text-emerald-300">
                  {docAnalytics.periodMetrics.documentsVerified}
                </p>
              </div>
              <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
                <span className="text-[10px] font-semibold uppercase tracking-wider text-rose-400">
                  Rejected in Period
                </span>
                <p className="text-2xl font-black text-rose-300">
                  {docAnalytics.periodMetrics.documentsRejected}
                </p>
              </div>
              <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
                <span className="text-[10px] font-semibold uppercase tracking-wider text-amber-400">
                  Expiries in Period
                </span>
                <p className="text-2xl font-black text-amber-300">
                  {docAnalytics.periodMetrics.documentsExpired}
                </p>
              </div>
            </div>
          </div>

          {/* Section C: Charts & Visual Intelligence */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Timeline AreaChart */}
            <div className="lg:col-span-2 p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-bold text-white">Document Processing Trend</h4>
                  <p className="text-xs text-slate-400">Timeline of document uploads vs verifications</p>
                </div>
              </div>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={docAnalytics.timeline}>
                    <defs>
                      <linearGradient id="colorUpload" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#6366f1" stopOpacity={0.4} />
                        <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                      </linearGradient>
                      <linearGradient id="colorVerify" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10b981" stopOpacity={0.4} />
                        <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                    <XAxis dataKey="date" stroke="#64748b" textAnchor="end" tick={{ fontSize: 10 }} />
                    <YAxis stroke="#64748b" tick={{ fontSize: 10 }} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#0f172a',
                        borderColor: '#334155',
                        borderRadius: '12px',
                        fontSize: '12px'
                      }}
                    />
                    <Legend wrapperStyle={{ fontSize: '11px' }} />
                    <Area
                      type="monotone"
                      dataKey="uploaded"
                      name="Uploaded"
                      stroke="#6366f1"
                      strokeWidth={2}
                      fillOpacity={1}
                      fill="url(#colorUpload)"
                    />
                    <Area
                      type="monotone"
                      dataKey="verified"
                      name="Verified"
                      stroke="#10b981"
                      strokeWidth={2}
                      fillOpacity={1}
                      fill="url(#colorVerify)"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Entity Distribution BarChart */}
            <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
              <div>
                <h4 className="text-sm font-bold text-white">Scope & Ownership Breakdown</h4>
                <p className="text-xs text-slate-400">Documents registered by institutional role</p>
              </div>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={docAnalytics.entityBreakdown} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                    <XAxis type="number" stroke="#64748b" tick={{ fontSize: 10 }} />
                    <YAxis
                      dataKey="entityType"
                      type="category"
                      stroke="#64748b"
                      tick={{ fontSize: 10 }}
                      width={70}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#0f172a',
                        borderColor: '#334155',
                        borderRadius: '12px',
                        fontSize: '12px'
                      }}
                    />
                    <Bar dataKey="count" name="Documents" fill="#3b82f6" radius={[0, 8, 8, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* 2. DOCUMENT COMPLIANCE REPORT */}
      {/* ============================================================== */}
      {activeSubTab === 'compliance' && (
        <div className="space-y-6">
          {/* Summary Cards */}
          {complianceSummary && (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
                <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">
                  Average Compliance
                </span>
                <p className="text-2xl font-black text-indigo-400">
                  {complianceSummary.averageComplianceRate}%
                </p>
                <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden mt-2">
                  <div
                    className="bg-indigo-500 h-full rounded-full transition-all"
                    style={{ width: `${complianceSummary.averageComplianceRate}%` }}
                  />
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900 border border-emerald-500/20 bg-emerald-500/5 space-y-1">
                <span className="text-[10px] font-semibold uppercase tracking-wider text-emerald-400">
                  Fully Compliant (100%)
                </span>
                <p className="text-2xl font-black text-emerald-300">
                  {complianceSummary.fullyCompliantCount}
                </p>
                <p className="text-[10px] text-emerald-500/80">All requirements verified</p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900 border border-amber-500/20 bg-amber-500/5 space-y-1">
                <span className="text-[10px] font-semibold uppercase tracking-wider text-amber-400">
                  Partially Compliant
                </span>
                <p className="text-2xl font-black text-amber-300">
                  {complianceSummary.partiallyCompliantCount}
                </p>
                <p className="text-[10px] text-amber-500/80">Pending review or missing</p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900 border border-rose-500/20 bg-rose-500/5 space-y-1">
                <span className="text-[10px] font-semibold uppercase tracking-wider text-rose-400">
                  Non-Compliant (0%)
                </span>
                <p className="text-2xl font-black text-rose-300">
                  {complianceSummary.nonCompliantCount}
                </p>
                <p className="text-[10px] text-rose-500/80">Zero verified submissions</p>
              </div>
            </div>
          )}

          {/* Filters Bar */}
          <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2.5 flex-1">
              <div className="relative flex-1 min-w-[200px]">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                <input
                  type="text"
                  placeholder="Search entity name, admission or employee code..."
                  value={complianceSearch}
                  onChange={e => {
                    setComplianceSearch(e.target.value);
                    setCompliancePage(1);
                  }}
                  className="w-full pl-9 pr-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <select
                value={complianceFilterEntity}
                onChange={e => {
                  setComplianceFilterEntity(e.target.value as any);
                  setCompliancePage(1);
                }}
                className="px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white focus:outline-none focus:border-indigo-500"
              >
                <option value="ALL">All Entity Scopes</option>
                <option value="STUDENT">Students</option>
                <option value="TEACHER">Teachers & Faculty</option>
                <option value="STAFF">Administrative Staff</option>
                <option value="GUARDIAN">Parents / Guardians</option>
                <option value="SCHOOL">School Institutional</option>
              </select>

              <select
                value={complianceFilterStatus}
                onChange={e => {
                  setComplianceFilterStatus(e.target.value);
                  setCompliancePage(1);
                }}
                className="px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white focus:outline-none focus:border-indigo-500"
              >
                <option value="ALL">All Compliance Levels</option>
                <option value="FULLY_COMPLIANT">Fully Compliant (100%)</option>
                <option value="PARTIALLY_COMPLIANT">Partially Compliant (1–99%)</option>
                <option value="NON_COMPLIANT">Non-Compliant (0%)</option>
              </select>
            </div>

            <p className="text-xs text-slate-400">
              Showing {complianceItems.length} of {complianceTotal} records
            </p>
          </div>

          {/* Compliance Table */}
          <div className="border border-slate-800 rounded-3xl overflow-hidden bg-slate-900 shadow-xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="bg-slate-950/60 border-b border-slate-800 text-slate-400">
                    <th className="px-6 py-4 font-semibold">Entity Name & Code</th>
                    <th className="px-4 py-4 font-semibold">Scope & Role</th>
                    <th className="px-4 py-4 font-semibold">Group / Department</th>
                    <th className="px-4 py-4 font-semibold text-center">Required</th>
                    <th className="px-4 py-4 font-semibold text-center">Verified</th>
                    <th className="px-4 py-4 font-semibold text-center">Missing</th>
                    <th className="px-6 py-4 font-semibold">Compliance Progress</th>
                    <th className="px-4 py-4 font-semibold">Status</th>
                    <th className="px-6 py-4 font-semibold text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {complianceItems.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="px-6 py-12 text-center text-slate-400">
                        No entities matched the selected compliance filters.
                      </td>
                    </tr>
                  ) : (
                    complianceItems.map(item => (
                      <tr
                        key={item.entityId}
                        className="hover:bg-slate-800/40 transition-colors group cursor-pointer"
                        onClick={() =>
                          setSelectedEntityForChecklist({
                            entityType: item.entityType,
                            entityId: item.entityId,
                            entityName: item.entityName
                          })
                        }
                      >
                        <td className="px-6 py-4">
                          <span className="font-bold text-white block text-sm">{item.entityName}</span>
                          <span className="font-mono text-[11px] text-slate-400">
                            {item.entityCode || 'ID: ' + item.entityId.slice(0, 10)}
                          </span>
                        </td>
                        <td className="px-4 py-4">
                          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-slate-800 text-slate-300 border border-slate-700">
                            {item.entityType}
                          </span>
                        </td>
                        <td className="px-4 py-4 text-slate-300">{item.subGroup || '—'}</td>
                        <td className="px-4 py-4 text-center font-mono font-bold text-white">
                          {item.totalApplicableRequired}
                        </td>
                        <td className="px-4 py-4 text-center font-mono font-bold text-emerald-400">
                          {item.verifiedCount}
                        </td>
                        <td className="px-4 py-4 text-center font-mono font-bold text-rose-400">
                          {item.missingCount}
                        </td>
                        <td className="px-6 py-4">
                          <div className="w-36 space-y-1">
                            <div className="flex justify-between text-[11px] font-mono">
                              <span className="text-slate-400">Completion</span>
                              <span className="font-bold text-white">{item.compliancePercentage}%</span>
                            </div>
                            <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                              <div
                                className={`h-full rounded-full transition-all ${
                                  item.compliancePercentage === 100
                                    ? 'bg-emerald-500'
                                    : item.compliancePercentage > 0
                                    ? 'bg-amber-500'
                                    : 'bg-rose-500'
                                }`}
                                style={{ width: `${item.compliancePercentage}%` }}
                              />
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-4">
                          <span
                            className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${
                              item.complianceStatus === 'FULLY_COMPLIANT'
                                ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/20'
                                : item.complianceStatus === 'PARTIALLY_COMPLIANT'
                                ? 'bg-amber-500/10 text-amber-300 border-amber-500/20'
                                : 'bg-rose-500/10 text-rose-300 border-rose-500/20'
                            }`}
                          >
                            {item.complianceStatus === 'FULLY_COMPLIANT'
                              ? 'Fully Compliant'
                              : item.complianceStatus === 'PARTIALLY_COMPLIANT'
                              ? 'Partial'
                              : 'Non-Compliant'}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-right">
                          <button
                            onClick={e => {
                              e.stopPropagation();
                              setSelectedEntityForChecklist({
                                entityType: item.entityType,
                                entityId: item.entityId,
                                entityName: item.entityName
                              });
                            }}
                            className="p-1.5 rounded-xl bg-slate-800 text-slate-300 hover:text-white hover:bg-indigo-600 transition-colors inline-flex items-center gap-1 text-xs"
                          >
                            <span>Inspect Checklist</span>
                            <ChevronRight className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            {/* Pagination Bar */}
            {complianceTotalPages > 1 && (
              <div className="p-4 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
                <span>
                  Page {compliancePage} of {complianceTotalPages}
                </span>
                <div className="flex items-center gap-2">
                  <Button
                    onClick={() => setCompliancePage(p => Math.max(1, p - 1))}
                    disabled={compliancePage === 1}
                    variant="outline"
                    className="text-xs px-3 py-1.5 border-slate-700"
                  >
                    <ChevronLeft className="w-3.5 h-3.5 mr-1" />
                    Previous
                  </Button>
                  <Button
                    onClick={() => setCompliancePage(p => Math.min(complianceTotalPages, p + 1))}
                    disabled={compliancePage === complianceTotalPages}
                    variant="outline"
                    className="text-xs px-3 py-1.5 border-slate-700"
                  >
                    Next
                    <ChevronRight className="w-3.5 h-3.5 ml-1" />
                  </Button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* 3. EXPIRY & RENEWAL REPORT */}
      {/* ============================================================== */}
      {activeSubTab === 'expiry' && (
        <div className="space-y-6">
          {/* Summary Cards */}
          {expirySummary && (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
                <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">
                  Monitored Vault Docs
                </span>
                <p className="text-2xl font-black text-white">{expirySummary.totalMonitored}</p>
                <p className="text-[10px] text-slate-500">With recorded expiry dates</p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900 border border-rose-500/20 bg-rose-500/5 space-y-1">
                <span className="text-[10px] font-semibold uppercase tracking-wider text-rose-400">
                  Already Overdue / Expired
                </span>
                <p className="text-2xl font-black text-rose-300">{expirySummary.alreadyExpired}</p>
                <p className="text-[10px] text-rose-500/80">Critical action required</p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900 border border-amber-500/20 bg-amber-500/5 space-y-1">
                <span className="text-[10px] font-semibold uppercase tracking-wider text-amber-400">
                  Expiring in ≤ 30 Days
                </span>
                <p className="text-2xl font-black text-amber-300">{expirySummary.expiringIn30Days}</p>
                <p className="text-[10px] text-amber-500/80">Renewal window active</p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900 border border-emerald-500/20 bg-emerald-500/5 space-y-1">
                <span className="text-[10px] font-semibold uppercase tracking-wider text-emerald-400">
                  Secure & Valid (&gt;60d)
                </span>
                <p className="text-2xl font-black text-emerald-300">{expirySummary.valid}</p>
                <p className="text-[10px] text-emerald-500/80">Safe compliance horizon</p>
              </div>
            </div>
          )}

          {/* Filters Bar */}
          <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2.5 flex-1">
              <div className="relative flex-1 min-w-[200px]">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                <input
                  type="text"
                  placeholder="Search document title, owner name or category..."
                  value={expirySearch}
                  onChange={e => {
                    setExpirySearch(e.target.value);
                    setExpiryPage(1);
                  }}
                  className="w-full pl-9 pr-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <select
                value={expiryHorizon}
                onChange={e => {
                  setExpiryHorizon(e.target.value);
                  setExpiryPage(1);
                }}
                className="px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white focus:outline-none focus:border-indigo-500"
              >
                <option value="30">30-Day Window</option>
                <option value="60">60-Day Window</option>
                <option value="90">90-Day Window</option>
                <option value="180">180-Day Window</option>
                <option value="365">1-Year Horizon</option>
              </select>

              <select
                value={expiryFilterUrgency}
                onChange={e => {
                  setExpiryFilterUrgency(e.target.value);
                  setExpiryPage(1);
                }}
                className="px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white focus:outline-none focus:border-indigo-500"
              >
                <option value="ALL">All Expiry States</option>
                <option value="EXPIRED">Already Expired</option>
                <option value="TODAY">Expiring Today</option>
                <option value="7_DAYS">Expiring within 7 Days</option>
                <option value="30_DAYS">Expiring within 30 Days</option>
              </select>

              <select
                value={expiryFilterEntity}
                onChange={e => {
                  setExpiryFilterEntity(e.target.value);
                  setExpiryPage(1);
                }}
                className="px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white focus:outline-none focus:border-indigo-500"
              >
                <option value="ALL">All Entity Scopes</option>
                <option value="STUDENT">Students</option>
                <option value="TEACHER">Teachers & Faculty</option>
                <option value="STAFF">Administrative Staff</option>
                <option value="GUARDIAN">Parents / Guardians</option>
                <option value="SCHOOL">School Institutional</option>
              </select>
            </div>
            <p className="text-xs text-slate-400">
              Showing {expiryItems.length} of {expiryTotal} documents
            </p>
          </div>

          {/* Expiry Table */}
          <div className="border border-slate-800 rounded-3xl overflow-hidden bg-slate-900 shadow-xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="bg-slate-950/60 border-b border-slate-800 text-slate-400">
                    <th className="px-6 py-4 font-semibold">Document Title</th>
                    <th className="px-4 py-4 font-semibold">Owner & Scope</th>
                    <th className="px-4 py-4 font-semibold">Document Category</th>
                    <th className="px-4 py-4 font-semibold">Expiry Date</th>
                    <th className="px-4 py-4 font-semibold">Days Remaining</th>
                    <th className="px-4 py-4 font-semibold">Urgency</th>
                    <th className="px-6 py-4 font-semibold text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {expiryItems.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="px-6 py-12 text-center text-slate-400">
                        No documents matched the selected expiry horizon filters.
                      </td>
                    </tr>
                  ) : (
                    expiryItems.map(item => (
                      <tr key={item.documentId} className="hover:bg-slate-800/40 transition-colors">
                        <td className="px-6 py-4">
                          <span className="font-bold text-white block text-sm">{item.documentTitle}</span>
                          <span className="font-mono text-[11px] text-slate-400">{item.fileName}</span>
                        </td>
                        <td className="px-4 py-4">
                          <span className="font-semibold text-white block">{item.entityName}</span>
                          <span className="text-[10px] text-slate-400 font-mono">{item.entityType}</span>
                        </td>
                        <td className="px-4 py-4">
                          <span className="font-mono text-xs text-indigo-400 bg-indigo-500/10 px-2 py-0.5 rounded border border-indigo-500/20">
                            {item.category}
                          </span>
                        </td>
                        <td className="px-4 py-4 font-mono font-semibold text-white">
                          {item.expiryDate}
                        </td>
                        <td className="px-4 py-4">
                          {item.daysRemaining < 0 ? (
                            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-rose-500/10 text-rose-400 border border-rose-500/20 font-mono">
                              {Math.abs(item.daysRemaining)} days overdue
                            </span>
                          ) : item.daysRemaining === 0 ? (
                            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-red-600 text-white font-mono animate-pulse">
                              Expiring Today
                            </span>
                          ) : item.daysRemaining <= 30 ? (
                            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-500/10 text-amber-300 border border-amber-500/20 font-mono">
                              {item.daysRemaining} days left
                            </span>
                          ) : (
                            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-mono">
                              {item.daysRemaining} days left
                            </span>
                          )}
                        </td>
                        <td className="px-4 py-4">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              item.urgency === 'CRITICAL'
                                ? 'bg-rose-500 text-white'
                                : item.urgency === 'HIGH'
                                ? 'bg-amber-500 text-black'
                                : item.urgency === 'MEDIUM'
                                ? 'bg-amber-500/20 text-amber-300'
                                : 'bg-slate-800 text-slate-400'
                            }`}
                          >
                            {item.urgency}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-right">
                          <button
                            onClick={() => {
                              if (onOpenDocumentDetail) onOpenDocumentDetail(item.documentId);
                            }}
                            className="p-1.5 rounded-xl bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition-colors text-xs font-semibold"
                          >
                            View Document
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            {/* Pagination */}
            {expiryTotalPages > 1 && (
              <div className="p-4 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
                <span>
                  Page {expiryPage} of {expiryTotalPages}
                </span>
                <div className="flex items-center gap-2">
                  <Button
                    onClick={() => setExpiryPage(p => Math.max(1, p - 1))}
                    disabled={expiryPage === 1}
                    variant="outline"
                    className="text-xs px-3 py-1.5 border-slate-700"
                  >
                    <ChevronLeft className="w-3.5 h-3.5 mr-1" />
                    Previous
                  </Button>
                  <Button
                    onClick={() => setExpiryPage(p => Math.min(expiryTotalPages, p + 1))}
                    disabled={expiryPage === expiryTotalPages}
                    variant="outline"
                    className="text-xs px-3 py-1.5 border-slate-700"
                  >
                    Next
                    <ChevronRight className="w-3.5 h-3.5 ml-1" />
                  </Button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* 4. CERTIFICATE ANALYTICS & LIFECYCLE */}
      {/* ============================================================== */}
      {activeSubTab === 'certificates' && certAnalytics && certLifecycle && (
        <div className="space-y-6">
          {/* Certificate Funnel */}
          <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-6 shadow-xl">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-indigo-400" />
                Certificate Lifecycle Funnel
              </h3>
              <p className="text-xs text-slate-400">
                Authoritative conversion rates through review, verification, approval, and official issuance.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
              <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-2 relative overflow-hidden">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Stage 1</span>
                <h4 className="text-sm font-extrabold text-white">Generated</h4>
                <p className="text-3xl font-black text-indigo-400">{certLifecycle.funnel.generatedCount}</p>
                <p className="text-[10px] text-slate-500">100% Volume Base</p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-2 relative overflow-hidden">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Stage 2</span>
                <h4 className="text-sm font-extrabold text-white">Verified</h4>
                <p className="text-3xl font-black text-sky-400">{certLifecycle.funnel.verifiedCount}</p>
                <p className="text-[10px] text-slate-500">
                  {certLifecycle.funnel.generatedCount > 0
                    ? Math.round((certLifecycle.funnel.verifiedCount / certLifecycle.funnel.generatedCount) * 100)
                    : 100}
                  % Throughput
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-2 relative overflow-hidden">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Stage 3</span>
                <h4 className="text-sm font-extrabold text-white">Approved</h4>
                <p className="text-3xl font-black text-purple-400">{certLifecycle.funnel.approvedCount}</p>
                <p className="text-[10px] text-slate-500">
                  {certLifecycle.funnel.verifiedCount > 0
                    ? Math.round((certLifecycle.funnel.approvedCount / certLifecycle.funnel.verifiedCount) * 100)
                    : 100}
                  % Clearance
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-950/80 border border-emerald-500/20 bg-emerald-500/5 space-y-2 relative overflow-hidden">
                <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400">Final Stage</span>
                <h4 className="text-sm font-extrabold text-emerald-300">Officially Issued</h4>
                <p className="text-3xl font-black text-emerald-400">{certLifecycle.funnel.issuedCount}</p>
                <p className="text-[10px] text-emerald-500/80">Conferred with QR Seal</p>
              </div>
            </div>

            {/* Measured Durations from Recorded Timestamps */}
            <div className="p-5 rounded-2xl bg-slate-950/60 border border-indigo-500/20 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                  <Clock className="w-4 h-4 text-indigo-400" />
                  Measured Processing Durations (Recorded Workflow Timestamps)
                </h4>
                <span className="text-[10px] font-mono text-slate-400">
                  Samples Audited: {certLifecycle.durations.sampleCount}
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                  <span className="text-slate-400 block text-[10px]">Generation → Verification</span>
                  <span className="font-extrabold text-white text-base">
                    {certLifecycle.durations.avgGenerationToVerificationHours} hrs
                  </span>
                </div>

                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                  <span className="text-slate-400 block text-[10px]">Verification → Approval</span>
                  <span className="font-extrabold text-white text-base">
                    {certLifecycle.durations.avgVerificationToApprovalHours} hrs
                  </span>
                </div>

                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                  <span className="text-slate-400 block text-[10px]">Approval → Issuance</span>
                  <span className="font-extrabold text-white text-base">
                    {certLifecycle.durations.avgApprovalToIssuanceHours} hrs
                  </span>
                </div>

                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                  <span className="text-slate-400 block text-[10px]">Average Total Turnaround</span>
                  <span className="font-extrabold text-emerald-400 text-base">
                    {certLifecycle.durations.avgTotalCycleDays} days
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Certificate Volume by Type */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
              <div>
                <h4 className="text-sm font-bold text-white">Certificates Conferred by Type</h4>
                <p className="text-xs text-slate-400">Distribution across configured academic certificate templates</p>
              </div>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={certAnalytics.byType}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                    <XAxis dataKey="typeCode" stroke="#64748b" tick={{ fontSize: 10 }} />
                    <YAxis stroke="#64748b" tick={{ fontSize: 10 }} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#0f172a',
                        borderColor: '#334155',
                        borderRadius: '12px',
                        fontSize: '12px'
                      }}
                    />
                    <Bar dataKey="count" name="Certificates" fill="#8b5cf6" radius={[6, 6, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
              <div>
                <h4 className="text-sm font-bold text-white">Exception & Cancellation Pipeline</h4>
                <p className="text-xs text-slate-400">Certificates rejected, revoked, or cancelled</p>
              </div>
              <div className="space-y-3 pt-2">
                <div className="p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800 flex items-center justify-between">
                  <span className="text-xs text-slate-300">Verification Rejections</span>
                  <span className="font-mono font-bold text-amber-400">
                    {certLifecycle.exceptions.verificationRejectedCount}
                  </span>
                </div>

                <div className="p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800 flex items-center justify-between">
                  <span className="text-xs text-slate-300">Approval Rejections</span>
                  <span className="font-mono font-bold text-rose-400">
                    {certLifecycle.exceptions.approvalRejectedCount}
                  </span>
                </div>

                <div className="p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800 flex items-center justify-between">
                  <span className="text-xs text-slate-300">Officially Revoked (Annulled)</span>
                  <span className="font-mono font-bold text-rose-500">
                    {certLifecycle.exceptions.revokedCount}
                  </span>
                </div>

                <div className="p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800 flex items-center justify-between">
                  <span className="text-xs text-slate-300">Cancelled Drafts</span>
                  <span className="font-mono font-bold text-slate-400">
                    {certLifecycle.exceptions.cancelledCount}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* 5. CERTIFICATE ISSUANCE LOGS */}
      {/* ============================================================== */}
      {activeSubTab === 'issuance' && (
        <div className="space-y-6">
          {/* Filters Bar */}
          <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2.5 flex-1">
              <div className="relative flex-1 min-w-[200px]">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                <input
                  type="text"
                  placeholder="Search certificate serial, student name or admission number..."
                  value={issuanceSearch}
                  onChange={e => {
                    setIssuanceSearch(e.target.value);
                    setIssuancePage(1);
                  }}
                  className="w-full pl-9 pr-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <select
                value={issuanceFilterStatus}
                onChange={e => {
                  setIssuanceFilterStatus(e.target.value);
                  setIssuancePage(1);
                }}
                className="px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white focus:outline-none focus:border-indigo-500"
              >
                <option value="ALL">All Statuses</option>
                <option value="ISSUED">Officially Issued</option>
                <option value="APPROVED">Approved</option>
                <option value="VERIFIED">Verified</option>
                <option value="GENERATED">Generated</option>
                <option value="REVOKED">Revoked</option>
                <option value="CANCELLED">Cancelled</option>
              </select>
            </div>
            <p className="text-xs text-slate-400">
              Showing {issuanceItems.length} of {issuanceTotal} certificates
            </p>
          </div>

          {/* Issuance Table */}
          <div className="border border-slate-800 rounded-3xl overflow-hidden bg-slate-900 shadow-xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="bg-slate-950/60 border-b border-slate-800 text-slate-400">
                    <th className="px-6 py-4 font-semibold">Certificate Number</th>
                    <th className="px-4 py-4 font-semibold">Student Name & Admission</th>
                    <th className="px-4 py-4 font-semibold">Certificate Type</th>
                    <th className="px-4 py-4 font-semibold">Issue Date</th>
                    <th className="px-4 py-4 font-semibold">Status</th>
                    <th className="px-4 py-4 font-semibold">Verified / Approved By</th>
                    <th className="px-6 py-4 font-semibold">Digital Reference</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {issuanceItems.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="px-6 py-12 text-center text-slate-400">
                        No certificates matched the current search criteria.
                      </td>
                    </tr>
                  ) : (
                    issuanceItems.map(item => (
                      <tr key={item.id} className="hover:bg-slate-800/40 transition-colors">
                        <td className="px-6 py-4">
                          <span className="font-mono font-bold text-indigo-400 block text-xs">
                            {item.certificateNumber}
                          </span>
                          {item.version > 1 && (
                            <span className="text-[10px] text-purple-400 font-bold bg-purple-500/10 px-1.5 py-0.5 rounded border border-purple-500/20">
                              v{item.version} (Reissued)
                            </span>
                          )}
                        </td>
                        <td className="px-4 py-4">
                          <span className="font-semibold text-white block">{item.studentName}</span>
                          <span className="text-[10px] text-slate-400 font-mono">
                            {item.admissionNumber} {item.className ? `• ${item.className}` : ''}
                          </span>
                        </td>
                        <td className="px-4 py-4 text-slate-300">{item.certificateTypeName}</td>
                        <td className="px-4 py-4 font-mono text-slate-400">{item.issueDate}</td>
                        <td className="px-4 py-4">
                          <span
                            className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${
                              item.status === 'ISSUED'
                                ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/20'
                                : item.status === 'APPROVED'
                                ? 'bg-indigo-500/10 text-indigo-300 border-indigo-500/20'
                                : item.status === 'REVOKED'
                                ? 'bg-rose-500/10 text-rose-300 border-rose-500/20'
                                : 'bg-slate-800 text-slate-300 border-slate-700'
                            }`}
                          >
                            {item.status}
                          </span>
                        </td>
                        <td className="px-4 py-4 text-[11px] text-slate-300">
                          <div>{item.approvedByName || item.verifiedByName || '—'}</div>
                        </td>
                        <td className="px-6 py-4 font-mono text-slate-400 text-[11px]">
                          {item.digitalVerificationReference}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            {/* Pagination */}
            {issuanceTotalPages > 1 && (
              <div className="p-4 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
                <span>
                  Page {issuancePage} of {issuanceTotalPages}
                </span>
                <div className="flex items-center gap-2">
                  <Button
                    onClick={() => setIssuancePage(p => Math.max(1, p - 1))}
                    disabled={issuancePage === 1}
                    variant="outline"
                    className="text-xs px-3 py-1.5 border-slate-700"
                  >
                    <ChevronLeft className="w-3.5 h-3.5 mr-1" />
                    Previous
                  </Button>
                  <Button
                    onClick={() => setIssuancePage(p => Math.min(issuanceTotalPages, p + 1))}
                    disabled={issuancePage === issuanceTotalPages}
                    variant="outline"
                    className="text-xs px-3 py-1.5 border-slate-700"
                  >
                    Next
                    <ChevronRight className="w-3.5 h-3.5 ml-1" />
                  </Button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* 6. AUDIT TRAIL & ACTIVITY LOG */}
      {/* ============================================================== */}
      {activeSubTab === 'audit' && (
        <div className="space-y-6">
          {/* Filters Bar */}
          <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2.5 flex-1">
              <div className="relative flex-1 min-w-[200px]">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                <input
                  type="text"
                  placeholder="Search user, audit action or details..."
                  value={auditSearch}
                  onChange={e => {
                    setAuditSearch(e.target.value);
                    setAuditPage(1);
                  }}
                  className="w-full pl-9 pr-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <select
                value={auditFilterAction}
                onChange={e => {
                  setAuditFilterAction(e.target.value);
                  setAuditPage(1);
                }}
                className="px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white focus:outline-none focus:border-indigo-500"
              >
                <option value="ALL">All Actions</option>
                <option value="DOCUMENT_UPLOADED">Document Uploaded</option>
                <option value="DOCUMENT_VERIFIED">Document Verified</option>
                <option value="CERTIFICATE_ISSUED">Certificate Issued</option>
                <option value="CERTIFICATE_REVOKED">Certificate Revoked</option>
                <option value="REPORT_EXPORTED">Report Exported</option>
              </select>
            </div>
          </div>

          {/* Audit Table */}
          <div className="border border-slate-800 rounded-3xl overflow-hidden bg-slate-900 shadow-xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="bg-slate-950/60 border-b border-slate-800 text-slate-400">
                    <th className="px-6 py-4 font-semibold">Timestamp</th>
                    <th className="px-4 py-4 font-semibold">Operator</th>
                    <th className="px-4 py-4 font-semibold">Role</th>
                    <th className="px-4 py-4 font-semibold">Action</th>
                    <th className="px-6 py-4 font-semibold">Audit Details</th>
                    <th className="px-4 py-4 font-semibold text-right">IP Address</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {auditItems.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="px-6 py-12 text-center text-slate-400">
                        No audit events recorded for document or certificate operations yet.
                      </td>
                    </tr>
                  ) : (
                    auditItems.map(item => (
                      <tr key={item.id} className="hover:bg-slate-800/40 transition-colors">
                        <td className="px-6 py-4 font-mono text-[11px] text-slate-400 whitespace-nowrap">
                          {new Date(item.timestamp).toLocaleString()}
                        </td>
                        <td className="px-4 py-4 font-semibold text-white">{item.userName}</td>
                        <td className="px-4 py-4">
                          <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-800 text-slate-300">
                            {item.userRole}
                          </span>
                        </td>
                        <td className="px-4 py-4 font-mono text-xs text-indigo-400">
                          {item.action}
                        </td>
                        <td className="px-6 py-4 text-slate-300">{item.details}</td>
                        <td className="px-4 py-4 text-right font-mono text-slate-500">
                          {item.ipAddress}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Reconciliation Modal */}
      <DocumentReconciliationModal
        isOpen={isReconciliationModalOpen}
        onClose={() => setIsReconciliationModalOpen(false)}
        initialReport={reconciliationReport}
        onReconciled={() => {
          loadOverviewAnalytics();
        }}
      />

      {/* Print Preview Modal */}
      <DocumentReportsPrintModal
        isOpen={isPrintModalOpen}
        onClose={() => setIsPrintModalOpen(false)}
        reportTitle={printModalConfig.title}
        reportSubtitle={printModalConfig.subtitle}
        generatedDate={new Date().toLocaleString()}
        summaryMetrics={printModalConfig.metrics}
        columns={printModalConfig.columns}
        data={printModalConfig.data}
      />

      {/* Drilldown Checklist Modal */}
      {selectedEntityForChecklist && (
        <EntityDocumentChecklistModal
          isOpen={true}
          onClose={() => setSelectedEntityForChecklist(null)}
          entityType={selectedEntityForChecklist.entityType}
          entityId={selectedEntityForChecklist.entityId}
          entityName={selectedEntityForChecklist.entityName}
          onDocumentUpdated={() => {
            loadComplianceReport();
          }}
        />
      )}
    </div>
  );
};
