/**
 * Part 15F — Document & Certificate Data Reconciliation Modal
 * Sygmate School Management System
 */

import React, { useState } from 'react';
import {
  X,
  RefreshCw,
  CheckCircle2,
  AlertTriangle,
  Database,
  FileCheck,
  ShieldCheck,
  Scale,
  Sparkles
} from 'lucide-react';
import { Button } from '../../ui/Button.js';
import { api } from '../../../services/api.js';
import { DocumentCertificateReconciliationReport } from '../../../types/index.js';

interface DocumentReconciliationModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialReport?: DocumentCertificateReconciliationReport | null;
  onReconciled?: () => void;
}

export const DocumentReconciliationModal: React.FC<DocumentReconciliationModalProps> = ({
  isOpen,
  onClose,
  initialReport,
  onReconciled
}) => {
  const [report, setReport] = useState<DocumentCertificateReconciliationReport | null>(
    initialReport || null
  );
  const [running, setRunning] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleRunReconciliation = async () => {
    setRunning(true);
    setError(null);
    try {
      const res = await api.documentReports.reconcileData();
      if (res.success && res.data) {
        setReport(res.data);
        if (onReconciled) onReconciled();
      } else {
        setError(res.error || 'Reconciliation failed.');
      }
    } catch (err: any) {
      setError(err.message || 'Network error running reconciliation.');
    } finally {
      setRunning(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-2xl w-full p-6 sm:p-8 space-y-6 shadow-2xl relative overflow-hidden">
        <div className="absolute right-0 top-0 w-80 h-80 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Header */}
        <div className="flex items-center justify-between relative z-10">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-2xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
              <Scale className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Authoritative Data Reconciliation</h2>
              <p className="text-xs text-slate-400">
                Audits document counts, certificate lifecycle states & expiry dates against core collections
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {error && (
          <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {report && (
          <div className="space-y-4 relative z-10">
            {/* Status Banner */}
            <div
              className={`p-4 rounded-2xl border flex items-center justify-between ${
                report.isReconciled
                  ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-300'
                  : 'bg-amber-500/10 border-amber-500/20 text-amber-300'
              }`}
            >
              <div className="flex items-center gap-2.5">
                {report.isReconciled ? (
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                ) : (
                  <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />
                )}
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider">
                    {report.isReconciled ? '100% Reconciled — Zero Variances' : 'Variance Detected in Ledger'}
                  </h4>
                  <p className="text-[11px] opacity-80">
                    Checked at {new Date(report.timestamp).toLocaleTimeString()}
                  </p>
                </div>
              </div>
              <span className="text-xs font-mono font-bold px-2.5 py-1 rounded-full bg-slate-900 border border-white/10">
                Variance: {report.documents.variance + report.certificates.variance + report.expiries.variance}
              </span>
            </div>

            {/* Reconciliation Detail Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800/80 space-y-2">
                <div className="flex items-center justify-between text-xs font-semibold text-slate-300">
                  <span>Document Vault Registry</span>
                  <Database className="w-4 h-4 text-indigo-400" />
                </div>
                <div className="space-y-1 text-xs">
                  <div className="flex justify-between text-slate-400">
                    <span>Database Records:</span>
                    <span className="text-white font-mono">{report.documents.totalRecords}</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>Active Documents:</span>
                    <span className="text-white font-mono">{report.documents.activeTotal}</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>Archived Records:</span>
                    <span className="text-white font-mono">{report.documents.archivedTotal}</span>
                  </div>
                  <div className="flex justify-between font-semibold border-t border-slate-800 pt-1 text-emerald-400">
                    <span>Reconciliation Variance:</span>
                    <span className="font-mono">{report.documents.variance}</span>
                  </div>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800/80 space-y-2">
                <div className="flex items-center justify-between text-xs font-semibold text-slate-300">
                  <span>Certificate Registry</span>
                  <FileCheck className="w-4 h-4 text-purple-400" />
                </div>
                <div className="space-y-1 text-xs">
                  <div className="flex justify-between text-slate-400">
                    <span>Database Records:</span>
                    <span className="text-white font-mono">{report.certificates.totalRecords}</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>Officially Issued:</span>
                    <span className="text-white font-mono">{report.certificates.issuedCount}</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>Reviewed / Verified:</span>
                    <span className="text-white font-mono">{report.certificates.verifiedCount}</span>
                  </div>
                  <div className="flex justify-between font-semibold border-t border-slate-800 pt-1 text-emerald-400">
                    <span>Reconciliation Variance:</span>
                    <span className="font-mono">{report.certificates.variance}</span>
                  </div>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800/80 space-y-2">
                <div className="flex items-center justify-between text-xs font-semibold text-slate-300">
                  <span>Document Expiries</span>
                  <ShieldCheck className="w-4 h-4 text-amber-400" />
                </div>
                <div className="space-y-1 text-xs">
                  <div className="flex justify-between text-slate-400">
                    <span>Expired Database Items:</span>
                    <span className="text-white font-mono">{report.expiries.expiredRecords}</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>Dashboard Aggregate:</span>
                    <span className="text-white font-mono">{report.expiries.dashboardExpired}</span>
                  </div>
                  <div className="flex justify-between font-semibold border-t border-slate-800 pt-1 text-emerald-400">
                    <span>Expiry Variance:</span>
                    <span className="font-mono">{report.expiries.variance}</span>
                  </div>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800/80 space-y-2">
                <div className="flex items-center justify-between text-xs font-semibold text-slate-300">
                  <span>Compliance Engine Audit</span>
                  <Sparkles className="w-4 h-4 text-sky-400" />
                </div>
                <div className="space-y-1 text-xs">
                  <div className="flex justify-between text-slate-400">
                    <span>Entities Evaluated:</span>
                    <span className="text-white font-mono">{report.compliance.evaluatedEntities}</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>Average Compliance:</span>
                    <span className="text-white font-mono">{report.compliance.averageCalculatedCompliance}%</span>
                  </div>
                  <div className="flex justify-between font-semibold border-t border-slate-800 pt-1 text-sky-400">
                    <span>Definition Checked:</span>
                    <span>Verified / Required</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Footer Actions */}
        <div className="flex items-center justify-between pt-4 border-t border-slate-800">
          <p className="text-[11px] text-slate-500">
            Reconciliation logs are written to the system audit trail.
          </p>
          <div className="flex items-center gap-2">
            <Button
              onClick={onClose}
              variant="outline"
              className="text-xs border-slate-700 text-slate-300"
            >
              Close
            </Button>
            <Button
              onClick={handleRunReconciliation}
              disabled={running}
              className="bg-indigo-600 hover:bg-indigo-500 text-white text-xs flex items-center gap-1.5 shadow-sm"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${running ? 'animate-spin' : ''}`} />
              {running ? 'Reconciling Records...' : 'Execute Fresh Reconciliation'}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};
