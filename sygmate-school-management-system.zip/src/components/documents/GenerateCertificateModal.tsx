/**
 * Part 15C — Generate & Issue Certificate Wizard Modal
 * Sygmate School Management System
 */

import React, { useState, useEffect, useMemo } from 'react';
import {
  X,
  Award,
  Sparkles,
  User,
  GraduationCap,
  Calendar,
  FileCheck,
  CheckCircle2,
  ChevronRight,
  ChevronLeft,
  Search,
  Eye,
  Send,
  AlertCircle
} from 'lucide-react';
import {
  CertificateTypeConfig,
  CertificateTemplate,
  StudentProfile,
  AcademicSession
} from '../../types';
import { api } from '../../services/api';
import { Button } from '../ui/Button';

interface GenerateCertificateModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (certificate: any) => void;
  certificateTypes: CertificateTypeConfig[];
  certificateTemplates: CertificateTemplate[];
}

export const GenerateCertificateModal: React.FC<GenerateCertificateModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  certificateTypes,
  certificateTemplates
}) => {
  const safeTypes = useMemo(
    () => (Array.isArray(certificateTypes) ? certificateTypes : []),
    [certificateTypes]
  );
  const safeTemplates = useMemo(
    () => (Array.isArray(certificateTemplates) ? certificateTemplates : []),
    [certificateTemplates]
  );

  // Wizard Step (1: Type & Student, 2: Academic & Template, 3: Remarks & Custom, 4: Live Preview)
  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);

  // Form State
  const [selectedTypeId, setSelectedTypeId] = useState<string>('');
  const [selectedStudentId, setSelectedStudentId] = useState<string>('');
  const [selectedTemplateId, setSelectedTemplateId] = useState<string>('');
  const [selectedSessionId, setSelectedSessionId] = useState<string>('');
  const [issueDate, setIssueDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [remarks, setRemarks] = useState<string>('');
  const [customFields, setCustomFields] = useState<Record<string, string>>({});

  // Loaded Options
  const [students, setStudents] = useState<any[]>([]);
  const [sessions, setSessions] = useState<AcademicSession[]>([]);
  const [studentSearch, setStudentSearch] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string>('');

  // Preview data
  const [previewData, setPreviewData] = useState<any>(null);
  const [isPreviewLoading, setIsPreviewLoading] = useState<boolean>(false);

  // Load students and sessions on modal open
  useEffect(() => {
    if (!isOpen) return;

    setStep(1);
    setErrorMessage('');
    if (safeTypes.length > 0 && !selectedTypeId) {
      setSelectedTypeId(safeTypes[0].id);
    }

    const loadInitialData = async () => {
      setIsLoading(true);
      try {
        const [studentsRes, sessionsRes] = await Promise.all([
          api.studentReports.search({ limit: 100 }),
          api.academic.getSessions()
        ]);
        const rawStudents = (studentsRes as any)?.data;
        if (Array.isArray(rawStudents)) {
          const formattedStudents = rawStudents.map((s: any) => ({
            ...s,
            id: s.studentId || s.id,
            currentGrade: s.className || s.currentGrade
          }));
          setStudents(formattedStudents);
          if (formattedStudents.length > 0 && !selectedStudentId) {
            setSelectedStudentId(formattedStudents[0].id);
          }
        }
        if (sessionsRes) {
          setSessions(sessionsRes);
          const current = sessionsRes.find((s: any) => s.isCurrent) || sessionsRes[0];
          if (current) setSelectedSessionId(current.id);
        }
      } catch (err: any) {
        console.error('Failed to load students/sessions', err);
      } finally {
        setIsLoading(false);
      }
    };

    loadInitialData();
  }, [isOpen, safeTypes]);

  // Update template selection when certificate type changes
  useEffect(() => {
    if (!selectedTypeId) return;
    const type = safeTypes.find(t => t.id === selectedTypeId);
    if (type?.defaultTemplateId) {
      setSelectedTemplateId(type.defaultTemplateId);
    } else if (safeTemplates.length > 0) {
      setSelectedTemplateId(safeTemplates[0].id);
    }
  }, [selectedTypeId, safeTypes, safeTemplates]);

  // Filtered Students
  const filteredStudents = useMemo(() => {
    if (!studentSearch.trim()) return students.slice(0, 15);
    const q = studentSearch.toLowerCase();
    return students
      .filter(
        s =>
          (s.fullName && s.fullName.toLowerCase().includes(q)) ||
          (s.admissionNumber && s.admissionNumber.toLowerCase().includes(q)) ||
          (s.currentGrade && s.currentGrade.toLowerCase().includes(q))
      )
      .slice(0, 15);
  }, [students, studentSearch]);

  const selectedType = useMemo(
    () => safeTypes.find(t => t.id === selectedTypeId),
    [safeTypes, selectedTypeId]
  );

  const selectedStudent = useMemo(
    () => students.find(s => s.id === selectedStudentId),
    [students, selectedStudentId]
  );

  // Fetch live preview when entering Step 4
  const handleLoadPreview = async () => {
    if (!selectedTypeId || !selectedStudentId) return;
    setIsPreviewLoading(true);
    setErrorMessage('');
    try {
      const res = await api.certificates.preview({
        certificateTypeId: selectedTypeId,
        studentId: selectedStudentId,
        templateId: selectedTemplateId || undefined,
        academicSessionId: selectedSessionId || undefined,
        issueDate,
        remarks: remarks || undefined,
        customFields: Object.keys(customFields).length > 0 ? customFields : undefined
      });
      setPreviewData(res);
      setStep(4);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to generate preview.');
    } finally {
      setIsPreviewLoading(false);
    }
  };

  // Submit Handler
  const handleGenerate = async (andIssue: boolean = false, asDraft: boolean = false) => {
    setIsSubmitting(true);
    setErrorMessage('');
    try {
      // 1. Generate Certificate
      const cert = await api.certificates.generate({
        certificateTypeId: selectedTypeId,
        studentId: selectedStudentId,
        templateId: selectedTemplateId || undefined,
        academicSessionId: selectedSessionId || undefined,
        issueDate,
        remarks: remarks || undefined,
        customFields: Object.keys(customFields).length > 0 ? customFields : undefined,
        asDraft
      });

      // 2. If immediate issue requested
      if (andIssue && cert?.id) {
        const issued = await api.certificates.issue(cert.id, {
          issueDate,
          remarks: remarks || undefined
        });
        onSuccess(issued);
      } else {
        onSuccess(cert);
      }
      onClose();
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to complete certificate generation.');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 w-full max-w-4xl rounded-2xl shadow-2xl overflow-hidden my-4 flex flex-col max-h-[92vh]">
        {/* Modal Top Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/80">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-500/10 rounded-xl border border-indigo-500/20 text-indigo-400">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Generate Official Certificate</h2>
              <p className="text-xs text-slate-400">
                Configure certificate issuance, dynamic placeholders, and verify academic snapshot.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Wizard Steps Stepper Bar */}
        <div className="flex items-center justify-between px-6 py-3 border-b border-slate-800 bg-slate-900/60 text-xs font-semibold">
          {[
            { num: 1, label: 'Type & Student' },
            { num: 2, label: 'Academic & Template' },
            { num: 3, label: 'Custom Variables' },
            { num: 4, label: 'Review & Issue' }
          ].map(s => (
            <div
              key={s.num}
              className={`flex items-center gap-2 ${
                step === s.num
                  ? 'text-indigo-400 font-bold'
                  : step > s.num
                  ? 'text-emerald-400'
                  : 'text-slate-500'
              }`}
            >
              <div
                className={`w-6 h-6 rounded-full flex items-center justify-center text-xs ${
                  step === s.num
                    ? 'bg-indigo-600 text-white'
                    : step > s.num
                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                    : 'bg-slate-800 text-slate-400 border border-slate-700'
                }`}
              >
                {step > s.num ? '✓' : s.num}
              </div>
              <span className="hidden sm:inline">{s.label}</span>
            </div>
          ))}
        </div>

        {/* Error Alert */}
        {errorMessage && (
          <div className="mx-6 mt-4 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Modal Body / Steps */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* STEP 1: Type & Student Selection */}
          {step === 1 && (
            <div className="space-y-6">
              {/* Select Certificate Type */}
              <div>
                <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
                  1. Select Certificate Classification <span className="text-rose-400">*</span>
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                  {safeTypes.map(t => (
                    <button
                      key={t.id}
                      type="button"
                      onClick={() => setSelectedTypeId(t.id)}
                      className={`text-left p-3.5 rounded-xl border transition-all ${
                        selectedTypeId === t.id
                          ? 'bg-indigo-600/15 border-indigo-500 shadow-md shadow-indigo-500/10 text-white'
                          : 'bg-slate-950/40 border-slate-800 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-sm text-white">{t.name}</span>
                        <span className="text-[10px] font-mono font-bold px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                          {t.numberingPrefix}
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 line-clamp-2 mt-1">
                        {t.description || 'Standard institutional certificate.'}
                      </p>
                    </button>
                  ))}
                </div>
              </div>

              {/* Select Student */}
              <div>
                <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
                  2. Select Student Recipient <span className="text-rose-400">*</span>
                </label>

                {/* Search Bar */}
                <div className="relative mb-3">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    placeholder="Search by student full name, admission number, or grade..."
                    value={studentSearch}
                    onChange={e => setStudentSearch(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                  />
                </div>

                {/* Students Radio List */}
                <div className="max-h-60 overflow-y-auto space-y-2 pr-1">
                  {filteredStudents.map(student => (
                    <div
                      key={student.id}
                      onClick={() => setSelectedStudentId(student.id)}
                      className={`p-3 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                        selectedStudentId === student.id
                          ? 'bg-indigo-600/15 border-indigo-500 text-white'
                          : 'bg-slate-950/40 border-slate-800/80 text-slate-300 hover:bg-slate-800/40'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-full bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 flex items-center justify-center font-bold text-xs">
                          {student.fullName ? student.fullName.slice(0, 2).toUpperCase() : 'ST'}
                        </div>
                        <div>
                          <p className="text-sm font-bold text-white">{student.fullName || 'Student'}</p>
                          <p className="text-xs text-slate-400 font-mono">
                            ADM: {student.admissionNumber} • Roll: {student.rollNumber || 'N/A'} • {student.currentGrade || student.gradeLevel || 'Grade 10'}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {selectedStudentId === student.id && (
                          <span className="w-5 h-5 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs">
                            ✓
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
                  {filteredStudents.length === 0 && (
                    <div className="p-8 text-center text-xs text-slate-500">
                      No student records found matching &ldquo;{studentSearch}&rdquo;.
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* STEP 2: Academic & Template Selection */}
          {step === 2 && (
            <div className="space-y-6">
              {/* Selected Summary */}
              <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center justify-between">
                <div>
                  <p className="text-xs text-slate-400">Target Certificate & Recipient</p>
                  <p className="text-sm font-bold text-white">
                    {selectedType?.name} &rarr; <span className="text-indigo-400">{selectedStudent?.fullName}</span> ({selectedStudent?.admissionNumber})
                  </p>
                </div>
              </div>

              {/* Academic Session */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
                    Academic Session <span className="text-rose-400">*</span>
                  </label>
                  <select
                    value={selectedSessionId}
                    onChange={e => setSelectedSessionId(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-indigo-500"
                  >
                    {sessions.map(s => (
                      <option key={s.id} value={s.id}>
                        {s.sessionName || s.name} {s.isCurrent ? '(Current)' : ''}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
                    Official Issue Date <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="date"
                    value={issueDate}
                    onChange={e => setIssueDate(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              {/* Template Selection */}
              <div>
                <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
                  Select Visual Certificate Template <span className="text-rose-400">*</span>
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {safeTemplates.map(tmpl => (
                    <button
                      key={tmpl.id}
                      type="button"
                      onClick={() => setSelectedTemplateId(tmpl.id)}
                      className={`text-left p-4 rounded-xl border transition-all ${
                        selectedTemplateId === tmpl.id
                          ? 'bg-indigo-600/15 border-indigo-500 text-white shadow-md'
                          : 'bg-slate-950/40 border-slate-800 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-sm text-white">{tmpl.name}</span>
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                          {tmpl.orientation} • {tmpl.layoutDesign}
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 mt-1 line-clamp-2">{tmpl.title}</p>
                      <div className="flex items-center gap-2 mt-2 text-[10px] text-slate-500">
                        <span>Signatories: {tmpl.signatories?.length || 2}</span>
                        <span>•</span>
                        <span>QR Enabled: {tmpl.qrCodeEnabled ? 'Yes' : 'No'}</span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* STEP 3: Remarks & Custom Placeholders */}
          {step === 3 && (
            <div className="space-y-6">
              <div>
                <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
                  Special Academic Citation / Remarks (Optional)
                </label>
                <textarea
                  rows={3}
                  placeholder="e.g. Conferred with High Distinction in Mathematics and peer leadership..."
                  value={remarks}
                  onChange={e => setRemarks(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                />
                <p className="text-[11px] text-slate-500 mt-1">
                  This narrative is automatically injected into the <code className="text-indigo-400 font-mono">{'{{remarks}}'}</code> placeholder on the template.
                </p>
              </div>

              {/* Dynamic Context Helpers */}
              <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800 space-y-3">
                <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                  Automatic Dynamic Template Placeholders
                </h4>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-[11px] font-mono text-slate-400">
                  <div className="p-2 rounded bg-slate-900 border border-slate-800">
                    <span className="text-indigo-400 block font-bold">{'{{student_name}}'}</span>
                    <span>{selectedStudent?.fullName}</span>
                  </div>
                  <div className="p-2 rounded bg-slate-900 border border-slate-800">
                    <span className="text-indigo-400 block font-bold">{'{{admission_number}}'}</span>
                    <span>{selectedStudent?.admissionNumber}</span>
                  </div>
                  <div className="p-2 rounded bg-slate-900 border border-slate-800">
                    <span className="text-indigo-400 block font-bold">{'{{class_name}}'}</span>
                    <span>{selectedStudent?.currentGrade || 'Grade 10'}</span>
                  </div>
                  <div className="p-2 rounded bg-slate-900 border border-slate-800">
                    <span className="text-indigo-400 block font-bold">{'{{issue_date}}'}</span>
                    <span>{issueDate}</span>
                  </div>
                  <div className="p-2 rounded bg-slate-900 border border-slate-800">
                    <span className="text-indigo-400 block font-bold">{'{{certificate_number}}'}</span>
                    <span className="text-slate-500">[Auto Generated]</span>
                  </div>
                  <div className="p-2 rounded bg-slate-900 border border-slate-800">
                    <span className="text-indigo-400 block font-bold">{'{{school_name}}'}</span>
                    <span>Sygmate Academy</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* STEP 4: Live Preview & Action Confirmation */}
          {step === 4 && previewData && (
            <div className="space-y-4">
              <div className="p-3 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-xs text-indigo-300 flex items-center justify-between">
                <span>
                  High-fidelity certificate preview generated. Review typography, student context, and signatories below.
                </span>
                <span className="font-mono text-[10px] bg-indigo-500/20 px-2 py-0.5 rounded text-indigo-200">
                  {previewData.previewCertificateNumber}
                </span>
              </div>

              {/* Preview Certificate Box */}
              <div className="bg-amber-50 text-slate-900 rounded-xl p-8 border-4 border-double border-indigo-950 shadow-xl font-serif text-center space-y-4">
                <div className="text-xs uppercase font-extrabold tracking-widest text-indigo-950">
                  {previewData.template?.headerText || 'SYGMATE INTERNATIONAL ACADEMY'}
                </div>
                <div className="text-2xl font-bold uppercase text-indigo-950 font-serif">
                  {previewData.renderedTitle}
                </div>
                {previewData.renderedSubtitle && (
                  <p className="text-xs italic text-slate-600 font-serif">
                    {previewData.renderedSubtitle}
                  </p>
                )}
                <div className="text-xl font-extrabold text-slate-900 border-b border-slate-400 inline-block px-8 pb-1">
                  {previewData.snapshot.student.fullName}
                </div>
                <p className="text-xs font-serif text-slate-700 max-w-xl mx-auto leading-relaxed">
                  {previewData.renderedBody}
                </p>
                {remarks && (
                  <p className="text-xs italic text-slate-600 font-serif">
                    Note: &ldquo;{remarks}&rdquo;
                  </p>
                )}

                <div className="pt-6 border-t border-slate-300 flex justify-between items-end text-xs font-sans text-slate-600 px-4">
                  <div className="text-center">
                    <div className="w-28 border-b border-slate-500 mb-1" />
                    <p className="font-bold text-slate-900">{previewData.template?.signatories?.[0]?.name || 'Principal'}</p>
                    <p className="text-[10px] text-slate-500">{previewData.template?.signatories?.[0]?.title || 'Principal'}</p>
                  </div>
                  <div className="text-[10px] font-mono text-slate-500">
                    [SECURE SERIAL]
                  </div>
                  <div className="text-center">
                    <div className="w-28 border-b border-slate-500 mb-1" />
                    <p className="font-bold text-slate-900">{previewData.template?.signatories?.[1]?.name || 'Registrar'}</p>
                    <p className="text-[10px] text-slate-500">{previewData.template?.signatories?.[1]?.title || 'Registrar'}</p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Bottom Footer / Navigation */}
        <div className="px-6 py-4 border-t border-slate-800 bg-slate-950/80 flex items-center justify-between">
          <div>
            {step > 1 ? (
              <Button
                variant="outline"
                size="sm"
                onClick={() => setStep((step - 1) as any)}
                disabled={isSubmitting || isPreviewLoading}
              >
                <ChevronLeft className="w-4 h-4 mr-1" /> Back
              </Button>
            ) : (
              <Button variant="ghost" size="sm" onClick={onClose}>
                Cancel
              </Button>
            )}
          </div>

          <div className="flex items-center gap-2">
            {step < 3 && (
              <Button
                variant="default"
                size="sm"
                onClick={() => setStep((step + 1) as any)}
                disabled={!selectedTypeId || !selectedStudentId}
                className="bg-indigo-600 hover:bg-indigo-500"
              >
                Continue <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            )}

            {step === 3 && (
              <Button
                variant="default"
                size="sm"
                onClick={handleLoadPreview}
                disabled={isPreviewLoading}
                className="bg-indigo-600 hover:bg-indigo-500"
              >
                {isPreviewLoading ? (
                  'Rendering Preview...'
                ) : (
                  <>
                    <Eye className="w-4 h-4 mr-1.5" /> Preview Certificate
                  </>
                )}
              </Button>
            )}

            {step === 4 && (
              <>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleGenerate(false, true)}
                  disabled={isSubmitting}
                >
                  Save as Draft
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleGenerate(false, false)}
                  disabled={isSubmitting}
                  className="border-indigo-500/40 text-indigo-300 hover:bg-indigo-500/10"
                >
                  Generate Record
                </Button>
                <Button
                  variant="default"
                  size="sm"
                  onClick={() => handleGenerate(true, false)}
                  disabled={isSubmitting}
                  className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold"
                >
                  {isSubmitting ? (
                    'Issuing...'
                  ) : (
                    <>
                      <Send className="w-4 h-4 mr-1.5" /> Generate & Issue
                    </>
                  )}
                </Button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
