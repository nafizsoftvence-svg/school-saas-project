/**
 * Part 15C — Official Certificate Viewer & Print / PDF Modal
 * Sygmate School Management System
 */

import React, { useState } from 'react';
import {
  X,
  Printer,
  Download,
  ShieldCheck,
  Award,
  QrCode,
  Calendar,
  User,
  History,
  Info,
  RefreshCw,
  Ban,
  CheckCircle2,
  Clock,
  Sparkles,
  FileText
} from 'lucide-react';
import { IssuedCertificate } from '../../types';
import { Button } from '../ui/Button';
import { downloadElementPdf, triggerSafePrint } from '../../utils/printPdf.js';

interface CertificateViewerModalProps {
  certificate: IssuedCertificate | null;
  onClose: () => void;
  onIssue?: (cert: IssuedCertificate) => void;
  onReissue?: (cert: IssuedCertificate) => void;
  onRevoke?: (cert: IssuedCertificate) => void;
  onCancel?: (cert: IssuedCertificate) => void;
  userRole?: string;
}

export const CertificateViewerModal: React.FC<CertificateViewerModalProps> = ({
  certificate,
  onClose,
  onIssue,
  onReissue,
  onRevoke,
  onCancel,
  userRole = 'SUPER_ADMIN'
}) => {
  const [activeView, setActiveView] = useState<'certificate' | 'snapshot'>('certificate');
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);

  if (!certificate) return null;

  const template = certificate.templateSnapshot;
  const isLandscape = template?.orientation !== 'PORTRAIT';
  const primaryColor = template?.primaryColor || '#16263B';
  const secondaryColor = template?.secondaryColor || '#D97706';
  const accentColor = template?.accentColor || '#1D64C9';

  const handlePrint = async () => {
    try {
      setIsGeneratingPdf(true);
      const cleanNum = (certificate.certificateNumber || 'certificate').replace(/[^a-zA-Z0-9_-]/g, '_');
      const filename = `${certificate.studentName.replace(/\s+/g, '_')}_${cleanNum}.pdf`;

      await downloadElementPdf('printable-certificate', filename, {
        orientation: isLandscape ? 'landscape' : 'portrait'
      });

      await triggerSafePrint({
        elementOrId: 'printable-certificate',
        fallbackTitle: `Certificate_${cleanNum}`
      });
    } catch (err) {
      console.error('Certificate print/PDF error:', err);
      try {
        window.print();
      } catch {
        // ignore
      }
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  const getStatusBadge = () => {
    switch (certificate.status) {
      case 'ISSUED':
        return (
          <span className="px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5" />
            Officially Issued
          </span>
        );
      case 'APPROVED':
        return (
          <span className="px-3 py-1 rounded-full text-xs font-semibold bg-teal-500/10 text-teal-400 border border-teal-500/20 flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5" />
            Approved by Leadership
          </span>
        );
      case 'PENDING_APPROVAL':
        return (
          <span className="px-3 py-1 rounded-full text-xs font-semibold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5" />
            Pending Approval
          </span>
        );
      case 'VERIFIED':
        return (
          <span className="px-3 py-1 rounded-full text-xs font-semibold bg-sky-500/10 text-sky-400 border border-sky-500/20 flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5" />
            Verified
          </span>
        );
      case 'PENDING_VERIFICATION':
        return (
          <span className="px-3 py-1 rounded-full text-xs font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/20 flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5" />
            Pending Verification
          </span>
        );
      case 'VERIFICATION_REJECTED':
      case 'APPROVAL_REJECTED':
        return (
          <span className="px-3 py-1 rounded-full text-xs font-semibold bg-rose-500/10 text-rose-400 border border-rose-500/20 flex items-center gap-1.5">
            <Ban className="w-3.5 h-3.5" />
            Rejected
          </span>
        );
      case 'DRAFT':
        return (
          <span className="px-3 py-1 rounded-full text-xs font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/20 flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5" />
            Draft
          </span>
        );
      case 'REVOKED':
        return (
          <span className="px-3 py-1 rounded-full text-xs font-semibold bg-rose-500/10 text-rose-400 border border-rose-500/20 flex items-center gap-1.5">
            <Ban className="w-3.5 h-3.5" />
            Revoked
          </span>
        );
      case 'CANCELLED':
        return (
          <span className="px-3 py-1 rounded-full text-xs font-semibold bg-slate-500/10 text-slate-400 border border-slate-500/20 flex items-center gap-1.5">
            <Ban className="w-3.5 h-3.5" />
            Cancelled
          </span>
        );
      default:
        return null;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white border border-slate-200 w-full max-w-5xl rounded-2xl shadow-2xl overflow-hidden my-4 flex flex-col max-h-[94vh]">
        {/* Top Header Bar */}
        <div className="flex flex-wrap items-center justify-between gap-4 px-6 py-4 border-b border-slate-200 bg-white print:hidden">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-sky-50 rounded-xl border border-sky-200 text-sky-700">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2.5">
                <h2 className="text-base sm:text-lg font-bold text-slate-900">
                  {certificate.certificateTypeName}
                </h2>
                {getStatusBadge()}
                {certificate.version > 1 && (
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-sky-50 text-sky-800 border border-sky-200">
                    Version v{certificate.version}
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-600 font-mono mt-0.5">
                Serial No: <span className="text-sky-800 font-bold">{certificate.certificateNumber}</span> • Recipient: <strong className="text-slate-900">{certificate.studentName}</strong> ({certificate.admissionNumber})
              </p>
            </div>
          </div>

          {/* Action Toolbar */}
          <div className="flex items-center gap-2">
            {/* View Switcher Tabs */}
            <div className="flex bg-slate-100 p-0.5 rounded-lg border border-slate-200 text-xs mr-2">
              <button
                onClick={() => setActiveView('certificate')}
                className={`px-3 py-1.5 rounded-md font-semibold transition-colors cursor-pointer ${
                  activeView === 'certificate' ? 'bg-sky-700 text-white shadow-2xs font-bold' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Certificate View
              </button>
              <button
                onClick={() => setActiveView('snapshot')}
                className={`px-3 py-1.5 rounded-md font-semibold transition-colors flex items-center gap-1 cursor-pointer ${
                  activeView === 'snapshot' ? 'bg-sky-700 text-white shadow-2xs font-bold' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Info className="w-3.5 h-3.5" />
                Data Snapshot
              </button>
            </div>

            {/* Print / Save PDF */}
            <button
              onClick={handlePrint}
              disabled={isGeneratingPdf}
              className="flex items-center gap-1.5 px-3.5 py-1.5 bg-sky-700 hover:bg-sky-800 disabled:opacity-50 text-white rounded-lg text-xs font-bold shadow-xs transition-colors cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>{isGeneratingPdf ? 'Generating PDF...' : 'Print / PDF'}</span>
            </button>

            {/* Administration Workflow Actions */}
            {(userRole === 'SUPER_ADMIN' || userRole === 'TEACHER') && (
              <>
                {certificate.status === 'GENERATED' && onIssue && (
                  <button
                    onClick={() => onIssue(certificate)}
                    className="flex items-center gap-1 px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-bold shadow-xs transition-colors cursor-pointer"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    Issue Certificate
                  </button>
                )}
                {certificate.status === 'ISSUED' && onReissue && (
                  <button
                    onClick={() => onReissue(certificate)}
                    className="flex items-center gap-1 px-3 py-1.5 bg-sky-50 hover:bg-sky-100 text-sky-800 border border-sky-200 rounded-lg text-xs font-semibold transition-colors cursor-pointer"
                    title="Safely reissue with updated information"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    Reissue
                  </button>
                )}
                {certificate.status === 'ISSUED' && onRevoke && (
                  <button
                    onClick={() => onRevoke(certificate)}
                    className="flex items-center gap-1 px-2.5 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-lg text-xs font-semibold transition-colors cursor-pointer"
                    title="Officially revoke certificate"
                  >
                    <Ban className="w-3.5 h-3.5" />
                    Revoke
                  </button>
                )}
                {(certificate.status === 'DRAFT' || certificate.status === 'GENERATED') && onCancel && (
                  <button
                    onClick={() => onCancel(certificate)}
                    className="flex items-center gap-1 px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold transition-colors cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                    Cancel
                  </button>
                )}
              </>
            )}

            <button
              onClick={onClose}
              className="p-1.5 text-slate-500 hover:text-slate-800 rounded-lg hover:bg-slate-100 transition-colors ml-1 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Main View */}
        <div className="flex-1 overflow-y-auto bg-slate-100 p-4 sm:p-8 flex flex-col items-center justify-center">
          {activeView === 'certificate' ? (
            /* Certificate Printable Board */
            <div
              id="printable-certificate"
              className={`w-full max-w-4xl bg-amber-50 text-slate-900 rounded-xl shadow-2xl relative border-8 border-double overflow-hidden print:border-none print:shadow-none print:max-w-none print:m-0 print:p-0 ${
                isLandscape ? 'aspect-[1.414/1] p-6 sm:p-12' : 'aspect-[1/1.414] p-6 sm:p-12'
              }`}
              style={{
                borderColor: primaryColor,
                backgroundImage: 'radial-gradient(#d4af37 0.5px, transparent 0.5px)',
                backgroundSize: '24px 24px'
              }}
            >
              {/* Inner Ornamental Border */}
              <div
                className="w-full h-full border-2 border-dashed rounded-lg p-6 sm:p-8 flex flex-col justify-between relative"
                style={{ borderColor: secondaryColor }}
              >
                {/* Corner Accents */}
                <div className="absolute top-2 left-2 w-4 h-4 border-t-2 border-l-2" style={{ borderColor: secondaryColor }} />
                <div className="absolute top-2 right-2 w-4 h-4 border-t-2 border-r-2" style={{ borderColor: secondaryColor }} />
                <div className="absolute bottom-2 left-2 w-4 h-4 border-b-2 border-l-2" style={{ borderColor: secondaryColor }} />
                <div className="absolute bottom-2 right-2 w-4 h-4 border-b-2 border-r-2" style={{ borderColor: secondaryColor }} />

                {/* Status Watermark for Cancelled or Revoked */}
                {(certificate.status === 'CANCELLED' || certificate.status === 'REVOKED') && (
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-10">
                    <span className="text-6xl sm:text-8xl font-black uppercase text-rose-500/20 transform -rotate-25 tracking-widest border-8 border-rose-500/20 px-8 py-4 rounded-3xl">
                      {certificate.status}
                    </span>
                  </div>
                )}

                {/* Top Institutional Crest & Header */}
                <div className="text-center space-y-2">
                  <div className="flex items-center justify-center gap-2">
                    <div className="w-12 h-12 rounded-full bg-slate-900 text-amber-400 flex items-center justify-center shadow-md border-2 border-amber-500">
                      <ShieldCheck className="w-7 h-7" />
                    </div>
                  </div>
                  <h4
                    className="font-serif tracking-widest text-xs uppercase font-extrabold"
                    style={{ color: primaryColor }}
                  >
                    {template?.headerText || certificate.dataSnapshot.school.name || 'SYGMATE INTERNATIONAL ACADEMY'}
                  </h4>
                  <div className="w-28 h-0.5 mx-auto" style={{ backgroundColor: secondaryColor }} />

                  {/* Serial & Metadata Ribbon */}
                  <div className="flex justify-between items-center text-[10px] sm:text-xs font-mono text-slate-600 px-2 pt-1">
                    <span>
                      <strong className="text-slate-800">REF:</strong> {certificate.certificateNumber}
                    </span>
                    <span>
                      <strong className="text-slate-800">ISSUE DATE:</strong> {certificate.issueDate}
                    </span>
                  </div>

                  {/* Title & Subtitle */}
                  <h2
                    className="font-serif text-2xl sm:text-3xl font-extrabold tracking-wide uppercase pt-2"
                    style={{ color: primaryColor }}
                  >
                    {certificate.renderedTitle}
                  </h2>
                  {certificate.renderedSubtitle && (
                    <p className="font-serif italic text-xs sm:text-sm text-slate-600 max-w-lg mx-auto">
                      {certificate.renderedSubtitle}
                    </p>
                  )}
                </div>

                {/* Recipient Full Name */}
                <div className="text-center my-3 sm:my-5 space-y-3">
                  <div className="inline-block border-b-2 border-slate-600 px-8 sm:px-12 pb-1 font-serif text-2xl sm:text-3xl font-black text-slate-900 tracking-wider">
                    {certificate.studentName}
                  </div>
                  <p className="text-xs sm:text-sm text-slate-600 font-mono">
                    Admission ID: <span className="font-bold text-slate-800">{certificate.admissionNumber}</span> • Academic Session: <span className="font-bold text-slate-800">{certificate.academicSessionName}</span>
                  </p>

                  {/* Rendered Body Narrative */}
                  <p className="text-xs sm:text-sm font-serif text-slate-800 max-w-2xl mx-auto leading-relaxed px-4 pt-1">
                    {certificate.renderedBody}
                  </p>

                  {certificate.remarks && (
                    <p className="text-xs italic text-slate-600 font-serif max-w-xl mx-auto">
                      Special Note: &ldquo;{certificate.remarks}&rdquo;
                    </p>
                  )}
                </div>

                {/* Signatories, Board Seal & QR Area */}
                <div className="pt-4 border-t border-slate-300">
                  <div className="flex items-end justify-between gap-4">
                    {/* Left Signatory */}
                    {template?.signatories?.[0] ? (
                      <div className="text-center space-y-1">
                        <div className="w-28 sm:w-36 h-8 border-b border-slate-600 mx-auto flex items-end justify-center">
                          <span className="font-serif italic text-[11px] text-slate-500">[Official Signature]</span>
                        </div>
                        <p className="text-xs font-bold text-slate-900">{template.signatories[0].name}</p>
                        <p className="text-[10px] uppercase tracking-wider text-slate-500">{template.signatories[0].title}</p>
                      </div>
                    ) : (
                      <div className="text-center space-y-1">
                        <div className="w-28 sm:w-36 h-8 border-b border-slate-600 mx-auto" />
                        <p className="text-xs font-bold text-slate-900">Dr. Evelyn Montgomery</p>
                        <p className="text-[10px] uppercase tracking-wider text-slate-500">Principal</p>
                      </div>
                    )}

                    {/* Center Seal / QR verification code */}
                    <div className="text-center space-y-1">
                      <div className="w-14 h-14 bg-white p-1 rounded border border-slate-300 mx-auto shadow-sm flex items-center justify-center">
                        {certificate.qrCodeDataUrl ? (
                          <img src={certificate.qrCodeDataUrl} alt="Official Verification QR" className="w-12 h-12 object-contain" />
                        ) : (
                          <QrCode className="w-10 h-10 text-slate-900" />
                        )}
                      </div>
                      <span className="text-[7.5px] font-mono text-slate-500 block uppercase max-w-[120px] truncate" title={certificate.digitalVerificationReference || certificate.qrVerificationCode}>
                        {certificate.digitalVerificationReference || certificate.qrVerificationCode}
                      </span>
                    </div>

                    {/* Right Signatory */}
                    {template?.signatories?.[1] ? (
                      <div className="text-center space-y-1">
                        <div className="w-28 sm:w-36 h-8 border-b border-slate-600 mx-auto flex items-end justify-center">
                          <span className="font-serif italic text-[11px] text-slate-500">[Official Signature]</span>
                        </div>
                        <p className="text-xs font-bold text-slate-900">{template.signatories[1].name}</p>
                        <p className="text-[10px] uppercase tracking-wider text-slate-500">{template.signatories[1].title}</p>
                      </div>
                    ) : (
                      <div className="text-center space-y-1">
                        <div className="w-28 sm:w-36 h-8 border-b border-slate-600 mx-auto" />
                        <p className="text-xs font-bold text-slate-900">Academic Registrar</p>
                        <p className="text-[10px] uppercase tracking-wider text-slate-500">Academic Affairs</p>
                      </div>
                    )}
                  </div>

                  {/* Rendered Footer */}
                  {certificate.renderedFooter && (
                    <p className="text-[9px] text-slate-500 text-center mt-3 pt-2 border-t border-slate-200 font-mono">
                      {certificate.renderedFooter}
                    </p>
                  )}
                </div>
              </div>
            </div>
          ) : (
            /* Immutable Data Snapshot Inspector */
            <div className="w-full max-w-3xl bg-white border border-slate-200 rounded-2xl p-6 space-y-6 text-sm shadow-xs">
              <div className="flex items-center justify-between pb-4 border-b border-slate-200">
                <div>
                  <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                    <ShieldCheck className="w-5 h-5 text-sky-700" />
                    Immutable Issuance Snapshot
                  </h3>
                  <p className="text-xs text-slate-600 font-medium">
                    Preserves the student and academic profile captured at the moment this certificate was minted.
                  </p>
                </div>
                <span className="font-mono text-xs text-sky-800 font-bold bg-sky-50 px-3 py-1 rounded-full border border-sky-200">
                  Version v{certificate.version}
                </span>
              </div>

              {/* Snapshot Details Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
                  <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider">Student Profile Snapshot</h4>
                  <div className="space-y-1.5 text-xs">
                    <p><span className="text-slate-500 font-medium">Full Name:</span> <strong className="text-slate-900">{certificate.dataSnapshot.student.fullName}</strong></p>
                    <p><span className="text-slate-500 font-medium">Admission No:</span> <span className="font-mono text-slate-800 font-semibold">{certificate.dataSnapshot.student.admissionNumber}</span></p>
                    <p><span className="text-slate-500 font-medium">Roll Number:</span> <span className="font-mono text-slate-800 font-semibold">{certificate.dataSnapshot.student.rollNumber || 'N/A'}</span></p>
                    <p><span className="text-slate-500 font-medium">Class & Section:</span> <span className="text-slate-800 font-semibold">{certificate.dataSnapshot.student.className} - {certificate.dataSnapshot.student.sectionName}</span></p>
                    <p><span className="text-slate-500 font-medium">Academic Session:</span> <span className="text-slate-800 font-semibold">{certificate.dataSnapshot.student.academicSession}</span></p>
                    <p><span className="text-slate-500 font-medium">Guardian Name:</span> <span className="text-slate-800 font-semibold">{certificate.dataSnapshot.student.guardianName || 'N/A'}</span></p>
                  </div>
                </div>

                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
                  <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider">Issuance & Audit Metadata</h4>
                  <div className="space-y-1.5 text-xs">
                    <p><span className="text-slate-500 font-medium">Certificate Status:</span> <strong className="text-sky-800 font-bold">{certificate.status}</strong></p>
                    <p><span className="text-slate-500 font-medium">Issue Date:</span> <span className="font-mono text-slate-800 font-semibold">{certificate.issueDate}</span></p>
                    <p><span className="text-slate-500 font-medium">Issued By:</span> <span className="text-slate-800 font-semibold">{certificate.issuedByName || 'Administrator'}</span></p>
                    <p><span className="text-slate-500 font-medium">Issued Timestamp:</span> <span className="font-mono text-slate-800 font-semibold">{certificate.issuedAt || certificate.createdAt}</span></p>
                    <p><span className="text-slate-500 font-medium">Vault Document ID:</span> <span className="font-mono text-slate-800 font-semibold">{certificate.documentId || 'Linked'}</span></p>
                    {certificate.reissueReason && (
                      <p><span className="text-slate-500 font-medium">Reissue Reason:</span> <span className="text-amber-800 font-semibold">{certificate.reissueReason}</span></p>
                    )}
                    {certificate.revocationReason && (
                      <p><span className="text-slate-500 font-medium">Revocation Reason:</span> <span className="text-rose-800 font-semibold">{certificate.revocationReason}</span></p>
                    )}
                  </div>
                </div>
              </div>

              {/* Resolved Variables Table */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
                <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider">Resolved Dynamic Variables</h4>
                <div className="max-h-48 overflow-y-auto space-y-1">
                  {Object.entries(certificate.dataSnapshot.variables).map(([k, v]) => (
                    <div key={k} className="flex justify-between items-center py-1.5 border-b border-slate-200 text-xs">
                      <span className="font-mono text-sky-800 font-bold">{`{{${k}}}`}</span>
                      <span className="text-slate-800 text-right max-w-md truncate font-medium">{v || '—'}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Bottom Footer */}
        <div className="p-4 border-t border-slate-200 bg-white flex items-center justify-between text-xs text-slate-600 print:hidden">
          <span>
            Certificate Generation & Issuance Layer • Sygmate Core
          </span>
          <Button size="sm" variant="outline" onClick={onClose}>
            Close
          </Button>
        </div>
      </div>
    </div>
  );
};
