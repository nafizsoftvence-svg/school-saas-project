/**
 * Part 15A — Foundational Certificate Template Preview Modal
 * Visual layout and schema preview for certificate templates
 * Sygmate School Management System
 */

import React from 'react';
import {
  X,
  Award,
  QrCode,
  CheckCircle2,
  FileCheck,
  Building2,
  Shield,
  Printer,
  Sparkles
} from 'lucide-react';
import { CertificateTemplate } from '../../types';
import { Button } from '../ui/Button';

interface CertificateTemplatePreviewModalProps {
  template: CertificateTemplate;
  onClose: () => void;
}

export const CertificateTemplatePreviewModal: React.FC<CertificateTemplatePreviewModalProps> = ({
  template,
  onClose
}) => {
  const isLandscape = template.orientation === 'LANDSCAPE';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 backdrop-blur-md p-4 overflow-y-auto">
      <div className="relative w-full max-w-5xl bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden my-6 flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-slate-800 bg-slate-900/80">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-bold text-white">{template.name}</h3>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/10 text-amber-400 border border-amber-500/20">
                  {template.layoutDesign}
                </span>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-slate-300 border border-slate-700">
                  {template.orientation} • {template.dimensions.width}x{template.dimensions.height}{template.dimensions.unit}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Target Entity: <strong className="text-slate-300">{template.entityType}</strong> • Category: <strong className="text-slate-300">{template.category}</strong> • Version: v{template.version}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Certificate Preview Canvas */}
        <div className="p-6 md:p-8 overflow-y-auto flex-1 bg-slate-950/90 flex flex-col items-center justify-center">
          {/* Certificate Board */}
          <div
            className={`w-full max-w-3xl bg-amber-50 text-slate-900 rounded-xl shadow-2xl relative border-8 border-double overflow-hidden transition-all ${
              isLandscape ? 'aspect-[1.414/1] p-8 md:p-12' : 'aspect-[1/1.414] p-8 md:p-12'
            }`}
            style={{
              borderColor: template.primaryColor || '#1e3a8a',
              backgroundImage: 'radial-gradient(#d4af37 0.5px, transparent 0.5px)',
              backgroundSize: '24px 24px'
            }}
          >
            {/* Ornamental Inner Border */}
            <div
              className="w-full h-full border-2 border-dashed rounded-lg p-6 flex flex-col justify-between relative"
              style={{ borderColor: template.secondaryColor || '#d97706' }}
            >
              {/* Corner Ornaments */}
              <div className="absolute top-2 left-2 w-4 h-4 border-t-2 border-l-2" style={{ borderColor: template.secondaryColor }} />
              <div className="absolute top-2 right-2 w-4 h-4 border-t-2 border-r-2" style={{ borderColor: template.secondaryColor }} />
              <div className="absolute bottom-2 left-2 w-4 h-4 border-b-2 border-l-2" style={{ borderColor: template.secondaryColor }} />
              <div className="absolute bottom-2 right-2 w-4 h-4 border-b-2 border-r-2" style={{ borderColor: template.secondaryColor }} />

              {/* Certificate Header & Crest */}
              <div className="text-center space-y-2">
                <div className="flex items-center justify-center gap-2">
                  <div className="w-10 h-10 rounded-full bg-slate-900 text-amber-400 flex items-center justify-center shadow-md">
                    <Shield className="w-6 h-6" />
                  </div>
                </div>
                <h4
                  className="font-serif tracking-widest text-xs uppercase font-bold"
                  style={{ color: template.primaryColor }}
                >
                  {template.headerText || 'SYGMATE INTERNATIONAL ACADEMY'}
                </h4>
                <div className="w-24 h-0.5 mx-auto" style={{ backgroundColor: template.secondaryColor }} />
                <h2
                  className="font-serif text-2xl md:text-3xl font-extrabold tracking-wide uppercase pt-1"
                  style={{ color: template.primaryColor }}
                >
                  {template.title}
                </h2>
                {template.subtitle && (
                  <p className="font-serif italic text-xs text-slate-600 max-w-lg mx-auto">
                    {template.subtitle}
                  </p>
                )}
              </div>

              {/* Certificate Recipient Placeholder Body */}
              <div className="text-center my-4 space-y-3">
                <div className="inline-block border-b-2 border-slate-400 px-8 pb-1 font-serif text-xl md:text-2xl font-bold text-slate-900 tracking-wider">
                  [RECIPIENT FULL NAME]
                </div>
                <p className="text-xs md:text-sm font-serif text-slate-700 max-w-xl mx-auto leading-relaxed">
                  {template.bodyTemplate}
                </p>
              </div>

              {/* Certificate Footer, Signatories & QR */}
              <div className="pt-4 border-t border-slate-300">
                <div className="flex items-end justify-between gap-4">
                  {/* Left Signatory */}
                  {template.signatories[0] && (
                    <div className="text-center space-y-1">
                      <div className="w-28 md:w-36 h-8 border-b border-slate-600 mx-auto flex items-end justify-center">
                        <span className="font-serif italic text-[11px] text-slate-500">[Official Signature]</span>
                      </div>
                      <p className="text-xs font-bold text-slate-900">{template.signatories[0].name}</p>
                      <p className="text-[10px] uppercase tracking-wider text-slate-500">{template.signatories[0].title}</p>
                    </div>
                  )}

                  {/* Center QR & Seal */}
                  <div className="text-center space-y-1">
                    {template.qrCodeEnabled ? (
                      <div className="w-12 h-12 bg-white p-1 rounded border border-slate-300 mx-auto shadow-sm flex items-center justify-center">
                        <QrCode className="w-10 h-10 text-slate-900" />
                      </div>
                    ) : (
                      <div className="w-10 h-10 rounded-full border-2 border-amber-600 mx-auto flex items-center justify-center">
                        <Award className="w-6 h-6 text-amber-600" />
                      </div>
                    )}
                    <span className="text-[9px] font-mono text-slate-500 block uppercase">
                      SECURE QR VERIFICATION
                    </span>
                  </div>

                  {/* Right Signatory */}
                  {template.signatories[1] ? (
                    <div className="text-center space-y-1">
                      <div className="w-28 md:w-36 h-8 border-b border-slate-600 mx-auto flex items-end justify-center">
                        <span className="font-serif italic text-[11px] text-slate-500">[Official Signature]</span>
                      </div>
                      <p className="text-xs font-bold text-slate-900">{template.signatories[1].name}</p>
                      <p className="text-[10px] uppercase tracking-wider text-slate-500">{template.signatories[1].title}</p>
                    </div>
                  ) : (
                    <div className="text-center space-y-1">
                      <div className="w-28 md:w-36 h-8 border-b border-slate-600 mx-auto" />
                      <p className="text-xs font-bold text-slate-900">Registrar</p>
                      <p className="text-[10px] uppercase tracking-wider text-slate-500">Board Seal</p>
                    </div>
                  )}
                </div>

                {template.footerText && (
                  <p className="text-[9px] text-slate-500 text-center mt-3 pt-2 border-t border-slate-200 font-mono">
                    {template.footerText}
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-900 flex items-center justify-between">
          <div className="text-xs text-slate-400">
            Certificate & Document Management Foundation • Part 15A
          </div>
          <Button size="md" variant="default" onClick={onClose} className="bg-indigo-600 hover:bg-indigo-500">
            Close Preview
          </Button>
        </div>
      </div>
    </div>
  );
};
