/**
 * Part 15A — Upload New Document Version Modal
 * Sygmate School Management System
 */

import React, { useState, useRef } from 'react';
import {
  X,
  Upload,
  FileText,
  AlertTriangle,
  CheckCircle2,
  History,
  ArrowRight
} from 'lucide-react';
import { ManagedDocument, UploadDocumentVersionPayload } from '../../types';
import { Button } from '../ui/Button';

interface UploadVersionModalProps {
  document: ManagedDocument;
  onClose: () => void;
  onSuccess: (updatedDoc: ManagedDocument) => void;
}

export const UploadVersionModal: React.FC<UploadVersionModalProps> = ({
  document,
  onClose,
  onSuccess
}) => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [fileDataUrl, setFileDataUrl] = useState<string>('');
  const [changeNotes, setChangeNotes] = useState<string>('');
  const [fileError, setFileError] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [generalError, setGeneralError] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const currentVersion = document.version || 1;
  const nextVersion = currentVersion + 1;

  const processFile = (file: File) => {
    setFileError(null);
    const maxBytes = 15 * 1024 * 1024; // 15MB
    const allowedExts = ['pdf', 'jpg', 'jpeg', 'png', 'webp', 'doc', 'docx'];
    const ext = file.name.split('.').pop()?.toLowerCase() || '';

    if (!allowedExts.includes(ext)) {
      setFileError(`Invalid format .${ext}. Permitted formats: ${allowedExts.join(', ')}`);
      return;
    }

    if (file.size > maxBytes) {
      setFileError(`File exceeds maximum size limit of 15 MB.`);
      return;
    }

    setSelectedFile(file);
    const reader = new FileReader();
    reader.onload = (e) => {
      setFileDataUrl((e.target?.result as string) || '');
    };
    reader.readAsDataURL(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setGeneralError(null);

    if (!selectedFile) {
      setGeneralError('Please select a replacement file for this new version.');
      return;
    }

    setIsSubmitting(true);
    try {
      const token = localStorage.getItem('sygmate_auth_token') || localStorage.getItem('token');
      const payload: UploadDocumentVersionPayload = {
        fileName: selectedFile.name,
        fileData: fileDataUrl,
        fileType: selectedFile.type || selectedFile.name.split('.').pop() || 'application/pdf',
        fileSizeBytes: selectedFile.size,
        changeNotes: changeNotes.trim() || `Revision v${nextVersion} uploaded.`
      };

      const res = await fetch(`/api/documents/${document.id}/version`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {})
        },
        body: JSON.stringify(payload)
      });

      const json = await res.json();
      if (!res.ok) {
        throw new Error(json.error || 'Failed to upload document revision.');
      }

      onSuccess(json.data);
      onClose();
    } catch (err: any) {
      setGeneralError(err.message || 'An unexpected error occurred.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-slate-800 bg-slate-900/60">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400">
              <History className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">Upload New Revision</h3>
              <p className="text-xs text-slate-400 truncate max-w-[280px]">
                {document.documentTitle}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {generalError && (
          <div className="m-6 p-4 rounded-xl bg-red-500/10 border border-red-500/20 flex items-start gap-3 text-red-300 text-sm">
            <AlertTriangle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
            <div>{generalError}</div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {/* Version Stepper Badge */}
          <div className="p-3 rounded-xl bg-slate-800/40 border border-slate-800 flex items-center justify-between">
            <div className="text-xs text-slate-400">
              Current active version: <strong className="text-slate-200">v{currentVersion}</strong>
            </div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded text-xs bg-slate-800 text-slate-400">v{currentVersion}</span>
              <ArrowRight className="w-3.5 h-3.5 text-indigo-400" />
              <span className="px-2 py-0.5 rounded text-xs font-bold bg-indigo-600 text-white">v{nextVersion}</span>
            </div>
          </div>

          {/* Secure File Dropzone */}
          <div>
            <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider block mb-1">
              Replacement File <span className="text-rose-400">*</span>
            </label>
            <div
              onDragOver={(e) => {
                e.preventDefault();
                setIsDragging(true);
              }}
              onDragLeave={() => setIsDragging(false)}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`p-6 rounded-2xl border-2 border-dashed cursor-pointer text-center transition-all ${
                isDragging
                  ? 'border-indigo-500 bg-indigo-500/10'
                  : selectedFile
                  ? 'border-emerald-500/50 bg-emerald-500/5'
                  : 'border-slate-700 hover:border-indigo-500/60 bg-slate-800/40 hover:bg-slate-800/70'
              }`}
            >
              <input
                ref={fileInputRef}
                type="file"
                className="hidden"
                accept=".pdf,.jpg,.jpeg,.png,.webp,.doc,.docx"
                onChange={(e) => {
                  if (e.target.files && e.target.files[0]) {
                    processFile(e.target.files[0]);
                  }
                }}
              />

              {selectedFile ? (
                <div className="flex items-center justify-center gap-3">
                  <div className="p-2.5 rounded-xl bg-emerald-500/10 text-emerald-400">
                    <CheckCircle2 className="w-6 h-6" />
                  </div>
                  <div className="text-left">
                    <span className="text-sm font-bold text-white block">{selectedFile.name}</span>
                    <span className="text-xs text-slate-400">
                      {(selectedFile.size / (1024 * 1024)).toFixed(2)} MB • Ready to commit as v{nextVersion}
                    </span>
                  </div>
                </div>
              ) : (
                <div className="space-y-2">
                  <Upload className="w-8 h-8 text-indigo-400 mx-auto" />
                  <p className="text-sm font-semibold text-white">
                    Click to select replacement file or drag & drop
                  </p>
                  <p className="text-xs text-slate-400">
                    Previous version v{currentVersion} will be preserved in immutable history
                  </p>
                </div>
              )}
            </div>

            {fileError && (
              <p className="text-xs text-rose-400 mt-1 flex items-center gap-1">
                <AlertTriangle className="w-3.5 h-3.5" />
                {fileError}
              </p>
            )}
          </div>

          {/* Change Notes */}
          <div>
            <label className="text-xs font-medium text-slate-300 block mb-1">
              Revision / Change Notes (Recommended)
            </label>
            <textarea
              value={changeNotes}
              onChange={(e) => setChangeNotes(e.target.value)}
              placeholder="e.g. Replaced blurry scan with certified notary copy requested by registrar..."
              rows={3}
              className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* Actions */}
          <div className="flex justify-end gap-3 pt-3 border-t border-slate-800">
            <Button size="md" variant="outline" type="button" onClick={onClose} disabled={isSubmitting}>
              Cancel
            </Button>
            <Button
              size="md"
              variant="default"
              type="submit"
              disabled={isSubmitting || !selectedFile}
              className="bg-indigo-600 hover:bg-indigo-500 text-white flex items-center gap-2 shadow"
            >
              <Upload className="w-4 h-4" />
              {isSubmitting ? 'Uploading Revision...' : `Commit Version ${nextVersion}`}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};
