/**
 * Part 15C — Cancel / Revoke Certificate Modal
 * Enforces status-based lifecycle transitions with mandatory reason tracking
 * Sygmate School Management System
 */

import React, { useState } from 'react';
import { X, Ban, AlertTriangle, ShieldAlert } from 'lucide-react';
import { IssuedCertificate } from '../../types';
import { api } from '../../services/api';
import { Button } from '../ui/Button';

interface RevokeCancelCertificateModalProps {
  isOpen: boolean;
  onClose: () => void;
  certificate: IssuedCertificate | null;
  mode: 'CANCEL' | 'REVOKE';
  onSuccess: (updated: IssuedCertificate) => void;
}

export const RevokeCancelCertificateModal: React.FC<RevokeCancelCertificateModalProps> = ({
  isOpen,
  onClose,
  certificate,
  mode,
  onSuccess
}) => {
  const [reason, setReason] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string>('');

  if (!isOpen || !certificate) return null;

  const isRevoke = mode === 'REVOKE';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reason.trim()) {
      setErrorMessage(`A formal explanation for ${isRevoke ? 'revoking' : 'cancelling'} this certificate is required.`);
      return;
    }

    setIsSubmitting(true);
    setErrorMessage('');
    try {
      const res = isRevoke
        ? await api.certificates.revoke(certificate.id, reason.trim())
        : await api.certificates.cancel(certificate.id, reason.trim());

      onSuccess(res);
      onClose();
    } catch (err: any) {
      setErrorMessage(err.message || `Failed to ${mode.toLowerCase()} certificate.`);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 w-full max-w-md rounded-2xl shadow-2xl overflow-hidden my-4">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/80">
          <div className="flex items-center gap-3">
            <div className={`p-2.5 rounded-xl border ${isRevoke ? 'bg-rose-500/10 border-rose-500/20 text-rose-400' : 'bg-amber-500/10 border-amber-500/20 text-amber-400'}`}>
              <Ban className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">
                {isRevoke ? 'Revoke Issued Certificate' : 'Cancel Certificate'}
              </h3>
              <p className="text-xs text-slate-400 font-mono">
                Serial: <strong className={isRevoke ? 'text-rose-400' : 'text-amber-400'}>{certificate.certificateNumber}</strong>
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {/* Target Student Info Card */}
          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 text-xs flex justify-between items-center">
            <div>
              <span className="text-slate-400 block">Recipient:</span>
              <strong className="text-white text-sm">{certificate.studentName}</strong>
              <span className="text-slate-400 font-mono ml-2">({certificate.admissionNumber})</span>
            </div>
            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-slate-300">
              {certificate.certificateTypeName}
            </span>
          </div>

          {/* Warning */}
          <div className={`p-3 rounded-xl border text-xs flex gap-2.5 ${isRevoke ? 'bg-rose-500/10 border-rose-500/25 text-rose-300' : 'bg-amber-500/10 border-amber-500/25 text-amber-300'}`}>
            <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
            <p>
              {isRevoke
                ? 'Revocation marks this certificate as permanently invalid. The record will remain in the institutional audit vault with a permanent revocation badge.'
                : 'Cancelling will invalidate this draft or generated record before official distribution.'}
            </p>
          </div>

          {errorMessage && (
            <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
              {errorMessage}
            </div>
          )}

          {/* Reason Input */}
          <div>
            <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
              Mandatory Reason <span className="text-rose-400">*</span>
            </label>
            <textarea
              rows={3}
              required
              placeholder={isRevoke ? 'e.g. Disciplinary revocation, credential falsification, or erroneous board ratification...' : 'e.g. Generated under wrong class stream or student transfer...'}
              value={reason}
              onChange={e => setReason(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-rose-500"
            />
          </div>

          {/* Actions */}
          <div className="pt-2 flex items-center justify-end gap-2">
            <Button variant="ghost" size="sm" type="button" onClick={onClose}>
              Go Back
            </Button>
            <Button
              variant="default"
              size="sm"
              type="submit"
              disabled={isSubmitting || !reason.trim()}
              className={isRevoke ? 'bg-rose-600 hover:bg-rose-500 text-white font-semibold' : 'bg-amber-600 hover:bg-amber-500 text-white font-semibold'}
            >
              {isSubmitting ? 'Processing...' : isRevoke ? 'Revoke Certificate' : 'Cancel Certificate'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};
