/**
 * Part 15E — Universal Entity Document Checklist & Verification Modal
 * Sygmate School Management System
 * Universal checklist component for Teachers, Staff, Parents/Guardians, and Institutional School records.
 */

import React, { useState, useEffect } from 'react';
import {
  X,
  ShieldCheck,
  FileText,
  AlertTriangle,
  CheckCircle2,
  Clock,
  XCircle,
  Upload,
  Download,
  Eye,
  RefreshCw,
  Calendar,
  Layers,
  Award,
  ChevronRight,
  User,
  Building2,
  AlertCircle,
  GraduationCap
} from 'lucide-react';
import {
  EntityDocumentChecklistSummary,
  EntityDocumentChecklistItem,
  DocumentEntityType,
  ManagedDocument,
  DocumentTypeConfig
} from '../../types/index.js';
import { api } from '../../services/api.js';
import { Button } from '../ui/Button.js';
import { Badge } from '../ui/Badge.js';
import { LoadingSpinner } from '../ui/LoadingSpinner.js';

interface EntityDocumentChecklistModalProps {
  entityType: DocumentEntityType;
  entityId: string;
  entityName?: string;
  isOpen: boolean;
  onClose: () => void;
  canVerify?: boolean; // whether current user can verify/reject (e.g. Admin / HR)
  onDocumentUpdated?: () => void;
}

export const EntityDocumentChecklistModal: React.FC<EntityDocumentChecklistModalProps> = ({
  entityType,
  entityId,
  entityName,
  isOpen,
  onClose,
  canVerify = false,
  onDocumentUpdated
}) => {
  const [loading, setLoading] = useState(true);
  const [checklist, setChecklist] = useState<EntityDocumentChecklistSummary | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Review & Rejection state
  const [reviewingDoc, setReviewingDoc] = useState<ManagedDocument | null>(null);
  const [rejectionReason, setRejectionReason] = useState('');
  const [verificationRemarks, setVerificationRemarks] = useState('');
  const [isRejecting, setIsRejecting] = useState(false);
  const [processingAction, setProcessingAction] = useState(false);

  // Quick Upload state
  const [uploadingItem, setUploadingItem] = useState<EntityDocumentChecklistItem | null>(null);
  const [uploadTitle, setUploadTitle] = useState('');
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [uploadFileUrl, setUploadFileUrl] = useState('');
  const [uploadRefNumber, setUploadRefNumber] = useState('');
  const [uploadExpiryDate, setUploadExpiryDate] = useState('');
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);

  const fetchChecklist = async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await api.documents.getChecklist(entityType, entityId);
      if (res) {
        setChecklist((res as any)?.data || res);
      }
    } catch (err: any) {
      setError(err.message || 'Failed to load document checklist.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen && entityId) {
      fetchChecklist();
    }
  }, [isOpen, entityType, entityId]);

  if (!isOpen) return null;

  const handleStartUpload = (item: EntityDocumentChecklistItem) => {
    setUploadingItem(item);
    setUploadTitle(item.documentTypeName);
    setUploadFile(null);
    setUploadFileUrl('');
    setUploadRefNumber('');
    setUploadExpiryDate('');
    setUploadError(null);
  };

  const handleUploadSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!uploadingItem) return;
    setUploadError(null);

    const title = uploadTitle.trim() || uploadingItem.documentTypeName;
    const fileUrl =
      uploadFileUrl.trim() ||
      (uploadFile
        ? URL.createObjectURL(uploadFile)
        : `https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&q=80&w=800`);

    const fileName = uploadFile?.name || `${title.toLowerCase().replace(/\s+/g, '_')}.pdf`;

    try {
      setUploading(true);
      await api.documents.createDocument({
        documentTypeId: uploadingItem.documentTypeId,
        entityType,
        entityId,
        documentTitle: title,
        referenceNumber: uploadRefNumber.trim() || undefined,
        expiryDate: uploadExpiryDate.trim() || undefined,
        fileName,
        fileUrl,
        fileType: uploadFile?.type || 'application/pdf',
        fileSize: uploadFile ? `${(uploadFile.size / 1024 / 1024).toFixed(1)} MB` : '1.2 MB'
      });

      setUploadingItem(null);
      await fetchChecklist();
      if (onDocumentUpdated) onDocumentUpdated();
    } catch (err: any) {
      setUploadError(err.message || 'Failed to upload document.');
    } finally {
      setUploading(false);
    }
  };

  const handleVerifyDecision = async (status: 'VERIFIED' | 'REJECTED') => {
    if (!reviewingDoc) return;
    setError(null);

    if (status === 'REJECTED' && !rejectionReason.trim()) {
      setError('A rejection reason or remarks is mandatory when rejecting a document.');
      return;
    }

    try {
      setProcessingAction(true);
      await api.documents.verifyDocument(reviewingDoc.id, {
        verificationStatus: status,
        verificationRemarks: verificationRemarks.trim() || undefined,
        rejectionReason: status === 'REJECTED' ? rejectionReason.trim() : undefined
      });

      setReviewingDoc(null);
      setRejectionReason('');
      setVerificationRemarks('');
      setIsRejecting(false);
      await fetchChecklist();
      if (onDocumentUpdated) onDocumentUpdated();
    } catch (err: any) {
      setError(err.message || 'Failed to record verification decision.');
    } finally {
      setProcessingAction(false);
    }
  };

  const getEntityIcon = (type: DocumentEntityType) => {
    switch (type) {
      case 'TEACHER':
        return <Award className="w-5 h-5 text-indigo-400" />;
      case 'STAFF':
        return <Building2 className="w-5 h-5 text-blue-400" />;
      case 'GUARDIAN':
        return <User className="w-5 h-5 text-amber-400" />;
      case 'SCHOOL':
        return <Building2 className="w-5 h-5 text-purple-400" />;
      case 'STUDENT':
        return <GraduationCap className="w-5 h-5 text-emerald-400" />;
      default:
        return <FileText className="w-5 h-5 text-slate-400" />;
    }
  };

  const getItemStatusBadge = (item: EntityDocumentChecklistItem) => {
    switch (item.status) {
      case 'VERIFIED':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            <CheckCircle2 className="w-3.5 h-3.5" /> Verified
          </span>
        );
      case 'PENDING_REVIEW':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/20">
            <Clock className="w-3.5 h-3.5" /> Pending Review
          </span>
        );
      case 'REJECTED':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-500/10 text-rose-400 border border-rose-500/20">
            <XCircle className="w-3.5 h-3.5" /> Rejected
          </span>
        );
      case 'EXPIRING_SOON':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-orange-500/10 text-orange-400 border border-orange-500/20">
            <Clock className="w-3.5 h-3.5" /> Expiring Soon ({item.daysRemaining}d)
          </span>
        );
      case 'EXPIRED':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-purple-500/10 text-purple-400 border border-purple-500/20">
            <AlertTriangle className="w-3.5 h-3.5" /> Expired ({Math.abs(item.daysRemaining || 0)}d ago)
          </span>
        );
      case 'SUBMITTED':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-500/10 text-blue-400 border border-blue-500/20">
            <FileText className="w-3.5 h-3.5" /> Submitted
          </span>
        );
      case 'MISSING':
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-800 text-slate-400 border border-slate-700">
            Missing
          </span>
        );
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden shadow-2xl my-8">
        {/* Header */}
        <div className="p-6 border-b border-slate-800 flex items-center justify-between bg-slate-900/90 shrink-0">
          <div className="flex items-center gap-3.5">
            <div className="p-3 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400">
              {getEntityIcon(entityType)}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold font-mono px-2 py-0.5 rounded bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 uppercase tracking-wider">
                  {entityType} Dossier
                </span>
                {checklist?.entityCode && (
                  <span className="text-xs font-mono text-slate-400">{checklist.entityCode}</span>
                )}
              </div>
              <h3 className="text-lg font-bold text-white tracking-tight mt-0.5">
                {checklist?.entityName || entityName || entityId} &mdash; Official Documents &amp; Compliance
              </h3>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={fetchChecklist}
              disabled={loading}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              title="Refresh checklist state"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-indigo-400' : ''}`} />
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-6 overflow-y-auto flex-1">
          {error && (
            <div className="p-4 bg-rose-500/10 border border-rose-500/20 rounded-2xl flex items-start gap-3 text-xs text-rose-300">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {loading && !checklist ? (
            <div className="py-16 text-center text-slate-400 space-y-2">
              <LoadingSpinner size="lg" />
              <p className="text-xs">Evaluating institutional document compliance...</p>
            </div>
          ) : !checklist ? (
            <div className="py-12 text-center text-slate-400">Unable to load checklist records.</div>
          ) : (
            <>
              {/* Compliance Scorecard */}
              <div className="p-5 rounded-2xl bg-gradient-to-r from-slate-950 via-slate-900 to-indigo-950/40 border border-slate-800 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <div className="text-xs uppercase font-bold tracking-wider text-slate-400">
                      Institutional Document Compliance
                    </div>
                    <div className="text-2xl font-black text-white mt-1">
                      {checklist.compliancePercentage}% Compliance
                    </div>
                    <p className="text-xs text-slate-400 mt-0.5">
                      {checklist.verified} of {checklist.totalRequired} mandatory requirements formally verified
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <span
                      className={`px-3 py-1 rounded-xl text-xs font-bold ${
                        checklist.compliancePercentage === 100
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                          : checklist.compliancePercentage >= 50
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                          : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                      }`}
                    >
                      {checklist.compliancePercentage === 100
                        ? 'FULL COMPLIANCE'
                        : checklist.compliancePercentage >= 50
                        ? 'PARTIAL COMPLIANCE'
                        : 'ACTION REQUIRED'}
                    </span>
                  </div>
                </div>

                {/* Progress bar */}
                <div className="w-full bg-slate-800 rounded-full h-2.5 overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${
                      checklist.compliancePercentage === 100
                        ? 'bg-emerald-500'
                        : checklist.compliancePercentage >= 50
                        ? 'bg-amber-500'
                        : 'bg-rose-500'
                    }`}
                    style={{ width: `${checklist.compliancePercentage}%` }}
                  />
                </div>

                {/* Scorecard Metric Blocks */}
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 pt-2 text-xs">
                  <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 space-y-1">
                    <span className="text-[11px] text-slate-400 font-semibold uppercase">Verified</span>
                    <div className="text-lg font-bold text-emerald-400">{checklist.verified}</div>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 space-y-1">
                    <span className="text-[11px] text-slate-400 font-semibold uppercase">In Review</span>
                    <div className="text-lg font-bold text-amber-400">{checklist.pendingReview}</div>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 space-y-1">
                    <span className="text-[11px] text-slate-400 font-semibold uppercase">Missing</span>
                    <div className="text-lg font-bold text-rose-400">{checklist.missing}</div>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 space-y-1">
                    <span className="text-[11px] text-slate-400 font-semibold uppercase">Rejected</span>
                    <div className="text-lg font-bold text-rose-400">{checklist.rejected}</div>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 space-y-1 col-span-2 sm:col-span-1">
                    <span className="text-[11px] text-slate-400 font-semibold uppercase">Expiring</span>
                    <div className="text-lg font-bold text-purple-400">{checklist.expiringSoon + checklist.expired}</div>
                  </div>
                </div>
              </div>

              {/* Quick Upload Form Drawer */}
              {uploadingItem && (
                <form
                  onSubmit={handleUploadSubmit}
                  className="p-5 rounded-2xl bg-indigo-950/20 border border-indigo-500/30 space-y-4 animate-in fade-in"
                >
                  <div className="flex items-center justify-between border-b border-indigo-500/20 pb-3">
                    <div className="flex items-center gap-2 text-indigo-300 font-bold text-sm">
                      <Upload className="w-4 h-4" />
                      <span>Upload &ldquo;{uploadingItem.documentTypeName}&rdquo;</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setUploadingItem(null)}
                      className="text-slate-400 hover:text-white text-xs"
                    >
                      Cancel
                    </button>
                  </div>

                  {uploadError && (
                    <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/20 text-xs text-rose-400">
                      {uploadError}
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                    <div>
                      <label className="block text-slate-300 font-medium mb-1">Document Title *</label>
                      <input
                        type="text"
                        value={uploadTitle}
                        onChange={(e) => setUploadTitle(e.target.value)}
                        placeholder="e.g. Master Diploma Degree"
                        className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-hidden focus:border-indigo-500"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-slate-300 font-medium mb-1">Reference / Serial #</label>
                      <input
                        type="text"
                        value={uploadRefNumber}
                        onChange={(e) => setUploadRefNumber(e.target.value)}
                        placeholder="e.g. REG-2026-908"
                        className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-hidden focus:border-indigo-500 font-mono"
                      />
                    </div>

                    <div>
                      <label className="block text-slate-300 font-medium mb-1">Credential Expiry Date (if applicable)</label>
                      <input
                        type="date"
                        value={uploadExpiryDate}
                        onChange={(e) => setUploadExpiryDate(e.target.value)}
                        className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-hidden focus:border-indigo-500"
                      />
                    </div>

                    <div>
                      <label className="block text-slate-300 font-medium mb-1">Select File (PDF, PNG, JPG)</label>
                      <input
                        type="file"
                        onChange={(e) => setUploadFile(e.target.files?.[0] || null)}
                        className="w-full text-xs text-slate-400 file:mr-3 file:py-2 file:px-3 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-indigo-600 file:text-white hover:file:bg-indigo-500"
                      />
                    </div>
                  </div>

                  <div className="flex justify-end gap-2 pt-2 border-t border-indigo-500/20">
                    <Button
                      type="button"
                      size="xs"
                      variant="outline"
                      onClick={() => setUploadingItem(null)}
                      disabled={uploading}
                    >
                      Cancel
                    </Button>
                    <Button
                      type="submit"
                      size="xs"
                      variant="primary"
                      disabled={uploading}
                      className="bg-indigo-600 hover:bg-indigo-500 text-white font-semibold"
                    >
                      {uploading ? 'Attaching Document...' : 'Submit to Vault'}
                    </Button>
                  </div>
                </form>
              )}

              {/* Review & Verification Decision Drawer */}
              {reviewingDoc && (
                <div className="p-5 rounded-2xl bg-slate-950 border border-indigo-500/30 space-y-4 animate-in fade-in">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                    <div className="flex items-center gap-2">
                      <ShieldCheck className="w-5 h-5 text-indigo-400" />
                      <div>
                        <h4 className="text-sm font-bold text-white">
                          Institutional Review &amp; Verification: {reviewingDoc.documentTitle}
                        </h4>
                        <span className="text-[11px] font-mono text-slate-400">
                          {reviewingDoc.fileName} &bull; v{reviewingDoc.version}
                        </span>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setReviewingDoc(null);
                        setIsRejecting(false);
                      }}
                      className="text-slate-400 hover:text-white text-xs"
                    >
                      Close Review
                    </button>
                  </div>

                  {reviewingDoc.notes && (
                    <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 text-xs text-slate-300">
                      <strong>Document Notes:</strong> {reviewingDoc.notes}
                    </div>
                  )}

                  {isRejecting ? (
                    <div className="space-y-3">
                      <div>
                        <label className="block text-xs font-semibold text-rose-400 uppercase tracking-wider mb-1">
                          Mandatory Rejection Reason *
                        </label>
                        <textarea
                          rows={3}
                          value={rejectionReason}
                          onChange={(e) => setRejectionReason(e.target.value)}
                          placeholder="State explicitly what was invalid (e.g. illegible seal, expired license date, missing page 2)..."
                          className="w-full p-2.5 rounded-xl bg-slate-900 border border-rose-500/40 text-white text-xs focus:outline-hidden focus:border-rose-500 resize-none"
                          required
                        />
                      </div>

                      <div className="flex justify-end gap-2">
                        <Button
                          type="button"
                          size="xs"
                          variant="outline"
                          onClick={() => setIsRejecting(false)}
                          disabled={processingAction}
                        >
                          Back to Decision
                        </Button>
                        <Button
                          type="button"
                          size="xs"
                          variant="danger"
                          onClick={() => handleVerifyDecision('REJECTED')}
                          disabled={processingAction || !rejectionReason.trim()}
                        >
                          Confirm Rejection &amp; Request Re-upload
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      <div>
                        <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                          Verification Approval Remarks (Optional)
                        </label>
                        <input
                          type="text"
                          value={verificationRemarks}
                          onChange={(e) => setVerificationRemarks(e.target.value)}
                          placeholder="e.g. Authenticated against Ministry of Education registrar registry."
                          className="w-full p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white text-xs focus:outline-hidden focus:border-indigo-500"
                        />
                      </div>

                      <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
                        <Button
                          type="button"
                          size="xs"
                          variant="danger"
                          onClick={() => setIsRejecting(true)}
                          disabled={processingAction}
                        >
                          <XCircle className="w-3.5 h-3.5 mr-1" />
                          Reject Document
                        </Button>
                        <Button
                          type="button"
                          size="xs"
                          variant="primary"
                          onClick={() => handleVerifyDecision('VERIFIED')}
                          disabled={processingAction}
                          className="bg-emerald-600 hover:bg-emerald-500 text-white font-semibold"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5 mr-1" />
                          Approve &amp; Verify Document
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Checklist Items Table */}
              <div className="bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden shadow-xl">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-sm text-slate-300">
                    <thead className="bg-slate-900/80 text-[11px] uppercase tracking-wider text-slate-400 border-b border-slate-800">
                      <tr>
                        <th className="px-6 py-4 font-semibold">Document Requirement</th>
                        <th className="px-4 py-4 font-semibold">Scope</th>
                        <th className="px-4 py-4 font-semibold">Submitted File</th>
                        <th className="px-4 py-4 font-semibold">Status</th>
                        <th className="px-4 py-4 font-semibold">Expiry Date</th>
                        <th className="px-6 py-4 font-semibold text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800">
                      {(checklist.items || []).map((item, idx) => (
                        <tr
                          key={`${item.documentTypeId}-${idx}`}
                          className="hover:bg-slate-900/40 transition-colors"
                        >
                          <td className="px-6 py-4">
                            <div className="flex items-center gap-3">
                              <div className="p-2 rounded-xl bg-indigo-500/10 text-indigo-400 shrink-0">
                                <FileText className="w-4 h-4" />
                              </div>
                              <div className="min-w-0">
                                <div className="font-bold text-white text-sm line-clamp-1">
                                  {item.documentTypeName}
                                </div>
                                <span className="text-[11px] text-slate-400 font-mono">
                                  Category: {item.category}
                                </span>
                              </div>
                            </div>
                          </td>

                          <td className="px-4 py-4 whitespace-nowrap">
                            <span
                              className={`text-[10px] font-bold px-2 py-0.5 rounded-md uppercase tracking-wider ${
                                item.isRequired
                                  ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                                  : 'bg-slate-800 text-slate-400 border border-slate-700'
                              }`}
                            >
                              {item.isRequired ? 'Required' : 'Optional'}
                            </span>
                          </td>

                          <td className="px-4 py-4">
                            {item.document ? (
                              <div className="min-w-0">
                                <span className="font-semibold text-slate-200 block text-xs line-clamp-1">
                                  {item.document.documentTitle}
                                </span>
                                <span className="text-[10px] text-slate-500 font-mono">
                                  {item.document.fileName} • v{item.document.version}
                                </span>
                              </div>
                            ) : (
                              <span className="text-xs text-slate-500 italic">Not submitted</span>
                            )}
                          </td>

                          <td className="px-4 py-4 whitespace-nowrap">
                            {getItemStatusBadge(item)}
                          </td>

                          <td className="px-4 py-4 whitespace-nowrap text-xs font-mono text-slate-400">
                            {item.document?.expiryDate ? (
                              <span className={item.isExpired ? 'text-rose-400 font-bold' : item.isExpiringSoon ? 'text-amber-400 font-bold' : ''}>
                                {new Date(item.document.expiryDate).toLocaleDateString()}
                              </span>
                            ) : (
                              '—'
                            )}
                          </td>

                          <td className="px-6 py-4 whitespace-nowrap text-right space-x-1.5">
                            {item.document ? (
                              <>
                                <a
                                  href={item.document.fileUrl}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="inline-flex items-center p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                                  title="View document file"
                                >
                                  <Eye className="w-3.5 h-3.5" />
                                </a>

                                <a
                                  href={item.document.fileUrl}
                                  download={item.document.fileName}
                                  className="inline-flex items-center p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                                  title="Download document file"
                                >
                                  <Download className="w-3.5 h-3.5" />
                                </a>

                                {canVerify && (
                                  <Button
                                    size="xs"
                                    variant="outline"
                                    onClick={() => {
                                      setReviewingDoc(item.document!);
                                      setIsRejecting(false);
                                      setRejectionReason('');
                                      setVerificationRemarks('');
                                    }}
                                    className="text-xs border-indigo-500/30 text-indigo-300 hover:bg-indigo-500/10"
                                  >
                                    <ShieldCheck className="w-3 h-3 mr-1" />
                                    Review
                                  </Button>
                                )}

                                <Button
                                  size="xs"
                                  variant="ghost"
                                  onClick={() => handleStartUpload(item)}
                                  className="text-xs text-indigo-400 hover:text-indigo-300"
                                  title="Upload newer version / replacement"
                                >
                                  <Upload className="w-3 h-3 mr-1" />
                                  Re-upload
                                </Button>
                              </>
                            ) : (
                              <Button
                                size="xs"
                                variant="primary"
                                onClick={() => handleStartUpload(item)}
                                className="text-xs bg-indigo-600 hover:bg-indigo-500 text-white font-semibold"
                              >
                                <Upload className="w-3 h-3 mr-1" />
                                Upload
                              </Button>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-900/90 flex justify-end">
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={onClose}
            className="text-slate-300 border-slate-700 hover:bg-slate-800 text-xs"
          >
            Close Checklist
          </Button>
        </div>
      </div>
    </div>
  );
};
