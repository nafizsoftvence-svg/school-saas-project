import React, { useState } from 'react';
import {
  X,
  Upload,
  FileText,
  AlertTriangle,
  CheckCircle2,
  Calendar,
  Building2,
  FileCheck
} from 'lucide-react';
import { StudentDocument, StudentDocumentCategory } from '../../types';

interface StudentDocumentUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (newDoc: StudentDocument) => void;
  studentId: string;
  studentName?: string;
  admissionNumber?: string;
}

export const StudentDocumentUploadModal: React.FC<StudentDocumentUploadModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  studentId,
  studentName,
  admissionNumber
}) => {
  const [category, setCategory] = useState<StudentDocumentCategory>('IDENTIFICATION');
  const [title, setTitle] = useState('');
  const [documentNumber, setDocumentNumber] = useState('');
  const [issuingAuthority, setIssuingAuthority] = useState('');
  const [issueDate, setIssueDate] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const categories: Array<{ id: StudentDocumentCategory; label: string; placeholder: string }> = [
    { id: 'IDENTIFICATION', label: 'Identification (Birth Cert, Passport, Aadhaar, SSN)', placeholder: 'Birth Certificate' },
    { id: 'ACADEMIC', label: 'Academic (Transfer Certificate, Prior Grade Sheet, Diploma)', placeholder: 'Previous School Transfer Certificate' },
    { id: 'MEDICAL', label: 'Medical (Immunization, Health Evaluation, Allergy Plan)', placeholder: 'Comprehensive Immunization Record' },
    { id: 'LEGAL_GUARDIANSHIP', label: 'Legal (Guardianship Court Order, Custody Decree)', placeholder: 'Official Custody / Guardianship Decree' },
    { id: 'IDENTITY_PHOTOS', label: 'Photos (Passport Photo, Badge Portrait)', placeholder: 'Official White-Background Portrait Photo' },
    { id: 'OTHER', label: 'Other Official Document', placeholder: 'Utility Proof of Residence' }
  ];

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const file = e.target.files?.[0];
      if (!file) return;
      setSelectedFile(file);
      if (!title) {
        // Auto-populate title from file name
        const cleanName = file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ');
        setTitle(cleanName.charAt(0).toUpperCase() + cleanName.slice(1));
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setError('Document title is required');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const token = localStorage.getItem('sygmate_auth_token') || localStorage.getItem('token');
      // In web demo environment, convert file to data URI or use simulated CDN fileUrl
      let fileUrl = 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf';
      let fileName = selectedFile ? selectedFile.name : `${title.toLowerCase().replace(/\s+/g, '_')}.pdf`;
      let fileSize = selectedFile ? `${(selectedFile.size / 1024).toFixed(1)} KB` : '320 KB';
      let fileType = selectedFile ? selectedFile.type : 'application/pdf';

      const payload = {
        title: title.trim(),
        name: title.trim(),
        category,
        documentNumber: documentNumber.trim() || undefined,
        issuingAuthority: issuingAuthority.trim() || undefined,
        issueDate: issueDate || undefined,
        expiryDate: expiryDate || undefined,
        fileUrl,
        url: fileUrl,
        fileName,
        fileSize,
        size: fileSize,
        fileType
      };

      const res = await fetch(`/api/documents-idcards/students/${studentId}/documents`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {})
        },
        body: JSON.stringify(payload)
      });

      const isJson = (res.headers.get('content-type') || '').includes('application/json');
      const data = isJson ? await res.json() : null;
      if (!res.ok || !data?.success) {
        throw new Error(data?.error || `Failed to upload document (HTTP ${res.status})`);
      }

      onSuccess(data.data);
      onClose();
    } catch (err: any) {
      setError(err.message || 'An error occurred while uploading document.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="px-6 py-4 bg-gradient-to-r from-indigo-600 to-indigo-700 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-white/15 flex items-center justify-center">
              <Upload className="w-4 h-4 text-indigo-100" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Upload Student Document</h3>
              <p className="text-xs text-indigo-100">
                {studentName ? `${studentName} (${admissionNumber})` : 'Attach official certificate to repository'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-white/80 hover:text-white p-1 rounded-lg hover:bg-white/10 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-xl flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0 text-rose-500" />
              {error}
            </div>
          )}

          {/* File Upload Drag & Drop Box */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Select Document File (PDF, PNG, JPEG up to 10MB) <span className="text-rose-500">*</span>
            </label>
            <div className="border-2 border-dashed border-slate-300 hover:border-indigo-400 rounded-2xl p-4 text-center bg-slate-50/50 hover:bg-indigo-50/30 transition cursor-pointer relative">
              <input
                type="file"
                accept=".pdf,.png,.jpg,.jpeg"
                onChange={handleFileChange}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              />
              <div className="flex flex-col items-center justify-center space-y-1.5">
                <div className="w-10 h-10 rounded-full bg-indigo-50 text-indigo-600 flex items-center justify-center">
                  <Upload className="w-5 h-5" />
                </div>
                {selectedFile ? (
                  <div>
                    <span className="text-xs font-bold text-indigo-700 block">{selectedFile.name}</span>
                    <span className="text-[10.5px] text-slate-500">{(selectedFile.size / 1024).toFixed(1)} KB</span>
                  </div>
                ) : (
                  <div>
                    <span className="text-xs font-semibold text-slate-700 block">Click or drag & drop to upload file</span>
                    <span className="text-[10px] text-slate-400">PDF, JPG, PNG supported</span>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Category */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Document Category <span className="text-rose-500">*</span>
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value as any)}
              className="w-full text-xs p-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              required
            >
              {categories.map(c => (
                <option key={c.id} value={c.id}>{c.label}</option>
              ))}
            </select>
          </div>

          {/* Title */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Document Title / Label <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Official Birth Certificate"
              className="w-full text-xs p-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              required
            />
          </div>

          {/* Document Number & Issuing Authority */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Document / Certificate #
              </label>
              <input
                type="text"
                value={documentNumber}
                onChange={(e) => setDocumentNumber(e.target.value)}
                placeholder="e.g. BC-9842105"
                className="w-full text-xs p-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Issuing Authority
              </label>
              <input
                type="text"
                value={issuingAuthority}
                onChange={(e) => setIssuingAuthority(e.target.value)}
                placeholder="e.g. Civil Registry Dept"
                className="w-full text-xs p-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

          {/* Dates */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Issue Date
              </label>
              <input
                type="date"
                value={issueDate}
                onChange={(e) => setIssueDate(e.target.value)}
                className="w-full text-xs p-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Expiry Date (If applicable)
              </label>
              <input
                type="date"
                value={expiryDate}
                onChange={(e) => setExpiryDate(e.target.value)}
                className="w-full text-xs p-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 hover:bg-slate-100 rounded-xl transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="flex items-center gap-1.5 px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl shadow transition disabled:opacity-50"
            >
              <Upload className="w-3.5 h-3.5" />
              {loading ? 'Uploading...' : 'Save & Upload Document'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
