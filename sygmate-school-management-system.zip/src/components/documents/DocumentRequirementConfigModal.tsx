import React, { useState, useEffect } from 'react';
import {
  X,
  ShieldCheck,
  Building,
  GraduationCap,
  Users,
  Briefcase,
  AlertCircle
} from 'lucide-react';
import {
  DocumentTypeConfig,
  DocumentRequirementConfig,
  DocumentEntityType,
  CreateDocumentRequirementPayload,
  UpdateDocumentRequirementPayload
} from '../../types/index.js';
import { api } from '../../services/api.js';
import { Button } from '../ui/Button.js';
import { Input } from '../ui/Input.js';

interface DocumentRequirementConfigModalProps {
  isOpen: boolean;
  onClose: () => void;
  documentTypes: DocumentTypeConfig[];
  requirementToEdit?: DocumentRequirementConfig | null;
  onSuccess: (saved: DocumentRequirementConfig) => void;
}

export const DocumentRequirementConfigModal: React.FC<DocumentRequirementConfigModalProps> = ({
  isOpen,
  onClose,
  documentTypes,
  requirementToEdit,
  onSuccess
}) => {
  const [entityType, setEntityType] = useState<DocumentEntityType>('TEACHER');
  const [documentTypeId, setDocumentTypeId] = useState<string>('');
  const [isRequired, setIsRequired] = useState<boolean>(true);
  const [applicableRole, setApplicableRole] = useState<string>('ALL');
  const [description, setDescription] = useState<string>('');
  const [isActive, setIsActive] = useState<boolean>(true);
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (requirementToEdit) {
      setEntityType(requirementToEdit.entityType);
      setDocumentTypeId(requirementToEdit.documentTypeId);
      setIsRequired(requirementToEdit.isRequired);
      setApplicableRole(requirementToEdit.applicableRole || 'ALL');
      setDescription(requirementToEdit.description || '');
      setIsActive(requirementToEdit.isActive !== false);
    } else {
      setEntityType('TEACHER');
      setDocumentTypeId(documentTypes[0]?.id || '');
      setIsRequired(true);
      setApplicableRole('ALL');
      setDescription('');
      setIsActive(true);
    }
    setError(null);
  }, [requirementToEdit, documentTypes, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!documentTypeId) {
      setError('Please select a valid document classification.');
      return;
    }

    try {
      setSubmitting(true);
      if (requirementToEdit) {
        const payload: UpdateDocumentRequirementPayload = {
          isRequired,
          applicableRole: applicableRole.trim() || 'ALL',
          description: description.trim() || undefined,
          isActive
        };
        const res = await api.documents.updateRequirement(requirementToEdit.id, payload);
        if (res) {
          onSuccess((res as any)?.data || res);
          onClose();
        }
      } else {
        const payload: CreateDocumentRequirementPayload = {
          entityType,
          documentTypeId,
          isRequired,
          applicableRole: applicableRole.trim() || 'ALL',
          description: description.trim() || undefined,
          isActive
        };
        const res = await api.documents.createRequirement(payload);
        if (res) {
          onSuccess((res as any)?.data || res);
          onClose();
        }
      }
    } catch (err: any) {
      setError(err.message || 'Failed to save document requirement rule.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl space-y-6">
        {/* Header */}
        <div className="p-6 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white tracking-tight">
                {requirementToEdit ? 'Edit Document Requirement' : 'New Document Requirement Rule'}
              </h3>
              <p className="text-xs text-slate-400">
                Institutional compliance and document checklist criteria
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-xl hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="px-6 space-y-4">
          {error && (
            <div className="p-3 bg-rose-500/10 border border-rose-500/20 rounded-xl flex items-start gap-2.5 text-xs text-rose-400">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {/* Target Entity Scope */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              Target Entity Scope *
            </label>
            <select
              value={entityType}
              onChange={(e) => setEntityType(e.target.value as DocumentEntityType)}
              disabled={Boolean(requirementToEdit)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-hidden focus:border-indigo-500 disabled:opacity-60"
            >
              <option value="TEACHER">Teacher / Academic Faculty</option>
              <option value="STAFF">Non-Teaching Staff &amp; HR Employees</option>
              <option value="GUARDIAN">Parent / Legal Guardian</option>
              <option value="SCHOOL">School Institutional Record</option>
              <option value="STUDENT">Student Record</option>
            </select>
          </div>

          {/* Document Type Classification */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              Document Classification *
            </label>
            <select
              value={documentTypeId}
              onChange={(e) => setDocumentTypeId(e.target.value)}
              disabled={Boolean(requirementToEdit)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-hidden focus:border-indigo-500 disabled:opacity-60"
            >
              <option value="">Select Document Type</option>
              {documentTypes.map((dt) => (
                <option key={dt.id} value={dt.id}>
                  {dt.name} ({dt.code})
                </option>
              ))}
            </select>
          </div>

          {/* Requirement Status & Role */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Requirement Level *
              </label>
              <select
                value={isRequired ? 'MANDATORY' : 'OPTIONAL'}
                onChange={(e) => setIsRequired(e.target.value === 'MANDATORY')}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-hidden focus:border-indigo-500"
              >
                <option value="MANDATORY">Mandatory / Required</option>
                <option value="OPTIONAL">Optional / Discretionary</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Applicable Role / Scope
              </label>
              <input
                type="text"
                value={applicableRole}
                onChange={(e) => setApplicableRole(e.target.value)}
                placeholder="ALL or e.g. HEAD_OF_DEPARTMENT"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-600 focus:outline-hidden focus:border-indigo-500 font-mono"
              />
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              Guidance &amp; Verification Description
            </label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="e.g. State-issued teaching certificate with active status through the current session."
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-600 focus:outline-hidden focus:border-indigo-500 resize-none"
            />
          </div>

          {/* Active Status */}
          <div className="flex items-center gap-2 pt-1">
            <input
              type="checkbox"
              id="req-active-toggle"
              checked={isActive}
              onChange={(e) => setIsActive(e.target.checked)}
              className="rounded bg-slate-950 border-slate-800 text-indigo-600 focus:ring-indigo-500"
            />
            <label htmlFor="req-active-toggle" className="text-xs font-medium text-slate-300 cursor-pointer">
              Active Requirement Rule (Enforced on checklists)
            </label>
          </div>

          {/* Footer Actions */}
          <div className="flex items-center justify-end gap-2.5 pt-4 pb-6 border-t border-slate-800">
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={onClose}
              disabled={submitting}
              className="text-slate-300 border-slate-700 hover:bg-slate-800 text-xs"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              variant="primary"
              size="sm"
              disabled={submitting}
              className="bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs"
            >
              {submitting ? 'Saving...' : requirementToEdit ? 'Save Changes' : 'Create Requirement'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};
