/**
 * Part 15D — Certificate Verification Modal
 * Sygmate School Management System
 */

import React, { useState } from 'react';
import {
  ShieldCheck,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  User,
  Calendar,
  Award,
  Layers,
  FileText,
  Clock,
  CheckSquare
} from 'lucide-react';
import { IssuedCertificate } from '../../types';
import { api } from '../../services/api';
import { Button } from '../ui/Button';

interface CertificateVerificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (updated: IssuedCertificate) => void;
  certificate: IssuedCertificate | null;
}

export const CertificateVerificationModal: React.FC<CertificateVerificationModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  certificate
}) => {
  const [decision, setDecision] = useState<'VERIFY' | 'REJECT'>('VERIFY');
  const [notes, setNotes] = useState('');
  const [rejectionReason, setRejectionReason] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  if (!isOpen || !certificate) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (decision === 'REJECT' && !rejectionReason.trim()) {
      setErrorMessage('Please provide a mandatory reason for rejecting this certificate.');
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await api.certificates.verify(certificate.id, {
        decision,
        notes: notes.trim() || undefined,
        rejectionReason: decision === 'REJECT' ? rejectionReason.trim() : undefined
      });
      onSuccess(res);
      onClose();
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to complete verification decision.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden my-6">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 bg-slate-950/80 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-blue-500/10 text-blue-400 rounded-xl border border-blue-500/20">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Review & Verify Certificate</h3>
              <p className="text-xs text-slate-400">
                Administrative prerequisite verification before forwarding for leadership approval.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg text-lg leading-none"
          >
            &times;
          </button>
        </div>

        {/* Certificate Snapshot Summary */}
        <div className="p-6 space-y-5">
          <div className="bg-slate-950/60 rounded-xl p-4 border border-slate-800/80 grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <span className="text-slate-400 font-semibold uppercase tracking-wider block text-[10px]">
                Student Recipient
              </span>
              <span className="text-sm font-bold text-white block mt-0.5">
                {certificate.studentName}
              </span>
              <span className="text-slate-400 text-[11px]">
                {certificate.admissionNumber} · {certificate.className || 'Grade'} ({certificate.sectionName || 'Sec'})
              </span>
            </div>

            <div>
              <span className="text-slate-400 font-semibold uppercase tracking-wider block text-[10px]">
                Certificate Serial
              </span>
              <span className="text-sm font-mono font-bold text-indigo-400 block mt-0.5">
                {certificate.certificateNumber}
              </span>
              <span className="text-slate-400 text-[11px]">
                {certificate.certificateTypeName}
              </span>
            </div>

            <div>
              <span className="text-slate-400 font-semibold uppercase tracking-wider block text-[10px]">
                Academic Session
              </span>
              <span className="text-slate-200 font-medium block mt-0.5">
                {certificate.academicSessionName}
              </span>
            </div>

            <div>
              <span className="text-slate-400 font-semibold uppercase tracking-wider block text-[10px]">
                Target Issue Date
              </span>
              <span className="text-slate-200 font-medium block mt-0.5">
                {certificate.issueDate}
              </span>
            </div>
          </div>

          {/* Verification Criteria Checklist */}
          <div className="space-y-2">
            <span className="text-xs font-bold text-slate-300 uppercase tracking-wider block">
              Prerequisite Validation Checklist
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              <div className="flex items-center gap-2 p-2.5 rounded-lg bg-slate-950/40 border border-slate-800/80 text-slate-300">
                <CheckSquare className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Student identity and enrollment active</span>
              </div>
              <div className="flex items-center gap-2 p-2.5 rounded-lg bg-slate-950/40 border border-slate-800/80 text-slate-300">
                <CheckSquare className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Transcript records & marks reconciled</span>
              </div>
              <div className="flex items-center gap-2 p-2.5 rounded-lg bg-slate-950/40 border border-slate-800/80 text-slate-300">
                <CheckSquare className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Template layout & signatories verified</span>
              </div>
              <div className="flex items-center gap-2 p-2.5 rounded-lg bg-slate-950/40 border border-slate-800/80 text-slate-300">
                <CheckSquare className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Unique certificate serial allocated</span>
              </div>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4 pt-2 border-t border-slate-800">
            {/* Decision Radio Selector */}
            <div>
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
                Verification Decision <span className="text-rose-400">*</span>
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setDecision('VERIFY')}
                  className={`p-3 rounded-xl border flex items-center gap-2.5 font-bold text-xs transition-all ${
                    decision === 'VERIFY'
                      ? 'bg-emerald-600/15 border-emerald-500 text-emerald-300 shadow-sm'
                      : 'bg-slate-950/40 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>Verify & Queue for Approval</span>
                </button>

                <button
                  type="button"
                  onClick={() => setDecision('REJECT')}
                  className={`p-3 rounded-xl border flex items-center gap-2.5 font-bold text-xs transition-all ${
                    decision === 'REJECT'
                      ? 'bg-rose-600/15 border-rose-500 text-rose-300 shadow-sm'
                      : 'bg-slate-950/40 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <XCircle className="w-4 h-4 text-rose-400" />
                  <span>Reject Verification</span>
                </button>
              </div>
            </div>

            {/* Rejection Reason (Mandatory if Reject) */}
            {decision === 'REJECT' && (
              <div className="space-y-1.5 animate-in fade-in duration-200">
                <label className="block text-xs font-bold text-rose-400 uppercase tracking-wider">
                  Mandatory Rejection Reason <span className="text-rose-400">*</span>
                </label>
                <textarea
                  value={rejectionReason}
                  onChange={(e) => setRejectionReason(e.target.value)}
                  placeholder="Explain why verification failed (e.g. Missing library clearance, incorrect session, grade discrepancy)..."
                  rows={3}
                  className="w-full bg-slate-950 border border-rose-800/80 rounded-xl p-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-rose-500"
                  required
                />
              </div>
            )}

            {/* Review Notes */}
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider">
                Verification Notes (Optional)
              </label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Add internal verification notes or regulatory citations..."
                rows={2}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
              />
            </div>

            {errorMessage && (
              <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-xs text-rose-400 font-medium">
                {errorMessage}
              </div>
            )}

            {/* Modal Actions */}
            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
              <Button
                type="button"
                variant="outline"
                size="md"
                onClick={onClose}
                disabled={isSubmitting}
                className="border-slate-700 text-slate-300 hover:bg-slate-800"
              >
                Cancel
              </Button>

              <Button
                type="submit"
                size="md"
                disabled={isSubmitting}
                className={
                  decision === 'VERIFY'
                    ? 'bg-emerald-600 hover:bg-emerald-500 text-white font-bold'
                    : 'bg-rose-600 hover:bg-rose-500 text-white font-bold'
                }
              >
                {isSubmitting
                  ? 'Submitting Decision...'
                  : decision === 'VERIFY'
                  ? 'Confirm Verification'
                  : 'Reject Certificate'}
              </Button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
