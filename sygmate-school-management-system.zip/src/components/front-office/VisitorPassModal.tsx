import React, { useState } from 'react';
import { X, Printer, User, Building, Clock, Calendar, CheckCircle2, Shield, Phone, MapPin } from 'lucide-react';
import { VisitorRecord } from '../../types';
import { downloadElementPdf, triggerSafePrint } from '../../utils/printPdf.js';

interface VisitorPassModalProps {
  visitor: VisitorRecord | null;
  isOpen: boolean;
  onClose: () => void;
  onCheckIn?: (id: string) => void;
  onCheckOut?: (id: string) => void;
}

export const VisitorPassModal: React.FC<VisitorPassModalProps> = ({
  visitor,
  isOpen,
  onClose,
  onCheckIn,
  onCheckOut
}) => {
  const [isExporting, setIsExporting] = useState(false);

  if (!isOpen || !visitor) return null;

  const handlePrint = async () => {
    try {
      setIsExporting(true);
      const cleanPass = (visitor.visitorPassNumber || 'pass').replace(/[^a-zA-Z0-9_-]/g, '_');
      const filename = `VisitorPass_${cleanPass}_${new Date().toISOString().split('T')[0]}.pdf`;

      await downloadElementPdf('printable-visitor-pass', filename, {
        orientation: 'portrait'
      });

      await triggerSafePrint({
        elementOrId: 'printable-visitor-pass',
        fallbackTitle: `VisitorPass_${cleanPass}`
      });
    } catch (err) {
      console.error('Visitor pass print error:', err);
      try {
        window.print();
      } catch {
        // ignore
      }
    } finally {
      setIsExporting(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'CHECKED_IN':
        return 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/30';
      case 'CHECKED_OUT':
        return 'bg-slate-500/10 text-slate-600 dark:text-slate-400 border-slate-500/30';
      case 'CONFIRMED':
        return 'bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/30';
      case 'CANCELLED':
        return 'bg-rose-500/10 text-rose-600 dark:text-rose-400 border-rose-500/30';
      default:
        return 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/30';
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden my-8">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-slate-800/40">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold text-sm">
              <Shield className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">Security Visitor Badge</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">Official Campus Access Credential</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              disabled={isExporting}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-700 disabled:opacity-50 rounded-xl transition shadow-sm"
              title="Print Pass"
            >
              <Printer className="w-3.5 h-3.5" />
              {isExporting ? 'Generating PDF...' : 'Print / Save PDF'}
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Printable Pass Body */}
        <div className="p-6">
          <div
            id="printable-visitor-pass"
            className="border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-2xl p-5 bg-gradient-to-b from-white to-slate-50 dark:from-slate-900 dark:to-slate-850 shadow-inner"
          >
            {/* Institution Badge Top */}
            <div className="flex items-start justify-between border-b border-slate-200 dark:border-slate-800 pb-4">
              <div>
                <span className="text-[10px] font-bold tracking-widest uppercase text-indigo-600 dark:text-indigo-400">
                  Sygmate International Academy
                </span>
                <h2 className="text-lg font-black text-slate-900 dark:text-white tracking-tight">VISITOR PASS</h2>
                <p className="text-[11px] text-slate-500">Security Gate Access Control</p>
              </div>
              <div className="text-right">
                <span className="font-mono text-sm font-bold text-indigo-600 dark:text-indigo-400 block">
                  {visitor.visitorPassNumber}
                </span>
                <span className={`inline-block px-2 py-0.5 mt-1 text-[10px] font-bold rounded-full border ${getStatusColor(visitor.status)}`}>
                  {visitor.status.replace('_', ' ')}
                </span>
              </div>
            </div>

            {/* Visitor Detail Grid */}
            <div className="grid grid-cols-3 gap-4 my-5 items-center">
              {/* Avatar / Photo Box */}
              <div className="col-span-1">
                <div className="w-24 h-28 mx-auto rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 flex flex-col items-center justify-center text-slate-400 p-2 text-center">
                  <User className="w-10 h-10 mb-1 text-slate-400" />
                  <span className="text-[9px] font-medium leading-tight">Visitor ID Verified</span>
                </div>
              </div>

              {/* Visitor Identity Info */}
              <div className="col-span-2 space-y-1.5">
                <div>
                  <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">Full Name</span>
                  <p className="text-base font-extrabold text-slate-900 dark:text-white leading-tight">{visitor.visitorName}</p>
                  {visitor.organization && (
                    <p className="text-xs text-slate-500 font-medium">{visitor.organization}</p>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-2 pt-1">
                  <div>
                    <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">Visitor Type</span>
                    <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">{visitor.visitorType}</span>
                  </div>
                  <div>
                    <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">Contact Phone</span>
                    <span className="text-xs font-mono text-slate-700 dark:text-slate-300">{visitor.phone}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Visit Details */}
            <div className="bg-slate-100/70 dark:bg-slate-800/60 rounded-xl p-3 space-y-2 text-xs border border-slate-200/80 dark:border-slate-700/50">
              <div className="flex justify-between items-center">
                <span className="text-slate-500 font-medium">Person To Meet:</span>
                <span className="font-bold text-slate-900 dark:text-white">{visitor.personToMeet}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500 font-medium">Department:</span>
                <span className="font-semibold text-slate-800 dark:text-slate-200">{visitor.department}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-500 font-medium">Purpose:</span>
                <span className="font-medium text-slate-800 dark:text-slate-200 text-right max-w-[240px] truncate">{visitor.purpose}</span>
              </div>
              <div className="flex justify-between items-center pt-1 border-t border-slate-200 dark:border-slate-700">
                <span className="text-slate-500 font-medium">Date & Slot:</span>
                <span className="font-mono font-semibold text-slate-900 dark:text-white">
                  {visitor.appointmentDate} at {visitor.appointmentTime}
                </span>
              </div>
              {visitor.bookingId && (
                <div className="flex justify-between items-center text-[11px]">
                  <span className="text-slate-500 font-medium">Booking ID:</span>
                  <span className="font-mono font-bold text-indigo-600 dark:text-indigo-400">{visitor.bookingId}</span>
                </div>
              )}
              {visitor.entryType && (
                <div className="flex justify-between items-center text-[11px]">
                  <span className="text-slate-500 font-medium">Entry Category:</span>
                  <span className="font-semibold text-slate-800 dark:text-slate-200">{visitor.entryType.replace('_', ' ')}</span>
                </div>
              )}
              {visitor.vehicleNumber && (
                <div className="flex justify-between items-center text-[11px]">
                  <span className="text-slate-500 font-medium">Vehicle / Reg:</span>
                  <span className="font-mono font-semibold text-slate-800 dark:text-slate-200">
                    {visitor.vehicleType || 'Vehicle'}: {visitor.vehicleNumber}
                  </span>
                </div>
              )}
              {(visitor.idCardNumber || visitor.idProofNumber) && (
                <div className="flex justify-between items-center text-[11px]">
                  <span className="text-slate-500 font-medium">ID Verified:</span>
                  <span className="font-mono text-slate-700 dark:text-slate-300">
                    {visitor.idCardType || visitor.idProofType || 'ID'}: {visitor.idCardNumber || visitor.idProofNumber}
                  </span>
                </div>
              )}
            </div>

            {/* Timing & Badge Info */}
            <div className="grid grid-cols-2 gap-3 mt-3 pt-3 border-t border-slate-200 dark:border-slate-800 text-[11px]">
              <div>
                <span className="text-slate-400 block font-medium">Check-In Time:</span>
                <span className="font-mono font-semibold text-slate-800 dark:text-slate-200">
                  {visitor.checkInTime ? new Date(visitor.checkInTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Pending'}
                </span>
                {visitor.checkInBy && (
                  <span className="text-[10px] text-slate-400 block">by {visitor.checkInBy}</span>
                )}
              </div>
              <div>
                <span className="text-slate-400 block font-medium">Check-Out Time:</span>
                <span className="font-mono font-semibold text-slate-800 dark:text-slate-200">
                  {visitor.checkOutTime ? new Date(visitor.checkOutTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Active on campus'}
                </span>
                {visitor.durationMinutes ? (
                  <span className="text-[10px] font-semibold text-indigo-600 dark:text-indigo-400 block">
                    Duration: {visitor.durationMinutes} mins
                  </span>
                ) : null}
              </div>
            </div>

            {/* Security QR & Barcode Strip */}
            <div className="mt-4 pt-3 border-t border-dashed border-slate-300 dark:border-slate-700 flex flex-col items-center justify-center">
              <div className="flex items-center gap-4 mb-2">
                {/* Visual QR Code Token */}
                <div className="p-1.5 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg shadow-sm">
                  <div className="w-14 h-14 bg-slate-900 dark:bg-slate-100 p-1 flex flex-wrap gap-0.5 rounded">
                    {Array.from({ length: 16 }).map((_, i) => (
                      <div
                        key={i}
                        className={`w-2.5 h-2.5 rounded-xs ${
                          (i * 7 + (visitor.visitorPassNumber.charCodeAt(i % 5) || 0)) % 2 === 0
                            ? 'bg-white dark:bg-slate-900'
                            : 'bg-transparent'
                        }`}
                      />
                    ))}
                  </div>
                </div>

                {/* Simulated barcode */}
                <div>
                  <div className="flex items-center gap-[2px] h-9 mb-1">
                    {[4, 2, 6, 2, 4, 3, 5, 2, 7, 3, 2, 6, 4, 3, 5, 2, 4, 6, 2, 3, 5, 4, 2, 6].map((w, i) => (
                      <div key={i} className="bg-slate-900 dark:bg-slate-200 h-full" style={{ width: `${w}px` }} />
                    ))}
                  </div>
                  <div className="text-center font-mono text-[9px] text-slate-500 tracking-wider">
                    {visitor.qrCodeToken || visitor.visitorPassNumber}
                  </div>
                </div>
              </div>

              <span className="font-mono text-[10px] text-slate-500 tracking-widest">{visitor.visitorPassNumber}</span>
              <p className="text-[9px] text-slate-400 mt-1 text-center">
                Official Campus Access Credential. Display visibly at all times. Return pass to security upon departure.
              </p>
            </div>
          </div>
        </div>

        {/* Action Footer */}
        <div className="px-6 py-4 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-slate-800/40">
          <div className="flex items-center gap-2">
            {visitor.status !== 'CHECKED_IN' && visitor.status !== 'CHECKED_OUT' && onCheckIn && (
              <button
                onClick={() => {
                  onCheckIn(visitor.id);
                  onClose();
                }}
                className="px-3.5 py-1.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl transition shadow-sm inline-flex items-center gap-1.5"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                Check In Now
              </button>
            )}
            {visitor.status === 'CHECKED_IN' && onCheckOut && (
              <button
                onClick={() => {
                  onCheckOut(visitor.id);
                  onClose();
                }}
                className="px-3.5 py-1.5 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 rounded-xl transition shadow-sm inline-flex items-center gap-1.5"
              >
                <Clock className="w-3.5 h-3.5" />
                Check Out Now
              </button>
            )}
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-xl transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
