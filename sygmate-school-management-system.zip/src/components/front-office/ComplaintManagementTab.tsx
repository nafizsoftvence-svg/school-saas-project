import React, { useState, useEffect } from 'react';
import {
  ShieldAlert,
  Search,
  Plus,
  RefreshCw,
  Clock,
  CheckCircle2,
  AlertCircle,
  Eye,
  AlertTriangle,
  Flame,
  Phone,
  Star
} from 'lucide-react';
import { api } from '../../services/api';
import {
  ComplaintRecord,
  ComplaintStatus,
  ComplaintPriority,
  ComplaintCategory,
  ComplaintSlaStatus,
  ComplaintMetricsSummary
} from '../../types';
import { NewComplaintModal } from './NewComplaintModal';
import { ComplaintDetailModal } from './ComplaintDetailModal';

interface ComplaintManagementTabProps {
  onRefreshStats?: () => void;
  staffList?: Array<{ id: string; name: string; department?: string }>;
}

export const ComplaintManagementTab: React.FC<ComplaintManagementTabProps> = ({
  onRefreshStats,
  staffList = []
}) => {
  const [complaints, setComplaints] = useState<ComplaintRecord[]>([]);
  const [metrics, setMetrics] = useState<ComplaintMetricsSummary | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Filters
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [priorityFilter, setPriorityFilter] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [slaFilter, setSlaFilter] = useState<ComplaintSlaStatus | ''>('');
  const [escalatedFilter, setEscalatedFilter] = useState(false);

  // Modals
  const [isNewModalOpen, setIsNewModalOpen] = useState(false);
  const [selectedComplaint, setSelectedComplaint] = useState<ComplaintRecord | null>(null);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);

  const loadComplaints = async () => {
    try {
      setLoading(true);
      setError(null);
      const [compRes, metricsRes] = await Promise.all([
        api.frontOffice.getComplaints({
          search: search || undefined,
          status: statusFilter || undefined,
          priority: priorityFilter || undefined,
          category: categoryFilter || undefined,
          slaStatus: slaFilter || undefined,
          isEscalated: escalatedFilter || undefined,
          limit: 100
        }),
        api.frontOffice.getComplaintMetricsSummary().catch(() => ({ success: false, data: null }))
      ]);

      if (compRes.success && compRes.data) {
        setComplaints(compRes.data);
      } else {
        setError(compRes.error || 'Failed to fetch complaints.');
      }

      if (metricsRes && metricsRes.success && metricsRes.data) {
        setMetrics(metricsRes.data);
      }
    } catch (err: any) {
      setError(err.message || 'Error loading complaints.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadComplaints();
  }, [statusFilter, priorityFilter, categoryFilter, slaFilter, escalatedFilter]);

  const getPriorityBadge = (p: ComplaintPriority) => {
    switch (p) {
      case 'URGENT':
        return 'bg-rose-500/10 text-rose-600 dark:text-rose-400 border-rose-500/30';
      case 'HIGH':
        return 'bg-orange-500/10 text-orange-600 dark:text-orange-400 border-orange-500/30';
      case 'MEDIUM':
        return 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/30';
      default:
        return 'bg-slate-500/10 text-slate-600 dark:text-slate-400 border-slate-500/30';
    }
  };

  const getStatusBadge = (s: ComplaintStatus) => {
    switch (s) {
      case 'RESOLVED':
        return 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/30';
      case 'IN_PROGRESS':
        return 'bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/30';
      case 'ASSIGNED':
        return 'bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border-indigo-500/30';
      case 'ACKNOWLEDGED':
        return 'bg-teal-500/10 text-teal-600 dark:text-teal-400 border-teal-500/30';
      case 'CLOSED':
        return 'bg-slate-500/10 text-slate-600 dark:text-slate-400 border-slate-500/30';
      case 'REOPENED':
        return 'bg-purple-500/10 text-purple-600 dark:text-purple-400 border-purple-500/30';
      case 'REJECTED':
        return 'bg-rose-500/10 text-rose-600 dark:text-rose-400 border-rose-500/30';
      default:
        return 'bg-rose-500/10 text-rose-600 dark:text-rose-400 border-rose-500/30';
    }
  };

  const getSlaBadge = (sla?: ComplaintSlaStatus, remaining?: number) => {
    switch (sla) {
      case 'BREACHED':
      case 'RESOLVED_BREACHED':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-500/20">
            <AlertTriangle className="w-3 h-3" />
            BREACHED
          </span>
        );
      case 'AT_RISK':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20">
            <Clock className="w-3 h-3" />
            AT RISK ({remaining !== undefined ? `${remaining}h` : '≤8h'})
          </span>
        );
      case 'RESOLVED_WITHIN_SLA':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">
            <CheckCircle2 className="w-3 h-3" />
            ON TIME
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">
            <Clock className="w-3 h-3" />
            ON TRACK {remaining !== undefined && remaining > 0 ? `(${remaining}h)` : ''}
          </span>
        );
    }
  };

  return (
    <div className="space-y-4">
      {/* Top search & filter bar */}
      <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex flex-wrap items-center justify-between gap-3 shadow-sm">
        <div className="flex flex-wrap items-center gap-2.5 flex-1 min-w-[280px]">
          {/* Search box */}
          <div className="relative flex-1 min-w-[200px]">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && loadComplaints()}
              placeholder="Search ticket #, subject, complainant name, or phone..."
              className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* Status filter */}
          <select
            value={statusFilter}
            onChange={e => setStatusFilter(e.target.value)}
            className="px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="">All Statuses</option>
            <option value="NEW">New (Unassigned)</option>
            <option value="ACKNOWLEDGED">Acknowledged</option>
            <option value="ASSIGNED">Assigned</option>
            <option value="IN_PROGRESS">In Progress</option>
            <option value="RESOLVED">Resolved</option>
            <option value="CLOSED">Closed</option>
            <option value="REOPENED">Reopened</option>
            <option value="REJECTED">Rejected</option>
          </select>

          {/* Priority filter */}
          <select
            value={priorityFilter}
            onChange={e => setPriorityFilter(e.target.value)}
            className="px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="">All Priorities</option>
            <option value="URGENT">Urgent (24h SLA)</option>
            <option value="HIGH">High (48h SLA)</option>
            <option value="MEDIUM">Medium (72h SLA)</option>
            <option value="LOW">Low (120h SLA)</option>
          </select>

          {/* Category filter */}
          <select
            value={categoryFilter}
            onChange={e => setCategoryFilter(e.target.value)}
            className="px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="">All Categories</option>
            <option value="INFRASTRUCTURE">Infrastructure</option>
            <option value="TRANSPORT">Transport</option>
            <option value="ACADEMIC">Academic</option>
            <option value="FEE_BILLING">Fee / Billing</option>
            <option value="FOOD_CANTEEN">Food & Canteen</option>
            <option value="DISCIPLINE_BULLYING">Discipline / Bullying</option>
            <option value="SECURITY">Campus Safety & Security</option>
            <option value="STAFF_BEHAVIOR">Staff Conduct</option>
            <option value="OTHER">Other Matter</option>
          </select>

          {/* SLA Filter */}
          <select
            value={slaFilter}
            onChange={e => setSlaFilter(e.target.value as ComplaintSlaStatus | '')}
            className="px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="">All SLA States</option>
            <option value="ON_TRACK">SLA On Track</option>
            <option value="AT_RISK">SLA At Risk</option>
            <option value="BREACHED">SLA Breached</option>
            <option value="RESOLVED_WITHIN_SLA">Resolved On Time</option>
            <option value="RESOLVED_BREACHED">Resolved Overdue</option>
          </select>

          {/* Escalated Toggle */}
          <button
            onClick={() => setEscalatedFilter(!escalatedFilter)}
            className={`px-3 py-1.5 text-xs font-semibold rounded-xl border transition flex items-center gap-1.5 ${
              escalatedFilter
                ? 'bg-rose-500/10 border-rose-500/40 text-rose-600 dark:text-rose-400'
                : 'border-slate-300 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <Flame className="w-3.5 h-3.5" />
            Escalated Only
          </button>
        </div>

        {/* Action buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={loadComplaints}
            className="p-2 text-slate-500 hover:text-slate-900 dark:hover:text-white rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition"
            title="Refresh Complaints"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>

          <button
            onClick={() => setIsNewModalOpen(true)}
            className="px-3.5 py-1.5 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-xl transition shadow-sm inline-flex items-center gap-1.5"
          >
            <Plus className="w-3.5 h-3.5" />
            Register Grievance
          </button>
        </div>
      </div>

      {/* SLA & Health KPI Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold">
            <ShieldAlert className="w-4 h-4" />
          </div>
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">Total Grievances</span>
            <span className="text-base font-extrabold text-slate-900 dark:text-white">{metrics?.total ?? complaints.length}</span>
          </div>
        </div>

        <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-amber-50 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400 flex items-center justify-center font-bold">
            <Clock className="w-4 h-4" />
          </div>
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">SLA At Risk (≤8h)</span>
            <span className="text-base font-extrabold text-slate-900 dark:text-white">
              {metrics ? metrics.slaAtRisk : complaints.filter(c => c.slaStatus === 'AT_RISK').length}
            </span>
          </div>
        </div>

        <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 flex items-center justify-center font-bold">
            <AlertTriangle className="w-4 h-4" />
          </div>
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">SLA Breached</span>
            <span className="text-base font-extrabold text-slate-900 dark:text-white">
              {metrics ? metrics.slaBreached : complaints.filter(c => c.slaStatus === 'BREACHED').length}
            </span>
          </div>
        </div>

        <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-bold">
            <CheckCircle2 className="w-4 h-4" />
          </div>
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">Resolution Rate</span>
            <span className="text-base font-extrabold text-slate-900 dark:text-white">
              {metrics ? `${metrics.resolutionRate.toFixed(0)}%` : '—'}
            </span>
          </div>
        </div>
      </div>

      {error && (
        <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-2xl flex items-center gap-2.5 text-xs text-rose-600 dark:text-rose-400">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Complaints Table */}
      <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-850 text-slate-500 dark:text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-200 dark:border-slate-800">
              <tr>
                <th className="px-4 py-3">Ticket # & Priority</th>
                <th className="px-4 py-3">Complainant</th>
                <th className="px-4 py-3">Subject & Category</th>
                <th className="px-4 py-3">Assigned Dept / Staff</th>
                <th className="px-4 py-3">SLA Status</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-300">
              {loading && complaints.length === 0 ? (
                <tr>
                  <td colSpan={7} className="text-center py-12 text-slate-400">
                    <RefreshCw className="w-6 h-6 animate-spin mx-auto mb-2 text-indigo-500" />
                    Loading complaint tickets...
                  </td>
                </tr>
              ) : complaints.length === 0 ? (
                <tr>
                  <td colSpan={7} className="text-center py-12 text-slate-400">
                    <CheckCircle2 className="w-8 h-8 mx-auto mb-2 text-slate-300 dark:text-slate-600" />
                    No grievance records found matching criteria.
                  </td>
                </tr>
              ) : (
                complaints.map(item => {
                  return (
                    <tr key={item.id} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40 transition">
                      {/* Ticket # & Priority */}
                      <td className="px-4 py-3">
                        <div className="space-y-1">
                          <div className="flex items-center gap-1.5">
                            <span className="font-mono font-bold text-slate-900 dark:text-white block">
                              {item.complaintNumber}
                            </span>
                            {item.isEscalated && (
                              <span
                                className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-rose-600 text-white flex items-center gap-0.5"
                                title={`Escalated: ${item.escalationLevel}`}
                              >
                                <Flame className="w-2.5 h-2.5" />
                                ESC
                              </span>
                            )}
                          </div>
                          <span className={`inline-block px-2 py-0.5 text-[10px] font-bold rounded-full border ${getPriorityBadge(item.priority)}`}>
                            {item.priority}
                          </span>
                        </div>
                      </td>

                      {/* Complainant */}
                      <td className="px-4 py-3">
                        <div>
                          <span className="font-bold text-slate-900 dark:text-white block">
                            {item.complainantName}
                          </span>
                          <span className="text-[11px] text-slate-500 block">
                            {item.complainantType} • <span className="font-mono">{item.phone}</span>
                          </span>
                        </div>
                      </td>

                      {/* Subject & Category */}
                      <td className="px-4 py-3 max-w-[280px]">
                        <div>
                          <span className="font-semibold text-slate-800 dark:text-slate-200 block truncate">
                            {item.subject}
                          </span>
                          <div className="flex items-center gap-1.5 mt-0.5">
                            <span className="text-[10px] font-medium text-indigo-600 dark:text-indigo-400">
                              {item.category.replace('_', ' ')}
                            </span>
                            {item.originatingCallNumber && (
                              <span className="text-[9px] px-1.5 py-0.2 rounded bg-blue-500/10 text-blue-600 dark:text-blue-400 font-mono flex items-center gap-0.5">
                                <Phone className="w-2.5 h-2.5" />
                                {item.originatingCallNumber}
                              </span>
                            )}
                          </div>
                        </div>
                      </td>

                      {/* Assigned Dept & Staff */}
                      <td className="px-4 py-3">
                        <div>
                          <span className="font-semibold text-slate-800 dark:text-slate-200 block">
                            {item.assignedStaffName || 'General Desk'}
                          </span>
                          <span className="text-[10px] text-slate-400 block">
                            {item.assignedDepartment}
                          </span>
                        </div>
                      </td>

                      {/* SLA Status */}
                      <td className="px-4 py-3">
                        {getSlaBadge(item.slaStatus, item.slaHoursRemaining)}
                      </td>

                      {/* Status */}
                      <td className="px-4 py-3">
                        <div className="space-y-0.5">
                          <span className={`inline-block px-2.5 py-0.5 text-[10px] font-bold rounded-full border ${getStatusBadge(item.status)}`}>
                            {item.status.replace('_', ' ')}
                          </span>
                          {item.feedbackRating && (
                            <div className="flex items-center gap-1 text-[10px] text-amber-500">
                              <Star className="w-3 h-3 fill-amber-400" />
                              <span>{item.feedbackRating}/5</span>
                            </div>
                          )}
                        </div>
                      </td>

                      {/* Action */}
                      <td className="px-4 py-3 text-right">
                        <button
                          onClick={() => {
                            setSelectedComplaint(item);
                            setIsDetailModalOpen(true);
                          }}
                          className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 rounded-lg transition"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          View / Resolve
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* New Complaint Modal */}
      <NewComplaintModal
        isOpen={isNewModalOpen}
        onClose={() => setIsNewModalOpen(false)}
        staffList={staffList}
        onSuccess={() => {
          loadComplaints();
          if (onRefreshStats) onRefreshStats();
        }}
      />

      {/* Detail / Resolution Modal */}
      <ComplaintDetailModal
        complaint={selectedComplaint}
        isOpen={isDetailModalOpen}
        onClose={() => {
          setIsDetailModalOpen(false);
          setSelectedComplaint(null);
        }}
        staffList={staffList}
        onUpdated={() => {
          loadComplaints();
          if (onRefreshStats) onRefreshStats();
        }}
      />
    </div>
  );
};
