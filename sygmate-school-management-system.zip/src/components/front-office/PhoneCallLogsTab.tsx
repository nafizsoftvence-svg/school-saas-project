import React, { useState, useEffect } from 'react';
import {
  Phone,
  PhoneIncoming,
  PhoneOutgoing,
  Search,
  Plus,
  RefreshCw,
  Clock,
  Calendar,
  AlertCircle,
  PhoneMissed,
  ShieldAlert,
  Eye
} from 'lucide-react';
import { api } from '../../services/api';
import { PhoneCallLogRecord, CallMetricsSummary, ComplaintRecord } from '../../types';
import { NewCallLogModal } from './NewCallLogModal';
import { CallDetailModal } from './CallDetailModal';

interface PhoneCallLogsTabProps {
  onRefreshStats?: () => void;
  staffList?: Array<{ id: string; name: string; department?: string }>;
  onViewComplaint?: (complaint: ComplaintRecord) => void;
}

export const PhoneCallLogsTab: React.FC<PhoneCallLogsTabProps> = ({
  onRefreshStats,
  staffList = [],
  onViewComplaint
}) => {
  const [calls, setCalls] = useState<PhoneCallLogRecord[]>([]);
  const [metrics, setMetrics] = useState<CallMetricsSummary | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Filters
  const [search, setSearch] = useState('');
  const [directionFilter, setDirectionFilter] = useState('');
  const [typeFilter, setTypeFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [followUpStatusFilter, setFollowUpStatusFilter] = useState('');
  const [followUpFilter, setFollowUpFilter] = useState(false);

  // Modals
  const [isNewModalOpen, setIsNewModalOpen] = useState(false);
  const [selectedCall, setSelectedCall] = useState<PhoneCallLogRecord | null>(null);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);

  const loadCalls = async () => {
    try {
      setLoading(true);
      setError(null);
      const [callsRes, metricsRes] = await Promise.all([
        api.frontOffice.getCalls({
          search: search || undefined,
          direction: directionFilter || undefined,
          callType: typeFilter || undefined,
          status: statusFilter || undefined,
          followUpRequired: followUpFilter || undefined,
          followUpStatus: followUpStatusFilter || undefined,
          limit: 100
        }),
        api.frontOffice.getCallMetricsSummary().catch(() => ({ success: false, data: null }))
      ]);

      if (callsRes.success && callsRes.data) {
        setCalls(callsRes.data);
      } else {
        setError(callsRes.error || 'Failed to fetch phone call logs.');
      }

      if (metricsRes && metricsRes.success && metricsRes.data) {
        setMetrics(metricsRes.data);
      }
    } catch (err: any) {
      setError(err.message || 'Error loading phone call logs.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadCalls();
  }, [directionFilter, typeFilter, statusFilter, followUpStatusFilter, followUpFilter]);

  const formatDuration = (seconds?: number) => {
    if (!seconds || seconds <= 0) return '0s';
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    if (mins === 0) return `${secs}s`;
    return `${mins}m ${secs}s`;
  };

  const missedCount = metrics ? metrics.missed : calls.filter(c => c.status === 'MISSED' || c.status === 'NO_ANSWER').length;
  const followUpPendingCount = metrics ? metrics.callbacksPending : calls.filter(c => c.followUpRequired && c.followUpStatus !== 'COMPLETED').length;
  const convertedCount = metrics ? metrics.convertedToComplaintCount : calls.filter(c => Boolean(c.convertedToComplaintNumber)).length;

  return (
    <div className="space-y-4">
      {/* Top search & filter bar */}
      <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex flex-wrap items-center justify-between gap-3 shadow-sm">
        <div className="flex flex-wrap items-center gap-2.5 flex-1 min-w-[280px]">
          {/* Search box */}
          <div className="relative flex-1 min-w-[200px]">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && loadCalls()}
              placeholder="Search caller name, phone #, topic, or staff member..."
              className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* Direction Filter */}
          <select
            value={directionFilter}
            onChange={e => setDirectionFilter(e.target.value)}
            className="px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="">All Directions</option>
            <option value="INCOMING">Incoming</option>
            <option value="OUTGOING">Outgoing</option>
          </select>

          {/* Type Filter */}
          <select
            value={typeFilter}
            onChange={e => setTypeFilter(e.target.value)}
            className="px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="">All Call Types</option>
            <option value="ADMISSION_INQUIRY">Admission Inquiry</option>
            <option value="GENERAL_QUERY">General Query</option>
            <option value="FEE_QUERY">Fee / Billing Query</option>
            <option value="COMPLAINT">Complaint</option>
            <option value="EMERGENCY">Emergency</option>
            <option value="ROUTINE">Routine Follow-up</option>
          </select>

          {/* Status Filter */}
          <select
            value={statusFilter}
            onChange={e => setStatusFilter(e.target.value)}
            className="px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="">All Outcomes</option>
            <option value="COMPLETED">Completed</option>
            <option value="MISSED">Missed</option>
            <option value="BUSY">Line Busy</option>
            <option value="NO_ANSWER">No Answer</option>
            <option value="VOICEMAIL">Voicemail</option>
          </select>

          {/* Follow-up Status filter */}
          <select
            value={followUpStatusFilter}
            onChange={e => setFollowUpStatusFilter(e.target.value)}
            className="px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="">All Follow-up Statuses</option>
            <option value="PENDING">Pending Callback</option>
            <option value="COMPLETED">Completed Callback</option>
            <option value="CANCELLED">Cancelled</option>
          </select>

          {/* Follow-up required toggle button */}
          <button
            onClick={() => setFollowUpFilter(!followUpFilter)}
            className={`px-3 py-1.5 text-xs font-semibold rounded-xl border transition ${
              followUpFilter
                ? 'bg-amber-500/10 border-amber-500/40 text-amber-600 dark:text-amber-400'
                : 'border-slate-300 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            Follow-Up Needed
          </button>
        </div>

        {/* Buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={loadCalls}
            className="p-2 text-slate-500 hover:text-slate-900 dark:hover:text-white rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition"
            title="Refresh Calls"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>

          <button
            onClick={() => setIsNewModalOpen(true)}
            className="px-3.5 py-1.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl transition shadow-sm inline-flex items-center gap-1.5"
          >
            <Plus className="w-3.5 h-3.5" />
            Log Call
          </button>
        </div>
      </div>

      {/* KPI Stats Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400 flex items-center justify-center font-bold">
            <Phone className="w-4 h-4" />
          </div>
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">Total Calls</span>
            <span className="text-base font-extrabold text-slate-900 dark:text-white">{metrics?.total ?? calls.length}</span>
          </div>
        </div>

        <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-amber-50 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400 flex items-center justify-center font-bold">
            <Clock className="w-4 h-4" />
          </div>
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">Callbacks Pending</span>
            <span className="text-base font-extrabold text-slate-900 dark:text-white">{followUpPendingCount}</span>
          </div>
        </div>

        <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 flex items-center justify-center font-bold">
            <ShieldAlert className="w-4 h-4" />
          </div>
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">Converted Grievances</span>
            <span className="text-base font-extrabold text-slate-900 dark:text-white">{convertedCount}</span>
          </div>
        </div>

        <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 flex items-center justify-center font-bold">
            <PhoneMissed className="w-4 h-4" />
          </div>
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">Missed Calls</span>
            <span className="text-base font-extrabold text-slate-900 dark:text-white">{missedCount}</span>
          </div>
        </div>
      </div>

      {error && (
        <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-2xl flex items-center gap-2.5 text-xs text-rose-600 dark:text-rose-400">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Phone Call Logs Table */}
      <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-850 text-slate-500 dark:text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-200 dark:border-slate-800">
              <tr>
                <th className="px-4 py-3">Call Ref & Type</th>
                <th className="px-4 py-3">Caller Info</th>
                <th className="px-4 py-3">Topic & Summary</th>
                <th className="px-4 py-3">Attending Staff</th>
                <th className="px-4 py-3">Date & Time</th>
                <th className="px-4 py-3">Status / Grievance</th>
                <th className="px-4 py-3">Follow-Up</th>
                <th className="px-4 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-300">
              {loading && calls.length === 0 ? (
                <tr>
                  <td colSpan={8} className="text-center py-12 text-slate-400">
                    <RefreshCw className="w-6 h-6 animate-spin mx-auto mb-2 text-indigo-500" />
                    Loading phone records...
                  </td>
                </tr>
              ) : calls.length === 0 ? (
                <tr>
                  <td colSpan={8} className="text-center py-12 text-slate-400">
                    <Phone className="w-8 h-8 mx-auto mb-2 text-slate-300 dark:text-slate-600" />
                    No telephone logs found matching your filter criteria.
                  </td>
                </tr>
              ) : (
                calls.map(call => {
                  const isIncoming = call.direction === 'INCOMING';
                  return (
                    <tr key={call.id} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40 transition">
                      {/* Ref & Direction */}
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <div
                            className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 ${
                              isIncoming
                                ? 'bg-blue-500/10 text-blue-600 dark:text-blue-400'
                                : 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
                            }`}
                            title={isIncoming ? 'Incoming' : 'Outgoing'}
                          >
                            {isIncoming ? <PhoneIncoming className="w-3.5 h-3.5" /> : <PhoneOutgoing className="w-3.5 h-3.5" />}
                          </div>
                          <div>
                            <span className="font-mono font-bold text-slate-900 dark:text-white block">
                              {call.callNumber || call.callLogNumber}
                            </span>
                            <span className="text-[10px] text-slate-400 uppercase font-semibold">
                              {call.callType.replace('_', ' ')}
                            </span>
                          </div>
                        </div>
                      </td>

                      {/* Caller */}
                      <td className="px-4 py-3">
                        <div>
                          <span className="font-bold text-slate-900 dark:text-white block">
                            {call.callerName}
                          </span>
                          <button
                            onClick={() => {
                              setSelectedCall(call);
                              setIsDetailModalOpen(true);
                            }}
                            className="font-mono text-[11px] text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1"
                            title="View caller history"
                          >
                            <Phone className="w-3 h-3 text-slate-400" />
                            {call.phone || call.callerPhone}
                          </button>
                        </div>
                      </td>

                      {/* Topic & Summary */}
                      <td className="px-4 py-3 max-w-[260px]">
                        <div>
                          <span className="font-semibold text-slate-800 dark:text-slate-200 block truncate">
                            {call.purpose}
                          </span>
                          {(call.summaryNotes || call.summary) && (
                            <span className="text-[11px] text-slate-400 line-clamp-1 italic">
                              "{call.summaryNotes || call.summary}"
                            </span>
                          )}
                        </div>
                      </td>

                      {/* Attending Staff */}
                      <td className="px-4 py-3">
                        <div>
                          <span className="font-semibold text-slate-800 dark:text-slate-200 block">
                            {call.assignedStaffName || 'Reception Desk'}
                          </span>
                          <span className="text-[10px] text-slate-400 block">
                            {call.department || 'Front Office'}
                          </span>
                        </div>
                      </td>

                      {/* Date, Time & Duration */}
                      <td className="px-4 py-3">
                        <div className="text-[11px] space-y-0.5">
                          <span className="font-semibold text-slate-900 dark:text-white block">
                            {call.callDate} at {call.callTime}
                          </span>
                          <span className="font-mono text-slate-500 block">
                            Duration: {formatDuration(call.durationSeconds)}
                          </span>
                        </div>
                      </td>

                      {/* Status & Converted Badge */}
                      <td className="px-4 py-3">
                        <div className="space-y-1">
                          <span
                            className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                              call.status === 'COMPLETED'
                                ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
                                : call.status === 'MISSED'
                                ? 'bg-rose-500/10 text-rose-600 dark:text-rose-400'
                                : 'bg-amber-500/10 text-amber-600 dark:text-amber-400'
                            }`}
                          >
                            {call.status}
                          </span>

                          {call.convertedToComplaintNumber && (
                            <span className="block text-[10px] font-mono font-bold text-rose-600 dark:text-rose-400">
                              Ticket: {call.convertedToComplaintNumber}
                            </span>
                          )}
                        </div>
                      </td>

                      {/* Follow-Up */}
                      <td className="px-4 py-3">
                        {call.followUpRequired ? (
                          <div
                            className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-lg border text-[10px] font-bold ${
                              call.followUpStatus === 'COMPLETED'
                                ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-600 dark:text-emerald-400'
                                : 'bg-amber-500/10 border-amber-500/30 text-amber-600 dark:text-amber-400'
                            }`}
                          >
                            <Calendar className="w-3 h-3" />
                            {call.followUpStatus === 'COMPLETED' ? 'Done' : call.followUpDate || 'Pending'}
                          </div>
                        ) : (
                          <span className="text-[11px] text-slate-400 font-medium">None</span>
                        )}
                      </td>

                      {/* Actions */}
                      <td className="px-4 py-3 text-right">
                        <button
                          onClick={() => {
                            setSelectedCall(call);
                            setIsDetailModalOpen(true);
                          }}
                          className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 rounded-lg transition"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          Details
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* New Call Modal */}
      <NewCallLogModal
        isOpen={isNewModalOpen}
        onClose={() => setIsNewModalOpen(false)}
        staffList={staffList}
        onSuccess={() => {
          loadCalls();
          if (onRefreshStats) onRefreshStats();
        }}
      />

      {/* Call Detail / Conversion / History Modal */}
      <CallDetailModal
        call={selectedCall}
        isOpen={isDetailModalOpen}
        onClose={() => {
          setIsDetailModalOpen(false);
          setSelectedCall(null);
        }}
        staffList={staffList}
        onUpdated={() => {
          loadCalls();
          if (onRefreshStats) onRefreshStats();
        }}
        onComplaintCreated={comp => {
          loadCalls();
          if (onRefreshStats) onRefreshStats();
          if (onViewComplaint) onViewComplaint(comp);
        }}
      />
    </div>
  );
};
