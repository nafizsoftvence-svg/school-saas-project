import React, { useState } from 'react';
import { X, Save, AlertCircle, User, Phone, Building, Tag, ShieldAlert } from 'lucide-react';
import { api } from '../../services/api';
import { ComplaintRecord, ComplaintCategory, ComplaintPriority, ComplainantType } from '../../types';

interface NewComplaintModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (complaint: ComplaintRecord) => void;
  staffList?: Array<{ id: string; name: string; department?: string }>;
}

export const NewComplaintModal: React.FC<NewComplaintModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  staffList = []
}) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    complainantName: '',
    phone: '',
    email: '',
    complainantType: 'PARENT' as ComplainantType,
    category: 'INFRASTRUCTURE' as ComplaintCategory,
    priority: 'MEDIUM' as ComplaintPriority,
    subject: '',
    description: '',
    assignedDepartment: 'Administration',
    assignedStaffId: '',
    assignedStaffName: '',
    immediateActionTaken: ''
  });

  if (!isOpen) return null;

  const handleStaffChange = (staffId: string) => {
    const st = (staffList || []).find(s => s?.id === staffId);
    if (st) {
      setFormData(prev => ({
        ...prev,
        assignedStaffId: st.id,
        assignedStaffName: st.name,
        assignedDepartment: st.department || prev.assignedDepartment
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        assignedStaffId: '',
        assignedStaffName: ''
      }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.complainantName.trim() || !formData.phone.trim() || !formData.subject.trim() || !formData.description.trim()) {
      setError('Complainant Name, Phone Number, Subject, and Description are required.');
      return;
    }

    try {
      setLoading(true);
      setError(null);
      const res = await api.frontOffice.createComplaint(formData);
      if (res.success && res.data) {
        onSuccess(res.data);
        onClose();
      } else {
        setError(res.error || 'Failed to file complaint.');
      }
    } catch (err: any) {
      setError(err.message || 'Error occurred while saving complaint.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-xl shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-slate-800/40">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-rose-500/10 text-rose-600 dark:text-rose-400 flex items-center justify-center font-bold">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">Register Grievance / Complaint</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">File official complaint ticket with SLA tracking</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {error && (
          <div className="mx-6 mt-4 p-3 bg-rose-500/10 border border-rose-500/30 rounded-2xl flex items-center gap-2.5 text-xs text-rose-600 dark:text-rose-400">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Complainant Name */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Complainant Name *
              </label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  required
                  value={formData.complainantName}
                  onChange={e => setFormData({ ...formData, complainantName: e.target.value })}
                  placeholder="e.g. Martha Stewart"
                  className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>

            {/* Contact Phone */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Contact Phone *
              </label>
              <div className="relative">
                <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="tel"
                  required
                  value={formData.phone}
                  onChange={e => setFormData({ ...formData, phone: e.target.value })}
                  placeholder="+1 (555) 000-0000"
                  className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono"
                />
              </div>
            </div>

            {/* Complainant Type */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Complainant Role
              </label>
              <select
                value={formData.complainantType}
                onChange={e => setFormData({ ...formData, complainantType: e.target.value as ComplainantType })}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="PARENT">Parent / Guardian</option>
                <option value="STUDENT">Student</option>
                <option value="TEACHER">Teacher</option>
                <option value="STAFF">Non-Teaching Staff</option>
                <option value="VISITOR">Visitor</option>
                <option value="NEIGHBOR_COMMUNITY">Local Community</option>
              </select>
            </div>

            {/* Category */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Complaint Category
              </label>
              <select
                value={formData.category}
                onChange={e => setFormData({ ...formData, category: e.target.value as ComplaintCategory })}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="INFRASTRUCTURE">Infrastructure & Facilities</option>
                <option value="TRANSPORT">Transport & Bus Service</option>
                <option value="ACADEMIC">Academic / Curriculum</option>
                <option value="FEE_BILLING">Fee & Billing</option>
                <option value="FOOD_CANTEEN">Food & Canteen</option>
                <option value="DISCIPLINE_BULLYING">Student Discipline / Bullying</option>
                <option value="SECURITY">Campus Safety & Security</option>
                <option value="STAFF_BEHAVIOR">Staff Conduct</option>
                <option value="OTHER">Other Issue</option>
              </select>
            </div>

            {/* Priority */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Urgency / Priority
              </label>
              <select
                value={formData.priority}
                onChange={e => setFormData({ ...formData, priority: e.target.value as ComplaintPriority })}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="LOW">Low (Routine)</option>
                <option value="MEDIUM">Medium (Standard)</option>
                <option value="HIGH">High (Important)</option>
                <option value="URGENT">Urgent (Immediate attention)</option>
              </select>
            </div>

            {/* Assignee Staff */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Assign To Staff Member
              </label>
              <select
                value={formData.assignedStaffId}
                onChange={e => handleStaffChange(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="">Auto-route to Department Lead</option>
                {staffList.map(st => (
                  <option key={st.id} value={st.id}>
                    {st.name} ({st.department || 'General'})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Subject */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Complaint Subject / Headline *
            </label>
            <input
              type="text"
              required
              value={formData.subject}
              onChange={e => setFormData({ ...formData, subject: e.target.value })}
              placeholder="e.g. Air conditioning not working in Physics Laboratory"
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Detailed Description *
            </label>
            <textarea
              required
              rows={3}
              value={formData.description}
              onChange={e => setFormData({ ...formData, description: e.target.value })}
              placeholder="Describe the complaint in detail, including locations, specific incidents, or people involved..."
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* Immediate Action Taken */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Immediate Front-Desk Action Taken (Optional)
            </label>
            <input
              type="text"
              value={formData.immediateActionTaken}
              onChange={e => setFormData({ ...formData, immediateActionTaken: e.target.value })}
              placeholder="e.g. Notified maintenance team on radio; ticket escalated"
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* Footer */}
          <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-5 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-xl transition shadow-sm inline-flex items-center gap-1.5 disabled:opacity-50"
            >
              <Save className="w-3.5 h-3.5" />
              {loading ? 'Filing...' : 'Submit Complaint Ticket'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
