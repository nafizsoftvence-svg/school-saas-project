import React, { useState, useEffect } from 'react';
import {
  FileSpreadsheet,
  Download,
  Printer,
  Calendar,
  Filter,
  RefreshCw,
  BarChart3,
  TrendingUp,
  CheckCircle2,
  Clock,
  Shield,
  Phone,
  ShieldAlert,
  Users,
  Search,
  ChevronDown,
  Layers,
  FileText,
  AlertTriangle,
  Award
} from 'lucide-react';
import { api } from '../../services/api';
import { downloadTablePdf, triggerSafePrint } from '../../utils/printPdf.js';
import {
  FrontOfficeReportType,
  FrontOfficeReportResult,
  DashboardDatePreset,
  AcademicSession,
  SchoolClass
} from '../../types';

interface FrontOfficeReportsTabProps {
  staffList?: Array<{ id: string; name: string; department?: string }>;
  sessions?: AcademicSession[];
  classes?: SchoolClass[];
}

const REPORT_GROUPS: {
  category: string;
  reports: { value: FrontOfficeReportType; label: string; desc: string }[];
}[] = [
  {
    category: 'Admission Enquiries',
    reports: [
      {
        value: 'ENQUIRY_REGISTER',
        label: 'Admission Enquiry Master Register',
        desc: 'Comprehensive register of all prospective student enquiries'
      },
      {
        value: 'ENQUIRY_CONVERSION',
        label: 'Admission Conversion Funnel Report',
        desc: 'Pipeline progression from initial enquiry to enrolled status'
      },
      {
        value: 'ENQUIRY_FOLLOWUP',
        label: 'Enquiry Follow-up & Callback Schedule',
        desc: 'Pending, due today, and overdue follow-up communications'
      },
      {
        value: 'ENQUIRY_SOURCE',
        label: 'Enquiry Source Effectiveness & ROI',
        desc: 'Distribution and conversion rate across marketing sources'
      },
      {
        value: 'ENQUIRY_STATUS',
        label: 'Enquiry Status Distribution Ledger',
        desc: 'Summary of enquiries broken down by current processing state'
      }
    ]
  },
  {
    category: 'Campus Visitors',
    reports: [
      {
        value: 'VISITOR_REGISTER',
        label: 'Campus Visitor Master Register',
        desc: 'Complete log of all campus visits and security badge issuances'
      },
      {
        value: 'VISITOR_CURRENTLY_INSIDE',
        label: 'Visitors Currently Inside Campus',
        desc: 'Active on-premise visitors for safety and security roll calls'
      },
      {
        value: 'VISITOR_EXPECTED',
        label: 'Scheduled & Expected Visitors',
        desc: 'Upcoming appointments and pre-registered guest itineraries'
      },
      {
        value: 'VISITOR_COMPLETED',
        label: 'Completed Visits & Check-outs Log',
        desc: 'Historical visit log with verified durations and departure times'
      },
      {
        value: 'VISITOR_CANCELLED',
        label: 'Cancelled & No-Show Visits',
        desc: 'Declined passes, cancellations, and missed appointments'
      },
      {
        value: 'VISITOR_SUMMARY',
        label: 'Visitor Traffic & Department Summary',
        desc: 'Cross-department visitor volume, host loads, and dwell time'
      }
    ]
  },
  {
    category: 'Phone Call Logs',
    reports: [
      {
        value: 'CALL_REGISTER',
        label: 'Phone Call Master Register',
        desc: 'Complete log of inbound and outbound telephonic communications'
      },
      {
        value: 'CALLS_FOLLOWUP_REQUIRED',
        label: 'Pending Callbacks & Follow-up Queue',
        desc: 'Unresolved calls requiring front office callback action'
      },
      {
        value: 'CALLS_MISSED',
        label: 'Missed Calls & Unattended Logs',
        desc: 'Unanswered incoming inquiries flagged for swift response'
      },
      {
        value: 'CALLS_DIRECTION',
        label: 'Call Direction & Traffic Analysis',
        desc: 'Inbound vs outbound volume comparisons and peak timing'
      },
      {
        value: 'CALLS_TYPE_SUMMARY',
        label: 'Call Nature & Purpose Distribution',
        desc: 'Categorization by academic, administrative, and fee queries'
      }
    ]
  },
  {
    category: 'Grievance & Complaints',
    reports: [
      {
        value: 'COMPLAINT_REGISTER',
        label: 'Grievance Desk Master Register',
        desc: 'Official ledger of registered complaints and escalated issues'
      },
      {
        value: 'COMPLAINT_OPEN',
        label: 'Open & In-Progress Complaints',
        desc: 'Active grievances under investigation by departments'
      },
      {
        value: 'COMPLAINT_OVERDUE',
        label: 'SLA Breached & Overdue Complaints',
        desc: 'Tickets exceeding turnaround SLA targets requiring intervention'
      },
      {
        value: 'COMPLAINT_RESOLVED',
        label: 'Resolved Complaints & SLA Compliance',
        desc: 'Closed and resolved cases with resolution turn-around times'
      },
      {
        value: 'COMPLAINT_PRIORITY',
        label: 'Priority & Severity Matrix',
        desc: 'Urgent, High, Medium, and Low grievance distribution'
      },
      {
        value: 'COMPLAINT_CATEGORY',
        label: 'Category & Department Breakdown',
        desc: 'Academic, transport, fee, facility, and discipline grievances'
      }
    ]
  },
  {
    category: 'Cross-Office Workload',
    reports: [
      {
        value: 'STAFF_ASSIGNMENT',
        label: 'Front Office Staff Workload & Interactions',
        desc: 'Comprehensive interaction counts per staff member across modules'
      }
    ]
  }
];

const PRESET_OPTIONS: { id: DashboardDatePreset; label: string }[] = [
  { id: 'TODAY', label: 'Today' },
  { id: 'YESTERDAY', label: 'Yesterday' },
  { id: 'THIS_WEEK', label: 'This Week' },
  { id: 'LAST_7_DAYS', label: 'Last 7 Days' },
  { id: 'THIS_MONTH', label: 'This Month' },
  { id: 'LAST_30_DAYS', label: 'Last 30 Days' },
  { id: 'THIS_ACADEMIC_YEAR', label: 'Academic Year' },
  { id: 'CUSTOM', label: 'Custom' }
];

export const FrontOfficeReportsTab: React.FC<FrontOfficeReportsTabProps> = ({
  staffList = [],
  sessions = [],
  classes = []
}) => {
  const [reportType, setReportType] = useState<FrontOfficeReportType>('ENQUIRY_REGISTER');
  const [datePreset, setDatePreset] = useState<DashboardDatePreset>('THIS_MONTH');
  const [startDate, setStartDate] = useState<string>('');
  const [endDate, setEndDate] = useState<string>('');
  const [academicSessionId, setAcademicSessionId] = useState<string>('');
  const [status, setStatus] = useState<string>('ALL');
  const [department, setDepartment] = useState<string>('ALL');
  const [assignedStaffId, setAssignedStaffId] = useState<string>('ALL');
  const [search, setSearch] = useState<string>('');

  const [loading, setLoading] = useState<boolean>(false);
  const [reportData, setReportData] = useState<FrontOfficeReportResult | null>(null);
  const [showPrintModal, setShowPrintModal] = useState<boolean>(false);

  const loadReport = async () => {
    try {
      setLoading(true);
      const filterParams = {
        reportType,
        datePreset,
        startDate: datePreset === 'CUSTOM' ? startDate : undefined,
        endDate: datePreset === 'CUSTOM' ? endDate : undefined,
        academicSessionId: academicSessionId || undefined,
        status: status !== 'ALL' ? status : undefined,
        department: department !== 'ALL' ? department : undefined,
        assignedStaffId: assignedStaffId !== 'ALL' ? assignedStaffId : undefined,
        search: search.trim() || undefined
      };

      const res = await api.frontOffice.getReports(filterParams);
      if (res.success && res.data) {
        setReportData(res.data);
      }
    } catch (err: any) {
      console.error('Failed to load front office report:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadReport();
  }, [reportType, datePreset, academicSessionId, status, department, assignedStaffId]);

  const handleExportCSV = () => {
    if (!reportData?.records || reportData.records.length === 0) {
      alert('No data available to export.');
      return;
    }

    const exportUrl = api.frontOffice.exportReportsUrl({
      reportType,
      datePreset,
      startDate: datePreset === 'CUSTOM' ? startDate : undefined,
      endDate: datePreset === 'CUSTOM' ? endDate : undefined,
      academicSessionId: academicSessionId || undefined,
      status: status !== 'ALL' ? status : undefined,
      department: department !== 'ALL' ? department : undefined,
      assignedStaffId: assignedStaffId !== 'ALL' ? assignedStaffId : undefined,
      search: search.trim() || undefined,
      format: 'csv'
    });

    // Secure token fetch and download trigger
    const token = localStorage.getItem('sygmate_auth_token') || localStorage.getItem('token');
    fetch(exportUrl, {
      headers: token ? { Authorization: `Bearer ${token}` } : {}
    })
      .then(res => res.blob())
      .then(blob => {
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `FrontOffice_${reportType}_${new Date().toISOString().split('T')[0]}.csv`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
      })
      .catch(err => {
        console.error('CSV Export failed', err);
        alert('Export failed. Please check permissions.');
      });
  };

  const [isExporting, setIsExporting] = useState(false);

  const handlePrint = async () => {
    if (!reportData || !reportData.records || reportData.records.length === 0) {
      alert('No ledger records available to print.');
      return;
    }

    try {
      setIsExporting(true);
      const cols =
        reportData.exportColumns && reportData.exportColumns.length > 0
          ? reportData.exportColumns.map(c => ({ header: c.label, dataKey: c.key }))
          : Object.keys(reportData.records[0])
              .filter(k => typeof reportData.records[0][k] !== 'object' && k !== 'id')
              .slice(0, 8)
              .map(col => ({ header: col.replace(/([A-Z])/g, ' $1'), dataKey: col }));

      const filename = `FrontOffice_${reportType}_${new Date().toISOString().split('T')[0]}.pdf`;

      await downloadTablePdf({
        title: reportData.reportTitle || `Front Office ${reportType} Report`,
        subtitle: `Timeframe: ${startDate} to ${endDate} | Total Records: ${reportData.totalRecords}`,
        columns: cols,
        data: reportData.records,
        filename,
        orientation: cols.length > 5 ? 'landscape' : 'portrait'
      });

      await triggerSafePrint({
        elementOrId: 'printable-front-office-ledger',
        fallbackTitle: `FrontOffice_${reportType}`
      });
    } catch (err) {
      console.error('Front Office print/PDF error:', err);
      try {
        window.print();
      } catch {
        // ignore
      }
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Configuration & Filter Panel */}
      <div className="p-5 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        {/* Top Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100 dark:border-slate-800">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <FileSpreadsheet className="w-4 h-4 text-indigo-600" />
              Front Office Official Ledgers & Reports
            </h3>
            <p className="text-xs text-slate-500">
              Audit-ready registers, SLA metrics, and operational reports across all front desk channels
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              disabled={isExporting}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 disabled:opacity-50 rounded-xl transition"
            >
              <Printer className="w-3.5 h-3.5" />
              {isExporting ? 'Generating PDF...' : 'Print / Save PDF'}
            </button>

            <button
              onClick={handleExportCSV}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl transition shadow-sm"
            >
              <Download className="w-3.5 h-3.5" />
              Export CSV
            </button>
          </div>
        </div>

        {/* Row 1: Report Subject Picker */}
        <div>
          <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">
            Select Official Report
          </label>
          <div className="relative">
            <select
              value={reportType}
              onChange={e => setReportType(e.target.value as FrontOfficeReportType)}
              className="w-full px-3.5 py-2.5 text-xs font-bold rounded-2xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 appearance-none cursor-pointer"
            >
              {REPORT_GROUPS.map(group => (
                <optgroup key={group.category} label={`━━━ ${group.category} ━━━`}>
                  {group.reports.map(rep => (
                    <option key={rep.value} value={rep.value}>
                      {rep.label}
                    </option>
                  ))}
                </optgroup>
              ))}
            </select>
            <ChevronDown className="w-4 h-4 absolute right-3.5 top-3 text-slate-400 pointer-events-none" />
          </div>
        </div>

        {/* Row 2: Date Presets & Custom Dates */}
        <div>
          <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1.5 flex items-center gap-1">
            <Calendar className="w-3 h-3" /> Reporting Timeframe Preset
          </label>
          <div className="flex flex-wrap items-center gap-1.5">
            {PRESET_OPTIONS.map(preset => (
              <button
                key={preset.id}
                onClick={() => setDatePreset(preset.id)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-xl transition ${
                  datePreset === preset.id
                    ? 'bg-indigo-600 text-white shadow-sm font-bold'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                }`}
              >
                {preset.label}
              </button>
            ))}

            {datePreset === 'CUSTOM' && (
              <div className="flex items-center gap-2 mt-2 sm:mt-0 sm:ml-2">
                <input
                  type="date"
                  value={startDate}
                  onChange={e => setStartDate(e.target.value)}
                  className="px-2.5 py-1 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
                <span className="text-xs text-slate-400">to</span>
                <input
                  type="date"
                  value={endDate}
                  onChange={e => setEndDate(e.target.value)}
                  className="px-2.5 py-1 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
                <button
                  onClick={loadReport}
                  className="px-3 py-1 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition"
                >
                  Apply
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Row 3: Secondary Multi-parameter Filters */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 pt-2">
          {/* Department Filter */}
          <div>
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
              Department
            </label>
            <select
              value={department}
              onChange={e => setDepartment(e.target.value)}
              className="w-full px-2.5 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
            >
              <option value="ALL">All Departments</option>
              <option value="Administration">Administration</option>
              <option value="Admissions">Admissions</option>
              <option value="Accounts">Accounts & Finance</option>
              <option value="Academics">Academics & Faculty</option>
              <option value="Transport">Transport</option>
              <option value="Hostel">Hostel & Boarding</option>
              <option value="Security">Security</option>
            </select>
          </div>

          {/* Assigned Staff Filter */}
          <div>
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
              Assigned Staff
            </label>
            <select
              value={assignedStaffId}
              onChange={e => setAssignedStaffId(e.target.value)}
              className="w-full px-2.5 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
            >
              <option value="ALL">All Staff Members</option>
              {staffList.map(s => (
                <option key={s.id} value={s.id}>
                  {s.name} {s.department ? `(${s.department})` : ''}
                </option>
              ))}
            </select>
          </div>

          {/* Academic Session */}
          <div>
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
              Academic Session
            </label>
            <select
              value={academicSessionId}
              onChange={e => setAcademicSessionId(e.target.value)}
              className="w-full px-2.5 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
            >
              <option value="">All Academic Sessions</option>
              {sessions.map(s => (
                <option key={s.id} value={s.id}>
                  {s.name} {s.isCurrent ? '(Current)' : ''}
                </option>
              ))}
            </select>
          </div>

          {/* Search Filter */}
          <div>
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
              Search Keywords
            </label>
            <div className="relative">
              <input
                type="text"
                value={search}
                onChange={e => setSearch(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && loadReport()}
                placeholder="Name, number, phone..."
                className="w-full pl-8 pr-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
              />
              <Search className="w-3.5 h-3.5 absolute left-2.5 top-2 text-slate-400" />
            </div>
          </div>
        </div>
      </div>

      {/* Summary Chips / Aggregate Stats */}
      {reportData?.summary && Object.keys(reportData.summary).length > 0 && (
        <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-5 gap-3">
          {Object.entries(reportData.summary).map(([key, val]) => {
            if (typeof val === 'object' && val !== null) {
              return null;
            }
            const isPercent = key.toLowerCase().includes('rate') || key.toLowerCase().includes('percentage');
            return (
              <div
                key={key}
                className="p-3.5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm"
              >
                <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider truncate">
                  {key.replace(/([A-Z])/g, ' $1')}
                </span>
                <span className="text-xl font-black text-slate-900 dark:text-white mt-1 block">
                  {isPercent && typeof val === 'number'
                    ? `${val.toFixed(0)}%`
                    : String(val)}
                </span>
              </div>
            );
          })}
        </div>
      )}

      {/* Data Table */}
      <div
        id="printable-front-office-ledger"
        className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden shadow-sm"
      >
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2">
          <div>
            <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              {reportData?.reportTitle || 'Official Ledger View'}
            </h4>
            {reportData?.timeframe && (
              <span className="text-[10px] text-slate-400">
                Timeframe: {reportData.timeframe.startDate} to {reportData.timeframe.endDate} • Generated by{' '}
                {reportData.generatedBy}
              </span>
            )}
          </div>
          <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
            {reportData?.totalRecords || 0} Records Found
          </span>
        </div>

        <div className="overflow-x-auto">
          {loading ? (
            <div className="text-center py-20 text-slate-400">
              <RefreshCw className="w-7 h-7 animate-spin mx-auto mb-2 text-indigo-600" />
              <p className="text-xs font-semibold">Generating authoritative ledger dataset...</p>
            </div>
          ) : !reportData?.records || reportData.records.length === 0 ? (
            <div className="text-center py-20 text-slate-400 text-xs">
              <FileText className="w-8 h-8 mx-auto mb-2 text-slate-300 dark:text-slate-700" />
              No matching records found for the selected reporting parameters and timeframe.
            </div>
          ) : (
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 dark:bg-slate-850 text-slate-500 uppercase tracking-wider font-semibold border-b border-slate-200 dark:border-slate-800">
                <tr>
                  {reportData.exportColumns && reportData.exportColumns.length > 0
                    ? reportData.exportColumns.map(col => (
                        <th key={col.key} className="px-4 py-3 whitespace-nowrap">
                          {col.label}
                        </th>
                      ))
                    : Object.keys(reportData.records[0])
                        .filter(k => typeof reportData.records[0][k] !== 'object' && k !== 'id')
                        .slice(0, 8)
                        .map(col => (
                          <th key={col} className="px-4 py-3 capitalize whitespace-nowrap">
                            {col.replace(/([A-Z])/g, ' $1')}
                          </th>
                        ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-300">
                {reportData.records.map((row: any, idx: number) => {
                  const columns =
                    reportData.exportColumns && reportData.exportColumns.length > 0
                      ? reportData.exportColumns.map(c => c.key)
                      : Object.keys(row).filter(k => typeof row[k] !== 'object' && k !== 'id').slice(0, 8);

                  return (
                    <tr key={row.id || idx} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40 transition">
                      {columns.map(key => {
                        const val = row[key];
                        const strVal = String(val ?? '—');

                        // Status badge styling
                        if (key.toLowerCase().includes('status')) {
                          let badgeClass = 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300';
                          if (strVal === 'CONVERTED' || strVal === 'RESOLVED' || strVal === 'CHECKED_OUT' || strVal === 'COMPLETED') {
                            badgeClass = 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/50 dark:text-emerald-300';
                          } else if (strVal === 'CHECKED_IN' || strVal === 'IN_PROGRESS' || strVal === 'CONTACTED') {
                            badgeClass = 'bg-indigo-100 text-indigo-800 dark:bg-indigo-950/50 dark:text-indigo-300';
                          } else if (strVal === 'URGENT' || strVal === 'MISSED' || strVal === 'BREACHED' || strVal === 'CANCELLED') {
                            badgeClass = 'bg-rose-100 text-rose-800 dark:bg-rose-950/50 dark:text-rose-300';
                          }
                          return (
                            <td key={key} className="px-4 py-2.5 whitespace-nowrap">
                              <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${badgeClass}`}>
                                {strVal}
                              </span>
                            </td>
                          );
                        }

                        // Priority styling
                        if (key.toLowerCase().includes('priority')) {
                          let pClass = 'text-slate-600';
                          if (strVal === 'URGENT') pClass = 'text-rose-600 font-bold';
                          else if (strVal === 'HIGH') pClass = 'text-amber-600 font-bold';
                          return (
                            <td key={key} className={`px-4 py-2.5 whitespace-nowrap text-[11px] ${pClass}`}>
                              {strVal}
                            </td>
                          );
                        }

                        // Number/ID column
                        if (key.toLowerCase().includes('number') || key.toLowerCase().includes('pass')) {
                          return (
                            <td key={key} className="px-4 py-2.5 whitespace-nowrap font-mono font-bold text-indigo-600 dark:text-indigo-400 text-[11px]">
                              {strVal}
                            </td>
                          );
                        }

                        return (
                          <td key={key} className="px-4 py-2.5 whitespace-nowrap text-[11px]">
                            {strVal}
                          </td>
                        );
                      })}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
};
