import React, { useState, useEffect } from 'react';
import {
  X,
  Phone,
  PhoneIncoming,
  PhoneOutgoing,
  Calendar,
  Clock,
  User,
  Building,
  CheckCircle2,
  AlertCircle,
  ShieldAlert,
  ArrowRight,
  History,
  FileText,
  Tag,
  CheckSquare
} from 'lucide-react';
import { api } from '../../services/api';
import { PhoneCallLogRecord, ComplaintRecord } from '../../types';

interface CallDetailModalProps {
  call: PhoneCallLogRecord | null;
  isOpen: boolean;
  onClose: () => void;
  onUpdated: (call: PhoneCallLogRecord) => void;
  onComplaintCreated?: (complaint: ComplaintRecord) => void;
  staffList?: Array<{ id: string; name: string; department?: string }>;
}

export const CallDetailModal: React.FC<CallDetailModalProps> = ({
  call,
  isOpen,
  onClose,
  onUpdated,
  onComplaintCreated,
  staffList = []
}) => {
  const [activeTab, setActiveTab] = useState<'details' | 'history'>('details');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Phone history state
  const [historyCalls, setHistoryCalls] = useState<PhoneCallLogRecord[]>([]);
  const [historyComplaints, setHistoryComplaints] = useState<ComplaintRecord[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);

  // Complete Follow-up form
  const [isFollowUpOpen, setIsFollowUpOpen] = useState(false);
  const [followUpOutcome, setFollowUpOutcome] = useState('Parent contacted and query resolved');
  const [followUpNotes, setFollowUpNotes] = useState('');

  // Convert to Complaint form
  const [isConvertOpen, setIsConvertOpen] = useState(false);
  const [complaintCategory, setComplaintCategory] = useState('INFRASTRUCTURE');
  const [complaintPriority, setComplaintPriority] = useState('HIGH');
  const [complaintSubject, setComplaintSubject] = useState(call?.purpose || '');
  const [complaintDescription, setComplaintDescription] = useState(call?.summaryNotes || call?.summary || '');
  const [complaintDepartment, setComplaintDepartment] = useState(call?.department || 'Administration');
  const [complaintStaffId, setComplaintStaffId] = useState(call?.assignedStaffId || '');

  // Load history when switching to history tab
  useEffect(() => {
    if (activeTab === 'history' && call?.phone) {
      loadHistory();
    }
  }, [activeTab, call?.phone]);

  if (!isOpen || !call) return null;

  const loadHistory = async () => {
    try {
      setHistoryLoading(true);
      const res = await api.frontOffice.getCallHistoryByPhone(call.phone || call.callerPhone || '');
      if (res.success && res.data) {
        setHistoryCalls(res.data.calls || []);
        setHistoryComplaints(res.data.complaints || []);
      }
    } catch (err: any) {
      console.warn('Failed to load phone history', err);
    } finally {
      setHistoryLoading(false);
    }
  };

  const handleCompleteFollowUp = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setLoading(true);
      setError(null);
      const res = await api.frontOffice.completeCallFollowUp(call.id, {
        toStatus: 'COMPLETED',
        followUpOutcome,
        followUpNotes
      });
      if (res.success && res.data) {
        setSuccessMessage('Follow-up marked as completed successfully.');
        setIsFollowUpOpen(false);
        onUpdated(res.data);
      } else {
        setError(res.error || 'Failed to complete follow-up.');
      }
    } catch (err: any) {
      setError(err.message || 'Error updating follow-up.');
    } finally {
      setLoading(false);
    }
  };

  const handleConvertToComplaint = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setLoading(true);
      setError(null);
      const res = await api.frontOffice.convertCallToComplaint(call.id, {
        complaintCategory,
        priority: complaintPriority,
        subject: complaintSubject,
        description: complaintDescription,
        assignedDepartment: complaintDepartment,
        assignedStaffId: complaintStaffId || undefined,
        complainantType: call.callerType === 'STUDENT' ? 'STUDENT' : call.callerType === 'PARENT' ? 'PARENT' : 'OTHER'
      });
      if (res.success && res.data) {
        setSuccessMessage(`Call successfully converted into Complaint ${res.data.complaint.complaintNumber}!`);
        setIsConvertOpen(false);
        onUpdated(res.data.call);
        if (onComplaintCreated) onComplaintCreated(res.data.complaint);
      } else {
        setError(res.error || 'Failed to convert call to complaint.');
      }
    } catch (err: any) {
      setError(err.message || 'Error converting call to complaint.');
    } finally {
      setLoading(false);
    }
  };

  const formatDuration = (seconds?: number) => {
    if (!seconds || seconds <= 0) return '0s';
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    if (mins === 0) return `${secs}s`;
    return `${mins}m ${secs}s`;
  };

  const isIncoming = call.direction === 'INCOMING';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-2xl shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-slate-800/40">
          <div className="flex items-center gap-3">
            <div
              className={`w-10 h-10 rounded-2xl flex items-center justify-center font-bold ${
                isIncoming
                  ? 'bg-blue-500/10 text-blue-600 dark:text-blue-400'
                  : 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
              }`}
            >
              {isIncoming ? <PhoneIncoming className="w-5 h-5" /> : <PhoneOutgoing className="w-5 h-5" />}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-mono font-bold text-sm text-slate-900 dark:text-white">
                  {call.callNumber || call.callLogNumber}
                </span>
                <span
                  className={`px-2 py-0.5 text-[10px] font-bold rounded-full border ${
                    isIncoming
                      ? 'bg-blue-500/10 text-blue-600 border-blue-500/20'
                      : 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20'
                  }`}
                >
                  {call.direction}
                </span>
                <span className="px-2 py-0.5 text-[10px] font-bold rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                  {call.callType}
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Logged on {call.callDate} at {call.callTime} • Duration: {formatDuration(call.durationSeconds)}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab navigation */}
        <div className="px-6 border-b border-slate-200 dark:border-slate-800 flex gap-4 text-xs font-bold">
          <button
            onClick={() => setActiveTab('details')}
            className={`py-3 border-b-2 transition ${
              activeTab === 'details'
                ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            Call Interaction Details
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`py-3 border-b-2 transition flex items-center gap-1.5 ${
              activeTab === 'history'
                ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            <History className="w-3.5 h-3.5" />
            Caller History ({call.phone})
          </button>
        </div>

        {error && (
          <div className="mx-6 mt-4 p-3 bg-rose-500/10 border border-rose-500/30 rounded-2xl flex items-center gap-2.5 text-xs text-rose-600 dark:text-rose-400">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {successMessage && (
          <div className="mx-6 mt-4 p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-2xl flex items-center gap-2.5 text-xs text-emerald-600 dark:text-emerald-400">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{successMessage}</span>
          </div>
        )}

        <div className="p-6 space-y-5">
          {activeTab === 'details' ? (
            <>
              {/* Converted banner */}
              {call.convertedToComplaintNumber && (
                <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-2xl flex items-center justify-between text-xs text-rose-700 dark:text-rose-300">
                  <div className="flex items-center gap-2">
                    <ShieldAlert className="w-4 h-4 text-rose-600" />
                    <span>
                      <strong>Converted to Formal Grievance Ticket:</strong> {call.convertedToComplaintNumber}
                    </span>
                  </div>
                  <span className="px-2 py-0.5 text-[10px] font-bold rounded-lg bg-rose-600 text-white">
                    Complaint Linked
                  </span>
                </div>
              )}

              {/* Key Information Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Caller Information */}
                <div className="p-3.5 bg-slate-50 dark:bg-slate-850 rounded-2xl border border-slate-200 dark:border-slate-800 text-xs space-y-1.5">
                  <span className="text-[10px] font-bold uppercase text-slate-400 tracking-wider block">Caller Profile</span>
                  <p className="font-bold text-slate-900 dark:text-white text-sm">{call.callerName}</p>
                  <div className="flex items-center gap-1.5 font-mono text-slate-600 dark:text-slate-300">
                    <Phone className="w-3.5 h-3.5 text-slate-400" />
                    {call.phone || call.callerPhone}
                  </div>
                  <div className="text-slate-500 text-[11px]">
                    Role: <span className="font-semibold text-slate-700 dark:text-slate-300">{call.callerType || 'General Public'}</span>
                    {call.relatedEntityName && (
                      <span className="block mt-0.5">
                        Related: <strong>{call.relatedEntityName}</strong> ({call.relatedEntityType})
                      </span>
                    )}
                  </div>
                </div>

                {/* Desk Assignment */}
                <div className="p-3.5 bg-slate-50 dark:bg-slate-850 rounded-2xl border border-slate-200 dark:border-slate-800 text-xs space-y-1.5">
                  <span className="text-[10px] font-bold uppercase text-slate-400 tracking-wider block">Handled By</span>
                  <p className="font-bold text-slate-900 dark:text-white text-sm">
                    {call.assignedStaffName || 'Front Desk Reception'}
                  </p>
                  <p className="text-slate-500 text-[11px]">Department: {call.department || 'Front Office'}</p>
                  <div className="pt-1 flex items-center gap-2">
                    <span
                      className={`px-2 py-0.5 text-[10px] font-bold rounded-full ${
                        call.status === 'COMPLETED'
                          ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
                          : call.status === 'MISSED'
                          ? 'bg-rose-500/10 text-rose-600 dark:text-rose-400'
                          : 'bg-amber-500/10 text-amber-600 dark:text-amber-400'
                      }`}
                    >
                      Call Status: {call.status}
                    </span>
                  </div>
                </div>
              </div>

              {/* Purpose & Detailed Notes */}
              <div className="p-4 bg-slate-50/80 dark:bg-slate-850/60 rounded-2xl border border-slate-200 dark:border-slate-800 text-xs space-y-2">
                <span className="text-[10px] font-bold uppercase text-slate-400 tracking-wider block">Call Purpose & Discussion</span>
                <p className="font-bold text-slate-900 dark:text-white text-sm">{call.purpose}</p>
                {(call.summaryNotes || call.summary) && (
                  <p className="text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-wrap text-xs">
                    {call.summaryNotes || call.summary}
                  </p>
                )}
                {call.notes && (
                  <p className="text-slate-500 italic text-[11px] pt-1 border-t border-slate-200 dark:border-slate-700">
                    Additional notes: {call.notes}
                  </p>
                )}
              </div>

              {/* Action Items if any */}
              {call.actionItems && call.actionItems.length > 0 && (
                <div className="space-y-1.5">
                  <span className="text-xs font-bold text-slate-900 dark:text-white block">Action Items Captured</span>
                  <div className="space-y-1">
                    {call.actionItems.map((item, idx) => (
                      <div
                        key={idx}
                        className="p-2 rounded-xl bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-800 text-xs flex items-center gap-2"
                      >
                        <CheckSquare className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
                        <span className="text-slate-700 dark:text-slate-300">{item}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Follow-up card */}
              {call.followUpRequired && (
                <div className="p-3.5 bg-amber-50/50 dark:bg-amber-950/20 rounded-2xl border border-amber-200 dark:border-amber-900/40 text-xs space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-amber-600" />
                      <span className="font-bold text-amber-900 dark:text-amber-200">
                        Callback Follow-Up: {call.followUpStatus === 'COMPLETED' ? 'Completed' : 'Pending'}
                      </span>
                    </div>
                    <span className="font-mono text-amber-700 dark:text-amber-300 text-[11px]">
                      Due Date: {call.followUpDate || 'Today'} {call.followUpTime || ''}
                    </span>
                  </div>
                  {call.followUpNotes && (
                    <p className="text-amber-800 dark:text-amber-300 text-[11px]">{call.followUpNotes}</p>
                  )}
                  {call.followUpStatus !== 'COMPLETED' && !isFollowUpOpen && (
                    <button
                      onClick={() => setIsFollowUpOpen(true)}
                      className="px-3 py-1 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 rounded-xl transition shadow-sm inline-flex items-center gap-1.5"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Mark Callback Completed
                    </button>
                  )}
                </div>
              )}

              {/* Complete Follow-up Form */}
              {isFollowUpOpen && (
                <form onSubmit={handleCompleteFollowUp} className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/30 border border-amber-300 dark:border-amber-800 space-y-3">
                  <h4 className="text-xs font-bold text-amber-950 dark:text-amber-200">Complete Follow-up Callback</h4>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Callback Outcome *
                    </label>
                    <input
                      type="text"
                      required
                      value={followUpOutcome}
                      onChange={e => setFollowUpOutcome(e.target.value)}
                      placeholder="e.g. Discussed fee invoice, parent verified transaction"
                      className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Outcome Notes (Optional)
                    </label>
                    <textarea
                      rows={2}
                      value={followUpNotes}
                      onChange={e => setFollowUpNotes(e.target.value)}
                      placeholder="Any additional remarks regarding the resolution of this callback..."
                      className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
                    />
                  </div>
                  <div className="flex items-center justify-end gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => setIsFollowUpOpen(false)}
                      className="px-3 py-1 text-xs text-slate-600 dark:text-slate-400 hover:bg-slate-200 rounded-xl"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={loading}
                      className="px-4 py-1.5 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 rounded-xl transition"
                    >
                      {loading ? 'Saving...' : 'Confirm Completed'}
                    </button>
                  </div>
                </form>
              )}

              {/* Action Bar: Convert to Complaint / Call Again */}
              {!call.convertedToComplaintNumber && !isConvertOpen && (
                <div className="pt-2 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
                  <span className="text-xs text-slate-500">Need to escalate this call into an official ticket?</span>
                  <button
                    onClick={() => setIsConvertOpen(true)}
                    className="px-3.5 py-1.5 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-xl transition shadow-sm inline-flex items-center gap-1.5"
                  >
                    <ShieldAlert className="w-3.5 h-3.5" />
                    Convert Call to Grievance Ticket
                  </button>
                </div>
              )}

              {/* Convert to Complaint Form Drawer */}
              {isConvertOpen && (
                <form onSubmit={handleConvertToComplaint} className="p-4 rounded-2xl bg-rose-50/40 dark:bg-rose-950/20 border border-rose-200 dark:border-rose-900/50 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-rose-950 dark:text-rose-200">
                      Convert Phone Interaction to Formal Grievance
                    </span>
                    <button
                      type="button"
                      onClick={() => setIsConvertOpen(false)}
                      className="text-xs text-slate-400 hover:text-slate-600"
                    >
                      Cancel
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        Grievance Category
                      </label>
                      <select
                        value={complaintCategory}
                        onChange={e => setComplaintCategory(e.target.value)}
                        className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                      >
                        <option value="INFRASTRUCTURE">Infrastructure & Facilities</option>
                        <option value="TRANSPORT">Transport & Bus Route</option>
                        <option value="ACADEMIC">Academic / Teacher</option>
                        <option value="FEE_BILLING">Fee & Billing</option>
                        <option value="FOOD_CANTEEN">Canteen & Meals</option>
                        <option value="SECURITY">Campus Security</option>
                        <option value="OTHER">Other Matter</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        Urgency Priority (SLA Standard)
                      </label>
                      <select
                        value={complaintPriority}
                        onChange={e => setComplaintPriority(e.target.value)}
                        className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-semibold"
                      >
                        <option value="URGENT">Urgent (24h SLA)</option>
                        <option value="HIGH">High (48h SLA)</option>
                        <option value="MEDIUM">Medium (72h SLA)</option>
                        <option value="LOW">Low (120h SLA)</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Ticket Subject *
                    </label>
                    <input
                      type="text"
                      required
                      value={complaintSubject}
                      onChange={e => setComplaintSubject(e.target.value)}
                      placeholder="e.g. Broken bench in science auditorium reported via call"
                      className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Description & Context *
                    </label>
                    <textarea
                      rows={2}
                      required
                      value={complaintDescription}
                      onChange={e => setComplaintDescription(e.target.value)}
                      placeholder="Explain the incident details from the phone call..."
                      className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        Assigned Department
                      </label>
                      <select
                        value={complaintDepartment}
                        onChange={e => setComplaintDepartment(e.target.value)}
                        className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                      >
                        <option value="Administration">Administration</option>
                        <option value="Maintenance">Maintenance & Estate</option>
                        <option value="Transport">Transport Division</option>
                        <option value="Academics">Academic Dean</option>
                        <option value="Accounts">Accounts & Fees</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                        Assign Staff
                      </label>
                      <select
                        value={complaintStaffId}
                        onChange={e => setComplaintStaffId(e.target.value)}
                        className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                      >
                        <option value="">Auto-assign Department Head</option>
                        {staffList.map(s => (
                          <option key={s.id} value={s.id}>
                            {s.name} ({s.department || 'General'})
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="flex justify-end pt-2">
                    <button
                      type="submit"
                      disabled={loading}
                      className="px-4 py-1.5 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-xl transition shadow-sm inline-flex items-center gap-1.5"
                    >
                      <ShieldAlert className="w-3.5 h-3.5" />
                      {loading ? 'Converting...' : 'Generate Complaint Ticket'}
                    </button>
                  </div>
                </form>
              )}
            </>
          ) : (
            /* Caller Phone History Tab */
            <div className="space-y-4">
              <div className="p-3 bg-slate-50 dark:bg-slate-850 rounded-2xl border border-slate-200 dark:border-slate-800 text-xs">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Caller Number</span>
                <span className="font-mono font-bold text-sm text-slate-900 dark:text-white">{call.phone}</span>
                <span className="text-slate-500 text-[11px] block mt-0.5">
                  Showing cross-linked interactions and grievance history for this telephone number.
                </span>
              </div>

              {historyLoading ? (
                <div className="text-center py-10 text-slate-400 text-xs">
                  Loading telephone history...
                </div>
              ) : (
                <div className="space-y-4 max-h-96 overflow-y-auto pr-1">
                  {/* Past Calls */}
                  <div>
                    <h5 className="text-xs font-bold text-slate-900 dark:text-white mb-2 flex items-center gap-1.5">
                      <Phone className="w-3.5 h-3.5 text-blue-500" />
                      Past Call Logs ({historyCalls.length})
                    </h5>
                    {historyCalls.length === 0 ? (
                      <p className="text-[11px] text-slate-400">No other call records from this number.</p>
                    ) : (
                      <div className="space-y-2">
                        {historyCalls.map(hc => (
                          <div
                            key={hc.id}
                            className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-800 text-xs flex items-center justify-between"
                          >
                            <div>
                              <div className="flex items-center gap-2">
                                <span className="font-mono font-bold text-slate-900 dark:text-white">
                                  {hc.callNumber}
                                </span>
                                <span className="text-[10px] text-slate-400 uppercase font-semibold">
                                  {hc.direction} • {hc.callType}
                                </span>
                              </div>
                              <p className="text-[11px] text-slate-600 dark:text-slate-300 mt-0.5">{hc.purpose}</p>
                            </div>
                            <span className="text-[10px] text-slate-400 font-mono">
                              {hc.callDate}
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Past Complaints */}
                  <div className="pt-2 border-t border-slate-200 dark:border-slate-800">
                    <h5 className="text-xs font-bold text-slate-900 dark:text-white mb-2 flex items-center gap-1.5">
                      <ShieldAlert className="w-3.5 h-3.5 text-rose-500" />
                      Past Grievance Tickets ({historyComplaints.length})
                    </h5>
                    {historyComplaints.length === 0 ? (
                      <p className="text-[11px] text-slate-400">No past grievances logged from this contact number.</p>
                    ) : (
                      <div className="space-y-2">
                        {historyComplaints.map(hcomp => (
                          <div
                            key={hcomp.id}
                            className="p-2.5 rounded-xl bg-rose-50/40 dark:bg-rose-950/20 border border-rose-200 dark:border-rose-900/30 text-xs flex items-center justify-between"
                          >
                            <div>
                              <div className="flex items-center gap-2">
                                <span className="font-mono font-bold text-rose-600 dark:text-rose-400">
                                  {hcomp.complaintNumber}
                                </span>
                                <span className="font-semibold text-slate-800 dark:text-slate-200">
                                  {hcomp.subject}
                                </span>
                              </div>
                              <span className="text-[10px] text-slate-400 block mt-0.5">
                                Priority: {hcomp.priority} • Status: {hcomp.status}
                              </span>
                            </div>
                            <span className="text-[10px] text-slate-400 font-mono">
                              {hcomp.complaintDate || hcomp.createdAt.split('T')[0]}
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
