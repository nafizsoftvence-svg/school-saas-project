import React, { useState } from 'react';
import { X, Save, User, Phone, Mail, Building, Clock, Calendar, Shield, Users, CheckCircle2, AlertCircle } from 'lucide-react';
import { api } from '../../services/api';
import { VisitorRecord, VisitorType, VisitorStatus } from '../../types';

interface NewVisitorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (visitor: VisitorRecord) => void;
  staffList?: Array<{ id: string; name: string; department?: string }>;
}

export const NewVisitorModal: React.FC<NewVisitorModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  staffList = []
}) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const today = new Date().toISOString().split('T')[0];
  const currentTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });

  const [formData, setFormData] = useState({
    visitorName: '',
    phone: '',
    email: '',
    organization: '',
    idProofType: 'National ID',
    idProofNumber: '',
    visitorType: 'GENERAL_VISITOR' as VisitorType,
    entryType: 'WALK_IN' as 'SCHEDULED' | 'WALK_IN',
    personToMeet: '',
    personToMeetStaffId: '',
    department: 'Administration',
    purpose: '',
    appointmentDate: today,
    appointmentTime: currentTime,
    expectedDurationMinutes: 45,
    numberOfPersons: 1,
    vehicleType: 'None',
    vehicleNumber: '',
    status: 'SCHEDULED' as VisitorStatus,
    autoCheckIn: true,
    notes: ''
  });

  if (!isOpen) return null;

  const handlePhoneBlur = async () => {
    if (!formData.phone || formData.phone.length < 7) return;
    try {
      const res = await api.frontOffice.getVisitorHistoryByPhone(formData.phone);
      if (res.success && res.data && res.data.length > 0) {
        const last = res.data[0];
        setFormData(prev => ({
          ...prev,
          visitorName: prev.visitorName || last.visitorName,
          email: prev.email || last.email || '',
          organization: prev.organization || last.organization || '',
          idProofType: prev.idProofType || last.idProofType || 'National ID',
          idProofNumber: prev.idProofNumber || last.idProofNumber || '',
          visitorType: prev.visitorType || last.visitorType
        }));
      }
    } catch {
      // Ignore background auto-fill lookup errors
    }
  };

  const handleStaffSelect = (staffId: string) => {
    const staff = (staffList || []).find(s => s?.id === staffId);
    if (staff) {
      setFormData(prev => ({
        ...prev,
        personToMeetStaffId: staff.id,
        personToMeet: staff.name,
        department: staff.department || prev.department
      }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.visitorName.trim() || !formData.phone.trim() || !formData.purpose.trim() || !formData.personToMeet.trim()) {
      setError('Visitor Name, Phone Number, Host / Person to Meet, and Purpose are required.');
      return;
    }

    try {
      setLoading(true);
      setError(null);
      const res = await api.frontOffice.createVisitor({
        ...formData,
        status: formData.autoCheckIn ? 'CHECKED_IN' : 'SCHEDULED'
      });
      if (res.success && res.data) {
        onSuccess(res.data);
        onClose();
      } else {
        setError(res.error || 'Failed to register visitor.');
      }
    } catch (err: any) {
      setError(err.message || 'An error occurred.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-2xl shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-slate-800/40">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold">
              <User className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">Register Visitor Entry</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">Create new visitor pass & log front-desk arrival</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {error && (
          <div className="mx-6 mt-4 p-3 bg-rose-500/10 border border-rose-500/30 rounded-2xl flex items-center gap-2.5 text-xs text-rose-600 dark:text-rose-400">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {/* Quick Check-in Switch */}
          <div className="p-3 bg-indigo-50/50 dark:bg-indigo-950/20 border border-indigo-200 dark:border-indigo-800/50 rounded-2xl flex items-center justify-between">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
              <div>
                <span className="text-xs font-bold text-indigo-950 dark:text-indigo-200 block">Instant Check-In</span>
                <span className="text-[11px] text-indigo-700 dark:text-indigo-400">
                  Mark visitor as active on campus immediately and generate pass
                </span>
              </div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={formData.autoCheckIn}
                onChange={e => setFormData({ ...formData, autoCheckIn: e.target.checked })}
                className="sr-only peer"
              />
              <div className="w-10 h-5 bg-slate-300 peer-focus:outline-none rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-indigo-600"></div>
            </label>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Phone (with autofill) */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Phone Number * <span className="text-[10px] text-indigo-600 dark:text-indigo-400 font-normal">(Autofills returning visitors)</span>
              </label>
              <div className="relative">
                <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="tel"
                  required
                  value={formData.phone}
                  onChange={e => setFormData({ ...formData, phone: e.target.value })}
                  onBlur={handlePhoneBlur}
                  placeholder="+1 (555) 000-0000"
                  className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>

            {/* Visitor Name */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Visitor Full Name *
              </label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  required
                  value={formData.visitorName}
                  onChange={e => setFormData({ ...formData, visitorName: e.target.value })}
                  placeholder="e.g. Eleanor Vance"
                  className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>

            {/* Visitor Type */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Visitor Type
              </label>
              <select
                value={formData.visitorType}
                onChange={e => setFormData({ ...formData, visitorType: e.target.value as VisitorType })}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="PARENT_GUARDIAN">Parent / Guardian</option>
                <option value="VENDOR_CONTRACTOR">Vendor / Contractor</option>
                <option value="GOVT_OFFICIAL">Government / Official</option>
                <option value="GUEST_SPEAKER">Guest / Speaker</option>
                <option value="ALUMNI">Alumni</option>
                <option value="GENERAL_VISITOR">General Visitor</option>
              </select>
            </div>

            {/* Entry Type */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Entry Category
              </label>
              <select
                value={formData.entryType}
                onChange={e => setFormData({ ...formData, entryType: e.target.value as 'SCHEDULED' | 'WALK_IN' })}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="WALK_IN">Walk-In Visitor (Arrived directly)</option>
                <option value="SCHEDULED">Pre-Scheduled Appointment</option>
              </select>
            </div>

            {/* Organization / Affiliation */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Organization / Affiliation
              </label>
              <input
                type="text"
                value={formData.organization}
                onChange={e => setFormData({ ...formData, organization: e.target.value })}
                placeholder="e.g. Apex Deliveries / Parent of Leo"
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            {/* ID Proof Type */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                ID Proof Type
              </label>
              <select
                value={formData.idProofType}
                onChange={e => setFormData({ ...formData, idProofType: e.target.value })}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="National ID">National ID Card</option>
                <option value="Driving License">Driving License</option>
                <option value="Passport">Passport</option>
                <option value="Employee ID">Company / Staff ID</option>
                <option value="Parent ID">School Parent Pass</option>
                <option value="Other">Other</option>
              </select>
            </div>

            {/* ID Proof Number */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                ID Document Number
              </label>
              <input
                type="text"
                value={formData.idProofNumber}
                onChange={e => setFormData({ ...formData, idProofNumber: e.target.value })}
                placeholder="e.g. DL-98124912"
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono"
              />
            </div>

            {/* Vehicle Details */}
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Vehicle Type
                </label>
                <select
                  value={formData.vehicleType}
                  onChange={e => setFormData({ ...formData, vehicleType: e.target.value })}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="None">No Vehicle (Pedestrian)</option>
                  <option value="Two Wheeler">Motorcycle / Scooter</option>
                  <option value="Car">Sedan / SUV / Car</option>
                  <option value="Van/Bus">Van / Minibus</option>
                  <option value="Delivery Truck">Commercial / Delivery</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Plate / Reg #
                </label>
                <input
                  type="text"
                  value={formData.vehicleNumber}
                  onChange={e => setFormData({ ...formData, vehicleNumber: e.target.value })}
                  placeholder="e.g. MA-829-XYZ"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono"
                />
              </div>
            </div>

            {/* Host Staff / Person to Meet */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Person To Meet / Host *
              </label>
              {staffList.length > 0 ? (
                <div className="space-y-1.5">
                  <select
                    value={formData.personToMeetStaffId}
                    onChange={e => handleStaffSelect(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value="">Select from Staff Directory...</option>
                    {staffList.map(st => (
                      <option key={st.id} value={st.id}>
                        {st.name} ({st.department || 'General'})
                      </option>
                    ))}
                  </select>
                  <input
                    type="text"
                    required
                    value={formData.personToMeet}
                    onChange={e => setFormData({ ...formData, personToMeet: e.target.value, personToMeetStaffId: '' })}
                    placeholder="Or enter host name manually..."
                    className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              ) : (
                <input
                  type="text"
                  required
                  value={formData.personToMeet}
                  onChange={e => setFormData({ ...formData, personToMeet: e.target.value })}
                  placeholder="e.g. Dr. Arthur Sterling (Principal)"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              )}
            </div>

            {/* Department */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Department
              </label>
              <select
                value={formData.department}
                onChange={e => setFormData({ ...formData, department: e.target.value })}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="Administration">Administration</option>
                <option value="Academic">Academic</option>
                <option value="Admissions">Admissions</option>
                <option value="Accounts / Finance">Accounts / Finance</option>
                <option value="Examination">Examination</option>
                <option value="Human Resources">Human Resources</option>
                <option value="Science">Science</option>
                <option value="Mathematics">Mathematics</option>
                <option value="Security / Maintenance">Security / Maintenance</option>
              </select>
            </div>

            {/* Date & Time */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Date & Time
              </label>
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="date"
                  value={formData.appointmentDate}
                  onChange={e => setFormData({ ...formData, appointmentDate: e.target.value })}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
                <input
                  type="time"
                  value={formData.appointmentTime}
                  onChange={e => setFormData({ ...formData, appointmentTime: e.target.value })}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>

            {/* Expected Duration & Number of Persons */}
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Duration (Mins)
                </label>
                <input
                  type="number"
                  min="5"
                  max="480"
                  step="5"
                  value={formData.expectedDurationMinutes}
                  onChange={e => setFormData({ ...formData, expectedDurationMinutes: parseInt(e.target.value) || 30 })}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Total Persons
                </label>
                <input
                  type="number"
                  min="1"
                  max="20"
                  value={formData.numberOfPersons}
                  onChange={e => setFormData({ ...formData, numberOfPersons: parseInt(e.target.value) || 1 })}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>
          </div>

          {/* Purpose of Visit */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Purpose of Visit *
            </label>
            <textarea
              required
              rows={2}
              value={formData.purpose}
              onChange={e => setFormData({ ...formData, purpose: e.target.value })}
              placeholder="State the specific reason for visit (e.g. Admission inquiry for Grade 8, Fee receipt collection, Vendor product demo)..."
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* Notes / Special Instructions */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Notes & Special Instructions <span className="text-slate-400 font-normal">(Optional)</span>
            </label>
            <input
              type="text"
              value={formData.notes}
              onChange={e => setFormData({ ...formData, notes: e.target.value })}
              placeholder="e.g. VIP visitor, requires wheelchair access, escorted by security..."
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* Footer buttons */}
          <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-5 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition shadow-sm inline-flex items-center gap-1.5 disabled:opacity-50"
            >
              <Save className="w-3.5 h-3.5" />
              {loading ? 'Processing...' : formData.autoCheckIn ? 'Save & Check-In' : 'Save & Schedule'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
