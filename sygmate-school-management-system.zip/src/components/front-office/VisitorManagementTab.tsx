import React, { useState, useEffect } from 'react';
import {
  Search,
  Filter,
  Plus,
  RefreshCw,
  Printer,
  CheckCircle2,
  Clock,
  XCircle,
  User,
  Shield,
  Building,
  Phone,
  Calendar,
  AlertCircle,
  QrCode,
  Download,
  Bell,
  AlertTriangle,
  History,
  BarChart3,
  Check,
  Ban,
  Car,
  ChevronRight,
  Sparkles
} from 'lucide-react';
import { api } from '../../services/api';
import {
  VisitorRecord,
  VisitorStatus,
  VisitorType,
  VisitorEntryType,
  TodaysFrontDeskOverview,
  AdvancedVisitorReport
} from '../../types';
import { VisitorPassModal } from './VisitorPassModal';
import { NewVisitorModal } from './NewVisitorModal';

interface VisitorManagementTabProps {
  onRefreshStats?: () => void;
  staffList?: Array<{ id: string; name: string; department?: string }>;
}

export const VisitorManagementTab: React.FC<VisitorManagementTabProps> = ({
  onRefreshStats,
  staffList = []
}) => {
  // Navigation sub-views
  const [subTab, setSubTab] = useState<'today' | 'registry' | 'history' | 'reports'>('today');

  // Today's Desk Overview state
  const [todayOverview, setTodayOverview] = useState<TodaysFrontDeskOverview | null>(null);
  const [todayCategoryFilter, setTodayCategoryFilter] = useState<'ALL' | 'EXPECTED' | 'CHECKED_IN' | 'INSIDE' | 'CHECKED_OUT' | 'CANCELLED_NO_SHOW'>('ALL');

  // General Visitor registry state
  const [visitors, setVisitors] = useState<VisitorRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [actionLoadingId, setActionLoadingId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [successNotice, setSuccessNotice] = useState<string | null>(null);

  // Visitor History Archive state
  const [historyRecords, setHistoryRecords] = useState<VisitorRecord[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);

  // Advanced Reports state
  const [reportData, setReportData] = useState<AdvancedVisitorReport | null>(null);
  const [reportLoading, setReportLoading] = useState(false);

  // Filters
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [typeFilter, setTypeFilter] = useState('');
  const [entryTypeFilter, setEntryTypeFilter] = useState('');
  const [dateFilter, setDateFilter] = useState('');

  // Pass verification tool
  const [verifyToken, setVerifyToken] = useState('');
  const [verifyLoading, setVerifyLoading] = useState(false);
  const [verificationResult, setVerificationResult] = useState<any | null>(null);
  const [showVerifyModal, setShowVerifyModal] = useState(false);

  // Modals
  const [selectedVisitorForPass, setSelectedVisitorForPass] = useState<VisitorRecord | null>(null);
  const [isPassModalOpen, setIsPassModalOpen] = useState(false);
  const [isNewModalOpen, setIsNewModalOpen] = useState(false);

  // Load Today's Front Desk View
  const loadTodayOverview = async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await api.frontOffice.getTodayOverview();
      if (res.success && res.data) {
        setTodayOverview(res.data);
      } else {
        setError(res.error || 'Failed to fetch today overview.');
      }
    } catch (err: any) {
      setError(err.message || 'Error loading today overview.');
    } finally {
      setLoading(false);
    }
  };

  // Load All Visitors Registry
  const loadVisitors = async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await api.frontOffice.getVisitors({
        search: search || undefined,
        status: statusFilter || undefined,
        visitorType: typeFilter || undefined,
        entryType: (entryTypeFilter as VisitorEntryType) || undefined,
        date: dateFilter || undefined,
        limit: 100
      });
      if (res.success && res.data) {
        setVisitors(res.data);
      } else {
        setError(res.error || 'Failed to fetch visitors.');
      }
    } catch (err: any) {
      setError(err.message || 'Error loading visitors.');
    } finally {
      setLoading(false);
    }
  };

  // Load History
  const loadHistory = async () => {
    try {
      setHistoryLoading(true);
      const res = await api.frontOffice.getVisitorHistory({
        search: search || undefined,
        visitorType: typeFilter || undefined,
        status: statusFilter || undefined,
        limit: 100
      });
      if (res.success && res.data) {
        setHistoryRecords(res.data);
      }
    } catch (err: any) {
      setError(err.message || 'Error loading visitor history.');
    } finally {
      setHistoryLoading(false);
    }
  };

  // Load Reports
  const loadReports = async () => {
    try {
      setReportLoading(true);
      const res = await api.frontOffice.getAdvancedVisitorReports({});
      if (res.success && res.data) {
        setReportData(res.data);
      }
    } catch (err: any) {
      setError(err.message || 'Error loading visitor reports.');
    } finally {
      setReportLoading(false);
    }
  };

  useEffect(() => {
    if (subTab === 'today') {
      loadTodayOverview();
    } else if (subTab === 'registry') {
      loadVisitors();
    } else if (subTab === 'history') {
      loadHistory();
    } else if (subTab === 'reports') {
      loadReports();
    }
  }, [subTab, statusFilter, typeFilter, entryTypeFilter, dateFilter]);

  const refreshCurrentView = () => {
    if (subTab === 'today') loadTodayOverview();
    else if (subTab === 'registry') loadVisitors();
    else if (subTab === 'history') loadHistory();
    else if (subTab === 'reports') loadReports();
    if (onRefreshStats) onRefreshStats();
  };

  // Auto-dismiss notice
  const triggerSuccessNotice = (msg: string) => {
    setSuccessNotice(msg);
    setTimeout(() => setSuccessNotice(null), 4000);
  };

  // Fast Check-In workflow
  const handleCheckIn = async (id: string) => {
    try {
      setActionLoadingId(id);
      const res = await api.frontOffice.checkInVisitor(id);
      if (res.success && res.data) {
        triggerSuccessNotice(`${res.data.visitorName} successfully checked in.`);
        refreshCurrentView();
        if (selectedVisitorForPass?.id === id) {
          setSelectedVisitorForPass(res.data);
        }
      } else {
        alert(res.error || 'Check-in failed');
      }
    } catch (err: any) {
      alert(err.message || 'Check-in failed');
    } finally {
      setActionLoadingId(null);
    }
  };

  // Fast Check-Out workflow
  const handleCheckOut = async (id: string) => {
    try {
      setActionLoadingId(id);
      const res = await api.frontOffice.checkOutVisitor(id);
      if (res.success && res.data) {
        triggerSuccessNotice(
          `${res.data.visitorName} checked out. Duration: ${res.data.durationMinutes || 'N/A'} mins.`
        );
        refreshCurrentView();
        if (selectedVisitorForPass?.id === id) {
          setSelectedVisitorForPass(res.data);
        }
      } else {
        alert(res.error || 'Check-out failed');
      }
    } catch (err: any) {
      alert(err.message || 'Check-out failed');
    } finally {
      setActionLoadingId(null);
    }
  };

  // Confirm Scheduled Booking
  const handleConfirm = async (id: string) => {
    try {
      setActionLoadingId(id);
      const res = await api.frontOffice.confirmVisitor(id);
      if (res.success && res.data) {
        triggerSuccessNotice(`Appointment confirmed for ${res.data.visitorName}.`);
        refreshCurrentView();
      } else {
        alert(res.error || 'Confirmation failed');
      }
    } catch (err: any) {
      alert(err.message || 'Confirmation failed');
    } finally {
      setActionLoadingId(null);
    }
  };

  // Reject Booking
  const handleReject = async (id: string) => {
    const reason = window.prompt('Please enter reason for declining this visit:');
    if (reason === null) return;
    try {
      setActionLoadingId(id);
      const res = await api.frontOffice.rejectVisitor(id, reason);
      if (res.success) {
        triggerSuccessNotice('Visitor booking declined.');
        refreshCurrentView();
      } else {
        alert(res.error || 'Rejection failed');
      }
    } catch (err: any) {
      alert(err.message || 'Rejection failed');
    } finally {
      setActionLoadingId(null);
    }
  };

  // Mark No-Show
  const handleMarkNoShow = async (id: string) => {
    if (!window.confirm('Mark this scheduled visitor as a No-Show?')) return;
    try {
      setActionLoadingId(id);
      const res = await api.frontOffice.markVisitorNoShow(id);
      if (res.success) {
        triggerSuccessNotice('Marked visitor as No-Show.');
        refreshCurrentView();
      } else {
        alert(res.error || 'Operation failed');
      }
    } catch (err: any) {
      alert(err.message || 'Operation failed');
    } finally {
      setActionLoadingId(null);
    }
  };

  // Send Reminder to host
  const handleSendReminder = async (id: string) => {
    try {
      setActionLoadingId(id);
      const res = await api.frontOffice.sendVisitorReminder(id);
      if (res.success) {
        triggerSuccessNotice(res.message || 'Reminder alert sent.');
      } else {
        alert(res.error || 'Failed to dispatch reminder');
      }
    } catch (err: any) {
      alert(err.message || 'Failed to dispatch reminder');
    } finally {
      setActionLoadingId(null);
    }
  };

  // Cancel Visit
  const handleCancel = async (id: string) => {
    const reason = window.prompt('Please enter cancellation reason:');
    if (reason === null) return;
    try {
      setActionLoadingId(id);
      const res = await api.frontOffice.cancelVisitor(id, reason);
      if (res.success && res.data) {
        triggerSuccessNotice('Visitor booking cancelled.');
        refreshCurrentView();
      } else {
        alert(res.error || 'Cancellation failed');
      }
    } catch (err: any) {
      alert(err.message || 'Cancellation failed');
    } finally {
      setActionLoadingId(null);
    }
  };

  // Fast Pass Verification lookup
  const handleVerifyPass = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!verifyToken.trim()) return;
    try {
      setVerifyLoading(true);
      setVerificationResult(null);
      const res = await api.frontOffice.verifyVisitorPass(verifyToken.trim());
      setVerificationResult(res.data);
    } catch (err: any) {
      setVerificationResult({
        valid: false,
        message: err.message || 'Invalid pass token or badge not recognized.'
      });
    } finally {
      setVerifyLoading(false);
    }
  };

  // Export CSV
  const handleExportCSV = (records: VisitorRecord[]) => {
    if (!records || records.length === 0) {
      alert('No visitor records to export.');
      return;
    }
    const headers = [
      'Pass Number',
      'Booking ID',
      'Visitor Name',
      'Phone',
      'Visitor Type',
      'Entry Type',
      'Organization',
      'Host Staff',
      'Department',
      'Appointment Date',
      'Appointment Time',
      'Check-In Time',
      'Check-Out Time',
      'Duration (Mins)',
      'Status',
      'Vehicle Number'
    ];

    const rows = records.map(r => [
      r.visitorPassNumber,
      r.bookingId || '',
      `"${r.visitorName.replace(/"/g, '""')}"`,
      r.phone,
      r.visitorType,
      r.entryType || 'SCHEDULED',
      `"${(r.organization || '').replace(/"/g, '""')}"`,
      `"${r.personToMeet.replace(/"/g, '""')}"`,
      r.department,
      r.appointmentDate,
      r.appointmentTime,
      r.checkInTime || '',
      r.checkOutTime || '',
      r.durationMinutes || '',
      r.status,
      r.vehicleNumber || ''
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Visitor_Register_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getStatusBadge = (status: VisitorStatus) => {
    switch (status) {
      case 'CHECKED_IN':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
            Currently Inside
          </span>
        );
      case 'CHECKED_OUT':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-500/10 text-slate-600 dark:text-slate-400 border border-slate-500/20">
            Checked Out
          </span>
        );
      case 'CONFIRMED':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">
            Confirmed
          </span>
        );
      case 'NO_SHOW':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-purple-500/10 text-purple-600 dark:text-purple-400 border border-purple-500/20">
            No-Show
          </span>
        );
      case 'REJECTED':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-red-500/10 text-red-600 dark:text-red-400 border border-red-500/20">
            Rejected
          </span>
        );
      case 'CANCELLED':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-500/20">
            Cancelled
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20">
            Scheduled
          </span>
        );
    }
  };

  // Get active display visitors for Today's View
  const getTodayDisplayRecords = () => {
    if (!todayOverview) return [];
    switch (todayCategoryFilter) {
      case 'EXPECTED':
        return todayOverview.expected;
      case 'CHECKED_IN':
        return todayOverview.checkedInToday;
      case 'INSIDE':
        return todayOverview.currentlyInside;
      case 'CHECKED_OUT':
        return todayOverview.checkedOutToday;
      case 'CANCELLED_NO_SHOW':
        return todayOverview.cancelledOrNoShow;
      default:
        // All combined for today
        const map = new Map<string, VisitorRecord>();
        [
          ...todayOverview.currentlyInside,
          ...todayOverview.expected,
          ...todayOverview.checkedInToday,
          ...todayOverview.checkedOutToday,
          ...todayOverview.cancelledOrNoShow
        ].forEach(v => map.set(v.id, v));
        return Array.from(map.values());
    }
  };

  return (
    <div className="space-y-4">
      {/* Sub-navigation tabs: Today's Front Desk, Registry, Archive, Reports */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-2 bg-slate-100 dark:bg-slate-800/80 rounded-2xl border border-slate-200 dark:border-slate-700">
        <div className="flex flex-wrap items-center gap-1">
          <button
            onClick={() => setSubTab('today')}
            className={`px-3.5 py-2 text-xs font-bold rounded-xl transition inline-flex items-center gap-1.5 ${
              subTab === 'today'
                ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-sm border border-slate-200 dark:border-slate-800'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            Today's Front Desk View
            {todayOverview && (
              <span className="ml-1 px-1.5 py-0.5 rounded-full text-[10px] bg-indigo-100 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300">
                {todayOverview.summary.currentlyInsideCount} inside
              </span>
            )}
          </button>

          <button
            onClick={() => setSubTab('registry')}
            className={`px-3.5 py-2 text-xs font-bold rounded-xl transition inline-flex items-center gap-1.5 ${
              subTab === 'registry'
                ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-sm border border-slate-200 dark:border-slate-800'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Shield className="w-3.5 h-3.5" />
            All Visitors Registry
          </button>

          <button
            onClick={() => setSubTab('history')}
            className={`px-3.5 py-2 text-xs font-bold rounded-xl transition inline-flex items-center gap-1.5 ${
              subTab === 'history'
                ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-sm border border-slate-200 dark:border-slate-800'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <History className="w-3.5 h-3.5" />
            Visitor History Archive
          </button>

          <button
            onClick={() => setSubTab('reports')}
            className={`px-3.5 py-2 text-xs font-bold rounded-xl transition inline-flex items-center gap-1.5 ${
              subTab === 'reports'
                ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-sm border border-slate-200 dark:border-slate-800'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5" />
            Analytics & Reports
          </button>
        </div>

        {/* Global Fast Actions */}
        <div className="flex items-center gap-2">
          {/* Fast Pass Verification */}
          <button
            onClick={() => setShowVerifyModal(true)}
            className="px-3 py-1.5 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-850 rounded-xl transition inline-flex items-center gap-1.5 shadow-sm"
          >
            <QrCode className="w-3.5 h-3.5 text-indigo-500" />
            Verify Badge / QR
          </button>

          {/* Register Visitor */}
          <button
            onClick={() => setIsNewModalOpen(true)}
            className="px-3.5 py-1.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition shadow-sm inline-flex items-center gap-1.5"
          >
            <Plus className="w-3.5 h-3.5" />
            Book / Walk-In Entry
          </button>

          {/* Refresh */}
          <button
            onClick={refreshCurrentView}
            className="p-2 text-slate-500 hover:text-slate-900 dark:hover:text-white rounded-xl hover:bg-white dark:hover:bg-slate-900 transition"
            title="Refresh"
          >
            <RefreshCw className={`w-4 h-4 ${loading || historyLoading || reportLoading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Success Notification Banner */}
      {successNotice && (
        <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-2xl flex items-center justify-between text-xs text-emerald-700 dark:text-emerald-300">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{successNotice}</span>
          </div>
          <button onClick={() => setSuccessNotice(null)} className="text-slate-400 hover:text-slate-600">
            <XCircle className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Error Banner */}
      {error && (
        <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-2xl flex items-center gap-2.5 text-xs text-rose-600 dark:text-rose-400">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* ========================================================================= */}
      {/* SUB-VIEW 1: TODAY'S FRONT DESK VIEW */}
      {/* ========================================================================= */}
      {subTab === 'today' && (
        <div className="space-y-4">
          {/* Categorized Metric Buckets */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
            {/* 1. Expected Today */}
            <button
              onClick={() => setTodayCategoryFilter(todayCategoryFilter === 'EXPECTED' ? 'ALL' : 'EXPECTED')}
              className={`p-4 rounded-2xl border text-left transition ${
                todayCategoryFilter === 'EXPECTED'
                  ? 'bg-amber-50 border-amber-300 dark:bg-amber-950/30 dark:border-amber-700 ring-2 ring-amber-500/40'
                  : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-slate-300'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-slate-500">Expected</span>
                <Clock className="w-4 h-4 text-amber-500" />
              </div>
              <div className="text-2xl font-black text-slate-900 dark:text-white">
                {todayOverview?.summary.expectedCount || 0}
              </div>
              <span className="text-[11px] text-slate-400 mt-1 block">Scheduled / Confirmed</span>
            </button>

            {/* 2. Checked In Today */}
            <button
              onClick={() => setTodayCategoryFilter(todayCategoryFilter === 'CHECKED_IN' ? 'ALL' : 'CHECKED_IN')}
              className={`p-4 rounded-2xl border text-left transition ${
                todayCategoryFilter === 'CHECKED_IN'
                  ? 'bg-indigo-50 border-indigo-300 dark:bg-indigo-950/30 dark:border-indigo-700 ring-2 ring-indigo-500/40'
                  : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-slate-300'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-slate-500">Checked In</span>
                <CheckCircle2 className="w-4 h-4 text-indigo-500" />
              </div>
              <div className="text-2xl font-black text-slate-900 dark:text-white">
                {todayOverview?.summary.checkedInCount || 0}
              </div>
              <span className="text-[11px] text-slate-400 mt-1 block">Arrivals logged today</span>
            </button>

            {/* 3. Currently Inside */}
            <button
              onClick={() => setTodayCategoryFilter(todayCategoryFilter === 'INSIDE' ? 'ALL' : 'INSIDE')}
              className={`p-4 rounded-2xl border text-left transition ${
                todayCategoryFilter === 'INSIDE'
                  ? 'bg-emerald-50 border-emerald-300 dark:bg-emerald-950/30 dark:border-emerald-700 ring-2 ring-emerald-500/40'
                  : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-slate-300'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-slate-500">Currently Inside</span>
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping"></span>
              </div>
              <div className="text-2xl font-black text-emerald-600 dark:text-emerald-400">
                {todayOverview?.summary.currentlyInsideCount || 0}
              </div>
              <span className="text-[11px] text-emerald-600/80 dark:text-emerald-400/80 mt-1 block font-medium">
                Live on campus grounds
              </span>
            </button>

            {/* 4. Checked Out */}
            <button
              onClick={() => setTodayCategoryFilter(todayCategoryFilter === 'CHECKED_OUT' ? 'ALL' : 'CHECKED_OUT')}
              className={`p-4 rounded-2xl border text-left transition ${
                todayCategoryFilter === 'CHECKED_OUT'
                  ? 'bg-slate-100 border-slate-300 dark:bg-slate-800 dark:border-slate-600 ring-2 ring-slate-400/40'
                  : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-slate-300'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-slate-500">Checked Out</span>
                <Shield className="w-4 h-4 text-slate-500" />
              </div>
              <div className="text-2xl font-black text-slate-900 dark:text-white">
                {todayOverview?.summary.checkedOutCount || 0}
              </div>
              <span className="text-[11px] text-slate-400 mt-1 block">
                Avg stay: {todayOverview?.summary.averageStayDurationMinutes || 0}m
              </span>
            </button>

            {/* 5. Cancelled / No-Show */}
            <button
              onClick={() => setTodayCategoryFilter(todayCategoryFilter === 'CANCELLED_NO_SHOW' ? 'ALL' : 'CANCELLED_NO_SHOW')}
              className={`p-4 rounded-2xl border text-left transition ${
                todayCategoryFilter === 'CANCELLED_NO_SHOW'
                  ? 'bg-rose-50 border-rose-300 dark:bg-rose-950/30 dark:border-rose-700 ring-2 ring-rose-500/40'
                  : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-slate-300'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-slate-500">Cancelled / No-Show</span>
                <XCircle className="w-4 h-4 text-rose-500" />
              </div>
              <div className="text-2xl font-black text-slate-900 dark:text-white">
                {todayOverview?.summary.cancelledOrNoShowCount || 0}
              </div>
              <span className="text-[11px] text-slate-400 mt-1 block">Did not visit / Declined</span>
            </button>
          </div>

          {/* Today's Table Header with Category Filter Indicator */}
          <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex flex-wrap items-center justify-between gap-3 shadow-sm">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-900 dark:text-white">
                Showing: {todayCategoryFilter === 'ALL' ? 'All Today Traffic' : todayCategoryFilter.replace('_', ' ')}
              </span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-indigo-50 text-indigo-700 dark:bg-indigo-950/40 dark:text-indigo-300">
                {getTodayDisplayRecords().length} records
              </span>
            </div>

            <div className="flex items-center gap-2">
              {todayCategoryFilter !== 'ALL' && (
                <button
                  onClick={() => setTodayCategoryFilter('ALL')}
                  className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline font-semibold"
                >
                  Clear Category Filter
                </button>
              )}
              <button
                onClick={() => handleExportCSV(getTodayDisplayRecords())}
                className="px-3 py-1.5 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-700 transition inline-flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5 text-slate-500" />
                Export Today's Register
              </button>
            </div>
          </div>

          {/* Today's Table */}
          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 dark:bg-slate-850 text-slate-500 dark:text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-200 dark:border-slate-800">
                  <tr>
                    <th className="px-4 py-3">Pass # / Booking</th>
                    <th className="px-4 py-3">Visitor Info</th>
                    <th className="px-4 py-3">Host & Purpose</th>
                    <th className="px-4 py-3">Slot / Timings</th>
                    <th className="px-4 py-3">Status</th>
                    <th className="px-4 py-3 text-right">Front Desk Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-300">
                  {loading && !todayOverview ? (
                    <tr>
                      <td colSpan={6} className="text-center py-12 text-slate-400">
                        <RefreshCw className="w-6 h-6 animate-spin mx-auto mb-2 text-indigo-500" />
                        Loading today's front desk view...
                      </td>
                    </tr>
                  ) : getTodayDisplayRecords().length === 0 ? (
                    <tr>
                      <td colSpan={6} className="text-center py-12 text-slate-400">
                        <Shield className="w-8 h-8 mx-auto mb-2 text-slate-300 dark:text-slate-600" />
                        No visitor entries match this category for today.
                      </td>
                    </tr>
                  ) : (
                    getTodayDisplayRecords().map(visitor => {
                      // Calculate active stay time if checked in
                      let activeMins = 0;
                      if (visitor.status === 'CHECKED_IN' && visitor.checkInTime) {
                        activeMins = Math.round(
                          (Date.now() - new Date(visitor.checkInTime).getTime()) / 60000
                        );
                      }
                      const isOverstay = activeMins > 90;

                      return (
                        <tr
                          key={visitor.id}
                          className={`hover:bg-slate-50/70 dark:hover:bg-slate-800/40 transition ${
                            isOverstay ? 'bg-amber-50/40 dark:bg-amber-950/20' : ''
                          }`}
                        >
                          {/* Pass # & Booking Ref */}
                          <td className="px-4 py-3">
                            <div className="font-mono font-bold text-indigo-600 dark:text-indigo-400">
                              {visitor.visitorPassNumber}
                            </div>
                            {visitor.bookingId && (
                              <span className="text-[10px] font-mono text-slate-400 block">
                                Ref: {visitor.bookingId}
                              </span>
                            )}
                            <div className="mt-1">
                              <span className="px-1.5 py-0.5 text-[9px] font-semibold uppercase rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
                                {visitor.entryType || 'SCHEDULED'}
                              </span>
                            </div>
                          </td>

                          {/* Visitor Info */}
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-2.5">
                              <div className="w-7 h-7 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold text-[10px] shrink-0">
                                {visitor.visitorName.charAt(0)}
                              </div>
                              <div>
                                <span className="font-bold text-slate-900 dark:text-white block">
                                  {visitor.visitorName}
                                </span>
                                <div className="flex items-center gap-1.5 text-[11px] text-slate-500">
                                  <span>{visitor.phone}</span>
                                  {visitor.organization && (
                                    <>
                                      <span>•</span>
                                      <span className="truncate max-w-[120px] italic">{visitor.organization}</span>
                                    </>
                                  )}
                                </div>
                                {visitor.vehicleNumber && (
                                  <div className="flex items-center gap-1 text-[10px] text-slate-400 mt-0.5">
                                    <Car className="w-3 h-3 text-slate-400" />
                                    <span>{visitor.vehicleType}: {visitor.vehicleNumber}</span>
                                  </div>
                                )}
                              </div>
                            </div>
                          </td>

                          {/* Host & Purpose */}
                          <td className="px-4 py-3">
                            <div className="space-y-0.5">
                              <div className="flex items-center gap-1.5">
                                <span className="font-semibold text-slate-900 dark:text-white">
                                  {visitor.personToMeet}
                                </span>
                                <span className="text-[10px] text-slate-400">({visitor.department})</span>
                              </div>
                              <p className="text-[11px] text-slate-500 line-clamp-1 max-w-[200px]" title={visitor.purpose}>
                                {visitor.purpose}
                              </p>
                            </div>
                          </td>

                          {/* Slot / Timings & Active Duration */}
                          <td className="px-4 py-3">
                            <div className="space-y-0.5 text-[11px]">
                              <div className="font-medium text-slate-800 dark:text-slate-200">
                                Slot: {visitor.appointmentTime}
                              </div>
                              {visitor.checkInTime && (
                                <div className="text-[10px] text-emerald-600 dark:text-emerald-400 font-mono">
                                  In: {new Date(visitor.checkInTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                </div>
                              )}
                              {visitor.checkOutTime && (
                                <div className="text-[10px] text-slate-400 font-mono">
                                  Out: {new Date(visitor.checkOutTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                  {visitor.durationMinutes ? ` (${visitor.durationMinutes}m)` : ''}
                                </div>
                              )}
                              {visitor.status === 'CHECKED_IN' && activeMins > 0 && (
                                <div className="flex items-center gap-1 mt-1">
                                  <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                                    isOverstay
                                      ? 'bg-rose-100 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300 flex items-center gap-1'
                                      : 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300'
                                  }`}>
                                    {isOverstay && <AlertTriangle className="w-2.5 h-2.5" />}
                                    {activeMins} mins inside
                                  </span>
                                </div>
                              )}
                            </div>
                          </td>

                          {/* Status */}
                          <td className="px-4 py-3">
                            {getStatusBadge(visitor.status)}
                          </td>

                          {/* Front Desk Actions */}
                          <td className="px-4 py-3 text-right">
                            <div className="inline-flex items-center gap-1.5">
                              {/* Security Pass Badge */}
                              <button
                                onClick={() => {
                                  setSelectedVisitorForPass(visitor);
                                  setIsPassModalOpen(true);
                                }}
                                className="p-1.5 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 rounded-lg transition"
                                title="Print / View Badge"
                              >
                                <Printer className="w-3.5 h-3.5" />
                              </button>

                              {/* Action Loading Spinner */}
                              {actionLoadingId === visitor.id ? (
                                <RefreshCw className="w-4 h-4 animate-spin text-indigo-600" />
                              ) : (
                                <>
                                  {/* Check In */}
                                  {visitor.status !== 'CHECKED_IN' && visitor.status !== 'CHECKED_OUT' && (
                                    <button
                                      onClick={() => handleCheckIn(visitor.id)}
                                      className="px-2.5 py-1 text-[11px] font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg transition shadow-sm"
                                      title="Check-In at Reception"
                                    >
                                      Check In
                                    </button>
                                  )}

                                  {/* Check Out */}
                                  {visitor.status === 'CHECKED_IN' && (
                                    <button
                                      onClick={() => handleCheckOut(visitor.id)}
                                      className="px-2.5 py-1 text-[11px] font-bold text-white bg-amber-600 hover:bg-amber-700 rounded-lg transition shadow-sm"
                                      title="Check-Out of Campus"
                                    >
                                      Check Out
                                    </button>
                                  )}

                                  {/* Confirm scheduled appointment */}
                                  {visitor.status === 'SCHEDULED' && (
                                    <button
                                      onClick={() => handleConfirm(visitor.id)}
                                      className="p-1.5 text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-950/40 rounded-lg transition"
                                      title="Confirm Appointment"
                                    >
                                      <Check className="w-3.5 h-3.5" />
                                    </button>
                                  )}

                                  {/* Send Reminder to host */}
                                  {['SCHEDULED', 'CONFIRMED'].includes(visitor.status) && (
                                    <button
                                      onClick={() => handleSendReminder(visitor.id)}
                                      className="p-1.5 text-slate-400 hover:text-indigo-600 rounded-lg transition"
                                      title="Send Reminder Alert to Host"
                                    >
                                      <Bell className="w-3.5 h-3.5" />
                                    </button>
                                  )}

                                  {/* Mark No-Show */}
                                  {['SCHEDULED', 'CONFIRMED'].includes(visitor.status) && (
                                    <button
                                      onClick={() => handleMarkNoShow(visitor.id)}
                                      className="p-1.5 text-slate-400 hover:text-purple-600 rounded-lg transition"
                                      title="Mark as No-Show"
                                    >
                                      <Ban className="w-3.5 h-3.5" />
                                    </button>
                                  )}

                                  {/* Reject / Cancel */}
                                  {['SCHEDULED', 'CONFIRMED'].includes(visitor.status) && (
                                    <button
                                      onClick={() => handleReject(visitor.id)}
                                      className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg transition"
                                      title="Decline / Reject"
                                    >
                                      <XCircle className="w-3.5 h-3.5" />
                                    </button>
                                  )}
                                </>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* SUB-VIEW 2: ALL VISITORS REGISTRY */}
      {/* ========================================================================= */}
      {subTab === 'registry' && (
        <div className="space-y-4">
          {/* Filter Bar */}
          <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex flex-wrap items-center justify-between gap-3 shadow-sm">
            <div className="flex flex-wrap items-center gap-2.5 flex-1 min-w-[280px]">
              {/* Search */}
              <div className="relative flex-1 min-w-[200px]">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && loadVisitors()}
                  placeholder="Search name, pass #, phone, organization, host..."
                  className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              {/* Status */}
              <select
                value={statusFilter}
                onChange={e => setStatusFilter(e.target.value)}
                className="px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="">All Statuses</option>
                <option value="CHECKED_IN">Currently Inside</option>
                <option value="SCHEDULED">Scheduled</option>
                <option value="CONFIRMED">Confirmed</option>
                <option value="CHECKED_OUT">Checked Out</option>
                <option value="NO_SHOW">No-Show</option>
                <option value="REJECTED">Rejected</option>
                <option value="CANCELLED">Cancelled</option>
              </select>

              {/* Entry Type */}
              <select
                value={entryTypeFilter}
                onChange={e => setEntryTypeFilter(e.target.value)}
                className="px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="">All Entry Categories</option>
                <option value="WALK_IN">Walk-In Visitors</option>
                <option value="SCHEDULED">Pre-Scheduled Appointments</option>
              </select>

              {/* Visitor Type */}
              <select
                value={typeFilter}
                onChange={e => setTypeFilter(e.target.value)}
                className="px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="">All Visitor Types</option>
                <option value="PARENT_GUARDIAN">Parent / Guardian</option>
                <option value="VENDOR_CONTRACTOR">Vendor / Contractor</option>
                <option value="GOVT_OFFICIAL">Govt Official</option>
                <option value="GUEST_SPEAKER">Guest Speaker</option>
                <option value="ALUMNI">Alumni</option>
                <option value="GENERAL_VISITOR">General Visitor</option>
              </select>

              {/* Date */}
              <input
                type="date"
                value={dateFilter}
                onChange={e => setDateFilter(e.target.value)}
                className="px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <button
              onClick={() => handleExportCSV(visitors)}
              className="px-3.5 py-1.5 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-700 transition inline-flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5 text-slate-500" />
              Export CSV
            </button>
          </div>

          {/* Registry Table */}
          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 dark:bg-slate-850 text-slate-500 dark:text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-200 dark:border-slate-800">
                  <tr>
                    <th className="px-4 py-3">Pass # / Badge</th>
                    <th className="px-4 py-3">Visitor Name & Type</th>
                    <th className="px-4 py-3">Contact</th>
                    <th className="px-4 py-3">Host & Dept</th>
                    <th className="px-4 py-3">Appointment / Times</th>
                    <th className="px-4 py-3">Status</th>
                    <th className="px-4 py-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-300">
                  {loading ? (
                    <tr>
                      <td colSpan={7} className="text-center py-12 text-slate-400">
                        <RefreshCw className="w-6 h-6 animate-spin mx-auto mb-2 text-indigo-500" />
                        Loading visitor records...
                      </td>
                    </tr>
                  ) : visitors.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="text-center py-12 text-slate-400">
                        <Shield className="w-8 h-8 mx-auto mb-2 text-slate-300 dark:text-slate-600" />
                        No visitors found matching your search criteria.
                      </td>
                    </tr>
                  ) : (
                    visitors.map(visitor => (
                      <tr key={visitor.id} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40 transition">
                        <td className="px-4 py-3 font-mono font-bold text-indigo-600 dark:text-indigo-400">
                          {visitor.visitorPassNumber}
                          {visitor.bookingId && (
                            <span className="text-[10px] text-slate-400 block font-normal">
                              {visitor.bookingId}
                            </span>
                          )}
                        </td>
                        <td className="px-4 py-3">
                          <span className="font-bold text-slate-900 dark:text-white block">
                            {visitor.visitorName}
                          </span>
                          <span className="text-[11px] text-slate-500 block">
                            {visitor.visitorType.replace('_', ' ')}
                            {visitor.organization ? ` • ${visitor.organization}` : ''}
                          </span>
                        </td>
                        <td className="px-4 py-3 font-mono text-[11px]">
                          {visitor.phone}
                        </td>
                        <td className="px-4 py-3">
                          <span className="font-semibold text-slate-900 dark:text-white block">
                            {visitor.personToMeet}
                          </span>
                          <span className="text-[11px] text-slate-500 block">
                            {visitor.department}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-[11px]">
                          <div>{visitor.appointmentDate} at {visitor.appointmentTime}</div>
                          {visitor.checkInTime && (
                            <div className="text-[10px] text-emerald-600 font-mono">
                              In: {new Date(visitor.checkInTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </div>
                          )}
                        </td>
                        <td className="px-4 py-3">
                          {getStatusBadge(visitor.status)}
                        </td>
                        <td className="px-4 py-3 text-right">
                          <div className="inline-flex items-center gap-1">
                            <button
                              onClick={() => {
                                setSelectedVisitorForPass(visitor);
                                setIsPassModalOpen(true);
                              }}
                              className="p-1.5 text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 rounded-lg transition"
                              title="Print Pass"
                            >
                              <Printer className="w-3.5 h-3.5" />
                            </button>

                            {visitor.status !== 'CHECKED_IN' && visitor.status !== 'CHECKED_OUT' && (
                              <button
                                onClick={() => handleCheckIn(visitor.id)}
                                className="px-2 py-1 text-[11px] font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg transition"
                              >
                                Check In
                              </button>
                            )}

                            {visitor.status === 'CHECKED_IN' && (
                              <button
                                onClick={() => handleCheckOut(visitor.id)}
                                className="px-2 py-1 text-[11px] font-semibold text-white bg-amber-600 hover:bg-amber-700 rounded-lg transition"
                              >
                                Check Out
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* SUB-VIEW 3: VISITOR HISTORY ARCHIVE */}
      {/* ========================================================================= */}
      {subTab === 'history' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex flex-wrap items-center justify-between gap-3 shadow-sm">
            <div>
              <h4 className="text-xs font-bold text-slate-900 dark:text-white">Visitor Past Encounters & Logs</h4>
              <p className="text-[11px] text-slate-500">Historical archive of checked out, cancelled, and concluded visits</p>
            </div>
            <button
              onClick={() => handleExportCSV(historyRecords)}
              className="px-3.5 py-1.5 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl hover:bg-slate-100 transition inline-flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5 text-slate-500" />
              Export History
            </button>
          </div>

          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 dark:bg-slate-850 text-slate-500 dark:text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-200 dark:border-slate-800">
                  <tr>
                    <th className="px-4 py-3">Pass #</th>
                    <th className="px-4 py-3">Visitor</th>
                    <th className="px-4 py-3">Phone</th>
                    <th className="px-4 py-3">Host & Dept</th>
                    <th className="px-4 py-3">Date</th>
                    <th className="px-4 py-3">Duration</th>
                    <th className="px-4 py-3">Status</th>
                    <th className="px-4 py-3 text-right">Pass</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-300">
                  {historyLoading ? (
                    <tr>
                      <td colSpan={8} className="text-center py-12 text-slate-400">
                        <RefreshCw className="w-6 h-6 animate-spin mx-auto mb-2 text-indigo-500" />
                        Loading history records...
                      </td>
                    </tr>
                  ) : historyRecords.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="text-center py-12 text-slate-400">
                        <History className="w-8 h-8 mx-auto mb-2 text-slate-300 dark:text-slate-600" />
                        No past visitors found in archive.
                      </td>
                    </tr>
                  ) : (
                    historyRecords.map(item => (
                      <tr key={item.id} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40 transition">
                        <td className="px-4 py-3 font-mono font-bold text-indigo-600 dark:text-indigo-400">
                          {item.visitorPassNumber}
                        </td>
                        <td className="px-4 py-3">
                          <span className="font-bold text-slate-900 dark:text-white block">
                            {item.visitorName}
                          </span>
                          <span className="text-[11px] text-slate-500">{item.organization || item.visitorType}</span>
                        </td>
                        <td className="px-4 py-3 font-mono text-[11px]">
                          {item.phone}
                        </td>
                        <td className="px-4 py-3">
                          <span className="font-semibold text-slate-800 dark:text-slate-200 block">{item.personToMeet}</span>
                          <span className="text-[10px] text-slate-400">{item.department}</span>
                        </td>
                        <td className="px-4 py-3 text-[11px]">
                          {item.appointmentDate}
                        </td>
                        <td className="px-4 py-3 text-[11px] font-mono">
                          {item.durationMinutes ? `${item.durationMinutes} mins` : '-'}
                        </td>
                        <td className="px-4 py-3">
                          {getStatusBadge(item.status)}
                        </td>
                        <td className="px-4 py-3 text-right">
                          <button
                            onClick={() => {
                              setSelectedVisitorForPass(item);
                              setIsPassModalOpen(true);
                            }}
                            className="p-1.5 text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 rounded-lg transition"
                            title="View Archived Badge"
                          >
                            <Printer className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* SUB-VIEW 4: ANALYTICS & ADVANCED REPORTS */}
      {/* ========================================================================= */}
      {subTab === 'reports' && (
        <div className="space-y-4">
          {/* Summary KPIs */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
              <span className="text-xs font-semibold text-slate-500 block mb-1">Total Visitors Logged</span>
              <div className="text-3xl font-black text-slate-900 dark:text-white">
                {reportData?.totalVisitors || 0}
              </div>
              <span className="text-[11px] text-indigo-600 dark:text-indigo-400 mt-1 block">Campus Traffic Volume</span>
            </div>

            <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
              <span className="text-xs font-semibold text-slate-500 block mb-1">Average Visit Duration</span>
              <div className="text-3xl font-black text-slate-900 dark:text-white">
                {reportData?.averageDurationMinutes || 0} <span className="text-sm font-semibold text-slate-400">mins</span>
              </div>
              <span className="text-[11px] text-emerald-600 dark:text-emerald-400 mt-1 block">Mean on-site duration</span>
            </div>

            <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
              <span className="text-xs font-semibold text-slate-500 block mb-1">Active Overstay Warnings</span>
              <div className="text-3xl font-black text-amber-600 dark:text-amber-400">
                {reportData?.overstayCount || 0}
              </div>
              <span className="text-[11px] text-amber-600 dark:text-amber-400 mt-1 block">Visits exceeding 90 mins</span>
            </div>
          </div>

          {/* Department Breakdown */}
          {reportData?.departmentBreakdown && (
            <div className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
              <h4 className="text-xs font-bold text-slate-900 dark:text-white">Department Traffic Breakdown</h4>
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
                {Object.entries(reportData.departmentBreakdown).map(([dept, count]) => (
                  <div key={dept} className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200/80 dark:border-slate-700/50">
                    <span className="text-[11px] text-slate-500 block truncate">{dept}</span>
                    <span className="text-lg font-black text-slate-900 dark:text-white">{count}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Overstay Warning Table */}
          {reportData?.overstayVisitors && reportData.overstayVisitors.length > 0 && (
            <div className="p-4 rounded-2xl border border-amber-300 dark:border-amber-800 bg-amber-50/50 dark:bg-amber-950/20 space-y-3">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-600" />
                <h4 className="text-xs font-bold text-amber-950 dark:text-amber-200">
                  Overstay Security Alert ({reportData.overstayVisitors.length} visitors on site &gt; 90 mins)
                </h4>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="text-amber-900 dark:text-amber-300 border-b border-amber-200 dark:border-amber-800">
                      <th className="py-2">Pass #</th>
                      <th className="py-2">Visitor Name</th>
                      <th className="py-2">Host Staff</th>
                      <th className="py-2">Time Inside</th>
                      <th className="py-2 text-right">Fast Checkout</th>
                    </tr>
                  </thead>
                  <tbody>
                    {reportData.overstayVisitors.map((v: any) => (
                      <tr key={v.id} className="border-b border-amber-100 dark:border-amber-900/40">
                        <td className="py-2 font-mono font-bold text-amber-900 dark:text-amber-200">{v.visitorPassNumber}</td>
                        <td className="py-2 font-semibold">{v.visitorName}</td>
                        <td className="py-2">{v.personToMeet} ({v.department})</td>
                        <td className="py-2 font-bold text-rose-600">{v.currentDurationMins} minutes</td>
                        <td className="py-2 text-right">
                          <button
                            onClick={() => handleCheckOut(v.id)}
                            className="px-2.5 py-1 text-[10px] font-bold text-white bg-amber-600 hover:bg-amber-700 rounded-lg"
                          >
                            Check Out
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Fast Pass Verification Modal */}
      {showVerifyModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-md shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <QrCode className="w-5 h-5 text-indigo-600" />
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">Verify Security Pass / QR</h3>
              </div>
              <button onClick={() => setShowVerifyModal(false)} className="text-slate-400 hover:text-slate-600">
                <XCircle className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleVerifyPass} className="space-y-3">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                Enter Pass Number, Booking Reference, or QR Token
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  required
                  value={verifyToken}
                  onChange={e => setVerifyToken(e.target.value)}
                  placeholder="e.g. VIS-2026-0001 or BK-20260920-001"
                  className="flex-1 px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono"
                />
                <button
                  type="submit"
                  disabled={verifyLoading}
                  className="px-4 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition disabled:opacity-50"
                >
                  {verifyLoading ? 'Verifying...' : 'Verify'}
                </button>
              </div>
            </form>

            {verificationResult && (
              <div className={`p-4 rounded-2xl border ${
                verificationResult.valid
                  ? 'bg-emerald-50 border-emerald-300 dark:bg-emerald-950/40 dark:border-emerald-700 text-emerald-900 dark:text-emerald-200'
                  : 'bg-rose-50 border-rose-300 dark:bg-rose-950/40 dark:border-rose-700 text-rose-900 dark:text-rose-200'
              }`}>
                <div className="flex items-center gap-2 mb-2 font-bold text-xs">
                  {verificationResult.valid ? (
                    <>
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      <span>Valid Campus Access Pass</span>
                    </>
                  ) : (
                    <>
                      <XCircle className="w-4 h-4 text-rose-600" />
                      <span>Invalid / Inactive Pass</span>
                    </>
                  )}
                </div>
                <p className="text-xs mb-2">{verificationResult.message}</p>
                {verificationResult.visitorName && (
                  <div className="text-[11px] space-y-1 pt-2 border-t border-slate-200 dark:border-slate-700">
                    <div>Visitor: <strong>{verificationResult.visitorName}</strong></div>
                    <div>Host: <strong>{verificationResult.personToMeet}</strong> ({verificationResult.department})</div>
                    <div>Status: <span className="font-mono font-semibold">{verificationResult.status}</span></div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Visitor Pass Badge Modal */}
      <VisitorPassModal
        visitor={selectedVisitorForPass}
        isOpen={isPassModalOpen}
        onClose={() => {
          setIsPassModalOpen(false);
          setSelectedVisitorForPass(null);
        }}
        onCheckIn={handleCheckIn}
        onCheckOut={handleCheckOut}
      />

      {/* New Visitor Booking / Walk-In Modal */}
      <NewVisitorModal
        isOpen={isNewModalOpen}
        onClose={() => setIsNewModalOpen(false)}
        staffList={staffList}
        onSuccess={() => {
          refreshCurrentView();
        }}
      />
    </div>
  );
};
