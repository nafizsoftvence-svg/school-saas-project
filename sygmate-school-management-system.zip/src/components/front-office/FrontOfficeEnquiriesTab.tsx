import React, { useState, useEffect } from 'react';
import {
  Users,
  Search,
  Filter,
  Plus,
  RefreshCw,
  Phone,
  Mail,
  Calendar,
  CheckCircle2,
  Clock,
  ArrowRight,
  Edit,
  UserCheck,
  AlertCircle,
  Download,
  Flag,
  Bell,
  Settings,
  X,
  School,
  TrendingUp,
  AlertTriangle
} from 'lucide-react';
import { api } from '../../services/api';
import {
  FrontOfficeEnquiry,
  SchoolClass,
  AcademicSession,
  EnquiryMetricsSummary,
  EnquirySourceConfig,
  EnquiryPriority
} from '../../types';
import { EnquiryFollowUpModal } from './EnquiryFollowUpModal';
import { AdmissionEnquiryModal } from '../admissions/AdmissionEnquiryModal';

interface FrontOfficeEnquiriesTabProps {
  onRefreshStats?: () => void;
  classes?: SchoolClass[];
  sessions?: AcademicSession[];
  onConvertToAdmission?: (enquiry: any) => void;
}

export const FrontOfficeEnquiriesTab: React.FC<FrontOfficeEnquiriesTabProps> = ({
  onRefreshStats,
  classes = [],
  sessions = [],
  onConvertToAdmission
}) => {
  const [enquiries, setEnquiries] = useState<FrontOfficeEnquiry[]>([]);
  const [metrics, setMetrics] = useState<EnquiryMetricsSummary | null>(null);
  const [sources, setSources] = useState<EnquirySourceConfig[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Filters
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [sourceFilter, setSourceFilter] = useState('');
  const [priorityFilter, setPriorityFilter] = useState('');
  const [classFilter, setClassFilter] = useState('');

  // Modals
  const [selectedEnquiryForFollowUp, setSelectedEnquiryForFollowUp] = useState<FrontOfficeEnquiry | null>(null);
  const [isFollowUpModalOpen, setIsFollowUpModalOpen] = useState(false);
  const [enquiryToEdit, setEnquiryToEdit] = useState<any | null>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isSourceModalOpen, setIsSourceModalOpen] = useState(false);

  // Source form
  const [newSourceName, setNewSourceName] = useState('');
  const [newSourceCode, setNewSourceCode] = useState('');
  const [sourceLoading, setSourceLoading] = useState(false);

  const loadMetrics = async () => {
    try {
      const res = await api.frontOffice.getEnquiryMetricsSummary();
      if (res.success && res.data) {
        setMetrics(res.data);
      }
    } catch (err) {
      console.warn('Failed to fetch enquiry metrics', err);
    }
  };

  const loadSources = async () => {
    try {
      const res = await api.frontOffice.getEnquirySources();
      if (res.success && res.data) {
        setSources(res.data);
      }
    } catch (err) {
      console.warn('Failed to fetch enquiry sources', err);
    }
  };

  const loadEnquiries = async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await api.frontOffice.getEnquiries({
        search: search || undefined,
        status: statusFilter || undefined,
        source: sourceFilter || undefined,
        classId: classFilter || undefined,
        limit: 100
      });
      if (res.success && res.data) {
        let filtered = res.data;
        if (priorityFilter) {
          filtered = filtered.filter(e => e.priority === priorityFilter);
        }
        setEnquiries(filtered);
      } else {
        setError(res.error || 'Failed to fetch admission enquiries.');
      }
    } catch (err: any) {
      setError(err.message || 'Error loading enquiries.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadEnquiries();
    loadMetrics();
    loadSources();
  }, [statusFilter, sourceFilter, priorityFilter, classFilter]);

  const handleFastConvert = async (enquiry: FrontOfficeEnquiry) => {
    if (
      !window.confirm(
        `Convert enquiry #${enquiry.enquiryNumber} (${enquiry.studentName}) directly into a registered Admission Application?`
      )
    ) {
      return;
    }
    try {
      const res = await api.frontOffice.convertEnquiry(enquiry.id);
      if (res.success && res.data) {
        setSuccessMessage(
          `Successfully converted to Admission Application #${res.data.application?.applicationNumber || ''}!`
        );
        loadEnquiries();
        loadMetrics();
        if (onRefreshStats) onRefreshStats();
      } else {
        setError(res.error || 'Conversion failed');
      }
    } catch (err: any) {
      setError(err.message || 'Error converting enquiry');
    }
  };

  const handleQuickStatusChange = async (enquiryId: string, newStatus: string) => {
    try {
      const res = await api.frontOffice.updateEnquiryStatus(enquiryId, {
        status: newStatus,
        remarks: `Status updated via Front Office list view`
      });
      if (res.success && res.data) {
        setEnquiries(prev => prev.map(e => (e.id === enquiryId ? res.data : e)));
        loadMetrics();
      }
    } catch (err: any) {
      setError(err.message || 'Failed to update status');
    }
  };

  const handleSendReminder = async (enquiry: FrontOfficeEnquiry) => {
    try {
      const res = await api.frontOffice.sendFollowUpReminder(enquiry.id);
      if (res.success) {
        setSuccessMessage(`Follow-up alert reminder sent for enquiry #${enquiry.enquiryNumber}`);
      } else {
        setError(res.error || 'Failed to send reminder');
      }
    } catch (err: any) {
      setError(err.message || 'Error sending reminder');
    }
  };

  const handleAddSource = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSourceName.trim()) return;
    try {
      setSourceLoading(true);
      const res = await api.frontOffice.createEnquirySource({
        name: newSourceName.trim(),
        code: newSourceCode.trim() || undefined
      });
      if (res.success && res.data) {
        setSources(prev => [...prev, res.data]);
        setNewSourceName('');
        setNewSourceCode('');
        setSuccessMessage(`Enquiry source "${res.data.name}" created.`);
      }
    } catch (err: any) {
      setError(err.message || 'Failed to create source');
    } finally {
      setSourceLoading(false);
    }
  };

  const handleExport = (format: 'csv' | 'json') => {
    const url = api.frontOffice.exportEnquiriesUrl({
      status: statusFilter || undefined,
      source: sourceFilter || undefined,
      priority: priorityFilter || undefined,
      classId: classFilter || undefined,
      format
    });
    window.open(url, '_blank');
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'NEW':
        return 'bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/30';
      case 'CONTACTED':
        return 'bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border-indigo-500/30';
      case 'FOLLOW_UP_REQUIRED':
      case 'FOLLOW_UP_IN_PROGRESS':
        return 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/30';
      case 'INTERESTED':
      case 'APPLICATION_STARTED':
      case 'QUALIFIED':
        return 'bg-purple-500/10 text-purple-600 dark:text-purple-400 border-purple-500/30';
      case 'CONVERTED':
        return 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/30';
      case 'NOT_INTERESTED':
      case 'LOST':
      case 'CLOSED':
        return 'bg-slate-500/10 text-slate-600 dark:text-slate-400 border-slate-500/30';
      default:
        return 'bg-slate-500/10 text-slate-600 dark:text-slate-400 border-slate-500/30';
    }
  };

  const getPriorityBadge = (priority?: string) => {
    switch (priority) {
      case 'URGENT':
        return 'bg-rose-500/10 text-rose-600 dark:text-rose-400 border-rose-500/30';
      case 'HIGH':
        return 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/30';
      case 'LOW':
        return 'bg-slate-500/10 text-slate-500 dark:text-slate-400 border-slate-500/30';
      default:
        return 'bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border-indigo-500/30';
    }
  };

  return (
    <div className="space-y-4">
      {/* Top Search & Filter Bar */}
      <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex flex-wrap items-center justify-between gap-3 shadow-sm">
        <div className="flex flex-wrap items-center gap-2.5 flex-1 min-w-[280px]">
          {/* Search box */}
          <div className="relative flex-1 min-w-[180px]">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && loadEnquiries()}
              placeholder="Search student, parent, enquiry #, or phone..."
              className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* Status filter */}
          <select
            value={statusFilter}
            onChange={e => setStatusFilter(e.target.value)}
            className="px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="">All Statuses</option>
            <option value="NEW">New Prospect</option>
            <option value="CONTACTED">Contacted</option>
            <option value="FOLLOW_UP_REQUIRED">Follow-Up Required</option>
            <option value="FOLLOW_UP_IN_PROGRESS">Follow-Up In Progress</option>
            <option value="INTERESTED">Interested / Warm Lead</option>
            <option value="APPLICATION_STARTED">Application Started</option>
            <option value="QUALIFIED">Qualified</option>
            <option value="CONVERTED">Converted to Admission</option>
            <option value="NOT_INTERESTED">Not Interested</option>
            <option value="LOST">Lost</option>
            <option value="CLOSED">Closed / Archive</option>
          </select>

          {/* Priority filter */}
          <select
            value={priorityFilter}
            onChange={e => setPriorityFilter(e.target.value)}
            className="px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="">All Priorities</option>
            <option value="URGENT">Urgent</option>
            <option value="HIGH">High</option>
            <option value="MEDIUM">Medium</option>
            <option value="LOW">Low</option>
          </select>

          {/* Source filter */}
          <select
            value={sourceFilter}
            onChange={e => setSourceFilter(e.target.value)}
            className="px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="">All Inflow Sources</option>
            {sources.map(s => (
              <option key={s.id} value={s.code}>
                {s.name}
              </option>
            ))}
          </select>

          {/* Class filter */}
          {classes.length > 0 && (
            <select
              value={classFilter}
              onChange={e => setClassFilter(e.target.value)}
              className="px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="">All Applying Classes</option>
              {classes.map(c => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          )}
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2">
          {/* Export Dropdown */}
          <button
            onClick={() => handleExport('csv')}
            className="px-3 py-1.5 text-xs font-semibold text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl transition inline-flex items-center gap-1"
            title="Export CSV"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>

          {/* Manage Sources */}
          <button
            onClick={() => setIsSourceModalOpen(true)}
            className="p-2 text-slate-500 hover:text-slate-900 dark:hover:text-white rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition"
            title="Configure Enquiry Sources"
          >
            <Settings className="w-4 h-4" />
          </button>

          <button
            onClick={() => {
              loadEnquiries();
              loadMetrics();
            }}
            className="p-2 text-slate-500 hover:text-slate-900 dark:hover:text-white rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition"
            title="Refresh Enquiries"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>

          <button
            onClick={() => {
              setEnquiryToEdit(null);
              setIsEditModalOpen(true);
            }}
            className="px-3.5 py-1.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition shadow-sm inline-flex items-center gap-1.5"
          >
            <Plus className="w-3.5 h-3.5" />
            New Enquiry
          </button>
        </div>
      </div>

      {/* KPI Stats Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold">
            <Users className="w-4 h-4" />
          </div>
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">Total Enquiries</span>
            <span className="text-base font-extrabold text-slate-900 dark:text-white">
              {metrics?.totalEnquiries ?? enquiries.length}
            </span>
          </div>
        </div>

        <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-amber-50 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400 flex items-center justify-center font-bold">
            <Clock className="w-4 h-4" />
          </div>
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">Follow-Up Today</span>
            <div className="flex items-center gap-1.5">
              <span className="text-base font-extrabold text-slate-900 dark:text-white">
                {metrics?.followUpTodayEnquiries ?? 0}
              </span>
              {(metrics?.overdueFollowUps ?? 0) > 0 && (
                <span className="px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-rose-100 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400">
                  {metrics?.overdueFollowUps} overdue
                </span>
              )}
            </div>
          </div>
        </div>

        <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-purple-50 dark:bg-purple-950/40 text-purple-600 dark:text-purple-400 flex items-center justify-center font-bold">
            <TrendingUp className="w-4 h-4" />
          </div>
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">Conversion Rate</span>
            <span className="text-base font-extrabold text-slate-900 dark:text-white">
              {metrics?.conversionRate ?? 0}%
            </span>
          </div>
        </div>

        <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-bold">
            <UserCheck className="w-4 h-4" />
          </div>
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">Converted</span>
            <span className="text-base font-extrabold text-slate-900 dark:text-white">
              {metrics?.convertedEnquiries ?? enquiries.filter(e => e.status === 'CONVERTED').length}
            </span>
          </div>
        </div>
      </div>

      {/* Notifications */}
      {error && (
        <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl flex items-center justify-between text-xs text-rose-600 dark:text-rose-400">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
          <button onClick={() => setError(null)}>
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {successMessage && (
        <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-xl flex items-center justify-between text-xs text-emerald-600 dark:text-emerald-400">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{successMessage}</span>
          </div>
          <button onClick={() => setSuccessMessage(null)}>
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Enquiries Table */}
      <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-850 text-slate-500 dark:text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-200 dark:border-slate-800">
              <tr>
                <th className="px-4 py-3">Enquiry # & Date</th>
                <th className="px-4 py-3">Student Prospect</th>
                <th className="px-4 py-3">Parent / Contact</th>
                <th className="px-4 py-3">Class & Source</th>
                <th className="px-4 py-3">Priority</th>
                <th className="px-4 py-3">Follow-Up Info</th>
                <th className="px-4 py-3">Pipeline Status</th>
                <th className="px-4 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-300">
              {loading && enquiries.length === 0 ? (
                <tr>
                  <td colSpan={8} className="text-center py-12 text-slate-400">
                    <RefreshCw className="w-6 h-6 animate-spin mx-auto mb-2 text-indigo-500" />
                    Loading admission enquiries...
                  </td>
                </tr>
              ) : enquiries.length === 0 ? (
                <tr>
                  <td colSpan={8} className="text-center py-12 text-slate-400">
                    <Users className="w-8 h-8 mx-auto mb-2 text-slate-300 dark:text-slate-600" />
                    No admission inquiries found matching criteria.
                  </td>
                </tr>
              ) : (
                enquiries.map(item => {
                  const targetClass = (classes || []).find(c => c?.id === item.applyingClassId);
                  const isFollowUpToday =
                    item.followUpDate === new Date().toISOString().split('T')[0];
                  const isOverdue =
                    item.followUpDate &&
                    item.followUpDate < new Date().toISOString().split('T')[0] &&
                    item.status !== 'CONVERTED' &&
                    item.status !== 'CLOSED';

                  return (
                    <tr key={item.id} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40 transition">
                      {/* Enquiry # */}
                      <td className="px-4 py-3">
                        <div>
                          <span className="font-mono font-bold text-indigo-600 dark:text-indigo-400 block">
                            {item.enquiryNumber}
                          </span>
                          <span className="text-[10px] text-slate-400 font-mono">
                            {new Date(item.createdAt).toLocaleDateString([], {
                              month: 'short',
                              day: 'numeric',
                              year: 'numeric'
                            })}
                          </span>
                        </div>
                      </td>

                      {/* Student Prospect */}
                      <td className="px-4 py-3">
                        <div>
                          <span className="font-bold text-slate-900 dark:text-white block">
                            {item.studentName}
                          </span>
                          <span className="text-[11px] text-slate-500 capitalize">
                            {item.gender} {item.dateOfBirth ? `• Born ${item.dateOfBirth}` : ''}
                          </span>
                          {item.previousSchool && (
                            <span className="text-[10px] text-slate-400 block truncate max-w-[150px]">
                              Prev: {item.previousSchool}
                            </span>
                          )}
                        </div>
                      </td>

                      {/* Parent / Contact */}
                      <td className="px-4 py-3">
                        <div>
                          <span className="font-semibold text-slate-800 dark:text-slate-200 block">
                            {item.parentName} {item.relationship ? `(${item.relationship})` : ''}
                          </span>
                          <span className="font-mono text-[11px] text-slate-500 flex items-center gap-1">
                            <Phone className="w-3 h-3 text-slate-400" />
                            {item.phone}
                          </span>
                          {item.email && (
                            <span className="text-[10px] text-slate-400 truncate max-w-[140px] block">
                              {item.email}
                            </span>
                          )}
                        </div>
                      </td>

                      {/* Class & Source */}
                      <td className="px-4 py-3">
                        <div>
                          <span className="font-semibold text-slate-800 dark:text-slate-200 block">
                            {targetClass?.name || 'Class ' + (item.applyingClassId || '—')}
                          </span>
                          <span className="text-[10px] text-slate-400 font-medium">
                            Via {item.source.replace(/_/g, ' ')}
                          </span>
                        </div>
                      </td>

                      {/* Priority */}
                      <td className="px-4 py-3">
                        <span
                          className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold border ${getPriorityBadge(
                            item.priority
                          )}`}
                        >
                          {item.priority || 'MEDIUM'}
                        </span>
                      </td>

                      {/* Follow-up info */}
                      <td className="px-4 py-3">
                        <div>
                          {item.followUpDate ? (
                            <span
                              className={`inline-flex items-center gap-1 text-[11px] font-semibold ${
                                isOverdue
                                  ? 'text-rose-600 dark:text-rose-400'
                                  : isFollowUpToday
                                  ? 'text-indigo-600 dark:text-indigo-400 font-bold'
                                  : 'text-amber-600 dark:text-amber-400'
                              }`}
                            >
                              <Calendar className="w-3 h-3" />
                              {item.followUpDate} {item.followUpTime || ''}
                              {isOverdue && <span className="text-[9px]">(Overdue)</span>}
                              {isFollowUpToday && <span className="text-[9px]">(Today)</span>}
                            </span>
                          ) : (
                            <span className="text-[11px] text-slate-400 font-medium">None scheduled</span>
                          )}
                          {item.notes && (
                            <p className="text-[10px] text-slate-400 truncate max-w-[160px] italic">
                              "{item.notes}"
                            </p>
                          )}
                        </div>
                      </td>

                      {/* Status with fast-switch */}
                      <td className="px-4 py-3">
                        <select
                          value={item.status}
                          onChange={e => handleQuickStatusChange(item.id, e.target.value)}
                          className={`px-2 py-0.5 rounded-lg text-[10px] font-bold border ${getStatusBadge(
                            item.status
                          )} bg-transparent cursor-pointer focus:outline-none`}
                        >
                          <option value="NEW">NEW</option>
                          <option value="CONTACTED">CONTACTED</option>
                          <option value="FOLLOW_UP_REQUIRED">FOLLOW UP REQUIRED</option>
                          <option value="FOLLOW_UP_IN_PROGRESS">FOLLOW UP IN PROGRESS</option>
                          <option value="INTERESTED">INTERESTED</option>
                          <option value="APPLICATION_STARTED">APPLICATION STARTED</option>
                          <option value="QUALIFIED">QUALIFIED</option>
                          <option value="CONVERTED">CONVERTED</option>
                          <option value="NOT_INTERESTED">NOT INTERESTED</option>
                          <option value="LOST">LOST</option>
                          <option value="CLOSED">CLOSED</option>
                        </select>
                      </td>

                      {/* Actions */}
                      <td className="px-4 py-3 text-right">
                        <div className="inline-flex items-center gap-1.5">
                          {/* Send alert reminder */}
                          <button
                            onClick={() => handleSendReminder(item)}
                            className="p-1 text-slate-400 hover:text-amber-600 dark:hover:text-amber-400 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                            title="Send follow-up reminder notification"
                          >
                            <Bell className="w-3.5 h-3.5" />
                          </button>

                          {/* Record Follow Up */}
                          <button
                            onClick={() => {
                              setSelectedEnquiryForFollowUp(item);
                              setIsFollowUpModalOpen(true);
                            }}
                            className="px-2 py-1 text-[11px] font-semibold text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 rounded-lg transition"
                            title="Log Follow-Up Interaction"
                          >
                            Follow-Up
                          </button>

                          {/* Convert to Admission Application */}
                          {item.status !== 'CONVERTED' && (
                            <button
                              onClick={() => {
                                if (onConvertToAdmission) {
                                  onConvertToAdmission(item);
                                } else {
                                  handleFastConvert(item);
                                }
                              }}
                              className="px-2.5 py-1 text-[11px] font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg transition shadow-sm inline-flex items-center gap-1"
                              title="Convert to full admission application"
                            >
                              <UserCheck className="w-3 h-3" />
                              Convert
                            </button>
                          )}

                          {/* Edit Details & View History */}
                          <button
                            onClick={() => {
                              setEnquiryToEdit(item);
                              setIsEditModalOpen(true);
                            }}
                            className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                            title="Edit Enquiry & View Timeline History"
                          >
                            <Edit className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Follow-Up Modal */}
      <EnquiryFollowUpModal
        enquiry={selectedEnquiryForFollowUp}
        isOpen={isFollowUpModalOpen}
        onClose={() => {
          setIsFollowUpModalOpen(false);
          setSelectedEnquiryForFollowUp(null);
        }}
        onSuccess={() => {
          loadEnquiries();
          loadMetrics();
          if (onRefreshStats) onRefreshStats();
        }}
      />

      {/* Edit / New Enquiry Modal */}
      <AdmissionEnquiryModal
        isOpen={isEditModalOpen}
        onClose={() => {
          setIsEditModalOpen(false);
          setEnquiryToEdit(null);
        }}
        enquiryToEdit={enquiryToEdit}
        onSuccess={() => {
          loadEnquiries();
          loadMetrics();
          if (onRefreshStats) onRefreshStats();
        }}
        onConvertToAdmission={onConvertToAdmission}
      />

      {/* Configure Enquiry Sources Modal */}
      {isSourceModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-md shadow-2xl overflow-hidden my-8">
            <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-slate-800/40">
              <div className="flex items-center gap-2">
                <Settings className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">Enquiry Inflow Sources</h3>
              </div>
              <button
                onClick={() => setIsSourceModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              {/* Existing Sources List */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
                  Configured Sources ({sources.length})
                </label>
                <div className="max-h-40 overflow-y-auto space-y-1.5 border border-slate-200 dark:border-slate-800 rounded-xl p-2">
                  {sources.map(s => (
                    <div
                      key={s.id}
                      className="flex items-center justify-between p-1.5 rounded-lg bg-slate-50 dark:bg-slate-800 text-xs"
                    >
                      <span className="font-semibold text-slate-800 dark:text-slate-200">{s.name}</span>
                      <span className="font-mono text-[10px] text-slate-400">{s.code}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Add New Source Form */}
              <form onSubmit={handleAddSource} className="pt-3 border-t border-slate-200 dark:border-slate-800 space-y-3">
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Add New Enquiry Source
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="text"
                    required
                    value={newSourceName}
                    onChange={e => setNewSourceName(e.target.value)}
                    placeholder="e.g. Newspaper Ad"
                    className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                  <input
                    type="text"
                    value={newSourceCode}
                    onChange={e => setNewSourceCode(e.target.value.toUpperCase())}
                    placeholder="CODE (e.g. NEWSPAPER)"
                    className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono"
                  />
                </div>
                <div className="flex justify-end">
                  <button
                    type="submit"
                    disabled={sourceLoading}
                    className="px-4 py-1.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition disabled:opacity-50"
                  >
                    {sourceLoading ? 'Adding...' : 'Add Source'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
