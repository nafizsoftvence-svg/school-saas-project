import React, { useState } from 'react';
import { X, Save, Phone, PhoneIncoming, PhoneOutgoing, User, Clock, Calendar, CheckSquare, AlertCircle } from 'lucide-react';
import { api } from '../../services/api';
import { PhoneCallLogRecord, CallDirection, CallType, CallStatus } from '../../types';

interface NewCallLogModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (call: PhoneCallLogRecord) => void;
  staffList?: Array<{ id: string; name: string; department?: string }>;
}

export const NewCallLogModal: React.FC<NewCallLogModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  staffList = []
}) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const today = new Date().toISOString().split('T')[0];
  const currentTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });

  const [formData, setFormData] = useState({
    direction: 'INCOMING' as CallDirection,
    callerName: '',
    phone: '',
    callerType: 'PARENT',
    callType: 'GENERAL_QUERY' as CallType,
    department: 'Administration',
    assignedStaffId: '',
    assignedStaffName: '',
    callDate: today,
    callTime: currentTime,
    durationSeconds: 120,
    status: 'COMPLETED' as CallStatus,
    purpose: '',
    summaryNotes: '',
    followUpRequired: false,
    followUpDate: ''
  });

  if (!isOpen) return null;

  const handleStaffChange = (staffId: string) => {
    const st = (staffList || []).find(s => s?.id === staffId);
    if (st) {
      setFormData(prev => ({
        ...prev,
        assignedStaffId: st.id,
        assignedStaffName: st.name,
        department: st.department || prev.department
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        assignedStaffId: '',
        assignedStaffName: ''
      }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.callerName.trim() || !formData.phone.trim() || !formData.purpose.trim()) {
      setError('Caller Name, Phone Number, and Call Purpose are required.');
      return;
    }
    if (formData.followUpRequired && !formData.followUpDate) {
      setError('Please specify a follow-up date when follow-up is required.');
      return;
    }

    try {
      setLoading(true);
      setError(null);
      const res = await api.frontOffice.createCall(formData);
      if (res.success && res.data) {
        onSuccess(res.data);
        onClose();
      } else {
        setError(res.error || 'Failed to log phone call.');
      }
    } catch (err: any) {
      setError(err.message || 'Error occurred while saving call log.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-xl shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-slate-800/40">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold">
              <Phone className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">Log Telephone Interaction</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">Record incoming or outgoing front-desk call details</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {error && (
          <div className="mx-6 mt-4 p-3 bg-rose-500/10 border border-rose-500/30 rounded-2xl flex items-center gap-2.5 text-xs text-rose-600 dark:text-rose-400">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {/* Call Direction Buttons */}
          <div className="grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => setFormData({ ...formData, direction: 'INCOMING' })}
              className={`p-3 rounded-2xl border text-xs font-bold flex items-center justify-center gap-2 transition ${
                formData.direction === 'INCOMING'
                  ? 'bg-blue-500/10 text-blue-600 border-blue-500/30 dark:text-blue-400 shadow-sm'
                  : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
              }`}
            >
              <PhoneIncoming className="w-4 h-4 text-blue-500" />
              Incoming Call
            </button>
            <button
              type="button"
              onClick={() => setFormData({ ...formData, direction: 'OUTGOING' })}
              className={`p-3 rounded-2xl border text-xs font-bold flex items-center justify-center gap-2 transition ${
                formData.direction === 'OUTGOING'
                  ? 'bg-emerald-500/10 text-emerald-600 border-emerald-500/30 dark:text-emerald-400 shadow-sm'
                  : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
              }`}
            >
              <PhoneOutgoing className="w-4 h-4 text-emerald-500" />
              Outgoing Call
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Caller Name */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                {formData.direction === 'INCOMING' ? 'Caller Name *' : 'Recipient Name *'}
              </label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  required
                  value={formData.callerName}
                  onChange={e => setFormData({ ...formData, callerName: e.target.value })}
                  placeholder="e.g. David Miller"
                  className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>

            {/* Phone */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Contact Phone *
              </label>
              <div className="relative">
                <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="tel"
                  required
                  value={formData.phone}
                  onChange={e => setFormData({ ...formData, phone: e.target.value })}
                  placeholder="+1 (555) 000-0000"
                  className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono"
                />
              </div>
            </div>

            {/* Call Type */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Call Purpose / Category
              </label>
              <select
                value={formData.callType}
                onChange={e => setFormData({ ...formData, callType: e.target.value as CallType })}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="GENERAL_QUERY">General Query</option>
                <option value="ADMISSION_INQUIRY">Admission Inquiry</option>
                <option value="FEE_QUERY">Fee / Billing Query</option>
                <option value="COMPLAINT">Complaint / Grievance</option>
                <option value="EMERGENCY">Emergency Notice</option>
                <option value="ROUTINE">Routine Follow-up</option>
              </select>
            </div>

            {/* Call Status */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Call Status / Outcome
              </label>
              <select
                value={formData.status}
                onChange={e => setFormData({ ...formData, status: e.target.value as CallStatus })}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="COMPLETED">Completed / Answered</option>
                <option value="MISSED">Missed Call</option>
                <option value="BUSY">Line Busy</option>
                <option value="NO_ANSWER">No Answer</option>
                <option value="VOICEMAIL">Voicemail Left</option>
              </select>
            </div>

            {/* Assigned Staff */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Attending Staff Member
              </label>
              <select
                value={formData.assignedStaffId}
                onChange={e => handleStaffChange(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="">Select Staff...</option>
                {staffList.map(st => (
                  <option key={st.id} value={st.id}>
                    {st.name} ({st.department || 'General'})
                  </option>
                ))}
              </select>
            </div>

            {/* Duration */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Duration (Seconds)
              </label>
              <div className="relative">
                <Clock className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="number"
                  min="0"
                  step="10"
                  value={formData.durationSeconds}
                  onChange={e => setFormData({ ...formData, durationSeconds: parseInt(e.target.value) || 0 })}
                  className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>
          </div>

          {/* Purpose */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Purpose / Topic *
            </label>
            <input
              type="text"
              required
              value={formData.purpose}
              onChange={e => setFormData({ ...formData, purpose: e.target.value })}
              placeholder="e.g. Inquired about Grade 9 fee structure & discount policies"
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* Summary Notes */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Call Summary / Outcome Notes
            </label>
            <textarea
              rows={2}
              value={formData.summaryNotes}
              onChange={e => setFormData({ ...formData, summaryNotes: e.target.value })}
              placeholder="Record any specific questions asked, documents promised, or resolution provided..."
              className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* Follow-up Section */}
          <div className="p-3.5 bg-slate-50 dark:bg-slate-850 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-2.5">
            <div className="flex items-center justify-between">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.followUpRequired}
                  onChange={e => setFormData({ ...formData, followUpRequired: e.target.checked })}
                  className="rounded text-indigo-600 focus:ring-indigo-500"
                />
                <span className="text-xs font-bold text-slate-900 dark:text-white">Requires Callback / Follow-Up</span>
              </label>
            </div>
            {formData.followUpRequired && (
              <div className="pt-2">
                <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                  Scheduled Follow-Up Date *
                </label>
                <input
                  type="date"
                  required={formData.followUpRequired}
                  value={formData.followUpDate}
                  onChange={e => setFormData({ ...formData, followUpDate: e.target.value })}
                  className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-5 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition shadow-sm inline-flex items-center gap-1.5 disabled:opacity-50"
            >
              <Save className="w-3.5 h-3.5" />
              {loading ? 'Saving...' : 'Save Call Record'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
