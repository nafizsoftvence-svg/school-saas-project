import React, { useState, useEffect, useMemo } from 'react';
import {
  Users,
  Shield,
  Phone,
  ShieldAlert,
  Plus,
  Clock,
  CheckCircle2,
  Calendar,
  ArrowRight,
  Printer,
  PhoneIncoming,
  AlertCircle,
  Eye,
  Search,
  RefreshCw,
  TrendingUp,
  BarChart2,
  Filter,
  Activity,
  Layers,
  Award,
  AlertTriangle,
  ArrowUpRight
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid
} from 'recharts';
import {
  FrontOfficeDashboardStats,
  FrontOfficeAnalyticsData,
  DashboardDatePreset,
  VisitorRecord,
  PhoneCallLogRecord,
  ComplaintRecord,
  FrontOfficeEnquiry,
  AcademicSession
} from '../../types';
import { api } from '../../services/api';

interface FrontOfficeDashboardTabProps {
  initialStats?: FrontOfficeDashboardStats | null;
  stats?: FrontOfficeDashboardStats | null;
  visitors: VisitorRecord[];
  calls: PhoneCallLogRecord[];
  complaints: ComplaintRecord[];
  enquiries: FrontOfficeEnquiry[];
  sessions?: AcademicSession[];
  staffList?: Array<{ id: string; name: string; department?: string }>;
  onOpenNewVisitor: () => void;
  onOpenNewCall: () => void;
  onOpenNewComplaint: () => void;
  onOpenNewEnquiry: () => void;
  onViewPass: (visitor: VisitorRecord) => void;
  onCheckOutVisitor: (id: string) => void;
  onViewComplaint: (complaint: ComplaintRecord) => void;
  onSwitchTab: (tabId: string) => void;
}

const PRESET_OPTIONS: { id: DashboardDatePreset; label: string }[] = [
  { id: 'TODAY', label: 'Today' },
  { id: 'YESTERDAY', label: 'Yesterday' },
  { id: 'THIS_WEEK', label: 'This Week' },
  { id: 'LAST_7_DAYS', label: 'Last 7 Days' },
  { id: 'THIS_MONTH', label: 'This Month' },
  { id: 'LAST_30_DAYS', label: 'Last 30 Days' },
  { id: 'THIS_ACADEMIC_YEAR', label: 'Academic Year' },
  { id: 'CUSTOM', label: 'Custom' }
];

export const FrontOfficeDashboardTab: React.FC<FrontOfficeDashboardTabProps> = ({
  initialStats,
  stats: propStats,
  visitors,
  calls,
  complaints,
  enquiries,
  sessions = [],
  staffList = [],
  onOpenNewVisitor,
  onOpenNewCall,
  onOpenNewComplaint,
  onOpenNewEnquiry,
  onViewPass,
  onCheckOutVisitor,
  onViewComplaint,
  onSwitchTab
}) => {
  const [datePreset, setDatePreset] = useState<DashboardDatePreset>('TODAY');
  const [startDate, setStartDate] = useState<string>('');
  const [endDate, setEndDate] = useState<string>('');
  const [selectedSessionId, setSelectedSessionId] = useState<string>('');

  const [dashboardStats, setDashboardStats] = useState<FrontOfficeDashboardStats | null>(
    propStats || initialStats || null
  );
  const [analyticsData, setAnalyticsData] = useState<FrontOfficeAnalyticsData | null>(null);
  const [loading, setLoading] = useState<boolean>(false);

  const activeVisitors = visitors.filter(v => v.status === 'CHECKED_IN');
  const urgentComplaints = complaints.filter(
    c => (c.priority === 'URGENT' || c.priority === 'HIGH') && c.status !== 'RESOLVED' && c.status !== 'CLOSED'
  );
  const pendingCalls = calls.filter(c => c.followUpRequired && c.followUpStatus !== 'COMPLETED');
  const pendingEnquiries = enquiries.filter(
    e => e.status === 'NEW' || e.status === 'CONTACTED' || e.status === 'FOLLOW_UP_REQUIRED'
  );

  const timeSeriesData = useMemo(() => {
    return analyticsData?.timeSeries || analyticsData?.trends || [];
  }, [analyticsData]);

  const departmentData = useMemo(() => {
    return analyticsData?.departmentDistribution || [];
  }, [analyticsData]);

  const fetchDashboardMetrics = async () => {
    try {
      setLoading(true);
      const params = {
        datePreset,
        startDate: datePreset === 'CUSTOM' ? startDate : undefined,
        endDate: datePreset === 'CUSTOM' ? endDate : undefined,
        academicSessionId: selectedSessionId || undefined
      };

      const [statsRes, analyticsRes] = await Promise.all([
        api.frontOffice.getStats(params),
        api.frontOffice.getAnalytics(params)
      ]);

      if (statsRes.success && statsRes.data) {
        setDashboardStats(statsRes.data);
      }
      if (analyticsRes.success && analyticsRes.data) {
        setAnalyticsData(analyticsRes.data);
      }
    } catch (err) {
      console.error('Failed to fetch dashboard metrics:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardMetrics();
  }, [datePreset, selectedSessionId]);

  const handleCustomApply = () => {
    if (startDate && endDate) {
      fetchDashboardMetrics();
    }
  };

  const currentStats = dashboardStats || propStats || initialStats;

  return (
    <div className="space-y-6">
      {/* Top Filter Bar: Date Presets & Academic Session */}
      <div className="p-4 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        {/* Preset Selector */}
        <div className="flex flex-wrap items-center gap-1.5">
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mr-2 flex items-center gap-1">
            <Calendar className="w-3.5 h-3.5" />
            Timeframe:
          </span>
          {PRESET_OPTIONS.map(preset => (
            <button
              key={preset.id}
              onClick={() => setDatePreset(preset.id)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-xl transition ${
                datePreset === preset.id
                  ? 'bg-indigo-600 text-white shadow-sm font-bold'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              {preset.label}
            </button>
          ))}
        </div>

        {/* Controls: Custom Range & Academic Session & Refresh */}
        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
          {datePreset === 'CUSTOM' && (
            <div className="flex items-center gap-2">
              <input
                type="date"
                value={startDate}
                onChange={e => setStartDate(e.target.value)}
                className="px-2.5 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
              />
              <span className="text-xs text-slate-400">to</span>
              <input
                type="date"
                value={endDate}
                onChange={e => setEndDate(e.target.value)}
                className="px-2.5 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
              />
              <button
                onClick={handleCustomApply}
                className="px-3 py-1.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition"
              >
                Apply
              </button>
            </div>
          )}

          {sessions.length > 0 && (
            <select
              value={selectedSessionId}
              onChange={e => setSelectedSessionId(e.target.value)}
              className="px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
            >
              <option value="">All Academic Sessions</option>
              {sessions.map(s => (
                <option key={s.id} value={s.id}>
                  {s.name} {s.isCurrent ? '(Current)' : ''}
                </option>
              ))}
            </select>
          )}

          <button
            onClick={fetchDashboardMetrics}
            disabled={loading}
            className="p-2 text-slate-500 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition"
            title="Refresh Dashboard Data"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-indigo-600' : ''}`} />
          </button>
        </div>
      </div>

      {/* Fast Operations Quick Action Dock */}
      <div className="p-4 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-wrap items-center justify-between gap-3">
        <div>
          <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <span>Front Desk Fast Operations</span>
            {currentStats?.dateRange && (
              <span className="text-[10px] font-normal text-slate-400">
                ({currentStats.dateRange.startDate} to {currentStats.dateRange.endDate})
              </span>
            )}
          </h3>
          <p className="text-xs text-slate-500">
            One-click workflows to log real-time front office interactions
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={onOpenNewVisitor}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition shadow-sm"
          >
            <Shield className="w-3.5 h-3.5" />
            New Visitor Pass
          </button>

          <button
            onClick={onOpenNewCall}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl transition shadow-sm"
          >
            <Phone className="w-3.5 h-3.5" />
            Log Phone Call
          </button>

          <button
            onClick={onOpenNewComplaint}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-xl transition shadow-sm"
          >
            <ShieldAlert className="w-3.5 h-3.5" />
            Register Grievance
          </button>

          <button
            onClick={onOpenNewEnquiry}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-xl transition"
          >
            <Users className="w-3.5 h-3.5 text-indigo-500" />
            Admission Enquiry
          </button>

          <button
            onClick={() => onSwitchTab('reports')}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/40 hover:bg-indigo-100 dark:hover:bg-indigo-900/40 rounded-xl transition"
          >
            <BarChart2 className="w-3.5 h-3.5" />
            View Reports
          </button>
        </div>
      </div>

      {/* Primary KPI Cards Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {/* Visitors KPI */}
        <div
          onClick={() => onSwitchTab('visitors')}
          className="p-4 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm hover:border-indigo-400 dark:hover:border-indigo-600 transition cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
              Campus Visitors
            </span>
            <div className="w-8 h-8 rounded-xl bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold">
              <Shield className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900 dark:text-white">
              {currentStats?.todaysVisitors ?? visitors.length}
            </span>
            <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400">
              ({currentStats?.checkedInVisitors ?? activeVisitors.length} Inside)
            </span>
          </div>
          <div className="mt-2 pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[11px] text-slate-500">
            <span>{currentStats?.expectedVisitors ?? 0} expected</span>
            <span className="text-indigo-600 font-semibold group-hover:translate-x-0.5 transition flex items-center gap-0.5">
              Passes <ArrowRight className="w-3 h-3" />
            </span>
          </div>
        </div>

        {/* Calls KPI */}
        <div
          onClick={() => onSwitchTab('calls')}
          className="p-4 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm hover:border-blue-400 dark:hover:border-blue-600 transition cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
              Phone Calls
            </span>
            <div className="w-8 h-8 rounded-xl bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400 flex items-center justify-center font-bold">
              <Phone className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900 dark:text-white">
              {currentStats?.todaysCalls ?? calls.length}
            </span>
            <span className="text-xs font-bold text-rose-500">
              ({currentStats?.missedCalls ?? 0} Missed)
            </span>
          </div>
          <div className="mt-2 pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[11px] text-slate-500">
            <span>{currentStats?.callsFollowUpRequired ?? pendingCalls.length} callbacks pending</span>
            <span className="text-blue-600 font-semibold group-hover:translate-x-0.5 transition flex items-center gap-0.5">
              Logs <ArrowRight className="w-3 h-3" />
            </span>
          </div>
        </div>

        {/* Grievance Desk KPI */}
        <div
          onClick={() => onSwitchTab('complaints')}
          className="p-4 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm hover:border-rose-400 dark:hover:border-rose-600 transition cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
              Grievance Desk
            </span>
            <div className="w-8 h-8 rounded-xl bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 flex items-center justify-center font-bold">
              <ShieldAlert className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900 dark:text-white">
              {currentStats?.openComplaints ?? complaints.length}
            </span>
            <span className="text-xs font-bold text-rose-600 dark:text-rose-400">
              ({currentStats?.urgentComplaints ?? urgentComplaints.length} Urgent)
            </span>
          </div>
          <div className="mt-2 pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[11px] text-slate-500">
            <span>{currentStats?.resolvedComplaints ?? 0} resolved</span>
            <span className="text-rose-600 font-semibold group-hover:translate-x-0.5 transition flex items-center gap-0.5">
              Tickets <ArrowRight className="w-3 h-3" />
            </span>
          </div>
        </div>

        {/* Admissions Pipeline KPI */}
        <div
          onClick={() => onSwitchTab('enquiries')}
          className="p-4 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm hover:border-emerald-400 dark:hover:border-emerald-600 transition cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
              Admissions Pipeline
            </span>
            <div className="w-8 h-8 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 flex items-center justify-center font-bold">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900 dark:text-white">
              {currentStats?.totalEnquiries ?? enquiries.length}
            </span>
            <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400">
              ({currentStats?.convertedAdmissions ?? 0} Enrolled)
            </span>
          </div>
          <div className="mt-2 pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[11px] text-slate-500">
            <span>
              {currentStats?.conversionRate ? `${currentStats.conversionRate}% conversion` : `${pendingEnquiries.length} follow-ups`}
            </span>
            <span className="text-emerald-600 font-semibold group-hover:translate-x-0.5 transition flex items-center gap-0.5">
              Pipeline <ArrowRight className="w-3 h-3" />
            </span>
          </div>
        </div>
      </div>

      {/* Analytics Charts & Visualizations */}
      {analyticsData && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Time Series Activity Trends (2 cols) */}
          <div className="lg:col-span-2 p-5 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Activity className="w-4 h-4 text-indigo-600" />
                  Front Office Activity Trends
                </h4>
                <p className="text-xs text-slate-500">
                  Daily volume distribution of enquiries, visitors, calls, and complaints
                </p>
              </div>
              <span className="text-[11px] px-2.5 py-1 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-medium">
                {timeSeriesData.length} Days Recorded
              </span>
            </div>

            <div className="h-64 w-full pt-2">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart
                  data={timeSeriesData}
                  margin={{ top: 10, right: 10, left: -20, bottom: 0 }}
                >
                  <defs>
                    <linearGradient id="enquiryGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#10b981" stopOpacity={0.4} />
                      <stop offset="95%" stopColor="#10b981" stopOpacity={0.0} />
                    </linearGradient>
                    <linearGradient id="visitorGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#6366f1" stopOpacity={0.4} />
                      <stop offset="95%" stopColor="#6366f1" stopOpacity={0.0} />
                    </linearGradient>
                    <linearGradient id="callGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.4} />
                      <stop offset="95%" stopColor="#3b82f6" stopOpacity={0.0} />
                    </linearGradient>
                    <linearGradient id="complaintGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#f43f5e" stopOpacity={0.4} />
                      <stop offset="95%" stopColor="#f43f5e" stopOpacity={0.0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" opacity={0.5} />
                  <XAxis
                    dataKey="date"
                    tick={{ fontSize: 10, fill: '#94a3b8' }}
                    tickFormatter={str => (str ? str.slice(5) : '')}
                  />
                  <YAxis tick={{ fontSize: 10, fill: '#94a3b8' }} allowDecimals={false} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#1e293b',
                      borderRadius: '12px',
                      border: 'none',
                      color: '#fff',
                      fontSize: '11px'
                    }}
                  />
                  <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} />
                  <Area
                    type="monotone"
                    dataKey="enquiries"
                    name="Enquiries"
                    stroke="#10b981"
                    strokeWidth={2}
                    fillOpacity={1}
                    fill="url(#enquiryGrad)"
                  />
                  <Area
                    type="monotone"
                    dataKey="visitors"
                    name="Visitors"
                    stroke="#6366f1"
                    strokeWidth={2}
                    fillOpacity={1}
                    fill="url(#visitorGrad)"
                  />
                  <Area
                    type="monotone"
                    dataKey="calls"
                    name="Calls"
                    stroke="#3b82f6"
                    strokeWidth={2}
                    fillOpacity={1}
                    fill="url(#callGrad)"
                  />
                  <Area
                    type="monotone"
                    dataKey="complaints"
                    name="Complaints"
                    stroke="#f43f5e"
                    strokeWidth={2}
                    fillOpacity={1}
                    fill="url(#complaintGrad)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Department Traffic Distribution (1 col) */}
          <div className="p-5 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <div>
              <h4 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Layers className="w-4 h-4 text-indigo-600" />
                Department Interactions
              </h4>
              <p className="text-xs text-slate-500">
                Cross-department visitor & complaint load
              </p>
            </div>

            <div className="h-64 w-full pt-2">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={departmentData.slice(0, 5)}
                  layout="vertical"
                  margin={{ top: 10, right: 10, left: 10, bottom: 0 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" opacity={0.5} />
                  <XAxis type="number" tick={{ fontSize: 10, fill: '#94a3b8' }} allowDecimals={false} />
                  <YAxis
                    dataKey="department"
                    type="category"
                    tick={{ fontSize: 10, fill: '#94a3b8' }}
                    width={80}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#1e293b',
                      borderRadius: '12px',
                      border: 'none',
                      color: '#fff',
                      fontSize: '11px'
                    }}
                  />
                  <Legend wrapperStyle={{ fontSize: '10px' }} />
                  <Bar dataKey="visitors" name="Visitors" fill="#6366f1" radius={[0, 4, 4, 0]} />
                  <Bar dataKey="complaints" name="Complaints" fill="#f43f5e" radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}

      {/* Real-time Operational Queues: Campus Visitors & Priority Tasks */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Active Visitors on Campus */}
        <div className="p-5 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
              <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                Active Visitors on Campus ({activeVisitors.length})
              </h4>
            </div>
            <button
              onClick={() => onSwitchTab('visitors')}
              className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline inline-flex items-center gap-1"
            >
              Full Register
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          {activeVisitors.length === 0 ? (
            <div className="text-center py-8 text-slate-400 text-xs">
              <Shield className="w-8 h-8 mx-auto mb-2 text-slate-300 dark:text-slate-700" />
              No external visitors currently checked in on school grounds.
            </div>
          ) : (
            <div className="space-y-2.5 max-h-80 overflow-y-auto pr-1">
              {activeVisitors.map(visitor => (
                <div
                  key={visitor.id}
                  className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs"
                >
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-900 dark:text-white">{visitor.visitorName}</span>
                      <span className="font-mono text-[10px] text-indigo-600 dark:text-indigo-400 font-bold">
                        {visitor.visitorPassNumber}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500">
                      Host: <strong>{visitor.personToMeet}</strong> ({visitor.department})
                    </p>
                    <span className="text-[10px] text-slate-400 font-mono">
                      Checked in at{' '}
                      {visitor.checkInTime
                        ? new Date(visitor.checkInTime).toLocaleTimeString([], {
                            hour: '2-digit',
                            minute: '2-digit'
                          })
                        : 'Earlier'}
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => onViewPass(visitor)}
                      className="p-1.5 text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 rounded-lg transition"
                      title="View / Print Badge"
                    >
                      <Printer className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => onCheckOutVisitor(visitor.id)}
                      className="px-2.5 py-1 text-[11px] font-bold text-white bg-amber-600 hover:bg-amber-700 rounded-lg transition shadow-sm"
                    >
                      Check Out
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Priority Queues: Urgent Complaints & Follow-ups */}
        <div className="space-y-6">
          {/* Urgent Complaints Queue */}
          <div className="p-5 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-rose-500" />
                <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                  Urgent Complaints Queue ({urgentComplaints.length})
                </h4>
              </div>
              <button
                onClick={() => onSwitchTab('complaints')}
                className="text-xs font-semibold text-rose-600 dark:text-rose-400 hover:underline inline-flex items-center gap-1"
              >
                Grievance Board
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>

            {urgentComplaints.length === 0 ? (
              <div className="text-center py-6 text-slate-400 text-xs">
                <CheckCircle2 className="w-7 h-7 mx-auto mb-1 text-emerald-500" />
                No unresolved urgent complaints. All priority SLAs in good standing.
              </div>
            ) : (
              <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                {urgentComplaints.map(c => (
                  <div
                    key={c.id}
                    onClick={() => onViewComplaint(c)}
                    className="p-3 rounded-2xl bg-rose-50/50 dark:bg-rose-950/20 border border-rose-200 dark:border-rose-900/40 text-xs flex items-center justify-between cursor-pointer hover:bg-rose-100/50 transition"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-rose-600 dark:text-rose-400">
                          {c.complaintNumber}
                        </span>
                        <span className="font-bold text-slate-900 dark:text-white">{c.subject}</span>
                      </div>
                      <span className="text-[11px] text-slate-500 block">
                        {c.complainantName} ({c.complainantType}) • {c.assignedDepartment || 'General'}
                      </span>
                    </div>
                    <Eye className="w-4 h-4 text-slate-400" />
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Pending Callbacks / Enquiries Box */}
          <div className="p-5 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-amber-500" />
                <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                  Pending Callbacks & Follow-Ups ({pendingCalls.length})
                </h4>
              </div>
              <button
                onClick={() => onSwitchTab('calls')}
                className="text-xs font-semibold text-amber-600 dark:text-amber-400 hover:underline inline-flex items-center gap-1"
              >
                Call Logs
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>

            {pendingCalls.length === 0 ? (
              <div className="text-center py-6 text-slate-400 text-xs">
                No outstanding telephone callbacks scheduled.
              </div>
            ) : (
              <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                {pendingCalls.slice(0, 3).map(call => (
                  <div
                    key={call.id}
                    className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-800 text-xs flex items-center justify-between"
                  >
                    <div>
                      <span className="font-bold text-slate-900 dark:text-white block">
                        {call.callerName}
                      </span>
                      <span className="text-[11px] text-slate-500 font-mono">{call.callerPhone}</span>
                      <span className="text-[10px] text-amber-600 dark:text-amber-400 block font-semibold">
                        Due: {call.followUpDate || 'Today'}
                      </span>
                    </div>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20 font-bold">
                      Callback
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Staff Workload Leaderboard (from analytics) */}
      {analyticsData?.staffWorkload && analyticsData.staffWorkload.length > 0 && (
        <div className="p-5 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Award className="w-4 h-4 text-amber-500" />
                Front Office Staff Productivity & Load
              </h4>
              <p className="text-xs text-slate-500">
                Staff interactions across admissions, visitors, telephone logs, and grievances
              </p>
            </div>
            <button
              onClick={() => onSwitchTab('reports')}
              className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline inline-flex items-center gap-1"
            >
              Staff Workload Report
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 dark:bg-slate-850 text-slate-500 font-semibold border-b border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="px-4 py-2.5">Staff Member</th>
                  <th className="px-4 py-2.5 text-center">Enquiries Assigned</th>
                  <th className="px-4 py-2.5 text-center">Admissions Converted</th>
                  <th className="px-4 py-2.5 text-center">Visitors Hosted</th>
                  <th className="px-4 py-2.5 text-center">Complaints Handled</th>
                  <th className="px-4 py-2.5 text-center">Total Volume</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-300">
                {analyticsData.staffWorkload.slice(0, 6).map(staff => (
                  <tr key={staff.staffId} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40">
                    <td className="px-4 py-2.5 font-bold text-slate-900 dark:text-white">
                      {staff.staffName}
                    </td>
                    <td className="px-4 py-2.5 text-center font-mono">{staff.enquiriesAssigned}</td>
                    <td className="px-4 py-2.5 text-center font-mono text-emerald-600 font-bold">
                      {staff.enquiriesConverted}
                    </td>
                    <td className="px-4 py-2.5 text-center font-mono">{staff.visitorsHosted}</td>
                    <td className="px-4 py-2.5 text-center font-mono">{staff.complaintsResolved}</td>
                    <td className="px-4 py-2.5 text-center font-mono font-bold text-indigo-600">
                      {(staff as any).totalVolume ?? staff.totalInteractions ?? 0}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
