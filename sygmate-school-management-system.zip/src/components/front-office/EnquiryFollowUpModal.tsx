import React, { useState } from 'react';
import { X, Save, Calendar, Clock, MessageSquare, Phone, Mail, User, CheckCircle2, AlertCircle, History, Send } from 'lucide-react';
import { api } from '../../services/api';
import { FrontOfficeEnquiry, EnquiryFollowUp, FollowUpContactMethod } from '../../types';

interface EnquiryFollowUpModalProps {
  enquiry: FrontOfficeEnquiry | null;
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (updatedEnquiry: FrontOfficeEnquiry) => void;
}

export const EnquiryFollowUpModal: React.FC<EnquiryFollowUpModalProps> = ({
  enquiry,
  isOpen,
  onClose,
  onSuccess
}) => {
  const today = new Date().toISOString().split('T')[0];
  const currentTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });

  const [followUpDate, setFollowUpDate] = useState(today);
  const [followUpTime, setFollowUpTime] = useState(currentTime);
  const [contactMethod, setContactMethod] = useState<FollowUpContactMethod>('Phone');
  const [contactOutcome, setContactOutcome] = useState('SPOKE_WITH_PARENT');
  const [nextStatus, setNextStatus] = useState<string>(enquiry?.status || 'CONTACTED');
  const [notes, setNotes] = useState('');
  const [sendReminder, setSendReminder] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen || !enquiry) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactOutcome) {
      setError('Please select contact outcome.');
      return;
    }

    try {
      setLoading(true);
      setError(null);
      const res = await api.frontOffice.addFollowUp(enquiry.id, {
        followUpDate,
        followUpTime,
        contactMethod,
        contactOutcome,
        nextStatus,
        notes,
        sendReminder
      });
      if (res.success && res.data) {
        onSuccess(res.data.enquiry);
        onClose();
      } else {
        setError(res.error || 'Failed to record follow-up.');
      }
    } catch (err: any) {
      setError(err.message || 'An error occurred.');
    } finally {
      setLoading(false);
    }
  };

  const pastFollowUps = enquiry.followUps || [];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-slate-800/40">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold">
              <Phone className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">Record Enquiry Follow-Up</h3>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Log conversation notes & advance prospect pipeline
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {error && (
          <div className="mx-6 mt-3 p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl flex items-center gap-2.5 text-xs text-rose-600 dark:text-rose-400">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Prospect Info Banner */}
        <div className="mx-6 mt-4 p-3 bg-slate-50 dark:bg-slate-850 rounded-xl border border-slate-200 dark:border-slate-800 text-xs flex items-center justify-between">
          <div>
            <span className="font-mono text-[10px] font-bold text-indigo-600 dark:text-indigo-400 block">
              {enquiry.enquiryNumber}
            </span>
            <p className="font-bold text-slate-900 dark:text-white">{enquiry.studentName}</p>
            <span className="text-slate-500 text-[11px]">Parent: {enquiry.parentName}</span>
          </div>
          <div className="text-right">
            <span className="font-mono text-slate-700 dark:text-slate-300 block text-[11px]">{enquiry.phone}</span>
            <span className="text-[10px] px-2 py-0.5 rounded-full font-semibold bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400">
              Current: {enquiry.status}
            </span>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-3.5 max-h-[72vh] overflow-y-auto">
          <div className="grid grid-cols-2 gap-3">
            {/* Follow-up Date */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Interaction Date
              </label>
              <input
                type="date"
                value={followUpDate}
                onChange={e => setFollowUpDate(e.target.value)}
                className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            {/* Follow-up Time */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Time
              </label>
              <input
                type="time"
                value={followUpTime}
                onChange={e => setFollowUpTime(e.target.value)}
                className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

          {/* Contact Method & Outcome */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Contact Channel
              </label>
              <select
                value={contactMethod}
                onChange={e => setContactMethod(e.target.value as FollowUpContactMethod)}
                className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="Phone">Phone Call</option>
                <option value="Email">Email Communication</option>
                <option value="In Person">In-Person Campus Visit</option>
                <option value="Website">Website / Portal Chat</option>
                <option value="Other">Other Channel</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Update Status
              </label>
              <select
                value={nextStatus}
                onChange={e => setNextStatus(e.target.value)}
                className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 font-semibold"
              >
                <option value="NEW">New Prospect</option>
                <option value="CONTACTED">Contacted</option>
                <option value="FOLLOW_UP_REQUIRED">Follow-up Required</option>
                <option value="FOLLOW_UP_IN_PROGRESS">Follow-up In Progress</option>
                <option value="INTERESTED">Interested / Warm Lead</option>
                <option value="APPLICATION_STARTED">Application Started</option>
                <option value="QUALIFIED">Qualified / Ready to Apply</option>
                <option value="CONVERTED">Converted to Admission</option>
                <option value="NOT_INTERESTED">Not Interested</option>
                <option value="LOST">Lost</option>
                <option value="CLOSED">Closed / Archived</option>
              </select>
            </div>
          </div>

          {/* Outcome */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Contact Outcome *
            </label>
            <select
              value={contactOutcome}
              onChange={e => setContactOutcome(e.target.value)}
              className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="SPOKE_WITH_PARENT">Spoke with Parent / Discussed Requirements</option>
              <option value="CALL_UNANSWERED">Call Unanswered / Left Voicemail</option>
              <option value="SCHEDULED_CAMPUS_VISIT">Scheduled Campus Tour & Assessment</option>
              <option value="BROCHURE_SENT">Sent Prospectus & Fee Brochure</option>
              <option value="FEE_QUERY_ANSWERED">Fee Structure & Scholarship Clarified</option>
              <option value="APPLICATION_LINK_SENT">Sent Direct Online Application Link</option>
              <option value="REQUESTED_CALLBACK">Parent Requested Callback at Later Date</option>
              <option value="NOT_INTERESTED">Not Interested / Chose Another School</option>
            </select>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Follow-Up Notes & Discussion Summary
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={e => setNotes(e.target.value)}
              placeholder="Record details of conversation, parent queries, or next scheduled touchpoint..."
              className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none"
            />
          </div>

          {/* Reminder Toggle */}
          <div className="flex items-center gap-2 text-xs pt-1">
            <input
              type="checkbox"
              id="sendReminder"
              checked={sendReminder}
              onChange={e => setSendReminder(e.target.checked)}
              className="rounded text-indigo-600 focus:ring-indigo-500"
            />
            <label htmlFor="sendReminder" className="text-slate-700 dark:text-slate-300 font-medium cursor-pointer">
              Send follow-up alert notification to assigned front-office team
            </label>
          </div>

          {/* Past History Accordion */}
          {pastFollowUps.length > 0 && (
            <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
              <span className="text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1.5 flex items-center gap-1">
                <History className="w-3.5 h-3.5 text-indigo-500" />
                Previous Interactions ({pastFollowUps.length})
              </span>
              <div className="space-y-1.5 max-h-24 overflow-y-auto">
                {pastFollowUps.map((fu, idx) => (
                  <div key={idx} className="p-1.5 rounded-lg bg-slate-50 dark:bg-slate-800/60 text-[10px] text-slate-600 dark:text-slate-400">
                    <div className="flex justify-between font-semibold text-slate-800 dark:text-slate-200">
                      <span>{fu.contactOutcome.replace(/_/g, ' ')}</span>
                      <span>{fu.followUpDate}</span>
                    </div>
                    {fu.notes && <p className="italic mt-0.5 truncate">"{fu.notes}"</p>}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Footer */}
          <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-1.5 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-4 py-1.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition shadow-sm inline-flex items-center gap-1.5 disabled:opacity-50"
            >
              <Save className="w-3.5 h-3.5" />
              {loading ? 'Recording...' : 'Save Follow-Up'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
