import React, { useState } from 'react';
import {
  X,
  Save,
  AlertCircle,
  CheckCircle2,
  Clock,
  User,
  Phone,
  Mail,
  Building,
  Tag,
  ShieldAlert,
  ArrowRight,
  MessageSquare,
  AlertTriangle,
  Flame,
  Star,
  CornerDownRight,
  FileText
} from 'lucide-react';
import { api } from '../../services/api';
import {
  ComplaintRecord,
  ComplaintStatus,
  ComplaintPriority,
  ComplaintSlaStatus,
  ComplaintResolutionCategory,
  EscalationLevel
} from '../../types';

interface ComplaintDetailModalProps {
  complaint: ComplaintRecord | null;
  isOpen: boolean;
  onClose: () => void;
  onUpdated: (complaint: ComplaintRecord) => void;
  staffList?: Array<{ id: string; name: string; department?: string }>;
}

export const ComplaintDetailModal: React.FC<ComplaintDetailModalProps> = ({
  complaint,
  isOpen,
  onClose,
  onUpdated,
  staffList = []
}) => {
  const [toStatus, setToStatus] = useState<ComplaintStatus>(complaint?.status || 'PENDING');
  const [remarks, setRemarks] = useState('');
  const [resolution, setResolution] = useState(complaint?.resolution || '');
  const [resolutionCategory, setResolutionCategory] = useState<ComplaintResolutionCategory>(
    complaint?.resolutionCategory || 'OTHER'
  );
  const [remedyActionTaken, setRemedyActionTaken] = useState(complaint?.remedyActionTaken || '');
  const [feedbackRating, setFeedbackRating] = useState<number>(complaint?.feedbackRating || 5);
  const [feedbackRemarks, setFeedbackRemarks] = useState(complaint?.feedbackRemarks || '');
  const [reopenReason, setReopenReason] = useState('');
  const [rejectionReason, setRejectionReason] = useState('');
  const [assignedStaffId, setAssignedStaffId] = useState(complaint?.assignedStaffId || '');

  // Escalation drawer state
  const [isEscalateOpen, setIsEscalateOpen] = useState(false);
  const [escalationLevel, setEscalationLevel] = useState<EscalationLevel>('LEVEL_1_HOD');
  const [escalationReason, setEscalationReason] = useState('');
  const [escalationDepartment, setEscalationDepartment] = useState(complaint?.assignedDepartment || 'Administration');
  const [escalationStaffId, setEscalationStaffId] = useState('');
  const [bumpPriority, setBumpPriority] = useState(true);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  if (!isOpen || !complaint) return null;

  const getPriorityBadge = (p: ComplaintPriority) => {
    switch (p) {
      case 'URGENT':
        return 'bg-rose-500/10 text-rose-600 dark:text-rose-400 border-rose-500/30';
      case 'HIGH':
        return 'bg-orange-500/10 text-orange-600 dark:text-orange-400 border-orange-500/30';
      case 'MEDIUM':
        return 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/30';
      default:
        return 'bg-slate-500/10 text-slate-600 dark:text-slate-400 border-slate-500/30';
    }
  };

  const getStatusBadge = (s: ComplaintStatus) => {
    switch (s) {
      case 'RESOLVED':
        return 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/30';
      case 'IN_PROGRESS':
        return 'bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/30';
      case 'ASSIGNED':
        return 'bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border-indigo-500/30';
      case 'ACKNOWLEDGED':
        return 'bg-teal-500/10 text-teal-600 dark:text-teal-400 border-teal-500/30';
      case 'CLOSED':
        return 'bg-slate-500/10 text-slate-600 dark:text-slate-400 border-slate-500/30';
      case 'REOPENED':
        return 'bg-purple-500/10 text-purple-600 dark:text-purple-400 border-purple-500/30';
      case 'REJECTED':
        return 'bg-rose-500/10 text-rose-600 dark:text-rose-400 border-rose-500/30';
      default:
        return 'bg-rose-500/10 text-rose-600 dark:text-rose-400 border-rose-500/30';
    }
  };

  const getSlaBadge = (sla?: ComplaintSlaStatus) => {
    switch (sla) {
      case 'BREACHED':
      case 'RESOLVED_BREACHED':
        return {
          bg: 'bg-rose-500/10 text-rose-600 dark:text-rose-400 border-rose-500/30',
          label: 'SLA BREACHED',
          icon: AlertTriangle
        };
      case 'AT_RISK':
        return {
          bg: 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/30',
          label: 'SLA AT RISK (≤8h)',
          icon: Clock
        };
      case 'RESOLVED_WITHIN_SLA':
        return {
          bg: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/30',
          label: 'RESOLVED ON TIME',
          icon: CheckCircle2
        };
      default:
        return {
          bg: 'bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/30',
          label: 'SLA ON TRACK',
          icon: Clock
        };
    }
  };

  const slaInfo = getSlaBadge(complaint.slaStatus);
  const SlaIcon = slaInfo.icon;

  const handleUpdateStatus = async (e: React.FormEvent) => {
    e.preventDefault();
    if (toStatus === 'RESOLVED' && !resolution.trim()) {
      setError('Official resolution findings are required to resolve this complaint.');
      return;
    }
    if (toStatus === 'REOPENED' && !reopenReason.trim()) {
      setError('Please provide a reason for reopening this ticket.');
      return;
    }
    if (toStatus === 'REJECTED' && !rejectionReason.trim()) {
      setError('Please provide a reason for rejecting this ticket.');
      return;
    }

    try {
      setLoading(true);
      setError(null);
      const res = await api.frontOffice.transitionComplaintStatus(complaint.id, {
        toStatus,
        remarks: remarks || `Status transitioned to ${toStatus}`,
        resolution: toStatus === 'RESOLVED' || toStatus === 'CLOSED' ? resolution : undefined,
        resolutionCategory: toStatus === 'RESOLVED' || toStatus === 'CLOSED' ? resolutionCategory : undefined,
        remedyActionTaken: toStatus === 'RESOLVED' || toStatus === 'CLOSED' ? remedyActionTaken : undefined,
        feedbackRating: toStatus === 'CLOSED' ? feedbackRating : undefined,
        feedbackRemarks: toStatus === 'CLOSED' ? feedbackRemarks : undefined,
        reopenReason: toStatus === 'REOPENED' ? reopenReason : undefined,
        rejectionReason: toStatus === 'REJECTED' ? rejectionReason : undefined,
        assignedStaffId: assignedStaffId || undefined
      });
      if (res.success && res.data) {
        setSuccessMessage('Ticket status successfully updated.');
        onUpdated(res.data);
      } else {
        setError(res.error || 'Failed to update complaint.');
      }
    } catch (err: any) {
      setError(err.message || 'Error updating complaint.');
    } finally {
      setLoading(false);
    }
  };

  const handleEscalate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!escalationReason.trim()) {
      setError('Escalation reason is mandatory.');
      return;
    }

    try {
      setLoading(true);
      setError(null);
      const res = await api.frontOffice.escalateComplaint(complaint.id, {
        escalationLevel,
        escalationReason,
        targetDepartment: escalationDepartment,
        targetStaffId: escalationStaffId || undefined,
        bumpPriority
      });
      if (res.success && res.data) {
        setSuccessMessage(`Complaint successfully escalated to ${escalationLevel.replace(/_/g, ' ')}!`);
        setIsEscalateOpen(false);
        onUpdated(res.data);
      } else {
        setError(res.error || 'Failed to escalate ticket.');
      }
    } catch (err: any) {
      setError(err.message || 'Error escalating ticket.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-2xl shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-slate-800/40">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-mono font-bold text-sm text-slate-900 dark:text-white">
                  {complaint.complaintNumber}
                </span>
                <span className={`px-2 py-0.5 text-[10px] font-bold rounded-full border ${getPriorityBadge(complaint.priority)}`}>
                  {complaint.priority}
                </span>
                <span className={`px-2 py-0.5 text-[10px] font-bold rounded-full border ${getStatusBadge(complaint.status)}`}>
                  {complaint.status.replace('_', ' ')}
                </span>
                {complaint.isEscalated && (
                  <span className="px-2 py-0.5 text-[10px] font-bold rounded-full bg-rose-600 text-white flex items-center gap-1 animate-pulse">
                    <Flame className="w-3 h-3" />
                    {complaint.escalationLevel?.replace(/_/g, ' ') || 'ESCALATED'}
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{complaint.subject}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {error && (
          <div className="mx-6 mt-4 p-3 bg-rose-500/10 border border-rose-500/30 rounded-2xl flex items-center gap-2.5 text-xs text-rose-600 dark:text-rose-400">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {successMessage && (
          <div className="mx-6 mt-4 p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-2xl flex items-center gap-2.5 text-xs text-emerald-600 dark:text-emerald-400">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{successMessage}</span>
          </div>
        )}

        <div className="p-6 space-y-4">
          {/* SLA Tracking Banner */}
          <div className={`p-3.5 rounded-2xl border flex items-center justify-between text-xs ${slaInfo.bg}`}>
            <div className="flex items-center gap-2.5">
              <SlaIcon className="w-4 h-4 shrink-0" />
              <div>
                <span className="font-bold uppercase tracking-wider block text-[11px]">{slaInfo.label}</span>
                <span className="text-[11px] opacity-90">
                  Target Resolution: {complaint.targetResolutionDate ? new Date(complaint.targetResolutionDate).toLocaleString() : 'Standard'}
                </span>
              </div>
            </div>
            <div className="text-right">
              {complaint.slaHoursRemaining !== undefined && (
                <span className="font-mono font-bold text-xs">
                  {complaint.slaHoursRemaining >= 0 ? `${complaint.slaHoursRemaining}h remaining` : `${Math.abs(complaint.slaHoursRemaining)}h overdue`}
                </span>
              )}
              <span className="block text-[10px] opacity-75">Priority Policy: {complaint.priority}</span>
            </div>
          </div>

          {/* Escalation details banner if escalated */}
          {complaint.isEscalated && (
            <div className="p-3.5 bg-rose-50/70 dark:bg-rose-950/20 border border-rose-200 dark:border-rose-900/40 rounded-2xl text-xs space-y-1">
              <div className="flex items-center justify-between text-rose-900 dark:text-rose-200 font-bold">
                <span className="flex items-center gap-1.5">
                  <Flame className="w-3.5 h-3.5 text-rose-600" />
                  Escalated to: {complaint.escalationLevel?.replace(/_/g, ' ')}
                </span>
                {complaint.escalatedAt && (
                  <span className="text-[10px] font-mono text-rose-600 dark:text-rose-400">
                    {new Date(complaint.escalatedAt).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })}
                  </span>
                )}
              </div>
              <p className="text-rose-800 dark:text-rose-300 text-[11px]">
                <strong>Reason:</strong> {complaint.escalationReason}
              </p>
              {complaint.escalatedByName && (
                <span className="text-[10px] text-rose-600/80 dark:text-rose-400/80 block">
                  Escalated by {complaint.escalatedByName}
                </span>
              )}
            </div>
          )}

          {/* Linked Originating Call if any */}
          {complaint.originatingCallNumber && (
            <div className="p-2.5 bg-blue-50/60 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-900/30 rounded-2xl flex items-center justify-between text-xs text-blue-800 dark:text-blue-300">
              <div className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-blue-600" />
                <span>
                  Converted from Front-Desk Telephone Call: <strong>{complaint.originatingCallNumber}</strong>
                </span>
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded-lg bg-blue-500/10 font-bold">
                Call Linked
              </span>
            </div>
          )}

          {/* Detail Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Complainant card */}
            <div className="p-3 bg-slate-50 dark:bg-slate-850 rounded-2xl border border-slate-200 dark:border-slate-800 text-xs space-y-1">
              <span className="text-[10px] font-bold uppercase text-slate-400 tracking-wider block">Complainant Info</span>
              <p className="font-bold text-slate-900 dark:text-white">{complaint.complainantName} ({complaint.complainantType})</p>
              <div className="flex items-center gap-1 font-mono text-slate-600 dark:text-slate-300">
                <Phone className="w-3 h-3 text-slate-400" />
                {complaint.phone}
              </div>
              {complaint.email && (
                <div className="flex items-center gap-1 text-slate-500">
                  <Mail className="w-3 h-3 text-slate-400" />
                  {complaint.email}
                </div>
              )}
            </div>

            {/* Department & Staff card */}
            <div className="p-3 bg-slate-50 dark:bg-slate-850 rounded-2xl border border-slate-200 dark:border-slate-800 text-xs space-y-1">
              <span className="text-[10px] font-bold uppercase text-slate-400 tracking-wider block">Assignment & Routing</span>
              <p className="font-bold text-slate-900 dark:text-white">{complaint.assignedDepartment || 'General Administration'}</p>
              <p className="text-slate-600 dark:text-slate-300">
                Assignee: <strong className="text-indigo-600 dark:text-indigo-400">{complaint.assignedStaffName || 'Unassigned'}</strong>
              </p>
              <span className="text-[10px] text-slate-400 block">
                Category: <strong>{complaint.category.replace('_', ' ')}</strong>
              </span>
            </div>
          </div>

          {/* Description */}
          <div className="p-3.5 bg-slate-50/70 dark:bg-slate-850/60 rounded-2xl border border-slate-200 dark:border-slate-800 text-xs space-y-1">
            <span className="text-[10px] font-bold uppercase text-slate-400 tracking-wider block">Incident Description</span>
            <p className="text-slate-800 dark:text-slate-200 leading-relaxed whitespace-pre-wrap">{complaint.description}</p>
            {complaint.immediateActionTaken && (
              <div className="pt-2 border-t border-slate-200 dark:border-slate-700 text-[11px] text-indigo-600 dark:text-indigo-400">
                <strong>Immediate Action:</strong> {complaint.immediateActionTaken}
              </div>
            )}
          </div>

          {/* If already resolved or closed, display resolution findings & feedback */}
          {(complaint.resolution || complaint.remedyActionTaken) && (
            <div className="p-3.5 bg-emerald-50/50 dark:bg-emerald-950/20 rounded-2xl border border-emerald-200 dark:border-emerald-900/40 text-xs space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="font-bold text-emerald-900 dark:text-emerald-200 text-xs flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  Resolution Remedy & Findings
                </span>
                {complaint.resolutionCategory && (
                  <span className="px-2 py-0.5 rounded-md bg-emerald-600 text-white text-[10px] font-bold">
                    {complaint.resolutionCategory.replace(/_/g, ' ')}
                  </span>
                )}
              </div>
              {complaint.remedyActionTaken && (
                <p className="text-emerald-800 dark:text-emerald-300 font-medium">
                  <strong>Remedy:</strong> {complaint.remedyActionTaken}
                </p>
              )}
              {complaint.resolution && (
                <p className="text-slate-700 dark:text-slate-300 whitespace-pre-wrap text-[11px]">
                  {complaint.resolution}
                </p>
              )}
              {complaint.feedbackRating && (
                <div className="pt-1.5 border-t border-emerald-200 dark:border-emerald-900/30 flex items-center gap-2 text-amber-600">
                  <div className="flex">
                    {[1, 2, 3, 4, 5].map(star => (
                      <Star
                        key={star}
                        className={`w-3.5 h-3.5 ${star <= (complaint.feedbackRating || 0) ? 'fill-amber-400 text-amber-400' : 'text-slate-300'}`}
                      />
                    ))}
                  </div>
                  <span className="text-[10px] text-slate-500 font-semibold">
                    Satisfaction: {complaint.feedbackRating} / 5
                    {complaint.feedbackRemarks ? ` - "${complaint.feedbackRemarks}"` : ''}
                  </span>
                </div>
              )}
            </div>
          )}

          {/* Resolution History Timeline */}
          {complaint.history && complaint.history.length > 0 && (
            <div className="space-y-2">
              <span className="text-xs font-bold text-slate-900 dark:text-white block">Audit & Status History</span>
              <div className="space-y-2 max-h-36 overflow-y-auto pr-1">
                {complaint.history.map((h, i) => (
                  <div key={i} className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-800 text-xs flex items-start gap-2.5">
                    <div className="w-5 h-5 rounded-full bg-indigo-500/10 text-indigo-600 flex items-center justify-center shrink-0 text-[10px] font-bold mt-0.5">
                      ✓
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <span className="font-semibold text-slate-800 dark:text-slate-200">
                          {h.fromStatus ? `${h.fromStatus} → ` : ''}{h.toStatus}
                        </span>
                        <span className="text-[10px] font-mono text-slate-400">
                          {new Date(h.changedAt).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-600 dark:text-slate-400 mt-0.5">{h.remarks}</p>
                      <span className="text-[10px] text-slate-400">By {h.changedByName}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Action Row: Escalate Toggle */}
          {complaint.status !== 'CLOSED' && complaint.status !== 'RESOLVED' && !isEscalateOpen && (
            <div className="flex items-center justify-between pt-1">
              <span className="text-xs text-slate-500">Unresolved roadblock or delay?</span>
              <button
                type="button"
                onClick={() => setIsEscalateOpen(true)}
                className="px-3 py-1 text-xs font-bold text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-xl border border-rose-300 dark:border-rose-800 transition inline-flex items-center gap-1.5"
              >
                <Flame className="w-3.5 h-3.5" />
                Escalate Ticket to Higher Authority
              </button>
            </div>
          )}

          {/* Escalation Form Drawer */}
          {isEscalateOpen && (
            <form onSubmit={handleEscalate} className="p-4 rounded-2xl bg-rose-50/50 dark:bg-rose-950/20 border border-rose-200 dark:border-rose-900/50 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-rose-950 dark:text-rose-200 flex items-center gap-1.5">
                  <Flame className="w-4 h-4 text-rose-600" />
                  Escalate Complaint to Leadership
                </span>
                <button
                  type="button"
                  onClick={() => setIsEscalateOpen(false)}
                  className="text-xs text-slate-400 hover:text-slate-600"
                >
                  Cancel
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Escalation Level *
                  </label>
                  <select
                    value={escalationLevel}
                    onChange={e => setEscalationLevel(e.target.value as EscalationLevel)}
                    className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-bold"
                  >
                    <option value="LEVEL_1_HOD">Level 1 - Head of Department</option>
                    <option value="LEVEL_2_VP">Level 2 - Vice Principal / Dean</option>
                    <option value="LEVEL_3_PRINCIPAL">Level 3 - Principal / Director</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Target Department
                  </label>
                  <select
                    value={escalationDepartment}
                    onChange={e => setEscalationDepartment(e.target.value)}
                    className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  >
                    <option value="Administration">Administration</option>
                    <option value="Maintenance">Maintenance & Estate</option>
                    <option value="Transport">Transport Division</option>
                    <option value="Academics">Academic Affairs</option>
                    <option value="Principal Office">Principal's Office</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Reason for Escalation *
                </label>
                <textarea
                  required
                  rows={2}
                  value={escalationReason}
                  onChange={e => setEscalationReason(e.target.value)}
                  placeholder="Explain why this requires senior leadership intervention or why SLA was endangered..."
                  className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div className="flex items-center justify-between pt-1">
                <label className="flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={bumpPriority}
                    onChange={e => setBumpPriority(e.target.checked)}
                    className="rounded text-rose-600 focus:ring-rose-500"
                  />
                  <span>Automatically bump priority to URGENT</span>
                </label>

                <button
                  type="submit"
                  disabled={loading}
                  className="px-4 py-1.5 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-xl transition shadow-sm inline-flex items-center gap-1.5"
                >
                  <Flame className="w-3.5 h-3.5" />
                  {loading ? 'Escalating...' : 'Confirm Escalation'}
                </button>
              </div>
            </form>
          )}

          {/* Transition / Update Form */}
          <form onSubmit={handleUpdateStatus} className="p-4 rounded-2xl bg-indigo-50/40 dark:bg-indigo-950/20 border border-indigo-200 dark:border-indigo-800/40 space-y-3">
            <span className="text-xs font-bold text-indigo-950 dark:text-indigo-200 block">Take Action on Complaint Ticket</span>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* To Status */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Change Status
                </label>
                <select
                  value={toStatus}
                  onChange={e => setToStatus(e.target.value as ComplaintStatus)}
                  className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 font-semibold"
                >
                  <option value="NEW">New</option>
                  <option value="ACKNOWLEDGED">Acknowledged</option>
                  <option value="ASSIGNED">Assigned</option>
                  <option value="IN_PROGRESS">In Progress</option>
                  <option value="RESOLVED">Resolved</option>
                  <option value="CLOSED">Closed</option>
                  <option value="REOPENED">Reopened</option>
                  <option value="REJECTED">Rejected</option>
                </select>
              </div>

              {/* Assign To */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Reassign Staff Member
                </label>
                <select
                  value={assignedStaffId}
                  onChange={e => setAssignedStaffId(e.target.value)}
                  className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="">Keep current assignee</option>
                  {staffList.map(st => (
                    <option key={st.id} value={st.id}>
                      {st.name} ({st.department || 'General'})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Resolution Fields when resolving or closing */}
            {(toStatus === 'RESOLVED' || toStatus === 'CLOSED') && (
              <div className="space-y-3 pt-2 border-t border-indigo-200/60 dark:border-indigo-800/40">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Resolution Category *
                    </label>
                    <select
                      value={resolutionCategory}
                      onChange={e => setResolutionCategory(e.target.value as ComplaintResolutionCategory)}
                      className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-medium"
                    >
                      <option value="REPAIRED_REPLACED">Repaired or Replaced</option>
                      <option value="POLICY_EXPLAINED">Policy / Procedure Clarified</option>
                      <option value="APOLOGY_ISSUED">Formal Apology Issued</option>
                      <option value="WAIVED_REFUNDED">Waived / Fee Refunded</option>
                      <option value="COUNSELED">Staff / Student Counseled</option>
                      <option value="PROCESS_IMPROVED">Process or Workflow Updated</option>
                      <option value="OTHER">Other Resolution</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Remedy Action Taken
                    </label>
                    <input
                      type="text"
                      value={remedyActionTaken}
                      onChange={e => setRemedyActionTaken(e.target.value)}
                      placeholder="e.g. Electrical board replaced and checked safe"
                      className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Official Resolution Findings *
                  </label>
                  <textarea
                    required
                    rows={2}
                    value={resolution}
                    onChange={e => setResolution(e.target.value)}
                    placeholder="Detail the root cause investigation, remedy applied, and confirmation of resolution..."
                    className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>
            )}

            {/* Satisfaction rating when closing */}
            {toStatus === 'CLOSED' && (
              <div className="p-3 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 space-y-2">
                <span className="text-[11px] font-bold text-slate-800 dark:text-slate-200 block">
                  Complainant Satisfaction Rating
                </span>
                <div className="flex items-center gap-2">
                  <div className="flex gap-1">
                    {[1, 2, 3, 4, 5].map(star => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setFeedbackRating(star)}
                        className="p-1 text-amber-400 hover:scale-110 transition"
                      >
                        <Star className={`w-5 h-5 ${star <= feedbackRating ? 'fill-amber-400' : 'text-slate-300'}`} />
                      </button>
                    ))}
                  </div>
                  <span className="text-xs font-bold text-slate-600 dark:text-slate-300 font-mono">
                    {feedbackRating} / 5 Stars
                  </span>
                </div>
                <input
                  type="text"
                  value={feedbackRemarks}
                  onChange={e => setFeedbackRemarks(e.target.value)}
                  placeholder="Complainant feedback remarks (e.g. Parent confirmed satisfied with prompt action)"
                  className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                />
              </div>
            )}

            {/* Reopen reason */}
            {toStatus === 'REOPENED' && (
              <div>
                <label className="block text-[11px] font-semibold text-purple-700 dark:text-purple-300 mb-1">
                  Reason for Reopening Ticket *
                </label>
                <input
                  type="text"
                  required
                  value={reopenReason}
                  onChange={e => setReopenReason(e.target.value)}
                  placeholder="e.g. Issue recurred, complainant reported problem persists"
                  className="w-full px-3 py-1.5 text-xs rounded-xl border border-purple-300 dark:border-purple-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>
            )}

            {/* Rejection reason */}
            {toStatus === 'REJECTED' && (
              <div>
                <label className="block text-[11px] font-semibold text-rose-700 dark:text-rose-300 mb-1">
                  Reason for Rejecting Grievance *
                </label>
                <input
                  type="text"
                  required
                  value={rejectionReason}
                  onChange={e => setRejectionReason(e.target.value)}
                  placeholder="e.g. Duplicate complaint ticket or outside institution jurisdiction"
                  className="w-full px-3 py-1.5 text-xs rounded-xl border border-rose-300 dark:border-rose-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>
            )}

            {/* Remarks */}
            <div>
              <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Action Remarks / Notes
              </label>
              <input
                type="text"
                value={remarks}
                onChange={e => setRemarks(e.target.value)}
                placeholder="e.g. Inspection conducted by electrician; work verified"
                className="w-full px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            {/* Submit */}
            <div className="flex justify-end pt-1">
              <button
                type="submit"
                disabled={loading}
                className="px-4 py-1.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition shadow-sm inline-flex items-center gap-1.5 disabled:opacity-50"
              >
                <Save className="w-3.5 h-3.5" />
                {loading ? 'Updating...' : 'Save Ticket Status'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
