import React, { useState, useEffect } from 'react';
import {
  GraduationCap,
  BookOpen,
  Users,
  Building,
  UserCheck,
  Mail,
  Phone,
  Calendar,
  ShieldCheck,
  Search,
  ExternalLink,
  ChevronRight,
  Sparkles,
  AlertCircle,
  RefreshCw,
  FileText,
  Clock
} from 'lucide-react';
import { api } from '../../services/api.js';
import { GuardianChildSummary, GuardianChildDossier } from '../../types/index.js';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner.js';
import { Badge } from '../../components/ui/Badge.js';
import { Button } from '../../components/ui/Button.js';
import { Modal } from '../../components/ui/Modal.js';
import { Input } from '../../components/ui/Input.js';

interface GuardianChildrenPageProps {
  onNavigate?: (view: string) => void;
}

export const GuardianChildrenPage: React.FC<GuardianChildrenPageProps> = ({ onNavigate }) => {
  const [children, setChildren] = useState<GuardianChildSummary[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Selected child for modal dossier
  const [selectedChildDossier, setSelectedChildDossier] = useState<GuardianChildDossier | null>(null);
  const [isLoadingDossier, setIsLoadingDossier] = useState<boolean>(false);
  const [isDossierModalOpen, setIsDossierModalOpen] = useState<boolean>(false);

  const fetchChildren = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await api.guardian.getChildren();
      if (res.success && res.data) {
        setChildren(Array.isArray(res.data) ? res.data : []);
      } else {
        setError(typeof res.error === 'string' ? res.error : 'Unable to retrieve linked scholar records.');
      }
    } catch (err: any) {
      setError(err?.message || 'Network error occurred.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchChildren();
  }, []);

  const handleOpenDossier = async (studentId: string) => {
    setIsLoadingDossier(true);
    setIsDossierModalOpen(true);
    try {
      const res = await api.guardian.getChildDossier(studentId);
      if (res.success && res.data) {
        setSelectedChildDossier(res.data);
      } else {
        setError(typeof res.error === 'string' ? res.error : 'Failed to load scholar dossier.');
      }
    } catch (err: any) {
      setError(err?.message || 'Network error.');
    } finally {
      setIsLoadingDossier(false);
    }
  };

  const filteredChildren = children.filter((child) => {
    const term = (searchQuery || '').toLowerCase();
    return (
      (child.name || '').toLowerCase().includes(term) ||
      (child.className || '').toLowerCase().includes(term) ||
      (child.admissionNumber || '').toLowerCase().includes(term) ||
      (child.rollNumber || '').toLowerCase().includes(term)
    );
  });

  if (isLoading) {
    return (
      <div className="p-8 flex items-center justify-center min-h-[400px]">
        <LoadingSpinner size="lg" message="Loading verified linked scholar profiles..." />
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      {/* Header & Context */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 rounded-full text-xs font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1.5">
              <GraduationCap className="w-3.5 h-3.5" />
              Verified Scholars
            </span>
            <span className="text-xs text-slate-400 font-mono">
              {children?.length || 0} Enrolled Student{(children?.length || 0) !== 1 ? 's' : ''}
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight mt-2">
            Linked Children &amp; Academic Placement
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-2xl">
            Access complete institutional records, enrolled curriculum subjects, and designated faculty leads for your scholars.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <Button onClick={fetchChildren} variant="secondary" className="text-xs">
            <RefreshCw className="w-3.5 h-3.5 mr-1.5" /> Refresh
          </Button>
        </div>
      </div>

      {/* Search & Filter Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-xl">
        <div className="relative w-full sm:max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by student name, admission no, or class..."
            className="w-full pl-10 pr-4 py-2.5 bg-slate-900/80 border border-white/10 rounded-xl text-xs text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-500"
          />
        </div>

        <div className="flex items-center gap-2 text-xs text-slate-400 font-medium w-full sm:w-auto justify-between sm:justify-start">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>Strict Access Isolation Active</span>
        </div>
      </div>

      {/* Children Grid */}
      {(filteredChildren?.length || 0) === 0 ? (
        <div className="p-12 text-center rounded-3xl bg-white/5 border border-white/10 space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-white/10 text-slate-400 flex items-center justify-center mx-auto">
            <Users className="w-6 h-6" />
          </div>
          <h3 className="text-base font-bold text-white">No Scholars Found</h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            No student profile matched your search query. Try searching with a different term.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {(filteredChildren || []).map((child) => (
            <div
              key={child.id}
              id={`child-dossier-card-${child.id}`}
              className="rounded-3xl bg-white/5 hover:bg-white/[0.07] border border-white/10 transition-all p-6 sm:p-7 backdrop-blur-xl space-y-6 flex flex-col justify-between group"
            >
              {/* Top Details & Avatar */}
              <div className="space-y-5">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 rounded-2xl bg-amber-600/30 border border-amber-400/40 text-amber-200 flex items-center justify-center font-black text-xl shadow-lg shadow-amber-600/20 overflow-hidden flex-shrink-0">
                      {child.avatarUrl ? (
                        <img src={child.avatarUrl} alt={child.name} className="w-full h-full object-cover" />
                      ) : (
                        child.name.slice(0, 2).toUpperCase()
                      )}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h2 className="text-lg font-bold text-white group-hover:text-amber-300 transition-colors">
                          {child.name}
                        </h2>
                        <Badge variant="success" size="sm">
                          {child.enrollmentStatus}
                        </Badge>
                      </div>
                      <p className="text-xs text-amber-200 font-semibold mt-0.5">
                        {child.className} — {child.sectionName}
                      </p>
                      <div className="flex items-center gap-3 text-[11px] text-slate-400 font-mono mt-1">
                        <span>Adm: {child.admissionNumber}</span>
                        <span>•</span>
                        <span>Roll: {child.rollNumber}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Academic Placement Breakdown Table */}
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 p-4 rounded-2xl bg-slate-900/60 border border-white/10 text-xs">
                  <div className="space-y-1">
                    <span className="text-slate-400 text-[11px]">Academic Session</span>
                    <p className="font-semibold text-white truncate">{child.academicSessionName}</p>
                  </div>
                  <div className="space-y-1">
                    <span className="text-slate-400 text-[11px]">Classroom</span>
                    <p className="font-semibold text-indigo-300">{child.roomNumber || 'Room 302'}</p>
                  </div>
                  <div className="space-y-1">
                    <span className="text-slate-400 text-[11px]">Curriculum</span>
                    <p className="font-semibold text-emerald-300">{child.totalSubjectsCount} Enrolled Subjects</p>
                  </div>
                </div>

                {/* Class Faculty Mentor Contact Card */}
                <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                      <UserCheck className="w-3.5 h-3.5 text-emerald-400" />
                      Class Teacher
                    </span>
                    <span className="font-semibold text-white">{child.classTeacherName}</span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-300 pt-1">
                    <div className="flex items-center gap-2 truncate font-mono text-[11px] text-slate-300">
                      <Mail className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                      <span className="truncate">{child.classTeacherEmail}</span>
                    </div>
                    <div className="flex items-center gap-2 font-mono text-[11px] text-slate-300">
                      <Phone className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                      <span>{child.classTeacherPhone}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-4 border-t border-white/10 flex flex-wrap items-center justify-between gap-2">
                <div className="text-[11px] text-slate-400">
                  Enrolled: <span className="text-slate-300 font-mono">{child.enrollmentDate || '2026-08-01'}</span>
                </div>
                <div className="flex items-center gap-2">
                  {onNavigate && (
                    <Button
                      id={`view-academic-overview-btn-${child.id}`}
                      onClick={() => onNavigate('guardian-academic-overview')}
                      variant="secondary"
                      className="text-xs"
                    >
                      <BookOpen className="w-3.5 h-3.5 mr-1" /> Academic Overview
                    </Button>
                  )}
                  <Button
                    id={`open-dossier-btn-${child.id}`}
                    onClick={() => handleOpenDossier(child.id)}
                    variant="primary"
                    className="text-xs bg-amber-600 hover:bg-amber-500 text-white border-amber-400/40"
                  >
                    <FileText className="w-3.5 h-3.5 mr-1.5" /> Quick Dossier
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Comprehensive Academic Dossier Modal */}
      <Modal
        isOpen={isDossierModalOpen}
        onClose={() => setIsDossierModalOpen(false)}
        title={selectedChildDossier ? `${selectedChildDossier.name} — Full Scholar Dossier` : 'Scholar Academic Dossier'}
        size="xl"
      >
        {isLoadingDossier ? (
          <div className="p-8 flex items-center justify-center">
            <LoadingSpinner size="md" message="Loading curriculum and faculty data..." />
          </div>
        ) : selectedChildDossier ? (
          <div className="space-y-6 text-slate-200">
            {/* Scholar Identity Summary Bar */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-2xl bg-amber-950/20 border border-amber-500/30">
              <div className="flex items-center gap-3.5">
                <div className="w-12 h-12 rounded-2xl bg-amber-600/40 border border-amber-400/50 text-amber-200 flex items-center justify-center font-bold text-base">
                  {selectedChildDossier.name.slice(0, 2).toUpperCase()}
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">{selectedChildDossier.name}</h3>
                  <p className="text-xs text-slate-300">
                    {selectedChildDossier.className} • {selectedChildDossier.sectionName} ({selectedChildDossier.roomNumber || 'Room 302'})
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2 text-xs font-mono">
                <Badge variant="primary" size="sm">
                  {selectedChildDossier.academicSessionName}
                </Badge>
                <Badge variant="success" size="sm">
                  {selectedChildDossier.enrollmentStatus}
                </Badge>
              </div>
            </div>

            {/* Enrolled Subjects & Faculty Allocation */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                  <BookOpen className="w-4 h-4 text-indigo-400" />
                  Curriculum Courses &amp; Instructors ({selectedChildDossier?.enrolledSubjects?.length || 0})
                </h4>
              </div>

              <div className="rounded-2xl border border-white/10 overflow-hidden">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-900/80 border-b border-white/10 text-slate-400 font-bold uppercase tracking-wider">
                    <tr>
                      <th className="p-3">Course Code</th>
                      <th className="p-3">Subject Name</th>
                      <th className="p-3">Type</th>
                      <th className="p-3">Credits</th>
                      <th className="p-3">Assigned Faculty</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5 bg-slate-950/40">
                    {(selectedChildDossier.enrolledSubjects || []).map((subj) => (
                      <tr key={subj.id} className="hover:bg-white/5 transition-colors">
                        <td className="p-3 font-mono font-bold text-indigo-300">{subj.code}</td>
                        <td className="p-3 font-semibold text-white">{subj.name}</td>
                        <td className="p-3">
                          <span className="capitalize px-2 py-0.5 rounded-md bg-white/10 text-slate-300 font-mono text-[10px]">
                            {subj.type}
                          </span>
                        </td>
                        <td className="p-3 font-mono text-slate-300">{subj.creditHours || 3} Hrs/Wk</td>
                        <td className="p-3 font-medium text-slate-200">{subj.teacherName}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Official Bio & Records Verification */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2 text-xs">
                <h5 className="font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  Institutional Records
                </h5>
                <div className="space-y-1.5 text-slate-300">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Admission No:</span>
                    <span className="font-mono text-white">{selectedChildDossier.admissionNumber}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Class Roll No:</span>
                    <span className="font-mono text-white">{selectedChildDossier.rollNumber}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Date of Birth:</span>
                    <span className="text-white">{selectedChildDossier.dateOfBirth}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Blood Group:</span>
                    <span className="text-white">{selectedChildDossier.bloodGroup || 'O+'}</span>
                  </div>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2 text-xs">
                <h5 className="font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Building className="w-3.5 h-3.5 text-indigo-400" />
                  Faculty &amp; In-Charge Contact
                </h5>
                <div className="space-y-1.5 text-slate-300">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Lead Teacher:</span>
                    <span className="font-semibold text-white">{selectedChildDossier.classTeacherName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Email:</span>
                    <span className="font-mono text-indigo-300">{selectedChildDossier.classTeacherEmail}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Phone:</span>
                    <span className="font-mono text-white">{selectedChildDossier.classTeacherPhone}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Term Window:</span>
                    <span className="text-white">Fall Semester 2026</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <Button onClick={() => setIsDossierModalOpen(false)} variant="secondary" className="text-xs">
                Close Dossier
              </Button>
            </div>
          </div>
        ) : (
          <div className="p-6 text-center text-slate-400 text-xs">
            Dossier details could not be loaded.
          </div>
        )}
      </Modal>
    </div>
  );
};
