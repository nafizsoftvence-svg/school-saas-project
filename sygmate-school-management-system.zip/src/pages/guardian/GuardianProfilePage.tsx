import React, { useState, useEffect } from 'react';
import {
  User,
  Phone,
  Mail,
  MapPin,
  Briefcase,
  ShieldCheck,
  Save,
  RefreshCw,
  HeartHandshake,
  GraduationCap,
  Sparkles,
  AlertCircle,
  Clock,
  UserCheck,
  Home,
  Users,
  KeyRound,
  Lock,
  Eye,
  EyeOff,
  CheckCircle2,
  Shield,
  FileText
} from 'lucide-react';
import { api } from '../../services/api.js';
import { Guardian, GuardianChildSummary, GuardianProfileUpdatePayload } from '../../types/index.js';
import { useAuth } from '../../context/AuthContext.js';
import { useToast } from '../../context/ToastContext.js';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner.js';
import { Badge } from '../../components/ui/Badge.js';
import { Button } from '../../components/ui/Button.js';
import { Input } from '../../components/ui/Input.js';
import { EntityDocumentChecklistModal } from '../../components/documents/EntityDocumentChecklistModal.js';

export const GuardianProfilePage: React.FC = () => {
  const { user } = useAuth();
  const [profile, setProfile] = useState<any | null>(null);
  const [children, setChildren] = useState<GuardianChildSummary[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const { addToast } = useToast();

  // Part 15E — Document Checklist State
  const [docChecklistTarget, setDocChecklistTarget] = useState<{
    entityType: 'GUARDIAN' | 'STUDENT';
    entityId: string;
    entityName: string;
  } | null>(null);

  // Form State for Contact Updates
  const [formState, setFormState] = useState<{
    name: string;
    phone: string;
    secondaryPhone: string;
    whatsapp: string;
    email: string;
    address: string;
    permanentAddress: string;
    occupation: string;
    emergencyContact: string;
  }>({
    name: '',
    phone: '',
    secondaryPhone: '',
    whatsapp: '',
    email: '',
    address: '',
    permanentAddress: '',
    occupation: '',
    emergencyContact: ''
  });

  // Password Change Form State
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isChangingPassword, setIsChangingPassword] = useState(false);
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);

  const fetchProfileData = async () => {
    setIsLoading(true);
    try {
      const [profileRes, childrenRes] = await Promise.all([
        api.guardian.getProfile(),
        api.guardian.getChildren()
      ]);

      if (profileRes.success && profileRes.data) {
        const p = profileRes.data;
        setProfile(p);
        setFormState({
          name: p.name || '',
          phone: p.phone || '',
          secondaryPhone: p.secondaryPhone || '',
          whatsapp: p.whatsapp || '',
          email: p.email || '',
          address: p.address || '',
          permanentAddress: p.permanentAddress || '',
          occupation: p.occupation || '',
          emergencyContact: p.emergencyContact || ''
        });
      }

      if (childrenRes.success && childrenRes.data) {
        setChildren(childrenRes.data);
      }
    } catch (err: any) {
      addToast('Failed to load profile details.', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchProfileData();
  }, []);

  const handleFormChange = (field: string, value: string) => {
    setFormState((prev) => ({ ...prev, [field]: value }));
  };

  const handleSaveContact = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    try {
      const payload: any = {
        name: formState.name,
        phone: formState.phone,
        secondaryPhone: formState.secondaryPhone,
        whatsapp: formState.whatsapp,
        email: formState.email,
        address: formState.address,
        permanentAddress: formState.permanentAddress,
        occupation: formState.occupation,
        emergencyContact: formState.emergencyContact
      };

      const res = await api.guardian.updateProfile(payload);
      if (res.success && res.data) {
        setProfile(res.data);
        addToast('Your contact details have been successfully updated.', 'success');
      } else {
        addToast(typeof res.error === 'string' ? res.error : 'Failed to update contact info.', 'error');
      }
    } catch (err: any) {
      addToast(err?.message || 'Failed to update profile.', 'error');
    } finally {
      setIsSaving(false);
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentPassword || !newPassword || !confirmPassword) {
      addToast('All password fields are required.', 'error');
      return;
    }
    if (newPassword !== confirmPassword) {
      addToast('New passwords do not match.', 'error');
      return;
    }
    if (newPassword.length < 8) {
      addToast('Password must be at least 8 characters long.', 'error');
      return;
    }

    setIsChangingPassword(true);
    try {
      const res = await api.auth.changePassword({
        currentPassword,
        newPassword,
        confirmPassword
      });

      if (res.success) {
        addToast('Your password has been changed successfully. Account credentials updated.', 'success');
        setCurrentPassword('');
        setNewPassword('');
        setConfirmPassword('');
      } else {
        addToast(res.error || 'Failed to change password. Please verify your current password.', 'error');
      }
    } catch (err: any) {
      addToast(err?.message || 'Network error updating password.', 'error');
    } finally {
      setIsChangingPassword(false);
    }
  };

  // Password Complexity Calculations
  const hasMinLength = newPassword.length >= 8;
  const hasUpper = /[A-Z]/.test(newPassword);
  const hasLower = /[a-z]/.test(newPassword);
  const hasNumber = /[0-9]/.test(newPassword);
  const hasSpecial = /[^A-Za-z0-9]/.test(newPassword);
  const passwordsMatch = newPassword.length > 0 && newPassword === confirmPassword;
  const passedCriteriaCount = [hasMinLength, hasUpper, hasLower, hasNumber, hasSpecial].filter(Boolean).length;

  if (isLoading) {
    return (
      <div className="p-8 flex items-center justify-center min-h-[400px]">
        <LoadingSpinner size="lg" message="Loading guardian profile and bio records..." />
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="p-8 text-center text-slate-400">
        <p>Guardian profile record not found.</p>
        <Button onClick={fetchProfileData} variant="secondary" className="mt-4">
          <RefreshCw className="w-4 h-4 mr-2" /> Try Again
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-in fade-in duration-200 max-w-6xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 rounded-full text-xs font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1.5">
              <HeartHandshake className="w-3.5 h-3.5" />
              Verified Parent / Guardian Record
            </span>
            <span className="text-xs text-slate-400 font-mono">
              Status: Active
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight mt-2">
            Parent &amp; Guardian Profile
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-2xl">
            Maintain your official communication channels, emergency dispatch numbers, and verify linked scholar relationships.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <Button onClick={fetchProfileData} variant="secondary" className="text-xs">
            <RefreshCw className="w-3.5 h-3.5 mr-1.5" /> Refresh
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Official Guardian ID Badge & Overview */}
        <div className="space-y-6">
          <div className="rounded-3xl bg-white/5 border border-white/10 p-6 backdrop-blur-xl space-y-6 text-center">
            <div className="relative mx-auto w-24 h-24 rounded-3xl bg-amber-600/30 border-2 border-amber-400/40 text-amber-200 flex items-center justify-center font-black text-3xl shadow-xl shadow-amber-600/20 overflow-hidden">
              {profile.avatarUrl ? (
                <img src={profile.avatarUrl} alt={profile.name} className="w-full h-full object-cover" />
              ) : (
                profile.name.slice(0, 2).toUpperCase()
              )}
            </div>

            <div className="space-y-1">
              <h2 className="text-xl font-bold text-white tracking-tight">{profile.name}</h2>
              <p className="text-xs text-amber-300 font-semibold">{profile.relationship || 'Guardian'} of Record</p>
              <p className="text-xs text-slate-400">{profile.occupation || 'Professional'}</p>
            </div>

            <div className="pt-4 border-t border-white/10 space-y-2.5 text-left text-xs">
              <div className="flex items-center gap-2.5 text-slate-300">
                <Mail className="w-4 h-4 text-amber-400 flex-shrink-0" />
                <span className="truncate font-mono">{profile.email}</span>
              </div>
              <div className="flex items-center gap-2.5 text-slate-300">
                <Phone className="w-4 h-4 text-amber-400 flex-shrink-0" />
                <span className="font-mono">{profile.phone}</span>
              </div>
              <div className="flex items-center gap-2.5 text-slate-300">
                <MapPin className="w-4 h-4 text-amber-400 flex-shrink-0" />
                <span className="truncate">{profile.address || 'Address on file'}</span>
              </div>
            </div>

            <div className="pt-3 border-t border-white/10">
              <Button
                type="button"
                size="xs"
                variant="primary"
                className="w-full bg-amber-600 hover:bg-amber-500 text-white font-semibold flex items-center justify-center gap-1.5 shadow"
                onClick={() => setDocChecklistTarget({
                  entityType: 'GUARDIAN',
                  entityId: profile.id,
                  entityName: profile.name
                })}
              >
                <FileText className="w-3.5 h-3.5" />
                My Verification Documents
              </Button>
            </div>
          </div>

          {/* Family Household Information */}
          {profile.family && (
            <div className="rounded-3xl bg-white/5 border border-white/10 p-6 backdrop-blur-xl space-y-3">
              <div className="flex items-center gap-2 text-xs font-bold text-indigo-300 uppercase tracking-wider">
                <Home className="w-4 h-4 text-indigo-400" />
                <span>Family Household Unit</span>
              </div>
              <div>
                <div className="text-sm font-bold text-white">{profile.family.familyName}</div>
                <div className="text-[11px] text-slate-400 mt-0.5">
                  Code: <span className="font-mono text-slate-300">{profile.family.familyCode || 'N/A'}</span>
                </div>
                {profile.family.address && (
                  <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-slate-500 shrink-0" />
                    <span>{profile.family.address}</span>
                  </div>
                )}
              </div>

              {((profile?.coGuardians?.length || 0) > 0) && (
                <div className="pt-2 border-t border-white/5 space-y-1.5">
                  <div className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                    Household Co-Parents / Guardians:
                  </div>
                  {(profile?.coGuardians || []).map((cg: any) => (
                    <div key={cg.id} className="p-2 rounded-xl bg-white/5 text-xs flex items-center justify-between">
                      <div>
                        <div className="font-semibold text-white">{cg.name}</div>
                        <div className="text-[10px] text-slate-400">{cg.relationship} • {cg.phone}</div>
                      </div>
                      <Badge variant="secondary" size="sm">{cg.relationship}</Badge>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Linked Scholars Mini List */}
          <div className="rounded-3xl bg-white/5 border border-white/10 p-6 backdrop-blur-xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                <GraduationCap className="w-4 h-4 text-amber-400" />
                Linked Children ({children?.length || 0})
              </h3>
            </div>

            <div className="space-y-3">
              {(children || []).map((child) => {
                const rel = (profile.relationships || []).find((r: any) => r.studentId === child.id);
                return (
                  <div
                    key={child.id}
                    className="p-3 rounded-2xl bg-white/5 border border-white/5 space-y-2"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-300 flex items-center justify-center font-bold text-xs">
                        {child.name.slice(0, 2).toUpperCase()}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-bold text-white truncate">{child.name}</p>
                        <p className="text-[11px] text-slate-400 truncate">
                          {child.className} • {child.sectionName}
                        </p>
                      </div>
                    </div>

                    {/* Permissions summary */}
                    <div className="flex flex-wrap gap-1 pt-1 border-t border-white/5">
                      {rel?.isPrimaryGuardian && (
                        <span className="px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 text-[10px] font-bold">
                          Primary Guardian
                        </span>
                      )}
                      {rel?.isAuthorizedAcademic !== false && (
                        <span className="px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-300 text-[10px]">
                          Academic Access
                        </span>
                      )}
                      {rel?.isAuthorizedAttendance !== false && (
                        <span className="px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300 text-[10px]">
                          Attendance Alerts
                        </span>
                      )}
                      {rel?.isAuthorizedFinancial !== false && (
                        <span className="px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-300 text-[10px]">
                          Fee Invoices
                        </span>
                      )}
                    </div>

                    <div className="flex items-center justify-between pt-1 border-t border-white/5">
                      <span className="text-[10px] text-slate-400">Academic Records</span>
                      <Button
                        type="button"
                        size="xs"
                        variant="outline"
                        className="text-[10px] py-0.5 px-2 h-auto text-amber-300 border-amber-500/30 hover:bg-amber-500/10 flex items-center gap-1"
                        onClick={() => setDocChecklistTarget({
                          entityType: 'STUDENT',
                          entityId: child.id,
                          entityName: child.name
                        })}
                      >
                        <FileText className="w-3 h-3" />
                        Child Documents
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Security & Access Protection Card */}
          <div className="rounded-3xl bg-gradient-to-br from-amber-950/20 to-slate-900 border border-white/10 p-5 backdrop-blur-xl space-y-2">
            <div className="flex items-center gap-2 text-xs font-bold text-amber-300">
              <ShieldCheck className="w-4 h-4" />
              Institutional Privacy Protection
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Your account access is cryptographically restricted to your verified children. Academic grades and sensitive notes are strictly isolated.
            </p>
          </div>
        </div>

        {/* Right Column: Contact Details Edit Form */}
        <div className="lg:col-span-2 space-y-6">
          <form
            onSubmit={handleSaveContact}
            className="rounded-3xl bg-white/5 border border-white/10 p-6 sm:p-8 backdrop-blur-xl space-y-6"
          >
            <div className="flex items-center justify-between pb-4 border-b border-white/10">
              <div>
                <h3 className="text-lg font-bold text-white tracking-tight">
                  Update Official Contact Information
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Keep your phone and residential coordinates synchronized for administrative dispatches.
                </p>
              </div>
              <Badge variant="primary" size="sm">
                Self-Service Contact
              </Badge>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">Full Name</label>
                <input
                  type="text"
                  value={formState.name}
                  onChange={(e) => handleFormChange('name', e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900/80 border border-white/10 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-amber-500"
                  required
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">Primary Phone Number</label>
                <input
                  type="tel"
                  value={formState.phone}
                  onChange={(e) => handleFormChange('phone', e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900/80 border border-white/10 text-xs text-white placeholder-slate-500 font-mono focus:outline-none focus:ring-2 focus:ring-amber-500"
                  required
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">Secondary / Alternate Phone</label>
                <input
                  type="tel"
                  value={formState.secondaryPhone}
                  onChange={(e) => handleFormChange('secondaryPhone', e.target.value)}
                  placeholder="e.g. +1 (555) 019-9922"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900/80 border border-white/10 text-xs text-white placeholder-slate-500 font-mono focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">WhatsApp Dispatch Number</label>
                <input
                  type="tel"
                  value={formState.whatsapp}
                  onChange={(e) => handleFormChange('whatsapp', e.target.value)}
                  placeholder="e.g. +1 (555) 019-9933"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900/80 border border-white/10 text-xs text-white placeholder-slate-500 font-mono focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">Email Address</label>
                <input
                  type="email"
                  value={formState.email}
                  onChange={(e) => handleFormChange('email', e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900/80 border border-white/10 text-xs text-white placeholder-slate-500 font-mono focus:outline-none focus:ring-2 focus:ring-amber-500"
                  required
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">Occupation / Profession</label>
                <input
                  type="text"
                  value={formState.occupation}
                  onChange={(e) => handleFormChange('occupation', e.target.value)}
                  placeholder="e.g. Senior Software Architect"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900/80 border border-white/10 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <div className="sm:col-span-2 space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">Residential Address</label>
                <input
                  type="text"
                  value={formState.address}
                  onChange={(e) => handleFormChange('address', e.target.value)}
                  placeholder="e.g. 742 Evergreen Terrace, Springfield"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900/80 border border-white/10 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <div className="sm:col-span-2 space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">Permanent Address (if different)</label>
                <input
                  type="text"
                  value={formState.permanentAddress}
                  onChange={(e) => handleFormChange('permanentAddress', e.target.value)}
                  placeholder="Permanent residential address"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900/80 border border-white/10 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <div className="sm:col-span-2 space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">Emergency Alternate Contact</label>
                <input
                  type="text"
                  value={formState.emergencyContact}
                  onChange={(e) => handleFormChange('emergencyContact', e.target.value)}
                  placeholder="e.g. Elena Rivera (Grandmother) - +1 (555) 019-9988"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900/80 border border-white/10 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>
            </div>

            <div className="pt-4 border-t border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-2 text-[11px] text-slate-400 font-mono">
                <Clock className="w-3 h-3" />
                <span>Last updated: {new Date(profile.updatedAt || Date.now()).toLocaleDateString()}</span>
              </div>

              <Button
                type="submit"
                variant="primary"
                className="text-xs bg-amber-600 hover:bg-amber-500 text-white border-amber-400/40"
                isLoading={isSaving}
              >
                <Save className="w-3.5 h-3.5 mr-1.5" /> Save Contact Details
              </Button>
            </div>
          </form>
        </div>

        {/* Account Credentials & Security Governance Section */}
        <div className="p-6 sm:p-8 rounded-3xl bg-white/5 border border-white/10 backdrop-blur-xl space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-5">
            <div>
              <div className="flex items-center gap-2">
                <span className="p-2 rounded-xl bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  <KeyRound className="w-4 h-4" />
                </span>
                <h2 className="text-lg font-bold text-white">Account Security &amp; Credentials</h2>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                Manage your Parent Portal authentication credentials and view account isolation status.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <span className="px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5" />
                Account Protected
              </span>
            </div>
          </div>

          {/* Account Overview Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-4 rounded-2xl bg-slate-900/60 border border-white/10">
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Username</span>
              <div className="text-sm font-bold text-white mt-0.5 font-mono">
                {user?.username || profile.email?.split('@')[0] || 'parent.user'}
              </div>
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Role &amp; Realm</span>
              <div className="text-sm font-bold text-indigo-300 mt-0.5">
                Guardian / Parent Portal
              </div>
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Account Status</span>
              <div className="text-sm font-bold text-emerald-400 mt-0.5 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                Active &amp; Verified
              </div>
            </div>
          </div>

          {/* Change Password Form */}
          <form onSubmit={handleChangePassword} className="space-y-4 pt-2">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Lock className="w-4 h-4 text-amber-400" />
              Change Account Password
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">Current Password</label>
                <div className="relative">
                  <input
                    type={showCurrentPassword ? 'text' : 'password'}
                    value={currentPassword}
                    onChange={(e) => setCurrentPassword(e.target.value)}
                    placeholder="Enter current password"
                    className="w-full px-3.5 py-2.5 pr-10 rounded-xl bg-slate-900/80 border border-white/10 text-xs text-white placeholder-slate-500 font-mono focus:outline-none focus:ring-2 focus:ring-amber-500"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowCurrentPassword((prev) => !prev)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                  >
                    {showCurrentPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">New Password</label>
                <div className="relative">
                  <input
                    type={showNewPassword ? 'text' : 'password'}
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="Min 8 chars, mixed case &amp; numbers"
                    className="w-full px-3.5 py-2.5 pr-10 rounded-xl bg-slate-900/80 border border-white/10 text-xs text-white placeholder-slate-500 font-mono focus:outline-none focus:ring-2 focus:ring-amber-500"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowNewPassword((prev) => !prev)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                  >
                    {showNewPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">Confirm New Password</label>
                <input
                  type={showNewPassword ? 'text' : 'password'}
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Repeat new password"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900/80 border border-white/10 text-xs text-white placeholder-slate-500 font-mono focus:outline-none focus:ring-2 focus:ring-amber-500"
                  required
                />
              </div>
            </div>

            {/* Password Strength Checklist */}
            {newPassword.length > 0 && (
              <div className="p-3.5 rounded-xl bg-slate-900/60 border border-white/10 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400 font-medium">Password Policy:</span>
                  <span
                    className={`font-semibold ${
                      passedCriteriaCount >= 4
                        ? 'text-emerald-400'
                        : passedCriteriaCount >= 3
                        ? 'text-amber-400'
                        : 'text-rose-400'
                    }`}
                  >
                    {passedCriteriaCount === 5
                      ? 'Strong Password'
                      : passedCriteriaCount >= 4
                      ? 'Good'
                      : passedCriteriaCount >= 3
                      ? 'Fair'
                      : 'Weak'}
                  </span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px]">
                  <span className={`flex items-center gap-1.5 ${hasMinLength ? 'text-emerald-400' : 'text-slate-500'}`}>
                    <CheckCircle2 className="w-3.5 h-3.5" /> 8+ Characters
                  </span>
                  <span className={`flex items-center gap-1.5 ${hasUpper && hasLower ? 'text-emerald-400' : 'text-slate-500'}`}>
                    <CheckCircle2 className="w-3.5 h-3.5" /> Uppercase &amp; Lowercase
                  </span>
                  <span className={`flex items-center gap-1.5 ${hasNumber ? 'text-emerald-400' : 'text-slate-500'}`}>
                    <CheckCircle2 className="w-3.5 h-3.5" /> Number (0-9)
                  </span>
                  <span className={`flex items-center gap-1.5 ${hasSpecial ? 'text-emerald-400' : 'text-slate-500'}`}>
                    <CheckCircle2 className="w-3.5 h-3.5" /> Symbol (!@#$)
                  </span>
                </div>
                {confirmPassword.length > 0 && !passwordsMatch && (
                  <div className="text-rose-400 text-xs font-semibold pt-1">
                    ⚠ Passwords do not match
                  </div>
                )}
              </div>
            )}

            <div className="pt-2 flex justify-end">
              <Button
                type="submit"
                variant="primary"
                className="text-xs bg-indigo-600 hover:bg-indigo-500 text-white border-indigo-400/40"
                isLoading={isChangingPassword}
                disabled={!currentPassword || !newPassword || !confirmPassword || !passwordsMatch || !hasMinLength}
              >
                <KeyRound className="w-3.5 h-3.5 mr-1.5" /> Update Account Password
              </Button>
            </div>
          </form>
        </div>
      </div>

      {/* Part 15E — Guardian & Student Document Checklist Modal */}
      {docChecklistTarget && (
        <EntityDocumentChecklistModal
          entityType={docChecklistTarget.entityType}
          entityId={docChecklistTarget.entityId}
          entityName={docChecklistTarget.entityName}
          isOpen={!!docChecklistTarget}
          onClose={() => setDocChecklistTarget(null)}
          canVerify={false}
        />
      )}
    </div>
  );
};
