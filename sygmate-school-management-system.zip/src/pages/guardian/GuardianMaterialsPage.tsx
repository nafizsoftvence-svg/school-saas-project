import React, { useState, useEffect } from 'react';
import {
  FolderOpen,
  FileText,
  Calendar,
  Filter,
  Search,
  ChevronRight,
  Info,
  Download,
  GraduationCap,
  Sparkles,
  ArrowRight,
  Check,
  X,
  AlertCircle,
  UserCheck,
  Building,
  Layers,
  ArrowLeft,
  RotateCcw,
  RefreshCw,
  FileCode,
  FileArchive,
  Film,
  Image,
  BookOpen
} from 'lucide-react';
import { api } from '../../services/api.js';
import {
  GuardianChildSummary,
  StudyMaterial,
  GuardianChildMaterialResponse
} from '../../types/index.js';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner.js';
import { Badge } from '../../components/ui/Badge.js';
import { Button } from '../../components/ui/Button.js';
import { Modal } from '../../components/ui/Modal.js';

interface GuardianMaterialsPageProps {
  onNavigate?: (view: string) => void;
  initialStudentId?: string;
}

export const GuardianMaterialsPage: React.FC<GuardianMaterialsPageProps> = ({
  onNavigate,
  initialStudentId
}) => {
  const [children, setChildren] = useState<GuardianChildSummary[]>([]);
  const [selectedChildId, setSelectedChildId] = useState<string | null>(initialStudentId || null);

  const [materialData, setMaterialData] = useState<GuardianChildMaterialResponse | null>(null);
  const [isLoadingChildren, setIsLoadingChildren] = useState<boolean>(true);
  const [isLoadingMaterials, setIsLoadingMaterials] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [authError, setAuthError] = useState<string | null>(null);

  // Filters
  const [subjectFilter, setSubjectFilter] = useState<string>('ALL');
  const [fileTypeFilter, setFileTypeFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Selected Material for Modal
  const [selectedMaterial, setSelectedMaterial] = useState<StudyMaterial | null>(null);

  useEffect(() => {
    const fetchChildren = async () => {
      setIsLoadingChildren(true);
      setAuthError(null);
      try {
        const res = await api.guardian.getChildren();
        const childrenList = Array.isArray(res?.data) ? res.data : Array.isArray(res) ? res : [];
        if (res?.success) {
          setChildren(childrenList);
          if (!selectedChildId && childrenList.length > 0) {
            setSelectedChildId(childrenList?.[0]?.id || null);
          } else if (selectedChildId) {
            const exists = childrenList.some((c: any) => c?.id === selectedChildId);
            if (!exists && childrenList.length > 0) {
              setSelectedChildId(childrenList?.[0]?.id || null);
            }
          }
        } else {
          setAuthError(typeof res.error === 'string' ? res.error : 'Failed to load children.');
        }
      } catch (err: any) {
        setAuthError(err?.message || 'Network error.');
      } finally {
        setIsLoadingChildren(false);
      }
    };

    fetchChildren();
  }, []);

  const fetchMaterials = async () => {
    if (!selectedChildId) return;

    setIsLoadingMaterials(true);
    setError(null);
    try {
      const res = await api.guardian.getChildStudyMaterials(selectedChildId, {
        subjectId: subjectFilter,
        fileType: fileTypeFilter,
        search: searchQuery
      });

      if (res.success && res.data) {
        setMaterialData(res.data);
      } else {
        if (res.code === 'FORBIDDEN_STUDENT_ACCESS') {
          setAuthError(typeof res.error === 'string' ? res.error : 'Access restricted.');
        } else {
          setError(typeof res.error === 'string' ? res.error : 'Failed to load study materials.');
        }
      }
    } catch (err: any) {
      setError(err?.message || 'Network error fetching materials.');
    } finally {
      setIsLoadingMaterials(false);
    }
  };

  useEffect(() => {
    if (selectedChildId) {
      fetchMaterials();
    }
  }, [selectedChildId, subjectFilter, fileTypeFilter]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchMaterials();
  };

  const handleResetFilters = () => {
    setSubjectFilter('ALL');
    setFileTypeFilter('ALL');
    setSearchQuery('');
  };

  const getFileIcon = (fileType?: string) => {
    const ft = (fileType || '').toLowerCase();
    if (ft.includes('pdf') || ft.includes('doc')) {
      return <FileText className="w-5 h-5 text-rose-400" />;
    }
    if (ft.includes('zip') || ft.includes('rar') || ft.includes('tar')) {
      return <FileArchive className="w-5 h-5 text-amber-400" />;
    }
    if (ft.includes('mp4') || ft.includes('video')) {
      return <Film className="w-5 h-5 text-purple-400" />;
    }
    if (ft.includes('png') || ft.includes('jpg') || ft.includes('jpeg')) {
      return <Image className="w-5 h-5 text-emerald-400" />;
    }
    return <FileCode className="w-5 h-5 text-emerald-400" />;
  };

  const activeChild = (children || []).find((c) => c.id === selectedChildId) || children?.[0];

  if (isLoadingChildren) {
    return (
      <div className="p-12 flex flex-col items-center justify-center min-h-[450px] space-y-4">
        <LoadingSpinner size="lg" message="Loading your verified scholars..." />
      </div>
    );
  }

  if (authError) {
    return (
      <div className="p-8 max-w-2xl mx-auto space-y-6 text-center">
        <div className="w-16 h-16 rounded-3xl bg-rose-500/20 border border-rose-500/30 text-rose-400 flex items-center justify-center mx-auto">
          <AlertCircle className="w-8 h-8" />
        </div>
        <div className="space-y-2">
          <h2 className="text-2xl font-bold text-white tracking-tight">Access Restricted</h2>
          <p className="text-sm text-slate-400">{authError}</p>
        </div>
        <div className="flex justify-center gap-3">
          <Button
            id="guardian-mat-back-btn"
            variant="secondary"
            onClick={() => onNavigate && onNavigate('guardian-dashboard')}
          >
            <ArrowLeft className="w-4 h-4 mr-2" /> Back to Dashboard
          </Button>
        </div>
      </div>
    );
  }

  if ((children?.length || 0) === 0) {
    return (
      <div className="p-12 max-w-lg mx-auto text-center space-y-4 rounded-3xl bg-slate-900/60 border border-white/10 p-8">
        <div className="w-14 h-14 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center mx-auto">
          <UserCheck className="w-7 h-7" />
        </div>
        <h3 className="text-xl font-bold text-white">No Linked Scholars</h3>
        <p className="text-sm text-slate-400">
          There are currently no student accounts linked to your guardian profile.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      {/* 1. Header & Navigation Hub */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <button
              onClick={() => onNavigate && onNavigate('guardian-dashboard')}
              className="text-xs font-semibold text-slate-400 hover:text-emerald-400 transition-colors flex items-center gap-1"
            >
              <ArrowLeft className="w-3.5 h-3.5" /> Portal Dashboard
            </button>
            <span className="text-slate-600">/</span>
            <span className="text-xs font-semibold text-emerald-400">Study Materials</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight flex items-center gap-3">
            <FolderOpen className="w-8 h-8 text-emerald-400" />
            Classroom Study Materials
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Access shared lesson notes, presentation slides, reference guides, and syllabus resources.
          </p>
        </div>

        {/* Quick Links */}
        <div className="flex flex-wrap items-center gap-2">
          <Button
            id="guardian-nav-hw-from-mat"
            variant="outline"
            size="sm"
            onClick={() => onNavigate && onNavigate('guardian-homework')}
            className="text-xs border-white/10 hover:border-emerald-500/40"
          >
            <BookOpen className="w-3.5 h-3.5 mr-1.5 text-amber-400" />
            Homework
          </Button>
          <Button
            id="guardian-nav-asg-from-mat"
            variant="outline"
            size="sm"
            onClick={() => onNavigate && onNavigate('guardian-assignments')}
            className="text-xs border-white/10 hover:border-emerald-500/40"
          >
            <FileText className="w-3.5 h-3.5 mr-1.5 text-indigo-400" />
            Assignments
          </Button>
          <Button
            id="guardian-nav-ann-from-mat"
            variant="outline"
            size="sm"
            onClick={() => onNavigate && onNavigate('guardian-announcements')}
            className="text-xs border-white/10 hover:border-emerald-500/40"
          >
            <Sparkles className="w-3.5 h-3.5 mr-1.5 text-purple-400" />
            Announcements
          </Button>
        </div>
      </div>

      {/* 2. Multi-Child Selector */}
      <div className="rounded-3xl bg-slate-900/60 border border-white/10 p-5 backdrop-blur-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 shrink-0">
              <GraduationCap className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-semibold text-emerald-400 uppercase tracking-wider">Active Scholar</div>
              <div className="text-sm font-bold text-white">
                {activeChild ? `${activeChild.name} (${activeChild.className} - ${activeChild.sectionName})` : 'Select Scholar'}
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {(children || []).map((child) => {
              const isSelected = child.id === selectedChildId;
              return (
                <button
                  key={child.id}
                  id={`select-child-mat-${child.id}`}
                  onClick={() => setSelectedChildId(child.id)}
                  className={`flex items-center gap-3 px-4 py-2.5 rounded-2xl text-xs font-bold transition-all border ${
                    isSelected
                      ? 'bg-emerald-600 text-white border-emerald-400 shadow-lg shadow-emerald-500/25 scale-[1.02]'
                      : 'bg-slate-800/80 text-slate-300 border-white/5 hover:border-white/20 hover:bg-slate-800'
                  }`}
                >
                  <div
                    className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-black ${
                      isSelected ? 'bg-white text-emerald-800' : 'bg-emerald-500/20 text-emerald-300'
                    }`}
                  >
                    {child.name.charAt(0)}
                  </div>
                  <div className="text-left">
                    <div>{child.name}</div>
                    <div className={`text-[10px] font-normal ${isSelected ? 'text-emerald-100' : 'text-slate-400'}`}>
                      {child.className} • Sec {child.sectionName}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* 3. Filter Toolbar */}
      <div className="rounded-3xl bg-slate-900/60 border border-white/10 p-5 backdrop-blur-xl space-y-4">
        <form onSubmit={handleSearchSubmit} className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              id="guardian-mat-search-input"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by topic, keyword, teacher..."
              className="w-full bg-slate-800/80 border border-white/10 rounded-2xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-400 transition-colors"
            />
          </div>

          <div>
            <select
              id="guardian-mat-subject-filter"
              value={subjectFilter}
              onChange={(e) => setSubjectFilter(e.target.value)}
              className="w-full bg-slate-800/80 border border-white/10 rounded-2xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-400 transition-colors"
            >
              <option value="ALL">All Subjects</option>
              {(materialData?.subjects || []).map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.code})
                </option>
              ))}
            </select>
          </div>

          <div className="flex gap-2">
            <select
              id="guardian-mat-type-filter"
              value={fileTypeFilter}
              onChange={(e) => setFileTypeFilter(e.target.value)}
              className="w-full bg-slate-800/80 border border-white/10 rounded-2xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-400 transition-colors"
            >
              <option value="ALL">All File Types</option>
              <option value="pdf">PDF Documents</option>
              <option value="docx">Word / DOCX</option>
              <option value="pptx">PowerPoint Slides</option>
              <option value="zip">Archive / ZIP</option>
            </select>
            <Button
              type="button"
              id="guardian-mat-reset-btn"
              variant="secondary"
              size="sm"
              onClick={handleResetFilters}
              title="Reset Filters"
              className="shrink-0 px-3"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </Button>
          </div>
        </form>
      </div>

      {/* 4. Materials Grid */}
      {isLoadingMaterials ? (
        <div className="p-12 flex flex-col items-center justify-center min-h-[300px]">
          <LoadingSpinner size="md" message="Fetching shared study materials..." />
        </div>
      ) : error ? (
        <div className="p-8 text-center rounded-3xl bg-rose-500/10 border border-rose-500/20 max-w-xl mx-auto space-y-3">
          <AlertCircle className="w-8 h-8 text-rose-400 mx-auto" />
          <div className="text-sm font-semibold text-white">Error Loading Study Materials</div>
          <p className="text-xs text-slate-400">{error}</p>
          <Button onClick={fetchMaterials} variant="secondary" size="sm">
            <RefreshCw className="w-3.5 h-3.5 mr-2" /> Try Again
          </Button>
        </div>
      ) : !materialData || !Array.isArray(materialData.data) || materialData.data.length === 0 ? (
        <div className="p-12 text-center rounded-3xl bg-slate-900/40 border border-white/10 max-w-lg mx-auto space-y-4">
          <div className="w-14 h-14 rounded-2xl bg-slate-800 text-slate-400 flex items-center justify-center mx-auto">
            <FolderOpen className="w-7 h-7" />
          </div>
          <div className="space-y-1">
            <h3 className="text-base font-bold text-white">No Study Materials Found</h3>
            <p className="text-xs text-slate-400">
              No study documents match the selected filters for {activeChild?.name}.
            </p>
          </div>
          {(subjectFilter !== 'ALL' || fileTypeFilter !== 'ALL' || searchQuery) && (
            <Button onClick={handleResetFilters} variant="secondary" size="sm">
              Clear All Filters
            </Button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {(materialData.data || []).map((item) => (
            <div
              key={item.id}
              id={`guardian-mat-card-${item.id}`}
              onClick={() => setSelectedMaterial(item)}
              className="group relative rounded-3xl bg-slate-900/60 border border-white/10 hover:border-emerald-500/40 p-6 backdrop-blur-xl transition-all duration-200 hover:-translate-y-0.5 cursor-pointer flex flex-col justify-between"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <span className="px-3 py-1 rounded-full text-[11px] font-bold bg-emerald-500/10 text-emerald-300 border border-emerald-500/20">
                    {item.subjectName}
                  </span>
                  <span className="px-2 py-0.5 rounded-lg text-[10px] font-mono uppercase bg-slate-800 text-slate-400 border border-white/5">
                    {item.fileType || 'FILE'}
                  </span>
                </div>

                <div>
                  <h3 className="text-base font-bold text-white group-hover:text-emerald-300 transition-colors line-clamp-1">
                    {item.title}
                  </h3>
                  <p className="text-xs text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                    {item.description}
                  </p>
                </div>
              </div>

              <div className="mt-5 pt-4 border-t border-white/5 flex items-center justify-between gap-2 text-xs text-slate-400">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-slate-800 flex items-center justify-center shrink-0">
                    {getFileIcon(item.fileType)}
                  </div>
                  <div className="truncate">
                    <div className="text-xs font-semibold text-slate-200 truncate">{item.fileName}</div>
                    <div className="text-[10px] text-slate-500">{item.fileSize || 'Standard'} • {item.uploadDate}</div>
                  </div>
                </div>

                <a
                  href={item.fileUrl || '#'}
                  target="_blank"
                  rel="noreferrer"
                  onClick={(e) => e.stopPropagation()}
                  className="p-2 rounded-xl bg-slate-800 text-emerald-400 hover:bg-emerald-500 hover:text-slate-950 transition-colors shrink-0"
                  title="Download File"
                >
                  <Download className="w-4 h-4" />
                </a>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* 5. Study Material Detail Modal */}
      <Modal
        isOpen={!!selectedMaterial}
        onClose={() => setSelectedMaterial(null)}
        title="Study Material Overview"
      >
        {selectedMaterial && (
          <div className="space-y-6">
            <div className="flex items-start justify-between gap-4">
              <div className="space-y-1">
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/10 text-emerald-300 border border-emerald-500/20">
                  {selectedMaterial.subjectName}
                </span>
                <h2 className="text-xl font-bold text-white mt-2">{selectedMaterial.title}</h2>
                <div className="text-xs text-slate-400">
                  Shared by <strong className="text-slate-200">{selectedMaterial.teacherName}</strong> • {activeChild?.className} ({activeChild?.sectionName})
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 p-4 rounded-2xl bg-slate-900 border border-white/5 text-xs">
              <div>
                <span className="text-slate-500 block mb-1">Uploaded Date</span>
                <span className="text-slate-200 font-semibold">{selectedMaterial.uploadDate}</span>
              </div>
              <div>
                <span className="text-slate-500 block mb-1">File Format</span>
                <span className="text-emerald-400 font-semibold uppercase">{selectedMaterial.fileType || 'Document'}</span>
              </div>
            </div>

            <div className="space-y-2">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">Lesson Notes &amp; Overview</h4>
              <div className="p-4 rounded-2xl bg-slate-900/90 border border-white/5 text-xs text-slate-300 leading-relaxed whitespace-pre-wrap">
                {selectedMaterial.description}
              </div>
            </div>

            <div className="space-y-2">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">Resource File</h4>
              <div className="flex items-center justify-between p-4 rounded-2xl bg-slate-900 border border-white/10 hover:border-emerald-500/30 transition-colors">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-slate-800 flex items-center justify-center">
                    {getFileIcon(selectedMaterial.fileType)}
                  </div>
                  <div>
                    <div className="text-xs font-bold text-white">{selectedMaterial.fileName}</div>
                    <div className="text-[10px] text-slate-400">{selectedMaterial.fileSize || 'Standard Material'}</div>
                  </div>
                </div>

                <a
                  href={selectedMaterial.fileUrl || '#'}
                  target="_blank"
                  rel="noreferrer"
                  className="px-4 py-2 rounded-xl bg-emerald-600 text-white hover:bg-emerald-500 text-xs font-semibold flex items-center gap-1.5 transition-colors"
                >
                  <Download className="w-3.5 h-3.5" />
                  Download Resource
                </a>
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <Button onClick={() => setSelectedMaterial(null)} variant="secondary">
                Close
              </Button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};
