import React, { useState, useEffect } from 'react';
import {
  Users,
  GraduationCap,
  BookOpen,
  Bell,
  Building,
  Phone,
  Mail,
  UserCheck,
  Calendar,
  AlertCircle,
  ArrowRight,
  RefreshCw,
  Sparkles,
  Clock,
  HeartHandshake,
  CheckSquare,
  Award,
  TrendingUp,
  CreditCard,
  Receipt,
  FileText,
  CalendarDays,
  ShieldCheck,
  ExternalLink
} from 'lucide-react';
import { api } from '../../services/api.js';
import {
  GuardianDashboardData,
  GuardianChildSummary,
  GuardianChildAcademicSnapshot,
  GuardianChildAttendanceSnapshot,
  GuardianChildFeesSnapshot,
  GuardianChildActivityItem
} from '../../types/index.js';
import { useToast } from '../../context/ToastContext.js';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner.js';
import { Badge } from '../../components/ui/Badge.js';
import { Button } from '../../components/ui/Button.js';
import { ChildOverviewCard } from '../../components/guardian/ChildOverviewCard.js';
import { ChildAcademicSnapshotCard } from '../../components/guardian/ChildAcademicSnapshotCard.js';
import { ChildAttendanceSnapshotCard } from '../../components/guardian/ChildAttendanceSnapshotCard.js';
import { ChildFeesSnapshotCard } from '../../components/guardian/ChildFeesSnapshotCard.js';
import { RecentActivityFeed } from '../../components/guardian/RecentActivityFeed.js';
import { ChildSwitcher } from '../../components/guardian/ChildSwitcher.js';

interface GuardianDashboardPageProps {
  onNavigate: (view: string) => void;
}

export const GuardianDashboardPage: React.FC<GuardianDashboardPageProps> = ({ onNavigate }) => {
  const [data, setData] = useState<GuardianDashboardData | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isSwitchingChild, setIsSwitchingChild] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedChildId, setSelectedChildId] = useState<string | null>(null);

  // Active child snapshots state (allows dynamic refresh when switching scholar)
  const [academicSnapshot, setAcademicSnapshot] = useState<GuardianChildAcademicSnapshot | undefined>(undefined);
  const [attendanceSnapshot, setAttendanceSnapshot] = useState<GuardianChildAttendanceSnapshot | undefined>(undefined);
  const [feesSnapshot, setFeesSnapshot] = useState<GuardianChildFeesSnapshot | undefined>(undefined);
  const [recentActivities, setRecentActivities] = useState<GuardianChildActivityItem[]>([]);

  const { addToast } = useToast();

  const fetchDashboard = async (childId?: string) => {
    if (!childId) {
      setIsLoading(true);
    } else {
      setIsSwitchingChild(true);
    }
    setError(null);

    try {
      const res = await api.guardian.getDashboard(childId);
      if (res.success && res.data) {
        setData(res.data);
        const childrenList = res.data.children || [];
        const activeId = childId || res.data.activeChildId || childrenList?.[0]?.id || null;
        setSelectedChildId(activeId);

        setAcademicSnapshot(res.data.academicSnapshot);
        setAttendanceSnapshot(res.data.attendanceSnapshot);
        setFeesSnapshot(res.data.feesSnapshot);
        setRecentActivities(res.data.recentActivities || []);
      } else {
        setError(typeof res.error === 'string' ? res.error : 'Unable to load guardian dashboard.');
      }
    } catch (err: any) {
      setError(err?.message || 'Network error occurred while fetching dashboard data.');
    } finally {
      setIsLoading(false);
      setIsSwitchingChild(false);
    }
  };

  const handleSelectChild = async (newChildId: string) => {
    if (newChildId === selectedChildId) return;
    setSelectedChildId(newChildId);
    await fetchDashboard(newChildId);
  };

  useEffect(() => {
    fetchDashboard();
  }, []);

  if (isLoading) {
    return (
      <div className="p-12 flex items-center justify-center min-h-[450px]">
        <LoadingSpinner size="lg" message="Loading your parent portal dashboard..." />
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="p-8 max-w-xl mx-auto text-center space-y-4 my-12">
        <div className="w-14 h-14 rounded-2xl bg-rose-50 border border-rose-200 text-rose-600 flex items-center justify-center mx-auto shadow-sm">
          <AlertCircle className="w-7 h-7" />
        </div>
        <h3 className="text-xl font-bold text-slate-900">Dashboard Unavailable</h3>
        <p className="text-sm text-slate-600 leading-relaxed">
          {error || 'Could not find authorized guardian account profile.'}
        </p>
        <Button onClick={() => fetchDashboard()} variant="secondary" className="mt-3">
          <RefreshCw className="w-4 h-4 mr-2" /> Try Again
        </Button>
      </div>
    );
  }

  const { guardian, quickStats } = data;
  const children = data.children || [];
  const recentNotifications = data.recentNotifications || [];
  const importantAnnouncements = data.importantAnnouncements || [];
  const activeChild = (children || []).find((c) => c.id === selectedChildId) || children?.[0];

  return (
    <div className="space-y-8 animate-in fade-in duration-200 pb-12 max-w-7xl mx-auto">
      {/* 1. Guardian Welcome Header & Institutional Summary */}
      <div className="rounded-2xl bg-white border border-slate-200 p-6 sm:p-8 shadow-2xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="px-3 py-1 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-200 flex items-center gap-1.5">
                <HeartHandshake className="w-3.5 h-3.5 text-blue-600" />
                Parent &amp; Guardian Portal
              </span>
              <span className="text-xs text-slate-500 font-mono">
                {guardian.relationship || 'Guardian'}
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900">
              Welcome, {guardian.name}
            </h1>
            <p className="text-sm text-slate-600 max-w-2xl leading-relaxed">
              Real-time academic snapshot, attendance monitoring, examination reports, and school communications for your enrolled scholars.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <Button
              id="guardian-refresh-btn"
              onClick={() => fetchDashboard(selectedChildId || undefined)}
              variant="outline"
              className="text-xs"
            >
              <RefreshCw className={`w-3.5 h-3.5 mr-1.5 ${isSwitchingChild ? 'animate-spin' : ''}`} /> Refresh
            </Button>
            <Button
              id="guardian-profile-quick-btn"
              onClick={() => onNavigate('guardian-profile')}
              variant="primary"
              className="text-xs shadow-xs"
            >
              <UserCheck className="w-3.5 h-3.5 mr-1.5" /> Contact Profile
            </Button>
          </div>
        </div>

        {/* Institutional Summary Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4 mt-6 pt-6 border-t border-slate-200">
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
            <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
              <span>Linked Scholars</span>
              <Users className="w-4 h-4 text-blue-600" />
            </div>
            <div className="text-xl sm:text-2xl font-black text-slate-900">{children?.length || 0}</div>
            <div className="text-[11px] text-slate-500">Verified Enrollment</div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
            <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
              <span>Enrolled Subjects</span>
              <BookOpen className="w-4 h-4 text-blue-600" />
            </div>
            <div className="text-xl sm:text-2xl font-black text-slate-900">{quickStats.totalEnrolledSubjects}</div>
            <div className="text-[11px] text-slate-500">Total Curriculum Count</div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
            <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
              <span>Academic Year</span>
              <Calendar className="w-4 h-4 text-emerald-600" />
            </div>
            <div className="text-sm sm:text-base font-bold text-slate-900 truncate">{quickStats.activeAcademicYear}</div>
            <div className="text-[11px] text-emerald-700 font-medium">Active Academic Cycle</div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
            <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
              <span>Unread Notices</span>
              <Bell className="w-4 h-4 text-amber-600" />
            </div>
            <div className="text-xl sm:text-2xl font-black text-slate-900">{data.unreadNotificationCount || 0}</div>
            <div className="text-[11px] text-slate-500">Targeted Bulletins</div>
          </div>
        </div>
      </div>

      {/* 2. Multi-Child Switcher (Rendered if >1 child linked) */}
      <ChildSwitcher
        childrenList={children}
        selectedChildId={selectedChildId || undefined}
        onSelectChild={handleSelectChild}
      />

      {/* 3. Empty State If No Children Linked */}
      {(children?.length || 0) === 0 ? (
        <div
          id="guardian-no-children-banner"
          className="bg-white rounded-2xl border border-slate-200/80 shadow-sm p-10 text-center space-y-4"
        >
          <div className="w-16 h-16 rounded-2xl bg-amber-50 border border-amber-200 text-amber-600 flex items-center justify-center mx-auto">
            <Users className="w-8 h-8" />
          </div>
          <div className="space-y-1 max-w-md mx-auto">
            <h3 className="text-lg font-bold text-slate-900">No Linked Scholars On Record</h3>
            <p className="text-sm text-slate-600">
              Your guardian account does not currently have any student profiles linked. If this is in error, please contact the academy registrar or administrative office.
            </p>
          </div>
          <div className="pt-2">
            <Button
              onClick={() => onNavigate('guardian-profile')}
              variant="secondary"
              className="text-xs"
            >
              Verify Contact Details
            </Button>
          </div>
        </div>
      ) : activeChild ? (
        <>
          {/* 4. Active Scholar Comprehensive Profile Card */}
          <div className="relative">
            {isSwitchingChild && (
              <div className="absolute inset-0 bg-white/70 backdrop-blur-[1px] z-20 rounded-xl flex items-center justify-center">
                <LoadingSpinner size="md" message="Updating scholar records..." />
              </div>
            )}
            <ChildOverviewCard
              child={activeChild}
              onNavigate={onNavigate}
            />
          </div>

          {/* 5. Core Three-Pillar Snapshots (Academic, Attendance, Fees) */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-bold text-slate-900 tracking-tight">
                  Performance &amp; Status Overview
                </h2>
                <p className="text-xs text-slate-500">
                  Real-time official school records for <strong className="text-slate-800">{activeChild.name}</strong>
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Academic Snapshot Card */}
              <ChildAcademicSnapshotCard
                snapshot={academicSnapshot}
                onNavigate={onNavigate}
              />

              {/* Attendance Snapshot Card */}
              <ChildAttendanceSnapshotCard
                snapshot={attendanceSnapshot}
                onNavigate={onNavigate}
              />

              {/* Fees Snapshot Card */}
              <ChildFeesSnapshotCard
                snapshot={feesSnapshot}
                onNavigate={onNavigate}
              />
            </div>
          </div>

          {/* 6. Quick Access Navigation Grid */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-bold text-slate-900 tracking-tight">
                Quick Access Modules
              </h2>
              <span className="text-xs text-slate-500">Essential Scholar Services</span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
              <button
                type="button"
                id="btn-quick-results"
                onClick={() => onNavigate('guardian-results')}
                className="p-4 rounded-xl bg-white border border-slate-200/80 shadow-sm hover:border-blue-400 hover:shadow-md transition-all text-left group flex flex-col justify-between"
              >
                <div className="p-2.5 rounded-lg bg-purple-50 text-purple-600 w-fit group-hover:scale-105 transition-transform">
                  <Award className="w-5 h-5" />
                </div>
                <div className="mt-3">
                  <span className="text-xs font-bold text-slate-900 block group-hover:text-blue-600">
                    Results &amp; Marks
                  </span>
                  <span className="text-[11px] text-slate-500">Published reports</span>
                </div>
              </button>

              <button
                type="button"
                id="btn-quick-attendance"
                onClick={() => onNavigate('guardian-attendance')}
                className="p-4 rounded-xl bg-white border border-slate-200/80 shadow-sm hover:border-emerald-400 hover:shadow-md transition-all text-left group flex flex-col justify-between"
              >
                <div className="p-2.5 rounded-lg bg-emerald-50 text-emerald-600 w-fit group-hover:scale-105 transition-transform">
                  <Calendar className="w-5 h-5" />
                </div>
                <div className="mt-3">
                  <span className="text-xs font-bold text-slate-900 block group-hover:text-emerald-600">
                    Attendance
                  </span>
                  <span className="text-[11px] text-slate-500">Monthly roll log</span>
                </div>
              </button>

              <button
                type="button"
                id="btn-quick-fees"
                onClick={() => onNavigate('guardian-fees')}
                className="p-4 rounded-xl bg-white border border-slate-200/80 shadow-sm hover:border-blue-400 hover:shadow-md transition-all text-left group flex flex-col justify-between"
              >
                <div className="p-2.5 rounded-lg bg-blue-50 text-blue-600 w-fit group-hover:scale-105 transition-transform">
                  <CreditCard className="w-5 h-5" />
                </div>
                <div className="mt-3">
                  <span className="text-xs font-bold text-slate-900 block group-hover:text-blue-600">
                    Fee Invoices
                  </span>
                  <span className="text-[11px] text-slate-500">Pay &amp; statements</span>
                </div>
              </button>

              <button
                type="button"
                id="btn-quick-leaves"
                onClick={() => onNavigate('guardian-leaves')}
                className="p-4 rounded-xl bg-white border border-slate-200/80 shadow-sm hover:border-indigo-400 hover:shadow-md transition-all text-left group flex flex-col justify-between"
              >
                <div className="p-2.5 rounded-lg bg-indigo-50 text-indigo-600 w-fit group-hover:scale-105 transition-transform">
                  <FileText className="w-5 h-5" />
                </div>
                <div className="mt-3">
                  <span className="text-xs font-bold text-slate-900 block group-hover:text-indigo-600">
                    Leave Requests
                  </span>
                  <span className="text-[11px] text-slate-500">Submit excuse</span>
                </div>
              </button>

              <button
                type="button"
                id="btn-quick-timetable"
                onClick={() => onNavigate('guardian-routine')}
                className="p-4 rounded-xl bg-white border border-slate-200/80 shadow-sm hover:border-amber-400 hover:shadow-md transition-all text-left group flex flex-col justify-between"
              >
                <div className="p-2.5 rounded-lg bg-amber-50 text-amber-600 w-fit group-hover:scale-105 transition-transform">
                  <CalendarDays className="w-5 h-5" />
                </div>
                <div className="mt-3">
                  <span className="text-xs font-bold text-slate-900 block group-hover:text-amber-600">
                    Class Routine
                  </span>
                  <span className="text-[11px] text-slate-500">Weekly schedule</span>
                </div>
              </button>

              <button
                type="button"
                id="btn-quick-dossier"
                onClick={() => onNavigate('guardian-academic-overview')}
                className="p-4 rounded-xl bg-white border border-slate-200/80 shadow-sm hover:border-slate-400 hover:shadow-md transition-all text-left group flex flex-col justify-between"
              >
                <div className="p-2.5 rounded-lg bg-slate-100 text-slate-700 w-fit group-hover:scale-105 transition-transform">
                  <BookOpen className="w-5 h-5" />
                </div>
                <div className="mt-3">
                  <span className="text-xs font-bold text-slate-900 block group-hover:text-slate-700">
                    Academic Dossier
                  </span>
                  <span className="text-[11px] text-slate-500">Full history</span>
                </div>
              </button>
            </div>
          </div>

          {/* 7. Live Scholar Activities & School Communications */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Left Column: Recent Activity Feed */}
            <RecentActivityFeed
              activities={recentActivities}
              onNavigate={onNavigate}
            />

            {/* Right Column: Official Notices & School Help Desk */}
            <div className="space-y-6">
              {/* Important School Announcements */}
              <div className="bg-white rounded-xl border border-slate-200/80 shadow-sm p-6 space-y-4">
                <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 rounded-lg bg-amber-50 text-amber-600">
                      <Sparkles className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-bold text-slate-900 text-base">Academy Announcements</h3>
                      <p className="text-xs text-slate-500">Official institutional bulletins</p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => onNavigate('guardian-announcements')}
                    className="text-xs font-semibold text-blue-600 hover:underline"
                  >
                    View All
                  </button>
                </div>

                <div className="space-y-3">
                  {(importantAnnouncements?.length || 0) === 0 ? (
                    <p className="text-xs text-slate-400 py-4 text-center">
                      No published school announcements at this time.
                    </p>
                  ) : (
                    importantAnnouncements.slice(0, 3).map((ann) => (
                      <div
                        key={ann.id}
                        className="p-3.5 rounded-xl bg-slate-50/70 border border-slate-100 space-y-1.5"
                      >
                        <div className="flex items-center justify-between gap-2">
                          <h4 className="text-xs font-bold text-slate-900 truncate">{ann.title}</h4>
                          <span
                            className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                              ann.priority === 'urgent'
                                ? 'bg-rose-50 text-rose-700 border border-rose-200'
                                : ann.priority === 'high'
                                ? 'bg-amber-50 text-amber-700 border border-amber-200'
                                : 'bg-slate-100 text-slate-700'
                            }`}
                          >
                            {ann.priority}
                          </span>
                        </div>
                        <p className="text-xs text-slate-600 leading-relaxed line-clamp-2">
                          {ann.content}
                        </p>
                        <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1">
                          <span>By: {ann.authorName}</span>
                          <span className="font-mono">
                            {new Date(ann.publishedAt).toLocaleDateString()}
                          </span>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>

              {/* Academy Parent Help Desk & Liaison */}
              <div className="bg-gradient-to-br from-slate-900 to-indigo-950 rounded-xl text-white p-6 space-y-3 border border-slate-800 shadow-sm">
                <div className="flex items-center gap-2">
                  <Building className="w-4 h-4 text-blue-400" />
                  <h3 className="text-xs font-bold uppercase tracking-wider text-blue-200">
                    Academy Parent Liaison &amp; Desk
                  </h3>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  For campus visits, student leave notifications, or emergency updates, contact the administration office.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2 text-xs">
                  <div className="flex items-center gap-2 p-2.5 rounded-lg bg-white/10 text-slate-200 font-mono">
                    <Phone className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                    <span>{quickStats.schoolPhone || '+1 (555) 012-3456'}</span>
                  </div>
                  <div className="flex items-center gap-2 p-2.5 rounded-lg bg-white/10 text-slate-200 font-mono truncate">
                    <Mail className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                    <span className="truncate">
                      {quickStats.schoolEmail || 'administration@sygmate.edu'}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </>
      ) : null}
    </div>
  );
};
