import React, { useState, useEffect } from 'react';
import {
  Receipt,
  Search,
  Filter,
  Calendar,
  RotateCcw,
  Download,
  Printer,
  CreditCard,
  Building,
  GraduationCap,
  User,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  FileText,
  DollarSign,
  Landmark,
  Wallet,
  ArrowLeft,
  X
} from 'lucide-react';
import { api } from '../../services/api.js';
import { triggerSafePrint } from '../../utils/printPdf.js';
import {
  FeePaymentTransaction,
  FeePaymentReceipt,
  GuardianChildSummary,
  GuardianPaymentHistoryResponse
} from '../../types/index.js';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner.js';
import { Badge } from '../../components/ui/Badge.js';
import { Button } from '../../components/ui/Button.js';
import { Modal } from '../../components/ui/Modal.js';
import { Input } from '../../components/ui/Input.js';
import { StudentStatementModal } from '../../components/fees/StudentStatementModal.js';

interface GuardianPaymentHistoryPageProps {
  onNavigate?: (view: string) => void;
}

export const GuardianPaymentHistoryPage: React.FC<GuardianPaymentHistoryPageProps> = ({
  onNavigate
}) => {
  const [data, setData] = useState<GuardianPaymentHistoryResponse | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Filters
  const [selectedStudentId, setSelectedStudentId] = useState<string>('ALL');
  const [selectedMethod, setSelectedMethod] = useState<string>('ALL');
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');
  const [startDate, setStartDate] = useState<string>('');
  const [endDate, setEndDate] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Statement Modal
  const [statementStudentId, setStatementStudentId] = useState<string | null>(null);
  const [statementStudentName, setStatementStudentName] = useState<string>('');
  const [isStatementModalOpen, setIsStatementModalOpen] = useState<boolean>(false);

  // Receipt Modal
  const [activeReceipt, setActiveReceipt] = useState<FeePaymentReceipt | null>(null);
  const [isLoadingReceipt, setIsLoadingReceipt] = useState<boolean>(false);

  const fetchPayments = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await api.guardian.getPaymentHistory({
        studentId: selectedStudentId,
        paymentMethod: selectedMethod,
        status: selectedStatus,
        startDate: startDate || undefined,
        endDate: endDate || undefined,
        search: searchQuery || undefined
      });

      if (res.success && res.data) {
        setData(res.data);
      } else {
        setError(typeof res.error === 'string' ? res.error : 'Failed to retrieve payment records.');
      }
    } catch (err: any) {
      setError(err?.message || 'Error communicating with financial service.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchPayments();
  }, [selectedStudentId, selectedMethod, selectedStatus, startDate, endDate]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchPayments();
  };

  const handleViewReceipt = async (transactionIdOrReceipt: string) => {
    setIsLoadingReceipt(true);
    try {
      const res = await api.guardian.getPaymentReceipt(transactionIdOrReceipt);
      if (res.success && res.data) {
        setActiveReceipt(res.data);
      }
    } catch (err: any) {
      console.error('Failed to load receipt:', err);
    } finally {
      setIsLoadingReceipt(false);
    }
  };

  const getMethodIcon = (method: string) => {
    switch (method.toUpperCase()) {
      case 'NET_BANKING':
      case 'BANK_TRANSFER':
        return <Landmark className="w-3.5 h-3.5 text-blue-600" />;
      case 'DIGITAL_WALLET':
        return <Wallet className="w-3.5 h-3.5 text-purple-600" />;
      default:
        return <CreditCard className="w-3.5 h-3.5 text-emerald-600" />;
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 border-b border-slate-200 pb-5">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-indigo-600 mb-1">
            <ShieldCheck className="w-4 h-4" />
            Financial Audit & Records
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
            Payment History & Receipts
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Audit trail of processed fee settlements, transaction IDs, and downloadable official school receipts.
          </p>
        </div>

        <div className="flex items-center gap-3">
          {(((data?.availableChildren?.length || 0) > 0) || ((data?.children?.length || 0) > 0)) && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                const childList = data?.availableChildren || data?.children || [];
                const targetChild = selectedStudentId !== 'ALL' 
                  ? childList.find(c => c.id === selectedStudentId) || childList?.[0]
                  : childList?.[0];
                if (targetChild) {
                  setStatementStudentId(targetChild.id);
                  setStatementStudentName(targetChild.name);
                  setIsStatementModalOpen(true);
                }
              }}
              className="flex items-center gap-1.5 shadow-sm text-indigo-600 border-indigo-200 hover:bg-indigo-50"
            >
              <FileText className="w-4 h-4 text-indigo-600" />
              Student Statement
            </Button>
          )}
          <Button
            variant="outline"
            size="sm"
            onClick={() => onNavigate && onNavigate('guardian-fees')}
            className="flex items-center gap-1.5 shadow-sm"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Invoices
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={fetchPayments}
            disabled={isLoading}
            className="flex items-center gap-1.5 shadow-sm"
          >
            <RotateCcw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* Total Settled */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Total Settled</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-100 flex items-center justify-center text-emerald-600">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold text-emerald-700">
              ${(data?.totalAmountPaid || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <div className="text-xs text-slate-500 mt-1">Total payments processed</div>
          </div>
        </div>

        {/* Transactions Count */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Total Transactions</span>
            <div className="w-8 h-8 rounded-lg bg-indigo-100 flex items-center justify-center text-indigo-600">
              <Receipt className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold text-slate-900">{data?.total || 0}</div>
            <div className="text-xs text-slate-500 mt-1">Verified settlement records</div>
          </div>
        </div>

        {/* Verification Status */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Gateway Status</span>
            <div className="w-8 h-8 rounded-lg bg-blue-100 flex items-center justify-center text-blue-600">
              <ShieldCheck className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold text-slate-900">100% Settled</div>
            <div className="text-xs text-emerald-600 mt-1 flex items-center gap-1 font-medium">
              <CheckCircle2 className="w-3.5 h-3.5" />
              All receipts bursar-certified
            </div>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm">
        <form onSubmit={handleSearchSubmit} className="flex flex-col lg:flex-row gap-3">
          {/* Search Query */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search by transaction ID, receipt #, student name, or fee title..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* Child Filter */}
          <div className="w-full lg:w-48">
            <select
              value={selectedStudentId}
              onChange={(e) => setSelectedStudentId(e.target.value)}
              className="w-full py-2 px-3 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
            >
              <option value="ALL">All Linked Scholars</option>
              {data?.availableChildren?.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          {/* Payment Method Filter */}
          <div className="w-full lg:w-44">
            <select
              value={selectedMethod}
              onChange={(e) => setSelectedMethod(e.target.value)}
              className="w-full py-2 px-3 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
            >
              <option value="ALL">All Methods</option>
              <option value="CREDIT_CARD">Credit Card</option>
              <option value="DEBIT_CARD">Debit Card</option>
              <option value="NET_BANKING">Net Banking / ACH</option>
              <option value="DIGITAL_WALLET">Digital Wallet</option>
              <option value="BANK_TRANSFER">Bank Wire</option>
            </select>
          </div>

          {/* Reset button */}
          {(selectedStudentId !== 'ALL' || selectedMethod !== 'ALL' || searchQuery || startDate || endDate) && (
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => {
                setSelectedStudentId('ALL');
                setSelectedMethod('ALL');
                setSelectedStatus('ALL');
                setStartDate('');
                setEndDate('');
                setSearchQuery('');
              }}
              className="shrink-0 flex items-center gap-1"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Reset
            </Button>
          )}
        </form>
      </div>

      {/* Transactions List */}
      {isLoading ? (
        <div className="flex flex-col items-center justify-center p-12 bg-white rounded-xl border border-slate-200">
          <LoadingSpinner size="lg" />
          <p className="mt-3 text-sm text-slate-500 font-medium">Loading transaction records...</p>
        </div>
      ) : error ? (
        <div className="bg-rose-50 border border-rose-200 rounded-xl p-6 text-center">
          <AlertCircle className="w-8 h-8 text-rose-600 mx-auto mb-2" />
          <p className="text-sm font-semibold text-rose-900">{error}</p>
          <Button variant="outline" size="sm" className="mt-3" onClick={fetchPayments}>
            Retry
          </Button>
        </div>
      ) : !data || !Array.isArray(data.data) || data.data.length === 0 ? (
        <div className="bg-white rounded-xl border border-slate-200 p-12 text-center shadow-sm">
          <Receipt className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <h3 className="text-base font-semibold text-slate-800">No Payment Records Found</h3>
          <p className="text-sm text-slate-500 max-w-sm mx-auto mt-1">
            No payments match your filter criteria.
          </p>
        </div>
      ) : (
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50/50">
            <div className="text-sm font-semibold text-slate-900 flex items-center gap-2">
              <Receipt className="w-4 h-4 text-indigo-600" />
              Payment Records ({data.total} transactions)
            </div>
            <div className="text-xs text-slate-500">
              Total Settled: <span className="font-bold text-emerald-700">${Number(data?.totalAmountPaid ?? 0).toFixed(2)}</span>
            </div>
          </div>

          {/* Desktop View */}
          <div className="hidden md:block overflow-x-auto">
            <table className="w-full text-left border-collapse text-sm">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600 uppercase tracking-wider">
                  <th className="py-3.5 px-4">Transaction / Receipt</th>
                  <th className="py-3.5 px-4">Date & Time</th>
                  <th className="py-3.5 px-4">Student Scholar</th>
                  <th className="py-3.5 px-4">Fee Particulars</th>
                  <th className="py-3.5 px-4">Payment Method</th>
                  <th className="py-3.5 px-4 text-right">Amount Paid</th>
                  <th className="py-3.5 px-4 text-center">Status</th>
                  <th className="py-3.5 px-4 text-center">Receipt</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {(data?.data || []).map((txn) => (
                  <tr key={txn.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3.5 px-4">
                      <div className="font-mono font-bold text-slate-900 text-xs">{txn.transactionId}</div>
                      <div className="text-xs font-mono text-indigo-600 mt-0.5">#{txn.receiptNumber}</div>
                    </td>

                    <td className="py-3.5 px-4 text-xs text-slate-700">
                      <div>{txn.paymentDate.split('T')[0]}</div>
                      <div className="text-[11px] text-slate-400">
                        {txn.paymentDate.split('T')[1]?.substring(0, 5) || '10:00'}
                      </div>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="font-semibold text-slate-900 text-xs">{txn.studentName}</div>
                      <div className="text-[11px] text-slate-500">Student Ward</div>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="font-medium text-slate-800 text-xs">{txn.feeTitle}</div>
                      <div className="text-[11px] text-slate-500 font-mono">{txn.feeType}</div>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-1.5 text-xs text-slate-700 font-medium">
                        {getMethodIcon(txn.paymentMethod)}
                        <span>{txn.paymentMethodLabel || txn.paymentMethod}</span>
                      </div>
                    </td>

                    <td className="py-3.5 px-4 text-right">
                      <div className="font-bold text-emerald-700 text-sm">${Number(txn?.amountPaid ?? 0).toFixed(2)}</div>
                    </td>

                    <td className="py-3.5 px-4 text-center">
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                        <CheckCircle2 className="w-3 h-3" />
                        Success
                      </span>
                    </td>

                    <td className="py-3.5 px-4 text-center">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleViewReceipt(txn.transactionId)}
                        className="text-xs py-1 px-2.5 flex items-center gap-1 shadow-sm"
                      >
                        <Printer className="w-3.5 h-3.5 text-slate-600" />
                        View Receipt
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Mobile View */}
          <div className="block md:hidden divide-y divide-slate-100">
            {(data?.data || []).map((txn) => (
              <div key={txn.id} className="p-4 space-y-2.5">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="font-mono font-bold text-slate-900 text-xs">{txn.transactionId}</div>
                    <div className="text-xs text-slate-500 font-mono">Receipt #{txn.receiptNumber}</div>
                  </div>
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                    <CheckCircle2 className="w-3 h-3" />
                    Settled
                  </span>
                </div>

                <div className="bg-slate-50 rounded-lg p-2.5 text-xs space-y-1">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Student:</span>
                    <span className="font-semibold text-slate-800">{txn.studentName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Fee Particulars:</span>
                    <span className="font-medium text-slate-800">{txn.feeTitle}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Date & Method:</span>
                    <span className="text-slate-700">
                      {txn.paymentDate.split('T')[0]} • {txn.paymentMethod}
                    </span>
                  </div>
                  <div className="flex justify-between pt-1 border-t border-slate-200">
                    <span className="font-semibold text-slate-700">Amount Paid:</span>
                    <span className="font-bold text-emerald-700 text-sm">${Number(txn?.amountPaid ?? 0).toFixed(2)}</span>
                  </div>
                </div>

                <div className="flex justify-end pt-1">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleViewReceipt(txn.transactionId)}
                    className="text-xs py-1.5 px-3 flex items-center gap-1.5 shadow-sm"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    View Receipt
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Official Receipt Modal */}
      {activeReceipt && (
        <Modal
          isOpen={true}
          onClose={() => setActiveReceipt(null)}
          title="Official Payment Receipt"
          size="lg"
        >
          <div className="space-y-5" id="printable-receipt-container">
            {/* Header / Letterhead */}
            <div className="text-center border-b-2 border-slate-800 pb-4">
              <div className="flex items-center justify-center gap-2 font-bold text-xl text-slate-900 uppercase tracking-tight">
                <Building className="w-6 h-6 text-indigo-600" />
                {activeReceipt.schoolInfo.name}
              </div>
              <p className="text-xs text-slate-600 mt-1">{activeReceipt.schoolInfo.address}</p>
              <p className="text-xs text-slate-500">
                Affiliation: {activeReceipt.schoolInfo.affiliationNumber} • Phone: {activeReceipt.schoolInfo.phone} • Email: {activeReceipt.schoolInfo.email}
              </p>
              <div className="inline-block mt-3 px-3 py-0.5 bg-slate-900 text-white font-bold text-xs rounded uppercase tracking-wider">
                Official Bursar Fee Receipt
              </div>
            </div>

            {/* Receipt Meta */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs">
              <div>
                <span className="text-slate-500 uppercase font-semibold text-[10px] block">Receipt Number</span>
                <span className="font-mono font-bold text-slate-900">{activeReceipt.receiptNumber}</span>
              </div>
              <div>
                <span className="text-slate-500 uppercase font-semibold text-[10px] block">Transaction ID</span>
                <span className="font-mono font-bold text-indigo-600">{activeReceipt.transactionId}</span>
              </div>
              <div>
                <span className="text-slate-500 uppercase font-semibold text-[10px] block">Payment Date</span>
                <span className="font-semibold text-slate-800">{activeReceipt.paymentDetails.paymentDate.split('T')[0]}</span>
              </div>
              <div>
                <span className="text-slate-500 uppercase font-semibold text-[10px] block">Status</span>
                <span className="font-bold text-emerald-600">{activeReceipt.paymentDetails.paymentStatus}</span>
              </div>
            </div>

            {/* Particulars */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div className="border border-slate-200 rounded-lg p-3 bg-white">
                <div className="font-bold text-slate-800 uppercase text-[11px] border-b border-slate-100 pb-1 mb-1.5 flex items-center gap-1.5">
                  <GraduationCap className="w-3.5 h-3.5 text-indigo-600" />
                  Student Particulars
                </div>
                <div className="space-y-1 text-slate-700">
                  <div><span className="font-medium text-slate-500">Student Name:</span> {activeReceipt.studentInfo.name}</div>
                  <div><span className="font-medium text-slate-500">Admission No:</span> {activeReceipt.studentInfo.admissionNumber}</div>
                  <div><span className="font-medium text-slate-500">Class & Section:</span> {activeReceipt.studentInfo.className} ({activeReceipt.studentInfo.sectionName})</div>
                  <div><span className="font-medium text-slate-500">Roll Number:</span> {activeReceipt.studentInfo.rollNumber}</div>
                </div>
              </div>

              <div className="border border-slate-200 rounded-lg p-3 bg-white">
                <div className="font-bold text-slate-800 uppercase text-[11px] border-b border-slate-100 pb-1 mb-1.5 flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-indigo-600" />
                  Guardian Particulars
                </div>
                <div className="space-y-1 text-slate-700">
                  <div><span className="font-medium text-slate-500">Payer Name:</span> {activeReceipt.guardianInfo.name}</div>
                  <div><span className="font-medium text-slate-500">Relationship:</span> {activeReceipt.guardianInfo.relation}</div>
                  <div><span className="font-medium text-slate-500">Contact Phone:</span> {activeReceipt.guardianInfo.phone}</div>
                  <div><span className="font-medium text-slate-500">Gateway:</span> {activeReceipt.paymentDetails.paymentMethod}</div>
                </div>
              </div>
            </div>

            {/* Table */}
            <div className="border border-slate-300 rounded-lg overflow-hidden text-xs">
              <table className="w-full text-left">
                <thead className="bg-slate-100 border-b border-slate-300 font-semibold text-slate-800">
                  <tr>
                    <th className="p-2.5">Fee Particulars & Academic Session</th>
                    <th className="p-2.5 text-right">Invoiced</th>
                    <th className="p-2.5 text-right">Discount</th>
                    <th className="p-2.5 text-right">Net Payable</th>
                    <th className="p-2.5 text-right">Amount Paid Now</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  <tr>
                    <td className="p-2.5">
                      <div className="font-bold text-slate-900">{activeReceipt.feeInfo.title}</div>
                      <div className="text-slate-500 text-[11px]">
                        {activeReceipt.feeInfo.academicSession} • {activeReceipt.feeInfo.term}
                      </div>
                    </td>
                    <td className="p-2.5 text-right">${Number(activeReceipt.feeInfo?.totalFee ?? 0).toFixed(2)}</td>
                    <td className="p-2.5 text-right text-amber-700">-${Number(activeReceipt.feeInfo?.discount ?? 0).toFixed(2)}</td>
                    <td className="p-2.5 text-right font-medium">${Number(activeReceipt.feeInfo?.netPayable ?? 0).toFixed(2)}</td>
                    <td className="p-2.5 text-right font-bold text-emerald-700 text-sm">
                      ${Number(activeReceipt.feeInfo?.amountPaidNow ?? 0).toFixed(2)}
                    </td>
                  </tr>
                </tbody>
                <tfoot className="bg-slate-50 border-t-2 border-slate-300 font-semibold">
                  <tr>
                    <td colSpan={4} className="p-2.5 text-right text-slate-700">Total Settled in this Transaction:</td>
                    <td className="p-2.5 text-right font-bold text-base text-emerald-700">
                      ${Number(activeReceipt.feeInfo?.amountPaidNow ?? 0).toFixed(2)}
                    </td>
                  </tr>
                  <tr>
                    <td colSpan={4} className="p-2.5 text-right text-slate-500">Remaining Balance Due:</td>
                    <td className="p-2.5 text-right font-bold text-slate-800">
                      ${Number(activeReceipt.feeInfo?.remainingDue ?? 0).toFixed(2)}
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>

            {/* Signature */}
            <div className="flex items-end justify-between pt-4 border-t border-slate-200 text-xs text-slate-500">
              <div>
                <div className="flex items-center gap-1.5 text-emerald-700 font-semibold mb-1">
                  <ShieldCheck className="w-4 h-4" />
                  <span>Digital Gateway Verification Verified</span>
                </div>
                <p className="text-[10px] font-mono">Ref: {activeReceipt.paymentDetails.gatewayReference}</p>
              </div>

              <div className="text-center">
                <div className="w-36 border-b border-slate-400 pb-1 mb-1 font-serif italic text-slate-800 font-bold">
                  Evelyn Montgomery
                </div>
                <div className="text-[10px] text-slate-600 font-medium">
                  {activeReceipt.paymentDetails.authorizedSignatory}
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200 print:hidden">
              <Button variant="outline" onClick={() => setActiveReceipt(null)}>
                Close
              </Button>
              <Button
                onClick={() =>
                  triggerSafePrint({
                    elementOrId: 'printable-receipt-container',
                    fallbackTitle: `Receipt_${activeReceipt.receiptNumber}`
                  })
                }
                className="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold flex items-center gap-1.5 shadow-sm"
              >
                <Printer className="w-4 h-4" />
                Print / Save PDF
              </Button>
            </div>
          </div>
        </Modal>
      )}

      {/* Statement Modal */}
      {statementStudentId && (
        <StudentStatementModal
          isOpen={isStatementModalOpen}
          onClose={() => setIsStatementModalOpen(false)}
          studentId={statementStudentId}
          studentName={statementStudentName}
        />
      )}
    </div>
  );
};
