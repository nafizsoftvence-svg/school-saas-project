import React, { useState, useEffect } from 'react';
import {
  FileText,
  Calendar,
  CheckCircle2,
  Clock,
  AlertTriangle,
  BookOpen,
  Filter,
  Search,
  ChevronRight,
  Info,
  Paperclip,
  Download,
  GraduationCap,
  Sparkles,
  ArrowRight,
  Check,
  X,
  AlertCircle,
  UserCheck,
  Building,
  Layers,
  ArrowLeft,
  RotateCcw,
  RefreshCw,
  Award,
  FolderOpen
} from 'lucide-react';
import { api } from '../../services/api.js';
import {
  GuardianChildSummary,
  StudentAssignmentItem,
  GuardianChildAssignmentResponse
} from '../../types/index.js';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner.js';
import { Badge } from '../../components/ui/Badge.js';
import { Button } from '../../components/ui/Button.js';
import { Modal } from '../../components/ui/Modal.js';
import { Input } from '../../components/ui/Input.js';

interface GuardianAssignmentsPageProps {
  onNavigate?: (view: string) => void;
  initialStudentId?: string;
}

export const GuardianAssignmentsPage: React.FC<GuardianAssignmentsPageProps> = ({
  onNavigate,
  initialStudentId
}) => {
  // All linked children
  const [children, setChildren] = useState<GuardianChildSummary[]>([]);
  const [selectedChildId, setSelectedChildId] = useState<string | null>(initialStudentId || null);

  // Assignments data
  const [assignmentData, setAssignmentData] = useState<GuardianChildAssignmentResponse | null>(null);
  const [isLoadingChildren, setIsLoadingChildren] = useState<boolean>(true);
  const [isLoadingAssignments, setIsLoadingAssignments] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [authError, setAuthError] = useState<string | null>(null);

  // Filters
  const [subjectFilter, setSubjectFilter] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [startDateFilter, setStartDateFilter] = useState<string>('');
  const [dueDateFilter, setDueDateFilter] = useState<string>('');

  // Selected Assignment for Detail Modal
  const [selectedAssignment, setSelectedAssignment] = useState<StudentAssignmentItem | null>(null);

  // 1. Fetch children
  useEffect(() => {
    const fetchChildren = async () => {
      setIsLoadingChildren(true);
      setAuthError(null);
      try {
        const res = await api.guardian.getChildren();
        const childrenList = Array.isArray(res?.data) ? res.data : Array.isArray(res) ? res : [];
        if (res?.success) {
          setChildren(childrenList);
          if (!selectedChildId && childrenList.length > 0) {
            setSelectedChildId(childrenList?.[0]?.id || null);
          } else if (selectedChildId) {
            const exists = childrenList.some((c: any) => c?.id === selectedChildId);
            if (!exists && childrenList.length > 0) {
              setSelectedChildId(childrenList?.[0]?.id || null);
            }
          }
        } else {
          setAuthError(typeof res.error === 'string' ? res.error : 'Failed to retrieve linked children.');
        }
      } catch (err: any) {
        setAuthError(err?.message || 'Network error occurred.');
      } finally {
        setIsLoadingChildren(false);
      }
    };

    fetchChildren();
  }, []);

  // 2. Fetch assignments
  const fetchAssignments = async () => {
    if (!selectedChildId) return;

    setIsLoadingAssignments(true);
    setError(null);
    try {
      const res = await api.guardian.getChildAssignments(selectedChildId, {
        subjectId: subjectFilter,
        status: statusFilter,
        search: searchQuery,
        startDate: startDateFilter || undefined,
        dueDate: dueDateFilter || undefined
      });

      if (res.success && res.data) {
        setAssignmentData(res.data);
      } else {
        if (res.code === 'FORBIDDEN_STUDENT_ACCESS') {
          setAuthError(typeof res.error === 'string' ? res.error : 'Access restricted.');
        } else {
          setError(typeof res.error === 'string' ? res.error : 'Failed to load assignments.');
        }
      }
    } catch (err: any) {
      setError(err?.message || 'Network error fetching assignments.');
    } finally {
      setIsLoadingAssignments(false);
    }
  };

  useEffect(() => {
    if (selectedChildId) {
      fetchAssignments();
    }
  }, [selectedChildId, subjectFilter, statusFilter, startDateFilter, dueDateFilter]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchAssignments();
  };

  const handleResetFilters = () => {
    setSubjectFilter('ALL');
    setStatusFilter('ALL');
    setSearchQuery('');
    setStartDateFilter('');
    setDueDateFilter('');
  };

  const activeChild = (children || []).find((c) => c.id === selectedChildId) || children?.[0];

  if (isLoadingChildren) {
    return (
      <div className="p-12 flex flex-col items-center justify-center min-h-[450px] space-y-4">
        <LoadingSpinner size="lg" message="Loading your verified scholars..." />
      </div>
    );
  }

  if (authError) {
    return (
      <div className="p-8 max-w-2xl mx-auto space-y-6 text-center">
        <div className="w-16 h-16 rounded-3xl bg-rose-500/20 border border-rose-500/30 text-rose-400 flex items-center justify-center mx-auto">
          <AlertTriangle className="w-8 h-8" />
        </div>
        <div className="space-y-2">
          <h2 className="text-2xl font-bold text-white tracking-tight">Access Restricted</h2>
          <p className="text-sm text-slate-400">{authError}</p>
        </div>
        <div className="flex justify-center gap-3">
          <Button
            id="guardian-asg-back-btn"
            variant="secondary"
            onClick={() => onNavigate && onNavigate('guardian-dashboard')}
          >
            <ArrowLeft className="w-4 h-4 mr-2" /> Back to Dashboard
          </Button>
        </div>
      </div>
    );
  }

  if ((children?.length || 0) === 0) {
    return (
      <div className="p-12 max-w-lg mx-auto text-center space-y-4 rounded-3xl bg-slate-900/60 border border-white/10 p-8">
        <div className="w-14 h-14 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center mx-auto">
          <UserCheck className="w-7 h-7" />
        </div>
        <h3 className="text-xl font-bold text-white">No Linked Scholars Found</h3>
        <p className="text-sm text-slate-400">
          There are currently no student accounts linked to your guardian profile.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      {/* 1. Header & Navigation */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <button
              onClick={() => onNavigate && onNavigate('guardian-dashboard')}
              className="text-xs font-semibold text-slate-400 hover:text-indigo-400 transition-colors flex items-center gap-1"
            >
              <ArrowLeft className="w-3.5 h-3.5" /> Portal Dashboard
            </button>
            <span className="text-slate-600">/</span>
            <span className="text-xs font-semibold text-indigo-400">Graded Assignments</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight flex items-center gap-3">
            <FileText className="w-8 h-8 text-indigo-400" />
            Scholar Assignments
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Track major coursework, project milestones, grading weights, and deadlines for your scholars.
          </p>
        </div>

        {/* Quick Links */}
        <div className="flex flex-wrap items-center gap-2">
          <Button
            id="guardian-nav-hw"
            variant="outline"
            size="sm"
            onClick={() => onNavigate && onNavigate('guardian-homework')}
            className="text-xs border-white/10 hover:border-indigo-500/40"
          >
            <BookOpen className="w-3.5 h-3.5 mr-1.5 text-amber-400" />
            Homework
          </Button>
          <Button
            id="guardian-nav-materials"
            variant="outline"
            size="sm"
            onClick={() => onNavigate && onNavigate('guardian-materials')}
            className="text-xs border-white/10 hover:border-indigo-500/40"
          >
            <FolderOpen className="w-3.5 h-3.5 mr-1.5 text-emerald-400" />
            Study Materials
          </Button>
          <Button
            id="guardian-nav-announcements"
            variant="outline"
            size="sm"
            onClick={() => onNavigate && onNavigate('guardian-announcements')}
            className="text-xs border-white/10 hover:border-indigo-500/40"
          >
            <Sparkles className="w-3.5 h-3.5 mr-1.5 text-purple-400" />
            Announcements
          </Button>
        </div>
      </div>

      {/* 2. Multi-Child Selector */}
      <div className="rounded-3xl bg-slate-900/60 border border-white/10 p-5 backdrop-blur-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400 shrink-0">
              <GraduationCap className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-semibold text-indigo-400 uppercase tracking-wider">Active Scholar</div>
              <div className="text-sm font-bold text-white">
                {activeChild ? `${activeChild.name} (${activeChild.className} - ${activeChild.sectionName})` : 'Select Scholar'}
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {(children || []).map((child) => {
              const isSelected = child.id === selectedChildId;
              return (
                <button
                  key={child.id}
                  id={`select-child-asg-${child.id}`}
                  onClick={() => setSelectedChildId(child.id)}
                  className={`flex items-center gap-3 px-4 py-2.5 rounded-2xl text-xs font-bold transition-all border ${
                    isSelected
                      ? 'bg-indigo-600 text-white border-indigo-400 shadow-lg shadow-indigo-500/25 scale-[1.02]'
                      : 'bg-slate-800/80 text-slate-300 border-white/5 hover:border-white/20 hover:bg-slate-800'
                  }`}
                >
                  <div
                    className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-black ${
                      isSelected ? 'bg-white text-indigo-700' : 'bg-indigo-500/20 text-indigo-300'
                    }`}
                  >
                    {child.name.charAt(0)}
                  </div>
                  <div className="text-left">
                    <div>{child.name}</div>
                    <div className={`text-[10px] font-normal ${isSelected ? 'text-indigo-200' : 'text-slate-400'}`}>
                      {child.className} • Sec {child.sectionName}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* 3. Stats Overview */}
      {assignmentData && (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="rounded-3xl bg-slate-900/60 border border-white/10 p-5 backdrop-blur-xl">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-slate-400">Total Assignments</span>
              <div className="w-8 h-8 rounded-xl bg-slate-800 flex items-center justify-center text-slate-300">
                <FileText className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl sm:text-3xl font-black text-white mt-2">
              {assignmentData?.stats?.total ?? 0}
            </div>
            <div className="text-[11px] text-slate-500 mt-1">Class {activeChild?.className} curriculum</div>
          </div>

          <div className="rounded-3xl bg-slate-900/60 border border-emerald-500/20 p-5 backdrop-blur-xl">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-emerald-300">Active</span>
              <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                <CheckCircle2 className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl sm:text-3xl font-black text-emerald-400 mt-2">
              {assignmentData?.stats?.active ?? 0}
            </div>
            <div className="text-[11px] text-emerald-500/80 mt-1">Open for submissions</div>
          </div>

          <div className="rounded-3xl bg-slate-900/60 border border-amber-500/20 p-5 backdrop-blur-xl">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-amber-300">Due Soon (≤ 3 Days)</span>
              <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
                <Clock className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl sm:text-3xl font-black text-amber-400 mt-2">
              {assignmentData?.stats?.dueSoon ?? 0}
            </div>
            <div className="text-[11px] text-amber-500/80 mt-1">Approaching final deadline</div>
          </div>

          <div className="rounded-3xl bg-slate-900/60 border border-rose-500/20 p-5 backdrop-blur-xl">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-rose-300">Overdue</span>
              <div className="w-8 h-8 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center">
                <AlertTriangle className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl sm:text-3xl font-black text-rose-400 mt-2">
              {assignmentData?.stats?.overdue ?? 0}
            </div>
            <div className="text-[11px] text-rose-500/80 mt-1">Late submission window</div>
          </div>
        </div>
      )}

      {/* 4. Filter Toolbar */}
      <div className="rounded-3xl bg-slate-900/60 border border-white/10 p-5 backdrop-blur-xl space-y-4">
        <form onSubmit={handleSearchSubmit} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              id="guardian-asg-search-input"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search assignment title, topic, teacher..."
              className="w-full bg-slate-800/80 border border-white/10 rounded-2xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-400 transition-colors"
            />
          </div>

          <div>
            <select
              id="guardian-asg-subject-filter"
              value={subjectFilter}
              onChange={(e) => setSubjectFilter(e.target.value)}
              className="w-full bg-slate-800/80 border border-white/10 rounded-2xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-indigo-400 transition-colors"
            >
              <option value="ALL">All Subjects</option>
              {(assignmentData?.subjects || []).map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.code})
                </option>
              ))}
            </select>
          </div>

          <div>
            <select
              id="guardian-asg-status-filter"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full bg-slate-800/80 border border-white/10 rounded-2xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-indigo-400 transition-colors"
            >
              <option value="ALL">All Statuses</option>
              <option value="active">Active</option>
              <option value="due_soon">Due Soon (≤ 3 Days)</option>
              <option value="overdue">Overdue</option>
              <option value="upcoming">Upcoming</option>
            </select>
          </div>

          <div className="flex gap-2">
            <input
              type="date"
              id="guardian-asg-date-filter"
              value={dueDateFilter}
              onChange={(e) => setDueDateFilter(e.target.value)}
              className="w-full bg-slate-800/80 border border-white/10 rounded-2xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-400 transition-colors"
            />
            <Button
              type="button"
              id="guardian-asg-reset-btn"
              variant="secondary"
              size="sm"
              onClick={handleResetFilters}
              title="Reset Filters"
              className="shrink-0 px-3"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </Button>
          </div>
        </form>
      </div>

      {/* 5. Assignment Items */}
      {isLoadingAssignments ? (
        <div className="p-12 flex flex-col items-center justify-center min-h-[300px]">
          <LoadingSpinner size="md" message="Fetching course assignments..." />
        </div>
      ) : error ? (
        <div className="p-8 text-center rounded-3xl bg-rose-500/10 border border-rose-500/20 max-w-xl mx-auto space-y-3">
          <AlertCircle className="w-8 h-8 text-rose-400 mx-auto" />
          <div className="text-sm font-semibold text-white">Error Loading Assignments</div>
          <p className="text-xs text-slate-400">{error}</p>
          <Button onClick={fetchAssignments} variant="secondary" size="sm">
            <RefreshCw className="w-3.5 h-3.5 mr-2" /> Try Again
          </Button>
        </div>
      ) : !assignmentData || !Array.isArray(assignmentData.data) || assignmentData.data.length === 0 ? (
        <div className="p-12 text-center rounded-3xl bg-slate-900/40 border border-white/10 max-w-lg mx-auto space-y-4">
          <div className="w-14 h-14 rounded-2xl bg-slate-800 text-slate-400 flex items-center justify-center mx-auto">
            <FileText className="w-7 h-7" />
          </div>
          <div className="space-y-1">
            <h3 className="text-base font-bold text-white">No Assignments Found</h3>
            <p className="text-xs text-slate-400">
              No assignments match your current criteria for {activeChild?.name}.
            </p>
          </div>
          {(subjectFilter !== 'ALL' || statusFilter !== 'ALL' || searchQuery || dueDateFilter) && (
            <Button onClick={handleResetFilters} variant="secondary" size="sm">
              Clear All Filters
            </Button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {(assignmentData.data || []).map((item) => {
            const isDueSoon = item.isDueSoon && !item.isOverdue;
            const isOverdue = item.isOverdue;

            return (
              <div
                key={item.id}
                id={`guardian-asg-card-${item.id}`}
                onClick={() => setSelectedAssignment(item)}
                className="group relative rounded-3xl bg-slate-900/60 border border-white/10 hover:border-indigo-500/40 p-6 backdrop-blur-xl transition-all duration-200 hover:-translate-y-0.5 cursor-pointer flex flex-col justify-between"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between gap-2">
                    <span className="px-3 py-1 rounded-full text-[11px] font-bold bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
                      {item.subjectName}
                    </span>

                    <div className="flex items-center gap-2">
                      {item.totalMarks && (
                        <span className="px-2.5 py-0.5 rounded-lg text-[10px] font-mono bg-slate-800 text-indigo-300 border border-indigo-500/20 flex items-center gap-1">
                          <Award className="w-3 h-3" />
                          {item.totalMarks} Marks
                        </span>
                      )}

                      {isOverdue ? (
                        <Badge variant="danger" className="text-[10px] uppercase font-bold">
                          <AlertTriangle className="w-3 h-3 mr-1" /> Overdue
                        </Badge>
                      ) : isDueSoon ? (
                        <Badge variant="warning" className="text-[10px] uppercase font-bold">
                          <Clock className="w-3 h-3 mr-1" /> Due in {item.daysRemaining}d
                        </Badge>
                      ) : (
                        <Badge variant="success" className="text-[10px] uppercase font-bold">
                          <CheckCircle2 className="w-3 h-3 mr-1" /> Active
                        </Badge>
                      )}
                    </div>
                  </div>

                  <div>
                    <h3 className="text-base font-bold text-white group-hover:text-indigo-300 transition-colors line-clamp-1">
                      {item.title}
                    </h3>
                    <p className="text-xs text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                      {item.description}
                    </p>
                  </div>
                </div>

                <div className="mt-5 pt-4 border-t border-white/5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-slate-400">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-full bg-slate-800 text-slate-300 flex items-center justify-center text-[10px] font-bold">
                      {item.teacherName?.charAt(0) || 'T'}
                    </div>
                    <span>{item.teacherName}</span>
                  </div>

                  <div className="flex items-center gap-4 text-[11px]">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5 text-slate-500" />
                      Due: <strong className="text-slate-200">{item.dueDate}</strong>
                    </span>

                    {item.attachmentName && (
                      <span className="flex items-center gap-1 text-indigo-400/90 font-mono">
                        <Paperclip className="w-3 h-3" />
                        Attachment
                      </span>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* 6. Assignment Detail Modal */}
      <Modal
        isOpen={!!selectedAssignment}
        onClose={() => setSelectedAssignment(null)}
        title="Assignment Details & Requirements"
      >
        {selectedAssignment && (
          <div className="space-y-6">
            <div className="flex items-start justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="px-3 py-1 rounded-full text-xs font-bold bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
                    {selectedAssignment.subjectName}
                  </span>
                  {selectedAssignment.totalMarks && (
                    <span className="px-2.5 py-0.5 rounded-lg text-xs font-mono bg-slate-800 text-indigo-300 border border-indigo-500/20">
                      {selectedAssignment.totalMarks} Total Marks
                    </span>
                  )}
                </div>
                <h2 className="text-xl font-bold text-white mt-2">{selectedAssignment.title}</h2>
                <div className="text-xs text-slate-400">
                  Instructor <strong className="text-slate-200">{selectedAssignment.teacherName}</strong> • {activeChild?.className} ({activeChild?.sectionName})
                </div>
              </div>

              {selectedAssignment.isOverdue ? (
                <Badge variant="danger" className="text-xs uppercase font-bold">
                  Overdue
                </Badge>
              ) : selectedAssignment.isDueSoon ? (
                <Badge variant="warning" className="text-xs uppercase font-bold">
                  Due in {selectedAssignment.daysRemaining} days
                </Badge>
              ) : (
                <Badge variant="success" className="text-xs uppercase font-bold">
                  Active
                </Badge>
              )}
            </div>

            {/* Schedule grid */}
            <div className="grid grid-cols-2 gap-3 p-4 rounded-2xl bg-slate-900 border border-white/5 text-xs">
              <div>
                <span className="text-slate-500 block mb-1">Start / Assigned Date</span>
                <span className="text-slate-200 font-semibold">{selectedAssignment.startDate}</span>
              </div>
              <div>
                <span className="text-slate-500 block mb-1">Submission Deadline</span>
                <span className="text-indigo-400 font-semibold">{selectedAssignment.dueDate}</span>
              </div>
            </div>

            {/* Assignment Brief */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">Assignment Brief &amp; Guidelines</h4>
              <div className="p-4 rounded-2xl bg-slate-900/90 border border-white/5 text-xs text-slate-300 leading-relaxed whitespace-pre-wrap">
                {selectedAssignment.description}
              </div>
            </div>

            {/* File Attachment */}
            {selectedAssignment.attachmentName && (
              <div className="space-y-2">
                <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">Reference Attachment</h4>
                <div className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-900 border border-white/10 hover:border-indigo-500/30 transition-colors">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center">
                      <FileText className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-white">{selectedAssignment.attachmentName}</div>
                      <div className="text-[10px] text-slate-400">Course Materials &amp; Templates</div>
                    </div>
                  </div>

                  <a
                    href={selectedAssignment.attachmentUrl || '#'}
                    target="_blank"
                    rel="noreferrer"
                    className="px-3 py-1.5 rounded-xl bg-slate-800 text-indigo-300 hover:bg-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-colors"
                  >
                    <Download className="w-3.5 h-3.5" />
                    Download
                  </a>
                </div>
              </div>
            )}

            {/* Guardian Submission Note */}
            <div className="p-4 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 text-xs text-indigo-200/90 flex items-start gap-3">
              <Info className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-indigo-300 block mb-0.5">Parent Review Mode</strong>
                Scholars submit files, documents, and code directly from their student dashboard. Guardians can verify guidelines and milestones.
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <Button onClick={() => setSelectedAssignment(null)} variant="secondary">
                Close
              </Button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};
