import React, { useState, useEffect } from 'react';
import {
  Award,
  Calendar,
  Clock,
  TrendingUp,
  Search,
  Filter,
  GraduationCap,
  FileText,
  AlertTriangle,
  ArrowLeft,
  RotateCcw,
  CheckCircle2,
  AlertCircle,
  Printer,
  Info,
  CalendarDays,
  Layers,
  Sparkles,
  BookOpen,
  ChevronDown,
  ChevronUp,
  Download,
  Trophy,
  ShieldCheck,
  UserCheck
} from 'lucide-react';
import { api } from '../../services/api.js';
import { downloadElementPdf, triggerSafePrint } from '../../utils/printPdf.js';
import {
  GuardianChildSummary,
  StudentExamResult,
  GuardianChildResultsResponse
} from '../../types/index.js';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner.js';
import { Badge } from '../../components/ui/Badge.js';
import { Button } from '../../components/ui/Button.js';
import { Modal } from '../../components/ui/Modal.js';
import { Input } from '../../components/ui/Input.js';

interface GuardianResultsPageProps {
  onNavigate?: (view: string) => void;
  initialStudentId?: string;
}

export const GuardianResultsPage: React.FC<GuardianResultsPageProps> = ({
  onNavigate,
  initialStudentId
}) => {
  // All linked children
  const [children, setChildren] = useState<GuardianChildSummary[]>([]);
  const [selectedChildId, setSelectedChildId] = useState<string | null>(initialStudentId || null);

  // Results data
  const [resultsData, setResultsData] = useState<GuardianChildResultsResponse | null>(null);
  const [isLoadingChildren, setIsLoadingChildren] = useState<boolean>(true);
  const [isLoadingResults, setIsLoadingResults] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [authError, setAuthError] = useState<string | null>(null);

  // Filters
  const [sessionFilter, setSessionFilter] = useState<string>('ALL');
  const [examFilter, setExamFilter] = useState<string>('ALL');
  const [yearFilter, setYearFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Expanded report cards
  const [expandedResultIds, setExpandedResultIds] = useState<Set<string>>(new Set());

  // Printable Report Card Modal
  const [reportCardModalResult, setReportCardModalResult] = useState<StudentExamResult | null>(null);

  // 1. Fetch children
  useEffect(() => {
    const fetchChildren = async () => {
      setIsLoadingChildren(true);
      setAuthError(null);
      try {
        const res = await api.guardian.getChildren();
        const childrenList = Array.isArray(res?.data) ? res.data : Array.isArray(res) ? res : [];
        if (res?.success) {
          setChildren(childrenList);
          if (!selectedChildId && childrenList.length > 0) {
            setSelectedChildId(childrenList?.[0]?.id || null);
          } else if (selectedChildId) {
            const exists = childrenList.some((c: any) => c?.id === selectedChildId);
            if (!exists && childrenList.length > 0) {
              setSelectedChildId(childrenList?.[0]?.id || null);
            }
          }
        } else {
          setAuthError(typeof res.error === 'string' ? res.error : 'Failed to retrieve linked scholars.');
        }
      } catch (err: any) {
        setAuthError(err?.message || 'Error communicating with parent security services.');
      } finally {
        setIsLoadingChildren(false);
      }
    };

    fetchChildren();
  }, []);

  // 2. Fetch results for selected child
  const fetchResults = async () => {
    if (!selectedChildId) return;

    setIsLoadingResults(true);
    setError(null);
    try {
      const res = await api.guardian.getChildResults(selectedChildId, {
        academicSessionId: sessionFilter,
        examId: examFilter,
        academicYear: yearFilter,
        search: searchQuery
      });

      if (res.success && res.data) {
        const payload = res.data as any;
        const normalizedData: GuardianChildResultsResponse = Array.isArray(payload)
          ? {
              student: (children || []).find((c) => c.id === selectedChildId) as any,
              data: payload,
              total: payload.length,
              summary: {
                latestResult: payload?.[0] || null,
                totalExamsTaken: payload.length,
                cumulativeGPA: 0,
                currentSessionGPA: 0,
                overallGrade: 'N/A',
                academicStanding: 'Good Standing'
              },
              availableSessions: [],
              availableExams: [],
              availableYears: []
            }
          : {
              ...payload,
              data: Array.isArray(payload.data) ? payload.data : []
            };

        setResultsData(normalizedData);
        // Expand the most recent result by default
        if (normalizedData.data && normalizedData.data.length > 0) {
          const firstId = normalizedData.data?.[0]?.id;
          if (firstId) {
            setExpandedResultIds(new Set([firstId]));
          }
        }
      } else {
        if (res.code === 'FORBIDDEN_STUDENT_ACCESS') {
          setAuthError(typeof res.error === 'string' ? res.error : 'Security violation: Access denied.');
        } else {
          setError(typeof res.error === 'string' ? res.error : 'Failed to load examination results.');
        }
      }
    } catch (err: any) {
      setError(err?.message || 'Network error fetching examination results.');
    } finally {
      setIsLoadingResults(false);
    }
  };

  useEffect(() => {
    if (selectedChildId) {
      fetchResults();
    }
  }, [selectedChildId, sessionFilter, examFilter, yearFilter]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchResults();
  };

  const handleResetFilters = () => {
    setSessionFilter('ALL');
    setExamFilter('ALL');
    setYearFilter('ALL');
    setSearchQuery('');
  };

  const toggleExpand = (id: string) => {
    setExpandedResultIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const activeChild = (children || []).find((c) => c.id === selectedChildId) || children?.[0];

  const getResultStatusBadge = (status: string) => {
    switch (status) {
      case 'DISTINCTION':
        return <Badge variant="success" className="px-2.5 py-1 text-xs">Distinction / Honors</Badge>;
      case 'PASSED':
        return <Badge variant="info" className="px-2.5 py-1 text-xs">Passed</Badge>;
      case 'FAILED':
        return <Badge variant="danger" className="px-2.5 py-1 text-xs">Failed</Badge>;
      default:
        return <Badge variant="secondary" className="px-2.5 py-1 text-xs">{status}</Badge>;
    }
  };

  const getGradeBadge = (grade: string) => {
    if (grade === 'A+' || grade === 'A') {
      return <span className="px-2 py-0.5 rounded-md font-bold text-xs bg-emerald-500/10 text-emerald-300 border border-emerald-500/20">{grade}</span>;
    }
    if (grade === 'B+' || grade === 'B') {
      return <span className="px-2 py-0.5 rounded-md font-bold text-xs bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">{grade}</span>;
    }
    if (grade === 'C+' || grade === 'C') {
      return <span className="px-2 py-0.5 rounded-md font-bold text-xs bg-amber-500/10 text-amber-300 border border-amber-500/20">{grade}</span>;
    }
    return <span className="px-2 py-0.5 rounded-md font-bold text-xs bg-rose-500/10 text-rose-300 border border-rose-500/20">{grade}</span>;
  };

  if (isLoadingChildren) {
    return (
      <div className="p-12 flex flex-col items-center justify-center min-h-[450px] space-y-4">
        <LoadingSpinner size="lg" message="Loading your verified scholars..." />
      </div>
    );
  }

  if (authError) {
    return (
      <div className="p-8 max-w-2xl mx-auto space-y-6 text-center">
        <div className="w-16 h-16 rounded-3xl bg-rose-500/20 border border-rose-500/30 text-rose-400 flex items-center justify-center mx-auto shadow-lg shadow-rose-950/40">
          <AlertTriangle className="w-8 h-8" />
        </div>
        <div className="space-y-2">
          <h2 className="text-2xl font-bold text-white tracking-tight">Access Restricted</h2>
          <p className="text-sm text-slate-400">{authError}</p>
        </div>
        <div className="flex justify-center gap-3">
          <Button
            id="guardian-results-back-btn"
            variant="secondary"
            onClick={() => onNavigate && onNavigate('guardian-dashboard')}
          >
            <ArrowLeft className="w-4 h-4 mr-2" /> Back to Dashboard
          </Button>
        </div>
      </div>
    );
  }

  if (children.length === 0) {
    return (
      <div className="p-12 max-w-lg mx-auto text-center space-y-4 rounded-3xl bg-slate-900/60 border border-white/10 p-8">
        <div className="w-14 h-14 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center mx-auto">
          <GraduationCap className="w-7 h-7" />
        </div>
        <h3 className="text-xl font-bold text-white">No Linked Scholars Found</h3>
        <p className="text-sm text-slate-400">
          There are currently no student accounts linked to your guardian profile. Please contact school administration.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      {/* 1. Header & Hub Navigation */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <button
              onClick={() => onNavigate && onNavigate('guardian-dashboard')}
              className="text-xs font-semibold text-slate-400 hover:text-amber-400 transition-colors flex items-center gap-1"
            >
              <ArrowLeft className="w-3.5 h-3.5" /> Portal Dashboard
            </button>
            <span className="text-slate-600">/</span>
            <span className="text-xs font-semibold text-amber-400">Results &amp; Marks</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight flex items-center gap-3">
            <Award className="w-8 h-8 text-amber-400" />
            Scholar Examination Results &amp; Report Cards
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Official published grades, GPA records, subject mark sheets, and academic progress transcripts for your scholars.
          </p>
        </div>

        {/* Navigation Quick Links */}
        <div className="flex flex-wrap items-center gap-2">
          <Button
            id="guardian-nav-exams"
            variant="outline"
            size="sm"
            onClick={() => onNavigate && onNavigate('guardian-examinations')}
            className="text-xs border-white/10 hover:border-amber-500/40"
          >
            <CalendarDays className="w-3.5 h-3.5 mr-1.5 text-indigo-400" />
            Exam Schedules
          </Button>
          <Button
            id="guardian-nav-progress"
            variant="outline"
            size="sm"
            onClick={() => onNavigate && onNavigate('guardian-progress')}
            className="text-xs border-white/10 hover:border-amber-500/40"
          >
            <TrendingUp className="w-3.5 h-3.5 mr-1.5 text-emerald-400" />
            Academic Progress
          </Button>
        </div>
      </div>

      {/* 2. Multi-Child Selector */}
      <div className="rounded-3xl bg-slate-900/60 border border-white/10 p-5 backdrop-blur-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 shrink-0">
              <GraduationCap className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-semibold text-amber-400 uppercase tracking-wider">Active Scholar</div>
              <div className="text-sm font-bold text-white">
                {activeChild ? `${activeChild.name} (${activeChild.className} - ${activeChild.sectionName})` : 'Select Scholar'}
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {(children || []).map((child) => {
              const isSelected = child.id === selectedChildId;
              return (
                <button
                  key={child.id}
                  id={`select-child-res-${child.id}`}
                  onClick={() => setSelectedChildId(child.id)}
                  className={`flex items-center gap-3 px-4 py-2.5 rounded-2xl text-xs font-bold transition-all border ${
                    isSelected
                      ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-lg shadow-amber-500/20 scale-[1.02]'
                      : 'bg-slate-800/80 text-slate-300 border-white/5 hover:border-white/20 hover:bg-slate-800'
                  }`}
                >
                  <div
                    className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-black ${
                      isSelected ? 'bg-slate-950 text-amber-400' : 'bg-amber-500/20 text-amber-300'
                    }`}
                  >
                    {child.name.charAt(0)}
                  </div>
                  <div className="text-left">
                    <div>{child.name}</div>
                    <div className={`text-[10px] ${isSelected ? 'text-slate-900 font-semibold' : 'text-slate-400'}`}>
                      {child.className} • {child.rollNumber}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* 3. Comprehensive Summary Card */}
      {resultsData && resultsData.summary && (
        <div className="rounded-3xl bg-gradient-to-br from-slate-900/90 via-slate-900/70 to-indigo-950/40 border border-white/10 p-6 backdrop-blur-xl shadow-xl">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
            <div className="space-y-2 max-w-lg">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" /> Institutional Academic Performance
                </span>
                <span className="text-slate-500">•</span>
                <span className="text-xs text-slate-400">{resultsData.summary.academicStanding}</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                {resultsData.summary.latestResult ? resultsData.summary.latestResult.examName : 'Examination Record'}
              </h2>
              <p className="text-xs text-slate-300 leading-relaxed">
                {activeChild?.name} is currently enrolled in {activeChild?.className} ({activeChild?.sectionName}) with {resultsData.summary.totalExamsTaken} evaluated institutional examination sittings on record.
              </p>
            </div>

            {/* Metrics Display Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
              <div className="p-3.5 rounded-2xl bg-white/[0.03] border border-white/10">
                <div className="text-[10px] uppercase font-bold text-slate-400">Cumulative GPA</div>
                <div className="text-2xl font-black text-amber-400 mt-1">
                  {(resultsData.summary.cumulativeGPA ?? 0) > 0 ? Number(resultsData.summary.cumulativeGPA).toFixed(2) : 'N/A'}
                </div>
                <div className="text-[10px] text-slate-400">Out of 4.00</div>
              </div>

              <div className="p-3.5 rounded-2xl bg-white/[0.03] border border-white/10">
                <div className="text-[10px] uppercase font-bold text-slate-400">Latest Exam %</div>
                <div className="text-2xl font-black text-emerald-400 mt-1">
                  {resultsData.summary.latestResult
                    ? `${Number(resultsData.summary.latestResult.summary?.overallPercentage ?? 0).toFixed(1)}%`
                    : 'N/A'}
                </div>
                <div className="text-[10px] text-slate-400">
                  {resultsData.summary.latestResult
                    ? `${resultsData.summary.latestResult.summary.totalObtainedMarks}/${resultsData.summary.latestResult.summary.totalFullMarks}`
                    : 'No data'}
                </div>
              </div>

              <div className="p-3.5 rounded-2xl bg-white/[0.03] border border-white/10">
                <div className="text-[10px] uppercase font-bold text-slate-400">Overall Grade</div>
                <div className="text-2xl font-black text-indigo-400 mt-1">
                  {resultsData.summary.overallGrade}
                </div>
                <div className="text-[10px] text-slate-400">Scale Standards</div>
              </div>

              <div className="p-3.5 rounded-2xl bg-white/[0.03] border border-white/10">
                <div className="text-[10px] uppercase font-bold text-slate-400">Class Standing</div>
                <div className="text-2xl font-black text-purple-400 mt-1">
                  {resultsData.summary.latestResult?.summary.classRank
                    ? `#${resultsData.summary.latestResult.summary.classRank}`
                    : 'Top Tier'}
                </div>
                <div className="text-[10px] text-slate-400">
                  {resultsData.summary.latestResult?.summary.totalStudentsInClass
                    ? `Of ${resultsData.summary.latestResult.summary.totalStudentsInClass} Scholars`
                    : 'Class Cohort'}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 4. Filter Bar */}
      <div className="rounded-3xl bg-slate-900/60 border border-white/10 p-5 backdrop-blur-xl space-y-4">
        <form onSubmit={handleSearchSubmit} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Search */}
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              id="guardian-results-search-input"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search exam, subject, grade..."
              className="w-full pl-9 pr-3 py-2 bg-slate-800/80 border border-white/10 rounded-2xl text-xs text-white placeholder-slate-400 focus:outline-hidden focus:border-amber-400"
            />
          </div>

          {/* Session Filter */}
          <div>
            <select
              id="guardian-results-session-select"
              value={sessionFilter}
              onChange={(e) => setSessionFilter(e.target.value)}
              className="w-full px-3 py-2 bg-slate-800/80 border border-white/10 rounded-2xl text-xs text-slate-200 focus:outline-hidden focus:border-amber-400"
            >
              <option value="ALL">All Academic Sessions</option>
              {resultsData?.availableSessions?.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
          </div>

          {/* Exam Filter */}
          <div>
            <select
              id="guardian-results-exam-select"
              value={examFilter}
              onChange={(e) => setExamFilter(e.target.value)}
              className="w-full px-3 py-2 bg-slate-800/80 border border-white/10 rounded-2xl text-xs text-slate-200 focus:outline-hidden focus:border-amber-400"
            >
              <option value="ALL">All Examination Sittings</option>
              {resultsData?.availableExams?.map((e) => (
                <option key={e.id} value={e.id}>
                  {e.name}
                </option>
              ))}
            </select>
          </div>

          {/* Academic Year Filter & Reset */}
          <div className="flex items-center gap-2">
            <select
              id="guardian-results-year-select"
              value={yearFilter}
              onChange={(e) => setYearFilter(e.target.value)}
              className="flex-1 px-3 py-2 bg-slate-800/80 border border-white/10 rounded-2xl text-xs text-slate-200 focus:outline-hidden focus:border-amber-400"
            >
              <option value="ALL">All Academic Years</option>
              {resultsData?.availableYears?.map((yr) => (
                <option key={yr} value={yr}>
                  {yr}
                </option>
              ))}
            </select>

            <Button
              id="guardian-results-reset-btn"
              type="button"
              variant="outline"
              size="sm"
              onClick={handleResetFilters}
              title="Reset Filters"
              className="border-white/10 text-slate-400 hover:text-white px-2.5"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </Button>
          </div>
        </form>
      </div>

      {/* 5. Examination Results History List */}
      {isLoadingResults ? (
        <div className="p-12 flex flex-col items-center justify-center min-h-[300px] space-y-4">
          <LoadingSpinner size="md" message="Loading examination results & transcripts..." />
        </div>
      ) : error ? (
        <div className="p-8 rounded-3xl bg-rose-500/10 border border-rose-500/20 text-center space-y-3">
          <AlertCircle className="w-8 h-8 text-rose-400 mx-auto" />
          <h3 className="text-base font-bold text-white">Unable to load examination results</h3>
          <p className="text-xs text-slate-400 max-w-md mx-auto">{error}</p>
          <Button size="sm" variant="secondary" onClick={fetchResults}>
            Retry Fetch
          </Button>
        </div>
      ) : !resultsData || !Array.isArray(resultsData.data) || resultsData.data.length === 0 ? (
        <div className="p-12 rounded-3xl bg-slate-900/40 border border-white/5 text-center space-y-4">
          <div className="w-14 h-14 rounded-2xl bg-slate-800/80 border border-white/10 flex items-center justify-center mx-auto text-slate-400">
            <Award className="w-7 h-7" />
          </div>
          <h3 className="text-lg font-bold text-white">No Examination Results Published</h3>
          <p className="text-xs text-slate-400 max-w-md mx-auto">
            No published results match your selected filters for {activeChild?.name}. Results will be accessible here as soon as approved and published by the Academic Board.
          </p>
          <Button size="sm" variant="outline" onClick={handleResetFilters} className="border-white/10">
            Clear Filters
          </Button>
        </div>
      ) : (
        <div className="space-y-6">
          <div className="flex items-center justify-between px-1">
            <div className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              {resultsData.data?.length || 0} Published {(resultsData.data?.length || 0) === 1 ? 'Report Card' : 'Report Cards'}
            </div>
            <div className="text-xs text-slate-400">
              Scholar: <span className="font-semibold text-amber-400">{activeChild?.name} ({activeChild?.admissionNumber})</span>
            </div>
          </div>

          <div className="space-y-5">
            {(resultsData.data || []).map((result) => {
              const isExpanded = expandedResultIds.has(result.id);
              return (
                <div
                  key={result.id}
                  id={`result-report-${result.id}`}
                  className="rounded-3xl bg-slate-900/60 border border-white/10 overflow-hidden backdrop-blur-xl transition-all"
                >
                  {/* Result Header Accordion Bar */}
                  <div
                    onClick={() => toggleExpand(result.id)}
                    className="p-6 flex flex-col md:flex-row md:items-center justify-between gap-4 cursor-pointer hover:bg-white/[0.02] transition-colors"
                  >
                    <div className="space-y-1.5">
                      <div className="flex items-center gap-2.5 flex-wrap">
                        <span className="text-xs font-bold px-2.5 py-0.5 rounded-lg bg-amber-500/10 text-amber-300 border border-amber-500/20">
                          {result.academicYear}
                        </span>
                        <span className="text-xs font-medium text-slate-400">{result.term}</span>
                        {getResultStatusBadge(result.summary.resultStatus)}
                      </div>

                      <h3 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
                        {result.examName}
                      </h3>

                      <div className="text-xs text-slate-400 flex items-center gap-3">
                        <span>Published: <strong className="text-slate-300">{result.publishDate}</strong></span>
                        <span>•</span>
                        <span>Class: <strong className="text-slate-300">{result.className} - {result.sectionName}</strong></span>
                      </div>
                    </div>

                    {/* Summary Badges on Header */}
                    <div className="flex items-center gap-3 sm:gap-4">
                      <div className="text-right">
                        <div className="text-xs text-slate-400">Overall Score</div>
                        <div className="text-lg font-black text-emerald-400">
                          {Number(result.summary?.overallPercentage ?? 0).toFixed(1)}%
                        </div>
                        <div className="text-[10px] text-slate-500">
                          {result.summary.totalObtainedMarks} / {result.summary.totalFullMarks}
                        </div>
                      </div>

                      <div className="text-right pl-3 border-l border-white/10">
                        <div className="text-xs text-slate-400">Term GPA</div>
                        <div className="text-lg font-black text-amber-400">
                          {Number(result.summary?.gpa ?? 0).toFixed(2)}
                        </div>
                        <div className="text-[10px] text-slate-500">
                          Grade {result.summary.overallGrade}
                        </div>
                      </div>

                      <div className="p-2 rounded-xl bg-slate-800 border border-white/10 text-slate-300 ml-2">
                        {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                      </div>
                    </div>
                  </div>

                  {/* Collapsible Subject Score Breakdown Table */}
                  {isExpanded && (
                    <div className="px-6 pb-6 pt-2 border-t border-white/5 space-y-6 animate-in fade-in duration-200">
                      {/* Responsive Table */}
                      <div className="overflow-x-auto rounded-2xl border border-white/10 bg-slate-950/40">
                        <table className="w-full text-left text-xs">
                          <thead>
                            <tr className="border-b border-white/10 bg-slate-900/80 text-slate-400 uppercase font-semibold">
                              <th className="py-3.5 px-4">Subject &amp; Code</th>
                              <th className="py-3.5 px-4 text-center">Credits</th>
                              <th className="py-3.5 px-4 text-center">Full Marks</th>
                              <th className="py-3.5 px-4 text-center">Pass Marks</th>
                              <th className="py-3.5 px-4 text-center">Obtained Marks</th>
                              <th className="py-3.5 px-4 text-center">Percentage</th>
                              <th className="py-3.5 px-4 text-center">Grade</th>
                              <th className="py-3.5 px-4 text-center">Grade Point</th>
                              <th className="py-3.5 px-4 text-center">Status</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-white/5">
                            {(result.subjectScores || []).map((score) => (
                              <tr key={score.id} className="hover:bg-white/[0.02] transition-colors">
                                <td className="py-3.5 px-4">
                                  <div className="font-bold text-white">{score.subjectName}</div>
                                  <div className="text-[11px] font-mono text-amber-400/80">{score.subjectCode}</div>
                                  {score.remarks && (
                                    <div className="text-[10px] text-slate-400 mt-1 italic">
                                      "{score.remarks}"
                                    </div>
                                  )}
                                </td>
                                <td className="py-3.5 px-4 text-center text-slate-300 font-medium">{score.credits || 3}</td>
                                <td className="py-3.5 px-4 text-center text-slate-300">{score.fullMarks}</td>
                                <td className="py-3.5 px-4 text-center text-slate-400">{score.passMarks}</td>
                                <td className="py-3.5 px-4 text-center font-bold text-white">
                                  {score.obtainedMarks}
                                  {score.theoryMarks !== undefined && score.practicalMarks !== undefined && (
                                    <span className="text-[10px] block text-slate-400 font-normal">
                                      (Th: {score.theoryMarks}, Pr: {score.practicalMarks})
                                    </span>
                                  )}
                                </td>
                                <td className="py-3.5 px-4 text-center font-bold text-emerald-400">
                                  {Number(score?.percentage ?? 0).toFixed(1)}%
                                </td>
                                <td className="py-3.5 px-4 text-center">
                                  {getGradeBadge(score.grade)}
                                </td>
                                <td className="py-3.5 px-4 text-center font-mono font-bold text-slate-200">
                                  {Number(score?.gradePoint ?? 0).toFixed(1)}
                                </td>
                                <td className="py-3.5 px-4 text-center">
                                  <span className={`px-2 py-0.5 rounded-md font-bold text-[10px] ${
                                    score.status === 'PASSED'
                                      ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                                      : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                                  }`}>
                                    {score.status}
                                  </span>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>

                      {/* Summary Footnote & Actions */}
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 rounded-2xl bg-white/[0.02] border border-white/5">
                        <div className="space-y-1">
                          <div className="text-xs text-slate-400">
                            Academic Progress Note:
                          </div>
                          <p className="text-xs font-medium text-slate-200">
                            {result.academicProgressNotes || 'Satisfactory academic performance recorded for this term examination sitting.'}
                          </p>
                        </div>

                        <div className="flex items-center gap-2">
                          <Button
                            id={`view-full-report-btn-${result.id}`}
                            variant="secondary"
                            size="sm"
                            onClick={() => setReportCardModalResult(result)}
                            className="text-xs"
                          >
                            <Printer className="w-3.5 h-3.5 mr-1.5 text-amber-400" />
                            Official Report Card
                          </Button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 6. Official Institutional Report Card Modal */}
      {reportCardModalResult && (
        <Modal
          isOpen={!!reportCardModalResult}
          onClose={() => setReportCardModalResult(null)}
          title="Official Scholar Examination Report Card"
          maxWidth="max-w-3xl"
        >
          <div id="printable-guardian-report-card" className="space-y-6 printable-area">
            {/* Header School Seal */}
            <div className="p-6 rounded-2xl bg-slate-900 border border-white/10 text-center space-y-2">
              <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 mx-auto font-black text-xl">
                S
              </div>
              <h2 className="text-lg font-black text-white tracking-wide uppercase">
                SYGMATE ACADEMY OF EXCELLENCE
              </h2>
              <p className="text-xs text-slate-400 uppercase tracking-widest font-semibold">
                Official Examination Transcript &amp; Performance Evaluation
              </p>
              <div className="inline-block px-3 py-1 rounded-full bg-amber-400/10 border border-amber-400/20 text-amber-400 text-xs font-bold mt-1">
                {reportCardModalResult.examName} ({reportCardModalResult.academicYear})
              </div>
            </div>

            {/* Scholar & Guardian Dossier */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              <div className="p-3 rounded-xl bg-slate-800/80 border border-white/5">
                <div className="text-[10px] text-slate-400 uppercase font-bold">Scholar Name</div>
                <div className="font-bold text-white mt-0.5">{reportCardModalResult.studentName}</div>
              </div>
              <div className="p-3 rounded-xl bg-slate-800/80 border border-white/5">
                <div className="text-[10px] text-slate-400 uppercase font-bold">Admission No</div>
                <div className="font-bold text-amber-400 font-mono mt-0.5">{reportCardModalResult.admissionNumber}</div>
              </div>
              <div className="p-3 rounded-xl bg-slate-800/80 border border-white/5">
                <div className="text-[10px] text-slate-400 uppercase font-bold">Class &amp; Roll</div>
                <div className="font-bold text-white mt-0.5">{reportCardModalResult.className} • {reportCardModalResult.rollNumber}</div>
              </div>
              <div className="p-3 rounded-xl bg-slate-800/80 border border-white/5">
                <div className="text-[10px] text-slate-400 uppercase font-bold">Publish Date</div>
                <div className="font-bold text-white mt-0.5">{reportCardModalResult.publishDate}</div>
              </div>
            </div>

            {/* Subject Marks Table */}
            <div className="overflow-x-auto rounded-xl border border-white/10 bg-slate-950/60">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-white/10 bg-slate-900/90 text-slate-400 uppercase font-semibold">
                    <th className="py-3 px-3">Subject</th>
                    <th className="py-3 px-3 text-center">Credits</th>
                    <th className="py-3 px-3 text-center">Full</th>
                    <th className="py-3 px-3 text-center">Pass</th>
                    <th className="py-3 px-3 text-center">Obtained</th>
                    <th className="py-3 px-3 text-center">%</th>
                    <th className="py-3 px-3 text-center">Grade</th>
                    <th className="py-3 px-3 text-center">GP</th>
                    <th className="py-3 px-3 text-center">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {(reportCardModalResult?.subjectScores || []).map((score) => (
                    <tr key={score.id}>
                      <td className="py-2.5 px-3">
                        <span className="font-bold text-white">{score.subjectName}</span>
                        <span className="text-[10px] font-mono text-slate-400 block">{score.subjectCode}</span>
                      </td>
                      <td className="py-2.5 px-3 text-center text-slate-300">{score.credits || 3}</td>
                      <td className="py-2.5 px-3 text-center text-slate-400">{score.fullMarks}</td>
                      <td className="py-2.5 px-3 text-center text-slate-400">{score.passMarks}</td>
                      <td className="py-2.5 px-3 text-center font-bold text-white">{score.obtainedMarks}</td>
                      <td className="py-2.5 px-3 text-center text-emerald-400 font-bold">{Number(score?.percentage ?? 0).toFixed(1)}%</td>
                      <td className="py-2.5 px-3 text-center">{getGradeBadge(score.grade)}</td>
                      <td className="py-2.5 px-3 text-center font-mono text-slate-300">{Number(score?.gradePoint ?? 0).toFixed(1)}</td>
                      <td className="py-2.5 px-3 text-center">
                        <span className="text-[10px] font-bold text-emerald-400">{score.status}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Total Assessment Summary Box */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 rounded-xl bg-slate-900 border border-white/10 text-center text-xs">
              <div>
                <span className="text-slate-400 text-[10px] uppercase font-bold">Total Marks</span>
                <p className="text-base font-black text-white mt-0.5">
                  {reportCardModalResult.summary.totalObtainedMarks} / {reportCardModalResult.summary.totalFullMarks}
                </p>
              </div>
              <div>
                <span className="text-slate-400 text-[10px] uppercase font-bold">Overall Percentage</span>
                <p className="text-base font-black text-emerald-400 mt-0.5">
                  {Number(reportCardModalResult?.summary?.overallPercentage ?? 0).toFixed(2)}%
                </p>
              </div>
              <div>
                <span className="text-slate-400 text-[10px] uppercase font-bold">Term GPA</span>
                <p className="text-base font-black text-amber-400 mt-0.5">
                  {Number(reportCardModalResult?.summary?.gpa ?? 0).toFixed(2)} / 4.00
                </p>
              </div>
              <div>
                <span className="text-slate-400 text-[10px] uppercase font-bold">Result Status</span>
                <p className="text-base font-black text-purple-400 mt-0.5">
                  {reportCardModalResult.summary.resultStatus}
                </p>
              </div>
            </div>

            {/* Institutional Sign-off */}
            <div className="p-4 rounded-xl bg-slate-950/40 border border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400">
              <div>
                <span className="font-semibold text-slate-300">Verified by:</span> Office of Controller of Examinations
              </div>
              <div className="flex items-center gap-1.5 text-emerald-400 font-semibold">
                <ShieldCheck className="w-4 h-4" /> Cryptographically Verified Record
              </div>
            </div>

            {/* Modal Actions */}
            <div className="flex justify-end gap-3 pt-4 border-t border-white/10">
              <Button variant="secondary" onClick={() => setReportCardModalResult(null)}>
                Close
              </Button>
              <Button
                variant="primary"
                onClick={() =>
                  triggerSafePrint({
                    elementOrId: 'printable-guardian-report-card',
                    fallbackTitle: `ReportCard_${(reportCardModalResult.studentName || 'Student').replace(/\s+/g, '_')}`
                  })
                }
              >
                <Printer className="w-4 h-4 mr-2" /> Print Official Report Card
              </Button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
