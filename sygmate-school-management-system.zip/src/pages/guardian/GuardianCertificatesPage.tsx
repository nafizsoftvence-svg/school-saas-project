/**
 * Part 15C — Guardian Portal: Child Academic Certificates
 * Sygmate School Management System
 */

import React, { useEffect, useState, useMemo } from 'react';
import {
  Award,
  Search,
  Printer,
  Download,
  Calendar,
  ShieldCheck,
  Sparkles,
  Eye,
  RefreshCw,
  AlertCircle,
  GraduationCap,
  Users
} from 'lucide-react';
import { IssuedCertificate } from '../../types';
import { api } from '../../services/api';
import { CertificateViewerModal } from '../../components/documents/CertificateViewerModal';
import { Button } from '../../components/ui/Button';

export const GuardianCertificatesPage: React.FC<{ onNavigate?: (view: string) => void }> = () => {
  const [certificates, setCertificates] = useState<IssuedCertificate[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Filters
  const [search, setSearch] = useState('');
  const [selectedChildId, setSelectedChildId] = useState<string>('ALL');
  const [typeFilter, setTypeFilter] = useState('ALL');

  // Viewer Modal
  const [viewingCert, setViewingCert] = useState<IssuedCertificate | null>(null);

  const fetchCertificates = async (isManual = false) => {
    try {
      if (isManual) setRefreshing(true);
      else setLoading(true);
      setError(null);

      const certs = await api.certificates.getGuardianCertificates();
      const list = Array.isArray(certs)
        ? certs
        : Array.isArray((certs as any)?.data)
        ? (certs as any).data
        : Array.isArray((certs as any)?.items)
        ? (certs as any).items
        : [];
      setCertificates(list);
    } catch (err: any) {
      setError(err.message || 'Failed to retrieve child certificates.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchCertificates();
  }, []);

  // Distinct linked children from certificates
  const linkedChildren = useMemo(() => {
    const list = Array.isArray(certificates) ? certificates : [];
    const map = new Map<string, { id: string; name: string; admission: string }>();
    for (const c of list) {
      if (!map.has(c.studentId)) {
        map.set(c.studentId, {
          id: c.studentId,
          name: c.studentName,
          admission: c.admissionNumber
        });
      }
    }
    return Array.from(map.values());
  }, [certificates]);

  const certificateTypes = useMemo(() => {
    const list = Array.isArray(certificates) ? certificates : [];
    const types = new Set(list.map(c => c.certificateTypeName));
    return Array.from(types);
  }, [certificates]);

  const filtered = useMemo(() => {
    const list = Array.isArray(certificates) ? certificates : [];
    return list.filter(c => {
      const matchesSearch =
        !search.trim() ||
        c.certificateNumber.toLowerCase().includes(search.toLowerCase()) ||
        c.studentName.toLowerCase().includes(search.toLowerCase()) ||
        c.certificateTypeName.toLowerCase().includes(search.toLowerCase());

      const matchesChild = selectedChildId === 'ALL' || c.studentId === selectedChildId;
      const matchesType = typeFilter === 'ALL' || c.certificateTypeName === typeFilter;
      return matchesSearch && matchesChild && matchesType;
    });
  }, [certificates, search, selectedChildId, typeFilter]);

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 relative overflow-hidden shadow-2xl">
        <div className="absolute right-0 top-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="p-3.5 bg-indigo-500/20 border border-indigo-500/30 rounded-2xl text-indigo-400">
              <Award className="w-8 h-8" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                  Child Academic Certificates & Honors
                </h1>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  Guardian Portal
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-xl">
                Official bonafide credentials, merit awards, and character citations issued to your registered children by the school board.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => fetchCertificates(true)}
              disabled={refreshing}
              className="flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold border border-slate-700 transition-colors"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin' : ''}`} />
              Refresh
            </button>
          </div>
        </div>

        {/* Linked Children Pill Strip */}
        {linkedChildren.length > 0 && (
          <div className="flex flex-wrap items-center gap-2 mt-6 pt-6 border-t border-slate-800/80">
            <span className="text-xs text-slate-400 font-semibold mr-1 flex items-center gap-1.5">
              <Users className="w-3.5 h-3.5 text-indigo-400" />
              Filter by Student:
            </span>
            <button
              onClick={() => setSelectedChildId('ALL')}
              className={`px-3 py-1 rounded-full text-xs font-semibold transition-colors ${
                selectedChildId === 'ALL'
                  ? 'bg-indigo-600 text-white'
                  : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              All Linked Children ({certificates.length})
            </button>
            {linkedChildren.map(ch => (
              <button
                key={ch.id}
                onClick={() => setSelectedChildId(ch.id)}
                className={`px-3 py-1 rounded-full text-xs font-semibold transition-colors flex items-center gap-1.5 ${
                  selectedChildId === ch.id
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'bg-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                <GraduationCap className="w-3.5 h-3.5" />
                {ch.name} ({ch.admission})
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900 border border-slate-800 p-4 rounded-2xl">
        <div className="relative flex-1 min-w-[240px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            type="text"
            placeholder="Search by student name, serial number or certificate title..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
          />
        </div>

        <div className="flex items-center gap-2">
          <select
            value={typeFilter}
            onChange={e => setTypeFilter(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
          >
            <option value="ALL">All Certificate Types</option>
            {certificateTypes.map(t => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Error Message */}
      {error && (
        <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
          <span>{error}</span>
        </div>
      )}

      {/* Certificates Cards Grid */}
      {loading ? (
        <div className="py-20 text-center text-xs text-slate-400">
          Loading child academic certificates...
        </div>
      ) : filtered.length === 0 ? (
        <div className="py-16 text-center bg-slate-900/60 border border-slate-800 rounded-3xl p-8 space-y-3">
          <div className="w-12 h-12 rounded-full bg-slate-800 text-slate-400 mx-auto flex items-center justify-center">
            <Award className="w-6 h-6" />
          </div>
          <h3 className="text-sm font-bold text-white">No Certificates Found</h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            {search
              ? 'No certificates match your search query.'
              : 'There are no official certificates issued for your linked children at this time.'}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map(cert => (
            <div
              key={cert.id}
              className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-2xl p-5 shadow-lg flex flex-col justify-between transition-all hover:shadow-indigo-500/5 group"
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="p-2 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400">
                    <Award className="w-5 h-5" />
                  </div>
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3" />
                    Verified Official
                  </span>
                </div>

                <div>
                  <span className="text-[10px] font-mono text-indigo-400 font-bold uppercase tracking-wider block">
                    {cert.studentName} ({cert.admissionNumber})
                  </span>
                  <h3 className="text-sm font-bold text-white group-hover:text-indigo-300 transition-colors mt-0.5">
                    {cert.certificateTypeName}
                  </h3>
                  <p className="font-mono text-xs text-slate-400 font-semibold mt-0.5">
                    {cert.certificateNumber}
                  </p>
                </div>

                <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800/80 space-y-1.5 text-xs">
                  <div className="flex justify-between items-center text-slate-400">
                    <span>Issue Date:</span>
                    <strong className="text-slate-200">{cert.issueDate}</strong>
                  </div>
                  <div className="flex justify-between items-center text-slate-400">
                    <span>Session:</span>
                    <strong className="text-slate-200">{cert.academicSessionName}</strong>
                  </div>
                  <div className="flex justify-between items-center text-slate-400">
                    <span>Class & Stream:</span>
                    <span className="text-slate-300">{cert.className || 'Grade 10'}</span>
                  </div>
                </div>

                {cert.remarks && (
                  <p className="text-xs text-slate-400 italic line-clamp-2">
                    &ldquo;{cert.remarks}&rdquo;
                  </p>
                )}
              </div>

              {/* Card Actions */}
              <div className="pt-4 mt-3 border-t border-slate-800 flex items-center justify-between gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => setViewingCert(cert)}
                  className="flex-1 text-xs"
                >
                  <Eye className="w-3.5 h-3.5 mr-1.5" />
                  View
                </Button>
                <Button
                  size="sm"
                  variant="default"
                  onClick={() => setViewingCert(cert)}
                  className="flex-1 bg-indigo-600 hover:bg-indigo-500 text-white text-xs"
                >
                  <Printer className="w-3.5 h-3.5 mr-1.5" />
                  Print / PDF
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Certificate Viewer Modal */}
      {viewingCert && (
        <CertificateViewerModal
          certificate={viewingCert}
          onClose={() => setViewingCert(null)}
          userRole="GUARDIAN"
        />
      )}
    </div>
  );
};
