import React, { useState, useEffect, useMemo } from 'react';
import {
  CreditCard,
  Receipt,
  DollarSign,
  Calendar,
  AlertCircle,
  CheckCircle2,
  Clock,
  Search,
  Filter,
  ArrowRight,
  ShieldCheck,
  Download,
  Printer,
  X,
  FileText,
  AlertTriangle,
  RotateCcw,
  Sparkles,
  Info,
  ChevronRight,
  Landmark,
  Wallet,
  Building,
  User,
  GraduationCap,
  Users
} from 'lucide-react';
import { api } from '../../services/api.js';
import { triggerSafePrint } from '../../utils/printPdf.js';
import {
  GuardianChildSummary,
  StudentFeeRecord,
  GuardianFeeSummary,
  GuardianChildFeesResponse,
  GuardianChildFeeDetailResponse,
  GuardianFamilyFeeOverviewResponse,
  FeePaymentReceipt,
  PaymentMethod
} from '../../types/index.js';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner.js';
import { Badge } from '../../components/ui/Badge.js';
import { Button } from '../../components/ui/Button.js';
import { Modal } from '../../components/ui/Modal.js';
import { Input } from '../../components/ui/Input.js';

interface GuardianFeesPageProps {
  onNavigate?: (view: string) => void;
  initialStudentId?: string;
}

export const GuardianFeesPage: React.FC<GuardianFeesPageProps> = ({
  onNavigate,
  initialStudentId
}) => {
  // Linked children state
  const [children, setChildren] = useState<GuardianChildSummary[]>([]);
  const [selectedChildId, setSelectedChildId] = useState<string | null>(initialStudentId || null);
  const [isLoadingChildren, setIsLoadingChildren] = useState<boolean>(true);

  // Fee ledger state
  const [feeData, setFeeData] = useState<GuardianChildFeesResponse | null>(null);
  const [familyOverview, setFamilyOverview] = useState<GuardianFamilyFeeOverviewResponse | null>(null);
  const [isLoadingFees, setIsLoadingFees] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [authError, setAuthError] = useState<string | null>(null);

  // Filters
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [sessionFilter, setSessionFilter] = useState<string>('ALL');
  const [feeTypeFilter, setFeeTypeFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Modals state
  const [selectedFeeDetail, setSelectedFeeDetail] = useState<GuardianChildFeeDetailResponse | null>(null);
  const [isLoadingFeeDetail, setIsLoadingFeeDetail] = useState<boolean>(false);

  // Payment Modal State
  const [payingFee, setPayingFee] = useState<StudentFeeRecord | null>(null);
  const [paymentAmountType, setPaymentAmountType] = useState<'FULL' | 'CUSTOM'>('FULL');
  const [customAmount, setCustomAmount] = useState<string>('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('CREDIT_CARD');
  const [cardholderName, setCardholderName] = useState<string>('');
  const [cardNumber, setCardNumber] = useState<string>('•••• •••• •••• 4242');
  const [cardExpiry, setCardExpiry] = useState<string>('12/28');
  const [cardCvv, setCardCvv] = useState<string>('•••');
  const [paymentNotes, setPaymentNotes] = useState<string>('');
  const [isProcessingPayment, setIsProcessingPayment] = useState<boolean>(false);
  const [paymentError, setPaymentError] = useState<string | null>(null);

  // Receipt Modal State
  const [activeReceipt, setActiveReceipt] = useState<FeePaymentReceipt | null>(null);
  const [isLoadingReceipt, setIsLoadingReceipt] = useState<boolean>(false);

  // Success Notification Banner
  const [successBanner, setSuccessBanner] = useState<string | null>(null);

  // 1. Fetch linked children
  useEffect(() => {
    const fetchChildren = async () => {
      setIsLoadingChildren(true);
      setAuthError(null);
      try {
        const res = await api.guardian.getChildren();
        const childrenList = Array.isArray(res?.data) ? res.data : Array.isArray(res) ? res : [];
        if (res?.success) {
          setChildren(childrenList);
          if (!selectedChildId && childrenList.length > 0) {
            setSelectedChildId(childrenList?.[0]?.id || null);
          } else if (selectedChildId && selectedChildId !== 'FAMILY_ALL') {
            const exists = childrenList.some((c: any) => c?.id === selectedChildId);
            if (!exists && childrenList.length > 0) {
              setSelectedChildId(childrenList?.[0]?.id || null);
            }
          }
        } else {
          setAuthError(typeof res.error === 'string' ? res.error : 'Failed to retrieve linked scholars.');
        }
      } catch (err: any) {
        setAuthError(err?.message || 'Error communicating with security services.');
      } finally {
        setIsLoadingChildren(false);
      }
    };

    fetchChildren();
  }, []);

  // 2. Fetch fees for selected child or family overview
  const fetchFees = async () => {
    if (!selectedChildId) return;

    setIsLoadingFees(true);
    setError(null);
    try {
      if (selectedChildId === 'FAMILY_ALL') {
        const res = await api.guardian.getFamilyFeeOverview();
        if (res.success && res.data) {
          setFamilyOverview(res.data);
        } else {
          setError(typeof res.error === 'string' ? res.error : 'Failed to load family fee overview.');
        }
      } else {
        const res = await api.guardian.getChildFees({
          studentId: selectedChildId,
          status: statusFilter,
          sessionId: sessionFilter,
          feeType: feeTypeFilter,
          search: searchQuery
        });

        if (res.success && res.data) {
          setFeeData(res.data);
        } else {
          if (res.code === 'UNAUTHORIZED_STUDENT_ACCESS' || res.code === 'FORBIDDEN_STUDENT_ACCESS') {
            setAuthError(typeof res.error === 'string' ? res.error : 'Security violation: Access denied.');
          } else {
            setError(typeof res.error === 'string' ? res.error : 'Failed to load fee ledger.');
          }
        }
      }
    } catch (err: any) {
      setError(err?.message || 'Error communicating with financial service.');
    } finally {
      setIsLoadingFees(false);
    }
  };

  useEffect(() => {
    if (selectedChildId) {
      fetchFees();
    }
  }, [selectedChildId, statusFilter, sessionFilter, feeTypeFilter]);

  // Handle Search Debounce / Trigger
  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchFees();
  };

  // Open Fee Detail Modal
  const handleOpenFeeDetail = async (feeId: string) => {
    setIsLoadingFeeDetail(true);
    try {
      const res = await api.guardian.getFeeDetail(feeId);
      if (res.success && res.data) {
        const localFee = feeData?.fees?.find((f) => f.id === feeId);
        const detailData = { ...res.data };
        if (!detailData.fee && localFee) {
          detailData.fee = localFee;
        }
        setSelectedFeeDetail(detailData);
      } else {
        const localFee = feeData?.fees?.find((f) => f.id === feeId);
        if (localFee) {
          setSelectedFeeDetail({
            student: feeData?.student || {
              id: localFee.studentId,
              name: (localFee as any).scholarName || 'Student Scholar',
              admissionNumber: (localFee as any).scholarAdmissionNumber || 'ADM-001',
              className: (localFee as any).scholarClass || 'Class',
              sectionName: 'A',
              rollNumber: '01'
            },
            fee: localFee,
            transactions: [],
            summary: feeData?.summary || ({} as any)
          });
        }
      }
    } catch (err: any) {
      console.error('Failed to load fee breakdown:', err);
      const localFee = feeData?.fees?.find((f) => f.id === feeId);
      if (localFee) {
        setSelectedFeeDetail({
          student: feeData?.student || {
            id: localFee.studentId,
            name: (localFee as any).scholarName || 'Student Scholar',
            admissionNumber: (localFee as any).scholarAdmissionNumber || 'ADM-001',
            className: (localFee as any).scholarClass || 'Class',
            sectionName: 'A',
            rollNumber: '01'
          },
          fee: localFee,
          transactions: [],
          summary: feeData?.summary || ({} as any)
        });
      }
    } finally {
      setIsLoadingFeeDetail(false);
    }
  };

  // Open Pay Modal
  const handleOpenPayModal = (fee: StudentFeeRecord) => {
    setPayingFee(fee);
    setPaymentAmountType('FULL');
    setCustomAmount(fee.dueAmount.toString());
    setPaymentMethod('CREDIT_CARD');
    setPaymentNotes('');
    setPaymentError(null);
  };

  // Process Online Payment
  const handleProcessPayment = async () => {
    if (!payingFee) return;

    const amountToPay =
      paymentAmountType === 'FULL'
        ? payingFee.dueAmount
        : parseFloat(customAmount);

    if (isNaN(amountToPay) || amountToPay <= 0) {
      setPaymentError('Please enter a valid positive payment amount.');
      return;
    }

    if (amountToPay > payingFee.dueAmount + 0.01) {
      setPaymentError(`Payment amount cannot exceed the remaining due of $${payingFee.dueAmount.toFixed(2)}.`);
      return;
    }

    setIsProcessingPayment(true);
    setPaymentError(null);

    try {
      const idempotencyKey = `pay_${payingFee.id}_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      const res = await api.guardian.payFee({
        feeId: payingFee.id,
        amount: amountToPay,
        paymentMethod,
        cardholderName: cardholderName || 'Carlos Rivera',
        notes: paymentNotes,
        idempotencyKey
      });

      if (res.success && res.data) {
        setSuccessBanner(
          `Payment of $${amountToPay.toFixed(2)} for "${payingFee.title}" settled successfully. Receipt #${res.data.receiptNumber} generated.`
        );
        const receiptNumber = res.data.receiptNumber;
        setPayingFee(null);
        setSelectedFeeDetail(null);
        // Refresh fees
        await fetchFees();
        // Prompt to view receipt
        handleViewReceipt(receiptNumber);
      } else {
        setPaymentError(typeof res.error === 'string' ? res.error : 'Payment processing failed.');
      }
    } catch (err: any) {
      setPaymentError(err?.message || 'Transaction could not be settled. Please try again.');
    } finally {
      setIsProcessingPayment(false);
    }
  };

  // Fetch & View Receipt
  const handleViewReceipt = async (transactionIdOrReceipt: string) => {
    setIsLoadingReceipt(true);
    try {
      const res = await api.guardian.getPaymentReceipt(transactionIdOrReceipt);
      if (res.success && res.data) {
        setActiveReceipt(res.data);
      }
    } catch (err: any) {
      console.error('Failed to load receipt:', err);
    } finally {
      setIsLoadingReceipt(false);
    }
  };

  const isFamilyView = selectedChildId === 'FAMILY_ALL';
  const currentSelectedChild = (children || []).find((c) => c?.id === selectedChildId);

  // Status Badge Helper
  const getStatusBadge = (status: string, dueAmount: number) => {
    if (status === 'PAID' || dueAmount <= 0) {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
          <CheckCircle2 className="w-3.5 h-3.5" />
          Paid in Full
        </span>
      );
    }
    if (status === 'PARTIAL') {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-50 text-amber-700 border border-amber-200">
          <Clock className="w-3.5 h-3.5" />
          Partially Paid
        </span>
      );
    }
    if (status === 'OVERDUE') {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-50 text-rose-700 border border-rose-200">
          <AlertCircle className="w-3.5 h-3.5" />
          Overdue
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-200">
        <Clock className="w-3.5 h-3.5" />
        Unpaid Due
      </span>
    );
  };

  // Fee Type Icon Helper
  const getFeeTypeIcon = (type: string) => {
    switch (type.toUpperCase()) {
      case 'TUITION':
        return <GraduationCap className="w-4 h-4 text-indigo-600" />;
      case 'EXAM':
        return <FileText className="w-4 h-4 text-purple-600" />;
      case 'TRANSPORT':
        return <Landmark className="w-4 h-4 text-amber-600" />;
      case 'LABORATORY':
        return <Sparkles className="w-4 h-4 text-emerald-600" />;
      case 'LIBRARY':
        return <FileText className="w-4 h-4 text-cyan-600" />;
      default:
        return <CreditCard className="w-4 h-4 text-slate-600" />;
    }
  };

  const summary: GuardianFeeSummary = isFamilyView
    ? familyOverview?.familySummary || {
        totalFees: 0,
        totalPaid: 0,
        totalDue: 0,
        totalOverdue: 0,
        totalDiscount: 0,
        totalPayable: 0,
        totalScholarship: 0,
        totalWaiver: 0,
        totalFine: 0,
        fullyPaidCount: 0,
        partiallyPaidCount: 0,
        unpaidCount: 0,
        overdueCount: 0,
        nextUpcomingDueDate: null
      }
    : feeData?.summary || {
        totalFees: 0,
        totalPaid: 0,
        totalDue: 0,
        totalOverdue: 0,
        totalDiscount: 0,
        totalPayable: 0,
        totalScholarship: 0,
        totalWaiver: 0,
        totalFine: 0,
        fullyPaidCount: 0,
        partiallyPaidCount: 0,
        unpaidCount: 0,
        overdueCount: 0,
        nextUpcomingDueDate: null
      };

  const totalConcessions =
    (summary.totalDiscount || 0) +
    (summary.totalScholarship || 0) +
    (summary.totalWaiver || 0);

  const displayFees = useMemo(() => {
    if (isFamilyView) {
      const allFees = (familyOverview?.childrenSummaries || []).flatMap((c) =>
        (c.fees || []).map((f) => ({
          ...f,
          scholarName: c.student.name,
          scholarClass: `${c.student.className} • ${c.student.sectionName}`,
          scholarRoll: c.student.rollNumber
        }))
      );
      return allFees.filter((fee) => {
        if (statusFilter !== 'ALL') {
          if (statusFilter === 'OUTSTANDING' && fee.dueAmount <= 0) return false;
          if (statusFilter === 'OVERDUE' && fee.status !== 'OVERDUE') return false;
          if (statusFilter === 'DUE' && fee.status !== 'DUE') return false;
          if (statusFilter === 'PARTIAL' && fee.status !== 'PARTIAL') return false;
          if (statusFilter === 'PAID' && fee.status !== 'PAID') return false;
        }
        if (sessionFilter !== 'ALL' && fee.academicSessionId !== sessionFilter) return false;
        if (feeTypeFilter !== 'ALL' && fee.feeType !== feeTypeFilter) return false;
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchTitle = fee.title?.toLowerCase().includes(q);
          const matchInvoice = fee.invoiceNumber?.toLowerCase().includes(q);
          const matchScholar = (fee as any).scholarName?.toLowerCase().includes(q);
          if (!matchTitle && !matchInvoice && !matchScholar) return false;
        }
        return true;
      });
    }
    return feeData?.data || [];
  }, [isFamilyView, familyOverview, feeData, statusFilter, sessionFilter, feeTypeFilter, searchQuery]);

  const availableFeeTypes = useMemo(() => {
    if (isFamilyView) {
      const types = new Set<string>();
      familyOverview?.childrenSummaries?.forEach((c) => {
        c.fees?.forEach((f) => {
          if (f.feeType) types.add(f.feeType);
        });
      });
      return Array.from(types);
    }
    return feeData?.availableFeeTypes || [];
  }, [isFamilyView, familyOverview, feeData]);

  const availableSessions = useMemo(() => {
    if (isFamilyView) {
      const sessionsMap = new Map<string, string>();
      familyOverview?.childrenSummaries?.forEach((c) => {
        c.fees?.forEach((f) => {
          if (f.academicSessionId && f.academicSessionName) {
            sessionsMap.set(f.academicSessionId, f.academicSessionName);
          }
        });
      });
      return Array.from(sessionsMap.entries()).map(([id, name]) => ({ id, name }));
    }
    return feeData?.availableSessions || [];
  }, [isFamilyView, familyOverview, feeData]);

  const totalLedgerCount = isFamilyView ? (displayFees?.length || 0) : (feeData?.total || 0);

  if (isLoadingChildren) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[400px] p-6">
        <LoadingSpinner size="lg" />
        <p className="mt-4 text-sm text-slate-600 font-medium">Authenticating & loading linked student records...</p>
      </div>
    );
  }

  if (authError) {
    return (
      <div className="max-w-4xl mx-auto p-6">
        <div className="bg-rose-50 border border-rose-200 rounded-xl p-6 text-center">
          <AlertTriangle className="w-12 h-12 text-rose-600 mx-auto mb-3" />
          <h2 className="text-lg font-bold text-rose-900 mb-2">Access Authorization Restriction</h2>
          <p className="text-sm text-rose-700 max-w-md mx-auto mb-4">{authError}</p>
          <Button variant="outline" onClick={() => window.location.reload()}>
            <RotateCcw className="w-4 h-4 mr-2" />
            Reload Portal
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Top Banner / Breadcrumb & Title */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 border-b border-slate-200 pb-5">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-indigo-600 mb-1">
            <ShieldCheck className="w-4 h-4" />
            Guardian Financial Management
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
            Fees & Invoices
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Official billing ledger, itemized breakdown, concessions, scholarships, and real-time online fee settlement.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <Button
            variant="outline"
            size="sm"
            onClick={() => onNavigate && onNavigate('guardian-payments')}
            className="flex items-center gap-1.5 shadow-sm"
          >
            <Receipt className="w-4 h-4 text-slate-600" />
            Payment History
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={fetchFees}
            disabled={isLoadingFees}
            className="flex items-center gap-1.5 shadow-sm"
          >
            <RotateCcw className={`w-4 h-4 ${isLoadingFees ? 'animate-spin' : ''}`} />
            Refresh Ledger
          </Button>
        </div>
      </div>

      {/* Success Notification */}
      {successBanner && (
        <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 flex items-center justify-between shadow-sm animate-in fade-in duration-300">
          <div className="flex items-center gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            <p className="text-sm font-medium text-emerald-900">{successBanner}</p>
          </div>
          <button
            onClick={() => setSuccessBanner(null)}
            className="text-emerald-700 hover:text-emerald-900 p-1"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Child Selector Tabs */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4">
        <div className="flex items-center justify-between mb-3">
          <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
            <User className="w-3.5 h-3.5 text-indigo-600" />
            Select Student Scholar
          </label>
          <span className="text-xs text-slate-400">
            {children?.length || 0} linked {(children?.length || 0) === 1 ? 'student' : 'students'}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
          {(children?.length || 0) > 1 && (
            <button
              onClick={() => setSelectedChildId('FAMILY_ALL')}
              className={`flex items-center gap-3 p-3 rounded-lg border text-left transition-all ${
                isFamilyView
                  ? 'bg-indigo-50/80 border-indigo-500 text-indigo-950 ring-2 ring-indigo-500/20 shadow-sm'
                  : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100 hover:border-slate-300'
              }`}
            >
              <div
                className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm shrink-0 ${
                  isFamilyView ? 'bg-indigo-600 text-white' : 'bg-slate-200 text-slate-700'
                }`}
              >
                <Users className="w-5 h-5" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="font-semibold text-sm truncate">Family Consolidated</div>
                <div className="text-xs text-slate-500 truncate">
                  All {children?.length || 0} Scholars
                </div>
              </div>
              {isFamilyView && <CheckCircle2 className="w-5 h-5 text-indigo-600 shrink-0" />}
            </button>
          )}

          {(children || []).map((child) => {
            const isSelected = !isFamilyView && child.id === selectedChildId;
            return (
              <button
                key={child.id}
                onClick={() => setSelectedChildId(child.id)}
                className={`flex items-center gap-3 p-3 rounded-lg border text-left transition-all ${
                  isSelected
                    ? 'bg-indigo-50/80 border-indigo-500 text-indigo-950 ring-2 ring-indigo-500/20 shadow-sm'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100 hover:border-slate-300'
                }`}
              >
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm shrink-0 ${
                    isSelected ? 'bg-indigo-600 text-white' : 'bg-slate-200 text-slate-700'
                  }`}
                >
                  {child.firstName?.[0] || child.name?.[0] || 'S'}
                  {child.lastName?.[0] || ''}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="font-semibold text-sm truncate">{child.name}</div>
                  <div className="text-xs text-slate-500 truncate">
                    {child.className} • {child.sectionName} • #{child.admissionNumber}
                  </div>
                </div>
                {isSelected && <CheckCircle2 className="w-5 h-5 text-indigo-600 shrink-0" />}
              </button>
            );
          })}
        </div>
      </div>

      {/* Financial Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3">
        {/* Total Invoiced */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Gross Invoiced</span>
            <div className="w-7 h-7 rounded-lg bg-slate-100 flex items-center justify-center text-slate-600">
              <FileText className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="mt-2.5">
            <div className="text-xl font-bold text-slate-900">
              ${summary.totalFees.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <div className="text-[11px] text-slate-500 mt-0.5 truncate">
              {totalLedgerCount} total ledger items
            </div>
          </div>
        </div>

        {/* Concessions & Scholarships */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Concessions</span>
            <div className="w-7 h-7 rounded-lg bg-purple-100 flex items-center justify-center text-purple-700">
              <Sparkles className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="mt-2.5">
            <div className="text-xl font-bold text-purple-700">
              -${totalConcessions.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <div className="text-[11px] text-purple-600 mt-0.5 truncate">
              {(summary.totalScholarship || 0) > 0 ? `Scholarships: $${summary.totalScholarship}` : 'Discounts & Waivers'}
            </div>
          </div>
        </div>

        {/* Net Payable */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Net Payable</span>
            <div className="w-7 h-7 rounded-lg bg-blue-100 flex items-center justify-center text-blue-700">
              <DollarSign className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="mt-2.5">
            <div className="text-xl font-bold text-blue-900">
              ${(summary.totalPayable || (summary.totalFees - totalConcessions + (summary.totalFine || 0))).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <div className="text-[11px] text-blue-600 mt-0.5 truncate">
              {(summary.totalFine || 0) > 0 ? `+ $${summary.totalFine} Fines` : 'Standard terms'}
            </div>
          </div>
        </div>

        {/* Total Settled / Paid */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Total Settled</span>
            <div className="w-7 h-7 rounded-lg bg-emerald-100 flex items-center justify-center text-emerald-600">
              <CheckCircle2 className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="mt-2.5">
            <div className="text-xl font-bold text-emerald-700">
              ${summary.totalPaid.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <div className="text-[11px] text-emerald-600 mt-0.5 truncate">
              {summary.fullyPaidCount} fully cleared
            </div>
          </div>
        </div>

        {/* Outstanding Due Balance */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Outstanding Due</span>
            <div className="w-7 h-7 rounded-lg bg-amber-100 flex items-center justify-center text-amber-600">
              <Clock className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="mt-2.5">
            <div className="text-xl font-bold text-amber-700">
              ${summary.totalDue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <div className="text-[11px] text-amber-600 mt-0.5 truncate">
              {summary.unpaidCount + summary.partiallyPaidCount} pending
            </div>
          </div>
        </div>

        {/* Overdue Amount */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Overdue Balance</span>
            <div className="w-7 h-7 rounded-lg bg-rose-100 flex items-center justify-center text-rose-600">
              <AlertCircle className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="mt-2.5">
            <div className="text-xl font-bold text-rose-700">
              ${summary.totalOverdue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <div className="text-[11px] text-rose-600 mt-0.5 truncate">
              {summary.overdueCount} overdue
            </div>
          </div>
        </div>
      </div>

      {/* Family Scholar Financial Breakdown Cards (When in Family Consolidated View) */}
      {isFamilyView && familyOverview?.childrenSummaries && (
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Users className="w-4 h-4 text-indigo-600" />
              Scholar Account Breakdowns
            </h3>
            <span className="text-xs text-slate-500">
              Click any scholar to inspect their dedicated ledger
            </span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {familyOverview.childrenSummaries.map((childSum) => (
              <div
                key={childSum.student.id}
                className="border border-slate-200 rounded-xl p-4 bg-slate-50/50 hover:bg-slate-50 hover:border-indigo-200 transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-indigo-600 text-white font-bold text-sm flex items-center justify-center shrink-0">
                        {(childSum.student?.name || '').split(' ').filter(Boolean).map((n) => n?.[0]).join('').slice(0, 2) || 'S'}
                      </div>
                      <div>
                        <h4 className="text-sm font-bold text-slate-900">{childSum.student?.name || 'Student'}</h4>
                        <p className="text-xs text-slate-500">
                          {childSum.student?.className || ''} • {childSum.student?.sectionName || ''} • #{childSum.student?.admissionNumber || ''}
                        </p>
                      </div>
                    </div>
                    {childSum.summary.totalOverdue > 0 ? (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-50 text-rose-700 border border-rose-200">
                        Overdue
                      </span>
                    ) : childSum.summary.totalDue <= 0 ? (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                        Cleared
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-50 text-amber-700 border border-amber-200">
                        Pending Due
                      </span>
                    )}
                  </div>

                  <div className="grid grid-cols-3 gap-2 py-2 border-y border-slate-200/80 text-xs my-3">
                    <div>
                      <span className="text-[10px] text-slate-500 block uppercase">Invoiced</span>
                      <span className="font-semibold text-slate-800">${Number(childSum.summary?.totalFees ?? 0).toFixed(2)}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500 block uppercase">Settled</span>
                      <span className="font-semibold text-emerald-600">${Number(childSum.summary?.totalPaid ?? 0).toFixed(2)}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500 block uppercase">Due</span>
                      <span className={`font-bold ${(childSum.summary?.totalDue ?? 0) > 0 ? 'text-amber-600' : 'text-slate-500'}`}>
                        ${Number(childSum.summary?.totalDue ?? 0).toFixed(2)}
                      </span>
                    </div>
                  </div>
                </div>

                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => setSelectedChildId(childSum.student.id)}
                  className="w-full text-xs mt-1"
                >
                  Inspect {childSum.student.name.split(' ')[0]}'s Ledger
                </Button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-sm">
        <form onSubmit={handleSearchSubmit} className="flex flex-col lg:flex-row gap-3">
          {/* Search Input */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder={isFamilyView ? "Search across all scholars by invoice #, title, or scholar name..." : "Search by invoice #, fee title, or category..."}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            />
          </div>

          {/* Status Dropdown */}
          <div className="w-full lg:w-44">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full py-2 px-3 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
            >
              <option value="ALL">All Statuses</option>
              <option value="OUTSTANDING">Outstanding Due</option>
              <option value="OVERDUE">Overdue Only</option>
              <option value="DUE">Unpaid Due</option>
              <option value="PARTIAL">Partially Paid</option>
              <option value="PAID">Fully Paid</option>
            </select>
          </div>

          {/* Fee Type Dropdown */}
          <div className="w-full lg:w-44">
            <select
              value={feeTypeFilter}
              onChange={(e) => setFeeTypeFilter(e.target.value)}
              className="w-full py-2 px-3 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
            >
              <option value="ALL">All Fee Types</option>
              {availableFeeTypes.map((type) => (
                <option key={type} value={type}>
                  {type}
                </option>
              ))}
            </select>
          </div>

          {/* Academic Session Dropdown */}
          <div className="w-full lg:w-48">
            <select
              value={sessionFilter}
              onChange={(e) => setSessionFilter(e.target.value)}
              className="w-full py-2 px-3 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
            >
              <option value="ALL">All Sessions</option>
              {availableSessions.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
          </div>

          {/* Reset Filters */}
          {(statusFilter !== 'ALL' || sessionFilter !== 'ALL' || feeTypeFilter !== 'ALL' || searchQuery) && (
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => {
                setStatusFilter('ALL');
                setSessionFilter('ALL');
                setFeeTypeFilter('ALL');
                setSearchQuery('');
              }}
              className="shrink-0 flex items-center gap-1"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Reset
            </Button>
          )}
        </form>
      </div>

      {/* Fee Ledger Content */}
      {isLoadingFees ? (
        <div className="flex flex-col items-center justify-center p-12 bg-white rounded-xl border border-slate-200">
          <LoadingSpinner size="lg" />
          <p className="mt-3 text-sm text-slate-500 font-medium">Fetching fee ledger records...</p>
        </div>
      ) : error ? (
        <div className="bg-rose-50 border border-rose-200 rounded-xl p-6 text-center">
          <AlertCircle className="w-8 h-8 text-rose-600 mx-auto mb-2" />
          <p className="text-sm font-semibold text-rose-900">{error}</p>
          <Button variant="outline" size="sm" className="mt-3" onClick={fetchFees}>
            Try Again
          </Button>
        </div>
      ) : (displayFees?.length || 0) === 0 ? (
        <div className="bg-white rounded-xl border border-slate-200 p-12 text-center shadow-sm">
          <FileText className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <h3 className="text-base font-semibold text-slate-800">No Fee Invoices Found</h3>
          <p className="text-sm text-slate-500 max-w-sm mx-auto mt-1">
            No fee records match the specified filters for{' '}
            <span className="font-semibold text-slate-700">
              {isFamilyView ? 'the family consolidated ledger' : currentSelectedChild?.name}
            </span>.
          </p>
          {(statusFilter !== 'ALL' || sessionFilter !== 'ALL' || feeTypeFilter !== 'ALL' || searchQuery) && (
            <Button
              variant="outline"
              size="sm"
              className="mt-4"
              onClick={() => {
                setStatusFilter('ALL');
                setSessionFilter('ALL');
                setFeeTypeFilter('ALL');
                setSearchQuery('');
              }}
            >
              Clear Filters
            </Button>
          )}
        </div>
      ) : (
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 bg-slate-50/50">
            <div className="text-sm font-semibold text-slate-900 flex items-center gap-2">
              <CreditCard className="w-4 h-4 text-indigo-600" />
              Invoice Ledger ({displayFees?.length || 0} {(displayFees?.length || 0) === 1 ? 'item' : 'items'})
            </div>
            <div className="text-xs text-slate-500">
              {isFamilyView
                ? `Showing consolidated records across all linked scholars (${children?.length || 0} students)`
                : `Showing financial records for ${currentSelectedChild?.name}`}
            </div>
          </div>

          {/* Desktop Table View */}
          <div className="hidden lg:block overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600 uppercase tracking-wider">
                  {isFamilyView && <th className="py-3.5 px-4">Scholar</th>}
                  <th className="py-3.5 px-4">Invoice / Fee Title</th>
                  <th className="py-3.5 px-4">Session & Term</th>
                  <th className="py-3.5 px-4 text-right">Gross Amount</th>
                  <th className="py-3.5 px-4 text-right">Concessions</th>
                  <th className="py-3.5 px-4 text-right">Net Payable</th>
                  <th className="py-3.5 px-4 text-right">Paid</th>
                  <th className="py-3.5 px-4 text-right">Due Balance</th>
                  <th className="py-3.5 px-4">Due Date</th>
                  <th className="py-3.5 px-4">Status</th>
                  <th className="py-3.5 px-4 text-center">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {displayFees.map((fee) => {
                  const netAmount = fee.netPayableAmount || fee.totalAmount;
                  const percentPaid = Math.min(
                    100,
                    Math.round((fee.paidAmount / (netAmount || 1)) * 100)
                  );
                  const isOverdue =
                    new Date(fee.dueDate) < new Date('2026-08-16') && fee.dueAmount > 0;
                  const rowConcession =
                    (fee.discountAmount || 0) +
                    (fee.scholarshipAmount || 0) +
                    (fee.waiverAmount || 0);

                  return (
                    <tr key={fee.id} className="hover:bg-slate-50/80 transition-colors">
                      {isFamilyView && (
                        <td className="py-4 px-4 whitespace-nowrap">
                          <div className="font-semibold text-slate-900 text-xs">{(fee as any).scholarName}</div>
                          <div className="text-[11px] text-slate-500">{(fee as any).scholarClass}</div>
                        </td>
                      )}

                      <td className="py-4 px-4">
                        <div className="flex items-start gap-3">
                          <div className="w-8 h-8 rounded-lg bg-indigo-50 border border-indigo-100 flex items-center justify-center shrink-0 mt-0.5">
                            {getFeeTypeIcon(fee.feeType)}
                          </div>
                          <div>
                            <div className="font-semibold text-slate-900 flex items-center gap-1.5 flex-wrap">
                              {fee.title}
                              {fee.discountAmount > 0 && (
                                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-50 text-amber-700 border border-amber-200">
                                  -${fee.discountAmount} Concession
                                </span>
                              )}
                              {(fee.scholarshipAmount ?? 0) > 0 && (
                                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-purple-50 text-purple-700 border border-purple-200">
                                  -${fee.scholarshipAmount} Scholarship
                                </span>
                              )}
                              {(fee.waiverAmount ?? 0) > 0 && (
                                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-teal-50 text-teal-700 border border-teal-200">
                                  -${fee.waiverAmount} Waiver
                                </span>
                              )}
                              {(fee.fineAmount ?? 0) > 0 && (
                                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-rose-50 text-rose-700 border border-rose-200">
                                  +${fee.fineAmount} Fine
                                </span>
                              )}
                            </div>
                            <div className="text-xs text-slate-500 font-mono mt-0.5">
                              #{fee?.invoiceNumber || fee?.id || 'INV-2026'} • {fee?.feeType || 'Fee'}
                            </div>
                          </div>
                        </div>
                      </td>

                      <td className="py-4 px-4">
                        <div className="text-slate-900 font-medium text-xs">{fee.academicSessionName}</div>
                        <div className="text-xs text-slate-500">{fee.term}</div>
                      </td>

                      <td className="py-4 px-4 text-right font-medium text-slate-700">
                        ${Number(fee.totalAmount ?? 0).toFixed(2)}
                      </td>

                      <td className="py-4 px-4 text-right">
                        {rowConcession > 0 ? (
                          <span className="font-semibold text-purple-700">
                            -${Number(rowConcession ?? 0).toFixed(2)}
                          </span>
                        ) : (
                          <span className="text-slate-400">—</span>
                        )}
                      </td>

                      <td className="py-4 px-4 text-right font-semibold text-slate-900">
                        ${Number(netAmount ?? 0).toFixed(2)}
                      </td>

                      <td className="py-4 px-4 text-right">
                        <div className="font-semibold text-emerald-600">${Number(fee.paidAmount ?? 0).toFixed(2)}</div>
                        <div className="w-16 bg-slate-100 rounded-full h-1.5 ml-auto mt-1 overflow-hidden">
                          <div
                            className="bg-emerald-500 h-1.5 rounded-full"
                            style={{ width: `${percentPaid}%` }}
                          />
                        </div>
                      </td>

                      <td className="py-4 px-4 text-right">
                        <div
                          className={`font-bold ${
                            (fee.dueAmount ?? 0) > 0 ? (isOverdue ? 'text-rose-600' : 'text-amber-600') : 'text-slate-400'
                          }`}
                        >
                          ${Number(fee.dueAmount ?? 0).toFixed(2)}
                        </div>
                      </td>

                      <td className="py-4 px-4">
                        <div className="text-xs font-medium text-slate-700">{fee.dueDate}</div>
                        {fee.dueAmount > 0 && (
                          <div
                            className={`text-[11px] mt-0.5 ${
                              isOverdue ? 'text-rose-600 font-semibold' : 'text-slate-500'
                            }`}
                          >
                            {isOverdue ? 'Past Due' : 'Standard Window'}
                          </div>
                        )}
                      </td>

                      <td className="py-4 px-4">
                        {getStatusBadge(fee.status, fee.dueAmount)}
                      </td>

                      <td className="py-4 px-4">
                        <div className="flex items-center justify-center gap-2">
                          <button
                            onClick={() => handleOpenFeeDetail(fee.id)}
                            className="px-2.5 py-1 text-xs font-medium rounded-lg text-slate-700 bg-slate-100 hover:bg-slate-200 transition-colors"
                          >
                            Details
                          </button>
                          {fee.dueAmount > 0 ? (
                            <Button
                              size="sm"
                              onClick={() => handleOpenPayModal(fee)}
                              className="text-xs py-1 px-3 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold shadow-sm"
                            >
                              Pay Now
                            </Button>
                          ) : (
                            <button
                              onClick={() => {
                                const latestTxn = (fee as any).latestTransactionId || fee.id;
                                handleViewReceipt(latestTxn);
                              }}
                              className="px-2.5 py-1 text-xs font-medium rounded-lg text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 transition-colors flex items-center gap-1"
                            >
                              <Receipt className="w-3 h-3" />
                              Receipt
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Mobile Card View */}
          <div className="block lg:hidden divide-y divide-slate-100">
            {displayFees.map((fee) => {
              const netAmount = fee.netPayableAmount || fee.totalAmount;
              const isOverdue =
                new Date(fee.dueDate) < new Date('2026-08-16') && fee.dueAmount > 0;
              const rowConcession =
                (fee.discountAmount || 0) +
                (fee.scholarshipAmount || 0) +
                (fee.waiverAmount || 0);

              return (
                <div key={fee.id} className="p-4 space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-start gap-2.5">
                      <div className="w-8 h-8 rounded-lg bg-indigo-50 border border-indigo-100 flex items-center justify-center shrink-0 mt-0.5">
                        {getFeeTypeIcon(fee.feeType)}
                      </div>
                      <div>
                        {isFamilyView && (
                          <div className="text-xs font-semibold text-indigo-700">
                            {(fee as any).scholarName} • {(fee as any).scholarClass}
                          </div>
                        )}
                        <div className="font-semibold text-slate-900 text-sm">{fee?.title || 'Fee'}</div>
                        <div className="text-xs text-slate-500 font-mono">#{fee?.invoiceNumber || fee?.id || 'INV-2026'}</div>
                      </div>
                    </div>
                    {getStatusBadge(fee.status, fee.dueAmount)}
                  </div>

                  {rowConcession > 0 && (
                    <div className="text-xs bg-purple-50 text-purple-700 px-2.5 py-1 rounded-md font-medium flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 shrink-0" />
                      <span>Concession Applied: -${Number(rowConcession ?? 0).toFixed(2)}</span>
                    </div>
                  )}

                  <div className="grid grid-cols-2 gap-2 text-xs bg-slate-50 p-2.5 rounded-lg">
                    <div>
                      <span className="text-slate-500">Gross Fee:</span>
                      <div className="font-semibold text-slate-800">${Number(fee.totalAmount ?? 0).toFixed(2)}</div>
                    </div>
                    <div>
                      <span className="text-slate-500">Net Payable:</span>
                      <div className="font-semibold text-slate-900">${Number(netAmount ?? 0).toFixed(2)}</div>
                    </div>
                    <div>
                      <span className="text-slate-500">Paid Amount:</span>
                      <div className="font-semibold text-emerald-600">${Number(fee.paidAmount ?? 0).toFixed(2)}</div>
                    </div>
                    <div>
                      <span className="text-slate-500">Due Balance:</span>
                      <div className={`font-bold ${(fee.dueAmount ?? 0) > 0 ? 'text-amber-600' : 'text-slate-500'}`}>
                        ${Number(fee.dueAmount ?? 0).toFixed(2)}
                      </div>
                    </div>
                    <div>
                      <span className="text-slate-500">Due Date:</span>
                      <div className={`font-semibold ${isOverdue ? 'text-rose-600' : 'text-slate-700'}`}>
                        {fee.dueDate}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-end gap-2 pt-1">
                    <button
                      onClick={() => handleOpenFeeDetail(fee.id)}
                      className="px-3 py-1.5 text-xs font-medium rounded-lg text-slate-700 bg-slate-100 hover:bg-slate-200 transition-colors"
                    >
                      View Breakdown
                    </button>
                    {fee.dueAmount > 0 ? (
                      <Button
                        size="sm"
                        onClick={() => handleOpenPayModal(fee)}
                        className="text-xs py-1.5 px-3 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold shadow-sm"
                      >
                        Pay Online
                      </Button>
                    ) : (
                      <button
                        onClick={() => handleViewReceipt(fee.id)}
                        className="px-3 py-1.5 text-xs font-medium rounded-lg text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 transition-colors flex items-center gap-1"
                      >
                        <Receipt className="w-3.5 h-3.5" />
                        Receipt
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 1. Fee Detail Breakdown Modal */}
      {/* ========================================================================= */}
      {selectedFeeDetail && (
        <Modal
          isOpen={true}
          onClose={() => setSelectedFeeDetail(null)}
          title={`Invoice Breakdown: ${selectedFeeDetail?.fee?.title || (selectedFeeDetail as any)?.title || 'Fee Details'}`}
          size="lg"
        >
          <div className="space-y-5">
            {/* Header info */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
              <div>
                <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Student Scholar</div>
                <div className="text-base font-bold text-slate-900">
                  {selectedFeeDetail?.student?.name || (selectedFeeDetail as any)?.studentName || 'Student Scholar'}
                </div>
                <div className="text-xs text-slate-500">
                  {selectedFeeDetail?.student?.className || (selectedFeeDetail as any)?.className || 'Class'} • {selectedFeeDetail?.student?.sectionName || (selectedFeeDetail as any)?.sectionName || 'Section'} • Roll #{selectedFeeDetail?.student?.rollNumber || (selectedFeeDetail as any)?.rollNumber || '—'}
                </div>
              </div>
              <div className="text-right sm:border-l sm:border-slate-200 sm:pl-4">
                <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Invoice Number</div>
                <div className="text-sm font-mono font-bold text-slate-800">
                  #{selectedFeeDetail?.fee?.invoiceNumber || (selectedFeeDetail as any)?.invoiceNumber || 'INV-2026'}
                </div>
                <div className="mt-1">
                  {getStatusBadge(
                    selectedFeeDetail?.fee?.status || (selectedFeeDetail as any)?.status || 'PENDING',
                    Number(selectedFeeDetail?.fee?.dueAmount ?? (selectedFeeDetail as any)?.dueAmount ?? 0)
                  )}
                </div>
              </div>
            </div>

            {/* Description */}
            {(selectedFeeDetail?.fee?.description || (selectedFeeDetail as any)?.description) && (
              <div className="text-sm text-slate-600 bg-indigo-50/50 border border-indigo-100 rounded-lg p-3">
                <span className="font-semibold text-indigo-950">Description: </span>
                {selectedFeeDetail?.fee?.description || (selectedFeeDetail as any)?.description}
              </div>
            )}

            {/* Financial Ledger Table */}
            <div className="border border-slate-200 rounded-xl overflow-hidden shadow-sm">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600 uppercase">
                    <th className="py-2.5 px-4 text-left">Particulars</th>
                    <th className="py-2.5 px-4 text-right">Amount</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  <tr>
                    <td className="py-2.5 px-4 text-slate-700">Gross Fee / Base Tuition</td>
                    <td className="py-2.5 px-4 text-right font-medium text-slate-900">
                      ${Number(selectedFeeDetail?.fee?.totalAmount ?? (selectedFeeDetail as any)?.totalAmount ?? 0).toFixed(2)}
                    </td>
                  </tr>

                  {Number(selectedFeeDetail?.fee?.discountAmount ?? (selectedFeeDetail as any)?.discountAmount ?? 0) > 0 && (
                    <tr className="bg-amber-50/40">
                      <td className="py-2.5 px-4 text-amber-900">
                        <div className="font-medium">Applied Concession / Discount</div>
                        {(selectedFeeDetail?.fee?.discountReason || (selectedFeeDetail as any)?.discountReason) && (
                          <div className="text-xs text-amber-700">
                            {selectedFeeDetail?.fee?.discountReason || (selectedFeeDetail as any)?.discountReason}
                          </div>
                        )}
                      </td>
                      <td className="py-2.5 px-4 text-right font-bold text-amber-700">
                        -${Number(selectedFeeDetail?.fee?.discountAmount ?? (selectedFeeDetail as any)?.discountAmount ?? 0).toFixed(2)}
                      </td>
                    </tr>
                  )}

                  {Number(selectedFeeDetail?.fee?.scholarshipAmount ?? (selectedFeeDetail as any)?.scholarshipAmount ?? 0) > 0 && (
                    <tr className="bg-purple-50/40">
                      <td className="py-2.5 px-4 text-purple-900">
                        <div className="font-medium">Scholarship Benefit</div>
                        {(selectedFeeDetail?.fee?.scholarshipName || (selectedFeeDetail as any)?.scholarshipName) && (
                          <div className="text-xs text-purple-700">
                            {selectedFeeDetail?.fee?.scholarshipName || (selectedFeeDetail as any)?.scholarshipName}
                          </div>
                        )}
                      </td>
                      <td className="py-2.5 px-4 text-right font-bold text-purple-700">
                        -${Number(selectedFeeDetail?.fee?.scholarshipAmount ?? (selectedFeeDetail as any)?.scholarshipAmount ?? 0).toFixed(2)}
                      </td>
                    </tr>
                  )}

                  {Number(selectedFeeDetail?.fee?.waiverAmount ?? (selectedFeeDetail as any)?.waiverAmount ?? 0) > 0 && (
                    <tr className="bg-teal-50/40">
                      <td className="py-2.5 px-4 text-teal-900">
                        <div className="font-medium">Fee Waiver</div>
                        {(selectedFeeDetail?.fee?.waiverReason || (selectedFeeDetail as any)?.waiverReason) && (
                          <div className="text-xs text-teal-700">
                            {selectedFeeDetail?.fee?.waiverReason || (selectedFeeDetail as any)?.waiverReason}
                          </div>
                        )}
                      </td>
                      <td className="py-2.5 px-4 text-right font-bold text-teal-700">
                        -${Number(selectedFeeDetail?.fee?.waiverAmount ?? (selectedFeeDetail as any)?.waiverAmount ?? 0).toFixed(2)}
                      </td>
                    </tr>
                  )}

                  {Number(selectedFeeDetail?.fee?.fineAmount ?? (selectedFeeDetail as any)?.fineAmount ?? 0) > 0 && (
                    <tr className="bg-rose-50/40">
                      <td className="py-2.5 px-4 text-rose-900">
                        <div className="font-medium">Late Fine / Penalty</div>
                        {(selectedFeeDetail?.fee?.fineReason || (selectedFeeDetail as any)?.fineReason) && (
                          <div className="text-xs text-rose-700">
                            {selectedFeeDetail?.fee?.fineReason || (selectedFeeDetail as any)?.fineReason}
                          </div>
                        )}
                      </td>
                      <td className="py-2.5 px-4 text-right font-bold text-rose-700">
                        +${Number(selectedFeeDetail?.fee?.fineAmount ?? (selectedFeeDetail as any)?.fineAmount ?? 0).toFixed(2)}
                      </td>
                    </tr>
                  )}

                  <tr className="bg-slate-50 font-semibold">
                    <td className="py-2.5 px-4 text-slate-900">Net Payable Amount</td>
                    <td className="py-2.5 px-4 text-right text-slate-900">
                      ${Number(selectedFeeDetail?.fee?.netPayableAmount ?? (selectedFeeDetail as any)?.netPayableAmount ?? 0).toFixed(2)}
                    </td>
                  </tr>

                  <tr>
                    <td className="py-2.5 px-4 text-emerald-700 font-medium">Total Paid to Date</td>
                    <td className="py-2.5 px-4 text-right font-bold text-emerald-600">
                      ${Number(selectedFeeDetail?.fee?.paidAmount ?? (selectedFeeDetail as any)?.paidAmount ?? 0).toFixed(2)}
                    </td>
                  </tr>

                  <tr className="bg-indigo-50/30 font-bold">
                    <td className="py-3 px-4 text-indigo-950">Remaining Due Balance</td>
                    <td className="py-3 px-4 text-right text-base text-indigo-900">
                      ${Number(selectedFeeDetail?.fee?.dueAmount ?? (selectedFeeDetail as any)?.dueAmount ?? 0).toFixed(2)}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>

            {/* Installment breakdown if exists */}
            {((selectedFeeDetail?.fee?.installments || (selectedFeeDetail as any)?.installments || []).length > 0) && (
              <div>
                <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">
                  Installment Schedule
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {(selectedFeeDetail?.fee?.installments || (selectedFeeDetail as any)?.installments || []).map((inst: any, idx: number) => (
                    <div
                      key={inst.id || idx}
                      className={`p-3 rounded-lg border text-xs flex items-center justify-between ${
                        inst.isPaid
                          ? 'bg-emerald-50/50 border-emerald-200 text-emerald-900'
                          : 'bg-slate-50 border-slate-200 text-slate-700'
                      }`}
                    >
                      <div>
                        <div className="font-semibold">{inst.title}</div>
                        <div className="text-[11px] text-slate-500">Due: {inst.dueDate}</div>
                      </div>
                      <div className="text-right">
                        <div className="font-bold">${Number(inst.amount ?? 0).toFixed(2)}</div>
                        <span
                          className={`text-[10px] font-semibold ${
                            inst.isPaid ? 'text-emerald-700' : 'text-amber-700'
                          }`}
                        >
                          {inst.isPaid ? '✓ Paid' : 'Pending'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Linked Payment Transactions */}
            {((selectedFeeDetail?.transactions || []).length > 0) && (
              <div>
                <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">
                  Settled Transaction Records
                </h4>
                <div className="border border-slate-200 rounded-lg divide-y divide-slate-100 overflow-hidden text-xs">
                  {(selectedFeeDetail?.transactions || []).map((txn) => (
                    <div key={txn.id} className="p-3 flex items-center justify-between bg-white hover:bg-slate-50">
                      <div>
                        <div className="font-semibold text-slate-800 font-mono">{txn.transactionId}</div>
                        <div className="text-slate-500">
                          {txn.paymentDate ? txn.paymentDate.split('T')[0] : 'Today'} • {txn.paymentMethodLabel || txn.paymentMethod}
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="text-right">
                          <div className="font-bold text-emerald-600">${Number(txn.amountPaid ?? 0).toFixed(2)}</div>
                          <span className="text-[10px] font-semibold text-emerald-700">Receipt #{txn.receiptNumber}</span>
                        </div>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleViewReceipt(txn.transactionId)}
                          className="text-xs py-1 px-2.5 flex items-center gap-1"
                        >
                          <Printer className="w-3 h-3" />
                          Receipt
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Modal Actions */}
            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
              <Button variant="outline" onClick={() => setSelectedFeeDetail(null)}>
                Close
              </Button>
              {Number(selectedFeeDetail?.fee?.dueAmount ?? (selectedFeeDetail as any)?.dueAmount ?? 0) > 0 && (
                <Button
                  onClick={() => {
                    const fee = selectedFeeDetail?.fee || selectedFeeDetail;
                    setSelectedFeeDetail(null);
                    handleOpenPayModal(fee);
                  }}
                  className="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold flex items-center gap-1.5"
                >
                  <CreditCard className="w-4 h-4" />
                  Proceed to Pay (${Number(selectedFeeDetail?.fee?.dueAmount ?? (selectedFeeDetail as any)?.dueAmount ?? 0).toFixed(2)})
                </Button>
              )}
            </div>
          </div>
        </Modal>
      )}

      {/* ========================================================================= */}
      {/* 2. Secure Online Payment Modal */}
      {/* ========================================================================= */}
      {payingFee && (
        <Modal
          isOpen={true}
          onClose={() => !isProcessingPayment && setPayingFee(null)}
          title="Secure Online Fee Settlement"
          size="md"
        >
          <div className="space-y-4">
            {/* Header info */}
            <div className="bg-indigo-50 border border-indigo-100 rounded-xl p-3.5">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-xs text-indigo-600 font-semibold uppercase">Payee Scholar</div>
                  <div className="text-sm font-bold text-indigo-950">
                    {feeData?.student?.name || (payingFee as any)?.scholarName || payingFee?.studentName || 'Student Scholar'}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xs text-indigo-600 font-semibold uppercase">Outstanding Due</div>
                  <div className="text-base font-bold text-indigo-950">${Number(payingFee?.dueAmount ?? 0).toFixed(2)}</div>
                </div>
              </div>
              <div className="text-xs text-indigo-800 mt-2 font-medium">
                Invoice: #{payingFee?.invoiceNumber || (payingFee as any)?.id || 'INV-2026'} — {payingFee?.title || 'Fee Invoice'}
              </div>
            </div>

            {/* Error banner */}
            {paymentError && (
              <div className="bg-rose-50 border border-rose-200 rounded-lg p-3 text-xs text-rose-800 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>{paymentError}</span>
              </div>
            )}

            {/* Amount Selection */}
            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1.5">Payment Option</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setPaymentAmountType('FULL')}
                  className={`p-2.5 rounded-lg border text-left text-xs transition-all ${
                    paymentAmountType === 'FULL'
                      ? 'bg-indigo-50 border-indigo-600 text-indigo-950 font-bold ring-2 ring-indigo-500/20'
                      : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <div>Pay Full Due</div>
                  <div className="text-sm text-indigo-700">${Number(payingFee.dueAmount ?? 0).toFixed(2)}</div>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentAmountType('CUSTOM')}
                  className={`p-2.5 rounded-lg border text-left text-xs transition-all ${
                    paymentAmountType === 'CUSTOM'
                      ? 'bg-indigo-50 border-indigo-600 text-indigo-950 font-bold ring-2 ring-indigo-500/20'
                      : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <div>Partial Amount</div>
                  <div className="text-xs text-slate-500">Custom Installment</div>
                </button>
              </div>

              {paymentAmountType === 'CUSTOM' && (
                <div className="mt-2.5">
                  <label className="text-xs text-slate-600 font-medium block mb-1">Enter Custom Amount ($)</label>
                  <Input
                    type="number"
                    step="0.01"
                    min="1"
                    max={payingFee.dueAmount}
                    value={customAmount}
                    onChange={(e) => setCustomAmount(e.target.value)}
                    placeholder="e.g. 500.00"
                  />
                  <div className="text-[11px] text-slate-500 mt-1">
                    Remaining balance after payment:{' '}
                    <span className="font-bold text-slate-700">
                      $
                      {Math.max(
                        0,
                        payingFee.dueAmount - (parseFloat(customAmount) || 0)
                      ).toFixed(2)}
                    </span>
                  </div>
                </div>
              )}
            </div>

            {/* Payment Method Selector */}
            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1.5">Select Payment Method</label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {[
                  { id: 'CREDIT_CARD', label: 'Credit Card', icon: CreditCard },
                  { id: 'DEBIT_CARD', label: 'Debit Card', icon: CreditCard },
                  { id: 'NET_BANKING', label: 'Net Banking / ACH', icon: Landmark },
                  { id: 'DIGITAL_WALLET', label: 'Apple/Google Pay', icon: Wallet },
                  { id: 'BANK_TRANSFER', label: 'Wire Transfer', icon: Building }
                ].map((m) => (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => setPaymentMethod(m.id as PaymentMethod)}
                    className={`p-2.5 rounded-lg border text-xs flex flex-col items-center gap-1 transition-all ${
                      paymentMethod === m.id
                        ? 'bg-indigo-50 border-indigo-600 text-indigo-950 font-bold ring-1 ring-indigo-500'
                        : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <m.icon className="w-4 h-4 text-indigo-600" />
                    <span>{m.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Payment Details Simulator Form */}
            {(paymentMethod === 'CREDIT_CARD' || paymentMethod === 'DEBIT_CARD') && (
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-2.5 text-xs">
                <div>
                  <label className="text-slate-600 font-medium block mb-1">Cardholder Name</label>
                  <input
                    type="text"
                    value={cardholderName}
                    onChange={(e) => setCardholderName(e.target.value)}
                    placeholder="Carlos Rivera"
                    className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg text-xs bg-white"
                  />
                </div>
                <div>
                  <label className="text-slate-600 font-medium block mb-1">Card Number (Simulated Token)</label>
                  <input
                    type="text"
                    value={cardNumber}
                    onChange={(e) => setCardNumber(e.target.value)}
                    className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg text-xs font-mono bg-white"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-slate-600 font-medium block mb-1">Expiry</label>
                    <input
                      type="text"
                      value={cardExpiry}
                      onChange={(e) => setCardExpiry(e.target.value)}
                      className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg text-xs font-mono bg-white"
                    />
                  </div>
                  <div>
                    <label className="text-slate-600 font-medium block mb-1">CVV (Tokenized)</label>
                    <input
                      type="password"
                      value={cardCvv}
                      onChange={(e) => setCardCvv(e.target.value)}
                      className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg text-xs font-mono bg-white"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Notes / Memo */}
            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">Payment Memo (Optional)</label>
              <input
                type="text"
                value={paymentNotes}
                onChange={(e) => setPaymentNotes(e.target.value)}
                placeholder="e.g. Fall term fee installment"
                className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg"
              />
            </div>

            {/* Security Guarantee Badge */}
            <div className="flex items-center gap-2 p-2 bg-slate-50 rounded-lg text-[11px] text-slate-500 border border-slate-100">
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>
                256-bit encrypted gateway simulation. Sensitive payment data is tokenized and never stored in plain text.
              </span>
            </div>

            {/* Modal Actions */}
            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
              <Button
                variant="outline"
                disabled={isProcessingPayment}
                onClick={() => setPayingFee(null)}
              >
                Cancel
              </Button>
              <Button
                onClick={handleProcessPayment}
                disabled={isProcessingPayment}
                className="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold flex items-center gap-2 shadow-sm"
              >
                {isProcessingPayment ? (
                  <>
                    <LoadingSpinner size="sm" />
                    <span>Settling Payment...</span>
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>
                      Authorize & Pay $
                      {(paymentAmountType === 'FULL'
                        ? payingFee.dueAmount
                        : parseFloat(customAmount) || 0
                      ).toFixed(2)}
                    </span>
                  </>
                )}
              </Button>
            </div>
          </div>
        </Modal>
      )}

      {/* ========================================================================= */}
      {/* 3. Official Printable Payment Receipt Modal */}
      {/* ========================================================================= */}
      {activeReceipt && (
        <Modal
          isOpen={true}
          onClose={() => setActiveReceipt(null)}
          title="Official Payment Receipt"
          size="lg"
        >
          <div className="space-y-5" id="printable-receipt-container">
            {/* Header / Letterhead */}
            <div className="text-center border-b-2 border-slate-800 pb-4">
              <div className="flex items-center justify-center gap-2 font-bold text-xl text-slate-900 uppercase tracking-tight">
                <Building className="w-6 h-6 text-indigo-600" />
                {activeReceipt.schoolInfo.name}
              </div>
              <p className="text-xs text-slate-600 mt-1">{activeReceipt.schoolInfo.address}</p>
              <p className="text-xs text-slate-500">
                Affiliation: {activeReceipt.schoolInfo.affiliationNumber} • Phone: {activeReceipt.schoolInfo.phone} • Email: {activeReceipt.schoolInfo.email}
              </p>
              <div className="inline-block mt-3 px-3 py-0.5 bg-slate-900 text-white font-bold text-xs rounded uppercase tracking-wider">
                Official Bursar Fee Receipt
              </div>
            </div>

            {/* Receipt & Transaction Meta */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs">
              <div>
                <span className="text-slate-500 uppercase font-semibold text-[10px] block">Receipt Number</span>
                <span className="font-mono font-bold text-slate-900">{activeReceipt.receiptNumber}</span>
              </div>
              <div>
                <span className="text-slate-500 uppercase font-semibold text-[10px] block">Transaction ID</span>
                <span className="font-mono font-bold text-indigo-600">{activeReceipt.transactionId}</span>
              </div>
              <div>
                <span className="text-slate-500 uppercase font-semibold text-[10px] block">Payment Date</span>
                <span className="font-semibold text-slate-800">{activeReceipt.paymentDetails.paymentDate.split('T')[0]}</span>
              </div>
              <div>
                <span className="text-slate-500 uppercase font-semibold text-[10px] block">Payment Status</span>
                <span className="font-bold text-emerald-600">{activeReceipt.paymentDetails.paymentStatus}</span>
              </div>
            </div>

            {/* Student & Guardian Particulars */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div className="border border-slate-200 rounded-lg p-3 bg-white">
                <div className="font-bold text-slate-800 uppercase text-[11px] border-b border-slate-100 pb-1 mb-1.5 flex items-center gap-1.5">
                  <GraduationCap className="w-3.5 h-3.5 text-indigo-600" />
                  Student Particulars
                </div>
                <div className="space-y-1 text-slate-700">
                  <div><span className="font-medium text-slate-500">Student Name:</span> {activeReceipt.studentInfo.name}</div>
                  <div><span className="font-medium text-slate-500">Admission No:</span> {activeReceipt.studentInfo.admissionNumber}</div>
                  <div><span className="font-medium text-slate-500">Class & Section:</span> {activeReceipt.studentInfo.className} ({activeReceipt.studentInfo.sectionName})</div>
                  <div><span className="font-medium text-slate-500">Roll Number:</span> {activeReceipt.studentInfo.rollNumber}</div>
                </div>
              </div>

              <div className="border border-slate-200 rounded-lg p-3 bg-white">
                <div className="font-bold text-slate-800 uppercase text-[11px] border-b border-slate-100 pb-1 mb-1.5 flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-indigo-600" />
                  Guardian / Payer Particulars
                </div>
                <div className="space-y-1 text-slate-700">
                  <div><span className="font-medium text-slate-500">Payer Name:</span> {activeReceipt.guardianInfo?.name || 'Authorized Parent/Guardian'}</div>
                  <div><span className="font-medium text-slate-500">Relationship:</span> {activeReceipt.guardianInfo?.relation || 'Primary Guardian'}</div>
                  <div><span className="font-medium text-slate-500">Contact Phone:</span> {activeReceipt.guardianInfo?.phone || 'On Record'}</div>
                  <div><span className="font-medium text-slate-500">Payment Gateway:</span> {activeReceipt.paymentDetails.paymentMethod}</div>
                </div>
              </div>
            </div>

            {/* Fee Itemization Table */}
            <div className="border border-slate-300 rounded-lg overflow-hidden text-xs">
              <table className="w-full text-left">
                <thead className="bg-slate-100 border-b border-slate-300 font-semibold text-slate-800">
                  <tr>
                    <th className="p-2.5">Fee Particulars & Academic Term</th>
                    <th className="p-2.5 text-right">Invoiced</th>
                    <th className="p-2.5 text-right">Discount</th>
                    <th className="p-2.5 text-right">Net Payable</th>
                    <th className="p-2.5 text-right">Amount Paid Now</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  <tr>
                    <td className="p-2.5">
                      <div className="font-bold text-slate-900">{activeReceipt.feeInfo.title}</div>
                      <div className="text-slate-500 text-[11px]">
                        {activeReceipt.feeInfo.academicSession} • {activeReceipt.feeInfo.term}
                      </div>
                    </td>
                    <td className="p-2.5 text-right">${Number(activeReceipt.feeInfo.totalFee ?? 0).toFixed(2)}</td>
                    <td className="p-2.5 text-right text-amber-700">
                      {(activeReceipt.feeInfo.discount ?? 0) > 0 ? `-$${Number(activeReceipt.feeInfo.discount).toFixed(2)}` : '—'}
                    </td>
                    <td className="p-2.5 text-right font-medium">${Number(activeReceipt.feeInfo.netPayable ?? 0).toFixed(2)}</td>
                    <td className="p-2.5 text-right font-bold text-emerald-700 text-sm">
                      ${Number(activeReceipt.feeInfo.amountPaidNow ?? 0).toFixed(2)}
                    </td>
                  </tr>
                  {((activeReceipt.feeInfo.scholarship ?? 0) > 0 || (activeReceipt.feeInfo.waiver ?? 0) > 0 || (activeReceipt.feeInfo.fine ?? 0) > 0) && (
                    <tr className="bg-slate-50/80 text-[11px] text-slate-600">
                      <td colSpan={5} className="p-2">
                        <div className="flex flex-wrap gap-3">
                          {(activeReceipt.feeInfo.scholarship ?? 0) > 0 && (
                            <span className="text-purple-700 font-medium">
                              Scholarship: -${Number(activeReceipt.feeInfo.scholarship).toFixed(2)}
                            </span>
                          )}
                          {(activeReceipt.feeInfo.waiver ?? 0) > 0 && (
                            <span className="text-teal-700 font-medium">
                              Waiver: -${Number(activeReceipt.feeInfo.waiver).toFixed(2)}
                            </span>
                          )}
                          {(activeReceipt.feeInfo.fine ?? 0) > 0 && (
                            <span className="text-rose-700 font-medium">
                              Late Fine: +${Number(activeReceipt.feeInfo.fine).toFixed(2)}
                            </span>
                          )}
                        </div>
                      </td>
                    </tr>
                  )}
                </tbody>
                <tfoot className="bg-slate-50 border-t-2 border-slate-300 font-semibold">
                  <tr>
                    <td colSpan={4} className="p-2.5 text-right text-slate-700">Total Settled in this Transaction:</td>
                    <td className="p-2.5 text-right font-bold text-base text-emerald-700">
                      ${Number(activeReceipt.feeInfo.amountPaidNow ?? 0).toFixed(2)}
                    </td>
                  </tr>
                  <tr>
                    <td colSpan={4} className="p-2.5 text-right text-slate-500">Remaining Balance Due:</td>
                    <td className="p-2.5 text-right font-bold text-slate-800">
                      ${Number(activeReceipt.feeInfo.remainingDue ?? 0).toFixed(2)}
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>

            {/* Signature & Digital Verification */}
            <div className="flex items-end justify-between pt-4 border-t border-slate-200 text-xs text-slate-500">
              <div>
                <div className="flex items-center gap-1.5 text-emerald-700 font-semibold mb-1">
                  <ShieldCheck className="w-4 h-4" />
                  <span>Digital Gateway Verification Verified</span>
                </div>
                <p className="text-[10px] font-mono">Ref: {activeReceipt.paymentDetails.gatewayReference}</p>
                <p className="text-[10px]">Issued at: {activeReceipt.issuedAt}</p>
              </div>

              <div className="text-center">
                <div className="w-36 border-b border-slate-400 pb-1 mb-1 font-serif italic text-slate-800 font-bold">
                  Evelyn Montgomery
                </div>
                <div className="text-[10px] text-slate-600 font-medium">
                  {activeReceipt.paymentDetails.authorizedSignatory}
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200 print:hidden">
              <Button variant="outline" onClick={() => setActiveReceipt(null)}>
                Close
              </Button>
              <Button
                onClick={() =>
                  triggerSafePrint({
                    elementOrId: 'printable-receipt-container',
                    fallbackTitle: `Receipt_${activeReceipt.receiptNumber}`
                  })
                }
                className="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold flex items-center gap-1.5 shadow-sm"
              >
                <Printer className="w-4 h-4" />
                Print / Save PDF
              </Button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
