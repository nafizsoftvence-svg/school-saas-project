import React, { useState, useEffect } from 'react';
import {
  TrendingUp,
  Award,
  Calendar,
  Clock,
  GraduationCap,
  Sparkles,
  ArrowLeft,
  CheckCircle2,
  AlertCircle,
  AlertTriangle,
  BookOpen,
  CalendarDays,
  FileText,
  UserCheck,
  BarChart3,
  Layers,
  ArrowUpRight,
  ArrowDownRight,
  Minus,
  CheckSquare,
  ShieldCheck,
  Scale,
  Users
} from 'lucide-react';
import { api } from '../../services/api.js';
import {
  GuardianChildSummary,
  GuardianChildProgressResponse,
  GuardianChildrenComparisonResponse,
  GradingScaleItem
} from '../../types/index.js';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner.js';
import { Badge } from '../../components/ui/Badge.js';
import { Button } from '../../components/ui/Button.js';
import { Modal } from '../../components/ui/Modal.js';

interface GuardianProgressPageProps {
  onNavigate?: (view: string) => void;
  initialStudentId?: string;
}

export const GuardianProgressPage: React.FC<GuardianProgressPageProps> = ({
  onNavigate,
  initialStudentId
}) => {
  // All linked children
  const [children, setChildren] = useState<GuardianChildSummary[]>([]);
  const [selectedChildId, setSelectedChildId] = useState<string | null>(initialStudentId || null);

  // View Mode: 'INDIVIDUAL' or 'COMPARISON'
  const [viewMode, setViewMode] = useState<'INDIVIDUAL' | 'COMPARISON'>('INDIVIDUAL');

  // Individual Progress Data
  const [progressData, setProgressData] = useState<GuardianChildProgressResponse | null>(null);
  const [isLoadingChildren, setIsLoadingChildren] = useState<boolean>(true);
  const [isLoadingProgress, setIsLoadingProgress] = useState<boolean>(false);

  // Multi-Child Comparison Data
  const [comparisonData, setComparisonData] = useState<GuardianChildrenComparisonResponse | null>(null);
  const [isLoadingComparison, setIsLoadingComparison] = useState<boolean>(false);

  const [error, setError] = useState<string | null>(null);
  const [authError, setAuthError] = useState<string | null>(null);

  // Grading Scale Modal
  const [isGradingScaleOpen, setIsGradingScaleOpen] = useState<boolean>(false);

  // 1. Fetch children
  useEffect(() => {
    const fetchChildren = async () => {
      setIsLoadingChildren(true);
      setAuthError(null);
      try {
        const res = await api.guardian.getChildren();
        const childrenList = Array.isArray(res?.data) ? res.data : Array.isArray(res) ? res : [];
        if (res?.success) {
          setChildren(childrenList);
          if (!selectedChildId && childrenList.length > 0) {
            setSelectedChildId(childrenList?.[0]?.id || null);
          } else if (selectedChildId) {
            const exists = childrenList.some((c: any) => c?.id === selectedChildId);
            if (!exists && childrenList.length > 0) {
              setSelectedChildId(childrenList?.[0]?.id || null);
            }
          }
        } else {
          setAuthError(typeof res.error === 'string' ? res.error : 'Failed to retrieve linked scholars.');
        }
      } catch (err: any) {
        setAuthError(err?.message || 'Error communicating with parent security services.');
      } finally {
        setIsLoadingChildren(false);
      }
    };

    fetchChildren();
  }, []);

  // 2. Fetch Progress Data for selected child
  const fetchProgress = async () => {
    if (!selectedChildId) return;

    setIsLoadingProgress(true);
    setError(null);
    try {
      const res = await api.guardian.getChildProgress(selectedChildId);
      if (res.success && res.data) {
        setProgressData(res.data);
      } else {
        if (res.code === 'FORBIDDEN_STUDENT_ACCESS') {
          setAuthError(typeof res.error === 'string' ? res.error : 'Security violation: Access denied.');
        } else {
          setError(typeof res.error === 'string' ? res.error : 'Failed to load scholar academic progress.');
        }
      }
    } catch (err: any) {
      setError(err?.message || 'Network error fetching academic progress.');
    } finally {
      setIsLoadingProgress(false);
    }
  };

  // 3. Fetch Comparison Data
  const fetchComparison = async () => {
    setIsLoadingComparison(true);
    try {
      const res = await api.guardian.getChildrenComparison();
      if (res.success && res.data) {
        setComparisonData(res.data);
      }
    } catch (err: any) {
      console.error('Failed to load comparison data', err);
    } finally {
      setIsLoadingComparison(false);
    }
  };

  useEffect(() => {
    if (selectedChildId && viewMode === 'INDIVIDUAL') {
      fetchProgress();
    } else if (viewMode === 'COMPARISON') {
      fetchComparison();
    }
  }, [selectedChildId, viewMode]);

  const activeChild = (children || []).find((c) => c.id === selectedChildId) || children?.[0];

  const getTrendBadge = (trend: string, delta: number) => {
    if (trend === 'UP') {
      return (
        <span className="flex items-center gap-1 text-[11px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-md border border-emerald-500/20">
          <ArrowUpRight className="w-3.5 h-3.5" /> +{Number(delta ?? 0).toFixed(1)}% Improving
        </span>
      );
    }
    if (trend === 'DOWN') {
      return (
        <span className="flex items-center gap-1 text-[11px] font-bold text-rose-400 bg-rose-500/10 px-2 py-0.5 rounded-md border border-rose-500/20">
          <ArrowDownRight className="w-3.5 h-3.5" /> -{Math.abs(Number(delta ?? 0)).toFixed(1)}% Declining
        </span>
      );
    }
    return (
      <span className="flex items-center gap-1 text-[11px] font-bold text-slate-400 bg-slate-500/10 px-2 py-0.5 rounded-md border border-slate-500/20">
        <Minus className="w-3.5 h-3.5" /> Stable
      </span>
    );
  };

  const getGradeBadge = (grade: string) => {
    if (grade === 'A+' || grade === 'A') {
      return <span className="px-2 py-0.5 rounded-md font-bold text-xs bg-emerald-500/10 text-emerald-300 border border-emerald-500/20">{grade}</span>;
    }
    if (grade === 'B+' || grade === 'B') {
      return <span className="px-2 py-0.5 rounded-md font-bold text-xs bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">{grade}</span>;
    }
    return <span className="px-2 py-0.5 rounded-md font-bold text-xs bg-amber-500/10 text-amber-300 border border-amber-500/20">{grade}</span>;
  };

  if (isLoadingChildren) {
    return (
      <div className="p-12 flex flex-col items-center justify-center min-h-[450px] space-y-4">
        <LoadingSpinner size="lg" message="Loading verified scholars..." />
      </div>
    );
  }

  if (authError) {
    return (
      <div className="p-8 max-w-2xl mx-auto space-y-6 text-center">
        <div className="w-16 h-16 rounded-3xl bg-rose-500/20 border border-rose-500/30 text-rose-400 flex items-center justify-center mx-auto shadow-lg shadow-rose-950/40">
          <AlertTriangle className="w-8 h-8" />
        </div>
        <div className="space-y-2">
          <h2 className="text-2xl font-bold text-white tracking-tight">Access Restricted</h2>
          <p className="text-sm text-slate-400">{authError}</p>
        </div>
        <div className="flex justify-center gap-3">
          <Button
            id="guardian-progress-back-btn"
            variant="secondary"
            onClick={() => onNavigate && onNavigate('guardian-dashboard')}
          >
            <ArrowLeft className="w-4 h-4 mr-2" /> Back to Dashboard
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      {/* 1. Header & View Mode Switcher */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <button
              onClick={() => onNavigate && onNavigate('guardian-dashboard')}
              className="text-xs font-semibold text-slate-400 hover:text-amber-400 transition-colors flex items-center gap-1"
            >
              <ArrowLeft className="w-3.5 h-3.5" /> Portal Dashboard
            </button>
            <span className="text-slate-600">/</span>
            <span className="text-xs font-semibold text-amber-400">Academic Progress</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight flex items-center gap-3">
            <TrendingUp className="w-8 h-8 text-amber-400" />
            Scholar Academic Progress &amp; Trends
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Holistic academic trajectory, GPA trends, attendance-to-performance correlations, and cross-child analytics.
          </p>
        </div>

        {/* View Mode Toggle & Scale Reference */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="p-1 rounded-2xl bg-slate-900/80 border border-white/10 flex items-center gap-1">
            <button
              id="progress-view-individual-btn"
              onClick={() => setViewMode('INDIVIDUAL')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                viewMode === 'INDIVIDUAL'
                  ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Individual Analysis
            </button>
            <button
              id="progress-view-comparison-btn"
              onClick={() => setViewMode('COMPARISON')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                viewMode === 'COMPARISON'
                  ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              Compare Scholars
            </button>
          </div>

          <Button
            id="guardian-grading-scale-btn"
            variant="outline"
            size="sm"
            onClick={() => setIsGradingScaleOpen(true)}
            className="text-xs border-white/10 hover:border-amber-500/40"
          >
            <Scale className="w-3.5 h-3.5 mr-1.5 text-amber-400" />
            Grading Scale
          </Button>
        </div>
      </div>

      {/* 2. Individual Child View Mode */}
      {viewMode === 'INDIVIDUAL' && (
        <div className="space-y-8 animate-in fade-in duration-200">
          {/* Child Selector */}
          <div className="rounded-3xl bg-slate-900/60 border border-white/10 p-5 backdrop-blur-xl">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 shrink-0">
                  <GraduationCap className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs font-semibold text-amber-400 uppercase tracking-wider">Active Scholar</div>
                  <div className="text-sm font-bold text-white">
                    {activeChild ? `${activeChild.name} (${activeChild.className} - ${activeChild.sectionName})` : 'Select Scholar'}
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                {(children || []).map((child) => {
                  const isSelected = child.id === selectedChildId;
                  return (
                    <button
                      key={child.id}
                      id={`select-child-prog-${child.id}`}
                      onClick={() => setSelectedChildId(child.id)}
                      className={`flex items-center gap-3 px-4 py-2.5 rounded-2xl text-xs font-bold transition-all border ${
                        isSelected
                          ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-lg shadow-amber-500/20 scale-[1.02]'
                          : 'bg-slate-800/80 text-slate-300 border-white/5 hover:border-white/20 hover:bg-slate-800'
                      }`}
                    >
                      <div
                        className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-black ${
                          isSelected ? 'bg-slate-950 text-amber-400' : 'bg-amber-500/20 text-amber-300'
                        }`}
                      >
                        {child.name.charAt(0)}
                      </div>
                      <div className="text-left">
                        <div>{child.name}</div>
                        <div className={`text-[10px] ${isSelected ? 'text-slate-900 font-semibold' : 'text-slate-400'}`}>
                          {child.className} • {child.rollNumber}
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Loading or Progress Content */}
          {isLoadingProgress ? (
            <div className="p-12 flex flex-col items-center justify-center min-h-[350px] space-y-4">
              <LoadingSpinner size="md" message="Calculating trajectory and performance metrics..." />
            </div>
          ) : error ? (
            <div className="p-8 rounded-3xl bg-rose-500/10 border border-rose-500/20 text-center space-y-3">
              <AlertCircle className="w-8 h-8 text-rose-400 mx-auto" />
              <h3 className="text-base font-bold text-white">Unable to load progress analytics</h3>
              <p className="text-xs text-slate-400 max-w-md mx-auto">{error}</p>
              <Button size="sm" variant="secondary" onClick={fetchProgress}>
                Retry
              </Button>
            </div>
          ) : progressData ? (
            <div className="space-y-8">
              {/* Performance Metrics Hero Banner */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div className="rounded-3xl bg-slate-900/60 border border-white/10 p-5 backdrop-blur-xl">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-amber-400">Cumulative GPA</span>
                    <div className="w-8 h-8 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
                      <Award className="w-4 h-4" />
                    </div>
                  </div>
                  <div className="text-2xl font-black text-white mt-2">
                    {Number(progressData?.overview?.cumulativeGPA ?? 0).toFixed(2)}
                  </div>
                  <div className="text-[11px] text-slate-400 mt-1">Grade: {progressData.overview.overallGrade}</div>
                </div>

                <div className="rounded-3xl bg-slate-900/60 border border-white/10 p-5 backdrop-blur-xl">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-emerald-400">Average Score</span>
                    <div className="w-8 h-8 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
                      <TrendingUp className="w-4 h-4" />
                    </div>
                  </div>
                  <div className="text-2xl font-black text-white mt-2">
                    {Number(progressData?.overview?.averagePercentage ?? 0).toFixed(1)}%
                  </div>
                  <div className="text-[11px] text-emerald-300 mt-1">
                    Highest: {Number(progressData?.overview?.highestPercentage ?? 0).toFixed(1)}%
                  </div>
                </div>

                <div className="rounded-3xl bg-slate-900/60 border border-white/10 p-5 backdrop-blur-xl">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-indigo-400">Credits Completed</span>
                    <div className="w-8 h-8 rounded-xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400">
                      <Layers className="w-4 h-4" />
                    </div>
                  </div>
                  <div className="text-2xl font-black text-white mt-2">
                    {progressData.overview.totalCreditsCompleted}
                  </div>
                  <div className="text-[11px] text-indigo-300 mt-1">Curriculum units</div>
                </div>

                <div className="rounded-3xl bg-slate-900/60 border border-white/10 p-5 backdrop-blur-xl">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-purple-400">Exams Evaluated</span>
                    <div className="w-8 h-8 rounded-xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400">
                      <CalendarDays className="w-4 h-4" />
                    </div>
                  </div>
                  <div className="text-2xl font-black text-white mt-2">
                    {progressData.overview.totalExamsTaken}
                  </div>
                  <div className="text-[11px] text-purple-300 mt-1">Official sittings</div>
                </div>
              </div>

              {/* Attendance vs Performance Correlation Card */}
              {progressData?.attendanceCorrelation && (
                <div className="rounded-3xl bg-gradient-to-br from-slate-900/90 via-slate-900/70 to-emerald-950/30 border border-white/10 p-6 backdrop-blur-xl">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                    <div className="space-y-2 max-w-xl">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
                          <CheckSquare className="w-3.5 h-3.5" /> Attendance &amp; Academic Correlation Analysis
                        </span>
                        <span className="text-slate-500">•</span>
                        <span className="text-xs font-semibold text-emerald-300 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
                          {progressData.attendanceCorrelation?.correlationRating}
                        </span>
                      </div>
                      <h3 className="text-lg font-bold text-white tracking-tight">
                        Attendance Rate: {(progressData.attendanceCorrelation?.attendancePercentage ?? 0).toFixed(1)}% vs. Academic Score: {(progressData.attendanceCorrelation?.academicAveragePercentage ?? 0).toFixed(1)}%
                      </h3>
                      <p className="text-xs text-slate-300 leading-relaxed">
                        {progressData.attendanceCorrelation?.narrativeInsight}
                      </p>
                    </div>

                    <div className="flex items-center gap-4 shrink-0 bg-slate-950/40 p-4 rounded-2xl border border-white/5">
                      <div className="text-center">
                        <div className="text-[10px] uppercase font-bold text-slate-400">Attendance</div>
                        <div className="text-xl font-black text-emerald-400 mt-0.5">
                          {(progressData.attendanceCorrelation?.attendancePercentage ?? 0).toFixed(1)}%
                        </div>
                      </div>
                      <div className="w-px h-8 bg-white/10" />
                      <div className="text-center">
                        <div className="text-[10px] uppercase font-bold text-slate-400">Avg Exam Mark</div>
                        <div className="text-xl font-black text-amber-400 mt-0.5">
                          {(progressData.attendanceCorrelation?.academicAveragePercentage ?? 0).toFixed(1)}%
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Subject-Wise Performance & Trends */}
              <div className="rounded-3xl bg-slate-900/60 border border-white/10 p-6 backdrop-blur-xl space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-bold text-white tracking-tight flex items-center gap-2">
                      <BookOpen className="w-5 h-5 text-amber-400" />
                      Subject-Wise Academic Trajectory
                    </h3>
                    <p className="text-xs text-slate-400 mt-0.5">
                      Subject breakdown comparing past term exams and performance trajectory for {activeChild?.name}.
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {(progressData?.subjectTrends || []).map((st) => (
                    <div
                      key={st.subjectId}
                      className="p-5 rounded-2xl bg-slate-800/50 border border-white/5 space-y-3"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <div className="flex items-center gap-2">
                            <h4 className="font-bold text-white text-sm">{st.subjectName}</h4>
                            <span className="text-[11px] font-mono text-amber-400 bg-amber-400/10 px-1.5 py-0.5 rounded border border-amber-400/20">
                              {st.subjectCode}
                            </span>
                          </div>
                          <div className="text-xs text-slate-400 mt-0.5">{st.credits} Credits</div>
                        </div>

                        <div>{getTrendBadge(st.trend, st.delta)}</div>
                      </div>

                      {/* Progress Bar */}
                      <div className="space-y-1">
                        <div className="flex justify-between text-xs">
                          <span className="text-slate-400">Average: <strong className="text-white">{Number(st?.averageMarks ?? 0).toFixed(1)}%</strong></span>
                          <span className="text-slate-400">Peak: <strong className="text-emerald-400">{Number(st?.highestMarks ?? 0).toFixed(1)}%</strong></span>
                        </div>
                        <div className="w-full h-2 rounded-full bg-slate-950/60 overflow-hidden border border-white/5">
                          <div
                            className="h-full rounded-full bg-gradient-to-r from-amber-500 to-emerald-400 transition-all duration-500"
                            style={{ width: `${Math.min(100, Math.max(0, st.averageMarks || 0))}%` }}
                          />
                        </div>
                      </div>

                      <div className="flex items-center justify-between text-xs pt-1 border-t border-white/5">
                        <span className="text-slate-400">Latest Grade: {getGradeBadge(st.latestGrade)}</span>
                        <span className="text-slate-400 font-mono">GP: <strong className="text-slate-200">{Number(st?.latestGradePoint ?? 0).toFixed(1)}</strong></span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Exam-Wise Performance Timeline */}
              <div className="rounded-3xl bg-slate-900/60 border border-white/10 p-6 backdrop-blur-xl space-y-4">
                <h3 className="text-lg font-bold text-white tracking-tight flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-indigo-400" />
                  Examination Timeline
                </h3>
                <p className="text-xs text-slate-400">
                  Chronological progression of overall percentages and grade point averages across school terms.
                </p>

                <div className="overflow-x-auto rounded-2xl border border-white/10 bg-slate-950/40">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="border-b border-white/10 bg-slate-900/80 text-slate-400 uppercase font-semibold">
                        <th className="py-3 px-4">Examination</th>
                        <th className="py-3 px-4 text-center">Session &amp; Year</th>
                        <th className="py-3 px-4 text-center">Term</th>
                        <th className="py-3 px-4 text-center">Percentage</th>
                        <th className="py-3 px-4 text-center">GPA</th>
                        <th className="py-3 px-4 text-center">Grade</th>
                        <th className="py-3 px-4 text-center">Total Marks</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                      {(progressData?.examTrends || []).map((et) => (
                        <tr key={et.examId} className="hover:bg-white/[0.02]">
                          <td className="py-3.5 px-4 font-bold text-white">{et.examName}</td>
                          <td className="py-3.5 px-4 text-center text-slate-300">{et.academicYear}</td>
                          <td className="py-3.5 px-4 text-center text-slate-400">{et.term}</td>
                          <td className="py-3.5 px-4 text-center font-black text-emerald-400">
                            {Number(et?.percentage ?? 0).toFixed(1)}%
                          </td>
                          <td className="py-3.5 px-4 text-center font-bold text-amber-400">{Number(et?.gpa ?? 0).toFixed(2)}</td>
                          <td className="py-3.5 px-4 text-center">{getGradeBadge(et.grade)}</td>
                          <td className="py-3.5 px-4 text-center text-slate-300 font-mono">
                            {et.totalObtainedMarks} / {et.totalFullMarks}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          ) : null}
        </div>
      )}

      {/* 3. Multi-Child Comparison Matrix Mode */}
      {viewMode === 'COMPARISON' && (
        <div className="space-y-6 animate-in fade-in duration-200">
          <div className="p-6 rounded-3xl bg-slate-900/60 border border-white/10 backdrop-blur-xl">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-lg font-bold text-white tracking-tight flex items-center gap-2">
                  <Users className="w-5 h-5 text-amber-400" />
                  Comparative Scholar Performance Matrix
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Side-by-side comparative indicators across all scholars registered under your guardianship.
                </p>
              </div>
            </div>

            {isLoadingComparison ? (
              <div className="p-12 flex flex-col items-center justify-center min-h-[300px] space-y-4">
                <LoadingSpinner size="md" message="Compiling comparative scholar matrix..." />
              </div>
            ) : !comparisonData || (comparisonData.comparison || []).length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-400">
                No comparative scholar records available.
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {(comparisonData.comparison || []).map((c) => (
                  <div
                    key={c.studentId}
                    id={`scholar-comparison-${c.studentId}`}
                    className="p-6 rounded-3xl bg-slate-800/40 border border-white/10 hover:border-amber-500/40 transition-all flex flex-col justify-between space-y-5"
                  >
                    <div className="space-y-4">
                      {/* Scholar Header */}
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 font-bold text-lg">
                          {c.studentName.charAt(0)}
                        </div>
                        <div>
                          <h4 className="font-bold text-white text-base">{c.studentName}</h4>
                          <div className="text-xs text-slate-400">
                            {c.className} ({c.sectionName}) • #{c.rollNumber}
                          </div>
                          <div className="text-[10px] font-mono text-amber-400/80 mt-0.5">
                            Adm: {c.admissionNumber}
                          </div>
                        </div>
                      </div>

                      {/* Performance Grid */}
                      <div className="grid grid-cols-2 gap-2.5 text-xs">
                        <div className="p-3 rounded-2xl bg-slate-900/80 border border-white/5">
                          <span className="text-[10px] text-slate-400 uppercase font-semibold">Cumulative GPA</span>
                          <div className="text-lg font-black text-amber-400 mt-0.5">
                            {(c.cumulativeGPA ?? 0) > 0 ? Number(c.cumulativeGPA).toFixed(2) : 'N/A'}
                          </div>
                          <span className="text-[10px] text-slate-500">Grade {c.overallGrade}</span>
                        </div>

                        <div className="p-3 rounded-2xl bg-slate-900/80 border border-white/5">
                          <span className="text-[10px] text-slate-400 uppercase font-semibold">Average Mark</span>
                          <div className="text-lg font-black text-emerald-400 mt-0.5">
                            {Number(c?.averagePercentage ?? 0).toFixed(1)}%
                          </div>
                          <span className="text-[10px] text-slate-500">{c.totalExamsTaken} Exams</span>
                        </div>

                        <div className="p-3 rounded-2xl bg-slate-900/80 border border-white/5">
                          <span className="text-[10px] text-slate-400 uppercase font-semibold">Attendance</span>
                          <div className="text-lg font-black text-indigo-400 mt-0.5">
                            {Number(c?.attendance?.percentage ?? 0).toFixed(1)}%
                          </div>
                          <span className="text-[10px] text-slate-500">{c.attendance?.presentDays ?? 0}/{c.attendance?.totalDays ?? 0} Days</span>
                        </div>

                        <div className="p-3 rounded-2xl bg-slate-900/80 border border-white/5">
                          <span className="text-[10px] text-slate-400 uppercase font-semibold">Class Rank</span>
                          <div className="text-lg font-black text-purple-400 mt-0.5">
                            {c.latestResult?.classRank ? `#${c.latestResult.classRank}` : 'Top Tier'}
                          </div>
                          <span className="text-[10px] text-slate-500">
                            {c.latestResult ? c.latestResult.examName : 'Current term'}
                          </span>
                        </div>
                      </div>

                      {/* Pending Tasks & Activities */}
                      <div className="p-3 rounded-2xl bg-white/[0.02] border border-white/5 flex items-center justify-between text-xs">
                        <span className="text-slate-400">Pending Homework &amp; Tasks:</span>
                        <span className="font-bold text-amber-400">
                          {c.pendingActivities.homework + c.pendingActivities.assignments} Active
                        </span>
                      </div>
                    </div>

                    {/* Quick Switch to Child Button */}
                    <div className="pt-2 border-t border-white/5 flex items-center gap-2">
                      <Button
                        id={`switch-to-child-${c.studentId}`}
                        variant="secondary"
                        size="sm"
                        onClick={() => {
                          setSelectedChildId(c.studentId);
                          setViewMode('INDIVIDUAL');
                        }}
                        className="w-full text-xs"
                      >
                        Inspect Full Profile
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* 4. Grading Scale Reference Modal */}
      <Modal
        isOpen={isGradingScaleOpen}
        onClose={() => setIsGradingScaleOpen(false)}
        title="Institutional Academic Grading Scale"
        maxWidth="max-w-xl"
      >
        <div className="space-y-4">
          <p className="text-xs text-slate-400">
            Standard 4.00 evaluation criteria utilized for calculation of letter grades, grade points, and academic honors.
          </p>

          <div className="overflow-x-auto rounded-2xl border border-white/10 bg-slate-950/60">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-white/10 bg-slate-900 text-slate-400 uppercase font-semibold">
                  <th className="py-3 px-4">Grade</th>
                  <th className="py-3 px-4 text-center">Score Range (%)</th>
                  <th className="py-3 px-4 text-center">Grade Point</th>
                  <th className="py-3 px-4">Performance Standard</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                <tr className="hover:bg-white/[0.02]">
                  <td className="py-2.5 px-4 font-bold text-emerald-400">A+</td>
                  <td className="py-2.5 px-4 text-center text-slate-300">90% - 100%</td>
                  <td className="py-2.5 px-4 text-center font-mono font-bold text-amber-400">4.0</td>
                  <td className="py-2.5 px-4 text-slate-300">Outstanding Distinction</td>
                </tr>
                <tr className="hover:bg-white/[0.02]">
                  <td className="py-2.5 px-4 font-bold text-emerald-300">A</td>
                  <td className="py-2.5 px-4 text-center text-slate-300">80% - 89.9%</td>
                  <td className="py-2.5 px-4 text-center font-mono font-bold text-amber-400">3.7</td>
                  <td className="py-2.5 px-4 text-slate-300">Excellent</td>
                </tr>
                <tr className="hover:bg-white/[0.02]">
                  <td className="py-2.5 px-4 font-bold text-indigo-400">B+</td>
                  <td className="py-2.5 px-4 text-center text-slate-300">75% - 79.9%</td>
                  <td className="py-2.5 px-4 text-center font-mono font-bold text-amber-400">3.3</td>
                  <td className="py-2.5 px-4 text-slate-300">Very Good</td>
                </tr>
                <tr className="hover:bg-white/[0.02]">
                  <td className="py-2.5 px-4 font-bold text-indigo-300">B</td>
                  <td className="py-2.5 px-4 text-center text-slate-300">70% - 74.9%</td>
                  <td className="py-2.5 px-4 text-center font-mono font-bold text-amber-400">3.0</td>
                  <td className="py-2.5 px-4 text-slate-300">Good</td>
                </tr>
                <tr className="hover:bg-white/[0.02]">
                  <td className="py-2.5 px-4 font-bold text-amber-400">C+</td>
                  <td className="py-2.5 px-4 text-center text-slate-300">65% - 69.9%</td>
                  <td className="py-2.5 px-4 text-center font-mono font-bold text-amber-400">2.7</td>
                  <td className="py-2.5 px-4 text-slate-300">Above Average</td>
                </tr>
                <tr className="hover:bg-white/[0.02]">
                  <td className="py-2.5 px-4 font-bold text-amber-300">C</td>
                  <td className="py-2.5 px-4 text-center text-slate-300">60% - 64.9%</td>
                  <td className="py-2.5 px-4 text-center font-mono font-bold text-amber-400">2.0</td>
                  <td className="py-2.5 px-4 text-slate-300">Average / Satisfactory</td>
                </tr>
                <tr className="hover:bg-white/[0.02]">
                  <td className="py-2.5 px-4 font-bold text-rose-400">F</td>
                  <td className="py-2.5 px-4 text-center text-slate-300">0% - 39.9%</td>
                  <td className="py-2.5 px-4 text-center font-mono font-bold text-rose-400">0.0</td>
                  <td className="py-2.5 px-4 text-rose-300">Unsatisfactory / Fail</td>
                </tr>
              </tbody>
            </table>
          </div>

          <div className="flex justify-end pt-2">
            <Button variant="secondary" onClick={() => setIsGradingScaleOpen(false)}>
              Close
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
