import React, { useState, useEffect } from 'react';
import {
  Bell,
  Megaphone,
  CheckCheck,
  Search,
  Filter,
  RefreshCw,
  Clock,
  ShieldAlert,
  BookOpen,
  Info,
  Check
} from 'lucide-react';
import { api } from '../../services/api.js';
import { NotificationItem } from '../../types/index.js';
import { useToast } from '../../context/ToastContext.js';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner.js';
import { Badge } from '../../components/ui/Badge.js';
import { Button } from '../../components/ui/Button.js';

export const GuardianNotificationsPage: React.FC = () => {
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [category, setCategory] = useState<string>('all');
  const [unreadOnly, setUnreadOnly] = useState<boolean>(false);
  const [search, setSearch] = useState<string>('');
  const { addToast } = useToast();

  const fetchNotifications = async () => {
    setIsLoading(true);
    try {
      const res = await api.guardian.getNotifications({
        category: category as any,
        unreadOnly,
        search: search || undefined
      });
      if (res.success && res.data) {
        setNotifications(res.data);
      }
    } catch (err: any) {
      addToast('Failed to load school notifications.', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchNotifications();
  }, [category, unreadOnly]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchNotifications();
  };

  const handleMarkRead = async (id: string) => {
    try {
      const res = await api.guardian.markNotificationRead(id);
      if (res.success) {
        setNotifications((prev) =>
          prev.map((n) => (n.id === id ? { ...n, isRead: true } : n))
        );
        addToast('Notification marked as read.', 'success');
      }
    } catch (err: any) {
      addToast('Failed to update notification status.', 'error');
    }
  };

  const handleMarkAllRead = async () => {
    try {
      const res = await api.guardian.markAllNotificationsRead();
      if (res.success) {
        setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
        addToast('All notifications marked as read.', 'success');
      }
    } catch (err: any) {
      addToast('Failed to mark notifications read.', 'error');
    }
  };

  const unreadCount = (notifications || []).filter((n) => !n.isRead).length;

  const categories = [
    { id: 'all', label: 'All Notices' },
    { id: 'academic', label: 'Academic & Courses' },
    { id: 'security', label: 'Safety & Security' },
    { id: 'general', label: 'General School' }
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 rounded-full text-xs font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1.5">
              <Megaphone className="w-3.5 h-3.5" />
              School Communications
            </span>
            {unreadCount > 0 && (
              <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-rose-500/20 text-rose-300 border border-rose-500/30">
                {unreadCount} Unread
              </span>
            )}
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight mt-2">
            School Notices &amp; Guardian Alerts
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-2xl">
            Official announcements, academic session milestones, and safety updates from the school administration.
          </p>
        </div>

        <div className="flex items-center gap-3">
          {unreadCount > 0 && (
            <Button
              id="mark-all-read-btn"
              onClick={handleMarkAllRead}
              variant="secondary"
              className="text-xs"
            >
              <CheckCheck className="w-3.5 h-3.5 mr-1.5" /> Mark All as Read
            </Button>
          )}
          <Button onClick={fetchNotifications} variant="secondary" className="text-xs">
            <RefreshCw className="w-3.5 h-3.5 mr-1.5" /> Refresh
          </Button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 rounded-3xl bg-white/5 border border-white/10 backdrop-blur-xl space-y-4">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          {/* Category Tabs */}
          <div className="flex flex-wrap items-center gap-1.5 w-full sm:w-auto">
            {(categories || []).map((cat) => (
              <button
                key={cat.id}
                id={`cat-filter-${cat.id}`}
                onClick={() => setCategory(cat.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  category === cat.id
                    ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                    : 'text-slate-400 hover:text-white hover:bg-white/5'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* Unread Only Toggle */}
          <div className="flex items-center gap-2 text-xs font-medium text-slate-300 w-full sm:w-auto justify-end">
            <label className="flex items-center gap-2 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={unreadOnly}
                onChange={(e) => setUnreadOnly(e.target.checked)}
                className="w-4 h-4 rounded bg-slate-900 border-white/20 text-amber-500 focus:ring-amber-500 cursor-pointer"
              />
              <span>Unread Only</span>
            </label>
          </div>
        </div>

        {/* Search Input */}
        <form onSubmit={handleSearchSubmit} className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search within notice headlines and content..."
            className="w-full pl-10 pr-20 py-2.5 bg-slate-900/80 border border-white/10 rounded-2xl text-xs text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-500"
          />
          <Button
            type="submit"
            variant="secondary"
            className="absolute right-1.5 top-1/2 -translate-y-1/2 py-1 px-3 text-xs"
          >
            Search
          </Button>
        </form>
      </div>

      {/* Notifications Feed */}
      {isLoading ? (
        <div className="p-12 flex items-center justify-center">
          <LoadingSpinner size="md" message="Fetching school notice feeds..." />
        </div>
      ) : (notifications?.length || 0) === 0 ? (
        <div className="p-12 text-center rounded-3xl bg-white/5 border border-white/10 space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-white/10 text-slate-400 flex items-center justify-center mx-auto">
            <Bell className="w-6 h-6" />
          </div>
          <h3 className="text-base font-bold text-white">No Notices Found</h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            You're all caught up! No active notices match the selected category or filter.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {(notifications || []).map((notif) => {
            const isUnread = !notif.isRead;
            const categoryIcons: Record<string, any> = {
              academic: BookOpen,
              security: ShieldAlert,
              general: Info,
              system: Bell
            };
            const Icon = categoryIcons[notif.category || 'general'] || Bell;

            return (
              <div
                key={notif.id}
                id={`notice-item-${notif.id}`}
                className={`p-5 rounded-3xl border transition-all space-y-3 relative overflow-hidden backdrop-blur-xl ${
                  isUnread
                    ? 'bg-amber-950/20 border-amber-500/40 shadow-lg shadow-amber-500/5'
                    : 'bg-white/5 border-white/10 hover:border-white/15'
                }`}
              >
                {isUnread && (
                  <div className="absolute top-0 left-0 w-1.5 h-full bg-amber-500" />
                )}

                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-start gap-3.5 flex-1 min-w-0">
                    <div
                      className={`w-10 h-10 rounded-2xl flex items-center justify-center flex-shrink-0 mt-0.5 ${
                        notif.category === 'academic'
                          ? 'bg-indigo-500/20 border border-indigo-500/30 text-indigo-300'
                          : notif.category === 'security'
                          ? 'bg-rose-500/20 border border-rose-500/30 text-rose-300'
                          : 'bg-amber-500/20 border border-amber-500/30 text-amber-300'
                      }`}
                    >
                      <Icon className="w-5 h-5" />
                    </div>

                    <div className="flex-1 min-w-0 space-y-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <h2 className="text-sm font-bold text-white tracking-tight">
                          {notif.title}
                        </h2>
                        {isUnread && (
                          <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                        )}
                      </div>
                      <p className="text-xs text-slate-300 leading-relaxed">{notif.message}</p>
                    </div>
                  </div>

                  <div className="flex flex-col items-end gap-2 flex-shrink-0">
                    <Badge
                      variant={
                        notif.category === 'academic'
                          ? 'info'
                          : notif.category === 'security'
                          ? 'danger'
                          : 'warning'
                      }
                      size="sm"
                    >
                      {notif.category || 'Notice'}
                    </Badge>
                    {isUnread && (
                      <button
                        onClick={() => handleMarkRead(notif.id)}
                        className="text-[11px] font-semibold text-amber-400 hover:text-amber-300 flex items-center gap-1 cursor-pointer pt-1"
                      >
                        <Check className="w-3 h-3" /> Mark Read
                      </button>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-2 text-[10px] text-slate-400 font-mono pt-2 border-t border-white/5">
                  <Clock className="w-3 h-3" />
                  <span>Dispatched: {new Date(notif.createdAt).toLocaleString()}</span>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
