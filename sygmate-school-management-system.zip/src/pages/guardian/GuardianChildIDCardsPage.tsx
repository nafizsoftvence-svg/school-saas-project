import React, { useState, useEffect } from 'react';
import {
  CreditCard,
  FileText,
  Printer,
  ShieldCheck,
  Upload,
  AlertTriangle,
  Users,
  Calendar,
  CheckCircle2,
  RefreshCw,
  PhoneCall
} from 'lucide-react';
import { StudentIDCard, StudentDocument, StudentIDCardTemplateLayout } from '../../types';
import { StudentIDCardVisual } from '../../components/idcards/StudentIDCardVisual';
import { StudentDocumentUploadModal } from '../../components/documents/StudentDocumentUploadModal';
import { StudentIDCardReissueModal } from '../../components/idcards/StudentIDCardReissueModal';
import { useAuth } from '../../context/AuthContext';
import { triggerSafePrint } from '../../utils/printPdf.js';

export const GuardianChildIDCardsPage: React.FC = () => {
  const { user } = useAuth();
  const [selectedChildId, setSelectedChildId] = useState<string>('student-1');
  const [childrenList, setChildrenList] = useState<Array<{ id: string; name: string; grade: string; roll: string }>>([
    { id: 'student-1', name: 'Liam Rivera', grade: 'Grade 10-A', roll: 'G10-A-01' },
    { id: 'student-2', name: 'Sophia Chen', grade: 'Grade 8-B', roll: 'G8-B-14' }
  ]);
  const [card, setCard] = useState<StudentIDCard | null>(null);
  const [documents, setDocuments] = useState<StudentDocument[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [activeTemplate, setActiveTemplate] = useState<StudentIDCardTemplateLayout>('modern-vertical');
  const [isUploadModalOpen, setIsUploadModalOpen] = useState<boolean>(false);
  const [isReissueModalOpen, setIsReissueModalOpen] = useState<boolean>(false);

  const fetchChildCardAndDocs = async (childId: string) => {
    setLoading(true);
    try {
      const token = localStorage.getItem('sygmate_auth_token') || localStorage.getItem('token');
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {})
      };

      const [cardsRes, docsRes] = await Promise.all([
        fetch(`/api/documents-idcards/students/${childId}/id-card`, { headers }),
        fetch(`/api/documents-idcards/students/${childId}/documents`, { headers })
      ]);

      if (cardsRes.ok && (cardsRes.headers.get('content-type') || '').includes('application/json')) {
        const cData = await cardsRes.json();
        if (cData.success && cData.data) {
          setCard(cData.data);
          setActiveTemplate(cData.data.templateId || 'modern-vertical');
        } else {
          setCard(null);
        }
      } else {
        setCard(null);
      }

      if (docsRes.ok && (docsRes.headers.get('content-type') || '').includes('application/json')) {
        const dData = await docsRes.json();
        if (dData.success && dData.data) {
          setDocuments(dData.data);
        } else {
          setDocuments([]);
        }
      } else {
        setDocuments([]);
      }
    } catch (err) {
      console.error('Error fetching child ID card and documents:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchChildCardAndDocs(selectedChildId);
  }, [selectedChildId]);

  const displayedCard = card || {
    id: `idc-${selectedChildId}`,
    studentId: selectedChildId,
    studentName: childrenList.find(c => c.id === selectedChildId)?.name || 'Liam Rivera',
    admissionNumber: selectedChildId === 'student-1' ? 'ADM-2026-0842' : 'ADM-2026-0914',
    cardNumber: `IDC-2026-${selectedChildId === 'student-1' ? '00842' : '00914'}`,
    templateId: activeTemplate,
    status: 'ISSUED',
    academicSessionName: '2026-2027 Academic Year',
    className: selectedChildId === 'student-1' ? 'Grade 10' : 'Grade 8',
    sectionName: selectedChildId === 'student-1' ? 'Section A (Advanced)' : 'Section B',
    rollNumber: selectedChildId === 'student-1' ? 'G10-A-01' : 'G8-B-14',
    bloodGroup: 'O+',
    emergencyContact: '+1 (555) 019-8811',
    avatarUrl: selectedChildId === 'student-1'
      ? 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&q=80&w=256'
      : 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&q=80&w=256',
    issueDate: '2026-08-20',
    expiryDate: '2027-06-30'
  } as StudentIDCard;

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono font-bold text-indigo-600 bg-indigo-50 px-2.5 py-0.5 rounded-full border border-indigo-100 uppercase tracking-wide">
              Parent & Guardian Portal
            </span>
            <span className="text-xs text-slate-400">• Institutional Access Badges</span>
          </div>
          <h1 className="text-2xl font-black text-slate-900 mt-1">Child ID Passes & Document Records</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            View, print, or request reissuance for your children's official digital identity passes and academic documentation.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => triggerSafePrint({ elementOrId: 'printable-guardian-id-card', fallbackTitle: 'Student_ID_Badge' })}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-xs transition"
          >
            <Printer className="w-4 h-4" />
            Print ID Badge
          </button>
          <button
            type="button"
            onClick={() => setIsUploadModalOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition"
          >
            <Upload className="w-4 h-4 text-slate-500" />
            Submit Certificate
          </button>
        </div>
      </div>

      {/* Child Switcher Tabs */}
      <div className="flex items-center gap-2 bg-slate-100/80 p-1.5 rounded-2xl w-fit border border-slate-200">
        <span className="text-xs font-bold text-slate-500 px-3 flex items-center gap-1.5">
          <Users className="w-3.5 h-3.5" />
          Select Child:
        </span>
        {childrenList.map(c => (
          <button
            key={c.id}
            type="button"
            onClick={() => setSelectedChildId(c.id)}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition ${
              selectedChildId === c.id
                ? 'bg-white text-indigo-600 shadow-xs border border-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {c.name} <span className="opacity-70 font-normal">({c.grade})</span>
          </button>
        ))}
      </div>

      {/* Main Grid: Left ID Card (2 cols), Right Document Vault (1 col) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: 3D Flip Card & Template Selector */}
        <div className="lg:col-span-2 bg-white rounded-2xl p-6 border border-slate-200 shadow-xs flex flex-col items-center">
          <div className="w-full flex items-center justify-between pb-4 border-b border-slate-100 mb-6">
            <div>
              <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                <CreditCard className="w-4 h-4 text-indigo-600" />
                Active Student Identity Pass
              </h3>
              <p className="text-[11px] text-slate-400 mt-0.5">Click card or Flip button to inspect barcode & reverse details</p>
            </div>

            {/* Template format switch */}
            <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl text-xs font-semibold">
              {(['modern-vertical', 'classic-horizontal', 'minimalist-academic', 'smart-card'] as StudentIDCardTemplateLayout[]).map(t => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setActiveTemplate(t)}
                  className={`px-2.5 py-1 rounded-lg transition capitalize text-[11px] ${
                    activeTemplate === t
                      ? 'bg-white text-indigo-600 shadow-xs'
                      : 'text-slate-500 hover:text-slate-800'
                  }`}
                >
                  {t.split('-')[0]}
                </button>
              ))}
            </div>
          </div>

          {/* Render Card Visual */}
          <div className="py-4" id="printable-guardian-id-card">
            <StudentIDCardVisual
              card={{
                ...displayedCard,
                templateId: activeTemplate
              }}
              scale={1}
              interactive={true}
              showFlipControls={true}
              onPrint={() => triggerSafePrint({ elementOrId: 'printable-guardian-id-card', fallbackTitle: 'Student_ID_Badge' })}
            />
          </div>

          <div className="w-full mt-6 pt-4 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-500">
            <div className="flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>Barcode encoded for automated turnstile gate access</span>
            </div>

            <button
              type="button"
              onClick={() => setIsReissueModalOpen(true)}
              className="px-3 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-800 font-bold rounded-lg border border-amber-200 transition text-[11px] flex items-center gap-1"
            >
              <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
              Report Lost / Request Reissue
            </button>
          </div>
        </div>

        {/* Right: Verified Document Vault */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                <FileText className="w-4 h-4 text-indigo-600" />
                Submitted Documents & Certs
              </h3>
              <span className="text-xs font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full">
                {documents?.length || 0} Files
              </span>
            </div>

            <p className="text-xs text-slate-500 mb-4">
              Enrollment documentation, medical certificates, and identification papers on file with school administration.
            </p>

            <div className="space-y-3">
              {(documents?.length || 0) === 0 ? (
                <div className="p-6 text-center border border-dashed border-slate-200 rounded-xl text-xs text-slate-400">
                  <FileText className="w-8 h-8 text-slate-300 mx-auto mb-1" />
                  No documents in vault for this child yet.
                </div>
              ) : (
                documents.map(doc => {
                  const isVerified = (doc.verificationStatus || 'PENDING_VERIFICATION') === 'VERIFIED';
                  return (
                    <div
                      key={doc.id}
                      className="p-3 bg-slate-50 hover:bg-slate-100/80 rounded-xl border border-slate-200/80 transition flex items-center justify-between text-xs"
                    >
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-indigo-600 shrink-0">
                          <FileText className="w-4 h-4" />
                        </div>
                        <div>
                          <strong className="text-slate-800 block font-bold leading-tight">
                            {doc.title || doc.name}
                          </strong>
                          <span className="text-[10px] text-slate-400">
                            {doc.category} • {doc.fileSize || '280 KB'}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <span className={`text-[9.5px] font-bold px-2 py-0.5 rounded-full uppercase ${
                          isVerified
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}>
                          {isVerified ? 'Verified' : 'Pending'}
                        </span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          <div className="pt-4 mt-6 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setIsUploadModalOpen(true)}
              className="w-full py-2.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-xs rounded-xl transition flex items-center justify-center gap-2"
            >
              <Upload className="w-4 h-4" />
              Upload Medical / Academic Document
            </button>
          </div>
        </div>
      </div>

      {/* Document Upload Modal */}
      {isUploadModalOpen && (
        <StudentDocumentUploadModal
          studentId={displayedCard.studentId || selectedChildId}
          studentName={displayedCard.studentName}
          admissionNumber={displayedCard.admissionNumber}
          isOpen={isUploadModalOpen}
          onClose={() => setIsUploadModalOpen(false)}
          onSuccess={(newDoc) => {
            setDocuments(prev => [newDoc, ...prev]);
            setIsUploadModalOpen(false);
          }}
        />
      )}

      {/* Reissue Request Modal */}
      {isReissueModalOpen && (
        <StudentIDCardReissueModal
          card={displayedCard}
          isOpen={isReissueModalOpen}
          onClose={() => setIsReissueModalOpen(false)}
          onSuccess={(updated) => {
            setCard(updated);
            setIsReissueModalOpen(false);
          }}
        />
      )}
    </div>
  );
};
