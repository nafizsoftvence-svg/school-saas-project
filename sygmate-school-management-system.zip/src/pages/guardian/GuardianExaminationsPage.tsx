import React, { useState, useEffect } from 'react';
import {
  CalendarDays,
  Clock,
  MapPin,
  User,
  Search,
  Filter,
  GraduationCap,
  Award,
  TrendingUp,
  FileText,
  AlertTriangle,
  ArrowLeft,
  RotateCcw,
  CheckCircle2,
  AlertCircle,
  Printer,
  Info,
  Calendar,
  Layers,
  Sparkles,
  BookOpen
} from 'lucide-react';
import { api } from '../../services/api.js';
import { downloadTablePdf, triggerSafePrint } from '../../utils/printPdf.js';
import {
  GuardianChildSummary,
  ExamScheduleItem,
  GuardianChildExaminationsResponse
} from '../../types/index.js';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner.js';
import { Badge } from '../../components/ui/Badge.js';
import { Button } from '../../components/ui/Button.js';
import { Modal } from '../../components/ui/Modal.js';
import { Input } from '../../components/ui/Input.js';

interface GuardianExaminationsPageProps {
  onNavigate?: (view: string) => void;
  initialStudentId?: string;
}

export const GuardianExaminationsPage: React.FC<GuardianExaminationsPageProps> = ({
  onNavigate,
  initialStudentId
}) => {
  // All linked children for this guardian
  const [children, setChildren] = useState<GuardianChildSummary[]>([]);
  const [selectedChildId, setSelectedChildId] = useState<string | null>(initialStudentId || null);

  // Exam schedule state
  const [examData, setExamData] = useState<GuardianChildExaminationsResponse | null>(null);
  const [isLoadingChildren, setIsLoadingChildren] = useState<boolean>(true);
  const [isLoadingExams, setIsLoadingExams] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [authError, setAuthError] = useState<string | null>(null);

  // Filters
  const [sessionFilter, setSessionFilter] = useState<string>('ALL');
  const [examFilter, setExamFilter] = useState<string>('ALL');
  const [subjectFilter, setSubjectFilter] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Detail Modal
  const [selectedExam, setSelectedExam] = useState<ExamScheduleItem | null>(null);

  // 1. Fetch linked children
  useEffect(() => {
    const fetchChildren = async () => {
      setIsLoadingChildren(true);
      setAuthError(null);
      try {
        const res = await api.guardian.getChildren();
        const childrenList = Array.isArray(res?.data) ? res.data : Array.isArray(res) ? res : [];
        if (res?.success) {
          setChildren(childrenList);
          if (!selectedChildId && childrenList.length > 0) {
            setSelectedChildId(childrenList?.[0]?.id || null);
          } else if (selectedChildId) {
            const exists = childrenList.some((c: any) => c?.id === selectedChildId);
            if (!exists && childrenList.length > 0) {
              setSelectedChildId(childrenList?.[0]?.id || null);
            }
          }
        } else {
          setAuthError(typeof res.error === 'string' ? res.error : 'Failed to retrieve linked scholars.');
        }
      } catch (err: any) {
        setAuthError(err?.message || 'Error communicating with parent security services.');
      } finally {
        setIsLoadingChildren(false);
      }
    };

    fetchChildren();
  }, []);

  // 2. Fetch examinations for selected child
  const fetchExaminations = async () => {
    if (!selectedChildId) return;

    setIsLoadingExams(true);
    setError(null);
    try {
      const res = await api.guardian.getChildExaminations(selectedChildId, {
        academicSessionId: sessionFilter,
        examId: examFilter,
        subjectId: subjectFilter,
        status: statusFilter,
        search: searchQuery
      });

      if (res.success && res.data) {
        setExamData(res.data);
      } else {
        if (res.code === 'FORBIDDEN_STUDENT_ACCESS') {
          setAuthError(typeof res.error === 'string' ? res.error : 'Security violation: Access denied.');
        } else {
          setError(typeof res.error === 'string' ? res.error : 'Failed to load examination schedule.');
        }
      }
    } catch (err: any) {
      setError(err?.message || 'Network error fetching examination schedule.');
    } finally {
      setIsLoadingExams(false);
    }
  };

  useEffect(() => {
    if (selectedChildId) {
      fetchExaminations();
    }
  }, [selectedChildId, sessionFilter, examFilter, subjectFilter, statusFilter]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchExaminations();
  };

  const handleResetFilters = () => {
    setSessionFilter('ALL');
    setExamFilter('ALL');
    setSubjectFilter('ALL');
    setStatusFilter('ALL');
    setSearchQuery('');
  };

  const activeChild = (children || []).find((c) => c.id === selectedChildId) || children?.[0];

  const handlePrintSchedule = async () => {
    if (!examData?.data || examData.data.length === 0) {
      window.print();
      return;
    }
    const cols = ['Subject', 'Code', 'Exam Name', 'Date', 'Time', 'Duration', 'Room', 'Status'];
    const rows = examData.data.map((exam) => [
      exam.subjectName,
      exam.subjectCode,
      exam.examName,
      exam.examDate,
      exam.startTime,
      `${exam.durationMinutes} min`,
      exam.roomNumber || 'Hall A',
      exam.status
    ]);
    await downloadTablePdf({
      title: `Examination Timetable — ${activeChild?.name || 'Student'}`,
      subtitle: `Class: ${activeChild?.className || ''} - ${activeChild?.sectionName || ''} | Session: 2026-2027`,
      columns: cols,
      data: rows,
      filename: `examination_timetable_${(activeChild?.name || 'student').toLowerCase().replace(/\s+/g, '_')}.pdf`,
      orientation: 'landscape'
    });
    await triggerSafePrint({
      fallbackTitle: `Exam_Timetable_${activeChild?.name || 'Student'}`
    });
  };

  if (isLoadingChildren) {
    return (
      <div className="p-12 flex flex-col items-center justify-center min-h-[450px] space-y-4">
        <LoadingSpinner size="lg" message="Loading your verified scholars..." />
      </div>
    );
  }

  if (authError) {
    return (
      <div className="p-8 max-w-2xl mx-auto space-y-6 text-center">
        <div className="w-16 h-16 rounded-3xl bg-rose-500/20 border border-rose-500/30 text-rose-400 flex items-center justify-center mx-auto shadow-lg shadow-rose-950/40">
          <AlertTriangle className="w-8 h-8" />
        </div>
        <div className="space-y-2">
          <h2 className="text-2xl font-bold text-white tracking-tight">Access Restricted</h2>
          <p className="text-sm text-slate-400">{authError}</p>
        </div>
        <div className="flex justify-center gap-3">
          <Button
            id="guardian-exam-back-btn"
            variant="secondary"
            onClick={() => onNavigate && onNavigate('guardian-dashboard')}
          >
            <ArrowLeft className="w-4 h-4 mr-2" /> Back to Dashboard
          </Button>
        </div>
      </div>
    );
  }

  if ((children?.length || 0) === 0) {
    return (
      <div className="p-12 max-w-lg mx-auto text-center space-y-4 rounded-3xl bg-slate-900/60 border border-white/10 p-8">
        <div className="w-14 h-14 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center mx-auto">
          <GraduationCap className="w-7 h-7" />
        </div>
        <h3 className="text-xl font-bold text-white">No Linked Scholars Found</h3>
        <p className="text-sm text-slate-400">
          There are currently no student accounts linked to your guardian profile. Please contact school administration.
        </p>
      </div>
    );
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'scheduled':
        return <Badge variant="info" className="px-2.5 py-1 text-xs">Scheduled</Badge>;
      case 'ongoing':
        return <Badge variant="warning" className="px-2.5 py-1 text-xs animate-pulse">In Progress</Badge>;
      case 'completed':
        return <Badge variant="success" className="px-2.5 py-1 text-xs">Completed</Badge>;
      case 'cancelled':
        return <Badge variant="danger" className="px-2.5 py-1 text-xs">Cancelled</Badge>;
      default:
        return <Badge variant="secondary" className="px-2.5 py-1 text-xs">{status}</Badge>;
    }
  };

  const getExamTypeBadge = (type: string) => {
    switch (type) {
      case 'mid_term':
      case 'Mid-Term':
        return <span className="text-[11px] font-bold px-2 py-0.5 rounded-md bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">Mid-Term</span>;
      case 'final':
      case 'Final Semester':
        return <span className="text-[11px] font-bold px-2 py-0.5 rounded-md bg-purple-500/10 text-purple-300 border border-purple-500/20">Final Exam</span>;
      case 'unit_test':
      case 'Unit Assessment':
        return <span className="text-[11px] font-bold px-2 py-0.5 rounded-md bg-sky-500/10 text-sky-300 border border-sky-500/20">Unit Test</span>;
      default:
        return <span className="text-[11px] font-bold px-2 py-0.5 rounded-md bg-slate-500/10 text-slate-300 border border-slate-500/20">{type}</span>;
    }
  };

  const isExamUpcoming = (dateStr: string) => {
    const examDate = new Date(dateStr);
    const today = new Date('2026-08-16');
    return examDate >= today;
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      {/* 1. Header & Quick Hub */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <button
              onClick={() => onNavigate && onNavigate('guardian-dashboard')}
              className="text-xs font-semibold text-slate-400 hover:text-amber-400 transition-colors flex items-center gap-1"
            >
              <ArrowLeft className="w-3.5 h-3.5" /> Portal Dashboard
            </button>
            <span className="text-slate-600">/</span>
            <span className="text-xs font-semibold text-amber-400">Examinations</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight flex items-center gap-3">
            <CalendarDays className="w-8 h-8 text-amber-400" />
            Scholar Examination Timetable
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Official institutional examination schedules, room allocations, timings, and invigilation details for your scholars.
          </p>
        </div>

        {/* Quick Hub Navigation Links */}
        <div className="flex flex-wrap items-center gap-2">
          <Button
            id="guardian-nav-results"
            variant="outline"
            size="sm"
            onClick={() => onNavigate && onNavigate('guardian-results')}
            className="text-xs border-white/10 hover:border-amber-500/40"
          >
            <Award className="w-3.5 h-3.5 mr-1.5 text-amber-400" />
            Results &amp; Marks
          </Button>
          <Button
            id="guardian-nav-progress"
            variant="outline"
            size="sm"
            onClick={() => onNavigate && onNavigate('guardian-progress')}
            className="text-xs border-white/10 hover:border-amber-500/40"
          >
            <TrendingUp className="w-3.5 h-3.5 mr-1.5 text-emerald-400" />
            Academic Progress
          </Button>
          <Button
            id="guardian-print-schedule-btn"
            variant="secondary"
            size="sm"
            onClick={handlePrintSchedule}
            className="text-xs"
          >
            <Printer className="w-3.5 h-3.5 mr-1.5 text-slate-300" />
            Print Timetable
          </Button>
        </div>
      </div>

      {/* 2. Multi-Child Selector */}
      <div className="rounded-3xl bg-slate-900/60 border border-white/10 p-5 backdrop-blur-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 shrink-0">
              <GraduationCap className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-semibold text-amber-400 uppercase tracking-wider">Active Scholar</div>
              <div className="text-sm font-bold text-white">
                {activeChild ? `${activeChild.name} (${activeChild.className} - ${activeChild.sectionName})` : 'Select Scholar'}
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {(children || []).map((child) => {
              const isSelected = child.id === selectedChildId;
              return (
                <button
                  key={child.id}
                  id={`select-child-exam-${child.id}`}
                  onClick={() => setSelectedChildId(child.id)}
                  className={`flex items-center gap-3 px-4 py-2.5 rounded-2xl text-xs font-bold transition-all border ${
                    isSelected
                      ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-lg shadow-amber-500/20 scale-[1.02]'
                      : 'bg-slate-800/80 text-slate-300 border-white/5 hover:border-white/20 hover:bg-slate-800'
                  }`}
                >
                  <div
                    className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-black ${
                      isSelected ? 'bg-slate-950 text-amber-400' : 'bg-amber-500/20 text-amber-300'
                    }`}
                  >
                    {child.name.charAt(0)}
                  </div>
                  <div className="text-left">
                    <div>{child.name}</div>
                    <div className={`text-[10px] ${isSelected ? 'text-slate-900 font-semibold' : 'text-slate-400'}`}>
                      {child.className} • {child.rollNumber}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* 3. Metric Stats Counters */}
      {examData && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="rounded-3xl bg-slate-900/60 border border-white/10 p-5 backdrop-blur-xl">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-400">Total Exams</span>
              <div className="w-8 h-8 rounded-xl bg-slate-800 border border-white/10 flex items-center justify-center text-slate-300">
                <CalendarDays className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl font-black text-white mt-2">{examData?.stats?.total ?? 0}</div>
            <div className="text-[11px] text-slate-400 mt-1">In curriculum cohort</div>
          </div>

          <div className="rounded-3xl bg-slate-900/60 border border-white/10 p-5 backdrop-blur-xl">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-indigo-400">Scheduled</span>
              <div className="w-8 h-8 rounded-xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400">
                <Clock className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl font-black text-white mt-2">{examData?.stats?.scheduled ?? 0}</div>
            <div className="text-[11px] text-indigo-300 mt-1">Upcoming assessments</div>
          </div>

          <div className="rounded-3xl bg-slate-900/60 border border-white/10 p-5 backdrop-blur-xl">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-amber-400">Ongoing</span>
              <div className="w-8 h-8 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
                <AlertCircle className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl font-black text-white mt-2">{examData?.stats?.ongoing ?? 0}</div>
            <div className="text-[11px] text-amber-300 mt-1">Active test window</div>
          </div>

          <div className="rounded-3xl bg-slate-900/60 border border-white/10 p-5 backdrop-blur-xl">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-emerald-400">Completed</span>
              <div className="w-8 h-8 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
                <CheckCircle2 className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl font-black text-white mt-2">{examData?.stats?.completed ?? 0}</div>
            <div className="text-[11px] text-emerald-300 mt-1">Evaluations concluded</div>
          </div>
        </div>
      )}

      {/* 4. Filters & Search Bar */}
      <div className="rounded-3xl bg-slate-900/60 border border-white/10 p-5 backdrop-blur-xl space-y-4">
        <form onSubmit={handleSearchSubmit} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {/* Search */}
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              id="guardian-exam-search-input"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search subject, room, exam..."
              className="w-full pl-9 pr-3 py-2 bg-slate-800/80 border border-white/10 rounded-2xl text-xs text-white placeholder-slate-400 focus:outline-hidden focus:border-amber-400"
            />
          </div>

          {/* Session Filter */}
          <div>
            <select
              id="guardian-exam-session-select"
              value={sessionFilter}
              onChange={(e) => setSessionFilter(e.target.value)}
              className="w-full px-3 py-2 bg-slate-800/80 border border-white/10 rounded-2xl text-xs text-slate-200 focus:outline-hidden focus:border-amber-400"
            >
              <option value="ALL">All Academic Sessions</option>
              {examData?.availableSessions?.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} {s.isActive ? '(Active)' : ''}
                </option>
              ))}
            </select>
          </div>

          {/* Exam Filter */}
          <div>
            <select
              id="guardian-exam-name-select"
              value={examFilter}
              onChange={(e) => setExamFilter(e.target.value)}
              className="w-full px-3 py-2 bg-slate-800/80 border border-white/10 rounded-2xl text-xs text-slate-200 focus:outline-hidden focus:border-amber-400"
            >
              <option value="ALL">All Examination Types</option>
              {examData?.availableExams?.map((e) => (
                <option key={e.id} value={e.id}>
                  {e.name}
                </option>
              ))}
            </select>
          </div>

          {/* Subject Filter */}
          <div>
            <select
              id="guardian-exam-subject-select"
              value={subjectFilter}
              onChange={(e) => setSubjectFilter(e.target.value)}
              className="w-full px-3 py-2 bg-slate-800/80 border border-white/10 rounded-2xl text-xs text-slate-200 focus:outline-hidden focus:border-amber-400"
            >
              <option value="ALL">All Subjects</option>
              {examData?.availableSubjects?.map((sub) => (
                <option key={sub.id} value={sub.id}>
                  {sub.name} ({sub.code})
                </option>
              ))}
            </select>
          </div>

          {/* Status Filter */}
          <div className="flex items-center gap-2">
            <select
              id="guardian-exam-status-select"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="flex-1 px-3 py-2 bg-slate-800/80 border border-white/10 rounded-2xl text-xs text-slate-200 focus:outline-hidden focus:border-amber-400"
            >
              <option value="ALL">All Statuses</option>
              <option value="scheduled">Scheduled</option>
              <option value="ongoing">In Progress</option>
              <option value="completed">Completed</option>
            </select>

            <Button
              id="guardian-exam-reset-btn"
              type="button"
              variant="outline"
              size="sm"
              onClick={handleResetFilters}
              title="Reset Filters"
              className="border-white/10 text-slate-400 hover:text-white px-2.5"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </Button>
          </div>
        </form>
      </div>

      {/* 5. Main Exam Timetable Content */}
      {isLoadingExams ? (
        <div className="p-12 flex flex-col items-center justify-center min-h-[300px] space-y-4">
          <LoadingSpinner size="md" message="Loading examination schedule..." />
        </div>
      ) : error ? (
        <div className="p-8 rounded-3xl bg-rose-500/10 border border-rose-500/20 text-center space-y-3">
          <AlertCircle className="w-8 h-8 text-rose-400 mx-auto" />
          <h3 className="text-base font-bold text-white">Unable to load examination schedule</h3>
          <p className="text-xs text-slate-400 max-w-md mx-auto">{error}</p>
          <Button size="sm" variant="secondary" onClick={fetchExaminations}>
            Retry Fetch
          </Button>
        </div>
      ) : !examData || !Array.isArray(examData.data) || examData.data.length === 0 ? (
        <div className="p-12 rounded-3xl bg-slate-900/40 border border-white/5 text-center space-y-4">
          <div className="w-14 h-14 rounded-2xl bg-slate-800/80 border border-white/10 flex items-center justify-center mx-auto text-slate-400">
            <CalendarDays className="w-7 h-7" />
          </div>
          <h3 className="text-lg font-bold text-white">No Examinations Found</h3>
          <p className="text-xs text-slate-400 max-w-md mx-auto">
            No examination schedules match your selected filters for {activeChild?.name}. Active upcoming schedules will appear here once finalized by the Examination Office.
          </p>
          <Button size="sm" variant="outline" onClick={handleResetFilters} className="border-white/10">
            Clear Filters
          </Button>
        </div>
      ) : (
        <div className="space-y-4">
          <div className="flex items-center justify-between px-1">
            <div className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              {(examData?.data || []).length} Examination {(examData?.data || []).length === 1 ? 'Entry' : 'Entries'}
            </div>
            <div className="text-xs text-slate-400">
              Cohort: <span className="font-semibold text-amber-400">{activeChild?.className} - {activeChild?.sectionName}</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {(examData?.data || []).map((exam) => {
              const isUpcoming = isExamUpcoming(exam.examDate);
              return (
                <div
                  key={exam.id}
                  id={`exam-card-${exam.id}`}
                  className="rounded-3xl bg-slate-900/60 border border-white/10 p-6 backdrop-blur-xl hover:border-amber-500/30 transition-all flex flex-col justify-between space-y-5"
                >
                  <div className="space-y-3">
                    {/* Header: Type and Status */}
                    <div className="flex items-start justify-between gap-3">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          {getExamTypeBadge(exam.examType)}
                          <span className="text-xs font-mono font-bold text-amber-400 bg-amber-400/10 px-2 py-0.5 rounded-md border border-amber-400/20">
                            {exam.subjectCode}
                          </span>
                        </div>
                        <h3 className="text-lg font-bold text-white tracking-tight pt-1">
                          {exam.subjectName}
                        </h3>
                        <p className="text-xs text-slate-400">{exam.examName}</p>
                      </div>

                      <div>{getStatusBadge(exam.status)}</div>
                    </div>

                    {/* Meta info grid */}
                    <div className="grid grid-cols-2 gap-2.5 pt-2 text-xs">
                      <div className="flex items-center gap-2 text-slate-300 bg-slate-800/50 p-2.5 rounded-2xl border border-white/5">
                        <Calendar className="w-4 h-4 text-indigo-400 shrink-0" />
                        <div>
                          <div className="text-[10px] text-slate-400">Date</div>
                          <div className="font-semibold">{exam.examDate}</div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 text-slate-300 bg-slate-800/50 p-2.5 rounded-2xl border border-white/5">
                        <Clock className="w-4 h-4 text-amber-400 shrink-0" />
                        <div>
                          <div className="text-[10px] text-slate-400">Time &amp; Duration</div>
                          <div className="font-semibold">{exam.startTime} ({exam.durationMinutes}m)</div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 text-slate-300 bg-slate-800/50 p-2.5 rounded-2xl border border-white/5">
                        <MapPin className="w-4 h-4 text-emerald-400 shrink-0" />
                        <div>
                          <div className="text-[10px] text-slate-400">Room / Hall</div>
                          <div className="font-semibold truncate max-w-[120px]">{exam.roomNumber || 'Assigned Hall'}</div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 text-slate-300 bg-slate-800/50 p-2.5 rounded-2xl border border-white/5">
                        <User className="w-4 h-4 text-purple-400 shrink-0" />
                        <div>
                          <div className="text-[10px] text-slate-400">Invigilator</div>
                          <div className="font-semibold truncate max-w-[120px]">{exam.invigilatorName || 'Faculty Assigned'}</div>
                        </div>
                      </div>
                    </div>

                    {/* Marks and Rules snippet */}
                    <div className="flex items-center justify-between text-xs px-3 py-2 rounded-xl bg-white/[0.02] border border-white/5">
                      <span className="text-slate-400">Full Marks: <strong className="text-white">{exam.fullMarks}</strong></span>
                      <span className="text-slate-400">Pass Marks: <strong className="text-amber-400">{exam.passMarks}</strong></span>
                      <span className="text-slate-400">Session: <strong className="text-slate-300">{exam.academicSessionName || '2026-2027'}</strong></span>
                    </div>

                    {exam.instructions && (
                      <p className="text-xs text-slate-400 line-clamp-2 italic bg-slate-950/40 p-2.5 rounded-xl border border-white/5">
                        "{exam.instructions}"
                      </p>
                    )}
                  </div>

                  {/* Actions */}
                  <div className="pt-2 border-t border-white/5 flex items-center justify-between">
                    <span className="text-[11px] text-slate-500">
                      Cohort: {exam.className} ({exam.sectionName})
                    </span>
                    <Button
                      id={`view-exam-details-${exam.id}`}
                      variant="outline"
                      size="sm"
                      onClick={() => setSelectedExam(exam)}
                      className="text-xs border-white/10 hover:border-amber-500/40"
                    >
                      <Info className="w-3.5 h-3.5 mr-1.5 text-amber-400" />
                      View Instructions
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 6. Detailed Exam Instruction Modal */}
      {selectedExam && (
        <Modal
          isOpen={!!selectedExam}
          onClose={() => setSelectedExam(null)}
          title="Examination Schedule Details"
          maxWidth="max-w-xl"
        >
          <div className="space-y-6">
            <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-start gap-3">
              <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-300 flex items-center justify-center shrink-0 mt-0.5">
                <BookOpen className="w-4 h-4" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono font-bold text-amber-400">{selectedExam.subjectCode}</span>
                  {getExamTypeBadge(selectedExam.examType)}
                </div>
                <h3 className="text-base font-bold text-white mt-1">{selectedExam.subjectName}</h3>
                <p className="text-xs text-slate-400">{selectedExam.examName}</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-3 rounded-2xl bg-slate-800/80 border border-white/5 space-y-1">
                <div className="text-[10px] uppercase font-bold text-slate-400">Date &amp; Time</div>
                <div className="text-sm font-bold text-white">{selectedExam.examDate}</div>
                <div className="text-slate-300">{selectedExam.startTime} - {selectedExam.endTime}</div>
              </div>

              <div className="p-3 rounded-2xl bg-slate-800/80 border border-white/5 space-y-1">
                <div className="text-[10px] uppercase font-bold text-slate-400">Venue &amp; Room</div>
                <div className="text-sm font-bold text-white">{selectedExam.roomNumber || 'Main Examination Hall'}</div>
                <div className="text-slate-300">Invigilator: {selectedExam.invigilatorName || 'Faculty Assigned'}</div>
              </div>

              <div className="p-3 rounded-2xl bg-slate-800/80 border border-white/5 space-y-1">
                <div className="text-[10px] uppercase font-bold text-slate-400">Evaluation Marks</div>
                <div className="text-sm font-bold text-white">Full: {selectedExam.fullMarks} / Pass: {selectedExam.passMarks}</div>
                <div className="text-slate-300">Duration: {selectedExam.durationMinutes} Minutes</div>
              </div>

              <div className="p-3 rounded-2xl bg-slate-800/80 border border-white/5 space-y-1">
                <div className="text-[10px] uppercase font-bold text-slate-400">Cohort &amp; Session</div>
                <div className="text-sm font-bold text-white">{selectedExam.className} ({selectedExam.sectionName})</div>
                <div className="text-slate-300">{selectedExam.academicSessionName || '2026-2027'}</div>
              </div>
            </div>

            <div className="space-y-2">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                <Info className="w-3.5 h-3.5 text-amber-400" /> Candidate Examination Instructions &amp; Rules
              </h4>
              <div className="p-4 rounded-2xl bg-slate-950/60 border border-white/10 text-xs text-slate-300 leading-relaxed">
                {selectedExam.instructions || 'Standard examination hall regulations apply. Students must carry valid identification and required stationery. Electronic devices and unapproved calculators are strictly prohibited.'}
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-4 border-t border-white/10">
              <Button variant="secondary" onClick={() => setSelectedExam(null)}>
                Close Window
              </Button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
