import React, { useState, useEffect } from 'react';
import {
  BookOpen,
  Calendar,
  CheckCircle2,
  Clock,
  AlertTriangle,
  FileText,
  Filter,
  Search,
  ChevronRight,
  Info,
  Paperclip,
  ExternalLink,
  Download,
  GraduationCap,
  Sparkles,
  ArrowRight,
  Check,
  X,
  AlertCircle,
  UserCheck,
  Building,
  Layers,
  ArrowLeft,
  RotateCcw,
  RefreshCw,
  FolderOpen
} from 'lucide-react';
import { api } from '../../services/api.js';
import {
  GuardianChildSummary,
  StudentHomeworkItem,
  GuardianChildHomeworkResponse
} from '../../types/index.js';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner.js';
import { Badge } from '../../components/ui/Badge.js';
import { Button } from '../../components/ui/Button.js';
import { Modal } from '../../components/ui/Modal.js';
import { Input } from '../../components/ui/Input.js';

interface GuardianHomeworkPageProps {
  onNavigate?: (view: string) => void;
  initialStudentId?: string;
}

export const GuardianHomeworkPage: React.FC<GuardianHomeworkPageProps> = ({
  onNavigate,
  initialStudentId
}) => {
  // All linked children for this guardian
  const [children, setChildren] = useState<GuardianChildSummary[]>([]);
  const [selectedChildId, setSelectedChildId] = useState<string | null>(initialStudentId || null);

  // Homework data
  const [homeworkData, setHomeworkData] = useState<GuardianChildHomeworkResponse | null>(null);
  const [isLoadingChildren, setIsLoadingChildren] = useState<boolean>(true);
  const [isLoadingHomework, setIsLoadingHomework] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [authError, setAuthError] = useState<string | null>(null);

  // Filters
  const [subjectFilter, setSubjectFilter] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [dueDateFilter, setDueDateFilter] = useState<string>('');

  // Selected item for detail modal
  const [selectedHomework, setSelectedHomework] = useState<StudentHomeworkItem | null>(null);

  // 1. Fetch all linked children on mount
  useEffect(() => {
    const fetchChildren = async () => {
      setIsLoadingChildren(true);
      setAuthError(null);
      try {
        const res = await api.guardian.getChildren();
        const childrenList = Array.isArray(res?.data) ? res.data : Array.isArray(res) ? res : [];
        if (res?.success) {
          setChildren(childrenList);
          if (!selectedChildId && childrenList.length > 0) {
            setSelectedChildId(childrenList?.[0]?.id || null);
          } else if (selectedChildId) {
            const exists = childrenList.some((c: any) => c?.id === selectedChildId);
            if (!exists && childrenList.length > 0) {
              setSelectedChildId(childrenList?.[0]?.id || null);
            }
          }
        } else {
          setAuthError(typeof res.error === 'string' ? res.error : 'Failed to retrieve linked children profiles.');
        }
      } catch (err: any) {
        setAuthError(err?.message || 'Error communicating with parent security services.');
      } finally {
        setIsLoadingChildren(false);
      }
    };

    fetchChildren();
  }, []);

  // 2. Fetch homework for selected child whenever childId or filters change
  const fetchHomework = async () => {
    if (!selectedChildId) return;

    setIsLoadingHomework(true);
    setError(null);
    try {
      const res = await api.guardian.getChildHomework(selectedChildId, {
        subjectId: subjectFilter,
        status: statusFilter,
        search: searchQuery,
        dueDate: dueDateFilter || undefined
      });

      if (res.success && res.data) {
        setHomeworkData(res.data);
      } else {
        if (res.code === 'FORBIDDEN_STUDENT_ACCESS') {
          setAuthError(typeof res.error === 'string' ? res.error : 'Security violation: Access denied.');
        } else {
          setError(typeof res.error === 'string' ? res.error : 'Failed to load homework assignments.');
        }
      }
    } catch (err: any) {
      setError(err?.message || 'Network error fetching homework.');
    } finally {
      setIsLoadingHomework(false);
    }
  };

  useEffect(() => {
    if (selectedChildId) {
      fetchHomework();
    }
  }, [selectedChildId, subjectFilter, statusFilter, dueDateFilter]);

  // Handle Search Debounce or trigger
  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchHomework();
  };

  const handleResetFilters = () => {
    setSubjectFilter('ALL');
    setStatusFilter('ALL');
    setSearchQuery('');
    setDueDateFilter('');
  };

  const activeChild = (children || []).find((c) => c.id === selectedChildId) || children?.[0];

  if (isLoadingChildren) {
    return (
      <div className="p-12 flex flex-col items-center justify-center min-h-[450px] space-y-4">
        <LoadingSpinner size="lg" message="Loading your verified scholars..." />
      </div>
    );
  }

  if (authError) {
    return (
      <div className="p-8 max-w-2xl mx-auto space-y-6 text-center">
        <div className="w-16 h-16 rounded-3xl bg-rose-500/20 border border-rose-500/30 text-rose-400 flex items-center justify-center mx-auto shadow-lg shadow-rose-950/40">
          <AlertTriangle className="w-8 h-8" />
        </div>
        <div className="space-y-2">
          <h2 className="text-2xl font-bold text-white tracking-tight">Access Restricted</h2>
          <p className="text-sm text-slate-400">{authError}</p>
        </div>
        <div className="flex justify-center gap-3">
          <Button
            id="guardian-hw-back-btn"
            variant="secondary"
            onClick={() => onNavigate && onNavigate('guardian-dashboard')}
          >
            <ArrowLeft className="w-4 h-4 mr-2" /> Back to Dashboard
          </Button>
        </div>
      </div>
    );
  }

  if ((children?.length || 0) === 0) {
    return (
      <div className="p-12 max-w-lg mx-auto text-center space-y-4 rounded-3xl bg-slate-900/60 border border-white/10 p-8">
        <div className="w-14 h-14 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center mx-auto">
          <UserCheck className="w-7 h-7" />
        </div>
        <h3 className="text-xl font-bold text-white">No Linked Scholars Found</h3>
        <p className="text-sm text-slate-400">
          There are currently no student accounts linked to your guardian profile. Please contact school administration.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      {/* 1. Header & Navigation Hub */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <button
              onClick={() => onNavigate && onNavigate('guardian-dashboard')}
              className="text-xs font-semibold text-slate-400 hover:text-amber-400 transition-colors flex items-center gap-1"
            >
              <ArrowLeft className="w-3.5 h-3.5" /> Portal Dashboard
            </button>
            <span className="text-slate-600">/</span>
            <span className="text-xs font-semibold text-amber-400">Homework &amp; Tasks</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight flex items-center gap-3">
            <BookOpen className="w-8 h-8 text-amber-400" />
            Scholar Homework
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Review daily homework, due dates, instructions, and subject study materials assigned to your children.
          </p>
        </div>

        {/* Quick Hub Navigation Links */}
        <div className="flex flex-wrap items-center gap-2">
          <Button
            id="guardian-nav-assignments"
            variant="outline"
            size="sm"
            onClick={() => onNavigate && onNavigate('guardian-assignments')}
            className="text-xs border-white/10 hover:border-amber-500/40"
          >
            <FileText className="w-3.5 h-3.5 mr-1.5 text-indigo-400" />
            Assignments
          </Button>
          <Button
            id="guardian-nav-materials"
            variant="outline"
            size="sm"
            onClick={() => onNavigate && onNavigate('guardian-materials')}
            className="text-xs border-white/10 hover:border-amber-500/40"
          >
            <FolderOpen className="w-3.5 h-3.5 mr-1.5 text-emerald-400" />
            Study Materials
          </Button>
          <Button
            id="guardian-nav-announcements"
            variant="outline"
            size="sm"
            onClick={() => onNavigate && onNavigate('guardian-announcements')}
            className="text-xs border-white/10 hover:border-amber-500/40"
          >
            <Sparkles className="w-3.5 h-3.5 mr-1.5 text-purple-400" />
            Announcements
          </Button>
        </div>
      </div>

      {/* 2. Multi-Child Selector */}
      <div className="rounded-3xl bg-slate-900/60 border border-white/10 p-5 backdrop-blur-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 shrink-0">
              <GraduationCap className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-semibold text-amber-400 uppercase tracking-wider">Active Scholar</div>
              <div className="text-sm font-bold text-white">
                {activeChild ? `${activeChild.name} (${activeChild.className} - ${activeChild.sectionName})` : 'Select Scholar'}
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {(children || []).map((child) => {
              const isSelected = child.id === selectedChildId;
              return (
                <button
                  key={child.id}
                  id={`select-child-hw-${child.id}`}
                  onClick={() => setSelectedChildId(child.id)}
                  className={`flex items-center gap-3 px-4 py-2.5 rounded-2xl text-xs font-bold transition-all border ${
                    isSelected
                      ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-lg shadow-amber-500/20 scale-[1.02]'
                      : 'bg-slate-800/80 text-slate-300 border-white/5 hover:border-white/20 hover:bg-slate-800'
                  }`}
                >
                  <div
                    className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-black ${
                      isSelected ? 'bg-slate-950 text-amber-400' : 'bg-amber-500/20 text-amber-300'
                    }`}
                  >
                    {child.name.charAt(0)}
                  </div>
                  <div className="text-left">
                    <div>{child.name}</div>
                    <div className={`text-[10px] font-normal ${isSelected ? 'text-slate-900' : 'text-slate-400'}`}>
                      {child.className} • Sec {child.sectionName}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* 3. Stats Overview Cards */}
      {homeworkData && (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="rounded-3xl bg-slate-900/60 border border-white/10 p-5 backdrop-blur-xl">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-slate-400">Total Assigned</span>
              <div className="w-8 h-8 rounded-xl bg-slate-800 flex items-center justify-center text-slate-300">
                <BookOpen className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl sm:text-3xl font-black text-white mt-2">
              {homeworkData?.stats?.total ?? 0}
            </div>
            <div className="text-[11px] text-slate-500 mt-1">Class {activeChild?.className} homework</div>
          </div>

          <div className="rounded-3xl bg-slate-900/60 border border-emerald-500/20 p-5 backdrop-blur-xl">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-emerald-300">Active / Current</span>
              <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                <CheckCircle2 className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl sm:text-3xl font-black text-emerald-400 mt-2">
              {homeworkData?.stats?.active ?? 0}
            </div>
            <div className="text-[11px] text-emerald-500/80 mt-1">Within submission window</div>
          </div>

          <div className="rounded-3xl bg-slate-900/60 border border-amber-500/20 p-5 backdrop-blur-xl">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-amber-300">Due Soon (≤ 3 Days)</span>
              <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
                <Clock className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl sm:text-3xl font-black text-amber-400 mt-2">
              {homeworkData?.stats?.dueSoon ?? 0}
            </div>
            <div className="text-[11px] text-amber-500/80 mt-1">Requires immediate focus</div>
          </div>

          <div className="rounded-3xl bg-slate-900/60 border border-rose-500/20 p-5 backdrop-blur-xl">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-rose-300">Overdue Tasks</span>
              <div className="w-8 h-8 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center">
                <AlertTriangle className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl sm:text-3xl font-black text-rose-400 mt-2">
              {homeworkData?.stats?.overdue ?? 0}
            </div>
            <div className="text-[11px] text-rose-500/80 mt-1">Past due deadline</div>
          </div>
        </div>
      )}

      {/* 4. Filter Toolbar */}
      <div className="rounded-3xl bg-slate-900/60 border border-white/10 p-5 backdrop-blur-xl space-y-4">
        <form onSubmit={handleSearchSubmit} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Search Input */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              id="guardian-hw-search-input"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search homework, topic, teacher..."
              className="w-full bg-slate-800/80 border border-white/10 rounded-2xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 transition-colors"
            />
          </div>

          {/* Subject Filter */}
          <div>
            <select
              id="guardian-hw-subject-filter"
              value={subjectFilter}
              onChange={(e) => setSubjectFilter(e.target.value)}
              className="w-full bg-slate-800/80 border border-white/10 rounded-2xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-amber-400 transition-colors"
            >
              <option value="ALL">All Subjects</option>
              {(homeworkData?.subjects || []).map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.code})
                </option>
              ))}
            </select>
          </div>

          {/* Status Filter */}
          <div>
            <select
              id="guardian-hw-status-filter"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full bg-slate-800/80 border border-white/10 rounded-2xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-amber-400 transition-colors"
            >
              <option value="ALL">All Statuses</option>
              <option value="active">Active</option>
              <option value="due_soon">Due Soon (≤ 3 Days)</option>
              <option value="overdue">Overdue</option>
              <option value="upcoming">Upcoming</option>
            </select>
          </div>

          {/* Due Date Filter */}
          <div className="flex gap-2">
            <input
              type="date"
              id="guardian-hw-date-filter"
              value={dueDateFilter}
              onChange={(e) => setDueDateFilter(e.target.value)}
              className="w-full bg-slate-800/80 border border-white/10 rounded-2xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400 transition-colors"
            />
            <Button
              type="button"
              id="guardian-hw-reset-btn"
              variant="secondary"
              size="sm"
              onClick={handleResetFilters}
              title="Reset Filters"
              className="shrink-0 px-3"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </Button>
          </div>
        </form>
      </div>

      {/* 5. Homework Item List */}
      {isLoadingHomework ? (
        <div className="p-12 flex flex-col items-center justify-center min-h-[300px]">
          <LoadingSpinner size="md" message="Fetching homework curriculum..." />
        </div>
      ) : error ? (
        <div className="p-8 text-center rounded-3xl bg-rose-500/10 border border-rose-500/20 max-w-xl mx-auto space-y-3">
          <AlertCircle className="w-8 h-8 text-rose-400 mx-auto" />
          <div className="text-sm font-semibold text-white">Error Loading Homework</div>
          <p className="text-xs text-slate-400">{error}</p>
          <Button onClick={fetchHomework} variant="secondary" size="sm">
            <RefreshCw className="w-3.5 h-3.5 mr-2" /> Try Again
          </Button>
        </div>
      ) : !homeworkData || !Array.isArray(homeworkData.data) || homeworkData.data.length === 0 ? (
        <div className="p-12 text-center rounded-3xl bg-slate-900/40 border border-white/10 max-w-lg mx-auto space-y-4">
          <div className="w-14 h-14 rounded-2xl bg-slate-800 text-slate-400 flex items-center justify-center mx-auto">
            <BookOpen className="w-7 h-7" />
          </div>
          <div className="space-y-1">
            <h3 className="text-base font-bold text-white">No Homework Found</h3>
            <p className="text-xs text-slate-400">
              No homework tasks match your current filter parameters for {activeChild?.name}.
            </p>
          </div>
          {(subjectFilter !== 'ALL' || statusFilter !== 'ALL' || searchQuery || dueDateFilter) && (
            <Button onClick={handleResetFilters} variant="secondary" size="sm">
              Clear All Filters
            </Button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {(homeworkData.data || []).map((item) => {
            const isDueSoon = item.isDueSoon && !item.isOverdue;
            const isOverdue = item.isOverdue;

            return (
              <div
                key={item.id}
                id={`guardian-hw-card-${item.id}`}
                onClick={() => setSelectedHomework(item)}
                className="group relative rounded-3xl bg-slate-900/60 border border-white/10 hover:border-amber-500/40 p-6 backdrop-blur-xl transition-all duration-200 hover:-translate-y-0.5 cursor-pointer flex flex-col justify-between"
              >
                <div className="space-y-3">
                  {/* Top Bar: Subject Badge & Status */}
                  <div className="flex items-center justify-between gap-2">
                    <span className="px-3 py-1 rounded-full text-[11px] font-bold bg-amber-500/10 text-amber-300 border border-amber-500/20">
                      {item.subjectName}
                    </span>

                    {isOverdue ? (
                      <Badge variant="danger" className="text-[10px] uppercase font-bold">
                        <AlertTriangle className="w-3 h-3 mr-1" /> Overdue
                      </Badge>
                    ) : isDueSoon ? (
                      <Badge variant="warning" className="text-[10px] uppercase font-bold">
                        <Clock className="w-3 h-3 mr-1" /> Due in {item.daysRemaining}d
                      </Badge>
                    ) : (
                      <Badge variant="success" className="text-[10px] uppercase font-bold">
                        <CheckCircle2 className="w-3 h-3 mr-1" /> Active
                      </Badge>
                    )}
                  </div>

                  {/* Title & Description preview */}
                  <div>
                    <h3 className="text-base font-bold text-white group-hover:text-amber-300 transition-colors line-clamp-1">
                      {item.title}
                    </h3>
                    <p className="text-xs text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                      {item.description}
                    </p>
                  </div>
                </div>

                {/* Footer Metadata */}
                <div className="mt-5 pt-4 border-t border-white/5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-slate-400">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-full bg-slate-800 text-slate-300 flex items-center justify-center text-[10px] font-bold">
                      {item.teacherName?.charAt(0) || 'T'}
                    </div>
                    <span>{item.teacherName}</span>
                  </div>

                  <div className="flex items-center gap-4 text-[11px]">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5 text-slate-500" />
                      Due: <strong className="text-slate-200">{item.dueDate}</strong>
                    </span>

                    {item.attachmentName && (
                      <span className="flex items-center gap-1 text-amber-400/80 font-mono">
                        <Paperclip className="w-3 h-3" />
                        File
                      </span>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* 6. Homework Detail Modal */}
      <Modal
        isOpen={!!selectedHomework}
        onClose={() => setSelectedHomework(null)}
        title="Homework Instructions & Details"
      >
        {selectedHomework && (
          <div className="space-y-6">
            {/* Header info */}
            <div className="flex items-start justify-between gap-4">
              <div className="space-y-1">
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-amber-500/10 text-amber-300 border border-amber-500/20">
                  {selectedHomework.subjectName}
                </span>
                <h2 className="text-xl font-bold text-white mt-2">{selectedHomework.title}</h2>
                <div className="text-xs text-slate-400">
                  Assigned by <strong className="text-slate-200">{selectedHomework.teacherName}</strong> • {activeChild?.className} ({activeChild?.sectionName})
                </div>
              </div>

              {selectedHomework.isOverdue ? (
                <Badge variant="danger" className="text-xs uppercase font-bold">
                  Overdue
                </Badge>
              ) : selectedHomework.isDueSoon ? (
                <Badge variant="warning" className="text-xs uppercase font-bold">
                  Due in {selectedHomework.daysRemaining} days
                </Badge>
              ) : (
                <Badge variant="success" className="text-xs uppercase font-bold">
                  Active
                </Badge>
              )}
            </div>

            {/* Schedule details */}
            <div className="grid grid-cols-2 gap-3 p-4 rounded-2xl bg-slate-900 border border-white/5 text-xs">
              <div>
                <span className="text-slate-500 block mb-1">Assigned Date</span>
                <span className="text-slate-200 font-semibold">{selectedHomework.assignedDate}</span>
              </div>
              <div>
                <span className="text-slate-500 block mb-1">Due Date</span>
                <span className="text-amber-400 font-semibold">{selectedHomework.dueDate}</span>
              </div>
            </div>

            {/* Description / Instructions */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">Teacher Instructions</h4>
              <div className="p-4 rounded-2xl bg-slate-900/90 border border-white/5 text-xs text-slate-300 leading-relaxed whitespace-pre-wrap">
                {selectedHomework.description}
              </div>
            </div>

            {/* Attachment preview / download */}
            {selectedHomework.attachmentName && (
              <div className="space-y-2">
                <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">Assigned Attachment</h4>
                <div className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-900 border border-white/10 hover:border-amber-500/30 transition-colors">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center">
                      <FileText className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-white">{selectedHomework.attachmentName}</div>
                      <div className="text-[10px] text-slate-400">Classroom Study Document</div>
                    </div>
                  </div>

                  <a
                    href={selectedHomework.attachmentUrl || '#'}
                    target="_blank"
                    rel="noreferrer"
                    className="px-3 py-1.5 rounded-xl bg-slate-800 text-amber-300 hover:bg-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-colors"
                  >
                    <Download className="w-3.5 h-3.5" />
                    Download
                  </a>
                </div>
              </div>
            )}

            {/* Guardian Guidance Notice */}
            <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-200/90 flex items-start gap-3">
              <Info className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-amber-300 block mb-0.5">Parent Monitoring View</strong>
                Scholars complete and submit their responses directly from their student dashboard. Parents can track submission readiness and support their scholar’s academic routine.
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <Button onClick={() => setSelectedHomework(null)} variant="secondary">
                Close
              </Button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};
