import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Bell,
  Pin,
  Calendar,
  Filter,
  Search,
  ChevronRight,
  Info,
  GraduationCap,
  ArrowRight,
  Check,
  X,
  AlertCircle,
  UserCheck,
  Building,
  Layers,
  ArrowLeft,
  RotateCcw,
  RefreshCw,
  AlertTriangle,
  BookOpen,
  FileText,
  FolderOpen,
  Paperclip,
  Download
} from 'lucide-react';
import { api } from '../../services/api.js';
import {
  GuardianChildSummary,
  ClassAnnouncement,
  GuardianChildAnnouncementResponse
} from '../../types/index.js';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner.js';
import { Badge } from '../../components/ui/Badge.js';
import { Button } from '../../components/ui/Button.js';
import { Modal } from '../../components/ui/Modal.js';

interface GuardianAnnouncementsPageProps {
  onNavigate?: (view: string) => void;
  initialStudentId?: string;
}

export const GuardianAnnouncementsPage: React.FC<GuardianAnnouncementsPageProps> = ({
  onNavigate,
  initialStudentId
}) => {
  const [children, setChildren] = useState<GuardianChildSummary[]>([]);
  const [selectedChildId, setSelectedChildId] = useState<string | null>(initialStudentId || null);

  const [announcementData, setAnnouncementData] = useState<GuardianChildAnnouncementResponse | null>(null);
  const [isLoadingChildren, setIsLoadingChildren] = useState<boolean>(true);
  const [isLoadingAnnouncements, setIsLoadingAnnouncements] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [authError, setAuthError] = useState<string | null>(null);

  // Filters
  const [priorityFilter, setPriorityFilter] = useState<string>('ALL');
  const [categoryFilter, setCategoryFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Detail Modal
  const [selectedAnnouncement, setSelectedAnnouncement] = useState<ClassAnnouncement | null>(null);

  useEffect(() => {
    const fetchChildren = async () => {
      setIsLoadingChildren(true);
      setAuthError(null);
      try {
        const res = await api.guardian.getChildren();
        const childrenList = Array.isArray(res?.data) ? res.data : Array.isArray(res) ? res : [];
        if (res?.success) {
          setChildren(childrenList);
          if (!selectedChildId && childrenList.length > 0) {
            setSelectedChildId(childrenList?.[0]?.id || null);
          } else if (selectedChildId) {
            const exists = childrenList.some((c: any) => c?.id === selectedChildId);
            if (!exists && childrenList.length > 0) {
              setSelectedChildId(childrenList?.[0]?.id || null);
            }
          }
        } else {
          setAuthError(typeof res.error === 'string' ? res.error : 'Failed to load children profiles.');
        }
      } catch (err: any) {
        setAuthError(err?.message || 'Network error.');
      } finally {
        setIsLoadingChildren(false);
      }
    };

    fetchChildren();
  }, []);

  const fetchAnnouncements = async () => {
    if (!selectedChildId) return;

    setIsLoadingAnnouncements(true);
    setError(null);
    try {
      const res = await api.guardian.getChildAnnouncements(selectedChildId, {
        priority: priorityFilter,
        search: searchQuery
      });

      if (res.success && res.data) {
        setAnnouncementData(res.data);
      } else {
        if (res.code === 'FORBIDDEN_STUDENT_ACCESS') {
          setAuthError(typeof res.error === 'string' ? res.error : 'Access restricted.');
        } else {
          setError(typeof res.error === 'string' ? res.error : 'Failed to load classroom announcements.');
        }
      }
    } catch (err: any) {
      setError(err?.message || 'Network error fetching announcements.');
    } finally {
      setIsLoadingAnnouncements(false);
    }
  };

  useEffect(() => {
    if (selectedChildId) {
      fetchAnnouncements();
    }
  }, [selectedChildId, priorityFilter]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchAnnouncements();
  };

  const handleResetFilters = () => {
    setPriorityFilter('ALL');
    setCategoryFilter('ALL');
    setSearchQuery('');
  };

  const handleOpenNotice = async (item: ClassAnnouncement) => {
    setSelectedAnnouncement(item);
    if (!item.isRead && selectedChildId) {
      setAnnouncementData((prev) => {
        if (!prev) return prev;
        return {
          ...prev,
          data: prev.data.map((a) => (a.id === item.id ? { ...a, isRead: true } : a))
        };
      });
      try {
        await api.guardian.markAnnouncementRead(selectedChildId, item.id);
      } catch (e) {
        console.error('Failed to mark read', e);
      }
    }
  };

  const getPriorityBadge = (priority?: string) => {
    switch ((priority || '').toLowerCase()) {
      case 'urgent':
        return (
          <Badge variant="danger" className="text-[10px] uppercase font-bold">
            <AlertTriangle className="w-3 h-3 mr-1" /> Urgent Notice
          </Badge>
        );
      case 'high':
        return (
          <Badge variant="warning" className="text-[10px] uppercase font-bold">
            <Bell className="w-3 h-3 mr-1" /> High Priority
          </Badge>
        );
      default:
        return (
          <Badge variant="default" className="text-[10px] uppercase font-medium">
            General Notice
          </Badge>
        );
    }
  };

  const getCategoryBadge = (cat?: string) => {
    switch (cat) {
      case 'EMERGENCY':
        return <Badge variant="danger" size="sm" className="text-[10px] font-bold">EMERGENCY</Badge>;
      case 'ACADEMIC':
        return <Badge variant="info" size="sm" className="text-[10px]">ACADEMIC</Badge>;
      case 'EXAMINATION':
        return <Badge variant="warning" size="sm" className="text-[10px]">EXAMS</Badge>;
      case 'EVENT':
        return <Badge variant="purple" size="sm" className="text-[10px]">EVENT</Badge>;
      case 'HOLIDAY':
        return <Badge variant="success" size="sm" className="text-[10px]">HOLIDAY</Badge>;
      case 'FEE_FINANCE':
        return <Badge variant="neutral" size="sm" className="text-[10px]">FEE/FINANCE</Badge>;
      default:
        return null;
    }
  };

  const activeChild = (children || []).find((c) => c.id === selectedChildId) || children?.[0];

  if (isLoadingChildren) {
    return (
      <div className="p-12 flex flex-col items-center justify-center min-h-[450px] space-y-4">
        <LoadingSpinner size="lg" message="Loading your verified scholars..." />
      </div>
    );
  }

  if (authError) {
    return (
      <div className="p-8 max-w-2xl mx-auto space-y-6 text-center">
        <div className="w-16 h-16 rounded-3xl bg-rose-500/20 border border-rose-500/30 text-rose-400 flex items-center justify-center mx-auto">
          <AlertCircle className="w-8 h-8" />
        </div>
        <div className="space-y-2">
          <h2 className="text-2xl font-bold text-white tracking-tight">Access Restricted</h2>
          <p className="text-sm text-slate-400">{authError}</p>
        </div>
        <div className="flex justify-center gap-3">
          <Button
            id="guardian-ann-back-btn"
            variant="secondary"
            onClick={() => onNavigate && onNavigate('guardian-dashboard')}
          >
            <ArrowLeft className="w-4 h-4 mr-2" /> Back to Dashboard
          </Button>
        </div>
      </div>
    );
  }

  if ((children?.length || 0) === 0) {
    return (
      <div className="p-12 max-w-lg mx-auto text-center space-y-4 rounded-3xl bg-slate-900/60 border border-white/10 p-8">
        <div className="w-14 h-14 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center mx-auto">
          <UserCheck className="w-7 h-7" />
        </div>
        <h3 className="text-xl font-bold text-white">No Linked Scholars</h3>
        <p className="text-sm text-slate-400">
          There are currently no student accounts linked to your guardian profile.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      {/* 1. Header & Navigation Hub */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <button
              onClick={() => onNavigate && onNavigate('guardian-dashboard')}
              className="text-xs font-semibold text-slate-400 hover:text-purple-400 transition-colors flex items-center gap-1"
            >
              <ArrowLeft className="w-3.5 h-3.5" /> Portal Dashboard
            </button>
            <span className="text-slate-600">/</span>
            <span className="text-xs font-semibold text-purple-400">Classroom Announcements</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight flex items-center gap-3">
            <Sparkles className="w-8 h-8 text-purple-400" />
            Class Announcements
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Stay informed on classroom circulars, faculty notices, field trips, and academic bulletins.
          </p>
        </div>

        {/* Quick Links */}
        <div className="flex flex-wrap items-center gap-2">
          <Button
            id="guardian-nav-hw-from-ann"
            variant="outline"
            size="sm"
            onClick={() => onNavigate && onNavigate('guardian-homework')}
            className="text-xs border-white/10 hover:border-purple-500/40"
          >
            <BookOpen className="w-3.5 h-3.5 mr-1.5 text-amber-400" />
            Homework
          </Button>
          <Button
            id="guardian-nav-asg-from-ann"
            variant="outline"
            size="sm"
            onClick={() => onNavigate && onNavigate('guardian-assignments')}
            className="text-xs border-white/10 hover:border-purple-500/40"
          >
            <FileText className="w-3.5 h-3.5 mr-1.5 text-indigo-400" />
            Assignments
          </Button>
          <Button
            id="guardian-nav-mat-from-ann"
            variant="outline"
            size="sm"
            onClick={() => onNavigate && onNavigate('guardian-materials')}
            className="text-xs border-white/10 hover:border-purple-500/40"
          >
            <FolderOpen className="w-3.5 h-3.5 mr-1.5 text-emerald-400" />
            Study Materials
          </Button>
        </div>
      </div>

      {/* 2. Multi-Child Selector */}
      <div className="rounded-3xl bg-slate-900/60 border border-white/10 p-5 backdrop-blur-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400 shrink-0">
              <GraduationCap className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-semibold text-purple-400 uppercase tracking-wider">Active Scholar</div>
              <div className="text-sm font-bold text-white">
                {activeChild ? `${activeChild.name} (${activeChild.className} - ${activeChild.sectionName})` : 'Select Scholar'}
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {(children || []).map((child) => {
              const isSelected = child.id === selectedChildId;
              return (
                <button
                  key={child.id}
                  id={`select-child-ann-${child.id}`}
                  onClick={() => setSelectedChildId(child.id)}
                  className={`flex items-center gap-3 px-4 py-2.5 rounded-2xl text-xs font-bold transition-all border ${
                    isSelected
                      ? 'bg-purple-600 text-white border-purple-400 shadow-lg shadow-purple-500/25 scale-[1.02]'
                      : 'bg-slate-800/80 text-slate-300 border-white/5 hover:border-white/20 hover:bg-slate-800'
                  }`}
                >
                  <div
                    className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-black ${
                      isSelected ? 'bg-white text-purple-800' : 'bg-purple-500/20 text-purple-300'
                    }`}
                  >
                    {child.name.charAt(0)}
                  </div>
                  <div className="text-left">
                    <div>{child.name}</div>
                    <div className={`text-[10px] font-normal ${isSelected ? 'text-purple-100' : 'text-slate-400'}`}>
                      {child.className} • Sec {child.sectionName}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* 3. Filter Toolbar */}
      <div className="rounded-3xl bg-slate-900/60 border border-white/10 p-5 backdrop-blur-xl space-y-4">
        <form onSubmit={handleSearchSubmit} className="grid grid-cols-1 sm:grid-cols-4 gap-3">
          <div className="relative sm:col-span-2">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              id="guardian-ann-search-input"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search announcements by subject, keyword, teacher..."
              className="w-full bg-slate-800/80 border border-white/10 rounded-2xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-400 transition-colors"
            />
          </div>

          <div>
            <select
              id="guardian-ann-priority-filter"
              value={priorityFilter}
              onChange={(e) => setPriorityFilter(e.target.value)}
              className="w-full bg-slate-800/80 border border-white/10 rounded-2xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-purple-400 transition-colors"
            >
              <option value="ALL">All Priorities</option>
              <option value="urgent">Urgent</option>
              <option value="high">High</option>
              <option value="normal">Normal</option>
            </select>
          </div>

          <div className="flex gap-2">
            <select
              id="guardian-ann-category-filter"
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="w-full bg-slate-800/80 border border-white/10 rounded-2xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-purple-400 transition-colors"
            >
              <option value="ALL">All Categories</option>
              <option value="ACADEMIC">Academic</option>
              <option value="EXAMINATION">Examinations</option>
              <option value="EVENT">Events</option>
              <option value="HOLIDAY">Holidays</option>
              <option value="FEE_FINANCE">Fee & Finance</option>
              <option value="EMERGENCY">Emergency</option>
              <option value="GENERAL">General</option>
            </select>
            <Button
              type="button"
              id="guardian-ann-reset-btn"
              variant="secondary"
              size="sm"
              onClick={handleResetFilters}
              title="Reset Filters"
              className="shrink-0 px-3"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </Button>
          </div>
        </form>
      </div>

      {/* 4. Announcements Feed */}
      {isLoadingAnnouncements ? (
        <div className="p-12 flex flex-col items-center justify-center min-h-[300px]">
          <LoadingSpinner size="md" message="Fetching class announcements..." />
        </div>
      ) : error ? (
        <div className="p-8 text-center rounded-3xl bg-rose-500/10 border border-rose-500/20 max-w-xl mx-auto space-y-3">
          <AlertCircle className="w-8 h-8 text-rose-400 mx-auto" />
          <div className="text-sm font-semibold text-white">Error Loading Announcements</div>
          <p className="text-xs text-slate-400">{error}</p>
          <Button onClick={fetchAnnouncements} variant="secondary" size="sm">
            <RefreshCw className="w-3.5 h-3.5 mr-2" /> Try Again
          </Button>
        </div>
      ) : !announcementData || !Array.isArray(announcementData.data) || announcementData.data.length === 0 ? (
        <div className="p-12 text-center rounded-3xl bg-slate-900/40 border border-white/10 max-w-lg mx-auto space-y-4">
          <div className="w-14 h-14 rounded-2xl bg-slate-800 text-slate-400 flex items-center justify-center mx-auto">
            <Sparkles className="w-7 h-7" />
          </div>
          <div className="space-y-1">
            <h3 className="text-base font-bold text-white">No Announcements</h3>
            <p className="text-xs text-slate-400">
              There are no classroom notices posted for {activeChild?.name} matching your search.
            </p>
          </div>
          {(priorityFilter !== 'ALL' || categoryFilter !== 'ALL' || searchQuery) && (
            <Button onClick={handleResetFilters} variant="secondary" size="sm">
              Clear All Filters
            </Button>
          )}
        </div>
      ) : (
        <div className="space-y-4">
          {(announcementData.data || [])
            .filter((item) => categoryFilter === 'ALL' || item.category === categoryFilter)
            .map((item) => (
            <div
              key={item.id}
              id={`guardian-ann-card-${item.id}`}
              onClick={() => handleOpenNotice(item)}
              className={`group relative rounded-3xl p-6 backdrop-blur-xl border transition-all duration-200 hover:-translate-y-0.5 cursor-pointer ${
                item.isPinned
                  ? 'bg-gradient-to-r from-purple-950/40 to-slate-900/80 border-purple-500/30 hover:border-purple-500/60 shadow-lg shadow-purple-950/20'
                  : !item.isRead
                  ? 'bg-slate-900/80 border-purple-500/30'
                  : 'bg-slate-900/60 border-white/10 hover:border-purple-500/40'
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                <div className="space-y-2">
                  <div className="flex flex-wrap items-center gap-2">
                    {item.isPinned && (
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1">
                        <Pin className="w-3 h-3 fill-amber-300" /> Pinned Bulletin
                      </span>
                    )}

                    {getPriorityBadge(item.priority)}
                    {getCategoryBadge(item.category)}

                    {!item.isRead ? (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-purple-500 text-white uppercase tracking-wider animate-pulse">
                        NEW
                      </span>
                    ) : (
                      <span className="flex items-center gap-1 text-[11px] text-emerald-400 font-medium">
                        <Check className="w-3 h-3" /> Read
                      </span>
                    )}

                    <span className="text-xs text-slate-400 font-medium">
                      {item.className ? `Class ${item.className}` : 'All Scholars'}
                    </span>
                  </div>

                  <h3 className="text-lg font-bold text-white group-hover:text-purple-300 transition-colors">
                    {item.title}
                  </h3>

                  <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed">
                    {item.message}
                  </p>

                  {/* Attachments preview */}
                  {((item?.attachments?.length || 0) > 0) && (
                    <div className="flex flex-wrap items-center gap-2 pt-1">
                      <span className="text-[11px] text-slate-400 flex items-center gap-1">
                        <Paperclip className="w-3 h-3 text-slate-400" />
                        {item.attachments?.length || 0} attachment{(item.attachments?.length || 0) > 1 ? 's' : ''}:
                      </span>
                      {(item?.attachments || []).map((att, idx) => (
                        <span
                          key={idx}
                          className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-lg bg-slate-800/80 border border-white/10 text-[11px] text-slate-300"
                        >
                          <FileText className="w-3 h-3 text-purple-400" />
                          <span className="truncate max-w-[120px]">{att.name}</span>
                        </span>
                      ))}
                    </div>
                  )}
                </div>

                <div className="shrink-0 text-right space-y-1">
                  <div className="text-xs font-semibold text-slate-300">{item.teacherName}</div>
                  <div className="text-[11px] text-slate-500 flex items-center sm:justify-end gap-1">
                    <Calendar className="w-3 h-3" />
                    {item.publishDate}
                  </div>
                  {item.expiryDate && (
                    <div className="text-[10px] text-slate-400">
                      Valid thru {item.expiryDate}
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* 5. Announcement Detail Modal */}
      <Modal
        isOpen={!!selectedAnnouncement}
        onClose={() => setSelectedAnnouncement(null)}
        title="Classroom Bulletin & Circular"
      >
        {selectedAnnouncement && (
          <div className="space-y-6">
            <div className="flex items-start justify-between gap-4">
              <div className="space-y-2">
                <div className="flex flex-wrap items-center gap-2">
                  {selectedAnnouncement.isPinned && (
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1">
                      <Pin className="w-3 h-3 fill-amber-300" /> Pinned
                    </span>
                  )}
                  {getPriorityBadge(selectedAnnouncement.priority)}
                  {getCategoryBadge(selectedAnnouncement.category)}
                  <span className="flex items-center gap-1 text-[11px] text-emerald-400 font-medium px-2 py-0.5 rounded bg-emerald-950/50 border border-emerald-500/30">
                    <Check className="w-3 h-3" /> Read Receipt Verified
                  </span>
                </div>
                <h2 className="text-xl font-bold text-white">{selectedAnnouncement.title}</h2>
                <div className="text-xs text-slate-400">
                  Posted by <strong className="text-slate-200">{selectedAnnouncement.teacherName}</strong> • {selectedAnnouncement.className || activeChild?.className}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="p-3.5 rounded-2xl bg-slate-900 border border-white/5 text-xs text-slate-400 flex items-center justify-between">
                <span>Date Published:</span>
                <strong className="text-slate-200">{selectedAnnouncement.publishDate}</strong>
              </div>
              <div className="p-3.5 rounded-2xl bg-slate-900 border border-white/5 text-xs text-slate-400 flex items-center justify-between">
                <span>Validity / Expiry:</span>
                <strong className="text-slate-200">{selectedAnnouncement.expiryDate || 'Indefinite'}</strong>
              </div>
            </div>

            <div className="space-y-2">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">Notice Content</h4>
              <div className="p-5 rounded-2xl bg-slate-900/90 border border-white/5 text-xs text-slate-200 leading-relaxed whitespace-pre-wrap">
                {selectedAnnouncement.message}
              </div>
            </div>

            {/* Attachments Section in Modal */}
            {((selectedAnnouncement?.attachments?.length || 0) > 0) && (
              <div className="space-y-2">
                <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                  <Paperclip className="w-3.5 h-3.5 text-purple-400" />
                  <span>Attachments ({selectedAnnouncement?.attachments?.length || 0})</span>
                </h4>
                <div className="space-y-2">
                  {(selectedAnnouncement?.attachments || []).map((att, idx) => (
                    <div
                      key={idx}
                      className="p-3 rounded-xl bg-slate-950/50 border border-white/10 flex items-center justify-between gap-3 text-xs"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <FileText className="w-4 h-4 text-purple-400 shrink-0" />
                        <div className="truncate">
                          <p className="font-semibold text-slate-200 truncate">{att.name}</p>
                          <p className="text-[10px] text-slate-400">
                            {att.size ? `${(att.size / 1024).toFixed(1)} KB` : 'Document'}
                          </p>
                        </div>
                      </div>
                      <a
                        href={att.url}
                        target="_blank"
                        rel="noreferrer"
                        className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-lg flex items-center gap-1.5 font-medium shrink-0 transition-colors"
                      >
                        <Download className="w-3.5 h-3.5" />
                        Download
                      </a>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="flex justify-end pt-2">
              <Button onClick={() => setSelectedAnnouncement(null)} variant="secondary">
                Close
              </Button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};
