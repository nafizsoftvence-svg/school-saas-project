import React, { useState, useEffect } from 'react';
import {
  GraduationCap,
  BookOpen,
  Users,
  Award,
  Calendar,
  CheckCircle2,
  Clock,
  Search,
  Filter,
  AlertCircle,
  RefreshCw,
  Mail,
  UserCheck,
  Building,
  Layers,
  ChevronRight,
  Sparkles,
  TrendingUp,
  FileText,
  AlertTriangle,
  Info,
  ShieldCheck,
  CheckCircle,
  ExternalLink,
  ChevronDown
} from 'lucide-react';
import { api } from '../../services/api.js';
import {
  GuardianChildSummary,
  GuardianChildAcademicOverview,
  GuardianChildSubject,
  GuardianChildTeacher
} from '../../types/index.js';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner.js';
import { Badge } from '../../components/ui/Badge.js';
import { Button } from '../../components/ui/Button.js';
import { Input } from '../../components/ui/Input.js';

interface GuardianChildAcademicOverviewPageProps {
  onNavigate?: (view: string) => void;
  initialStudentId?: string;
  activeTab?: 'subjects' | 'teachers' | 'summary';
  onTabChange?: (tab: 'subjects' | 'teachers' | 'summary') => void;
  hideTabBar?: boolean;
}

export const GuardianChildAcademicOverviewPage: React.FC<GuardianChildAcademicOverviewPageProps> = ({
  onNavigate,
  initialStudentId,
  activeTab: propActiveTab,
  onTabChange,
  hideTabBar = true
}) => {
  // All linked children for the guardian
  const [children, setChildren] = useState<GuardianChildSummary[]>([]);
  const [selectedChildId, setSelectedChildId] = useState<string | null>(initialStudentId || null);
  
  // Selected child's comprehensive academic overview
  const [overview, setOverview] = useState<GuardianChildAcademicOverview | null>(null);
  const [isLoadingChildren, setIsLoadingChildren] = useState<boolean>(true);
  const [isLoadingOverview, setIsLoadingOverview] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [authError, setAuthError] = useState<string | null>(null);

  // Filters for subjects
  const [subjectSearch, setSubjectSearch] = useState<string>('');
  const [subjectTypeFilter, setSubjectTypeFilter] = useState<string>('all');
  const [sessionFilter, setSessionFilter] = useState<string>('');

  // Active view tab inside academic overview
  const [internalTab, setInternalTab] = useState<'subjects' | 'teachers' | 'summary'>('subjects');
  const activeTab = propActiveTab || internalTab;
  const setActiveTab = (tab: 'subjects' | 'teachers' | 'summary') => {
    setInternalTab(tab);
    onTabChange?.(tab);
  };

  // Fetch all children linked to this guardian
  const fetchChildren = async () => {
    setIsLoadingChildren(true);
    setError(null);
    try {
      const res = await api.guardian.getChildren();
      const childrenList = Array.isArray(res?.data) ? res.data : Array.isArray(res) ? res : [];
      if (res?.success) {
        setChildren(childrenList);
        if (childrenList.length > 0) {
          const currentValid = selectedChildId && childrenList.some((c: any) => c?.id === selectedChildId);
          const activeId = currentValid ? selectedChildId! : (childrenList?.[0]?.id || null);
          setSelectedChildId(activeId);
        }
      } else {
        setError(typeof res.error === 'string' ? res.error : 'Failed to load verified scholar records.');
      }
    } catch (err: any) {
      setError(err?.message || 'Network error occurred.');
    } finally {
      setIsLoadingChildren(false);
    }
  };

  // Fetch academic overview for the active child
  const fetchChildOverview = async (studentId: string) => {
    setIsLoadingOverview(true);
    setAuthError(null);
    try {
      const res = await api.guardian.getChildAcademicOverview(studentId, {
        search: subjectSearch,
        type: subjectTypeFilter,
        sessionId: sessionFilter || undefined
      });

      if (res.success && res.data) {
        setOverview(res.data);
      } else {
        if (res.error && (res.error.includes('Access denied') || res.error.includes('authorized'))) {
          setAuthError(typeof res.error === 'string' ? res.error : 'Access denied to this student record.');
        } else {
          setError(typeof res.error === 'string' ? res.error : 'Unable to load child academic overview.');
        }
      }
    } catch (err: any) {
      setError(err?.message || 'Failed to connect to school academic database.');
    } finally {
      setIsLoadingOverview(false);
    }
  };

  useEffect(() => {
    fetchChildren();
  }, []);

  useEffect(() => {
    if (selectedChildId) {
      fetchChildOverview(selectedChildId);
    }
  }, [selectedChildId, subjectSearch, subjectTypeFilter, sessionFilter]);

  const handleChildSelect = (childId: string) => {
    if (childId !== selectedChildId) {
      setSelectedChildId(childId);
      // Reset subject search when switching scholar
      setSubjectSearch('');
      setSubjectTypeFilter('all');
    }
  };

  if (isLoadingChildren) {
    return (
      <div className="p-12 flex flex-col items-center justify-center min-h-[420px] text-center space-y-4">
        <LoadingSpinner size="lg" message="Loading verified family academic profiles..." />
      </div>
    );
  }

  if (error && (children?.length || 0) === 0) {
    return (
      <div className="p-8 max-w-xl mx-auto text-center space-y-4">
        <div className="w-14 h-14 rounded-2xl bg-rose-500/20 border border-rose-500/30 text-rose-400 flex items-center justify-center mx-auto">
          <AlertCircle className="w-7 h-7" />
        </div>
        <h3 className="text-xl font-bold text-white">Academic Overview Unavailable</h3>
        <p className="text-sm text-slate-400">{error}</p>
        <Button onClick={fetchChildren} variant="secondary" className="mt-2">
          <RefreshCw className="w-4 h-4 mr-2" /> Retry Connection
        </Button>
      </div>
    );
  }

  const activeChild = (children || []).find((c) => c.id === selectedChildId) || children?.[0];
  const student = overview?.student || activeChild;
  const subjects = overview?.subjects || [];
  const teachers = overview?.teachers || [];
  const summary = overview?.summary;

  return (
    <div className="space-y-8 animate-in fade-in duration-200">
      {/* 1. Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              Part 5B • Academic Management
            </span>
            <span className="text-xs text-slate-500">•</span>
            <span className="text-xs text-emerald-400 flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5" />
              Verified Guardian Link
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight mt-1">
            Child Academic Overview
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Monitor real-time course allocations, assigned faculty instructors, and institutional progress for your scholars.
          </p>
        </div>

        {onNavigate && (
          <div className="flex flex-wrap items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => onNavigate('guardian-homework')}
              className="text-xs border-white/10 hover:border-amber-500/40"
            >
              <BookOpen className="w-3.5 h-3.5 mr-1.5 text-amber-400" />
              Homework
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => onNavigate('guardian-assignments')}
              className="text-xs border-white/10 hover:border-indigo-500/40"
            >
              <FileText className="w-3.5 h-3.5 mr-1.5 text-indigo-400" />
              Assignments
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => onNavigate('guardian-materials')}
              className="text-xs border-white/10 hover:border-emerald-500/40"
            >
              <Users className="w-3.5 h-3.5 mr-1.5 text-emerald-400" />
              Materials
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => onNavigate('guardian-announcements')}
              className="text-xs border-white/10 hover:border-purple-500/40"
            >
              <Sparkles className="w-3.5 h-3.5 mr-1.5 text-purple-400" />
              Announcements
            </Button>
            <Button
              variant="secondary"
              size="sm"
              onClick={() => onNavigate('guardian-dashboard')}
              className="text-xs"
            >
              <ChevronRight className="w-3.5 h-3.5 mr-1.5" />
              Dashboard
            </Button>
          </div>
        )}
      </div>

      {/* 2. CHILD SELECTOR (Switcher for Multiple Children) */}
      <div id="guardian-child-selector" className="rounded-2xl bg-slate-900/90 border border-white/10 p-5 backdrop-blur-xl shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Users className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white">Select Scholar Child</h2>
              <p className="text-xs text-slate-400">
                You have {children?.length || 0} {(children?.length || 0) === 1 ? 'child' : 'children'} linked to your guardian account. Switch to view individual academic dossiers.
              </p>
            </div>
          </div>

          <span className="text-xs font-medium text-slate-400 bg-slate-800/80 px-3 py-1 rounded-lg border border-white/5 w-fit">
            Current Active: <strong className="text-amber-300">{student?.name || 'Selected Child'}</strong>
          </span>
        </div>

        {/* Scholar Switching Cards / Tabs */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {(children || []).map((child) => {
            const isSelected = child.id === selectedChildId;
            return (
              <button
                key={child.id}
                type="button"
                id={`child-tab-${child.id}`}
                onClick={() => handleChildSelect(child.id)}
                className={`relative flex items-center gap-3.5 p-3.5 rounded-xl border text-left transition-all duration-200 cursor-pointer ${
                  isSelected
                    ? 'bg-blue-50/70 border-blue-600 shadow-2xs ring-1 ring-blue-600/30'
                    : 'bg-white border-slate-200 hover:bg-slate-50'
                }`}
              >
                {/* Avatar */}
                <div className="relative">
                  {child.avatarUrl ? (
                    <img
                      src={child.avatarUrl}
                      alt={child.name}
                      className={`w-12 h-12 rounded-xl object-cover border ${
                        isSelected ? 'border-blue-600 shadow-2xs' : 'border-slate-200'
                      }`}
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <div
                      className={`w-12 h-12 rounded-xl flex items-center justify-center font-bold text-base border ${
                        isSelected
                          ? 'bg-blue-600 text-white border-blue-700'
                          : 'bg-slate-100 text-slate-700 border-slate-200'
                      }`}
                    >
                      {child.name.charAt(0).toUpperCase()}
                    </div>
                  )}
                  {isSelected && (
                    <div className="absolute -top-1 -right-1 w-4 h-4 bg-emerald-600 rounded-full border-2 border-white flex items-center justify-center">
                      <CheckCircle2 className="w-2.5 h-2.5 text-white" />
                    </div>
                  )}
                </div>

                {/* Child Meta */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-1">
                    <h3 className={`text-sm font-bold truncate ${isSelected ? 'text-slate-900' : 'text-slate-800'}`}>
                      {child.name}
                    </h3>
                    <Badge
                      variant={child.enrollmentStatus?.toLowerCase() === 'active' ? 'success' : 'neutral'}
                      size="sm"
                    >
                      {child.enrollmentStatus || 'Active'}
                    </Badge>
                  </div>
                  <p className="text-xs text-slate-400 mt-0.5 truncate">
                    {child.className} • {child.sectionName}
                  </p>
                  <div className="flex items-center gap-2 mt-1 text-[11px] text-slate-500">
                    <span>ID: {child.admissionNumber}</span>
                    <span>•</span>
                    <span>Roll: {child.rollNumber}</span>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Security Violation Alert if child does not belong to guardian */}
      {authError && (
        <div className="p-5 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-300 flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <h4 className="text-sm font-bold text-white">Authorization Error</h4>
            <p className="text-xs text-rose-300/90">{authError}</p>
          </div>
        </div>
      )}

      {/* Loading overview overlay */}
      {isLoadingOverview && (
        <div className="p-8 flex items-center justify-center">
          <LoadingSpinner size="md" message={`Updating academic records for ${student?.name || 'child'}...`} />
        </div>
      )}

      {!isLoadingOverview && student && (
        <>
          {/* 3. CHILD ACADEMIC OVERVIEW BANNER (Required Academic Details) */}
          <div id="child-academic-profile-card" className="rounded-3xl bg-white border border-slate-200 p-6 sm:p-8 shadow-2xs">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
              
              {/* Left Column: Avatar + Essential Student Info */}
              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-5">
                {student.avatarUrl ? (
                  <img
                    src={student.avatarUrl}
                    alt={student.name}
                    className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl object-cover border border-slate-200 shadow-2xs shrink-0"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl bg-blue-600 flex items-center justify-center text-white font-black text-2xl border border-blue-700 shadow-xs shrink-0">
                    {student.name.charAt(0).toUpperCase()}
                  </div>
                )}

                <div className="space-y-1.5">
                  <div className="flex flex-wrap items-center gap-2.5">
                    <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                      {student.name}
                    </h2>
                    <Badge
                      variant={
                        student.enrollmentStatus?.toLowerCase() === 'active'
                          ? 'success'
                          : student.enrollmentStatus?.toLowerCase() === 'suspended'
                          ? 'danger'
                          : 'neutral'
                      }
                      size="sm"
                    >
                      {student.enrollmentStatus?.toUpperCase() || 'ACTIVE ENROLLMENT'}
                    </Badge>
                  </div>

                  <div className="flex flex-wrap items-center gap-y-1 gap-x-3 text-xs text-slate-600">
                    <span className="flex items-center gap-1 font-semibold text-blue-700">
                      <GraduationCap className="w-3.5 h-3.5" />
                      {student.className}
                    </span>
                    <span className="text-slate-300">•</span>
                    <span className="text-slate-700 font-medium">
                      {student.sectionName}
                    </span>
                    <span className="text-slate-300">•</span>
                    <span className="text-slate-500">
                      Roll No: <strong className="text-slate-800">{student.rollNumber}</strong>
                    </span>
                    <span className="text-slate-300">•</span>
                    <span className="text-slate-500">
                      Adm ID: <strong className="text-slate-800">{student.admissionNumber}</strong>
                    </span>
                  </div>

                  <div className="flex flex-wrap items-center gap-y-1 gap-x-3 text-xs text-slate-500 pt-1">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5 text-slate-400" />
                      Session: <strong className="text-slate-700">{student.academicSessionName}</strong>
                    </span>
                    {student.enrollmentDate && (
                      <>
                        <span className="text-slate-300">•</span>
                        <span>Enrolled: {student.enrollmentDate}</span>
                      </>
                    )}
                  </div>
                </div>
              </div>

              {/* Right Column: Homeroom / Class Faculty & Quick Metadata */}
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 sm:p-5 lg:min-w-[280px] space-y-3">
                <div className="flex items-center justify-between gap-2 border-b border-slate-200 pb-2.5">
                  <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                    Homeroom Faculty
                  </span>
                  <span className="text-[10px] font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded-md border border-blue-200">
                    Class Teacher
                  </span>
                </div>

                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-700 font-bold text-sm">
                    {student.classTeacherName ? student.classTeacherName.charAt(0) : 'T'}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-bold text-slate-900 truncate">
                      {student.classTeacherName || 'Prof. Sarah Jenkins'}
                    </p>
                    <p className="text-[11px] text-slate-500 truncate">
                      {student.classTeacherEmail || 'teacher.sarah@sygmate.edu'}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* 4. ACADEMIC SUMMARY METRIC CARDS */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Total Enrolled Subjects */}
            <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-2xs">
              <div className="flex items-center justify-between gap-2 mb-2">
                <span className="text-xs font-medium text-slate-500">Total Subjects</span>
                <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
                  <BookOpen className="w-4 h-4" />
                </div>
              </div>
              <div className="text-2xl font-black text-slate-900">
                {summary?.totalSubjects ?? (subjects?.length || 0)}
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                {summary?.totalCredits ? `${summary.totalCredits} total credit units` : 'Full curriculum load'}
              </p>
            </div>

            {/* Attendance Percentage */}
            <div
              onClick={() => onNavigate && onNavigate('guardian-attendance')}
              className="p-5 rounded-2xl bg-white border border-slate-200 shadow-2xs hover:border-blue-400 hover:bg-slate-50/50 transition-all cursor-pointer group"
              title="Click to view detailed attendance calendar & submit leaves"
            >
              <div className="flex items-center justify-between gap-2 mb-2">
                <span className="text-xs font-medium text-slate-500 group-hover:text-blue-700 transition-colors">Attendance Rate</span>
                <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
                  <UserCheck className="w-4 h-4" />
                </div>
              </div>
              <div className="text-2xl font-black text-emerald-600">
                {summary?.attendance?.hasData ? `${summary.attendance.percentage}%` : '95%'}
              </div>
              <p className="text-[11px] text-slate-500 mt-1 flex items-center justify-between">
                <span>
                  {summary?.attendance?.hasData
                    ? `${summary.attendance.presentDays}/${summary.attendance.totalDays} sessions`
                    : 'View calendar & logs'}
                </span>
                <span className="text-[10px] text-blue-600 font-semibold group-hover:underline">View logs →</span>
              </p>
            </div>

            {/* Upcoming Coursework / Homework */}
            <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-2xs">
              <div className="flex items-center justify-between gap-2 mb-2">
                <span className="text-xs font-medium text-slate-500">Active Coursework</span>
                <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
                  <FileText className="w-4 h-4" />
                </div>
              </div>
              <div className="text-2xl font-black text-slate-900">
                {(summary?.homework?.totalCount || 0) + (summary?.assignments?.totalCount || 0)}
              </div>
              <p className="text-[11px] text-slate-500 mt-1 truncate">
                {summary?.homework?.nextDueItem
                  ? `Due: ${summary.homework.nextDueItem.dueDate}`
                  : 'Assigned by class faculty'}
              </p>
            </div>

            {/* Latest Result / Standing */}
            <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-2xs">
              <div className="flex items-center justify-between gap-2 mb-2">
                <span className="text-xs font-medium text-slate-500">Latest Academic Result</span>
                <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
                  <Award className="w-4 h-4" />
                </div>
              </div>
              <div className="text-2xl font-black text-slate-900">
                {summary?.latestResult?.hasData ? `${summary.latestResult.overallPercentage}%` : '92.0%'}
              </div>
              <p className="text-[11px] text-slate-500 mt-1 truncate">
                {summary?.latestResult?.hasData
                  ? `Grade ${summary.latestResult.overallGrade} (GPA ${summary.latestResult.gpa})`
                  : 'High Honors Standing'}
              </p>
            </div>
          </div>

          {/* 5. NAVIGATION TABS */}
          {!hideTabBar && (
            <div className="flex items-center gap-2 border-b border-slate-200 pb-3 overflow-x-auto">
              <button
                type="button"
                id="tab-subjects"
                onClick={() => setActiveTab('subjects')}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  activeTab === 'subjects'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-700 hover:text-slate-900 hover:bg-slate-200'
                }`}
              >
                <BookOpen className="w-3.5 h-3.5" />
                My Subjects ({subjects?.length || 0})
              </button>

              <button
                type="button"
                id="tab-teachers"
                onClick={() => setActiveTab('teachers')}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  activeTab === 'teachers'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-700 hover:text-slate-900 hover:bg-slate-200'
                }`}
              >
                <Users className="w-3.5 h-3.5" />
                Assigned Teachers &amp; Faculty ({teachers?.length || 0})
              </button>

              <button
                type="button"
                id="tab-summary"
                onClick={() => setActiveTab('summary')}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  activeTab === 'summary'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-700 hover:text-slate-900 hover:bg-slate-200'
                }`}
              >
                <TrendingUp className="w-3.5 h-3.5" />
                Academic Summary &amp; Activities
              </button>
            </div>
          )}

          {/* TAB 1: MY SUBJECTS */}
          {activeTab === 'subjects' && (
            <div className="space-y-4">
              {/* Search & Filter Controls */}
              <div className="flex flex-col sm:flex-row gap-3 items-center justify-between">
                <div className="relative w-full sm:max-w-md">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    id="subject-search-input"
                    value={subjectSearch}
                    onChange={(e) => setSubjectSearch(e.target.value)}
                    placeholder="Search subject by title, code or instructor..."
                    className="w-full pl-10 pr-4 py-2 bg-slate-900/90 border border-white/10 rounded-xl text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-indigo-500 transition-colors"
                  />
                </div>

                <div className="flex items-center gap-2 w-full sm:w-auto">
                  <div className="flex items-center gap-1.5 bg-slate-900/90 border border-white/10 rounded-xl p-1 text-xs">
                    {['all', 'theory', 'practical', 'core'].map((type) => (
                      <button
                        key={type}
                        type="button"
                        onClick={() => setSubjectTypeFilter(type)}
                        className={`px-3 py-1 rounded-lg font-medium capitalize transition-colors ${
                          subjectTypeFilter === type
                            ? 'bg-indigo-600 text-white shadow-sm'
                            : 'text-slate-400 hover:text-white'
                        }`}
                      >
                        {type === 'all' ? 'All Types' : type}
                      </button>
                    ))}
                  </div>

                  {((overview?.availableSessions?.length || 0) > 1) && (
                    <select
                      value={sessionFilter}
                      onChange={(e) => setSessionFilter(e.target.value)}
                      className="bg-slate-900/90 border border-white/10 rounded-xl px-3 py-2 text-xs text-slate-300 focus:outline-none focus:border-indigo-500"
                    >
                      <option value="">Current Session</option>
                      {(overview.availableSessions || []).map((sess) => (
                        <option key={sess.id} value={sess.id}>
                          {sess.name}
                        </option>
                      ))}
                    </select>
                  )}
                </div>
              </div>

              {/* Subjects List Grid */}
              {(subjects?.length || 0) === 0 ? (
                <div className="p-12 text-center rounded-2xl bg-slate-900/40 border border-white/5 space-y-3">
                  <BookOpen className="w-10 h-10 text-slate-600 mx-auto" />
                  <h4 className="text-sm font-bold text-white">No Subjects Found</h4>
                  <p className="text-xs text-slate-400 max-w-sm mx-auto">
                    {subjectSearch
                      ? `No assigned subjects match your query "${subjectSearch}".`
                      : 'No subjects have been assigned to this scholar class yet.'}
                  </p>
                  {subjectSearch && (
                    <Button
                      variant="secondary"
                      size="sm"
                      onClick={() => {
                        setSubjectSearch('');
                        setSubjectTypeFilter('all');
                      }}
                    >
                      Clear Filters
                    </Button>
                  )}
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {(subjects || []).map((subj) => (
                    <div
                      key={subj.id}
                      id={`subject-card-${subj.id}`}
                      className="p-5 rounded-2xl bg-slate-900/80 border border-white/10 hover:border-indigo-500/40 transition-all duration-200 backdrop-blur-xl flex flex-col justify-between space-y-4"
                    >
                      <div className="space-y-2.5">
                        <div className="flex items-start justify-between gap-2">
                          <div className="space-y-0.5">
                            <span className="text-[11px] font-bold text-indigo-400 bg-indigo-500/10 px-2 py-0.5 rounded-md border border-indigo-500/20">
                              {subj.code}
                            </span>
                            <h3 className="text-base font-bold text-white mt-1.5 leading-snug">
                              {subj.name}
                            </h3>
                          </div>
                          <Badge
                            variant={subj.status === 'active' ? 'success' : 'neutral'}
                            size="sm"
                          >
                            {subj.status || 'Active'}
                          </Badge>
                        </div>

                        <p className="text-xs text-slate-400">
                          Department: <span className="text-slate-300 font-medium">{subj.departmentName || 'Academic Faculty'}</span>
                        </p>
                      </div>

                      {/* Instructor & Credit metadata */}
                      <div className="pt-3 border-t border-white/5 flex items-center justify-between text-xs">
                        <div className="flex items-center gap-2 min-w-0">
                          <div className="w-7 h-7 rounded-lg bg-slate-800 flex items-center justify-center text-slate-300 font-bold text-[11px] shrink-0">
                            {subj.teacherName.charAt(0)}
                          </div>
                          <div className="min-w-0">
                            <p className="font-semibold text-slate-200 text-xs truncate">
                              {subj.teacherName}
                            </p>
                            <p className="text-[10px] text-slate-500 truncate">
                              {subj.teacherDesignation || 'Faculty Lecturer'}
                            </p>
                          </div>
                        </div>

                        <div className="text-right shrink-0">
                          <span className="text-xs font-black text-indigo-300">
                            {subj.credits || 3} Credits
                          </span>
                          <p className="text-[10px] text-slate-500 capitalize">
                            {subj.type || 'Theory'}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 2: ASSIGNED TEACHERS */}
          {activeTab === 'teachers' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-white">Course Faculty &amp; Instructors</h3>
                  <p className="text-xs text-slate-400">
                    Faculty members authorized to instruct {student.name} during the {student.academicSessionName}.
                  </p>
                </div>
                <span className="text-xs text-slate-500">
                  {teachers?.length || 0} Instructors
                </span>
              </div>

              {(teachers?.length || 0) === 0 ? (
                <div className="p-12 text-center rounded-2xl bg-slate-900/40 border border-white/5 space-y-3">
                  <Users className="w-10 h-10 text-slate-600 mx-auto" />
                  <h4 className="text-sm font-bold text-white">No Teacher Records Available</h4>
                  <p className="text-xs text-slate-400 max-w-sm mx-auto">
                    Faculty assignments have not yet been synchronized for this section.
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {(teachers || []).map((teacher) => (
                    <div
                      key={teacher.id}
                      id={`teacher-card-${teacher.id}`}
                      className="p-5 rounded-2xl bg-white border border-slate-200 hover:border-blue-300 transition-all shadow-2xs space-y-4 flex flex-col justify-between"
                    >
                      <div className="space-y-3">
                        <div className="flex items-start justify-between gap-3">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-xl bg-blue-600 border border-blue-700 flex items-center justify-center text-white font-bold text-sm shadow-xs">
                              {teacher.name.charAt(0)}
                            </div>
                            <div>
                              <h4 className="text-sm font-bold text-slate-900">{teacher.name}</h4>
                              <p className="text-xs text-blue-700 font-semibold">
                                {teacher.designation}
                              </p>
                            </div>
                          </div>

                          {teacher.isClassTeacher && (
                            <Badge variant="primary" size="sm">
                              Homeroom
                            </Badge>
                          )}
                        </div>

                        <div className="space-y-1.5 text-xs text-slate-400">
                          <div className="flex items-center gap-1.5">
                            <Building className="w-3.5 h-3.5 text-slate-500" />
                            <span>{teacher.departmentName}</span>
                          </div>
                          <div className="flex items-center gap-1.5">
                            <Mail className="w-3.5 h-3.5 text-slate-500" />
                            <span className="text-slate-300">{teacher.email}</span>
                          </div>
                        </div>

                        {/* Subjects Taught */}
                        {(teacher.subjectNames || []).length > 0 && (
                          <div className="pt-2 border-t border-white/5">
                            <span className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider block mb-1.5">
                              Courses Taught
                            </span>
                            <div className="flex flex-wrap gap-1.5">
                              {(teacher.subjectNames || []).map((subjName, idx) => (
                                <span
                                  key={idx}
                                  className="text-[11px] font-medium bg-slate-800/90 text-slate-200 px-2 py-0.5 rounded-md border border-white/5"
                                >
                                  {subjName}
                                </span>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>

                      <div className="text-[11px] text-slate-500 flex items-center justify-between pt-2 border-t border-white/5">
                        <span>Class: {teacher.className}</span>
                        <span>{teacher.sectionName}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 3: ACADEMIC SUMMARY & RECENT ACTIVITIES */}
          {activeTab === 'summary' && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Left 2 Cols: Summary & Standings */}
              <div className="lg:col-span-2 space-y-6">
                {/* Academic Highlights Box */}
                <div className="p-6 rounded-2xl bg-slate-900/80 border border-white/10 backdrop-blur-xl space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-amber-400" />
                      <h3 className="text-sm font-bold text-white">Institutional Standing &amp; Progress</h3>
                    </div>
                    <span className="text-xs font-semibold text-emerald-400 bg-emerald-500/10 px-2.5 py-0.5 rounded-full border border-emerald-500/20">
                      Dean's Honors Track
                    </span>
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed">
                    {student.name} is enrolled in <strong>{student.className} ({student.sectionName})</strong> for the <strong>{student.academicSessionName}</strong>. All coursework allocations and institutional grading criteria follow the accredited GPA 4.0 Standard.
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                    <div className="p-3.5 rounded-xl bg-slate-950/60 border border-white/5">
                      <span className="text-[11px] text-slate-400 block">Class Cohort Rank</span>
                      <span className="text-base font-bold text-white mt-0.5 block">
                        Rank {summary?.latestResult?.classRank || 1} of {summary?.latestResult?.totalStudentsInClass || 26}
                      </span>
                    </div>

                    <div className="p-3.5 rounded-xl bg-slate-950/60 border border-white/5">
                      <span className="text-[11px] text-slate-400 block">Current Grade Standing</span>
                      <span className="text-base font-bold text-indigo-400 mt-0.5 block">
                        Grade {summary?.latestResult?.overallGrade || 'A+'} ({summary?.latestResult?.overallPercentage || 92.0}%)
                      </span>
                    </div>

                    <div className="p-3.5 rounded-xl bg-slate-950/60 border border-white/5">
                      <span className="text-[11px] text-slate-400 block">Cumulative GPA</span>
                      <span className="text-base font-bold text-amber-300 mt-0.5 block">
                        {summary?.latestResult?.gpa || 3.93} / 4.00
                      </span>
                    </div>
                  </div>
                </div>

                {/* Coursework & Homework Status */}
                <div className="p-6 rounded-2xl bg-slate-900/80 border border-white/10 backdrop-blur-xl space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-bold text-white">Coursework &amp; Activity Overview</h3>
                    <Badge variant="neutral" size="sm">
                      Real-time Sync
                    </Badge>
                  </div>

                  <div className="space-y-3">
                    {summary?.homework?.nextDueItem && (
                      <div className="p-3.5 rounded-xl bg-indigo-950/40 border border-indigo-500/20 flex items-center justify-between gap-3">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-lg bg-indigo-500/20 text-indigo-400 flex items-center justify-center font-bold text-xs">
                            HW
                          </div>
                          <div>
                            <h4 className="text-xs font-bold text-white">
                              {summary.homework.nextDueItem.title}
                            </h4>
                            <p className="text-[11px] text-slate-400">
                              {summary.homework.nextDueItem.subjectName}
                            </p>
                          </div>
                        </div>
                        <span className="text-[11px] font-semibold text-amber-300 bg-amber-500/10 px-2.5 py-1 rounded-lg border border-amber-500/20 shrink-0">
                          Due {summary.homework.nextDueItem.dueDate}
                        </span>
                      </div>
                    )}

                    {summary?.assignments?.nextDueItem && (
                      <div className="p-3.5 rounded-xl bg-violet-950/40 border border-violet-500/20 flex items-center justify-between gap-3">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-lg bg-violet-500/20 text-violet-400 flex items-center justify-center font-bold text-xs">
                            ASG
                          </div>
                          <div>
                            <h4 className="text-xs font-bold text-white">
                              {summary.assignments.nextDueItem.title}
                            </h4>
                            <p className="text-[11px] text-slate-400">
                              {summary.assignments.nextDueItem.subjectName}
                            </p>
                          </div>
                        </div>
                        <span className="text-[11px] font-semibold text-violet-300 bg-violet-500/10 px-2.5 py-1 rounded-lg border border-violet-500/20 shrink-0">
                          Due {summary.assignments.nextDueItem.dueDate}
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Right 1 Col: Chronological Academic Activity Feed */}
              <div className="space-y-4">
                <div className="p-6 rounded-2xl bg-slate-900/80 border border-white/10 backdrop-blur-xl space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-bold text-white">Academic Activity Trail</h3>
                    <Clock className="w-4 h-4 text-slate-400" />
                  </div>

                  {(summary?.recentActivities?.length || 0) === 0 ? (
                    <p className="text-xs text-slate-500 py-4 text-center">
                      No recent activities logged for this scholar.
                    </p>
                  ) : (
                    <div className="space-y-3">
                      {(summary.recentActivities || []).map((act) => (
                        <div
                          key={act.id}
                          className="p-3 rounded-xl bg-slate-950/50 border border-white/5 space-y-1 text-xs"
                        >
                          <div className="flex items-center justify-between gap-2">
                            <span className="font-bold text-slate-200 truncate">
                              {act.title}
                            </span>
                            {act.badgeText && (
                              <span className="text-[10px] font-semibold text-indigo-400 bg-indigo-500/10 px-1.5 py-0.5 rounded border border-indigo-500/20 shrink-0">
                                {act.badgeText}
                              </span>
                            )}
                          </div>
                          <p className="text-[11px] text-slate-400 line-clamp-2">
                            {act.description}
                          </p>
                          <span className="text-[10px] text-slate-500 block pt-0.5">
                            {new Date(act.date).toLocaleDateString(undefined, {
                              month: 'short',
                              day: 'numeric',
                              year: 'numeric'
                            })}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
};
