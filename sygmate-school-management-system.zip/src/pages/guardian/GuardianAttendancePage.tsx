import React, { useState, useEffect } from 'react';
import {
  Calendar as CalendarIcon,
  CheckCircle2,
  XCircle,
  Clock,
  ShieldCheck,
  AlertTriangle,
  FileText,
  Plus,
  Filter,
  Search,
  ChevronLeft,
  ChevronRight,
  Info,
  Paperclip,
  Trash2,
  RefreshCw,
  ExternalLink,
  GraduationCap,
  Sparkles,
  ArrowRight,
  Check,
  X,
  AlertCircle,
  UserCheck,
  CalendarDays,
  Send,
  Building,
  Layers,
  UploadCloud,
  FileCheck
} from 'lucide-react';
import { api } from '../../services/api.js';
import {
  GuardianChildSummary,
  GuardianChildAttendanceOverviewData,
  GuardianChildAttendanceDay,
  StudentLeaveApplication,
  AttendanceRecord,
  AttendanceStatus,
  LeaveStatus
} from '../../types/index.js';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner.js';
import { Badge } from '../../components/ui/Badge.js';
import { Button } from '../../components/ui/Button.js';
import { Modal } from '../../components/ui/Modal.js';
import { Input } from '../../components/ui/Input.js';

interface GuardianAttendancePageProps {
  onNavigate?: (view: string) => void;
  initialStudentId?: string;
  initialTab?: 'calendar' | 'summary' | 'records' | 'leave-status';
  activeTab?: 'calendar' | 'summary' | 'records' | 'leave-status';
  onTabChange?: (tab: 'calendar' | 'summary' | 'records' | 'leave-status') => void;
  hideTabBar?: boolean;
}

export const GuardianAttendancePage: React.FC<GuardianAttendancePageProps> = ({
  onNavigate,
  initialStudentId,
  initialTab = 'calendar',
  activeTab: propActiveTab,
  onTabChange,
  hideTabBar = true
}) => {
  // All linked children for this guardian
  const [children, setChildren] = useState<GuardianChildSummary[]>([]);
  const [selectedChildId, setSelectedChildId] = useState<string | null>(initialStudentId || null);

  // Selected child's attendance & leave data
  const [attendanceData, setAttendanceData] = useState<GuardianChildAttendanceOverviewData | null>(null);
  const [isLoadingChildren, setIsLoadingChildren] = useState<boolean>(true);
  const [isLoadingAttendance, setIsLoadingAttendance] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [authError, setAuthError] = useState<string | null>(null);

  // Month & Session Filters
  const [currentMonth, setCurrentMonth] = useState<string>('2026-08');
  const [selectedSessionId, setSelectedSessionId] = useState<string>('ALL');
  const [startDateFilter, setStartDateFilter] = useState<string>('');
  const [endDateFilter, setEndDateFilter] = useState<string>('');

  // Active View Tab
  const [activeTab, setActiveTabState] = useState<'calendar' | 'summary' | 'records' | 'leave-status'>(propActiveTab || initialTab);

  useEffect(() => {
    if (propActiveTab) {
      setActiveTabState(propActiveTab);
    } else if (initialTab) {
      setActiveTabState(initialTab);
    }
  }, [propActiveTab, initialTab]);

  const setActiveTab = (tab: 'calendar' | 'summary' | 'records' | 'leave-status') => {
    setActiveTabState(tab);
    if (onTabChange) {
      onTabChange(tab);
    }
  };

  // Day Details Modal
  const [selectedDay, setSelectedDay] = useState<GuardianChildAttendanceDay | null>(null);

  // Leave Application Form Modal
  const [isLeaveModalOpen, setIsLeaveModalOpen] = useState<boolean>(false);
  const [leaveSubmitting, setLeaveSubmitting] = useState<boolean>(false);
  const [leaveFormError, setLeaveFormError] = useState<string | null>(null);
  const [leaveSuccessMessage, setLeaveSuccessMessage] = useState<string | null>(null);
  const [leaveDate, setLeaveDate] = useState<string>('');
  const [leaveEndDate, setLeaveEndDate] = useState<string>('');
  const [leaveReason, setLeaveReason] = useState<string>('Medical / Illness');
  const [leaveDescription, setLeaveDescription] = useState<string>('');
  const [attachmentUrl, setAttachmentUrl] = useState<string>('');
  const [attachmentName, setAttachmentName] = useState<string>('');
  const [guardianConfirmed, setGuardianConfirmed] = useState<boolean>(false);

  // Leave Status Filter
  const [leaveFilterStatus, setLeaveFilterStatus] = useState<string>('ALL');
  const [selectedLeaveDetail, setSelectedLeaveDetail] = useState<StudentLeaveApplication | null>(null);
  const [cancellingLeaveId, setCancellingLeaveId] = useState<string | null>(null);

  // Records Table Filter & Search
  const [recordSearch, setRecordSearch] = useState<string>('');
  const [recordStatusFilter, setRecordStatusFilter] = useState<string>('ALL');

  // Fetch all children linked to this guardian
  const fetchChildren = async () => {
    setIsLoadingChildren(true);
    setError(null);
    try {
      const res = await api.guardian.getChildren();
      const childrenList = Array.isArray(res?.data) ? res.data : Array.isArray(res) ? res : [];
      if (res?.success) {
        setChildren(childrenList);
        if (childrenList.length > 0) {
          const currentValid = selectedChildId && childrenList.some((c: any) => c?.id === selectedChildId);
          const activeId = currentValid ? selectedChildId! : (childrenList?.[0]?.id || null);
          setSelectedChildId(activeId);
        }
      } else {
        setError(typeof res.error === 'string' ? res.error : 'Failed to load verified scholar records.');
      }
    } catch (err: any) {
      setError(err?.message || 'Network error occurred while fetching children.');
    } finally {
      setIsLoadingChildren(false);
    }
  };

  // Fetch attendance records & metrics for the selected child
  const fetchChildAttendance = async (studentId: string) => {
    setIsLoadingAttendance(true);
    setAuthError(null);
    try {
      const res = await api.guardian.getChildAttendance(studentId, {
        month: currentMonth,
        academicSessionId: selectedSessionId !== 'ALL' ? selectedSessionId : undefined,
        startDate: startDateFilter || undefined,
        endDate: endDateFilter || undefined
      });

      if (res.success && res.data) {
        setAttendanceData(res.data);
      } else {
        if (res.error && (res.error.includes('Access denied') || res.error.includes('authorized'))) {
          setAuthError(typeof res.error === 'string' ? res.error : 'Access denied to this student record.');
        } else {
          setError(typeof res.error === 'string' ? res.error : 'Unable to load attendance records.');
        }
      }
    } catch (err: any) {
      setError(err?.message || 'Failed to connect to school attendance database.');
    } finally {
      setIsLoadingAttendance(false);
    }
  };

  useEffect(() => {
    fetchChildren();
  }, []);

  useEffect(() => {
    if (selectedChildId) {
      fetchChildAttendance(selectedChildId);
    }
  }, [selectedChildId, currentMonth, selectedSessionId, startDateFilter, endDateFilter]);

  const handleChildSelect = (childId: string) => {
    if (childId !== selectedChildId) {
      setSelectedChildId(childId);
      // Reset day selection and modals
      setSelectedDay(null);
      setSelectedLeaveDetail(null);
    }
  };

  const handlePrevMonth = () => {
    const [yearStr, monthStr] = currentMonth.split('-');
    let year = parseInt(yearStr, 10);
    let month = parseInt(monthStr, 10) - 1;
    if (month < 1) {
      month = 12;
      year -= 1;
    }
    setCurrentMonth(`${year}-${String(month).padStart(2, '0')}`);
  };

  const handleNextMonth = () => {
    const [yearStr, monthStr] = currentMonth.split('-');
    let year = parseInt(yearStr, 10);
    let month = parseInt(monthStr, 10) + 1;
    if (month > 12) {
      month = 1;
      year += 1;
    }
    setCurrentMonth(`${year}-${String(month).padStart(2, '0')}`);
  };

  const calculatedLeaveDays = React.useMemo(() => {
    if (!leaveDate) return 0;
    if (!leaveEndDate || leaveEndDate === leaveDate) return 1;
    const start = new Date(leaveDate).getTime();
    const end = new Date(leaveEndDate).getTime();
    if (end < start) return 0;
    return Math.max(1, Math.round((end - start) / (1000 * 60 * 60 * 24)) + 1);
  }, [leaveDate, leaveEndDate]);

  const openLeaveModal = (presetDate?: string) => {
    setLeaveDate(presetDate || new Date().toISOString().split('T')[0]);
    setLeaveEndDate('');
    setLeaveReason('Medical / Illness');
    setLeaveDescription('');
    setAttachmentUrl('');
    setAttachmentName('');
    setGuardianConfirmed(false);
    setLeaveFormError(null);
    setLeaveSuccessMessage(null);
    setIsLeaveModalOpen(true);
  };

  const handleSubmitLeave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedChildId) return;
    setLeaveFormError(null);

    if (!leaveDate) {
      setLeaveFormError('Please select a leave start date.');
      return;
    }
    if (leaveEndDate && leaveEndDate < leaveDate) {
      setLeaveFormError('End date cannot be earlier than start date.');
      return;
    }
    if (!leaveReason.trim()) {
      setLeaveFormError('Please specify the reason for absence.');
      return;
    }
    if (!leaveDescription.trim() || leaveDescription.trim().length < 10) {
      setLeaveFormError('Please provide a detailed description (at least 10 characters).');
      return;
    }
    if (!guardianConfirmed) {
      setLeaveFormError('Please confirm your authorization as the parent/guardian before submitting.');
      return;
    }

    try {
      setLeaveSubmitting(true);
      const res = await api.guardian.submitChildLeaveApplication(selectedChildId, {
        leaveDate,
        endDate: leaveEndDate || undefined,
        reason: leaveReason,
        description: leaveDescription,
        attachmentUrl: attachmentUrl || undefined,
        attachmentName: attachmentName || (attachmentUrl ? 'Absence_Verification_Doc.pdf' : undefined)
      });

      if (res.success && res.data) {
        setLeaveSuccessMessage(
          `Leave request for ${attendanceData?.student.name || 'your child'} on ${leaveDate} submitted successfully! The school administration and faculty will review it.`
        );
        // Refresh attendance data
        fetchChildAttendance(selectedChildId);
        setTimeout(() => {
          setIsLeaveModalOpen(false);
          setLeaveSuccessMessage(null);
          setActiveTab('leave-status');
        }, 2000);
      } else {
        setLeaveFormError(typeof res.error === 'string' ? res.error : 'Failed to submit leave application.');
      }
    } catch (err: any) {
      setLeaveFormError(err?.message || 'An error occurred while submitting leave request.');
    } finally {
      setLeaveSubmitting(false);
    }
  };

  const handleCancelLeave = async (leaveId: string) => {
    if (!selectedChildId) return;
    try {
      setCancellingLeaveId(leaveId);
      const res = await api.guardian.cancelChildLeaveApplication(selectedChildId, leaveId);
      if (res.success) {
        if (selectedLeaveDetail?.id === leaveId) {
          setSelectedLeaveDetail(null);
        }
        fetchChildAttendance(selectedChildId);
      } else {
        alert(res.error || 'Failed to cancel leave application.');
      }
    } catch (err: any) {
      alert(err.message || 'An error occurred.');
    } finally {
      setCancellingLeaveId(null);
    }
  };

  // Helper formatting month title
  const formatMonthTitle = (monthStr: string) => {
    const [year, month] = monthStr.split('-');
    const date = new Date(parseInt(year, 10), parseInt(month, 10) - 1, 1);
    return date.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
  };

  // Filtered records for table view
  const filteredRecords = (attendanceData?.records || []).filter((rec) => {
    if (recordStatusFilter !== 'ALL' && rec.status !== recordStatusFilter) return false;
    if (recordSearch.trim()) {
      const q = recordSearch.trim().toLowerCase();
      return (
        (rec.date || '').toLowerCase().includes(q) ||
        (rec.subjectName && rec.subjectName.toLowerCase().includes(q)) ||
        (rec.recordedByTeacherName && rec.recordedByTeacherName.toLowerCase().includes(q)) ||
        (rec.remarks && rec.remarks.toLowerCase().includes(q))
      );
    }
    return true;
  });

  // Filtered leave applications
  const filteredLeaves = (attendanceData?.leaveApplications || []).filter((leave) => {
    if (leaveFilterStatus !== 'ALL' && leave.status !== leaveFilterStatus) return false;
    return true;
  });

  if (isLoadingChildren) {
    return (
      <div className="p-12 flex flex-col items-center justify-center min-h-[420px] text-center space-y-4">
        <LoadingSpinner size="lg" message="Loading verified family academic & attendance profiles..." />
      </div>
    );
  }

  if (error && (children?.length || 0) === 0) {
    return (
      <div className="p-8 max-w-xl mx-auto text-center space-y-4">
        <div className="w-14 h-14 rounded-2xl bg-rose-500/20 border border-rose-500/30 text-rose-400 flex items-center justify-center mx-auto">
          <AlertCircle className="w-7 h-7" />
        </div>
        <h2 className="text-xl font-bold text-white">Unable to Load Family Profile</h2>
        <p className="text-sm text-slate-400">{error}</p>
        <Button onClick={fetchChildren} variant="outline" className="gap-2 mx-auto">
          <RefreshCw className="w-4 h-4" />
          Retry Connection
        </Button>
      </div>
    );
  }

  const selectedChild = (children || []).find((c) => c.id === selectedChildId) || children?.[0];
  const summary = attendanceData?.summary;
  const attendanceRate = summary?.attendancePercentage ?? 0;

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-8 animate-fadeIn">
      {/* ------------------------------------------------------------- */}
      {/* HEADER SECTION & CHILD SWITCHER */}
      {/* ------------------------------------------------------------- */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/10 pb-6">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-indigo-400 mb-1">
            <ShieldCheck className="w-4 h-4" />
            <span>Parent / Guardian Portal • Attendance & Leave Management</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center gap-3">
            <span>Attendance & Leave Management</span>
          </h1>
          <p className="text-sm text-slate-400 mt-1 max-w-2xl">
            Monitor daily attendance logs, view monthly calendar records, inspect faculty remarks, and submit verified leave requests on behalf of your children.
          </p>
        </div>

        <div className="flex items-center gap-3 flex-wrap">
          <Button
            id="btn-apply-leave-main"
            onClick={() => openLeaveModal()}
            className="bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-600/30 flex items-center gap-2 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Submit Leave Request</span>
          </Button>

          {onNavigate && (
            <Button
              variant="outline"
              onClick={() => onNavigate('guardian-academic-overview')}
              className="gap-1.5 text-xs text-slate-300 hover:text-white border-white/10"
            >
              <span>Academic Overview</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Button>
          )}
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* 1. CHILD SELECTOR CAROUSEL / SWITCHER */}
      {/* ------------------------------------------------------------- */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <GraduationCap className="w-4 h-4 text-indigo-400" />
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-300">
              Select Linked Child / Scholar ({children?.length || 0})
            </h2>
          </div>
          <span className="text-[11px] text-slate-400 italic">
            Switch child to instantly sync attendance logs
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {(children || []).map((child) => {
            const isSelected = child.id === selectedChildId;
            return (
              <button
                key={child.id}
                id={`child-selector-btn-${child.id}`}
                onClick={() => handleChildSelect(child.id)}
                className={`flex items-center gap-3.5 p-3.5 rounded-2xl border text-left transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-blue-50/70 border-blue-600 shadow-2xs ring-1 ring-blue-600/30'
                    : 'bg-white border-slate-200 hover:bg-slate-50 text-slate-800'
                }`}
              >
                <div className="relative">
                  {child.photoUrl ? (
                    <img
                      src={child.photoUrl}
                      alt={child.name}
                      className="w-12 h-12 rounded-xl object-cover border border-slate-200 shadow-2xs"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <div className="w-12 h-12 rounded-xl bg-blue-600 text-white flex items-center justify-center font-bold text-lg shadow-xs border border-blue-700">
                      {child.name.charAt(0)}
                    </div>
                  )}
                  {isSelected && (
                    <span className="absolute -top-1 -right-1 w-4 h-4 bg-emerald-600 border-2 border-white rounded-full flex items-center justify-center">
                      <Check className="w-2.5 h-2.5 text-white stroke-[3]" />
                    </span>
                  )}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-1">
                    <h3 className={`text-sm font-bold truncate ${isSelected ? 'text-slate-900' : 'text-slate-800'}`}>{child.name}</h3>
                    <Badge
                      variant={isSelected ? 'info' : 'secondary'}
                      className="text-[10px] px-1.5 py-0 font-mono tracking-tight shrink-0"
                    >
                      {child.className} - {child.sectionName}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5">
                    <span>ID: {child.admissionNumber}</span>
                    <span>•</span>
                    <span>Roll #{child.rollNumber}</span>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Security Alert if cross-access is blocked */}
      {authError && (
        <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 flex items-start gap-3 text-rose-300 text-sm">
          <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
          <div className="flex-1">
            <h4 className="font-bold text-white">Access Verification Error</h4>
            <p className="text-xs text-rose-300/90 mt-0.5">{authError}</p>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* 2. ATTENDANCE SUMMARY METRICS CARDS */}
      {/* ------------------------------------------------------------- */}
      {summary && (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
          {/* Total Days */}
          <div className="p-4 rounded-2xl bg-slate-900/60 border border-white/10 backdrop-blur-md relative overflow-hidden flex flex-col justify-between">
            <div className="flex items-center justify-between text-slate-400 text-xs font-semibold">
              <span>Total School Days</span>
              <CalendarDays className="w-4 h-4 text-slate-300" />
            </div>
            <div className="mt-3">
              <span className="text-2xl sm:text-3xl font-extrabold text-white font-mono">
                {summary.totalSchoolDays}
              </span>
              <p className="text-[11px] text-slate-400 mt-0.5">Recorded sessions</p>
            </div>
          </div>

          {/* Present */}
          <div className="p-4 rounded-2xl bg-emerald-950/20 border border-emerald-500/20 backdrop-blur-md relative overflow-hidden flex flex-col justify-between">
            <div className="flex items-center justify-between text-emerald-400 text-xs font-semibold">
              <span>Present Days</span>
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="mt-3">
              <span className="text-2xl sm:text-3xl font-extrabold text-emerald-400 font-mono">
                {summary.presentCount}
              </span>
              <p className="text-[11px] text-emerald-400/80 mt-0.5">Attended classes</p>
            </div>
          </div>

          {/* Absent */}
          <div className="p-4 rounded-2xl bg-rose-950/20 border border-rose-500/20 backdrop-blur-md relative overflow-hidden flex flex-col justify-between">
            <div className="flex items-center justify-between text-rose-400 text-xs font-semibold">
              <span>Absent Days</span>
              <XCircle className="w-4 h-4 text-rose-400" />
            </div>
            <div className="mt-3">
              <span className="text-2xl sm:text-3xl font-extrabold text-rose-400 font-mono">
                {summary.absentCount}
              </span>
              <p className="text-[11px] text-rose-400/80 mt-0.5">Unexcused misses</p>
            </div>
          </div>

          {/* Late */}
          <div className="p-4 rounded-2xl bg-amber-950/20 border border-amber-500/20 backdrop-blur-md relative overflow-hidden flex flex-col justify-between">
            <div className="flex items-center justify-between text-amber-400 text-xs font-semibold">
              <span>Late Arrivals</span>
              <Clock className="w-4 h-4 text-amber-400" />
            </div>
            <div className="mt-3">
              <span className="text-2xl sm:text-3xl font-extrabold text-amber-400 font-mono">
                {summary.lateCount}
              </span>
              <p className="text-[11px] text-amber-400/80 mt-0.5">Tardy records</p>
            </div>
          </div>

          {/* Leave / Excused */}
          <div className="p-4 rounded-2xl bg-indigo-950/20 border border-indigo-500/20 backdrop-blur-md relative overflow-hidden flex flex-col justify-between">
            <div className="flex items-center justify-between text-indigo-400 text-xs font-semibold">
              <span>Approved Leave</span>
              <FileCheck className="w-4 h-4 text-indigo-400" />
            </div>
            <div className="mt-3">
              <span className="text-2xl sm:text-3xl font-extrabold text-indigo-400 font-mono">
                {summary.leaveCount}
              </span>
              <p className="text-[11px] text-indigo-400/80 mt-0.5">Excused absences</p>
            </div>
          </div>

          {/* Overall Percentage */}
          <div className="p-4 rounded-2xl bg-slate-900/80 border border-indigo-500/30 backdrop-blur-md relative overflow-hidden flex flex-col justify-between shadow-lg shadow-indigo-950/30">
            <div className="flex items-center justify-between text-indigo-300 text-xs font-semibold">
              <span>Attendance Rate</span>
              <Sparkles className="w-4 h-4 text-indigo-400" />
            </div>
            <div className="mt-2">
              <div className="flex items-baseline gap-1">
                <span
                  className={`text-2xl sm:text-3xl font-black font-mono ${
                    attendanceRate >= 85
                      ? 'text-emerald-400'
                      : attendanceRate >= 75
                      ? 'text-amber-400'
                      : 'text-rose-400'
                  }`}
                >
                  {attendanceRate}%
                </span>
              </div>
              {/* Mini progress bar */}
              <div className="w-full bg-slate-800 rounded-full h-1.5 mt-1.5 overflow-hidden">
                <div
                  className={`h-full rounded-full ${
                    attendanceRate >= 85
                      ? 'bg-emerald-500'
                      : attendanceRate >= 75
                      ? 'bg-amber-500'
                      : 'bg-rose-500'
                  }`}
                  style={{ width: `${Math.min(100, attendanceRate)}%` }}
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* NAVIGATION TABS & FILTERS BAR */}
      {/* ------------------------------------------------------------- */}
      <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 bg-slate-900/40 p-2.5 rounded-2xl border border-white/10">
        {/* Navigation Tabs */}
        {!hideTabBar && (
          <div className="flex items-center gap-1.5 p-1 bg-slate-950/60 rounded-xl border border-white/5 overflow-x-auto w-full lg:w-auto">
            <button
              id="tab-btn-calendar"
              onClick={() => setActiveTab('calendar')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                activeTab === 'calendar'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <CalendarIcon className="w-3.5 h-3.5" />
              <span>Attendance Calendar</span>
            </button>

            <button
              id="tab-btn-records"
              onClick={() => setActiveTab('records')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                activeTab === 'records'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Detailed Logs ({attendanceData?.records?.length || 0})</span>
            </button>

            <button
              id="tab-btn-leaves"
              onClick={() => setActiveTab('leave-status')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                activeTab === 'leave-status'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <Send className="w-3.5 h-3.5" />
              <span>Leave Requests ({attendanceData?.leaveApplications?.length || 0})</span>
            </button>
          </div>
        )}

        {/* Global Month / Session Filters */}
        <div className="flex items-center gap-2.5 flex-wrap w-full lg:w-auto justify-end">
          {/* Academic Session Filter */}
          {attendanceData?.availableSessions && (
            <div className="flex items-center gap-1.5 bg-slate-950/80 px-2.5 py-1.5 rounded-xl border border-white/10 text-xs">
              <Layers className="w-3.5 h-3.5 text-slate-400" />
              <select
                id="select-academic-session-filter"
                value={selectedSessionId}
                onChange={(e) => setSelectedSessionId(e.target.value)}
                className="bg-transparent text-slate-200 text-xs focus:outline-none cursor-pointer"
              >
                <option value="ALL" className="bg-slate-900 text-white">All Sessions</option>
                {(attendanceData.availableSessions || []).map((sess) => (
                  <option key={sess.id} value={sess.id} className="bg-slate-900 text-white">
                    {sess.name} {sess.isActive ? '(Current)' : ''}
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Month Stepper Controller */}
          <div className="flex items-center gap-1 bg-slate-950/80 p-1 rounded-xl border border-white/10">
            <button
              id="btn-prev-month"
              onClick={handlePrevMonth}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
              title="Previous Month"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="text-xs font-bold text-white px-2 min-w-[110px] text-center">
              {formatMonthTitle(currentMonth)}
            </span>
            <button
              id="btn-next-month"
              onClick={handleNextMonth}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
              title="Next Month"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* LOADING STATE FOR ATTENDANCE */}
      {/* ------------------------------------------------------------- */}
      {isLoadingAttendance && (
        <div className="p-12 flex flex-col items-center justify-center min-h-[300px] text-center space-y-4">
          <LoadingSpinner size="md" message="Refreshing child attendance records & calendar..." />
        </div>
      )}

      {!isLoadingAttendance && attendanceData && (
        <>
          {/* ========================================================= */}
          {/* TAB 1: CALENDAR VIEW */}
          {/* ========================================================= */}
          {activeTab === 'calendar' && (
            <div className="space-y-6">
              {/* Calendar Card */}
              <div className="p-6 rounded-3xl bg-slate-900/60 border border-white/10 backdrop-blur-xl shadow-2xl space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-4">
                  <div>
                    <h3 className="text-lg font-bold text-white flex items-center gap-2">
                      <CalendarIcon className="w-5 h-5 text-indigo-400" />
                      <span>{formatMonthTitle(currentMonth)} — Daily Attendance Matrix</span>
                    </h3>
                    <p className="text-xs text-slate-400 mt-0.5">
                      Click any date card to view class session remarks, faculty member details, or file a leave request.
                    </p>
                  </div>

                  {/* Status Legend */}
                  <div className="flex items-center gap-3 flex-wrap text-xs">
                    <div className="flex items-center gap-1.5">
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                      <span className="text-slate-300">Present</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className="w-2.5 h-2.5 rounded-full bg-rose-500" />
                      <span className="text-slate-300">Absent</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                      <span className="text-slate-300">Late</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className="w-2.5 h-2.5 rounded-full bg-indigo-500" />
                      <span className="text-slate-300">Leave/Excused</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className="w-2.5 h-2.5 rounded-full bg-slate-600" />
                      <span className="text-slate-400">Weekend</span>
                    </div>
                  </div>
                </div>

                {/* Day of Week Headers */}
                <div className="grid grid-cols-7 gap-2 text-center">
                  {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((d, i) => (
                    <div
                      key={d}
                      className={`text-xs font-bold uppercase tracking-wider py-1.5 ${
                        i === 0 || i === 6 ? 'text-slate-500' : 'text-slate-300'
                      }`}
                    >
                      {d}
                    </div>
                  ))}
                </div>

                {/* Days Grid */}
                <div className="grid grid-cols-7 gap-2 sm:gap-3">
                  {/* Leading Empty Cells */}
                  {Array.from({ length: (attendanceData?.calendarDays || [])?.[0]?.dayOfWeek || 0 }).map((_, i) => (
                    <div
                      key={`empty-lead-${i}`}
                      className="min-h-[90px] rounded-2xl bg-slate-950/20 border border-transparent opacity-30"
                    />
                  ))}

                  {/* Calendar Days */}
                  {(attendanceData.calendarDays || []).map((day) => {
                    const isSelected = selectedDay?.date === day.date;
                    const hasRecord = !!day.record;
                    const hasLeave = !!day.leaveApplication;

                    let bgStyle = 'bg-slate-950/40 border-white/5 text-slate-400';
                    let badgeBg = 'bg-slate-800 text-slate-300';

                    if (day.status === 'PRESENT') {
                      bgStyle = 'bg-emerald-950/30 border-emerald-500/30 hover:border-emerald-500/60 text-emerald-300';
                      badgeBg = 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30';
                    } else if (day.status === 'ABSENT') {
                      bgStyle = 'bg-rose-950/30 border-rose-500/30 hover:border-rose-500/60 text-rose-300';
                      badgeBg = 'bg-rose-500/20 text-rose-300 border border-rose-500/30';
                    } else if (day.status === 'LATE') {
                      bgStyle = 'bg-amber-950/30 border-amber-500/30 hover:border-amber-500/60 text-amber-300';
                      badgeBg = 'bg-amber-500/20 text-amber-300 border border-amber-500/30';
                    } else if (day.status === 'EXCUSED') {
                      bgStyle = 'bg-indigo-950/30 border-indigo-500/30 hover:border-indigo-500/60 text-indigo-300';
                      badgeBg = 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/30';
                    } else if (day.isWeekend) {
                      bgStyle = 'bg-slate-950/30 border-white/5 opacity-60 text-slate-500';
                      badgeBg = 'bg-slate-900 text-slate-500';
                    }

                    return (
                      <button
                        key={day.date}
                        id={`calendar-day-btn-${day.date}`}
                        onClick={() => setSelectedDay(day)}
                        className={`min-h-[85px] sm:min-h-[96px] p-2.5 rounded-2xl border text-left flex flex-col justify-between transition-all relative cursor-pointer ${bgStyle} ${
                          isSelected ? 'ring-2 ring-indigo-400 scale-[1.02] shadow-xl' : 'hover:scale-[1.01]'
                        } ${day.isToday ? 'ring-1 ring-amber-400/80' : ''}`}
                      >
                        <div className="flex items-center justify-between w-full">
                          <span
                            className={`text-xs sm:text-sm font-black ${
                              day.isToday
                                ? 'w-6 h-6 rounded-full bg-amber-500 text-slate-950 flex items-center justify-center font-black'
                                : 'text-slate-200'
                            }`}
                          >
                            {day.dayOfMonth}
                          </span>

                          {day.status === 'PRESENT' && (
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                          )}
                          {day.status === 'ABSENT' && (
                            <XCircle className="w-3.5 h-3.5 text-rose-400" />
                          )}
                          {day.status === 'LATE' && (
                            <Clock className="w-3.5 h-3.5 text-amber-400" />
                          )}
                          {day.status === 'EXCUSED' && (
                            <FileCheck className="w-3.5 h-3.5 text-indigo-400" />
                          )}
                        </div>

                        <div className="mt-1 space-y-1 w-full">
                          <span
                            className={`inline-block text-[10px] font-bold px-1.5 py-0.5 rounded-md truncate max-w-full ${badgeBg}`}
                          >
                            {day.statusLabel}
                          </span>

                          {hasLeave && (
                            <span className="block text-[9px] text-indigo-300 font-semibold truncate">
                              • Leave: {day.leaveApplication?.reason}
                            </span>
                          )}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* ========================================================= */}
          {/* TAB 2: DETAILED RECORDS LOGS TABLE */}
          {/* ========================================================= */}
          {activeTab === 'records' && (
            <div className="p-6 rounded-3xl bg-slate-900/60 border border-white/10 backdrop-blur-xl shadow-2xl space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-4">
                <div>
                  <h3 className="text-lg font-bold text-white flex items-center gap-2">
                    <FileText className="w-5 h-5 text-indigo-400" />
                    <span>Attendance Records & Faculty Logs ({filteredRecords?.length || 0})</span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Official attendance marks logged by teaching staff and academic coordinators.
                  </p>
                </div>

                {/* Filter & Search */}
                <div className="flex items-center gap-2 flex-wrap">
                  <div className="relative">
                    <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      placeholder="Search date, remarks..."
                      value={recordSearch}
                      onChange={(e) => setRecordSearch(e.target.value)}
                      className="bg-slate-950/80 border border-white/10 text-xs text-white pl-8 pr-3 py-1.5 rounded-xl focus:outline-none focus:border-indigo-500 w-44"
                    />
                  </div>

                  <select
                    value={recordStatusFilter}
                    onChange={(e) => setRecordStatusFilter(e.target.value)}
                    className="bg-slate-950/80 border border-white/10 text-xs text-white px-3 py-1.5 rounded-xl focus:outline-none focus:border-indigo-500 cursor-pointer"
                  >
                    <option value="ALL">All Statuses</option>
                    <option value="PRESENT">Present</option>
                    <option value="ABSENT">Absent</option>
                    <option value="LATE">Late</option>
                    <option value="EXCUSED">Excused / Leave</option>
                  </select>
                </div>
              </div>

              {(filteredRecords?.length || 0) === 0 ? (
                <div className="py-12 text-center space-y-3">
                  <FileText className="w-10 h-10 text-slate-600 mx-auto" />
                  <p className="text-sm font-semibold text-slate-300">No attendance records found</p>
                  <p className="text-xs text-slate-500">
                    No matching attendance logs found for the selected month or filter criteria.
                  </p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs text-slate-300">
                    <thead className="bg-slate-950/60 uppercase text-[11px] font-bold text-slate-400 tracking-wider border-b border-white/10">
                      <tr>
                        <th className="py-3 px-4">Date</th>
                        <th className="py-3 px-4">Class / Section</th>
                        <th className="py-3 px-4">Subject / Period</th>
                        <th className="py-3 px-4">Status</th>
                        <th className="py-3 px-4">Remarks</th>
                        <th className="py-3 px-4">Recorded By</th>
                        <th className="py-3 px-4 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                      {(filteredRecords || []).map((record) => (
                        <tr
                          key={record.id}
                          className="hover:bg-white/[0.02] transition-colors"
                        >
                          <td className="py-3 px-4 font-mono font-bold text-white whitespace-nowrap">
                            {record.date}
                          </td>
                          <td className="py-3 px-4 whitespace-nowrap">
                            <span className="font-semibold text-slate-200">
                              {attendanceData.student.className} - {attendanceData.student.sectionName}
                            </span>
                          </td>
                          <td className="py-3 px-4 whitespace-nowrap">
                            {record.subjectName || 'Homeroom / Daily Session'}
                          </td>
                          <td className="py-3 px-4 whitespace-nowrap">
                            <Badge
                              variant={
                                record.status === 'PRESENT'
                                  ? 'success'
                                  : record.status === 'ABSENT'
                                  ? 'danger'
                                  : record.status === 'LATE'
                                  ? 'warning'
                                  : 'info'
                              }
                              className="font-bold uppercase tracking-wider text-[10px]"
                            >
                              {record.status}
                            </Badge>
                          </td>
                          <td className="py-3 px-4 max-w-xs truncate text-slate-400 italic">
                            {record.remarks || 'No remarks recorded.'}
                          </td>
                          <td className="py-3 px-4 whitespace-nowrap text-slate-300">
                            {record.recordedByTeacherName || 'Academic Staff'}
                          </td>
                          <td className="py-3 px-4 text-right whitespace-nowrap">
                            {record.status === 'ABSENT' && (
                              <button
                                onClick={() => openLeaveModal(record.date)}
                                className="text-indigo-400 hover:text-indigo-300 font-bold hover:underline cursor-pointer"
                              >
                                Request Leave
                              </button>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* ========================================================= */}
          {/* TAB 3: LEAVE REQUESTS & STATUS */}
          {/* ========================================================= */}
          {activeTab === 'leave-status' && (
            <div className="p-6 rounded-3xl bg-slate-900/60 border border-white/10 backdrop-blur-xl shadow-2xl space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-4">
                <div>
                  <h3 className="text-lg font-bold text-white flex items-center gap-2">
                    <Send className="w-5 h-5 text-indigo-400" />
                    <span>Parent-Submitted Leave Applications ({filteredLeaves?.length || 0})</span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Track the review status of leaves submitted on behalf of {attendanceData.student.name}.
                  </p>
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  <select
                    id="select-leave-status-filter"
                    value={leaveFilterStatus}
                    onChange={(e) => setLeaveFilterStatus(e.target.value)}
                    className="bg-slate-950/80 border border-white/10 text-xs text-white px-3 py-1.5 rounded-xl focus:outline-none focus:border-indigo-500 cursor-pointer"
                  >
                    <option value="ALL">All Application Statuses</option>
                    <option value="PENDING">Pending Review</option>
                    <option value="APPROVED">Approved</option>
                    <option value="REJECTED">Rejected</option>
                  </select>

                  <Button
                    onClick={() => openLeaveModal()}
                    className="bg-indigo-600 hover:bg-indigo-500 text-white text-xs gap-1.5"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>New Leave</span>
                  </Button>
                </div>
              </div>

              {(filteredLeaves?.length || 0) === 0 ? (
                <div className="py-14 text-center space-y-3">
                  <FileText className="w-12 h-12 text-slate-600 mx-auto" />
                  <h4 className="text-sm font-bold text-slate-300">No Leave Applications Found</h4>
                  <p className="text-xs text-slate-500 max-w-md mx-auto">
                    You have not submitted any leave requests matching the selected filter for {attendanceData.student.name}.
                  </p>
                  <Button
                    onClick={() => openLeaveModal()}
                    variant="outline"
                    className="gap-2 text-xs text-indigo-400 border-indigo-500/30 hover:bg-indigo-500/10 mx-auto"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Apply for Absence / Leave</span>
                  </Button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {(filteredLeaves || []).map((leave) => {
                    const isPending = leave.status === 'PENDING';
                    const isApproved = leave.status === 'APPROVED';
                    const isRejected = leave.status === 'REJECTED';

                    return (
                      <div
                        key={leave.id}
                        id={`leave-app-card-${leave.id}`}
                        className={`p-5 rounded-2xl border transition-all space-y-4 ${
                          isApproved
                            ? 'bg-emerald-950/20 border-emerald-500/30'
                            : isRejected
                            ? 'bg-rose-950/20 border-rose-500/30'
                            : 'bg-slate-950/60 border-white/10'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-3">
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="text-sm font-bold text-white">
                                {leave.reason}
                              </span>
                              <Badge
                                variant={isApproved ? 'success' : isRejected ? 'danger' : 'warning'}
                                className="text-[10px] font-mono uppercase tracking-wider"
                              >
                                {leave.status}
                              </Badge>
                            </div>

                            <p className="text-xs text-slate-400 mt-1 flex items-center gap-1.5">
                              <CalendarIcon className="w-3.5 h-3.5 text-slate-400" />
                              <span className="font-semibold text-slate-300">
                                {leave.leaveDate} {leave.endDate ? `to ${leave.endDate}` : '(Single Day)'}
                              </span>
                            </p>
                          </div>

                          {isPending && (
                            <button
                              id={`btn-cancel-leave-${leave.id}`}
                              onClick={() => handleCancelLeave(leave.id)}
                              disabled={cancellingLeaveId === leave.id}
                              className="text-xs text-rose-400 hover:text-rose-300 bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 px-2.5 py-1 rounded-lg transition-colors cursor-pointer flex items-center gap-1"
                              title="Retract pending leave request"
                            >
                              <Trash2 className="w-3 h-3" />
                              <span>{cancellingLeaveId === leave.id ? 'Cancelling...' : 'Retract'}</span>
                            </button>
                          )}
                        </div>

                        {/* Description */}
                        <div className="p-3 rounded-xl bg-slate-900/80 border border-white/5 text-xs text-slate-300 leading-relaxed">
                          <p className="font-semibold text-slate-400 text-[10px] uppercase tracking-wider mb-1">
                            Guardian Note:
                          </p>
                          {leave.description}
                        </div>

                        {/* Metadata Footer */}
                        <div className="flex items-center justify-between text-[11px] text-slate-400 border-t border-white/5 pt-3">
                          <div>
                            <span>Submitted on: {leave.submissionDate || leave.createdAt.substring(0, 10)}</span>
                            {leave.submittedByGuardianName && (
                              <span className="block text-[10px] text-slate-500">
                                By Guardian: {leave.submittedByGuardianName}
                              </span>
                            )}
                          </div>

                          {leave.attachmentUrl && (
                            <a
                              href={leave.attachmentUrl}
                              target="_blank"
                              rel="noreferrer"
                              className="flex items-center gap-1 text-indigo-400 hover:text-indigo-300 hover:underline"
                            >
                              <Paperclip className="w-3.5 h-3.5" />
                              <span>{leave.attachmentName || 'Attachment'}</span>
                            </a>
                          )}
                        </div>

                        {/* Reviewer remarks if available */}
                        {(isApproved || isRejected) && (
                          <div
                            className={`p-3 rounded-xl border text-xs ${
                              isApproved
                                ? 'bg-emerald-950/40 border-emerald-500/30 text-emerald-300'
                                : 'bg-rose-950/40 border-rose-500/30 text-rose-300'
                            }`}
                          >
                            <div className="flex items-center justify-between font-bold">
                              <span>Admin Review Response:</span>
                              {leave.reviewedAt && (
                                <span className="text-[10px] font-normal opacity-80">
                                  {leave.reviewedAt.substring(0, 10)}
                                </span>
                              )}
                            </div>
                            <p className="mt-1 text-slate-300">
                              {leave.adminRemarks || (isApproved ? 'Leave approved and excused in academic records.' : 'Leave request was not approved.')}
                            </p>
                            {leave.reviewedByName && (
                              <p className="text-[10px] opacity-75 mt-1">
                                Reviewed by: {leave.reviewedByName} ({leave.reviewedByRole || 'Administration'})
                              </p>
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}
        </>
      )}

      {/* ------------------------------------------------------------- */}
      {/* DAY DETAILS MODAL / DRAWER */}
      {/* ------------------------------------------------------------- */}
      {selectedDay && (
        <Modal
          isOpen={!!selectedDay}
          onClose={() => setSelectedDay(null)}
          title={`Attendance Details • ${selectedDay.date}`}
          size="md"
        >
          <div className="space-y-5">
            <div className="flex items-center justify-between p-4 rounded-2xl bg-slate-950/70 border border-white/10">
              <div>
                <span className="text-xs text-slate-400">Student Scholar</span>
                <h4 className="text-base font-bold text-white">{attendanceData?.student.name}</h4>
                <p className="text-xs text-slate-400">
                  {attendanceData?.student.className} • Section {attendanceData?.student.sectionName} (Roll #{attendanceData?.student.rollNumber})
                </p>
              </div>
              <Badge
                variant={
                  selectedDay.status === 'PRESENT'
                    ? 'success'
                    : selectedDay.status === 'ABSENT'
                    ? 'danger'
                    : selectedDay.status === 'LATE'
                    ? 'warning'
                    : 'info'
                }
                className="text-xs font-bold uppercase tracking-wider px-3 py-1"
              >
                {selectedDay.statusLabel}
              </Badge>
            </div>

            {/* If record exists */}
            {selectedDay.record && (
              <div className="space-y-3 p-4 rounded-2xl bg-slate-900/60 border border-white/10 text-xs">
                <div className="flex items-center justify-between border-b border-white/5 pb-2">
                  <span className="text-slate-400">Session Subject:</span>
                  <span className="font-semibold text-white">
                    {selectedDay.record.subjectName || 'Homeroom / Class Wide'}
                  </span>
                </div>

                <div className="flex items-center justify-between border-b border-white/5 pb-2">
                  <span className="text-slate-400">Recorded By Faculty:</span>
                  <span className="font-semibold text-white">
                    {selectedDay.record.recordedByTeacherName || 'Academic Faculty'}
                  </span>
                </div>

                <div className="space-y-1 pt-1">
                  <span className="text-slate-400 font-semibold">Teacher Remarks / Notes:</span>
                  <p className="p-3 rounded-xl bg-slate-950/60 text-slate-300 italic border border-white/5">
                    {selectedDay.record.remarks || 'No specific remarks recorded for this session.'}
                  </p>
                </div>
              </div>
            )}

            {/* If leave application linked */}
            {selectedDay.leaveApplication && (
              <div className="p-4 rounded-2xl bg-indigo-950/30 border border-indigo-500/30 text-xs space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-indigo-300">Linked Leave Application:</span>
                  <Badge variant="info">{selectedDay.leaveApplication.status}</Badge>
                </div>
                <p className="text-slate-300">{selectedDay.leaveApplication.description}</p>
              </div>
            )}

            {/* Quick action to file leave if unexcused/absent or future */}
            {(selectedDay.status === 'ABSENT' || selectedDay.status === 'NO_RECORD' || selectedDay.isFuture) && (
              <Button
                onClick={() => {
                  const targetDate = selectedDay.date;
                  setSelectedDay(null);
                  openLeaveModal(targetDate);
                }}
                className="w-full bg-indigo-600 hover:bg-indigo-500 text-white gap-2 justify-center"
              >
                <Plus className="w-4 h-4" />
                <span>Submit Leave for {selectedDay.date}</span>
              </Button>
            )}
          </div>
        </Modal>
      )}

      {/* ------------------------------------------------------------- */}
      {/* SUBMIT LEAVE APPLICATION MODAL */}
      {/* ------------------------------------------------------------- */}
      {isLeaveModalOpen && (
        <Modal
          isOpen={isLeaveModalOpen}
          onClose={() => setIsLeaveModalOpen(false)}
          title="Submit Student Leave Application"
          size="lg"
        >
          <form onSubmit={handleSubmitLeave} className="space-y-5">
            {/* Student Info Banner */}
            <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-bold">
                  {selectedChild?.name.charAt(0)}
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">{selectedChild?.name}</h4>
                  <p className="text-xs text-slate-400">
                    {selectedChild?.className} • Section {selectedChild?.sectionName} (Adm: {selectedChild?.admissionNumber})
                  </p>
                </div>
              </div>
              <Badge variant="info" className="text-[10px]">Verified Scholar</Badge>
            </div>

            {leaveFormError && (
              <div className="p-3 rounded-xl bg-rose-500/20 border border-rose-500/30 text-rose-300 text-xs flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <span>{leaveFormError}</span>
              </div>
            )}

            {leaveSuccessMessage && (
              <div className="p-3 rounded-xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 text-xs flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>{leaveSuccessMessage}</span>
              </div>
            )}

            {/* Dates */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Leave Start Date <span className="text-rose-400">*</span>
                </label>
                <Input
                  type="date"
                  value={leaveDate}
                  onChange={(e) => setLeaveDate(e.target.value)}
                  required
                  className="w-full bg-slate-950 border-white/10 text-white text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  End Date <span className="text-slate-500 font-normal">(Optional for multi-day)</span>
                </label>
                <Input
                  type="date"
                  value={leaveEndDate}
                  onChange={(e) => setLeaveEndDate(e.target.value)}
                  className="w-full bg-slate-950 border-white/10 text-white text-xs"
                />
              </div>
            </div>

            {calculatedLeaveDays > 0 && (
              <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-indigo-950/40 border border-indigo-500/20 text-xs text-indigo-300">
                <CalendarDays className="w-4 h-4 text-indigo-400 shrink-0" />
                <span>
                  Total Requested Duration: <strong className="text-white">{calculatedLeaveDays} day{calculatedLeaveDays > 1 ? 's' : ''}</strong> ({leaveDate}{leaveEndDate && leaveEndDate !== leaveDate ? ` to ${leaveEndDate}` : ''})
                </span>
              </div>
            )}

            {/* Reason */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Reason Category <span className="text-rose-400">*</span>
              </label>
              <select
                value={leaveReason}
                onChange={(e) => setLeaveReason(e.target.value)}
                className="w-full bg-slate-950 border border-white/10 text-white text-xs rounded-xl p-2.5 focus:outline-none focus:border-indigo-500"
              >
                <option value="Medical / Illness">Medical / Illness</option>
                <option value="Family Emergency">Family Emergency</option>
                <option value="Bereavement">Bereavement</option>
                <option value="Religious Observance">Religious Observance</option>
                <option value="Academic / External Exam">Academic / External Competition</option>
                <option value="Travel / Personal">Travel / Personal Event</option>
                <option value="Other">Other Excused Absence</option>
              </select>
            </div>

            {/* Detailed Description */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Detailed Explanation <span className="text-rose-400">*</span>
              </label>
              <textarea
                rows={3}
                placeholder="Explain the circumstance of the student's absence for the school administration..."
                value={leaveDescription}
                onChange={(e) => setLeaveDescription(e.target.value)}
                required
                className="w-full bg-slate-950 border border-white/10 text-white text-xs rounded-xl p-3 focus:outline-none focus:border-indigo-500"
              />
            </div>

            {/* Attachment URL / File */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Doctor's Slip / Document Link <span className="text-slate-500 font-normal">(Optional)</span>
              </label>
              <Input
                type="url"
                placeholder="https://docs.google.com/... or cloud document link"
                value={attachmentUrl}
                onChange={(e) => {
                  setAttachmentUrl(e.target.value);
                  if (e.target.value && !attachmentName) {
                    setAttachmentName('Medical_or_Absence_Verification.pdf');
                  }
                }}
                className="w-full bg-slate-950 border-white/10 text-white text-xs"
              />
            </div>

            {/* Authorization Confirmation Checkbox */}
            <div className="p-3.5 rounded-xl bg-slate-950/80 border border-white/10 flex items-start gap-2.5">
              <input
                type="checkbox"
                id="guardian-leave-confirm"
                checked={guardianConfirmed}
                onChange={(e) => setGuardianConfirmed(e.target.checked)}
                className="mt-0.5 h-4 w-4 rounded border-white/20 text-indigo-600 focus:ring-indigo-500 bg-slate-900 cursor-pointer"
              />
              <label htmlFor="guardian-leave-confirm" className="text-xs text-slate-300 cursor-pointer">
                I confirm that I am the verified parent/guardian authorized to submit this absence request for <strong className="text-white">{selectedChild?.name}</strong>.
              </label>
            </div>

            <div className="flex items-center justify-end gap-3 border-t border-white/10 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => setIsLeaveModalOpen(false)}
                className="border-white/10 text-slate-300"
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={leaveSubmitting}
                className="bg-indigo-600 hover:bg-indigo-500 text-white gap-2"
              >
                <Send className="w-4 h-4" />
                <span>{leaveSubmitting ? 'Submitting Application...' : 'Submit Leave Request'}</span>
              </Button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
};
