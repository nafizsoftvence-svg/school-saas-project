import React, { useEffect, useState, useMemo } from 'react';
import {
  CalendarDays,
  Search,
  Filter,
  Calendar,
  Clock,
  MapPin,
  FileText,
  User,
  AlertCircle,
  CheckCircle2,
  RefreshCw,
  Eye,
  ChevronRight,
  Sparkles,
  BookOpen,
  Info,
  Layers,
  GraduationCap,
  Download,
  Printer,
  ShieldCheck,
  Award,
  AlertTriangle
} from 'lucide-react';
import { Badge } from '../../components/ui/Badge.js';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner.js';
import { Modal } from '../../components/ui/Modal.js';
import { EmptyState } from '../../components/ui/EmptyState.js';
import { downloadElementPdf, triggerSafePrint } from '../../utils/printPdf.js';
import { api } from '../../services/api.js';
import {
  ExamScheduleItem,
  StudentEnrolledSubject,
  StudentClassInfo
} from '../../types/index.js';

interface StudentExaminationsPageProps {
  onNavigate?: (view: string) => void;
}

export const StudentExaminationsPage: React.FC<StudentExaminationsPageProps> = ({ onNavigate }) => {
  const [schedules, setSchedules] = useState<ExamScheduleItem[]>([]);
  const [subjects, setSubjects] = useState<StudentEnrolledSubject[]>([]);
  const [classInfo, setClassInfo] = useState<StudentClassInfo | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Filters & controls
  const [searchTerm, setSearchTerm] = useState('');
  const [subjectFilter, setSubjectFilter] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [viewMode, setViewMode] = useState<'cards' | 'table'>('cards');

  // Modal inspection
  const [selectedExam, setSelectedExam] = useState<ExamScheduleItem | null>(null);
  const [showAdmitSlipModal, setShowAdmitSlipModal] = useState(false);

  const loadData = async (isManualRefresh = false) => {
    try {
      if (isManualRefresh) setRefreshing(true);
      else setLoading(true);
      setError(null);

      const [examRes, subjRes, classRes] = await Promise.all([
        api.getMyExaminations({
          subjectId: subjectFilter !== 'ALL' ? subjectFilter : undefined,
          status: statusFilter !== 'ALL' ? statusFilter : undefined,
          search: searchTerm || undefined
        }),
        api.getMyEnrolledSubjects(),
        api.getMyClassInfo()
      ]);

      if (examRes.success && examRes.data) {
        setSchedules(examRes.data);
      } else {
        setError(examRes.error || 'Failed to load examination timetable.');
      }

      if (subjRes.success && subjRes.data) {
        setSubjects(subjRes.data);
      }

      if (classRes.success && classRes.data) {
        setClassInfo(classRes.data);
      }
    } catch (err: any) {
      console.error('Error fetching exam timetable:', err);
      setError(err.message || 'Failed to connect to examination service.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [subjectFilter, statusFilter]);

  // Client-side search and sorting
  const filteredSchedules = useMemo(() => {
    return schedules.filter((item) => {
      if (searchTerm.trim()) {
        const q = searchTerm.toLowerCase().trim();
        const matchesName = (item.examName || '').toLowerCase().includes(q);
        const matchesSubject = (item.subjectName || '').toLowerCase().includes(q) || (item.subjectCode || '').toLowerCase().includes(q);
        const matchesRoom = item.roomNumber?.toLowerCase().includes(q);
        const matchesInstructions = item.instructions?.toLowerCase().includes(q);
        if (!matchesName && !matchesSubject && !matchesRoom && !matchesInstructions) {
          return false;
        }
      }
      return true;
    });
  }, [schedules, searchTerm]);

  // Analytics counts
  const totalCount = schedules.length;
  const scheduledCount = schedules.filter((s) => s.status === 'scheduled').length;
  const completedCount = schedules.filter((s) => s.status === 'completed').length;
  const ongoingCount = schedules.filter((s) => s.status === 'ongoing').length;

  const getStatusBadge = (status: ExamScheduleItem['status']) => {
    switch (status) {
      case 'scheduled':
        return (
          <Badge variant="primary" size="sm" dot>
            Upcoming
          </Badge>
        );
      case 'ongoing':
        return (
          <Badge variant="warning" size="sm" dot>
            In Progress
          </Badge>
        );
      case 'completed':
        return (
          <Badge variant="success" size="sm" dot>
            Concluded
          </Badge>
        );
      case 'postponed':
        return (
          <Badge variant="danger" size="sm" dot>
            Postponed
          </Badge>
        );
      default:
        return <Badge variant="neutral" size="sm">{status}</Badge>;
    }
  };

  const formatDate = (dateStr: string) => {
    try {
      const date = new Date(dateStr);
      return date.toLocaleDateString('en-US', {
        weekday: 'short',
        month: 'short',
        day: 'numeric',
        year: 'numeric'
      });
    } catch {
      return dateStr;
    }
  };

  const getDaysRemaining = (dateStr: string) => {
    try {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const target = new Date(dateStr);
      target.setHours(0, 0, 0, 0);
      const diffTime = target.getTime() - today.getTime();
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      if (diffDays === 0) return 'Today';
      if (diffDays === 1) return 'Tomorrow';
      if (diffDays > 1) return `In ${diffDays} days`;
      if (diffDays === -1) return 'Yesterday';
      return `${Math.abs(diffDays)} days ago`;
    } catch {
      return '';
    }
  };

  return (
    <div id="student-examinations-view" className="space-y-6">
      {/* Top Header & Context Banner */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-white border border-slate-200 p-6 sm:p-7 rounded-3xl shadow-2xs">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <Badge variant="primary" size="sm" dot>
              Official Timetable
            </Badge>
            <span className="text-xs text-slate-500 font-mono font-semibold">PART 4E — EXAM SCHEDULE</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 flex items-center gap-3">
            <CalendarDays className="w-7 h-7 text-blue-600" />
            <span>Examinations & Assessments</span>
          </h1>
          <p className="text-xs text-slate-600 mt-1 max-w-2xl leading-relaxed">
            View scheduled term evaluations, classroom seating locations, subject durations, and official examination guidelines assigned to your enrolled cohort.
          </p>
        </div>

        <div className="flex items-center flex-wrap gap-2.5">
          <button
            id="refresh-exams-btn"
            onClick={() => loadData(true)}
            disabled={refreshing || loading}
            className="px-3.5 py-2 rounded-xl bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer disabled:opacity-50 shadow-2xs"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin text-blue-600' : ''}`} />
            <span>{refreshing ? 'Refreshing...' : 'Refresh'}</span>
          </button>

          <button
            id="open-admit-slip-btn"
            onClick={() => setShowAdmitSlipModal(true)}
            className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold flex items-center gap-2 shadow-xs border border-blue-700 transition-all cursor-pointer"
          >
            <Award className="w-3.5 h-3.5" />
            <span>View Hall Ticket / Admit Card</span>
          </button>

          {onNavigate && (
            <button
              onClick={() => onNavigate('student-results')}
              className="px-3.5 py-2 rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-800 text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer shadow-2xs"
            >
              <span>View Results</span>
              <ChevronRight className="w-3.5 h-3.5 text-slate-500" />
            </button>
          )}
        </div>
      </div>

      {/* Cohort Identification Card & Summary Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-900/40 border border-white/10 p-4 rounded-xl backdrop-blur-md">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Enrolled Cohort</span>
            <GraduationCap className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="text-base font-bold text-white">
            {classInfo?.className || 'Grade 10'} • {classInfo?.sectionName || 'Section A'}
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            Session: {classInfo?.academicSessionName || '2026-2027 Academic Year'}
          </p>
        </div>

        <div className="bg-slate-900/40 border border-white/10 p-4 rounded-xl backdrop-blur-md">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Upcoming Exams</span>
            <Calendar className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-black text-amber-300">{scheduledCount}</div>
          <p className="text-[11px] text-slate-400 mt-1">Ready for evaluation</p>
        </div>

        <div className="bg-slate-900/40 border border-white/10 p-4 rounded-xl backdrop-blur-md">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Completed</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-black text-emerald-300">{completedCount}</div>
          <p className="text-[11px] text-slate-400 mt-1">Evaluated & archived</p>
        </div>

        <div className="bg-slate-900/40 border border-white/10 p-4 rounded-xl backdrop-blur-md">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Total Evaluated</span>
            <Layers className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-black text-cyan-300">{totalCount}</div>
          <p className="text-[11px] text-slate-400 mt-1">Across all enrolled subjects</p>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-slate-900/50 border border-white/10 p-4 rounded-2xl backdrop-blur-xl flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="flex-1 relative">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            id="search-exams-input"
            type="text"
            placeholder="Search exam name, subject, code, room number, supervisor..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-colors"
          />
        </div>

        <div className="flex items-center flex-wrap gap-2.5">
          {/* Subject Filter */}
          <div className="flex items-center gap-1.5 bg-slate-950/60 border border-white/10 px-3 py-1.5 rounded-xl">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <select
              id="filter-exam-subject"
              value={subjectFilter}
              onChange={(e) => setSubjectFilter(e.target.value)}
              className="bg-transparent text-xs text-slate-200 focus:outline-none cursor-pointer"
            >
              <option value="ALL" className="bg-slate-900 text-white">All Subjects</option>
              {(subjects || []).map((s) => (
                <option key={s.id} value={s.id} className="bg-slate-900 text-white">
                  {s.name} ({s.code})
                </option>
              ))}
            </select>
          </div>

          {/* Status Filter */}
          <div className="flex items-center gap-1.5 bg-slate-950/60 border border-white/10 px-3 py-1.5 rounded-xl">
            <select
              id="filter-exam-status"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="bg-transparent text-xs text-slate-200 focus:outline-none cursor-pointer"
            >
              <option value="ALL" className="bg-slate-900 text-white">All Statuses</option>
              <option value="scheduled" className="bg-slate-900 text-white">Upcoming</option>
              <option value="ongoing" className="bg-slate-900 text-white">In Progress</option>
              <option value="completed" className="bg-slate-900 text-white">Completed</option>
              <option value="postponed" className="bg-slate-900 text-white">Postponed</option>
            </select>
          </div>

          {/* View Toggle */}
          <div className="flex items-center bg-slate-950/60 border border-white/10 rounded-xl p-0.5">
            <button
              onClick={() => setViewMode('cards')}
              className={`px-3 py-1 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                viewMode === 'cards' ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-400 hover:text-white'
              }`}
            >
              Cards
            </button>
            <button
              onClick={() => setViewMode('table')}
              className={`px-3 py-1 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                viewMode === 'table' ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-400 hover:text-white'
              }`}
            >
              Timeline Table
            </button>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      {loading ? (
        <div className="p-16 flex flex-col items-center justify-center bg-slate-900/30 border border-white/10 rounded-2xl">
          <LoadingSpinner size="lg" />
          <p className="text-xs text-slate-400 mt-4 font-medium">Loading examination schedules & hall allocations...</p>
        </div>
      ) : error ? (
        <div className="p-8 bg-rose-500/10 border border-rose-500/20 rounded-2xl flex items-start gap-4 text-rose-300">
          <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
          <div>
            <h3 className="text-sm font-bold text-rose-200">Unable to load examination schedule</h3>
            <p className="text-xs mt-1">{error}</p>
            <button
              onClick={() => loadData()}
              className="mt-3 px-3 py-1.5 bg-rose-500/20 hover:bg-rose-500/30 text-rose-200 rounded-lg text-xs font-semibold transition-all cursor-pointer"
            >
              Try Again
            </button>
          </div>
        </div>
      ) : filteredSchedules.length === 0 ? (
        <EmptyState
          icon={CalendarDays}
          title="No Examination Schedules Found"
          description={
            searchTerm || subjectFilter !== 'ALL' || statusFilter !== 'ALL'
              ? 'No scheduled exams match your selected search or filter criteria.'
              : 'There are no examination sessions scheduled for your class at this time.'
          }
          actionLabel={
            searchTerm || subjectFilter !== 'ALL' || statusFilter !== 'ALL'
              ? 'Clear All Filters'
              : undefined
          }
          onAction={
            searchTerm || subjectFilter !== 'ALL' || statusFilter !== 'ALL'
              ? () => {
                  setSearchTerm('');
                  setSubjectFilter('ALL');
                  setStatusFilter('ALL');
                }
              : undefined
          }
        />
      ) : viewMode === 'cards' ? (
        /* Cards View */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {(filteredSchedules || []).map((exam) => {
            const daysLabel = getDaysRemaining(exam.examDate);
            return (
              <div
                key={exam.id}
                id={`exam-card-${exam.id}`}
                className="group bg-slate-900/50 hover:bg-slate-900/80 border border-white/10 hover:border-indigo-500/40 rounded-2xl p-5 backdrop-blur-xl transition-all duration-200 flex flex-col justify-between shadow-lg hover:shadow-indigo-500/10"
              >
                <div className="space-y-3.5">
                  {/* Card Header with Status and Remaining Days */}
                  <div className="flex items-center justify-between gap-2">
                    {getStatusBadge(exam.status)}
                    {daysLabel && (
                      <span className="text-[11px] font-semibold text-slate-400 bg-white/5 px-2.5 py-1 rounded-full border border-white/5">
                        {daysLabel}
                      </span>
                    )}
                  </div>

                  {/* Subject and Exam Title */}
                  <div>
                    <span className="text-[10px] font-black uppercase tracking-widest text-indigo-400 block mb-1">
                      {exam.subjectCode} • {exam.subjectName}
                    </span>
                    <h3 className="text-base font-bold text-white group-hover:text-indigo-200 transition-colors">
                      {exam.examName}
                    </h3>
                  </div>

                  {/* Exam Logistics Badge Grid */}
                  <div className="grid grid-cols-2 gap-2 bg-slate-950/40 border border-white/5 p-3 rounded-xl">
                    <div className="flex items-center gap-2">
                      <Calendar className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                      <span className="text-xs text-slate-300 truncate">{formatDate(exam.examDate)}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                      <span className="text-xs text-slate-300 truncate">
                        {exam.startTime} - {exam.endTime}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <MapPin className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                      <span className="text-xs text-slate-300 truncate">
                        {exam.roomNumber || 'TBD'} {exam.building ? `(${exam.building})` : ''}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <FileText className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                      <span className="text-xs text-slate-300 truncate">
                        {exam.totalMarks} Marks (Pass: {exam.passingMarks})
                      </span>
                    </div>
                  </div>

                  {/* Short instructions preview if available */}
                  {exam.instructions && (
                    <p className="text-xs text-slate-400 line-clamp-2 italic bg-white/[0.02] p-2 rounded-lg border border-white/5">
                      "{exam.instructions}"
                    </p>
                  )}
                </div>

                {/* Card Footer Actions */}
                <div className="mt-4 pt-3.5 border-t border-white/10 flex items-center justify-between gap-2">
                  <div className="text-[11px] text-slate-400 flex items-center gap-1.5">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Duration: {exam.durationMinutes} mins</span>
                  </div>

                  <button
                    onClick={() => setSelectedExam(exam)}
                    className="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/15 text-slate-200 hover:text-white text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
                  >
                    <Eye className="w-3.5 h-3.5 text-indigo-400" />
                    <span>Details</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* Timeline Table View */
        <div className="bg-slate-900/50 border border-white/10 rounded-2xl overflow-hidden backdrop-blur-xl shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-white/10 bg-slate-950/60 text-[11px] font-bold uppercase tracking-wider text-slate-400">
                  <th className="py-3.5 px-4">Date & Time</th>
                  <th className="py-3.5 px-4">Subject & Code</th>
                  <th className="py-3.5 px-4">Examination</th>
                  <th className="py-3.5 px-4">Venue / Hall</th>
                  <th className="py-3.5 px-4">Marks</th>
                  <th className="py-3.5 px-4">Status</th>
                  <th className="py-3.5 px-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 text-xs text-slate-300">
                {(filteredSchedules || []).map((exam) => (
                  <tr key={exam.id} className="hover:bg-white/[0.02] transition-colors">
                    <td className="py-3.5 px-4">
                      <div className="font-semibold text-white">{formatDate(exam.examDate)}</div>
                      <div className="text-[11px] text-slate-400 font-mono">
                        {exam.startTime} – {exam.endTime} ({exam.durationMinutes}m)
                      </div>
                    </td>
                    <td className="py-3.5 px-4">
                      <div className="font-bold text-indigo-300">{exam.subjectName}</div>
                      <div className="text-[11px] text-slate-400 font-mono">{exam.subjectCode}</div>
                    </td>
                    <td className="py-3.5 px-4">
                      <div className="font-semibold text-white">{exam.examName}</div>
                      <div className="text-[11px] text-slate-400">{exam.academicSessionName}</div>
                    </td>
                    <td className="py-3.5 px-4">
                      <div className="font-medium text-slate-200 flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-slate-400" />
                        <span>{exam.roomNumber || 'Unassigned'}</span>
                      </div>
                      {exam.building && <div className="text-[11px] text-slate-400">{exam.building}</div>}
                    </td>
                    <td className="py-3.5 px-4">
                      <div className="font-semibold text-white">{exam.totalMarks} Total</div>
                      <div className="text-[11px] text-slate-400">Pass: {exam.passingMarks}</div>
                    </td>
                    <td className="py-3.5 px-4">{getStatusBadge(exam.status)}</td>
                    <td className="py-3.5 px-4 text-right">
                      <button
                        onClick={() => setSelectedExam(exam)}
                        className="px-2.5 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white font-semibold transition-all inline-flex items-center gap-1 cursor-pointer"
                      >
                        <Eye className="w-3 h-3 text-indigo-400" />
                        <span>View</span>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Security & Authorization Guard Notice */}
      <div className="bg-slate-900/40 border border-white/10 p-4 rounded-xl flex items-center gap-3 text-xs text-slate-400">
        <ShieldCheck className="w-5 h-5 text-indigo-400 flex-shrink-0" />
        <div>
          <span className="font-semibold text-slate-300">Cohort-Isolated Exam Verification: </span>
          Timetable entries are strictly matched against your enrolled Grade 10 Section A cohort. Unauthorized schedules and external cohort questions are completely secured.
        </div>
      </div>

      {/* Modal 1: Detailed Exam Inspection */}
      <Modal
        isOpen={!!selectedExam}
        onClose={() => setSelectedExam(null)}
        title={
          <div className="flex items-center gap-2.5">
            <CalendarDays className="w-5 h-5 text-indigo-400" />
            <span className="text-base font-bold text-white">Examination Details & Hall Instructions</span>
          </div>
        }
        size="lg"
      >
        {selectedExam && (
          <div className="space-y-5">
            {/* Header banner */}
            <div className="bg-slate-950/60 border border-white/10 p-4 rounded-xl flex items-center justify-between gap-4">
              <div>
                <span className="text-[11px] font-black uppercase tracking-widest text-indigo-400 block mb-1">
                  {selectedExam.subjectCode} • {selectedExam.academicSessionName}
                </span>
                <h2 className="text-lg font-bold text-white">{selectedExam.examName}</h2>
                <p className="text-xs text-slate-300 font-medium">{selectedExam.subjectName}</p>
              </div>
              <div>{getStatusBadge(selectedExam.status)}</div>
            </div>

            {/* Key Information Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <div className="bg-white/[0.02] border border-white/5 p-3 rounded-xl">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Exam Date</span>
                <span className="text-xs font-semibold text-white mt-1 block">{formatDate(selectedExam.examDate)}</span>
              </div>
              <div className="bg-white/[0.02] border border-white/5 p-3 rounded-xl">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Time & Duration</span>
                <span className="text-xs font-semibold text-white mt-1 block">
                  {selectedExam.startTime} - {selectedExam.endTime} ({selectedExam.durationMinutes}m)
                </span>
              </div>
              <div className="bg-white/[0.02] border border-white/5 p-3 rounded-xl">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Examination Venue</span>
                <span className="text-xs font-semibold text-white mt-1 block">
                  {selectedExam.roomNumber || 'TBD'} {selectedExam.building ? `(${selectedExam.building})` : ''}
                </span>
              </div>
              <div className="bg-white/[0.02] border border-white/5 p-3 rounded-xl">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Total Marks</span>
                <span className="text-xs font-semibold text-white mt-1 block">{selectedExam.totalMarks} Points</span>
              </div>
              <div className="bg-white/[0.02] border border-white/5 p-3 rounded-xl">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Passing Benchmark</span>
                <span className="text-xs font-semibold text-emerald-300 mt-1 block">{selectedExam.passingMarks} Points</span>
              </div>
              <div className="bg-white/[0.02] border border-white/5 p-3 rounded-xl">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Invigilator / Supervisor</span>
                <span className="text-xs font-semibold text-white mt-1 block">{selectedExam.invigilatorName || 'Faculty Board'}</span>
              </div>
            </div>

            {/* Exam Instructions */}
            <div className="bg-indigo-950/30 border border-indigo-500/20 p-4 rounded-xl">
              <div className="flex items-center gap-2 text-indigo-300 text-xs font-bold mb-2">
                <Info className="w-4 h-4" />
                <span>Candidate Instructions & Regulations</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed whitespace-pre-line">
                {selectedExam.instructions ||
                  'Please arrive at the examination hall at least 15 minutes prior to start time with your official student ID card and verified Hall Ticket. Electronic communication devices are strictly prohibited inside the hall.'}
              </p>
            </div>

            {/* Modal Actions */}
            <div className="flex items-center justify-end gap-3 pt-3 border-t border-white/10">
              <button
                onClick={() => setSelectedExam(null)}
                className="px-4 py-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-xs font-semibold text-slate-300 hover:text-white transition-all cursor-pointer"
              >
                Close
              </button>
              <button
                onClick={() => {
                  setSelectedExam(null);
                  setShowAdmitSlipModal(true);
                }}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer shadow-md shadow-indigo-600/30"
              >
                <Award className="w-3.5 h-3.5" />
                <span>Print Admit Card Slip</span>
              </button>
            </div>
          </div>
        )}
      </Modal>

      {/* Modal 2: Hall Ticket / Admit Slip Preview */}
      <Modal
        isOpen={showAdmitSlipModal}
        onClose={() => setShowAdmitSlipModal(false)}
        title={
          <div className="flex items-center gap-2.5">
            <Award className="w-5 h-5 text-indigo-400" />
            <span className="text-base font-bold text-white">Official Examination Admit Slip</span>
          </div>
        }
        size="xl"
      >
        <div className="space-y-6">
          {/* Printable Ticket Canvas */}
          <div id="printable-exam-admit-card" className="bg-slate-950 border border-white/15 p-6 rounded-2xl text-slate-100 shadow-2xl relative overflow-hidden">
            {/* Header */}
            <div className="flex items-center justify-between border-b border-white/10 pb-4 mb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center font-black text-white text-lg">
                  S
                </div>
                <div>
                  <h2 className="text-base font-black tracking-tight text-white uppercase">SYGMATE ACADEMY OF EXCELLENCE</h2>
                  <p className="text-[11px] text-slate-400">Board of Examinations • Official Candidate Admit Card</p>
                </div>
              </div>
              <div className="text-right">
                <Badge variant="success" size="sm">
                  VERIFIED CANDIDATE
                </Badge>
                <p className="text-[10px] font-mono text-slate-400 mt-1">SESSION: 2026-2027</p>
              </div>
            </div>

            {/* Candidate Metadata Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-white/[0.02] border border-white/5 p-3 rounded-xl mb-5 text-xs">
              <div>
                <span className="text-[10px] text-slate-400 font-bold uppercase block">Candidate Name</span>
                <span className="font-bold text-white mt-0.5 block">Alex Rivera</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 font-bold uppercase block">Admission ID</span>
                <span className="font-mono text-indigo-300 mt-0.5 block">ADM-2026-0042</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 font-bold uppercase block">Class & Section</span>
                <span className="font-bold text-white mt-0.5 block">Grade 10 • Section A</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 font-bold uppercase block">Roll Number</span>
                <span className="font-mono text-white mt-0.5 block">10A-01</span>
              </div>
            </div>

            {/* Timetable schedule breakdown */}
            <div className="space-y-2">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">
                Authorized Examination Schedule
              </span>
              <div className="border border-white/10 rounded-xl overflow-hidden">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-900 border-b border-white/10 text-[10px] font-bold uppercase text-slate-400">
                      <th className="py-2.5 px-3">Date</th>
                      <th className="py-2.5 px-3">Subject</th>
                      <th className="py-2.5 px-3">Time</th>
                      <th className="py-2.5 px-3">Hall</th>
                      <th className="py-2.5 px-3 text-right">Invigilator Sign</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {(schedules || []).map((item) => (
                      <tr key={item.id} className="hover:bg-white/[0.02]">
                        <td className="py-2.5 px-3 font-semibold text-white">{formatDate(item.examDate)}</td>
                        <td className="py-2.5 px-3 text-indigo-300 font-medium">
                          {item.subjectName} ({item.subjectCode})
                        </td>
                        <td className="py-2.5 px-3 font-mono text-slate-300">
                          {item.startTime} - {item.endTime}
                        </td>
                        <td className="py-2.5 px-3 text-slate-300">{item.roomNumber || 'Hall A'}</td>
                        <td className="py-2.5 px-3 text-right text-slate-500 font-mono">________________</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Footer validation notice */}
            <div className="mt-5 pt-4 border-t border-white/10 flex items-center justify-between text-[11px] text-slate-400">
              <span>Candidate Signature: ______________________</span>
              <span className="text-right">Controller of Examinations Seal (Authenticated)</span>
            </div>
          </div>

          {/* Modal Actions */}
          <div className="flex items-center justify-end gap-3">
            <button
              onClick={() => setShowAdmitSlipModal(false)}
              className="px-4 py-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-xs font-semibold text-slate-300 hover:text-white transition-all cursor-pointer"
            >
              Close
            </button>
            <button
              onClick={async () => {
                await downloadElementPdf('printable-exam-admit-card', 'alex_rivera_exam_admit_slip.pdf', {
                  orientation: 'portrait'
                });
                await triggerSafePrint({
                  elementOrId: 'printable-exam-admit-card',
                  fallbackTitle: 'Exam_Admit_Card'
                });
              }}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-lg shadow-indigo-600/30 transition-all cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / Download Slip</span>
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
