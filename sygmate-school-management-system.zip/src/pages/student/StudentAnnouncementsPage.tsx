import React, { useEffect, useState, useMemo } from 'react';
import {
  Bell,
  Search,
  Filter,
  Pin,
  Calendar,
  Clock,
  User,
  AlertCircle,
  AlertTriangle,
  Info,
  CheckCircle2,
  RefreshCw,
  Eye,
  Sparkles,
  ChevronRight,
  Megaphone,
  Layers,
  ShieldAlert,
  Paperclip,
  Download,
  FileText,
  Check
} from 'lucide-react';
import { Badge } from '../../components/ui/Badge.js';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner.js';
import { Modal } from '../../components/ui/Modal.js';
import { EmptyState } from '../../components/ui/EmptyState.js';
import { api } from '../../services/api.js';
import {
  ClassAnnouncement,
  StudentClassInfo
} from '../../types/index.js';

interface StudentAnnouncementsPageProps {
  onNavigate?: (view: string) => void;
}

export const StudentAnnouncementsPage: React.FC<StudentAnnouncementsPageProps> = ({ onNavigate }) => {
  const [announcements, setAnnouncements] = useState<ClassAnnouncement[]>([]);
  const [classInfo, setClassInfo] = useState<StudentClassInfo | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Filters
  const [searchTerm, setSearchTerm] = useState('');
  const [priorityFilter, setPriorityFilter] = useState<string>('ALL');
  const [categoryFilter, setCategoryFilter] = useState<string>('ALL');

  // Modal inspection
  const [selectedAnnouncement, setSelectedAnnouncement] = useState<ClassAnnouncement | null>(null);

  const loadData = async (isManualRefresh = false) => {
    try {
      if (isManualRefresh) setRefreshing(true);
      else setLoading(true);
      setError(null);

      const [annRes, classRes] = await Promise.all([
        api.getMyAnnouncements({
          priority: priorityFilter !== 'ALL' ? priorityFilter : undefined,
          search: searchTerm || undefined
        }),
        api.getMyClassInfo()
      ]);

      if (annRes.success && annRes.data) {
        setAnnouncements(annRes.data);
      } else {
        setError(annRes.error || 'Failed to load class announcements.');
      }

      if (classRes.success && classRes.data) {
        setClassInfo(classRes.data);
      }
    } catch (err: any) {
      console.error('Error fetching student announcements:', err);
      setError(err.message || 'Network error while retrieving announcements.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [priorityFilter]);

  const handleOpenNotice = async (item: ClassAnnouncement) => {
    setSelectedAnnouncement(item);
    if (!item.isRead) {
      try {
        await api.communication.announcements.markAsRead(item.id);
        setAnnouncements((prev) =>
          prev.map((a) => (a.id === item.id ? { ...a, isRead: true, readAt: new Date().toISOString() } : a))
        );
      } catch (err) {
        console.error('Failed to mark notice as read:', err);
      }
    }
  };

  const filteredAnnouncements = useMemo(() => {
    let list = [...announcements];

    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase().trim();
      list = list.filter(
        (a) =>
          (a.title || '').toLowerCase().includes(q) ||
          (a.message || '').toLowerCase().includes(q) ||
          (a.teacherName || '').toLowerCase().includes(q) ||
          (a.className || '').toLowerCase().includes(q) ||
          (a.category || '').toLowerCase().includes(q)
      );
    }

    if (categoryFilter !== 'ALL') {
      list = list.filter((a) => (a.category || 'GENERAL').toUpperCase() === categoryFilter.toUpperCase());
    }

    // Pinned announcements always on top
    list.sort((a, b) => {
      if (a.isPinned && !b.isPinned) return -1;
      if (!a.isPinned && b.isPinned) return 1;
      return b.publishDate.localeCompare(a.publishDate);
    });

    return list;
  }, [announcements, searchTerm, categoryFilter]);

  const metrics = useMemo(() => {
    const total = announcements.length;
    const urgent = announcements.filter((a) => a.priority === 'urgent').length;
    const unread = announcements.filter((a) => !a.isRead).length;
    const pinned = announcements.filter((a) => a.isPinned).length;
    return { total, urgent, unread, pinned };
  }, [announcements]);

  const getPriorityBadge = (priority: string) => {
    const p = (priority || 'normal').toLowerCase();
    if (p === 'urgent') {
      return (
        <Badge variant="danger" dot>
          Urgent Notice
        </Badge>
      );
    }
    if (p === 'high') {
      return (
        <Badge variant="warning" dot>
          High Priority
        </Badge>
      );
    }
    return <Badge variant="neutral">General Notice</Badge>;
  };

  const getCategoryBadge = (category?: string) => {
    const cat = (category || 'GENERAL').toUpperCase();
    switch (cat) {
      case 'ACADEMIC':
        return <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-500/20 text-blue-300 border border-blue-500/30">Academic</span>;
      case 'EXAMINATION':
        return <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">Exam Notice</span>;
      case 'EMERGENCY':
        return <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/20 text-rose-300 border border-rose-500/30">Emergency</span>;
      case 'EVENT':
        return <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-purple-500/20 text-purple-300 border border-purple-500/30">School Event</span>;
      case 'HOLIDAY':
        return <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">Holiday</span>;
      case 'FEE_FINANCE':
        return <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">Fee Notice</span>;
      default:
        return <span className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-slate-800 text-slate-300 border border-white/10">Notice</span>;
    }
  };

  return (
    <div id="student-announcements-page" className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900/60 backdrop-blur-xl p-6 rounded-2xl border border-white/10 shadow-xl relative overflow-hidden">
        <div className="absolute -right-16 -top-16 w-56 h-56 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10">
          <div className="flex items-center gap-2 text-amber-400 text-xs font-semibold uppercase tracking-wider mb-1">
            <Megaphone className="w-4 h-4" />
            <span>Official Cohort Bulletins</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight flex items-center gap-3">
            Class Announcements
            {classInfo && (
              <span className="text-xs font-normal px-2.5 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
                {classInfo.schoolClass.name} • {classInfo.section.name}
              </span>
            )}
          </h1>
          <p className="text-sm text-slate-400 mt-1 max-w-2xl">
            Stay informed with real-time class notices, exam schedules, schedule adjustments, and urgent updates broadcast by faculty.
          </p>
        </div>

        <div className="flex items-center gap-3 relative z-10 self-start md:self-auto">
          <button
            id="announcements-refresh-btn"
            onClick={() => loadData(true)}
            disabled={refreshing}
            className="flex items-center gap-2 px-3.5 py-2 text-xs font-medium text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-700/80 border border-white/10 rounded-xl transition-all disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin' : ''}`} />
            <span>{refreshing ? 'Refreshing...' : 'Refresh'}</span>
          </button>
          {onNavigate && (
            <button
              onClick={() => onNavigate('student-homework')}
              className="flex items-center gap-2 px-3.5 py-2 text-xs font-medium text-amber-300 hover:text-amber-200 bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/30 rounded-xl transition-all"
            >
              <Calendar className="w-3.5 h-3.5" />
              <span>Homework</span>
            </button>
          )}
        </div>
      </div>

      {/* Metrics Summary Pills */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
        <div
          onClick={() => setPriorityFilter('ALL')}
          className={`cursor-pointer p-4 rounded-xl border transition-all ${
            priorityFilter === 'ALL'
              ? 'bg-amber-500/15 border-amber-500/40 shadow-lg shadow-amber-500/10'
              : 'bg-slate-900/40 hover:bg-slate-900/60 border-white/5'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Total Bulletins</span>
            <Megaphone className="w-4 h-4 text-amber-400" />
          </div>
          <p className="text-2xl font-bold text-white mt-2">{metrics.total}</p>
          <span className="text-[11px] text-slate-400">All announcements</span>
        </div>

        <div className="p-4 rounded-xl border bg-slate-900/40 border-white/5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-amber-400">Unread Notices</span>
            <Bell className="w-4 h-4 text-amber-400" />
          </div>
          <p className="text-2xl font-bold text-amber-300 mt-2">{metrics.unread}</p>
          <span className="text-[11px] text-slate-400">Awaiting acknowledgment</span>
        </div>

        <div
          onClick={() => setPriorityFilter(priorityFilter === 'urgent' ? 'ALL' : 'urgent')}
          className={`cursor-pointer p-4 rounded-xl border transition-all ${
            priorityFilter === 'urgent'
              ? 'bg-rose-500/15 border-rose-500/40 shadow-lg shadow-rose-500/10'
              : 'bg-slate-900/40 hover:bg-slate-900/60 border-white/5'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-rose-400">Urgent Alerts</span>
            <ShieldAlert className="w-4 h-4 text-rose-400" />
          </div>
          <p className="text-2xl font-bold text-rose-300 mt-2">{metrics.urgent}</p>
          <span className="text-[11px] text-slate-400">Immediate attention</span>
        </div>

        <div className="p-4 rounded-xl border bg-slate-900/40 border-white/5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Pinned Notices</span>
            <Pin className="w-4 h-4 text-amber-400" />
          </div>
          <p className="text-2xl font-bold text-amber-300 mt-2">{metrics.pinned}</p>
          <span className="text-[11px] text-slate-400">Important notices pinned</span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-slate-900/40 backdrop-blur-md p-4 rounded-2xl border border-white/10 flex flex-col md:flex-row gap-3 items-center justify-between">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search announcement keywords, faculty..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-950/60 border border-white/10 text-white placeholder-slate-500 text-xs rounded-xl pl-9 pr-4 py-2.5 focus:outline-none focus:border-amber-500/50 transition-colors"
          />
          {searchTerm && (
            <button
              onClick={() => setSearchTerm('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white text-xs"
            >
              &times;
            </button>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto">
          <div className="flex items-center gap-1.5 bg-slate-950/60 border border-white/10 rounded-xl px-3 py-1.5">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={priorityFilter}
              onChange={(e) => setPriorityFilter(e.target.value)}
              className="bg-transparent text-xs text-white focus:outline-none cursor-pointer"
            >
              <option value="ALL" className="bg-slate-900 text-white">All Priorities</option>
              <option value="urgent" className="bg-slate-900 text-white">Urgent Only</option>
              <option value="high" className="bg-slate-900 text-white">High Priority</option>
              <option value="normal" className="bg-slate-900 text-white">General / Normal</option>
            </select>
          </div>

          <div className="flex items-center gap-1.5 bg-slate-950/60 border border-white/10 rounded-xl px-3 py-1.5">
            <Layers className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="bg-transparent text-xs text-white focus:outline-none cursor-pointer"
            >
              <option value="ALL" className="bg-slate-900 text-white">All Categories</option>
              <option value="ACADEMIC" className="bg-slate-900 text-white">Academic</option>
              <option value="EXAMINATION" className="bg-slate-900 text-white">Examinations</option>
              <option value="EVENT" className="bg-slate-900 text-white">Events</option>
              <option value="HOLIDAY" className="bg-slate-900 text-white">Holidays</option>
              <option value="FEE_FINANCE" className="bg-slate-900 text-white">Fee & Finance</option>
              <option value="EMERGENCY" className="bg-slate-900 text-white">Emergency</option>
              <option value="GENERAL" className="bg-slate-900 text-white">General</option>
            </select>
          </div>
        </div>
      </div>

      {/* Error state */}
      {error && (
        <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-sm flex items-center gap-3">
          <AlertCircle className="w-5 h-5 shrink-0" />
          <span>{error}</span>
          <button
            onClick={() => loadData()}
            className="ml-auto text-xs underline hover:text-white"
          >
            Retry
          </button>
        </div>
      )}

      {/* Main Content */}
      {loading ? (
        <div className="py-20 flex flex-col items-center justify-center gap-3">
          <LoadingSpinner size="lg" />
          <p className="text-sm text-slate-400">Loading class notices...</p>
        </div>
      ) : filteredAnnouncements.length === 0 ? (
        <EmptyState
          icon={Bell}
          title="No Announcements"
          description={
            searchTerm || priorityFilter !== 'ALL'
              ? 'No announcements match your search or priority filter.'
              : 'There are no active announcements published for your class and section at this time.'
          }
          action={
            searchTerm || priorityFilter !== 'ALL' ? (
              <button
                onClick={() => {
                  setSearchTerm('');
                  setPriorityFilter('ALL');
                }}
                className="px-4 py-2 text-xs font-semibold text-white bg-amber-600 hover:bg-amber-500 rounded-xl transition-all"
              >
                Clear Filter
              </button>
            ) : undefined
          }
        />
      ) : (
        <div className="space-y-4">
          {(filteredAnnouncements || []).map((item) => (
            <div
              key={item.id}
              onClick={() => handleOpenNotice(item)}
              className={`rounded-2xl border bg-slate-900/50 backdrop-blur-xl p-5 sm:p-6 transition-all duration-200 hover:border-white/20 relative overflow-hidden group cursor-pointer ${
                item.isPinned
                  ? 'border-amber-500/40 bg-amber-500/[0.03] shadow-lg shadow-amber-500/5'
                  : item.priority === 'urgent'
                  ? 'border-rose-500/30'
                  : !item.isRead
                  ? 'border-indigo-500/40 bg-indigo-500/[0.02]'
                  : 'border-white/10'
              }`}
            >
              {/* Top indicator ribbon */}
              {item.isPinned && (
                <div className="absolute top-0 right-0 bg-amber-500/20 text-amber-300 border-b border-l border-amber-500/30 px-3 py-1 text-[10px] font-bold rounded-bl-xl flex items-center gap-1">
                  <Pin className="w-3 h-3 rotate-45" />
                  <span>PINNED NOTICE</span>
                </div>
              )}

              <div className="space-y-3">
                {/* Header row with badges */}
                <div className="flex flex-wrap items-center gap-2">
                  {getPriorityBadge(item.priority)}
                  {getCategoryBadge(item.category)}
                  {!item.isRead ? (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500 text-slate-950 uppercase tracking-wider animate-pulse">
                      NEW
                    </span>
                  ) : (
                    <span className="flex items-center gap-1 text-[11px] text-emerald-400/90 font-medium">
                      <Check className="w-3 h-3" /> Read
                    </span>
                  )}
                  <span className="text-slate-600">•</span>
                  <span className="text-xs text-slate-400">
                    Target: <strong className="text-slate-300">{item.className} • {item.sectionName}</strong>
                  </span>
                  <span className="text-slate-600">•</span>
                  <div className="flex items-center gap-1.5 text-xs text-slate-400">
                    <Calendar className="w-3.5 h-3.5 text-slate-500" />
                    <span>{item.publishDate}</span>
                  </div>
                </div>

                {/* Announcement Title */}
                <h3 className="text-base sm:text-lg font-bold text-white group-hover:text-amber-300 transition-colors">
                  {item.title}
                </h3>

                {/* Announcement Body */}
                <div className="text-sm text-slate-300 leading-relaxed whitespace-pre-wrap line-clamp-3">
                  {item.message}
                </div>

                {/* Attachments preview */}
                {((item?.attachments?.length || 0) > 0) && (
                  <div className="flex flex-wrap items-center gap-2 pt-1">
                    <span className="text-[11px] text-slate-400 flex items-center gap-1">
                      <Paperclip className="w-3 h-3 text-slate-400" />
                      {item.attachments?.length || 0} attachment{(item.attachments?.length || 0) > 1 ? 's' : ''}:
                    </span>
                    {(item.attachments || []).map((att, idx) => (
                      <span
                        key={idx}
                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800/80 border border-white/10 text-[11px] text-slate-300 hover:text-white"
                        onClick={(e) => {
                          e.stopPropagation();
                          if (att.url) window.open(att.url, '_blank');
                        }}
                      >
                        <FileText className="w-3 h-3 text-amber-400" />
                        <span className="truncate max-w-[140px]">{att.name}</span>
                        <Download className="w-3 h-3 text-slate-400 hover:text-amber-300 ml-0.5" />
                      </span>
                    ))}
                  </div>
                )}

                {/* Footer metadata */}
                <div className="pt-3 border-t border-white/5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                  <div className="flex items-center gap-2 text-slate-400">
                    <div className="w-6 h-6 rounded-full bg-slate-800 border border-white/10 flex items-center justify-center text-amber-400 font-bold text-[10px]">
                      {item.teacherName ? item.teacherName.charAt(0) : 'S'}
                    </div>
                    <span>Announced by: <strong className="text-slate-200">{item.teacherName}</strong></span>
                  </div>

                  <div className="flex items-center gap-3">
                    {item.expiryDate && (
                      <span className="text-[11px] text-slate-500 flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        <span>Valid until {item.expiryDate}</span>
                      </span>
                    )}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleOpenNotice(item);
                      }}
                      className="flex items-center gap-1.5 text-xs font-medium text-amber-300 hover:text-amber-200 px-3 py-1.5 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/20 transition-colors ml-auto sm:ml-0"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>Full Notice</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Modal: Full Announcement View */}
      {selectedAnnouncement && (
        <Modal
          isOpen={!!selectedAnnouncement}
          onClose={() => setSelectedAnnouncement(null)}
          title="Class Announcement"
          size="lg"
        >
          <div className="space-y-5">
            <div className="p-4 rounded-xl bg-slate-950/60 border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <div className="flex flex-wrap items-center gap-2 mb-1.5">
                  {getPriorityBadge(selectedAnnouncement.priority)}
                  {getCategoryBadge(selectedAnnouncement.category)}
                  {selectedAnnouncement.isPinned && (
                    <Badge variant="warning" size="sm">
                      Pinned
                    </Badge>
                  )}
                  <span className="flex items-center gap-1 text-[11px] text-emerald-400 font-medium px-2 py-0.5 rounded bg-emerald-950/50 border border-emerald-500/30">
                    <Check className="w-3 h-3" /> Read Receipt Verified
                  </span>
                </div>
                <h2 className="text-lg font-bold text-white">{selectedAnnouncement.title}</h2>
              </div>
              <div className="text-right sm:border-l sm:border-white/10 sm:pl-4 shrink-0">
                <div className="text-[10px] uppercase tracking-wider text-slate-400">Class Cohort</div>
                <div className="text-xs font-semibold text-amber-300">
                  {selectedAnnouncement.className} • {selectedAnnouncement.sectionName}
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                <Megaphone className="w-3.5 h-3.5 text-amber-400" />
                <span>Official Broadcast Message</span>
              </label>
              <div className="p-5 rounded-xl bg-slate-900/90 border border-white/5 text-sm text-slate-100 leading-relaxed whitespace-pre-wrap">
                {selectedAnnouncement.message}
              </div>
            </div>

            {/* Attachments Section in Modal */}
            {((selectedAnnouncement?.attachments?.length || 0) > 0) && (
              <div className="space-y-2">
                <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Paperclip className="w-3.5 h-3.5 text-amber-400" />
                  <span>Attachments ({selectedAnnouncement?.attachments?.length || 0})</span>
                </label>
                <div className="space-y-2">
                  {(selectedAnnouncement?.attachments || []).map((att, idx) => (
                    <div
                      key={idx}
                      className="p-3 rounded-xl bg-slate-950/50 border border-white/10 flex items-center justify-between gap-3 text-xs"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <FileText className="w-4 h-4 text-amber-400 shrink-0" />
                        <div className="truncate">
                          <p className="font-semibold text-slate-200 truncate">{att.name}</p>
                          <p className="text-[10px] text-slate-400">
                            {att.size ? `${(att.size / 1024).toFixed(1)} KB` : 'Document'}
                          </p>
                        </div>
                      </div>
                      <a
                        href={att.url}
                        target="_blank"
                        rel="noreferrer"
                        className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-lg flex items-center gap-1.5 font-medium shrink-0 transition-colors"
                      >
                        <Download className="w-3.5 h-3.5" />
                        Download
                      </a>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div className="p-3.5 rounded-xl bg-slate-950/40 border border-white/5 flex items-center gap-3">
                <User className="w-4 h-4 text-amber-400 shrink-0" />
                <div>
                  <span className="text-slate-500 block text-[11px]">Published By</span>
                  <span className="text-slate-200 font-semibold">{selectedAnnouncement.teacherName}</span>
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-950/40 border border-white/5 flex items-center gap-3">
                <Calendar className="w-4 h-4 text-amber-400 shrink-0" />
                <div>
                  <span className="text-slate-500 block text-[11px]">Publish Date</span>
                  <span className="text-slate-200 font-semibold">{selectedAnnouncement.publishDate}</span>
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-950/40 border border-white/5 flex items-center gap-3">
                <Clock className="w-4 h-4 text-amber-400 shrink-0" />
                <div>
                  <span className="text-slate-500 block text-[11px]">Expiry / Valid Thru</span>
                  <span className="text-slate-200 font-semibold">{selectedAnnouncement.expiryDate || 'Indefinite'}</span>
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-white/10">
              <button
                onClick={() => setSelectedAnnouncement(null)}
                className="px-4 py-2 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 rounded-xl transition-colors"
              >
                Close Notice
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
