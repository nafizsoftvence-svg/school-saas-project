import React, { useState, useEffect } from 'react';
import { User, AlertCircle, RefreshCw } from 'lucide-react';
import { Button } from '../../components/ui/Button.js';
import { Alert } from '../../components/ui/Alert.js';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner.js';
import { api } from '../../services/api.js';
import { StudentMasterProfile } from '../../components/students/StudentMasterProfile.js';

export const StudentProfilePage: React.FC = () => {
  const [profileId, setProfileId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchProfile = async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await api.getMyProfile();
      if (res.success && res.data) {
        const studentProfile = res.data.profile;
        if (studentProfile?.id) {
          setProfileId(studentProfile.id);
        } else {
          setError('Student record profile not found for the authenticated user.');
        }
      } else {
        setError(res.error || 'Unable to retrieve student profile.');
      }
    } catch (err: any) {
      setError(err?.message || 'Network error fetching student bio.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProfile();
  }, []);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center p-16 space-y-4">
        <LoadingSpinner size="lg" />
        <p className="text-slate-400 text-sm">Loading Student Profile &amp; Records...</p>
      </div>
    );
  }

  if (error || !profileId) {
    return (
      <div className="max-w-2xl mx-auto my-12 p-6 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-center space-y-4">
        <AlertCircle className="w-10 h-10 text-rose-400 mx-auto" />
        <h3 className="text-lg font-bold text-white">Student Profile Unavailable</h3>
        <p className="text-xs text-rose-200">{error || 'Could not find your student profile record.'}</p>
        <Button size="sm" variant="primary" onClick={fetchProfile} icon={<RefreshCw className="w-4 h-4" />}>
          Retry
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-10">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2">
            <User className="w-6 h-6 text-indigo-400" />
            My Student Master Profile
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Access your academic placement, enrolled subjects, attendance standing, examination results, fee account, and official documents.
          </p>
        </div>
      </div>

      <StudentMasterProfile
        studentId={profileId}
        isSelfService={true}
        allowEdit={true}
        onRefresh={fetchProfile}
      />
    </div>
  );
};
