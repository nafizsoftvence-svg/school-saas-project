import React, { useEffect, useState, useMemo } from 'react';
import {
  TrendingUp,
  Award,
  Calendar,
  CheckCircle2,
  AlertCircle,
  Clock,
  RefreshCw,
  Eye,
  Info,
  ShieldCheck,
  Percent,
  Sparkles,
  BarChart3,
  BookOpen,
  CheckSquare,
  ArrowUpRight,
  ArrowDownRight,
  Minus,
  Star,
  ChevronRight,
  GraduationCap,
  Layers,
  Flame,
  FileText
} from 'lucide-react';
import { Badge } from '../../components/ui/Badge.js';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner.js';
import { Modal } from '../../components/ui/Modal.js';
import { EmptyState } from '../../components/ui/EmptyState.js';
import { api } from '../../services/api.js';
import {
  StudentAcademicProgressOverview,
  SubjectPerformanceTrend,
  ExamWiseTrendItem
} from '../../types/index.js';

interface StudentProgressPageProps {
  onNavigate?: (view: string) => void;
}

export const StudentProgressPage: React.FC<StudentProgressPageProps> = ({ onNavigate }) => {
  const [progressData, setProgressData] = useState<StudentAcademicProgressOverview | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Subject drilldown inspection modal
  const [inspectedSubject, setInspectedSubject] = useState<SubjectPerformanceTrend | null>(null);

  const loadData = async (isManualRefresh = false) => {
    try {
      if (isManualRefresh) setRefreshing(true);
      else setLoading(true);
      setError(null);

      const res = await api.getMyAcademicProgress();
      if (res.success && res.data) {
        setProgressData(res.data);
      } else {
        setError(res.error || 'Failed to load academic progress metrics.');
      }
    } catch (err: any) {
      console.error('Error fetching academic progress:', err);
      setError(err.message || 'Network error while calculating progress trends.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const getTrendIcon = (trend: SubjectPerformanceTrend['trend']) => {
    switch (trend) {
      case 'improving':
        return <ArrowUpRight className="w-3.5 h-3.5 text-emerald-400" />;
      case 'declining':
        return <ArrowDownRight className="w-3.5 h-3.5 text-rose-400" />;
      default:
        return <Minus className="w-3.5 h-3.5 text-slate-400" />;
    }
  };

  const getTrendBadge = (trend: SubjectPerformanceTrend['trend'], delta: number) => {
    switch (trend) {
      case 'improving':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-300 bg-emerald-500/15 px-2 py-0.5 rounded-full border border-emerald-500/30">
            <ArrowUpRight className="w-3 h-3" />
            <span>+{delta}% Improving</span>
          </span>
        );
      case 'declining':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-rose-300 bg-rose-500/15 px-2 py-0.5 rounded-full border border-rose-500/30">
            <ArrowDownRight className="w-3 h-3" />
            <span>{delta}% Declining</span>
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-slate-300 bg-white/10 px-2 py-0.5 rounded-full border border-white/10">
            <Minus className="w-3 h-3 text-slate-400" />
            <span>Steady</span>
          </span>
        );
    }
  };

  const getGradeColor = (grade: string) => {
    const g = grade.toUpperCase();
    if (g.startsWith('A')) return 'text-emerald-300 bg-emerald-500/10 border-emerald-500/30';
    if (g.startsWith('B')) return 'text-indigo-300 bg-indigo-500/10 border-indigo-500/30';
    if (g.startsWith('C')) return 'text-amber-300 bg-amber-500/10 border-amber-500/30';
    return 'text-rose-300 bg-rose-500/10 border-rose-500/30';
  };

  return (
    <div id="student-progress-view" className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-slate-900/60 border border-white/10 p-6 rounded-2xl backdrop-blur-xl shadow-xl">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <Badge variant="cyan" size="sm" dot>
              Academic Analytics
            </Badge>
            <span className="text-xs text-slate-400 font-mono">PART 4E — PROGRESS & IMPROVEMENT</span>
          </div>
          <h1 className="text-2xl font-black tracking-tight text-white flex items-center gap-3">
            <TrendingUp className="w-7 h-7 text-cyan-400" />
            <span>Academic Progress & Growth Analytics</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            Real-time multi-term performance tracking, subject-wise trajectory analysis, attendance correlation benchmarks, and honor milestones.
          </p>
        </div>

        <div className="flex items-center flex-wrap gap-2.5">
          <button
            id="refresh-progress-btn"
            onClick={() => loadData(true)}
            disabled={refreshing || loading}
            className="px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300 hover:text-white text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin text-cyan-400' : ''}`} />
            <span>{refreshing ? 'Recalculating...' : 'Recalculate'}</span>
          </button>

          {onNavigate && (
            <>
              <button
                onClick={() => onNavigate('student-results')}
                className="px-3.5 py-2 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 border border-emerald-500/30 text-emerald-300 text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
              >
                <Award className="w-3.5 h-3.5" />
                <span>View Term Marks</span>
              </button>

              <button
                onClick={() => onNavigate('student-attendance')}
                className="px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300 hover:text-white text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
              >
                <CheckSquare className="w-3.5 h-3.5 text-indigo-400" />
                <span>Attendance Log</span>
              </button>
            </>
          )}
        </div>
      </div>

      {loading ? (
        <div className="p-16 flex flex-col items-center justify-center bg-slate-900/30 border border-white/10 rounded-2xl">
          <LoadingSpinner size="lg" />
          <p className="text-xs text-slate-400 mt-4 font-medium">Computing longitudinal performance trends...</p>
        </div>
      ) : error ? (
        <div className="p-8 bg-rose-500/10 border border-rose-500/20 rounded-2xl flex items-start gap-4 text-rose-300">
          <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
          <div>
            <h3 className="text-sm font-bold text-rose-200">Unable to generate academic progress</h3>
            <p className="text-xs mt-1">{error}</p>
            <button
              onClick={() => loadData()}
              className="mt-3 px-3 py-1.5 bg-rose-500/20 hover:bg-rose-500/30 text-rose-200 rounded-lg text-xs font-semibold transition-all cursor-pointer"
            >
              Retry Analysis
            </button>
          </div>
        </div>
      ) : !progressData ? (
        <EmptyState
          icon={TrendingUp}
          title="No Progress Analytics Available"
          description="Insufficient published test records exist to formulate longitudinal trajectory trends."
        />
      ) : (
        <div className="space-y-6">
          {/* Top KPI Metrics Row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Cumulative GPA */}
            <div className="bg-slate-900/40 border border-white/10 p-5 rounded-2xl backdrop-blur-md">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Cumulative GPA</span>
                <Award className="w-4 h-4 text-cyan-400" />
              </div>
              <div className="text-3xl font-black text-cyan-300 flex items-baseline gap-1.5">
                <span>{Number(progressData?.metrics?.cumulativeGPA ?? 0).toFixed(2)}</span>
                <span className="text-xs font-semibold text-slate-400">/ 4.00</span>
              </div>
              <div className="mt-2 flex items-center gap-2 text-xs">
                <span className={`px-2 py-0.5 rounded-md font-bold text-[11px] border ${getGradeColor(progressData.metrics.overallGrade)}`}>
                  Grade {progressData.metrics.overallGrade}
                </span>
                <span className="text-[11px] text-slate-400">Latest Term: {Number(progressData?.metrics?.currentGPA ?? 0).toFixed(2)} GP</span>
              </div>
            </div>

            {/* Academic Standing */}
            <div className="bg-slate-900/40 border border-white/10 p-5 rounded-2xl backdrop-blur-md">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Academic Standing</span>
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
              </div>
              <div className="text-lg font-black text-white mt-1 leading-snug">
                {progressData.metrics.academicStanding}
              </div>
              <p className="text-[11px] text-slate-400 mt-2">
                Top percentile cohort tier
              </p>
            </div>

            {/* Total Credits & Terms */}
            <div className="bg-slate-900/40 border border-white/10 p-5 rounded-2xl backdrop-blur-md">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Completed Credits</span>
                <BookOpen className="w-4 h-4 text-indigo-400" />
              </div>
              <div className="text-3xl font-black text-indigo-300 flex items-baseline gap-1.5">
                <span>{progressData.metrics.totalCreditsCompleted}</span>
                <span className="text-xs font-semibold text-slate-400">Credits</span>
              </div>
              <p className="text-[11px] text-slate-400 mt-2">
                Across {progressData.metrics.totalExamsTaken} evaluated exam terms
              </p>
            </div>

            {/* Peak Assessment Score */}
            <div className="bg-slate-900/40 border border-white/10 p-5 rounded-2xl backdrop-blur-md">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Highest Peak Score</span>
                <Flame className="w-4 h-4 text-amber-400" />
              </div>
              <div className="text-3xl font-black text-amber-300 flex items-baseline gap-1.5">
                <span>{progressData.metrics.highestPercentage}%</span>
              </div>
              <p className="text-[11px] text-slate-400 mt-2">
                Maximum term aggregate percentage
              </p>
            </div>
          </div>

          {/* Attendance vs Performance Correlation Card */}
          <div className="bg-gradient-to-r from-slate-900/90 via-indigo-950/40 to-slate-900/90 border border-indigo-500/20 p-6 rounded-2xl backdrop-blur-xl shadow-xl">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
                  <BarChart3 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white flex items-center gap-2">
                    <span>Attendance vs. Academic Mastery Correlation</span>
                    <Badge variant="primary" size="sm">
                      {progressData.attendancePerformanceCorrelation.correlationRating}
                    </Badge>
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Analyzing the direct relationship between classroom presence and test outcomes
                  </p>
                </div>
              </div>

              {/* Progress Benchmarks Comparison */}
              <div className="flex items-center gap-6 bg-slate-950/60 border border-white/10 px-5 py-3 rounded-xl">
                <div>
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Class Attendance</span>
                  <div className="text-xl font-black text-emerald-300">
                    {progressData.attendanceSummary?.attendancePercentage ?? 0}%
                  </div>
                  <span className="text-[10px] text-slate-400">
                    {progressData.attendanceSummary?.presentCount ?? 0} Days Present
                  </span>
                </div>
                <div className="h-8 w-px bg-white/10" />
                <div>
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Academic Average</span>
                  <div className="text-xl font-black text-cyan-300">
                    {progressData.attendancePerformanceCorrelation?.academicPercentage ?? 0}%
                  </div>
                  <span className="text-[10px] text-slate-400">Term Mean Score</span>
                </div>
              </div>
            </div>

            {/* Contextual Guidance Insight */}
            <div className="bg-slate-950/50 border border-white/5 p-4 rounded-xl flex items-start gap-3">
              <Sparkles className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
              <p className="text-xs text-slate-300 leading-relaxed">
                {progressData.attendancePerformanceCorrelation.insightText}
              </p>
            </div>
          </div>

          {/* Subject-Wise Trajectory & Historical Score Table */}
          <div className="bg-slate-900/50 border border-white/10 p-6 rounded-2xl backdrop-blur-xl shadow-xl">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <BookOpen className="w-5 h-5 text-indigo-400" />
                  <span>Subject Performance Trajectory</span>
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Aggregated historical test performance, grade point averages, and improvement dynamics per subject.
                </p>
              </div>
              <span className="text-xs text-slate-400 font-mono">
                {progressData?.subjectPerformances?.length || 0} Subjects Evaluated
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-white/10 text-[11px] font-bold uppercase tracking-wider text-slate-400">
                    <th className="py-3 px-3">Subject & Code</th>
                    <th className="py-3 px-3 text-center">Credits</th>
                    <th className="py-3 px-3 text-center">Historical Average</th>
                    <th className="py-3 px-3 text-center">Highest Score</th>
                    <th className="py-3 px-3 text-center">Latest Grade</th>
                    <th className="py-3 px-3 text-center">Trajectory Trend</th>
                    <th className="py-3 px-3 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5 text-xs text-slate-300">
                  {(progressData.subjectPerformances || []).map((subj) => (
                    <tr key={subj.subjectId} className="hover:bg-white/[0.02] transition-colors">
                      <td className="py-3.5 px-3">
                        <div className="font-bold text-white">{subj.subjectName}</div>
                        <div className="text-[11px] font-mono text-indigo-300">{subj.subjectCode}</div>
                      </td>
                      <td className="py-3.5 px-3 text-center font-mono text-slate-400">{subj.credits}</td>
                      <td className="py-3.5 px-3 text-center">
                        <span className="font-bold text-white">{subj.averageMarks}%</span>
                        <div className="w-16 bg-white/10 h-1 rounded-full mx-auto mt-1 overflow-hidden">
                          <div
                            className="bg-indigo-400 h-full rounded-full"
                            style={{ width: `${Math.min(subj.averageMarks, 100)}%` }}
                          />
                        </div>
                      </td>
                      <td className="py-3.5 px-3 text-center font-mono font-bold text-emerald-300">
                        {subj.highestMarks} Pts
                      </td>
                      <td className="py-3.5 px-3 text-center">
                        <span className={`px-2 py-0.5 rounded-md font-bold text-xs border ${getGradeColor(subj.latestGrade)}`}>
                          {subj.latestGrade} ({Number(subj?.latestGradePoint ?? 0).toFixed(1)})
                        </span>
                      </td>
                      <td className="py-3.5 px-3 text-center">
                        {getTrendBadge(subj.trend, subj.trendDelta)}
                      </td>
                      <td className="py-3.5 px-3 text-right">
                        <button
                          onClick={() => setInspectedSubject(subj)}
                          className="px-2.5 py-1.5 rounded-lg bg-white/5 hover:bg-white/15 text-slate-200 hover:text-white font-semibold transition-all inline-flex items-center gap-1 cursor-pointer"
                        >
                          <Eye className="w-3 h-3 text-indigo-400" />
                          <span>History</span>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Exam-Wise Chronological Evolution */}
          <div className="bg-slate-900/50 border border-white/10 p-6 rounded-2xl backdrop-blur-xl shadow-xl">
            <h3 className="text-base font-bold text-white flex items-center gap-2 mb-4">
              <Clock className="w-5 h-5 text-emerald-400" />
              <span>Exam-Wise Historical Evolution</span>
            </h3>

            <div className="space-y-3">
              {(progressData.examWiseTrends || []).map((exam, idx) => (
                <div
                  key={exam.examId}
                  className="bg-slate-950/40 border border-white/5 hover:border-white/15 p-4 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-4 transition-all"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-mono text-slate-400 uppercase">
                        {exam.academicSessionName} • {exam.academicYear}
                      </span>
                      <Badge variant={exam.resultStatus === 'PASS' ? 'success' : 'primary'} size="sm">
                        {exam.resultStatus}
                      </Badge>
                    </div>
                    <h4 className="text-sm font-bold text-white">{exam.examName}</h4>
                    <p className="text-xs text-slate-400">
                      Total Marks: {exam.totalObtainedMarks} / {exam.totalFullMarks}
                    </p>
                  </div>

                  {/* Percentage Bar & Score Pill */}
                  <div className="flex items-center gap-4">
                    <div className="w-36 hidden sm:block">
                      <div className="flex justify-between text-[10px] text-slate-400 font-semibold mb-1">
                        <span>Score</span>
                        <span className="text-white font-bold">{exam.overallPercentage}%</span>
                      </div>
                      <div className="w-full bg-white/10 h-2 rounded-full overflow-hidden">
                        <div
                          className="bg-emerald-400 h-full rounded-full transition-all duration-500"
                          style={{ width: `${Math.min(exam.overallPercentage, 100)}%` }}
                        />
                      </div>
                    </div>

                    <div className="text-right">
                      <span className="text-xs font-mono font-bold text-emerald-300 block">
                        {Number(exam?.gpa ?? 0).toFixed(2)} GPA
                      </span>
                      <span className={`px-2 py-0.5 rounded-md font-bold text-[10px] border inline-block mt-0.5 ${getGradeColor(exam.overallGrade)}`}>
                        Grade {exam.overallGrade}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Highlights & Accolades Row */}
          {((progressData?.improvementHighlights?.length || 0) > 0) && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {(progressData.improvementHighlights || []).map((hl) => (
                <div
                  key={hl.id}
                  className="bg-slate-900/40 border border-white/10 p-5 rounded-2xl backdrop-blur-md space-y-2 relative overflow-hidden"
                >
                  <div className="flex items-center gap-2 text-amber-400">
                    <Star className="w-4 h-4 fill-amber-400" />
                    <span className="text-[11px] font-bold uppercase tracking-wider text-amber-300">
                      {hl.type === 'milestone' ? 'Academic Distinction' : 'Performance Breakthrough'}
                    </span>
                  </div>
                  <h4 className="text-sm font-bold text-white">{hl.title}</h4>
                  <p className="text-xs text-slate-300 leading-relaxed">{hl.description}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Modal: Subject Historical Examination Drilldown */}
      <Modal
        isOpen={!!inspectedSubject}
        onClose={() => setInspectedSubject(null)}
        title={
          <div className="flex items-center gap-2.5">
            <BookOpen className="w-5 h-5 text-indigo-400" />
            <span className="text-base font-bold text-white">
              {inspectedSubject?.subjectName} ({inspectedSubject?.subjectCode}) — Historical Score Breakdown
            </span>
          </div>
        }
        size="lg"
      >
        {inspectedSubject && (
          <div className="space-y-5">
            {/* Subject Summary Row */}
            <div className="grid grid-cols-3 gap-3 bg-slate-950/60 border border-white/10 p-4 rounded-xl text-xs">
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-bold block">Historical Average</span>
                <span className="text-lg font-black text-white mt-0.5 block">{inspectedSubject.averageMarks}%</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-bold block">Highest Score</span>
                <span className="text-lg font-black text-emerald-300 mt-0.5 block">{inspectedSubject.highestMarks} Pts</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-bold block">Trajectory</span>
                <div className="mt-1">{getTrendBadge(inspectedSubject.trend, inspectedSubject.trendDelta)}</div>
              </div>
            </div>

            {/* Exam-by-exam history table */}
            <div className="border border-white/10 rounded-xl overflow-hidden">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-950 border-b border-white/10 text-[10px] font-bold uppercase text-slate-400">
                    <th className="py-2.5 px-3">Examination Session</th>
                    <th className="py-2.5 px-3 text-center">Marks</th>
                    <th className="py-2.5 px-3 text-center">Percentage</th>
                    <th className="py-2.5 px-3 text-center">Grade</th>
                    <th className="py-2.5 px-3 text-center">Grade Point</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5 text-slate-300">
                  {(inspectedSubject.examHistory || []).map((h, i) => (
                    <tr key={i} className="hover:bg-white/[0.02]">
                      <td className="py-2.5 px-3">
                        <div className="font-semibold text-white">{h.examName}</div>
                        <div className="text-[10px] text-slate-400">{h.academicSessionName}</div>
                      </td>
                      <td className="py-2.5 px-3 text-center font-mono">
                        {h.obtainedMarks} / {h.fullMarks}
                      </td>
                      <td className="py-2.5 px-3 text-center font-bold text-white">{h.percentage}%</td>
                      <td className="py-2.5 px-3 text-center">
                        <span className={`px-2 py-0.5 rounded-md font-bold text-[10px] border ${getGradeColor(h.grade)}`}>
                          {h.grade}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-center font-mono text-emerald-300 font-bold">
                        {Number(h?.gradePoint ?? 0).toFixed(2)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="flex justify-end pt-3 border-t border-white/10">
              <button
                onClick={() => setInspectedSubject(null)}
                className="px-4 py-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-xs font-semibold text-slate-300 hover:text-white transition-all cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};
