import React, { useEffect, useState } from 'react';
import {
  Layers,
  GraduationCap,
  Calendar,
  Building,
  Hash,
  Sparkles,
  BookOpen,
  Award,
  Clock,
  CheckCircle2,
  AlertCircle,
  FileCheck2,
  TrendingUp,
  BarChart3,
  ShieldCheck,
  ArrowRight,
  History
} from 'lucide-react';
import { Badge } from '../../components/ui/Badge.js';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner.js';
import { api } from '../../services/api.js';
import { StudentAcademicInfoData } from '../../types/index.js';
import { StudentAcademicTimelineModal } from '../../components/promotions/StudentAcademicTimelineModal.js';

interface StudentAcademicInfoPageProps {
  onNavigate?: (view: string) => void;
}

export const StudentAcademicInfoPage: React.FC<StudentAcademicInfoPageProps> = ({ onNavigate }) => {
  const [data, setData] = useState<StudentAcademicInfoData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showTimelineModal, setShowTimelineModal] = useState(false);

  useEffect(() => {
    const fetchAcademicInfo = async () => {
      try {
        setLoading(true);
        setError(null);
        const res = await api.getMyAcademicInfo();
        if (res.success && res.data) {
          setData(res.data);
        } else {
          setError(res.error || 'Failed to load institutional academic records.');
        }
      } catch (err: any) {
        console.error('Error fetching academic info:', err);
        setError(err.message || 'Network error fetching academic information.');
      } finally {
        setLoading(false);
      }
    };

    fetchAcademicInfo();
  }, []);

  if (loading) {
    return (
      <div className="py-24 flex flex-col items-center justify-center">
        <LoadingSpinner size="lg" message="Loading your comprehensive academic profile..." />
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="p-8 max-w-2xl mx-auto bg-rose-500/10 border border-rose-500/20 rounded-3xl text-center space-y-4">
        <AlertCircle className="w-12 h-12 text-rose-400 mx-auto" />
        <h3 className="text-xl font-bold text-white">Unable to Load Academic Information</h3>
        <p className="text-sm text-slate-300">{error || 'Academic record is temporarily unavailable.'}</p>
        <button
          onClick={() => window.location.reload()}
          className="px-5 py-2.5 bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold rounded-xl transition-all"
        >
          Retry Connection
        </button>
      </div>
    );
  }

  const { student, academicSession, schoolClass, section, subjects, summary, futureRoadmap } = data;

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Top Banner */}
      <div className="relative overflow-hidden bg-gradient-to-br from-purple-950/60 via-slate-900/80 to-indigo-950/50 backdrop-blur-xl border border-white/10 rounded-3xl p-6 sm:p-8 shadow-2xl shadow-black/40">
        <div className="absolute top-0 right-0 w-80 h-80 bg-purple-500/10 rounded-full blur-3xl pointer-events-none -mr-16 -mt-16" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-purple-400 text-xs font-bold uppercase tracking-wider">
              <Layers className="w-4 h-4" />
              <span>Comprehensive Institutional Record</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">Academic Information</h1>
            <p className="text-sm text-slate-300 max-w-2xl">
              Official institutional standing, curriculum credit audit, and session advancement credentials for{' '}
              <strong className="text-white">{student.fullName}</strong>.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => setShowTimelineModal(true)}
              className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white rounded-2xl flex items-center gap-2 text-xs font-bold transition-all shadow-lg shadow-purple-600/20"
            >
              <History className="w-4 h-4" />
              <span>View Academic Lifecycle & History</span>
            </button>
            <div className="px-4 py-2 bg-purple-500/15 border border-purple-500/30 rounded-2xl flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-purple-300" />
              <span className="text-xs font-bold text-purple-200">Verified Academic Record</span>
            </div>
          </div>
        </div>
      </div>

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-5 shadow-lg shadow-black/20">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">Current Session</span>
            <div className="p-2.5 bg-purple-500/15 rounded-xl text-purple-400">
              <Calendar className="w-5 h-5" />
            </div>
          </div>
          <p className="text-xl font-bold text-white mt-2">{academicSession.sessionName}</p>
          <p className="text-xs text-emerald-400 mt-1 font-mono">Active Term 2026-2027</p>
        </div>

        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-5 shadow-lg shadow-black/20">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">Class &amp; Section</span>
            <div className="p-2.5 bg-indigo-500/15 rounded-xl text-indigo-400">
              <GraduationCap className="w-5 h-5" />
            </div>
          </div>
          <p className="text-xl font-bold text-white mt-2">{schoolClass.name}</p>
          <p className="text-xs text-slate-400 mt-1">{section.name} • {section.roomNumber}</p>
        </div>

        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-5 shadow-lg shadow-black/20">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">Total Modules</span>
            <div className="p-2.5 bg-emerald-500/15 rounded-xl text-emerald-400">
              <BookOpen className="w-5 h-5" />
            </div>
          </div>
          <p className="text-xl font-bold text-white mt-2">{summary.totalSubjects} Subjects</p>
          <p className="text-xs text-slate-400 mt-1">{summary.coreSubjectsCount} Core • {summary.electiveSubjectsCount} Elective</p>
        </div>

        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-5 shadow-lg shadow-black/20">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">Earned Weight</span>
            <div className="p-2.5 bg-amber-500/15 rounded-xl text-amber-400">
              <Award className="w-5 h-5" />
            </div>
          </div>
          <p className="text-xl font-bold text-white mt-2">{summary.totalCredits} Credit Hours</p>
          <p className="text-xs text-emerald-400 mt-1">Full Curriculum Load</p>
        </div>
      </div>

      {/* Institutional Details Table */}
      <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-6 sm:p-8 shadow-xl shadow-black/25 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-4">
          <div>
            <h3 className="text-lg font-bold text-white">Current Academic Curriculum</h3>
            <p className="text-xs text-slate-400">Enrolled subjects and instructor accreditation</p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => onNavigate?.('student-subjects')}
              className="px-4 py-2 bg-indigo-600/20 hover:bg-indigo-600 text-indigo-300 hover:text-white border border-indigo-500/30 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5"
            >
              <span>Explore Course Materials</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-white/10 text-slate-400 uppercase font-mono tracking-wider text-[11px]">
                <th className="pb-3 px-3">Subject Code</th>
                <th className="pb-3 px-3">Subject Title</th>
                <th className="pb-3 px-3">Type</th>
                <th className="pb-3 px-3">Credits</th>
                <th className="pb-3 px-3">Department</th>
                <th className="pb-3 px-3">Faculty Instructor</th>
                <th className="pb-3 px-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 font-sans text-slate-300">
              {(subjects || []).map((sub) => (
                <tr key={sub.id} className="hover:bg-white/5 transition-colors">
                  <td className="py-3 px-3 font-mono font-bold text-indigo-400">{sub.code}</td>
                  <td className="py-3 px-3 font-semibold text-white">{sub.name}</td>
                  <td className="py-3 px-3">
                    <span className="px-2 py-0.5 rounded uppercase font-bold text-[10px] bg-white/10 text-slate-300">
                      {sub.type}
                    </span>
                  </td>
                  <td className="py-3 px-3 font-mono">{sub.credits} hrs</td>
                  <td className="py-3 px-3 text-slate-400">{sub.departmentName}</td>
                  <td className="py-3 px-3 text-slate-200 font-medium">{sub.teacherName}</td>
                  <td className="py-3 px-3">
                    <span className="inline-flex items-center gap-1 text-emerald-400 font-semibold">
                      <CheckCircle2 className="w-3.5 h-3.5" /> Enrolled
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Institutional Progression & Future Roadmap Modules */}
      <div className="space-y-4">
        <div>
          <h3 className="text-base font-bold text-white">Academic Lifecycle &amp; Progress Roadmap</h3>
          <p className="text-xs text-slate-400">Institutional milestones scheduled across the academic term</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Card 1: Promotion & Advancement Standing */}
          <div className="p-6 bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-indigo-400 font-bold text-sm">
                <TrendingUp className="w-4 h-4" />
                <span>Session Promotion &amp; Advancement</span>
              </div>
              <Badge variant="info">IN PROGRESS</Badge>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              {futureRoadmap.promotionStatus}
            </p>
            <div className="p-3 bg-white/5 rounded-xl border border-white/5 text-[11px] text-slate-400">
              {futureRoadmap.promotionNotes}
            </div>
          </div>

          {/* Card 2: Attendance Registry */}
          <div className="p-6 bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
                <Clock className="w-4 h-4" />
                <span>Attendance Log Compliance</span>
              </div>
              <Badge variant="success">RECORDED DAILY</Badge>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              {futureRoadmap.attendanceSummaryStatus}
            </p>
            <div className="p-3 bg-white/5 rounded-xl border border-white/5 text-[11px] text-slate-400">
              Automated institutional attendance synchronization is active. Formal term summaries update weekly.
            </div>
          </div>

          {/* Card 3: Examination & Term Assessments */}
          <div className="p-6 bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-amber-400 font-bold text-sm">
                <FileCheck2 className="w-4 h-4" />
                <span>Examinations &amp; Term Testing</span>
              </div>
              <Badge variant="warning">TERM 1 SCHEDULED</Badge>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              {futureRoadmap.examinationStatus}
            </p>
            <div className="p-3 bg-white/5 rounded-xl border border-white/5 text-[11px] text-slate-400">
              Standardized examination seating, admit cards, and schedules will publish ahead of the testing window.
            </div>
          </div>

          {/* Card 4: Evaluation & Report Cards */}
          <div className="p-6 bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-purple-400 font-bold text-sm">
                <BarChart3 className="w-4 h-4" />
                <span>Results &amp; Academic Transcript</span>
              </div>
              <Badge variant="neutral">EVALUATION PENDING</Badge>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              {futureRoadmap.resultsStatus}
            </p>
            <div className="p-3 bg-white/5 rounded-xl border border-white/5 text-[11px] text-slate-400">
              Grade points, letter grades, and academic honors will be tabulated following term completion.
            </div>
          </div>
        </div>
      </div>

      {showTimelineModal && student && (
        <StudentAcademicTimelineModal
          studentId={student.id}
          onClose={() => setShowTimelineModal(false)}
        />
      )}
    </div>
  );
};
