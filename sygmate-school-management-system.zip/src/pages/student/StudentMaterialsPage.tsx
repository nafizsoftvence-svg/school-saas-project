import React, { useEffect, useState, useMemo } from 'react';
import {
  BookOpen,
  Search,
  Filter,
  Download,
  FileText,
  User,
  AlertCircle,
  RefreshCw,
  Eye,
  Calendar,
  Layers,
  FolderOpen,
  FileCode,
  FileSpreadsheet,
  FileArchive,
  Image as ImageIcon,
  ChevronRight,
  ExternalLink,
  Sparkles,
  Info
} from 'lucide-react';
import { Badge } from '../../components/ui/Badge.js';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner.js';
import { Modal } from '../../components/ui/Modal.js';
import { EmptyState } from '../../components/ui/EmptyState.js';
import { api } from '../../services/api.js';
import {
  StudyMaterial,
  StudentEnrolledSubject,
  StudentClassInfo
} from '../../types/index.js';

interface StudentMaterialsPageProps {
  onNavigate?: (view: string) => void;
}

export const StudentMaterialsPage: React.FC<StudentMaterialsPageProps> = ({ onNavigate }) => {
  const [materials, setMaterials] = useState<StudyMaterial[]>([]);
  const [subjects, setSubjects] = useState<StudentEnrolledSubject[]>([]);
  const [classInfo, setClassInfo] = useState<StudentClassInfo | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Filters
  const [searchTerm, setSearchTerm] = useState('');
  const [subjectFilter, setSubjectFilter] = useState<string>('ALL');
  const [fileTypeFilter, setFileTypeFilter] = useState<string>('ALL');
  const [viewMode, setViewMode] = useState<'grid' | 'by_subject'>('grid');

  // Modal inspection & Document viewer
  const [selectedMaterial, setSelectedMaterial] = useState<StudyMaterial | null>(null);
  const [previewFile, setPreviewFile] = useState<StudyMaterial | null>(null);

  const loadData = async (isManualRefresh = false) => {
    try {
      if (isManualRefresh) setRefreshing(true);
      else setLoading(true);
      setError(null);

      const [matRes, subjRes, classRes] = await Promise.all([
        api.getMyMaterials({
          subjectId: subjectFilter !== 'ALL' ? subjectFilter : undefined,
          fileType: fileTypeFilter !== 'ALL' ? fileTypeFilter : undefined,
          search: searchTerm || undefined
        }),
        api.getMyEnrolledSubjects(),
        api.getMyClassInfo()
      ]);

      if (matRes.success && matRes.data) {
        setMaterials(matRes.data);
      } else {
        setError(matRes.error || 'Failed to load study materials.');
      }

      if (subjRes.success && subjRes.data) {
        setSubjects(subjRes.data);
      }

      if (classRes.success && classRes.data) {
        setClassInfo(classRes.data);
      }
    } catch (err: any) {
      console.error('Error fetching student study materials:', err);
      setError(err.message || 'Network error while retrieving materials.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [subjectFilter, fileTypeFilter]);

  const filteredMaterials = useMemo(() => {
    let list = [...materials];

    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase().trim();
      list = list.filter(
        (m) =>
          (m.title || '').toLowerCase().includes(q) ||
          (m.description ? m.description.toLowerCase().includes(q) : false) ||
          (m.subjectName || '').toLowerCase().includes(q) ||
          (m.teacherName || '').toLowerCase().includes(q) ||
          (m.fileName || '').toLowerCase().includes(q)
      );
    }

    return list;
  }, [materials, searchTerm]);

  // Group by Subject for grouped view
  const materialsBySubject = useMemo(() => {
    const map: Record<string, StudyMaterial[]> = {};
    filteredMaterials.forEach((m) => {
      if (!map[m.subjectName]) {
        map[m.subjectName] = [];
      }
      map[m.subjectName].push(m);
    });
    return map;
  }, [filteredMaterials]);

  const getFileIcon = (fileType?: string, fileName?: string) => {
    const ft = (fileType || '').toLowerCase();
    const fn = (fileName || '').toLowerCase();

    if (ft.includes('pdf') || fn.endsWith('.pdf')) {
      return <FileText className="w-5 h-5 text-rose-400" />;
    }
    if (ft.includes('doc') || fn.endsWith('.docx') || fn.endsWith('.doc')) {
      return <FileText className="w-5 h-5 text-blue-400" />;
    }
    if (ft.includes('ppt') || fn.endsWith('.pptx') || fn.endsWith('.ppt')) {
      return <FileSpreadsheet className="w-5 h-5 text-amber-400" />;
    }
    if (ft.includes('zip') || ft.includes('rar') || fn.endsWith('.zip')) {
      return <FileArchive className="w-5 h-5 text-purple-400" />;
    }
    if (ft.includes('img') || ft.includes('jpg') || ft.includes('png') || fn.endsWith('.png')) {
      return <ImageIcon className="w-5 h-5 text-emerald-400" />;
    }
    return <FileCode className="w-5 h-5 text-indigo-400" />;
  };

  const getFileTypeColor = (fileType?: string) => {
    const ft = (fileType || '').toLowerCase();
    if (ft.includes('pdf')) return 'danger';
    if (ft.includes('doc')) return 'info';
    if (ft.includes('ppt')) return 'warning';
    if (ft.includes('zip')) return 'secondary';
    if (ft.includes('img') || ft.includes('png')) return 'success';
    return 'primary';
  };

  return (
    <div id="student-materials-page" className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900/60 backdrop-blur-xl p-6 rounded-2xl border border-white/10 shadow-xl relative overflow-hidden">
        <div className="absolute -right-16 -top-16 w-56 h-56 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10">
          <div className="flex items-center gap-2 text-emerald-400 text-xs font-semibold uppercase tracking-wider mb-1">
            <BookOpen className="w-4 h-4" />
            <span>Digital Learning Repository</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight flex items-center gap-3">
            Study Materials
            {classInfo && (
              <span className="text-xs font-normal px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                {classInfo.schoolClass.name} • {classInfo.section.name}
              </span>
            )}
          </h1>
          <p className="text-sm text-slate-400 mt-1 max-w-2xl">
            Download and study lecture slides, reading chapters, formula cheat-sheets, and supplementary resources curated by your subject faculty.
          </p>
        </div>

        <div className="flex items-center gap-3 relative z-10 self-start md:self-auto">
          <button
            id="materials-refresh-btn"
            onClick={() => loadData(true)}
            disabled={refreshing}
            className="flex items-center gap-2 px-3.5 py-2 text-xs font-medium text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-700/80 border border-white/10 rounded-xl transition-all disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin' : ''}`} />
            <span>{refreshing ? 'Refreshing...' : 'Refresh'}</span>
          </button>
          {onNavigate && (
            <button
              onClick={() => onNavigate('student-homework')}
              className="flex items-center gap-2 px-3.5 py-2 text-xs font-medium text-emerald-300 hover:text-emerald-200 bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/30 rounded-xl transition-all"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Homework</span>
            </button>
          )}
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-slate-900/40 backdrop-blur-md p-4 rounded-2xl border border-white/10 flex flex-col md:flex-row gap-3 items-center justify-between">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search materials, topics, teacher, files..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-950/60 border border-white/10 text-white placeholder-slate-500 text-xs rounded-xl pl-9 pr-4 py-2.5 focus:outline-none focus:border-emerald-500/50 transition-colors"
          />
          {searchTerm && (
            <button
              onClick={() => setSearchTerm('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white text-xs"
            >
              &times;
            </button>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto">
          {/* Subject Filter */}
          <div className="flex items-center gap-1.5 bg-slate-950/60 border border-white/10 rounded-xl px-3 py-1.5">
            <BookOpen className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={subjectFilter}
              onChange={(e) => setSubjectFilter(e.target.value)}
              className="bg-transparent text-xs text-white focus:outline-none cursor-pointer"
            >
              <option value="ALL" className="bg-slate-900 text-white">All Subjects</option>
              {(subjects || []).map((s) => (
                <option key={s.id} value={s.id} className="bg-slate-900 text-white">
                  {s.name}
                </option>
              ))}
            </select>
          </div>

          {/* File Type Filter */}
          <div className="flex items-center gap-1.5 bg-slate-950/60 border border-white/10 rounded-xl px-3 py-1.5">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={fileTypeFilter}
              onChange={(e) => setFileTypeFilter(e.target.value)}
              className="bg-transparent text-xs text-white focus:outline-none cursor-pointer"
            >
              <option value="ALL" className="bg-slate-900 text-white">All File Formats</option>
              <option value="pdf" className="bg-slate-900 text-white">PDF Documents</option>
              <option value="docx" className="bg-slate-900 text-white">Word Documents</option>
              <option value="pptx" className="bg-slate-900 text-white">PowerPoint Slides</option>
              <option value="zip" className="bg-slate-900 text-white">ZIP Archives</option>
              <option value="image" className="bg-slate-900 text-white">Images / Diagrams</option>
            </select>
          </div>

          {/* View Toggle */}
          <div className="flex items-center bg-slate-950/60 border border-white/10 rounded-xl p-0.5">
            <button
              onClick={() => setViewMode('grid')}
              className={`px-3 py-1 text-xs rounded-lg transition-all ${
                viewMode === 'grid'
                  ? 'bg-emerald-600 text-white font-semibold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              All Files ({filteredMaterials.length})
            </button>
            <button
              onClick={() => setViewMode('by_subject')}
              className={`px-3 py-1 text-xs rounded-lg transition-all ${
                viewMode === 'by_subject'
                  ? 'bg-emerald-600 text-white font-semibold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              By Subject ({Object.keys(materialsBySubject).length})
            </button>
          </div>
        </div>
      </div>

      {/* Error state */}
      {error && (
        <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-sm flex items-center gap-3">
          <AlertCircle className="w-5 h-5 shrink-0" />
          <span>{error}</span>
          <button
            onClick={() => loadData()}
            className="ml-auto text-xs underline hover:text-white"
          >
            Retry
          </button>
        </div>
      )}

      {/* Main Content */}
      {loading ? (
        <div className="py-20 flex flex-col items-center justify-center gap-3">
          <LoadingSpinner size="lg" />
          <p className="text-sm text-slate-400">Loading learning repository...</p>
        </div>
      ) : filteredMaterials.length === 0 ? (
        <EmptyState
          icon={FolderOpen}
          title="No Study Materials Found"
          description={
            searchTerm || subjectFilter !== 'ALL' || fileTypeFilter !== 'ALL'
              ? 'No learning resources match your current search and filter criteria.'
              : 'Your faculty has not uploaded study materials for this cohort yet. Check back soon.'
          }
          action={
            searchTerm || subjectFilter !== 'ALL' || fileTypeFilter !== 'ALL' ? (
              <button
                onClick={() => {
                  setSearchTerm('');
                  setSubjectFilter('ALL');
                  setFileTypeFilter('ALL');
                }}
                className="px-4 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-xl transition-all"
              >
                Reset Filters
              </button>
            ) : undefined
          }
        />
      ) : viewMode === 'by_subject' ? (
        /* Subject Grouped View */
        <div className="space-y-6">
          {(Object.entries(materialsBySubject) as [string, StudyMaterial[]][]).map(([subjectName, items]) => (
            <div key={subjectName} className="space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-white/10">
                <div className="flex items-center gap-2">
                  <FolderOpen className="w-4 h-4 text-emerald-400" />
                  <h2 className="text-base font-bold text-white">{subjectName}</h2>
                  <span className="text-xs px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-white/10">
                    {items.length} {items.length === 1 ? 'file' : 'files'}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {(items || []).map((item) => (
                  <div
                    key={item.id}
                    className="p-4 rounded-2xl bg-slate-900/50 border border-white/10 hover:border-emerald-500/40 backdrop-blur-md flex flex-col justify-between transition-all group"
                  >
                    <div>
                      <div className="flex items-center justify-between gap-2 mb-2">
                        <div className="flex items-center gap-2">
                          <div className="p-2 rounded-xl bg-slate-950 border border-white/10">
                            {getFileIcon(item.fileType, item.fileName)}
                          </div>
                          <Badge variant={getFileTypeColor(item.fileType) as any} size="sm">
                            {item.fileType ? item.fileType.toUpperCase() : 'FILE'}
                          </Badge>
                        </div>
                        <span className="text-[11px] text-slate-400">{item.fileSize || '1.5 MB'}</span>
                      </div>

                      <h3 className="text-sm font-bold text-white group-hover:text-emerald-300 transition-colors line-clamp-1 mb-1">
                        {item.title}
                      </h3>
                      <p className="text-xs text-slate-400 line-clamp-2 mb-3">
                        {item.description}
                      </p>
                    </div>

                    <div className="pt-3 border-t border-white/5 space-y-2.5">
                      <div className="flex items-center justify-between text-[11px] text-slate-400">
                        <span className="truncate max-w-[120px]">{item.teacherName}</span>
                        <span>{item.uploadDate}</span>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => setSelectedMaterial(item)}
                          className="flex-1 py-1.5 px-2.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg border border-white/5 transition-colors flex items-center justify-center gap-1"
                        >
                          <Eye className="w-3 h-3" />
                          <span>Details</span>
                        </button>
                        <button
                          onClick={() => setPreviewFile(item)}
                          className="flex-1 py-1.5 px-2.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg transition-colors flex items-center justify-center gap-1"
                        >
                          <Download className="w-3 h-3" />
                          <span>Download</span>
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      ) : (
        /* Unified Grid View */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {(filteredMaterials || []).map((item) => (
            <div
              key={item.id}
              className="p-5 rounded-2xl bg-slate-900/50 border border-white/10 hover:border-emerald-500/40 backdrop-blur-md flex flex-col justify-between transition-all group"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-3">
                  <Badge variant="neutral" size="sm">
                    {item.subjectName}
                  </Badge>
                  <span className="text-[11px] text-slate-400">{item.fileSize || '2.0 MB'}</span>
                </div>

                <div className="flex items-start gap-3 mb-3">
                  <div className="p-2.5 rounded-xl bg-slate-950 border border-white/10 shrink-0">
                    {getFileIcon(item.fileType, item.fileName)}
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white group-hover:text-emerald-300 transition-colors line-clamp-2 mb-1">
                      {item.title}
                    </h3>
                    <div className="flex items-center gap-2">
                      <Badge variant={getFileTypeColor(item.fileType) as any} size="sm">
                        {item.fileType ? item.fileType.toUpperCase() : 'DOC'}
                      </Badge>
                      <span className="text-[11px] text-slate-400 truncate max-w-[130px]">{item.fileName}</span>
                    </div>
                  </div>
                </div>

                <p className="text-xs text-slate-400 line-clamp-2 mb-4 leading-relaxed">
                  {item.description}
                </p>
              </div>

              <div className="pt-3.5 border-t border-white/5 space-y-3">
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <div className="flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-slate-300 truncate max-w-[140px]">{item.teacherName}</span>
                  </div>
                  <span className="text-[11px] text-slate-500">
                    Uploaded: {item.uploadDate}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setSelectedMaterial(item)}
                    className="flex-1 py-2 px-3 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl border border-white/5 transition-colors flex items-center justify-center gap-1.5"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>View Info</span>
                  </button>
                  <button
                    onClick={() => setPreviewFile(item)}
                    className="flex-1 py-2 px-3 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-xl transition-colors flex items-center justify-center gap-1.5 shadow-sm"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Modal: Detailed Material Inspection */}
      {selectedMaterial && (
        <Modal
          isOpen={!!selectedMaterial}
          onClose={() => setSelectedMaterial(null)}
          title="Study Material Information"
          size="lg"
        >
          <div className="space-y-5">
            <div className="p-4 rounded-xl bg-slate-950/60 border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <Badge variant="neutral" size="sm" className="mb-1">
                  {selectedMaterial.subjectName}
                </Badge>
                <h2 className="text-lg font-bold text-white">{selectedMaterial.title}</h2>
              </div>
              <div className="text-right sm:border-l sm:border-white/10 sm:pl-4">
                <div className="text-[10px] uppercase tracking-wider text-slate-400">Class Cohort</div>
                <div className="text-xs font-semibold text-emerald-300">
                  {selectedMaterial.className} • {selectedMaterial.sectionName}
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5 text-emerald-400" />
                <span>Resource Summary & Faculty Notes</span>
              </label>
              <div className="p-4 rounded-xl bg-slate-900/80 border border-white/5 text-sm text-slate-200 leading-relaxed whitespace-pre-wrap">
                {selectedMaterial.description}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="p-3.5 rounded-xl bg-slate-950/40 border border-white/5 flex items-center gap-3">
                <User className="w-4 h-4 text-emerald-400 shrink-0" />
                <div>
                  <span className="text-slate-500 block text-[11px]">Instructor</span>
                  <span className="text-slate-200 font-semibold">{selectedMaterial.teacherName}</span>
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-950/40 border border-white/5 flex items-center gap-3">
                <Calendar className="w-4 h-4 text-emerald-400 shrink-0" />
                <div>
                  <span className="text-slate-500 block text-[11px]">Upload Date</span>
                  <span className="text-slate-200 font-semibold">{selectedMaterial.uploadDate}</span>
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-950/40 border border-white/5 flex items-center gap-3">
                <Layers className="w-4 h-4 text-emerald-400 shrink-0" />
                <div>
                  <span className="text-slate-500 block text-[11px]">File Format</span>
                  <span className="text-slate-200 font-semibold uppercase">{selectedMaterial.fileType || 'PDF'} Document ({selectedMaterial.fileSize || '2.4 MB'})</span>
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-950/40 border border-white/5 flex items-center gap-3">
                <FolderOpen className="w-4 h-4 text-emerald-400 shrink-0" />
                <div>
                  <span className="text-slate-500 block text-[11px]">File Name</span>
                  <span className="text-slate-200 font-semibold truncate block max-w-[180px]">{selectedMaterial.fileName}</span>
                </div>
              </div>
            </div>

            {/* Quick action bar */}
            <div className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-between">
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-9 h-9 rounded-lg bg-emerald-500/20 text-emerald-300 flex items-center justify-center shrink-0">
                  {getFileIcon(selectedMaterial.fileType, selectedMaterial.fileName)}
                </div>
                <div className="min-w-0">
                  <p className="text-xs font-semibold text-white truncate">{selectedMaterial.fileName}</p>
                  <p className="text-[11px] text-emerald-300/80">{selectedMaterial.fileSize || 'Standard Material'} • Verified</p>
                </div>
              </div>
              <button
                onClick={() => {
                  setSelectedMaterial(null);
                  setPreviewFile(selectedMaterial);
                }}
                className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg transition-colors shrink-0 ml-3"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Open & Download</span>
              </button>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-white/10">
              <button
                onClick={() => setSelectedMaterial(null)}
                className="px-4 py-2 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 rounded-xl transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* Modal: Document Viewer & Download */}
      {previewFile && (
        <Modal
          isOpen={!!previewFile}
          onClose={() => setPreviewFile(null)}
          title={`Resource: ${previewFile.fileName}`}
          size="lg"
        >
          <div className="space-y-4">
            <div className="p-4 rounded-xl bg-slate-950/60 border border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <FileText className="w-6 h-6 text-emerald-400" />
                <div>
                  <h4 className="text-sm font-semibold text-white">{previewFile.title}</h4>
                  <p className="text-xs text-slate-400">{previewFile.subjectName} • {previewFile.fileName}</p>
                </div>
              </div>
              <a
                href={previewFile.fileUrl}
                target="_blank"
                rel="noreferrer noopener"
                download={previewFile.fileName}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download File</span>
              </a>
            </div>

            <div className="h-72 rounded-xl bg-slate-950 border border-white/10 overflow-hidden flex flex-col items-center justify-center p-4 relative">
              {previewFile.fileUrl && previewFile.fileUrl.startsWith('http') ? (
                <img
                  src={previewFile.fileUrl}
                  alt={previewFile.title}
                  className="max-h-full max-w-full object-contain rounded-lg shadow-md"
                  referrerPolicy="no-referrer"
                />
              ) : (
                <div className="text-center space-y-2">
                  <FileText className="w-12 h-12 text-slate-600 mx-auto" />
                  <p className="text-xs text-slate-400">Institutional document ready for download to your device.</p>
                </div>
              )}
            </div>

            <div className="flex justify-end">
              <button
                onClick={() => setPreviewFile(null)}
                className="px-4 py-2 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 rounded-xl"
              >
                Close
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
