import React, { useState, useEffect } from 'react';
import {
  CreditCard,
  Receipt,
  Calendar,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Ban,
  Eye,
  RefreshCw,
  Printer,
  ShieldCheck,
  Building,
  DollarSign,
  ArrowDownRight
} from 'lucide-react';
import {
  StudentFeeRecord,
  StudentFeeSummaryStats,
  FeePaymentStatus,
  InvoiceDetailResponse
} from '../../types/index.js';
import { api } from '../../services/api.js';
import { useToast } from '../../context/ToastContext.js';
import { useAuth } from '../../context/AuthContext.js';
import { InvoiceViewModal } from '../../components/fees/InvoiceViewModal.js';
import { StudentStatementModal } from '../../components/fees/StudentStatementModal.js';
import { FileText } from 'lucide-react';

export const StudentFeesPage: React.FC = () => {
  const { user } = useAuth();
  const { showToast } = useToast();
  const [feeRecords, setFeeRecords] = useState<StudentFeeRecord[]>([]);
  const [summary, setSummary] = useState<StudentFeeSummaryStats | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [selectedStatusFilter, setSelectedStatusFilter] = useState<string>('ALL');

  // Statement modal
  const [isStatementModalOpen, setIsStatementModalOpen] = useState<boolean>(false);

  // Invoice modal
  const [selectedInvoice, setSelectedInvoice] = useState<InvoiceDetailResponse | null>(null);
  const [isInvoiceModalOpen, setIsInvoiceModalOpen] = useState<boolean>(false);
  const [isLoadingInvoice, setIsLoadingInvoice] = useState<boolean>(false);

  const fetchStudentFees = async () => {
    setIsLoading(true);
    try {
      const res = await api.student.getFees();
      const payload = (res as any)?.data || res;
      setFeeRecords(payload?.fees || payload?.data || (Array.isArray(payload) ? payload : []));
      setSummary(payload?.summary || null);
    } catch (err: any) {
      showToast(err.message || 'Failed to load your fee records', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchStudentFees();
  }, []);

  const handleOpenInvoice = async (invoiceNumber: string) => {
    setIsInvoiceModalOpen(true);
    setIsLoadingInvoice(true);
    try {
      const res = await api.student.getInvoice(invoiceNumber);
      const detail = (res as any)?.data || res;
      setSelectedInvoice(detail);
    } catch (err: any) {
      showToast(err.message || 'Failed to open invoice', 'error');
      setIsInvoiceModalOpen(false);
    } finally {
      setIsLoadingInvoice(false);
    }
  };

  const filteredRecords = feeRecords.filter((rec) => {
    if (selectedStatusFilter === 'ALL') return true;
    if (selectedStatusFilter === 'DUE') return rec.dueAmount > 0;
    if (selectedStatusFilter === 'PAID') return rec.status === 'PAID';
    if (selectedStatusFilter === 'OVERDUE') return rec.status === 'OVERDUE';
    return rec.status === selectedStatusFilter;
  });

  const renderStatusBadge = (record: StudentFeeRecord) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const isOverdue =
      record.status === 'OVERDUE' ||
      (new Date(record.dueDate) < today && record.dueAmount > 0 && record.status !== 'CANCELLED');

    if (record.status === 'PAID') {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
          <CheckCircle2 className="w-3 h-3" />
          PAID IN FULL
        </span>
      );
    }
    if (record.status === 'PARTIAL' || record.status === 'PARTIALLY_PAID') {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-amber-500/15 text-amber-400 border border-amber-500/30">
          <Clock className="w-3 h-3" />
          PARTIALLY PAID
        </span>
      );
    }
    if (isOverdue) {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-rose-500/15 text-rose-400 border border-rose-500/30">
          <AlertTriangle className="w-3 h-3" />
          OVERDUE
        </span>
      );
    }
    if (record.status === 'CANCELLED') {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-gray-500/15 text-gray-400 border border-gray-500/30 line-through">
          <Ban className="w-3 h-3" />
          CANCELLED
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-indigo-500/15 text-indigo-400 border border-indigo-500/30">
        <Clock className="w-3 h-3" />
        UNPAID
      </span>
    );
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2.5">
            <CreditCard className="w-7 h-7 text-indigo-400" />
            My Fees & Invoices
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            View your assigned academic fee invoices, payment status, discounts and official statements
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsStatementModalOpen(true)}
            className="inline-flex items-center gap-2 px-3.5 py-2 bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 rounded-xl border border-indigo-500/30 text-xs font-semibold transition-colors cursor-pointer"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Account Statement</span>
          </button>

          <button
            onClick={fetchStudentFees}
            disabled={isLoading}
            className="inline-flex items-center gap-2 px-3.5 py-2 bg-white/5 hover:bg-white/10 text-slate-300 rounded-xl border border-white/10 text-xs font-medium transition-colors cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>
        </div>
      </div>

      {/* Summary Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Net Invoiced */}
        <div className="p-4 bg-slate-900/80 border border-white/10 rounded-2xl">
          <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
            Total Net Invoiced
          </p>
          <p className="text-xl font-mono font-bold text-white mt-1">
            ${Number(summary?.totalNetPayable ?? summary?.totalAmount ?? 0).toFixed(2)}
          </p>
          <p className="text-[11px] text-slate-400 mt-0.5">
            Across {summary?.totalInvoices || 0} invoice(s)
          </p>
        </div>

        {/* Total Concessions / Discounts */}
        <div className="p-4 bg-slate-900/80 border border-white/10 rounded-2xl">
          <p className="text-[10px] font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1">
            <ArrowDownRight className="w-3.5 h-3.5" /> Total Discounts
          </p>
          <p className="text-xl font-mono font-bold text-emerald-400 mt-1">
            ${Number(summary?.totalDiscount ?? 0).toFixed(2)}
          </p>
          <p className="text-[11px] text-slate-400 mt-0.5">Approved concessions</p>
        </div>

        {/* Total Paid */}
        <div className="p-4 bg-slate-900/80 border border-white/10 rounded-2xl">
          <p className="text-[10px] font-bold uppercase tracking-wider text-emerald-300">
            Total Paid
          </p>
          <p className="text-xl font-mono font-bold text-emerald-300 mt-1">
            ${Number(summary?.totalPaid ?? 0).toFixed(2)}
          </p>
          <p className="text-[11px] text-slate-400 mt-0.5">
            {summary?.paidCount || 0} invoice(s) settled
          </p>
        </div>

        {/* Remaining Outstanding Due */}
        <div className="p-4 bg-slate-900/80 border border-amber-500/20 bg-amber-500/[0.03] rounded-2xl">
          <p className="text-[10px] font-bold uppercase tracking-wider text-amber-400">
            Outstanding Due
          </p>
          <p className="text-xl font-mono font-bold text-amber-400 mt-1">
            ${Number(summary?.totalDue ?? 0).toFixed(2)}
          </p>
          <p className="text-[11px] text-amber-400/80 mt-0.5 font-medium">
            {summary && (summary.totalDue || 0) > 0 ? 'Pending payment' : 'All clear!'}
          </p>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 border-b border-white/10 pb-2">
        <button
          onClick={() => setSelectedStatusFilter('ALL')}
          className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
            selectedStatusFilter === 'ALL'
              ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          All Invoices ({feeRecords.length})
        </button>
        <button
          onClick={() => setSelectedStatusFilter('DUE')}
          className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
            selectedStatusFilter === 'DUE'
              ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          Unpaid / Dues
        </button>
        <button
          onClick={() => setSelectedStatusFilter('PAID')}
          className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
            selectedStatusFilter === 'PAID'
              ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          Paid in Full
        </button>
      </div>

      {/* Invoice List Table */}
      <div className="bg-slate-900/90 border border-white/10 rounded-2xl overflow-hidden">
        {isLoading ? (
          <div className="py-20 text-center text-slate-400">
            <div className="w-8 h-8 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
            <p className="text-xs">Loading fee invoices...</p>
          </div>
        ) : filteredRecords.length === 0 ? (
          <div className="py-16 text-center text-slate-400">
            <Receipt className="w-10 h-10 mx-auto mb-3 text-slate-600" />
            <p className="text-sm font-semibold text-white">No fee records found</p>
            <p className="text-xs text-slate-400 mt-1">
              You currently have no fee invoices matching this view.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950/60 border-b border-white/10 text-slate-400 font-semibold uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="px-4 py-3">Invoice #</th>
                  <th className="px-4 py-3">Fee Title & Type</th>
                  <th className="px-3 py-3 text-right">Base Amount</th>
                  <th className="px-3 py-3 text-right">Discount</th>
                  <th className="px-3 py-3 text-right">Fine</th>
                  <th className="px-3 py-3 text-right">Net Payable</th>
                  <th className="px-3 py-3 text-right">Paid</th>
                  <th className="px-3 py-3 text-right">Balance Due</th>
                  <th className="px-3 py-3 text-center">Due Date</th>
                  <th className="px-3 py-3 text-center">Status</th>
                  <th className="px-4 py-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 text-slate-300">
                {filteredRecords.map((fee) => {
                  const today = new Date();
                  today.setHours(0, 0, 0, 0);
                  const isOverdue =
                    new Date(fee.dueDate) < today &&
                    fee.dueAmount > 0 &&
                    fee.status !== 'CANCELLED';

                  return (
                    <tr key={fee.id} className="hover:bg-white/[0.02] transition-colors">
                      {/* Invoice # */}
                      <td className="px-4 py-3">
                        <span className="font-mono font-bold text-white block">
                          {fee?.invoiceNumber || fee?.id || 'INV-2026'}
                        </span>
                        <span className="text-[10px] text-slate-400">
                          {new Date(fee.createdAt).toLocaleDateString()}
                        </span>
                      </td>

                      {/* Title & Type */}
                      <td className="px-4 py-3">
                        <span className="font-medium text-white block">{fee.title}</span>
                        <div className="flex items-center gap-1.5 mt-0.5">
                          <span className="px-1.5 py-0.2 rounded text-[10px] bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
                            {fee.feeType}
                          </span>
                          <span className="text-[10px] text-slate-400">
                            {fee.frequency || 'ONE_TIME'}
                          </span>
                        </div>
                      </td>

                      {/* Base */}
                      <td className="px-3 py-3 text-right font-mono text-slate-300">
                        ${Number(fee.totalAmount ?? 0).toFixed(2)}
                      </td>

                      {/* Discount */}
                      <td className="px-3 py-3 text-right font-mono">
                        {(fee.discountAmount ?? 0) > 0 ? (
                          <span className="text-emerald-400 font-medium" title={fee.discountReason}>
                            -${Number(fee.discountAmount ?? 0).toFixed(2)}
                          </span>
                        ) : (
                          <span className="text-slate-400">-</span>
                        )}
                      </td>

                      {/* Fine */}
                      <td className="px-3 py-3 text-right font-mono">
                        {fee.fineAmount && fee.fineAmount > 0 ? (
                          <span className="text-rose-400 font-medium" title={fee.fineReason}>
                            +${Number(fee.fineAmount ?? 0).toFixed(2)}
                          </span>
                        ) : (
                          <span className="text-slate-400">-</span>
                        )}
                      </td>

                      {/* Net Payable */}
                      <td className="px-3 py-3 text-right font-mono font-bold text-indigo-300">
                        ${Number(fee.netPayableAmount ?? 0).toFixed(2)}
                      </td>

                      {/* Paid */}
                      <td className="px-3 py-3 text-right font-mono text-emerald-400 font-semibold">
                        ${Number(fee.paidAmount ?? 0).toFixed(2)}
                      </td>

                      {/* Due */}
                      <td className="px-3 py-3 text-right font-mono font-bold">
                        <span className={(fee.dueAmount ?? 0) > 0 ? 'text-amber-400' : 'text-emerald-400'}>
                          ${Number(fee.dueAmount ?? 0).toFixed(2)}
                        </span>
                      </td>

                      {/* Due Date */}
                      <td className="px-3 py-3 text-center">
                        <span
                          className={`font-mono ${
                            isOverdue ? 'text-rose-400 font-bold' : 'text-slate-300'
                          }`}
                        >
                          {fee.dueDate}
                        </span>
                      </td>

                      {/* Status */}
                      <td className="px-3 py-3 text-center">{renderStatusBadge(fee)}</td>

                      {/* Action */}
                      <td className="px-4 py-3 text-right">
                        <button
                          onClick={() => handleOpenInvoice(fee?.invoiceNumber || fee?.id || '')}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-indigo-600/80 hover:bg-indigo-600 rounded-lg shadow transition-colors cursor-pointer"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>View Invoice</span>
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Invoice Modal */}
      <InvoiceViewModal
        isOpen={isInvoiceModalOpen}
        onClose={() => {
          setIsInvoiceModalOpen(false);
          setSelectedInvoice(null);
        }}
        invoiceData={selectedInvoice}
        isLoading={isLoadingInvoice}
      />

      {/* Account Statement Modal */}
      {user && (
        <StudentStatementModal
          isOpen={isStatementModalOpen}
          onClose={() => setIsStatementModalOpen(false)}
          studentId={user.id}
          studentName={user.name}
        />
      )}
    </div>
  );
};
