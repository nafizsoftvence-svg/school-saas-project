import React, { useEffect, useState } from 'react';
import { Calendar, Clock, AlertCircle, Sparkles } from 'lucide-react';
import { api } from '../../services/api.js';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner.js';

interface RoutineSlot {
  time: string;
  subject: string;
  teacher: string;
  room: string;
}

interface DaySchedule {
  day: string;
  slots: RoutineSlot[];
}

export const StudentRoutinePage: React.FC = () => {
  const [schedule, setSchedule] = useState<DaySchedule[]>([]);
  const [className, setClassName] = useState<string>('');
  const [sectionName, setSectionName] = useState<string>('');
  const [sessionName, setSessionName] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchRoutine = async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await api.getStudentRoutine();
      if (res.success && res.data) {
        setSchedule(res.data.schedule || []);
        setClassName(res.data.className || 'Class 10');
        setSectionName(res.data.sectionName || 'Section A');
        setSessionName(res.data.sessionName || '2026-2027');
      } else {
        setError(res.error || 'Failed to load timetable.');
      }
    } catch (err: any) {
      console.error('Failed to load routine', err);
      setError(err?.message || 'Network error fetching academic routine.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRoutine();
  }, []);

  if (loading) {
    return (
      <div className="py-24 flex items-center justify-center">
        <LoadingSpinner size="lg" message="Loading weekly timetable..." />
      </div>
    );
  }

  if (error) {
    return (
      <div className="max-w-xl mx-auto my-12 p-8 bg-rose-50 border border-rose-200 rounded-2xl text-center space-y-3">
        <AlertCircle className="w-10 h-10 text-rose-600 mx-auto" />
        <h3 className="text-lg font-bold text-slate-900">Unable to Load Schedule</h3>
        <p className="text-xs text-rose-700">{error}</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 shadow-xs">
        <div className="flex items-center gap-2 text-blue-600 text-xs font-bold uppercase tracking-wider mb-1">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Weekly Timetable</span>
        </div>
        <h2 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">Class Routine &amp; Schedule</h2>
        <p className="text-xs text-slate-500 mt-1 font-medium">
          {className} • {sectionName} • Academic Session {sessionName}
        </p>
      </div>

      <div className="space-y-4">
        {(schedule || []).map((d) => (
          <div
            key={d.day}
            className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-4"
          >
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Calendar className="w-4 h-4 text-blue-600" />
                <span>{d.day}</span>
              </h3>
              <span className="text-xs text-slate-500 font-mono font-medium">{d?.slots?.length || 0} Scheduled Periods</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-1">
              {(d.slots || []).map((s, idx) => (
                <div
                  key={idx}
                  className="p-4 rounded-xl bg-slate-50/70 border border-slate-200 hover:border-slate-300 transition-all space-y-1.5"
                >
                  <div className="text-[11px] font-mono text-blue-700 font-semibold flex items-center gap-1.5">
                    <Clock className="w-3 h-3 text-blue-600" />
                    <span>{s.time}</span>
                  </div>
                  <div className="text-sm font-bold text-slate-900">{s.subject}</div>
                  <div className="text-xs text-slate-500 flex items-center justify-between font-medium">
                    <span>{s.room}</span>
                    <span className="text-[11px] text-slate-700 font-semibold">{s.teacher}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
