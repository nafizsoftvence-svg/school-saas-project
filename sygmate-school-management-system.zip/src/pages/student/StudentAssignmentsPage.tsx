import React, { useEffect, useState, useMemo } from 'react';
import {
  FileSpreadsheet,
  Search,
  Filter,
  Calendar,
  Clock,
  Download,
  FileText,
  User,
  AlertCircle,
  CheckCircle2,
  RefreshCw,
  Eye,
  ExternalLink,
  ChevronRight,
  Sparkles,
  BookOpen,
  Info,
  Layers,
  ArrowUpDown,
  UploadCloud,
  Award,
  Lock
} from 'lucide-react';
import { Badge } from '../../components/ui/Badge.js';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner.js';
import { Modal } from '../../components/ui/Modal.js';
import { EmptyState } from '../../components/ui/EmptyState.js';
import { api } from '../../services/api.js';
import {
  StudentAssignmentItem,
  StudentEnrolledSubject,
  StudentClassInfo
} from '../../types/index.js';

interface StudentAssignmentsPageProps {
  onNavigate?: (view: string) => void;
}

export const StudentAssignmentsPage: React.FC<StudentAssignmentsPageProps> = ({ onNavigate }) => {
  const [assignments, setAssignments] = useState<StudentAssignmentItem[]>([]);
  const [subjects, setSubjects] = useState<StudentEnrolledSubject[]>([]);
  const [classInfo, setClassInfo] = useState<StudentClassInfo | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Filters
  const [searchTerm, setSearchTerm] = useState('');
  const [subjectFilter, setSubjectFilter] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [startDateFilter, setStartDateFilter] = useState<string>('');
  const [dueDateFilter, setDueDateFilter] = useState<string>('');
  const [sortOrder, setSortOrder] = useState<'due_asc' | 'due_desc' | 'start_desc'>('due_asc');

  // Modal inspection
  const [selectedAssignment, setSelectedAssignment] = useState<StudentAssignmentItem | null>(null);
  const [previewAttachment, setPreviewAttachment] = useState<{ url: string; name: string; type?: string } | null>(null);

  const loadData = async (isManualRefresh = false) => {
    try {
      if (isManualRefresh) setRefreshing(true);
      else setLoading(true);
      setError(null);

      const [asgRes, subjRes, classRes] = await Promise.all([
        api.getMyAssignments({
          subjectId: subjectFilter !== 'ALL' ? subjectFilter : undefined,
          status: statusFilter !== 'ALL' ? statusFilter : undefined,
          search: searchTerm || undefined,
          startDate: startDateFilter || undefined,
          dueDate: dueDateFilter || undefined
        }),
        api.getMyEnrolledSubjects(),
        api.getMyClassInfo()
      ]);

      if (asgRes.success && asgRes.data) {
        setAssignments(asgRes.data);
      } else {
        setError(asgRes.error || 'Failed to load class assignments.');
      }

      if (subjRes.success && subjRes.data) {
        setSubjects(subjRes.data);
      }

      if (classRes.success && classRes.data) {
        setClassInfo(classRes.data);
      }
    } catch (err: any) {
      console.error('Error fetching student assignments:', err);
      setError(err.message || 'Network error while retrieving assignments.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [subjectFilter, statusFilter, startDateFilter, dueDateFilter]);

  const filteredAndSortedAssignments = useMemo(() => {
    let list = [...assignments];

    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase().trim();
      list = list.filter(
        (a) =>
          (a.title || '').toLowerCase().includes(q) ||
          (a.description ? a.description.toLowerCase().includes(q) : false) ||
          (a.subjectName || '').toLowerCase().includes(q) ||
          (a.teacherName || '').toLowerCase().includes(q) ||
          (a.attachmentName ? a.attachmentName.toLowerCase().includes(q) : false)
      );
    }

    list.sort((a, b) => {
      if (sortOrder === 'due_asc') {
        if (a.isOverdue && !b.isOverdue) return 1;
        if (!a.isOverdue && b.isOverdue) return -1;
        return a.dueDate.localeCompare(b.dueDate);
      }
      if (sortOrder === 'due_desc') {
        return b.dueDate.localeCompare(a.dueDate);
      }
      return b.startDate.localeCompare(a.startDate);
    });

    return list;
  }, [assignments, searchTerm, sortOrder]);

  const metrics = useMemo(() => {
    const total = assignments.length;
    const dueSoon = assignments.filter((a) => a.isDueSoon && !a.isOverdue).length;
    const overdue = assignments.filter((a) => a.isOverdue).length;
    const active = assignments.filter((a) => !a.isOverdue && !a.isDueSoon).length;
    return { total, active, dueSoon, overdue };
  }, [assignments]);

  const getStatusBadge = (item: StudentAssignmentItem) => {
    if (item.isOverdue) {
      return (
        <Badge variant="danger" dot>
          Overdue ({Math.abs(item.daysRemaining)}d ago)
        </Badge>
      );
    }
    if (item.isDueSoon) {
      return (
        <Badge variant="warning" dot>
          Due Soon ({item.daysRemaining === 0 ? 'Today' : `${item.daysRemaining}d left`})
        </Badge>
      );
    }
    if (item.calculatedStatus === 'upcoming') {
      return <Badge variant="info">Upcoming</Badge>;
    }
    return (
      <Badge variant="success" dot>
        Active ({item.daysRemaining}d left)
      </Badge>
    );
  };

  const getSubjectColorBadge = (subjectName?: string) => {
    const s = (subjectName || '').toLowerCase();
    if (s.includes('math')) return 'primary';
    if (s.includes('physic') || s.includes('chem') || s.includes('sci')) return 'cyan';
    if (s.includes('comput') || s.includes('ict')) return 'info';
    if (s.includes('eng') || s.includes('lang')) return 'success';
    return 'neutral';
  };

  return (
    <div id="student-assignments-page" className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900/60 backdrop-blur-xl p-6 rounded-2xl border border-white/10 shadow-xl relative overflow-hidden">
        <div className="absolute -right-16 -top-16 w-56 h-56 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10">
          <div className="flex items-center gap-2 text-cyan-400 text-xs font-semibold uppercase tracking-wider mb-1">
            <FileSpreadsheet className="w-4 h-4" />
            <span>Academic Coursework & Projects</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight flex items-center gap-3">
            Class Assignments
            {classInfo && (
              <span className="text-xs font-normal px-2.5 py-1 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                {classInfo.schoolClass.name} • {classInfo.section.name}
              </span>
            )}
          </h1>
          <p className="text-sm text-slate-400 mt-1 max-w-2xl">
            Access graded project requirements, rubric guidelines, reference files, and deadlines assigned to your class cohort.
          </p>
        </div>

        <div className="flex items-center gap-3 relative z-10 self-start md:self-auto">
          <button
            id="assignments-refresh-btn"
            onClick={() => loadData(true)}
            disabled={refreshing}
            className="flex items-center gap-2 px-3.5 py-2 text-xs font-medium text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-700/80 border border-white/10 rounded-xl transition-all disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin' : ''}`} />
            <span>{refreshing ? 'Refreshing...' : 'Refresh'}</span>
          </button>
          {onNavigate && (
            <button
              onClick={() => onNavigate('student-materials')}
              className="flex items-center gap-2 px-3.5 py-2 text-xs font-medium text-cyan-300 hover:text-cyan-200 bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/30 rounded-xl transition-all"
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>Study Materials</span>
            </button>
          )}
        </div>
      </div>

      {/* Metrics Summary Pills */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
        <div
          onClick={() => setStatusFilter('ALL')}
          className={`cursor-pointer p-4 rounded-xl border transition-all ${
            statusFilter === 'ALL'
              ? 'bg-cyan-500/15 border-cyan-500/40 shadow-lg shadow-cyan-500/10'
              : 'bg-slate-900/40 hover:bg-slate-900/60 border-white/5'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Total Assignments</span>
            <FileSpreadsheet className="w-4 h-4 text-cyan-400" />
          </div>
          <p className="text-2xl font-bold text-white mt-2">{metrics.total}</p>
          <span className="text-[11px] text-slate-400">Coursework projects</span>
        </div>

        <div
          onClick={() => setStatusFilter('active')}
          className={`cursor-pointer p-4 rounded-xl border transition-all ${
            statusFilter === 'active'
              ? 'bg-emerald-500/15 border-emerald-500/40 shadow-lg shadow-emerald-500/10'
              : 'bg-slate-900/40 hover:bg-slate-900/60 border-white/5'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-emerald-400">Active</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <p className="text-2xl font-bold text-emerald-300 mt-2">{metrics.active}</p>
          <span className="text-[11px] text-slate-400">In submission window</span>
        </div>

        <div
          onClick={() => setStatusFilter('due_soon')}
          className={`cursor-pointer p-4 rounded-xl border transition-all ${
            statusFilter === 'due_soon'
              ? 'bg-amber-500/15 border-amber-500/40 shadow-lg shadow-amber-500/10'
              : 'bg-slate-900/40 hover:bg-slate-900/60 border-white/5'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-amber-400">Due Soon (&le;3 Days)</span>
            <Clock className="w-4 h-4 text-amber-400" />
          </div>
          <p className="text-2xl font-bold text-amber-300 mt-2">{metrics.dueSoon}</p>
          <span className="text-[11px] text-slate-400">Deadline approaching</span>
        </div>

        <div
          onClick={() => setStatusFilter('overdue')}
          className={`cursor-pointer p-4 rounded-xl border transition-all ${
            statusFilter === 'overdue'
              ? 'bg-rose-500/15 border-rose-500/40 shadow-lg shadow-rose-500/10'
              : 'bg-slate-900/40 hover:bg-slate-900/60 border-white/5'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-rose-400">Overdue</span>
            <AlertCircle className="w-4 h-4 text-rose-400" />
          </div>
          <p className="text-2xl font-bold text-rose-300 mt-2">{metrics.overdue}</p>
          <span className="text-[11px] text-slate-400">Past deadline</span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-slate-900/40 backdrop-blur-md p-4 rounded-2xl border border-white/10 flex flex-col md:flex-row gap-3 items-center justify-between">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search assignments by title, subject..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-950/60 border border-white/10 text-white placeholder-slate-500 text-xs rounded-xl pl-9 pr-4 py-2.5 focus:outline-none focus:border-cyan-500/50 transition-colors"
          />
          {searchTerm && (
            <button
              onClick={() => setSearchTerm('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white text-xs"
            >
              &times;
            </button>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto">
          {/* Subject Filter */}
          <div className="flex items-center gap-1.5 bg-slate-950/60 border border-white/10 rounded-xl px-3 py-1.5">
            <BookOpen className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={subjectFilter}
              onChange={(e) => setSubjectFilter(e.target.value)}
              className="bg-transparent text-xs text-white focus:outline-none cursor-pointer"
            >
              <option value="ALL" className="bg-slate-900 text-white">All Subjects</option>
              {(subjects || []).map((s) => (
                <option key={s.id} value={s.id} className="bg-slate-900 text-white">
                  {s.name}
                </option>
              ))}
            </select>
          </div>

          {/* Status Filter */}
          <div className="flex items-center gap-1.5 bg-slate-950/60 border border-white/10 rounded-xl px-3 py-1.5">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="bg-transparent text-xs text-white focus:outline-none cursor-pointer"
            >
              <option value="ALL" className="bg-slate-900 text-white">All Statuses</option>
              <option value="active" className="bg-slate-900 text-white">Active</option>
              <option value="due_soon" className="bg-slate-900 text-white">Due Soon</option>
              <option value="overdue" className="bg-slate-900 text-white">Overdue</option>
            </select>
          </div>

          {/* Start Date Picker Filter */}
          <div className="flex items-center gap-1.5 bg-slate-950/60 border border-white/10 rounded-xl px-3 py-1.5">
            <Calendar className="w-3.5 h-3.5 text-slate-400" />
            <input
              type="date"
              value={startDateFilter}
              onChange={(e) => setStartDateFilter(e.target.value)}
              className="bg-transparent text-xs text-white focus:outline-none cursor-pointer"
              title="Filter by start date"
            />
            {startDateFilter && (
              <button
                onClick={() => setStartDateFilter('')}
                className="text-slate-400 hover:text-white text-xs ml-1"
                title="Clear date"
              >
                &times;
              </button>
            )}
          </div>

          {/* Due Date Picker Filter */}
          <div className="flex items-center gap-1.5 bg-slate-950/60 border border-white/10 rounded-xl px-3 py-1.5">
            <Clock className="w-3.5 h-3.5 text-slate-400" />
            <input
              type="date"
              value={dueDateFilter}
              onChange={(e) => setDueDateFilter(e.target.value)}
              className="bg-transparent text-xs text-white focus:outline-none cursor-pointer"
              title="Filter by due date"
            />
            {dueDateFilter && (
              <button
                onClick={() => setDueDateFilter('')}
                className="text-slate-400 hover:text-white text-xs ml-1"
                title="Clear date"
              >
                &times;
              </button>
            )}
          </div>

          {/* Sort Order */}
          <div className="flex items-center gap-1.5 bg-slate-950/60 border border-white/10 rounded-xl px-3 py-1.5">
            <ArrowUpDown className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={sortOrder}
              onChange={(e) => setSortOrder(e.target.value as any)}
              className="bg-transparent text-xs text-white focus:outline-none cursor-pointer"
            >
              <option value="due_asc" className="bg-slate-900 text-white">Earliest Due First</option>
              <option value="due_desc" className="bg-slate-900 text-white">Latest Due First</option>
              <option value="start_desc" className="bg-slate-900 text-white">Newest Start Date</option>
            </select>
          </div>
        </div>
      </div>

      {/* Error state */}
      {error && (
        <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-sm flex items-center gap-3">
          <AlertCircle className="w-5 h-5 shrink-0" />
          <span>{error}</span>
          <button
            onClick={() => loadData()}
            className="ml-auto text-xs underline hover:text-white"
          >
            Retry
          </button>
        </div>
      )}

      {/* Main Content List */}
      {loading ? (
        <div className="py-20 flex flex-col items-center justify-center gap-3">
          <LoadingSpinner size="lg" />
          <p className="text-sm text-slate-400">Loading assignments repository...</p>
        </div>
      ) : filteredAndSortedAssignments.length === 0 ? (
        <EmptyState
          icon={FileSpreadsheet}
          title="No Assignments Found"
          description={
            searchTerm || subjectFilter !== 'ALL' || statusFilter !== 'ALL' || startDateFilter || dueDateFilter
              ? 'No assignments match your search or filters. Try adjusting your parameters.'
              : 'There are no active assignments published for your class and section at this time.'
          }
          action={
            searchTerm || subjectFilter !== 'ALL' || statusFilter !== 'ALL' || startDateFilter || dueDateFilter ? (
              <button
                onClick={() => {
                  setSearchTerm('');
                  setSubjectFilter('ALL');
                  setStatusFilter('ALL');
                  setStartDateFilter('');
                  setDueDateFilter('');
                }}
                className="px-4 py-2 text-xs font-semibold text-white bg-cyan-600 hover:bg-cyan-500 rounded-xl transition-all"
              >
                Reset Filters
              </button>
            ) : undefined
          }
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {(filteredAndSortedAssignments || []).map((item) => (
            <div
              key={item.id}
              className={`rounded-2xl border bg-slate-900/50 backdrop-blur-xl p-5 flex flex-col justify-between transition-all duration-200 hover:shadow-2xl hover:border-white/20 group relative overflow-hidden ${
                item.isOverdue
                  ? 'border-rose-500/30 hover:border-rose-500/50'
                  : item.isDueSoon
                  ? 'border-amber-500/30 hover:border-amber-500/50'
                  : 'border-white/10'
              }`}
            >
              {/* Subtle top indicator bar */}
              <div
                className={`absolute top-0 left-0 right-0 h-1 ${
                  item.isOverdue
                    ? 'bg-rose-500'
                    : item.isDueSoon
                    ? 'bg-amber-500'
                    : 'bg-cyan-500'
                }`}
              />

              <div>
                {/* Badges row */}
                <div className="flex items-center justify-between gap-2 mb-3">
                  <div className="flex items-center gap-1.5">
                    <Badge variant={getSubjectColorBadge(item.subjectName) as any}>
                      {item.subjectName}
                    </Badge>
                    {item.totalMarks && (
                      <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-300 border border-amber-500/30">
                        {item.totalMarks} Marks
                      </span>
                    )}
                  </div>
                  {getStatusBadge(item)}
                </div>

                {/* Title */}
                <h3 className="text-base font-bold text-white group-hover:text-cyan-300 transition-colors line-clamp-2 mb-2">
                  {item.title}
                </h3>

                {/* Description */}
                <p className="text-xs text-slate-400 line-clamp-3 leading-relaxed mb-4">
                  {item.description}
                </p>
              </div>

              {/* Card Footer Details */}
              <div className="pt-4 border-t border-white/5 space-y-3">
                {/* Faculty Info */}
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <div className="flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-cyan-400" />
                    <span className="text-slate-300 font-medium truncate max-w-[150px]">{item.teacherName}</span>
                  </div>
                  <span className="text-[11px] text-slate-500">
                    Starts: {item.startDate}
                  </span>
                </div>

                {/* Date Window */}
                <div className="flex items-center justify-between bg-slate-950/40 p-2.5 rounded-xl border border-white/5">
                  <div className="flex items-center gap-2">
                    <Clock className={`w-4 h-4 ${item.isOverdue ? 'text-rose-400' : item.isDueSoon ? 'text-amber-400' : 'text-cyan-400'}`} />
                    <div>
                      <div className="text-[10px] text-slate-500 uppercase tracking-wider font-semibold">Deadline</div>
                      <div className={`text-xs font-bold ${item.isOverdue ? 'text-rose-300' : item.isDueSoon ? 'text-amber-300' : 'text-slate-200'}`}>
                        {item.dueDate}
                      </div>
                    </div>
                  </div>

                  {item.attachmentName ? (
                    <button
                      onClick={() => setPreviewAttachment({ url: item.attachmentUrl || '', name: item.attachmentName || 'Assignment_Guidelines.pdf', type: item.attachmentType })}
                      className="flex items-center gap-1 text-[11px] font-medium text-cyan-300 hover:text-cyan-200 bg-cyan-500/10 hover:bg-cyan-500/20 px-2 py-1 rounded-lg border border-cyan-500/20 transition-colors"
                      title={item.attachmentName}
                    >
                      <Download className="w-3 h-3" />
                      <span className="truncate max-w-[80px]">Rubric</span>
                    </button>
                  ) : (
                    <span className="text-[11px] text-slate-500 italic">No attachments</span>
                  )}
                </div>

                {/* Action Button */}
                <button
                  onClick={() => setSelectedAssignment(item)}
                  className="w-full mt-2 flex items-center justify-center gap-2 py-2 text-xs font-medium text-slate-300 hover:text-white bg-slate-800/80 hover:bg-cyan-600/80 rounded-xl border border-white/10 hover:border-cyan-500/50 transition-all duration-150"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>View Full Assignment Spec</span>
                  <ChevronRight className="w-3.5 h-3.5 ml-auto" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Modal: Detailed Assignment Inspection */}
      {selectedAssignment && (
        <Modal
          isOpen={!!selectedAssignment}
          onClose={() => setSelectedAssignment(null)}
          title="Assignment Brief & Rubric"
          size="lg"
        >
          <div className="space-y-5">
            {/* Header info */}
            <div className="p-4 rounded-xl bg-slate-950/60 border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <Badge variant={getSubjectColorBadge(selectedAssignment.subjectName) as any}>
                    {selectedAssignment.subjectName}
                  </Badge>
                  {getStatusBadge(selectedAssignment)}
                  {selectedAssignment.totalMarks && (
                    <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-300 border border-amber-500/30">
                      {selectedAssignment.totalMarks} Total Marks
                    </span>
                  )}
                </div>
                <h2 className="text-lg font-bold text-white">{selectedAssignment.title}</h2>
              </div>
              <div className="text-right sm:border-l sm:border-white/10 sm:pl-4">
                <div className="text-[10px] uppercase tracking-wider text-slate-400">Class Cohort</div>
                <div className="text-xs font-semibold text-cyan-300">
                  {selectedAssignment.className} • {selectedAssignment.sectionName}
                </div>
              </div>
            </div>

            {/* Assignment Problem Statement / Description */}
            <div className="space-y-2">
              <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5 text-cyan-400" />
                <span>Assignment Brief & Problem Statement</span>
              </label>
              <div className="p-4 rounded-xl bg-slate-900/80 border border-white/5 text-sm text-slate-200 leading-relaxed whitespace-pre-wrap">
                {selectedAssignment.description}
              </div>
            </div>

            {/* Metadata Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div className="p-3.5 rounded-xl bg-slate-950/40 border border-white/5 flex items-center gap-3">
                <User className="w-4 h-4 text-cyan-400 shrink-0" />
                <div>
                  <span className="text-slate-500 block text-[11px]">Instructor / Faculty</span>
                  <span className="text-slate-200 font-semibold">{selectedAssignment.teacherName}</span>
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-950/40 border border-white/5 flex items-center gap-3">
                <Calendar className="w-4 h-4 text-cyan-400 shrink-0" />
                <div>
                  <span className="text-slate-500 block text-[11px]">Start / Release Date</span>
                  <span className="text-slate-200 font-semibold">{selectedAssignment.startDate}</span>
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-950/40 border border-white/5 flex items-center gap-3">
                <Clock className={`w-4 h-4 ${selectedAssignment.isOverdue ? 'text-rose-400' : 'text-amber-400'} shrink-0`} />
                <div>
                  <span className="text-slate-500 block text-[11px]">Final Due Date</span>
                  <span className={`font-semibold ${selectedAssignment.isOverdue ? 'text-rose-300' : 'text-slate-200'}`}>
                    {selectedAssignment.dueDate}
                  </span>
                </div>
              </div>
            </div>

            {/* Attached Reference Material */}
            {selectedAssignment.attachmentName && (
              <div className="space-y-2">
                <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Download className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Assignment Rubric & Starter Resource</span>
                </label>
                <div className="p-3.5 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-between">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-9 h-9 rounded-lg bg-cyan-500/20 text-cyan-300 flex items-center justify-center shrink-0 font-bold uppercase text-xs">
                      {selectedAssignment.attachmentType || 'DOC'}
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs font-semibold text-white truncate">{selectedAssignment.attachmentName}</p>
                      <p className="text-[11px] text-cyan-300/80">{selectedAssignment.attachmentSize || 'Resource Document'}</p>
                    </div>
                  </div>
                  <button
                    onClick={() => setPreviewAttachment({ url: selectedAssignment.attachmentUrl || '', name: selectedAssignment.attachmentName || '', type: selectedAssignment.attachmentType })}
                    className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-cyan-600 hover:bg-cyan-500 rounded-lg transition-colors shrink-0 ml-3"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download Resource</span>
                  </button>
                </div>
              </div>
            )}

            {/* Architecture Preparation Card: Submission & Grading Workflow */}
            <div className="p-4 rounded-xl bg-slate-950 border border-white/10 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-200">
                  <UploadCloud className="w-4 h-4 text-cyan-400" />
                  <span>Submission & Assessment Status</span>
                </div>
                <Badge variant="neutral" size="sm">
                  Phase 4D Active View
                </Badge>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="p-3 rounded-lg bg-slate-900/60 border border-white/5">
                  <span className="text-slate-400 block text-[11px]">Submission State</span>
                  <span className="text-slate-200 font-medium">Class Submissions Window Active</span>
                </div>
                <div className="p-3 rounded-lg bg-slate-900/60 border border-white/5">
                  <span className="text-slate-400 block text-[11px]">Maximum Weightage</span>
                  <span className="text-amber-300 font-semibold">{selectedAssignment.totalMarks || 100} Points</span>
                </div>
              </div>
              <p className="text-[11px] text-slate-400 leading-normal">
                Online file submission upload portal, version history, plagiarism check, teacher rubrics, and published grades will be integrated into the upcoming Phase 4E Student Assessment & Grading module.
              </p>
            </div>

            {/* Modal Actions */}
            <div className="flex justify-end gap-2 pt-2 border-t border-white/10">
              <button
                onClick={() => setSelectedAssignment(null)}
                className="px-4 py-2 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 rounded-xl transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* Modal: Document Attachment Previewer */}
      {previewAttachment && (
        <Modal
          isOpen={!!previewAttachment}
          onClose={() => setPreviewAttachment(null)}
          title={`Resource: ${previewAttachment.name}`}
          size="lg"
        >
          <div className="space-y-4">
            <div className="p-4 rounded-xl bg-slate-950/60 border border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <FileText className="w-6 h-6 text-cyan-400" />
                <div>
                  <h4 className="text-sm font-semibold text-white">{previewAttachment.name}</h4>
                  <p className="text-xs text-slate-400">Institutional assignment rubric & study guide</p>
                </div>
              </div>
              <a
                href={previewAttachment.url}
                target="_blank"
                rel="noreferrer noopener"
                download={previewAttachment.name}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-cyan-600 hover:bg-cyan-500 rounded-lg transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download File</span>
              </a>
            </div>

            <div className="h-72 rounded-xl bg-slate-950 border border-white/10 overflow-hidden flex flex-col items-center justify-center p-4 relative">
              {previewAttachment.url && previewAttachment.url.startsWith('http') ? (
                <img
                  src={previewAttachment.url}
                  alt={previewAttachment.name}
                  className="max-h-full max-w-full object-contain rounded-lg shadow-md"
                  referrerPolicy="no-referrer"
                />
              ) : (
                <div className="text-center space-y-2">
                  <FileText className="w-12 h-12 text-slate-600 mx-auto" />
                  <p className="text-xs text-slate-400">Direct file preview is optimized for local browser download.</p>
                </div>
              )}
            </div>

            <div className="flex justify-end">
              <button
                onClick={() => setPreviewAttachment(null)}
                className="px-4 py-2 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 rounded-xl"
              >
                Close Preview
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
