import React, { useEffect, useState, useMemo } from 'react';
import {
  Calendar as CalendarIcon,
  CheckCircle2,
  XCircle,
  Clock,
  ShieldCheck,
  AlertTriangle,
  FileText,
  Plus,
  Filter,
  Search,
  ChevronLeft,
  ChevronRight,
  Info,
  Paperclip,
  Trash2,
  RefreshCw,
  ExternalLink,
  User,
  GraduationCap,
  Sparkles,
  ArrowRight,
  Check,
  X,
  AlertCircle
} from 'lucide-react';
import { Badge } from '../../components/ui/Badge.js';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner.js';
import { Modal } from '../../components/ui/Modal.js';
import { api } from '../../services/api.js';
import {
  StudentAttendanceOverviewData,
  StudentAttendanceDay,
  StudentLeaveApplication,
  AttendanceRecord,
  AttendanceStatus,
  LeaveStatus
} from '../../types/index.js';

interface StudentAttendancePageProps {
  onNavigate?: (viewId: string) => void;
  activeTab?: 'calendar' | 'records' | 'leaves';
  onTabChange?: (tab: 'calendar' | 'records' | 'leaves') => void;
  hideTabBar?: boolean;
}

export const StudentAttendancePage: React.FC<StudentAttendancePageProps> = ({
  onNavigate,
  activeTab: propActiveTab,
  onTabChange,
  hideTabBar = true
}) => {
  const [data, setData] = useState<StudentAttendanceOverviewData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [currentMonth, setCurrentMonth] = useState<string>('2026-08');
  const [internalTab, setInternalTab] = useState<'calendar' | 'records' | 'leaves'>('calendar');
  const activeTab = propActiveTab || internalTab;
  const setActiveTab = (tab: 'calendar' | 'records' | 'leaves') => {
    setInternalTab(tab);
    onTabChange?.(tab);
  };

  // Day Details Modal
  const [selectedDay, setSelectedDay] = useState<StudentAttendanceDay | null>(null);

  // Leave Application Modal
  const [isLeaveModalOpen, setIsLeaveModalOpen] = useState(false);
  const [leaveSubmitting, setLeaveSubmitting] = useState(false);
  const [leaveFormError, setLeaveFormError] = useState<string | null>(null);
  const [leaveSuccessMessage, setLeaveSuccessMessage] = useState<string | null>(null);
  const [leaveDate, setLeaveDate] = useState<string>('');
  const [leaveEndDate, setLeaveEndDate] = useState<string>('');
  const [leaveReason, setLeaveReason] = useState<string>('Medical');
  const [leaveDescription, setLeaveDescription] = useState<string>('');
  const [attachmentUrl, setAttachmentUrl] = useState<string>('');
  const [attachmentName, setAttachmentName] = useState<string>('');

  // Table Filters
  const [recordFilterStatus, setRecordFilterStatus] = useState<string>('ALL');
  const [recordSearch, setRecordSearch] = useState<string>('');
  const [leaveFilterStatus, setLeaveFilterStatus] = useState<string>('ALL');

  // Leave Details Modal
  const [selectedLeave, setSelectedLeave] = useState<StudentLeaveApplication | null>(null);
  const [cancellingLeaveId, setCancellingLeaveId] = useState<string | null>(null);

  const fetchAttendance = async (targetMonth: string) => {
    try {
      setLoading(true);
      setError(null);
      const res = await api.getMyAttendance({ month: targetMonth });
      if (res.success && res.data) {
        setData(res.data);
      } else {
        setError(res.error || 'Failed to load attendance records.');
      }
    } catch (err: any) {
      setError(err.message || 'An error occurred while fetching attendance data.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAttendance(currentMonth);
  }, [currentMonth]);

  const handlePrevMonth = () => {
    const [yearStr, monthStr] = currentMonth.split('-');
    let year = parseInt(yearStr, 10);
    let month = parseInt(monthStr, 10) - 1;
    if (month < 1) {
      month = 12;
      year -= 1;
    }
    const newMonthStr = `${year}-${String(month).padStart(2, '0')}`;
    setCurrentMonth(newMonthStr);
  };

  const handleNextMonth = () => {
    const [yearStr, monthStr] = currentMonth.split('-');
    let year = parseInt(yearStr, 10);
    let month = parseInt(monthStr, 10) + 1;
    if (month > 12) {
      month = 1;
      year += 1;
    }
    const newMonthStr = `${year}-${String(month).padStart(2, '0')}`;
    setCurrentMonth(newMonthStr);
  };

  const openLeaveModal = (presetDate?: string) => {
    setLeaveDate(presetDate || new Date().toISOString().split('T')[0]);
    setLeaveEndDate('');
    setLeaveReason('Medical');
    setLeaveDescription('');
    setAttachmentUrl('');
    setAttachmentName('');
    setLeaveFormError(null);
    setLeaveSuccessMessage(null);
    setIsLeaveModalOpen(true);
  };

  const handleSubmitLeave = async (e: React.FormEvent) => {
    e.preventDefault();
    setLeaveFormError(null);

    if (!leaveDate) {
      setLeaveFormError('Please select a leave start date.');
      return;
    }
    if (!leaveReason) {
      setLeaveFormError('Please select a reason for your absence.');
      return;
    }
    if (!leaveDescription || leaveDescription.trim().length < 10) {
      setLeaveFormError('Please provide a detailed explanation (minimum 10 characters).');
      return;
    }

    try {
      setLeaveSubmitting(true);
      const res = await api.submitMyLeaveApplication({
        leaveDate,
        endDate: leaveEndDate || undefined,
        reason: leaveReason,
        description: leaveDescription,
        attachmentUrl: attachmentUrl || undefined,
        attachmentName: attachmentName || (attachmentUrl ? 'Medical_Documentation_Note.pdf' : undefined)
      });

      if (res.success) {
        setLeaveSuccessMessage('Leave application submitted successfully for faculty review.');
        setTimeout(() => {
          setIsLeaveModalOpen(false);
          fetchAttendance(currentMonth);
        }, 1200);
      } else {
        setLeaveFormError(res.error || 'Failed to submit leave application.');
      }
    } catch (err: any) {
      setLeaveFormError(err.message || 'An error occurred while submitting.');
    } finally {
      setLeaveSubmitting(false);
    }
  };

  const handleCancelLeave = async (leaveId: string) => {
    if (!window.confirm('Are you sure you want to cancel this pending leave application?')) {
      return;
    }

    try {
      setCancellingLeaveId(leaveId);
      const res = await api.cancelMyLeaveApplication(leaveId);
      if (res.success) {
        if (selectedLeave?.id === leaveId) {
          setSelectedLeave(null);
        }
        await fetchAttendance(currentMonth);
      } else {
        alert(res.error || 'Failed to cancel leave application.');
      }
    } catch (err: any) {
      alert(err.message || 'An error occurred while cancelling.');
    } finally {
      setCancellingLeaveId(null);
    }
  };

  // Month formatted title (e.g. August 2026)
  const monthDisplayTitle = useMemo(() => {
    const [yearStr, monthStr] = currentMonth.split('-');
    const dateObj = new Date(parseInt(yearStr, 10), parseInt(monthStr, 10) - 1, 1);
    return dateObj.toLocaleString('default', { month: 'long', year: 'numeric' });
  }, [currentMonth]);

  // Filtered records
  const filteredRecords = useMemo(() => {
    if (!data?.records) return [];
    return data.records.filter((r) => {
      if (recordFilterStatus !== 'ALL' && r.status !== recordFilterStatus) return false;
      if (recordSearch.trim()) {
        const q = recordSearch.toLowerCase().trim();
        const matchSubject = (r.subjectName || '').toLowerCase().includes(q);
        const matchTeacher = (r.recordedByTeacherName || '').toLowerCase().includes(q);
        const matchRemarks = (r.remarks || '').toLowerCase().includes(q);
        const matchDate = r.date.includes(q);
        if (!matchSubject && !matchTeacher && !matchRemarks && !matchDate) return false;
      }
      return true;
    });
  }, [data?.records, recordFilterStatus, recordSearch]);

  // Filtered leave applications
  const filteredLeaves = useMemo(() => {
    if (!data?.leaveApplications) return [];
    return data.leaveApplications.filter((l) => {
      if (leaveFilterStatus !== 'ALL' && l.status !== leaveFilterStatus) return false;
      return true;
    });
  }, [data?.leaveApplications, leaveFilterStatus]);

  // Percentage status label
  const percentageStatus = useMemo(() => {
    const pct = data?.summary?.attendancePercentage ?? 100;
    if (pct >= 85) return { label: 'Excellent Standing', color: 'emerald', text: 'Meets academic merit and honors attendance criteria.' };
    if (pct >= 75) return { label: 'Good Standing', color: 'indigo', text: 'Compliant with minimum institutional attendance requirements.' };
    return { label: 'Attendance Warning', color: 'rose', text: 'Below 75% mandatory threshold. Requires faculty consultation.' };
  }, [data?.summary?.attendancePercentage]);

  if (loading && !data) {
    return (
      <div className="min-h-[600px] flex items-center justify-center">
        <LoadingSpinner message="Loading attendance records & leave status..." />
      </div>
    );
  }

  if (error && !data) {
    return (
      <div className="p-8 max-w-4xl mx-auto">
        <div className="bg-rose-500/10 border border-rose-500/20 rounded-2xl p-6 text-center text-rose-200">
          <AlertCircle className="w-12 h-12 text-rose-400 mx-auto mb-3" />
          <h3 className="text-lg font-bold">Failed to Load Attendance Information</h3>
          <p className="text-sm text-slate-400 mt-1">{error}</p>
          <button
            onClick={() => fetchAttendance(currentMonth)}
            className="mt-4 px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold rounded-xl transition-all cursor-pointer"
          >
            Retry Loading
          </button>
        </div>
      </div>
    );
  }

  const student = data?.student;
  const summary = data?.summary;

  return (
    <div className="space-y-8 pb-16 max-w-7xl mx-auto">
      {/* Header Banner */}
      <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-2xs relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2 flex-wrap">
              <Badge variant="primary" size="sm">
                Student Attendance & Leave
              </Badge>
              <Badge variant="neutral" size="sm">
                {student?.academicSessionName}
              </Badge>
              <Badge variant="emerald" size="sm">
                {student?.className} • {student?.sectionName}
              </Badge>
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight flex items-center gap-3">
              <CalendarIcon className="w-7 h-7 text-blue-600" />
              Attendance Record & Leaves
            </h1>
            <p className="text-sm text-slate-600 max-w-2xl leading-relaxed">
              Real-time daily attendance logs recorded by course faculty, aggregated session metrics, and verified leave applications.
            </p>
          </div>

          <div className="flex items-center gap-3 flex-wrap">
            <button
              onClick={() => openLeaveModal()}
              id="student-apply-leave-btn"
              className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-xl shadow-xs flex items-center gap-2 transition-all cursor-pointer border border-blue-700"
            >
              <Plus className="w-4 h-4" />
              Apply for Leave
            </button>
            <button
              onClick={() => fetchAttendance(currentMonth)}
              className="p-2.5 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 rounded-xl transition-all cursor-pointer shadow-2xs"
              title="Refresh attendance records"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
          </div>
        </div>
      </div>

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-6 gap-4">
        {/* Total School Days */}
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Total Days</span>
            <div className="p-2 rounded-xl bg-slate-100 text-slate-700">
              <CalendarIcon className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-slate-900 mt-3">{summary?.totalSchoolDays ?? 0}</p>
          <p className="text-[11px] text-slate-500 mt-1">Recorded sessions</p>
        </div>

        {/* Present Days */}
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-emerald-700 uppercase tracking-wider">Present</span>
            <div className="p-2 rounded-xl bg-emerald-50 text-emerald-700 border border-emerald-200">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-slate-900 mt-3">{summary?.presentCount ?? 0}</p>
          <p className="text-[11px] text-emerald-700 mt-1 font-medium">On-time sessions</p>
        </div>

        {/* Late Days */}
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-amber-800 uppercase tracking-wider">Late Arrival</span>
            <div className="p-2 rounded-xl bg-amber-50 text-amber-700 border border-amber-200">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-slate-900 mt-3">{summary?.lateCount ?? 0}</p>
          <p className="text-[11px] text-amber-700 mt-1 font-medium">Tardy entries</p>
        </div>

        {/* Absent Days */}
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-rose-700 uppercase tracking-wider">Absent</span>
            <div className="p-2 rounded-xl bg-rose-50 text-rose-700 border border-rose-200">
              <XCircle className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-slate-900 mt-3">{summary?.absentCount ?? 0}</p>
          <p className="text-[11px] text-rose-700 mt-1 font-medium">Unexcused absence</p>
        </div>

        {/* Half Day */}
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-600 uppercase tracking-wider">Half Day</span>
            <div className="p-2 rounded-xl bg-slate-100 text-slate-700 border border-slate-200">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-slate-900 mt-3">{summary?.halfDayCount ?? 0}</p>
          <p className="text-[11px] text-slate-500 mt-1 font-medium">0.5 session credit</p>
        </div>

        {/* Approved Leave */}
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-blue-700 uppercase tracking-wider">Excused Leave</span>
            <div className="p-2 rounded-xl bg-blue-50 text-blue-700 border border-blue-200">
              <ShieldCheck className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-slate-900 mt-3">{summary?.leaveCount ?? 0}</p>
          <p className="text-[11px] text-blue-700 mt-1 font-medium">Authorized absence</p>
        </div>

        {/* Overall Percentage (Spans row on larger displays if needed or stays cleanly aligned) */}
      </div>

      {/* Percentage Progress Banner */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-blue-50 text-blue-600 border border-blue-200 font-bold">
            <CalendarIcon className="w-5 h-5" />
          </div>
          <div>
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Overall Session Attendance</span>
            <div className="flex items-baseline gap-2">
              <p className="text-2xl font-black text-slate-900">{summary?.attendancePercentage ?? 100}%</p>
              <Badge variant={(summary?.attendancePercentage ?? 100) >= 85 ? 'success' : (summary?.attendancePercentage ?? 100) >= 75 ? 'warning' : 'danger'} size="sm">
                {(summary?.attendancePercentage ?? 100) >= 85 ? 'Target Met' : (summary?.attendancePercentage ?? 100) >= 75 ? 'Warning Threshold' : 'Action Required'}
              </Badge>
            </div>
          </div>
        </div>

        <div className="w-full sm:w-64">
          <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden border border-slate-200">
            <div
              className={`h-full rounded-full ${
                (summary?.attendancePercentage ?? 100) >= 85
                  ? 'bg-emerald-600'
                  : (summary?.attendancePercentage ?? 100) >= 75
                  ? 'bg-amber-500'
                  : 'bg-rose-600'
              }`}
              style={{ width: `${Math.min(100, Math.max(0, summary?.attendancePercentage ?? 100))}%` }}
            />
          </div>
        </div>
      </div>

      {/* Main Tab Navigation */}
      {!hideTabBar && (
        <div className="flex items-center gap-2 border-b border-white/10 pb-3 overflow-x-auto">
          <button
            onClick={() => setActiveTab('calendar')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'calendar'
                ? 'bg-white/15 text-white shadow-lg backdrop-blur-md border border-white/20'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <CalendarIcon className="w-4 h-4 text-indigo-400" />
            <span>Monthly Calendar</span>
          </button>

          <button
            onClick={() => setActiveTab('records')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'records'
                ? 'bg-white/15 text-white shadow-lg backdrop-blur-md border border-white/20'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <FileText className="w-4 h-4 text-emerald-400" />
            <span>Attendance Records Log ({data?.records?.length || 0})</span>
          </button>

          <button
            onClick={() => setActiveTab('leaves')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'leaves'
                ? 'bg-white/15 text-white shadow-lg backdrop-blur-md border border-white/20'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <ShieldCheck className="w-4 h-4 text-blue-400" />
            <span>My Leave Applications ({data?.leaveApplications?.length || 0})</span>
          </button>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 1: CALENDAR VIEW */}
      {/* ========================================================================= */}
      {activeTab === 'calendar' && (
        <div className="space-y-6">
          {/* Calendar Header & Month Navigation */}
          <div className="bg-slate-900/60 border border-white/10 rounded-2xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 backdrop-blur-md">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                <CalendarIcon className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-lg font-bold text-white tracking-tight">{monthDisplayTitle}</h2>
                <p className="text-xs text-slate-400">Click any date card to view complete session details</p>
              </div>
            </div>

            {/* Navigation & Controls */}
            <div className="flex items-center gap-2">
              <button
                onClick={handlePrevMonth}
                className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/10 transition-all cursor-pointer flex items-center gap-1 text-xs font-medium"
              >
                <ChevronLeft className="w-4 h-4" />
                <span className="hidden sm:inline">Previous</span>
              </button>

              <input
                type="month"
                value={currentMonth}
                onChange={(e) => e.target.value && setCurrentMonth(e.target.value)}
                className="px-3 py-1.5 bg-slate-800/80 border border-white/10 rounded-xl text-xs text-white focus:outline-hidden focus:border-indigo-500 cursor-pointer"
              />

              <button
                onClick={handleNextMonth}
                className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/10 transition-all cursor-pointer flex items-center gap-1 text-xs font-medium"
              >
                <span className="hidden sm:inline">Next</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Calendar Legend Bar */}
          <div className="flex items-center gap-4 flex-wrap text-xs bg-slate-900/40 p-3.5 rounded-xl border border-white/5">
            <div className="flex items-center gap-1.5 text-slate-300">
              <span className="w-3 h-3 rounded-md bg-emerald-500/20 border border-emerald-500/50" />
              <span>Present</span>
            </div>
            <div className="flex items-center gap-1.5 text-slate-300">
              <span className="w-3 h-3 rounded-md bg-rose-500/20 border border-rose-500/50" />
              <span>Absent</span>
            </div>
            <div className="flex items-center gap-1.5 text-slate-300">
              <span className="w-3 h-3 rounded-md bg-amber-500/20 border border-amber-500/50" />
              <span>Late Arrival</span>
            </div>
            <div className="flex items-center gap-1.5 text-slate-300">
              <span className="w-3 h-3 rounded-md bg-blue-500/20 border border-blue-500/50" />
              <span>Excused / Approved Leave</span>
            </div>
            <div className="flex items-center gap-1.5 text-slate-400">
              <span className="w-3 h-3 rounded-md bg-slate-800/50 border border-slate-700" />
              <span>Weekend</span>
            </div>
          </div>

          {/* Calendar Matrix Grid */}
          <div className="bg-slate-900/60 border border-white/10 rounded-2xl p-4 sm:p-6 backdrop-blur-xl shadow-xl overflow-hidden">
            {/* Weekday Headers */}
            <div className="grid grid-cols-7 gap-2 mb-3 text-center">
              {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((dayName, idx) => (
                <div
                  key={dayName}
                  className={`text-xs font-bold py-1.5 uppercase tracking-wider ${
                    idx === 0 || idx === 6 ? 'text-slate-400' : 'text-slate-300'
                  }`}
                >
                  {dayName}
                </div>
              ))}
            </div>

            {/* Calendar Cells */}
            <div className="grid grid-cols-7 gap-2 sm:gap-3">
              {/* Padding for first day of month */}
              {Array.from({ length: (data?.calendarDays || [])[0]?.dayOfWeek || 0 }).map((_, i) => (
                <div
                  key={`empty-${i}`}
                  className="min-h-[85px] sm:min-h-[110px] rounded-xl bg-slate-950/20 border border-white/[0.02]"
                />
              ))}

              {(data?.calendarDays || []).map((day) => {
                const isSelected = selectedDay?.date === day.date;
                const isAbsent = day.status === 'ABSENT';
                const isPresent = day.status === 'PRESENT';
                const isLate = day.status === 'LATE';
                const isHalfDay = day.status === 'HALF_DAY';
                const isExcused = day.status === 'EXCUSED';
                const isWeekend = day.isWeekend;

                let cardStyle = 'bg-slate-900/40 border-white/5 text-slate-300 hover:border-white/20';
                if (isPresent) cardStyle = 'bg-emerald-500/10 border-emerald-500/30 text-emerald-200 hover:border-emerald-500/60';
                if (isAbsent) cardStyle = 'bg-rose-500/10 border-rose-500/30 text-rose-200 hover:border-rose-500/60';
                if (isLate) cardStyle = 'bg-amber-500/10 border-amber-500/30 text-amber-200 hover:border-amber-500/60';
                if (isHalfDay) cardStyle = 'bg-purple-500/10 border-purple-500/30 text-purple-200 hover:border-purple-500/60';
                if (isExcused) cardStyle = 'bg-blue-500/10 border-blue-500/30 text-blue-200 hover:border-blue-500/60';
                if (isWeekend) cardStyle = 'bg-slate-950/40 border-white/[0.03] text-slate-400 opacity-60';

                return (
                  <div
                    key={day.date}
                    onClick={() => setSelectedDay(day)}
                    className={`min-h-[85px] sm:min-h-[110px] p-2.5 rounded-xl border transition-all duration-150 cursor-pointer flex flex-col justify-between group ${cardStyle} ${
                      isSelected ? 'ring-2 ring-indigo-400 shadow-lg' : ''
                    }`}
                  >
                    {/* Day Number Header */}
                    <div className="flex items-center justify-between">
                      <span
                        className={`text-xs sm:text-sm font-black ${
                          day.isToday
                            ? 'w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center'
                            : ''
                        }`}
                      >
                        {day.dayOfMonth}
                      </span>

                      {/* Status Icon Indicator */}
                      <div>
                        {isPresent && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />}
                        {isAbsent && <XCircle className="w-3.5 h-3.5 text-rose-400" />}
                        {isLate && <Clock className="w-3.5 h-3.5 text-amber-400" />}
                        {isHalfDay && <Clock className="w-3.5 h-3.5 text-purple-400" />}
                        {isExcused && <ShieldCheck className="w-3.5 h-3.5 text-blue-400" />}
                      </div>
                    </div>

                    {/* Cell Body Text */}
                    <div className="mt-1 space-y-1">
                      <span
                        className={`text-[10px] font-bold block truncate uppercase tracking-wider ${
                          isPresent
                            ? 'text-emerald-400'
                            : isAbsent
                            ? 'text-rose-400'
                            : isLate
                            ? 'text-amber-400'
                            : isHalfDay
                            ? 'text-purple-400'
                            : isExcused
                            ? 'text-blue-400'
                            : 'text-slate-400'
                        }`}
                      >
                        {day.statusLabel}
                      </span>

                      {day.record?.subjectName && (
                        <p className="text-[10px] text-slate-300 font-medium truncate hidden sm:block">
                          {day.record.subjectName}
                        </p>
                      )}

                      {day.leaveApplication && (
                        <div className="text-[9px] px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-300 font-medium truncate">
                          Leave: {day.leaveApplication.reason}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 2: ATTENDANCE RECORDS LOG TABLE */}
      {/* ========================================================================= */}
      {activeTab === 'records' && (
        <div className="bg-slate-900/60 border border-white/10 rounded-2xl p-6 backdrop-blur-xl space-y-6 shadow-xl">
          {/* Filter Bar */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="relative flex-1 max-w-md">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search subject, instructor, remarks..."
                value={recordSearch}
                onChange={(e) => setRecordSearch(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-slate-800/80 border border-white/10 rounded-xl text-xs text-white focus:outline-hidden focus:border-indigo-500"
              />
            </div>

            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2">
                <Filter className="w-4 h-4 text-slate-400" />
                <select
                  value={recordFilterStatus}
                  onChange={(e) => setRecordFilterStatus(e.target.value)}
                  className="px-3 py-2 bg-slate-800/80 border border-white/10 rounded-xl text-xs text-white focus:outline-hidden focus:border-indigo-500 cursor-pointer"
                >
                  <option value="ALL">All Statuses</option>
                  <option value="PRESENT">Present Only</option>
                  <option value="ABSENT">Absent Only</option>
                  <option value="LATE">Late Arrival Only</option>
                  <option value="HALF_DAY">Half Day Only</option>
                  <option value="EXCUSED">Excused / Leave Only</option>
                </select>
              </div>
            </div>
          </div>

          {/* Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-white/10 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                  <th className="py-3 px-4">Date</th>
                  <th className="py-3 px-4">Subject</th>
                  <th className="py-3 px-4">Class & Section</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Instructor</th>
                  <th className="py-3 px-4">Remarks</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 text-xs text-slate-300">
                {filteredRecords.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-8 text-center text-slate-400">
                      No attendance records found matching your filter.
                    </td>
                  </tr>
                ) : (
                  filteredRecords.map((rec) => {
                    const isAbsent = rec.status === 'ABSENT';
                    return (
                      <tr key={rec.id} className="hover:bg-white/[0.02] transition-colors">
                        <td className="py-3 px-4 font-mono font-medium text-white">{rec.date}</td>
                        <td className="py-3 px-4 font-semibold text-white">{rec.subjectName || 'General Homeroom'}</td>
                        <td className="py-3 px-4 text-slate-400">
                          {rec.className} • {rec.sectionName}
                        </td>
                        <td className="py-3 px-4">
                          {rec.status === 'PRESENT' && <Badge variant="emerald" size="sm">Present</Badge>}
                          {rec.status === 'ABSENT' && <Badge variant="rose" size="sm">Absent</Badge>}
                          {rec.status === 'LATE' && <Badge variant="amber" size="sm">Late</Badge>}
                          {rec.status === 'HALF_DAY' && <Badge variant="purple" size="sm">Half Day</Badge>}
                          {rec.status === 'EXCUSED' && <Badge variant="blue" size="sm">Excused</Badge>}
                        </td>
                        <td className="py-3 px-4 text-slate-300">{rec.recordedByTeacherName || 'Class Faculty'}</td>
                        <td className="py-3 px-4 text-slate-400 max-w-xs truncate">{rec.remarks || '—'}</td>
                        <td className="py-3 px-4 text-right">
                          {isAbsent && (
                            <button
                              onClick={() => openLeaveModal(rec.date)}
                              className="px-2.5 py-1 rounded-lg bg-indigo-600/20 hover:bg-indigo-600/40 text-indigo-300 text-[11px] font-semibold transition-all cursor-pointer inline-flex items-center gap-1"
                            >
                              <Plus className="w-3 h-3" />
                              Apply Leave
                            </button>
                          )}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 3: MY LEAVE APPLICATIONS */}
      {/* ========================================================================= */}
      {activeTab === 'leaves' && (
        <div className="bg-slate-900/60 border border-white/10 rounded-2xl p-6 backdrop-blur-xl space-y-6 shadow-xl">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-lg font-bold text-white tracking-tight flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-blue-400" />
                Submitted Leave Applications
              </h2>
              <p className="text-xs text-slate-400">
                Track status of submitted absence excuses, administrative remarks, and doctor notes.
              </p>
            </div>

            <div className="flex items-center gap-3">
              <select
                value={leaveFilterStatus}
                onChange={(e) => setLeaveFilterStatus(e.target.value)}
                className="px-3 py-2 bg-slate-800/80 border border-white/10 rounded-xl text-xs text-white focus:outline-hidden focus:border-indigo-500 cursor-pointer"
              >
                <option value="ALL">All Applications</option>
                <option value="PENDING">Pending Review</option>
                <option value="APPROVED">Approved Leaves</option>
                <option value="REJECTED">Declined Requests</option>
              </select>

              <button
                onClick={() => openLeaveModal()}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl shadow-lg shadow-indigo-600/30 flex items-center gap-1.5 transition-all cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                New Application
              </button>
            </div>
          </div>

          {/* Leave Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredLeaves.length === 0 ? (
              <div className="col-span-full py-12 text-center text-slate-400 bg-slate-950/30 rounded-2xl border border-white/5">
                <ShieldCheck className="w-12 h-12 text-slate-400 mx-auto mb-3" />
                <p className="text-sm font-semibold text-slate-300">No leave applications found</p>
                <p className="text-xs text-slate-400 mt-1">
                  You have not submitted any leave applications for this status.
                </p>
              </div>
            ) : (
              filteredLeaves.map((leave) => {
                const isPending = leave.status === 'PENDING';
                const isApproved = leave.status === 'APPROVED';
                const isRejected = leave.status === 'REJECTED';

                return (
                  <div
                    key={leave.id}
                    className="bg-slate-900/50 border border-white/10 hover:border-white/20 rounded-2xl p-5 space-y-4 backdrop-blur-md transition-all shadow-lg relative flex flex-col justify-between"
                  >
                    <div>
                      {/* Card Header */}
                      <div className="flex items-start justify-between gap-3">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-mono text-xs font-bold text-white bg-white/10 px-2.5 py-1 rounded-lg">
                              {leave.leaveDate} {leave.endDate ? `to ${leave.endDate}` : ''}
                            </span>
                            <Badge
                              variant={
                                leave.reason === 'Medical'
                                  ? 'rose'
                                  : leave.reason === 'Academic Competition'
                                  ? 'indigo'
                                  : 'neutral'
                              }
                              size="sm"
                            >
                              {leave.reason}
                            </Badge>
                          </div>
                          <p className="text-xs text-slate-400">
                            Submitted on {leave.submissionDate} • {leave.className} ({leave.sectionName})
                          </p>
                        </div>

                        <div>
                          {isPending && <Badge variant="amber" size="sm">Pending Review</Badge>}
                          {isApproved && <Badge variant="emerald" size="sm">Approved</Badge>}
                          {isRejected && <Badge variant="rose" size="sm">Declined</Badge>}
                        </div>
                      </div>

                      {/* Description */}
                      <p className="text-xs text-slate-300 mt-3 leading-relaxed line-clamp-3 bg-slate-950/40 p-3 rounded-xl border border-white/5">
                        {leave.description}
                      </p>

                      {/* Attachment if exists */}
                      {leave.attachmentUrl && (
                        <div className="mt-3 flex items-center gap-2 text-xs text-indigo-300 bg-indigo-500/10 px-3 py-2 rounded-xl border border-indigo-500/20">
                          <Paperclip className="w-3.5 h-3.5 flex-shrink-0" />
                          <span className="truncate flex-1 font-medium">
                            {leave.attachmentName || 'Supporting_Document.pdf'}
                          </span>
                          <a
                            href={leave.attachmentUrl}
                            target="_blank"
                            rel="noreferrer"
                            className="hover:underline flex items-center gap-1 text-[11px] font-bold text-indigo-400"
                          >
                            View <ExternalLink className="w-3 h-3" />
                          </a>
                        </div>
                      )}

                      {/* Faculty Review Status Box */}
                      {leave.reviewedByName && (
                        <div
                          className={`mt-3 p-3 rounded-xl border text-xs space-y-1 ${
                            isApproved
                              ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-200'
                              : 'bg-rose-500/10 border-rose-500/20 text-rose-200'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-bold flex items-center gap-1.5">
                              {isApproved ? <Check className="w-3.5 h-3.5" /> : <X className="w-3.5 h-3.5" />}
                              Reviewed by {leave.reviewedByName} ({leave.reviewedByRole})
                            </span>
                            <span className="text-[10px] text-slate-400 font-mono">
                              {leave.reviewedAt ? new Date(leave.reviewedAt).toLocaleDateString() : ''}
                            </span>
                          </div>
                          {leave.adminRemarks && (
                            <p className="text-[11px] text-slate-300 font-normal mt-0.5">
                              "{leave.adminRemarks}"
                            </p>
                          )}
                        </div>
                      )}
                    </div>

                    {/* Card Actions */}
                    <div className="pt-3 border-t border-white/5 flex items-center justify-between">
                      <button
                        onClick={() => setSelectedLeave(leave)}
                        className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 transition-colors cursor-pointer"
                      >
                        View Full Details →
                      </button>

                      {isPending && (
                        <button
                          onClick={() => handleCancelLeave(leave.id)}
                          disabled={cancellingLeaveId === leave.id}
                          className="px-3 py-1 bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 text-xs font-semibold rounded-lg border border-rose-500/20 transition-all cursor-pointer flex items-center gap-1.5"
                        >
                          <Trash2 className="w-3 h-3" />
                          <span>{cancellingLeaveId === leave.id ? 'Cancelling...' : 'Withdraw'}</span>
                        </button>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 1: DAY ATTENDANCE BREAKDOWN */}
      {/* ========================================================================= */}
      {selectedDay && (
        <Modal
          isOpen={!!selectedDay}
          onClose={() => setSelectedDay(null)}
          title={`Attendance Details: ${selectedDay.date}`}
          maxWidth="max-w-lg"
        >
          <div className="space-y-5">
            <div className="flex items-center justify-between p-4 rounded-xl bg-slate-900/60 border border-white/10">
              <div>
                <p className="text-xs text-slate-400 font-mono">{selectedDay.date}</p>
                <p className="text-base font-bold text-white mt-0.5">
                  {new Date(selectedDay.date + 'T00:00:00').toLocaleDateString('default', {
                    weekday: 'long',
                    month: 'long',
                    day: 'numeric',
                    year: 'numeric'
                  })}
                </p>
              </div>
              <div>
                {selectedDay.status === 'PRESENT' && <Badge variant="emerald">Present</Badge>}
                {selectedDay.status === 'ABSENT' && <Badge variant="rose">Absent</Badge>}
                {selectedDay.status === 'LATE' && <Badge variant="amber">Late</Badge>}
                {selectedDay.status === 'HALF_DAY' && <Badge variant="purple">Half Day</Badge>}
                {selectedDay.status === 'EXCUSED' && <Badge variant="blue">Excused Leave</Badge>}
                {selectedDay.status === 'WEEKEND' && <Badge variant="neutral">Weekend</Badge>}
                {selectedDay.status === 'FUTURE' && <Badge variant="neutral">Upcoming</Badge>}
                {selectedDay.status === 'NO_RECORD' && <Badge variant="neutral">No Record</Badge>}
              </div>
            </div>

            {selectedDay.record ? (
              <div className="space-y-3 bg-slate-900/40 p-4 rounded-xl border border-white/5 text-xs text-slate-300">
                <div className="flex justify-between py-1 border-b border-white/5">
                  <span className="text-slate-400">Class Cohort:</span>
                  <span className="font-semibold text-white">
                    {selectedDay.record.className} • {selectedDay.record.sectionName}
                  </span>
                </div>
                <div className="flex justify-between py-1 border-b border-white/5">
                  <span className="text-slate-400">Subject Session:</span>
                  <span className="font-semibold text-white">
                    {selectedDay.record.subjectName || 'Homeroom / Core Routine'}
                  </span>
                </div>
                <div className="flex justify-between py-1 border-b border-white/5">
                  <span className="text-slate-400">Recorded By:</span>
                  <span className="font-semibold text-white">
                    {selectedDay.record.recordedByTeacherName || 'Academic Instructor'}
                  </span>
                </div>
                <div className="flex justify-between py-1 border-b border-white/5">
                  <span className="text-slate-400">Faculty Remarks:</span>
                  <span className="font-medium text-white">{selectedDay.record.remarks || 'Standard entry logged'}</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-400">Logged At:</span>
                  <span className="font-mono text-slate-400">
                    {new Date(selectedDay.record.createdAt).toLocaleTimeString()}
                  </span>
                </div>
              </div>
            ) : (
              <div className="text-center py-6 text-slate-400 text-xs bg-slate-900/30 rounded-xl border border-white/5">
                {selectedDay.isWeekend
                  ? 'Institutional weekend — no class sessions scheduled.'
                  : selectedDay.isFuture
                  ? 'Upcoming academic session date.'
                  : 'No formal attendance roll-call was scheduled or recorded for this date.'}
              </div>
            )}

            {/* If absent, offer instant leave application */}
            {selectedDay.status === 'ABSENT' && (
              <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/20 text-xs text-rose-200 space-y-2">
                <div className="flex items-center gap-2 font-bold text-rose-300">
                  <AlertTriangle className="w-4 h-4" />
                  <span>Unexcused Absence Flagged</span>
                </div>
                <p className="text-slate-300 text-[11px]">
                  Institutional policy permits students to submit documentation or medical certificates to convert unexcused absences to excused status.
                </p>
                <button
                  onClick={() => {
                    const d = selectedDay.date;
                    setSelectedDay(null);
                    openLeaveModal(d);
                  }}
                  className="w-full mt-2 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-lg transition-all cursor-pointer flex items-center justify-center gap-2"
                >
                  <Plus className="w-4 h-4" />
                  Submit Leave Application for {selectedDay.date}
                </button>
              </div>
            )}
          </div>
        </Modal>
      )}

      {/* ========================================================================= */}
      {/* MODAL 2: APPLY FOR LEAVE */}
      {/* ========================================================================= */}
      {isLeaveModalOpen && (
        <Modal
          isOpen={isLeaveModalOpen}
          onClose={() => !leaveSubmitting && setIsLeaveModalOpen(false)}
          title="Submit Student Leave Application"
          maxWidth="max-w-xl"
        >
          <form onSubmit={handleSubmitLeave} className="space-y-4">
            {leaveFormError && (
              <div className="p-3 bg-rose-500/10 border border-rose-500/20 rounded-xl text-rose-200 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 flex-shrink-0" />
                <span>{leaveFormError}</span>
              </div>
            )}

            {leaveSuccessMessage && (
              <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-emerald-200 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
                <span>{leaveSuccessMessage}</span>
              </div>
            )}

            {/* Date Pickers */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                  <CalendarIcon className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Leave Start Date *</span>
                </label>
                <input
                  type="date"
                  required
                  value={leaveDate}
                  onChange={(e) => setLeaveDate(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-800/80 border border-white/10 rounded-xl text-xs text-white focus:outline-hidden focus:border-indigo-500"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                  <CalendarIcon className="w-3.5 h-3.5 text-slate-400" />
                  <span>End Date (Optional for multi-day)</span>
                </label>
                <input
                  type="date"
                  value={leaveEndDate}
                  onChange={(e) => setLeaveEndDate(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-800/80 border border-white/10 rounded-xl text-xs text-white focus:outline-hidden focus:border-indigo-500"
                />
              </div>
            </div>

            {/* Reason Category */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-indigo-400" />
                <span>Absence Reason Category *</span>
              </label>
              <select
                required
                value={leaveReason}
                onChange={(e) => setLeaveReason(e.target.value)}
                className="w-full px-3 py-2 bg-slate-800/80 border border-white/10 rounded-xl text-xs text-white focus:outline-hidden focus:border-indigo-500 cursor-pointer"
              >
                <option value="Medical">Medical / Health Condition</option>
                <option value="Family Emergency">Family Emergency</option>
                <option value="Academic Competition">Academic Competition / Olympiad</option>
                <option value="Bereavement">Bereavement</option>
                <option value="Religious Observance">Religious Observance</option>
                <option value="Personal">Personal Grounds</option>
                <option value="Other">Other Verified Reason</option>
              </select>
            </div>

            {/* Description Textarea */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300 flex items-center justify-between">
                <span>Detailed Explanation *</span>
                <span className="text-[11px] text-slate-400 font-normal">{leaveDescription.length} / 500 chars</span>
              </label>
              <textarea
                required
                rows={3}
                maxLength={500}
                placeholder="Explain the circumstance, scheduled clinic visit, or academic event requiring leave..."
                value={leaveDescription}
                onChange={(e) => setLeaveDescription(e.target.value)}
                className="w-full px-3 py-2 bg-slate-800/80 border border-white/10 rounded-xl text-xs text-white focus:outline-hidden focus:border-indigo-500"
              />
            </div>

            {/* Supporting Document / Attachment Simulation */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300 flex items-center justify-between">
                <span className="flex items-center gap-1.5">
                  <Paperclip className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Medical Certificate / Documentation (URL or Attachment)</span>
                </span>
                <span className="text-[10px] text-slate-400">PDF / Image</span>
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="https://... or sample medical pass link"
                  value={attachmentUrl}
                  onChange={(e) => setAttachmentUrl(e.target.value)}
                  className="flex-1 px-3 py-2 bg-slate-800/80 border border-white/10 rounded-xl text-xs text-white focus:outline-hidden focus:border-indigo-500"
                />
                <button
                  type="button"
                  onClick={() => {
                    setAttachmentUrl('https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?auto=format&fit=crop&q=80&w=800');
                    setAttachmentName('Verified_Medical_Certificate_Cambridge_Health.pdf');
                  }}
                  className="px-3 py-2 bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300 text-xs font-semibold rounded-xl transition-all cursor-pointer whitespace-nowrap"
                >
                  Insert Sample Pass
                </button>
              </div>
            </div>

            {/* Footer Form Buttons */}
            <div className="pt-4 border-t border-white/10 flex items-center justify-end gap-3">
              <button
                type="button"
                disabled={leaveSubmitting}
                onClick={() => setIsLeaveModalOpen(false)}
                className="px-4 py-2 bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-semibold rounded-xl transition-all cursor-pointer"
              >
                Cancel
              </button>

              <button
                type="submit"
                disabled={leaveSubmitting}
                id="submit-leave-application-btn"
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl shadow-lg shadow-indigo-600/30 flex items-center gap-2 transition-all cursor-pointer"
              >
                {leaveSubmitting ? (
                  <>
                    <LoadingSpinner size="sm" />
                    <span>Submitting Application...</span>
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Submit for Faculty Review</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </Modal>
      )}

      {/* ========================================================================= */}
      {/* MODAL 3: VIEW LEAVE APPLICATION DETAILS */}
      {/* ========================================================================= */}
      {selectedLeave && (
        <Modal
          isOpen={!!selectedLeave}
          onClose={() => setSelectedLeave(null)}
          title={`Leave Application #${selectedLeave.id.slice(-6).toUpperCase()}`}
          maxWidth="max-w-lg"
        >
          <div className="space-y-4 text-xs text-slate-300">
            <div className="flex items-center justify-between p-4 rounded-xl bg-slate-900/60 border border-white/10">
              <div>
                <p className="font-mono text-white text-sm font-bold">
                  {selectedLeave.leaveDate} {selectedLeave.endDate ? `to ${selectedLeave.endDate}` : ''}
                </p>
                <p className="text-slate-400 mt-0.5">Submitted on {selectedLeave.submissionDate}</p>
              </div>
              <div>
                {selectedLeave.status === 'PENDING' && <Badge variant="amber">Pending Review</Badge>}
                {selectedLeave.status === 'APPROVED' && <Badge variant="emerald">Approved</Badge>}
                {selectedLeave.status === 'REJECTED' && <Badge variant="rose">Declined</Badge>}
              </div>
            </div>

            <div className="space-y-2 bg-slate-900/40 p-4 rounded-xl border border-white/5">
              <div className="flex justify-between py-1 border-b border-white/5">
                <span className="text-slate-400">Category Reason:</span>
                <span className="font-semibold text-white">{selectedLeave.reason}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-white/5">
                <span className="text-slate-400">Class & Section:</span>
                <span className="font-semibold text-white">
                  {selectedLeave.className} • {selectedLeave.sectionName}
                </span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-400">Student Roll No:</span>
                <span className="font-mono text-white">{selectedLeave.rollNumber}</span>
              </div>
            </div>

            <div>
              <p className="text-slate-400 font-semibold mb-1">Student Stated Explanation:</p>
              <div className="p-3 bg-slate-950/60 rounded-xl border border-white/5 text-slate-200 leading-relaxed">
                {selectedLeave.description}
              </div>
            </div>

            {selectedLeave.attachmentUrl && (
              <div>
                <p className="text-slate-400 font-semibold mb-1">Uploaded Attachment:</p>
                <a
                  href={selectedLeave.attachmentUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-2 p-3 bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 rounded-xl hover:bg-indigo-500/20 transition-all font-medium"
                >
                  <Paperclip className="w-4 h-4 text-indigo-400" />
                  <span className="truncate flex-1">{selectedLeave.attachmentName || 'Supporting_Doc.pdf'}</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            )}

            {selectedLeave.reviewedByName && (
              <div
                className={`p-4 rounded-xl border space-y-1.5 ${
                  selectedLeave.status === 'APPROVED'
                    ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-200'
                    : 'bg-rose-500/10 border-rose-500/20 text-rose-200'
                }`}
              >
                <p className="font-bold flex items-center gap-1.5">
                  {selectedLeave.status === 'APPROVED' ? <Check className="w-4 h-4" /> : <X className="w-4 h-4" />}
                  Administrative Review Decision
                </p>
                <p className="text-slate-300">
                  Evaluated by <strong className="text-white">{selectedLeave.reviewedByName}</strong> ({selectedLeave.reviewedByRole}) on{' '}
                  {selectedLeave.reviewedAt ? new Date(selectedLeave.reviewedAt).toLocaleString() : ''}
                </p>
                {selectedLeave.adminRemarks && (
                  <p className="mt-1 p-2 bg-slate-950/40 rounded-lg text-slate-200 font-mono text-[11px]">
                    "{selectedLeave.adminRemarks}"
                  </p>
                )}
              </div>
            )}
          </div>
        </Modal>
      )}
    </div>
  );
};
