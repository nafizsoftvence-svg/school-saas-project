import React, { useEffect, useState, useMemo } from 'react';
import {
  Award,
  Search,
  Filter,
  Calendar,
  Layers,
  GraduationCap,
  Download,
  Printer,
  ChevronRight,
  TrendingUp,
  CheckCircle2,
  AlertCircle,
  Clock,
  RefreshCw,
  Eye,
  Info,
  ShieldCheck,
  Percent,
  Sparkles,
  BarChart3,
  FileText,
  Star
} from 'lucide-react';
import { Badge } from '../../components/ui/Badge.js';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner.js';
import { Modal } from '../../components/ui/Modal.js';
import { EmptyState } from '../../components/ui/EmptyState.js';
import { api } from '../../services/api.js';
import { triggerSafePrint } from '../../utils/printPdf.js';
import {
  StudentExamResult,
  GradingScaleItem,
  StudentClassInfo
} from '../../types/index.js';

interface StudentResultsPageProps {
  onNavigate?: (view: string) => void;
}

export const StudentResultsPage: React.FC<StudentResultsPageProps> = ({ onNavigate }) => {
  const [results, setResults] = useState<StudentExamResult[]>([]);
  const [gradingScale, setGradingScale] = useState<GradingScaleItem[]>([]);
  const [classInfo, setClassInfo] = useState<StudentClassInfo | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Active Selected Result (for main inspection view)
  const [selectedResultId, setSelectedResultId] = useState<string>('');

  // Filters & Search
  const [searchTerm, setSearchTerm] = useState('');
  const [sessionFilter, setSessionFilter] = useState<string>('ALL');
  const [academicYearFilter, setAcademicYearFilter] = useState<string>('ALL');

  // Modals
  const [showTranscriptModal, setShowTranscriptModal] = useState(false);
  const [showGradingScaleModal, setShowGradingScaleModal] = useState(false);

  const loadData = async (isManualRefresh = false) => {
    try {
      if (isManualRefresh) setRefreshing(true);
      else setLoading(true);
      setError(null);

      const [resData, scaleData, classRes] = await Promise.all([
        api.getMyResults({
          academicSessionId: sessionFilter !== 'ALL' ? sessionFilter : undefined,
          academicYear: academicYearFilter !== 'ALL' ? academicYearFilter : undefined,
          search: searchTerm || undefined
        }),
        api.getGradingScale(),
        api.getMyClassInfo()
      ]);

      if (resData.success && resData.data) {
        const items = Array.isArray(resData.data)
          ? resData.data
          : Array.isArray((resData.data as any).data)
          ? (resData.data as any).data
          : [];
        setResults(items);
        if (items.length > 0) {
          // If current selected result is not in the new results, select the first one (most recent)
          if (!selectedResultId || !items.some((r: any) => r.id === selectedResultId)) {
            setSelectedResultId(items?.[0]?.id || '');
          }
        } else {
          setSelectedResultId('');
        }
      } else {
        setError(resData.error || 'Failed to load examination results.');
      }

      if (scaleData.success && scaleData.data) {
        const scaleItems = Array.isArray(scaleData.data)
          ? scaleData.data
          : Array.isArray((scaleData.data as any).data)
          ? (scaleData.data as any).data
          : [];
        setGradingScale(scaleItems);
      }

      if (classRes.success && classRes.data) {
        setClassInfo(classRes.data);
      }
    } catch (err: any) {
      console.error('Error loading examination results:', err);
      setError(err.message || 'Network error while retrieving academic performance records.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [sessionFilter, academicYearFilter]);

  // Derive unique academic sessions and years for filter dropdowns
  const availableSessions = useMemo(() => {
    const map = new Map<string, string>();
    (results || []).forEach((r) => {
      if (r?.academicSessionId && !map.has(r.academicSessionId)) {
        map.set(r.academicSessionId, r.academicSessionName || 'Academic Session');
      }
    });
    return Array.from(map.entries()).map(([id, name]) => ({ id, name }));
  }, [results]);

  const availableYears = useMemo(() => {
    return Array.from(new Set((results || []).map((r) => r?.academicYear).filter(Boolean)));
  }, [results]);

  // The active result being viewed in full detail
  const activeResult = useMemo(() => {
    return (results || []).find((r) => r.id === selectedResultId) || results?.[0] || null;
  }, [results, selectedResultId]);

  // Overall Cumulative GPA & Stats across all historical records
  const cumulativeStats = useMemo(() => {
    if (!results || results.length === 0) {
      return { cumulativeGPA: 0, totalExams: 0, highestPercentage: 0, averagePercentage: 0 };
    }
    const gpaSum = results.reduce((acc, curr) => acc + (curr?.summary?.gpa || 0), 0);
    const cumulativeGPA = parseFloat((gpaSum / results.length).toFixed(2));
    const percentages = results.map((r) => r?.summary?.overallPercentage || 0);
    const highestPercentage = percentages.length > 0 ? Math.max(...percentages) : 0;
    const avgPercentage = parseFloat(
      (results.reduce((acc, curr) => acc + (curr?.summary?.overallPercentage || 0), 0) / results.length).toFixed(1)
    );

    return {
      cumulativeGPA,
      totalExams: results.length,
      highestPercentage,
      averagePercentage: avgPercentage
    };
  }, [results]);

  const formatDate = (dateStr: string) => {
    try {
      return new Date(dateStr).toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric'
      });
    } catch {
      return dateStr;
    }
  };

  const getResultBadge = (status: string) => {
    const s = status.toUpperCase();
    if (s.includes('PASS') || s.includes('HONORS')) {
      return (
        <Badge variant="success" size="sm" dot>
          {status}
        </Badge>
      );
    }
    return (
      <Badge variant="danger" size="sm" dot>
        {status}
      </Badge>
    );
  };

  const getGradePill = (grade: string) => {
    const g = grade.toUpperCase();
    if (g.startsWith('A')) {
      return 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30';
    }
    if (g.startsWith('B')) {
      return 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30';
    }
    if (g.startsWith('C')) {
      return 'bg-amber-500/20 text-amber-300 border-amber-500/30';
    }
    return 'bg-rose-500/20 text-rose-300 border-rose-500/30';
  };

  return (
    <div id="student-results-view" className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-slate-900/60 border border-white/10 p-6 rounded-2xl backdrop-blur-xl shadow-xl">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <Badge variant="success" size="sm" dot>
              Official Transcripts
            </Badge>
            <span className="text-xs text-slate-400 font-mono">PART 4E — EXAM RESULTS & MARKS</span>
          </div>
          <h1 className="text-2xl font-black tracking-tight text-white flex items-center gap-3">
            <Award className="w-7 h-7 text-emerald-400" />
            <span>Examination Results & Grade Sheets</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            Review detailed marks, subject-wise grade point breakdowns, cumulative GPA, and authenticated academic performance records.
          </p>
        </div>

        <div className="flex items-center flex-wrap gap-2.5">
          <button
            id="refresh-results-btn"
            onClick={() => loadData(true)}
            disabled={refreshing || loading}
            className="px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300 hover:text-white text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin text-emerald-400' : ''}`} />
            <span>{refreshing ? 'Refreshing...' : 'Refresh'}</span>
          </button>

          <button
            id="open-grading-scale-btn"
            onClick={() => setShowGradingScaleModal(true)}
            className="px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300 hover:text-white text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer"
          >
            <Info className="w-3.5 h-3.5 text-indigo-400" />
            <span>Grading Scale</span>
          </button>

          {activeResult && (
            <button
              id="open-transcript-btn"
              onClick={() => setShowTranscriptModal(true)}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-500 hover:to-teal-600 text-white text-xs font-bold flex items-center gap-2 shadow-lg shadow-emerald-600/20 border border-emerald-400/30 transition-all cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Official Grade Sheet</span>
            </button>
          )}

          {onNavigate && (
            <button
              onClick={() => onNavigate('student-progress')}
              className="px-3.5 py-2 rounded-xl bg-indigo-600/20 hover:bg-indigo-600/30 border border-indigo-500/30 text-indigo-300 text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <span>Academic Progress</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* KPI Performance Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Latest / Selected GPA */}
        <div className="bg-slate-900/40 border border-white/10 p-5 rounded-2xl backdrop-blur-md relative overflow-hidden">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              {activeResult ? activeResult.term : 'Selected Term'} GPA
            </span>
            <Award className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-3xl font-black text-emerald-300 flex items-baseline gap-1.5">
            <span>{activeResult?.summary?.gpa != null ? Number(activeResult.summary.gpa).toFixed(2) : '0.00'}</span>
            <span className="text-xs font-semibold text-slate-400">/ 4.00</span>
          </div>
          <div className="flex items-center gap-2 mt-2">
            <span className={`px-2 py-0.5 rounded-md text-[11px] font-bold border ${getGradePill(activeResult?.summary?.overallGrade || 'A')}`}>
              Grade {activeResult?.summary?.overallGrade || '—'}
            </span>
            <span className="text-[11px] text-slate-400">
              {activeResult?.summary ? `${activeResult.summary.overallPercentage}% Score` : 'No active record'}
            </span>
          </div>
        </div>

        {/* Cumulative Historical GPA */}
        <div className="bg-slate-900/40 border border-white/10 p-5 rounded-2xl backdrop-blur-md">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Cumulative GPA</span>
            <TrendingUp className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="text-3xl font-black text-indigo-300 flex items-baseline gap-1.5">
            <span>{(cumulativeStats.cumulativeGPA || 0).toFixed(2)}</span>
            <span className="text-xs font-semibold text-slate-400">/ 4.00</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-2">
            Calculated across {cumulativeStats.totalExams} published terms
          </p>
        </div>

        {/* Aggregate Marks in Selected Exam */}
        <div className="bg-slate-900/40 border border-white/10 p-5 rounded-2xl backdrop-blur-md">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Total Marks Obtained</span>
            <BarChart3 className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-3xl font-black text-cyan-300 flex items-baseline gap-1.5">
            <span>{activeResult?.summary?.totalObtainedMarks ?? 0}</span>
            <span className="text-xs font-semibold text-slate-400">/ {activeResult?.summary?.totalFullMarks ?? 0}</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-2">
            Pass Benchmark: {activeResult?.summary?.totalPassMarks ?? 0} Marks
          </p>
        </div>

        {/* Result & Standing Status */}
        <div className="bg-slate-900/40 border border-white/10 p-5 rounded-2xl backdrop-blur-md">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Standing & Status</span>
            <ShieldCheck className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-black text-white mt-1">
            {activeResult?.summary.resultStatus || 'PASSED'}
          </div>
          <div className="flex items-center gap-1.5 mt-2">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-[11px] text-amber-300 font-semibold">
              {activeResult?.summary.gpa && activeResult.summary.gpa >= 3.8 ? 'Honors Distinction' : 'Academic Good Standing'}
            </span>
          </div>
        </div>
      </div>

      {/* History Selection Tabs & Search Controls */}
      <div className="bg-slate-900/50 border border-white/10 p-4 rounded-2xl backdrop-blur-xl space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          {/* History Term Selector Chips */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 max-w-full">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1 flex-shrink-0 mr-1">
              <Clock className="w-3.5 h-3.5 text-indigo-400" />
              <span>Select Exam:</span>
            </span>
            {(results || []).map((res) => {
              const isSelected = activeResult?.id === res.id;
              return (
                <button
                  key={res.id}
                  id={`select-result-btn-${res.id}`}
                  onClick={() => setSelectedResultId(res.id)}
                  className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer flex items-center gap-2 border ${
                    isSelected
                      ? 'bg-emerald-600 text-white border-emerald-400 shadow-md shadow-emerald-600/30'
                      : 'bg-slate-950/60 text-slate-300 border-white/10 hover:bg-white/5 hover:text-white'
                  }`}
                >
                  <span>{res.examName}</span>
                  <span
                    className={`text-[10px] px-1.5 py-0.5 rounded-md font-mono ${
                      isSelected ? 'bg-emerald-800 text-emerald-100' : 'bg-white/10 text-slate-400'
                    }`}
                  >
                    {res.academicYear}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Academic Session Filter */}
          <div className="flex items-center gap-2 flex-shrink-0">
            <div className="flex items-center gap-1.5 bg-slate-950/60 border border-white/10 px-3 py-1.5 rounded-xl text-xs">
              <Filter className="w-3.5 h-3.5 text-slate-400" />
              <select
                id="filter-result-session"
                value={sessionFilter}
                onChange={(e) => setSessionFilter(e.target.value)}
                className="bg-transparent text-slate-200 focus:outline-none cursor-pointer"
              >
                <option value="ALL" className="bg-slate-900 text-white">All Sessions</option>
                {(availableSessions || []).map((s) => (
                  <option key={s.id} value={s.id} className="bg-slate-900 text-white">
                    {s.name}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Main Results Table & Assessment Breakdown */}
      {loading ? (
        <div className="p-16 flex flex-col items-center justify-center bg-slate-900/30 border border-white/10 rounded-2xl">
          <LoadingSpinner size="lg" />
          <p className="text-xs text-slate-400 mt-4 font-medium">Calculating grades and subject points from database...</p>
        </div>
      ) : error ? (
        <div className="p-8 bg-rose-500/10 border border-rose-500/20 rounded-2xl flex items-start gap-4 text-rose-300">
          <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
          <div>
            <h3 className="text-sm font-bold text-rose-200">Unable to load examination results</h3>
            <p className="text-xs mt-1">{error}</p>
            <button
              onClick={() => loadData()}
              className="mt-3 px-3 py-1.5 bg-rose-500/20 hover:bg-rose-500/30 text-rose-200 rounded-lg text-xs font-semibold transition-all cursor-pointer"
            >
              Try Again
            </button>
          </div>
        </div>
      ) : !activeResult ? (
        <EmptyState
          icon={Award}
          title="No Published Results Available"
          description="There are no published examination results found for your account under the selected session."
        />
      ) : (
        <div className="space-y-6">
          {/* Active Examination Header Card */}
          <div className="bg-slate-900/60 border border-white/10 rounded-2xl p-6 backdrop-blur-xl shadow-xl">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/10 pb-5">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-[10px] font-black uppercase tracking-widest text-emerald-400">
                    {activeResult.academicSessionName} • {activeResult.term}
                  </span>
                  {getResultBadge(activeResult.summary.resultStatus)}
                </div>
                <h2 className="text-xl font-black text-white">{activeResult.examName}</h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Published on {formatDate(activeResult.publishDate)} • Evaluated across {activeResult?.subjectScores?.length || 0} Subjects
                </p>
              </div>

              {/* Aggregated Score Gauge Box */}
              <div className="flex items-center gap-4 bg-slate-950/60 border border-white/10 px-5 py-3 rounded-xl">
                <div>
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Overall Percentage</span>
                  <div className="text-2xl font-black text-white">{activeResult.summary.overallPercentage}%</div>
                </div>
                <div className="h-9 w-px bg-white/10" />
                <div>
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Grade Point</span>
                  <div className="text-2xl font-black text-emerald-300">{Number(activeResult.summary?.gpa ?? 0).toFixed(2)}</div>
                </div>
                <div className="h-9 w-px bg-white/10" />
                <div className="text-center">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Overall</span>
                  <span className={`px-2.5 py-1 rounded-lg text-xs font-black border ${getGradePill(activeResult.summary?.overallGrade || 'A')} inline-block mt-0.5`}>
                    {activeResult.summary?.overallGrade || '—'}
                  </span>
                </div>
              </div>
            </div>

            {/* Subject-wise Marks Table */}
            <div className="mt-6 overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-white/10 text-[11px] font-bold uppercase tracking-wider text-slate-400">
                    <th className="py-3 px-3">Subject & Code</th>
                    <th className="py-3 px-3 text-center">Credits</th>
                    <th className="py-3 px-3 text-center">Full Marks</th>
                    <th className="py-3 px-3 text-center">Pass Marks</th>
                    <th className="py-3 px-3 text-center">Marks Obtained</th>
                    <th className="py-3 px-3 text-center">Percentage</th>
                    <th className="py-3 px-3 text-center">Grade</th>
                    <th className="py-3 px-3 text-center">Grade Point</th>
                    <th className="py-3 px-3 text-right">Remarks</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5 text-xs text-slate-300">
                  {(activeResult.subjectScores || []).map((subj) => {
                    const isPassing = subj.obtainedMarks >= subj.passMarks;
                    return (
                      <tr key={subj.subjectId} className="hover:bg-white/[0.02] transition-colors">
                        <td className="py-3.5 px-3">
                          <div className="font-bold text-white">{subj.subjectName}</div>
                          <div className="text-[11px] font-mono text-indigo-300">{subj.subjectCode}</div>
                        </td>
                        <td className="py-3.5 px-3 text-center font-mono text-slate-400">{subj.credits}</td>
                        <td className="py-3.5 px-3 text-center font-mono text-slate-300">{subj.fullMarks}</td>
                        <td className="py-3.5 px-3 text-center font-mono text-slate-400">{subj.passMarks}</td>
                        <td className="py-3.5 px-3 text-center font-mono font-bold text-white">
                          <span className={isPassing ? 'text-emerald-300' : 'text-rose-400'}>
                            {subj.obtainedMarks}
                          </span>
                        </td>
                        <td className="py-3.5 px-3 text-center">
                          <div className="font-semibold text-slate-200">{subj.percentage}%</div>
                          {/* Mini Progress Bar */}
                          <div className="w-16 bg-white/10 h-1.5 rounded-full mx-auto mt-1 overflow-hidden">
                            <div
                              className="bg-emerald-400 h-full rounded-full"
                              style={{ width: `${Math.min(subj.percentage, 100)}%` }}
                            />
                          </div>
                        </td>
                        <td className="py-3.5 px-3 text-center">
                          <span className={`px-2 py-0.5 rounded-md font-bold text-xs border ${getGradePill(subj.grade)}`}>
                            {subj.grade}
                          </span>
                        </td>
                        <td className="py-3.5 px-3 text-center font-mono font-bold text-slate-200">
                          {Number(subj.gradePoint ?? 0).toFixed(2)}
                        </td>
                        <td className="py-3.5 px-3 text-right">
                          <span className="text-[11px] font-semibold text-slate-300 bg-white/5 px-2 py-1 rounded-md border border-white/5">
                            {subj.remarks || 'Outstanding'}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
                <tfoot>
                  <tr className="border-t-2 border-white/15 bg-slate-950/40 text-xs font-bold text-white">
                    <td className="py-3.5 px-3 uppercase tracking-wider text-emerald-400">
                      Total Summary
                    </td>
                    <td className="py-3.5 px-3 text-center font-mono">
                      {(activeResult.subjectScores || []).reduce((acc, curr) => acc + (curr.credits || 0), 0)} Credits
                    </td>
                    <td className="py-3.5 px-3 text-center font-mono">{activeResult.summary?.totalFullMarks ?? 0}</td>
                    <td className="py-3.5 px-3 text-center font-mono">{activeResult.summary?.totalPassMarks ?? 0}</td>
                    <td className="py-3.5 px-3 text-center font-mono text-emerald-300 text-sm">
                      {activeResult.summary?.totalObtainedMarks ?? 0}
                    </td>
                    <td className="py-3.5 px-3 text-center text-emerald-300 text-sm">
                      {activeResult.summary?.overallPercentage ?? 0}%
                    </td>
                    <td className="py-3.5 px-3 text-center">
                      <span className={`px-2 py-0.5 rounded-md font-bold text-xs border ${getGradePill(activeResult.summary?.overallGrade || 'A')}`}>
                        {activeResult.summary?.overallGrade || '—'}
                      </span>
                    </td>
                    <td className="py-3.5 px-3 text-center font-mono text-emerald-300 text-sm">
                      {Number(activeResult.summary?.gpa ?? 0).toFixed(2)} GPA
                    </td>
                    <td className="py-3.5 px-3 text-right text-emerald-400 uppercase tracking-wide text-[11px]">
                      {activeResult.summary?.resultStatus || 'PASSED'}
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>

            {/* Remarks Section */}
            {(activeResult.remarks || activeResult.principalRemarks) && (
              <div className="mt-6 pt-5 border-t border-white/10 grid grid-cols-1 md:grid-cols-2 gap-4">
                {activeResult.remarks && (
                  <div className="bg-slate-950/40 border border-white/5 p-4 rounded-xl">
                    <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">
                      Class Teacher Evaluation Remarks
                    </span>
                    <p className="text-xs text-slate-300 italic">"{activeResult.remarks}"</p>
                  </div>
                )}
                {activeResult.principalRemarks && (
                  <div className="bg-slate-950/40 border border-white/5 p-4 rounded-xl">
                    <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">
                      Academic Directorate Endorsement
                    </span>
                    <p className="text-xs text-slate-300 italic">"{activeResult.principalRemarks}"</p>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Result History Timeline Cards */}
          <div className="bg-slate-900/50 border border-white/10 p-6 rounded-2xl backdrop-blur-xl">
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-300 mb-4 flex items-center gap-2">
              <Clock className="w-4 h-4 text-indigo-400" />
              <span>Historical Examination Progression ({results.length} Terms Evaluated)</span>
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {(results || []).map((res) => {
                const isCurrent = res.id === activeResult.id;
                return (
                  <div
                    key={res.id}
                    onClick={() => setSelectedResultId(res.id)}
                    className={`p-4 rounded-xl border transition-all cursor-pointer flex flex-col justify-between ${
                      isCurrent
                        ? 'bg-emerald-950/20 border-emerald-500/40 shadow-lg shadow-emerald-900/20'
                        : 'bg-slate-950/40 border-white/5 hover:border-white/20 hover:bg-white/[0.02]'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between mb-1.5">
                        <span className="text-[10px] font-mono text-slate-400">{res.academicYear}</span>
                        {getResultBadge(res.summary.resultStatus)}
                      </div>
                      <h4 className="text-sm font-bold text-white mb-1">{res.examName}</h4>
                      <p className="text-xs text-slate-400">{res.term}</p>
                    </div>

                    <div className="mt-4 pt-3 border-t border-white/5 flex items-center justify-between text-xs">
                      <div>
                        <span className="text-[10px] text-slate-400 block">Marks</span>
                        <span className="font-semibold text-white">
                          {res.summary?.totalObtainedMarks ?? 0} / {res.summary?.totalFullMarks ?? 0}
                        </span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 block">Percentage</span>
                        <span className="font-semibold text-emerald-300">{res.summary?.overallPercentage ?? 0}%</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 block">GPA</span>
                        <span className="font-bold text-white">{Number(res.summary?.gpa ?? 0).toFixed(2)}</span>
                      </div>
                      <div>
                        <span className={`px-2 py-0.5 rounded-md font-bold text-[11px] border ${getGradePill(res.summary?.overallGrade || 'A')}`}>
                          {res.summary?.overallGrade || '—'}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Modal 1: Official Printable Transcript / Grade Sheet */}
      <Modal
        isOpen={showTranscriptModal && !!activeResult}
        onClose={() => setShowTranscriptModal(false)}
        title={
          <div className="flex items-center gap-2.5">
            <Printer className="w-5 h-5 text-emerald-400" />
            <span className="text-base font-bold text-white">Official Academic Transcript</span>
          </div>
        }
        size="xl"
      >
        {activeResult && (
          <div className="space-y-6">
            {/* Transcript Sheet Canvas */}
            <div id="printable-student-transcript" className="bg-slate-950 border border-white/15 p-8 rounded-2xl text-slate-100 shadow-2xl space-y-6">
              {/* Header */}
              <div className="text-center border-b border-white/10 pb-5">
                <div className="w-12 h-12 bg-emerald-600 rounded-2xl flex items-center justify-center font-black text-white text-xl mx-auto mb-2 shadow-lg shadow-emerald-600/30">
                  S
                </div>
                <h1 className="text-lg font-black text-white uppercase tracking-wider">SYGMATE ACADEMY OF EXCELLENCE</h1>
                <p className="text-xs text-slate-400">Office of the Controller of Academic Records & Evaluation</p>
                <p className="text-[11px] font-mono text-emerald-400 uppercase mt-1">
                  OFFICIAL GRADE SHEET & PERFORMANCE TRANSCRIPT
                </p>
              </div>

              {/* Student Metadata */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-white/[0.02] border border-white/5 p-4 rounded-xl text-xs">
                <div>
                  <span className="text-[10px] text-slate-400 font-bold uppercase block">Student Name</span>
                  <span className="font-bold text-white mt-0.5 block">{activeResult.studentName}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 font-bold uppercase block">Admission ID</span>
                  <span className="font-mono text-indigo-300 mt-0.5 block">{activeResult.admissionNumber}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 font-bold uppercase block">Class & Section</span>
                  <span className="font-bold text-white mt-0.5 block">{activeResult.className} • {activeResult.sectionName}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 font-bold uppercase block">Academic Year</span>
                  <span className="font-mono text-white mt-0.5 block">{activeResult.academicYear}</span>
                </div>
              </div>

              {/* Subject Breakdown */}
              <div className="border border-white/10 rounded-xl overflow-hidden">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-900 border-b border-white/10 text-[10px] font-bold uppercase text-slate-400">
                      <th className="py-2.5 px-3">Subject Name</th>
                      <th className="py-2.5 px-3 text-center">Code</th>
                      <th className="py-2.5 px-3 text-center">Credits</th>
                      <th className="py-2.5 px-3 text-center">Max Marks</th>
                      <th className="py-2.5 px-3 text-center">Obtained</th>
                      <th className="py-2.5 px-3 text-center">Grade</th>
                      <th className="py-2.5 px-3 text-center">Grade Point</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {(activeResult.subjectScores || []).map((s) => (
                      <tr key={s.subjectId} className="hover:bg-white/[0.02]">
                        <td className="py-2.5 px-3 font-semibold text-white">{s.subjectName}</td>
                        <td className="py-2.5 px-3 text-center font-mono text-indigo-300">{s.subjectCode}</td>
                        <td className="py-2.5 px-3 text-center font-mono text-slate-400">{s.credits}</td>
                        <td className="py-2.5 px-3 text-center font-mono text-slate-300">{s.fullMarks}</td>
                        <td className="py-2.5 px-3 text-center font-mono font-bold text-emerald-300">{s.obtainedMarks}</td>
                        <td className="py-2.5 px-3 text-center font-bold">{s.grade}</td>
                        <td className="py-2.5 px-3 text-center font-mono">{Number(s.gradePoint ?? 0).toFixed(2)}</td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot>
                    <tr className="border-t border-white/15 bg-slate-900 font-bold text-xs text-white">
                      <td colSpan={3} className="py-2.5 px-3 uppercase text-emerald-400">
                        Aggregate Performance
                      </td>
                      <td className="py-2.5 px-3 text-center font-mono">{activeResult.summary?.totalFullMarks ?? 0}</td>
                      <td className="py-2.5 px-3 text-center font-mono text-emerald-300">{activeResult.summary?.totalObtainedMarks ?? 0}</td>
                      <td className="py-2.5 px-3 text-center">{activeResult.summary?.overallGrade || '—'}</td>
                      <td className="py-2.5 px-3 text-center font-mono text-emerald-300">{Number(activeResult.summary?.gpa ?? 0).toFixed(2)} GPA</td>
                    </tr>
                  </tfoot>
                </table>
              </div>

              {/* Signatures & Seal */}
              <div className="pt-6 border-t border-white/10 flex items-center justify-between text-[11px] text-slate-400">
                <div className="space-y-1">
                  <div className="font-semibold text-slate-200">Issue Date: {formatDate(activeResult.publishDate)}</div>
                  <div>System Verification Hash: #SYG-{activeResult.id.toUpperCase()}</div>
                </div>
                <div className="text-right space-y-1">
                  <div className="font-semibold text-slate-200">Controller of Examinations</div>
                  <div className="text-[10px] text-emerald-400 uppercase font-mono">Digitally Signed & Validated</div>
                </div>
              </div>
            </div>

            {/* Modal Actions */}
            <div className="flex items-center justify-end gap-3">
              <button
                onClick={() => setShowTranscriptModal(false)}
                className="px-4 py-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-xs font-semibold text-slate-300 hover:text-white transition-all cursor-pointer"
              >
                Close
              </button>
              <button
                onClick={() =>
                  triggerSafePrint({
                    elementOrId: 'printable-student-transcript',
                    fallbackTitle: `Transcript_${(activeResult.examName || 'Academic').replace(/\s+/g, '_')}`
                  })
                }
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-lg shadow-emerald-600/30 transition-all cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Print Transcript</span>
              </button>
            </div>
          </div>
        )}
      </Modal>

      {/* Modal 2: Institutional Grading Scale Reference */}
      <Modal
        isOpen={showGradingScaleModal}
        onClose={() => setShowGradingScaleModal(false)}
        title={
          <div className="flex items-center gap-2.5">
            <Info className="w-5 h-5 text-indigo-400" />
            <span className="text-base font-bold text-white">Institutional Grading System (4.00 Scale)</span>
          </div>
        }
        size="lg"
      >
        <div className="space-y-4">
          <p className="text-xs text-slate-300">
            Standard 4.00 Grade Point Average benchmark used across Sygmate Academy for all evaluations.
          </p>

          <div className="border border-white/10 rounded-xl overflow-hidden">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-950/80 border-b border-white/10 text-[10px] font-bold uppercase text-slate-400">
                  <th className="py-2.5 px-3">Grade</th>
                  <th className="py-2.5 px-3">Percentage Range</th>
                  <th className="py-2.5 px-3 text-center">Grade Point</th>
                  <th className="py-2.5 px-3">Performance Tier</th>
                  <th className="py-2.5 px-3 text-right">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {(gradingScale || []).map((item) => (
                  <tr key={item.id} className="hover:bg-white/[0.02]">
                    <td className="py-2.5 px-3 font-bold text-white">{item.grade}</td>
                    <td className="py-2.5 px-3 font-mono text-slate-300">
                      {item.minPercentage}% – {item.maxPercentage}%
                    </td>
                    <td className="py-2.5 px-3 text-center font-mono font-bold text-indigo-300">
                      {Number(item?.gradePoint ?? 0).toFixed(2)}
                    </td>
                    <td className="py-2.5 px-3 text-slate-300">{item.description}</td>
                    <td className="py-2.5 px-3 text-right">
                      {item.isPassing ? (
                        <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
                          PASS
                        </span>
                      ) : (
                        <span className="text-[10px] font-bold text-rose-400 bg-rose-500/10 px-2 py-0.5 rounded-full border border-rose-500/20">
                          FAIL
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="flex justify-end pt-3 border-t border-white/10">
            <button
              onClick={() => setShowGradingScaleModal(false)}
              className="px-4 py-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-xs font-semibold text-slate-300 hover:text-white transition-all cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
