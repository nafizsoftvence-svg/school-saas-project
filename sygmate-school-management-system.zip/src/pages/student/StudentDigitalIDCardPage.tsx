import React, { useState, useEffect } from 'react';
import {
  CreditCard,
  FileText,
  Printer,
  Download,
  ShieldCheck,
  QrCode,
  Sparkles,
  Upload,
  Clock,
  CheckCircle2,
  AlertTriangle,
  RefreshCw
} from 'lucide-react';
import { StudentIDCard, StudentDocument, StudentIDCardTemplateLayout } from '../../types';
import { StudentIDCardVisual } from '../../components/idcards/StudentIDCardVisual';
import { StudentDocumentUploadModal } from '../../components/documents/StudentDocumentUploadModal';
import { useAuth } from '../../context/AuthContext';
import { downloadElementPdf, triggerSafePrint } from '../../utils/printPdf.js';

export const StudentDigitalIDCardPage: React.FC = () => {
  const { user } = useAuth();
  const [card, setCard] = useState<StudentIDCard | null>(null);
  const [documents, setDocuments] = useState<StudentDocument[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTemplate, setActiveTemplate] = useState<StudentIDCardTemplateLayout>('modern-vertical');
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);

  const fetchStudentCredentialData = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('sygmate_auth_token') || localStorage.getItem('token');
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {})
      };

      // Fetch all cards and find this student's card
      const targetStudentId = user?.studentProfileId || (user as any)?.studentProfile?.id || user?.id || 'stud-prof-1';
      const [cardsRes, docsRes] = await Promise.all([
        fetch(`/api/documents-idcards/students/${targetStudentId}/id-card`, { headers }),
        fetch(`/api/documents-idcards/students/${targetStudentId}/documents`, { headers })
      ]);

      if (cardsRes.ok && (cardsRes.headers.get('content-type') || '').includes('application/json')) {
        const cData = await cardsRes.json();
        if (cData.success && cData.data) {
          setCard(cData.data);
          setActiveTemplate(cData.data.templateId || 'modern-vertical');
        }
      }

      if (docsRes.ok && (docsRes.headers.get('content-type') || '').includes('application/json')) {
        const dData = await docsRes.json();
        if (dData.success && dData.data) {
          setDocuments(dData.data);
        }
      }
    } catch (err) {
      console.error('Error loading student credential data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStudentCredentialData();
  }, [user]);

  const displayedCard = card || {
    id: 'idc-demo',
    studentId: user?.id || 'student-1',
    studentName: user?.name || 'Liam Rivera',
    admissionNumber: 'ADM-2026-0842',
    cardNumber: 'IDC-2026-00842',
    templateId: activeTemplate,
    status: 'ISSUED',
    academicSessionName: '2026-2027 Academic Year',
    className: 'Grade 10',
    sectionName: 'Section A (Advanced)',
    rollNumber: 'G10-A-01',
    bloodGroup: 'O+',
    emergencyContact: '+1 (555) 019-8811',
    avatarUrl: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&q=80&w=256',
    issueDate: '2026-08-20',
    expiryDate: '2027-06-30'
  } as StudentIDCard;

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono font-bold text-indigo-600 bg-indigo-50 px-2.5 py-0.5 rounded-full border border-indigo-100 uppercase tracking-wide">
              Official Institutional Pass
            </span>
            <span className="text-xs text-slate-400">• Academic Year 2026-2027</span>
          </div>
          <h1 className="text-2xl font-black text-slate-900 mt-1">Digital Student ID & Credentials</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Your official digital student credential for campus access, examination entry, and library checkout.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={async () => {
              await downloadElementPdf('student-idcard-visual-card', `student_badge_${displayedCard.studentName.replace(/\s+/g, '_')}.pdf`, {
                orientation: activeTemplate === 'classic-horizontal' ? 'landscape' : 'portrait'
              });
              await triggerSafePrint({
                elementOrId: 'student-idcard-visual-card',
                fallbackTitle: `Student_Badge_${displayedCard.cardNumber}`
              });
            }}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-xs transition"
          >
            <Printer className="w-4 h-4" />
            Print Badge
          </button>
          <button
            type="button"
            onClick={() => setIsUploadModalOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition"
          >
            <Upload className="w-4 h-4 text-slate-500" />
            Submit Document
          </button>
        </div>
      </div>

      {/* Main Grid: Left ID Card (2 cols), Right Document Vault (1 col) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: 3D Flip Card & Template Selector */}
        <div className="lg:col-span-2 bg-white rounded-2xl p-6 border border-slate-200 shadow-xs flex flex-col items-center">
          <div className="w-full flex items-center justify-between pb-4 border-b border-slate-100 mb-6">
            <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
              <CreditCard className="w-4 h-4 text-indigo-600" />
              Interactive Institutional Credential
            </h3>

            {/* Template format switch */}
            <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl text-xs font-semibold">
              {(['modern-vertical', 'classic-horizontal', 'minimalist-academic', 'smart-card'] as StudentIDCardTemplateLayout[]).map(t => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setActiveTemplate(t)}
                  className={`px-2.5 py-1 rounded-lg transition capitalize text-[11px] ${
                    activeTemplate === t
                      ? 'bg-white text-indigo-600 shadow-xs'
                      : 'text-slate-500 hover:text-slate-800'
                  }`}
                >
                  {t.split('-')[0]}
                </button>
              ))}
            </div>
          </div>

          {/* Render Card Visual */}
          <div id="student-idcard-visual-card" className="py-4">
            <StudentIDCardVisual
              card={{
                ...displayedCard,
                templateId: activeTemplate
              }}
              scale={1}
              interactive={true}
              showFlipControls={true}
              onPrint={async () => {
                await downloadElementPdf('student-idcard-visual-card', `student_badge_${displayedCard.studentName.replace(/\s+/g, '_')}.pdf`, {
                  orientation: activeTemplate === 'classic-horizontal' ? 'landscape' : 'portrait'
                });
                await triggerSafePrint({
                  elementOrId: 'student-idcard-visual-card',
                  fallbackTitle: `Student_Badge_${displayedCard.cardNumber}`
                });
              }}
            />
          </div>

          <div className="w-full mt-6 pt-4 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span className="flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              Cryptographically verified by Sygmate Security Core
            </span>
            <span className="font-mono">Card Ref: {displayedCard.cardNumber}</span>
          </div>
        </div>

        {/* Right: Verified Document Vault */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                <FileText className="w-4 h-4 text-indigo-600" />
                Student Document Vault
              </h3>
              <span className="text-xs font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full">
                {documents.length} Files
              </span>
            </div>

            <p className="text-xs text-slate-500 mb-4">
              Your official records approved by school administrators for academic enrollment.
            </p>

            <div className="space-y-3">
              {documents.length === 0 ? (
                <div className="p-6 text-center border border-dashed border-slate-200 rounded-xl text-xs text-slate-400">
                  <FileText className="w-8 h-8 text-slate-300 mx-auto mb-1" />
                  No documents in vault yet.
                </div>
              ) : (
                documents.map(doc => {
                  const isVerified = (doc.verificationStatus || 'PENDING_VERIFICATION') === 'VERIFIED';
                  return (
                    <div
                      key={doc.id}
                      className="p-3 bg-slate-50 hover:bg-slate-100/80 rounded-xl border border-slate-200/80 transition flex items-center justify-between text-xs"
                    >
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-indigo-600 shrink-0">
                          <FileText className="w-4 h-4" />
                        </div>
                        <div>
                          <strong className="text-slate-800 block font-bold leading-tight">
                            {doc.title || doc.name}
                          </strong>
                          <span className="text-[10px] text-slate-400">
                            {doc.category} • {doc.fileSize || '320 KB'}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <span className={`text-[9.5px] font-bold px-2 py-0.5 rounded-full uppercase ${
                          isVerified
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}>
                          {isVerified ? 'Verified' : 'Pending'}
                        </span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          <div className="pt-4 mt-6 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setIsUploadModalOpen(true)}
              className="w-full py-2.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-xs rounded-xl transition flex items-center justify-center gap-2"
            >
              <Upload className="w-4 h-4" />
              Upload Additional Certificate
            </button>
          </div>
        </div>
      </div>

      {/* Document Upload Modal */}
      {isUploadModalOpen && (
        <StudentDocumentUploadModal
          studentId={displayedCard.studentId || 'student-1'}
          studentName={displayedCard.studentName}
          admissionNumber={displayedCard.admissionNumber}
          isOpen={isUploadModalOpen}
          onClose={() => setIsUploadModalOpen(false)}
          onSuccess={(newDoc) => {
            setDocuments(prev => [newDoc, ...prev]);
            setIsUploadModalOpen(false);
          }}
        />
      )}
    </div>
  );
};
