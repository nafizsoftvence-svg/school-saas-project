import React, { useEffect, useState } from 'react';
import {
  GraduationCap,
  BookOpen,
  Calendar,
  Clock,
  User,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  FileText,
  ClipboardList,
  Bell,
  Check,
  Download,
  Paperclip,
  ExternalLink,
  ChevronRight,
  ShieldCheck,
  CalendarDays,
  Award,
  TrendingUp
} from 'lucide-react';
import { Button } from '../../components/ui/Button.js';
import { Badge } from '../../components/ui/Badge.js';
import { api } from '../../services/api.js';
import { StudentDashboardData, NotificationItem } from '../../types/index.js';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner.js';

interface StudentDashboardProps {
  onNavigate: (viewId: string) => void;
}

export const StudentDashboard: React.FC<StudentDashboardProps> = ({ onNavigate }) => {
  const [data, setData] = useState<StudentDashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [markingNotifId, setMarkingNotifId] = useState<string | null>(null);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await api.getStudentDashboard();
      if (res.success && res.data) {
        setData(res.data);
      } else {
        setError(res.error || 'Failed to load student dashboard.');
      }
    } catch (err: any) {
      console.error('Failed to load student dashboard', err);
      setError(err?.message || 'Network error loading academic dashboard.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const handleMarkNotificationRead = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      setMarkingNotifId(id);
      await api.markNotificationAsRead(id);
      setData((prev) => {
        if (!prev) return prev;
        const updated = (prev.recentNotifications || []).map((n) =>
          n.id === id ? { ...n, isRead: true } : n
        );
        const unreadCount = updated.filter((n) => !n.isRead).length;
        return {
          ...prev,
          recentNotifications: updated,
          metrics: {
            ...prev.metrics,
            unreadNotificationsCount: unreadCount
          }
        };
      });
    } catch (err) {
      console.error('Failed to mark notification read', err);
    } finally {
      setMarkingNotifId(null);
    }
  };

  if (loading) {
    return (
      <div className="py-24 flex flex-col items-center justify-center">
        <LoadingSpinner size="lg" message="Loading your verified academic workspace..." />
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="max-w-2xl mx-auto my-12 bg-rose-500/10 border border-rose-500/30 rounded-3xl p-8 text-center space-y-4">
        <AlertCircle className="w-12 h-12 text-rose-400 mx-auto" />
        <h3 className="text-xl font-bold text-white">Unable to Load Student Dashboard</h3>
        <p className="text-sm text-rose-200">{error || 'Data could not be retrieved from the server.'}</p>
        <Button size="sm" variant="primary" onClick={fetchDashboardData}>
          Try Again
        </Button>
      </div>
    );
  }

  const student = data.student;
  const metrics = data.metrics || ({} as any);
  const enrolledSubjects = data.enrolledSubjects || [];
  const upcomingHomework = data.upcomingHomework || [];
  const upcomingAssignments = data.upcomingAssignments || [];
  const recentAnnouncements = data.recentAnnouncements || [];
  const recentNotifications = data.recentNotifications || [];
  const initials = `${student.firstName?.[0] || 'S'}${student.lastName?.[0] || ''}`;

  return (
    <div className="space-y-8">
      {/* Top Welcome Banner */}
      <div className="bg-gradient-to-r from-emerald-950/40 via-slate-900/60 to-indigo-950/40 backdrop-blur-xl border border-white/10 rounded-3xl p-6 sm:p-8 shadow-xl shadow-black/30 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div className="flex items-center gap-5">
          {student.avatarUrl ? (
            <img
              src={student.avatarUrl}
              alt={`${student.firstName} ${student.lastName}`}
              className="w-20 h-20 rounded-3xl object-cover border-2 border-emerald-400/40 shadow-xl shadow-emerald-900/30"
            />
          ) : (
            <div className="w-20 h-20 rounded-3xl bg-gradient-to-br from-emerald-600 to-teal-700 border border-emerald-400/40 text-white flex items-center justify-center font-black text-2xl shadow-xl shadow-emerald-900/30">
              {initials}
            </div>
          )}

          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="flex items-center gap-1.5 text-emerald-400 text-xs font-bold uppercase tracking-wider">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Student Portal</span>
              </span>
              <Badge variant="success">ACTIVE ENROLLMENT</Badge>
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
              Welcome back, {student.firstName} {student.lastName}
            </h2>
            <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-400 font-mono">
              <span>ID: <strong className="text-slate-200">{student.admissionNumber || 'ADM-2026-0842'}</strong></span>
              <span>•</span>
              <span>Class: <strong className="text-emerald-300">{student.className}</strong></span>
              <span>•</span>
              <span>Section: <strong className="text-indigo-300">{student.sectionName}</strong></span>
              <span>•</span>
              <span>Roll: <strong className="text-slate-200">#{student.rollNumber || '01'}</strong></span>
            </div>
          </div>
        </div>

        {/* Quick Top Actions */}
        <div className="flex flex-wrap items-center gap-3">
          <Button
            size="sm"
            variant="glass"
            leftIcon={<GraduationCap className="w-4 h-4 text-indigo-400" />}
            onClick={() => onNavigate('student-class')}
          >
            My Class
          </Button>
          <Button
            size="sm"
            variant="glass"
            leftIcon={<BookOpen className="w-4 h-4 text-cyan-400" />}
            onClick={() => onNavigate('student-subjects')}
          >
            My Subjects
          </Button>
          <Button
            size="sm"
            variant="glass"
            leftIcon={<Clock className="w-4 h-4 text-emerald-400" />}
            onClick={() => onNavigate('student-routine')}
          >
            Timetable
          </Button>
          <Button
            size="sm"
            variant="primary"
            leftIcon={<User className="w-4 h-4" />}
            onClick={() => onNavigate('student-profile')}
          >
            Bio &amp; Profile
          </Button>
        </div>
      </div>

      {/* Metric Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {/* Class Placement */}
        <div
          onClick={() => onNavigate('student-class')}
          className="bg-white/5 hover:bg-white/10 cursor-pointer backdrop-blur-xl border border-white/10 hover:border-indigo-500/40 p-6 rounded-3xl shadow-xl shadow-black/20 space-y-2 transition-all group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Class &amp; Section</span>
            <div className="p-2 rounded-xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 group-hover:bg-indigo-500/20 transition-all">
              <GraduationCap className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-white">
            {student.className}
          </div>
          <div className="text-xs text-indigo-300 font-semibold flex items-center justify-between">
            <span>{student.sectionName} • Roll #{student.rollNumber || 'N/A'}</span>
            <span className="text-[10px] text-indigo-400 opacity-0 group-hover:opacity-100 transition-opacity">View Class &rarr;</span>
          </div>
        </div>

        {/* Total Subjects */}
        <div
          onClick={() => onNavigate('student-subjects')}
          className="bg-white/5 hover:bg-white/10 cursor-pointer backdrop-blur-xl border border-white/10 hover:border-cyan-500/40 p-6 rounded-3xl shadow-xl shadow-black/20 space-y-2 transition-all group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Total Subjects</span>
            <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 group-hover:bg-cyan-500/20 transition-all">
              <BookOpen className="w-4 h-4" />
            </div>
          </div>
          <div className="text-3xl font-black text-white">
            {metrics?.totalSubjects || enrolledSubjects?.length || 0}
          </div>
          <div className="text-xs text-cyan-300 font-semibold flex items-center justify-between">
            <span>Active Core &amp; Electives</span>
            <span className="text-[10px] text-cyan-400 opacity-0 group-hover:opacity-100 transition-opacity">Explore &rarr;</span>
          </div>
        </div>

        {/* Attendance Rate */}
        <div
          onClick={() => onNavigate('student-attendance')}
          className="bg-white/5 hover:bg-white/10 cursor-pointer backdrop-blur-xl border border-white/10 hover:border-emerald-500/40 p-6 rounded-3xl shadow-xl shadow-black/20 space-y-2 transition-all group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Attendance Rate</span>
            <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 group-hover:bg-emerald-500/20 transition-all">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div className="text-3xl font-black text-white">
            {metrics.attendancePercentage ?? '100%'}
          </div>
          <div className="text-xs text-emerald-300 font-semibold flex items-center justify-between">
            {metrics.hasAttendanceData ? (
              <span>{metrics.attendancePresentDays} of {metrics.attendanceTotalDays} recorded sessions present</span>
            ) : (
              <span className="text-slate-400">Attendance records pending</span>
            )}
            <span className="text-[10px] text-emerald-400 opacity-0 group-hover:opacity-100 transition-opacity">Calendar & Leaves &rarr;</span>
          </div>
        </div>

        {/* Academic Session */}
        <div
          onClick={() => onNavigate('student-academic-info')}
          className="bg-white/5 hover:bg-white/10 cursor-pointer backdrop-blur-xl border border-white/10 hover:border-amber-500/40 p-6 rounded-3xl shadow-xl shadow-black/20 space-y-2 transition-all group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Academic Session</span>
            <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20 group-hover:bg-amber-500/20 transition-all">
              <Calendar className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl font-bold text-white truncate">
            {metrics.academicSession}
          </div>
          <div className="text-xs text-amber-300 font-semibold flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
              <span>Active Term</span>
            </div>
            <span className="text-[10px] text-amber-400 opacity-0 group-hover:opacity-100 transition-opacity">Details &rarr;</span>
          </div>
        </div>
      </div>

      {/* Main Content Layout: Left = Homework & Assignments, Right = Announcements & Notifications */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column (2 Cols): Homework, Assignments, and Subjects */}
        <div className="lg:col-span-2 space-y-8">
          {/* Upcoming Homework */}
          <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-6 sm:p-7 shadow-xl shadow-black/20 space-y-5">
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white tracking-tight">Upcoming Homework</h3>
                  <p className="text-xs text-slate-400">Assigned course tasks and practice problem sets</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="neutral">{upcomingHomework?.length || 0} ASSIGNED</Badge>
                <Button size="xs" variant="outline" onClick={() => onNavigate('student-homework')}>
                  View All
                </Button>
              </div>
            </div>

            {((upcomingHomework?.length || 0) > 0) ? (
              <div className="space-y-3">
                {(upcomingHomework || []).map((hw) => (
                  <div
                    key={hw.id}
                    className="p-4 rounded-2xl bg-white/5 border border-white/10 hover:border-emerald-500/30 transition-all space-y-2.5"
                  >
                    <div className="flex flex-wrap items-start justify-between gap-2">
                      <div>
                        <span className="inline-block text-[11px] font-mono font-bold text-emerald-300 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20 mb-1">
                          {hw.subjectName}
                        </span>
                        <h4 className="text-sm font-bold text-white">{hw.title}</h4>
                      </div>
                      <div className="text-right">
                        <span className="text-xs font-semibold text-amber-300 bg-amber-500/10 px-2.5 py-1 rounded-full border border-amber-500/20 flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          <span>Due {hw.dueDate}</span>
                        </span>
                      </div>
                    </div>

                    <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed">
                      {hw.description}
                    </p>

                    <div className="flex items-center justify-between text-xs pt-1 border-t border-white/5 text-slate-400">
                      <span>Instructor: <strong className="text-slate-200">{hw.teacherName}</strong></span>
                      {hw.attachmentName && (
                        <span className="flex items-center gap-1 text-cyan-300 font-mono text-[11px]">
                          <Paperclip className="w-3 h-3" />
                          <span>{hw.attachmentName}</span>
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-8 text-center bg-white/5 rounded-2xl border border-dashed border-white/10 space-y-2">
                <CheckCircle2 className="w-8 h-8 text-emerald-400/60 mx-auto" />
                <p className="text-sm font-medium text-white">No Pending Homework</p>
                <p className="text-xs text-slate-400">All current homework coursework has been completed.</p>
              </div>
            )}
          </div>

          {/* Upcoming Assignments */}
          <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-6 sm:p-7 shadow-xl shadow-black/20 space-y-5">
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                  <ClipboardList className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white tracking-tight">Active Assignments &amp; Projects</h3>
                  <p className="text-xs text-slate-400">Formal coursework evaluations and term deliverables</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="primary">{upcomingAssignments?.length || 0} ACTIVE</Badge>
                <Button size="xs" variant="outline" onClick={() => onNavigate('student-assignments')}>
                  View All
                </Button>
              </div>
            </div>

            {((upcomingAssignments?.length || 0) > 0) ? (
              <div className="space-y-3">
                {(upcomingAssignments || []).map((assign) => (
                  <div
                    key={assign.id}
                    className="p-4 rounded-2xl bg-white/5 border border-white/10 hover:border-indigo-500/30 transition-all space-y-2.5"
                  >
                    <div className="flex flex-wrap items-start justify-between gap-2">
                      <div>
                        <span className="inline-block text-[11px] font-mono font-bold text-indigo-300 bg-indigo-500/10 px-2 py-0.5 rounded border border-indigo-500/20 mb-1">
                          {assign.subjectName}
                        </span>
                        <h4 className="text-sm font-bold text-white">{assign.title}</h4>
                      </div>
                      <div className="text-right flex items-center gap-2">
                        <span className="text-xs font-mono font-bold text-emerald-300 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                          {assign.totalMarks} Marks
                        </span>
                        <span className="text-xs font-semibold text-rose-300 bg-rose-500/10 px-2.5 py-1 rounded-full border border-rose-500/20">
                          Due {assign.dueDate}
                        </span>
                      </div>
                    </div>

                    <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed">
                      {assign.description}
                    </p>

                    <div className="flex items-center justify-between text-xs pt-1 border-t border-white/5 text-slate-400">
                      <span>Evaluator: <strong className="text-slate-200">{assign.teacherName}</strong></span>
                      {assign.attachmentName && (
                        <span className="flex items-center gap-1 text-indigo-300 font-mono text-[11px]">
                          <Paperclip className="w-3 h-3" />
                          <span>{assign.attachmentName}</span>
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-8 text-center bg-white/5 rounded-2xl border border-dashed border-white/10 space-y-2">
                <CheckCircle2 className="w-8 h-8 text-indigo-400/60 mx-auto" />
                <p className="text-sm font-medium text-white">No Active Term Assignments</p>
                <p className="text-xs text-slate-400">New assignment briefs will appear here when published by faculty.</p>
              </div>
            )}
          </div>

          {/* Enrolled Subjects List */}
          <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-6 sm:p-7 shadow-xl shadow-black/20 space-y-5">
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div>
                <h3 className="text-lg font-bold text-white tracking-tight">Curriculum Course Modules</h3>
                <p className="text-xs text-slate-400">Faculty instructors assigned to your current grade level</p>
              </div>
              <Button size="xs" variant="outline" onClick={() => onNavigate('student-subjects')}>
                View Curriculum
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              {(enrolledSubjects || []).map((sub) => (
                <div
                  key={sub.id}
                  className="p-4 rounded-2xl bg-white/5 border border-white/10 hover:border-emerald-500/30 transition-all flex items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center justify-center shrink-0">
                      <BookOpen className="w-5 h-5" />
                    </div>
                    <div className="min-w-0">
                      <h5 className="font-semibold text-white text-sm truncate">{sub.name}</h5>
                      <p className="text-xs text-slate-400 truncate">{sub.teacherName}</p>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <span className="text-xs font-mono font-bold text-emerald-300 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                      {sub.credits} Credits
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column (1 Col): Class Announcements & System Notifications */}
        <div className="space-y-8">
          {/* Class Announcements */}
          <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-6 shadow-xl shadow-black/20 space-y-4">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2">
                <Bell className="w-4 h-4 text-amber-400" />
                <h3 className="text-base font-bold text-white">Class Notice Board</h3>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="warning">{recentAnnouncements?.length || 0} BULLETINS</Badge>
                <Button size="xs" variant="outline" onClick={() => onNavigate('student-announcements')}>
                  View All
                </Button>
              </div>
            </div>

            {((recentAnnouncements?.length || 0) > 0) ? (
              <div className="space-y-3">
                {(recentAnnouncements || []).map((ann) => (
                  <div
                    key={ann.id}
                    className="p-4 rounded-2xl bg-white/5 border border-white/10 hover:border-amber-500/30 transition-all space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <Badge
                        variant={ann.priority === 'urgent' ? 'error' : ann.priority === 'high' ? 'warning' : 'neutral'}
                      >
                        {ann.priority?.toUpperCase() || 'NORMAL'}
                      </Badge>
                      <span className="text-[10px] text-slate-400 font-mono">
                        {ann.publishDate || ann.createdAt.split('T')[0]}
                      </span>
                    </div>

                    <h4 className="text-xs font-bold text-white leading-snug">{ann.title}</h4>
                    <p className="text-xs text-slate-300 leading-relaxed">{ann.message}</p>

                    <div className="text-[11px] text-slate-400 pt-1 border-t border-white/5">
                      Posted by <span className="text-slate-200 font-semibold">{ann.teacherName}</span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-6 text-center bg-white/5 rounded-2xl border border-dashed border-white/10">
                <p className="text-xs text-slate-400">No active class announcements at this time.</p>
              </div>
            )}
          </div>

          {/* System Notifications */}
          <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-6 shadow-xl shadow-black/20 space-y-4">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-indigo-400" />
                <h3 className="text-base font-bold text-white">Recent Notifications</h3>
              </div>
              {metrics.unreadNotificationsCount ? (
                <span className="text-[10px] font-bold text-indigo-300 bg-indigo-500/20 px-2 py-0.5 rounded-full border border-indigo-500/30">
                  {metrics.unreadNotificationsCount} UNREAD
                </span>
              ) : null}
            </div>

            {((recentNotifications?.length || 0) > 0) ? (
              <div className="space-y-2.5">
                {(recentNotifications || []).map((notif) => (
                  <div
                    key={notif.id}
                    className={`p-3.5 rounded-2xl border transition-all ${
                      notif.isRead
                        ? 'bg-white/5 border-white/10 text-slate-400'
                        : 'bg-indigo-950/30 border-indigo-500/30 text-white'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="space-y-1">
                        <div className="flex items-center gap-1.5">
                          {!notif.isRead && (
                            <span className="w-2 h-2 rounded-full bg-indigo-400 animate-pulse" />
                          )}
                          <h5 className="text-xs font-bold text-white leading-tight">{notif.title}</h5>
                        </div>
                        <p className="text-[11px] text-slate-300 leading-relaxed">{notif.message}</p>
                      </div>

                      {!notif.isRead && (
                        <button
                          onClick={(e) => handleMarkNotificationRead(notif.id, e)}
                          disabled={markingNotifId === notif.id}
                          className="p-1 rounded-lg hover:bg-white/10 text-slate-400 hover:text-emerald-400 transition-colors shrink-0 cursor-pointer"
                          title="Mark as read"
                        >
                          <Check className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-6 text-center bg-white/5 rounded-2xl border border-dashed border-white/10">
                <p className="text-xs text-slate-400">All notifications read.</p>
              </div>
            )}
          </div>

          {/* Examinations & Academic Progression Quick Hub */}
          <div className="bg-gradient-to-br from-indigo-900/30 via-slate-900/50 to-emerald-900/30 backdrop-blur-xl border border-indigo-500/20 rounded-3xl p-6 shadow-xl shadow-black/20 space-y-4">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2 text-indigo-400 font-bold text-sm">
                <Award className="w-5 h-5" />
                <span>Exams & Evaluations</span>
              </div>
              <Badge variant="primary" size="sm">
                Part 4E
              </Badge>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Check scheduled room venues, download your examination admit slip, and review authenticated transcripts.
            </p>
            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                onClick={() => onNavigate('student-examinations')}
                className="px-3 py-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-xs font-semibold text-white flex items-center justify-center gap-1.5 transition-all cursor-pointer"
              >
                <CalendarDays className="w-3.5 h-3.5 text-indigo-400" />
                <span>Timetable</span>
              </button>
              <button
                onClick={() => onNavigate('student-results')}
                className="px-3 py-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-xs font-semibold text-white flex items-center justify-center gap-1.5 transition-all cursor-pointer"
              >
                <Award className="w-3.5 h-3.5 text-emerald-400" />
                <span>Results</span>
              </button>
            </div>
            <button
              onClick={() => onNavigate('student-progress')}
              className="w-full py-2 bg-indigo-600/20 hover:bg-indigo-600/30 border border-indigo-500/30 text-indigo-300 hover:text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <TrendingUp className="w-3.5 h-3.5" />
              <span>View Academic Progress Analytics</span>
            </button>
          </div>

          {/* Quick Academic Directory Card */}
          <div className="bg-gradient-to-br from-emerald-900/30 via-slate-900/50 to-indigo-900/30 backdrop-blur-xl border border-emerald-500/20 rounded-3xl p-6 shadow-xl shadow-black/20 space-y-4">
            <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
              <ShieldCheck className="w-5 h-5" />
              <span>Institutional Identity</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Your official student credentials are encrypted and verified under Sygmate Institutional Records. For changes to formal records (ID, Grade placement), contact the Registrar's Office.
            </p>
            <Button
              size="sm"
              variant="outline"
              className="w-full justify-center"
              onClick={() => onNavigate('student-profile')}
            >
              Manage My Contact Bio
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};
