/**
 * Part 15C — Student Portal: My Issued Certificates
 * Sygmate School Management System
 */

import React, { useEffect, useState, useMemo } from 'react';
import {
  Award,
  Search,
  Printer,
  Download,
  Calendar,
  ShieldCheck,
  Sparkles,
  Eye,
  RefreshCw,
  AlertCircle,
  FileCheck
} from 'lucide-react';
import { IssuedCertificate } from '../../types';
import { api } from '../../services/api';
import { CertificateViewerModal } from '../../components/documents/CertificateViewerModal';
import { Button } from '../../components/ui/Button';

export const StudentCertificatesPage: React.FC<{ onNavigate?: (view: string) => void }> = () => {
  const [certificates, setCertificates] = useState<IssuedCertificate[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Filters
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('ALL');

  // Viewer Modal
  const [viewingCert, setViewingCert] = useState<IssuedCertificate | null>(null);

  const fetchCertificates = async (isManual = false) => {
    try {
      if (isManual) setRefreshing(true);
      else setLoading(true);
      setError(null);

      const certs = await api.certificates.getMyCertificates();
      const list = Array.isArray(certs)
        ? certs
        : Array.isArray((certs as any)?.data)
        ? (certs as any).data
        : Array.isArray((certs as any)?.items)
        ? (certs as any).items
        : [];
      setCertificates(list);
    } catch (err: any) {
      setError(err.message || 'Failed to retrieve your student certificates.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchCertificates();
  }, []);

  const certificateTypes = useMemo(() => {
    const list = Array.isArray(certificates) ? certificates : [];
    const types = new Set(list.map(c => c.certificateTypeName));
    return Array.from(types);
  }, [certificates]);

  const filtered = useMemo(() => {
    const list = Array.isArray(certificates) ? certificates : [];
    return list.filter(c => {
      const matchesSearch =
        !search.trim() ||
        c.certificateNumber.toLowerCase().includes(search.toLowerCase()) ||
        c.certificateTypeName.toLowerCase().includes(search.toLowerCase()) ||
        (c.remarks && c.remarks.toLowerCase().includes(search.toLowerCase()));

      const matchesType = typeFilter === 'ALL' || c.certificateTypeName === typeFilter;
      return matchesSearch && matchesType;
    });
  }, [certificates, search, typeFilter]);

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 relative overflow-hidden shadow-2xl">
        <div className="absolute right-0 top-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="p-3.5 bg-indigo-500/20 border border-indigo-500/30 rounded-2xl text-indigo-400">
              <Award className="w-8 h-8" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                  My Official Academic Certificates
                </h1>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  Institutional Vault
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-xl">
                View, download, and verify your authenticated credentials, merit certificates, and bonafide citations issued by Sygmate International Academy.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => fetchCertificates(true)}
              disabled={refreshing}
              className="flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold border border-slate-700 transition-colors"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin' : ''}`} />
              Refresh
            </button>
          </div>
        </div>

        {/* Quick Stats Pill Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-6 border-t border-slate-800/80">
          <div className="bg-slate-900/60 border border-slate-800 p-3 rounded-2xl">
            <span className="text-[10px] uppercase font-bold text-slate-400">Total Issued</span>
            <p className="text-lg font-black text-white">{certificates.length}</p>
          </div>
          <div className="bg-slate-900/60 border border-slate-800 p-3 rounded-2xl">
            <span className="text-[10px] uppercase font-bold text-slate-400">Academic & Merit</span>
            <p className="text-lg font-black text-indigo-400">
              {certificates.filter(c => (c.certificateTypeCode || '').includes('MERIT')).length}
            </p>
          </div>
          <div className="bg-slate-900/60 border border-slate-800 p-3 rounded-2xl">
            <span className="text-[10px] uppercase font-bold text-slate-400">Bonafide & Study</span>
            <p className="text-lg font-black text-emerald-400">
              {certificates.filter(c => (c.certificateTypeCode || '').includes('BONAFIDE') || (c.certificateTypeCode || '').includes('STUDY')).length}
            </p>
          </div>
          <div className="bg-slate-900/60 border border-slate-800 p-3 rounded-2xl">
            <span className="text-[10px] uppercase font-bold text-slate-400">QR Verified</span>
            <p className="text-lg font-black text-purple-400">{certificates.length}</p>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900 border border-slate-800 p-4 rounded-2xl">
        <div className="relative flex-1 min-w-[240px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            type="text"
            placeholder="Search by serial number or certificate name..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
          />
        </div>

        <div className="flex items-center gap-2">
          <select
            value={typeFilter}
            onChange={e => setTypeFilter(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
          >
            <option value="ALL">All Certificate Types</option>
            {certificateTypes.map(t => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Error Message */}
      {error && (
        <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
          <span>{error}</span>
        </div>
      )}

      {/* Certificates Cards Grid */}
      {loading ? (
        <div className="py-20 text-center text-xs text-slate-400">
          Loading authenticated student certificates...
        </div>
      ) : filtered.length === 0 ? (
        <div className="py-16 text-center bg-slate-900/60 border border-slate-800 rounded-3xl p-8 space-y-3">
          <div className="w-12 h-12 rounded-full bg-slate-800 text-slate-400 mx-auto flex items-center justify-center">
            <Award className="w-6 h-6" />
          </div>
          <h3 className="text-sm font-bold text-white">No Issued Certificates Found</h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            {search
              ? 'No certificates match your search query.'
              : 'You have no official certificates on file currently. New credentials ratified by academic faculty will appear here.'}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map(cert => (
            <div
              key={cert.id}
              className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-2xl p-5 shadow-lg flex flex-col justify-between transition-all hover:shadow-indigo-500/5 group"
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="p-2 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400">
                    <Award className="w-5 h-5" />
                  </div>
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3" />
                    Verified Official
                  </span>
                </div>

                <div>
                  <h3 className="text-sm font-bold text-white group-hover:text-indigo-300 transition-colors">
                    {cert.certificateTypeName}
                  </h3>
                  <p className="font-mono text-xs text-indigo-400 font-semibold mt-0.5">
                    {cert.certificateNumber}
                  </p>
                </div>

                <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800/80 space-y-1.5 text-xs">
                  <div className="flex justify-between items-center text-slate-400">
                    <span>Issue Date:</span>
                    <strong className="text-slate-200">{cert.issueDate}</strong>
                  </div>
                  <div className="flex justify-between items-center text-slate-400">
                    <span>Academic Session:</span>
                    <strong className="text-slate-200">{cert.academicSessionName}</strong>
                  </div>
                  <div className="flex justify-between items-center text-slate-400">
                    <span>Issued By:</span>
                    <span className="text-slate-300 truncate max-w-[140px]">{cert.issuedByName || 'Registrar'}</span>
                  </div>
                </div>

                {cert.remarks && (
                  <p className="text-xs text-slate-400 italic line-clamp-2">
                    &ldquo;{cert.remarks}&rdquo;
                  </p>
                )}
              </div>

              {/* Card Actions */}
              <div className="pt-4 mt-3 border-t border-slate-800 flex items-center justify-between gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => setViewingCert(cert)}
                  className="flex-1 text-xs"
                >
                  <Eye className="w-3.5 h-3.5 mr-1.5" />
                  View
                </Button>
                <Button
                  size="sm"
                  variant="default"
                  onClick={() => setViewingCert(cert)}
                  className="flex-1 bg-indigo-600 hover:bg-indigo-500 text-white text-xs"
                >
                  <Printer className="w-3.5 h-3.5 mr-1.5" />
                  Print / PDF
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Certificate Viewer Modal */}
      {viewingCert && (
        <CertificateViewerModal
          certificate={viewingCert}
          onClose={() => setViewingCert(null)}
          userRole="STUDENT"
        />
      )}
    </div>
  );
};
