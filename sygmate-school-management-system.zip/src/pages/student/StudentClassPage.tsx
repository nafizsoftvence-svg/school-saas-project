import React, { useEffect, useState } from 'react';
import {
  GraduationCap,
  Building,
  Users,
  BookOpen,
  Calendar,
  Mail,
  UserCheck,
  CheckCircle2,
  Clock,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Hash
} from 'lucide-react';
import { api } from '../../services/api.js';
import { StudentClassInfo } from '../../types/index.js';
import { Badge } from '../../components/ui/Badge.js';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner.js';

interface StudentClassPageProps {
  onNavigate?: (view: string) => void;
}

export const StudentClassPage: React.FC<StudentClassPageProps> = ({ onNavigate }) => {
  const [data, setData] = useState<StudentClassInfo | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchClassData = async () => {
      try {
        setLoading(true);
        const res = await api.student.getClassInfo();
        if (res.success && res.data) {
          setData(res.data);
        } else {
          setError(res.error || 'Unable to retrieve cohort assignment details.');
        }
      } catch (err: any) {
        setError(err.message || 'Network error retrieving student class records.');
      } finally {
        setLoading(false);
      }
    };

    fetchClassData();
  }, []);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[400px] gap-3">
        <LoadingSpinner size="lg" />
        <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
          Retrieving Academic Cohort Records...
        </p>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="p-8 text-center bg-white rounded-2xl border border-rose-200 text-rose-700 max-w-lg mx-auto space-y-3 shadow-2xs">
        <div className="w-12 h-12 rounded-full bg-rose-50 text-rose-600 flex items-center justify-center mx-auto">
          <GraduationCap className="w-6 h-6" />
        </div>
        <h3 className="text-base font-bold text-slate-900">Cohort Record Unavailable</h3>
        <p className="text-xs text-slate-600">{error || 'Classroom enrollment data could not be verified.'}</p>
      </div>
    );
  }

  const { student, academicSession, schoolClass, section, classTeacher, metrics } = data;

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Hero Banner */}
      <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-blue-600 text-xs font-bold uppercase tracking-wider">
            <GraduationCap className="w-4 h-4" />
            <span>Institutional Academic Registration</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
            {schoolClass.name} — {section.name}
          </h1>
          <p className="text-sm text-slate-600 max-w-2xl leading-relaxed">
            Official academic cohort details, session registration, and institutional enrollment records for{' '}
            <strong className="text-slate-900 font-semibold">{student.fullName}</strong>.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="px-3.5 py-1.5 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-600" />
            <span className="text-xs font-bold text-emerald-800">Enrollment Active</span>
          </div>
          <div className="px-3.5 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono text-slate-600">
            Session: <strong className="text-slate-900">{academicSession.sessionName}</strong>
          </div>
        </div>
      </div>

      {/* Metric Quick Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-2xs space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Class Grade</span>
            <div className="p-2 bg-blue-50 rounded-xl text-blue-600 border border-blue-200">
              <GraduationCap className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-slate-900">{schoolClass.name}</p>
          <p className="text-xs text-slate-500 font-mono">Code: {schoolClass.code} • Grade {schoolClass.numericGrade}</p>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-2xs space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Assigned Section</span>
            <div className="p-2 bg-blue-50 rounded-xl text-blue-600 border border-blue-200">
              <Building className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-slate-900">{section.name}</p>
          <p className="text-xs text-slate-500">Room: <strong className="text-slate-800">{section.roomNumber}</strong></p>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-2xs space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Enrolled Subjects</span>
            <div className="p-2 bg-emerald-50 rounded-xl text-emerald-600 border border-emerald-200">
              <BookOpen className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-slate-900">{metrics.totalClassSubjects} Subjects</p>
          <p className="text-xs text-slate-500">{metrics.totalClassCredits} Total Credit Hours</p>
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-2xs space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Cohort Classmates</span>
            <div className="p-2 bg-amber-50 rounded-xl text-amber-600 border border-amber-200">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-slate-900">{metrics.classmatesCount} Students</p>
          <p className="text-xs text-slate-500">Room Capacity: {section.capacity} Seats</p>
        </div>
      </div>

      {/* Main Two Column Details */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Official Academic Credentials */}
        <div className="lg:col-span-2 space-y-6">
          {/* Card: Student Institutional Identity */}
          <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-7 shadow-2xs space-y-6">
            <div className="flex items-center justify-between border-b border-slate-200 pb-4">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-blue-50 rounded-2xl text-blue-600 border border-blue-200">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900">Student Enrollment &amp; Identification</h3>
                  <p className="text-xs text-slate-500">Official student registry data in Sygmate SIS</p>
                </div>
              </div>
              <Badge variant="success">ACTIVE ENROLLMENT</Badge>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-1">
                <span className="text-xs text-slate-500 font-semibold uppercase tracking-wider flex items-center gap-1.5">
                  <Hash className="w-3.5 h-3.5 text-blue-600" /> Admission Number
                </span>
                <p className="text-base font-bold text-slate-900 font-mono">{student.admissionNumber}</p>
                <p className="text-[11px] text-slate-500">Institutional registration ID</p>
              </div>

              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-1">
                <span className="text-xs text-slate-500 font-semibold uppercase tracking-wider flex items-center gap-1.5">
                  <Hash className="w-3.5 h-3.5 text-blue-600" /> Class Roll Number
                </span>
                <p className="text-base font-bold text-slate-900 font-mono">{student.rollNumber}</p>
                <p className="text-[11px] text-slate-500">Assigned section roll code</p>
              </div>

              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-1">
                <span className="text-xs text-slate-500 font-semibold uppercase tracking-wider flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-emerald-600" /> Academic Session
                </span>
                <p className="text-base font-bold text-slate-900">{academicSession.sessionName}</p>
                <p className="text-[11px] text-slate-500">Term: {academicSession.startDate} to {academicSession.endDate}</p>
              </div>

              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-1">
                <span className="text-xs text-slate-500 font-semibold uppercase tracking-wider flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> Enrollment Status
                </span>
                <p className="text-base font-bold text-emerald-700">{student.enrollmentStatus}</p>
                <p className="text-[11px] text-slate-500">Enrolled on: {student.enrollmentDate}</p>
              </div>
            </div>

            {/* Quick Navigation Action Cards */}
            <div className="pt-4 border-t border-slate-200 grid grid-cols-1 sm:grid-cols-2 gap-4">
              <button
                onClick={() => onNavigate?.('student-subjects')}
                className="flex items-center justify-between p-4 bg-blue-50/70 hover:bg-blue-50 border border-blue-200 rounded-2xl text-left transition-all cursor-pointer group shadow-2xs"
              >
                <div>
                  <h4 className="text-sm font-bold text-slate-900 group-hover:text-blue-700 transition-colors">
                    Explore My Subjects
                  </h4>
                  <p className="text-xs text-slate-500 mt-0.5">View course curriculum &amp; learning materials</p>
                </div>
                <ArrowRight className="w-4 h-4 text-blue-600 group-hover:translate-x-1 transition-transform" />
              </button>

              <button
                onClick={() => onNavigate?.('student-routine')}
                className="flex items-center justify-between p-4 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-2xl text-left transition-all cursor-pointer group shadow-2xs"
              >
                <div>
                  <h4 className="text-sm font-bold text-slate-900 group-hover:text-blue-700 transition-colors">
                    View Class Timetable
                  </h4>
                  <p className="text-xs text-slate-500 mt-0.5">Check weekly routine &amp; period schedules</p>
                </div>
                <Clock className="w-4 h-4 text-slate-600 group-hover:scale-110 transition-transform" />
              </button>
            </div>
          </div>

          {/* Card: Classroom & Facility Information */}
          <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-7 shadow-2xs space-y-4">
            <div className="flex items-center gap-3 border-b border-slate-200 pb-4">
              <div className="p-2.5 bg-blue-50 rounded-2xl text-blue-600 border border-blue-200">
                <Building className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">Classroom Facility &amp; Location</h3>
                <p className="text-xs text-slate-500">Physical room and infrastructure specifications</p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200">
                <span className="text-xs text-slate-500 font-semibold">Assigned Hall / Lab</span>
                <p className="text-lg font-bold text-slate-900 mt-1">{section.roomNumber}</p>
                <p className="text-[11px] text-slate-500 mt-0.5">Primary homeroom location</p>
              </div>

              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200">
                <span className="text-xs text-slate-500 font-semibold">Section Capacity</span>
                <p className="text-lg font-bold text-slate-900 mt-1">{section.capacity} Desks</p>
                <p className="text-[11px] text-slate-500 mt-0.5">{metrics.classmatesCount} currently enrolled</p>
              </div>

              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200">
                <span className="text-xs text-slate-500 font-semibold">Section Identifier</span>
                <p className="text-lg font-bold text-slate-900 font-mono mt-1">{section.code}</p>
                <p className="text-[11px] text-slate-500 mt-0.5">Standard cohort code</p>
              </div>
            </div>
          </div>
        </div>

        {/* Right 1 Col: Class Teacher & Academic Mentor */}
        <div className="space-y-6">
          <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-7 shadow-2xs space-y-6">
            <div className="flex items-center gap-3 border-b border-slate-200 pb-4">
              <div className="p-2.5 bg-emerald-50 rounded-2xl text-emerald-600 border border-emerald-200">
                <UserCheck className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">Class Teacher</h3>
                <p className="text-xs text-slate-500">Assigned Section Academic Mentor</p>
              </div>
            </div>

            {classTeacher ? (
              <div className="space-y-4">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-2xl bg-blue-600 border border-blue-700 flex items-center justify-center text-white font-extrabold text-lg shadow-xs">
                    {(classTeacher.name || '').split(' ').filter(Boolean).map((n) => n[0]).join('').slice(0, 2) || 'T'}
                  </div>
                  <div>
                    <h4 className="text-base font-bold text-slate-900">{classTeacher.name}</h4>
                    <p className="text-xs text-blue-700 font-semibold">{classTeacher.designation}</p>
                    <p className="text-[11px] text-slate-500">{classTeacher.departmentName}</p>
                  </div>
                </div>

                <div className="space-y-3 pt-4 border-t border-slate-200 text-xs">
                  {classTeacher.qualification && (
                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                      <span className="text-slate-500 font-medium block">Academic Qualification:</span>
                      <span className="text-slate-900 font-semibold">{classTeacher.qualification}</span>
                    </div>
                  )}

                  {classTeacher.specialization && (
                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                      <span className="text-slate-500 font-medium block">Specialization:</span>
                      <span className="text-slate-900 font-semibold">{classTeacher.specialization}</span>
                    </div>
                  )}

                  {classTeacher.email && (
                    <div className="flex items-center gap-2 p-3 bg-blue-50/70 border border-blue-200 rounded-xl text-blue-800">
                      <Mail className="w-4 h-4 text-blue-600 shrink-0" />
                      <span className="font-mono truncate">{classTeacher.email}</span>
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <div className="p-6 bg-slate-50 rounded-2xl border border-slate-200 text-center space-y-2">
                <Users className="w-8 h-8 text-slate-400 mx-auto" />
                <p className="text-xs font-semibold text-slate-700">Faculty Mentor Assigned Soon</p>
                <p className="text-[11px] text-slate-500">Contact the academic registrar for inquiries.</p>
              </div>
            )}
          </div>

          {/* Academic Policy Note */}
          <div className="p-5 bg-white border border-slate-200 rounded-3xl space-y-2 text-xs shadow-2xs">
            <div className="flex items-center gap-2 text-blue-700 font-bold">
              <Sparkles className="w-4 h-4 text-blue-600" />
              <span>Academic Session Guidelines</span>
            </div>
            <p className="text-slate-600 leading-relaxed text-[11px]">
              Class section assignments and academic schedules are synchronized with the institutional registry. For transfer requests or elective adjustments, please consult your assigned academic advisor.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
