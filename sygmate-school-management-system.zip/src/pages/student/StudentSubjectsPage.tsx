import React, { useEffect, useState, useMemo } from 'react';
import {
  BookOpen,
  Award,
  CheckCircle2,
  Sparkles,
  AlertCircle,
  Building2,
  User,
  Search,
  Filter,
  FileText,
  Clock,
  Download,
  Calendar,
  Layers,
  GraduationCap,
  ExternalLink,
  ChevronRight,
  RefreshCw,
  FolderOpen,
  BookMarked,
  HelpCircle,
  Hash,
  Mail,
  X
} from 'lucide-react';
import { Badge } from '../../components/ui/Badge.js';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner.js';
import { Modal } from '../../components/ui/Modal.js';
import { api } from '../../services/api.js';
import {
  StudentEnrolledSubject,
  StudentSubjectDetailData,
  StudyMaterial,
  Homework,
  Assignment
} from '../../types/index.js';

export const StudentSubjectsPage: React.FC = () => {
  const [subjects, setSubjects] = useState<StudentEnrolledSubject[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');

  // Modal State for Subject Details
  const [selectedSubjectId, setSelectedSubjectId] = useState<string | null>(null);
  const [subjectDetail, setSubjectDetail] = useState<StudentSubjectDetailData | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [detailError, setDetailError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'overview' | 'materials' | 'homework' | 'assignments'>('overview');

  const fetchSubjects = async () => {
    try {
      setLoading(true);
      const res = await api.getMyEnrolledSubjects({
        search: searchTerm || undefined,
        type: typeFilter !== 'ALL' ? typeFilter : undefined,
        status: statusFilter !== 'ALL' ? statusFilter : undefined
      });

      if (res.success && res.data) {
        setSubjects(res.data);
      } else {
        // Fallback to dashboard subjects if necessary
        const dashRes = await api.getStudentDashboard();
        if (dashRes.success && dashRes.data?.enrolledSubjects) {
          const fallback = dashRes.data.enrolledSubjects.map((s: any) => ({
            id: s.id,
            name: s.name,
            code: s.code,
            type: s.type || 'core',
            credits: s.credits || 3,
            status: 'active' as const,
            departmentName: s.departmentName || 'Department of Academics',
            teacher: {
              id: 't-1',
              name: s.teacherName || 'Assigned Faculty',
              designation: 'Course Instructor'
            },
            counts: {
              studyMaterials: 0,
              homework: 0,
              assignments: 0
            }
          }));
          setSubjects(fallback);
        }
      }
    } catch (err) {
      console.error('Failed to load curriculum subjects:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSubjects();
  }, [typeFilter, statusFilter]);

  // Client-side search for instant responsiveness
  const filteredSubjects = useMemo(() => {
    const q = (searchTerm || '').toLowerCase();
    return subjects.filter((sub) => {
      const matchesSearch =
        !q ||
        (sub.name || '').toLowerCase().includes(q) ||
        (sub.code || '').toLowerCase().includes(q) ||
        (sub.description ? sub.description.toLowerCase().includes(q) : false) ||
        (sub.teacher?.name ? sub.teacher.name.toLowerCase().includes(q) : false);

      const matchesType = typeFilter === 'ALL' || (sub.type || '').toLowerCase() === (typeFilter || '').toLowerCase();
      const matchesStatus = statusFilter === 'ALL' || (sub.status || '').toLowerCase() === (statusFilter || '').toLowerCase();

      return matchesSearch && matchesType && matchesStatus;
    });
  }, [subjects, searchTerm, typeFilter, statusFilter]);

  const handleOpenDetail = async (subjectId: string) => {
    setSelectedSubjectId(subjectId);
    setActiveTab('overview');
    setDetailLoading(true);
    setDetailError(null);

    try {
      const res = await api.getMySubjectDetail(subjectId);
      if (res.success && res.data) {
        setSubjectDetail(res.data);
      } else {
        setDetailError(res.error || 'Failed to load subject details.');
      }
    } catch (err: any) {
      console.error('Error fetching subject detail:', err);
      setDetailError(err.message || 'Unable to retrieve course details.');
    } finally {
      setDetailLoading(false);
    }
  };

  const handleCloseDetail = () => {
    setSelectedSubjectId(null);
    setSubjectDetail(null);
  };

  const handleResetFilters = () => {
    setSearchTerm('');
    setTypeFilter('ALL');
    setStatusFilter('ALL');
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Top Banner */}
      <div className="relative overflow-hidden bg-gradient-to-r from-emerald-950/50 via-slate-900/80 to-indigo-950/50 backdrop-blur-xl border border-white/10 rounded-3xl p-6 sm:p-8 shadow-2xl shadow-black/40">
        <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none -mr-16 -mt-16" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold uppercase tracking-wider">
              <Sparkles className="w-4 h-4" />
              <span>Curriculum &amp; Course Directory</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">My Subjects</h1>
            <p className="text-sm text-slate-300 max-w-2xl">
              Course syllabus modules, accredited learning materials, homework, and assignment rubrics for your enrolled academic cohort.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="px-4 py-2.5 bg-white/5 border border-white/10 rounded-2xl flex items-center gap-3 text-xs">
              <BookMarked className="w-4 h-4 text-emerald-400" />
              <span className="text-slate-300">
                Enrolled Modules: <strong className="text-white font-bold">{filteredSubjects.length}</strong>
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Search & Filter Controls */}
      <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-4 sm:p-6 shadow-xl shadow-black/20 space-y-4">
        <div className="flex flex-col md:flex-row items-center gap-4">
          {/* Search Input */}
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search by subject name, code (e.g. MTH-201), or instructor..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-11 pr-4 py-2.5 bg-slate-900/60 border border-white/10 rounded-xl text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all"
            />
            {searchTerm && (
              <button
                onClick={() => setSearchTerm('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white p-1"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Type Filter */}
          <div className="flex items-center gap-2 w-full md:w-auto">
            <span className="text-xs font-medium text-slate-400 whitespace-nowrap">Type:</span>
            <select
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
              className="w-full md:w-40 py-2.5 px-3 bg-slate-900/60 border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-indigo-500"
            >
              <option value="ALL">All Types</option>
              <option value="core">Core</option>
              <option value="elective">Elective</option>
              <option value="practical">Practical</option>
              <option value="theory">Theory</option>
            </select>
          </div>

          {/* Status Filter */}
          <div className="flex items-center gap-2 w-full md:w-auto">
            <span className="text-xs font-medium text-slate-400 whitespace-nowrap">Status:</span>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full md:w-36 py-2.5 px-3 bg-slate-900/60 border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-indigo-500"
            >
              <option value="ALL">All Status</option>
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
            </select>
          </div>

          {/* Reset Filters */}
          {(searchTerm || typeFilter !== 'ALL' || statusFilter !== 'ALL') && (
            <button
              onClick={handleResetFilters}
              className="w-full md:w-auto px-4 py-2.5 bg-white/5 hover:bg-white/10 text-xs font-medium text-slate-300 rounded-xl border border-white/10 transition-all flex items-center justify-center gap-1.5"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Reset</span>
            </button>
          )}
        </div>
      </div>

      {/* Loading state */}
      {loading ? (
        <div className="py-24 flex flex-col items-center justify-center">
          <LoadingSpinner size="lg" message="Loading your enrolled subjects..." />
        </div>
      ) : filteredSubjects.length === 0 ? (
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-12 text-center space-y-3">
          <BookOpen className="w-12 h-12 text-slate-500 mx-auto" />
          <h3 className="text-lg font-bold text-white">No Subjects Found</h3>
          <p className="text-xs text-slate-400 max-w-md mx-auto">
            No enrolled subjects match your current search query or filter criteria.
          </p>
          <button
            onClick={handleResetFilters}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-xl transition-all"
          >
            Clear Search Filters
          </button>
        </div>
      ) : (
        /* Subjects Grid */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {(filteredSubjects || []).map((sub) => {
            const isElective = sub.type?.toLowerCase() === 'elective';
            const isPractical = sub.type?.toLowerCase() === 'practical';

            return (
              <div
                key={sub.id}
                className="bg-white/5 backdrop-blur-xl border border-white/10 hover:border-indigo-500/40 rounded-3xl p-6 shadow-xl shadow-black/20 flex flex-col justify-between space-y-5 transition-all duration-200 group hover:-translate-y-0.5"
              >
                {/* Subject Header */}
                <div className="space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    <Badge
                      variant={isElective ? 'warning' : isPractical ? 'info' : 'success'}
                    >
                      {sub.type ? sub.type.toUpperCase() : 'CORE'}
                    </Badge>
                    <span className="text-xs font-mono font-bold text-indigo-300 px-2.5 py-1 bg-indigo-500/10 border border-indigo-500/20 rounded-lg">
                      {sub.code}
                    </span>
                  </div>

                  <div>
                    <h3 className="text-lg font-bold text-white group-hover:text-indigo-300 transition-colors leading-snug">
                      {sub.name}
                    </h3>
                    <p className="text-xs text-slate-400 mt-1 line-clamp-2">
                      {sub.description || 'Core academic course unit with theoretical and applied assignments.'}
                    </p>
                  </div>
                </div>

                {/* Teacher / Faculty Info */}
                <div className="p-3.5 bg-slate-900/60 rounded-2xl border border-white/5 space-y-2 text-xs">
                  <div className="flex items-center gap-2 text-slate-200">
                    <User className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span className="truncate">
                      Instructor: <strong className="text-white">{sub.teacher?.name || 'Assigned Faculty'}</strong>
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-400 text-[11px]">
                    <Building2 className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                    <span className="truncate">{sub.departmentName}</span>
                  </div>
                </div>

                {/* Resource Badges */}
                <div className="grid grid-cols-3 gap-2 text-center text-xs font-mono border-t border-white/5 pt-3">
                  <div className="p-2 bg-white/5 rounded-xl">
                    <span className="text-[10px] text-slate-400 uppercase block">Materials</span>
                    <span className="text-xs font-bold text-white">{sub.counts.studyMaterials}</span>
                  </div>
                  <div className="p-2 bg-white/5 rounded-xl">
                    <span className="text-[10px] text-slate-400 uppercase block">Homework</span>
                    <span className="text-xs font-bold text-white">{sub.counts.homework}</span>
                  </div>
                  <div className="p-2 bg-white/5 rounded-xl">
                    <span className="text-[10px] text-slate-400 uppercase block">Assign.</span>
                    <span className="text-xs font-bold text-white">{sub.counts.assignments}</span>
                  </div>
                </div>

                {/* Card Action */}
                <div className="pt-2">
                  <button
                    onClick={() => handleOpenDetail(sub.id)}
                    className="w-full py-2.5 px-4 bg-indigo-600/20 hover:bg-indigo-600 text-indigo-300 hover:text-white border border-indigo-500/30 hover:border-indigo-500 rounded-xl text-xs font-semibold transition-all flex items-center justify-center gap-2"
                  >
                    <span>View Subject Details</span>
                    <ChevronRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Subject Details Modal */}
      <Modal
        isOpen={Boolean(selectedSubjectId)}
        onClose={handleCloseDetail}
        size="xl"
        title={
          <div className="flex items-center gap-3">
            <div className="p-2 bg-indigo-500/20 rounded-xl text-indigo-400">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">
                {subjectDetail?.subject.name || 'Subject Information'}
              </h3>
              <p className="text-xs text-slate-400 font-mono">
                Code: {subjectDetail?.subject.code} • {subjectDetail?.subject.credits} Academic Credits
              </p>
            </div>
          </div>
        }
      >
        {detailLoading ? (
          <div className="py-16 flex flex-col items-center justify-center">
            <LoadingSpinner size="md" message="Loading course curriculum details..." />
          </div>
        ) : detailError ? (
          <div className="p-6 bg-rose-500/10 border border-rose-500/20 rounded-2xl text-center space-y-3">
            <AlertCircle className="w-8 h-8 text-rose-400 mx-auto" />
            <p className="text-xs text-rose-300">{detailError}</p>
            <button
              onClick={handleCloseDetail}
              className="px-4 py-2 bg-slate-800 text-white text-xs font-semibold rounded-xl"
            >
              Close Window
            </button>
          </div>
        ) : subjectDetail ? (
          <div className="space-y-6">
            {/* Modal Navigation Tabs */}
            <div className="flex items-center gap-2 border-b border-white/10 pb-2 overflow-x-auto text-xs font-medium">
              <button
                onClick={() => setActiveTab('overview')}
                className={`px-4 py-2 rounded-xl transition-all whitespace-nowrap flex items-center gap-1.5 ${
                  activeTab === 'overview'
                    ? 'bg-indigo-600 text-white font-bold shadow-lg shadow-indigo-600/30'
                    : 'text-slate-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <BookOpen className="w-3.5 h-3.5" />
                <span>Overview &amp; Instructor</span>
              </button>

              <button
                onClick={() => setActiveTab('materials')}
                className={`px-4 py-2 rounded-xl transition-all whitespace-nowrap flex items-center gap-1.5 ${
                  activeTab === 'materials'
                    ? 'bg-indigo-600 text-white font-bold shadow-lg shadow-indigo-600/30'
                    : 'text-slate-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <FileText className="w-3.5 h-3.5" />
                <span>Study Materials ({subjectDetail?.studyMaterials?.length || 0})</span>
              </button>

              <button
                onClick={() => setActiveTab('homework')}
                className={`px-4 py-2 rounded-xl transition-all whitespace-nowrap flex items-center gap-1.5 ${
                  activeTab === 'homework'
                    ? 'bg-indigo-600 text-white font-bold shadow-lg shadow-indigo-600/30'
                    : 'text-slate-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <Clock className="w-3.5 h-3.5" />
                <span>Homework ({subjectDetail?.homework?.length || 0})</span>
              </button>

              <button
                onClick={() => setActiveTab('assignments')}
                className={`px-4 py-2 rounded-xl transition-all whitespace-nowrap flex items-center gap-1.5 ${
                  activeTab === 'assignments'
                    ? 'bg-indigo-600 text-white font-bold shadow-lg shadow-indigo-600/30'
                    : 'text-slate-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <Award className="w-3.5 h-3.5" />
                <span>Assignments ({subjectDetail?.assignments?.length || 0})</span>
              </button>
            </div>

            {/* TAB 1: OVERVIEW */}
            {activeTab === 'overview' && (
              <div className="space-y-6">
                {/* Course Metadata */}
                <div className="p-5 bg-white/5 rounded-2xl border border-white/10 space-y-3">
                  <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">Course Description</h4>
                  <p className="text-sm text-slate-200 leading-relaxed">
                    {subjectDetail.subject.description || 'Comprehensive syllabus designed according to institutional academic standards.'}
                  </p>
                </div>

                {/* Fast Facts Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  <div className="p-3 bg-white/5 rounded-xl border border-white/5">
                    <span className="text-slate-400 block text-[11px]">Subject Type</span>
                    <span className="text-white font-bold uppercase mt-0.5 block">{subjectDetail.subject.type}</span>
                  </div>
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                    <span className="text-slate-500 block text-[11px] font-semibold">Credit Weight</span>
                    <span className="text-slate-900 font-bold mt-0.5 block">{subjectDetail.subject.credits} Credits</span>
                  </div>
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                    <span className="text-slate-500 block text-[11px] font-semibold">Class Cohort</span>
                    <span className="text-slate-900 font-bold mt-0.5 block">{subjectDetail.classInfo.className}</span>
                  </div>
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                    <span className="text-slate-500 block text-[11px] font-semibold">Section</span>
                    <span className="text-slate-900 font-bold mt-0.5 block">{subjectDetail.classInfo.sectionName}</span>
                  </div>
                </div>

                {/* Instructor Card */}
                {subjectDetail.teacher ? (
                  <div className="p-5 bg-white rounded-2xl border border-slate-200 space-y-3 shadow-2xs">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-xl bg-blue-600 border border-blue-700 flex items-center justify-center text-white font-bold text-base shadow-xs">
                        {(subjectDetail.teacher.name || '').split(' ').filter(Boolean).map((n) => n[0]).join('').slice(0, 2) || 'T'}
                      </div>
                      <div>
                        <h4 className="text-sm font-bold text-slate-900">{subjectDetail.teacher.name}</h4>
                        <p className="text-xs text-blue-700 font-semibold">{subjectDetail.teacher.designation}</p>
                        <p className="text-[11px] text-slate-500">{subjectDetail.teacher.departmentName}</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs pt-2 border-t border-slate-200">
                      {subjectDetail.teacher.qualification && (
                        <div className="text-slate-800">
                          <span className="text-slate-500 block text-[10px] uppercase font-semibold">Qualification:</span>
                          <span>{subjectDetail.teacher.qualification}</span>
                        </div>
                      )}
                      {subjectDetail.teacher.email && (
                        <div className="text-slate-800">
                          <span className="text-slate-500 block text-[10px] uppercase font-semibold">Institutional Email:</span>
                          <span className="font-mono text-blue-700">{subjectDetail.teacher.email}</span>
                        </div>
                      )}
                    </div>
                  </div>
                ) : (
                  <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-500 text-center">
                    No faculty instructor assigned yet.
                  </div>
                )}
              </div>
            )}

            {/* TAB 2: STUDY MATERIALS */}
            {activeTab === 'materials' && (
              <div className="space-y-4">
                {(subjectDetail?.studyMaterials?.length || 0) === 0 ? (
                  <div className="p-10 bg-white/5 rounded-2xl border border-white/5 text-center space-y-2">
                    <FolderOpen className="w-10 h-10 text-slate-500 mx-auto" />
                    <p className="text-sm font-bold text-white">No Study Materials Published</p>
                    <p className="text-xs text-slate-400">Your instructor has not uploaded materials for this subject yet.</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {(subjectDetail.studyMaterials || []).map((mat) => (
                      <div
                        key={mat.id}
                        className="p-4 bg-white/5 hover:bg-white/10 rounded-2xl border border-white/10 flex items-start justify-between gap-4 transition-all"
                      >
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="text-[10px] font-bold font-mono px-2 py-0.5 bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 rounded uppercase">
                              {mat.fileType}
                            </span>
                            <h5 className="text-sm font-bold text-white">{mat.title}</h5>
                          </div>
                          <p className="text-xs text-slate-300">{mat.description}</p>
                          <div className="flex items-center gap-4 text-[11px] text-slate-500 font-mono pt-1">
                            <span>Size: {mat.fileSize}</span>
                            <span>Uploaded: {mat.uploadDate}</span>
                            <span>By: {mat.teacherName}</span>
                          </div>
                        </div>

                        <a
                          href={mat.fileUrl}
                          target="_blank"
                          rel="noreferrer"
                          className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 shrink-0 transition-all"
                        >
                          <Download className="w-3.5 h-3.5" />
                          <span>View Material</span>
                        </a>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* TAB 3: HOMEWORK */}
            {activeTab === 'homework' && (
              <div className="space-y-4">
                {(subjectDetail?.homework?.length || 0) === 0 ? (
                  <div className="p-10 bg-white/5 rounded-2xl border border-white/5 text-center space-y-2">
                    <Clock className="w-10 h-10 text-slate-500 mx-auto" />
                    <p className="text-sm font-bold text-white">No Active Homework</p>
                    <p className="text-xs text-slate-400">There are no pending homework assignments for this subject.</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {(subjectDetail.homework || []).map((hw) => (
                      <div
                        key={hw.id}
                        className="p-4 bg-white/5 rounded-2xl border border-white/10 space-y-2"
                      >
                        <div className="flex items-center justify-between">
                          <h5 className="text-sm font-bold text-white">{hw.title}</h5>
                          <Badge variant="warning">Due: {hw.dueDate}</Badge>
                        </div>
                        <p className="text-xs text-slate-300 leading-relaxed">{hw.description}</p>
                        <div className="flex items-center justify-between text-[11px] text-slate-500 font-mono pt-2 border-t border-white/5">
                          <span>Assigned on: {hw.assignedDate}</span>
                          <span>Instructor: {hw.teacherName}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* TAB 4: ASSIGNMENTS */}
            {activeTab === 'assignments' && (
              <div className="space-y-4">
                {(subjectDetail?.assignments?.length || 0) === 0 ? (
                  <div className="p-10 bg-white/5 rounded-2xl border border-white/5 text-center space-y-2">
                    <Award className="w-10 h-10 text-slate-500 mx-auto" />
                    <p className="text-sm font-bold text-white">No Course Assignments</p>
                    <p className="text-xs text-slate-400">There are no major project assignments active at this time.</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {(subjectDetail.assignments || []).map((assign) => (
                      <div
                        key={assign.id}
                        className="p-4 bg-white/5 rounded-2xl border border-white/10 space-y-3"
                      >
                        <div className="flex items-center justify-between gap-2">
                          <h5 className="text-sm font-bold text-white">{assign.title}</h5>
                          <Badge variant="success">{assign.totalMarks} Total Marks</Badge>
                        </div>
                        <p className="text-xs text-slate-300 leading-relaxed">{assign.description}</p>
                        
                        {assign.attachmentUrl && (
                          <div className="p-2.5 bg-white/5 rounded-xl border border-white/5 flex items-center justify-between text-xs">
                            <span className="text-slate-300 font-mono truncate">{assign.attachmentName || 'Assignment_Rubric_Doc'}</span>
                            <a
                              href={assign.attachmentUrl}
                              target="_blank"
                              rel="noreferrer"
                              className="text-indigo-400 hover:text-indigo-300 font-semibold flex items-center gap-1 shrink-0 ml-2"
                            >
                              <Download className="w-3.5 h-3.5" />
                              <span>Download Rubric</span>
                            </a>
                          </div>
                        )}

                        <div className="flex items-center justify-between text-[11px] text-slate-500 font-mono pt-1">
                          <span>Start: {assign.startDate}</span>
                          <span className="text-rose-400 font-bold">Submission Deadline: {assign.dueDate}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        ) : null}
      </Modal>
    </div>
  );
};
