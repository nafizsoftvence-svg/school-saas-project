/**
 * Part 15D — Public Certificate Verification Portal
 * Sygmate School Management System
 *
 * Design Constitution Compliant:
 * Primary Navy: #16263B, Secondary Blue: #1D64C9, Accent Sky: #79C7FF, Background: #F6F8FC, Surface: #FFFFFF
 * Data Minimization & Privacy Compliant:
 * Never exposes unmasked student details, personal documents, guardian info, or internal notes.
 */

import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  Search,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Clock,
  Building2,
  Calendar,
  Award,
  ExternalLink,
  QrCode,
  ArrowRight,
  RefreshCw,
  FileCheck2,
  Lock
} from 'lucide-react';
import { PublicCertificateVerificationResult } from '../../types';
import { api } from '../../services/api';

export const PublicCertificateVerificationPage: React.FC<{ onNavigateToLogin?: () => void }> = ({
  onNavigateToLogin
}) => {
  const [queryReference, setQueryReference] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);
  const [result, setResult] = useState<PublicCertificateVerificationResult | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Auto-verify on mount if ?ref=... is present in URL
  useEffect(() => {
    try {
      const urlParams = new URLSearchParams(window.location.search);
      const refParam = urlParams.get('ref') || urlParams.get('code') || urlParams.get('token');
      if (refParam) {
        setQueryReference(refParam);
        verifyReference(refParam);
      }
    } catch (e) {
      console.error('Failed to parse URL query', e);
    }
  }, []);

  const verifyReference = async (refToken: string) => {
    const cleanRef = refToken.trim();
    if (!cleanRef) {
      setErrorMessage('Please enter a certificate verification reference or certificate number.');
      return;
    }

    setIsVerifying(true);
    setErrorMessage(null);
    setResult(null);

    try {
      const res = await api.certificates.publicVerify(cleanRef);
      setResult(res);
    } catch (err: any) {
      setResult({
        status: 'NOT_FOUND',
        isAuthentic: false,
        message: err.message || 'The supplied certificate reference could not be verified or is not active.'
      });
    } finally {
      setIsVerifying(false);
    }
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    verifyReference(queryReference);
  };

  return (
    <div className="min-h-screen bg-[#F6F8FC] text-slate-800 flex flex-col font-sans selection:bg-[#79C7FF]/30">
      {/* Top Navigation Bar */}
      <header className="bg-[#16263B] border-b border-slate-700/60 sticky top-0 z-30 shadow-md">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#1D64C9] to-[#79C7FF] flex items-center justify-center text-white shadow-sm font-bold text-lg tracking-wider">
              S
            </div>
            <div>
              <div className="text-white font-bold tracking-tight text-base flex items-center gap-2">
                Sygmate International Academy
                <span className="text-[10px] uppercase tracking-widest text-[#79C7FF] font-semibold hidden sm:inline-block">
                  Registry
                </span>
              </div>
              <div className="text-slate-400 text-xs">
                Official Credential Verification Service
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {onNavigateToLogin && (
              <button
                type="button"
                onClick={onNavigateToLogin}
                className="text-xs font-semibold text-slate-300 hover:text-white px-3 py-1.5 rounded-lg border border-slate-700 hover:border-slate-500 transition-colors"
              >
                Sign In to Portal
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 max-w-4xl w-full mx-auto px-4 sm:px-6 py-10 space-y-8">
        {/* Hero Section */}
        <div className="text-center space-y-3">
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-[#1D64C9] bg-[#1D64C9]/10 px-3 py-1 rounded-full border border-[#1D64C9]/20">
            <ShieldCheck className="w-4 h-4 text-[#1D64C9]" />
            <span>Digital Certificate Registry</span>
            <span aria-hidden="true">·</span>
            <span>Cryptographic Verification</span>
          </div>

          <h1 className="text-3xl sm:text-4xl font-extrabold text-[#16263B] tracking-tight">
            Verify Certificate Authenticity
          </h1>
          <p className="text-sm text-slate-600 max-w-xl mx-auto leading-relaxed">
            Enter the unique Digital Verification Reference (e.g., <code className="font-mono text-xs bg-slate-200/80 px-1 py-0.5 rounded text-slate-800">SEC-VER-XXXX-XXXX-XXXX-XXXX</code>) or the official Certificate Number found on the printed document.
          </p>
        </div>

        {/* Search Input Box */}
        <div className="bg-white rounded-2xl p-4 sm:p-6 shadow-sm border border-slate-200">
          <form onSubmit={handleSearchSubmit} className="space-y-4">
            <div className="relative">
              <label htmlFor="ref-input" className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
                Verification Reference or Certificate Number
              </label>
              <div className="relative flex items-center">
                <Search className="w-5 h-5 text-slate-400 absolute left-3.5" />
                <input
                  id="ref-input"
                  type="text"
                  value={queryReference}
                  onChange={(e) => setQueryReference(e.target.value)}
                  placeholder="Enter reference, e.g. SEC-VER-A1B2-C3D4-E5F6-0001 or MERIT/2026/000001"
                  className="w-full bg-[#F6F8FC] border border-slate-300 rounded-xl pl-11 pr-32 py-3.5 text-sm text-[#16263B] placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-[#1D64C9] focus:bg-white font-mono transition-all"
                  autoComplete="off"
                  spellCheck="false"
                />
                <button
                  type="submit"
                  disabled={isVerifying || !queryReference.trim()}
                  className="absolute right-2 px-5 py-2 rounded-lg bg-[#16263B] hover:bg-[#1D64C9] disabled:bg-slate-300 text-white font-semibold text-xs tracking-wide shadow transition-colors flex items-center gap-1.5"
                >
                  {isVerifying ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Checking...</span>
                    </>
                  ) : (
                    <>
                      <span>Verify</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </>
                  )}
                </button>
              </div>
            </div>

            {errorMessage && (
              <p className="text-xs text-rose-600 font-medium">{errorMessage}</p>
            )}

            {/* Quick Demo Reference Pill Buttons */}
            <div className="pt-2 border-t border-slate-100 flex items-center gap-2 flex-wrap text-xs text-slate-500">
              <span className="font-semibold">Demo samples:</span>
              <button
                type="button"
                onClick={() => {
                  setQueryReference('SEC-VER-A1B2-C3D4-E5F6-0001');
                  verifyReference('SEC-VER-A1B2-C3D4-E5F6-0001');
                }}
                className="underline hover:text-[#1D64C9] font-mono text-[11px]"
              >
                Valid Merit Cert (Rivera)
              </button>
              <span>·</span>
              <button
                type="button"
                onClick={() => {
                  setQueryReference('SEC-VER-F6A7-B8C9-D0E1-0006');
                  verifyReference('SEC-VER-F6A7-B8C9-D0E1-0006');
                }}
                className="underline hover:text-rose-600 font-mono text-[11px]"
              >
                Revoked Cert
              </button>
              <span>·</span>
              <button
                type="button"
                onClick={() => {
                  setQueryReference('SEC-VER-E5F6-A7B8-C9D0-0005');
                  verifyReference('SEC-VER-E5F6-A7B8-C9D0-0005');
                }}
                className="underline hover:text-amber-600 font-mono text-[11px]"
              >
                Cancelled Cert
              </button>
            </div>
          </form>
        </div>

        {/* Verification Result Card */}
        {result && (
          <div className="animate-in fade-in slide-in-from-bottom-2 duration-300">
            {/* 1. VALID / AUTHENTIC */}
            {result.status === 'VALID' && result.certificate && (
              <div className="bg-white rounded-2xl border-2 border-emerald-500/60 shadow-lg overflow-hidden">
                <div className="bg-emerald-50 border-b border-emerald-200/60 px-6 py-4 flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-emerald-600 text-white flex items-center justify-center shadow-sm">
                    <CheckCircle2 className="w-6 h-6" />
                  </div>
                  <div>
                    <h2 className="text-base font-bold text-emerald-900">
                      Certificate Authenticity Verified
                    </h2>
                    <p className="text-xs text-emerald-700">
                      This is an official, unmodified certificate registered with Sygmate International Academy.
                    </p>
                  </div>
                </div>

                <div className="p-6 sm:p-8 space-y-6">
                  {/* Institutional Header */}
                  <div className="border-b border-slate-100 pb-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div>
                      <div className="text-xs font-semibold text-slate-400 uppercase tracking-widest">
                        Issuing Institution
                      </div>
                      <div className="text-lg font-bold text-[#16263B]">
                        {result.certificate.schoolName}
                      </div>
                      {result.certificate.schoolAddress && (
                        <div className="text-xs text-slate-500">
                          {result.certificate.schoolAddress}
                        </div>
                      )}
                    </div>
                    <div className="text-left sm:text-right">
                      <div className="text-xs font-semibold text-slate-400 uppercase tracking-widest">
                        Official Status
                      </div>
                      <div className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-700 bg-emerald-100 px-2.5 py-1 rounded-md mt-0.5">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        ACTIVE & ISSUED
                      </div>
                    </div>
                  </div>

                  {/* Key Metadata Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-5 text-sm">
                    <div>
                      <div className="text-xs text-slate-400 font-semibold uppercase tracking-wider">
                        Certificate Classification
                      </div>
                      <div className="font-bold text-[#16263B] mt-0.5 flex items-center gap-1.5">
                        <Award className="w-4 h-4 text-[#1D64C9]" />
                        {result.certificate.certificateTypeName}
                      </div>
                    </div>

                    <div>
                      <div className="text-xs text-slate-400 font-semibold uppercase tracking-wider">
                        Certificate Number
                      </div>
                      <div className="font-mono font-bold text-[#16263B] mt-0.5">
                        {result.certificate.certificateNumber}
                      </div>
                    </div>

                    <div>
                      <div className="text-xs text-slate-400 font-semibold uppercase tracking-wider">
                        Issue Date
                      </div>
                      <div className="font-bold text-[#16263B] mt-0.5 flex items-center gap-1.5">
                        <Calendar className="w-4 h-4 text-slate-400" />
                        {result.certificate.issueDate}
                      </div>
                    </div>

                    <div>
                      <div className="text-xs text-slate-400 font-semibold uppercase tracking-wider">
                        Recipient (Privacy Masked)
                      </div>
                      <div className="font-bold text-[#16263B] mt-0.5 font-mono">
                        {result.certificate.maskedStudentName}
                      </div>
                      <div className="text-[11px] text-slate-400">
                        Admission Ref: {result.certificate.admissionNumberMasked}
                      </div>
                    </div>

                    <div>
                      <div className="text-xs text-slate-400 font-semibold uppercase tracking-wider">
                        Academic Standing / Class
                      </div>
                      <div className="font-bold text-[#16263B] mt-0.5">
                        {result.certificate.className || 'Secondary'}
                      </div>
                      <div className="text-[11px] text-slate-400">
                        Session: {result.certificate.academicSessionName}
                      </div>
                    </div>

                    <div>
                      <div className="text-xs text-slate-400 font-semibold uppercase tracking-wider">
                        Digital Verification Ref
                      </div>
                      <div className="font-mono text-xs font-semibold text-[#1D64C9] mt-0.5 break-all">
                        {result.certificate.verificationReference}
                      </div>
                    </div>
                  </div>

                  {/* Privacy & Anti-Tamper Notice */}
                  <div className="bg-[#F6F8FC] border border-slate-200/80 rounded-xl p-4 flex items-start gap-3 text-xs text-slate-600 leading-relaxed">
                    <Lock className="w-4 h-4 text-[#1D64C9] shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold text-slate-800">Privacy & Data Minimization:</span> In accordance with educational privacy regulations, personal identifiers, guardian data, and academic score breakdowns are masked from public inspection. For verified admissions confirmation, contact the registrar's office.
                    </div>
                  </div>
                </div>

                <div className="bg-slate-50 border-t border-slate-200 px-6 py-3 text-xs text-slate-500 flex items-center justify-between">
                  <span>Verified at: {new Date(result.certificate.verificationTimestamp).toLocaleString()}</span>
                  <span className="font-mono text-[10px] text-slate-400">SHA-256 Validated</span>
                </div>
              </div>
            )}

            {/* 2. REVOKED CERTIFICATE */}
            {result.status === 'REVOKED' && result.certificate && (
              <div className="bg-white rounded-2xl border-2 border-rose-500 shadow-lg overflow-hidden">
                <div className="bg-rose-50 border-b border-rose-200 px-6 py-4 flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-rose-600 text-white flex items-center justify-center shadow-sm">
                    <XCircle className="w-6 h-6" />
                  </div>
                  <div>
                    <h2 className="text-base font-bold text-rose-900">
                      Institutional Notice: Certificate Revoked
                    </h2>
                    <p className="text-xs text-rose-700">
                      This certificate was officially issued but has subsequently been REVOKED by administrative authority.
                    </p>
                  </div>
                </div>

                <div className="p-6 sm:p-8 space-y-6">
                  <div className="bg-rose-50/50 border border-rose-200 rounded-xl p-4 space-y-2">
                    <div className="text-xs font-bold text-rose-800 uppercase tracking-wider">
                      Revocation Details
                    </div>
                    <p className="text-sm text-rose-900 font-medium">
                      Reason: {result.certificate.revocationReason || 'Revoked by school administrative authority.'}
                    </p>
                    {result.certificate.revokedAt && (
                      <p className="text-xs text-rose-700">
                        Effective Revocation Date: {new Date(result.certificate.revokedAt).toLocaleDateString()}
                      </p>
                    )}
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-xs text-slate-400 font-semibold uppercase">Certificate Number</span>
                      <p className="font-mono font-bold text-slate-800">{result.certificate.certificateNumber}</p>
                    </div>
                    <div>
                      <span className="text-xs text-slate-400 font-semibold uppercase">Certificate Classification</span>
                      <p className="font-bold text-slate-800">{result.certificate.certificateTypeName}</p>
                    </div>
                    <div>
                      <span className="text-xs text-slate-400 font-semibold uppercase">Issued To (Masked)</span>
                      <p className="font-mono font-bold text-slate-800">{result.certificate.maskedStudentName}</p>
                    </div>
                    <div>
                      <span className="text-xs text-slate-400 font-semibold uppercase">Issuing Institution</span>
                      <p className="font-bold text-slate-800">{result.certificate.schoolName}</p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* 3. CANCELLED CERTIFICATE */}
            {result.status === 'CANCELLED' && result.certificate && (
              <div className="bg-white rounded-2xl border-2 border-amber-500 shadow-lg overflow-hidden">
                <div className="bg-amber-50 border-b border-amber-200 px-6 py-4 flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-amber-600 text-white flex items-center justify-center shadow-sm">
                    <AlertTriangle className="w-6 h-6" />
                  </div>
                  <div>
                    <h2 className="text-base font-bold text-amber-900">
                      Certificate Cancelled / Void
                    </h2>
                    <p className="text-xs text-amber-700">
                      This certificate record was officially cancelled and is not valid.
                    </p>
                  </div>
                </div>

                <div className="p-6 space-y-4">
                  <p className="text-xs text-slate-600">
                    Reason: {result.certificate.cancellationReason || 'Cancelled before completion.'}
                  </p>
                  <div className="font-mono text-sm font-bold text-slate-800">
                    Certificate Number: {result.certificate.certificateNumber}
                  </div>
                </div>
              </div>
            )}

            {/* 4. NOT FOUND */}
            {result.status === 'NOT_FOUND' && (
              <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-8 text-center space-y-4">
                <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-500 mx-auto flex items-center justify-center">
                  <XCircle className="w-6 h-6" />
                </div>
                <div className="space-y-1">
                  <h3 className="text-base font-bold text-slate-800">
                    Verification Unsuccessful
                  </h3>
                  <p className="text-xs text-slate-500 max-w-md mx-auto">
                    {result.message}
                  </p>
                </div>
                <div className="text-[11px] text-slate-400 max-w-sm mx-auto">
                  Please confirm that the reference token or certificate serial was typed accurately without spaces or typos.
                </div>
              </div>
            )}

            {/* 5. RATE LIMITED */}
            {result.status === 'RATE_LIMITED' && (
              <div className="bg-white rounded-2xl border border-amber-300 shadow-sm p-8 text-center space-y-3">
                <Clock className="w-10 h-10 text-amber-500 mx-auto" />
                <h3 className="text-base font-bold text-slate-800">Rate Limit Exceeded</h3>
                <p className="text-xs text-slate-600 max-w-md mx-auto">{result.message}</p>
              </div>
            )}
          </div>
        )}

        {/* Informational Guidance Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4">
          <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs space-y-2">
            <div className="w-8 h-8 rounded-lg bg-[#16263B]/5 text-[#16263B] flex items-center justify-center font-bold text-xs">
              <FileCheck2 className="w-4 h-4 text-[#1D64C9]" />
            </div>
            <h3 className="text-sm font-bold text-slate-800">QR Code Verification</h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Every printed certificate features an authentic QR code linking directly to this cryptographic verification portal.
            </p>
          </div>

          <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs space-y-2">
            <div className="w-8 h-8 rounded-lg bg-[#16263B]/5 text-[#16263B] flex items-center justify-center font-bold text-xs">
              <Lock className="w-4 h-4 text-[#1D64C9]" />
            </div>
            <h3 className="text-sm font-bold text-slate-800">Tamper-Proof Ledger</h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Modifications to paper documents will fail verification. The institutional snapshot remains immutable.
            </p>
          </div>

          <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs space-y-2">
            <div className="w-8 h-8 rounded-lg bg-[#16263B]/5 text-[#16263B] flex items-center justify-center font-bold text-xs">
              <Building2 className="w-4 h-4 text-[#1D64C9]" />
            </div>
            <h3 className="text-sm font-bold text-slate-800">Institutional Authority</h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Only certificates officially authorized and registered by school leadership are validated through this registry.
            </p>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-6 text-center text-xs text-slate-500 mt-auto">
        <div className="max-w-6xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div>
            &copy; {new Date().getFullYear()} Sygmate International Academy · All Rights Reserved.
          </div>
          <div className="text-[11px] text-slate-400">
            Official Academic Credential Registry · Complies with FERPA & Digital Trust Standards
          </div>
        </div>
      </footer>
    </div>
  );
};
