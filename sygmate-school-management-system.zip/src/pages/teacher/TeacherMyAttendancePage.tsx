import React, { useState, useEffect, useMemo } from 'react';
import {
  CalendarCheck,
  Calendar,
  Clock,
  CheckCircle2,
  XCircle,
  AlertCircle,
  ChevronLeft,
  ChevronRight,
  TrendingUp,
  User,
  Building,
  ShieldCheck,
  History,
  Info,
  CalendarDays,
  Sparkles,
  RefreshCw,
  Eye,
  X,
  Check,
  AlertTriangle,
  List,
  Grid,
  FileText
} from 'lucide-react';
import { api } from '../../services/api.js';
import { useAuth } from '../../context/AuthContext.js';
import { useSettings } from '../../context/SettingsContext.js';
import { TeacherLeaveManagementTab } from './TeacherLeaveManagementTab.js';
import {
  TeacherAttendanceRecord,
  TeacherAttendanceStatus,
  TeacherMyAttendanceResponse,
  TeacherMyAttendanceDay
} from '../../types/index.js';

interface TeacherMyAttendancePageProps {
  onNavigate?: (view: string) => void;
  activeTab?: 'attendance' | 'leaves';
  onTabChange?: (tab: 'attendance' | 'leaves') => void;
  hideTabBar?: boolean;
}

export const TeacherMyAttendancePage: React.FC<TeacherMyAttendancePageProps> = ({
  onNavigate,
  activeTab: propActiveTab,
  onTabChange,
  hideTabBar = true
}) => {
  const { user } = useAuth();
  const { settings, activeSession } = useSettings();

  // Top Tab: 'attendance' | 'leaves'
  const [internalTab, setInternalTab] = useState<'attendance' | 'leaves'>('attendance');
  const activeTab = propActiveTab || internalTab;
  const setActiveTab = (tab: 'attendance' | 'leaves') => {
    setInternalTab(tab);
    onTabChange?.(tab);
  };

  // Current Month & Year
  const [selectedYear, setSelectedYear] = useState<number>(() => new Date().getFullYear());
  const [selectedMonth, setSelectedMonth] = useState<number>(() => new Date().getMonth() + 1);

  // View Mode: 'calendar' | 'table'
  const [viewMode, setViewMode] = useState<'calendar' | 'table'>('calendar');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');

  // Attendance Data
  const [attendanceData, setAttendanceData] = useState<TeacherMyAttendanceResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [checkingIn, setCheckingIn] = useState(false);
  const [checkingOut, setCheckingOut] = useState(false);

  // Selected Day Details Modal
  const [selectedDayModal, setSelectedDayModal] = useState<TeacherMyAttendanceDay | null>(null);

  // Toast
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error' | 'warning'; message: string } | null>(null);

  // Live Clock
  const [currentTime, setCurrentTime] = useState<string>(() => new Date().toLocaleTimeString());
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date().toLocaleTimeString());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const showToast = (type: 'success' | 'error' | 'warning', message: string) => {
    setFeedback({ type, message });
    setTimeout(() => {
      setFeedback(null);
    }, 5000);
  };

  // Fetch Attendance
  const fetchMyAttendance = async () => {
    setLoading(true);
    try {
      const res = await api.getMyTeacherAttendance({
        year: selectedYear,
        month: selectedMonth
      });
      if (res && res.success) {
        setAttendanceData(res.data);
      }
    } catch (err: any) {
      showToast('error', err.message || 'Failed to load attendance records');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMyAttendance();
  }, [selectedYear, selectedMonth]);

  // Handle Self Check-In
  const handleCheckIn = async () => {
    setCheckingIn(true);
    try {
      const res = await api.teacherCheckIn();
      if (res && res.success) {
        showToast('success', res.message || 'Check-in recorded successfully!');
        await fetchMyAttendance();
      }
    } catch (err: any) {
      showToast('error', err.message || 'Check-in failed');
    } finally {
      setCheckingIn(false);
    }
  };

  // Handle Self Check-Out
  const handleCheckOut = async () => {
    setCheckingOut(true);
    try {
      const res = await api.teacherCheckOut();
      if (res && res.success) {
        showToast('success', res.message || 'Check-out recorded successfully!');
        await fetchMyAttendance();
      }
    } catch (err: any) {
      showToast('error', err.message || 'Check-out failed');
    } finally {
      setCheckingOut(false);
    }
  };

  // Month Navigation
  const handleNavigateMonth = (offset: number) => {
    let newM = selectedMonth + offset;
    let newY = selectedYear;
    if (newM > 12) {
      newM = 1;
      newY += 1;
    } else if (newM < 1) {
      newM = 12;
      newY -= 1;
    }
    setSelectedMonth(newM);
    setSelectedYear(newY);
  };

  const getStatusBadge = (status?: TeacherAttendanceStatus) => {
    switch (status) {
      case 'PRESENT':
        return <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 border border-emerald-300">Present</span>;
      case 'LATE':
        return <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-100 text-amber-800 border border-amber-300">Late</span>;
      case 'HALF_DAY':
        return <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-orange-100 text-orange-800 border border-orange-300">Half Day</span>;
      case 'LEAVE':
        return <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-100 text-blue-800 border border-blue-300">Approved Leave</span>;
      case 'EXCUSED':
        return <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-purple-100 text-purple-800 border border-purple-300">Excused</span>;
      case 'ABSENT':
        return <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-100 text-rose-800 border border-rose-300">Absent</span>;
      default:
        return <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-100 text-slate-600 border border-slate-300">Not Marked</span>;
    }
  };

  // Safely extract days array supporting both days and calendarDays
  const daysList: TeacherMyAttendanceDay[] = useMemo(() => {
    return attendanceData?.days || attendanceData?.calendarDays || [];
  }, [attendanceData]);

  // Safely extract summary / stats supporting both shapes
  const stats = useMemo(() => {
    const s = attendanceData?.stats;
    const sum = attendanceData?.summary;
    return {
      totalWorkingDays: s?.totalWorkingDays ?? sum?.totalWorkingDays ?? 0,
      presentCount: s?.presentCount ?? sum?.present ?? 0,
      lateCount: s?.lateCount ?? sum?.late ?? 0,
      halfDayCount: s?.halfDayCount ?? sum?.halfDay ?? 0,
      leaveCount: s?.leaveCount ?? sum?.leave ?? 0,
      excusedCount: s?.excusedCount ?? sum?.excused ?? 0,
      absentCount: s?.absentCount ?? sum?.absent ?? 0,
      attendanceRate: s?.attendanceRate ?? sum?.attendanceRate ?? 0
    };
  }, [attendanceData]);

  // Filtered List for Table View
  const filteredDays = useMemo(() => {
    if (!daysList || daysList.length === 0) return [];
    return daysList.filter((d) => {
      if (statusFilter !== 'ALL') {
        if (statusFilter === 'UNMARKED' && d.status) return false;
        if (statusFilter !== 'UNMARKED' && d.status !== statusFilter) return false;
      }
      return true;
    });
  }, [daysList, statusFilter]);

  // Today's Day item
  const todayDateStr = new Date().toISOString().split('T')[0];
  const todayRecord = daysList.find((d) => d.date === todayDateStr);

  // Pad start of calendar if first day is not Sunday
  const calendarPadDivs = useMemo(() => {
    const firstDayName = daysList[0]?.dayName || '';
    const dayMap: Record<string, number> = {
      Sunday: 0,
      Monday: 1,
      Tuesday: 2,
      Wednesday: 3,
      Thursday: 4,
      Friday: 5,
      Saturday: 6
    };
    const padCount = dayMap[firstDayName] || 0;
    return Array.from({ length: padCount }).map((_, idx) => (
      <div key={`pad-${idx}`} className="h-28 bg-slate-50/50 rounded-xl border border-slate-100 opacity-30" />
    ));
  }, [daysList]);

  return (
    <div className="space-y-6 pb-16">
      {/* Toast Feedback */}
      {feedback && (
        <div
          className={`fixed top-5 right-5 z-50 flex items-center gap-3 px-4 py-3 rounded-lg shadow-lg border text-sm transition-all duration-300 ${
            feedback.type === 'success'
              ? 'bg-emerald-50 text-emerald-900 border-emerald-300'
              : feedback.type === 'error'
              ? 'bg-rose-50 text-rose-900 border-rose-300'
              : 'bg-amber-50 text-amber-900 border-amber-300'
          }`}
        >
          {feedback.type === 'success' && <CheckCircle2 className="w-5 h-5 text-emerald-600 flex-shrink-0" />}
          {feedback.type === 'error' && <XCircle className="w-5 h-5 text-rose-600 flex-shrink-0" />}
          {feedback.type === 'warning' && <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0" />}
          <span className="font-medium">{feedback.message}</span>
        </div>
      )}

      {/* Header Profile & Clock Card */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-sm">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          {/* Teacher Profile Summary */}
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-full bg-indigo-100 text-indigo-800 font-bold text-xl flex items-center justify-center border-2 border-indigo-200 shadow-xs">
              {attendanceData?.teacher.avatarUrl ? (
                <img src={attendanceData.teacher.avatarUrl} alt="" className="w-full h-full rounded-full object-cover" />
              ) : (
                attendanceData?.teacher.name?.substring(0, 2).toUpperCase() || 'TC'
              )}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl font-bold text-slate-900">
                  {attendanceData?.teacher.name || user?.name || 'My Attendance'}
                </h1>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200">
                  {attendanceData?.teacher.designation || 'Faculty Member'}
                </span>
              </div>
              <p className="text-sm text-slate-500 font-medium mt-0.5">
                Code: <span className="font-mono text-slate-700 font-bold">{attendanceData?.teacher.employeeCode}</span> • Department: <span className="text-slate-700 font-bold">{attendanceData?.teacher.departmentName || 'Academics'}</span>
              </p>
            </div>
          </div>

          {/* Today Check-In / Clock Section */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 bg-slate-50 p-3.5 rounded-xl border border-slate-200">
            <div className="text-center sm:text-right sm:pr-3 sm:border-r border-slate-200">
              <div className="text-xs font-semibold text-slate-500 flex items-center justify-center sm:justify-end gap-1">
                <Clock className="w-3.5 h-3.5 text-indigo-600" />
                Live Time
              </div>
              <div className="text-lg font-mono font-bold text-slate-900 mt-0.5">{currentTime}</div>
              <div className="text-[10px] text-slate-500">{todayDateStr}</div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleCheckIn}
                disabled={checkingIn || !!todayRecord?.checkInTime}
                className={`flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-4 py-2 rounded-lg text-sm font-bold shadow-xs transition ${
                  todayRecord?.checkInTime
                    ? 'bg-emerald-50 text-emerald-800 border border-emerald-300 cursor-default'
                    : 'bg-emerald-600 hover:bg-emerald-700 text-white cursor-pointer'
                }`}
              >
                <CheckCircle2 className="w-4 h-4" />
                {todayRecord?.checkInTime ? `Checked In: ${todayRecord.checkInTime}` : checkingIn ? 'Checking In...' : 'Clock In'}
              </button>

              <button
                onClick={handleCheckOut}
                disabled={checkingOut || !todayRecord?.checkInTime || !!todayRecord?.checkOutTime}
                className={`flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-4 py-2 rounded-lg text-sm font-bold shadow-xs transition ${
                  todayRecord?.checkOutTime
                    ? 'bg-blue-50 text-blue-800 border border-blue-300 cursor-default'
                    : !todayRecord?.checkInTime
                    ? 'bg-slate-100 text-slate-400 border border-slate-200 cursor-not-allowed'
                    : 'bg-blue-600 hover:bg-blue-700 text-white cursor-pointer'
                }`}
              >
                <Clock className="w-4 h-4" />
                {todayRecord?.checkOutTime ? `Checked Out: ${todayRecord.checkOutTime}` : checkingOut ? 'Checking Out...' : 'Clock Out'}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      {!hideTabBar && (
        <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
          <button
            type="button"
            onClick={() => setActiveTab('attendance')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-bold transition ${
              activeTab === 'attendance'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <CalendarCheck className="w-4 h-4" />
            <span>My Attendance & Clock In</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('leaves')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-bold transition ${
              activeTab === 'leaves'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>Leave Applications & Quotas</span>
          </button>
        </div>
      )}

      {activeTab === 'leaves' ? (
        <TeacherLeaveManagementTab onLeaveUpdated={fetchMyAttendance} />
      ) : (
        <>
          {/* Monthly KPI Overview */}
      {attendanceData && (
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
          <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-sm text-center">
            <div className="text-xs font-semibold text-slate-500">Working Days</div>
            <div className="text-xl font-bold text-slate-900 mt-1">{stats.totalWorkingDays}</div>
          </div>
          <div className="bg-white p-3.5 rounded-xl border border-emerald-200 bg-emerald-50/20 shadow-sm text-center">
            <div className="text-xs font-semibold text-emerald-700">Present</div>
            <div className="text-xl font-bold text-emerald-800 mt-1">{stats.presentCount}</div>
          </div>
          <div className="bg-white p-3.5 rounded-xl border border-amber-200 bg-amber-50/20 shadow-sm text-center">
            <div className="text-xs font-semibold text-amber-700">Late</div>
            <div className="text-xl font-bold text-amber-800 mt-1">{stats.lateCount}</div>
          </div>
          <div className="bg-white p-3.5 rounded-xl border border-orange-200 bg-orange-50/20 shadow-sm text-center">
            <div className="text-xs font-semibold text-orange-700">Half Day</div>
            <div className="text-xl font-bold text-orange-800 mt-1">{stats.halfDayCount}</div>
          </div>
          <div className="bg-white p-3.5 rounded-xl border border-blue-200 bg-blue-50/20 shadow-sm text-center">
            <div className="text-xs font-semibold text-blue-700">Leave</div>
            <div className="text-xl font-bold text-blue-800 mt-1">{stats.leaveCount}</div>
          </div>
          <div className="bg-white p-3.5 rounded-xl border border-purple-200 bg-purple-50/20 shadow-sm text-center">
            <div className="text-xs font-semibold text-purple-700">Excused</div>
            <div className="text-xl font-bold text-purple-800 mt-1">{stats.excusedCount}</div>
          </div>
          <div className="bg-white p-3.5 rounded-xl border border-rose-200 bg-rose-50/20 shadow-sm text-center">
            <div className="text-xs font-semibold text-rose-700">Absent</div>
            <div className="text-xl font-bold text-rose-800 mt-1">{stats.absentCount}</div>
          </div>
          <div className="bg-indigo-600 p-3.5 rounded-xl text-white shadow-sm text-center">
            <div className="text-xs font-semibold text-indigo-100">Rate</div>
            <div className="text-xl font-bold text-white mt-1">{stats.attendanceRate}%</div>
          </div>
        </div>
      )}

      {/* Month Navigation & View Mode Controls */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-col md:flex-row items-center justify-between gap-4">
        {/* Month Navigation */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => handleNavigateMonth(-1)}
            className="p-2 border border-slate-200 rounded-lg hover:bg-slate-50 text-slate-700 transition"
            title="Previous Month"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          <div className="flex items-center gap-2 bg-slate-50 border border-slate-300 px-3 py-1.5 rounded-lg">
            <CalendarDays className="w-4 h-4 text-indigo-600" />
            <select
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(parseInt(e.target.value, 10))}
              className="bg-transparent text-sm font-bold text-slate-800 outline-none cursor-pointer"
            >
              {[
                'January', 'February', 'March', 'April', 'May', 'June',
                'July', 'August', 'September', 'October', 'November', 'December'
              ].map((mName, idx) => (
                <option key={mName} value={idx + 1}>
                  {mName}
                </option>
              ))}
            </select>
            <select
              value={selectedYear}
              onChange={(e) => setSelectedYear(parseInt(e.target.value, 10))}
              className="bg-transparent text-sm font-bold text-slate-800 outline-none cursor-pointer"
            >
              {[2024, 2025, 2026, 2027, 2028].map((y) => (
                <option key={y} value={y}>
                  {y}
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={() => handleNavigateMonth(1)}
            className="p-2 border border-slate-200 rounded-lg hover:bg-slate-50 text-slate-700 transition"
            title="Next Month"
          >
            <ChevronRight className="w-4 h-4" />
          </button>

          <button
            onClick={() => {
              const d = new Date();
              setSelectedMonth(d.getMonth() + 1);
              setSelectedYear(d.getFullYear());
            }}
            className="px-3 py-1.5 text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg transition"
          >
            Current Month
          </button>
        </div>

        {/* View Mode Toggle & Status Filter */}
        <div className="flex items-center gap-3">
          {viewMode === 'table' && (
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="text-xs bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 font-medium text-slate-700 outline-none"
            >
              <option value="ALL">All Statuses</option>
              <option value="PRESENT">Present</option>
              <option value="LATE">Late</option>
              <option value="HALF_DAY">Half Day</option>
              <option value="LEAVE">Leave</option>
              <option value="EXCUSED">Excused</option>
              <option value="ABSENT">Absent</option>
            </select>
          )}

          <div className="inline-flex rounded-lg border border-slate-200 p-0.5 bg-slate-100">
            <button
              onClick={() => setViewMode('calendar')}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-md transition ${
                viewMode === 'calendar'
                  ? 'bg-white text-indigo-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Grid className="w-3.5 h-3.5" />
              Calendar View
            </button>
            <button
              onClick={() => setViewMode('table')}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-md transition ${
                viewMode === 'table'
                  ? 'bg-white text-indigo-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <List className="w-3.5 h-3.5" />
              List View
            </button>
          </div>

          <button
            onClick={fetchMyAttendance}
            className="p-2 border border-slate-200 rounded-lg hover:bg-slate-50 text-slate-700 transition"
            title="Refresh Attendance"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-indigo-600' : ''}`} />
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 1. CALENDAR VIEW */}
      {/* ========================================================================= */}
      {viewMode === 'calendar' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-5 space-y-4">
          {/* Day of week headers */}
          <div className="grid grid-cols-7 gap-2 text-center text-xs font-bold text-slate-500 uppercase tracking-wider py-2 border-b border-slate-200">
            <div>Sun</div>
            <div>Mon</div>
            <div>Tue</div>
            <div>Wed</div>
            <div>Thu</div>
            <div>Fri</div>
            <div>Sat</div>
          </div>

          {/* Calendar Grid */}
          {loading ? (
            <div className="py-20 text-center text-slate-500">
              <RefreshCw className="w-6 h-6 animate-spin mx-auto text-indigo-600 mb-2" />
              Loading calendar entries...
            </div>
          ) : daysList.length === 0 ? (
            <div className="py-20 text-center text-slate-500">No attendance data available.</div>
          ) : (
            <div className="grid grid-cols-7 gap-2">
              {/* Pad start of calendar if first day is not Sunday */}
              {calendarPadDivs}

              {/* Day Tiles */}
              {daysList.map((dayItem) => {
                const isToday = dayItem.date === todayDateStr;
                const isNonWorking = !dayItem.isWorkingDay;

                let cardBg = 'bg-white';
                let borderCol = 'border-slate-200';

                if (dayItem.status === 'PRESENT') {
                  cardBg = 'bg-emerald-50/30';
                  borderCol = 'border-emerald-200';
                } else if (dayItem.status === 'LATE') {
                  cardBg = 'bg-amber-50/30';
                  borderCol = 'border-amber-200';
                } else if (dayItem.status === 'HALF_DAY') {
                  cardBg = 'bg-orange-50/30';
                  borderCol = 'border-orange-200';
                } else if (dayItem.status === 'LEAVE') {
                  cardBg = 'bg-blue-50/30';
                  borderCol = 'border-blue-200';
                } else if (dayItem.status === 'ABSENT') {
                  cardBg = 'bg-rose-50/30';
                  borderCol = 'border-rose-200';
                } else if (isNonWorking) {
                  cardBg = 'bg-slate-50';
                  borderCol = 'border-slate-200';
                }

                return (
                  <div
                    key={dayItem.date}
                    onClick={() => setSelectedDayModal(dayItem)}
                    className={`h-28 p-2.5 rounded-xl border ${borderCol} ${cardBg} flex flex-col justify-between cursor-pointer hover:shadow-md hover:border-indigo-400 transition-all ${
                      isToday ? 'ring-2 ring-indigo-600' : ''
                    }`}
                  >
                    {/* Top Row: Date & Day Type Badge */}
                    <div className="flex items-center justify-between">
                      <span className={`text-sm font-bold ${isToday ? 'text-indigo-600 font-extrabold' : 'text-slate-800'}`}>
                        {dayItem.dayOfMonth}
                      </span>
                      {isNonWorking && (
                        <span className="text-[9px] font-bold text-slate-500 bg-slate-200/70 px-1 rounded">
                          {dayItem.dayType === 'WEEKEND' ? 'Weekend' : 'Holiday'}
                        </span>
                      )}
                    </div>

                    {/* Middle: Attendance Status */}
                    <div>
                      {dayItem.status ? (
                        getStatusBadge(dayItem.status)
                      ) : isNonWorking ? (
                        <span className="text-[10px] text-slate-400 font-medium">{dayItem.reason || dayItem.dayType}</span>
                      ) : (
                        <span className="text-[10px] text-slate-400 font-medium">Unmarked</span>
                      )}
                    </div>

                    {/* Bottom: Check-In/Out times */}
                    <div className="text-[10px] font-mono text-slate-600 flex items-center justify-between">
                      <span>{dayItem.checkInTime || '--:--'}</span>
                      <span className="text-slate-400">→</span>
                      <span>{dayItem.checkOutTime || '--:--'}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* 2. LIST / TABLE VIEW */}
      {/* ========================================================================= */}
      {viewMode === 'table' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-xs font-bold text-slate-600 uppercase tracking-wider">
                  <th className="py-3.5 px-4">Date</th>
                  <th className="py-3.5 px-4">Day Type</th>
                  <th className="py-3.5 px-4">Attendance Status</th>
                  <th className="py-3.5 px-4">Check-In</th>
                  <th className="py-3.5 px-4">Check-Out</th>
                  <th className="py-3.5 px-4">Remarks / Overrides</th>
                  <th className="py-3.5 px-4 text-right">Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 text-sm">
                {loading ? (
                  <tr>
                    <td colSpan={7} className="py-12 text-center text-slate-500">
                      <RefreshCw className="w-6 h-6 animate-spin mx-auto text-indigo-600 mb-2" />
                      Loading attendance table...
                    </td>
                  </tr>
                ) : filteredDays.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-12 text-center text-slate-500">
                      No days matching selected status filter.
                    </td>
                  </tr>
                ) : (
                  filteredDays.map((dayItem) => (
                    <tr key={dayItem.date} className="hover:bg-slate-50 transition">
                      <td className="py-3 px-4 font-bold text-slate-800 font-mono">
                        {dayItem.date} ({dayItem.dayName})
                      </td>
                      <td className="py-3 px-4 text-xs">
                        {dayItem.isWorkingDay ? (
                          <span className="text-emerald-700 font-semibold">Working Day</span>
                        ) : (
                          <span className="text-slate-500 font-medium">
                            {dayItem.dayType === 'WEEKEND' ? 'Weekend' : `Holiday: ${dayItem.reason || ''}`}
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-4">{getStatusBadge(dayItem.status)}</td>
                      <td className="py-3 px-4 text-xs font-mono text-slate-700">
                        {dayItem.checkInTime || '--:--'}
                      </td>
                      <td className="py-3 px-4 text-xs font-mono text-slate-700">
                        {dayItem.checkOutTime || '--:--'}
                      </td>
                      <td className="py-3 px-4 text-xs text-slate-600">
                        <div>{dayItem.remarks || '-'}</div>
                        {dayItem.isOverridden && (
                          <span className="text-[10px] font-bold text-amber-800 bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200">
                            Admin Override
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <button
                          onClick={() => setSelectedDayModal(dayItem)}
                          className="px-2.5 py-1 text-xs font-semibold text-indigo-600 hover:bg-indigo-50 rounded transition"
                        >
                          View
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* School Attendance Policies Card */}
      <div className="bg-slate-50 p-5 rounded-xl border border-slate-200 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4 text-sm text-slate-600">
        <div className="flex items-start gap-3">
          <Info className="w-5 h-5 text-indigo-600 flex-shrink-0 mt-0.5" />
          <div className="space-y-1">
            <h4 className="font-bold text-slate-900">Faculty Attendance Policies & Correction Protocol</h4>
            <p className="text-xs text-slate-500">
              Standard working hours are 08:00 AM to 04:00 PM. Check-ins after 08:15 AM are categorized as Late. If you notice any discrepancy in your biometric/manual attendance log, please contact your Department Head or School Administration. All corrections are logged in an immutable audit trail.
            </p>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* MODAL: DAY DETAILS MODAL */}
      {/* ========================================================================= */}
      {selectedDayModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4 backdrop-blur-xs">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-md w-full overflow-hidden animate-in fade-in zoom-in duration-200">
            <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2">
                <CalendarCheck className="w-5 h-5 text-indigo-600" />
                <h3 className="text-lg font-bold text-slate-900">Attendance Details</h3>
              </div>
              <button
                onClick={() => setSelectedDayModal(null)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4 text-sm">
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between">
                <div>
                  <div className="font-bold text-slate-900 text-base">{selectedDayModal.date}</div>
                  <div className="text-xs text-slate-500">{selectedDayModal.dayName}</div>
                </div>
                <div>{getStatusBadge(selectedDayModal.status)}</div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                  <div className="text-xs font-semibold text-slate-500">Check-In Time</div>
                  <div className="text-base font-mono font-bold text-slate-800 mt-1">
                    {selectedDayModal.checkInTime || 'Not Recorded'}
                  </div>
                </div>
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                  <div className="text-xs font-semibold text-slate-500">Check-Out Time</div>
                  <div className="text-base font-mono font-bold text-slate-800 mt-1">
                    {selectedDayModal.checkOutTime || 'Not Recorded'}
                  </div>
                </div>
              </div>

              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-1">
                <div className="text-xs font-semibold text-slate-500">Day Designation</div>
                <div className="text-sm font-bold text-slate-800">
                  {selectedDayModal.isWorkingDay ? 'Regular Working Day' : `${selectedDayModal.dayType}: ${selectedDayModal.reason || ''}`}
                </div>
              </div>

              {selectedDayModal.remarks && (
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-1">
                  <div className="text-xs font-semibold text-slate-500">Remarks</div>
                  <div className="text-sm text-slate-700">{selectedDayModal.remarks}</div>
                </div>
              )}

              {((selectedDayModal?.history?.length || 0) > 0) && (
                <div className="p-3 bg-indigo-50/50 border border-indigo-200 rounded-lg space-y-2">
                  <div className="text-xs font-bold text-indigo-900 flex items-center gap-1.5">
                    <History className="w-3.5 h-3.5 text-indigo-600" />
                    Admin Correction History ({selectedDayModal?.history?.length || 0})
                  </div>
                  {(selectedDayModal?.history || []).map((h, i) => (
                    <div key={i} className="text-xs text-slate-700 border-t border-indigo-100 pt-1.5">
                      <div className="font-semibold text-slate-800">
                        {h.fromStatus} → {h.toStatus} (by {h.correctedByUserName})
                      </div>
                      <div className="text-[11px] text-slate-600 italic">Reason: {h.reason}</div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-end">
              <button
                type="button"
                onClick={() => setSelectedDayModal(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white text-sm font-semibold rounded-lg"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
        </>
      )}
    </div>
  );
};
export default TeacherMyAttendancePage;
