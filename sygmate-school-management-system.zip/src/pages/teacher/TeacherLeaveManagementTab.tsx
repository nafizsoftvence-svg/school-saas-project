import React, { useState, useEffect, useMemo } from 'react';
import {
  Calendar,
  Clock,
  CheckCircle2,
  XCircle,
  AlertCircle,
  FileText,
  Plus,
  Filter,
  Search,
  RefreshCw,
  Eye,
  X,
  Check,
  AlertTriangle,
  Paperclip,
  Trash2,
  CalendarDays,
  Info,
  Building,
  UserCheck,
  Send,
  Save,
  RotateCcw
} from 'lucide-react';
import { api } from '../../services/api.js';
import { useAuth } from '../../context/AuthContext.js';
import { useSettings } from '../../context/SettingsContext.js';
import { Badge } from '../../components/ui/Badge.js';
import { Modal } from '../../components/ui/Modal.js';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner.js';
import { LeaveType, LeaveApplication, LeaveStatus } from '../../types/index.js';

interface TeacherLeaveManagementTabProps {
  onLeaveUpdated?: () => void;
}

export const TeacherLeaveManagementTab: React.FC<TeacherLeaveManagementTabProps> = ({ onLeaveUpdated }) => {
  const { user } = useAuth();
  const { activeSession } = useSettings();

  const [loading, setLoading] = useState(false);
  const [leaveTypes, setLeaveTypes] = useState<LeaveType[]>([]);
  const [applications, setApplications] = useState<LeaveApplication[]>([]);
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  // Toast / feedback message
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error' | 'warning'; message: string } | null>(null);

  // Apply Modal state
  const [isApplyModalOpen, setIsApplyModalOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [leaveTypeId, setLeaveTypeId] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [reason, setReason] = useState('');
  const [description, setDescription] = useState('');
  const [remarks, setRemarks] = useState('');
  const [attachmentUrl, setAttachmentUrl] = useState('');
  const [attachmentName, setAttachmentName] = useState('');

  // Live Working Days Calculation Preview
  const [calculatingDays, setCalculatingDays] = useState(false);
  const [workingBreakdown, setWorkingBreakdown] = useState<{
    startDate: string;
    endDate: string;
    totalCalendarDays: number;
    totalWorkingLeaveDays: number;
    workingDates: string[];
    nonWorkingDates: { date: string; dayType: string; reason: string }[];
  } | null>(null);

  // Detail Modal state
  const [selectedApp, setSelectedApp] = useState<LeaveApplication | null>(null);
  const [detailModalOpen, setDetailModalOpen] = useState(false);
  const [detailLoading, setDetailLoading] = useState(false);
  const [selectedAppBreakdown, setSelectedAppBreakdown] = useState<any>(null);

  // Cancel Modal state
  const [cancelModalOpen, setCancelModalOpen] = useState(false);
  const [cancellingApp, setCancellingApp] = useState<LeaveApplication | null>(null);
  const [cancelReason, setCancelReason] = useState('');
  const [cancelling, setCancelling] = useState(false);

  const showToast = (type: 'success' | 'error' | 'warning', message: string) => {
    setFeedback({ type, message });
    setTimeout(() => {
      setFeedback(null);
    }, 5000);
  };

  // Load Leave Types & Applications
  const fetchData = async () => {
    setLoading(true);
    try {
      const [typesRes, appsRes] = await Promise.all([
        api.getLeaveTypes({ applicableTo: 'TEACHER' }),
        api.getLeaveApplications({ applicantType: 'TEACHER' })
      ]);

      const types = Array.isArray(typesRes?.data)
        ? typesRes.data
        : Array.isArray(typesRes)
        ? typesRes
        : [];
      setLeaveTypes(types);
      if (types.length > 0 && !leaveTypeId) {
        setLeaveTypeId(types?.[0]?.id || '');
      }

      const apps = Array.isArray(appsRes?.data)
        ? appsRes.data
        : Array.isArray(appsRes)
        ? appsRes
        : [];
      setApplications(apps);
    } catch (err: any) {
      showToast('error', err.message || 'Failed to load leave records');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // Recalculate working days whenever startDate or endDate changes in Apply modal
  useEffect(() => {
    if (!startDate) {
      setWorkingBreakdown(null);
      return;
    }
    const end = endDate || startDate;
    if (startDate > end) {
      setWorkingBreakdown(null);
      return;
    }

    let isMounted = true;
    const calcDays = async () => {
      setCalculatingDays(true);
      try {
        const res = await api.calculateLeaveWorkingDays({
          startDate,
          endDate: end,
          academicSessionId: activeSession?.id
        });
        if (isMounted && res && res.success && res.data) {
          setWorkingBreakdown(res.data);
        }
      } catch (e) {
        // fail gracefully
      } finally {
        if (isMounted) setCalculatingDays(false);
      }
    };

    const timer = setTimeout(calcDays, 300);
    return () => {
      isMounted = false;
      clearTimeout(timer);
    };
  }, [startDate, endDate, activeSession?.id]);

  const selectedLeaveTypeObj = useMemo(() => {
    return (leaveTypes || []).find((lt) => lt?.id === leaveTypeId);
  }, [leaveTypes, leaveTypeId]);

  const handleOpenApplyModal = () => {
    const today = new Date().toISOString().split('T')[0];
    setStartDate(today);
    setEndDate(today);
    setReason('');
    setDescription('');
    setRemarks('');
    setAttachmentUrl('');
    setAttachmentName('');
    if (leaveTypes && leaveTypes.length > 0) {
      setLeaveTypeId(leaveTypes?.[0]?.id || '');
    }
    setIsApplyModalOpen(true);
  };

  const handleSubmitLeave = async (mode: 'DRAFT' | 'SUBMITTED') => {
    if (!startDate) {
      showToast('error', 'Please choose a start date');
      return;
    }
    const end = endDate || startDate;
    if (startDate > end) {
      showToast('error', 'Start date cannot be after end date');
      return;
    }
    if (!reason.trim()) {
      showToast('error', 'Please provide a reason / title for your absence');
      return;
    }

    // Attachment check if required by leave type
    if (mode === 'SUBMITTED' && selectedLeaveTypeObj?.requiresAttachment && !attachmentUrl) {
      showToast('error', `Documentation attachment is mandatory for ${selectedLeaveTypeObj.name}`);
      return;
    }

    if (workingBreakdown && workingBreakdown.totalWorkingLeaveDays === 0 && mode === 'SUBMITTED') {
      showToast('warning', 'The selected range contains only weekends or holidays. No working days will be deducted.');
    }

    setSubmitting(true);
    try {
      const res = await api.submitTeacherLeave({
        leaveTypeId,
        startDate,
        endDate: end,
        reason: reason.trim(),
        description: description.trim(),
        remarks: remarks.trim(),
        attachmentUrl: attachmentUrl.trim() || undefined,
        attachmentName: attachmentName.trim() || (attachmentUrl ? 'Leave_Documentation.pdf' : undefined),
        status: mode
      });

      if (res && res.success) {
        showToast('success', res.message || `Leave application ${mode === 'DRAFT' ? 'saved as draft' : 'submitted successfully'}!`);
        setIsApplyModalOpen(false);
        await fetchData();
        if (onLeaveUpdated) onLeaveUpdated();
      } else {
        showToast('error', res.error || 'Failed to submit leave application');
      }
    } catch (err: any) {
      showToast('error', err.message || 'Submission failed');
    } finally {
      setSubmitting(false);
    }
  };

  const handleOpenDetails = async (app: LeaveApplication) => {
    setSelectedApp(app);
    setDetailModalOpen(true);
    setDetailLoading(true);
    try {
      const res = await api.getLeaveApplicationDetail(app.id);
      if (res && res.success && res.data) {
        setSelectedApp(res.data);
        setSelectedAppBreakdown(res.data.workingBreakdown || null);
      }
    } catch (e) {
      // ignore
    } finally {
      setDetailLoading(false);
    }
  };

  const handleOpenCancelModal = (app: LeaveApplication) => {
    setCancellingApp(app);
    setCancelReason('');
    setCancelModalOpen(true);
  };

  const handleConfirmCancel = async () => {
    if (!cancellingApp) return;
    setCancelling(true);
    try {
      const res = await api.cancelLeaveApplication(cancellingApp.id, cancelReason.trim());
      if (res && res.success) {
        showToast('success', res.message || 'Leave application cancelled successfully');
        setCancelModalOpen(false);
        setCancellingApp(null);
        await fetchData();
        if (onLeaveUpdated) onLeaveUpdated();
      } else {
        showToast('error', res.error || 'Failed to cancel application');
      }
    } catch (err: any) {
      showToast('error', err.message || 'Cancellation failed');
    } finally {
      setCancelling(false);
    }
  };

  // Filtered Applications
  const filteredApplications = useMemo(() => {
    return applications.filter((app) => {
      if (statusFilter !== 'ALL') {
        if (statusFilter === 'PENDING' && (app.status !== 'SUBMITTED' && app.status !== 'PENDING')) return false;
        if (statusFilter !== 'PENDING' && app.status !== statusFilter) return false;
      }
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchReason = app.reason?.toLowerCase().includes(q);
        const matchType = app.leaveTypeName?.toLowerCase().includes(q);
        const matchDesc = app.description?.toLowerCase().includes(q);
        const matchDate = (app.startDate || app.leaveDate || '').includes(q);
        if (!matchReason && !matchType && !matchDesc && !matchDate) return false;
      }
      return true;
    });
  }, [applications, statusFilter, searchQuery]);

  // Status Badge Helper
  const getStatusBadge = (status: LeaveStatus) => {
    switch (status) {
      case 'DRAFT':
        return <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-100 text-slate-700 border border-slate-300">Draft</span>;
      case 'SUBMITTED':
      case 'PENDING':
        return <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-100 text-blue-800 border border-blue-300">Submitted</span>;
      case 'UNDER_REVIEW':
        return <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-100 text-amber-800 border border-amber-300">Under Review</span>;
      case 'APPROVED':
        return <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 border border-emerald-300">Approved</span>;
      case 'REJECTED':
        return <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-100 text-rose-800 border border-rose-300">Rejected</span>;
      case 'CANCELLED':
        return <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-200 text-slate-600 border border-slate-400">Cancelled</span>;
      default:
        return <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-100 text-slate-700">{status}</span>;
    }
  };

  // Metrics calculation
  const metrics = useMemo(() => {
    const total = applications.length;
    const approved = applications.filter((a) => a.status === 'APPROVED').length;
    const pending = applications.filter((a) => a.status === 'SUBMITTED' || a.status === 'PENDING' || a.status === 'UNDER_REVIEW').length;
    const rejected = applications.filter((a) => a.status === 'REJECTED').length;
    return { total, approved, pending, rejected };
  }, [applications]);

  return (
    <div className="space-y-6">
      {/* Toast Feedback */}
      {feedback && (
        <div
          className={`flex items-center gap-3 px-4 py-3 rounded-lg border text-sm transition-all duration-300 ${
            feedback.type === 'success'
              ? 'bg-emerald-50 text-emerald-900 border-emerald-300'
              : feedback.type === 'error'
              ? 'bg-rose-50 text-rose-900 border-rose-300'
              : 'bg-amber-50 text-amber-900 border-amber-300'
          }`}
        >
          {feedback.type === 'success' && <CheckCircle2 className="w-5 h-5 text-emerald-600 flex-shrink-0" />}
          {feedback.type === 'error' && <XCircle className="w-5 h-5 text-rose-600 flex-shrink-0" />}
          {feedback.type === 'warning' && <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0" />}
          <div className="flex-1 font-medium">{feedback.message}</div>
          <button onClick={() => setFeedback(null)} className="text-slate-400 hover:text-slate-600">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Top Metrics & Action Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium uppercase tracking-wider mb-1">
            <span>Total Requests</span>
            <FileText className="w-4 h-4 text-slate-400" />
          </div>
          <div className="text-2xl font-bold text-slate-800">{metrics.total}</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-emerald-200 shadow-sm bg-emerald-50/20">
          <div className="flex items-center justify-between text-emerald-700 text-xs font-medium uppercase tracking-wider mb-1">
            <span>Approved Leaves</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="text-2xl font-bold text-emerald-700">{metrics.approved}</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-blue-200 shadow-sm bg-blue-50/20">
          <div className="flex items-center justify-between text-blue-700 text-xs font-medium uppercase tracking-wider mb-1">
            <span>Under Review / Pending</span>
            <Clock className="w-4 h-4 text-blue-500" />
          </div>
          <div className="text-2xl font-bold text-blue-700">{metrics.pending}</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-rose-200 shadow-sm bg-rose-50/20">
          <div className="flex items-center justify-between text-rose-700 text-xs font-medium uppercase tracking-wider mb-1">
            <span>Rejected</span>
            <XCircle className="w-4 h-4 text-rose-500" />
          </div>
          <div className="text-2xl font-bold text-rose-700">{metrics.rejected}</div>
        </div>
      </div>

      {/* Filters and Search Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3 flex-1">
          <div className="relative flex-1 min-w-[200px] max-w-sm">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search reason or dates..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            />
          </div>

          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg text-xs font-medium text-slate-600">
            {['ALL', 'SUBMITTED', 'UNDER_REVIEW', 'APPROVED', 'REJECTED', 'CANCELLED'].map((st) => (
              <button
                key={st}
                onClick={() => setStatusFilter(st)}
                className={`px-3 py-1 rounded-md transition-colors ${
                  statusFilter === st ? 'bg-white text-indigo-700 shadow-sm font-semibold' : 'hover:text-slate-900'
                }`}
              >
                {st === 'ALL' ? 'All' : (st || '').replace(/_/g, ' ')}
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={fetchData}
            disabled={loading}
            className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition border border-slate-200"
            title="Refresh"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
          <button
            onClick={handleOpenApplyModal}
            className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium rounded-lg shadow-sm transition"
          >
            <Plus className="w-4 h-4" />
            <span>Apply for Leave</span>
          </button>
        </div>
      </div>

      {/* Applications Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        {loading ? (
          <div className="p-12 text-center">
            <LoadingSpinner message="Loading leave applications..." />
          </div>
        ) : filteredApplications.length === 0 ? (
          <div className="p-12 text-center text-slate-500">
            <FileText className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <h4 className="text-base font-semibold text-slate-700">No Leave Applications Found</h4>
            <p className="text-sm text-slate-500 mt-1">
              {statusFilter !== 'ALL' || searchQuery
                ? 'Try adjusting your filters or search criteria.'
                : 'You have not submitted any leave applications yet.'}
            </p>
            <button
              onClick={handleOpenApplyModal}
              className="mt-4 inline-flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white text-xs font-semibold rounded-lg hover:bg-indigo-700 transition"
            >
              <Plus className="w-4 h-4" />
              Apply for Leave Now
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-slate-600">
              <thead className="bg-slate-50 text-slate-700 text-xs font-semibold uppercase tracking-wider border-b border-slate-200">
                <tr>
                  <th className="px-5 py-3.5">Leave Type</th>
                  <th className="px-5 py-3.5">Dates / Period</th>
                  <th className="px-5 py-3.5 text-center">Working Days</th>
                  <th className="px-5 py-3.5">Reason & Purpose</th>
                  <th className="px-5 py-3.5 text-center">Status</th>
                  <th className="px-5 py-3.5">Submission Date</th>
                  <th className="px-5 py-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredApplications.map((app) => {
                  const isPendingOrDraft = ['DRAFT', 'SUBMITTED', 'PENDING', 'UNDER_REVIEW'].includes(app.status);
                  const isApproved = app.status === 'APPROVED';
                  const isCancelable = isPendingOrDraft || isApproved;

                  return (
                    <tr key={app.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="px-5 py-4 font-medium text-slate-900">
                        <div className="flex items-center gap-2">
                          <span className="w-2.5 h-2.5 rounded-full bg-indigo-500 flex-shrink-0" />
                          <span>{app.leaveTypeName || 'Leave'}</span>
                        </div>
                      </td>
                      <td className="px-5 py-4 whitespace-nowrap">
                        <div className="font-semibold text-slate-800">
                          {app.startDate || app.leaveDate}
                          {app.endDate && app.endDate !== (app.startDate || app.leaveDate) && (
                            <span className="text-slate-500 font-normal"> to {app.endDate}</span>
                          )}
                        </div>
                      </td>
                      <td className="px-5 py-4 text-center whitespace-nowrap">
                        <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-bold bg-slate-100 text-slate-800">
                          {app.totalDays} {app.totalDays === 1 ? 'day' : 'days'}
                        </span>
                      </td>
                      <td className="px-5 py-4 max-w-xs truncate" title={app.description || app.reason}>
                        <div className="font-medium text-slate-800 truncate">{app.reason}</div>
                        {app.description && <div className="text-xs text-slate-400 truncate">{app.description}</div>}
                      </td>
                      <td className="px-5 py-4 text-center whitespace-nowrap">
                        {getStatusBadge(app.status)}
                      </td>
                      <td className="px-5 py-4 text-xs text-slate-500 whitespace-nowrap">
                        {app.submissionDate || app.createdAt.split('T')[0]}
                      </td>
                      <td className="px-5 py-4 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => handleOpenDetails(app)}
                            className="p-1.5 text-slate-500 hover:text-indigo-600 hover:bg-slate-100 rounded-lg transition"
                            title="View Breakdown & Details"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                          {isCancelable && (
                            <button
                              onClick={() => handleOpenCancelModal(app)}
                              className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition"
                              title="Cancel Application"
                            >
                              <RotateCcw className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* ========================================================================= */}
      {/* 1. APPLY FOR LEAVE MODAL                                                  */}
      {/* ========================================================================= */}
      <Modal
        isOpen={isApplyModalOpen}
        onClose={() => setIsApplyModalOpen(false)}
        title="Apply for Teacher Leave"
        size="lg"
      >
        <div className="space-y-5">
          {/* Leave Type Selector */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
              Leave Category *
            </label>
            <select
              value={leaveTypeId}
              onChange={(e) => setLeaveTypeId(e.target.value)}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none"
            >
              {leaveTypes.map((lt) => (
                <option key={lt.id} value={lt.id}>
                  {lt.name} (Max {lt.maxDaysPerYear} days/yr){lt.requiresAttachment ? ' • Requires Attachment' : ''}
                </option>
              ))}
            </select>
            {selectedLeaveTypeObj && (
              <p className="text-xs text-slate-500 mt-1">
                {selectedLeaveTypeObj.description || 'Standard institutional leave policy.'}
                {selectedLeaveTypeObj.requiresAttachment && (
                  <span className="text-rose-600 font-semibold ml-1.5">
                    (Official certificate or document upload is required).
                  </span>
                )}
              </p>
            )}
          </div>

          {/* Date Pickers */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                Start Date *
              </label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                End Date (Leave blank for single day)
              </label>
              <input
                type="date"
                value={endDate}
                min={startDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Working Days Calculation Preview Banner */}
          {startDate && (
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-700 uppercase tracking-wider">
                  <CalendarDays className="w-4 h-4 text-indigo-600" />
                  <span>Working Days Calculation Preview</span>
                </div>
                {calculatingDays ? (
                  <span className="text-xs text-slate-400 animate-pulse">Calculating...</span>
                ) : (
                  <span className="text-xs font-bold text-indigo-700">
                    {workingBreakdown?.totalWorkingLeaveDays ?? 0} Working Days / {workingBreakdown?.totalCalendarDays ?? 0} Calendar Days
                  </span>
                )}
              </div>

              {((workingBreakdown?.nonWorkingDates?.length || 0) > 0) && (
                <div className="mt-2 text-xs text-amber-800 bg-amber-50 p-2.5 rounded-lg border border-amber-200 space-y-1">
                  <div className="font-semibold flex items-center gap-1.5">
                    <Info className="w-3.5 h-3.5 text-amber-600 flex-shrink-0" />
                    <span>Non-working days excluded from deduction:</span>
                  </div>
                  <ul className="list-disc list-inside space-y-0.5 text-slate-600 pl-1">
                    {workingBreakdown.nonWorkingDates.map((nwd) => (
                      <li key={nwd.date}>
                        <strong className="text-slate-800">{nwd.date}</strong>: {nwd.reason || nwd.dayType}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}

          {/* Reason */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
              Reason / Purpose *
            </label>
            <input
              type="text"
              placeholder="e.g. Acute viral fever, Family emergency, Professional training"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none"
            />
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
              Detailed Explanation
            </label>
            <textarea
              rows={3}
              placeholder="Provide context or classroom handover arrangements if applicable..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none"
            />
          </div>

          {/* Attachment Link / Documentation */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
              Documentation / Attachment {selectedLeaveTypeObj?.requiresAttachment && <span className="text-rose-600">*</span>}
            </label>
            <div className="flex items-center gap-2">
              <input
                type="text"
                placeholder="Paste document URL or file link (e.g. https://.../medical_slip.pdf)"
                value={attachmentUrl}
                onChange={(e) => {
                  setAttachmentUrl(e.target.value);
                  if (e.target.value && !attachmentName) {
                    setAttachmentName('Medical_or_Official_Document.pdf');
                  }
                }}
                className="flex-1 px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none"
              />
              <button
                type="button"
                onClick={() => {
                  setAttachmentUrl('https://example.com/uploads/leave_cert_sample.pdf');
                  setAttachmentName('Official_Leave_Documentation.pdf');
                }}
                className="px-3 py-2 text-xs bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium rounded-lg transition whitespace-nowrap"
              >
                Simulate File
              </button>
            </div>
            {attachmentUrl && (
              <p className="text-xs text-emerald-600 mt-1 flex items-center gap-1">
                <Paperclip className="w-3.5 h-3.5" />
                Attached: {attachmentName || 'Documentation'}
              </p>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-between pt-4 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setIsApplyModalOpen(false)}
              className="px-4 py-2 text-sm text-slate-600 hover:text-slate-800 font-medium rounded-lg hover:bg-slate-100 transition"
            >
              Cancel
            </button>
            <div className="flex items-center gap-3">
              <button
                type="button"
                disabled={submitting}
                onClick={() => handleSubmitLeave('DRAFT')}
                className="px-4 py-2 text-sm bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium rounded-lg transition inline-flex items-center gap-2"
              >
                <Save className="w-4 h-4" />
                Save as Draft
              </button>
              <button
                type="button"
                disabled={submitting}
                onClick={() => handleSubmitLeave('SUBMITTED')}
                className="px-4 py-2 text-sm bg-indigo-600 hover:bg-indigo-700 text-white font-medium rounded-lg shadow-sm transition inline-flex items-center gap-2"
              >
                <Send className="w-4 h-4" />
                {submitting ? 'Submitting...' : 'Submit Application'}
              </button>
            </div>
          </div>
        </div>
      </Modal>

      {/* ========================================================================= */}
      {/* 2. LEAVE DETAILS & AUDIT BREAKDOWN MODAL                                  */}
      {/* ========================================================================= */}
      <Modal
        isOpen={detailModalOpen}
        onClose={() => setDetailModalOpen(false)}
        title="Leave Application Details & Attendance Synchronization"
        size="md"
      >
        {selectedApp && (
          <div className="space-y-4 text-sm text-slate-700">
            <div className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-200">
              <div>
                <div className="text-xs text-slate-400 uppercase font-semibold">Status</div>
                <div className="mt-1">{getStatusBadge(selectedApp.status)}</div>
              </div>
              <div className="text-right">
                <div className="text-xs text-slate-400 uppercase font-semibold">Leave Type</div>
                <div className="font-bold text-slate-900 mt-1">{selectedApp.leaveTypeName || 'Standard Leave'}</div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="p-3 bg-white border border-slate-200 rounded-xl">
                <div className="text-xs text-slate-500 uppercase font-semibold">Date Range</div>
                <div className="font-medium text-slate-900 mt-1">
                  {selectedApp.startDate || selectedApp.leaveDate} to {selectedApp.endDate || selectedApp.startDate || selectedApp.leaveDate}
                </div>
              </div>
              <div className="p-3 bg-white border border-slate-200 rounded-xl">
                <div className="text-xs text-slate-500 uppercase font-semibold">Working Days Deducted</div>
                <div className="font-bold text-indigo-700 mt-1">
                  {selectedApp.totalDays} {selectedApp.totalDays === 1 ? 'day' : 'days'}
                </div>
              </div>
            </div>

            <div>
              <div className="text-xs text-slate-500 uppercase font-semibold mb-1">Reason & Description</div>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-slate-800">
                <p className="font-semibold text-slate-900">{selectedApp.reason}</p>
                {selectedApp.description && <p className="mt-1 text-slate-600 text-xs">{selectedApp.description}</p>}
              </div>
            </div>

            {selectedApp.attachmentUrl && (
              <div>
                <div className="text-xs text-slate-500 uppercase font-semibold mb-1">Attachment</div>
                <a
                  href={selectedApp.attachmentUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 p-2.5 bg-indigo-50 text-indigo-700 border border-indigo-200 rounded-xl hover:bg-indigo-100 transition text-xs font-semibold"
                >
                  <Paperclip className="w-4 h-4" />
                  <span>{selectedApp.attachmentName || 'View Document Attachment'}</span>
                </a>
              </div>
            )}

            {/* Review Info */}
            {(selectedApp.reviewedByName || selectedApp.adminRemarks || selectedApp.rejectionReason) && (
              <div className="p-3 bg-amber-50/60 border border-amber-200 rounded-xl space-y-1.5 text-xs text-slate-700">
                <div className="font-bold text-amber-900 uppercase tracking-wider text-[10px]">
                  Administrative Evaluation
                </div>
                {selectedApp.reviewedByName && (
                  <div>
                    Evaluated by: <strong className="text-slate-900">{selectedApp.reviewedByName}</strong> on {selectedApp.reviewedAt?.split('T')[0]}
                  </div>
                )}
                {selectedApp.adminRemarks && (
                  <div>
                    Admin Remarks: <span className="italic text-slate-800 font-medium">"{selectedApp.adminRemarks}"</span>
                  </div>
                )}
                {selectedApp.rejectionReason && (
                  <div className="text-rose-700">
                    Rejection Reason: <strong>{selectedApp.rejectionReason}</strong>
                  </div>
                )}
              </div>
            )}

            <div className="flex justify-end pt-3 border-t border-slate-200">
              <button
                type="button"
                onClick={() => setDetailModalOpen(false)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg transition"
              >
                Close
              </button>
            </div>
          </div>
        )}
      </Modal>

      {/* ========================================================================= */}
      {/* 3. CANCEL APPLICATION CONFIRMATION MODAL                                  */}
      {/* ========================================================================= */}
      <Modal
        isOpen={cancelModalOpen}
        onClose={() => setCancelModalOpen(false)}
        title="Cancel Leave Application"
        size="sm"
      >
        <div className="space-y-4 text-sm text-slate-700">
          <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 flex items-start gap-2">
            <AlertTriangle className="w-4 h-4 text-rose-600 flex-shrink-0 mt-0.5" />
            <div>
              Are you sure you want to cancel this application for{' '}
              <strong>{cancellingApp?.startDate || cancellingApp?.leaveDate}</strong>?
              {cancellingApp?.status === 'APPROVED' && (
                <p className="mt-1 text-rose-900 font-semibold">
                  Note: This application was approved. Cancelling will automatically reconcile and revert attendance records for these dates!
                </p>
              )}
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
              Reason for Cancellation (Optional)
            </label>
            <input
              type="text"
              placeholder="e.g. Health recovered early, Travel postponed"
              value={cancelReason}
              onChange={(e) => setCancelReason(e.target.value)}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-rose-500 focus:outline-none"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setCancelModalOpen(false)}
              className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-800 font-medium rounded-lg hover:bg-slate-100 transition"
            >
              Keep Active
            </button>
            <button
              type="button"
              disabled={cancelling}
              onClick={handleConfirmCancel}
              className="px-4 py-1.5 text-xs bg-rose-600 hover:bg-rose-700 text-white font-semibold rounded-lg shadow-sm transition inline-flex items-center gap-1.5"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              {cancelling ? 'Cancelling...' : 'Confirm Cancellation'}
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
