import React, { useEffect, useState } from 'react';
import { BookOpen, Layers, CheckCircle2, Clock, Sparkles, Building, AlertCircle } from 'lucide-react';
import { Badge } from '../../components/ui/Badge.js';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner.js';
import { api } from '../../services/api.js';
import { Subject } from '../../types/index.js';

interface EnrichedTeacherSubject extends Subject {
  departmentName?: string;
  classNames?: string[];
}

export const TeacherSubjectsPage: React.FC = () => {
  const [subjects, setSubjects] = useState<EnrichedTeacherSubject[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchSubjects = async () => {
      try {
        setLoading(true);
        const res = await api.getMyTeacherSubjects();
        if (res.success && res.data) {
          setSubjects(res.data);
        }
      } catch (err) {
        console.error('Failed to load teacher subjects', err);
      } finally {
        setLoading(false);
      }
    };
    fetchSubjects();
  }, []);

  return (
    <div className="space-y-6">
      <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-6 sm:p-8 shadow-xl shadow-black/20">
        <div className="flex items-center gap-2 text-indigo-400 text-xs font-bold uppercase tracking-wider mb-1">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Curriculum Allocation</span>
        </div>
        <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">Teaching Syllabus &amp; Subjects</h2>
        <p className="text-xs text-slate-400 mt-1">
          Live curriculum courses, syllabus progression, and classroom cohorts assigned to your faculty profile.
        </p>
      </div>

      {loading ? (
        <div className="py-20 flex justify-center">
          <LoadingSpinner size="lg" message="Loading assigned teaching subjects..." />
        </div>
      ) : subjects.length === 0 ? (
        <div className="bg-white/5 border border-white/10 rounded-3xl p-12 text-center space-y-3">
          <BookOpen className="w-12 h-12 text-slate-500 mx-auto" />
          <h3 className="text-lg font-bold text-white">No Subjects Assigned Yet</h3>
          <p className="text-xs text-slate-400 max-w-md mx-auto">
            Your teacher profile does not currently have any assigned subjects for this academic session. Please consult your Academic Department Head.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {(subjects || []).map((sub) => (
            <div
              key={sub.id}
              className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-6 shadow-xl shadow-black/20 space-y-4 hover:border-indigo-500/30 transition-all flex flex-col justify-between"
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <Badge variant={sub.type === 'THEORY' || sub.type === 'CORE' ? 'primary' : 'cyan'}>
                      {sub.type} COURSE
                    </Badge>
                    <h3 className="text-lg font-bold text-white mt-2">{sub.name}</h3>
                    <p className="text-xs text-slate-400 font-mono">
                      Code: {sub.code} • {sub.credits} Academic Credits
                    </p>
                  </div>
                </div>

                <div className="space-y-1 text-xs">
                  <span className="text-slate-400 text-[11px] font-medium flex items-center gap-1">
                    <Building className="w-3.5 h-3.5 text-slate-400" /> Academic Department:
                  </span>
                  <p className="text-slate-200 font-semibold">{sub.departmentName || 'Natural & Applied Sciences'}</p>
                </div>

                {((sub?.classNames?.length || 0) > 0) && (
                  <div className="space-y-2 text-xs pt-1">
                    <div className="text-slate-300 font-semibold">Assigned Class Tiers:</div>
                    <div className="flex flex-wrap gap-2">
                      {(sub.classNames || []).map((c) => (
                        <span key={c} className="px-2.5 py-1 rounded-xl bg-white/10 text-white font-medium">
                          {c}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div className="pt-3 border-t border-white/10 flex items-center justify-between text-xs text-slate-400">
                <span>Passing Grade: {sub.passMarks || 40} / {sub.totalMarks || 100}</span>
                <span className="text-indigo-300 font-mono font-medium">Active Syllabus</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
