import React, { useEffect, useState, useMemo } from 'react';
import {
  Users,
  Search,
  Filter,
  GraduationCap,
  Layers,
  ChevronLeft,
  ChevronRight,
  Eye,
  Shield,
  Phone,
  Mail,
  Calendar,
  MapPin,
  UserCheck,
  User,
  Heart,
  BookOpen,
  Info,
  RefreshCw,
  CalendarCheck,
  CheckCircle2,
  XCircle,
  Clock,
  AlertCircle
} from 'lucide-react';
import { Table, Column } from '../../components/ui/Table.js';
import { Badge } from '../../components/ui/Badge.js';
import { Button } from '../../components/ui/Button.js';
import { Modal } from '../../components/ui/Modal.js';
import { api } from '../../services/api.js';
import {
  TeacherStudentInfo,
  TeacherClassInfo,
  TeacherSectionInfo,
  StudentAttendanceHistoryData
} from '../../types/index.js';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner.js';
import { useToast } from '../../context/ToastContext.js';

interface TeacherStudentsPageProps {
  initialClassId?: string;
  initialSectionId?: string;
}

export const TeacherStudentsPage: React.FC<TeacherStudentsPageProps> = ({
  initialClassId,
  initialSectionId
}) => {
  const [students, setStudents] = useState<TeacherStudentInfo[]>([]);
  const [classes, setClasses] = useState<TeacherClassInfo[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedStudent, setSelectedStudent] = useState<TeacherStudentInfo | null>(null);
  const [studentDetailLoading, setStudentDetailLoading] = useState(false);
  const [studentAttendance, setStudentAttendance] = useState<StudentAttendanceHistoryData | null>(null);
  const [loadingAttendance, setLoadingAttendance] = useState(false);
  const { showToast } = useToast();

  // Load student attendance stats when selectedStudent opens
  useEffect(() => {
    if (!selectedStudent) {
      setStudentAttendance(null);
      return;
    }
    const loadAtt = async () => {
      setLoadingAttendance(true);
      try {
        const res = await api.getStudentAttendanceHistory(selectedStudent.id);
        if (res.success && res.data) {
          setStudentAttendance(res.data);
        }
      } catch (err) {
        console.error('Failed to load student attendance', err);
      } finally {
        setLoadingAttendance(false);
      }
    };
    loadAtt();
  }, [selectedStudent]);

  // Filters & Search
  const [search, setSearch] = useState('');
  const [selectedClassId, setSelectedClassId] = useState<string>(initialClassId || 'ALL');
  const [selectedSectionId, setSelectedSectionId] = useState<string>(initialSectionId || 'ALL');
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');

  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [totalStudents, setTotalStudents] = useState(0);
  const [totalPages, setTotalPages] = useState(1);

  // Load teacher's assigned classes on mount
  useEffect(() => {
    const fetchTeacherClasses = async () => {
      try {
        const res = await api.getMyTeacherClasses();
        if (res.success && res.data) {
          setClasses(res.data);
        }
      } catch (err) {
        console.error('Failed to load teacher classes', err);
      }
    };
    fetchTeacherClasses();
  }, []);

  // Compute available sections based on selected class
  const availableSections = useMemo(() => {
    if (selectedClassId === 'ALL') {
      // Gather all sections from all assigned classes
      const allSecs: TeacherSectionInfo[] = [];
      classes.forEach((c) => {
        if (c.sections) {
          allSecs.push(...c.sections);
        }
      });
      return allSecs;
    }
    const foundClass = (classes || []).find((c) => c?.id === selectedClassId);
    return foundClass?.sections || [];
  }, [classes, selectedClassId]);

  // Fetch students whenever filters, search, or pagination change
  const fetchStudents = async () => {
    try {
      setLoading(true);
      const res = await api.getMyTeacherStudents({
        classId: selectedClassId !== 'ALL' ? selectedClassId : undefined,
        sectionId: selectedSectionId !== 'ALL' ? selectedSectionId : undefined,
        status: selectedStatus !== 'ALL' ? selectedStatus : undefined,
        search: search.trim() || undefined,
        page: currentPage,
        limit: pageSize
      });

      if (res?.success) {
        const studentList = Array.isArray(res.data) ? res.data : Array.isArray((res as any)?.data?.students) ? (res as any).data.students : [];
        setStudents(studentList);
        if (res.pagination) {
          setTotalStudents(res.pagination.total);
          setTotalPages(res.pagination.totalPages);
        } else {
          setTotalStudents(studentList.length);
          setTotalPages(1);
        }
      }
    } catch (err: any) {
      console.error('Failed to fetch teacher students', err);
      showToast(err.message || 'Could not load student roster', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStudents();
  }, [selectedClassId, selectedSectionId, selectedStatus, search, currentPage, pageSize]);

  // Reset section when class filter changes
  const handleClassChange = (classId: string) => {
    setSelectedClassId(classId);
    setSelectedSectionId('ALL');
    setCurrentPage(1);
  };

  // Reset all filters
  const handleResetFilters = () => {
    setSearch('');
    setSelectedClassId('ALL');
    setSelectedSectionId('ALL');
    setSelectedStatus('ALL');
    setCurrentPage(1);
  };

  // View individual student profile
  const handleViewStudent = async (student: TeacherStudentInfo) => {
    try {
      setStudentDetailLoading(true);
      setSelectedStudent(student);
      const res = await api.getMyTeacherStudent(student.id);
      if (res.success && res.data) {
        setSelectedStudent(res.data);
      }
    } catch (err: any) {
      console.error('Failed to fetch student details', err);
      showToast(err.message || 'Could not load student profile', 'error');
    } finally {
      setStudentDetailLoading(false);
    }
  };

  const columns: Column<TeacherStudentInfo>[] = [
    {
      header: 'Student Name & ID',
      accessor: (row) => (
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-600/30 border border-indigo-400/30 flex items-center justify-center font-bold text-white text-xs flex-shrink-0 overflow-hidden shadow-inner">
            {row.avatarUrl ? (
              <img
                src={row.avatarUrl}
                alt={row.firstName}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            ) : (
              <span>
                {row.firstName?.[0]}
                {row.lastName?.[0]}
              </span>
            )}
          </div>
          <div>
            <div className="font-semibold text-white text-sm">
              {row.firstName} {row.lastName}
            </div>
            <div className="text-[11px] text-slate-400 font-mono flex items-center gap-1.5 mt-0.5">
              <span>Adm: {row.admissionNumber}</span>
              <span>•</span>
              <span className="text-indigo-300 font-bold">Roll: {row.rollNumber}</span>
            </div>
          </div>
        </div>
      )
    },
    {
      header: 'Class & Section',
      accessor: (row) => (
        <div>
          <span className="px-2.5 py-1 rounded-xl bg-white/10 text-white font-medium text-xs border border-white/5 inline-block">
            {row.className} • {row.sectionName}
          </span>
          <div className="text-[10px] text-slate-400 mt-1 font-mono">{row.academicSessionName}</div>
        </div>
      )
    },
    {
      header: 'Guardian Info',
      accessor: (row) => (
        <div className="space-y-0.5">
          <div className="text-xs text-slate-200 font-medium">{row.guardianName || 'Guardian on File'}</div>
          <div className="text-[11px] text-slate-400 flex items-center gap-1">
            <span className="text-indigo-400 font-mono text-[10px] uppercase">({row.guardianRelation || 'Parent'})</span>
            <span className="font-mono">{row.guardianPhone || 'N/A'}</span>
          </div>
        </div>
      )
    },
    {
      header: 'Status',
      accessor: (row) => {
        const isAct = row.status?.toLowerCase() === 'active' || row.enrollmentStatus?.toLowerCase() === 'active';
        return (
          <Badge variant={isAct ? 'success' : 'neutral'} dot>
            {row.enrollmentStatus || row.status || 'Active'}
          </Badge>
        );
      }
    },
    {
      header: 'Action',
      accessor: (row) => (
        <Button
          size="xs"
          variant="outline"
          leftIcon={<Eye className="w-3.5 h-3.5" />}
          onClick={() => handleViewStudent(row)}
        >
          View Profile
        </Button>
      )
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-6 sm:p-8 shadow-xl shadow-black/20 relative overflow-hidden flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="absolute top-0 right-0 w-80 h-80 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none" />

        <div className="space-y-1 z-10">
          <div className="flex items-center gap-2 text-indigo-400 text-xs font-bold uppercase tracking-wider">
            <Users className="w-3.5 h-3.5" />
            <span>Authorized Student Directory</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
            My Students Roster
          </h2>
          <p className="text-xs text-slate-400 max-w-xl">
            Access profile and contact information for students enrolled in your assigned classrooms.
            Protected by real-time institutional role authorization.
          </p>
        </div>

        <div className="flex items-center gap-3 z-10">
          <div className="px-4 py-2.5 rounded-2xl bg-white/5 border border-white/10 text-center">
            <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider block">Total Students</span>
            <span className="text-lg font-black text-white">{totalStudents}</span>
          </div>
          <Button
            size="sm"
            variant="glass"
            leftIcon={<RefreshCw className="w-3.5 h-3.5" />}
            onClick={() => fetchStudents()}
          >
            Refresh
          </Button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-4 sm:p-5 shadow-xl shadow-black/20 space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Search Input */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                setCurrentPage(1);
              }}
              placeholder="Search name, roll #, admission ID..."
              className="w-full bg-slate-900/80 border border-white/10 rounded-xl pl-10 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* Class Filter */}
          <div className="flex items-center gap-2">
            <GraduationCap className="w-4 h-4 text-slate-400 flex-shrink-0" />
            <select
              value={selectedClassId}
              onChange={(e) => handleClassChange(e.target.value)}
              className="w-full bg-slate-900/80 border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="ALL">All Assigned Classes</option>
              {(classes || []).map((cls) => (
                <option key={cls.id} value={cls.id}>
                  {cls.name} ({cls.totalStudents} students)
                </option>
              ))}
            </select>
          </div>

          {/* Section Filter */}
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-slate-400 flex-shrink-0" />
            <select
              value={selectedSectionId}
              onChange={(e) => {
                setSelectedSectionId(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full bg-slate-900/80 border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="ALL">All Sections</option>
              {(availableSections || []).map((sec) => (
                <option key={sec.id} value={sec.id}>
                  {sec.name} ({sec.studentCount} students)
                </option>
              ))}
            </select>
          </div>

          {/* Status Filter */}
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-slate-400 flex-shrink-0" />
            <select
              value={selectedStatus}
              onChange={(e) => {
                setSelectedStatus(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full bg-slate-900/80 border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="ALL">All Enrollment Statuses</option>
              <option value="active">Active</option>
              <option value="suspended">Suspended / On Leave</option>
              <option value="inactive">Inactive</option>
            </select>
          </div>
        </div>

        {(search || selectedClassId !== 'ALL' || selectedSectionId !== 'ALL' || selectedStatus !== 'ALL') && (
          <div className="flex items-center justify-between pt-2 border-t border-white/5 text-xs">
            <span className="text-slate-400">
              Filtered results: <strong className="text-white">{totalStudents}</strong> students
            </span>
            <button
              onClick={handleResetFilters}
              className="text-xs text-indigo-400 hover:text-indigo-300 font-semibold cursor-pointer"
            >
              Reset all filters
            </button>
          </div>
        )}
      </div>

      {/* Main Table or Loading State */}
      {loading ? (
        <div className="py-20 flex justify-center bg-white/5 rounded-3xl border border-white/10">
          <LoadingSpinner size="lg" message="Loading authorized student records..." />
        </div>
      ) : students.length === 0 ? (
        <div className="bg-white/5 border border-white/10 rounded-3xl p-12 text-center space-y-4">
          <Users className="w-12 h-12 text-slate-500 mx-auto" />
          <h3 className="text-lg font-bold text-white">No Students Found</h3>
          <p className="text-xs text-slate-400 max-w-md mx-auto leading-relaxed">
            No students matched your search criteria in your authorized class allocations.
            Try adjusting your search terms or clearing the selected filters.
          </p>
          <Button size="sm" variant="outline" onClick={handleResetFilters}>
            Clear Filters
          </Button>
        </div>
      ) : (
        <div className="space-y-4">
          <Table columns={columns} data={students} keyExtractor={(s) => s.id} />

          {/* Pagination Controls */}
          <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="text-xs text-slate-400">
              Showing <strong className="text-white">{Math.min(1 + (currentPage - 1) * pageSize, totalStudents)}</strong> to{' '}
              <strong className="text-white">{Math.min(currentPage * pageSize, totalStudents)}</strong> of{' '}
              <strong className="text-white">{totalStudents}</strong> student records
            </div>

            <div className="flex items-center gap-2">
              <select
                value={pageSize}
                onChange={(e) => {
                  setPageSize(Number(e.target.value));
                  setCurrentPage(1);
                }}
                className="bg-slate-900 border border-white/10 rounded-xl px-2.5 py-1.5 text-xs text-white focus:outline-none"
              >
                <option value={5}>5 per page</option>
                <option value={10}>10 per page</option>
                <option value={20}>20 per page</option>
              </select>

              <div className="flex items-center gap-1">
                <Button
                  size="xs"
                  variant="outline"
                  disabled={currentPage <= 1}
                  onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                  leftIcon={<ChevronLeft className="w-3.5 h-3.5" />}
                >
                  Prev
                </Button>
                <span className="px-3 py-1 text-xs font-mono font-semibold text-indigo-300">
                  Page {currentPage} of {totalPages}
                </span>
                <Button
                  size="xs"
                  variant="outline"
                  disabled={currentPage >= totalPages}
                  onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                  rightIcon={<ChevronRight className="w-3.5 h-3.5" />}
                >
                  Next
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Student Profile View Modal (Strictly Read-Only) */}
      {selectedStudent && (
        <Modal
          isOpen={Boolean(selectedStudent)}
          onClose={() => setSelectedStudent(null)}
          title="Student Profile Record"
          description="Authorized Academic Directory View"
          maxWidth="max-w-2xl"
        >
          <div className="space-y-6 text-xs">
            {/* Top Identity Card */}
            <div className="p-5 rounded-2xl bg-white/5 border border-white/10 flex flex-col sm:flex-row items-center sm:items-start gap-4">
              <div className="w-16 h-16 rounded-2xl bg-indigo-600/30 border border-indigo-400/40 flex items-center justify-center font-bold text-white text-xl flex-shrink-0 overflow-hidden shadow-xl">
                {selectedStudent.avatarUrl ? (
                  <img
                    src={selectedStudent.avatarUrl}
                    alt={selectedStudent.firstName}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <span>
                    {selectedStudent.firstName?.[0]}
                    {selectedStudent.lastName?.[0]}
                  </span>
                )}
              </div>

              <div className="flex-1 text-center sm:text-left space-y-1">
                <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
                  <h3 className="text-base font-bold text-white">
                    {selectedStudent.firstName} {selectedStudent.lastName}
                  </h3>
                  <Badge variant={selectedStudent.status === 'active' ? 'success' : 'neutral'} dot>
                    {selectedStudent.enrollmentStatus || selectedStudent.status || 'Active'}
                  </Badge>
                </div>

                <div className="flex flex-wrap items-center justify-center sm:justify-start gap-3 text-xs text-slate-300 font-mono">
                  <span>Student ID: <strong className="text-white">{selectedStudent.admissionNumber}</strong></span>
                  <span>•</span>
                  <span>Roll No: <strong className="text-indigo-300 font-bold">#{selectedStudent.rollNumber}</strong></span>
                </div>

                <div className="text-[11px] text-slate-400 flex items-center justify-center sm:justify-start gap-1 pt-0.5">
                  <Mail className="w-3 h-3 text-indigo-400" />
                  <span className="font-mono text-indigo-300">{selectedStudent.email}</span>
                </div>
              </div>
            </div>

            {/* Academic Information */}
            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-3">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5 text-indigo-400">
                <GraduationCap className="w-3.5 h-3.5" />
                <span>Class &amp; Academic Enrollment</span>
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="p-2.5 rounded-xl bg-white/[0.02] border border-white/5">
                  <span className="text-[10px] text-slate-400 uppercase font-semibold block">Class</span>
                  <span className="text-xs font-bold text-white">{selectedStudent.className}</span>
                </div>
                <div className="p-2.5 rounded-xl bg-white/[0.02] border border-white/5">
                  <span className="text-[10px] text-slate-400 uppercase font-semibold block">Section</span>
                  <span className="text-xs font-bold text-white">{selectedStudent.sectionName}</span>
                </div>
                <div className="p-2.5 rounded-xl bg-white/[0.02] border border-white/5">
                  <span className="text-[10px] text-slate-400 uppercase font-semibold block">Academic Session</span>
                  <span className="text-xs font-bold text-white">{selectedStudent.academicSessionName}</span>
                </div>
              </div>
            </div>

            {/* Personal & Demographics */}
            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-3">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5 text-cyan-400">
                <User className="w-3.5 h-3.5" />
                <span>Personal Details</span>
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="p-2.5 rounded-xl bg-white/[0.02] border border-white/5">
                  <span className="text-[10px] text-slate-400 uppercase font-semibold block">Date of Birth</span>
                  <span className="text-xs font-medium text-white">{selectedStudent.dateOfBirth || 'N/A'}</span>
                </div>
                <div className="p-2.5 rounded-xl bg-white/[0.02] border border-white/5">
                  <span className="text-[10px] text-slate-400 uppercase font-semibold block">Gender</span>
                  <span className="text-xs font-medium text-white capitalize">{selectedStudent.gender || 'N/A'}</span>
                </div>
                <div className="p-2.5 rounded-xl bg-white/[0.02] border border-white/5">
                  <span className="text-[10px] text-slate-400 uppercase font-semibold block">Blood Group</span>
                  <span className="text-xs font-bold text-rose-300 font-mono">{selectedStudent.bloodGroup || 'N/A'}</span>
                </div>
              </div>

              {selectedStudent.address && (
                <div className="p-2.5 rounded-xl bg-white/[0.02] border border-white/5 flex items-start gap-2">
                  <MapPin className="w-3.5 h-3.5 text-slate-400 mt-0.5 flex-shrink-0" />
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase font-semibold block">Residential Address</span>
                    <span className="text-xs text-slate-200">{selectedStudent.address}</span>
                  </div>
                </div>
              )}
            </div>

            {/* Guardian Information */}
            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-3">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5 text-amber-400">
                <Heart className="w-3.5 h-3.5" />
                <span>Guardian &amp; Emergency Contact</span>
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-2.5 rounded-xl bg-white/[0.02] border border-white/5 space-y-1">
                  <span className="text-[10px] text-slate-400 uppercase font-semibold block">Guardian Name</span>
                  <span className="text-xs font-bold text-white">{selectedStudent.guardianName}</span>
                  <span className="text-[10px] text-indigo-400 block font-mono">
                    Relationship: {selectedStudent.guardianRelation}
                  </span>
                </div>
                <div className="p-2.5 rounded-xl bg-white/[0.02] border border-white/5 space-y-1">
                  <span className="text-[10px] text-slate-400 uppercase font-semibold block">Contact Details</span>
                  <div className="flex items-center gap-1.5 text-xs text-white font-mono">
                    <Phone className="w-3 h-3 text-slate-400" />
                    <span>{selectedStudent.guardianPhone || 'N/A'}</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-[11px] text-indigo-300 font-mono truncate">
                    <Mail className="w-3 h-3 text-slate-400" />
                    <span>{selectedStudent.guardianEmail || 'N/A'}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Attendance & Participation Summary */}
            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-3">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center justify-between text-emerald-400">
                <div className="flex items-center gap-1.5">
                  <CalendarCheck className="w-3.5 h-3.5" />
                  <span>Attendance &amp; Participation History</span>
                </div>
                {studentAttendance && (
                  <span className="text-[11px] font-mono text-emerald-300 font-bold">
                    {studentAttendance.stats.percentage}% Attendance Rate
                  </span>
                )}
              </h4>

              {loadingAttendance ? (
                <div className="py-4 text-center text-slate-400 text-xs">
                  Loading student attendance history...
                </div>
              ) : studentAttendance ? (
                <div className="space-y-3">
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center">
                    <div className="p-2 rounded-xl bg-white/[0.02] border border-white/5">
                      <span className="text-[9px] text-slate-400 uppercase font-bold block">Recorded Sessions</span>
                      <span className="text-xs font-bold text-white">{studentAttendance.stats.totalSessions}</span>
                    </div>
                    <div className="p-2 rounded-xl bg-emerald-500/10 border border-emerald-500/20">
                      <span className="text-[9px] text-emerald-400 uppercase font-bold block">Present</span>
                      <span className="text-xs font-bold text-emerald-300">{studentAttendance.stats.present}</span>
                    </div>
                    <div className="p-2 rounded-xl bg-rose-500/10 border border-rose-500/20">
                      <span className="text-[9px] text-rose-400 uppercase font-bold block">Absent</span>
                      <span className="text-xs font-bold text-rose-300">{studentAttendance.stats.absent}</span>
                    </div>
                    <div className="p-2 rounded-xl bg-amber-500/10 border border-amber-500/20">
                      <span className="text-[9px] text-amber-400 uppercase font-bold block">Late / Excused</span>
                      <span className="text-xs font-bold text-amber-300">
                        {studentAttendance.stats.late + studentAttendance.stats.excused}
                      </span>
                    </div>
                  </div>

                  {/* Recent Logs list */}
                  {((studentAttendance?.records?.length || 0) > 0) && (
                    <div className="space-y-1.5 pt-1">
                      <span className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider block">
                        Recent Logged Sessions:
                      </span>
                      <div className="space-y-1 max-h-32 overflow-y-auto pr-1">
                        {studentAttendance.records.slice(0, 5).map((r) => (
                          <div
                            key={r.id}
                            className="p-2 rounded-lg bg-white/[0.02] border border-white/5 flex items-center justify-between text-[11px]"
                          >
                            <div className="flex items-center gap-2">
                              <span className="font-mono text-slate-300">{r.date}</span>
                              <span className="text-slate-500">•</span>
                              <span className="text-slate-400">{r.subjectName || 'Daily'}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              {r.remarks && <span className="text-slate-500 italic text-[10px]">"{r.remarks}"</span>}
                              <Badge
                                variant={
                                  r.status === 'PRESENT'
                                    ? 'success'
                                    : r.status === 'ABSENT'
                                    ? 'danger'
                                    : r.status === 'LATE'
                                    ? 'warning'
                                    : 'info'
                                }
                              >
                                {r.status}
                              </Badge>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div className="py-2 text-center text-slate-500 text-xs italic">
                  No attendance history logged yet.
                </div>
              )}
            </div>

            {/* Security Governance Notice */}
            <div className="p-3 rounded-xl bg-indigo-500/10 border border-indigo-500/20 flex items-start gap-2.5">
              <Shield className="w-4 h-4 text-indigo-400 mt-0.5 flex-shrink-0" />
              <p className="text-[11px] text-slate-300 leading-relaxed">
                <strong>Teacher Read-Only Mode:</strong> This record is provided for instructional and classroom communication purposes.
                Student admission profiles, demographic updates, and official enrollment statuses are maintained by the School Administration.
              </p>
            </div>

            <div className="flex justify-end pt-2">
              <Button size="sm" variant="outline" onClick={() => setSelectedStudent(null)}>
                Close Profile
              </Button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
