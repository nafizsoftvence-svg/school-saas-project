import React, { useEffect, useState, useMemo } from 'react';
import {
  Megaphone,
  Plus,
  Search,
  Filter,
  Calendar,
  Clock,
  CheckCircle2,
  AlertCircle,
  Pin,
  Trash2,
  Edit3,
  Eye,
  Archive,
  RefreshCw,
  Sparkles,
  GraduationCap,
  Bell,
  Radio,
  PinOff,
  Flame,
  Info
} from 'lucide-react';
import { api } from '../../services/api.js';
import { useAuth } from '../../context/AuthContext.js';
import { useToast } from '../../context/ToastContext.js';
import {
  ClassAnnouncement,
  AnnouncementFilterParams,
  TeacherClassInfo
} from '../../types/index.js';
import { Button } from '../../components/ui/Button.js';
import { Badge } from '../../components/ui/Badge.js';
import { Modal } from '../../components/ui/Modal.js';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner.js';

interface TeacherAnnouncementsPageProps {
  onNavigate?: (viewId: string) => void;
}

export const TeacherAnnouncementsPage: React.FC<TeacherAnnouncementsPageProps> = ({ onNavigate }) => {
  const { user } = useAuth();
  const { showToast } = useToast();

  // Data state
  const [announcementsList, setAnnouncementsList] = useState<ClassAnnouncement[]>([]);
  const [loading, setLoading] = useState(true);
  const [classes, setClasses] = useState<TeacherClassInfo[]>([]);

  // Filter state
  const [search, setSearch] = useState('');
  const [selectedClassId, setSelectedClassId] = useState('ALL');
  const [selectedSectionId, setSelectedSectionId] = useState('ALL');
  const [selectedPriority, setSelectedPriority] = useState('ALL');
  const [selectedStatus, setSelectedStatus] = useState('ALL');

  // Modals
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showViewModal, setShowViewModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [activeItem, setActiveItem] = useState<ClassAnnouncement | null>(null);

  // Form State
  const [formData, setFormData] = useState<{
    title: string;
    message: string;
    classId: string;
    sectionId: string;
    date: string;
    priority: 'normal' | 'important' | 'urgent';
    isPinned: boolean;
    status: 'draft' | 'published' | 'archived';
  }>({
    title: '',
    message: '',
    classId: '',
    sectionId: 'ALL',
    date: new Date().toISOString().split('T')[0],
    priority: 'normal',
    isPinned: false,
    status: 'published'
  });

  const [saving, setSaving] = useState(false);

  const loadContext = async () => {
    try {
      const classesRes = await api.getMyTeacherClasses();
      if (classesRes.success && classesRes.data) {
        setClasses(classesRes.data);
      }
    } catch (err: any) {
      console.error('Failed to load teacher context', err);
    }
  };

  const loadAnnouncements = async () => {
    try {
      setLoading(true);
      const params: AnnouncementFilterParams = {
        classId: selectedClassId,
        sectionId: selectedSectionId,
        priority: selectedPriority,
        status: selectedStatus,
        search
      };
      const res = await api.activities.getAnnouncements(params);
      if (res.success && res.data) {
        setAnnouncementsList(res.data);
      }
    } catch (err: any) {
      console.error('Failed to load announcements', err);
      showToast(err.message || 'Could not fetch announcements', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadContext();
  }, []);

  useEffect(() => {
    loadAnnouncements();
  }, [selectedClassId, selectedSectionId, selectedPriority, selectedStatus]);

  const availableSectionsForForm = useMemo(() => {
    if (!formData.classId) return [];
    const cls = (classes || []).find((c) => c?.id === formData.classId);
    return cls?.sections || [];
  }, [formData.classId, classes]);

  const availableSectionsForFilter = useMemo(() => {
    if (!selectedClassId || selectedClassId === 'ALL') return [];
    const cls = (classes || []).find((c) => c?.id === selectedClassId);
    return cls?.sections || [];
  }, [selectedClassId, classes]);

  const openCreateModal = () => {
    const defaultClass = classes?.[0];
    setFormData({
      title: '',
      message: '',
      classId: defaultClass?.id || '',
      sectionId: 'ALL',
      date: new Date().toISOString().split('T')[0],
      priority: 'normal',
      isPinned: false,
      status: 'published'
    });
    setShowCreateModal(true);
  };

  const openEditModal = (item: ClassAnnouncement) => {
    setActiveItem(item);
    setFormData({
      title: item.title,
      message: item.message,
      classId: item.classId,
      sectionId: item.sectionId,
      date: item.publishDate || item.date || new Date().toISOString().split('T')[0],
      priority: item.priority === 'high' ? 'urgent' : item.priority,
      isPinned: !!item.isPinned,
      status: item.status
    });
    setShowEditModal(true);
  };

  const openViewModal = (item: ClassAnnouncement) => {
    setActiveItem(item);
    setShowViewModal(true);
  };

  const openDeleteModal = (item: ClassAnnouncement) => {
    setActiveItem(item);
    setShowDeleteModal(true);
  };

  const handleCreateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title.trim() || !formData.message.trim()) {
      showToast('Please enter both title and message for the announcement', 'error');
      return;
    }
    if (!formData.classId) {
      showToast('Please select a target class', 'error');
      return;
    }

    try {
      setSaving(true);
      const res = await api.activities.createAnnouncement(formData);
      if (res.success && res.data) {
        showToast('Announcement posted successfully', 'success');
        setShowCreateModal(false);
        loadAnnouncements();
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to post announcement', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleEditSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeItem) return;

    try {
      setSaving(true);
      const res = await api.activities.updateAnnouncement(activeItem.id, formData);
      if (res.success && res.data) {
        showToast('Announcement updated successfully', 'success');
        setShowEditModal(false);
        loadAnnouncements();
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to update announcement', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteSubmit = async () => {
    if (!activeItem) return;
    try {
      setSaving(true);
      const res = await api.activities.deleteAnnouncement(activeItem.id);
      if (res.success) {
        showToast('Announcement deleted successfully', 'success');
        setShowDeleteModal(false);
        loadAnnouncements();
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to delete announcement', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleTogglePin = async (item: ClassAnnouncement) => {
    try {
      const nextPinned = !item.isPinned;
      await api.activities.updateAnnouncement(item.id, { isPinned: nextPinned });
      showToast(nextPinned ? 'Announcement pinned to top' : 'Announcement unpinned', 'info');
      loadAnnouncements();
    } catch (err: any) {
      showToast(err.message || 'Failed to update pinned state', 'error');
    }
  };

  const handleToggleArchive = async (item: ClassAnnouncement) => {
    try {
      const newStatus = item.status === 'archived' ? 'published' : 'archived';
      await api.activities.updateAnnouncement(item.id, { status: newStatus });
      showToast(`Announcement ${newStatus === 'archived' ? 'archived' : 'restored'}`, 'info');
      loadAnnouncements();
    } catch (err: any) {
      showToast(err.message || 'Failed to update status', 'error');
    }
  };

  const stats = useMemo(() => {
    const total = announcementsList.length;
    const published = announcementsList.filter((a) => a.status === 'published').length;
    const urgent = announcementsList.filter((a) => a.priority === 'urgent').length;
    const pinned = announcementsList.filter((a) => a.isPinned).length;
    return { total, published, urgent, pinned };
  }, [announcementsList]);

  return (
    <div className="space-y-8 pb-12">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-slate-900/60 p-6 rounded-2xl border border-white/10 backdrop-blur-xl">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 uppercase tracking-wider">
              Communication & Broadcasts
            </span>
            <span className="text-xs text-slate-400 font-medium">Part 3D</span>
          </div>
          <h1 className="text-2xl font-black tracking-tight text-white flex items-center gap-2">
            <Megaphone className="w-6 h-6 text-indigo-400" />
            Class Announcements
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Post urgent notices, homework reminders, and classroom bulletins to authorized classes and sections.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <Button
            variant="outline"
            size="sm"
            onClick={loadAnnouncements}
            disabled={loading}
            className="flex items-center gap-1.5"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
          <Button
            variant="primary"
            size="sm"
            onClick={openCreateModal}
            className="flex items-center gap-2 shadow-lg shadow-indigo-600/30"
          >
            <Plus className="w-4 h-4" />
            New Announcement
          </Button>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-slate-900/50 p-4 rounded-xl border border-white/10 backdrop-blur-sm">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">Total Bulletins</span>
          <div className="text-2xl font-black text-white mt-1">{stats.total}</div>
          <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-1">
            <Radio className="w-3 h-3 text-indigo-400" /> Broadcast logs
          </div>
        </div>
        <div className="bg-slate-900/50 p-4 rounded-xl border border-white/10 backdrop-blur-sm">
          <span className="text-xs font-semibold uppercase tracking-wider text-emerald-400">Published</span>
          <div className="text-2xl font-black text-emerald-400 mt-1">{stats.published}</div>
          <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3 text-emerald-400" /> Live on student feeds
          </div>
        </div>
        <div className="bg-slate-900/50 p-4 rounded-xl border border-white/10 backdrop-blur-sm">
          <span className="text-xs font-semibold uppercase tracking-wider text-rose-400">Urgent Notices</span>
          <div className="text-2xl font-black text-rose-400 mt-1">{stats.urgent}</div>
          <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-1">
            <Flame className="w-3 h-3 text-rose-400" /> High-priority alerts
          </div>
        </div>
        <div className="bg-slate-900/50 p-4 rounded-xl border border-white/10 backdrop-blur-sm">
          <span className="text-xs font-semibold uppercase tracking-wider text-amber-400">Pinned Notices</span>
          <div className="text-2xl font-black text-amber-400 mt-1">{stats.pinned}</div>
          <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-1">
            <Pin className="w-3 h-3 text-amber-400" /> Kept at top of feed
          </div>
        </div>
      </div>

      {/* Toolbar */}
      <div className="bg-slate-900/50 p-5 rounded-2xl border border-white/10 backdrop-blur-xl space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-3">
          <div className="lg:col-span-2 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search announcements by keywords..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && loadAnnouncements()}
              className="w-full pl-10 pr-4 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-colors"
            />
          </div>

          <div>
            <select
              value={selectedClassId}
              onChange={(e) => {
                setSelectedClassId(e.target.value);
                setSelectedSectionId('ALL');
              }}
              className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:border-indigo-500"
            >
              <option value="ALL">All Assigned Classes</option>
              {(classes || []).map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <select
              value={selectedPriority}
              onChange={(e) => setSelectedPriority(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:border-indigo-500"
            >
              <option value="ALL">All Priorities</option>
              <option value="urgent">Urgent</option>
              <option value="important">Important</option>
              <option value="normal">Normal</option>
            </select>
          </div>

          <div>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:border-indigo-500"
            >
              <option value="ALL">All Statuses</option>
              <option value="published">Published</option>
              <option value="draft">Draft</option>
              <option value="archived">Archived</option>
            </select>
          </div>
        </div>

        {(selectedClassId !== 'ALL' ||
          selectedPriority !== 'ALL' ||
          selectedStatus !== 'ALL' ||
          search.trim() !== '') && (
          <div className="flex items-center justify-between pt-2 border-t border-white/5 text-xs text-slate-400">
            <div className="flex items-center gap-2">
              <Filter className="w-3.5 h-3.5 text-indigo-400" />
              <span>Active filters applied</span>
            </div>
            <button
              onClick={() => {
                setSearch('');
                setSelectedClassId('ALL');
                setSelectedSectionId('ALL');
                setSelectedPriority('ALL');
                setSelectedStatus('ALL');
              }}
              className="text-indigo-400 hover:text-indigo-300 font-semibold cursor-pointer"
            >
              Reset Filters
            </button>
          </div>
        )}
      </div>

      {/* Grid */}
      {loading ? (
        <div className="py-20 flex justify-center">
          <LoadingSpinner size="lg" message="Loading announcements..." />
        </div>
      ) : announcementsList.length === 0 ? (
        <div className="bg-slate-900/40 p-12 rounded-2xl border border-white/10 text-center space-y-4">
          <div className="w-12 h-12 bg-indigo-600/20 text-indigo-400 rounded-2xl flex items-center justify-center mx-auto border border-indigo-500/30">
            <Megaphone className="w-6 h-6" />
          </div>
          <div className="space-y-1">
            <h3 className="text-lg font-bold text-white">No Announcements Found</h3>
            <p className="text-sm text-slate-400 max-w-md mx-auto">
              Broadcast notices and syllabus updates to your students.
            </p>
          </div>
          <Button variant="primary" size="sm" onClick={openCreateModal}>
            <Plus className="w-4 h-4 mr-1.5" />
            Post First Announcement
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {(announcementsList || []).map((item) => (
            <div
              key={item.id}
              className={`rounded-2xl border p-5 flex flex-col justify-between transition-all duration-200 shadow-2xs ${
                item.isPinned
                  ? 'bg-blue-50/40 border-blue-300 ring-1 ring-blue-300/40'
                  : 'bg-white border-slate-200 hover:border-slate-300'
              }`}
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    {item.isPinned && (
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-50 text-blue-700 border border-blue-200 flex items-center gap-1">
                        <Pin className="w-3 h-3 fill-blue-600" /> Pinned
                      </span>
                    )}
                    <span
                      className={`px-2.5 py-0.5 rounded-md text-[11px] font-bold uppercase tracking-wider ${
                        item.priority === 'urgent'
                          ? 'bg-rose-50 text-rose-800 border border-rose-200'
                          : item.priority === 'important'
                          ? 'bg-amber-50 text-amber-800 border border-amber-200'
                          : 'bg-slate-100 text-slate-700 border border-slate-200'
                      }`}
                    >
                      {item.priority}
                    </span>
                  </div>

                  <Badge
                    variant={
                      item.status === 'published'
                        ? 'success'
                        : item.status === 'draft'
                        ? 'warning'
                        : 'secondary'
                    }
                    className="capitalize"
                  >
                    {item.status}
                  </Badge>
                </div>

                <div>
                  <h3 className="text-base font-bold text-slate-900 leading-snug">
                    {item.title}
                  </h3>
                  <p className="text-xs text-slate-600 mt-2 leading-relaxed whitespace-pre-line line-clamp-3 font-medium">
                    {item.message}
                  </p>
                </div>

                <div className="bg-slate-50 rounded-xl p-3 border border-slate-200 space-y-1 text-xs">
                  <div className="flex items-center justify-between text-slate-700">
                    <span className="flex items-center gap-1.5 text-slate-500 font-medium">
                      <GraduationCap className="w-3.5 h-3.5 text-blue-600" /> Cohort Target
                    </span>
                    <span className="font-semibold text-slate-900">
                      {item.className} &bull; {item.sectionName}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-slate-700">
                    <span className="flex items-center gap-1.5 text-slate-500 font-medium">
                      <Calendar className="w-3.5 h-3.5 text-slate-400" /> Published
                    </span>
                    <span className="font-semibold text-slate-300">{item.publishDate || item.date}</span>
                  </div>
                </div>
              </div>

              {/* Card Actions */}
              <div className="pt-4 mt-4 border-t border-white/5 flex items-center justify-between">
                <span className="text-[10px] text-slate-500">
                  By {item.teacherName}
                </span>

                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => handleTogglePin(item)}
                    className={`p-1.5 rounded-lg transition-colors ${
                      item.isPinned
                        ? 'text-indigo-400 bg-indigo-500/10'
                        : 'text-slate-400 hover:text-white hover:bg-white/10'
                    }`}
                    title={item.isPinned ? 'Unpin' : 'Pin to Top'}
                  >
                    {item.isPinned ? <PinOff className="w-4 h-4" /> : <Pin className="w-4 h-4" />}
                  </button>
                  <button
                    onClick={() => openViewModal(item)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
                    title="View Full Notice"
                  >
                    <Eye className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => openEditModal(item)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-400 hover:bg-white/10 transition-colors"
                    title="Edit Announcement"
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleToggleArchive(item)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-amber-400 hover:bg-white/10 transition-colors"
                    title={item.status === 'archived' ? 'Restore Announcement' : 'Archive Announcement'}
                  >
                    <Archive className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => openDeleteModal(item)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-white/10 transition-colors"
                    title="Delete Announcement"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* CREATE MODAL */}
      <Modal
        isOpen={showCreateModal}
        onClose={() => !saving && setShowCreateModal(false)}
        title="Post New Class Announcement"
        maxWidth="max-w-xl"
      >
        <form onSubmit={handleCreateSubmit} className="space-y-4 text-sm">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
              Notice Headline / Subject <span className="text-rose-400">*</span>
            </label>
            <input
              type="text"
              required
              placeholder="e.g. Schedule Update: Math Lab Relocation on Friday"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              className="w-full px-3.5 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Target Class <span className="text-rose-400">*</span>
              </label>
              <select
                required
                value={formData.classId}
                onChange={(e) => {
                  const newClassId = e.target.value;
                  setFormData({
                    ...formData,
                    classId: newClassId,
                    sectionId: 'ALL'
                  });
                }}
                className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500"
              >
                <option value="">Select Class</option>
                {(classes || []).map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Section Audience
              </label>
              <select
                value={formData.sectionId}
                onChange={(e) => setFormData({ ...formData, sectionId: e.target.value })}
                disabled={!formData.classId}
                className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500 disabled:opacity-50"
              >
                <option value="ALL">All Sections (Entire Class)</option>
                {(availableSectionsForForm || []).map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Priority Level
              </label>
              <select
                value={formData.priority}
                onChange={(e) => setFormData({ ...formData, priority: e.target.value as any })}
                className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500"
              >
                <option value="normal">Normal Announcement</option>
                <option value="important">Important (Highlighted)</option>
                <option value="urgent">Urgent Alert</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Publish Date
              </label>
              <input
                type="date"
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
              Announcement Message <span className="text-rose-400">*</span>
            </label>
            <textarea
              rows={5}
              required
              placeholder="Write the message text clearly for all students..."
              value={formData.message}
              onChange={(e) => setFormData({ ...formData, message: e.target.value })}
              className="w-full px-3.5 py-2.5 bg-slate-950/60 border border-white/10 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div className="flex items-center gap-2 pt-1">
            <input
              type="checkbox"
              id="isPinned"
              checked={formData.isPinned}
              onChange={(e) => setFormData({ ...formData, isPinned: e.target.checked })}
              className="w-4 h-4 rounded text-indigo-600 bg-slate-950 border-white/20 focus:ring-indigo-500"
            />
            <label htmlFor="isPinned" className="text-xs text-slate-300 cursor-pointer font-medium">
              Pin to top of student announcements board
            </label>
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-white/10">
            <Button
              type="button"
              variant="outline"
              onClick={() => setShowCreateModal(false)}
              disabled={saving}
            >
              Cancel
            </Button>
            <Button type="submit" variant="primary" disabled={saving}>
              {saving ? 'Publishing...' : 'Broadcast Announcement'}
            </Button>
          </div>
        </form>
      </Modal>

      {/* EDIT MODAL */}
      <Modal
        isOpen={showEditModal}
        onClose={() => !saving && setShowEditModal(false)}
        title="Edit Announcement"
        maxWidth="max-w-xl"
      >
        <form onSubmit={handleEditSubmit} className="space-y-4 text-sm">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
              Headline <span className="text-rose-400">*</span>
            </label>
            <input
              type="text"
              required
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              className="w-full px-3.5 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Class
              </label>
              <select
                value={formData.classId}
                onChange={(e) => {
                  const newClassId = e.target.value;
                  setFormData({
                    ...formData,
                    classId: newClassId,
                    sectionId: 'ALL'
                  });
                }}
                className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500"
              >
                {(classes || []).map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Section
              </label>
              <select
                value={formData.sectionId}
                onChange={(e) => setFormData({ ...formData, sectionId: e.target.value })}
                className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500"
              >
                <option value="ALL">All Sections</option>
                {(availableSectionsForForm || []).map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Priority Level
              </label>
              <select
                value={formData.priority}
                onChange={(e) => setFormData({ ...formData, priority: e.target.value as any })}
                className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500"
              >
                <option value="normal">Normal</option>
                <option value="important">Important</option>
                <option value="urgent">Urgent</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Status
              </label>
              <select
                value={formData.status}
                onChange={(e) => setFormData({ ...formData, status: e.target.value as any })}
                className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500"
              >
                <option value="published">Published</option>
                <option value="draft">Draft</option>
                <option value="archived">Archived</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
              Message Text
            </label>
            <textarea
              rows={5}
              required
              value={formData.message}
              onChange={(e) => setFormData({ ...formData, message: e.target.value })}
              className="w-full px-3.5 py-2.5 bg-slate-950/60 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div className="flex items-center gap-2 pt-1">
            <input
              type="checkbox"
              id="editIsPinned"
              checked={formData.isPinned}
              onChange={(e) => setFormData({ ...formData, isPinned: e.target.checked })}
              className="w-4 h-4 rounded text-indigo-600 bg-slate-950 border-white/20 focus:ring-indigo-500"
            />
            <label htmlFor="editIsPinned" className="text-xs text-slate-300 cursor-pointer font-medium">
              Pin to top
            </label>
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-white/10">
            <Button
              type="button"
              variant="outline"
              onClick={() => setShowEditModal(false)}
              disabled={saving}
            >
              Cancel
            </Button>
            <Button type="submit" variant="primary" disabled={saving}>
              {saving ? 'Saving...' : 'Save Changes'}
            </Button>
          </div>
        </form>
      </Modal>

      {/* VIEW MODAL */}
      <Modal
        isOpen={showViewModal}
        onClose={() => setShowViewModal(false)}
        title="Announcement Broadcast"
        maxWidth="max-w-lg"
      >
        {activeItem && (
          <div className="space-y-4 text-sm">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <span
                className={`px-2.5 py-0.5 rounded-md text-[11px] font-bold uppercase tracking-wider ${
                  activeItem.priority === 'urgent'
                    ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                    : activeItem.priority === 'important'
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                    : 'bg-slate-800 text-slate-300'
                }`}
              >
                {activeItem.priority} notice
              </span>
              <Badge variant={activeItem.status === 'published' ? 'success' : 'secondary'}>
                {activeItem.status}
              </Badge>
            </div>

            <div>
              <h2 className="text-xl font-bold text-white">{activeItem.title}</h2>
              <div className="flex items-center gap-4 text-xs text-slate-400 mt-1">
                <span>Audience: <strong className="text-white">{activeItem.className} ({activeItem.sectionName})</strong></span>
                <span>Date: <strong className="text-white">{activeItem.publishDate || activeItem.date}</strong></span>
              </div>
            </div>

            <div className="bg-slate-950/60 p-4 rounded-xl border border-white/10">
              <p className="text-sm text-slate-200 whitespace-pre-line leading-relaxed">
                {activeItem.message}
              </p>
            </div>

            <div className="pt-3 border-t border-white/10 flex items-center justify-between text-xs text-slate-500">
              <span>Author: {activeItem.teacherName}</span>
              <Button variant="outline" size="sm" onClick={() => setShowViewModal(false)}>
                Close
              </Button>
            </div>
          </div>
        )}
      </Modal>

      {/* DELETE MODAL */}
      <Modal
        isOpen={showDeleteModal}
        onClose={() => !saving && setShowDeleteModal(false)}
        title="Confirm Announcement Deletion"
        maxWidth="max-w-md"
      >
        <div className="space-y-4">
          <div className="flex items-center gap-3 p-3 bg-rose-950/30 rounded-xl border border-rose-500/30 text-rose-300 text-sm">
            <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />
            <p>
              Are you sure you want to delete <strong>{activeItem?.title}</strong>?
            </p>
          </div>

          <div className="flex justify-end gap-3 pt-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => setShowDeleteModal(false)}
              disabled={saving}
            >
              Cancel
            </Button>
            <Button
              type="button"
              variant="danger"
              onClick={handleDeleteSubmit}
              disabled={saving}
            >
              {saving ? 'Deleting...' : 'Delete Permanently'}
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
