import React, { useEffect, useState, useMemo } from 'react';
import {
  FileSpreadsheet,
  Plus,
  Search,
  Filter,
  Calendar,
  Clock,
  CheckCircle2,
  AlertCircle,
  FileText,
  Paperclip,
  Trash2,
  Edit3,
  Eye,
  Archive,
  RefreshCw,
  Sparkles,
  GraduationCap,
  BookOpen,
  ArrowRight,
  Download,
  Award,
  UploadCloud,
  X,
  Lock,
  Unlock
} from 'lucide-react';
import { api } from '../../services/api.js';
import { useAuth } from '../../context/AuthContext.js';
import { useToast } from '../../context/ToastContext.js';
import {
  Assignment,
  AssignmentFilterParams,
  TeacherClassInfo,
  TeacherSubjectBrief
} from '../../types/index.js';
import { Button } from '../../components/ui/Button.js';
import { Badge } from '../../components/ui/Badge.js';
import { Modal } from '../../components/ui/Modal.js';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner.js';

interface TeacherAssignmentsPageProps {
  onNavigate?: (viewId: string) => void;
}

export const TeacherAssignmentsPage: React.FC<TeacherAssignmentsPageProps> = ({ onNavigate }) => {
  const { user } = useAuth();
  const { showToast } = useToast();

  // Data state
  const [assignmentsList, setAssignmentsList] = useState<Assignment[]>([]);
  const [loading, setLoading] = useState(true);
  const [classes, setClasses] = useState<TeacherClassInfo[]>([]);
  const [subjects, setSubjects] = useState<TeacherSubjectBrief[]>([]);

  // Filter state
  const [search, setSearch] = useState('');
  const [selectedClassId, setSelectedClassId] = useState('ALL');
  const [selectedSectionId, setSelectedSectionId] = useState('ALL');
  const [selectedSubjectId, setSelectedSubjectId] = useState('ALL');
  const [selectedStatus, setSelectedStatus] = useState('ALL');

  // Modals
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showViewModal, setShowViewModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [activeItem, setActiveItem] = useState<Assignment | null>(null);

  // Form State
  const [formData, setFormData] = useState<{
    title: string;
    description: string;
    subjectId: string;
    classId: string;
    sectionId: string;
    startDate: string;
    dueDate: string;
    totalMarks: number;
    attachmentUrl: string;
    attachmentName: string;
    attachmentSize: string;
    attachmentType: string;
    status: 'draft' | 'published' | 'closed' | 'archived';
  }>({
    title: '',
    description: '',
    subjectId: '',
    classId: '',
    sectionId: '',
    startDate: new Date().toISOString().split('T')[0],
    dueDate: '',
    totalMarks: 100,
    attachmentUrl: '',
    attachmentName: '',
    attachmentSize: '',
    attachmentType: '',
    status: 'published'
  });

  const [uploadingFile, setUploadingFile] = useState(false);
  const [saving, setSaving] = useState(false);

  const loadContext = async () => {
    try {
      const [classesRes, subjectsRes] = await Promise.all([
        api.getMyTeacherClasses(),
        api.getMyTeacherSubjects()
      ]);

      if (classesRes.success && classesRes.data) {
        setClasses(classesRes.data);
      }
      if (subjectsRes.success && subjectsRes.data) {
        setSubjects(subjectsRes.data);
      }
    } catch (err: any) {
      console.error('Failed to load context', err);
    }
  };

  const loadAssignments = async () => {
    try {
      setLoading(true);
      const params: AssignmentFilterParams = {
        classId: selectedClassId,
        sectionId: selectedSectionId,
        subjectId: selectedSubjectId,
        status: selectedStatus,
        search
      };
      const res = await api.activities.getAssignments(params);
      if (res.success && res.data) {
        setAssignmentsList(res.data);
      }
    } catch (err: any) {
      console.error('Failed to load assignments', err);
      showToast(err.message || 'Could not fetch assignments list', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadContext();
  }, []);

  useEffect(() => {
    loadAssignments();
  }, [selectedClassId, selectedSectionId, selectedSubjectId, selectedStatus]);

  const availableSectionsForForm = useMemo(() => {
    if (!formData.classId) return [];
    const cls = (classes || []).find((c) => c?.id === formData.classId);
    return cls?.sections || [];
  }, [formData.classId, classes]);

  const availableSectionsForFilter = useMemo(() => {
    if (!selectedClassId || selectedClassId === 'ALL') return [];
    const cls = (classes || []).find((c) => c?.id === selectedClassId);
    return cls?.sections || [];
  }, [selectedClassId, classes]);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setUploadingFile(true);
      const res = await api.activities.uploadFile({
        fileName: file.name,
        fileSizeBytes: file.size,
        fileType: file.name.split('.').pop() || 'pdf'
      });

      if (res.success && res.data) {
        setFormData((prev) => ({
          ...prev,
          attachmentUrl: res.data.fileUrl,
          attachmentName: res.data.fileName,
          attachmentSize: res.data.fileSize,
          attachmentType: res.data.fileType
        }));
        showToast('Assignment attachment verified and attached', 'success');
      }
    } catch (err: any) {
      showToast(err.message || 'File upload failed', 'error');
    } finally {
      setUploadingFile(false);
    }
  };

  const openCreateModal = () => {
    const defaultClass = classes?.[0];
    const defaultSection = defaultClass?.sections?.[0];
    const defaultSubject = subjects?.[0];

    const today = new Date();
    const twoWeeksLater = new Date(today);
    twoWeeksLater.setDate(today.getDate() + 14);

    setFormData({
      title: '',
      description: '',
      classId: defaultClass?.id || '',
      sectionId: defaultSection?.id || '',
      subjectId: defaultSubject?.id || '',
      startDate: today.toISOString().split('T')[0],
      dueDate: twoWeeksLater.toISOString().split('T')[0],
      totalMarks: 100,
      attachmentUrl: '',
      attachmentName: '',
      attachmentSize: '',
      attachmentType: '',
      status: 'published'
    });
    setShowCreateModal(true);
  };

  const openEditModal = (item: Assignment) => {
    setActiveItem(item);
    setFormData({
      title: item.title,
      description: item.description,
      classId: item.classId,
      sectionId: item.sectionId,
      subjectId: item.subjectId,
      startDate: item.startDate,
      dueDate: item.dueDate,
      totalMarks: item.totalMarks || 100,
      attachmentUrl: item.attachmentUrl || '',
      attachmentName: item.attachmentName || '',
      attachmentSize: item.attachmentSize || '',
      attachmentType: item.attachmentType || '',
      status: item.status
    });
    setShowEditModal(true);
  };

  const openViewModal = (item: Assignment) => {
    setActiveItem(item);
    setShowViewModal(true);
  };

  const openDeleteModal = (item: Assignment) => {
    setActiveItem(item);
    setShowDeleteModal(true);
  };

  const handleCreateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title.trim()) {
      showToast('Please enter an assignment title', 'error');
      return;
    }
    if (!formData.classId || !formData.sectionId || !formData.subjectId) {
      showToast('Please select Class, Section, and Subject', 'error');
      return;
    }
    if (!formData.dueDate) {
      showToast('Please select a due date', 'error');
      return;
    }

    try {
      setSaving(true);
      const res = await api.activities.createAssignment(formData);
      if (res.success && res.data) {
        showToast('Assignment created and published successfully', 'success');
        setShowCreateModal(false);
        loadAssignments();
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to create assignment', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleEditSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeItem) return;

    try {
      setSaving(true);
      const res = await api.activities.updateAssignment(activeItem.id, formData);
      if (res.success && res.data) {
        showToast('Assignment updated successfully', 'success');
        setShowEditModal(false);
        loadAssignments();
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to update assignment', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteSubmit = async () => {
    if (!activeItem) return;
    try {
      setSaving(true);
      const res = await api.activities.deleteAssignment(activeItem.id);
      if (res.success) {
        showToast('Assignment deleted successfully', 'success');
        setShowDeleteModal(false);
        loadAssignments();
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to delete assignment', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleToggleClose = async (item: Assignment) => {
    try {
      const newStatus = item.status === 'closed' ? 'published' : 'closed';
      await api.activities.updateAssignment(item.id, { status: newStatus });
      showToast(`Assignment ${newStatus === 'closed' ? 'closed' : 're-opened'}`, 'info');
      loadAssignments();
    } catch (err: any) {
      showToast(err.message || 'Failed to update status', 'error');
    }
  };

  const stats = useMemo(() => {
    const total = assignmentsList.length;
    const active = assignmentsList.filter((a) => a.status === 'published').length;
    const closed = assignmentsList.filter((a) => a.status === 'closed').length;
    const drafts = assignmentsList.filter((a) => a.status === 'draft').length;
    return { total, active, closed, drafts };
  }, [assignmentsList]);

  return (
    <div className="space-y-8 pb-12">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-slate-900/60 p-6 rounded-2xl border border-white/10 backdrop-blur-xl">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 uppercase tracking-wider">
              Academic Operations
            </span>
            <span className="text-xs text-slate-400 font-medium">Part 3D</span>
          </div>
          <h1 className="text-2xl font-black tracking-tight text-white flex items-center gap-2">
            <FileSpreadsheet className="w-6 h-6 text-indigo-400" />
            Class Assignments
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Create structured academic assignments, rubrics, and track project deadlines for authorized cohorts.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <Button
            variant="outline"
            size="sm"
            onClick={loadAssignments}
            disabled={loading}
            className="flex items-center gap-1.5"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
          <Button
            variant="primary"
            size="sm"
            onClick={openCreateModal}
            className="flex items-center gap-2 shadow-lg shadow-indigo-600/30"
          >
            <Plus className="w-4 h-4" />
            New Assignment
          </Button>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-slate-900/50 p-4 rounded-xl border border-white/10 backdrop-blur-sm">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">Total Assignments</span>
          <div className="text-2xl font-black text-white mt-1">{stats.total}</div>
          <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-1">
            <BookOpen className="w-3 h-3 text-indigo-400" /> Major projects & tasks
          </div>
        </div>
        <div className="bg-slate-900/50 p-4 rounded-xl border border-white/10 backdrop-blur-sm">
          <span className="text-xs font-semibold uppercase tracking-wider text-emerald-400">Active / Open</span>
          <div className="text-2xl font-black text-emerald-400 mt-1">{stats.active}</div>
          <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3 text-emerald-400" /> Open for study
          </div>
        </div>
        <div className="bg-slate-900/50 p-4 rounded-xl border border-white/10 backdrop-blur-sm">
          <span className="text-xs font-semibold uppercase tracking-wider text-amber-400">Closed</span>
          <div className="text-2xl font-black text-amber-400 mt-1">{stats.closed}</div>
          <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-1">
            <Lock className="w-3 h-3 text-amber-400" /> Past deadline
          </div>
        </div>
        <div className="bg-slate-900/50 p-4 rounded-xl border border-white/10 backdrop-blur-sm">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">Drafts</span>
          <div className="text-2xl font-black text-slate-300 mt-1">{stats.drafts}</div>
          <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-1">
            <Clock className="w-3 h-3 text-slate-400" /> Unreleased
          </div>
        </div>
      </div>

      {/* Toolbar */}
      <div className="bg-slate-900/50 p-5 rounded-2xl border border-white/10 backdrop-blur-xl space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-3">
          <div className="lg:col-span-2 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search assignments by title or rubric..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && loadAssignments()}
              className="w-full pl-10 pr-4 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-colors"
            />
          </div>

          <div>
            <select
              value={selectedClassId}
              onChange={(e) => {
                setSelectedClassId(e.target.value);
                setSelectedSectionId('ALL');
              }}
              className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:border-indigo-500"
            >
              <option value="ALL">All Assigned Classes</option>
              {(classes || []).map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <select
              value={selectedSectionId}
              onChange={(e) => setSelectedSectionId(e.target.value)}
              disabled={selectedClassId === 'ALL'}
              className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:border-indigo-500 disabled:opacity-50"
            >
              <option value="ALL">All Sections</option>
              {(availableSectionsForFilter || []).map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <select
              value={selectedSubjectId}
              onChange={(e) => setSelectedSubjectId(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:border-indigo-500"
            >
              <option value="ALL">All My Subjects</option>
              {(subjects || []).map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.code})
                </option>
              ))}
            </select>
          </div>

          <div>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:border-indigo-500"
            >
              <option value="ALL">All Statuses</option>
              <option value="published">Published</option>
              <option value="closed">Closed</option>
              <option value="draft">Draft</option>
              <option value="archived">Archived</option>
            </select>
          </div>
        </div>

        {(selectedClassId !== 'ALL' ||
          selectedSectionId !== 'ALL' ||
          selectedSubjectId !== 'ALL' ||
          selectedStatus !== 'ALL' ||
          search.trim() !== '') && (
          <div className="flex items-center justify-between pt-2 border-t border-white/5 text-xs text-slate-400">
            <div className="flex items-center gap-2">
              <Filter className="w-3.5 h-3.5 text-indigo-400" />
              <span>Active filters applied</span>
            </div>
            <button
              onClick={() => {
                setSearch('');
                setSelectedClassId('ALL');
                setSelectedSectionId('ALL');
                setSelectedSubjectId('ALL');
                setSelectedStatus('ALL');
              }}
              className="text-indigo-400 hover:text-indigo-300 font-semibold cursor-pointer"
            >
              Reset Filters
            </button>
          </div>
        )}
      </div>

      {/* Grid */}
      {loading ? (
        <div className="py-20 flex justify-center">
          <LoadingSpinner size="lg" message="Loading assignments..." />
        </div>
      ) : assignmentsList.length === 0 ? (
        <div className="bg-slate-900/40 p-12 rounded-2xl border border-white/10 text-center space-y-4">
          <div className="w-12 h-12 bg-indigo-600/20 text-indigo-400 rounded-2xl flex items-center justify-center mx-auto border border-indigo-500/30">
            <FileSpreadsheet className="w-6 h-6" />
          </div>
          <div className="space-y-1">
            <h3 className="text-lg font-bold text-white">No Assignments Found</h3>
            <p className="text-sm text-slate-400 max-w-md mx-auto">
              No assignments match your search and filter parameters.
            </p>
          </div>
          <Button variant="primary" size="sm" onClick={openCreateModal}>
            <Plus className="w-4 h-4 mr-1.5" />
            Create First Assignment
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {(assignmentsList || []).map((item) => (
            <div
              key={item.id}
              className="bg-slate-900/60 rounded-2xl border border-white/10 hover:border-indigo-500/40 p-5 flex flex-col justify-between transition-all duration-200 hover:shadow-xl hover:shadow-indigo-950/40 group backdrop-blur-sm"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <span className="px-2.5 py-0.5 rounded-md text-[11px] font-bold bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 truncate max-w-[150px]">
                    {item.subjectName}
                  </span>
                  <div className="flex items-center gap-1.5">
                    {item.totalMarks && (
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/10 text-amber-300 border border-amber-500/20 flex items-center gap-1">
                        <Award className="w-3 h-3" /> {item.totalMarks} pts
                      </span>
                    )}
                    <Badge
                      variant={
                        item.status === 'published'
                          ? 'success'
                          : item.status === 'closed'
                          ? 'danger'
                          : item.status === 'draft'
                          ? 'warning'
                          : 'secondary'
                      }
                      className="capitalize"
                    >
                      {item.status}
                    </Badge>
                  </div>
                </div>

                <div>
                  <h3 className="text-base font-bold text-white group-hover:text-indigo-300 transition-colors line-clamp-1">
                    {item.title}
                  </h3>
                  <p className="text-xs text-slate-400 mt-1.5 line-clamp-2 leading-relaxed">
                    {item.description || 'No detailed instructions provided.'}
                  </p>
                </div>

                <div className="bg-slate-950/40 rounded-xl p-3 border border-white/5 space-y-2 text-xs">
                  <div className="flex items-center justify-between text-slate-300">
                    <span className="flex items-center gap-1.5 text-slate-400">
                      <GraduationCap className="w-3.5 h-3.5 text-slate-500" /> Target
                    </span>
                    <span className="font-semibold text-white">
                      {item.className} &bull; {item.sectionName}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-slate-300">
                    <span className="flex items-center gap-1.5 text-slate-400">
                      <Calendar className="w-3.5 h-3.5 text-slate-500" /> Timeline
                    </span>
                    <span className="font-semibold text-slate-200">
                      {item.startDate} &rarr; <span className="text-amber-400">{item.dueDate}</span>
                    </span>
                  </div>
                </div>

                {item.attachmentName && (
                  <div className="flex items-center gap-2 p-2 bg-indigo-950/30 rounded-lg border border-indigo-500/20 text-xs text-indigo-300">
                    <Paperclip className="w-3.5 h-3.5 shrink-0" />
                    <span className="truncate flex-1">{item.attachmentName}</span>
                    {item.attachmentSize && (
                      <span className="text-[10px] text-indigo-400 font-mono">{item.attachmentSize}</span>
                    )}
                  </div>
                )}
              </div>

              {/* Card Actions */}
              <div className="pt-4 mt-4 border-t border-white/5 flex items-center justify-between">
                <span className="text-[10px] text-slate-500 truncate max-w-[120px]">
                  Teacher: {item.teacherName}
                </span>

                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => openViewModal(item)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
                    title="View Details"
                  >
                    <Eye className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => openEditModal(item)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-400 hover:bg-white/10 transition-colors"
                    title="Edit Assignment"
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleToggleClose(item)}
                    className={`p-1.5 rounded-lg transition-colors ${
                      item.status === 'closed'
                        ? 'text-emerald-400 hover:bg-emerald-500/10'
                        : 'text-slate-400 hover:text-amber-400 hover:bg-white/10'
                    }`}
                    title={item.status === 'closed' ? 'Reopen Submissions' : 'Close Submissions'}
                  >
                    {item.status === 'closed' ? <Unlock className="w-4 h-4" /> : <Lock className="w-4 h-4" />}
                  </button>
                  <button
                    onClick={() => openDeleteModal(item)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-white/10 transition-colors"
                    title="Delete Assignment"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* CREATE MODAL */}
      <Modal
        isOpen={showCreateModal}
        onClose={() => !saving && setShowCreateModal(false)}
        title="Create New Academic Assignment"
        maxWidth="max-w-2xl"
      >
        <form onSubmit={handleCreateSubmit} className="space-y-4 text-sm">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
              Assignment Title <span className="text-rose-400">*</span>
            </label>
            <input
              type="text"
              required
              placeholder="e.g. Calculus & Optimization Modeling Capstone Project"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              className="w-full px-3.5 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Class <span className="text-rose-400">*</span>
              </label>
              <select
                required
                value={formData.classId}
                onChange={(e) => {
                  const newClassId = e.target.value;
                  const cls = (classes || []).find((c) => c?.id === newClassId);
                  setFormData({
                    ...formData,
                    classId: newClassId,
                    sectionId: cls?.sections?.[0]?.id || ''
                  });
                }}
                className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500"
              >
                <option value="">Select Class</option>
                {(classes || []).map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Section <span className="text-rose-400">*</span>
              </label>
              <select
                required
                value={formData.sectionId}
                onChange={(e) => setFormData({ ...formData, sectionId: e.target.value })}
                disabled={!formData.classId}
                className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500 disabled:opacity-50"
              >
                <option value="">Select Section</option>
                {(availableSectionsForForm || []).map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Subject <span className="text-rose-400">*</span>
              </label>
              <select
                required
                value={formData.subjectId}
                onChange={(e) => setFormData({ ...formData, subjectId: e.target.value })}
                className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500"
              >
                <option value="">Select Subject</option>
                {(subjects || []).map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name} ({s.code})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Start Date
              </label>
              <input
                type="date"
                value={formData.startDate}
                onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Due Date <span className="text-rose-400">*</span>
              </label>
              <input
                type="date"
                required
                value={formData.dueDate}
                onChange={(e) => setFormData({ ...formData, dueDate: e.target.value })}
                className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Total Marks
              </label>
              <input
                type="number"
                min={1}
                max={500}
                value={formData.totalMarks}
                onChange={(e) => setFormData({ ...formData, totalMarks: Number(e.target.value) })}
                className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Status
              </label>
              <select
                value={formData.status}
                onChange={(e) => setFormData({ ...formData, status: e.target.value as any })}
                className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500"
              >
                <option value="published">Published</option>
                <option value="draft">Draft</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
              Assignment Description, Instructions & Rubrics
            </label>
            <textarea
              rows={4}
              placeholder="Detail the project guidelines, milestones, submission formats, and grading criteria..."
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              className="w-full px-3.5 py-2.5 bg-slate-950/60 border border-white/10 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
            />
          </div>

          {/* Attachment */}
          <div className="bg-slate-950/40 p-4 rounded-xl border border-white/5 space-y-2">
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-300">
              Optional Assignment Rubric / Brief Document (PDF, Word, Code Zip - Max 15MB)
            </label>

            {formData.attachmentName ? (
              <div className="flex items-center justify-between p-2.5 bg-indigo-950/40 rounded-xl border border-indigo-500/30">
                <div className="flex items-center gap-2 text-xs text-indigo-300 truncate">
                  <FileText className="w-4 h-4 text-indigo-400" />
                  <span className="font-semibold truncate">{formData.attachmentName}</span>
                  <span className="text-slate-400 font-mono">({formData.attachmentSize})</span>
                </div>
                <button
                  type="button"
                  onClick={() =>
                    setFormData({
                      ...formData,
                      attachmentUrl: '',
                      attachmentName: '',
                      attachmentSize: '',
                      attachmentType: ''
                    })
                  }
                  className="text-slate-400 hover:text-rose-400 p-1"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="relative border-2 border-dashed border-white/10 hover:border-indigo-500/40 rounded-xl p-4 text-center cursor-pointer transition-colors">
                <input
                  type="file"
                  onChange={handleFileUpload}
                  className="absolute inset-0 opacity-0 cursor-pointer"
                  disabled={uploadingFile}
                />
                <UploadCloud className="w-6 h-6 text-slate-400 mx-auto mb-1" />
                <p className="text-xs text-slate-300">
                  {uploadingFile ? 'Scanning attachment...' : 'Upload assignment rubric or starter files'}
                </p>
                <span className="text-[10px] text-slate-500">Supports PDF, DOCX, ZIP, PPTX (up to 15MB)</span>
              </div>
            )}
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-white/10">
            <Button
              type="button"
              variant="outline"
              onClick={() => setShowCreateModal(false)}
              disabled={saving}
            >
              Cancel
            </Button>
            <Button type="submit" variant="primary" disabled={saving || uploadingFile}>
              {saving ? 'Creating...' : 'Create & Publish Assignment'}
            </Button>
          </div>
        </form>
      </Modal>

      {/* EDIT MODAL */}
      <Modal
        isOpen={showEditModal}
        onClose={() => !saving && setShowEditModal(false)}
        title="Edit Assignment"
        maxWidth="max-w-2xl"
      >
        <form onSubmit={handleEditSubmit} className="space-y-4 text-sm">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
              Assignment Title <span className="text-rose-400">*</span>
            </label>
            <input
              type="text"
              required
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              className="w-full px-3.5 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Class
              </label>
              <select
                value={formData.classId}
                onChange={(e) => {
                  const newClassId = e.target.value;
                  const cls = (classes || []).find((c) => c?.id === newClassId);
                  setFormData({
                    ...formData,
                    classId: newClassId,
                    sectionId: cls?.sections?.[0]?.id || ''
                  });
                }}
                className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500"
              >
                {(classes || []).map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Section
              </label>
              <select
                value={formData.sectionId}
                onChange={(e) => setFormData({ ...formData, sectionId: e.target.value })}
                className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500"
              >
                {(availableSectionsForForm || []).map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Subject
              </label>
              <select
                value={formData.subjectId}
                onChange={(e) => setFormData({ ...formData, subjectId: e.target.value })}
                className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500"
              >
                {(subjects || []).map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name} ({s.code})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Start Date
              </label>
              <input
                type="date"
                value={formData.startDate}
                onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Due Date
              </label>
              <input
                type="date"
                required
                value={formData.dueDate}
                onChange={(e) => setFormData({ ...formData, dueDate: e.target.value })}
                className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Total Marks
              </label>
              <input
                type="number"
                min={1}
                max={500}
                value={formData.totalMarks}
                onChange={(e) => setFormData({ ...formData, totalMarks: Number(e.target.value) })}
                className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Status
              </label>
              <select
                value={formData.status}
                onChange={(e) => setFormData({ ...formData, status: e.target.value as any })}
                className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500"
              >
                <option value="published">Published</option>
                <option value="closed">Closed</option>
                <option value="draft">Draft</option>
                <option value="archived">Archived</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
              Description & Rubrics
            </label>
            <textarea
              rows={4}
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              className="w-full px-3.5 py-2.5 bg-slate-950/60 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div className="bg-slate-950/40 p-4 rounded-xl border border-white/5 space-y-2">
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-300">
              Attachment
            </label>
            {formData.attachmentName ? (
              <div className="flex items-center justify-between p-2.5 bg-indigo-950/40 rounded-xl border border-indigo-500/30">
                <div className="flex items-center gap-2 text-xs text-indigo-300 truncate">
                  <FileText className="w-4 h-4 text-indigo-400" />
                  <span className="font-semibold truncate">{formData.attachmentName}</span>
                  <span className="text-slate-400 font-mono">({formData.attachmentSize})</span>
                </div>
                <button
                  type="button"
                  onClick={() =>
                    setFormData({
                      ...formData,
                      attachmentUrl: '',
                      attachmentName: '',
                      attachmentSize: '',
                      attachmentType: ''
                    })
                  }
                  className="text-slate-400 hover:text-rose-400 p-1"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="relative border-2 border-dashed border-white/10 hover:border-indigo-500/40 rounded-xl p-4 text-center cursor-pointer transition-colors">
                <input
                  type="file"
                  onChange={handleFileUpload}
                  className="absolute inset-0 opacity-0 cursor-pointer"
                  disabled={uploadingFile}
                />
                <UploadCloud className="w-6 h-6 text-slate-400 mx-auto mb-1" />
                <p className="text-xs text-slate-300">
                  {uploadingFile ? 'Uploading...' : 'Replace or attach document'}
                </p>
              </div>
            )}
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-white/10">
            <Button
              type="button"
              variant="outline"
              onClick={() => setShowEditModal(false)}
              disabled={saving}
            >
              Cancel
            </Button>
            <Button type="submit" variant="primary" disabled={saving || uploadingFile}>
              {saving ? 'Saving...' : 'Save Changes'}
            </Button>
          </div>
        </form>
      </Modal>

      {/* VIEW MODAL */}
      <Modal
        isOpen={showViewModal}
        onClose={() => setShowViewModal(false)}
        title="Assignment Details"
        maxWidth="max-w-xl"
      >
        {activeItem && (
          <div className="space-y-4 text-sm">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <span className="px-2.5 py-1 rounded-md text-xs font-bold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                {activeItem.subjectName}
              </span>
              <div className="flex items-center gap-2">
                {activeItem.totalMarks && (
                  <span className="px-2.5 py-0.5 rounded text-xs font-bold bg-amber-500/10 text-amber-300 border border-amber-500/20 flex items-center gap-1">
                    <Award className="w-3.5 h-3.5" /> Max {activeItem.totalMarks} Marks
                  </span>
                )}
                <Badge
                  variant={
                    activeItem.status === 'published'
                      ? 'success'
                      : activeItem.status === 'closed'
                      ? 'danger'
                      : 'warning'
                  }
                >
                  {activeItem.status}
                </Badge>
              </div>
            </div>

            <div>
              <h2 className="text-xl font-bold text-white">{activeItem.title}</h2>
              <div className="flex flex-wrap items-center gap-4 text-xs text-slate-400 mt-2">
                <span>Target: <strong className="text-white">{activeItem.className} ({activeItem.sectionName})</strong></span>
                <span>Start: <strong className="text-white">{activeItem.startDate}</strong></span>
                <span>Due Date: <strong className="text-amber-400">{activeItem.dueDate}</strong></span>
              </div>
            </div>

            <div className="bg-slate-950/50 p-4 rounded-xl border border-white/10 space-y-2">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Assignment Brief & Rubrics</span>
              <p className="text-sm text-slate-200 whitespace-pre-wrap leading-relaxed">
                {activeItem.description || 'No detailed instructions provided.'}
              </p>
            </div>

            {activeItem.attachmentName && (
              <div className="bg-indigo-950/30 p-3.5 rounded-xl border border-indigo-500/20 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <FileText className="w-5 h-5 text-indigo-400" />
                  <div>
                    <div className="text-xs font-bold text-white truncate max-w-[280px]">
                      {activeItem.attachmentName}
                    </div>
                    <div className="text-[10px] text-indigo-300 font-mono">
                      {activeItem.attachmentSize || 'Resource Document'} &bull; Verified Attachment
                    </div>
                  </div>
                </div>
                {activeItem.attachmentUrl && (
                  <a
                    href={activeItem.attachmentUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors"
                  >
                    <Download className="w-3.5 h-3.5" />
                    Download
                  </a>
                )}
              </div>
            )}

            <div className="pt-3 border-t border-white/10 flex items-center justify-between text-xs text-slate-500">
              <span>Teacher: {activeItem.teacherName}</span>
              <Button variant="outline" size="sm" onClick={() => setShowViewModal(false)}>
                Close
              </Button>
            </div>
          </div>
        )}
      </Modal>

      {/* DELETE MODAL */}
      <Modal
        isOpen={showDeleteModal}
        onClose={() => !saving && setShowDeleteModal(false)}
        title="Confirm Assignment Deletion"
        maxWidth="max-w-md"
      >
        <div className="space-y-4">
          <div className="flex items-center gap-3 p-3 bg-rose-950/30 rounded-xl border border-rose-500/30 text-rose-300 text-sm">
            <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />
            <p>
              Are you sure you want to delete assignment <strong>{activeItem?.title}</strong>?
            </p>
          </div>

          <div className="flex justify-end gap-3 pt-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => setShowDeleteModal(false)}
              disabled={saving}
            >
              Cancel
            </Button>
            <Button
              type="button"
              variant="danger"
              onClick={handleDeleteSubmit}
              disabled={saving}
            >
              {saving ? 'Deleting...' : 'Delete Permanently'}
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
