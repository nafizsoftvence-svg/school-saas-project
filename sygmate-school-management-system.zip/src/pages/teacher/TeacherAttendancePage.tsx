import React, { useState, useEffect, useMemo } from 'react';
import {
  CheckSquare,
  Calendar,
  Users,
  Search,
  Filter,
  CheckCircle2,
  XCircle,
  Clock,
  AlertCircle,
  Save,
  RotateCcw,
  RefreshCw,
  Edit3,
  CalendarCheck,
  ChevronRight,
  UserCheck,
  Building,
  GraduationCap,
  BookOpen,
  ArrowRight,
  TrendingUp,
  FileText,
  Eye,
  Info,
  ShieldCheck,
  ChevronLeft,
  Sparkles,
  HelpCircle,
  AlertTriangle
} from 'lucide-react';
import { api } from '../../services/api.js';
import { useAuth } from '../../context/AuthContext.js';
import { useSettings } from '../../context/SettingsContext.js';
import {
  TeacherClassInfo,
  TeacherSectionInfo,
  TeacherSubjectBrief,
  AttendanceRecord,
  AttendanceStatus,
  AttendanceSheetData,
  AttendanceSheetStudent,
  AttendanceSummaryStats,
  StudentAttendanceHistoryData,
  StudentLeaveApplication
} from '../../types/index.js';
import { TeacherStudentLeaveReviewTab } from './TeacherStudentLeaveReviewTab.js';

interface TeacherAttendancePageProps {
  onNavigate?: (view: string) => void;
  initialClassId?: string;
  initialSectionId?: string;
  initialStudentId?: string;
  activeTab?: 'mark' | 'history' | 'analytics' | 'student_leaves';
  onTabChange?: (tab: 'mark' | 'history' | 'analytics' | 'student_leaves') => void;
  hideTabBar?: boolean;
}

export const TeacherAttendancePage: React.FC<TeacherAttendancePageProps> = ({
  onNavigate,
  initialClassId,
  initialSectionId,
  initialStudentId,
  activeTab: propActiveTab,
  onTabChange,
  hideTabBar = true
}) => {
  const { user } = useAuth();
  const { settings, activeSession } = useSettings();

  // Active View Tab: 'mark' | 'history' | 'analytics' | 'student_leaves'
  const [internalTab, setInternalTab] = useState<'mark' | 'history' | 'analytics' | 'student_leaves'>('mark');
  const activeTab = propActiveTab || internalTab;

  const setActiveTab = (tab: 'mark' | 'history' | 'analytics' | 'student_leaves') => {
    setInternalTab(tab);
    onTabChange?.(tab);
  };

  // Teacher Context Metadata
  const [classes, setClasses] = useState<TeacherClassInfo[]>([]);
  const [sections, setSections] = useState<TeacherSectionInfo[]>([]);
  const [subjects, setSubjects] = useState<TeacherSubjectBrief[]>([]);
  const [loadingContext, setLoadingContext] = useState(true);

  // Selection for Marking Attendance
  const [selectedClassId, setSelectedClassId] = useState<string>(initialClassId || '');
  const [selectedSectionId, setSelectedSectionId] = useState<string>(initialSectionId || '');
  const [selectedSubjectId, setSelectedSubjectId] = useState<string>('ALL');
  const [selectedDate, setSelectedDate] = useState<string>(() => {
    const today = new Date().toISOString().split('T')[0];
    return today;
  });

  // Sheet State
  const [sheetData, setSheetData] = useState<AttendanceSheetData | null>(null);
  const [studentsRoster, setStudentsRoster] = useState<AttendanceSheetStudent[]>([]);
  const [loadingSheet, setLoadingSheet] = useState(false);
  const [savingAttendance, setSavingAttendance] = useState(false);
  const [editReason, setEditReason] = useState('');
  const [allowOverride, setAllowOverride] = useState(false);
  const [overrideReason, setOverrideReason] = useState('');
  const [targetSubmissionStatus, setTargetSubmissionStatus] = useState<'DRAFT' | 'SUBMITTED'>('SUBMITTED');
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [feedbackMessage, setFeedbackMessage] = useState<{ type: 'success' | 'error' | 'warning'; text: string } | null>(null);

  // History State
  const [historyRecords, setHistoryRecords] = useState<AttendanceRecord[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);
  const [historyFilters, setHistoryFilters] = useState({
    search: '',
    classId: 'ALL',
    sectionId: 'ALL',
    subjectId: 'ALL',
    status: 'ALL' as AttendanceStatus | 'ALL',
    submissionStatus: 'ALL' as 'ALL' | 'DRAFT' | 'SUBMITTED',
    startDate: '',
    endDate: '',
    page: 1,
    limit: 15
  });
  const [historyTotal, setHistoryTotal] = useState(0);
  const [historyTotalPages, setHistoryTotalPages] = useState(1);
  const [historySummary, setHistorySummary] = useState<AttendanceSummaryStats | null>(null);

  // Analytics Summary State
  const [analyticsSummary, setAnalyticsSummary] = useState<AttendanceSummaryStats | null>(null);
  const [analyticsLoading, setAnalyticsLoading] = useState(false);

  // Student Detail Modal
  const [inspectedStudentId, setInspectedStudentId] = useState<string | null>(initialStudentId || null);
  const [studentHistoryData, setStudentHistoryData] = useState<StudentAttendanceHistoryData | null>(null);
  const [loadingStudentHistory, setLoadingStudentHistory] = useState(false);

  // 1. Initial Data Fetch: Assigned Classes & Subjects
  useEffect(() => {
    const fetchTeacherContext = async () => {
      setLoadingContext(true);
      try {
        const [classesRes, subjectsRes] = await Promise.all([
          api.getMyTeacherClasses(),
          api.getMyTeacherSubjects()
        ]);

        const classesList = Array.isArray(classesRes?.data) ? classesRes.data : Array.isArray(classesRes) ? classesRes : [];
        setClasses(classesList);
        if (classesList.length > 0) {
          const defaultClass = initialClassId
            ? classesList.find((c) => c.id === initialClassId) || classesList?.[0]
            : classesList?.[0];
          setSelectedClassId(defaultClass?.id || '');
          const sectionsList = Array.isArray(defaultClass?.sections) ? defaultClass.sections : [];
          setSections(sectionsList);
          if (sectionsList.length > 0) {
            const defaultSec = initialSectionId
              ? sectionsList.find((s) => s.id === initialSectionId) || sectionsList?.[0]
              : sectionsList?.[0];
            setSelectedSectionId(defaultSec?.id || '');
          }
        }

        const subjectsList = Array.isArray(subjectsRes?.data) ? subjectsRes.data : Array.isArray(subjectsRes) ? subjectsRes : [];
        setSubjects(subjectsList);
      } catch (err) {
        console.error('Failed to load teacher context', err);
      } finally {
        setLoadingContext(false);
      }
    };

    fetchTeacherContext();
  }, [initialClassId, initialSectionId]);

  // 2. Update Sections when selectedClassId changes
  useEffect(() => {
    if (!selectedClassId) {
      setSections([]);
      setSelectedSectionId('');
      return;
    }

    const found = (classes || []).find((c) => c?.id === selectedClassId);
    const secs = found?.sections || [];
    setSections(secs);
    if (secs.length > 0) {
      const defaultSec = initialSectionId
        ? secs.find((s) => s.id === initialSectionId) || secs?.[0]
        : secs?.[0];
      setSelectedSectionId(defaultSec?.id || '');
    } else {
      setSelectedSectionId('');
    }
  }, [selectedClassId, classes, initialSectionId]);

  // 3. Load Attendance Sheet when Class, Section, Date, or Subject is chosen
  const loadSheet = async () => {
    if (!selectedClassId || !selectedSectionId) {
      setSheetData(null);
      setStudentsRoster([]);
      return;
    }

    setLoadingSheet(true);
    setFeedbackMessage(null);
    try {
      const res = await api.getAttendanceSheet({
        classId: selectedClassId,
        sectionId: selectedSectionId,
        date: selectedDate,
        subjectId: selectedSubjectId !== 'ALL' ? selectedSubjectId : undefined
      });

      if (res.success && res.data) {
        setSheetData(res.data);
        setStudentsRoster(res.data.students || []);
      } else {
        setFeedbackMessage({
          type: 'error',
          text: res.error || 'Failed to load student roster for selected class.'
        });
      }
    } catch (err: any) {
      setFeedbackMessage({
        type: 'error',
        text: err.message || 'Error communicating with attendance service.'
      });
    } finally {
      setLoadingSheet(false);
    }
  };

  useEffect(() => {
    if (activeTab === 'mark' && selectedClassId && selectedSectionId) {
      loadSheet();
    }
  }, [activeTab, selectedClassId, selectedSectionId, selectedDate, selectedSubjectId]);

  // 4. History Fetcher
  const fetchHistory = async () => {
    setHistoryLoading(true);
    try {
      const res = await api.getAttendanceHistory({
        classId: historyFilters.classId,
        sectionId: historyFilters.sectionId,
        subjectId: historyFilters.subjectId,
        status: historyFilters.status,
        submissionStatus: historyFilters.submissionStatus !== 'ALL' ? historyFilters.submissionStatus : undefined,
        search: historyFilters.search,
        startDate: historyFilters.startDate || undefined,
        endDate: historyFilters.endDate || undefined,
        page: historyFilters.page,
        limit: historyFilters.limit
      });

      if (res.success && res.data) {
        setHistoryRecords(res.data);
        const rawRes = res as any;
        if (rawRes.pagination) {
          setHistoryTotal(rawRes.pagination.total);
          setHistoryTotalPages(rawRes.pagination.totalPages);
        }
        if (rawRes.summary) {
          setHistorySummary(rawRes.summary);
        }
      }
    } catch (err) {
      console.error('Failed to load history', err);
    } finally {
      setHistoryLoading(false);
    }
  };

  useEffect(() => {
    if (activeTab === 'history') {
      fetchHistory();
    }
  }, [activeTab, historyFilters]);

  // 5. Analytics Summary Fetcher
  const fetchAnalytics = async () => {
    setAnalyticsLoading(true);
    try {
      const res = await api.getAttendanceSummary();
      if (res.success && res.data) {
        setAnalyticsSummary(res.data);
      }
    } catch (err) {
      console.error('Failed to load analytics', err);
    } finally {
      setAnalyticsLoading(false);
    }
  };

  useEffect(() => {
    if (activeTab === 'analytics') {
      fetchAnalytics();
    }
  }, [activeTab]);

  // 6. Inspect Student History
  useEffect(() => {
    if (!inspectedStudentId) {
      setStudentHistoryData(null);
      return;
    }

    const loadStudentDetails = async () => {
      setLoadingStudentHistory(true);
      try {
        const res = await api.getStudentAttendanceHistory(inspectedStudentId);
        if (res.success && res.data) {
          setStudentHistoryData(res.data);
        }
      } catch (err) {
        console.error('Failed to inspect student attendance', err);
      } finally {
        setLoadingStudentHistory(false);
      }
    };

    loadStudentDetails();
  }, [inspectedStudentId]);

  // Bulk Status Updaters
  const handleMarkAll = (status: AttendanceStatus) => {
    setStudentsRoster((prev) =>
      prev.map((s) => ({
        ...s,
        status
      }))
    );
  };

  const handleStudentStatusChange = (studentId: string, status: AttendanceStatus) => {
    setStudentsRoster((prev) =>
      prev.map((s) => (s.studentId === studentId ? { ...s, status } : s))
    );
  };

  const handleStudentRemarksChange = (studentId: string, remarks: string) => {
    setStudentsRoster((prev) =>
      prev.map((s) => (s.studentId === studentId ? { ...s, remarks } : s))
    );
  };

  // Compute Live Sheet Stats
  const liveStats = useMemo(() => {
    const total = studentsRoster.length;
    const present = studentsRoster.filter((s) => s.status === 'PRESENT').length;
    const absent = studentsRoster.filter((s) => s.status === 'ABSENT').length;
    const late = studentsRoster.filter((s) => s.status === 'LATE').length;
    const halfDay = studentsRoster.filter((s) => s.status === 'HALF_DAY').length;
    const excused = studentsRoster.filter((s) => s.status === 'EXCUSED' || (s.status as string) === 'LEAVE').length;
    const attendanceRate = total > 0 ? Math.round(((present + late + (halfDay * 0.5)) / total) * 1000) / 10 : 0;
    return { total, present, absent, late, halfDay, excused, attendanceRate };
  }, [studentsRoster]);

  // Submit Handler
  const handleSaveAttendance = async (statusToSubmit?: 'DRAFT' | 'SUBMITTED') => {
    if (!selectedClassId || !selectedSectionId || !selectedDate) {
      setFeedbackMessage({
        type: 'error',
        text: 'Please ensure Class, Section, and Date are selected.'
      });
      return;
    }

    if (studentsRoster.length === 0) {
      setFeedbackMessage({
        type: 'warning',
        text: 'No student records to save for this cohort.'
      });
      return;
    }

    const finalStatus = statusToSubmit || targetSubmissionStatus;

    if (sheetData && !sheetData.isWorkingDay && allowOverride && (!overrideReason || !overrideReason.trim())) {
      setFeedbackMessage({
        type: 'error',
        text: 'An authorized override reason is required to record attendance on holidays or weekends.'
      });
      return;
    }

    setSavingAttendance(true);
    setFeedbackMessage(null);
    setShowConfirmModal(false);

    try {
      const payload = {
        classId: selectedClassId,
        sectionId: selectedSectionId,
        subjectId: selectedSubjectId !== 'ALL' ? selectedSubjectId : undefined,
        date: selectedDate,
        submissionStatus: finalStatus,
        allowOverride,
        overrideReason: allowOverride ? overrideReason.trim() : undefined,
        records: studentsRoster.map((s) => ({
          studentId: s.studentId,
          status: s.status,
          remarks: s.remarks
        })),
        changeReason: sheetData?.isExisting ? editReason || 'Faculty Routine Correction' : undefined
      };

      let res;
      if (sheetData?.isExisting) {
        res = await api.updateAttendance(payload);
      } else {
        res = await api.submitAttendance(payload);
      }

      if (res.success) {
        setFeedbackMessage({
          type: 'success',
          text: res.message || `Attendance records successfully saved as ${finalStatus === 'DRAFT' ? 'Draft' : 'Final'}.`
        });
        setEditReason('');
        setAllowOverride(false);
        setOverrideReason('');
        // Reload fresh sheet
        await loadSheet();
      } else {
        const errorMsg = (res as any).error || 'Failed to submit attendance.';
        setFeedbackMessage({
          type: 'error',
          text: errorMsg
        });
      }
    } catch (err: any) {
      setFeedbackMessage({
        type: 'error',
        text: err.message || 'An unexpected error occurred during submission.'
      });
    } finally {
      setSavingAttendance(false);
    }
  };

  // Helper: Status badge
  const renderStatusBadge = (status: AttendanceStatus | string) => {
    switch (status) {
      case 'PRESENT':
        return (
          <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
            <CheckCircle2 className="w-3.5 h-3.5 mr-1" />
            Present
          </span>
        );
      case 'ABSENT':
        return (
          <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-rose-50 text-rose-700 border border-rose-200">
            <XCircle className="w-3.5 h-3.5 mr-1" />
            Absent
          </span>
        );
      case 'LATE':
        return (
          <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-50 text-amber-700 border border-amber-200">
            <Clock className="w-3.5 h-3.5 mr-1" />
            Late
          </span>
        );
      case 'HALF_DAY':
        return (
          <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-purple-50 text-purple-700 border border-purple-200">
            <Clock className="w-3.5 h-3.5 mr-1" />
            Half Day
          </span>
        );
      case 'EXCUSED':
      case 'LEAVE':
        return (
          <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-sky-50 text-sky-700 border border-sky-200">
            <AlertCircle className="w-3.5 h-3.5 mr-1" />
            Excused
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-slate-100 text-slate-700">
            {status}
          </span>
        );
    }
  };

  const selectedClass = (classes || []).find((c) => c?.id === selectedClassId);
  const selectedSection = (sections || []).find((s) => s?.id === selectedSectionId);

  return (
    <div className="space-y-6 pb-12">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm">
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 rounded-xl bg-indigo-600 flex items-center justify-center text-white shadow-md shadow-indigo-100">
            <CalendarCheck className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-bold text-slate-900">Attendance Management</h1>
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-50 text-indigo-700 border border-indigo-200">
                Teacher Portal
              </span>
            </div>
            <p className="text-sm text-slate-500 mt-0.5">
              Record daily and subject session attendance for assigned classes and analyze cohort participation.
            </p>
          </div>
        </div>

        {/* Tab Toggle Navigation (Hidden when subtabs are hosted in sidebar) */}
        {!hideTabBar && (
          <div className="flex items-center bg-slate-100/80 p-1 rounded-xl border border-slate-200/60 self-start md:self-auto">
            <button
              onClick={() => setActiveTab('mark')}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                activeTab === 'mark'
                  ? 'bg-white text-indigo-700 shadow-sm font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <CheckSquare className="w-4 h-4" />
              <span>Take Attendance</span>
            </button>
            <button
              onClick={() => setActiveTab('history')}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                activeTab === 'history'
                  ? 'bg-white text-indigo-700 shadow-sm font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Clock className="w-4 h-4" />
              <span>Attendance History</span>
            </button>
            <button
              onClick={() => setActiveTab('analytics')}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                activeTab === 'analytics'
                  ? 'bg-white text-indigo-700 shadow-sm font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <TrendingUp className="w-4 h-4" />
              <span>Cohort Analytics</span>
            </button>
            <button
              onClick={() => setActiveTab('student_leaves')}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                activeTab === 'student_leaves'
                  ? 'bg-white text-indigo-700 shadow-sm font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <FileText className="w-4 h-4" />
              <span>Student Leave Requests</span>
            </button>
          </div>
        )}
      </div>

      {/* Global Feedback Banner */}
      {feedbackMessage && (
        <div
          className={`p-4 rounded-xl border flex items-center justify-between animate-fadeIn ${
            feedbackMessage.type === 'success'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
              : feedbackMessage.type === 'warning'
              ? 'bg-amber-50 border-amber-200 text-amber-800'
              : 'bg-rose-50 border-rose-200 text-rose-800'
          }`}
        >
          <div className="flex items-center space-x-3">
            {feedbackMessage.type === 'success' ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-600 flex-shrink-0" />
            ) : feedbackMessage.type === 'warning' ? (
              <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0" />
            ) : (
              <XCircle className="w-5 h-5 text-rose-600 flex-shrink-0" />
            )}
            <span className="text-sm font-medium">{feedbackMessage.text}</span>
          </div>
          <button
            onClick={() => setFeedbackMessage(null)}
            className="text-xs font-semibold hover:underline ml-4"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* =========================================================================
          TAB 1: TAKE / MARK ATTENDANCE
          ========================================================================= */}
      {activeTab === 'mark' && (
        <div className="space-y-6">
          {/* Cohort Selector Card */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm">
            <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 flex-1">
                {/* Class Selection */}
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1.5">
                    Class Cohort <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative">
                    <GraduationCap className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <select
                      value={selectedClassId}
                      onChange={(e) => setSelectedClassId(e.target.value)}
                      disabled={loadingContext || classes.length === 0}
                      className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-medium text-slate-800 focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all disabled:opacity-50"
                    >
                      {classes.length === 0 ? (
                        <option value="">No Assigned Classes</option>
                      ) : (
                        classes.map((c, idx) => (
                          <option key={`${c.id}-${idx}`} value={c.id}>
                            {c.name} ({c.code})
                          </option>
                        ))
                      )}
                    </select>
                  </div>
                </div>

                {/* Section Selection */}
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1.5">
                    Class Section <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative">
                    <Building className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <select
                      value={selectedSectionId}
                      onChange={(e) => setSelectedSectionId(e.target.value)}
                      disabled={sections.length === 0}
                      className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-medium text-slate-800 focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all disabled:opacity-50"
                    >
                      {sections.length === 0 ? (
                        <option value="">No Sections Available</option>
                      ) : (
                        sections.map((s) => (
                          <option key={s.id} value={s.id}>
                            {s.name} (Room {s.roomNumber || 'N/A'})
                          </option>
                        ))
                      )}
                    </select>
                  </div>
                </div>

                {/* Subject Selection (Optional) */}
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1.5">
                    Subject / Period
                  </label>
                  <div className="relative">
                    <BookOpen className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <select
                      value={selectedSubjectId}
                      onChange={(e) => setSelectedSubjectId(e.target.value)}
                      className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-medium text-slate-800 focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all"
                    >
                      <option value="ALL">Daily Class Attendance</option>
                      {(subjects || []).map((sb) => (
                        <option key={sb.id} value={sb.id}>
                          {sb.name} ({sb.code})
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Date Picker */}
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1.5">
                    Session Date <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative">
                    <Calendar className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="date"
                      value={selectedDate}
                      onChange={(e) => setSelectedDate(e.target.value)}
                      max={new Date().toISOString().split('T')[0]}
                      className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-medium text-slate-800 focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all"
                    />
                  </div>
                </div>
              </div>

              {/* Refresh / Reload Button */}
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={loadSheet}
                  disabled={loadingSheet}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium rounded-xl text-sm transition-colors flex items-center gap-2 disabled:opacity-50"
                  title="Reload Roster Sheet"
                >
                  <RefreshCw className={`w-4 h-4 ${loadingSheet ? 'animate-spin' : ''}`} />
                  <span className="hidden sm:inline">Refresh</span>
                </button>
              </div>
            </div>
          </div>

          {/* Calendar Non-Working Day Notice */}
          {sheetData && !sheetData.isWorkingDay && (
            <div className="p-4 rounded-2xl border bg-amber-50 border-amber-300 text-amber-900 flex flex-col gap-3">
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start space-x-3">
                  <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <div className="font-bold text-sm">
                      Academic Calendar Notice: {sheetData.dayType} ({sheetData.nonWorkingReason || 'Scheduled Non-Working Day'})
                    </div>
                    <p className="text-xs text-amber-800 mt-0.5">
                      Standard attendance is not required on this date. If this is a special session, makeup class, or school event, you can authorize and record attendance.
                    </p>
                  </div>
                </div>
                <label className="flex items-center space-x-2 text-xs font-semibold text-amber-900 cursor-pointer bg-white px-3 py-1.5 rounded-xl border border-amber-300 shadow-xs flex-shrink-0">
                  <input
                    type="checkbox"
                    checked={allowOverride}
                    onChange={(e) => setAllowOverride(e.target.checked)}
                    className="rounded text-indigo-600 focus:ring-indigo-500"
                  />
                  <span>Authorize Session</span>
                </label>
              </div>

              {allowOverride && (
                <div className="pt-2 border-t border-amber-200">
                  <label className="block text-xs font-semibold text-amber-900 mb-1">
                    Justification / Override Reason <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    placeholder="e.g., Saturday makeup lecture, extra examination prep, annual sports rehearsal..."
                    value={overrideReason}
                    onChange={(e) => setOverrideReason(e.target.value)}
                    className="w-full text-xs px-3 py-2 bg-white border border-amber-300 rounded-xl focus:ring-2 focus:ring-indigo-500 text-slate-800"
                  />
                </div>
              )}
            </div>
          )}

          {/* Session Status Banner */}
          {sheetData && (
            <div
              className={`p-4 rounded-2xl border flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                sheetData.isExisting
                  ? 'bg-amber-50/70 border-amber-200/80 text-amber-900'
                  : 'bg-indigo-50/70 border-indigo-200/80 text-indigo-900'
              }`}
            >
              <div className="flex items-center space-x-3">
                <div
                  className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                    sheetData.isExisting ? 'bg-amber-100 text-amber-700' : 'bg-indigo-100 text-indigo-700'
                  }`}
                >
                  {sheetData.isExisting ? <Edit3 className="w-5 h-5" /> : <Sparkles className="w-5 h-5" />}
                </div>
                <div>
                  <div className="flex items-center gap-2 font-semibold text-sm">
                    <span>
                      {sheetData.isExisting
                        ? `Attendance Already Recorded (${sheetData.submissionStatus === 'DRAFT' ? 'Draft Mode' : 'Correction Mode'})`
                        : 'New Attendance Session'}
                    </span>
                    <span
                      className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                        sheetData.isExisting
                          ? 'bg-amber-200/70 text-amber-800'
                          : 'bg-indigo-200/70 text-indigo-800'
                      }`}
                    >
                      {selectedDate}
                    </span>
                    {sheetData.submissionStatus === 'DRAFT' && (
                      <span className="text-xs px-2 py-0.5 rounded-full font-semibold bg-amber-100 text-amber-800 border border-amber-300">
                        Draft
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-600 mt-0.5">
                    {sheetData.isExisting
                      ? `Originally submitted by ${sheetData.recordedByTeacherName || 'Faculty'}. Any changes will be audited.`
                      : 'Students have been defaulted to Present. Adjust individual statuses and save.'}
                  </p>
                </div>
              </div>

              {/* Quick Preset Buttons */}
              <div className="flex items-center gap-1.5 sm:gap-2 self-end sm:self-auto flex-wrap">
                <button
                  type="button"
                  onClick={() => handleMarkAll('PRESENT')}
                  className="px-2.5 py-1.5 text-xs font-semibold rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs transition-colors flex items-center gap-1"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  All Present
                </button>
                <button
                  type="button"
                  onClick={() => handleMarkAll('ABSENT')}
                  className="px-2.5 py-1.5 text-xs font-semibold rounded-lg bg-rose-600 hover:bg-rose-700 text-white shadow-xs transition-colors flex items-center gap-1"
                >
                  <XCircle className="w-3.5 h-3.5" />
                  All Absent
                </button>
                <button
                  type="button"
                  onClick={() => handleMarkAll('HALF_DAY')}
                  className="px-2.5 py-1.5 text-xs font-semibold rounded-lg bg-purple-600 hover:bg-purple-700 text-white shadow-xs transition-colors flex items-center gap-1"
                >
                  <Clock className="w-3.5 h-3.5" />
                  All Half Day
                </button>
                <button
                  type="button"
                  onClick={() => handleMarkAll('LATE')}
                  className="px-2.5 py-1.5 text-xs font-semibold rounded-lg bg-amber-600 hover:bg-amber-700 text-white shadow-xs transition-colors flex items-center gap-1"
                >
                  <Clock className="w-3.5 h-3.5" />
                  All Late
                </button>
              </div>
            </div>
          )}

          {/* Live Roster Metrics Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-7 gap-3">
            <div className="bg-white p-3.5 rounded-2xl border border-slate-200/80 shadow-xs">
              <div className="text-xs font-medium text-slate-500">Total Enrolled</div>
              <div className="text-2xl font-bold text-slate-900 mt-1">{liveStats.total}</div>
              <div className="text-xs text-slate-400 mt-0.5">Students in cohort</div>
            </div>
            <div className="bg-emerald-50/60 p-3.5 rounded-2xl border border-emerald-100 shadow-xs">
              <div className="text-xs font-semibold text-emerald-700 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> Present
              </div>
              <div className="text-2xl font-bold text-emerald-800 mt-1">{liveStats.present}</div>
              <div className="text-xs text-emerald-600 mt-0.5">
                {liveStats.total > 0 ? Math.round((liveStats.present / liveStats.total) * 100) : 0}% of class
              </div>
            </div>
            <div className="bg-rose-50/60 p-3.5 rounded-2xl border border-rose-100 shadow-xs">
              <div className="text-xs font-semibold text-rose-700 flex items-center gap-1">
                <XCircle className="w-3.5 h-3.5" /> Absent
              </div>
              <div className="text-2xl font-bold text-rose-800 mt-1">{liveStats.absent}</div>
              <div className="text-xs text-rose-600 mt-0.5">
                {liveStats.total > 0 ? Math.round((liveStats.absent / liveStats.total) * 100) : 0}% of class
              </div>
            </div>
            <div className="bg-purple-50/60 p-3.5 rounded-2xl border border-purple-100 shadow-xs">
              <div className="text-xs font-semibold text-purple-700 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5" /> Half Day
              </div>
              <div className="text-2xl font-bold text-purple-800 mt-1">{liveStats.halfDay}</div>
              <div className="text-xs text-purple-600 mt-0.5">0.5 weight</div>
            </div>
            <div className="bg-amber-50/60 p-3.5 rounded-2xl border border-amber-100 shadow-xs">
              <div className="text-xs font-semibold text-amber-700 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5" /> Late
              </div>
              <div className="text-2xl font-bold text-amber-800 mt-1">{liveStats.late}</div>
              <div className="text-xs text-amber-600 mt-0.5">Tardy arrival</div>
            </div>
            <div className="bg-sky-50/60 p-3.5 rounded-2xl border border-sky-100 shadow-xs">
              <div className="text-xs font-semibold text-sky-700 flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5" /> Excused
              </div>
              <div className="text-2xl font-bold text-sky-800 mt-1">{liveStats.excused}</div>
              <div className="text-xs text-sky-600 mt-0.5">Authorized leave</div>
            </div>
            <div className="bg-indigo-50/60 p-3.5 rounded-2xl border border-indigo-100 shadow-xs">
              <div className="text-xs font-semibold text-indigo-700 flex items-center gap-1">
                <TrendingUp className="w-3.5 h-3.5" /> Rate
              </div>
              <div className="text-2xl font-bold text-indigo-900 mt-1">{liveStats.attendanceRate}%</div>
              <div className="text-xs text-indigo-600 mt-0.5">Present+Late+0.5H</div>
            </div>
          </div>

          {/* Student Roster Table */}
          <div className="bg-white rounded-2xl border border-slate-200/80 shadow-sm overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-slate-800 text-base">
                  Student Roster ({selectedClass?.name || 'Class'} - {selectedSection?.name || 'Section'})
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Click a status button for each student or enter specific remarks where needed.
                </p>
              </div>
              <div className="text-xs font-medium text-slate-500">
                Sorted by Roll Number
              </div>
            </div>

            {loadingSheet ? (
              <div className="py-20 flex flex-col items-center justify-center">
                <RefreshCw className="w-8 h-8 text-indigo-600 animate-spin mb-3" />
                <p className="text-sm font-medium text-slate-600">Loading student attendance sheet...</p>
              </div>
            ) : studentsRoster.length === 0 ? (
              <div className="py-16 text-center px-4">
                <Users className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                <h4 className="text-base font-semibold text-slate-800">No Enrolled Students Found</h4>
                <p className="text-sm text-slate-500 max-w-md mx-auto mt-1">
                  There are currently no active students registered in this class and section.
                </p>
              </div>
            ) : (
              <div className="divide-y divide-slate-100">
                {(studentsRoster || []).map((student, idx) => (
                  <div
                    key={student.studentId}
                    className={`p-4 sm:px-6 flex flex-col lg:flex-row lg:items-center justify-between gap-4 transition-colors ${
                      student.status === 'ABSENT'
                        ? 'bg-rose-50/30'
                        : student.status === 'LATE'
                        ? 'bg-amber-50/20'
                        : student.status === 'EXCUSED'
                        ? 'bg-sky-50/20'
                        : 'hover:bg-slate-50/80'
                    }`}
                  >
                    {/* Student Info */}
                    <div className="flex items-center space-x-3.5 min-w-[260px]">
                      <div className="w-8 text-center text-xs font-bold text-slate-400">
                        #{idx + 1}
                      </div>
                      <div className="w-10 h-10 rounded-full bg-slate-100 border border-slate-200 overflow-hidden flex items-center justify-center flex-shrink-0 text-slate-600 font-bold text-sm">
                        {student.avatarUrl ? (
                          <img
                            src={student.avatarUrl}
                            alt={student.fullName}
                            className="w-full h-full object-cover"
                            referrerPolicy="no-referrer"
                          />
                        ) : (
                          `${student.firstName?.[0] || ''}${student.lastName?.[0] || ''}` || 'S'
                        )}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-slate-900 text-sm">
                            {student.fullName}
                          </span>
                          <button
                            type="button"
                            onClick={() => setInspectedStudentId(student.studentId)}
                            className="text-xs text-indigo-600 hover:text-indigo-800 hover:underline flex items-center gap-0.5"
                            title="View Student Attendance Log"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                        </div>
                        <div className="flex items-center gap-2 text-xs text-slate-500 mt-0.5">
                          <span className="font-mono bg-slate-100 px-1.5 py-0.5 rounded text-slate-700 font-medium">
                            {student.rollNumber || 'No Roll'}
                          </span>
                          <span>•</span>
                          <span className="font-mono text-slate-500">{student.admissionNumber}</span>
                        </div>
                      </div>
                    </div>

                    {/* Fast Status Toggles */}
                    <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap">
                      {/* Present */}
                      <button
                        type="button"
                        onClick={() => handleStudentStatusChange(student.studentId, 'PRESENT')}
                        className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 ${
                          student.status === 'PRESENT'
                            ? 'bg-emerald-600 text-white shadow-xs ring-2 ring-emerald-600/30'
                            : 'bg-slate-100 text-slate-600 hover:bg-emerald-50 hover:text-emerald-700'
                        }`}
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Present</span>
                      </button>

                      {/* Absent */}
                      <button
                        type="button"
                        onClick={() => handleStudentStatusChange(student.studentId, 'ABSENT')}
                        className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 ${
                          student.status === 'ABSENT'
                            ? 'bg-rose-600 text-white shadow-xs ring-2 ring-rose-600/30'
                            : 'bg-slate-100 text-slate-600 hover:bg-rose-50 hover:text-rose-700'
                        }`}
                      >
                        <XCircle className="w-3.5 h-3.5" />
                        <span>Absent</span>
                      </button>

                      {/* Late */}
                      <button
                        type="button"
                        onClick={() => handleStudentStatusChange(student.studentId, 'LATE')}
                        className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 ${
                          student.status === 'LATE'
                            ? 'bg-amber-500 text-white shadow-xs ring-2 ring-amber-500/30'
                            : 'bg-slate-100 text-slate-600 hover:bg-amber-50 hover:text-amber-700'
                        }`}
                      >
                        <Clock className="w-3.5 h-3.5" />
                        <span>Late</span>
                      </button>

                      {/* Half Day */}
                      <button
                        type="button"
                        onClick={() => handleStudentStatusChange(student.studentId, 'HALF_DAY')}
                        className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 ${
                          student.status === 'HALF_DAY'
                            ? 'bg-purple-600 text-white shadow-xs ring-2 ring-purple-600/30'
                            : 'bg-slate-100 text-slate-600 hover:bg-purple-50 hover:text-purple-700'
                        }`}
                      >
                        <Clock className="w-3.5 h-3.5" />
                        <span>Half Day</span>
                      </button>

                      {/* Excused / Leave */}
                      <button
                        type="button"
                        onClick={() => handleStudentStatusChange(student.studentId, 'EXCUSED')}
                        className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 ${
                          student.status === 'EXCUSED' || (student.status as string) === 'LEAVE'
                            ? 'bg-sky-600 text-white shadow-xs ring-2 ring-sky-600/30'
                            : 'bg-slate-100 text-slate-600 hover:bg-sky-50 hover:text-sky-700'
                        }`}
                      >
                        <AlertCircle className="w-3.5 h-3.5" />
                        <span>Excused</span>
                      </button>
                    </div>

                    {/* Remarks Input */}
                    <div className="w-full lg:w-64">
                      <input
                        type="text"
                        placeholder="Optional remarks (e.g. medical slip, late bus)..."
                        value={student.remarks || ''}
                        onChange={(e) => handleStudentRemarksChange(student.studentId, e.target.value)}
                        className="w-full text-xs px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 focus:bg-white focus:ring-1 focus:ring-indigo-500 placeholder:text-slate-400"
                      />
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Submission Actions Footer */}
            {studentsRoster.length > 0 && (
              <div className="p-6 bg-slate-50/80 border-t border-slate-200 flex flex-col md:flex-row items-center justify-between gap-4">
                {sheetData?.isExisting ? (
                  <div className="w-full md:w-1/2">
                    <label className="block text-xs font-semibold text-slate-600 mb-1">
                      Reason for Correction / Adjustment (Required for Audit Trail)
                    </label>
                    <input
                      type="text"
                      placeholder="e.g., Medical certificate submitted, corrected accidental absent mark..."
                      value={editReason}
                      onChange={(e) => setEditReason(e.target.value)}
                      className="w-full text-xs px-3.5 py-2 bg-white border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 text-slate-800"
                    />
                  </div>
                ) : (
                  <div className="flex items-center space-x-2 text-xs text-slate-500">
                    <ShieldCheck className="w-4 h-4 text-emerald-600" />
                    <span>Submission will be recorded under your faculty ID ({user?.name}).</span>
                  </div>
                )}

                <div className="flex items-center space-x-3 w-full md:w-auto justify-end">
                  <button
                    type="button"
                    onClick={loadSheet}
                    className="px-4 py-2.5 bg-white border border-slate-300 hover:bg-slate-100 text-slate-700 text-sm font-semibold rounded-xl transition-colors"
                  >
                    Reset Changes
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setTargetSubmissionStatus('DRAFT');
                      handleSaveAttendance('DRAFT');
                    }}
                    disabled={savingAttendance}
                    className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-sm font-semibold rounded-xl transition-colors disabled:opacity-50 flex items-center space-x-1.5"
                  >
                    <Save className="w-4 h-4 text-slate-500" />
                    <span>Save as Draft</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setTargetSubmissionStatus('SUBMITTED');
                      setShowConfirmModal(true);
                    }}
                    disabled={savingAttendance}
                    className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-semibold rounded-xl shadow-sm transition-all flex items-center space-x-2 disabled:opacity-50"
                  >
                    <CheckSquare className="w-4 h-4" />
                    <span>
                      {sheetData?.isExisting ? 'Update Final Attendance' : 'Submit Final Attendance'}
                    </span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* =========================================================================
          TAB 2: ATTENDANCE HISTORY & REPORTS
          ========================================================================= */}
      {activeTab === 'history' && (
        <div className="space-y-6">
          {/* Filter Bar */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center space-x-2">
                <Filter className="w-5 h-5 text-indigo-600" />
                <h3 className="font-bold text-slate-800 text-base">Filter Attendance History</h3>
              </div>
              <button
                type="button"
                onClick={() => {
                  setHistoryFilters({
                    search: '',
                    classId: 'ALL',
                    sectionId: 'ALL',
                    subjectId: 'ALL',
                    status: 'ALL',
                    submissionStatus: 'ALL',
                    startDate: '',
                    endDate: '',
                    page: 1,
                    limit: 15
                  });
                }}
                className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Reset Filters
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
              {/* Search */}
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">Student Search</label>
                <div className="relative">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    placeholder="Name, Roll No, Adm No..."
                    value={historyFilters.search}
                    onChange={(e) =>
                      setHistoryFilters((prev) => ({ ...prev, search: e.target.value, page: 1 }))
                    }
                    className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-800 focus:bg-white focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>

              {/* Class Filter */}
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">Class</label>
                <select
                  value={historyFilters.classId}
                  onChange={(e) =>
                    setHistoryFilters((prev) => ({ ...prev, classId: e.target.value, page: 1 }))
                  }
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-800 focus:bg-white focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="ALL">All Authorized Classes</option>
                  {(classes || []).map((c, idx) => (
                    <option key={`${c.id}-${idx}`} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Status Filter */}
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">Status</label>
                <select
                  value={historyFilters.status}
                  onChange={(e) =>
                    setHistoryFilters((prev) => ({ ...prev, status: e.target.value as any, page: 1 }))
                  }
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-800 focus:bg-white focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="ALL">All Statuses</option>
                  <option value="PRESENT">Present</option>
                  <option value="ABSENT">Absent</option>
                  <option value="LATE">Late</option>
                  <option value="HALF_DAY">Half Day</option>
                  <option value="EXCUSED">Excused / Leave</option>
                </select>
              </div>

              {/* Submission Status */}
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">Workflow Status</label>
                <select
                  value={historyFilters.submissionStatus}
                  onChange={(e) =>
                    setHistoryFilters((prev) => ({ ...prev, submissionStatus: e.target.value as any, page: 1 }))
                  }
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-800 focus:bg-white focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="ALL">All Workflows</option>
                  <option value="SUBMITTED">Submitted / Final</option>
                  <option value="DRAFT">Draft Only</option>
                </select>
              </div>

              {/* Start Date */}
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">From Date</label>
                <input
                  type="date"
                  value={historyFilters.startDate}
                  onChange={(e) =>
                    setHistoryFilters((prev) => ({ ...prev, startDate: e.target.value, page: 1 }))
                  }
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-800 focus:bg-white focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>
          </div>

          {/* History Statistics Cards */}
          {historySummary && (
            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
              <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
                <div className="text-xs text-slate-500 font-medium">Filtered Records</div>
                <div className="text-xl font-bold text-slate-900 mt-1">{historySummary.totalRecords}</div>
              </div>
              <div className="bg-emerald-50 p-4 rounded-xl border border-emerald-100 shadow-xs">
                <div className="text-xs text-emerald-700 font-medium">Present</div>
                <div className="text-xl font-bold text-emerald-800 mt-1">{historySummary.presentCount}</div>
              </div>
              <div className="bg-rose-50 p-4 rounded-xl border border-rose-100 shadow-xs">
                <div className="text-xs text-rose-700 font-medium">Absent</div>
                <div className="text-xl font-bold text-rose-800 mt-1">{historySummary.absentCount}</div>
              </div>
              <div className="bg-purple-50 p-4 rounded-xl border border-purple-100 shadow-xs">
                <div className="text-xs text-purple-700 font-medium">Half Day</div>
                <div className="text-xl font-bold text-purple-800 mt-1">{historySummary.halfDayCount || 0}</div>
              </div>
              <div className="bg-amber-50 p-4 rounded-xl border border-amber-100 shadow-xs">
                <div className="text-xs text-amber-700 font-medium">Late</div>
                <div className="text-xl font-bold text-amber-800 mt-1">{historySummary.lateCount}</div>
              </div>
              <div className="bg-sky-50 p-4 rounded-xl border border-sky-100 shadow-xs">
                <div className="text-xs text-sky-700 font-medium">Excused</div>
                <div className="text-xl font-bold text-sky-800 mt-1">{historySummary.excusedCount}</div>
              </div>
              <div className="bg-indigo-50 p-4 rounded-xl border border-indigo-100 shadow-xs">
                <div className="text-xs text-indigo-700 font-medium">Attendance Rate</div>
                <div className="text-xl font-bold text-indigo-900 mt-1">
                  {historySummary?.attendancePercentage ?? 0}%
                </div>
              </div>
            </div>
          )}

          {/* History Records Table */}
          <div className="bg-white rounded-2xl border border-slate-200/80 shadow-sm overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
              <h4 className="font-bold text-slate-800 text-sm">Attendance Logs</h4>
              <span className="text-xs text-slate-500">
                Showing {historyRecords.length} of {historyTotal} records
              </span>
            </div>

            {historyLoading ? (
              <div className="py-20 flex flex-col items-center justify-center">
                <RefreshCw className="w-8 h-8 text-indigo-600 animate-spin mb-3" />
                <p className="text-sm font-medium text-slate-600">Loading attendance history...</p>
              </div>
            ) : historyRecords.length === 0 ? (
              <div className="py-16 text-center px-4">
                <Clock className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                <h4 className="text-base font-semibold text-slate-800">No Attendance Records Found</h4>
                <p className="text-sm text-slate-500 max-w-md mx-auto mt-1">
                  No attendance entries match the chosen filters or date range.
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead className="bg-slate-50 text-xs font-semibold uppercase text-slate-500 border-b border-slate-200/60">
                    <tr>
                      <th className="px-6 py-3.5">Date</th>
                      <th className="px-6 py-3.5">Student</th>
                      <th className="px-6 py-3.5">Class & Section</th>
                      <th className="px-6 py-3.5">Subject</th>
                      <th className="px-6 py-3.5">Status</th>
                      <th className="px-6 py-3.5">Remarks</th>
                      <th className="px-6 py-3.5">Recorded By</th>
                      <th className="px-6 py-3.5 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {(historyRecords || []).map((rec) => (
                      <tr key={rec.id} className="hover:bg-slate-50/70 transition-colors">
                        <td className="px-6 py-4 font-mono text-xs font-medium text-slate-700 whitespace-nowrap">
                          {rec.date}
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center space-x-2.5">
                            <div className="w-7 h-7 rounded-full bg-slate-100 text-slate-700 font-bold text-xs flex items-center justify-center">
                              {rec?.studentName ? rec.studentName[0] : 'S'}
                            </div>
                            <div>
                              <div className="font-semibold text-slate-900 text-xs">
                                {rec.studentName}
                              </div>
                              <div className="text-[11px] text-slate-400 font-mono">
                                {rec.rollNumber} • {rec.admissionNumber}
                              </div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-xs font-medium text-slate-800">{rec.className}</div>
                          <div className="text-[11px] text-slate-500">{rec.sectionName}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-xs text-slate-600">
                          {rec.subjectName || 'Daily Attendance'}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          {renderStatusBadge(rec.status)}
                        </td>
                        <td className="px-6 py-4 text-xs text-slate-500 max-w-xs truncate">
                          {rec.remarks || <span className="text-slate-300 italic">—</span>}
                        </td>
                        <td className="px-6 py-4 text-xs text-slate-600 whitespace-nowrap">
                          <div>{rec.recordedByTeacherName}</div>
                          {rec.updatedByTeacherName && (
                            <div className="text-[10px] text-slate-400">
                              Updated by {rec.updatedByTeacherName}
                            </div>
                          )}
                        </td>
                        <td className="px-6 py-4 text-right whitespace-nowrap">
                          <button
                            type="button"
                            onClick={() => setInspectedStudentId(rec.studentId)}
                            className="px-2.5 py-1 text-xs font-semibold text-indigo-600 hover:text-indigo-800 bg-indigo-50 hover:bg-indigo-100 rounded-lg transition-colors inline-flex items-center gap-1"
                          >
                            <Eye className="w-3 h-3" />
                            History
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {/* Pagination Controls */}
            {historyTotalPages > 1 && (
              <div className="px-6 py-4 bg-slate-50/70 border-t border-slate-200 flex items-center justify-between">
                <div className="text-xs text-slate-500">
                  Page <span className="font-semibold text-slate-800">{historyFilters.page}</span> of{' '}
                  <span className="font-semibold text-slate-800">{historyTotalPages}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <button
                    type="button"
                    onClick={() =>
                      setHistoryFilters((prev) => ({ ...prev, page: Math.max(1, prev.page - 1) }))
                    }
                    disabled={historyFilters.page <= 1}
                    className="p-2 border border-slate-300 rounded-lg text-slate-600 hover:bg-white disabled:opacity-40 transition-colors"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      setHistoryFilters((prev) => ({
                        ...prev,
                        page: Math.min(historyTotalPages, prev.page + 1)
                      }))
                    }
                    disabled={historyFilters.page >= historyTotalPages}
                    className="p-2 border border-slate-300 rounded-lg text-slate-600 hover:bg-white disabled:opacity-40 transition-colors"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* =========================================================================
          TAB 3: COHORT ANALYTICS & BREAKDOWN
          ========================================================================= */}
      {activeTab === 'analytics' && (
        <div className="space-y-6">
          {analyticsLoading ? (
            <div className="py-20 flex flex-col items-center justify-center">
              <RefreshCw className="w-8 h-8 text-indigo-600 animate-spin mb-3" />
              <p className="text-sm font-medium text-slate-600">Calculating cohort analytics...</p>
            </div>
          ) : analyticsSummary ? (
            <>
              {/* Overall KPIs */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm">
                  <div className="flex items-center justify-between text-slate-500 mb-2">
                    <span className="text-xs font-semibold uppercase tracking-wider">Total Recorded Sessions</span>
                    <Calendar className="w-5 h-5 text-indigo-600" />
                  </div>
                  <div className="text-3xl font-bold text-slate-900">{analyticsSummary.totalRecords}</div>
                  <p className="text-xs text-slate-500 mt-1">Across all authorized cohorts</p>
                </div>

                <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm">
                  <div className="flex items-center justify-between text-emerald-600 mb-2">
                    <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                      Present Rate
                    </span>
                    <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                  </div>
                  <div className="text-3xl font-bold text-emerald-700">
                    {analyticsSummary?.attendancePercentage ?? 0}%
                  </div>
                  <p className="text-xs text-emerald-600 mt-1">
                    {analyticsSummary?.presentCount ?? 0} present, {analyticsSummary?.halfDayCount || 0} half-day, {analyticsSummary?.lateCount ?? 0} late
                  </p>
                </div>

                <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm">
                  <div className="flex items-center justify-between text-rose-600 mb-2">
                    <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                      Absent Rate
                    </span>
                    <XCircle className="w-5 h-5 text-rose-600" />
                  </div>
                  <div className="text-3xl font-bold text-rose-700">
                    {analyticsSummary.totalRecords > 0
                      ? Math.round((analyticsSummary.absentCount / analyticsSummary.totalRecords) * 1000) / 10
                      : 0}
                    %
                  </div>
                  <p className="text-xs text-rose-600 mt-1">
                    {analyticsSummary.absentCount} total unexcused absences
                  </p>
                </div>

                <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm">
                  <div className="flex items-center justify-between text-sky-600 mb-2">
                    <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                      Excused / Leave
                    </span>
                    <AlertCircle className="w-5 h-5 text-sky-600" />
                  </div>
                  <div className="text-3xl font-bold text-sky-700">{analyticsSummary.excusedCount}</div>
                  <p className="text-xs text-sky-600 mt-1">Official leaves approved</p>
                </div>
              </div>

              {/* Class by Class Breakdown */}
              <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm">
                <h3 className="text-base font-bold text-slate-900 mb-4">
                  Class & Section Attendance Breakdown
                </h3>
                <div className="space-y-4">
                  {((analyticsSummary?.classBreakdown?.length || 0) > 0) ? (
                    (analyticsSummary?.classBreakdown || []).map((item, idx) => (
                      <div
                        key={`${item.classId}-${item.sectionId}-${idx}`}
                        className="p-4 rounded-xl bg-slate-50 border border-slate-200/60 flex flex-col md:flex-row md:items-center justify-between gap-4"
                      >
                        <div className="min-w-[200px]">
                          <h4 className="font-bold text-slate-900 text-sm">{item.className}</h4>
                          <p className="text-xs text-slate-500">{item.sectionName}</p>
                        </div>

                        {/* Progress Bar */}
                        <div className="flex-1 max-w-md">
                          <div className="flex items-center justify-between text-xs font-semibold mb-1">
                            <span className="text-slate-700">Participation Rate</span>
                            <span className="text-indigo-600">{item.rate}%</span>
                          </div>
                          <div className="w-full bg-slate-200 rounded-full h-2.5 overflow-hidden">
                            <div
                              className="bg-indigo-600 h-2.5 rounded-full transition-all duration-500"
                              style={{ width: `${Math.min(100, item.rate)}%` }}
                            />
                          </div>
                        </div>

                        {/* Counts */}
                        <div className="flex items-center gap-4 text-xs">
                          <div>
                            <span className="text-slate-400">Total:</span>{' '}
                            <span className="font-bold text-slate-800">{item.total}</span>
                          </div>
                          <div>
                            <span className="text-emerald-600 font-medium">Present:</span>{' '}
                            <span className="font-bold text-emerald-700">{item.present}</span>
                          </div>
                          <div>
                            <span className="text-rose-600 font-medium">Absent:</span>{' '}
                            <span className="font-bold text-rose-700">{item.absent}</span>
                          </div>
                        </div>
                      </div>
                    ))
                  ) : (
                    <p className="text-xs text-slate-500 italic">
                      No cohort breakdown data available yet.
                    </p>
                  )}
                </div>
              </div>
            </>
          ) : (
            <div className="py-16 text-center">
              <p className="text-sm text-slate-500">No analytics data available.</p>
            </div>
          )}
        </div>
      )}

      {/* =========================================================================
          TAB 4: STUDENT LEAVE REQUESTS
          ========================================================================= */}
      {activeTab === 'student_leaves' && (
        <TeacherStudentLeaveReviewTab />
      )}

      {/* =========================================================================
          CONFIRMATION MODAL BEFORE SAVING ATTENDANCE
          ========================================================================= */}
      {showConfirmModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fadeIn">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-100 space-y-4">
            <div className="w-12 h-12 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center mx-auto">
              <CalendarCheck className="w-6 h-6" />
            </div>

            <div className="text-center">
              <h3 className="text-lg font-bold text-slate-900">
                {sheetData?.isExisting ? 'Confirm Attendance Update' : 'Confirm Attendance Submission'}
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                You are about to record the attendance for{' '}
                <span className="font-semibold text-slate-800">{selectedClass?.name}</span> (
                {selectedSection?.name}) on <span className="font-semibold text-slate-800">{selectedDate}</span>.
              </p>
            </div>

            {/* Summary Box */}
            <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 text-xs space-y-1.5">
              <div className="flex justify-between">
                <span className="text-slate-500">Total Students:</span>
                <span className="font-bold text-slate-800">{liveStats.total}</span>
              </div>
              <div className="flex justify-between text-emerald-700">
                <span>Present:</span>
                <span className="font-bold">{liveStats.present}</span>
              </div>
              <div className="flex justify-between text-rose-700">
                <span>Absent:</span>
                <span className="font-bold">{liveStats.absent}</span>
              </div>
              <div className="flex justify-between text-amber-700">
                <span>Late:</span>
                <span className="font-bold">{liveStats.late}</span>
              </div>
              <div className="flex justify-between text-purple-700">
                <span>Half Day:</span>
                <span className="font-bold">{liveStats.halfDay}</span>
              </div>
              <div className="flex justify-between text-sky-700">
                <span>Excused:</span>
                <span className="font-bold">{liveStats.excused}</span>
              </div>
            </div>

            <div className="flex items-center space-x-3 pt-2">
              <button
                type="button"
                onClick={() => setShowConfirmModal(false)}
                className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold transition-colors"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSaveAttendance}
                disabled={savingAttendance}
                className="flex-1 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold transition-colors shadow-sm disabled:opacity-50"
              >
                {savingAttendance ? 'Saving...' : 'Yes, Confirm & Save'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          INDIVIDUAL STUDENT ATTENDANCE HISTORY MODAL
          ========================================================================= */}
      {inspectedStudentId && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fadeIn">
          <div className="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-2xl border border-slate-100 space-y-4 max-h-[90vh] flex flex-col">
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-full bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold text-sm">
                  {studentHistoryData?.student
                    ? `${studentHistoryData.student.firstName?.[0] || ''}${studentHistoryData.student.lastName?.[0] || ''}` || 'S'
                    : 'S'}
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900">
                    {studentHistoryData?.student?.firstName} {studentHistoryData?.student?.lastName}
                  </h3>
                  <p className="text-xs text-slate-500">
                    Roll: {studentHistoryData?.student?.rollNumber} • Adm: {studentHistoryData?.student?.admissionNumber} • {studentHistoryData?.student?.className} ({studentHistoryData?.student?.sectionName})
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setInspectedStudentId(null)}
                className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-100"
              >
                <XCircle className="w-5 h-5" />
              </button>
            </div>

            {loadingStudentHistory ? (
              <div className="py-16 flex flex-col items-center justify-center">
                <RefreshCw className="w-6 h-6 text-indigo-600 animate-spin mb-2" />
                <p className="text-xs text-slate-500">Loading student attendance log...</p>
              </div>
            ) : studentHistoryData ? (
              <div className="space-y-4 overflow-y-auto flex-1 pr-1">
                {/* Stats Header */}
                <div className="grid grid-cols-3 sm:grid-cols-5 gap-2 text-center">
                  <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                    <div className="text-[10px] text-slate-500 uppercase font-bold">Total</div>
                    <div className="text-base font-bold text-slate-800">
                      {studentHistoryData.stats.totalSessions}
                    </div>
                  </div>
                  <div className="bg-emerald-50 p-2.5 rounded-xl border border-emerald-100">
                    <div className="text-[10px] text-emerald-700 uppercase font-bold">Present</div>
                    <div className="text-base font-bold text-emerald-800">
                      {studentHistoryData.stats.present}
                    </div>
                  </div>
                  <div className="bg-rose-50 p-2.5 rounded-xl border border-rose-100">
                    <div className="text-[10px] text-rose-700 uppercase font-bold">Absent</div>
                    <div className="text-base font-bold text-rose-800">
                      {studentHistoryData.stats.absent}
                    </div>
                  </div>
                  <div className="bg-amber-50 p-2.5 rounded-xl border border-amber-100">
                    <div className="text-[10px] text-amber-700 uppercase font-bold">Late</div>
                    <div className="text-base font-bold text-amber-800">
                      {studentHistoryData.stats.late}
                    </div>
                  </div>
                  <div className="bg-indigo-50 p-2.5 rounded-xl border border-indigo-100">
                    <div className="text-[10px] text-indigo-700 uppercase font-bold">Rate</div>
                    <div className="text-base font-bold text-indigo-900">
                      {studentHistoryData.stats.percentage}%
                    </div>
                  </div>
                </div>

                {/* Date-wise Log List */}
                <div className="space-y-2">
                  <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                    Date-Wise Attendance History
                  </h4>
                  {(studentHistoryData?.records?.length || 0) === 0 ? (
                    <p className="text-xs text-slate-500 py-6 text-center italic">
                      No attendance records logged yet for this student.
                    </p>
                  ) : (
                    <div className="divide-y divide-slate-100 border border-slate-200 rounded-xl overflow-hidden">
                      {(studentHistoryData.records || []).map((r) => (
                        <div
                          key={r.id}
                          className="p-3 bg-white flex items-center justify-between text-xs hover:bg-slate-50"
                        >
                          <div className="flex items-center space-x-3">
                            <span className="font-mono font-medium text-slate-700">{r.date}</span>
                            <span className="text-slate-400">•</span>
                            <span className="text-slate-600">{r.subjectName || 'Daily Attendance'}</span>
                          </div>
                          <div className="flex items-center space-x-3">
                            {r.remarks && (
                              <span className="text-[11px] text-slate-400 italic max-w-xs truncate">
                                "{r.remarks}"
                              </span>
                            )}
                            {renderStatusBadge(r.status)}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ) : null}

            <div className="pt-2 border-t border-slate-100 text-right">
              <button
                type="button"
                onClick={() => setInspectedStudentId(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
