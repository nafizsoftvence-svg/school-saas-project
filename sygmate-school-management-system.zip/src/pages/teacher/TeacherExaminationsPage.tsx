import React, { useState, useEffect } from 'react';
import {
  CalendarDays,
  Search,
  Filter,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Award,
  BookOpen,
  GraduationCap,
  Sparkles,
  Layers,
  ArrowRight,
  FileCheck2,
  ShieldCheck,
  RefreshCw,
  Eye,
  Edit3
} from 'lucide-react';
import { api } from '../../services/api.js';
import { useToast } from '../../context/ToastContext.js';
import { useSettings } from '../../context/SettingsContext.js';
import { TeacherAssignedExamSubject, ExamMarksSubmissionStatus } from '../../types/index.js';
import { TeacherMarksEntrySheet } from '../../components/examinations/TeacherMarksEntrySheet.js';

export const TeacherExaminationsPage: React.FC = () => {
  const { addToast } = useToast();
  const { activeSession } = useSettings();

  const [loading, setLoading] = useState<boolean>(true);
  const [assignedSubjects, setAssignedSubjects] = useState<TeacherAssignedExamSubject[]>([]);

  // Filtering states
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [classFilter, setClassFilter] = useState<string>('ALL');
  const [sessionFilter, setSessionFilter] = useState<string>('ALL');

  // Selected subject for marks sheet view
  const [selectedSubject, setSelectedSubject] = useState<{
    examId: string;
    subjectId: string;
  } | null>(null);

  const fetchAssignedSubjects = async () => {
    try {
      setLoading(true);
      const res = await api.examinations.getTeacherAssignedSubjects();
      if (res.data) {
        setAssignedSubjects(res.data);
      }
    } catch (err: any) {
      addToast({
        type: 'error',
        title: 'Error Loading Examinations',
        message: err.message || 'Failed to retrieve assigned exam subjects.'
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAssignedSubjects();
  }, []);

  // Filter options
  const uniqueClasses = Array.from(new Set(assignedSubjects.map((s) => s.className))).filter(Boolean);
  const uniqueSessions = Array.from(new Set(assignedSubjects.map((s) => s.academicSessionName))).filter(Boolean);

  const filteredSubjects = assignedSubjects.filter((item) => {
    // Search
    const q = (searchTerm || '').toLowerCase();
    const matchSearch =
      (item.examName || '').toLowerCase().includes(q) ||
      (item.subjectName || '').toLowerCase().includes(q) ||
      (item.subjectCode || '').toLowerCase().includes(q) ||
      (item.className || '').toLowerCase().includes(q);

    if (!matchSearch) return false;

    // Status filter
    if (statusFilter !== 'ALL' && item.submissionStatus !== statusFilter) {
      return false;
    }

    // Class filter
    if (classFilter !== 'ALL' && item.className !== classFilter) {
      return false;
    }

    // Session filter
    if (sessionFilter !== 'ALL' && item.academicSessionName !== sessionFilter) {
      return false;
    }

    return true;
  });

  // KPI counters
  const totalCount = assignedSubjects.length;
  const notStartedCount = assignedSubjects.filter((s) => s.submissionStatus === 'not_started').length;
  const draftCount = assignedSubjects.filter((s) => s.submissionStatus === 'draft' || s.submissionStatus === 'in_progress').length;
  const submittedCount = assignedSubjects.filter((s) => s.submissionStatus === 'submitted').length;
  const returnedCount = assignedSubjects.filter((s) => s.submissionStatus === 'returned').length;
  const approvedCount = assignedSubjects.filter((s) => s.submissionStatus === 'approved').length;

  if (selectedSubject) {
    return (
      <TeacherMarksEntrySheet
        examId={selectedSubject.examId}
        subjectId={selectedSubject.subjectId}
        onBack={() => setSelectedSubject(null)}
        onRefreshParent={() => fetchAssignedSubjects()}
      />
    );
  }

  return (
    <div className="space-y-8 animate-fade-in pb-12">
      {/* Top Banner */}
      <div className="rounded-3xl bg-white border border-slate-200 p-8 shadow-2xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 border border-blue-200 text-blue-700 text-xs font-bold mb-3 tracking-wide uppercase">
              <GraduationCap className="w-3.5 h-3.5 text-blue-600" />
              <span>Teacher Portal • Part 6C Assessments</span>
            </div>
            <h1 className="text-2xl md:text-3xl font-black text-slate-900 tracking-tight">
              Examinations &amp; Marks Entry
            </h1>
            <p className="text-sm text-slate-600 max-w-2xl mt-1">
              View your assigned examinations, record individual student scores with live validation, save drafts, and submit marks directly for administrative approval.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={fetchAssignedSubjects}
              disabled={loading}
              className="px-4 py-2.5 rounded-2xl bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 shadow-2xs text-xs font-semibold flex items-center gap-2 transition cursor-pointer"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
              <span>Refresh Roster</span>
            </button>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <div className="p-4 rounded-3xl bg-white border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Assigned Subjects</span>
            <BookOpen className="w-4 h-4 text-blue-600" />
          </div>
          <p className="text-2xl font-black text-slate-900 mt-2">{totalCount}</p>
          <span className="text-[10px] text-slate-500 mt-0.5 block">Active exam papers</span>
        </div>

        <div className="p-4 rounded-3xl bg-white border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Not Started</span>
            <Clock className="w-4 h-4 text-slate-400" />
          </div>
          <p className="text-2xl font-black text-slate-700 mt-2">{notStartedCount}</p>
          <span className="text-[10px] text-slate-500 mt-0.5 block">Pending first entry</span>
        </div>

        <div className="p-4 rounded-3xl bg-white border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Draft In-Progress</span>
            <Edit3 className="w-4 h-4 text-amber-600" />
          </div>
          <p className="text-2xl font-black text-amber-700 mt-2">{draftCount}</p>
          <span className="text-[10px] text-slate-500 mt-0.5 block">Partially entered</span>
        </div>

        <div className="p-4 rounded-3xl bg-white border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Submitted</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <p className="text-2xl font-black text-emerald-700 mt-2">{submittedCount}</p>
          <span className="text-[10px] text-slate-500 mt-0.5 block">Forwarded to admin</span>
        </div>

        <div className="p-4 rounded-3xl bg-white border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Correction Needed</span>
            <AlertTriangle className="w-4 h-4 text-rose-600" />
          </div>
          <p className="text-2xl font-black text-rose-700 mt-2">{returnedCount}</p>
          <span className="text-[10px] text-slate-500 mt-0.5 block">Returned by admin</span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-slate-900/60 rounded-3xl p-4 border border-white/10 backdrop-blur-2xl shadow-xl flex flex-wrap items-center justify-between gap-4">
        <div className="relative flex-1 min-w-[240px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by exam name, subject, or class..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-950/60 text-white placeholder-slate-500 pl-9 pr-4 py-2.5 rounded-2xl text-xs border border-white/10 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 transition"
          />
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          {/* Status Filter */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-slate-950/60 text-slate-200 px-3 py-2.5 rounded-2xl text-xs border border-white/10 focus:border-indigo-500 focus:outline-none transition cursor-pointer"
          >
            <option value="ALL">All Submission Statuses</option>
            <option value="not_started">Not Started</option>
            <option value="draft">Draft In-Progress</option>
            <option value="submitted">Submitted</option>
            <option value="returned">Correction Requested</option>
            <option value="approved">Approved</option>
          </select>

          {/* Class Filter */}
          {uniqueClasses.length > 0 && (
            <select
              value={classFilter}
              onChange={(e) => setClassFilter(e.target.value)}
              className="bg-slate-950/60 text-slate-200 px-3 py-2.5 rounded-2xl text-xs border border-white/10 focus:border-indigo-500 focus:outline-none transition cursor-pointer"
            >
              <option value="ALL">All Classes</option>
              {(uniqueClasses || []).map((cls) => (
                <option key={cls} value={cls}>
                  Class {cls}
                </option>
              ))}
            </select>
          )}

          {/* Session Filter */}
          {uniqueSessions.length > 0 && (
            <select
              value={sessionFilter}
              onChange={(e) => setSessionFilter(e.target.value)}
              className="bg-slate-950/60 text-slate-200 px-3 py-2.5 rounded-2xl text-xs border border-white/10 focus:border-indigo-500 focus:outline-none transition cursor-pointer"
            >
              <option value="ALL">All Sessions</option>
              {(uniqueSessions || []).map((sess) => (
                <option key={sess} value={sess}>
                  {sess}
                </option>
              ))}
            </select>
          )}
        </div>
      </div>

      {/* Exam Subjects Grid */}
      {loading ? (
        <div className="flex flex-col items-center justify-center min-h-[300px] p-8 text-center bg-slate-950/40 rounded-3xl border border-white/10">
          <div className="w-10 h-10 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin mb-3" />
          <p className="text-sm font-semibold text-slate-300">Loading Assigned Examinations...</p>
        </div>
      ) : filteredSubjects.length === 0 ? (
        <div className="flex flex-col items-center justify-center min-h-[300px] p-8 text-center bg-slate-900/40 rounded-3xl border border-white/10">
          <CalendarDays className="w-12 h-12 text-slate-600 mb-3" />
          <h3 className="text-base font-bold text-white">No Assigned Exam Subjects Found</h3>
          <p className="text-xs text-slate-400 mt-1 max-w-md">
            {searchTerm || statusFilter !== 'ALL'
              ? 'Try changing your search keywords or filter criteria.'
              : 'You do not have any examination subjects currently assigned for marks entry.'}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {(filteredSubjects || []).map((item) => {
            const completionPercent = item.totalStudents > 0 ? Math.round((item.enteredCount / item.totalStudents) * 100) : 0;
            const isCompleted = item.totalStudents > 0 && item.enteredCount === item.totalStudents;

            return (
              <div
                key={`${item.examId}-${item.subjectId}`}
                className="group relative bg-slate-900/60 hover:bg-slate-900/80 rounded-3xl p-6 border border-white/10 hover:border-indigo-500/40 backdrop-blur-xl transition-all duration-200 flex flex-col justify-between shadow-xl"
              >
                <div>
                  {/* Top Bar: Class Badge & Status */}
                  <div className="flex items-center justify-between gap-2 mb-4">
                    <div className="flex items-center gap-2">
                      <span className="px-2.5 py-1 rounded-xl bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 text-xs font-bold font-mono">
                        Class {item.className}
                      </span>
                      <span className="text-[11px] text-slate-400">
                        {item.sectionName || 'All'}
                      </span>
                    </div>

                    <span
                      className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider border ${
                        item.submissionStatus === 'submitted'
                          ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30'
                          : item.submissionStatus === 'approved'
                          ? 'bg-purple-500/10 text-purple-300 border-purple-500/30'
                          : item.submissionStatus === 'returned'
                          ? 'bg-rose-500/10 text-rose-300 border-rose-500/30 animate-pulse'
                          : item.submissionStatus === 'draft' || item.submissionStatus === 'in_progress'
                          ? 'bg-amber-500/10 text-amber-300 border-amber-500/30'
                          : 'bg-slate-800 text-slate-400 border-slate-700'
                      }`}
                    >
                      {item.submissionStatus === 'not_started'
                        ? 'Not Started'
                        : item.submissionStatus === 'draft' || item.submissionStatus === 'in_progress'
                        ? 'Draft'
                        : item.submissionStatus === 'submitted'
                        ? 'Submitted'
                        : item.submissionStatus === 'returned'
                        ? 'Correction'
                        : 'Approved'}
                    </span>
                  </div>

                  {/* Subject Title & Code */}
                  <div className="mb-4">
                    <div className="flex items-center gap-2">
                      <h3 className="text-base font-bold text-white group-hover:text-indigo-300 transition-colors">
                        {item.subjectName}
                      </h3>
                      {item.subjectCode && (
                        <span className="px-1.5 py-0.5 rounded bg-white/5 text-slate-400 border border-white/10 text-[10px] font-mono">
                          {item.subjectCode}
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-400 mt-0.5">
                      {item.examName} ({item.academicSessionName})
                    </p>
                  </div>

                  {/* Exam Schedule Meta */}
                  <div className="grid grid-cols-2 gap-2 p-3 rounded-2xl bg-white/[0.02] border border-white/5 text-xs mb-4">
                    <div>
                      <span className="text-[10px] text-slate-500 uppercase font-semibold block">Date & Time</span>
                      <span className="font-semibold text-slate-200">{item.examDate || 'TBD'}</span>
                      <span className="text-[10px] text-slate-400 block">{item.startTime || '09:00 AM'}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500 uppercase font-semibold block">Marks Weight</span>
                      <span className="font-semibold text-white">Full: {item.fullMarks}</span>
                      <span className="text-[10px] text-amber-400 block">Pass: {item.passMarks}</span>
                    </div>
                  </div>

                  {/* Returned notice if applicable */}
                  {item.submissionStatus === 'returned' && item.returnedReason && (
                    <div className="p-2.5 rounded-xl bg-rose-500/10 border border-rose-500/20 text-xs text-rose-300 mb-4 flex items-start gap-2">
                      <AlertTriangle className="w-4 h-4 flex-shrink-0 text-rose-400 mt-0.5" />
                      <p className="text-[11px] leading-tight">
                        <strong>Reason:</strong> {item.returnedReason}
                      </p>
                    </div>
                  )}

                  {/* Student Entry Progress */}
                  <div className="space-y-1.5 mb-6">
                    <div className="flex justify-between text-xs">
                      <span className="text-slate-400">Marks Progress</span>
                      <span className="font-mono font-bold text-white">
                        {item.enteredCount} / {item.totalStudents} ({completionPercent}%)
                      </span>
                    </div>
                    <div className="w-full bg-slate-950 rounded-full h-2 overflow-hidden border border-white/5">
                      <div
                        className={`h-full rounded-full transition-all duration-300 ${
                          isCompleted
                            ? 'bg-emerald-500'
                            : completionPercent > 0
                            ? 'bg-indigo-500'
                            : 'bg-slate-700'
                        }`}
                        style={{ width: `${completionPercent}%` }}
                      />
                    </div>
                  </div>
                </div>

                {/* Card Action Button */}
                <button
                  onClick={() => setSelectedSubject({ examId: item.examId, subjectId: item.subjectId })}
                  className={`w-full py-2.5 px-4 rounded-2xl text-xs font-bold flex items-center justify-center gap-2 transition cursor-pointer ${
                    item.submissionStatus === 'submitted' || item.submissionStatus === 'approved'
                      ? 'bg-white/5 hover:bg-white/10 text-slate-200 border border-white/10'
                      : item.submissionStatus === 'returned'
                      ? 'bg-rose-600 hover:bg-rose-500 text-white shadow-lg shadow-rose-600/30'
                      : item.submissionStatus === 'draft' || item.submissionStatus === 'in_progress'
                      ? 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-600/30'
                      : 'bg-white/10 hover:bg-white/15 text-white border border-white/15'
                  }`}
                >
                  {item.submissionStatus === 'submitted' || item.submissionStatus === 'approved' ? (
                    <>
                      <Eye className="w-4 h-4 text-emerald-400" />
                      <span>View Submitted Marksheet</span>
                    </>
                  ) : item.submissionStatus === 'returned' ? (
                    <>
                      <Edit3 className="w-4 h-4" />
                      <span>Correct & Re-Submit Marks</span>
                    </>
                  ) : item.submissionStatus === 'draft' || item.submissionStatus === 'in_progress' ? (
                    <>
                      <Edit3 className="w-4 h-4" />
                      <span>Continue Draft Entry</span>
                    </>
                  ) : (
                    <>
                      <Edit3 className="w-4 h-4" />
                      <span>Start Marks Entry</span>
                    </>
                  )}
                  <ArrowRight className="w-4 h-4 ml-auto" />
                </button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
