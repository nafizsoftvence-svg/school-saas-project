import React, { useEffect, useState } from 'react';
import {
  GraduationCap,
  BookOpen,
  Users,
  Calendar,
  Clock,
  Sparkles,
  ArrowRight,
  CheckCircle2,
  Bell,
  Check,
  CheckCheck,
  Building,
  User,
  ShieldAlert,
  Layers,
  CheckSquare,
  BookCheck,
  FileSpreadsheet,
  FolderGit2,
  Megaphone,
  CalendarDays,
  CalendarCheck,
  Mail
} from 'lucide-react';
import { Button } from '../../components/ui/Button.js';
import { Badge } from '../../components/ui/Badge.js';
import { api } from '../../services/api.js';
import { TeacherDashboardData, NotificationItem } from '../../types/index.js';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner.js';
import { useToast } from '../../context/ToastContext.js';

interface TeacherDashboardProps {
  onNavigate: (viewId: string) => void;
}

export const TeacherDashboard: React.FC<TeacherDashboardProps> = ({ onNavigate }) => {
  const [data, setData] = useState<TeacherDashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const { showToast } = useToast();

  const loadData = async () => {
    try {
      setLoading(true);
      const res = await api.getTeacherDashboard();
      if (res.success && res.data) {
        setData(res.data);
      }
    } catch (err) {
      console.error('Failed to load teacher dashboard', err);
      showToast('Could not load teacher dashboard metrics', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleMarkNotifRead = async (id: string) => {
    try {
      await api.markNotificationAsRead(id);
      setData((prev) => {
        if (!prev) return null;
        return {
          ...prev,
          recentNotifications: (prev.recentNotifications || []).map((n) =>
            n.id === id ? { ...n, isRead: true } : n
          )
        };
      });
      showToast('Notification marked as read', 'info');
    } catch (err) {
      console.error('Failed to mark read', err);
    }
  };

  const handleMarkAllNotifsRead = async () => {
    try {
      await api.markAllNotificationsAsRead();
      setData((prev) => {
        if (!prev) return null;
        return {
          ...prev,
          recentNotifications: (prev.recentNotifications || []).map((n) => ({ ...n, isRead: true }))
        };
      });
      showToast('All notifications marked as read', 'success');
    } catch (err) {
      console.error('Failed to mark all read', err);
    }
  };

  if (loading) {
    return (
      <div className="py-24 flex justify-center">
        <LoadingSpinner size="lg" message="Loading teacher portal workspace..." />
      </div>
    );
  }

  const teacher = data?.teacher;
  const metrics = data?.metrics;
  const initials = `${teacher?.firstName?.[0] || 'T'}${teacher?.lastName?.[0] || 'P'}`;
  const unreadNotifs = (data?.recentNotifications || []).filter((n) => !n.isRead);

  return (
    <div className="space-y-8">
      {/* Top Banner / Welcome Card */}
      <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-2xs relative overflow-hidden flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-center gap-5 z-10">
          {/* Avatar photo / initials */}
          <div
            onClick={() => onNavigate('teacher-profile')}
            className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl overflow-hidden bg-blue-600 border border-blue-700 text-white flex items-center justify-center font-bold text-2xl shadow-xs flex-shrink-0 cursor-pointer hover:opacity-95 transition-all group"
            title="Click to view & edit profile"
          >
            {teacher?.avatarUrl ? (
              <img
                src={teacher.avatarUrl}
                alt="Teacher Profile"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                referrerPolicy="no-referrer"
              />
            ) : (
              <span>{initials}</span>
            )}
          </div>

          <div className="space-y-1">
            <div className="flex items-center gap-2 text-blue-700 text-xs font-bold uppercase tracking-wider">
              <Sparkles className="w-3.5 h-3.5 text-blue-600" />
              <span>Teacher Portal Workspace</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
              Welcome back, {teacher?.firstName} {teacher?.lastName}
            </h2>
            <p className="text-xs text-slate-500">
              Department: <strong className="text-slate-700">{teacher?.department || 'Natural & Applied Sciences'}</strong> • Designation: <strong className="text-slate-700">{teacher?.designation || 'Senior Lecturer'}</strong>
            </p>
          </div>
        </div>

        {/* Quick Action Navigation */}
        <div className="flex flex-wrap items-center gap-2.5 z-10">
          <Button
            size="sm"
            variant="outline"
            leftIcon={<CalendarDays className="w-4 h-4 text-blue-600" />}
            onClick={() => onNavigate('teacher-examinations')}
          >
            Examinations &amp; Marks
          </Button>
          <Button
            size="sm"
            variant="outline"
            leftIcon={<GraduationCap className="w-4 h-4 text-blue-600" />}
            onClick={() => onNavigate('teacher-classes')}
          >
            My Classes
          </Button>
          <Button
            size="sm"
            variant="outline"
            leftIcon={<CalendarCheck className="w-4 h-4 text-emerald-600" />}
            onClick={() => onNavigate('teacher-my-attendance')}
          >
            My Attendance
          </Button>
          <Button
            size="sm"
            variant="outline"
            leftIcon={<CheckSquare className="w-4 h-4 text-emerald-600" />}
            onClick={() => onNavigate('teacher-attendance')}
          >
            Student Attendance
          </Button>
          <Button
            size="sm"
            variant="outline"
            leftIcon={<BookCheck className="w-4 h-4 text-blue-600" />}
            onClick={() => onNavigate('teacher-homework')}
          >
            Homework
          </Button>
          <Button
            size="sm"
            variant="outline"
            leftIcon={<FileSpreadsheet className="w-4 h-4 text-amber-600" />}
            onClick={() => onNavigate('teacher-assignments')}
          >
            Assignments
          </Button>
          <Button
            size="sm"
            variant="outline"
            leftIcon={<FolderGit2 className="w-4 h-4 text-blue-600" />}
            onClick={() => onNavigate('teacher-materials')}
          >
            Study Materials
          </Button>
          <Button
            size="sm"
            variant="outline"
            leftIcon={<Megaphone className="w-4 h-4 text-rose-600" />}
            onClick={() => onNavigate('teacher-announcements')}
          >
            Announcements
          </Button>
          <Button
            id="teacher-dash-inbox-btn"
            size="sm"
            variant="outline"
            leftIcon={<Mail className="w-4 h-4 text-blue-600" />}
            onClick={() => onNavigate('teacher-inbox')}
          >
            Messages &amp; Parent Chat
          </Button>
          <Button
            size="sm"
            variant="primary"
            leftIcon={<User className="w-4 h-4" />}
            onClick={() => onNavigate('teacher-profile')}
          >
            My Profile
          </Button>
        </div>
      </div>

      {/* 4 Real Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {/* Total Assigned Classes */}
        <div
          onClick={() => onNavigate('teacher-classes')}
          className="bg-white border border-slate-200 hover:border-blue-400 p-6 rounded-2xl shadow-2xs hover:shadow-xs relative group transition-all cursor-pointer"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Assigned Classes</span>
            <GraduationCap className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-3xl font-black text-slate-900">
            {metrics?.totalAssignedClasses ?? metrics?.myClassesCount ?? 0}
          </div>
          <div className="mt-2 text-[10px] text-blue-600 font-bold tracking-wider uppercase">
            Curriculum Cohorts →
          </div>
        </div>

        {/* Total Assigned Sections */}
        <div
          onClick={() => onNavigate('teacher-classes')}
          className="bg-white border border-slate-200 hover:border-blue-400 p-6 rounded-2xl shadow-2xs hover:shadow-xs relative group transition-all cursor-pointer"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Assigned Sections</span>
            <Layers className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-3xl font-black text-slate-900">
            {metrics?.totalAssignedSections ?? 0}
          </div>
          <div className="mt-2 text-[10px] text-emerald-600 font-bold tracking-wider uppercase">
            Active Classrooms →
          </div>
        </div>

        {/* Total Assigned Subjects */}
        <div
          onClick={() => onNavigate('teacher-subjects')}
          className="bg-white border border-slate-200 hover:border-blue-400 p-6 rounded-2xl shadow-2xs hover:shadow-xs relative group transition-all cursor-pointer"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Assigned Subjects</span>
            <BookOpen className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-3xl font-black text-slate-900">
            {metrics?.totalAssignedSubjects ?? metrics?.mySubjectsCount ?? 0}
          </div>
          <div className="mt-2 text-[10px] text-blue-600 font-bold tracking-wider uppercase">
            Academic Courses →
          </div>
        </div>

        {/* Total Students Under Assigned Classes */}
        <div
          onClick={() => onNavigate('teacher-students')}
          className="bg-white border border-slate-200 hover:border-blue-400 p-6 rounded-2xl shadow-2xs hover:shadow-xs relative group transition-all cursor-pointer"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Total Enrolled Students</span>
            <Users className="w-4 h-4 text-slate-700" />
          </div>
          <div className="text-3xl font-black text-slate-900">
            {metrics?.totalStudentsUnderClasses ?? metrics?.totalStudentsTaught ?? 0}
          </div>
          <div className="mt-2 text-[10px] text-slate-600 font-bold tracking-wider uppercase">
            Students in My Classes →
          </div>
        </div>
      </div>

      {/* Main Grid: Today's Classes & Assigned Class Sections */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Assigned Classes & Today's Activities */}
        <div className="lg:col-span-2 space-y-6">
          {/* Today's Classes / Activities */}
          <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-2xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-blue-600" />
                <h3 className="text-base font-bold text-slate-900">Today's Lectures &amp; Activities</h3>
              </div>
              <span className="text-xs text-slate-500 font-medium">
                {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' })}
              </span>
            </div>

            {(data?.todayClasses?.length || 0) > 0 ? (
              <div className="space-y-3">
                {(data.todayClasses || []).map((item) => (
                  <div
                    key={item.id}
                    className="p-4 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between hover:border-blue-300 transition-colors"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <h4 className="font-bold text-slate-900 text-sm">{item.subjectName}</h4>
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-blue-100 text-blue-800 font-semibold">
                          {item.subjectCode}
                        </span>
                      </div>
                      <p className="text-xs text-slate-500">
                        {item.className} • Section {item.sectionName} • Room {item.roomNumber}
                      </p>
                    </div>
                    <div className="text-right">
                      <span className="text-xs font-mono font-bold text-blue-700">{item.timeSlot}</span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-8 text-center bg-slate-50 border border-dashed border-slate-200 rounded-2xl space-y-2">
                <Clock className="w-8 h-8 text-slate-400 mx-auto" />
                <p className="text-sm font-semibold text-slate-700">No Scheduled Lectures Today</p>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  You have no scheduled class periods or exam invigilations for today. Enjoy your preparation time!
                </p>
              </div>
            )}
          </div>

          {/* Assigned Class Sections */}
          <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-2xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div className="flex items-center gap-2">
                <GraduationCap className="w-4 h-4 text-blue-600" />
                <h3 className="text-base font-bold text-slate-900">Assigned Classes &amp; Sections</h3>
              </div>
              <button
                onClick={() => onNavigate('teacher-classes')}
                className="text-xs text-blue-700 hover:text-blue-900 flex items-center gap-1 font-semibold cursor-pointer"
              >
                <span>View all rosters</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {(data?.assignedClasses?.length || 0) > 0 ? (
                (data.assignedClasses || []).map((item, idx) => (
                  <div
                    key={`${item.id}-${idx}`}
                    className="p-5 bg-slate-50 rounded-2xl border border-slate-200 space-y-3 hover:border-blue-300 transition-all flex flex-col justify-between"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <h4 className="text-base font-bold text-slate-900">{item.className}</h4>
                        <p className="text-xs text-slate-500">
                          Section {item.sectionName} • Room {item.roomNumber}
                        </p>
                      </div>
                      <Badge variant="primary">{item.studentCount} Students</Badge>
                    </div>

                    <div className="flex items-center justify-between pt-3 border-t border-slate-200 text-xs">
                      <span className="text-[11px] text-slate-500">Enrolled Roster</span>
                      <Button size="xs" variant="outline" onClick={() => onNavigate('teacher-classes')}>
                        Open Class Roster
                      </Button>
                    </div>
                  </div>
                ))
              ) : (
                <div className="col-span-2 p-8 text-center text-xs text-slate-500 bg-slate-50 rounded-2xl">
                  No classes currently assigned to your profile.
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right 1 Col: Recent Notifications & Quick Profile Card */}
        <div className="space-y-6">
          {/* Notifications Card */}
          <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-2xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div className="flex items-center gap-2">
                <Bell className="w-4 h-4 text-blue-600" />
                <h3 className="text-sm font-bold text-slate-900">Recent Notifications</h3>
              </div>
              {(unreadNotifs?.length || 0) > 0 && (
                <button
                  onClick={() => handleMarkAllNotifsRead()}
                  className="text-[11px] text-blue-700 hover:text-blue-900 font-semibold flex items-center gap-1 cursor-pointer"
                >
                  <CheckCheck className="w-3.5 h-3.5" />
                  Mark all read
                </button>
              )}
            </div>

            <div className="space-y-3">
              {(data?.recentNotifications?.length || 0) > 0 ? (
                (data.recentNotifications || []).map((notif) => (
                  <div
                    key={notif.id}
                    className={`p-3 rounded-2xl border transition-all ${
                      notif.isRead
                        ? 'bg-slate-50 border-slate-200 opacity-80'
                        : 'bg-blue-50/70 border-blue-200'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-blue-600" />
                        <h5 className="text-xs font-bold text-slate-900">{notif.title}</h5>
                      </div>
                      {!notif.isRead && (
                        <button
                          onClick={() => handleMarkNotifRead(notif.id)}
                          className="text-blue-700 hover:text-blue-900 text-[10px] flex items-center gap-0.5 cursor-pointer"
                          title="Mark read"
                        >
                          <Check className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                    <p className="text-[11px] text-slate-600 mt-1 leading-relaxed">{notif.message}</p>
                    <span className="text-[9px] text-slate-400 font-mono mt-1.5 block">
                      {new Date(notif.createdAt).toLocaleDateString()} at {new Date(notif.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                ))
              ) : (
                <div className="p-6 text-center text-xs text-slate-500 bg-slate-50 rounded-2xl">
                  No notifications at this moment.
                </div>
              )}
            </div>
          </div>

          {/* Quick Profile Summary Card */}
          <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-2xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <User className="w-4 h-4 text-blue-600" />
                <span>My Faculty Profile</span>
              </h3>
              <Badge variant="primary">Verified</Badge>
            </div>

            <div className="space-y-2.5 text-xs">
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500">Employee Code:</span>
                <span className="text-slate-900 font-mono font-semibold">{teacher?.employeeCode || 'EMP-T-1004'}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500">Primary Contact:</span>
                <span className="text-slate-900 font-mono">{teacher?.phone || '+1 (555) 234-5678'}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500">Institutional Email:</span>
                <span className="text-blue-700 font-mono truncate max-w-[150px]">{teacher?.email}</span>
              </div>
            </div>

            <Button
              size="xs"
              variant="outline"
              className="w-full mt-2"
              onClick={() => onNavigate('teacher-profile')}
            >
              Edit Profile &amp; Photo
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};
