import React, { useState, useEffect, useMemo } from 'react';
import {
  Calendar,
  Clock,
  CheckCircle2,
  XCircle,
  AlertCircle,
  FileText,
  Filter,
  Search,
  RefreshCw,
  Eye,
  Check,
  X,
  AlertTriangle,
  Paperclip,
  User,
  GraduationCap,
  ChevronRight,
  ShieldCheck,
  Sparkles
} from 'lucide-react';
import { api } from '../../services/api.js';
import { useAuth } from '../../context/AuthContext.js';
import { Modal } from '../../components/ui/Modal.js';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner.js';
import { LeaveApplication, LeaveStatus } from '../../types/index.js';

interface TeacherStudentLeaveReviewTabProps {
  onLeaveActionTaken?: () => void;
}

export const TeacherStudentLeaveReviewTab: React.FC<TeacherStudentLeaveReviewTabProps> = ({ onLeaveActionTaken }) => {
  const { user } = useAuth();

  const [loading, setLoading] = useState(false);
  const [applications, setApplications] = useState<LeaveApplication[]>([]);
  const [statusFilter, setStatusFilter] = useState<string>('SUBMITTED');
  const [searchQuery, setSearchQuery] = useState('');

  // Toast / Feedback message
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error' | 'warning'; message: string } | null>(null);

  // Detail Modal
  const [selectedApp, setSelectedApp] = useState<LeaveApplication | null>(null);
  const [detailModalOpen, setDetailModalOpen] = useState(false);

  // Approval Modal
  const [approveModalOpen, setApproveModalOpen] = useState(false);
  const [targetApp, setTargetApp] = useState<LeaveApplication | null>(null);
  const [adminRemarks, setAdminRemarks] = useState('');
  const [processing, setProcessing] = useState(false);

  // Rejection Modal
  const [rejectModalOpen, setRejectModalOpen] = useState(false);
  const [rejectionReason, setRejectionReason] = useState('');

  const showToast = (type: 'success' | 'error' | 'warning', message: string) => {
    setFeedback({ type, message });
    setTimeout(() => {
      setFeedback(null);
    }, 5000);
  };

  const fetchApplications = async () => {
    setLoading(true);
    try {
      const res = await api.getLeaveApplications({
        applicantType: 'STUDENT'
      });
      if (res && res.success && res.data) {
        setApplications(res.data);
      }
    } catch (err: any) {
      showToast('error', err.message || 'Failed to fetch student leave applications');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchApplications();
  }, []);

  const handleMarkUnderReview = async (app: LeaveApplication) => {
    try {
      const res = await api.reviewLeaveApplication(app.id, {
        status: 'UNDER_REVIEW',
        adminRemarks: 'Application taken under review by class teacher'
      });
      if (res && res.success) {
        showToast('success', 'Application marked as under review');
        await fetchApplications();
        if (onLeaveActionTaken) onLeaveActionTaken();
      } else {
        showToast('error', res.error || 'Failed to update status');
      }
    } catch (e: any) {
      showToast('error', e.message || 'Action failed');
    }
  };

  const handleOpenApproveModal = (app: LeaveApplication) => {
    setTargetApp(app);
    setAdminRemarks('Approved by teacher. Attendance updated automatically to LEAVE for working dates.');
    setApproveModalOpen(true);
  };

  const handleConfirmApprove = async () => {
    if (!targetApp) return;
    setProcessing(true);
    try {
      const res = await api.reviewLeaveApplication(targetApp.id, {
        status: 'APPROVED',
        adminRemarks: adminRemarks.trim()
      });
      if (res && res.success) {
        showToast('success', 'Student leave approved! Attendance records successfully updated to LEAVE.');
        setApproveModalOpen(false);
        setTargetApp(null);
        await fetchApplications();
        if (onLeaveActionTaken) onLeaveActionTaken();
      } else {
        showToast('error', res.error || 'Failed to approve leave application');
      }
    } catch (err: any) {
      showToast('error', err.message || 'Approval failed');
    } finally {
      setProcessing(false);
    }
  };

  const handleOpenRejectModal = (app: LeaveApplication) => {
    setTargetApp(app);
    setRejectionReason('');
    setRejectModalOpen(true);
  };

  const handleConfirmReject = async () => {
    if (!targetApp) return;
    if (!rejectionReason.trim()) {
      showToast('error', 'Please enter a clear explanation for the rejection');
      return;
    }
    setProcessing(true);
    try {
      const res = await api.reviewLeaveApplication(targetApp.id, {
        status: 'REJECTED',
        rejectionReason: rejectionReason.trim()
      });
      if (res && res.success) {
        showToast('success', 'Student leave application rejected.');
        setRejectModalOpen(false);
        setTargetApp(null);
        await fetchApplications();
        if (onLeaveActionTaken) onLeaveActionTaken();
      } else {
        showToast('error', res.error || 'Failed to reject application');
      }
    } catch (err: any) {
      showToast('error', err.message || 'Rejection failed');
    } finally {
      setProcessing(false);
    }
  };

  // Filtered Applications
  const filteredApplications = useMemo(() => {
    return applications.filter((app) => {
      if (statusFilter !== 'ALL') {
        if (statusFilter === 'SUBMITTED' && (app.status !== 'SUBMITTED' && app.status !== 'PENDING')) return false;
        if (statusFilter !== 'SUBMITTED' && app.status !== statusFilter) return false;
      }
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchName = app.applicantName?.toLowerCase().includes(q);
        const matchClass = app.className?.toLowerCase().includes(q);
        const matchSection = app.sectionName?.toLowerCase().includes(q);
        const matchReason = app.reason?.toLowerCase().includes(q);
        const matchDate = (app.startDate || app.leaveDate || '').includes(q);
        if (!matchName && !matchClass && !matchSection && !matchReason && !matchDate) return false;
      }
      return true;
    });
  }, [applications, statusFilter, searchQuery]);

  // Status Badge Helper
  const getStatusBadge = (status: LeaveStatus) => {
    switch (status) {
      case 'DRAFT':
        return <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold bg-slate-100 text-slate-700 border border-slate-300">Draft</span>;
      case 'SUBMITTED':
      case 'PENDING':
        return <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold bg-blue-100 text-blue-800 border border-blue-300">Submitted</span>;
      case 'UNDER_REVIEW':
        return <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold bg-amber-100 text-amber-800 border border-amber-300">Under Review</span>;
      case 'APPROVED':
        return <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 border border-emerald-300">Approved</span>;
      case 'REJECTED':
        return <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold bg-rose-100 text-rose-800 border border-rose-300">Rejected</span>;
      case 'CANCELLED':
        return <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold bg-slate-200 text-slate-600 border border-slate-400">Cancelled</span>;
      default:
        return <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold bg-slate-100 text-slate-700">{status}</span>;
    }
  };

  const metrics = useMemo(() => {
    const total = applications.length;
    const submitted = applications.filter((a) => a.status === 'SUBMITTED' || a.status === 'PENDING').length;
    const underReview = applications.filter((a) => a.status === 'UNDER_REVIEW').length;
    const approved = applications.filter((a) => a.status === 'APPROVED').length;
    return { total, submitted, underReview, approved };
  }, [applications]);

  return (
    <div className="space-y-6">
      {/* Toast */}
      {feedback && (
        <div
          className={`flex items-center gap-3 px-4 py-3 rounded-lg border text-sm transition-all duration-300 ${
            feedback.type === 'success'
              ? 'bg-emerald-50 text-emerald-900 border-emerald-300'
              : feedback.type === 'error'
              ? 'bg-rose-50 text-rose-900 border-rose-300'
              : 'bg-amber-50 text-amber-900 border-amber-300'
          }`}
        >
          {feedback.type === 'success' && <CheckCircle2 className="w-5 h-5 text-emerald-600 flex-shrink-0" />}
          {feedback.type === 'error' && <XCircle className="w-5 h-5 text-rose-600 flex-shrink-0" />}
          {feedback.type === 'warning' && <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0" />}
          <div className="flex-1 font-medium">{feedback.message}</div>
          <button onClick={() => setFeedback(null)} className="text-slate-400 hover:text-slate-600">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Metrics Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          <div className="text-xs font-medium text-slate-500 uppercase tracking-wider mb-1">Total Requests</div>
          <div className="text-2xl font-bold text-slate-800">{metrics.total}</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-blue-200 shadow-sm bg-blue-50/20">
          <div className="text-xs font-medium text-blue-700 uppercase tracking-wider mb-1">Awaiting Review</div>
          <div className="text-2xl font-bold text-blue-700">{metrics.submitted}</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-amber-200 shadow-sm bg-amber-50/20">
          <div className="text-xs font-medium text-amber-700 uppercase tracking-wider mb-1">Under Review</div>
          <div className="text-2xl font-bold text-amber-700">{metrics.underReview}</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-emerald-200 shadow-sm bg-emerald-50/20">
          <div className="text-xs font-medium text-emerald-700 uppercase tracking-wider mb-1">Approved & Synced</div>
          <div className="text-2xl font-bold text-emerald-700">{metrics.approved}</div>
        </div>
      </div>

      {/* Controls Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3 flex-1">
          <div className="relative flex-1 min-w-[200px] max-w-sm">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search student, class, reason..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            />
          </div>

          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg text-xs font-medium text-slate-600 overflow-x-auto">
            {['ALL', 'SUBMITTED', 'UNDER_REVIEW', 'APPROVED', 'REJECTED'].map((st) => (
              <button
                key={st}
                onClick={() => setStatusFilter(st)}
                className={`px-3 py-1 rounded-md transition-colors whitespace-nowrap ${
                  statusFilter === st ? 'bg-white text-indigo-700 shadow-sm font-semibold' : 'hover:text-slate-900'
                }`}
              >
                {st === 'ALL' ? 'All' : (st || '').replace(/_/g, ' ')}
              </button>
            ))}
          </div>
        </div>

        <button
          onClick={fetchApplications}
          disabled={loading}
          className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition border border-slate-200 self-end md:self-auto"
          title="Refresh Applications"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
        </button>
      </div>

      {/* Applications Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        {loading ? (
          <div className="p-12 text-center">
            <LoadingSpinner message="Loading student leave applications..." />
          </div>
        ) : filteredApplications.length === 0 ? (
          <div className="p-12 text-center text-slate-500">
            <GraduationCap className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <h4 className="text-base font-semibold text-slate-700">No Student Leave Applications</h4>
            <p className="text-sm text-slate-500 mt-1">
              There are no student leave requests matching your current filter.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-slate-600">
              <thead className="bg-slate-50 text-slate-700 text-xs font-semibold uppercase tracking-wider border-b border-slate-200">
                <tr>
                  <th className="px-5 py-3.5">Student & Class</th>
                  <th className="px-5 py-3.5">Leave Type</th>
                  <th className="px-5 py-3.5">Date Range</th>
                  <th className="px-5 py-3.5 text-center">Working Days</th>
                  <th className="px-5 py-3.5">Reason & Description</th>
                  <th className="px-5 py-3.5 text-center">Status</th>
                  <th className="px-5 py-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredApplications.map((app) => {
                  const isPending = app.status === 'SUBMITTED' || app.status === 'PENDING';
                  const isUnderReview = app.status === 'UNDER_REVIEW';

                  return (
                    <tr key={app.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="px-5 py-4">
                        <div className="font-bold text-slate-900">{app.applicantName}</div>
                        <div className="text-xs text-slate-500">
                          {app.className || 'Class'} • Section {app.sectionName || '-'}
                        </div>
                      </td>
                      <td className="px-5 py-4 font-medium text-slate-800">
                        {app.leaveTypeName || 'Student Leave'}
                      </td>
                      <td className="px-5 py-4 whitespace-nowrap text-xs font-semibold text-slate-800">
                        {app.startDate || app.leaveDate}
                        {app.endDate && app.endDate !== (app.startDate || app.leaveDate) && (
                          <span className="text-slate-500 font-normal"> to {app.endDate}</span>
                        )}
                      </td>
                      <td className="px-5 py-4 text-center whitespace-nowrap">
                        <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-bold bg-slate-100 text-slate-800">
                          {app.totalDays} {app.totalDays === 1 ? 'day' : 'days'}
                        </span>
                      </td>
                      <td className="px-5 py-4 max-w-xs truncate" title={app.description || app.reason}>
                        <div className="font-medium text-slate-800 truncate">{app.reason}</div>
                        {app.description && <div className="text-xs text-slate-400 truncate">{app.description}</div>}
                      </td>
                      <td className="px-5 py-4 text-center whitespace-nowrap">
                        {getStatusBadge(app.status)}
                      </td>
                      <td className="px-5 py-4 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => {
                              setSelectedApp(app);
                              setDetailModalOpen(true);
                            }}
                            className="p-1.5 text-slate-500 hover:text-indigo-600 hover:bg-slate-100 rounded-lg transition"
                            title="View Details"
                          >
                            <Eye className="w-4 h-4" />
                          </button>

                          {isPending && (
                            <button
                              onClick={() => handleMarkUnderReview(app)}
                              className="px-2.5 py-1 text-xs bg-amber-50 hover:bg-amber-100 text-amber-700 font-semibold rounded-lg border border-amber-200 transition"
                              title="Mark Under Review"
                            >
                              Review
                            </button>
                          )}

                          {(isPending || isUnderReview) && (
                            <>
                              <button
                                onClick={() => handleOpenApproveModal(app)}
                                className="px-2.5 py-1 text-xs bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-lg shadow-sm transition inline-flex items-center gap-1"
                                title="Approve & Mark Leave Attendance"
                              >
                                <Check className="w-3.5 h-3.5" />
                                Approve
                              </button>
                              <button
                                onClick={() => handleOpenRejectModal(app)}
                                className="px-2.5 py-1 text-xs bg-rose-50 hover:bg-rose-100 text-rose-700 font-semibold rounded-lg border border-rose-200 transition inline-flex items-center gap-1"
                                title="Reject Application"
                              >
                                <X className="w-3.5 h-3.5" />
                                Reject
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* ========================================================================= */}
      {/* 1. APPROVE CONFIRMATION MODAL                                             */}
      {/* ========================================================================= */}
      <Modal
        isOpen={approveModalOpen}
        onClose={() => setApproveModalOpen(false)}
        title="Approve Student Leave Application"
        size="md"
      >
        <div className="space-y-4 text-sm text-slate-700">
          <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl space-y-2 text-emerald-900">
            <div className="flex items-center gap-2 font-bold text-emerald-800">
              <ShieldCheck className="w-5 h-5 text-emerald-600" />
              <span>Automatic Attendance Synchronization</span>
            </div>
            <p className="text-xs text-emerald-800/90 leading-relaxed">
              Approving this application will automatically update or generate attendance records for{' '}
              <strong>{targetApp?.applicantName}</strong> across all {targetApp?.totalDays} working days with status{' '}
              <strong className="underline">LEAVE</strong>. Non-working days (weekends, calendar holidays) are safely protected.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs bg-slate-50 p-3 rounded-lg border border-slate-200">
            <div>
              <span className="text-slate-400 uppercase font-semibold">Student:</span>
              <div className="font-bold text-slate-800 mt-0.5">{targetApp?.applicantName}</div>
            </div>
            <div>
              <span className="text-slate-400 uppercase font-semibold">Date Range:</span>
              <div className="font-bold text-slate-800 mt-0.5">
                {targetApp?.startDate || targetApp?.leaveDate} to {targetApp?.endDate || targetApp?.startDate || targetApp?.leaveDate} ({targetApp?.totalDays} working days)
              </div>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
              Faculty / Teacher Remarks (Optional)
            </label>
            <textarea
              rows={2}
              placeholder="e.g. Leave granted with instructions to catch up on missed coursework."
              value={adminRemarks}
              onChange={(e) => setAdminRemarks(e.target.value)}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setApproveModalOpen(false)}
              className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-800 font-medium rounded-lg hover:bg-slate-100 transition"
            >
              Cancel
            </button>
            <button
              type="button"
              disabled={processing}
              onClick={handleConfirmApprove}
              className="px-4 py-2 text-xs bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg shadow-sm transition inline-flex items-center gap-1.5"
            >
              <Check className="w-4 h-4" />
              {processing ? 'Processing...' : 'Confirm Approval & Sync Attendance'}
            </button>
          </div>
        </div>
      </Modal>

      {/* ========================================================================= */}
      {/* 2. REJECT CONFIRMATION MODAL                                              */}
      {/* ========================================================================= */}
      <Modal
        isOpen={rejectModalOpen}
        onClose={() => setRejectModalOpen(false)}
        title="Reject Student Leave Application"
        size="md"
      >
        <div className="space-y-4 text-sm text-slate-700">
          <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 flex items-start gap-2">
            <AlertTriangle className="w-4 h-4 text-rose-600 flex-shrink-0 mt-0.5" />
            <div>
              You are rejecting the leave application for <strong>{targetApp?.applicantName}</strong> ({targetApp?.startDate || targetApp?.leaveDate}).
              Please enter a clear explanation for the student and guardians.
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
              Rejection Reason *
            </label>
            <textarea
              rows={3}
              placeholder="e.g. Mandatory examination scheduled on this date; unexcused absence; missing required medical documentation."
              value={rejectionReason}
              onChange={(e) => setRejectionReason(e.target.value)}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-rose-500 focus:outline-none"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setRejectModalOpen(false)}
              className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-800 font-medium rounded-lg hover:bg-slate-100 transition"
            >
              Cancel
            </button>
            <button
              type="button"
              disabled={processing}
              onClick={handleConfirmReject}
              className="px-4 py-2 text-xs bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-lg shadow-sm transition inline-flex items-center gap-1.5"
            >
              <X className="w-4 h-4" />
              {processing ? 'Processing...' : 'Confirm Rejection'}
            </button>
          </div>
        </div>
      </Modal>

      {/* ========================================================================= */}
      {/* 3. DETAILS MODAL                                                          */}
      {/* ========================================================================= */}
      <Modal
        isOpen={detailModalOpen}
        onClose={() => setDetailModalOpen(false)}
        title="Student Leave Application Details"
        size="md"
      >
        {selectedApp && (
          <div className="space-y-4 text-sm text-slate-700">
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between">
              <div>
                <div className="text-xs text-slate-400 uppercase font-semibold">Student</div>
                <div className="font-bold text-slate-900 mt-0.5">{selectedApp.applicantName}</div>
                <div className="text-xs text-slate-500">{selectedApp.className} • Section {selectedApp.sectionName}</div>
              </div>
              <div className="text-right">
                <div className="text-xs text-slate-400 uppercase font-semibold">Status</div>
                <div className="mt-1">{getStatusBadge(selectedApp.status)}</div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="p-3 bg-white border border-slate-200 rounded-xl">
                <div className="text-xs text-slate-500 uppercase font-semibold">Date Range</div>
                <div className="font-medium text-slate-900 mt-1">
                  {selectedApp.startDate || selectedApp.leaveDate} to {selectedApp.endDate || selectedApp.startDate || selectedApp.leaveDate}
                </div>
              </div>
              <div className="p-3 bg-white border border-slate-200 rounded-xl">
                <div className="text-xs text-slate-500 uppercase font-semibold">Working Days</div>
                <div className="font-bold text-indigo-700 mt-1">
                  {selectedApp.totalDays} {selectedApp.totalDays === 1 ? 'day' : 'days'}
                </div>
              </div>
            </div>

            <div>
              <div className="text-xs text-slate-500 uppercase font-semibold mb-1">Reason & Description</div>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-slate-800">
                <p className="font-semibold text-slate-900">{selectedApp.reason}</p>
                {selectedApp.description && <p className="mt-1 text-slate-600 text-xs">{selectedApp.description}</p>}
              </div>
            </div>

            {selectedApp.attachmentUrl && (
              <div>
                <div className="text-xs text-slate-500 uppercase font-semibold mb-1">Attachment</div>
                <a
                  href={selectedApp.attachmentUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 p-2.5 bg-indigo-50 text-indigo-700 border border-indigo-200 rounded-xl hover:bg-indigo-100 transition text-xs font-semibold"
                >
                  <Paperclip className="w-4 h-4" />
                  <span>{selectedApp.attachmentName || 'View Document Attachment'}</span>
                </a>
              </div>
            )}

            {(selectedApp.reviewedByName || selectedApp.adminRemarks || selectedApp.rejectionReason) && (
              <div className="p-3 bg-amber-50/60 border border-amber-200 rounded-xl space-y-1 text-xs text-slate-700">
                <div className="font-bold text-amber-900 uppercase tracking-wider text-[10px]">Review Log</div>
                {selectedApp.reviewedByName && (
                  <div>Reviewed By: <strong className="text-slate-900">{selectedApp.reviewedByName}</strong> on {selectedApp.reviewedAt?.split('T')[0]}</div>
                )}
                {selectedApp.adminRemarks && <div>Remarks: <span className="italic font-medium">"{selectedApp.adminRemarks}"</span></div>}
                {selectedApp.rejectionReason && <div className="text-rose-700 font-medium">Rejection Reason: {selectedApp.rejectionReason}</div>}
              </div>
            )}

            <div className="flex justify-end pt-3 border-t border-slate-200">
              <button
                type="button"
                onClick={() => setDetailModalOpen(false)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg transition"
              >
                Close
              </button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};
