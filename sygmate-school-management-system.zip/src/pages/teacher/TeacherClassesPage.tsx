import React, { useEffect, useState } from 'react';
import {
  GraduationCap,
  Layers,
  BookOpen,
  Users,
  Calendar,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  ChevronRight,
  School,
  CheckCircle2,
  RefreshCw,
  Search
} from 'lucide-react';
import { Badge } from '../../components/ui/Badge.js';
import { Button } from '../../components/ui/Button.js';
import { Modal } from '../../components/ui/Modal.js';
import { api } from '../../services/api.js';
import { TeacherClassInfo, TeacherSectionInfo } from '../../types/index.js';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner.js';
import { useToast } from '../../context/ToastContext.js';

interface TeacherClassesPageProps {
  onNavigate?: (viewId: string, params?: any) => void;
  activeTab?: 'classes' | 'sections';
  onTabChange?: (tab: 'classes' | 'sections') => void;
  hideTabBar?: boolean;
}

export const TeacherClassesPage: React.FC<TeacherClassesPageProps> = ({
  onNavigate,
  activeTab: propActiveTab,
  onTabChange,
  hideTabBar = true
}) => {
  const [classes, setClasses] = useState<TeacherClassInfo[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedClass, setSelectedClass] = useState<TeacherClassInfo | null>(null);
  const [internalTab, setInternalTab] = useState<'classes' | 'sections'>('classes');
  const activeTab = propActiveTab || internalTab;
  const setActiveTab = (tab: 'classes' | 'sections') => {
    setInternalTab(tab);
    onTabChange?.(tab);
  };
  const [search, setSearch] = useState('');
  const { showToast } = useToast();

  const loadClasses = async () => {
    try {
      setLoading(true);
      const res = await api.getMyTeacherClasses();
      const classesList = Array.isArray(res?.data) ? res.data : Array.isArray(res) ? res : [];
      setClasses(classesList);
      if (Array.isArray(classesList) && classesList.length > 0 && !selectedClass) {
        setSelectedClass(classesList?.[0] || null);
      }
    } catch (err: any) {
      console.error('Failed to load teacher classes', err);
      showToast(err.message || 'Could not load assigned classes', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadClasses();
  }, []);

  // Compute aggregate metrics
  const totalClasses = classes.length;
  const totalSections = classes.reduce((sum, c) => sum + (c.sections?.length || 0), 0);
  const totalStudents = classes.reduce((sum, c) => sum + (c.totalStudents || 0), 0);
  const totalSubjects = classes.reduce((sum, c) => sum + (c.subjects?.length || 0), 0);

  // Filtered classes
  const filteredClasses = classes.filter((c) => {
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return (
      (c.name || '').toLowerCase().includes(q) ||
      (c.code || '').toLowerCase().includes(q) ||
      (c.subjects && c.subjects.some((s) => (s.name || '').toLowerCase().includes(q) || (s.code || '').toLowerCase().includes(q)))
    );
  });

  // Filtered sections for selected class
  const currentSections: TeacherSectionInfo[] = selectedClass?.sections || [];

  return (
    <div className="space-y-8">
      {/* Header Banner */}
      <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-6 sm:p-8 shadow-xl shadow-black/20 relative overflow-hidden flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="absolute top-0 right-0 w-80 h-80 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none" />

        <div className="space-y-1 z-10">
          <div className="flex items-center gap-2 text-indigo-400 text-xs font-bold uppercase tracking-wider">
            <GraduationCap className="w-3.5 h-3.5" />
            <span>Academic Management &amp; Cohort Access</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
            My Classes &amp; Sections
          </h2>
          <p className="text-xs text-slate-400 max-w-xl">
            View classrooms, cohort sections, and curriculum subjects assigned to your faculty profile.
            Data is strictly scoped to your teaching allocation.
          </p>
        </div>

        <div className="flex items-center gap-3 z-10">
          {onNavigate && (
            <Button
              size="sm"
              variant="primary"
              leftIcon={<Users className="w-4 h-4" />}
              onClick={() => onNavigate('teacher-students')}
            >
              My Students Roster
            </Button>
          )}
          <Button
            size="sm"
            variant="glass"
            leftIcon={<RefreshCw className="w-3.5 h-3.5" />}
            onClick={() => loadClasses()}
          >
            Refresh
          </Button>
        </div>
      </div>

      {/* Metric Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5">
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 p-5 rounded-2xl shadow-xl shadow-black/20">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Assigned Classes</span>
            <GraduationCap className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-bold text-white">{totalClasses}</div>
          <div className="mt-1 text-[10px] text-indigo-400 font-bold uppercase tracking-wider">
            Grade Cohorts
          </div>
        </div>

        <div className="bg-white/5 backdrop-blur-xl border border-white/10 p-5 rounded-2xl shadow-xl shadow-black/20">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Assigned Sections</span>
            <Layers className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-bold text-white">{totalSections}</div>
          <div className="mt-1 text-[10px] text-emerald-400 font-bold uppercase tracking-wider">
            Active Classrooms
          </div>
        </div>

        <div className="bg-white/5 backdrop-blur-xl border border-white/10 p-5 rounded-2xl shadow-xl shadow-black/20">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Assigned Subjects</span>
            <BookOpen className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-bold text-white">{totalSubjects}</div>
          <div className="mt-1 text-[10px] text-cyan-400 font-bold uppercase tracking-wider">
            Taught in Classes
          </div>
        </div>

        <div className="bg-white/5 backdrop-blur-xl border border-white/10 p-5 rounded-2xl shadow-xl shadow-black/20">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Total Students</span>
            <Users className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-bold text-white">{totalStudents}</div>
          <div className="mt-1 text-[10px] text-amber-400 font-bold uppercase tracking-wider">
            Under My Classes
          </div>
        </div>
      </div>

      {/* Navigation Tabs (My Classes vs My Sections) */}
      <div className="flex items-center justify-between border-b border-white/10 pb-4">
        {!hideTabBar && (
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('classes')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'classes'
                  ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30 border border-indigo-400/30'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              1. My Classes ({totalClasses})
            </button>
            <button
              onClick={() => setActiveTab('sections')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'sections'
                  ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30 border border-indigo-400/30'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              2. My Sections ({totalSections})
            </button>
          </div>
        )}

        <div className="relative w-64 hidden sm:block">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search class or subject..."
            className="w-full bg-white/5 border border-white/10 rounded-xl pl-9 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>
      </div>

      {loading ? (
        <div className="py-20 flex justify-center bg-white/5 rounded-3xl border border-white/10">
          <LoadingSpinner size="lg" message="Loading assigned academic cohorts..." />
        </div>
      ) : classes.length === 0 ? (
        <div className="bg-white/5 border border-white/10 rounded-3xl p-12 text-center space-y-3">
          <GraduationCap className="w-12 h-12 text-slate-500 mx-auto" />
          <h3 className="text-lg font-bold text-white">No Assigned Classes</h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            You do not currently have classes assigned to your faculty profile. Please contact your Academic Administrator.
          </p>
        </div>
      ) : activeTab === 'classes' ? (
        /* ================= 1. MY CLASSES TAB ================= */
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {(filteredClasses || []).map((cls, idx) => (
              <div
                key={`${cls.id}-${idx}`}
                className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-6 shadow-xl shadow-black/20 hover:border-indigo-500/30 transition-all flex flex-col justify-between space-y-6"
              >
                {/* Header */}
                <div className="space-y-4">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-2xl bg-indigo-600/30 border border-indigo-400/30 flex items-center justify-center font-bold text-white text-lg shadow-inner">
                        {cls.numericGrade || 'C'}
                      </div>
                      <div>
                        <h3 className="text-lg font-bold text-white flex items-center gap-2">
                          <span>{cls.name}</span>
                          <span className="text-xs font-mono px-2 py-0.5 rounded bg-white/10 text-slate-300 font-normal">
                            {cls.code}
                          </span>
                        </h3>
                        <p className="text-xs text-slate-400 font-mono mt-0.5">
                          Academic Session: <strong className="text-slate-200">{cls.academicSessionName}</strong>
                        </p>
                      </div>
                    </div>

                    <Badge variant={cls.status === 'inactive' ? 'neutral' : 'success'} dot>
                      {cls.status || 'Active'}
                    </Badge>
                  </div>

                  {/* Sections List */}
                  <div className="p-3.5 rounded-2xl bg-white/[0.03] border border-white/5 space-y-2">
                    <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider block">
                      Assigned Sections ({cls.sections?.length || 0})
                    </span>
                    <div className="flex flex-wrap gap-2">
                      {(cls.sections || []).map((sec) => (
                        <div
                          key={sec.id}
                          className="px-2.5 py-1 rounded-xl bg-white/5 border border-white/10 text-xs text-slate-200 flex items-center gap-1.5"
                        >
                          <span className="font-semibold text-white">{sec.name}</span>
                          <span className="text-[10px] text-slate-400">({sec.studentCount} students)</span>
                          {sec.isClassTeacher && (
                            <span className="px-1.5 py-0.2 rounded bg-indigo-500/20 text-indigo-300 text-[9px] font-bold">
                              Class Teacher
                            </span>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Subjects Assigned in this Class */}
                  {((cls?.subjects?.length || 0) > 0) && (
                    <div className="p-3.5 rounded-2xl bg-white/[0.03] border border-white/5 space-y-2">
                      <span className="text-[10px] text-cyan-400 uppercase font-bold tracking-wider block">
                        Assigned Subject(s) in this Class ({cls?.subjects?.length || 0})
                      </span>
                      <div className="flex flex-wrap gap-2">
                        {(cls.subjects || []).map((sub) => (
                          <div
                            key={sub.id}
                            className="px-2.5 py-1 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-xs text-cyan-300 flex items-center gap-1"
                          >
                            <BookOpen className="w-3 h-3 text-cyan-400" />
                            <span className="font-semibold">{sub.name}</span>
                            <span className="text-[10px] font-mono text-cyan-400/70">({sub.code})</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Footer Metrics & Actions */}
                <div className="pt-4 border-t border-white/10 flex items-center justify-between">
                  <div className="text-xs text-slate-400">
                    Total Enrolled:{' '}
                    <strong className="text-white font-mono text-sm">{cls.totalStudents}</strong> students
                  </div>

                  <div className="flex items-center gap-2">
                    <Button
                      size="xs"
                      variant="outline"
                      onClick={() => {
                        setSelectedClass(cls);
                        setActiveTab('sections');
                      }}
                      rightIcon={<ArrowRight className="w-3.5 h-3.5" />}
                    >
                      View Sections
                    </Button>
                    {onNavigate && (
                      <Button
                        size="xs"
                        variant="glass"
                        onClick={() => onNavigate('teacher-students')}
                      >
                        View Students
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        /* ================= 2. MY SECTIONS TAB ================= */
        <div className="space-y-6">
          {/* Class Selector Bar */}
          <div className="flex flex-wrap items-center gap-2 bg-white/5 p-3 rounded-2xl border border-white/10">
            <span className="text-xs text-slate-400 font-semibold px-2">Select Class:</span>
            {(classes || []).map((c, idx) => (
              <button
                key={`${c.id}-${idx}`}
                onClick={() => setSelectedClass(c)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  selectedClass?.id === c.id
                    ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                    : 'bg-white/5 text-slate-400 hover:text-white hover:bg-white/10'
                }`}
              >
                {c.name} ({c.sections?.length || 0} Sections)
              </button>
            ))}
          </div>

          {/* Sections Grid for Selected Class */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Layers className="w-4 h-4 text-emerald-400" />
                <span>
                  {selectedClass?.name} — Assigned Sections ({currentSections.length})
                </span>
              </h3>
              <span className="text-xs text-slate-400 font-mono">
                Academic Session: {selectedClass?.academicSessionName}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {(currentSections || []).map((sec) => {
                const capacityRatio = Math.round(((sec.studentCount || 0) / (sec.capacity || 30)) * 100);
                return (
                  <div
                    key={sec.id}
                    className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-6 shadow-xl shadow-black/20 hover:border-indigo-500/30 transition-all flex flex-col justify-between space-y-5"
                  >
                    <div className="space-y-4">
                      {/* Top bar */}
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <h4 className="text-base font-bold text-white">{sec.name}</h4>
                          <span className="text-xs text-slate-400 font-mono">{sec.code || 'Cohort'}</span>
                        </div>
                        {sec.isClassTeacher ? (
                          <Badge variant="primary">Class Teacher</Badge>
                        ) : (
                          <Badge variant="neutral">Subject Teacher</Badge>
                        )}
                      </div>

                      {/* Detail attributes */}
                      <div className="grid grid-cols-2 gap-2 text-xs">
                        <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                          <span className="text-[10px] text-slate-500 uppercase font-semibold block">Room</span>
                          <span className="text-xs font-bold text-slate-900">{sec.roomNumber || 'TBD'}</span>
                        </div>
                        <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                          <span className="text-[10px] text-slate-500 uppercase font-semibold block">Capacity</span>
                          <span className="text-xs font-bold text-slate-900">{sec.capacity || 30} seats</span>
                        </div>
                      </div>

                      {/* Enrollment progress */}
                      <div className="space-y-1.5">
                        <div className="flex justify-between text-xs">
                          <span className="text-slate-500 font-medium">Enrolled Students</span>
                          <span className="font-mono text-slate-900 font-bold">
                            {sec.studentCount} / {sec.capacity || 30}
                          </span>
                        </div>
                        <div className="w-full h-2 bg-slate-100 border border-slate-200 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-blue-600 rounded-full"
                            style={{ width: `${Math.min(100, capacityRatio)}%` }}
                          />
                        </div>
                      </div>

                      {/* Subjects */}
                      {((sec?.subjects?.length || 0) > 0) && (
                        <div className="p-3 rounded-xl bg-blue-50/60 border border-blue-200 space-y-1.5">
                          <span className="text-[10px] text-blue-700 uppercase font-bold tracking-wider block">
                            Subjects Taught
                          </span>
                          <div className="space-y-1">
                            {(sec.subjects || []).map((sub) => (
                              <div key={sub.id} className="text-xs text-slate-800 flex items-center justify-between">
                                <span className="font-medium">{sub.name}</span>
                                <span className="text-[10px] font-mono text-blue-700 font-semibold">{sub.code}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Action */}
                    <div className="pt-4 border-t border-slate-200 flex items-center justify-between">
                      <span className="text-[11px] text-slate-500">
                        {sec.academicSessionName}
                      </span>
                      {onNavigate && (
                        <Button
                          size="xs"
                          variant="primary"
                          leftIcon={<Users className="w-3.5 h-3.5" />}
                          onClick={() => onNavigate('teacher-students')}
                        >
                          View Students
                        </Button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
