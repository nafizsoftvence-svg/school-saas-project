import React, { useEffect, useState, useMemo } from 'react';
import {
  FolderGit2,
  Plus,
  Search,
  Filter,
  Calendar,
  Clock,
  CheckCircle2,
  AlertCircle,
  FileText,
  Trash2,
  Edit3,
  Eye,
  Archive,
  RefreshCw,
  Sparkles,
  GraduationCap,
  BookOpen,
  Download,
  UploadCloud,
  X,
  FileCode,
  FileSpreadsheet,
  FileArchive,
  Image as ImageIcon,
  File,
  Layers
} from 'lucide-react';
import { api } from '../../services/api.js';
import { useAuth } from '../../context/AuthContext.js';
import { useToast } from '../../context/ToastContext.js';
import {
  StudyMaterial,
  StudyMaterialFilterParams,
  TeacherClassInfo,
  TeacherSubjectBrief
} from '../../types/index.js';
import { Button } from '../../components/ui/Button.js';
import { Badge } from '../../components/ui/Badge.js';
import { Modal } from '../../components/ui/Modal.js';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner.js';

interface TeacherMaterialsPageProps {
  onNavigate?: (viewId: string) => void;
}

export const TeacherMaterialsPage: React.FC<TeacherMaterialsPageProps> = ({ onNavigate }) => {
  const { user } = useAuth();
  const { showToast } = useToast();

  // Data state
  const [materialsList, setMaterialsList] = useState<StudyMaterial[]>([]);
  const [loading, setLoading] = useState(true);
  const [classes, setClasses] = useState<TeacherClassInfo[]>([]);
  const [subjects, setSubjects] = useState<TeacherSubjectBrief[]>([]);

  // Filter state
  const [search, setSearch] = useState('');
  const [selectedClassId, setSelectedClassId] = useState('ALL');
  const [selectedSectionId, setSelectedSectionId] = useState('ALL');
  const [selectedSubjectId, setSelectedSubjectId] = useState('ALL');
  const [selectedFileType, setSelectedFileType] = useState('ALL');
  const [selectedStatus, setSelectedStatus] = useState('ALL');

  // Modals
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [showViewModal, setShowViewModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [activeItem, setActiveItem] = useState<StudyMaterial | null>(null);

  // Form State
  const [formData, setFormData] = useState<{
    title: string;
    description: string;
    subjectId: string;
    classId: string;
    sectionId: string;
    fileUrl: string;
    fileName: string;
    fileSize: string;
    fileSizeBytes: number;
    fileType: string;
    status: 'active' | 'archived' | 'draft';
  }>({
    title: '',
    description: '',
    subjectId: '',
    classId: '',
    sectionId: 'ALL',
    fileUrl: '',
    fileName: '',
    fileSize: '',
    fileSizeBytes: 0,
    fileType: 'pdf',
    status: 'active'
  });

  const [uploadingFile, setUploadingFile] = useState(false);
  const [saving, setSaving] = useState(false);

  const loadContext = async () => {
    try {
      const [classesRes, subjectsRes] = await Promise.all([
        api.getMyTeacherClasses(),
        api.getMyTeacherSubjects()
      ]);

      if (classesRes.success && classesRes.data) {
        setClasses(classesRes.data);
      }
      if (subjectsRes.success && subjectsRes.data) {
        setSubjects(subjectsRes.data);
      }
    } catch (err: any) {
      console.error('Failed to load teacher context', err);
    }
  };

  const loadMaterials = async () => {
    try {
      setLoading(true);
      const params: StudyMaterialFilterParams = {
        classId: selectedClassId,
        sectionId: selectedSectionId,
        subjectId: selectedSubjectId,
        fileType: selectedFileType,
        status: selectedStatus,
        search
      };
      const res = await api.activities.getMaterials(params);
      if (res.success && res.data) {
        setMaterialsList(res.data);
      }
    } catch (err: any) {
      console.error('Failed to load study materials', err);
      showToast(err.message || 'Could not fetch study materials', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadContext();
  }, []);

  useEffect(() => {
    loadMaterials();
  }, [selectedClassId, selectedSectionId, selectedSubjectId, selectedFileType, selectedStatus]);

  const availableSectionsForForm = useMemo(() => {
    if (!formData.classId) return [];
    const cls = (classes || []).find((c) => c?.id === formData.classId);
    return cls?.sections || [];
  }, [formData.classId, classes]);

  const availableSectionsForFilter = useMemo(() => {
    if (!selectedClassId || selectedClassId === 'ALL') return [];
    const cls = (classes || []).find((c) => c?.id === selectedClassId);
    return cls?.sections || [];
  }, [selectedClassId, classes]);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setUploadingFile(true);
      const res = await api.activities.uploadFile({
        fileName: file.name,
        fileSizeBytes: file.size,
        fileType: file.name.split('.').pop() || 'pdf'
      });

      if (res.success && res.data) {
        setFormData((prev) => ({
          ...prev,
          title: prev.title || file.name.replace(/\.[^/.]+$/, '').replace(/_/g, ' '),
          fileUrl: res.data.fileUrl,
          fileName: res.data.fileName,
          fileSize: res.data.fileSize,
          fileSizeBytes: res.data.fileSizeBytes,
          fileType: res.data.fileType
        }));
        showToast('Document uploaded and validated', 'success');
      }
    } catch (err: any) {
      showToast(err.message || 'File upload failed', 'error');
    } finally {
      setUploadingFile(false);
    }
  };

  const openUploadModal = () => {
    const defaultClass = classes?.[0];
    const defaultSubject = subjects?.[0];

    setFormData({
      title: '',
      description: '',
      classId: defaultClass?.id || '',
      sectionId: 'ALL',
      subjectId: defaultSubject?.id || '',
      fileUrl: '',
      fileName: '',
      fileSize: '',
      fileSizeBytes: 0,
      fileType: 'pdf',
      status: 'active'
    });
    setShowUploadModal(true);
  };

  const openEditModal = (item: StudyMaterial) => {
    setActiveItem(item);
    setFormData({
      title: item.title,
      description: item.description,
      classId: item.classId,
      sectionId: item.sectionId,
      subjectId: item.subjectId,
      fileUrl: item.fileUrl,
      fileName: item.fileName,
      fileSize: item.fileSize,
      fileSizeBytes: item.fileSizeBytes || 0,
      fileType: item.fileType,
      status: item.status
    });
    setShowEditModal(true);
  };

  const openViewModal = (item: StudyMaterial) => {
    setActiveItem(item);
    setShowViewModal(true);
  };

  const openDeleteModal = (item: StudyMaterial) => {
    setActiveItem(item);
    setShowDeleteModal(true);
  };

  const handleUploadSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title.trim()) {
      showToast('Please enter a title for the study material', 'error');
      return;
    }
    if (!formData.classId || !formData.subjectId) {
      showToast('Please select Target Class and Subject', 'error');
      return;
    }
    if (!formData.fileName) {
      showToast('Please upload a file attachment', 'error');
      return;
    }

    try {
      setSaving(true);
      const res = await api.activities.createMaterial(formData);
      if (res.success && res.data) {
        showToast('Study material published successfully', 'success');
        setShowUploadModal(false);
        loadMaterials();
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to publish material', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleEditSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeItem) return;

    try {
      setSaving(true);
      const res = await api.activities.updateMaterial(activeItem.id, formData);
      if (res.success && res.data) {
        showToast('Study material updated successfully', 'success');
        setShowEditModal(false);
        loadMaterials();
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to update study material', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteSubmit = async () => {
    if (!activeItem) return;
    try {
      setSaving(true);
      const res = await api.activities.deleteMaterial(activeItem.id);
      if (res.success) {
        showToast('Study material deleted successfully', 'success');
        setShowDeleteModal(false);
        loadMaterials();
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to delete material', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleToggleArchive = async (item: StudyMaterial) => {
    try {
      const newStatus = item.status === 'archived' ? 'active' : 'archived';
      await api.activities.updateMaterial(item.id, { status: newStatus });
      showToast(`Material ${newStatus === 'archived' ? 'archived' : 'activated'}`, 'info');
      loadMaterials();
    } catch (err: any) {
      showToast(err.message || 'Failed to update status', 'error');
    }
  };

  // Helper for rendering file icons
  const getFileIcon = (fileType?: string) => {
    const ext = (fileType || '').toLowerCase();
    if (ext === 'pdf') return <FileText className="w-5 h-5 text-rose-400" />;
    if (['ppt', 'pptx'].includes(ext)) return <Layers className="w-5 h-5 text-amber-400" />;
    if (['xls', 'xlsx', 'csv'].includes(ext)) return <FileSpreadsheet className="w-5 h-5 text-emerald-400" />;
    if (['doc', 'docx'].includes(ext)) return <FileText className="w-5 h-5 text-blue-400" />;
    if (['zip', 'rar', '7z'].includes(ext)) return <FileArchive className="w-5 h-5 text-purple-400" />;
    if (['png', 'jpg', 'jpeg'].includes(ext)) return <ImageIcon className="w-5 h-5 text-teal-400" />;
    return <File className="w-5 h-5 text-indigo-400" />;
  };

  const stats = useMemo(() => {
    const total = materialsList.length;
    const active = materialsList.filter((m) => m.status === 'active').length;
    const pdfs = materialsList.filter((m) => (m.fileType || '').toLowerCase() === 'pdf').length;
    const slides = materialsList.filter((m) => ['ppt', 'pptx'].includes((m.fileType || '').toLowerCase())).length;
    return { total, active, pdfs, slides };
  }, [materialsList]);

  return (
    <div className="space-y-8 pb-12">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-slate-900/60 p-6 rounded-2xl border border-white/10 backdrop-blur-xl">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 uppercase tracking-wider">
              Academic Repository
            </span>
            <span className="text-xs text-slate-400 font-medium">Part 3D</span>
          </div>
          <h1 className="text-2xl font-black tracking-tight text-white flex items-center gap-2">
            <FolderGit2 className="w-6 h-6 text-indigo-400" />
            Study Materials & Resources
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Upload and distribute lecture slides, PDF formula sheets, reference handbooks, and laboratory notes.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <Button
            variant="outline"
            size="sm"
            onClick={loadMaterials}
            disabled={loading}
            className="flex items-center gap-1.5"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
          <Button
            variant="primary"
            size="sm"
            onClick={openUploadModal}
            className="flex items-center gap-2 shadow-lg shadow-indigo-600/30"
          >
            <UploadCloud className="w-4 h-4" />
            Upload Material
          </Button>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-slate-900/50 p-4 rounded-xl border border-white/10 backdrop-blur-sm">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">Total Materials</span>
          <div className="text-2xl font-black text-white mt-1">{stats.total}</div>
          <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-1">
            <BookOpen className="w-3 h-3 text-indigo-400" /> Shared repository files
          </div>
        </div>
        <div className="bg-slate-900/50 p-4 rounded-xl border border-white/10 backdrop-blur-sm">
          <span className="text-xs font-semibold uppercase tracking-wider text-emerald-400">Active</span>
          <div className="text-2xl font-black text-emerald-400 mt-1">{stats.active}</div>
          <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3 text-emerald-400" /> Accessible to cohorts
          </div>
        </div>
        <div className="bg-slate-900/50 p-4 rounded-xl border border-white/10 backdrop-blur-sm">
          <span className="text-xs font-semibold uppercase tracking-wider text-rose-400">PDF Documents</span>
          <div className="text-2xl font-black text-rose-400 mt-1">{stats.pdfs}</div>
          <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-1">
            <FileText className="w-3 h-3 text-rose-400" /> Guides & cheatsheets
          </div>
        </div>
        <div className="bg-slate-900/50 p-4 rounded-xl border border-white/10 backdrop-blur-sm">
          <span className="text-xs font-semibold uppercase tracking-wider text-amber-400">Slides & PPT</span>
          <div className="text-2xl font-black text-amber-400 mt-1">{stats.slides}</div>
          <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-1">
            <Layers className="w-3 h-3 text-amber-400" /> Lecture presentations
          </div>
        </div>
      </div>

      {/* Toolbar */}
      <div className="bg-slate-900/50 p-5 rounded-2xl border border-white/10 backdrop-blur-xl space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-3">
          <div className="lg:col-span-2 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search materials by title or filename..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && loadMaterials()}
              className="w-full pl-10 pr-4 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-colors"
            />
          </div>

          <div>
            <select
              value={selectedClassId}
              onChange={(e) => {
                setSelectedClassId(e.target.value);
                setSelectedSectionId('ALL');
              }}
              className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:border-indigo-500"
            >
              <option value="ALL">All Assigned Classes</option>
              {(classes || []).map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <select
              value={selectedSubjectId}
              onChange={(e) => setSelectedSubjectId(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:border-indigo-500"
            >
              <option value="ALL">All My Subjects</option>
              {(subjects || []).map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.code})
                </option>
              ))}
            </select>
          </div>

          <div>
            <select
              value={selectedFileType}
              onChange={(e) => setSelectedFileType(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:border-indigo-500"
            >
              <option value="ALL">All File Types</option>
              <option value="pdf">PDF Documents (.pdf)</option>
              <option value="pptx">PowerPoint Slides (.pptx)</option>
              <option value="docx">Word Documents (.docx)</option>
              <option value="zip">Archive Packages (.zip)</option>
            </select>
          </div>

          <div>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:border-indigo-500"
            >
              <option value="ALL">All Statuses</option>
              <option value="active">Active</option>
              <option value="archived">Archived</option>
              <option value="draft">Draft</option>
            </select>
          </div>
        </div>

        {(selectedClassId !== 'ALL' ||
          selectedSubjectId !== 'ALL' ||
          selectedFileType !== 'ALL' ||
          selectedStatus !== 'ALL' ||
          search.trim() !== '') && (
          <div className="flex items-center justify-between pt-2 border-t border-white/5 text-xs text-slate-400">
            <div className="flex items-center gap-2">
              <Filter className="w-3.5 h-3.5 text-indigo-400" />
              <span>Active filters applied</span>
            </div>
            <button
              onClick={() => {
                setSearch('');
                setSelectedClassId('ALL');
                setSelectedSectionId('ALL');
                setSelectedSubjectId('ALL');
                setSelectedFileType('ALL');
                setSelectedStatus('ALL');
              }}
              className="text-indigo-400 hover:text-indigo-300 font-semibold cursor-pointer"
            >
              Reset Filters
            </button>
          </div>
        )}
      </div>

      {/* Grid */}
      {loading ? (
        <div className="py-20 flex justify-center">
          <LoadingSpinner size="lg" message="Loading study materials repository..." />
        </div>
      ) : materialsList.length === 0 ? (
        <div className="bg-slate-900/40 p-12 rounded-2xl border border-white/10 text-center space-y-4">
          <div className="w-12 h-12 bg-indigo-600/20 text-indigo-400 rounded-2xl flex items-center justify-center mx-auto border border-indigo-500/30">
            <FolderGit2 className="w-6 h-6" />
          </div>
          <div className="space-y-1">
            <h3 className="text-lg font-bold text-white">No Study Materials Found</h3>
            <p className="text-sm text-slate-400 max-w-md mx-auto">
              Upload textbook chapters, formula references, or lab safety protocols for your students.
            </p>
          </div>
          <Button variant="primary" size="sm" onClick={openUploadModal}>
            <UploadCloud className="w-4 h-4 mr-1.5" />
            Upload First Material
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {(materialsList || []).map((item) => (
            <div
              key={item.id}
              className="bg-slate-900/60 rounded-2xl border border-white/10 hover:border-indigo-500/40 p-5 flex flex-col justify-between transition-all duration-200 hover:shadow-xl hover:shadow-indigo-950/40 group backdrop-blur-sm"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <span className="px-2.5 py-0.5 rounded-md text-[11px] font-bold bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 truncate max-w-[150px]">
                    {item.subjectName}
                  </span>
                  <Badge
                    variant={
                      item.status === 'active'
                        ? 'success'
                        : item.status === 'draft'
                        ? 'warning'
                        : 'secondary'
                    }
                    className="capitalize"
                  >
                    {item.status}
                  </Badge>
                </div>

                <div className="flex items-start gap-3">
                  <div className="p-2.5 bg-slate-950/60 rounded-xl border border-white/10 shrink-0 mt-0.5">
                    {getFileIcon(item.fileType)}
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-white group-hover:text-indigo-300 transition-colors line-clamp-1">
                      {item.title}
                    </h3>
                    <p className="text-xs text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                      {item.description || 'No supplementary notes provided.'}
                    </p>
                  </div>
                </div>

                <div className="bg-slate-950/40 rounded-xl p-3 border border-white/5 space-y-1.5 text-xs">
                  <div className="flex items-center justify-between text-slate-300">
                    <span className="flex items-center gap-1.5 text-slate-400">
                      <GraduationCap className="w-3.5 h-3.5 text-slate-500" /> Shared With
                    </span>
                    <span className="font-semibold text-white">
                      {item.className} &bull; {item.sectionName}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-slate-300">
                    <span className="flex items-center gap-1.5 text-slate-400">
                      <Calendar className="w-3.5 h-3.5 text-slate-500" /> Uploaded
                    </span>
                    <span className="font-semibold text-slate-300">{item.uploadDate}</span>
                  </div>
                </div>

                {/* File chip */}
                <div className="flex items-center justify-between p-2.5 bg-indigo-950/30 rounded-xl border border-indigo-500/20 text-xs text-indigo-300">
                  <span className="truncate max-w-[180px] font-mono text-[11px]">{item.fileName}</span>
                  <span className="text-[10px] text-indigo-400 font-mono font-bold">{item.fileSize}</span>
                </div>
              </div>

              {/* Card Actions */}
              <div className="pt-4 mt-4 border-t border-white/5 flex items-center justify-between">
                <a
                  href={item.fileUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs text-indigo-400 hover:text-indigo-300 font-semibold flex items-center gap-1"
                >
                  <Download className="w-3.5 h-3.5" /> Download
                </a>

                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => openViewModal(item)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
                    title="View Details"
                  >
                    <Eye className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => openEditModal(item)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-400 hover:bg-white/10 transition-colors"
                    title="Edit Material"
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleToggleArchive(item)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-amber-400 hover:bg-white/10 transition-colors"
                    title={item.status === 'archived' ? 'Restore Material' : 'Archive Material'}
                  >
                    <Archive className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => openDeleteModal(item)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-white/10 transition-colors"
                    title="Delete Material"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* UPLOAD MODAL */}
      <Modal
        isOpen={showUploadModal}
        onClose={() => !saving && setShowUploadModal(false)}
        title="Upload Study Material / Resource"
        maxWidth="max-w-2xl"
      >
        <form onSubmit={handleUploadSubmit} className="space-y-4 text-sm">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
              Material Title <span className="text-rose-400">*</span>
            </label>
            <input
              type="text"
              required
              placeholder="e.g. Chapter 4 Trigonometric Identities Reference Cheatsheet"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              className="w-full px-3.5 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Target Class <span className="text-rose-400">*</span>
              </label>
              <select
                required
                value={formData.classId}
                onChange={(e) => {
                  const newClassId = e.target.value;
                  setFormData({
                    ...formData,
                    classId: newClassId,
                    sectionId: 'ALL'
                  });
                }}
                className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500"
              >
                <option value="">Select Class</option>
                {(classes || []).map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Section
              </label>
              <select
                value={formData.sectionId}
                onChange={(e) => setFormData({ ...formData, sectionId: e.target.value })}
                disabled={!formData.classId}
                className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500 disabled:opacity-50"
              >
                <option value="ALL">All Sections (Entire Class)</option>
                {(availableSectionsForForm || []).map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Subject <span className="text-rose-400">*</span>
              </label>
              <select
                required
                value={formData.subjectId}
                onChange={(e) => setFormData({ ...formData, subjectId: e.target.value })}
                className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500"
              >
                <option value="">Select Subject</option>
                {(subjects || []).map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name} ({s.code})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
              Description / Learning Objectives
            </label>
            <textarea
              rows={3}
              placeholder="Outline what this document covers and how students should use it..."
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              className="w-full px-3.5 py-2.5 bg-slate-950/60 border border-white/10 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
            />
          </div>

          {/* Upload Box */}
          <div className="bg-slate-950/40 p-4 rounded-xl border border-white/5 space-y-2">
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-300">
              Document / File Upload <span className="text-rose-400">*</span>
            </label>

            {formData.fileName ? (
              <div className="flex items-center justify-between p-3 bg-indigo-950/40 rounded-xl border border-indigo-500/30">
                <div className="flex items-center gap-3">
                  {getFileIcon(formData.fileType)}
                  <div>
                    <div className="text-xs font-bold text-white truncate max-w-[280px]">
                      {formData.fileName}
                    </div>
                    <div className="text-[10px] text-indigo-300 font-mono">
                      {formData.fileSize} &bull; Ready to publish
                    </div>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() =>
                    setFormData({
                      ...formData,
                      fileUrl: '',
                      fileName: '',
                      fileSize: '',
                      fileSizeBytes: 0,
                      fileType: 'pdf'
                    })
                  }
                  className="text-slate-400 hover:text-rose-400 p-1"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="relative border-2 border-dashed border-white/10 hover:border-indigo-500/40 rounded-xl p-6 text-center cursor-pointer transition-colors">
                <input
                  type="file"
                  required
                  onChange={handleFileUpload}
                  className="absolute inset-0 opacity-0 cursor-pointer"
                  disabled={uploadingFile}
                />
                <UploadCloud className="w-8 h-8 text-indigo-400 mx-auto mb-2" />
                <p className="text-sm font-semibold text-white">
                  {uploadingFile ? 'Scanning & Uploading File...' : 'Choose file or drag here'}
                </p>
                <p className="text-xs text-slate-400 mt-1">
                  Supports PDF, PowerPoint (.pptx), Word (.docx), Excel (.xlsx), ZIP (Up to 15MB)
                </p>
              </div>
            )}
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-white/10">
            <Button
              type="button"
              variant="outline"
              onClick={() => setShowUploadModal(false)}
              disabled={saving}
            >
              Cancel
            </Button>
            <Button type="submit" variant="primary" disabled={saving || uploadingFile || !formData.fileName}>
              {saving ? 'Publishing...' : 'Publish Study Material'}
            </Button>
          </div>
        </form>
      </Modal>

      {/* EDIT MODAL */}
      <Modal
        isOpen={showEditModal}
        onClose={() => !saving && setShowEditModal(false)}
        title="Edit Study Material"
        maxWidth="max-w-2xl"
      >
        <form onSubmit={handleEditSubmit} className="space-y-4 text-sm">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
              Title <span className="text-rose-400">*</span>
            </label>
            <input
              type="text"
              required
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              className="w-full px-3.5 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Class
              </label>
              <select
                value={formData.classId}
                onChange={(e) => {
                  const newClassId = e.target.value;
                  setFormData({
                    ...formData,
                    classId: newClassId,
                    sectionId: 'ALL'
                  });
                }}
                className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500"
              >
                {(classes || []).map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Section
              </label>
              <select
                value={formData.sectionId}
                onChange={(e) => setFormData({ ...formData, sectionId: e.target.value })}
                className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500"
              >
                <option value="ALL">All Sections</option>
                {(availableSectionsForForm || []).map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Subject
              </label>
              <select
                value={formData.subjectId}
                onChange={(e) => setFormData({ ...formData, subjectId: e.target.value })}
                className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500"
              >
                {(subjects || []).map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name} ({s.code})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
              Description
            </label>
            <textarea
              rows={3}
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              className="w-full px-3.5 py-2.5 bg-slate-950/60 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div className="bg-slate-950/40 p-4 rounded-xl border border-white/5 space-y-2">
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-300">
              Attached File
            </label>
            <div className="flex items-center justify-between p-3 bg-indigo-950/40 rounded-xl border border-indigo-500/30">
              <div className="flex items-center gap-3">
                {getFileIcon(formData.fileType)}
                <div>
                  <div className="text-xs font-bold text-white truncate max-w-[280px]">
                    {formData.fileName}
                  </div>
                  <div className="text-[10px] text-indigo-300 font-mono">
                    {formData.fileSize}
                  </div>
                </div>
              </div>
              <label className="px-3 py-1 bg-white/10 hover:bg-white/20 text-white rounded-lg text-xs font-semibold cursor-pointer">
                Replace
                <input type="file" onChange={handleFileUpload} className="hidden" />
              </label>
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-white/10">
            <Button
              type="button"
              variant="outline"
              onClick={() => setShowEditModal(false)}
              disabled={saving}
            >
              Cancel
            </Button>
            <Button type="submit" variant="primary" disabled={saving || uploadingFile}>
              {saving ? 'Saving...' : 'Save Changes'}
            </Button>
          </div>
        </form>
      </Modal>

      {/* VIEW MODAL */}
      <Modal
        isOpen={showViewModal}
        onClose={() => setShowViewModal(false)}
        title="Study Material Overview"
        maxWidth="max-w-xl"
      >
        {activeItem && (
          <div className="space-y-4 text-sm">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <span className="px-2.5 py-1 rounded-md text-xs font-bold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                {activeItem.subjectName}
              </span>
              <Badge variant={activeItem.status === 'active' ? 'success' : 'secondary'}>
                {activeItem.status}
              </Badge>
            </div>

            <div className="flex items-start gap-3">
              <div className="p-3 bg-slate-950/80 rounded-xl border border-white/10">
                {getFileIcon(activeItem.fileType)}
              </div>
              <div>
                <h2 className="text-xl font-bold text-white">{activeItem.title}</h2>
                <div className="flex items-center gap-4 text-xs text-slate-400 mt-1">
                  <span>Class: <strong className="text-white">{activeItem.className} ({activeItem.sectionName})</strong></span>
                  <span>Uploaded: <strong className="text-white">{activeItem.uploadDate}</strong></span>
                </div>
              </div>
            </div>

            <div className="bg-slate-950/50 p-4 rounded-xl border border-white/10 space-y-2">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Description & Notes</span>
              <p className="text-sm text-slate-200 whitespace-pre-wrap leading-relaxed">
                {activeItem.description || 'No detailed learning objectives provided.'}
              </p>
            </div>

            <div className="bg-indigo-950/30 p-4 rounded-xl border border-indigo-500/20 flex items-center justify-between">
              <div>
                <div className="text-xs font-bold text-white truncate max-w-[280px]">
                  {activeItem.fileName}
                </div>
                <div className="text-[10px] text-indigo-300 font-mono">
                  {activeItem.fileSize} &bull; Validated Safe
                </div>
              </div>
              <a
                href={activeItem.fileUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-lg shadow-indigo-600/30 transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                Download File
              </a>
            </div>

            <div className="pt-3 border-t border-white/10 flex items-center justify-between text-xs text-slate-500">
              <span>Teacher: {activeItem.teacherName}</span>
              <Button variant="outline" size="sm" onClick={() => setShowViewModal(false)}>
                Close
              </Button>
            </div>
          </div>
        )}
      </Modal>

      {/* DELETE MODAL */}
      <Modal
        isOpen={showDeleteModal}
        onClose={() => !saving && setShowDeleteModal(false)}
        title="Confirm Material Deletion"
        maxWidth="max-w-md"
      >
        <div className="space-y-4">
          <div className="flex items-center gap-3 p-3 bg-rose-950/30 rounded-xl border border-rose-500/30 text-rose-300 text-sm">
            <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />
            <p>
              Are you sure you want to delete <strong>{activeItem?.title}</strong>? This file will no longer be available to students.
            </p>
          </div>

          <div className="flex justify-end gap-3 pt-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => setShowDeleteModal(false)}
              disabled={saving}
            >
              Cancel
            </Button>
            <Button
              type="button"
              variant="danger"
              onClick={handleDeleteSubmit}
              disabled={saving}
            >
              {saving ? 'Deleting...' : 'Delete Permanently'}
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
