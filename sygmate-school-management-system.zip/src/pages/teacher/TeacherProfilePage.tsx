import React, { useState, useEffect, useRef } from 'react';
import {
  User,
  Phone,
  Mail,
  MapPin,
  Building,
  GraduationCap,
  Briefcase,
  Calendar,
  ShieldCheck,
  Lock,
  Camera,
  Upload,
  Trash2,
  Save,
  RotateCcw,
  CheckCircle2,
  Sparkles,
  BookOpen,
  Users,
  AlertCircle,
  FileText,
  ShieldAlert,
  CheckCircle,
  XCircle,
  Clock
} from 'lucide-react';
import { EntityDocumentChecklistModal } from '../../components/documents/EntityDocumentChecklistModal.js';
import { Button } from '../../components/ui/Button.js';
import { Badge } from '../../components/ui/Badge.js';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner.js';
import { useAuth } from '../../context/AuthContext.js';
import { useToast } from '../../context/ToastContext.js';
import { api } from '../../services/api.js';

interface TeacherProfilePageProps {
  onNavigate?: (viewId: string) => void;
}

export const TeacherProfilePage: React.FC<TeacherProfilePageProps> = ({ onNavigate }) => {
  const { user } = useAuth();
  const { showToast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [profileData, setProfileData] = useState<any>(null);

  // Editable form state
  const [phone, setPhone] = useState('');
  const [emergencyContact, setEmergencyContact] = useState('');
  const [address, setAddress] = useState('');
  const [avatarUrl, setAvatarUrl] = useState('');
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);

  // Part 15E — Teacher Documents State
  const [isDocumentsModalOpen, setIsDocumentsModalOpen] = useState(false);
  const [checklistSummary, setChecklistSummary] = useState<any>(null);

  const fetchProfile = async () => {
    try {
      setLoading(true);
      const res = await api.getMyProfile();
      if (res.success && res.data) {
        const prof = res.data.profile || {};
        const u = res.data.user || user;
        setProfileData({ ...prof, user: u });
        setPhone(prof.contactNumber || prof.phone || u.phoneNumber || '');
        setEmergencyContact(prof.emergencyContact || '');
        setAddress(prof.address || '');
        setAvatarUrl(prof.avatarUrl || u.avatarUrl || '');
        setPhotoPreview(prof.avatarUrl || u.avatarUrl || null);

        // Fetch teacher's authoritative document checklist
        if (prof.id) {
          try {
            const cl = await api.documents.getChecklist('TEACHER', prof.id);
            if (cl) setChecklistSummary((cl as any)?.data || cl);
          } catch {
            // Silently continue if checklist fails
          }
        }
      }
    } catch (err: any) {
      showToast('Failed to load profile data: ' + err.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProfile();
  }, [user]);

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      showToast('Please upload a valid image file (PNG, JPG, WebP)', 'error');
      return;
    }

    if (file.size > 2 * 1024 * 1024) {
      showToast('Image size exceeds 2MB limit', 'error');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      setPhotoPreview(result);
      setAvatarUrl(result);
      showToast('Photo selected. Click "Save Profile Changes" to persist.', 'info');
    };
    reader.readAsDataURL(file);
  };

  const handleRemovePhoto = () => {
    setPhotoPreview(null);
    setAvatarUrl('');
    if (fileInputRef.current) fileInputRef.current.value = '';
    showToast('Photo removed. Click "Save Changes" to finalize.', 'info');
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setSaving(true);
      const res = await api.updateMyProfile({
        phone: phone.trim(),
        contactNumber: phone.trim(),
        emergencyContact: emergencyContact.trim(),
        address: address.trim(),
        avatarUrl: avatarUrl
      });

      if (res.success) {
        showToast('Profile information successfully saved.', 'success');
        if (res.data?.profile) {
          setProfileData((prev: any) => ({ ...prev, ...res.data.profile }));
        }
      } else {
        showToast(res.error || 'Failed to update profile', 'error');
      }
    } catch (err: any) {
      showToast('Error saving profile: ' + err.message, 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleReset = () => {
    if (profileData) {
      setPhone(profileData.contactNumber || profileData.phone || '');
      setEmergencyContact(profileData.emergencyContact || '');
      setAddress(profileData.address || '');
      setAvatarUrl(profileData.avatarUrl || '');
      setPhotoPreview(profileData.avatarUrl || null);
      showToast('Form reset to saved values', 'info');
    }
  };

  if (loading) {
    return (
      <div className="py-24 flex justify-center">
        <LoadingSpinner size="lg" message="Loading your verified faculty profile..." />
      </div>
    );
  }

  const initials = `${profileData?.firstName?.[0] || 'T'}${profileData?.lastName?.[0] || 'P'}`;

  return (
    <div className="max-w-6xl mx-auto space-y-8 pb-12">
      {/* Top Banner with Profile Photo & Key Faculty Highlights */}
      <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-6 sm:p-8 shadow-xl shadow-black/20 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="flex flex-col md:flex-row items-center md:items-start gap-6 relative z-10">
          {/* Avatar with Camera Overlay */}
          <div className="relative group">
            <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-3xl overflow-hidden bg-indigo-600/80 border-2 border-indigo-400/50 flex items-center justify-center font-bold text-3xl text-white shadow-xl shadow-indigo-600/30">
              {photoPreview ? (
                <img
                  src={photoPreview}
                  alt="Teacher Profile"
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              ) : (
                <span>{initials}</span>
              )}
            </div>

            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="absolute -bottom-2 -right-2 p-2 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg border border-white/20 transition-transform active:scale-95 cursor-pointer"
              title="Upload photo"
              aria-label="Upload photo"
            >
              <Camera className="w-4 h-4" />
            </button>
            <input
              type="file"
              ref={fileInputRef}
              onChange={handlePhotoUpload}
              accept="image/png, image/jpeg, image/webp"
              className="hidden"
            />
          </div>

          {/* Teacher Summary Details */}
          <div className="flex-1 text-center md:text-left space-y-2">
            <div className="flex flex-wrap items-center justify-center md:justify-start gap-2.5">
              <h2 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
                {profileData?.firstName} {profileData?.lastName}
              </h2>
              <Badge variant="primary">Faculty Profile</Badge>
              <Badge variant={profileData?.status === 'ACTIVE' ? 'success' : 'neutral'}>
                {profileData?.status || 'Active'}
              </Badge>
            </div>

            <p className="text-sm text-indigo-300 font-medium">
              {profileData?.designation || 'Faculty Member'} • {profileData?.departmentName || profileData?.department || 'Academic Department'}
            </p>

            <div className="flex flex-wrap items-center justify-center md:justify-start gap-4 text-xs text-slate-400 pt-1 font-mono">
              <span className="flex items-center gap-1.5 bg-white/5 px-3 py-1 rounded-xl border border-white/5">
                <ShieldCheck className="w-3.5 h-3.5 text-indigo-400" />
                Employee ID: <strong className="text-white font-semibold">{profileData?.employeeCode || 'EMP-T-1004'}</strong>
              </span>
              <span className="flex items-center gap-1.5 bg-white/5 px-3 py-1 rounded-xl border border-white/5">
                <Calendar className="w-3.5 h-3.5 text-cyan-400" />
                Joined: <strong className="text-slate-200">{profileData?.joiningDate ? new Date(profileData.joiningDate).toLocaleDateString() : 'August 2024'}</strong>
              </span>
            </div>
          </div>

          {/* Quick Photo Actions & Document Vault */}
          <div className="flex flex-row md:flex-col gap-2">
            <Button
              size="xs"
              variant="primary"
              leftIcon={<FileText className="w-3.5 h-3.5" />}
              onClick={() => setIsDocumentsModalOpen(true)}
              className="bg-indigo-600 hover:bg-indigo-500 text-white shadow-md font-semibold"
            >
              Faculty Documents {checklistSummary ? `(${checklistSummary.compliancePercentage}%)` : ''}
            </Button>
            <Button
              size="xs"
              variant="outline"
              leftIcon={<Upload className="w-3.5 h-3.5" />}
              onClick={() => fileInputRef.current?.click()}
            >
              Change Photo
            </Button>
            {photoPreview && (
              <Button
                size="xs"
                variant="danger"
                leftIcon={<Trash2 className="w-3.5 h-3.5" />}
                onClick={handleRemovePhoto}
              >
                Remove
              </Button>
            )}
          </div>
        </div>
      </div>

      <form onSubmit={handleSave} className="space-y-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Column 1 & 2: Editable & Verified Profile Details */}
          <div className="lg:col-span-2 space-y-6">
            {/* Self-Service Editable Card */}
            <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-6 sm:p-8 shadow-xl shadow-black/20 space-y-6">
              <div className="flex items-center justify-between border-b border-white/10 pb-4">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400">
                    <User className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-white">Contact & Personal Information</h3>
                    <p className="text-xs text-slate-400">Self-service editable information</p>
                  </div>
                </div>
                <Badge variant="primary">Self-Service</Badge>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                    Contact Phone Number <span className="text-indigo-400">*</span>
                  </label>
                  <div className="relative">
                    <Phone className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="tel"
                      id="teacher-profile-phone"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="+1 (555) 000-0000"
                      className="w-full bg-white/5 border border-white/10 rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
                      required
                    />
                  </div>
                  <p className="text-[10px] text-slate-400 mt-1">Used for administrative and school SMS notifications.</p>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                    Emergency Contact Number
                  </label>
                  <div className="relative">
                    <Phone className="w-4 h-4 text-rose-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="tel"
                      id="teacher-profile-emergency"
                      value={emergencyContact}
                      onChange={(e) => setEmergencyContact(e.target.value)}
                      placeholder="+1 (555) 999-8888"
                      className="w-full bg-white/5 border border-white/10 rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
                    />
                  </div>
                  <p className="text-[10px] text-slate-400 mt-1">Emergency contact / next of kin.</p>
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                    Residential Address
                  </label>
                  <div className="relative">
                    <MapPin className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                    <textarea
                      id="teacher-profile-address"
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      rows={3}
                      placeholder="Enter street address, city, state, postal code"
                      className="w-full bg-white/5 border border-white/10 rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
                    />
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
                <Button
                  type="button"
                  variant="glass"
                  size="sm"
                  leftIcon={<RotateCcw className="w-3.5 h-3.5" />}
                  onClick={handleReset}
                  disabled={saving}
                >
                  Reset
                </Button>
                <Button
                  type="submit"
                  variant="primary"
                  size="sm"
                  leftIcon={saving ? undefined : <Save className="w-3.5 h-3.5" />}
                  disabled={saving}
                >
                  {saving ? 'Saving...' : 'Save Profile Changes'}
                </Button>
              </div>
            </div>

            {/* Read-Only Institutional & Academic Credentials */}
            <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-6 sm:p-8 shadow-xl shadow-black/20 space-y-6">
              <div className="flex items-center justify-between border-b border-white/10 pb-4">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400">
                    <Lock className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-white">Administrative & Academic Credentials</h3>
                    <p className="text-xs text-slate-400">Protected fields managed strictly by School Administration</p>
                  </div>
                </div>
                <Badge variant="warning">Admin Controlled</Badge>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 text-xs">
                <div className="p-3.5 bg-white/[0.02] border border-white/5 rounded-2xl space-y-1">
                  <span className="text-slate-400 text-[11px] font-medium flex items-center gap-1">
                    <Mail className="w-3 h-3 text-slate-400" /> Institutional Email
                  </span>
                  <p className="text-white font-mono font-semibold">{profileData?.email || 'prof.sterling@sygmate.edu'}</p>
                </div>

                <div className="p-3.5 bg-white/[0.02] border border-white/5 rounded-2xl space-y-1">
                  <span className="text-slate-400 text-[11px] font-medium flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3 text-slate-400" /> Employee Code
                  </span>
                  <p className="text-white font-mono font-semibold">{profileData?.employeeCode || 'EMP-T-1004'}</p>
                </div>

                <div className="p-3.5 bg-white/[0.02] border border-white/5 rounded-2xl space-y-1">
                  <span className="text-slate-400 text-[11px] font-medium flex items-center gap-1">
                    <Building className="w-3 h-3 text-slate-400" /> Department
                  </span>
                  <p className="text-white font-semibold">{profileData?.departmentName || profileData?.department || 'Natural Sciences'}</p>
                </div>

                <div className="p-3.5 bg-white/[0.02] border border-white/5 rounded-2xl space-y-1">
                  <span className="text-slate-400 text-[11px] font-medium flex items-center gap-1">
                    <Briefcase className="w-3 h-3 text-slate-400" /> Academic Designation
                  </span>
                  <p className="text-white font-semibold">{profileData?.designation || 'Senior Faculty'}</p>
                </div>

                <div className="p-3.5 bg-white/[0.02] border border-white/5 rounded-2xl space-y-1">
                  <span className="text-slate-400 text-[11px] font-medium flex items-center gap-1">
                    <GraduationCap className="w-3 h-3 text-slate-400" /> Academic Qualification
                  </span>
                  <p className="text-white font-semibold">{profileData?.qualification || 'Ph.D. / M.Sc. in Discipline'}</p>
                </div>

                <div className="p-3.5 bg-white/[0.02] border border-white/5 rounded-2xl space-y-1">
                  <span className="text-slate-400 text-[11px] font-medium flex items-center gap-1">
                    <Calendar className="w-3 h-3 text-slate-400" /> Employment Contract
                  </span>
                  <p className="text-emerald-300 font-semibold">{profileData?.employmentStatus || 'Full-Time Academic Faculty'}</p>
                </div>
              </div>
            </div>

            {/* Part 15E — Faculty Document Compliance & Credentials Card */}
            <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-6 sm:p-8 shadow-xl shadow-black/20 space-y-5">
              <div className="flex items-center justify-between border-b border-white/10 pb-4 flex-wrap gap-2">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400">
                    <FileText className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-white">Faculty Documents &amp; Credentials</h3>
                    <p className="text-xs text-slate-400">Accreditation, licenses, diplomas, and official employment records</p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {checklistSummary && (
                    <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
                      {checklistSummary.compliancePercentage}% Compliance
                    </span>
                  )}
                  <Button
                    type="button"
                    size="xs"
                    variant="primary"
                    onClick={() => setIsDocumentsModalOpen(true)}
                    className="bg-indigo-600 hover:bg-indigo-500 text-white font-semibold"
                  >
                    Open Document Vault
                  </Button>
                </div>
              </div>

              {/* Status Metric Blocks */}
              {checklistSummary && (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  <div className="p-3 rounded-2xl bg-emerald-500/5 border border-emerald-500/20 space-y-1">
                    <div className="flex items-center justify-between text-emerald-400">
                      <span className="font-semibold text-[11px] uppercase tracking-wider">Verified</span>
                      <CheckCircle className="w-3.5 h-3.5" />
                    </div>
                    <div className="text-xl font-bold text-emerald-300">{checklistSummary.verifiedItems}</div>
                    <span className="text-[10px] text-slate-400">Credentials approved</span>
                  </div>

                  <div className="p-3 rounded-2xl bg-amber-500/5 border border-amber-500/20 space-y-1">
                    <div className="flex items-center justify-between text-amber-400">
                      <span className="font-semibold text-[11px] uppercase tracking-wider">In Review</span>
                      <Clock className="w-3.5 h-3.5" />
                    </div>
                    <div className="text-xl font-bold text-amber-300">{checklistSummary.pendingReviewItems}</div>
                    <span className="text-[10px] text-slate-400">Pending HR review</span>
                  </div>

                  <div className="p-3 rounded-2xl bg-rose-500/5 border border-rose-500/20 space-y-1">
                    <div className="flex items-center justify-between text-rose-400">
                      <span className="font-semibold text-[11px] uppercase tracking-wider">Missing</span>
                      <XCircle className="w-3.5 h-3.5" />
                    </div>
                    <div className="text-xl font-bold text-rose-300">{checklistSummary.missingRequired}</div>
                    <span className="text-[10px] text-slate-400">Mandatory to upload</span>
                  </div>

                  <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
                    <div className="flex items-center justify-between text-slate-400">
                      <span className="font-semibold text-[11px] uppercase tracking-wider">Total</span>
                      <ShieldCheck className="w-3.5 h-3.5 text-indigo-400" />
                    </div>
                    <div className="text-xl font-bold text-white">{checklistSummary.totalRequired + checklistSummary.totalOptional}</div>
                    <span className="text-[10px] text-slate-400">Tracked criteria</span>
                  </div>
                </div>
              )}

              {/* Quick Summary of Checklist items */}
              {checklistSummary?.items && checklistSummary.items.length > 0 ? (
                <div className="space-y-2">
                  <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                    Required Credentials Status
                  </div>
                  <div className="space-y-1.5">
                    {checklistSummary.items.slice(0, 4).map((item: any) => (
                      <div
                        key={item.documentTypeId}
                        className="p-3 rounded-xl bg-white/[0.02] border border-white/5 flex items-center justify-between text-xs"
                      >
                        <div className="flex items-center gap-2.5">
                          <FileText className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                          <div>
                            <span className="font-semibold text-white">{item.documentTypeName}</span>
                            {item.document && (
                              <span className="text-[10px] text-slate-400 ml-2 font-mono">
                                ({item.document.fileName})
                              </span>
                            )}
                          </div>
                        </div>

                        <div>
                          {item.status === 'VERIFIED' ? (
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                              Verified
                            </span>
                          ) : item.status === 'PENDING_REVIEW' ? (
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/10 text-amber-400 border border-amber-500/20">
                              Pending Review
                            </span>
                          ) : item.status === 'REJECTED' ? (
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-500/10 text-rose-400 border border-rose-500/20">
                              Rejected
                            </span>
                          ) : item.status === 'EXPIRED' ? (
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-500/10 text-purple-400 border border-purple-500/20">
                              Expired
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-slate-400 border border-slate-700">
                              Missing
                            </span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/5 text-center text-xs text-slate-400">
                  Click &ldquo;Open Document Vault&rdquo; to view and upload academic degrees, licenses, and employment contracts.
                </div>
              )}
            </div>
          </div>

          {/* Column 3: Academic Assignments & Quick Summary */}
          <div className="space-y-6">
            {/* Assigned Classes */}
            <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-6 shadow-xl shadow-black/20 space-y-4">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <GraduationCap className="w-4 h-4 text-indigo-400" />
                  <span>Assigned Classes</span>
                </h3>
                <span className="text-xs font-mono font-bold text-indigo-300">
                  {profileData?.assignedClasses?.length || profileData?.assignedClassIds?.length || 0} Classes
                </span>
              </div>

              <div className="space-y-2.5">
                {(profileData?.assignedClasses?.length || 0) > 0 ? (
                  profileData.assignedClasses.map((cls: any, idx: number) => (
                    <div
                      key={`${cls.id}-${idx}`}
                      className="p-3 bg-white/5 rounded-2xl border border-white/5 flex items-center justify-between text-xs hover:border-indigo-500/30 transition-colors"
                    >
                      <div>
                        <p className="font-bold text-white">{cls.name}</p>
                        <p className="text-[10px] text-slate-400">Class Code: {cls.code || cls.id}</p>
                      </div>
                      <Badge variant="primary">{cls.numericGrade ? `Grade ${cls.numericGrade}` : 'Active'}</Badge>
                    </div>
                  ))
                ) : (
                  <div className="p-4 text-center text-xs text-slate-400 bg-white/[0.02] rounded-2xl">
                    No classes currently assigned.
                  </div>
                )}
              </div>

              {onNavigate && (
                <Button
                  size="xs"
                  variant="glass"
                  className="w-full mt-2"
                  onClick={() => onNavigate('teacher-classes')}
                >
                  Open Assigned Classes
                </Button>
              )}
            </div>

            {/* Assigned Subjects */}
            <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-6 shadow-xl shadow-black/20 space-y-4">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-cyan-400" />
                  <span>Assigned Subjects</span>
                </h3>
                <span className="text-xs font-mono font-bold text-cyan-300">
                  {profileData?.assignedSubjects?.length || profileData?.assignedSubjectIds?.length || 0} Subjects
                </span>
              </div>

              <div className="space-y-2.5">
                {(profileData?.assignedSubjects?.length || 0) > 0 ? (
                  profileData.assignedSubjects.map((sub: any) => (
                    <div
                      key={sub.id}
                      className="p-3 bg-white/5 rounded-2xl border border-white/5 flex items-center justify-between text-xs hover:border-cyan-500/30 transition-colors"
                    >
                      <div>
                        <p className="font-bold text-white">{sub.name}</p>
                        <p className="text-[10px] text-slate-400 font-mono">{sub.code} • {sub.credits} Credits</p>
                      </div>
                      <Badge variant="neutral">{sub.type}</Badge>
                    </div>
                  ))
                ) : (
                  <div className="p-4 text-center text-xs text-slate-400 bg-white/[0.02] rounded-2xl">
                    No subjects currently assigned.
                  </div>
                )}
              </div>

              {onNavigate && (
                <Button
                  size="xs"
                  variant="glass"
                  className="w-full mt-2"
                  onClick={() => onNavigate('teacher-subjects')}
                >
                  Open My Subjects
                </Button>
              )}
            </div>

            {/* Security Notice */}
            <div className="p-4 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 text-xs text-indigo-300 flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 text-indigo-400 flex-shrink-0 mt-0.5" />
              <p className="leading-relaxed">
                To update administrative details, qualifications, or department transfers, please submit an official request to the Academic Registrar or Super Admin.
              </p>
            </div>
          </div>
        </div>
      </form>

      {/* Part 15E — Faculty Document Checklist Modal */}
      {profileData?.id && (
        <EntityDocumentChecklistModal
          entityType="TEACHER"
          entityId={profileData.id}
          entityName={`${profileData.firstName || ''} ${profileData.lastName || ''}`.trim() || 'Faculty Member'}
          isOpen={isDocumentsModalOpen}
          onClose={() => {
            setIsDocumentsModalOpen(false);
            fetchProfile();
          }}
          canVerify={false}
          onDocumentUpdated={fetchProfile}
        />
      )}
    </div>
  );
};
