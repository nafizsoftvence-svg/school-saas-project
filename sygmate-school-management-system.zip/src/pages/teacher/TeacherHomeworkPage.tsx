import React, { useEffect, useState, useMemo } from 'react';
import {
  BookCheck,
  Plus,
  Search,
  Filter,
  Calendar,
  Clock,
  CheckCircle2,
  AlertCircle,
  FileText,
  Paperclip,
  Trash2,
  Edit3,
  Eye,
  Archive,
  RefreshCw,
  Sparkles,
  GraduationCap,
  BookOpen,
  ArrowRight,
  Download,
  ExternalLink,
  Layers,
  UploadCloud,
  X
} from 'lucide-react';
import { api } from '../../services/api.js';
import { useAuth } from '../../context/AuthContext.js';
import { useToast } from '../../context/ToastContext.js';
import {
  Homework,
  HomeworkFilterParams,
  TeacherClassInfo,
  TeacherSubjectBrief
} from '../../types/index.js';
import { Button } from '../../components/ui/Button.js';
import { Badge } from '../../components/ui/Badge.js';
import { Modal } from '../../components/ui/Modal.js';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner.js';

interface TeacherHomeworkPageProps {
  onNavigate?: (viewId: string) => void;
}

export const TeacherHomeworkPage: React.FC<TeacherHomeworkPageProps> = ({ onNavigate }) => {
  const { user } = useAuth();
  const { showToast } = useToast();

  // Data state
  const [homeworkList, setHomeworkList] = useState<Homework[]>([]);
  const [loading, setLoading] = useState(true);
  const [classes, setClasses] = useState<TeacherClassInfo[]>([]);
  const [subjects, setSubjects] = useState<TeacherSubjectBrief[]>([]);

  // Filter state
  const [search, setSearch] = useState('');
  const [selectedClassId, setSelectedClassId] = useState('ALL');
  const [selectedSectionId, setSelectedSectionId] = useState('ALL');
  const [selectedSubjectId, setSelectedSubjectId] = useState('ALL');
  const [selectedStatus, setSelectedStatus] = useState('ALL');
  const [selectedDueDate, setSelectedDueDate] = useState('');

  // Modals state
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showViewModal, setShowViewModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [activeItem, setActiveItem] = useState<Homework | null>(null);

  // Form state
  const [formData, setFormData] = useState<{
    title: string;
    description: string;
    classId: string;
    sectionId: string;
    subjectId: string;
    dueDate: string;
    assignedDate: string;
    attachmentUrl: string;
    attachmentName: string;
    attachmentSize: string;
    attachmentType: string;
    status: 'draft' | 'published' | 'archived';
  }>({
    title: '',
    description: '',
    classId: '',
    sectionId: '',
    subjectId: '',
    dueDate: '',
    assignedDate: new Date().toISOString().split('T')[0],
    attachmentUrl: '',
    attachmentName: '',
    attachmentSize: '',
    attachmentType: '',
    status: 'published'
  });

  const [uploadingFile, setUploadingFile] = useState(false);
  const [saving, setSaving] = useState(false);

  // Load teacher classes & subjects context
  const loadContext = async () => {
    try {
      const [classesRes, subjectsRes] = await Promise.all([
        api.getMyTeacherClasses(),
        api.getMyTeacherSubjects()
      ]);

      if (classesRes.success && classesRes.data) {
        setClasses(classesRes.data);
      }
      if (subjectsRes.success && subjectsRes.data) {
        setSubjects(subjectsRes.data);
      }
    } catch (err: any) {
      console.error('Failed to load teacher context', err);
    }
  };

  // Fetch homework list
  const loadHomework = async () => {
    try {
      setLoading(true);
      const params: HomeworkFilterParams = {
        classId: selectedClassId,
        sectionId: selectedSectionId,
        subjectId: selectedSubjectId,
        status: selectedStatus,
        dueDate: selectedDueDate,
        search
      };
      const res = await api.activities.getHomework(params);
      if (res.success && res.data) {
        setHomeworkList(res.data);
      }
    } catch (err: any) {
      console.error('Failed to load homework', err);
      showToast(err.message || 'Could not fetch homework list', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadContext();
  }, []);

  useEffect(() => {
    loadHomework();
  }, [selectedClassId, selectedSectionId, selectedSubjectId, selectedStatus, selectedDueDate]);

  // Derived sections for the selected class in the form
  const availableSectionsForForm = useMemo(() => {
    if (!formData.classId) return [];
    const cls = (classes || []).find((c) => c?.id === formData.classId);
    return cls?.sections || [];
  }, [formData.classId, classes]);

  // Derived sections for filter
  const availableSectionsForFilter = useMemo(() => {
    if (!selectedClassId || selectedClassId === 'ALL') return [];
    const cls = (classes || []).find((c) => c?.id === selectedClassId);
    return cls?.sections || [];
  }, [selectedClassId, classes]);

  // Handle File Upload Simulator
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setUploadingFile(true);
      const res = await api.activities.uploadFile({
        fileName: file.name,
        fileSizeBytes: file.size,
        fileType: file.name.split('.').pop() || 'pdf'
      });

      if (res.success && res.data) {
        setFormData((prev) => ({
          ...prev,
          attachmentUrl: res.data.fileUrl,
          attachmentName: res.data.fileName,
          attachmentSize: res.data.fileSize,
          attachmentType: res.data.fileType
        }));
        showToast('Attachment uploaded and verified successfully', 'success');
      }
    } catch (err: any) {
      showToast(err.message || 'File upload failed', 'error');
    } finally {
      setUploadingFile(false);
    }
  };

  // Open Create Modal
  const openCreateModal = () => {
    const defaultClass = classes?.[0];
    const defaultSection = defaultClass?.sections?.[0];
    const defaultSubject = subjects?.[0];

    const today = new Date();
    const nextWeek = new Date(today);
    nextWeek.setDate(today.getDate() + 7);

    setFormData({
      title: '',
      description: '',
      classId: defaultClass?.id || '',
      sectionId: defaultSection?.id || '',
      subjectId: defaultSubject?.id || '',
      dueDate: nextWeek.toISOString().split('T')[0],
      assignedDate: today.toISOString().split('T')[0],
      attachmentUrl: '',
      attachmentName: '',
      attachmentSize: '',
      attachmentType: '',
      status: 'published'
    });
    setShowCreateModal(true);
  };

  // Open Edit Modal
  const openEditModal = (item: Homework) => {
    setActiveItem(item);
    setFormData({
      title: item.title,
      description: item.description,
      classId: item.classId,
      sectionId: item.sectionId,
      subjectId: item.subjectId,
      dueDate: item.dueDate,
      assignedDate: item.assignedDate,
      attachmentUrl: item.attachmentUrl || '',
      attachmentName: item.attachmentName || '',
      attachmentSize: item.attachmentSize || '',
      attachmentType: item.attachmentType || '',
      status: item.status
    });
    setShowEditModal(true);
  };

  // Open View Modal
  const openViewModal = (item: Homework) => {
    setActiveItem(item);
    setShowViewModal(true);
  };

  // Open Delete Modal
  const openDeleteModal = (item: Homework) => {
    setActiveItem(item);
    setShowDeleteModal(true);
  };

  // Submit Create
  const handleCreateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title.trim()) {
      showToast('Please enter a homework title', 'error');
      return;
    }
    if (!formData.classId || !formData.sectionId || !formData.subjectId) {
      showToast('Please specify Class, Section, and Subject', 'error');
      return;
    }
    if (!formData.dueDate) {
      showToast('Please specify a due date', 'error');
      return;
    }

    try {
      setSaving(true);
      const res = await api.activities.createHomework(formData);
      if (res.success && res.data) {
        showToast('Homework created and published successfully', 'success');
        setShowCreateModal(false);
        loadHomework();
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to create homework', 'error');
    } finally {
      setSaving(false);
    }
  };

  // Submit Edit
  const handleEditSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeItem) return;

    try {
      setSaving(true);
      const res = await api.activities.updateHomework(activeItem.id, formData);
      if (res.success && res.data) {
        showToast('Homework updated successfully', 'success');
        setShowEditModal(false);
        loadHomework();
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to update homework', 'error');
    } finally {
      setSaving(false);
    }
  };

  // Submit Delete
  const handleDeleteSubmit = async () => {
    if (!activeItem) return;
    try {
      setSaving(true);
      const res = await api.activities.deleteHomework(activeItem.id);
      if (res.success) {
        showToast('Homework deleted successfully', 'success');
        setShowDeleteModal(false);
        loadHomework();
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to delete homework', 'error');
    } finally {
      setSaving(false);
    }
  };

  // Quick Archive
  const handleQuickArchive = async (item: Homework) => {
    try {
      const newStatus = item.status === 'archived' ? 'published' : 'archived';
      await api.activities.updateHomework(item.id, { status: newStatus });
      showToast(`Homework ${newStatus === 'archived' ? 'archived' : 'restored'} successfully`, 'info');
      loadHomework();
    } catch (err: any) {
      showToast(err.message || 'Failed to update status', 'error');
    }
  };

  // Summary statistics
  const stats = useMemo(() => {
    const total = homeworkList.length;
    const published = homeworkList.filter((h) => h.status === 'published').length;
    const drafts = homeworkList.filter((h) => h.status === 'draft').length;
    const archived = homeworkList.filter((h) => h.status === 'archived').length;
    return { total, published, drafts, archived };
  }, [homeworkList]);

  return (
    <div className="space-y-8 pb-12">
      {/* Page Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-slate-900/60 p-6 rounded-2xl border border-white/10 backdrop-blur-xl">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 uppercase tracking-wider">
              Academic Operations
            </span>
            <span className="text-xs text-slate-400 font-medium">Part 3D</span>
          </div>
          <h1 className="text-2xl font-black tracking-tight text-white flex items-center gap-2">
            <BookCheck className="w-6 h-6 text-indigo-400" />
            Homework Management
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Create, assign, and distribute daily homework to authorized classes, sections, and subjects.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <Button
            variant="outline"
            size="sm"
            onClick={loadHomework}
            disabled={loading}
            className="flex items-center gap-1.5"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
          <Button
            variant="primary"
            size="sm"
            onClick={openCreateModal}
            className="flex items-center gap-2 shadow-lg shadow-indigo-600/30"
          >
            <Plus className="w-4 h-4" />
            Create Homework
          </Button>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-slate-900/50 p-4 rounded-xl border border-white/10 backdrop-blur-sm">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">Total Homework</span>
          <div className="text-2xl font-black text-white mt-1">{stats.total}</div>
          <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-1">
            <BookOpen className="w-3 h-3 text-indigo-400" /> Active curriculum records
          </div>
        </div>
        <div className="bg-slate-900/50 p-4 rounded-xl border border-white/10 backdrop-blur-sm">
          <span className="text-xs font-semibold uppercase tracking-wider text-emerald-400">Published</span>
          <div className="text-2xl font-black text-emerald-400 mt-1">{stats.published}</div>
          <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3 text-emerald-400" /> Visible to students
          </div>
        </div>
        <div className="bg-slate-900/50 p-4 rounded-xl border border-white/10 backdrop-blur-sm">
          <span className="text-xs font-semibold uppercase tracking-wider text-amber-400">Drafts</span>
          <div className="text-2xl font-black text-amber-400 mt-1">{stats.drafts}</div>
          <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-1">
            <Clock className="w-3 h-3 text-amber-400" /> In preparation
          </div>
        </div>
        <div className="bg-slate-900/50 p-4 rounded-xl border border-white/10 backdrop-blur-sm">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">Archived</span>
          <div className="text-2xl font-black text-slate-300 mt-1">{stats.archived}</div>
          <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-1">
            <Archive className="w-3 h-3 text-slate-400" /> Stored for reference
          </div>
        </div>
      </div>

      {/* Search & Filter Toolbar */}
      <div className="bg-slate-900/50 p-5 rounded-2xl border border-white/10 backdrop-blur-xl space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-3">
          {/* Search Input */}
          <div className="lg:col-span-2 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search homework by title or topic..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && loadHomework()}
              className="w-full pl-10 pr-4 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-colors"
            />
          </div>

          {/* Class Filter */}
          <div>
            <select
              value={selectedClassId}
              onChange={(e) => {
                setSelectedClassId(e.target.value);
                setSelectedSectionId('ALL');
              }}
              className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:border-indigo-500 transition-colors"
            >
              <option value="ALL">All Assigned Classes</option>
              {(classes || []).map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          {/* Section Filter */}
          <div>
            <select
              value={selectedSectionId}
              onChange={(e) => setSelectedSectionId(e.target.value)}
              disabled={selectedClassId === 'ALL'}
              className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:border-indigo-500 transition-colors disabled:opacity-50"
            >
              <option value="ALL">All Sections</option>
              {(availableSectionsForFilter || []).map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
          </div>

          {/* Subject Filter */}
          <div>
            <select
              value={selectedSubjectId}
              onChange={(e) => setSelectedSubjectId(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:border-indigo-500 transition-colors"
            >
              <option value="ALL">All My Subjects</option>
              {(subjects || []).map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.code})
                </option>
              ))}
            </select>
          </div>

          {/* Status Filter */}
          <div>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:border-indigo-500 transition-colors"
            >
              <option value="ALL">All Statuses</option>
              <option value="published">Published</option>
              <option value="draft">Draft</option>
              <option value="archived">Archived</option>
            </select>
          </div>
        </div>

        {/* Active Filter Chips & Reset */}
        {(selectedClassId !== 'ALL' ||
          selectedSectionId !== 'ALL' ||
          selectedSubjectId !== 'ALL' ||
          selectedStatus !== 'ALL' ||
          search.trim() !== '') && (
          <div className="flex items-center justify-between pt-2 border-t border-white/5 text-xs text-slate-400">
            <div className="flex items-center gap-2">
              <Filter className="w-3.5 h-3.5 text-indigo-400" />
              <span>Active filters applied</span>
            </div>
            <button
              onClick={() => {
                setSearch('');
                setSelectedClassId('ALL');
                setSelectedSectionId('ALL');
                setSelectedSubjectId('ALL');
                setSelectedStatus('ALL');
                setSelectedDueDate('');
              }}
              className="text-indigo-400 hover:text-indigo-300 font-semibold cursor-pointer"
            >
              Reset Filters
            </button>
          </div>
        )}
      </div>

      {/* Homework Grid / Table */}
      {loading ? (
        <div className="py-20 flex justify-center">
          <LoadingSpinner size="lg" message="Loading homework assignments..." />
        </div>
      ) : homeworkList.length === 0 ? (
        <div className="bg-slate-900/40 p-12 rounded-2xl border border-white/10 text-center space-y-4">
          <div className="w-12 h-12 bg-indigo-600/20 text-indigo-400 rounded-2xl flex items-center justify-center mx-auto border border-indigo-500/30">
            <BookCheck className="w-6 h-6" />
          </div>
          <div className="space-y-1">
            <h3 className="text-lg font-bold text-white">No Homework Found</h3>
            <p className="text-sm text-slate-400 max-w-md mx-auto">
              No homework records match your current filter criteria. Create a new homework task to get started.
            </p>
          </div>
          <Button variant="primary" size="sm" onClick={openCreateModal}>
            <Plus className="w-4 h-4 mr-1.5" />
            Create First Homework
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {(homeworkList || []).map((item) => (
            <div
              key={item.id}
              className="bg-slate-900/60 rounded-2xl border border-white/10 hover:border-indigo-500/40 p-5 flex flex-col justify-between transition-all duration-200 hover:shadow-xl hover:shadow-indigo-950/40 group backdrop-blur-sm"
            >
              <div className="space-y-3">
                {/* Header tags */}
                <div className="flex items-center justify-between gap-2">
                  <span className="px-2.5 py-0.5 rounded-md text-[11px] font-bold bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 truncate max-w-[150px]">
                    {item.subjectName}
                  </span>
                  <Badge
                    variant={
                      item.status === 'published'
                        ? 'success'
                        : item.status === 'draft'
                        ? 'warning'
                        : 'secondary'
                    }
                    className="capitalize"
                  >
                    {item.status}
                  </Badge>
                </div>

                {/* Title & Description */}
                <div>
                  <h3 className="text-base font-bold text-white group-hover:text-indigo-300 transition-colors line-clamp-1">
                    {item.title}
                  </h3>
                  <p className="text-xs text-slate-400 mt-1.5 line-clamp-2 leading-relaxed">
                    {item.description || 'No detailed instructions provided.'}
                  </p>
                </div>

                {/* Class / Section / Due Date Badges */}
                <div className="bg-slate-950/40 rounded-xl p-3 border border-white/5 space-y-2 text-xs">
                  <div className="flex items-center justify-between text-slate-300">
                    <span className="flex items-center gap-1.5 text-slate-400">
                      <GraduationCap className="w-3.5 h-3.5 text-slate-500" /> Target
                    </span>
                    <span className="font-semibold text-white">
                      {item.className} &bull; {item.sectionName}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-slate-300">
                    <span className="flex items-center gap-1.5 text-slate-400">
                      <Calendar className="w-3.5 h-3.5 text-slate-500" /> Due Date
                    </span>
                    <span className="font-semibold text-amber-400">{item.dueDate}</span>
                  </div>
                </div>

                {/* Attachment info */}
                {item.attachmentName && (
                  <div className="flex items-center gap-2 p-2 bg-indigo-950/30 rounded-lg border border-indigo-500/20 text-xs text-indigo-300">
                    <Paperclip className="w-3.5 h-3.5 shrink-0" />
                    <span className="truncate flex-1">{item.attachmentName}</span>
                    {item.attachmentSize && (
                      <span className="text-[10px] text-indigo-400 font-mono">{item.attachmentSize}</span>
                    )}
                  </div>
                )}
              </div>

              {/* Card Footer Actions */}
              <div className="pt-4 mt-4 border-t border-white/5 flex items-center justify-between">
                <span className="text-[10px] text-slate-500">
                  Assigned: {item.assignedDate}
                </span>

                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => openViewModal(item)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
                    title="View Details"
                  >
                    <Eye className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => openEditModal(item)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-400 hover:bg-white/10 transition-colors"
                    title="Edit Homework"
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleQuickArchive(item)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-amber-400 hover:bg-white/10 transition-colors"
                    title={item.status === 'archived' ? 'Restore Homework' : 'Archive Homework'}
                  >
                    <Archive className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => openDeleteModal(item)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-white/10 transition-colors"
                    title="Delete Homework"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* CREATE MODAL */}
      <Modal
        isOpen={showCreateModal}
        onClose={() => !saving && setShowCreateModal(false)}
        title="Create New Homework Assignment"
        maxWidth="max-w-2xl"
      >
        <form onSubmit={handleCreateSubmit} className="space-y-4 text-sm">
          {/* Title */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
              Homework Title <span className="text-rose-400">*</span>
            </label>
            <input
              type="text"
              required
              placeholder="e.g. Chapter 4 Trigonometry & Problem Set 4.2"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              className="w-full px-3.5 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
            />
          </div>

          {/* Class, Section, Subject Row */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Class <span className="text-rose-400">*</span>
              </label>
              <select
                required
                value={formData.classId}
                onChange={(e) => {
                  const newClassId = e.target.value;
                  const cls = (classes || []).find((c) => c?.id === newClassId);
                  setFormData({
                    ...formData,
                    classId: newClassId,
                    sectionId: cls?.sections?.[0]?.id || ''
                  });
                }}
                className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500"
              >
                <option value="">Select Authorized Class</option>
                {(classes || []).map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Section <span className="text-rose-400">*</span>
              </label>
              <select
                required
                value={formData.sectionId}
                onChange={(e) => setFormData({ ...formData, sectionId: e.target.value })}
                disabled={!formData.classId}
                className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500 disabled:opacity-50"
              >
                <option value="">Select Section</option>
                {(availableSectionsForForm || []).map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Subject <span className="text-rose-400">*</span>
              </label>
              <select
                required
                value={formData.subjectId}
                onChange={(e) => setFormData({ ...formData, subjectId: e.target.value })}
                className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500"
              >
                <option value="">Select Subject</option>
                {(subjects || []).map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name} ({s.code})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Dates & Status */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Assigned Date
              </label>
              <input
                type="date"
                value={formData.assignedDate}
                onChange={(e) => setFormData({ ...formData, assignedDate: e.target.value })}
                className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Due Date <span className="text-rose-400">*</span>
              </label>
              <input
                type="date"
                required
                value={formData.dueDate}
                onChange={(e) => setFormData({ ...formData, dueDate: e.target.value })}
                className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Status
              </label>
              <select
                value={formData.status}
                onChange={(e) => setFormData({ ...formData, status: e.target.value as any })}
                className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500"
              >
                <option value="published">Published</option>
                <option value="draft">Draft</option>
              </select>
            </div>
          </div>

          {/* Description / Instructions */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
              Homework Description & Instructions
            </label>
            <textarea
              rows={4}
              placeholder="Provide clear steps, questions, textbook references, or guidelines..."
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              className="w-full px-3.5 py-2.5 bg-slate-950/60 border border-white/10 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
            />
          </div>

          {/* Attachment Upload */}
          <div className="bg-slate-950/40 p-4 rounded-xl border border-white/5 space-y-2">
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-300">
              Optional Attachment / Worksheet (PDF, Word, Images, Zip - Max 15MB)
            </label>

            {formData.attachmentName ? (
              <div className="flex items-center justify-between p-2.5 bg-indigo-950/40 rounded-xl border border-indigo-500/30">
                <div className="flex items-center gap-2 text-xs text-indigo-300 truncate">
                  <FileText className="w-4 h-4 text-indigo-400" />
                  <span className="font-semibold truncate">{formData.attachmentName}</span>
                  <span className="text-slate-400 font-mono">({formData.attachmentSize})</span>
                </div>
                <button
                  type="button"
                  onClick={() =>
                    setFormData({
                      ...formData,
                      attachmentUrl: '',
                      attachmentName: '',
                      attachmentSize: '',
                      attachmentType: ''
                    })
                  }
                  className="text-slate-400 hover:text-rose-400 p-1"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="relative border-2 border-dashed border-white/10 hover:border-indigo-500/40 rounded-xl p-4 text-center cursor-pointer transition-colors">
                <input
                  type="file"
                  onChange={handleFileUpload}
                  className="absolute inset-0 opacity-0 cursor-pointer"
                  disabled={uploadingFile}
                />
                <UploadCloud className="w-6 h-6 text-slate-400 mx-auto mb-1" />
                <p className="text-xs text-slate-300">
                  {uploadingFile ? 'Uploading and scanning file...' : 'Click or drag a file to upload'}
                </p>
                <span className="text-[10px] text-slate-500">Supported: PDF, DOCX, PPTX, JPG, PNG (up to 15MB)</span>
              </div>
            )}
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-white/10">
            <Button
              type="button"
              variant="outline"
              onClick={() => setShowCreateModal(false)}
              disabled={saving}
            >
              Cancel
            </Button>
            <Button type="submit" variant="primary" disabled={saving || uploadingFile}>
              {saving ? 'Creating...' : 'Create & Assign Homework'}
            </Button>
          </div>
        </form>
      </Modal>

      {/* EDIT MODAL */}
      <Modal
        isOpen={showEditModal}
        onClose={() => !saving && setShowEditModal(false)}
        title="Edit Homework Assignment"
        maxWidth="max-w-2xl"
      >
        <form onSubmit={handleEditSubmit} className="space-y-4 text-sm">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
              Homework Title <span className="text-rose-400">*</span>
            </label>
            <input
              type="text"
              required
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              className="w-full px-3.5 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Class
              </label>
              <select
                value={formData.classId}
                onChange={(e) => {
                  const newClassId = e.target.value;
                  const cls = (classes || []).find((c) => c?.id === newClassId);
                  setFormData({
                    ...formData,
                    classId: newClassId,
                    sectionId: cls?.sections?.[0]?.id || ''
                  });
                }}
                className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500"
              >
                {(classes || []).map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Section
              </label>
              <select
                value={formData.sectionId}
                onChange={(e) => setFormData({ ...formData, sectionId: e.target.value })}
                className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500"
              >
                {(availableSectionsForForm || []).map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Subject
              </label>
              <select
                value={formData.subjectId}
                onChange={(e) => setFormData({ ...formData, subjectId: e.target.value })}
                className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500"
              >
                {(subjects || []).map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name} ({s.code})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Assigned Date
              </label>
              <input
                type="date"
                value={formData.assignedDate}
                onChange={(e) => setFormData({ ...formData, assignedDate: e.target.value })}
                className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Due Date
              </label>
              <input
                type="date"
                required
                value={formData.dueDate}
                onChange={(e) => setFormData({ ...formData, dueDate: e.target.value })}
                className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Status
              </label>
              <select
                value={formData.status}
                onChange={(e) => setFormData({ ...formData, status: e.target.value as any })}
                className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500"
              >
                <option value="published">Published</option>
                <option value="draft">Draft</option>
                <option value="archived">Archived</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
              Homework Description & Instructions
            </label>
            <textarea
              rows={4}
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              className="w-full px-3.5 py-2.5 bg-slate-950/60 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500"
            />
          </div>

          {/* Attachment Upload */}
          <div className="bg-slate-950/40 p-4 rounded-xl border border-white/5 space-y-2">
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-300">
              Attachment
            </label>
            {formData.attachmentName ? (
              <div className="flex items-center justify-between p-2.5 bg-indigo-950/40 rounded-xl border border-indigo-500/30">
                <div className="flex items-center gap-2 text-xs text-indigo-300 truncate">
                  <FileText className="w-4 h-4 text-indigo-400" />
                  <span className="font-semibold truncate">{formData.attachmentName}</span>
                  <span className="text-slate-400 font-mono">({formData.attachmentSize})</span>
                </div>
                <button
                  type="button"
                  onClick={() =>
                    setFormData({
                      ...formData,
                      attachmentUrl: '',
                      attachmentName: '',
                      attachmentSize: '',
                      attachmentType: ''
                    })
                  }
                  className="text-slate-400 hover:text-rose-400 p-1"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="relative border-2 border-dashed border-white/10 hover:border-indigo-500/40 rounded-xl p-4 text-center cursor-pointer transition-colors">
                <input
                  type="file"
                  onChange={handleFileUpload}
                  className="absolute inset-0 opacity-0 cursor-pointer"
                  disabled={uploadingFile}
                />
                <UploadCloud className="w-6 h-6 text-slate-400 mx-auto mb-1" />
                <p className="text-xs text-slate-300">
                  {uploadingFile ? 'Uploading...' : 'Replace or attach a new document'}
                </p>
              </div>
            )}
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-white/10">
            <Button
              type="button"
              variant="outline"
              onClick={() => setShowEditModal(false)}
              disabled={saving}
            >
              Cancel
            </Button>
            <Button type="submit" variant="primary" disabled={saving || uploadingFile}>
              {saving ? 'Saving...' : 'Save Changes'}
            </Button>
          </div>
        </form>
      </Modal>

      {/* VIEW MODAL */}
      <Modal
        isOpen={showViewModal}
        onClose={() => setShowViewModal(false)}
        title="Homework Details"
        maxWidth="max-w-xl"
      >
        {activeItem && (
          <div className="space-y-4 text-sm">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <span className="px-2.5 py-1 rounded-md text-xs font-bold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                {activeItem.subjectName}
              </span>
              <Badge
                variant={
                  activeItem.status === 'published'
                    ? 'success'
                    : activeItem.status === 'draft'
                    ? 'warning'
                    : 'secondary'
                }
              >
                {activeItem.status}
              </Badge>
            </div>

            <div>
              <h2 className="text-xl font-bold text-white">{activeItem.title}</h2>
              <div className="flex items-center gap-4 text-xs text-slate-400 mt-1">
                <span>Class: <strong className="text-white">{activeItem.className} ({activeItem.sectionName})</strong></span>
                <span>Assigned: <strong className="text-white">{activeItem.assignedDate}</strong></span>
                <span>Due: <strong className="text-amber-400">{activeItem.dueDate}</strong></span>
              </div>
            </div>

            <div className="bg-slate-950/50 p-4 rounded-xl border border-white/10 space-y-2">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Description & Instructions</span>
              <p className="text-sm text-slate-200 whitespace-pre-wrap leading-relaxed">
                {activeItem.description || 'No detailed instructions provided.'}
              </p>
            </div>

            {activeItem.attachmentName && (
              <div className="bg-indigo-950/30 p-3.5 rounded-xl border border-indigo-500/20 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <FileText className="w-5 h-5 text-indigo-400" />
                  <div>
                    <div className="text-xs font-bold text-white truncate max-w-[280px]">
                      {activeItem.attachmentName}
                    </div>
                    <div className="text-[10px] text-indigo-300 font-mono">
                      {activeItem.attachmentSize || 'Document'} &bull; Verified Attachment
                    </div>
                  </div>
                </div>
                {activeItem.attachmentUrl && (
                  <a
                    href={activeItem.attachmentUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors"
                  >
                    <Download className="w-3.5 h-3.5" />
                    Download
                  </a>
                )}
              </div>
            )}

            <div className="pt-3 border-t border-white/10 flex items-center justify-between text-xs text-slate-500">
              <span>Teacher: {activeItem.teacherName}</span>
              <Button variant="outline" size="sm" onClick={() => setShowViewModal(false)}>
                Close
              </Button>
            </div>
          </div>
        )}
      </Modal>

      {/* DELETE MODAL */}
      <Modal
        isOpen={showDeleteModal}
        onClose={() => !saving && setShowDeleteModal(false)}
        title="Confirm Homework Deletion"
        maxWidth="max-w-md"
      >
        <div className="space-y-4">
          <div className="flex items-center gap-3 p-3 bg-rose-950/30 rounded-xl border border-rose-500/30 text-rose-300 text-sm">
            <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />
            <p>
              Are you sure you want to permanently delete <strong>{activeItem?.title}</strong>? This action cannot be undone.
            </p>
          </div>

          <div className="flex justify-end gap-3 pt-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => setShowDeleteModal(false)}
              disabled={saving}
            >
              Cancel
            </Button>
            <Button
              type="button"
              variant="danger"
              onClick={handleDeleteSubmit}
              disabled={saving}
            >
              {saving ? 'Deleting...' : 'Delete Permanently'}
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
