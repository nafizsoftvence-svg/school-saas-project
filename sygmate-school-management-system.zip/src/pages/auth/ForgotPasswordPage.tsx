import React, { useState } from 'react';
import {
  ShieldCheck,
  Mail,
  User,
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  KeyRound
} from 'lucide-react';
import { api } from '../../services/api.js';
import { useToast } from '../../context/ToastContext.js';
import { Button } from '../../components/ui/Button.js';
import { Input } from '../../components/ui/Input.js';

interface ForgotPasswordPageProps {
  onNavigateToLogin: () => void;
  onNavigateToReset?: (token: string) => void;
}

export const ForgotPasswordPage: React.FC<ForgotPasswordPageProps> = ({
  onNavigateToLogin,
  onNavigateToReset
}) => {
  const { success: toastSuccess, error: toastError } = useToast();
  const [identifier, setIdentifier] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [simulationUrl, setSimulationUrl] = useState<string | null>(null);
  const [extractedToken, setExtractedToken] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!identifier.trim()) return;

    setIsSubmitting(true);
    setSimulationUrl(null);
    setExtractedToken(null);

    try {
      const res = await api.auth.forgotPassword(identifier.trim());
      if (res.success) {
        setSubmitted(true);
        toastSuccess('Recovery Request Submitted', 'If an account exists, a reset link was generated.');

        if (res.data?.simulationDirectUrl) {
          setSimulationUrl(res.data.simulationDirectUrl);
          const tokenMatch = res.data.simulationDirectUrl.match(/token=([^&]+)/);
          if (tokenMatch && tokenMatch[1]) {
            setExtractedToken(tokenMatch[1]);
          }
        }
      } else {
        toastError('Request Error', res.error || 'Unable to process recovery request.');
      }
    } catch (err: any) {
      toastError('Network Error', err?.message || 'Could not connect to authentication server.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleQuickIdentifier = (sampleId: string) => {
    setIdentifier(sampleId);
  };

  return (
    <div
      className="min-h-screen w-full flex items-center justify-center p-4 sm:p-6 bg-slate-950 font-sans text-slate-100 relative overflow-hidden"
      style={{ background: 'radial-gradient(circle at top right, #1e293b, #0f172a)' }}
    >
      {/* Decorative Glow */}
      <div className="absolute top-[-10%] right-[-5%] w-[500px] h-[500px] bg-indigo-500/15 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[-10%] left-[-5%] w-[450px] h-[450px] bg-amber-500/10 rounded-full blur-[100px] pointer-events-none" />

      <div className="max-w-md w-full z-10 space-y-6">
        {/* Brand Header */}
        <div className="text-center space-y-2">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-indigo-600 border border-indigo-400/40 text-white font-black text-2xl shadow-xl shadow-indigo-600/30 mb-2">
            S
          </div>
          <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white flex items-center justify-center gap-2">
            ACCOUNT RECOVERY
            <span className="text-xs px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 font-mono font-normal">
              RESET
            </span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-400">
            Sygmate International Academy • Self-Service Credential Reset
          </p>
        </div>

        {/* Card */}
        <div className="bg-white/5 backdrop-blur-2xl border border-white/15 rounded-3xl p-6 sm:p-8 shadow-2xl shadow-black/80 space-y-6">
          {!submitted ? (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <h2 className="text-lg font-bold text-white tracking-tight">Forgot Password</h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Enter your registered email address or username to receive a 1-hour secure password reset link.
                </p>
              </div>

              <Input
                id="recovery-identifier"
                label="Email or Username"
                type="text"
                placeholder="e.g. c.rivera@example.com or crivera"
                value={identifier}
                onChange={(e) => setIdentifier(e.target.value)}
                leftIcon={<User className="w-4 h-4" />}
                required
              />

              {/* Sample quick buttons for convenience */}
              <div className="flex items-center gap-2 text-xs">
                <span className="text-[11px] text-slate-400">Try demo:</span>
                <button
                  type="button"
                  onClick={() => handleQuickIdentifier('c.rivera@example.com')}
                  className="px-2 py-0.5 rounded-lg bg-white/5 hover:bg-white/10 text-[11px] text-indigo-300 font-mono cursor-pointer"
                >
                  c.rivera@example.com
                </button>
              </div>

              <Button
                id="send-recovery-btn"
                type="submit"
                variant="primary"
                className="w-full py-3"
                isLoading={isSubmitting}
                disabled={!identifier.trim() || isSubmitting}
              >
                Send Reset Instructions
              </Button>

              <div className="pt-3 border-t border-white/10 flex items-center justify-between text-xs text-slate-400">
                <button
                  type="button"
                  id="recovery-back-to-login"
                  onClick={onNavigateToLogin}
                  className="flex items-center gap-1.5 hover:text-white transition-colors cursor-pointer"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  Back to Sign In
                </button>
                <span className="text-[11px] text-slate-400">Links expire in 1 hour</span>
              </div>
            </form>
          ) : (
            <div className="space-y-4 text-center py-2">
              <div className="w-14 h-14 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-7 h-7" />
              </div>
              <h2 className="text-lg font-bold text-white">Reset Request Processed</h2>
              <p className="text-xs text-slate-300 leading-relaxed max-w-sm mx-auto">
                If an authorized account matches <span className="font-semibold text-white">{identifier}</span>, a time-limited password recovery link has been generated.
              </p>

              {/* Simulation Banner for Sandbox / Review */}
              {simulationUrl && extractedToken && onNavigateToReset && (
                <div className="p-4 rounded-2xl bg-indigo-950/60 border border-indigo-500/40 text-left space-y-3 mt-4">
                  <div className="flex items-center gap-2 text-xs font-bold text-indigo-300">
                    <Sparkles className="w-4 h-4 text-indigo-400" />
                    <span>Demo Mode Direct Simulation</span>
                  </div>
                  <p className="text-[11px] text-slate-300">
                    In this sandbox environment, you can directly launch the password reset form without checking an email inbox:
                  </p>
                  <Button
                    id="simulation-reset-launch-btn"
                    variant="primary"
                    className="w-full py-2.5 text-xs flex items-center justify-center gap-1.5"
                    onClick={() => onNavigateToReset(extractedToken)}
                  >
                    <span>Proceed to Password Reset Form</span>
                    <ArrowRight className="w-4 h-4" />
                  </Button>
                </div>
              )}

              <div className="pt-4 border-t border-white/10 flex items-center justify-between text-xs text-slate-400">
                <button
                  type="button"
                  onClick={() => setSubmitted(false)}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Try another address
                </button>
                <button
                  type="button"
                  onClick={onNavigateToLogin}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Return to Sign In
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Security Footer */}
        <div className="text-center text-xs text-slate-400 space-y-1">
          <p className="flex items-center justify-center gap-1.5 text-[11px]">
            <ShieldCheck className="w-3.5 h-3.5 text-indigo-400" />
            Protected by Sygmate RBAC Matrix &amp; Cryptographic Tokens
          </p>
          <p className="text-[10px] text-slate-400">© 2026 Sygmate International Academy</p>
        </div>
      </div>
    </div>
  );
};
