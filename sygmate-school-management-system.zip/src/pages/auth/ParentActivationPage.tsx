import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  Lock,
  User,
  Eye,
  EyeOff,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  GraduationCap,
  Users,
  ArrowRight,
  ArrowLeft,
  Sparkles,
  KeyRound,
  FileCheck2
} from 'lucide-react';
import { api } from '../../services/api.js';
import { useAuth } from '../../context/AuthContext.js';
import { useToast } from '../../context/ToastContext.js';
import { Button } from '../../components/ui/Button.js';
import { Input } from '../../components/ui/Input.js';

interface ParentActivationPageProps {
  initialToken?: string;
  onNavigateToLogin: () => void;
  onActivationSuccess?: (redirectTo?: string) => void;
}

export const ParentActivationPage: React.FC<ParentActivationPageProps> = ({
  initialToken = '',
  onNavigateToLogin,
  onActivationSuccess
}) => {
  const { setSessionFromLogin } = useAuth();
  const { success: toastSuccess, error: toastError } = useToast();

  const [token, setToken] = useState<string>(initialToken);
  const [isVerifying, setIsVerifying] = useState<boolean>(false);
  const [verificationError, setVerificationError] = useState<string | null>(null);
  const [invitationData, setInvitationData] = useState<{
    invitation: any;
    guardian: any;
    students: any[];
  } | null>(null);

  // Form inputs
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [agreedToTerms, setAgreedToTerms] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [activationDone, setActivationDone] = useState(false);

  // Check URL token if not provided in props
  useEffect(() => {
    let activeToken = initialToken;
    if (!activeToken && typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      const urlToken = params.get('token') || params.get('invitationToken');
      if (urlToken) {
        activeToken = urlToken;
        setToken(urlToken);
      }
    }

    if (activeToken) {
      verifyToken(activeToken);
    }
  }, [initialToken]);

  const verifyToken = async (tokenToVerify: string) => {
    if (!tokenToVerify.trim()) {
      setVerificationError('Please enter a valid invitation token.');
      return;
    }

    setIsVerifying(true);
    setVerificationError(null);

    try {
      const res = await api.auth.verifyInvitation(tokenToVerify.trim());
      if (res.success && res.data) {
        setInvitationData(res.data);
        const suggestedUser =
          res.data.guardian?.email?.split('@')[0]?.toLowerCase().replace(/[^a-z0-9]/g, '') || '';
        setUsername(suggestedUser);
      } else {
        setVerificationError(res.error || 'Invitation token is invalid or has expired.');
        setInvitationData(null);
      }
    } catch (err: any) {
      setVerificationError(err?.message || 'Unable to verify invitation. Please check your connection.');
      setInvitationData(null);
    } finally {
      setIsVerifying(false);
    }
  };

  // Password validation rules
  const hasMinLength = (password?.length || 0) >= 8;
  const hasUpper = /[A-Z]/.test(password || '');
  const hasLower = /[a-z]/.test(password || '');
  const hasNumber = /[0-9]/.test(password || '');
  const hasSpecial = /[^A-Za-z0-9]/.test(password || '');
  const passwordsMatch = (password?.length || 0) > 0 && password === confirmPassword;

  const passedCount = [hasMinLength, hasUpper, hasLower, hasNumber, hasSpecial].filter(Boolean).length;
  let strengthLabel = 'Weak';
  let strengthColor = 'bg-rose-500';
  let strengthPercent = 20;

  if (passedCount === 5) {
    strengthLabel = 'Strong';
    strengthColor = 'bg-emerald-500';
    strengthPercent = 100;
  } else if (passedCount >= 4) {
    strengthLabel = 'Good';
    strengthColor = 'bg-teal-500';
    strengthPercent = 80;
  } else if (passedCount >= 3) {
    strengthLabel = 'Fair';
    strengthColor = 'bg-amber-500';
    strengthPercent = 60;
  } else if (passedCount >= 2) {
    strengthLabel = 'Moderate';
    strengthColor = 'bg-orange-500';
    strengthPercent = 40;
  }

  const isFormValid =
    hasMinLength &&
    hasUpper &&
    hasLower &&
    hasNumber &&
    hasSpecial &&
    passwordsMatch &&
    agreedToTerms &&
    username.trim().length >= 3;

  const handleActivate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isFormValid || !token.trim()) return;

    setIsSubmitting(true);
    try {
      const res = await api.auth.activateAccount({
        token: token.trim(),
        username: username.trim(),
        password,
        confirmPassword
      });

      if (res.success && res.data) {
        setActivationDone(true);
        toastSuccess('Account Activated', 'Your parent portal account is now active and ready!');
        setSessionFromLogin(res.data.session);

        if (onActivationSuccess) {
          setTimeout(() => {
            onActivationSuccess(res.data.redirectTo || 'guardian-dashboard');
          }, 1200);
        }
      } else {
        toastError('Activation Failed', res.error || 'Could not complete account activation.');
      }
    } catch (err: any) {
      toastError('Activation Error', err?.message || 'A network error occurred.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleUseDemoToken = () => {
    const demoToken = 'act-sample-elena-rivera-2026';
    setToken(demoToken);
    verifyToken(demoToken);
  };

  return (
    <div
      className="min-h-screen w-full flex items-center justify-center p-4 sm:p-6 bg-slate-950 font-sans text-slate-100 relative overflow-hidden"
      style={{ background: 'radial-gradient(circle at top right, #1e293b, #0f172a)' }}
    >
      {/* Glow Orbs */}
      <div className="absolute top-[-10%] right-[-5%] w-[500px] h-[500px] bg-indigo-500/15 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[-10%] left-[-5%] w-[450px] h-[450px] bg-teal-500/10 rounded-full blur-[100px] pointer-events-none" />

      <div className="max-w-xl w-full z-10 space-y-6">
        {/* Header Branding */}
        <div className="text-center space-y-2">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-indigo-600 border border-indigo-400/40 text-white font-black text-2xl shadow-xl shadow-indigo-600/30 mb-1">
            S
          </div>
          <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white flex items-center justify-center gap-2">
            PARENT PORTAL SETUP
            <span className="text-xs px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 font-mono font-normal">
              ACTIVATION
            </span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-400">
            Sygmate International Academy • Official Guardian Onboarding
          </p>
        </div>

        {/* Main Card */}
        <div className="bg-white/5 backdrop-blur-2xl border border-white/15 rounded-3xl p-6 sm:p-8 shadow-2xl shadow-black/80 space-y-6">
          {/* Activation Success View */}
          {activationDone ? (
            <div className="text-center py-6 space-y-4">
              <div className="w-16 h-16 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center mx-auto shadow-lg shadow-emerald-500/20">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h2 className="text-xl font-bold text-white">Account Successfully Activated!</h2>
              <p className="text-sm text-slate-300 max-w-md mx-auto">
                Welcome to the Sygmate Parent Portal. Your login credentials are now established, and you are authorized to view and manage your child&apos;s records.
              </p>
              <div className="pt-4 flex flex-col sm:flex-row gap-3 justify-center">
                <Button
                  id="activation-proceed-btn"
                  variant="primary"
                  className="px-6 py-3"
                  onClick={() => onActivationSuccess?.('guardian-dashboard')}
                >
                  <span>Launch Parent Portal</span>
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </div>
          ) : !invitationData ? (
            /* Step 1: Token Input / Verification */
            <div className="space-y-5">
              <div>
                <h2 className="text-lg font-bold text-white">Verify Your Invitation Token</h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Enter the unique security activation token provided in your school invitation email or SMS.
                </p>
              </div>

              {verificationError && (
                <div className="p-3.5 rounded-2xl bg-rose-950/40 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
                  <XCircle className="w-4 h-4 flex-shrink-0 text-rose-400" />
                  <span>{verificationError}</span>
                </div>
              )}

              <div className="space-y-3">
                <Input
                  id="invitation-token-input"
                  label="Activation Token"
                  type="text"
                  placeholder="e.g. act-sample-elena-rivera-2026"
                  value={token}
                  onChange={(e) => setToken(e.target.value)}
                  leftIcon={<KeyRound className="w-4 h-4" />}
                />

                <div className="flex gap-2 pt-1">
                  <Button
                    id="verify-token-btn"
                    variant="primary"
                    className="flex-1 py-2.5"
                    onClick={() => verifyToken(token)}
                    isLoading={isVerifying}
                    disabled={!token.trim()}
                  >
                    Verify Token &amp; Continue
                  </Button>

                  <Button
                    id="token-demo-btn"
                    variant="outline"
                    type="button"
                    onClick={handleUseDemoToken}
                    className="px-3 text-xs border-indigo-500/30 text-indigo-300 hover:bg-indigo-500/10"
                    title="Load pre-seeded demo invitation"
                  >
                    <Sparkles className="w-3.5 h-3.5 mr-1 text-indigo-400" />
                    Load Demo Token
                  </Button>
                </div>
              </div>

              <div className="pt-4 border-t border-white/10 flex items-center justify-between text-xs text-slate-400">
                <button
                  type="button"
                  id="back-to-login-btn"
                  onClick={onNavigateToLogin}
                  className="flex items-center gap-1.5 hover:text-white transition-colors cursor-pointer"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  Return to Sign In
                </button>
                <span className="text-[11px] text-slate-400">Token validity: 48 Hours</span>
              </div>
            </div>
          ) : (
            /* Step 2: Account Provisioning Form */
            <form onSubmit={handleActivate} className="space-y-5">
              {/* Guardian & Student Summary Header */}
              <div className="p-4 rounded-2xl bg-indigo-950/40 border border-indigo-500/30 space-y-3">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="text-[11px] font-bold text-indigo-300 uppercase tracking-wider flex items-center gap-1.5">
                      <Users className="w-3.5 h-3.5" />
                      Verified Guardian Record
                    </div>
                    <div className="text-base font-bold text-white mt-0.5">
                      {invitationData.guardian.name}
                    </div>
                    <div className="text-xs text-slate-300">
                      {invitationData.guardian.email} • {invitationData.guardian.phone}
                    </div>
                  </div>
                  <span className="px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[11px] font-bold">
                    Token Verified
                  </span>
                </div>

                {/* Linked Students List */}
                <div className="pt-2 border-t border-indigo-500/20">
                  <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2">
                    Authorized Linked Students ({invitationData.students?.length || 0})
                  </div>
                  <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
                    {invitationData.students?.map((student: any) => (
                      <div
                        key={student.id}
                        className="p-2.5 rounded-xl bg-white/5 border border-white/10 flex items-center justify-between text-xs"
                      >
                        <div className="flex items-center gap-2">
                          <div className="w-7 h-7 rounded-lg bg-indigo-600/30 text-indigo-300 flex items-center justify-center font-bold text-xs">
                            <GraduationCap className="w-4 h-4" />
                          </div>
                          <div>
                            <div className="font-bold text-white">{student.name}</div>
                            <div className="text-[11px] text-slate-400 font-mono">
                              Adm: {student.admissionNumber} • {student.className} - {student.sectionName}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-1">
                          <span className="px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300 text-[10px] font-semibold">
                            {student.relationshipType || 'Child'}
                          </span>
                          {student.isPrimary && (
                            <span className="px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[10px] font-semibold">
                              Primary
                            </span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Set Credentials */}
              <div className="space-y-4">
                <Input
                  id="activation-username"
                  label="Choose Portal Username"
                  type="text"
                  placeholder="e.g. erivera"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  leftIcon={<User className="w-4 h-4" />}
                  required
                />

                <Input
                  id="activation-password"
                  label="Create Security Password"
                  type={showPassword ? 'text' : 'password'}
                  placeholder="At least 8 chars with mixed cases & symbols"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  leftIcon={<Lock className="w-4 h-4" />}
                  rightIcon={
                    <button
                      type="button"
                      onClick={() => setShowPassword((p) => !p)}
                      className="text-slate-400 hover:text-white transition-colors cursor-pointer"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  }
                  required
                />

                {/* Password Strength Meter */}
                {password.length > 0 && (
                  <div className="space-y-2 p-3 rounded-xl bg-slate-900/60 border border-white/10 text-xs">
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="text-slate-400 font-medium">Password Strength:</span>
                      <span className={`font-bold ${(strengthColor || '').replace('bg-', 'text-')}`}>
                        {strengthLabel}
                      </span>
                    </div>
                    <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden">
                      <div
                        className={`h-full transition-all duration-300 ${strengthColor}`}
                        style={{ width: `${strengthPercent}%` }}
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-1 text-[11px] pt-1">
                      <span
                        className={`flex items-center gap-1 ${
                          hasMinLength ? 'text-emerald-400' : 'text-slate-400'
                        }`}
                      >
                        {hasMinLength ? (
                          <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                        ) : (
                          <div className="w-2.5 h-2.5 rounded-full border border-slate-600" />
                        )}
                        8+ characters
                      </span>
                      <span
                        className={`flex items-center gap-1 ${
                          hasUpper ? 'text-emerald-400' : 'text-slate-400'
                        }`}
                      >
                        {hasUpper ? (
                          <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                        ) : (
                          <div className="w-2.5 h-2.5 rounded-full border border-slate-600" />
                        )}
                        Uppercase letter
                      </span>
                      <span
                        className={`flex items-center gap-1 ${
                          hasLower ? 'text-emerald-400' : 'text-slate-400'
                        }`}
                      >
                        {hasLower ? (
                          <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                        ) : (
                          <div className="w-2.5 h-2.5 rounded-full border border-slate-600" />
                        )}
                        Lowercase letter
                      </span>
                      <span
                        className={`flex items-center gap-1 ${
                          hasNumber ? 'text-emerald-400' : 'text-slate-400'
                        }`}
                      >
                        {hasNumber ? (
                          <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                        ) : (
                          <div className="w-2.5 h-2.5 rounded-full border border-slate-600" />
                        )}
                        At least 1 number
                      </span>
                      <span
                        className={`flex items-center gap-1 ${
                          hasSpecial ? 'text-emerald-400' : 'text-slate-400'
                        }`}
                      >
                        {hasSpecial ? (
                          <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                        ) : (
                          <div className="w-2.5 h-2.5 rounded-full border border-slate-600" />
                        )}
                        Special symbol (!@#$%)
                      </span>
                    </div>
                  </div>
                )}

                <Input
                  id="activation-confirm-password"
                  label="Confirm Security Password"
                  type={showPassword ? 'text' : 'password'}
                  placeholder="Re-enter your chosen password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  leftIcon={<Lock className="w-4 h-4" />}
                  required
                />

                {confirmPassword.length > 0 && (
                  <div
                    className={`text-xs flex items-center gap-1.5 ${
                      passwordsMatch ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {passwordsMatch ? (
                      <>
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        Passwords match
                      </>
                    ) : (
                      <>
                        <XCircle className="w-3.5 h-3.5" />
                        Passwords do not match
                      </>
                    )}
                  </div>
                )}

                {/* Terms Agreement */}
                <label className="flex items-start gap-2.5 p-3 rounded-xl bg-white/5 border border-white/10 cursor-pointer select-none">
                  <input
                    id="activation-terms-checkbox"
                    type="checkbox"
                    checked={agreedToTerms}
                    onChange={(e) => setAgreedToTerms(e.target.checked)}
                    className="mt-0.5 w-4 h-4 rounded bg-slate-900 border-white/20 text-indigo-600 focus:ring-indigo-500"
                  />
                  <span className="text-xs text-slate-300 leading-relaxed">
                    I confirm that I am the authorized legal parent/guardian of the listed student(s) and agree to uphold the security and privacy terms of the Sygmate Parent Portal.
                  </span>
                </label>
              </div>

              {/* Submit Buttons */}
              <div className="space-y-2 pt-2">
                <Button
                  id="activate-account-submit-btn"
                  type="submit"
                  variant="primary"
                  className="w-full py-3"
                  isLoading={isSubmitting}
                  disabled={!isFormValid || isSubmitting}
                >
                  Complete Activation &amp; Enter Portal
                </Button>

                <div className="flex items-center justify-between text-xs text-slate-400 pt-1">
                  <button
                    type="button"
                    onClick={() => setInvitationData(null)}
                    className="hover:text-white transition-colors cursor-pointer"
                  >
                    Change Token
                  </button>
                  <button
                    type="button"
                    onClick={onNavigateToLogin}
                    className="hover:text-white transition-colors cursor-pointer"
                  >
                    Return to Sign In
                  </button>
                </div>
              </div>
            </form>
          )}
        </div>

        {/* Security & System Info Footer */}
        <div className="text-center text-xs text-slate-400 space-y-1">
          <p className="flex items-center justify-center gap-1.5 text-[11px]">
            <ShieldCheck className="w-3.5 h-3.5 text-indigo-400" />
            PBKDF2 Cryptographic Salt &amp; Session Invalidation Matrix
          </p>
          <p className="text-[10px] text-slate-400">© 2026 Sygmate International Academy</p>
        </div>
      </div>
    </div>
  );
};
