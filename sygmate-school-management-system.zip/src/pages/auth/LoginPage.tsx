import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  Lock,
  User,
  Eye,
  EyeOff,
  Sparkles,
  Building2,
  AlertTriangle,
  KeyRound,
  ArrowRight,
  UserPlus,
  Compass,
  Globe,
  GraduationCap,
  Users
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext.js';
import { useToast } from '../../context/ToastContext.js';
import { Button } from '../../components/ui/Button.js';
import { Input } from '../../components/ui/Input.js';
import { UserRole } from '../../types/index.js';
import { api } from '../../services/api.js';

interface LoginPageProps {
  initialUsername?: string;
  onNavigateToActivate?: (token?: string) => void;
  onNavigateToForgotPassword?: () => void;
  onNavigateToVerifyCertificate?: () => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({
  initialUsername = '',
  onNavigateToActivate,
  onNavigateToForgotPassword,
  onNavigateToVerifyCertificate
}) => {
  const { login, switchDemoRole } = useAuth();
  const { addToast } = useToast();

  const [username, setUsername] = useState(initialUsername);
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [errorCode, setErrorCode] = useState<string | null>(null);
  const [pendingToken, setPendingToken] = useState<string | null>(null);

  // Check whether demo personas are permitted in current environment
  const [isDemoEnabled, setIsDemoEnabled] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const metaEnv = (import.meta as any).env;
      return (
        metaEnv?.DEV ||
        metaEnv?.VITE_ENABLE_DEMO_PERSONAS === 'true' ||
        metaEnv?.MODE !== 'production'
      );
    }
    return false;
  });

  useEffect(() => {
    let isMounted = true;
    api.auth
      .demoStatus()
      .then((res) => {
        if (isMounted && res?.success && typeof res.data?.isDemoEnabled === 'boolean') {
          setIsDemoEnabled(res.data.isDemoEnabled);
        }
      })
      .catch(() => {
        // Retain initial client environment detection
      });
    return () => {
      isMounted = false;
    };
  }, []);

  const handleManualLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !password.trim()) {
      setError('Please enter both your identifier and security password');
      return;
    }

    try {
      setIsLoading(true);
      setError(null);
      setErrorCode(null);
      setPendingToken(null);
      const res = await login(username, password);
      if (res.success) {
        addToast('Welcome back! Session authenticated successfully.', 'success');
      } else {
        setError(res.error || 'Invalid credentials. Please verify your login details.');
        setErrorCode(res.code || null);
        if (res.invitationToken) {
          setPendingToken(res.invitationToken);
        }
      }
    } catch (err: any) {
      setError(err?.message || 'Invalid credentials. Please verify your login details.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleQuickPersona = async (role: UserRole) => {
    try {
      setIsLoading(true);
      setError(null);
      setErrorCode(null);
      const res = await switchDemoRole(role);
      if (res?.success) {
        const roleName =
          role === 'SUPER_ADMIN'
            ? 'Platform Super Admin'
            : role === 'ADMIN'
            ? 'School Admin'
            : role === 'TEACHER'
            ? 'Teacher'
            : role === 'GUARDIAN'
            ? 'Parent / Guardian'
            : 'Student';
        addToast(`Authenticated as ${roleName}`, 'info');
      } else {
        setError(res?.error || 'Failed to authenticate demo persona.');
      }
    } catch (err: any) {
      setError(err?.message || 'Failed to authenticate demo persona.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDemoInvitedParent = () => {
    setUsername('erivera');
    setPassword('temporary123');
    setError('This account is pending initial activation. Click below to complete activation.');
    setErrorCode('ACCOUNT_PENDING_ACTIVATION');
    setPendingToken('act-sample-elena-rivera-2026');
  };

  return (
    <div
      className="min-h-screen w-full flex items-center justify-center p-4 sm:p-6 bg-slate-50 font-sans text-slate-900 relative overflow-hidden"
      style={{
        background: 'radial-gradient(circle at top right, #f1f5f9, #f8fafc)'
      }}
    >
      {/* Nordic Crisp Light Theme Tag in Corner */}
      <div className="absolute top-4 right-4 z-20">
        <div className="px-3 py-1.5 rounded-xl bg-white border border-slate-200 text-slate-700 shadow-xs flex items-center gap-2 text-xs font-semibold">
          <Compass className="w-3.5 h-3.5 text-sky-700" />
          <span>Nordic Crisp Light</span>
        </div>
      </div>

      {/* Decorative Subtle Fjord Orbs */}
      <div className="absolute top-[-10%] right-[-5%] w-[500px] h-[500px] bg-sky-500/5 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[-10%] left-[-5%] w-[450px] h-[450px] bg-slate-400/5 rounded-full blur-[100px] pointer-events-none" />

      <div className="max-w-lg w-full z-10 space-y-6">
        {/* Brand Header */}
        <div className="text-center space-y-2">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-sky-700 border border-sky-800 text-white font-black text-2xl shadow-md shadow-sky-900/10 mb-2">
            S
          </div>
          <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-slate-900 flex items-center justify-center gap-2">
            SYGMATE
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-sky-50 text-sky-800 border border-sky-200 font-mono font-semibold">
              PORTAL OS
            </span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 font-medium">
            Sygmate International Academy • Multi-Role Secure Portal
          </p>
        </div>

        {/* Login Card */}
        <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-xl shadow-slate-200/50 space-y-6">
          <div>
            <h2 className="text-lg font-bold text-slate-900 tracking-tight">Portal Authentication</h2>
            <p className="text-xs text-slate-600 mt-0.5">Sign in to access your role-authorized workspace</p>
          </div>

          {/* Pending Activation Special Notice */}
          {errorCode === 'ACCOUNT_PENDING_ACTIVATION' ? (
            <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900 text-xs space-y-2.5">
              <div className="flex items-center gap-2 font-bold text-amber-900">
                <AlertTriangle className="w-4 h-4 text-amber-600 flex-shrink-0" />
                <span>Account Pending Initial Activation</span>
              </div>
              <p className="text-[11px] text-amber-800 leading-relaxed font-medium">
                This parent account has been invited by the school administration but requires one-time security password setup before logging in.
              </p>
              {onNavigateToActivate && (
                <Button
                  id="pending-activation-btn"
                  variant="primary"
                  className="w-full py-2 text-xs bg-amber-600 hover:bg-amber-700 text-white font-bold"
                  onClick={() => onNavigateToActivate(pendingToken || undefined)}
                >
                  <UserPlus className="w-3.5 h-3.5 mr-1.5" />
                  Activate Account with Invitation Token
                </Button>
              )}
            </div>
          ) : errorCode === 'ACCOUNT_LOCKED' ? (
            <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-900 text-xs space-y-2.5">
              <div className="flex items-center gap-2 font-bold text-rose-900">
                <Lock className="w-4 h-4 text-rose-600 flex-shrink-0" />
                <span>Account Temporarily Locked</span>
              </div>
              <p className="text-[11px] text-rose-800 leading-relaxed font-medium">
                Too many consecutive failed sign-in attempts were recorded. You can reset your password now or contact the school office.
              </p>
              {onNavigateToForgotPassword && (
                <Button
                  id="locked-account-reset-btn"
                  variant="outline"
                  className="w-full py-2 text-xs border-rose-300 text-rose-700 hover:bg-rose-50"
                  onClick={onNavigateToForgotPassword}
                >
                  Reset Security Password
                </Button>
              )}
            </div>
          ) : error ? (
            <div className="p-3.5 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center gap-2 font-medium">
              <span className="w-2 h-2 rounded-full bg-rose-600 flex-shrink-0" />
              <span>{error}</span>
            </div>
          ) : null}

          {/* Form */}
          <form onSubmit={handleManualLogin} className="space-y-4">
            <Input
              id="login-username"
              label="Username / Email"
              type="text"
              placeholder="e.g. c.rivera@example.com or crivera"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              leftIcon={<User className="w-4 h-4 text-slate-500" />}
              required
            />

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xs font-semibold text-slate-700 uppercase tracking-wider">Password</span>
                {onNavigateToForgotPassword && (
                  <button
                    type="button"
                    id="login-forgot-password-link"
                    onClick={onNavigateToForgotPassword}
                    className="text-xs text-sky-700 hover:text-sky-800 font-semibold transition-colors cursor-pointer"
                  >
                    Forgot password?
                  </button>
                )}
              </div>
              <Input
                id="login-password"
                type={showPassword ? 'text' : 'password'}
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                leftIcon={<Lock className="w-4 h-4 text-slate-500" />}
                rightIcon={
                  <button
                    type="button"
                    onClick={() => setShowPassword((p) => !p)}
                    className="text-slate-500 hover:text-slate-800 transition-colors cursor-pointer p-0.5"
                    aria-label={showPassword ? 'Hide password' : 'Show password'}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                }
                required
              />
            </div>

            <Button
              id="login-submit-btn"
              type="submit"
              variant="primary"
              className="w-full py-3 bg-sky-700 hover:bg-sky-800 text-white font-bold shadow-xs border border-sky-800"
              isLoading={isLoading}
            >
              Sign In to Portal
            </Button>
          </form>

          {/* Invitation Activation Entry */}
          {onNavigateToActivate && (
            <div className="pt-2 text-center">
              <button
                type="button"
                id="login-activate-invitation-link"
                onClick={() => onNavigateToActivate()}
                className="text-xs text-slate-600 hover:text-sky-800 transition-colors inline-flex items-center gap-1.5 cursor-pointer font-medium"
              >
                <KeyRound className="w-3.5 h-3.5 text-sky-700" />
                <span>Received a school invitation? <strong className="text-sky-700 underline underline-offset-2">Activate Account</strong></span>
              </button>
            </div>
          )}

          {/* Public Certificate Verification Link */}
          {onNavigateToVerifyCertificate && (
            <div className="pt-1 text-center">
              <button
                type="button"
                id="login-verify-certificate-link"
                onClick={() => onNavigateToVerifyCertificate()}
                className="text-xs text-slate-600 hover:text-sky-800 transition-colors inline-flex items-center gap-1.5 cursor-pointer font-medium"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-sky-700" />
                <span>Verify an Official Certificate Credential</span>
              </button>
            </div>
          )}

          {/* 1-Click Fast Persona Switchers - Available strictly in Development/Demo Environment */}
          {isDemoEnabled && (
            <div className="pt-4 border-t border-slate-200 space-y-3.5">
              <div className="flex items-center justify-between text-[11px] font-bold text-slate-700 uppercase tracking-wider">
                <span className="flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-sky-700" />
                  Quick Demo Personas
                </span>
                <span className="text-[10px] text-emerald-700 font-mono font-bold px-1.5 py-0.5 rounded-sm bg-emerald-50 border border-emerald-200">
                  SANDBOX READY
                </span>
              </div>
              <p className="text-[11px] text-slate-500 leading-normal">
                Inspect role-scoped RBAC, multi-school tenant isolation, and administrative controls:
              </p>

              {/* Administrative Tiers: Platform Super Admin vs School Admin */}
              <div className="space-y-1.5">
                <div className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider">
                  Administrative Access Tiers
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {/* Platform Super Admin */}
                  <button
                    type="button"
                    id="quick-super-admin-btn"
                    data-testid="quick-super-admin-btn"
                    data-role="SUPER_ADMIN"
                    onClick={() => handleQuickPersona('SUPER_ADMIN')}
                    disabled={isLoading}
                    className="p-3 rounded-2xl bg-indigo-50/60 hover:bg-indigo-100/70 border border-indigo-200 hover:border-indigo-300 text-left transition-all group cursor-pointer shadow-2xs flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between gap-1 mb-1">
                        <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-sm bg-indigo-100 text-indigo-800 border border-indigo-200 font-mono">
                          PLATFORM SAAS
                        </span>
                        <Globe className="w-3.5 h-3.5 text-indigo-600 flex-shrink-0" />
                      </div>
                      <div className="text-xs font-bold text-slate-900 group-hover:text-indigo-950">
                        Platform Super Admin
                      </div>
                      <div className="text-[11px] text-indigo-900 font-medium truncate mt-0.5">
                        Dr. Arthur Sterling
                      </div>
                    </div>
                    <div className="text-[10px] text-slate-600 mt-2 pt-1.5 border-t border-indigo-100 leading-tight">
                      Cross-school governance, provisioning &amp; global SaaS metrics
                    </div>
                  </button>

                  {/* School Admin */}
                  <button
                    type="button"
                    id="quick-school-admin-btn"
                    data-testid="quick-school-admin-btn"
                    data-role="ADMIN"
                    onClick={() => handleQuickPersona('ADMIN')}
                    disabled={isLoading}
                    className="p-3 rounded-2xl bg-sky-50/60 hover:bg-sky-100/70 border border-sky-200 hover:border-sky-300 text-left transition-all group cursor-pointer shadow-2xs flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between gap-1 mb-1">
                        <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-sm bg-sky-100 text-sky-800 border border-sky-200 font-mono">
                          SINGLE SCHOOL
                        </span>
                        <Building2 className="w-3.5 h-3.5 text-sky-700 flex-shrink-0" />
                      </div>
                      <div className="text-xs font-bold text-slate-900 group-hover:text-sky-950">
                        School Admin
                      </div>
                      <div className="text-[11px] text-sky-900 font-medium truncate mt-0.5">
                        Elena Rostova
                      </div>
                    </div>
                    <div className="text-[10px] text-slate-600 mt-2 pt-1.5 border-t border-sky-100 leading-tight">
                      Scoped strictly to Sygmate Academy (no cross-school access)
                    </div>
                  </button>
                </div>
              </div>

              {/* School Faculty, Student & Guardian Personas */}
              <div className="space-y-1.5 pt-0.5">
                <div className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider">
                  Academic &amp; Family Portals
                </div>
                <div className="grid grid-cols-3 gap-2">
                  {/* Teacher */}
                  <button
                    type="button"
                    id="quick-teacher-btn"
                    data-role="TEACHER"
                    onClick={() => handleQuickPersona('TEACHER')}
                    disabled={isLoading}
                    className="p-2.5 rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-200 text-left transition-all group cursor-pointer shadow-2xs"
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[9px] font-bold px-1 py-0.2 rounded bg-blue-50 text-blue-700 border border-blue-200 font-mono">
                        FACULTY
                      </span>
                      <GraduationCap className="w-3 h-3 text-slate-500" />
                    </div>
                    <div className="text-[11px] font-bold text-slate-900 group-hover:text-blue-700 truncate">
                      Teacher
                    </div>
                    <div className="text-[10px] text-slate-600 font-medium truncate">
                      Prof. Sarah Jenkins
                    </div>
                  </button>

                  {/* Student */}
                  <button
                    type="button"
                    id="quick-student-btn"
                    data-role="STUDENT"
                    onClick={() => handleQuickPersona('STUDENT')}
                    disabled={isLoading}
                    className="p-2.5 rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-200 text-left transition-all group cursor-pointer shadow-2xs"
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[9px] font-bold px-1 py-0.2 rounded bg-emerald-50 text-emerald-700 border border-emerald-200 font-mono">
                        STUDENT
                      </span>
                      <User className="w-3 h-3 text-slate-500" />
                    </div>
                    <div className="text-[11px] font-bold text-slate-900 group-hover:text-emerald-700 truncate">
                      Student
                    </div>
                    <div className="text-[10px] text-slate-600 font-medium truncate">
                      Alex Rivera
                    </div>
                  </button>

                  {/* Guardian / Parent */}
                  <button
                    type="button"
                    id="quick-guardian-btn"
                    data-role="GUARDIAN"
                    onClick={() => handleQuickPersona('GUARDIAN')}
                    disabled={isLoading}
                    className="p-2.5 rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-200 text-left transition-all group cursor-pointer shadow-2xs"
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[9px] font-bold px-1 py-0.2 rounded bg-amber-50 text-amber-800 border border-amber-200 font-mono">
                        GUARDIAN
                      </span>
                      <Users className="w-3 h-3 text-slate-500" />
                    </div>
                    <div className="text-[11px] font-bold text-slate-900 group-hover:text-amber-700 truncate">
                      Guardian/Parent
                    </div>
                    <div className="text-[10px] text-slate-600 font-medium truncate">
                      Carlos Rivera
                    </div>
                  </button>
                </div>
              </div>

              {/* Quick Demo for Pending Activation */}
              <div className="pt-1">
                <button
                  type="button"
                  id="quick-invited-guardian-btn"
                  onClick={handleDemoInvitedParent}
                  disabled={isLoading}
                  className="w-full p-2.5 rounded-xl bg-amber-50/80 hover:bg-amber-100/90 border border-amber-200 text-left transition-all flex items-center justify-between text-xs group cursor-pointer"
                >
                  <div className="flex items-center gap-2">
                    <UserPlus className="w-3.5 h-3.5 text-amber-700" />
                    <span className="text-[11px] text-amber-900 font-medium">
                      Test Pending Parent Flow: <strong className="text-amber-950 font-bold">Elena Rivera (Invited)</strong>
                    </span>
                  </div>
                  <ArrowRight className="w-3.5 h-3.5 text-amber-700 group-hover:translate-x-0.5 transition-transform" />
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Security & System Info Footer */}
        <div className="text-center text-xs text-slate-500 space-y-1">
          <p className="flex items-center justify-center gap-1.5 text-[11px] font-medium text-slate-600">
            <ShieldCheck className="w-3.5 h-3.5 text-sky-700" />
            Protected by Sygmate RBAC Matrix &amp; Cryptographic Tokens
          </p>
          <p className="text-[10px] text-slate-500 font-mono">© 2026 Sygmate International Academy</p>
        </div>
      </div>
    </div>
  );
};
