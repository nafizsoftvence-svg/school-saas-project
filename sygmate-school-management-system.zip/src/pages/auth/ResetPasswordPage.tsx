import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  Lock,
  Eye,
  EyeOff,
  CheckCircle2,
  XCircle,
  ArrowLeft,
  ArrowRight,
  KeyRound,
  UserCheck
} from 'lucide-react';
import { api } from '../../services/api.js';
import { useToast } from '../../context/ToastContext.js';
import { Button } from '../../components/ui/Button.js';
import { Input } from '../../components/ui/Input.js';

interface ResetPasswordPageProps {
  initialToken?: string;
  onNavigateToLogin: (prefilledUsername?: string) => void;
}

export const ResetPasswordPage: React.FC<ResetPasswordPageProps> = ({
  initialToken = '',
  onNavigateToLogin
}) => {
  const { success: toastSuccess, error: toastError } = useToast();

  const [token, setToken] = useState<string>(initialToken);
  const [isVerifying, setIsVerifying] = useState(false);
  const [verificationError, setVerificationError] = useState<string | null>(null);
  const [userData, setUserData] = useState<{
    valid: boolean;
    userId: string;
    email: string;
    name: string;
    expiresAt: string;
  } | null>(null);

  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isResetSuccess, setIsResetSuccess] = useState(false);
  const [resolvedUsername, setResolvedUsername] = useState<string>('');

  useEffect(() => {
    let activeToken = initialToken;
    if (!activeToken && typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      const urlToken = params.get('token');
      if (urlToken) {
        activeToken = urlToken;
        setToken(urlToken);
      }
    }

    if (activeToken) {
      verifyToken(activeToken);
    }
  }, [initialToken]);

  const verifyToken = async (tokenToVerify: string) => {
    if (!tokenToVerify.trim()) {
      setVerificationError('No reset token provided.');
      return;
    }

    setIsVerifying(true);
    setVerificationError(null);

    try {
      const res = await api.auth.verifyResetToken(tokenToVerify.trim());
      if (res.success && res.data) {
        setUserData(res.data);
      } else {
        setVerificationError(res.error || 'Password reset token is invalid or has expired.');
        setUserData(null);
      }
    } catch (err: any) {
      setVerificationError(err?.message || 'Failed to verify reset token.');
      setUserData(null);
    } finally {
      setIsVerifying(false);
    }
  };

  // Password rules
  const hasMinLength = (newPassword?.length || 0) >= 8;
  const hasUpper = /[A-Z]/.test(newPassword || '');
  const hasLower = /[a-z]/.test(newPassword || '');
  const hasNumber = /[0-9]/.test(newPassword || '');
  const hasSpecial = /[^A-Za-z0-9]/.test(newPassword || '');
  const passwordsMatch = (newPassword?.length || 0) > 0 && newPassword === confirmPassword;

  const passedCount = [hasMinLength, hasUpper, hasLower, hasNumber, hasSpecial].filter(Boolean).length;
  let strengthLabel = 'Weak';
  let strengthColor = 'bg-rose-500';
  let strengthPercent = 20;

  if (passedCount === 5) {
    strengthLabel = 'Strong';
    strengthColor = 'bg-emerald-500';
    strengthPercent = 100;
  } else if (passedCount >= 4) {
    strengthLabel = 'Good';
    strengthColor = 'bg-teal-500';
    strengthPercent = 80;
  } else if (passedCount >= 3) {
    strengthLabel = 'Fair';
    strengthColor = 'bg-amber-500';
    strengthPercent = 60;
  } else if (passedCount >= 2) {
    strengthLabel = 'Moderate';
    strengthColor = 'bg-orange-500';
    strengthPercent = 40;
  }

  const isFormValid =
    hasMinLength &&
    hasUpper &&
    hasLower &&
    hasNumber &&
    hasSpecial &&
    passwordsMatch;

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isFormValid || !token.trim()) return;

    setIsSubmitting(true);
    try {
      const res = await api.auth.resetPassword({
        token: token.trim(),
        newPassword,
        confirmPassword
      });

      if (res.success && res.data) {
        setIsResetSuccess(true);
        setResolvedUsername(res.data.username);
        toastSuccess('Password Reset Complete', 'Your account password has been updated.');
      } else {
        toastError('Reset Failed', res.error || 'Could not reset password.');
      }
    } catch (err: any) {
      toastError('Network Error', err?.message || 'Could not connect to authentication server.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div
      className="min-h-screen w-full flex items-center justify-center p-4 sm:p-6 bg-slate-950 font-sans text-slate-100 relative overflow-hidden"
      style={{ background: 'radial-gradient(circle at top right, #1e293b, #0f172a)' }}
    >
      <div className="absolute top-[-10%] right-[-5%] w-[500px] h-[500px] bg-indigo-500/15 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[-10%] left-[-5%] w-[450px] h-[450px] bg-teal-500/10 rounded-full blur-[100px] pointer-events-none" />

      <div className="max-w-md w-full z-10 space-y-6">
        <div className="text-center space-y-2">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-indigo-600 border border-indigo-400/40 text-white font-black text-2xl shadow-xl shadow-indigo-600/30 mb-2">
            S
          </div>
          <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white flex items-center justify-center gap-2">
            NEW PASSWORD
            <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-mono font-normal">
              SECURE
            </span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-400">
            Sygmate International Academy • Account Credential Update
          </p>
        </div>

        <div className="bg-white/5 backdrop-blur-2xl border border-white/15 rounded-3xl p-6 sm:p-8 shadow-2xl shadow-black/80 space-y-6">
          {isResetSuccess ? (
            <div className="text-center py-4 space-y-4">
              <div className="w-16 h-16 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center mx-auto shadow-lg shadow-emerald-500/20">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h2 className="text-lg font-bold text-white">Password Updated Successfully</h2>
              <p className="text-xs text-slate-300 max-w-sm mx-auto">
                All existing active sessions have been invalidated. You can now sign in using your new password.
              </p>
              <div className="pt-2">
                <Button
                  id="reset-success-login-btn"
                  variant="primary"
                  className="w-full py-3"
                  onClick={() => onNavigateToLogin(resolvedUsername)}
                >
                  <span>Sign In with New Password</span>
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </div>
          ) : !userData ? (
            <div className="space-y-4">
              <div>
                <h2 className="text-lg font-bold text-white">Validate Reset Token</h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Enter the recovery token from your password reset message.
                </p>
              </div>

              {verificationError && (
                <div className="p-3.5 rounded-2xl bg-rose-950/40 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
                  <XCircle className="w-4 h-4 flex-shrink-0 text-rose-400" />
                  <span>{verificationError}</span>
                </div>
              )}

              <Input
                id="reset-token-input"
                label="Reset Token"
                type="text"
                placeholder="Paste your reset token here"
                value={token}
                onChange={(e) => setToken(e.target.value)}
                leftIcon={<KeyRound className="w-4 h-4" />}
              />

              <Button
                id="verify-reset-token-btn"
                variant="primary"
                className="w-full py-2.5"
                onClick={() => verifyToken(token)}
                isLoading={isVerifying}
                disabled={!token.trim()}
              >
                Validate Token &amp; Continue
              </Button>

              <div className="pt-3 border-t border-white/10 flex items-center justify-between text-xs text-slate-400">
                <button
                  type="button"
                  onClick={() => onNavigateToLogin()}
                  className="flex items-center gap-1.5 hover:text-white transition-colors cursor-pointer"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  Return to Sign In
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleResetPassword} className="space-y-4">
              {/* Verified User Header */}
              <div className="p-3 rounded-2xl bg-indigo-950/40 border border-indigo-500/30 flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-indigo-600/30 text-indigo-300 flex items-center justify-center">
                  <UserCheck className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-xs font-bold text-white">{userData.name}</div>
                  <div className="text-[11px] text-slate-400">{userData.email}</div>
                </div>
              </div>

              <Input
                id="reset-new-password"
                label="New Password"
                type={showPassword ? 'text' : 'password'}
                placeholder="Create a strong password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                leftIcon={<Lock className="w-4 h-4" />}
                rightIcon={
                  <button
                    type="button"
                    onClick={() => setShowPassword((p) => !p)}
                    className="text-slate-400 hover:text-white transition-colors cursor-pointer"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                }
                required
              />

              {/* Password Strength Checklist */}
              {newPassword.length > 0 && (
                <div className="space-y-2 p-3 rounded-xl bg-slate-900/60 border border-white/10 text-xs">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-slate-400 font-medium">Strength:</span>
                    <span className={`font-bold ${(strengthColor || '').replace('bg-', 'text-')}`}>
                      {strengthLabel}
                    </span>
                  </div>
                  <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden">
                    <div
                      className={`h-full transition-all duration-300 ${strengthColor}`}
                      style={{ width: `${strengthPercent}%` }}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-1 text-[11px] pt-1">
                    <span
                      className={`flex items-center gap-1 ${
                        hasMinLength ? 'text-emerald-400' : 'text-slate-400'
                      }`}
                    >
                      {hasMinLength ? (
                        <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                      ) : (
                        <div className="w-2.5 h-2.5 rounded-full border border-slate-600" />
                      )}
                      8+ characters
                    </span>
                    <span
                      className={`flex items-center gap-1 ${
                        hasUpper ? 'text-emerald-400' : 'text-slate-400'
                      }`}
                    >
                      {hasUpper ? (
                        <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                      ) : (
                        <div className="w-2.5 h-2.5 rounded-full border border-slate-600" />
                      )}
                      Uppercase letter
                    </span>
                    <span
                      className={`flex items-center gap-1 ${
                        hasLower ? 'text-emerald-400' : 'text-slate-400'
                      }`}
                    >
                      {hasLower ? (
                        <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                      ) : (
                        <div className="w-2.5 h-2.5 rounded-full border border-slate-600" />
                      )}
                      Lowercase letter
                    </span>
                    <span
                      className={`flex items-center gap-1 ${
                        hasNumber ? 'text-emerald-400' : 'text-slate-400'
                      }`}
                    >
                      {hasNumber ? (
                        <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                      ) : (
                        <div className="w-2.5 h-2.5 rounded-full border border-slate-600" />
                      )}
                      Number (0-9)
                    </span>
                    <span
                      className={`flex items-center gap-1 ${
                        hasSpecial ? 'text-emerald-400' : 'text-slate-400'
                      }`}
                    >
                      {hasSpecial ? (
                        <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                      ) : (
                        <div className="w-2.5 h-2.5 rounded-full border border-slate-600" />
                      )}
                      Special character
                    </span>
                  </div>
                </div>
              )}

              <Input
                id="reset-confirm-password"
                label="Confirm Password"
                type={showPassword ? 'text' : 'password'}
                placeholder="Re-enter password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                leftIcon={<Lock className="w-4 h-4" />}
                required
              />

              {confirmPassword.length > 0 && (
                <div
                  className={`text-xs flex items-center gap-1.5 ${
                    passwordsMatch ? 'text-emerald-400' : 'text-rose-400'
                  }`}
                >
                  {passwordsMatch ? (
                    <>
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Passwords match
                    </>
                  ) : (
                    <>
                      <XCircle className="w-3.5 h-3.5" />
                      Passwords do not match
                    </>
                  )}
                </div>
              )}

              <Button
                id="submit-reset-password-btn"
                type="submit"
                variant="primary"
                className="w-full py-3 mt-2"
                isLoading={isSubmitting}
                disabled={!isFormValid || isSubmitting}
              >
                Update Password &amp; Invalidate Sessions
              </Button>

              <div className="pt-3 border-t border-white/10 flex items-center justify-between text-xs text-slate-400">
                <button
                  type="button"
                  onClick={() => onNavigateToLogin()}
                  className="flex items-center gap-1.5 hover:text-white transition-colors cursor-pointer"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  Cancel &amp; Return to Sign In
                </button>
              </div>
            </form>
          )}
        </div>

        <div className="text-center text-xs text-slate-400 space-y-1">
          <p className="flex items-center justify-center gap-1.5 text-[11px]">
            <ShieldCheck className="w-3.5 h-3.5 text-indigo-400" />
            PBKDF2 Cryptographic Salt &amp; Session Invalidation Matrix
          </p>
          <p className="text-[10px] text-slate-400">© 2026 Sygmate International Academy</p>
        </div>
      </div>
    </div>
  );
};
