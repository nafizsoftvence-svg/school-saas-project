import React from 'react';
import { User, ShieldCheck, Key, Lock, Sparkles, CheckCircle2 } from 'lucide-react';
import { useAuth } from '../../context/AuthContext.js';
import { Badge } from '../../components/ui/Badge.js';

export const ProfilePage: React.FC = () => {
  const { user, role, permissions } = useAuth();

  if (!user) return null;

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header Profile Banner */}
      <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-6 sm:p-8 shadow-xl shadow-black/20 flex flex-col sm:flex-row items-center gap-6">
        <div className="w-20 h-20 rounded-3xl bg-indigo-600 border border-indigo-400/40 text-white flex items-center justify-center font-black text-3xl shadow-xl shadow-indigo-600/30">
          {user.firstName?.[0] || user.username?.[0] || 'U'}
          {user.lastName?.[0] || ''}
        </div>
        <div className="text-center sm:text-left space-y-1 flex-1">
          <div className="flex items-center justify-center sm:justify-start gap-2">
            <h2 className="text-2xl font-bold text-white">
              {user.firstName} {user.lastName}
            </h2>
            <Badge variant="primary">{role}</Badge>
          </div>
          <p className="text-xs text-slate-400 font-mono">User ID: {user.id} • Username: {user.username}</p>
          <p className="text-xs text-indigo-300 font-mono">{user.email}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Account Details */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-6 shadow-xl shadow-black/20 space-y-4">
          <h3 className="text-base font-bold text-white tracking-tight border-b border-white/10 pb-3 flex items-center gap-2">
            <User className="w-4 h-4 text-indigo-400" />
            <span>Account Details</span>
          </h3>

          <div className="space-y-3 text-xs">
            <div className="flex justify-between">
              <span className="text-slate-400">First Name:</span>
              <span className="text-white font-medium">{user.firstName}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Last Name:</span>
              <span className="text-white font-medium">{user.lastName}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Primary Email:</span>
              <span className="text-white font-mono">{user.email}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Account Status:</span>
              <span className="text-emerald-300 font-semibold">{user.status}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Account Created:</span>
              <span className="text-white font-mono">{new Date(user.createdAt).toLocaleDateString()}</span>
            </div>
          </div>
        </div>

        {/* Security & RBAC Capabilities */}
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-6 shadow-xl shadow-black/20 space-y-4">
          <h3 className="text-base font-bold text-white tracking-tight border-b border-white/10 pb-3 flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Active Cryptographic Permissions</span>
          </h3>

          <p className="text-xs text-slate-400">
            Granular capabilities assigned to your current session token:
          </p>

          <div className="flex flex-wrap gap-2 pt-1">
            {(permissions || []).map((perm) => (
              <span
                key={perm}
                className="px-2.5 py-1 rounded-xl bg-indigo-500/15 text-indigo-300 border border-indigo-500/30 font-mono text-[11px] font-semibold"
              >
                {perm}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
