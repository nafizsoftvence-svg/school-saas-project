import React from 'react';
import { ShieldAlert, ArrowLeft, RefreshCw } from 'lucide-react';
import { Button } from '../../components/ui/Button.js';
import { useAuth } from '../../context/AuthContext.js';
import { UserRole } from '../../types/index.js';

interface UnauthorizedPageProps {
  requiredRole?: UserRole | UserRole[];
  onBackToPortal?: () => void;
}

export const UnauthorizedPage: React.FC<UnauthorizedPageProps> = ({ requiredRole, onBackToPortal }) => {
  const { user, role, switchDemoRole } = useAuth();

  const roleText = Array.isArray(requiredRole) ? requiredRole.join(' or ') : requiredRole || 'Elevated privileges';

  return (
    <div className="min-h-[60vh] flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-white/5 backdrop-blur-2xl rounded-3xl border border-rose-500/30 shadow-2xl p-8 text-center space-y-4">
        <div className="w-16 h-16 rounded-2xl bg-rose-500/20 border border-rose-500/30 text-rose-300 flex items-center justify-center mx-auto shadow-lg">
          <ShieldAlert className="w-8 h-8" />
        </div>

        <span className="inline-block px-3 py-1 rounded-full bg-rose-500/20 border border-rose-500/30 text-rose-300 font-bold text-xs uppercase tracking-wider">
          HTTP 403 Forbidden
        </span>

        <h2 className="text-xl font-bold text-white">Access Boundary Restriction</h2>

        <p className="text-xs text-slate-300 leading-relaxed">
          Your current active account role (<span className="font-semibold text-white">{role}</span>) does not have
          authorization to access this portal partition. This section strictly requires{' '}
          <span className="font-semibold text-rose-300">{roleText}</span> permissions.
        </p>

        <div className="space-y-3 pt-2">
          {onBackToPortal && (
            <Button
              id="return-portal-btn"
              variant="primary"
              className="w-full"
              leftIcon={<ArrowLeft className="w-4 h-4" />}
              onClick={onBackToPortal}
            >
              Return to Authorized Portal
            </Button>
          )}

          {requiredRole && (
            <div className="pt-3 border-t border-white/10">
              <p className="text-[11px] text-slate-400 mb-2">Or switch to an authorized preview persona:</p>
              <div className="flex gap-2 justify-center">
                {(['SUPER_ADMIN', 'ADMIN', 'TEACHER', 'STUDENT'] as UserRole[]).map((r) => (
                  <Button
                    key={r}
                    size="xs"
                    variant={r === role ? 'outline' : 'subtle'}
                    onClick={() => switchDemoRole(r)}
                  >
                    Switch to {r === 'SUPER_ADMIN' ? 'Platform Admin' : r === 'ADMIN' ? 'School Admin' : r === 'TEACHER' ? 'Teacher' : 'Student'}
                  </Button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
