import React, { useState } from 'react';
import {
  Sparkles,
  Layers,
  Search,
  Mail,
  Lock,
  User,
  CheckCircle2,
  AlertTriangle,
  AlertCircle,
  HelpCircle,
  Download,
  Trash2,
  Send,
  Plus,
  ArrowRight,
  Shield,
  GraduationCap,
  Users,
  Copy,
  Check,
  Code2,
  ExternalLink,
  Laptop
} from 'lucide-react';
import {
  Button,
  Input,
  Select,
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
  CardFooter,
  Modal,
  Alert,
  Badge,
  PortalTheme,
  ButtonVariant,
  ButtonSize,
  AlertVariant,
  AlertStyle,
  ModalSize
} from '../../components/ui';

export const AdminUIComponentsPage: React.FC = () => {
  // Global Portal Theme switcher for demo
  const [activePortalTheme, setActivePortalTheme] = useState<PortalTheme>('admin');
  const [activeCategory, setActiveCategory] = useState<
    'buttons' | 'inputs' | 'selects' | 'cards' | 'modals' | 'alerts'
  >('buttons');

  // Button Playground State
  const [btnLoading, setBtnLoading] = useState<boolean>(false);
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  // Input Playground State
  const [textValue, setTextValue] = useState<string>('Sygmate Academy');
  const [searchValue, setSearchValue] = useState<string>('Physics 101');
  const [passwordValue, setPasswordValue] = useState<string>('SecretP@ss123');
  const [hasInputError, setHasInputError] = useState<boolean>(false);

  // Select Playground State
  const [selectedCourse, setSelectedCourse] = useState<string>('CS201');
  const [hasSelectError, setHasSelectError] = useState<boolean>(false);

  // Modal Playground State
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [modalSize, setModalSize] = useState<ModalSize>('md');

  // Alert Playground State
  const [alertStyle, setAlertStyle] = useState<AlertStyle>('subtle');
  const [dismissedAlerts, setDismissedAlerts] = useState<Record<string, boolean>>({});

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCode(id);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  const portalThemeMeta = {
    admin: {
      name: 'Super Admin Portal',
      description: 'Executive precision, high information density, indigo/slate authority',
      icon: <Shield className="w-4 h-4" />,
      badge: 'bg-indigo-100 text-indigo-800 dark:bg-indigo-950/60 dark:text-indigo-300'
    },
    teacher: {
      name: 'Teacher Portal',
      description: 'Productivity focused, accessible grading & attendance, emerald/teal accents',
      icon: <GraduationCap className="w-4 h-4" />,
      badge: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300'
    },
    student: {
      name: 'Student / Guardian Portal',
      description: 'Engaging, friendly, high-contrast readability, violet/amber warmth',
      icon: <Users className="w-4 h-4" />,
      badge: 'bg-violet-100 text-violet-800 dark:bg-violet-950/60 dark:text-violet-300'
    },
    default: {
      name: 'System Default',
      description: 'Standard neutral Sygmate design theme',
      icon: <Laptop className="w-4 h-4" />,
      badge: 'bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-300'
    }
  };

  return (
    <div className="space-y-8 pb-16">
      {/* Header & Portal Switcher */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
          <div>
            <div className="flex items-center gap-2.5 mb-2">
              <span className="p-2 rounded-xl bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 border border-indigo-100 dark:border-indigo-800/60">
                <Sparkles className="w-5 h-5" />
              </span>
              <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white tracking-tight">
                Sygmate UI Component Library
              </h1>
              <Badge variant="indigo" size="sm">
                v2.0 Architecture
              </Badge>
            </div>
            <p className="text-sm text-slate-600 dark:text-slate-400 max-w-2xl leading-relaxed">
              Standardized, accessible, production-ready UI components engineered with a unified design
              language and customizable presets across Super Admin, Teacher, and Student portals.
            </p>
          </div>

          {/* Portal Theme Selector */}
          <div className="bg-slate-50 dark:bg-slate-850 p-2 rounded-2xl border border-slate-200 dark:border-slate-700/70 flex flex-col sm:flex-row gap-1.5 self-start lg:self-center">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 self-center px-3 hidden sm:inline">
              Portal Preset:
            </span>
            {(['admin', 'teacher', 'student'] as PortalTheme[]).map((theme) => {
              const meta = portalThemeMeta[theme];
              const isActive = activePortalTheme === theme;
              return (
                <button
                  key={theme}
                  type="button"
                  onClick={() => setActivePortalTheme(theme)}
                  className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                    isActive
                      ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs border border-slate-200/80 dark:border-slate-600'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  {meta.icon}
                  <span>{meta.name.replace(' Portal', '')}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Current Active Preset Context Bar */}
        <div className="mt-6 pt-5 border-t border-slate-100 dark:border-slate-800/80 flex flex-wrap items-center justify-between gap-4 text-xs">
          <div className="flex items-center gap-2">
            <span className="text-slate-500">Active Theme Context:</span>
            <span className={`px-2.5 py-1 rounded-full font-semibold ${portalThemeMeta[activePortalTheme].badge}`}>
              {portalThemeMeta[activePortalTheme].name}
            </span>
            <span className="text-slate-400 hidden md:inline">
              — {portalThemeMeta[activePortalTheme].description}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-slate-500">WCAG AA Compliant</span>
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
            <span className="text-slate-500">Full Light/Dark Sync</span>
          </div>
        </div>
      </div>

      {/* Component Category Navigation Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-slate-200 dark:border-slate-800">
        {[
          { id: 'buttons', label: 'Buttons', count: '10 Variants' },
          { id: 'inputs', label: 'Input Fields', count: 'Text, Pwd, Search' },
          { id: 'selects', label: 'Select Dropdowns', count: 'Standard & Grouped' },
          { id: 'cards', label: 'Cards & Panels', count: '6 Variants' },
          { id: 'modals', label: 'Modals & Dialogs', count: '6 Sizes' },
          { id: 'alerts', label: 'Alerts & Feedback', count: '4 Styles' }
        ].map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setActiveCategory(tab.id as any)}
            className={`px-4 py-2.5 rounded-xl text-sm font-semibold whitespace-nowrap transition-all cursor-pointer flex items-center gap-2 ${
              activeCategory === tab.id
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800'
            }`}
          >
            <span>{tab.label}</span>
            <span
              className={`text-[11px] px-2 py-0.5 rounded-full ${
                activeCategory === tab.id
                  ? 'bg-white/20 text-white'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-500'
              }`}
            >
              {tab.count}
            </span>
          </button>
        ))}
      </div>

      {/* SECTION 1: BUTTONS */}
      {activeCategory === 'buttons' && (
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <div>
                <CardTitle>Button Component Variants</CardTitle>
                <CardDescription>
                  Supports primary, secondary, outline, subtle, danger, success, warning, ghost, and glass variants with responsive states.
                </CardDescription>
              </div>
              <div className="flex items-center gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => setBtnLoading(!btnLoading)}
                  leftIcon={<Sparkles className="w-3.5 h-3.5" />}
                >
                  {btnLoading ? 'Disable Spinner' : 'Toggle Spinner'}
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Variant Grid */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">Visual Variants</h4>
                <div className="flex flex-wrap gap-3">
                  <Button portalTheme={activePortalTheme} variant="primary" isLoading={btnLoading}>
                    Primary Action
                  </Button>
                  <Button portalTheme={activePortalTheme} variant="secondary">
                    Secondary
                  </Button>
                  <Button portalTheme={activePortalTheme} variant="outline">
                    Outline
                  </Button>
                  <Button portalTheme={activePortalTheme} variant="subtle">
                    Subtle Tint
                  </Button>
                  <Button portalTheme={activePortalTheme} variant="success" leftIcon={<CheckCircle2 className="w-4 h-4" />}>
                    Success
                  </Button>
                  <Button portalTheme={activePortalTheme} variant="warning" leftIcon={<AlertTriangle className="w-4 h-4" />}>
                    Warning
                  </Button>
                  <Button portalTheme={activePortalTheme} variant="danger" leftIcon={<Trash2 className="w-4 h-4" />}>
                    Destructive
                  </Button>
                  <Button portalTheme={activePortalTheme} variant="cyan">
                    Cyan Accent
                  </Button>
                  <Button portalTheme={activePortalTheme} variant="ghost">
                    Ghost Link
                  </Button>
                  <Button portalTheme={activePortalTheme} variant="glass">
                    Glass Card
                  </Button>
                </div>
              </div>

              {/* Sizes Grid */}
              <div className="space-y-3 pt-4 border-t border-slate-100 dark:border-slate-800">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">Size Scales</h4>
                <div className="flex flex-wrap items-center gap-3">
                  <Button portalTheme={activePortalTheme} size="xs" variant="primary">
                    Extra Small (xs)
                  </Button>
                  <Button portalTheme={activePortalTheme} size="sm" variant="primary">
                    Small (sm)
                  </Button>
                  <Button portalTheme={activePortalTheme} size="md" variant="primary">
                    Medium (md - Default)
                  </Button>
                  <Button portalTheme={activePortalTheme} size="lg" variant="primary">
                    Large CTA (lg)
                  </Button>
                </div>
              </div>

              {/* Icon Combinations */}
              <div className="space-y-3 pt-4 border-t border-slate-100 dark:border-slate-800">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">With Icons</h4>
                <div className="flex flex-wrap items-center gap-3">
                  <Button
                    portalTheme={activePortalTheme}
                    variant="primary"
                    leftIcon={<Plus className="w-4 h-4" />}
                  >
                    Create Enrollment
                  </Button>
                  <Button
                    portalTheme={activePortalTheme}
                    variant="outline"
                    rightIcon={<ArrowRight className="w-4 h-4" />}
                  >
                    View Academic Records
                  </Button>
                  <Button
                    portalTheme={activePortalTheme}
                    variant="subtle"
                    leftIcon={<Download className="w-4 h-4" />}
                  >
                    Export Gradebook (CSV)
                  </Button>
                  <Button
                    portalTheme={activePortalTheme}
                    variant="secondary"
                    disabled
                    leftIcon={<Lock className="w-4 h-4" />}
                  >
                    Disabled Locked
                  </Button>
                </div>
              </div>
            </CardContent>
            <CardFooter className="bg-slate-50 dark:bg-slate-850">
              <div className="flex items-center gap-2 text-xs text-slate-500">
                <Code2 className="w-4 h-4 text-slate-400" />
                <span>Example:</span>
                <code className="bg-white dark:bg-slate-900 px-2 py-0.5 rounded-md border border-slate-200 dark:border-slate-700 font-mono text-[11px]">
                  {'<Button portalTheme="admin" variant="primary" size="md">Save</Button>'}
                </code>
              </div>
              <Button
                size="xs"
                variant="ghost"
                onClick={() =>
                  copyToClipboard(
                    '<Button portalTheme="admin" variant="primary" size="md">Save Changes</Button>',
                    'btn-code'
                  )
                }
                leftIcon={copiedCode === 'btn-code' ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
              >
                {copiedCode === 'btn-code' ? 'Copied' : 'Copy JSX'}
              </Button>
            </CardFooter>
          </Card>
        </div>
      )}

      {/* SECTION 2: INPUT FIELDS */}
      {activeCategory === 'inputs' && (
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <div>
                <CardTitle>Input Field Component</CardTitle>
                <CardDescription>
                  Robust form inputs with support for labels, helper text, validation errors, clear buttons, password reveal toggles, and size variations.
                </CardDescription>
              </div>
              <div className="flex items-center gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => setHasInputError(!hasInputError)}
                >
                  {hasInputError ? 'Clear Error State' : 'Simulate Error State'}
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Standard Text Input */}
                <Input
                  id="demo-school-name"
                  label="Institution Name"
                  required
                  portalTheme={activePortalTheme}
                  value={textValue}
                  onChange={(e) => setTextValue(e.target.value)}
                  placeholder="e.g. Sygmate International High School"
                  helperText="Official registered name appearing on diplomas and transcripts."
                  error={hasInputError ? 'Institution name is required and cannot be blank.' : undefined}
                  leftIcon={<User className="w-4 h-4" />}
                />

                {/* Email Input */}
                <Input
                  id="demo-email"
                  label="Administrative Contact Email"
                  type="email"
                  portalTheme={activePortalTheme}
                  placeholder="admin@sygmate.edu"
                  leftIcon={<Mail className="w-4 h-4" />}
                  helperText="Primary email for audit trails and critical password resets."
                />

                {/* Search Input with Clear Button */}
                <Input
                  id="demo-search"
                  label="Live Search Filter"
                  portalTheme={activePortalTheme}
                  value={searchValue}
                  onChange={(e) => setSearchValue(e.target.value)}
                  clearable
                  onClear={() => setSearchValue('')}
                  leftIcon={<Search className="w-4 h-4" />}
                  placeholder="Search students by roll number or name..."
                  helperText="Click the (x) icon to immediately clear and reset search terms."
                />

                {/* Password Input with Visibility Toggle */}
                <Input
                  id="demo-password"
                  label="Secure Access Token / Password"
                  type="password"
                  portalTheme={activePortalTheme}
                  value={passwordValue}
                  onChange={(e) => setPasswordValue(e.target.value)}
                  leftIcon={<Lock className="w-4 h-4" />}
                  helperText="Features automated toggle to reveal or conceal secret credentials."
                />
              </div>

              {/* Sizes Comparison */}
              <div className="space-y-3 pt-4 border-t border-slate-100 dark:border-slate-800">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">Input Size Variations</h4>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <Input
                    id="size-sm"
                    label="Small (sm)"
                    inputSize="sm"
                    portalTheme={activePortalTheme}
                    defaultValue="Compact table filter"
                  />
                  <Input
                    id="size-md"
                    label="Medium (md - Default)"
                    inputSize="md"
                    portalTheme={activePortalTheme}
                    defaultValue="Standard form field"
                  />
                  <Input
                    id="size-lg"
                    label="Large (lg)"
                    inputSize="lg"
                    portalTheme={activePortalTheme}
                    defaultValue="Prominent modal hero"
                  />
                </div>
              </div>
            </CardContent>
            <CardFooter className="bg-slate-50 dark:bg-slate-850">
              <div className="flex items-center gap-2 text-xs text-slate-500">
                <Code2 className="w-4 h-4 text-slate-400" />
                <span>Example:</span>
                <code className="bg-white dark:bg-slate-900 px-2 py-0.5 rounded-md border border-slate-200 dark:border-slate-700 font-mono text-[11px]">
                  {'<Input id="email" label="Email" leftIcon={<Mail />} clearable />'}
                </code>
              </div>
              <Button
                size="xs"
                variant="ghost"
                onClick={() =>
                  copyToClipboard(
                    '<Input id="email" label="Email" portalTheme="admin" leftIcon={<Mail className="w-4 h-4" />} clearable />',
                    'input-code'
                  )
                }
                leftIcon={copiedCode === 'input-code' ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
              >
                {copiedCode === 'input-code' ? 'Copied' : 'Copy JSX'}
              </Button>
            </CardFooter>
          </Card>
        </div>
      )}

      {/* SECTION 3: SELECT DROPDOWNS */}
      {activeCategory === 'selects' && (
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <div>
                <CardTitle>Select Dropdown Component</CardTitle>
                <CardDescription>
                  Custom dropdowns with custom chevron arrows, option groups, placeholder states, helper text, and validation styles.
                </CardDescription>
              </div>
              <div className="flex items-center gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => setHasSelectError(!hasSelectError)}
                >
                  {hasSelectError ? 'Clear Error State' : 'Simulate Select Error'}
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Standard Select */}
                <Select
                  id="demo-academic-session"
                  label="Academic Academic Term"
                  portalTheme={activePortalTheme}
                  required
                  helperText="Sets the active evaluation period for marksheets and attendance."
                  options={[
                    { value: '2026-2027', label: 'Academic Year 2026 - 2027 (Current Active)' },
                    { value: '2025-2026', label: 'Academic Year 2025 - 2026 (Archived)' },
                    { value: '2024-2025', label: 'Academic Year 2024 - 2025 (Archived)' }
                  ]}
                  error={hasSelectError ? 'Please select an authorized academic session.' : undefined}
                />

                {/* Grouped Options Select */}
                <Select
                  id="demo-department-course"
                  label="Academic Department & Course"
                  portalTheme={activePortalTheme}
                  value={selectedCourse}
                  onChange={(e) => setSelectedCourse(e.target.value)}
                  helperText="Demonstrates categorized optgroup rendering."
                  options={[
                    { group: 'Computer Science & IT', value: 'CS101', label: 'CS101: Intro to Computing' },
                    { group: 'Computer Science & IT', value: 'CS201', label: 'CS201: Data Structures & Algorithms' },
                    { group: 'Mathematics & Statistics', value: 'MATH101', label: 'MATH101: Linear Algebra' },
                    { group: 'Mathematics & Statistics', value: 'MATH202', label: 'MATH202: Discrete Mathematics' },
                    { group: 'Natural Sciences', value: 'PHY101', label: 'PHY101: Classical Mechanics' },
                    { group: 'Natural Sciences', value: 'CHEM101', label: 'CHEM101: General Chemistry' }
                  ]}
                />
              </div>

              {/* Select Sizes */}
              <div className="space-y-3 pt-4 border-t border-slate-100 dark:border-slate-800">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">Select Sizes</h4>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <Select
                    id="select-size-sm"
                    label="Small (sm)"
                    selectSize="sm"
                    portalTheme={activePortalTheme}
                    options={[
                      { value: '1', label: '10 items / page' },
                      { value: '2', label: '25 items / page' },
                      { value: '3', label: '50 items / page' }
                    ]}
                  />
                  <Select
                    id="select-size-md"
                    label="Medium (md - Default)"
                    selectSize="md"
                    portalTheme={activePortalTheme}
                    options={[
                      { value: 'all', label: 'All Enrollment Sections' },
                      { value: 'sec-a', label: 'Section A (Morning)' },
                      { value: 'sec-b', label: 'Section B (Afternoon)' }
                    ]}
                  />
                  <Select
                    id="select-size-lg"
                    label="Large (lg)"
                    selectSize="lg"
                    portalTheme={activePortalTheme}
                    options={[
                      { value: 'active', label: 'Enrollment Status: Active' },
                      { value: 'pending', label: 'Enrollment Status: Pending' }
                    ]}
                  />
                </div>
              </div>
            </CardContent>
            <CardFooter className="bg-slate-50 dark:bg-slate-850">
              <div className="flex items-center gap-2 text-xs text-slate-500">
                <Code2 className="w-4 h-4 text-slate-400" />
                <span>Example:</span>
                <code className="bg-white dark:bg-slate-900 px-2 py-0.5 rounded-md border border-slate-200 dark:border-slate-700 font-mono text-[11px]">
                  {'<Select id="role" label="Role" options={[{ value: "admin", label: "Admin" }]} />'}
                </code>
              </div>
              <Button
                size="xs"
                variant="ghost"
                onClick={() =>
                  copyToClipboard(
                    '<Select id="role" label="Role" portalTheme="admin" options={[{ value: "1", label: "Active" }]} />',
                    'select-code'
                  )
                }
                leftIcon={copiedCode === 'select-code' ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
              >
                {copiedCode === 'select-code' ? 'Copied' : 'Copy JSX'}
              </Button>
            </CardFooter>
          </Card>
        </div>
      )}

      {/* SECTION 4: CARDS */}
      {activeCategory === 'cards' && (
        <div className="space-y-6">
          {/* Stat Cards with Portal Accents */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            <Card variant="stat" portalTheme={activePortalTheme}>
              <CardContent className="p-5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                    Total Enrolled Students
                  </span>
                  <Badge variant="indigo" size="sm">
                    Active
                  </Badge>
                </div>
                <div className="mt-3 flex items-baseline gap-2">
                  <span className="text-3xl font-bold text-slate-900 dark:text-white">1,420</span>
                  <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400">+12% this term</span>
                </div>
              </CardContent>
            </Card>

            <Card variant="stat" portalTheme={activePortalTheme}>
              <CardContent className="p-5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                    Staff Attendance Rate
                  </span>
                  <Badge variant="emerald" size="sm">
                    98.4%
                  </Badge>
                </div>
                <div className="mt-3 flex items-baseline gap-2">
                  <span className="text-3xl font-bold text-slate-900 dark:text-white">98.4%</span>
                  <span className="text-xs font-semibold text-slate-500">Normal Range</span>
                </div>
              </CardContent>
            </Card>

            <Card variant="stat" portalTheme={activePortalTheme}>
              <CardContent className="p-5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                    Fee Collection Volume
                  </span>
                  <Badge variant="amber" size="sm">
                    Quarter 3
                  </Badge>
                </div>
                <div className="mt-3 flex items-baseline gap-2">
                  <span className="text-3xl font-bold text-slate-900 dark:text-white">$428,500</span>
                  <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400">92% on-time</span>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Card Layout Variants */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Standard Default Card */}
            <Card variant="default">
              <CardHeader>
                <div>
                  <CardTitle>Standard Structured Card</CardTitle>
                  <CardDescription>Composed using CardHeader, CardTitle, CardContent, and CardFooter.</CardDescription>
                </div>
                <Badge variant="neutral">Default</Badge>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                  Clean neutral container optimized for dense operational tables, dashboard panels, and administrative control groupings.
                </p>
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/60 flex items-center justify-between">
                  <span className="text-xs font-medium text-slate-700 dark:text-slate-300">Automatic Backup Service</span>
                  <span className="text-xs font-semibold text-emerald-600">Active Daily</span>
                </div>
              </CardContent>
              <CardFooter>
                <Button size="xs" variant="ghost">Dismiss</Button>
                <Button size="xs" variant="primary" portalTheme={activePortalTheme}>Configure</Button>
              </CardFooter>
            </Card>

            {/* Interactive Hover Card */}
            <Card variant="interactive">
              <CardHeader>
                <div>
                  <CardTitle>Interactive Clickable Card</CardTitle>
                  <CardDescription>Hover lift effect for drill-down action cards or student profile tiles.</CardDescription>
                </div>
                <Badge variant="indigo">Hover Lift</Badge>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                  Notice the subtle scale press and elevation shadow response on cursor hover, indicating clickable navigation.
                </p>
                <div className="flex items-center gap-3 pt-2">
                  <div className="w-10 h-10 rounded-full bg-indigo-100 dark:bg-indigo-950 flex items-center justify-center font-bold text-indigo-600">
                    JD
                  </div>
                  <div>
                    <h5 className="text-xs font-bold text-slate-900 dark:text-white">Johnathan Doe</h5>
                    <p className="text-[11px] text-slate-500">Grade 11 - Computer Science Track</p>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <span className="text-xs text-indigo-600 dark:text-indigo-400 font-semibold flex items-center gap-1">
                  View Full Academic Profile <ArrowRight className="w-3 h-3" />
                </span>
              </CardFooter>
            </Card>
          </div>
        </div>
      )}

      {/* SECTION 5: MODALS */}
      {activeCategory === 'modals' && (
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <div>
                <CardTitle>Modal Dialog Component</CardTitle>
                <CardDescription>
                  Accessible dialogs with keyboard Escape listener, backdrop click dismiss, body scroll lock, portal icon badge, and scalable sizing.
                </CardDescription>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              <p className="text-sm text-slate-600 dark:text-slate-400">
                Click any of the buttons below to open an interactive modal dialog formatted with the selected size and active portal theme styling:
              </p>

              <div className="flex flex-wrap gap-3">
                {(['sm', 'md', 'lg', 'xl'] as ModalSize[]).map((size) => (
                  <Button
                    key={size}
                    portalTheme={activePortalTheme}
                    variant="outline"
                    onClick={() => {
                      setModalSize(size);
                      setIsModalOpen(true);
                    }}
                    leftIcon={<ExternalLink className="w-4 h-4" />}
                  >
                    Open Modal ({size.toUpperCase()})
                  </Button>
                ))}
              </div>

              {/* Modal Features Checklist */}
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-850 border border-slate-200/80 dark:border-slate-800 space-y-2.5">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                  Engineered Modal Capabilities
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-600 dark:text-slate-400">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                    <span>Automatic background scroll lock during open state</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                    <span>Press Escape key to dismiss</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                    <span>Backdrop click to close with dark blur overlay</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                    <span>Full light & dark mode high-contrast support</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Interactive Modal Instance */}
          <Modal
            isOpen={isModalOpen}
            onClose={() => setIsModalOpen(false)}
            size={modalSize}
            portalTheme={activePortalTheme}
            icon={<Sparkles className="w-5 h-5" />}
            title={`Sygmate Modal Dialog (${modalSize.toUpperCase()})`}
            description={`Rendered in ${portalThemeMeta[activePortalTheme].name} mode with responsive padding.`}
            footer={
              <>
                <Button variant="outline" size="sm" onClick={() => setIsModalOpen(false)}>
                  Cancel
                </Button>
                <Button
                  portalTheme={activePortalTheme}
                  variant="primary"
                  size="sm"
                  onClick={() => setIsModalOpen(false)}
                >
                  Confirm & Save Changes
                </Button>
              </>
            }
          >
            <div className="space-y-4">
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                This dialog demonstrates nested input components, selects, and notification banners inside a modal body.
              </p>

              <div className="grid grid-cols-1 gap-4">
                <Input
                  id="modal-student-name"
                  label="Student Full Name"
                  portalTheme={activePortalTheme}
                  defaultValue="Alexander Pierce"
                />
                <Select
                  id="modal-grade-level"
                  label="Assigned Academic Grade"
                  portalTheme={activePortalTheme}
                  options={[
                    { value: '10', label: 'Grade 10 - Secondary' },
                    { value: '11', label: 'Grade 11 - Higher Secondary' },
                    { value: '12', label: 'Grade 12 - Senior' }
                  ]}
                />
              </div>

              <Alert variant="info" styleType="subtle" title="Audit Information">
                Changes saved in this dialog will be logged into the administrative audit trail.
              </Alert>
            </div>
          </Modal>
        </div>
      )}

      {/* SECTION 6: ALERTS */}
      {activeCategory === 'alerts' && (
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <div>
                <CardTitle>Alert & Feedback Component</CardTitle>
                <CardDescription>
                  Rich notification containers with 4 display styles (subtle, filled, outline, banner) and 5 functional variants.
                </CardDescription>
              </div>
              {/* Style Selector */}
              <div className="flex items-center gap-1.5 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl">
                {(['subtle', 'filled', 'outline', 'banner'] as AlertStyle[]).map((st) => (
                  <button
                    key={st}
                    type="button"
                    onClick={() => setAlertStyle(st)}
                    className={`px-3 py-1 rounded-lg text-xs font-semibold capitalize transition-all cursor-pointer ${
                      alertStyle === st
                        ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                    }`}
                  >
                    {st}
                  </button>
                ))}
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Info Alert */}
              {!dismissedAlerts['info'] && (
                <Alert
                  variant="info"
                  styleType={alertStyle}
                  title="Scheduled System Maintenance"
                  onClose={() => setDismissedAlerts((prev) => ({ ...prev, info: true }))}
                  action={
                    <Button size="xs" variant="outline" className="bg-white/40 dark:bg-black/20">
                      View Service Status
                    </Button>
                  }
                >
                  Gradebook sync and report card generation services will undergo routine optimization this Sunday at 02:00 AM UTC.
                </Alert>
              )}

              {/* Success Alert */}
              {!dismissedAlerts['success'] && (
                <Alert
                  variant="success"
                  styleType={alertStyle}
                  title="Fee Invoices Issued Successfully"
                  onClose={() => setDismissedAlerts((prev) => ({ ...prev, success: true }))}
                >
                  1,240 automated term billing receipts have been dispatched to student guardians via SMS and email notifications.
                </Alert>
              )}

              {/* Warning Alert */}
              {!dismissedAlerts['warning'] && (
                <Alert
                  variant="warning"
                  styleType={alertStyle}
                  title="Pending Teacher Attendance Approvals"
                  onClose={() => setDismissedAlerts((prev) => ({ ...prev, warning: true }))}
                  action={
                    <Button size="xs" variant="primary" portalTheme={activePortalTheme}>
                      Review Pending (4)
                    </Button>
                  }
                >
                  4 leave requests from the Science department require immediate administrator clearance before payroll lock.
                </Alert>
              )}

              {/* Error Alert */}
              {!dismissedAlerts['error'] && (
                <Alert
                  variant="error"
                  styleType={alertStyle}
                  title="Critical Gateway Authentication Failure"
                  onClose={() => setDismissedAlerts((prev) => ({ ...prev, error: true }))}
                  action={
                    <Button size="xs" variant="danger">
                      Retry Connection
                    </Button>
                  }
                >
                  Unable to connect to the biometric biometric terminal cluster on Campus Gate B. Verify local subnet routing.
                </Alert>
              )}

              {/* Neutral Alert */}
              {!dismissedAlerts['neutral'] && (
                <Alert
                  variant="neutral"
                  styleType={alertStyle}
                  title="Academic Session Notice"
                  onClose={() => setDismissedAlerts((prev) => ({ ...prev, neutral: true }))}
                >
                  Default grading scale rubric is currently locked by the Examination Controller.
                </Alert>
              )}

              {Object.values(dismissedAlerts).some(Boolean) && (
                <div className="pt-2 text-center">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setDismissedAlerts({})}
                  >
                    Reset Dismissed Alerts
                  </Button>
                </div>
              )}
            </CardContent>
            <CardFooter className="bg-slate-50 dark:bg-slate-850">
              <div className="flex items-center gap-2 text-xs text-slate-500">
                <Code2 className="w-4 h-4 text-slate-400" />
                <span>Example:</span>
                <code className="bg-white dark:bg-slate-900 px-2 py-0.5 rounded-md border border-slate-200 dark:border-slate-700 font-mono text-[11px]">
                  {'<Alert variant="success" styleType="subtle" title="Saved">Changes updated.</Alert>'}
                </code>
              </div>
              <Button
                size="xs"
                variant="ghost"
                onClick={() =>
                  copyToClipboard(
                    '<Alert variant="success" styleType="subtle" title="Success">Record updated successfully.</Alert>',
                    'alert-code'
                  )
                }
                leftIcon={copiedCode === 'alert-code' ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
              >
                {copiedCode === 'alert-code' ? 'Copied' : 'Copy JSX'}
              </Button>
            </CardFooter>
          </Card>
        </div>
      )}
    </div>
  );
};
