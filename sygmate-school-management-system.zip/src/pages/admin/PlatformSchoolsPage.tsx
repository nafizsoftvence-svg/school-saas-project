import React, { useState, useEffect } from 'react';
import {
  Building2,
  Plus,
  Users,
  GraduationCap,
  ShieldCheck,
  CheckCircle,
  AlertTriangle,
  Clock,
  ArrowRight,
  RefreshCw,
  Search,
  Filter,
  Shield,
  Layers,
  Sparkles,
  ExternalLink,
  ChevronRight,
  X
} from 'lucide-react';
import { api } from '../../services/api.js';
import { useAuth } from '../../context/AuthContext.js';
import { useToast } from '../../context/ToastContext.js';
import { School, SchoolSubscriptionPlan, SchoolSubscriptionStatus } from '../../types/index.js';

interface SchoolWithStats extends School {
  stats?: {
    studentsCount: number;
    teachersCount: number;
    adminsCount: number;
    classesCount: number;
  };
  primaryAdmin?: {
    name: string;
    email: string;
  };
}

interface PlatformSchoolsPageProps {
  onNavigate?: (viewId: string, subTabId?: string) => void;
}

export const PlatformSchoolsPage: React.FC<PlatformSchoolsPageProps> = ({ onNavigate }) => {
  const { switchActiveSchool, activeSchool } = useAuth();
  const { success: toastSuccess, error: toastError } = useToast();

  const [schools, setSchools] = useState<SchoolWithStats[]>([]);
  const [platformStats, setPlatformStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [planFilter, setPlanFilter] = useState('ALL');
  const [statusFilter, setStatusFilter] = useState('ALL');

  // Modal states
  const [showProvisionModal, setShowProvisionModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [selectedSchool, setSelectedSchool] = useState<SchoolWithStats | null>(null);
  const [submitting, setSubmitting] = useState(false);

  // New school form state
  const [formData, setFormData] = useState({
    name: '',
    code: '',
    plan: 'starter' as SchoolSubscriptionPlan,
    contactEmail: '',
    contactPhone: '',
    address: '',
    city: '',
    state: '',
    country: 'United States',
    adminName: '',
    adminEmail: ''
  });

  // Edit school form state
  const [editFormData, setEditFormData] = useState({
    name: '',
    plan: 'starter' as SchoolSubscriptionPlan,
    status: 'active' as 'active' | 'suspended' | 'trial',
    subscriptionStatus: 'active' as SchoolSubscriptionStatus,
    maxStudents: 500,
    maxStaff: 50,
    contactEmail: '',
    contactPhone: ''
  });

  const fetchData = async () => {
    setLoading(true);
    try {
      const [schoolsRes, statsRes] = await Promise.all([
        api.platform.getSchools(),
        api.platform.getStats()
      ]);

      if (schoolsRes.success && schoolsRes.data) {
        setSchools(schoolsRes.data as SchoolWithStats[]);
      }
      if (statsRes.success && statsRes.data) {
        setPlatformStats(statsRes.data);
      }
    } catch (err: any) {
      toastError('Failed to load schools', err.message || 'Network error.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleSwitchSchool = async (school: SchoolWithStats) => {
    try {
      const res = await switchActiveSchool(school.id);
      if (res.success) {
        toastSuccess('School Context Switched', `Now managing ${school.name}`);
        if (onNavigate) {
          onNavigate('admin-dashboard');
        }
      }
    } catch (err: any) {
      toastError('Switch Failed', err.message);
    }
  };

  const handleCreateSchool = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.code || !formData.contactEmail) {
      toastError('Validation Error', 'School name, unique code, and contact email are required.');
      return;
    }

    setSubmitting(true);
    try {
      const res = await api.platform.createSchool(formData);
      if (res.success && res.data) {
        toastSuccess('Tenant Provisioned', `School '${res.data.school.name}' has been created successfully.`);
        setShowProvisionModal(false);
        setFormData({
          name: '',
          code: '',
          plan: 'starter',
          contactEmail: '',
          contactPhone: '',
          address: '',
          city: '',
          state: '',
          country: 'United States',
          adminName: '',
          adminEmail: ''
        });
        await fetchData();
      } else {
        toastError('Provisioning Failed', res.error || 'Server error.');
      }
    } catch (err: any) {
      toastError('Creation Error', err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleOpenEdit = (school: SchoolWithStats) => {
    setSelectedSchool(school);
    setEditFormData({
      name: school.name,
      plan: school.plan,
      status: school.status === 'pending' ? 'active' : school.status,
      subscriptionStatus: school.subscriptionStatus,
      maxStudents: school.maxStudents,
      maxStaff: school.maxStaff,
      contactEmail: school.contactEmail,
      contactPhone: school.contactPhone
    });
    setShowEditModal(true);
  };

  const handleUpdateSchool = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSchool) return;

    setSubmitting(true);
    try {
      const res = await api.platform.updateSchool(selectedSchool.id, editFormData);
      if (res.success) {
        toastSuccess('Tenant Updated', `School '${editFormData.name}' settings have been updated.`);
        setShowEditModal(false);
        await fetchData();
      } else {
        toastError('Update Failed', res.error || 'Server error.');
      }
    } catch (err: any) {
      toastError('Update Error', err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const filteredSchools = schools.filter((school) => {
    const matchesSearch =
      school.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      school.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (school.city && school.city.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesPlan = planFilter === 'ALL' || school.plan === planFilter;
    const matchesStatus = statusFilter === 'ALL' || school.status === statusFilter;

    return matchesSearch && matchesPlan && matchesStatus;
  });

  const getPlanBadge = (plan: SchoolSubscriptionPlan) => {
    switch (plan) {
      case 'enterprise':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-purple-100 text-purple-800 border border-purple-200">
            <Sparkles className="w-3 h-3 text-purple-600" /> Enterprise
          </span>
        );
      case 'growth':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-100 text-blue-800 border border-blue-200">
            <Layers className="w-3 h-3 text-blue-600" /> Growth
          </span>
        );
      case 'starter':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 border border-emerald-200">
            Starter
          </span>
        );
      case 'trial':
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-100 text-amber-800 border border-amber-200">
            <Clock className="w-3 h-3 text-amber-600" /> Trial
          </span>
        );
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium bg-emerald-50 text-emerald-700 border border-emerald-200">
            <CheckCircle className="w-3 h-3 text-emerald-600" /> Active
          </span>
        );
      case 'trial':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-50 text-amber-700 border border-amber-200">
            <Clock className="w-3 h-3 text-amber-600" /> Evaluation
          </span>
        );
      case 'suspended':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium bg-rose-50 text-rose-700 border border-rose-200">
            <AlertTriangle className="w-3 h-3 text-rose-600" /> Suspended
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium bg-slate-100 text-slate-700 border border-slate-200">
            {status}
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2 text-blue-600 font-semibold text-xs uppercase tracking-wider mb-1">
            <Shield className="w-4 h-4" /> Platform Super Administrator Control Plane
          </div>
          <h2 className="text-2xl font-bold text-slate-900">Platform Schools & Multi-Tenant Management</h2>
          <p className="text-sm text-slate-600 mt-1">
            Provision, monitor, and govern all school tenants across the Sygmate SaaS infrastructure.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={fetchData}
            disabled={loading}
            className="p-2.5 rounded-xl border border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-slate-50 transition-colors"
            title="Refresh"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
          <button
            onClick={() => setShowProvisionModal(true)}
            className="flex items-center gap-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-xl shadow-xs transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" /> Provision New School
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center gap-4">
          <div className="p-3 bg-blue-50 text-blue-600 rounded-xl">
            <Building2 className="w-6 h-6" />
          </div>
          <div>
            <div className="text-xs font-semibold text-slate-500 uppercase">Registered Schools</div>
            <div className="text-2xl font-bold text-slate-900 mt-0.5">
              {platformStats ? platformStats.totalSchools : schools.length}
            </div>
            <div className="text-[11px] text-emerald-600 font-medium mt-0.5">
              {platformStats ? `${platformStats.activeSchools} active • ${platformStats.trialSchools} trial` : 'Multi-Tenant'}
            </div>
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center gap-4">
          <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl">
            <GraduationCap className="w-6 h-6" />
          </div>
          <div>
            <div className="text-xs font-semibold text-slate-500 uppercase">Total Students</div>
            <div className="text-2xl font-bold text-slate-900 mt-0.5">
              {platformStats ? platformStats.totalStudents.toLocaleString() : '—'}
            </div>
            <div className="text-[11px] text-slate-500 font-medium mt-0.5">Across all registered tenants</div>
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center gap-4">
          <div className="p-3 bg-purple-50 text-purple-600 rounded-xl">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <div className="text-xs font-semibold text-slate-500 uppercase">Faculty & Staff</div>
            <div className="text-2xl font-bold text-slate-900 mt-0.5">
              {platformStats ? (platformStats.totalTeachers + platformStats.totalStaff).toLocaleString() : '—'}
            </div>
            <div className="text-[11px] text-slate-500 font-medium mt-0.5">Educators & staff profiles</div>
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center gap-4">
          <div className="p-3 bg-indigo-50 text-indigo-600 rounded-xl">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <div className="text-xs font-semibold text-slate-500 uppercase">Tenant Isolation</div>
            <div className="text-2xl font-bold text-emerald-600 mt-0.5">Active</div>
            <div className="text-[11px] text-slate-500 font-medium mt-0.5">RBAC & Membership Enforced</div>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center md:justify-between gap-3">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search by school name, code, or city..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-1.5 text-xs text-slate-500 font-medium">
            <Filter className="w-3.5 h-3.5" /> Plan:
          </div>
          <select
            value={planFilter}
            onChange={(e) => setPlanFilter(e.target.value)}
            className="px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
          >
            <option value="ALL">All Plans</option>
            <option value="enterprise">Enterprise</option>
            <option value="growth">Growth</option>
            <option value="starter">Starter</option>
            <option value="trial">Trial</option>
          </select>

          <div className="flex items-center gap-1.5 text-xs text-slate-500 font-medium ml-2">
            Status:
          </div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
          >
            <option value="ALL">All Statuses</option>
            <option value="active">Active</option>
            <option value="trial">Trial</option>
            <option value="suspended">Suspended</option>
          </select>
        </div>
      </div>

      {/* Schools Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-200 text-xs font-semibold text-slate-500 uppercase tracking-wider">
                <th className="py-3.5 px-4 sm:px-6">School Tenant</th>
                <th className="py-3.5 px-4">Subscription Plan</th>
                <th className="py-3.5 px-4">Status</th>
                <th className="py-3.5 px-4">Enrolled Capacity</th>
                <th className="py-3.5 px-4">Contact & Location</th>
                <th className="py-3.5 px-4 text-right pr-6">Management</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-slate-500 text-sm">
                    <RefreshCw className="w-6 h-6 animate-spin mx-auto text-blue-600 mb-2" />
                    Loading school tenants...
                  </td>
                </tr>
              ) : filteredSchools.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-slate-500 text-sm">
                    No school tenants found matching current criteria.
                  </td>
                </tr>
              ) : (
                filteredSchools.map((school) => {
                  const isCurrent = activeSchool?.id === school.id;
                  const currentStudents = school.stats?.studentsCount || 0;
                  const percentUsed = Math.min(100, Math.round((currentStudents / school.maxStudents) * 100));

                  return (
                    <tr
                      key={school.id}
                      className={`hover:bg-slate-50/70 transition-colors ${
                        isCurrent ? 'bg-blue-50/30' : ''
                      }`}
                    >
                      <td className="py-4 px-4 sm:px-6">
                        <div className="flex items-center gap-3">
                          <div className="p-2.5 rounded-xl bg-blue-50 border border-blue-200 text-blue-700 font-bold shrink-0">
                            <Building2 className="w-5 h-5" />
                          </div>
                          <div>
                            <div className="font-bold text-slate-900 flex items-center gap-2">
                              <span>{school.name}</span>
                              {isCurrent && (
                                <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 border border-blue-200">
                                  Current Context
                                </span>
                              )}
                            </div>
                            <div className="text-xs text-slate-500 font-mono mt-0.5">
                              ID: {school.id} • Code: {school.code}
                            </div>
                          </div>
                        </div>
                      </td>

                      <td className="py-4 px-4">{getPlanBadge(school.plan)}</td>

                      <td className="py-4 px-4">{getStatusBadge(school.status)}</td>

                      <td className="py-4 px-4">
                        <div className="w-36">
                          <div className="flex justify-between text-xs text-slate-600 mb-1">
                            <span className="font-medium text-slate-900">{currentStudents}</span>
                            <span className="text-slate-400">/ {school.maxStudents} max</span>
                          </div>
                          <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
                            <div
                              className={`h-full rounded-full ${
                                percentUsed > 90 ? 'bg-rose-500' : percentUsed > 70 ? 'bg-amber-500' : 'bg-blue-600'
                              }`}
                              style={{ width: `${Math.max(5, percentUsed)}%` }}
                            />
                          </div>
                        </div>
                      </td>

                      <td className="py-4 px-4">
                        <div className="text-xs text-slate-800 font-medium">{school.contactEmail}</div>
                        <div className="text-[11px] text-slate-500">
                          {school.city ? `${school.city}, ${school.state || school.country}` : school.country}
                        </div>
                      </td>

                      <td className="py-4 px-4 text-right pr-6">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => handleSwitchSchool(school)}
                            disabled={isCurrent}
                            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer flex items-center gap-1 ${
                              isCurrent
                                ? 'bg-slate-100 text-slate-400 cursor-default'
                                : 'bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200'
                            }`}
                            title="Switch into this school's context"
                          >
                            <span>Switch Context</span>
                            <ChevronRight className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleOpenEdit(school)}
                            className="px-2.5 py-1.5 text-xs font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg border border-slate-200 transition-colors"
                          >
                            Settings
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Provision New School Modal */}
      {showProvisionModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-2xl max-w-xl w-full border border-slate-200 shadow-xl overflow-hidden">
            <div className="flex items-center justify-between p-6 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-blue-50 text-blue-600 border border-blue-200">
                  <Building2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-slate-900">Provision New School Tenant</h3>
                  <p className="text-xs text-slate-500">Creates an isolated multi-tenant school instance</p>
                </div>
              </div>
              <button
                onClick={() => setShowProvisionModal(false)}
                className="p-2 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateSchool} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    School / Institution Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. St. Jude International Academy"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-3.5 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    School Code * (Unique Identifier)
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. SJA-2026"
                    value={formData.code}
                    onChange={(e) => setFormData({ ...formData, code: e.target.value.toUpperCase() })}
                    className="w-full px-3.5 py-2.5 text-sm font-mono bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Subscription Plan Tier
                  </label>
                  <select
                    value={formData.plan}
                    onChange={(e) =>
                      setFormData({ ...formData, plan: e.target.value as SchoolSubscriptionPlan })
                    }
                    className="w-full px-3.5 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                  >
                    <option value="starter">Starter (Up to 500 Students)</option>
                    <option value="growth">Growth (Up to 1,500 Students)</option>
                    <option value="enterprise">Enterprise (Up to 5,000 Students)</option>
                    <option value="trial">Trial Evaluation (300 Students)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Contact Email *
                  </label>
                  <input
                    type="email"
                    required
                    placeholder="administration@school.edu"
                    value={formData.contactEmail}
                    onChange={(e) => setFormData({ ...formData, contactEmail: e.target.value })}
                    className="w-full px-3.5 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Contact Phone
                  </label>
                  <input
                    type="text"
                    placeholder="+1 (555) 123-4567"
                    value={formData.contactPhone}
                    onChange={(e) => setFormData({ ...formData, contactPhone: e.target.value })}
                    className="w-full px-3.5 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Street Address & Campus Location
                  </label>
                  <input
                    type="text"
                    placeholder="123 Campus Parkway"
                    value={formData.address}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    className="w-full px-3.5 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">City</label>
                  <input
                    type="text"
                    placeholder="Boston"
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    className="w-full px-3.5 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">State / Province</label>
                  <input
                    type="text"
                    placeholder="MA"
                    value={formData.state}
                    onChange={(e) => setFormData({ ...formData, state: e.target.value })}
                    className="w-full px-3.5 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                  />
                </div>
              </div>

              {/* Initial School Administrator Credentials */}
              <div className="pt-3 border-t border-slate-100">
                <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  Initial School Administrator Account (Optional)
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs text-slate-600 font-medium mb-1">Admin Full Name</label>
                    <input
                      type="text"
                      placeholder="e.g. Dr. Robert Davies"
                      value={formData.adminName}
                      onChange={(e) => setFormData({ ...formData, adminName: e.target.value })}
                      className="w-full px-3.5 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-600 font-medium mb-1">Admin Email</label>
                    <input
                      type="email"
                      placeholder="admin@school.edu"
                      value={formData.adminEmail}
                      onChange={(e) => setFormData({ ...formData, adminEmail: e.target.value })}
                      className="w-full px-3.5 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                    />
                  </div>
                </div>
                <p className="text-[11px] text-slate-500 mt-1.5">
                  Default temporary password will be initialized to <code className="bg-slate-100 px-1 py-0.5 rounded font-mono font-semibold">Admin@123</code>.
                </p>
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowProvisionModal(false)}
                  className="px-4 py-2 text-sm font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-5 py-2 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs transition-colors flex items-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  {submitting && <RefreshCw className="w-4 h-4 animate-spin" />}
                  <span>Provision Tenant</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit School Modal */}
      {showEditModal && selectedSchool && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-2xl max-w-lg w-full border border-slate-200 shadow-xl overflow-hidden">
            <div className="flex items-center justify-between p-6 border-b border-slate-100">
              <div>
                <h3 className="text-lg font-bold text-slate-900">Manage Tenant & Subscription</h3>
                <p className="text-xs text-slate-500">{selectedSchool.name} ({selectedSchool.code})</p>
              </div>
              <button
                onClick={() => setShowEditModal(false)}
                className="p-2 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleUpdateSchool} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  School Name
                </label>
                <input
                  type="text"
                  required
                  value={editFormData.name}
                  onChange={(e) => setEditFormData({ ...editFormData, name: e.target.value })}
                  className="w-full px-3.5 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Subscription Tier
                  </label>
                  <select
                    value={editFormData.plan}
                    onChange={(e) =>
                      setEditFormData({ ...editFormData, plan: e.target.value as SchoolSubscriptionPlan })
                    }
                    className="w-full px-3.5 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                  >
                    <option value="enterprise">Enterprise</option>
                    <option value="growth">Growth</option>
                    <option value="starter">Starter</option>
                    <option value="trial">Trial</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Operational Status
                  </label>
                  <select
                    value={editFormData.status}
                    onChange={(e) =>
                      setEditFormData({
                        ...editFormData,
                        status: e.target.value as 'active' | 'suspended' | 'trial'
                      })
                    }
                    className="w-full px-3.5 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                  >
                    <option value="active">Active</option>
                    <option value="trial">Trial</option>
                    <option value="suspended">Suspended</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Max Student Limit
                  </label>
                  <input
                    type="number"
                    value={editFormData.maxStudents}
                    onChange={(e) =>
                      setEditFormData({ ...editFormData, maxStudents: parseInt(e.target.value, 10) || 500 })
                    }
                    className="w-full px-3.5 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Max Staff Limit
                  </label>
                  <input
                    type="number"
                    value={editFormData.maxStaff}
                    onChange={(e) =>
                      setEditFormData({ ...editFormData, maxStaff: parseInt(e.target.value, 10) || 50 })
                    }
                    className="w-full px-3.5 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Contact Email
                </label>
                <input
                  type="email"
                  value={editFormData.contactEmail}
                  onChange={(e) => setEditFormData({ ...editFormData, contactEmail: e.target.value })}
                  className="w-full px-3.5 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowEditModal(false)}
                  className="px-4 py-2 text-sm font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-5 py-2 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs transition-colors flex items-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  {submitting && <RefreshCw className="w-4 h-4 animate-spin" />}
                  <span>Save Changes</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
