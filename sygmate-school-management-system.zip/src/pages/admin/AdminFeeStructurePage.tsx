import React, { useState, useEffect } from 'react';
import {
  FileSpreadsheet,
  Coins,
  BarChart3,
  Calendar,
  Layers,
  GraduationCap,
  Sparkles,
  ShieldAlert,
  Info,
  DollarSign,
  TrendingUp,
  CheckCircle2,
  PieChart
} from 'lucide-react';
import { Tabs } from '../../components/ui/Tabs.js';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '../../components/ui/Card.js';
import { Badge } from '../../components/ui/Badge.js';
import { Breadcrumb } from '../../components/layout/Breadcrumb.js';
import { FeeStructureManagement } from '../../components/fees/FeeStructureManagement.js';
import { FeeTypesManager } from '../../components/fees/FeeTypesManager.js';
import { api } from '../../services/api.js';
import { FeeStructure, FeeType, FeeStructureSummaryStats } from '../../types/index.js';

interface AdminFeeStructurePageProps {
  initialTab?: 'structures' | 'types' | 'analytics';
  activeTab?: 'structures' | 'types' | 'analytics';
  onTabChange?: (tab: string) => void;
  hideTabBar?: boolean;
}

export const AdminFeeStructurePage: React.FC<AdminFeeStructurePageProps> = ({
  initialTab = 'structures',
  activeTab: propActiveTab,
  onTabChange,
  hideTabBar = true
}) => {
  const [internalTab, setInternalTab] = useState<string>(initialTab);
  const activeTab = propActiveTab || internalTab;
  const setActiveTab = (tabId: string) => {
    setInternalTab(tabId);
    onTabChange?.(tabId);
  };
  const [stats, setStats] = useState<FeeStructureSummaryStats | null>(null);
  const [structures, setStructures] = useState<FeeStructure[]>([]);
  const [feeTypes, setFeeTypes] = useState<FeeType[]>([]);

  const loadAnalytics = async () => {
    try {
      const [statsRes, structRes, typesRes] = await Promise.all([
        api.fees.getFeeStructureStats(),
        api.fees.getFeeStructures(),
        api.fees.getFeeTypes()
      ]);
      if (statsRes.success && statsRes.data) setStats(statsRes.data);
      if (structRes.success && structRes.data) setStructures(structRes.data);
      if (typesRes.success && typesRes.data) setFeeTypes(typesRes.data);
    } catch (e) {
      // Ignored
    }
  };

  useEffect(() => {
    loadAnalytics();
  }, [activeTab]);

  const tabs = [
    {
      id: 'structures',
      label: 'Fee Structures',
      icon: FileSpreadsheet,
      badge: stats ? stats.totalStructures : undefined
    },
    {
      id: 'types',
      label: 'Fee Types Configuration',
      icon: Coins,
      badge: stats ? stats.totalFeeTypes : undefined
    },
    {
      id: 'analytics',
      label: 'Finance Analytics',
      icon: BarChart3
    }
  ];

  return (
    <div id="admin-fee-structure-page" className="space-y-6 pb-12">
      {/* Breadcrumb Navigation */}
      <Breadcrumb
        portalName="Super Admin Portal"
        items={[
          { label: 'Fees & Finance' },
          { label: 'Fee Structure & Type Management', active: true }
        ]}
      />

      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-gradient-to-r from-slate-900 via-indigo-950/30 to-slate-900 p-6 rounded-3xl border border-white/10 shadow-2xl backdrop-blur-xl">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="text-xs font-mono font-bold uppercase tracking-widest px-2.5 py-1 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 flex items-center gap-1.5">
              <Sparkles className="w-3 h-3 text-indigo-400" /> Part 7A — Fees & Finance Engine
            </span>
            <Badge variant="success" className="text-xs font-semibold">
              Live & Synchronized
            </Badge>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
            Fee Structure & Type Management
          </h1>
          <p className="text-sm text-slate-400 max-w-2xl mt-1 leading-relaxed">
            Configure institutional fee types (Admission, Tuition, Lab, Transport, etc.), grade-wise billing structures, collection schedules, and mandatory/optional policies.
          </p>
        </div>
      </div>

      {/* Navigation Tabs */}
      {!hideTabBar && (
        <div className="border-b border-white/10 pb-1">
          <Tabs
            tabs={tabs}
            activeTab={activeTab}
            onChange={(tabId) => setActiveTab(tabId)}
            variant="pill"
          />
        </div>
      )}

      {/* Tab 1: Fee Structures Management */}
      {activeTab === 'structures' && (
        <FeeStructureManagement
          onOpenCreateFeeType={() => setActiveTab('types')}
        />
      )}

      {/* Tab 2: Fee Types Configuration */}
      {activeTab === 'types' && (
        <FeeTypesManager
          onTypeCreatedOrUpdated={loadAnalytics}
        />
      )}

      {/* Tab 3: Finance Analytics & Distribution */}
      {activeTab === 'analytics' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Coins className="w-4 h-4 text-indigo-400" /> Category Breakdown
                </CardTitle>
                <CardDescription>Configured fee types by operational category</CardDescription>
              </CardHeader>
              <CardContent className="space-y-2">
                {['ACADEMIC', 'FACILITY', 'TRANSPORT', 'HOSTEL', 'EXTRACURRICULAR', 'ADMINISTRATIVE', 'MISCELLANEOUS'].map((cat) => {
                  const count = feeTypes.filter((t) => t.category === cat).length;
                  return (
                    <div key={cat} className="flex items-center justify-between text-xs py-1.5 border-b border-white/5">
                      <span className="text-slate-400 font-medium">{cat}</span>
                      <span className="font-mono font-bold text-white bg-slate-800 px-2 py-0.5 rounded">
                        {count} type(s)
                      </span>
                    </div>
                  );
                })}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-emerald-400" /> Frequency Distribution
                </CardTitle>
                <CardDescription>Fee structures grouped by billing cycles</CardDescription>
              </CardHeader>
              <CardContent className="space-y-2">
                {['YEARLY', 'HALF_YEARLY', 'QUARTERLY', 'MONTHLY', 'ONE_TIME', 'CUSTOM'].map((freq) => {
                  const count = structures.filter((s) => s.frequency === freq).length;
                  return (
                    <div key={freq} className="flex items-center justify-between text-xs py-1.5 border-b border-white/5">
                      <span className="text-slate-400 font-medium">{(freq || '').replace(/_/g, ' ')}</span>
                      <span className="font-mono font-bold text-emerald-300 bg-slate-800 px-2 py-0.5 rounded">
                        {count} structure(s)
                      </span>
                    </div>
                  );
                })}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-pink-400" /> Policy & Requirement
                </CardTitle>
                <CardDescription>Mandatory vs Optional enrollment rules</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="p-3 rounded-xl bg-indigo-500/10 border border-indigo-500/20">
                  <div className="flex justify-between items-center text-xs">
                    <span className="font-semibold text-indigo-300">Mandatory Structures:</span>
                    <span className="font-bold text-white font-mono text-sm">
                      {structures.filter((s) => s.isMandatory || s.feeCategory === 'MANDATORY').length}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Universal fees assigned by default across grades.
                  </p>
                </div>

                <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20">
                  <div className="flex justify-between items-center text-xs">
                    <span className="font-semibold text-emerald-300">Optional / Opt-in Structures:</span>
                    <span className="font-bold text-white font-mono text-sm">
                      {structures.filter((s) => !s.isMandatory || s.feeCategory === 'OPTIONAL').length}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Specialized transit, lab, or extracurricular subscriptions.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      )}
    </div>
  );
};
