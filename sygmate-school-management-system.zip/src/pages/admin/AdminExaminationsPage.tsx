import React, { useEffect, useState, useCallback, useMemo } from 'react';
import {
  CalendarDays,
  Plus,
  Search,
  Filter,
  RefreshCw,
  Edit2,
  Trash2,
  Archive,
  ArchiveRestore,
  Layers,
  BookOpen,
  Clock,
  CheckCircle2,
  AlertCircle,
  AlertTriangle,
  Users,
  ChevronRight,
  Sparkles,
  GraduationCap,
  Calendar,
  Building,
  HelpCircle,
  Tag,
  ArrowRight,
  Check,
  X,
  FileSpreadsheet,
  FileCheck,
  FileText,
  Award,
  BarChart3
} from 'lucide-react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '../../components/ui/Card.js';
import { Button } from '../../components/ui/Button.js';
import { Badge } from '../../components/ui/Badge.js';
import { Alert } from '../../components/ui/Alert.js';
import { Modal } from '../../components/ui/Modal.js';
import { Input } from '../../components/ui/Input.js';
import { Select } from '../../components/ui/Select.js';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner.js';
import { EmptyState } from '../../components/ui/EmptyState.js';
import { useToast } from '../../context/ToastContext.js';
import { useSettings } from '../../context/SettingsContext.js';
import { api } from '../../services/api.js';
import {
  Examination,
  ExamSubjectConfig,
  ExaminationStatus,
  AcademicSession,
  SchoolClass,
  Section,
  Subject,
  CreateExamPayload,
  UpdateExamPayload,
  ExamSubjectConfigPayload
} from '../../types/index.js';
import { ExamScheduleMasterView } from '../../components/examinations/ExamScheduleMasterView.js';
import { AdminMarksReviewView } from '../../components/examinations/AdminMarksReviewView.js';
import { GradingSystemConfigView } from '../../components/examinations/GradingSystemConfigView.js';
import { ResultCalculationView } from '../../components/examinations/ResultCalculationView.js';
import { ResultReviewAndPublishView } from '../../components/examinations/ResultReviewAndPublishView.js';
import { ReportCardsManagerView } from '../../components/examinations/ReportCardsManagerView.js';
import { MeritPositionManagerView } from '../../components/examinations/MeritPositionManagerView.js';
import { AcademicReportsDashboardView } from '../../components/examinations/AcademicReportsDashboardView.js';

interface AdminExaminationsPageProps {
  initialTab?:
    | 'overview'
    | 'schedules'
    | 'marks'
    | 'grading'
    | 'calculation'
    | 'review'
    | 'report-cards'
    | 'merit'
    | 'reports';
  activeTab?:
    | 'overview'
    | 'schedules'
    | 'marks'
    | 'grading'
    | 'calculation'
    | 'review'
    | 'report-cards'
    | 'merit'
    | 'reports';
  onTabChange?: (tab: string) => void;
  hideTabBar?: boolean;
}

export const AdminExaminationsPage: React.FC<AdminExaminationsPageProps> = ({
  initialTab = 'overview',
  activeTab: propActiveTab,
  onTabChange,
  hideTabBar = true
}) => {
  const { addToast } = useToast();
  const { settings, formatDate } = useSettings();

  // Primary Tab switcher
  const [internalTab, setInternalTab] = useState<
    'overview' | 'schedules' | 'marks' | 'grading' | 'calculation' | 'review' | 'report-cards' | 'merit' | 'reports'
  >(initialTab);
  const activeMainTab = propActiveTab || internalTab;

  const setActiveMainTab = (tab: any) => {
    setInternalTab(tab);
    onTabChange?.(tab);
  };

  useEffect(() => {
    if (initialTab) {
      setInternalTab(initialTab);
    }
  }, [initialTab]);

  // Data states
  const [examinations, setExaminations] = useState<Examination[]>([]);
  const [stats, setStats] = useState({
    total: 0,
    draft: 0,
    scheduled: 0,
    ongoing: 0,
    completed: 0,
    published: 0,
    archived: 0
  });
  const [academicSessions, setAcademicSessions] = useState<AcademicSession[]>([]);
  const [classes, setClasses] = useState<SchoolClass[]>([]);
  const [sections, setSections] = useState<Section[]>([]);
  const [examTypes, setExamTypes] = useState<string[]>([]);
  const [allSubjects, setAllSubjects] = useState<Subject[]>([]);
  const [teachers, setTeachers] = useState<Array<{ id: string; name: string; designation: string; department: string }>>([]);

  // UI & Loading states
  const [loading, setLoading] = useState<boolean>(true);
  const [refreshing, setRefreshing] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // Filters
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filterSession, setFilterSession] = useState<string>('ALL');
  const [filterClass, setFilterClass] = useState<string>('ALL');
  const [filterSection, setFilterSection] = useState<string>('ALL');
  const [filterType, setFilterType] = useState<string>('ALL');
  const [filterStatus, setFilterStatus] = useState<string>('ALL');
  const [includeArchived, setIncludeArchived] = useState<boolean>(false);

  // Modals state
  const [isCreateModalOpen, setIsCreateModalOpen] = useState<boolean>(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState<boolean>(false);
  const [isSubjectModalOpen, setIsSubjectModalOpen] = useState<boolean>(false);
  const [isAddSubjectModalOpen, setIsAddSubjectModalOpen] = useState<boolean>(false);
  const [isEditSubjectModalOpen, setIsEditSubjectModalOpen] = useState<boolean>(false);
  const [isStatusModalOpen, setIsStatusModalOpen] = useState<boolean>(false);
  const [isTypeModalOpen, setIsTypeModalOpen] = useState<boolean>(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState<boolean>(false);

  // Active / Selected items
  const [selectedExam, setSelectedExam] = useState<Examination | null>(null);
  const [selectedSubjectConfig, setSelectedSubjectConfig] = useState<ExamSubjectConfig | null>(null);

  // Form states: Create / Edit Exam
  const [formData, setFormData] = useState<CreateExamPayload>({
    name: '',
    examType: 'Mid Term',
    academicSessionId: '',
    classId: '',
    sectionId: 'ALL',
    startDate: '',
    endDate: '',
    status: 'draft',
    description: '',
    instructions: ''
  });
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Form states: Subject Config
  const [subjectFormData, setSubjectFormData] = useState<ExamSubjectConfigPayload>({
    subjectId: '',
    fullMarks: 100,
    passMarks: 40,
    examDurationMinutes: 120,
    examDate: '',
    startTime: '09:00 AM',
    endTime: '11:00 AM',
    roomNumber: 'Main Examination Hall',
    invigilatorTeacherId: '',
    instructions: ''
  });
  const [subjectFormErrors, setSubjectFormErrors] = useState<Record<string, string>>({});

  // Form states: Custom Exam Type
  const [newTypeName, setNewTypeName] = useState<string>('');
  const [typeError, setTypeError] = useState<string | null>(null);

  // Form state: Status change
  const [targetStatus, setTargetStatus] = useState<ExaminationStatus>('draft');

  // Load all initial data
  const loadData = useCallback(async (isSilent = false) => {
    try {
      if (!isSilent) setLoading(true);
      else setRefreshing(true);
      setError(null);

      const [examsRes, sessionsRes, classesRes, sectionsRes, typesRes, subjectsRes, teachersRes] = await Promise.all([
        api.examinations.getExaminations({
          academicSessionId: filterSession !== 'ALL' ? filterSession : undefined,
          classId: filterClass !== 'ALL' ? filterClass : undefined,
          sectionId: filterSection !== 'ALL' ? filterSection : undefined,
          status: filterStatus !== 'ALL' ? filterStatus : undefined,
          examType: filterType !== 'ALL' ? filterType : undefined,
          search: searchQuery.trim() ? searchQuery.trim() : undefined,
          includeArchived
        }),
        api.getAcademicSessions(),
        api.getClasses(),
        api.getSections(),
        api.examinations.getExamTypes(),
        api.getSubjects(),
        api.getTeachers()
      ]);

      if (examsRes.success && examsRes.data) {
        const items = Array.isArray(examsRes.data)
          ? examsRes.data
          : Array.isArray((examsRes.data as any).data)
          ? (examsRes.data as any).data
          : [];
        setExaminations(items);
        if ((examsRes.data as any).stats) {
          setStats((examsRes.data as any).stats);
        }
      }

      if (sessionsRes.success && sessionsRes.data) {
        const items = Array.isArray(sessionsRes.data)
          ? sessionsRes.data
          : Array.isArray((sessionsRes.data as any).data)
          ? (sessionsRes.data as any).data
          : [];
        setAcademicSessions(items);
      }

      if (classesRes.success && classesRes.data) {
        const items = Array.isArray(classesRes.data)
          ? classesRes.data
          : Array.isArray((classesRes.data as any).data)
          ? (classesRes.data as any).data
          : [];
        setClasses(items);
      }

      if (sectionsRes.success && sectionsRes.data) {
        const items = Array.isArray(sectionsRes.data)
          ? sectionsRes.data
          : Array.isArray((sectionsRes.data as any).data)
          ? (sectionsRes.data as any).data
          : [];
        setSections(items);
      }

      if (typesRes.success && typesRes.data) {
        const items = Array.isArray(typesRes.data)
          ? typesRes.data
          : Array.isArray((typesRes.data as any).data)
          ? (typesRes.data as any).data
          : [];
        setExamTypes(items);
      }

      if (subjectsRes.success && subjectsRes.data) {
        const items = Array.isArray(subjectsRes.data)
          ? subjectsRes.data
          : Array.isArray((subjectsRes.data as any).data)
          ? (subjectsRes.data as any).data
          : [];
        setAllSubjects(items);
      }

      if (teachersRes.success && teachersRes.data) {
        const rawTeachers = Array.isArray(teachersRes.data)
          ? teachersRes.data
          : Array.isArray((teachersRes.data as any).data)
          ? (teachersRes.data as any).data
          : [];
        const teacherList = rawTeachers.map((t: any) => ({
          id: t.id,
          name: `${t.firstName || ''} ${t.lastName || ''}`.trim() || t.employeeCode || 'Faculty Member',
          designation: t.designation || 'Faculty Member',
          department: t.department || 'Academic Faculty'
        }));
        setTeachers(teacherList);
      }
    } catch (err: any) {
      console.error('Failed to load examination management data:', err);
      setError(err?.message || 'Failed to load examinations. Please verify server connection.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [filterSession, filterClass, filterSection, filterStatus, filterType, searchQuery, includeArchived]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // Available sections for chosen class in create/edit modal
  const availableFormSections = useMemo(() => {
    if (!formData.classId) return [];
    return sections.filter((s) => s.classId === formData.classId);
  }, [formData.classId, sections]);

  // Available subjects for chosen exam in subject modal
  const availableExamSubjects = useMemo(() => {
    if (!selectedExam) return [];
    return allSubjects.filter((s) => s.classId === selectedExam.classId);
  }, [selectedExam, allSubjects]);

  // Filter sections for the filter toolbar
  const availableFilterSections = useMemo(() => {
    if (filterClass === 'ALL') return [];
    return sections.filter((s) => s.classId === filterClass);
  }, [filterClass, sections]);

  // Open Create Exam Modal
  const handleOpenCreateModal = () => {
    const defaultSession = (academicSessions || []).find((s) => s.isActive)?.id || academicSessions?.[0]?.id || '';
    const defaultClass = classes?.[0]?.id || '';
    const today = new Date().toISOString().split('T')[0];
    const nextWeek = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

    setFormData({
      name: '',
      examType: examTypes?.[0] || 'Mid Term',
      academicSessionId: defaultSession,
      classId: defaultClass,
      sectionId: 'ALL',
      startDate: today,
      endDate: nextWeek,
      status: 'draft',
      description: '',
      instructions: ''
    });
    setFormErrors({});
    setIsCreateModalOpen(true);
  };

  // Open Edit Exam Modal
  const handleOpenEditModal = (exam: Examination) => {
    setSelectedExam(exam);
    setFormData({
      name: exam.name,
      examType: exam.examType,
      academicSessionId: exam.academicSessionId,
      classId: exam.classId,
      sectionId: exam.sectionId || 'ALL',
      startDate: exam.startDate,
      endDate: exam.endDate,
      status: exam.status,
      description: exam.description || '',
      instructions: exam.instructions || ''
    });
    setFormErrors({});
    setIsEditModalOpen(true);
  };

  // Open Subject Management Drawer
  const handleOpenSubjectModal = async (exam: Examination) => {
    setSelectedExam(exam);
    setIsSubjectModalOpen(true);
    // Refresh exam to have latest subjects
    try {
      const res = await api.examinations.getExamById(exam.id);
      if (res.success && res.data) {
        setSelectedExam(res.data.data);
      }
    } catch (e) {
      console.error('Failed to fetch full exam details', e);
    }
  };

  // Open Add Single Subject Modal
  const handleOpenAddSubjectModal = () => {
    if (!selectedExam) return;
    const existingSubjectIds = new Set((selectedExam.subjectsConfig || []).map((s) => s.subjectId));
    const available = (allSubjects || []).filter((s) => s.classId === selectedExam.classId && !existingSubjectIds.has(s.id));
    const firstSubject = available?.[0]?.id || '';

    setSubjectFormData({
      subjectId: firstSubject,
      fullMarks: 100,
      passMarks: 40,
      examDurationMinutes: 120,
      examDate: selectedExam.startDate,
      startTime: '09:00 AM',
      endTime: '11:00 AM',
      roomNumber: 'Main Examination Hall',
      invigilatorTeacherId: teachers?.[0]?.id || '',
      instructions: ''
    });
    setSubjectFormErrors({});
    setIsAddSubjectModalOpen(true);
  };

  // Open Edit Subject Modal
  const handleOpenEditSubjectModal = (config: ExamSubjectConfig) => {
    setSelectedSubjectConfig(config);
    setSubjectFormData({
      subjectId: config.subjectId,
      fullMarks: config.fullMarks,
      passMarks: config.passMarks,
      examDurationMinutes: config.examDurationMinutes,
      examDate: config.examDate,
      startTime: config.startTime,
      endTime: config.endTime,
      roomNumber: config.roomNumber || 'Main Examination Hall',
      invigilatorTeacherId: config.invigilatorTeacherId || '',
      instructions: config.instructions || ''
    });
    setSubjectFormErrors({});
    setIsEditSubjectModalOpen(true);
  };

  // Open Status Transition Modal
  const handleOpenStatusModal = (exam: Examination) => {
    setSelectedExam(exam);
    setTargetStatus(exam.status);
    setIsStatusModalOpen(true);
  };

  // Open Delete Confirmation Modal
  const handleOpenDeleteModal = (exam: Examination) => {
    setSelectedExam(exam);
    setIsDeleteModalOpen(true);
  };

  // Validate Examination Form
  const validateExamForm = (): boolean => {
    const errors: Record<string, string> = {};

    if (!formData.name.trim() || formData.name.trim().length < 3) {
      errors.name = 'Examination name must be at least 3 characters.';
    }

    if (!formData.examType) {
      errors.examType = 'Exam type is required.';
    }

    if (!formData.academicSessionId) {
      errors.academicSessionId = 'Academic session is required.';
    }

    if (!formData.classId) {
      errors.classId = 'Class selection is required.';
    }

    if (!formData.startDate) {
      errors.startDate = 'Start date is required.';
    }

    if (!formData.endDate) {
      errors.endDate = 'End date is required.';
    }

    if (formData.startDate && formData.endDate) {
      if (new Date(formData.startDate).getTime() > new Date(formData.endDate).getTime()) {
        errors.endDate = 'End date cannot be earlier than start date.';
      }
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  // Handle Create Exam Submit
  const handleCreateExam = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateExamForm()) return;

    try {
      setIsSubmitting(true);
      const res = await api.examinations.createExam(formData);
      if (res.success && res.data) {
        addToast('Examination created successfully!', 'success');
        setIsCreateModalOpen(false);
        loadData(true);
      } else {
        addToast(res.error || 'Failed to create examination.', 'error');
      }
    } catch (err: any) {
      console.error('Error creating examination:', err);
      addToast(err?.message || 'Server error creating examination.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle Edit Exam Submit
  const handleEditExam = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedExam || !validateExamForm()) return;

    try {
      setIsSubmitting(true);
      const res = await api.examinations.updateExam(selectedExam.id, formData);
      if (res.success && res.data) {
        addToast(`Examination "${formData.name}" updated successfully!`, 'success');
        setIsEditModalOpen(false);
        loadData(true);
      } else {
        addToast(res.error || 'Failed to update examination.', 'error');
      }
    } catch (err: any) {
      console.error('Error updating examination:', err);
      addToast(err?.message || 'Server error updating examination.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle Archive / Restore
  const handleToggleArchive = async (exam: Examination) => {
    try {
      const res = await api.examinations.archiveExam(exam.id);
      if (res.success) {
        addToast(
          exam.isArchived
            ? `Examination "${exam.name}" restored successfully.`
            : `Examination "${exam.name}" archived.`,
          'info'
        );
        loadData(true);
      } else {
        addToast(res.error || 'Failed to update archive status.', 'error');
      }
    } catch (err: any) {
      addToast(err?.message || 'Failed to update archive status.', 'error');
    }
  };

  // Handle Delete Exam
  const handleDeleteExam = async () => {
    if (!selectedExam) return;

    try {
      setIsSubmitting(true);
      const res = await api.examinations.deleteExam(selectedExam.id);
      if (res.success) {
        addToast(`Examination "${selectedExam.name}" deleted.`, 'success');
        setIsDeleteModalOpen(false);
        loadData(true);
      } else {
        addToast(res.error || 'Failed to delete examination.', 'error');
      }
    } catch (err: any) {
      addToast(err?.message || 'Server error deleting examination.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle Status Change Submit
  const handleUpdateStatus = async () => {
    if (!selectedExam) return;

    try {
      setIsSubmitting(true);
      const res = await api.examinations.updateExamStatus(selectedExam.id, targetStatus);
      if (res.success) {
        addToast(`Examination status changed to ${targetStatus.toUpperCase()}.`, 'success');
        setIsStatusModalOpen(false);
        loadData(true);
      } else {
        addToast(res.error || 'Failed to update examination status.', 'error');
      }
    } catch (err: any) {
      addToast(err?.message || 'Server error updating status.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Validate Subject Config Form
  const validateSubjectForm = (): boolean => {
    const errors: Record<string, string> = {};

    if (!subjectFormData.subjectId) {
      errors.subjectId = 'Please select a subject.';
    }

    const full = Number(subjectFormData.fullMarks);
    const pass = Number(subjectFormData.passMarks);

    if (isNaN(full) || full <= 0) {
      errors.fullMarks = 'Full marks must be greater than 0.';
    }

    if (isNaN(pass) || pass < 0) {
      errors.passMarks = 'Pass marks cannot be negative.';
    }

    if (pass > full) {
      errors.passMarks = `Pass marks (${pass}) cannot exceed full marks (${full}).`;
    }

    const duration = Number(subjectFormData.examDurationMinutes);
    if (isNaN(duration) || duration <= 0) {
      errors.examDurationMinutes = 'Duration must be greater than 0 minutes.';
    }

    if (!subjectFormData.examDate) {
      errors.examDate = 'Exam date is required.';
    }

    setSubjectFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  // Handle Add Subject Submit
  const handleAddSubject = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedExam || !validateSubjectForm()) return;

    try {
      setIsSubmitting(true);
      const res = await api.examinations.addSubjectConfig(selectedExam.id, subjectFormData);
      if (res.success && res.data) {
        addToast('Subject added to examination schedule!', 'success');
        setSelectedExam(res.data);
        setIsAddSubjectModalOpen(false);
        loadData(true);
      } else {
        addToast(res.error || 'Failed to add subject.', 'error');
      }
    } catch (err: any) {
      addToast(err?.message || 'Server error adding subject.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle Edit Subject Submit
  const handleEditSubject = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedExam || !selectedSubjectConfig || !validateSubjectForm()) return;

    try {
      setIsSubmitting(true);
      const res = await api.examinations.updateSubjectConfig(
        selectedExam.id,
        selectedSubjectConfig.id,
        subjectFormData
      );
      if (res.success && res.data) {
        addToast('Subject configuration updated!', 'success');
        setSelectedExam(res.data);
        setIsEditSubjectModalOpen(false);
        loadData(true);
      } else {
        addToast(res.error || 'Failed to update subject configuration.', 'error');
      }
    } catch (err: any) {
      addToast(err?.message || 'Server error updating subject.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle Delete Subject
  const handleDeleteSubject = async (configId: string) => {
    if (!selectedExam) return;

    try {
      const res = await api.examinations.deleteSubjectConfig(selectedExam.id, configId);
      if (res.success && res.data) {
        addToast('Subject removed from examination.', 'info');
        setSelectedExam(res.data);
        loadData(true);
      } else {
        addToast(res.error || 'Failed to remove subject.', 'error');
      }
    } catch (err: any) {
      addToast(err?.message || 'Server error removing subject.', 'error');
    }
  };

  // Handle Bulk Auto-Import Subjects
  const handleBulkImportSubjects = async () => {
    if (!selectedExam) return;

    try {
      setIsSubmitting(true);
      const res = await api.examinations.bulkImportClassSubjects(selectedExam.id, {
        defaultFullMarks: 100,
        defaultPassMarks: 40,
        defaultDuration: 120
      });
      if (res.success && res.data) {
        addToast('All active class subjects auto-imported successfully!', 'success');
        setSelectedExam(res.data);
        loadData(true);
      } else {
        addToast(res.error || 'No new subjects available to import.', 'info');
      }
    } catch (err: any) {
      addToast(err?.message || 'Failed to import subjects.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle Add Custom Exam Type
  const handleAddCustomType = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTypeName.trim() || newTypeName.trim().length < 2) {
      setTypeError('Exam type name must be at least 2 characters.');
      return;
    }

    try {
      setIsSubmitting(true);
      const res = await api.examinations.addExamType(newTypeName.trim());
      if (res.success && res.data) {
        addToast(`Exam type "${newTypeName.trim()}" added.`, 'success');
        setExamTypes(res.data);
        setFormData((prev) => ({ ...prev, examType: newTypeName.trim() }));
        setNewTypeName('');
        setTypeError(null);
        setIsTypeModalOpen(false);
      } else {
        setTypeError(res.error || 'Failed to add exam type.');
      }
    } catch (err: any) {
      setTypeError(err?.message || 'Server error adding exam type.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Helper badge color for status
  const getStatusBadge = (status: ExaminationStatus) => {
    switch (status) {
      case 'draft':
        return <Badge variant="neutral" className="bg-slate-800 text-slate-300 border-slate-700">DRAFT</Badge>;
      case 'scheduled':
        return <Badge variant="primary" className="bg-sky-500/20 text-sky-300 border-sky-500/30">SCHEDULED</Badge>;
      case 'ongoing':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 animate-pulse">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
            ONGOING
          </span>
        );
      case 'completed':
        return <Badge variant="success" className="bg-purple-500/20 text-purple-300 border-purple-500/30">COMPLETED</Badge>;
      case 'published':
        return <Badge variant="success" className="bg-emerald-500/20 text-emerald-300 border-emerald-500/30">PUBLISHED</Badge>;
      case 'archived':
        return <Badge variant="neutral" className="bg-zinc-800/80 text-zinc-400 border-zinc-700">ARCHIVED</Badge>;
      default:
        return <Badge variant="neutral">{status}</Badge>;
    }
  };

  // Quick stat filter click
  const handleStatFilterClick = (status: string) => {
    if (filterStatus === status) {
      setFilterStatus('ALL');
    } else {
      setFilterStatus(status);
      if (status === 'archived') {
        setIncludeArchived(true);
      }
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in-50 duration-200">
      {/* 1. Page Header & Action Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/10 pb-6">
        <div>
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-500/10 border border-indigo-500/20 rounded-2xl text-indigo-400">
              <CalendarDays className="w-7 h-7" />
            </div>
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
                Examination Setup & Management
              </h1>
              <p className="text-sm text-slate-400 mt-1">
                Configure examination cycles, exam types, class/section relationships, subject mark distributions, duration, and room schedules.
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3 flex-wrap">
          <Button
            id="btn-add-exam-type"
            variant="outline"
            size="sm"
            onClick={() => {
              setNewTypeName('');
              setTypeError(null);
              setIsTypeModalOpen(true);
            }}
            className="border-white/10 text-slate-300 hover:bg-slate-800"
          >
            <Tag className="w-4 h-4 mr-2 text-indigo-400" />
            Exam Types
          </Button>

          <Button
            id="btn-refresh-exams"
            variant="outline"
            size="sm"
            onClick={() => loadData(true)}
            disabled={refreshing || loading}
            className="border-white/10 text-slate-300 hover:bg-slate-800"
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${refreshing ? 'animate-spin text-indigo-400' : ''}`} />
            Refresh
          </Button>

          <Button
            id="btn-create-exam"
            variant="primary"
            size="sm"
            onClick={handleOpenCreateModal}
            className="bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-600/30"
          >
            <Plus className="w-4 h-4 mr-2" />
            Create Examination
          </Button>
        </div>
      </div>

      {/* Primary Navigation Tabs: Examination Cycles vs Master Schedule vs Marks Submissions vs Grading Scale vs Result Calculation */}
      {!hideTabBar && (
        <div className="flex items-center gap-2 border-b border-white/10 pb-4 flex-wrap">
        <button
          type="button"
          onClick={() => setActiveMainTab('overview')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold transition-all ${
            activeMainTab === 'overview'
              ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
              : 'bg-slate-900/60 text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>Examinations & Cycles</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveMainTab('schedules')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold transition-all ${
            activeMainTab === 'schedules'
              ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
              : 'bg-slate-900/60 text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Calendar className="w-4 h-4" />
          <span>Master Schedules & Conflict Engine</span>
          <Badge variant="primary" className="text-[10px] ml-1 bg-white/20 text-white border-0">
            Part 6B
          </Badge>
        </button>

        <button
          type="button"
          onClick={() => setActiveMainTab('marks')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold transition-all ${
            activeMainTab === 'marks'
              ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
              : 'bg-slate-900/60 text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <FileSpreadsheet className="w-4 h-4" />
          <span>Marks Submissions & Review</span>
          <Badge variant="primary" className="text-[10px] ml-1 bg-amber-500/20 text-amber-300 border-amber-500/30">
            Part 6C
          </Badge>
        </button>

        <button
          type="button"
          onClick={() => setActiveMainTab('grading')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold transition-all ${
            activeMainTab === 'grading'
              ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
              : 'bg-slate-900/60 text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <GraduationCap className="w-4 h-4" />
          <span>Grading System</span>
          <Badge variant="primary" className="text-[10px] ml-1 bg-emerald-500/20 text-emerald-300 border-emerald-500/30">
            Part 6D
          </Badge>
        </button>

        <button
          type="button"
          onClick={() => setActiveMainTab('calculation')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold transition-all ${
            activeMainTab === 'calculation'
              ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
              : 'bg-slate-900/60 text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Sparkles className="w-4 h-4" />
          <span>Grade & Result Calculation</span>
          <Badge variant="primary" className="text-[10px] ml-1 bg-sky-500/20 text-sky-300 border-sky-500/30">
            Part 6D
          </Badge>
        </button>

        <button
          type="button"
          onClick={() => setActiveMainTab('review')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold transition-all ${
            activeMainTab === 'review'
              ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
              : 'bg-slate-900/60 text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <FileCheck className="w-4 h-4" />
          <span>Result Review & Publishing</span>
          <Badge variant="primary" className="text-[10px] ml-1 bg-emerald-500/20 text-emerald-300 border-emerald-500/30">
            Part 6E
          </Badge>
        </button>

        <button
          type="button"
          onClick={() => setActiveMainTab('report-cards')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold transition-all ${
            activeMainTab === 'report-cards'
              ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
              : 'bg-slate-900/60 text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>Report Cards & Transcripts</span>
          <Badge variant="primary" className="text-[10px] ml-1 bg-indigo-500/20 text-indigo-300 border-indigo-500/30">
            Part 6F
          </Badge>
        </button>

        <button
          type="button"
          onClick={() => setActiveMainTab('merit')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold transition-all ${
            activeMainTab === 'merit'
              ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
              : 'bg-slate-900/60 text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Award className="w-4 h-4" />
          <span>Merit & Position Ranking</span>
          <Badge variant="primary" className="text-[10px] ml-1 bg-amber-500/20 text-amber-300 border-amber-500/30">
            Part 6F
          </Badge>
        </button>

        <button
          type="button"
          onClick={() => setActiveMainTab('reports')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold transition-all ${
            activeMainTab === 'reports'
              ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
              : 'bg-slate-900/60 text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <BarChart3 className="w-4 h-4" />
          <span>Academic Reports & Analytics</span>
          <Badge variant="primary" className="text-[10px] ml-1 bg-purple-500/20 text-purple-300 border-purple-500/30">
            Part 6F
          </Badge>
        </button>
      </div>
      )}

      {activeMainTab === 'reports' ? (
        <AcademicReportsDashboardView />
      ) : activeMainTab === 'merit' ? (
        <MeritPositionManagerView />
      ) : activeMainTab === 'report-cards' ? (
        <ReportCardsManagerView />
      ) : activeMainTab === 'review' ? (
        <ResultReviewAndPublishView />
      ) : activeMainTab === 'grading' ? (
        <GradingSystemConfigView />
      ) : activeMainTab === 'calculation' ? (
        <ResultCalculationView />
      ) : activeMainTab === 'marks' ? (
        <AdminMarksReviewView
          academicSessions={academicSessions}
          classes={classes}
          sections={sections}
          subjects={allSubjects}
        />
      ) : activeMainTab === 'schedules' ? (
        <ExamScheduleMasterView
          academicSessions={academicSessions}
          classes={classes}
          sections={sections}
          subjects={allSubjects}
          examinations={examinations}
          teachers={teachers}
          onRefreshParent={() => loadData(true)}
        />
      ) : (
        <>
          {/* 2. KPI Summary Telemetry Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-7 gap-3">
        <button
          type="button"
          onClick={() => setFilterStatus('ALL')}
          className={`p-4 rounded-2xl border text-left transition-all ${
            filterStatus === 'ALL'
              ? 'bg-slate-800/90 border-indigo-500/50 shadow-md ring-1 ring-indigo-500/20'
              : 'bg-slate-900/60 border-white/10 hover:bg-slate-900/90'
          }`}
        >
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">Total Exams</span>
          <span className="text-2xl font-bold text-white mt-1 block">{stats.total}</span>
        </button>

        <button
          type="button"
          onClick={() => handleStatFilterClick('draft')}
          className={`p-4 rounded-2xl border text-left transition-all ${
            filterStatus === 'draft'
              ? 'bg-amber-950/40 border-amber-500/50 shadow-md ring-1 ring-amber-500/20'
              : 'bg-slate-900/60 border-white/10 hover:bg-slate-900/90'
          }`}
        >
          <span className="text-xs font-semibold text-amber-400 uppercase tracking-wider block">Draft</span>
          <span className="text-2xl font-bold text-amber-300 mt-1 block">{stats.draft}</span>
        </button>

        <button
          type="button"
          onClick={() => handleStatFilterClick('scheduled')}
          className={`p-4 rounded-2xl border text-left transition-all ${
            filterStatus === 'scheduled'
              ? 'bg-sky-950/40 border-sky-500/50 shadow-md ring-1 ring-sky-500/20'
              : 'bg-slate-900/60 border-white/10 hover:bg-slate-900/90'
          }`}
        >
          <span className="text-xs font-semibold text-sky-400 uppercase tracking-wider block">Scheduled</span>
          <span className="text-2xl font-bold text-sky-300 mt-1 block">{stats.scheduled}</span>
        </button>

        <button
          type="button"
          onClick={() => handleStatFilterClick('ongoing')}
          className={`p-4 rounded-2xl border text-left transition-all ${
            filterStatus === 'ongoing'
              ? 'bg-emerald-950/40 border-emerald-500/50 shadow-md ring-1 ring-emerald-500/20'
              : 'bg-slate-900/60 border-white/10 hover:bg-slate-900/90'
          }`}
        >
          <span className="text-xs font-semibold text-emerald-400 uppercase tracking-wider block">Ongoing</span>
          <span className="text-2xl font-bold text-emerald-300 mt-1 block">{stats.ongoing}</span>
        </button>

        <button
          type="button"
          onClick={() => handleStatFilterClick('completed')}
          className={`p-4 rounded-2xl border text-left transition-all ${
            filterStatus === 'completed'
              ? 'bg-purple-950/40 border-purple-500/50 shadow-md ring-1 ring-purple-500/20'
              : 'bg-slate-900/60 border-white/10 hover:bg-slate-900/90'
          }`}
        >
          <span className="text-xs font-semibold text-purple-400 uppercase tracking-wider block">Completed</span>
          <span className="text-2xl font-bold text-purple-300 mt-1 block">{stats.completed}</span>
        </button>

        <button
          type="button"
          onClick={() => handleStatFilterClick('published')}
          className={`p-4 rounded-2xl border text-left transition-all ${
            filterStatus === 'published'
              ? 'bg-indigo-950/40 border-indigo-500/50 shadow-md ring-1 ring-indigo-500/20'
              : 'bg-slate-900/60 border-white/10 hover:bg-slate-900/90'
          }`}
        >
          <span className="text-xs font-semibold text-indigo-400 uppercase tracking-wider block">Published</span>
          <span className="text-2xl font-bold text-indigo-300 mt-1 block">{stats.published}</span>
        </button>

        <button
          type="button"
          onClick={() => {
            setFilterStatus('archived');
            setIncludeArchived(true);
          }}
          className={`p-4 rounded-2xl border text-left transition-all ${
            filterStatus === 'archived'
              ? 'bg-zinc-800/80 border-zinc-500/50 shadow-md ring-1 ring-zinc-500/20'
              : 'bg-slate-900/60 border-white/10 hover:bg-slate-900/90'
          }`}
        >
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">Archived</span>
          <span className="text-2xl font-bold text-slate-300 mt-1 block">{stats.archived}</span>
        </button>
      </div>

      {/* 3. Search & Multi-Criteria Filter Toolbar */}
      <Card className="bg-slate-900/70 border-white/10 backdrop-blur-xl">
        <CardContent className="p-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-4">
            {/* Search Input */}
            <div className="lg:col-span-2">
              <Input
                id="filter-search"
                placeholder="Search by exam name or type..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                leftIcon={<Search className="w-4 h-4 text-slate-400" />}
              />
            </div>

            {/* Academic Session */}
            <div>
              <Select
                id="filter-session"
                value={filterSession}
                onChange={(e) => setFilterSession(e.target.value)}
                options={[
                  { value: 'ALL', label: 'All Sessions' },
                  ...academicSessions.map((s) => ({ value: s.id, label: s.name }))
                ]}
              />
            </div>

            {/* Class */}
            <div>
              <Select
                id="filter-class"
                value={filterClass}
                onChange={(e) => {
                  setFilterClass(e.target.value);
                  setFilterSection('ALL');
                }}
                options={[
                  { value: 'ALL', label: 'All Classes' },
                  ...classes.map((c) => ({ value: c.id, label: c.name }))
                ]}
              />
            </div>

            {/* Exam Type */}
            <div>
              <Select
                id="filter-type"
                value={filterType}
                onChange={(e) => setFilterType(e.target.value)}
                options={[
                  { value: 'ALL', label: 'All Exam Types' },
                  ...examTypes.map((t) => ({ value: t, label: t }))
                ]}
              />
            </div>

            {/* Status Filter */}
            <div>
              <Select
                id="filter-status"
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                options={[
                  { value: 'ALL', label: 'All Statuses' },
                  { value: 'draft', label: 'Draft' },
                  { value: 'scheduled', label: 'Scheduled' },
                  { value: 'ongoing', label: 'Ongoing' },
                  { value: 'completed', label: 'Completed' },
                  { value: 'published', label: 'Published' },
                  { value: 'archived', label: 'Archived' }
                ]}
              />
            </div>
          </div>

          <div className="flex items-center justify-between mt-4 pt-3 border-t border-white/5 text-xs text-slate-400">
            <label className="flex items-center gap-2 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={includeArchived}
                onChange={(e) => setIncludeArchived(e.target.checked)}
                className="rounded border-slate-700 bg-slate-800 text-indigo-600 focus:ring-indigo-500 h-4 w-4"
              />
              <span>Include archived & deactivated examinations</span>
            </label>

            {(searchQuery || filterSession !== 'ALL' || filterClass !== 'ALL' || filterType !== 'ALL' || filterStatus !== 'ALL' || includeArchived) && (
              <button
                type="button"
                onClick={() => {
                  setSearchQuery('');
                  setFilterSession('ALL');
                  setFilterClass('ALL');
                  setFilterSection('ALL');
                  setFilterType('ALL');
                  setFilterStatus('ALL');
                  setIncludeArchived(false);
                }}
                className="text-indigo-400 hover:text-indigo-300 font-medium underline cursor-pointer"
              >
                Reset all filters
              </button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* 4. Main Examinations Table / List */}
      {loading ? (
        <div className="py-20 flex justify-center">
          <LoadingSpinner size="lg" message="Loading examination directories and schedules..." />
        </div>
      ) : error ? (
        <Alert variant="error" title="Failed to load examinations">
          {error}
        </Alert>
      ) : examinations.length === 0 ? (
        <EmptyState
          title="No examinations found"
          description={
            searchQuery || filterSession !== 'ALL' || filterClass !== 'ALL' || filterStatus !== 'ALL'
              ? 'No examinations matched your active search and filter parameters. Try clearing filters.'
              : 'There are no examination cycles configured in the system yet. Click "Create Examination" to begin.'
          }
          icon={<CalendarDays className="w-10 h-10 text-slate-400" />}
          action={
            <Button variant="primary" onClick={handleOpenCreateModal} className="bg-indigo-600 hover:bg-indigo-500">
              <Plus className="w-4 h-4 mr-2" />
              Create First Examination
            </Button>
          }
        />
      ) : (
        <div className="space-y-4">
          <div className="overflow-x-auto rounded-2xl border border-white/10 bg-slate-900/60 backdrop-blur-xl shadow-xl">
            <table className="w-full text-left text-sm text-slate-300 border-collapse">
              <thead className="bg-slate-950/80 text-xs font-semibold text-slate-400 uppercase tracking-wider border-b border-white/10">
                <tr>
                  <th scope="col" className="py-4 px-6">Examination Details</th>
                  <th scope="col" className="py-4 px-6">Academic Scope</th>
                  <th scope="col" className="py-4 px-6">Date Window</th>
                  <th scope="col" className="py-4 px-6">Subjects & Marks</th>
                  <th scope="col" className="py-4 px-6">Status</th>
                  <th scope="col" className="py-4 px-6 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {(examinations || []).map((exam) => {
                  const subjectCount = exam.subjectsConfig?.length || exam.subjectCount || 0;
                  const totalMarks = exam.totalFullMarks || (exam.subjectsConfig || []).reduce((acc, s) => acc + (s.fullMarks || 0), 0);

                  return (
                    <tr
                      key={exam.id}
                      className={`hover:bg-white/[0.03] transition-colors ${
                        exam.isArchived ? 'opacity-60 bg-zinc-950/40' : ''
                      }`}
                    >
                      {/* Name & Type */}
                      <td className="py-4 px-6">
                        <div className="flex flex-col gap-1">
                          <div className="flex items-center gap-2">
                            <span className="font-semibold text-white text-base">{exam.name}</span>
                            {exam.isArchived && (
                              <Badge variant="neutral" className="text-[10px] px-1.5 py-0 bg-zinc-800 text-zinc-400">
                                Archived
                              </Badge>
                            )}
                          </div>
                          <div className="flex items-center gap-2 text-xs text-slate-400">
                            <span className="inline-flex items-center px-2 py-0.5 rounded-md bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 font-medium">
                              {exam.examType}
                            </span>
                            {exam.description && (
                              <span className="truncate max-w-xs text-slate-500" title={exam.description}>
                                • {exam.description}
                              </span>
                            )}
                          </div>
                        </div>
                      </td>

                      {/* Academic Scope: Session, Class, Section */}
                      <td className="py-4 px-6">
                        <div className="flex flex-col gap-1">
                          <span className="font-medium text-slate-200">{exam.className || 'All Classes'}</span>
                          <div className="flex items-center gap-2 text-xs text-slate-400">
                            <span>{exam.academicSessionName}</span>
                            <span>•</span>
                            <span className="text-slate-400 font-mono">
                              {exam.sectionId === 'ALL' ? 'All Sections' : exam.sectionName || 'Specific Section'}
                            </span>
                          </div>
                        </div>
                      </td>

                      {/* Date Window */}
                      <td className="py-4 px-6">
                        <div className="flex flex-col gap-1 text-xs">
                          <span className="font-medium text-slate-200 flex items-center gap-1.5">
                            <Calendar className="w-3.5 h-3.5 text-indigo-400" />
                            {formatDate(exam.startDate)} – {formatDate(exam.endDate)}
                          </span>
                          <span className="text-slate-500">
                            {Math.max(1, Math.round((new Date(exam.endDate).getTime() - new Date(exam.startDate).getTime()) / (1000 * 60 * 60 * 24)) + 1)} days schedule window
                          </span>
                        </div>
                      </td>

                      {/* Subjects & Marks */}
                      <td className="py-4 px-6">
                        <div className="flex flex-col gap-1">
                          <div className="flex items-center gap-2">
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-800 text-indigo-300 border border-indigo-500/20">
                              <BookOpen className="w-3 h-3 text-indigo-400" />
                              {subjectCount} {subjectCount === 1 ? 'Subject' : 'Subjects'}
                            </span>
                            {totalMarks > 0 && (
                              <span className="text-xs text-slate-400 font-mono">
                                {totalMarks} Full Marks
                              </span>
                            )}
                          </div>
                          {subjectCount === 0 && (
                            <span className="text-[11px] text-amber-400/90 flex items-center gap-1">
                              <AlertCircle className="w-3 h-3" /> No subjects configured yet
                            </span>
                          )}
                        </div>
                      </td>

                      {/* Status */}
                      <td className="py-4 px-6">
                        <div className="flex items-center gap-2">
                          {getStatusBadge(exam.status)}
                        </div>
                      </td>

                      {/* Actions */}
                      <td className="py-4 px-6 text-right">
                        <div className="flex items-center justify-end gap-2">
                          {/* Subject Config Drawer Button */}
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleOpenSubjectModal(exam)}
                            className="bg-indigo-950/40 hover:bg-indigo-900/60 text-indigo-300 border-indigo-500/30 text-xs px-3 py-1.5"
                            title="Manage exam subjects and schedule"
                          >
                            <BookOpen className="w-3.5 h-3.5 mr-1.5 text-indigo-400" />
                            Subjects ({subjectCount})
                          </Button>

                          {/* Quick Status Change */}
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleOpenStatusModal(exam)}
                            className="border-white/10 text-slate-300 hover:bg-slate-800 text-xs px-2.5 py-1.5"
                            title="Change status"
                          >
                            Status
                          </Button>

                          {/* Edit Details */}
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleOpenEditModal(exam)}
                            className="border-white/10 text-slate-300 hover:bg-slate-800 p-2"
                            title="Edit examination details"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </Button>

                          {/* Archive / Restore */}
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleToggleArchive(exam)}
                            className="border-white/10 text-slate-400 hover:text-slate-200 hover:bg-slate-800 p-2"
                            title={exam.isArchived ? 'Restore Examination' : 'Archive Examination'}
                          >
                            {exam.isArchived ? (
                              <ArchiveRestore className="w-3.5 h-3.5 text-emerald-400" />
                            ) : (
                              <Archive className="w-3.5 h-3.5" />
                            )}
                          </Button>

                          {/* Delete */}
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleOpenDeleteModal(exam)}
                            className="border-rose-500/20 text-rose-400 hover:bg-rose-950/40 hover:border-rose-500/40 p-2"
                            title="Delete examination"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
        </>
      )}

      {/* ========================================================= */}
      {/* 5. MODAL: CREATE EXAMINATION                             */}
      {/* ========================================================= */}
      <Modal
        id="modal-create-exam"
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        size="lg"
        title={
          <div className="flex items-center gap-3">
            <div className="p-2 bg-indigo-500/20 rounded-xl text-indigo-400">
              <CalendarDays className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">Create New Examination</h3>
              <p className="text-xs text-slate-400">Define academic session, class association, timeline, and exam type.</p>
            </div>
          </div>
        }
      >
        <form onSubmit={handleCreateExam} className="p-6 space-y-5">
          {/* Exam Name */}
          <div>
            <Input
              id="create-exam-name"
              label="Examination Name *"
              placeholder="e.g. Fall Mid-Term Examination 2026"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              error={formErrors.name}
              helperText="Must be distinct for the selected class and academic session."
            />
          </div>

          {/* Exam Type & Status */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <Select
                id="create-exam-type"
                label="Exam Type *"
                value={formData.examType}
                onChange={(e) => setFormData({ ...formData, examType: e.target.value })}
                error={formErrors.examType}
                options={(examTypes || []).map((t) => ({ value: t, label: t }))}
              />
            </div>

            <div>
              <Select
                id="create-exam-status"
                label="Initial Status"
                value={formData.status || 'draft'}
                onChange={(e) => setFormData({ ...formData, status: e.target.value as ExaminationStatus })}
                options={[
                  { value: 'draft', label: 'Draft (Configuration Phase)' },
                  { value: 'scheduled', label: 'Scheduled (Timetable Active)' },
                  { value: 'ongoing', label: 'Ongoing (In Progress)' }
                ]}
              />
            </div>
          </div>

          {/* Academic Session & Class */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <Select
                id="create-exam-session"
                label="Academic Session *"
                value={formData.academicSessionId}
                onChange={(e) => setFormData({ ...formData, academicSessionId: e.target.value })}
                error={formErrors.academicSessionId}
                options={(academicSessions || []).map((s) => ({
                  value: s.id,
                  label: `${s.name}${s.isActive ? ' (Current Active)' : ''}`
                }))}
              />
            </div>

            <div>
              <Select
                id="create-exam-class"
                label="Target Class *"
                value={formData.classId}
                onChange={(e) => setFormData({ ...formData, classId: e.target.value, sectionId: 'ALL' })}
                error={formErrors.classId}
                options={(classes || []).map((c) => ({ value: c.id, label: c.name }))}
              />
            </div>
          </div>

          {/* Section Association */}
          <div>
            <Select
              id="create-exam-section"
              label="Target Section"
              value={formData.sectionId || 'ALL'}
              onChange={(e) => setFormData({ ...formData, sectionId: e.target.value })}
              options={[
                { value: 'ALL', label: 'All Sections (Whole Grade)' },
                ...availableFormSections.map((s) => ({ value: s.id, label: `Section ${s.name}` }))
              ]}
              helperText="Choose 'All Sections' unless this exam is customized for a specific cohort."
            />
          </div>

          {/* Date Window */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <Input
                id="create-exam-start-date"
                type="date"
                label="Start Date *"
                value={formData.startDate}
                onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                error={formErrors.startDate}
              />
            </div>

            <div>
              <Input
                id="create-exam-end-date"
                type="date"
                label="End Date *"
                value={formData.endDate}
                onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
                error={formErrors.endDate}
              />
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              Description & Scope (Optional)
            </label>
            <textarea
              id="create-exam-description"
              rows={2}
              value={formData.description || ''}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Brief summary of this examination cycle..."
              className="block w-full rounded-xl border border-white/10 bg-slate-900/60 text-slate-100 placeholder-slate-500 focus:border-indigo-500 focus:ring-indigo-500/30 p-3 text-sm"
            />
          </div>

          {/* General Instructions */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              General Instructions for Students (Optional)
            </label>
            <textarea
              id="create-exam-instructions"
              rows={2}
              value={formData.instructions || ''}
              onChange={(e) => setFormData({ ...formData, instructions: e.target.value })}
              placeholder="e.g. Arrive 15 minutes before exam. Carry ID card and blue/black pens."
              className="block w-full rounded-xl border border-white/10 bg-slate-900/60 text-slate-100 placeholder-slate-500 focus:border-indigo-500 focus:ring-indigo-500/30 p-3 text-sm"
            />
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
            <Button
              type="button"
              variant="outline"
              onClick={() => setIsCreateModalOpen(false)}
              disabled={isSubmitting}
              className="border-white/10 text-slate-300"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              variant="primary"
              disabled={isSubmitting}
              className="bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-600/30"
            >
              {isSubmitting ? <LoadingSpinner size="sm" /> : <Check className="w-4 h-4 mr-2" />}
              Create Examination
            </Button>
          </div>
        </form>
      </Modal>

      {/* ========================================================= */}
      {/* 6. MODAL: EDIT EXAMINATION                               */}
      {/* ========================================================= */}
      <Modal
        id="modal-edit-exam"
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        size="lg"
        title={
          <div className="flex items-center gap-3">
            <div className="p-2 bg-indigo-500/20 rounded-xl text-indigo-400">
              <Edit2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">Edit Examination Details</h3>
              <p className="text-xs text-slate-400">Update examination parameters, dates, and instructions.</p>
            </div>
          </div>
        }
      >
        <form onSubmit={handleEditExam} className="p-6 space-y-5">
          {/* Exam Name */}
          <div>
            <Input
              id="edit-exam-name"
              label="Examination Name *"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              error={formErrors.name}
            />
          </div>

          {/* Exam Type & Status */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <Select
                id="edit-exam-type"
                label="Exam Type *"
                value={formData.examType}
                onChange={(e) => setFormData({ ...formData, examType: e.target.value })}
                error={formErrors.examType}
                options={(examTypes || []).map((t) => ({ value: t, label: t }))}
              />
            </div>

            <div>
              <Select
                id="edit-exam-status"
                label="Status"
                value={formData.status || 'draft'}
                onChange={(e) => setFormData({ ...formData, status: e.target.value as ExaminationStatus })}
                options={[
                  { value: 'draft', label: 'Draft' },
                  { value: 'scheduled', label: 'Scheduled' },
                  { value: 'ongoing', label: 'Ongoing' },
                  { value: 'completed', label: 'Completed' },
                  { value: 'published', label: 'Published' },
                  { value: 'archived', label: 'Archived' }
                ]}
              />
            </div>
          </div>

          {/* Academic Session & Class */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <Select
                id="edit-exam-session"
                label="Academic Session *"
                value={formData.academicSessionId}
                onChange={(e) => setFormData({ ...formData, academicSessionId: e.target.value })}
                error={formErrors.academicSessionId}
                options={(academicSessions || []).map((s) => ({ value: s.id, label: s.name }))}
              />
            </div>

            <div>
              <Select
                id="edit-exam-class"
                label="Class *"
                value={formData.classId}
                onChange={(e) => setFormData({ ...formData, classId: e.target.value, sectionId: 'ALL' })}
                error={formErrors.classId}
                options={(classes || []).map((c) => ({ value: c.id, label: c.name }))}
              />
            </div>
          </div>

          {/* Section Association */}
          <div>
            <Select
              id="edit-exam-section"
              label="Target Section"
              value={formData.sectionId || 'ALL'}
              onChange={(e) => setFormData({ ...formData, sectionId: e.target.value })}
              options={[
                { value: 'ALL', label: 'All Sections' },
                ...availableFormSections.map((s) => ({ value: s.id, label: `Section ${s.name}` }))
              ]}
            />
          </div>

          {/* Date Window */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <Input
                id="edit-exam-start-date"
                type="date"
                label="Start Date *"
                value={formData.startDate}
                onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                error={formErrors.startDate}
              />
            </div>

            <div>
              <Input
                id="edit-exam-end-date"
                type="date"
                label="End Date *"
                value={formData.endDate}
                onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
                error={formErrors.endDate}
              />
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              Description & Scope
            </label>
            <textarea
              id="edit-exam-description"
              rows={2}
              value={formData.description || ''}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              className="block w-full rounded-xl border border-white/10 bg-slate-900/60 text-slate-100 placeholder-slate-500 focus:border-indigo-500 focus:ring-indigo-500/30 p-3 text-sm"
            />
          </div>

          {/* General Instructions */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              General Instructions
            </label>
            <textarea
              id="edit-exam-instructions"
              rows={2}
              value={formData.instructions || ''}
              onChange={(e) => setFormData({ ...formData, instructions: e.target.value })}
              className="block w-full rounded-xl border border-white/10 bg-slate-900/60 text-slate-100 placeholder-slate-500 focus:border-indigo-500 focus:ring-indigo-500/30 p-3 text-sm"
            />
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
            <Button
              type="button"
              variant="outline"
              onClick={() => setIsEditModalOpen(false)}
              disabled={isSubmitting}
              className="border-white/10 text-slate-300"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              variant="primary"
              disabled={isSubmitting}
              className="bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-600/30"
            >
              {isSubmitting ? <LoadingSpinner size="sm" /> : <Check className="w-4 h-4 mr-2" />}
              Save Changes
            </Button>
          </div>
        </form>
      </Modal>

      {/* ========================================================= */}
      {/* 7. MODAL: SUBJECT CONFIGURATION & TIMETABLE DRAWER       */}
      {/* ========================================================= */}
      <Modal
        id="modal-subject-config"
        isOpen={isSubjectModalOpen}
        onClose={() => setIsSubjectModalOpen(false)}
        size="xl"
        title={
          <div className="flex items-center justify-between w-full pr-6">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-indigo-500/20 rounded-2xl text-indigo-400">
                <BookOpen className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white">Subject Marks & Schedule Matrix</h3>
                <p className="text-xs text-slate-400">
                  {selectedExam?.name} • {selectedExam?.className} ({selectedExam?.academicSessionName})
                </p>
              </div>
            </div>
          </div>
        }
      >
        <div className="p-6 space-y-6">
          {/* Header Stats Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-950/60 p-4 rounded-2xl border border-white/10">
            <div>
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">Subjects Configured</span>
              <span className="text-xl font-bold text-white mt-0.5 block">
                {selectedExam?.subjectsConfig?.length || 0}
              </span>
            </div>

            <div>
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">Total Full Marks</span>
              <span className="text-xl font-bold text-indigo-300 mt-0.5 block">
                {(selectedExam?.subjectsConfig || []).reduce((acc, s) => acc + (s.fullMarks || 0), 0)}
              </span>
            </div>

            <div>
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">Total Pass Marks</span>
              <span className="text-xl font-bold text-emerald-300 mt-0.5 block">
                {(selectedExam?.subjectsConfig || []).reduce((acc, s) => acc + (s.passMarks || 0), 0)}
              </span>
            </div>

            <div>
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">Exam Window</span>
              <span className="text-xs font-medium text-slate-300 mt-1 block">
                {selectedExam ? `${formatDate(selectedExam.startDate)} to ${formatDate(selectedExam.endDate)}` : ''}
              </span>
            </div>
          </div>

          {/* Action Toolbar */}
          <div className="flex items-center justify-between gap-3 flex-wrap">
            <div className="text-xs text-slate-400">
              Configure full marks, passing thresholds, duration, room allocation, and invigilator assignment for each subject.
            </div>

            <div className="flex items-center gap-2">
              <Button
                id="btn-auto-import-subjects"
                variant="outline"
                size="sm"
                onClick={handleBulkImportSubjects}
                disabled={isSubmitting}
                className="border-indigo-500/30 text-indigo-300 hover:bg-indigo-950/40 text-xs"
              >
                <Sparkles className="w-3.5 h-3.5 mr-1.5 text-indigo-400" />
                Auto-Import Class Subjects
              </Button>

              <Button
                id="btn-add-single-subject"
                variant="primary"
                size="sm"
                onClick={handleOpenAddSubjectModal}
                className="bg-indigo-600 hover:bg-indigo-500 text-white text-xs shadow-md"
              >
                <Plus className="w-3.5 h-3.5 mr-1.5" />
                Add Subject
              </Button>
            </div>
          </div>

          {/* Subjects Table */}
          {(selectedExam?.subjectsConfig?.length || 0) === 0 ? (
            <div className="py-12 border border-dashed border-white/10 rounded-2xl bg-slate-950/40 text-center p-6 space-y-3">
              <BookOpen className="w-10 h-10 text-slate-500 mx-auto" />
              <h4 className="text-base font-semibold text-white">No subjects configured yet</h4>
              <p className="text-xs text-slate-400 max-w-md mx-auto">
                Add subjects to this examination to establish full marks, pass marks, exam timings, and room schedules.
              </p>
              <div className="pt-2 flex justify-center gap-3">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleBulkImportSubjects}
                  className="border-indigo-500/30 text-indigo-300 hover:bg-indigo-950/40"
                >
                  <Sparkles className="w-4 h-4 mr-2" />
                  Auto-Import All Class Subjects
                </Button>
                <Button
                  variant="primary"
                  size="sm"
                  onClick={handleOpenAddSubjectModal}
                  className="bg-indigo-600 hover:bg-indigo-500 text-white"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add Subject Manually
                </Button>
              </div>
            </div>
          ) : (
            <div className="overflow-x-auto rounded-xl border border-white/10 bg-slate-950/40">
              <table className="w-full text-left text-sm text-slate-300 border-collapse">
                <thead className="bg-slate-950/90 text-xs font-semibold text-slate-400 uppercase tracking-wider border-b border-white/10">
                  <tr>
                    <th scope="col" className="py-3 px-4">Subject</th>
                    <th scope="col" className="py-3 px-4">Marks (Full / Pass)</th>
                    <th scope="col" className="py-3 px-4">Date & Timing</th>
                    <th scope="col" className="py-3 px-4">Room & Hall</th>
                    <th scope="col" className="py-3 px-4">Invigilator</th>
                    <th scope="col" className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {(selectedExam.subjectsConfig || []).map((config) => {
                    const passPercent = config.fullMarks > 0 ? Math.round((config.passMarks / config.fullMarks) * 100) : 0;

                    return (
                      <tr key={config.id} className="hover:bg-white/[0.02] transition-colors">
                        {/* Subject info */}
                        <td className="py-3.5 px-4">
                          <div>
                            <div className="font-semibold text-white">{config.subjectName}</div>
                            <div className="text-xs text-indigo-400 font-mono">{config.subjectCode}</div>
                          </div>
                        </td>

                        {/* Marks */}
                        <td className="py-3.5 px-4">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-slate-100">{config.fullMarks}</span>
                            <span className="text-slate-500">/</span>
                            <span className="text-emerald-400 font-medium">{config.passMarks} pass</span>
                            <span className="text-[10px] text-slate-400 bg-slate-800 px-1.5 py-0.5 rounded">
                              ({passPercent}%)
                            </span>
                          </div>
                        </td>

                        {/* Date & Time */}
                        <td className="py-3.5 px-4">
                          <div className="text-xs">
                            <div className="font-medium text-slate-200">{formatDate(config.examDate)}</div>
                            <div className="text-slate-400 flex items-center gap-1 mt-0.5">
                              <Clock className="w-3 h-3 text-slate-500" />
                              {config.startTime} – {config.endTime} ({config.examDurationMinutes} min)
                            </div>
                          </div>
                        </td>

                        {/* Room */}
                        <td className="py-3.5 px-4">
                          <span className="text-xs text-slate-300 bg-slate-900 border border-white/5 px-2 py-1 rounded-md">
                            {config.roomNumber || 'Main Exam Hall'}
                          </span>
                        </td>

                        {/* Invigilator */}
                        <td className="py-3.5 px-4">
                          <span className="text-xs text-slate-300">
                            {config.invigilatorName || 'Unassigned'}
                          </span>
                        </td>

                        {/* Actions */}
                        <td className="py-3.5 px-4 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              type="button"
                              onClick={() => handleOpenEditSubjectModal(config)}
                              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                              title="Edit marks and schedule"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleDeleteSubject(config.id)}
                              className="p-1.5 rounded-lg text-rose-400 hover:text-rose-300 hover:bg-rose-950/40 transition-colors"
                              title="Remove subject"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}

          {/* Close button */}
          <div className="flex justify-end pt-4 border-t border-white/10">
            <Button
              type="button"
              variant="outline"
              onClick={() => setIsSubjectModalOpen(false)}
              className="border-white/10 text-slate-300"
            >
              Done
            </Button>
          </div>
        </div>
      </Modal>

      {/* ========================================================= */}
      {/* 8. MODAL: ADD SUBJECT CONFIG                              */}
      {/* ========================================================= */}
      <Modal
        id="modal-add-subject"
        isOpen={isAddSubjectModalOpen}
        onClose={() => setIsAddSubjectModalOpen(false)}
        size="md"
        title={
          <div className="flex items-center gap-3">
            <div className="p-2 bg-indigo-500/20 rounded-xl text-indigo-400">
              <Plus className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">Add Subject to Examination</h3>
              <p className="text-xs text-slate-400">Configure full marks, pass marks, room, and timings.</p>
            </div>
          </div>
        }
      >
        <form onSubmit={handleAddSubject} className="p-6 space-y-4">
          {/* Subject Picker */}
          <div>
            <Select
              id="add-subject-id"
              label="Subject *"
              value={subjectFormData.subjectId}
              onChange={(e) => setSubjectFormData({ ...subjectFormData, subjectId: e.target.value })}
              error={subjectFormErrors.subjectId}
              options={(availableExamSubjects || []).map((s) => ({
                value: s.id,
                label: `${s.name} (${s.code})`
              }))}
            />
          </div>

          {/* Marks: Full & Pass */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Input
                id="add-subject-full-marks"
                type="number"
                label="Full Marks *"
                value={subjectFormData.fullMarks}
                onChange={(e) => setSubjectFormData({ ...subjectFormData, fullMarks: Number(e.target.value) })}
                error={subjectFormErrors.fullMarks}
              />
            </div>

            <div>
              <Input
                id="add-subject-pass-marks"
                type="number"
                label="Pass Marks *"
                value={subjectFormData.passMarks}
                onChange={(e) => setSubjectFormData({ ...subjectFormData, passMarks: Number(e.target.value) })}
                error={subjectFormErrors.passMarks}
              />
            </div>
          </div>

          {/* Date & Duration */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Input
                id="add-subject-date"
                type="date"
                label="Exam Date *"
                value={subjectFormData.examDate}
                onChange={(e) => setSubjectFormData({ ...subjectFormData, examDate: e.target.value })}
                error={subjectFormErrors.examDate}
              />
            </div>

            <div>
              <Input
                id="add-subject-duration"
                type="number"
                label="Duration (Minutes) *"
                value={subjectFormData.examDurationMinutes}
                onChange={(e) =>
                  setSubjectFormData({ ...subjectFormData, examDurationMinutes: Number(e.target.value) })
                }
                error={subjectFormErrors.examDurationMinutes}
              />
            </div>
          </div>

          {/* Timings */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Input
                id="add-subject-start-time"
                label="Start Time"
                value={subjectFormData.startTime}
                onChange={(e) => setSubjectFormData({ ...subjectFormData, startTime: e.target.value })}
                placeholder="09:00 AM"
              />
            </div>

            <div>
              <Input
                id="add-subject-end-time"
                label="End Time"
                value={subjectFormData.endTime}
                onChange={(e) => setSubjectFormData({ ...subjectFormData, endTime: e.target.value })}
                placeholder="11:00 AM"
              />
            </div>
          </div>

          {/* Room & Hall */}
          <div>
            <Input
              id="add-subject-room"
              label="Room / Examination Hall"
              value={subjectFormData.roomNumber || ''}
              onChange={(e) => setSubjectFormData({ ...subjectFormData, roomNumber: e.target.value })}
              placeholder="e.g. Main Examination Hall A-101"
            />
          </div>

          {/* Invigilator Teacher */}
          <div>
            <Select
              id="add-subject-invigilator"
              label="Assigned Invigilator Teacher"
              value={subjectFormData.invigilatorTeacherId || ''}
              onChange={(e) => setSubjectFormData({ ...subjectFormData, invigilatorTeacherId: e.target.value })}
              options={[
                { value: '', label: 'Unassigned (Select later)' },
                ...teachers.map((t) => ({ value: t.id, label: t.name }))
              ]}
            />
          </div>

          {/* Instructions */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              Paper-Specific Instructions (Optional)
            </label>
            <textarea
              id="add-subject-instructions"
              rows={2}
              value={subjectFormData.instructions || ''}
              onChange={(e) => setSubjectFormData({ ...subjectFormData, instructions: e.target.value })}
              placeholder="e.g. Scientific calculators allowed. Section A is compulsory."
              className="block w-full rounded-xl border border-white/10 bg-slate-900/60 text-slate-100 placeholder-slate-500 focus:border-indigo-500 focus:ring-indigo-500/30 p-3 text-sm"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
            <Button
              type="button"
              variant="outline"
              onClick={() => setIsAddSubjectModalOpen(false)}
              className="border-white/10 text-slate-300"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              variant="primary"
              disabled={isSubmitting}
              className="bg-indigo-600 hover:bg-indigo-500 text-white"
            >
              {isSubmitting ? <LoadingSpinner size="sm" /> : <Check className="w-4 h-4 mr-2" />}
              Save Subject
            </Button>
          </div>
        </form>
      </Modal>

      {/* ========================================================= */}
      {/* 9. MODAL: EDIT SUBJECT CONFIG                             */}
      {/* ========================================================= */}
      <Modal
        id="modal-edit-subject"
        isOpen={isEditSubjectModalOpen}
        onClose={() => setIsEditSubjectModalOpen(false)}
        size="md"
        title={
          <div className="flex items-center gap-3">
            <div className="p-2 bg-indigo-500/20 rounded-xl text-indigo-400">
              <Edit2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">Edit Subject Configuration</h3>
              <p className="text-xs text-slate-400">{selectedSubjectConfig?.subjectName}</p>
            </div>
          </div>
        }
      >
        <form onSubmit={handleEditSubject} className="p-6 space-y-4">
          {/* Marks: Full & Pass */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Input
                id="edit-subject-full-marks"
                type="number"
                label="Full Marks *"
                value={subjectFormData.fullMarks}
                onChange={(e) => setSubjectFormData({ ...subjectFormData, fullMarks: Number(e.target.value) })}
                error={subjectFormErrors.fullMarks}
              />
            </div>

            <div>
              <Input
                id="edit-subject-pass-marks"
                type="number"
                label="Pass Marks *"
                value={subjectFormData.passMarks}
                onChange={(e) => setSubjectFormData({ ...subjectFormData, passMarks: Number(e.target.value) })}
                error={subjectFormErrors.passMarks}
              />
            </div>
          </div>

          {/* Date & Duration */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Input
                id="edit-subject-date"
                type="date"
                label="Exam Date *"
                value={subjectFormData.examDate}
                onChange={(e) => setSubjectFormData({ ...subjectFormData, examDate: e.target.value })}
                error={subjectFormErrors.examDate}
              />
            </div>

            <div>
              <Input
                id="edit-subject-duration"
                type="number"
                label="Duration (Minutes) *"
                value={subjectFormData.examDurationMinutes}
                onChange={(e) =>
                  setSubjectFormData({ ...subjectFormData, examDurationMinutes: Number(e.target.value) })
                }
                error={subjectFormErrors.examDurationMinutes}
              />
            </div>
          </div>

          {/* Timings */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Input
                id="edit-subject-start-time"
                label="Start Time"
                value={subjectFormData.startTime}
                onChange={(e) => setSubjectFormData({ ...subjectFormData, startTime: e.target.value })}
              />
            </div>

            <div>
              <Input
                id="edit-subject-end-time"
                label="End Time"
                value={subjectFormData.endTime}
                onChange={(e) => setSubjectFormData({ ...subjectFormData, endTime: e.target.value })}
              />
            </div>
          </div>

          {/* Room & Hall */}
          <div>
            <Input
              id="edit-subject-room"
              label="Room / Examination Hall"
              value={subjectFormData.roomNumber || ''}
              onChange={(e) => setSubjectFormData({ ...subjectFormData, roomNumber: e.target.value })}
            />
          </div>

          {/* Invigilator Teacher */}
          <div>
            <Select
              id="edit-subject-invigilator"
              label="Assigned Invigilator Teacher"
              value={subjectFormData.invigilatorTeacherId || ''}
              onChange={(e) => setSubjectFormData({ ...subjectFormData, invigilatorTeacherId: e.target.value })}
              options={[
                { value: '', label: 'Unassigned' },
                ...teachers.map((t) => ({ value: t.id, label: t.name }))
              ]}
            />
          </div>

          {/* Instructions */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              Paper Instructions
            </label>
            <textarea
              id="edit-subject-instructions"
              rows={2}
              value={subjectFormData.instructions || ''}
              onChange={(e) => setSubjectFormData({ ...subjectFormData, instructions: e.target.value })}
              className="block w-full rounded-xl border border-white/10 bg-slate-900/60 text-slate-100 placeholder-slate-500 focus:border-indigo-500 focus:ring-indigo-500/30 p-3 text-sm"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
            <Button
              type="button"
              variant="outline"
              onClick={() => setIsEditSubjectModalOpen(false)}
              className="border-white/10 text-slate-300"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              variant="primary"
              disabled={isSubmitting}
              className="bg-indigo-600 hover:bg-indigo-500 text-white"
            >
              {isSubmitting ? <LoadingSpinner size="sm" /> : <Check className="w-4 h-4 mr-2" />}
              Update Configuration
            </Button>
          </div>
        </form>
      </Modal>

      {/* ========================================================= */}
      {/* 10. MODAL: STATUS TRANSITION WORKFLOW                    */}
      {/* ========================================================= */}
      <Modal
        id="modal-status-transition"
        isOpen={isStatusModalOpen}
        onClose={() => setIsStatusModalOpen(false)}
        size="md"
        title={
          <div className="flex items-center gap-3">
            <div className="p-2 bg-indigo-500/20 rounded-xl text-indigo-400">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">Examination Status Transition</h3>
              <p className="text-xs text-slate-400">{selectedExam?.name}</p>
            </div>
          </div>
        }
      >
        <div className="p-6 space-y-5">
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              Select Lifecycle Status
            </label>
            <div className="space-y-2">
              {[
                { id: 'draft', label: 'Draft', desc: 'Planning and configuration phase. Not visible in active schedules.' },
                { id: 'scheduled', label: 'Scheduled', desc: 'Timetables confirmed and visible to students/teachers.' },
                { id: 'ongoing', label: 'Ongoing', desc: 'Examination window is currently active and in progress.' },
                { id: 'completed', label: 'Completed', desc: 'Papers concluded; awaiting grading and marks review.' },
                { id: 'published', label: 'Published', desc: 'Official examination records and schedules finalized.' },
                { id: 'archived', label: 'Archived', desc: 'Historical record preserved and removed from active rosters.' }
              ].map((s) => (
                <label
                  key={s.id}
                  className={`flex items-start gap-3 p-3 rounded-xl border cursor-pointer transition-all ${
                    targetStatus === s.id
                      ? 'bg-indigo-950/40 border-indigo-500/50 ring-1 ring-indigo-500/30'
                      : 'bg-slate-900/60 border-white/5 hover:bg-slate-900'
                  }`}
                >
                  <input
                    type="radio"
                    name="targetStatus"
                    value={s.id}
                    checked={targetStatus === s.id}
                    onChange={(e) => setTargetStatus(e.target.value as ExaminationStatus)}
                    className="mt-1 text-indigo-600 focus:ring-indigo-500"
                  />
                  <div>
                    <span className="text-sm font-semibold text-white block">{s.label}</span>
                    <span className="text-xs text-slate-400 block">{s.desc}</span>
                  </div>
                </label>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
            <Button
              type="button"
              variant="outline"
              onClick={() => setIsStatusModalOpen(false)}
              className="border-white/10 text-slate-300"
            >
              Cancel
            </Button>
            <Button
              type="button"
              variant="primary"
              onClick={handleUpdateStatus}
              disabled={isSubmitting}
              className="bg-indigo-600 hover:bg-indigo-500 text-white"
            >
              {isSubmitting ? <LoadingSpinner size="sm" /> : <Check className="w-4 h-4 mr-2" />}
              Apply Transition
            </Button>
          </div>
        </div>
      </Modal>

      {/* ========================================================= */}
      {/* 11. MODAL: ADD CUSTOM EXAM TYPE                          */}
      {/* ========================================================= */}
      <Modal
        id="modal-custom-type"
        isOpen={isTypeModalOpen}
        onClose={() => setIsTypeModalOpen(false)}
        size="sm"
        title={
          <div className="flex items-center gap-3">
            <div className="p-2 bg-indigo-500/20 rounded-xl text-indigo-400">
              <Tag className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">Configurable Exam Types</h3>
              <p className="text-xs text-slate-400">Register new institutional examination classifications.</p>
            </div>
          </div>
        }
      >
        <form onSubmit={handleAddCustomType} className="p-6 space-y-4">
          <div className="space-y-2">
            <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider block">
              Active Exam Types
            </label>
            <div className="flex flex-wrap gap-2 max-h-40 overflow-y-auto p-2 rounded-xl bg-slate-950/60 border border-white/5">
              {(examTypes || []).map((t) => (
                <span
                  key={t}
                  className="px-2.5 py-1 rounded-lg text-xs font-medium bg-slate-900 text-slate-200 border border-white/10"
                >
                  {t}
                </span>
              ))}
            </div>
          </div>

          <div>
            <Input
              id="new-exam-type-name"
              label="Add New Exam Type"
              placeholder="e.g. Diagnostic Quiz, Lab Defense"
              value={newTypeName}
              onChange={(e) => {
                setNewTypeName(e.target.value);
                setTypeError(null);
              }}
              error={typeError || undefined}
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
            <Button
              type="button"
              variant="outline"
              onClick={() => setIsTypeModalOpen(false)}
              className="border-white/10 text-slate-300"
            >
              Close
            </Button>
            <Button
              type="submit"
              variant="primary"
              disabled={isSubmitting || !newTypeName.trim()}
              className="bg-indigo-600 hover:bg-indigo-500 text-white"
            >
              {isSubmitting ? <LoadingSpinner size="sm" /> : <Plus className="w-4 h-4 mr-1.5" />}
              Add Type
            </Button>
          </div>
        </form>
      </Modal>

      {/* ========================================================= */}
      {/* 12. MODAL: DELETE CONFIRMATION                           */}
      {/* ========================================================= */}
      <Modal
        id="modal-delete-exam"
        isOpen={isDeleteModalOpen}
        onClose={() => setIsDeleteModalOpen(false)}
        size="sm"
        title={
          <div className="flex items-center gap-3 text-rose-400">
            <div className="p-2 bg-rose-500/20 rounded-xl">
              <Trash2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">Delete Examination</h3>
              <p className="text-xs text-slate-400">Permanent removal check</p>
            </div>
          </div>
        }
      >
        <div className="p-6 space-y-4">
          <p className="text-sm text-slate-300">
            Are you sure you want to permanently delete{' '}
            <strong className="text-white font-semibold">"{selectedExam?.name}"</strong>?
          </p>

          <Alert variant="warning" title="Irreversible Action">
            All subject configurations and examination schedules associated with this exam will be removed. If you wish to preserve historical records, please consider Archiving instead.
          </Alert>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
            <Button
              type="button"
              variant="outline"
              onClick={() => setIsDeleteModalOpen(false)}
              disabled={isSubmitting}
              className="border-white/10 text-slate-300"
            >
              Cancel
            </Button>
            <Button
              type="button"
              variant="destructive"
              onClick={handleDeleteExam}
              disabled={isSubmitting}
              className="bg-rose-600 hover:bg-rose-500 text-white shadow-lg shadow-rose-600/30"
            >
              {isSubmitting ? <LoadingSpinner size="sm" /> : <Trash2 className="w-4 h-4 mr-2" />}
              Confirm Deletion
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
