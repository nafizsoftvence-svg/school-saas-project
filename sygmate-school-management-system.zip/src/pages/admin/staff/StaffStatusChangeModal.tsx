import React, { useState } from 'react';
import {
  AlertTriangle,
  X,
  Calendar,
  FileText,
  UserX,
  CheckCircle,
  ShieldAlert,
  Info
} from 'lucide-react';
import { Button } from '../../../components/ui/Button.js';
import { StaffProfile, EmploymentStatus } from '../../../types/index.js';

interface StaffStatusChangeModalProps {
  staff: StaffProfile;
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (payload: {
    newStatus: EmploymentStatus;
    reason: string;
    effectiveDate: string;
    notes?: string;
    deactivateAccount?: boolean;
  }) => Promise<void>;
  isSubmitting?: boolean;
}

const STATUS_OPTIONS: Array<{ value: EmploymentStatus; label: string; desc: string; badgeColor: string }> = [
  {
    value: 'active',
    label: 'Active',
    desc: 'Regular ongoing duties with active access',
    badgeColor: 'bg-emerald-50 text-emerald-700 border-emerald-200'
  },
  {
    value: 'on_leave',
    label: 'On Leave',
    desc: 'Authorized temporary medical, personal, or sabbatical leave',
    badgeColor: 'bg-amber-50 text-amber-700 border-amber-200'
  },
  {
    value: 'probation',
    label: 'Probationary',
    desc: 'Introductory assessment period for new staff',
    badgeColor: 'bg-blue-50 text-blue-700 border-blue-200'
  },
  {
    value: 'suspended',
    label: 'Suspended',
    desc: 'Temporary administrative hold pending review',
    badgeColor: 'bg-orange-50 text-orange-700 border-orange-200'
  },
  {
    value: 'resigned',
    label: 'Resigned',
    desc: 'Voluntary separation with notice period',
    badgeColor: 'bg-slate-100 text-slate-700 border-slate-300'
  },
  {
    value: 'retired',
    label: 'Retired',
    desc: 'Official superannuation retirement from service',
    badgeColor: 'bg-purple-50 text-purple-700 border-purple-200'
  },
  {
    value: 'terminated',
    label: 'Terminated',
    desc: 'Official administrative cessation of employment contract',
    badgeColor: 'bg-red-50 text-red-700 border-red-200'
  }
];

export const StaffStatusChangeModal: React.FC<StaffStatusChangeModalProps> = ({
  staff,
  isOpen,
  onClose,
  onSubmit,
  isSubmitting = false
}) => {
  const [newStatus, setNewStatus] = useState<EmploymentStatus>(staff.employmentStatus);
  const [effectiveDate, setEffectiveDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [reason, setReason] = useState<string>('');
  const [notes, setNotes] = useState<string>('');
  const [deactivateAccount, setDeactivateAccount] = useState<boolean>(
    ['suspended', 'terminated', 'resigned', 'retired'].includes(newStatus)
  );
  const [validationError, setValidationError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleStatusSelect = (val: EmploymentStatus) => {
    setNewStatus(val);
    if (['suspended', 'terminated', 'resigned', 'retired'].includes(val)) {
      setDeactivateAccount(true);
    } else if (val === 'active') {
      setDeactivateAccount(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setValidationError(null);

    if (newStatus === staff.employmentStatus) {
      setValidationError('Please select a different employment status than the current status.');
      return;
    }

    if (!reason.trim()) {
      setValidationError('A clear operational reason is mandatory for employment status transitions.');
      return;
    }

    if (!effectiveDate) {
      setValidationError('Please provide the effective date for this transition.');
      return;
    }

    try {
      await onSubmit({
        newStatus,
        reason: reason.trim(),
        effectiveDate,
        notes: notes.trim() || undefined,
        deactivateAccount
      });
      onClose();
    } catch (err: any) {
      setValidationError(err.message || 'Failed to change employment status.');
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto"
      id="staff-status-modal-overlay"
    >
      <div
        className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-xl overflow-hidden my-8"
        id="staff-status-modal-container"
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50/70">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-amber-100 text-amber-800 border border-amber-200">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-slate-900">
                Change Employment Status
              </h3>
              <p className="text-xs text-slate-500">
                Staff: {staff.displayName} ({staff.employeeCode})
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1 rounded-lg hover:bg-slate-100 transition-colors"
            id="close-status-modal-btn"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5" id="staff-status-form">
          {validationError && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-lg flex items-start gap-2 text-xs text-red-700">
              <ShieldAlert className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
              <span>{validationError}</span>
            </div>
          )}

          {/* Current Status Banner */}
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 flex items-center justify-between">
            <div>
              <span className="text-xs text-slate-500 block">Current Status</span>
              <span className="text-sm font-semibold text-slate-800 capitalize">
                {(staff.employmentStatus || 'active').replace(/_/g, ' ')}
              </span>
            </div>
            <div className="text-right">
              <span className="text-xs text-slate-500 block">Department</span>
              <span className="text-xs font-medium text-slate-700">
                {staff.departmentName}
              </span>
            </div>
          </div>

          {/* Select New Status */}
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-2">
              Select New Employment Status <span className="text-red-500">*</span>
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {STATUS_OPTIONS.map((opt) => {
                const isCurrent = staff.employmentStatus === opt.value;
                const isSelected = newStatus === opt.value;
                return (
                  <button
                    key={opt.value}
                    type="button"
                    disabled={isCurrent}
                    onClick={() => handleStatusSelect(opt.value)}
                    className={`p-3 rounded-lg border text-left transition-all ${
                      isSelected
                        ? 'border-indigo-600 bg-indigo-50/60 ring-2 ring-indigo-500/20'
                        : isCurrent
                        ? 'border-slate-200 bg-slate-100/70 opacity-60 cursor-not-allowed'
                        : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold text-slate-900">
                        {opt.label}
                      </span>
                      {isCurrent && (
                        <span className="text-[10px] text-slate-500 uppercase tracking-wider font-semibold">
                          Current
                        </span>
                      )}
                      {isSelected && !isCurrent && (
                        <CheckCircle className="w-3.5 h-3.5 text-indigo-600" />
                      )}
                    </div>
                    <p className="text-[11px] text-slate-500 mt-1 leading-tight">
                      {opt.desc}
                    </p>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Effective Date */}
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">
              Effective Date <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <input
                type="date"
                value={effectiveDate}
                onChange={(e) => setEffectiveDate(e.target.value)}
                required
                className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                id="effective-date-input"
              />
            </div>
          </div>

          {/* Operational Reason */}
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">
              Operational Reason <span className="text-red-500">*</span>
            </label>
            <textarea
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              required
              rows={2}
              placeholder="E.g., Approved annual sabbatical leave, contract term expiry, resignation notice submitted..."
              className="w-full text-xs rounded-lg border border-slate-300 p-2.5 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 resize-none"
              id="status-reason-textarea"
            />
          </div>

          {/* HR Internal Notes */}
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">
              HR Notes & Transition Context (Optional)
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Internal tracking reference or HR ticket ID"
              className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
              id="status-notes-input"
            />
          </div>

          {/* Account Governance Checkbox if staff has linked account */}
          {staff.hasAccount && (
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
              <label className="flex items-start gap-2.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={deactivateAccount}
                  onChange={(e) => setDeactivateAccount(e.target.checked)}
                  className="mt-0.5 rounded text-indigo-600 focus:ring-indigo-500 border-slate-300"
                  id="deactivate-account-checkbox"
                />
                <div>
                  <span className="text-xs font-medium text-slate-800 block">
                    Update System Login Status ({staff.username})
                  </span>
                  <span className="text-[11px] text-slate-500">
                    {deactivateAccount
                      ? 'Deactivates user account to prevent login during this period.'
                      : 'Account remains active and authorized to log in.'}
                  </span>
                </div>
              </label>
            </div>
          )}

          {/* Historical integrity reminder */}
          <div className="flex items-start gap-2 p-3 bg-blue-50/70 border border-blue-200 rounded-lg text-xs text-blue-800">
            <Info className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
            <span>
              <strong>Integrity Guard:</strong> Updating employment status safely records an audit log entry and updates rosters. All historical attendance, leave records, timetable routines, and communications remain intact.
            </span>
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={onClose}
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              variant="primary"
              size="sm"
              isLoading={isSubmitting}
              id="confirm-status-transition-btn"
            >
              Confirm Status Transition
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};
