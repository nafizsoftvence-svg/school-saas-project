import React, { useState } from 'react';
import {
  FileText,
  Upload,
  X,
  CheckCircle,
  Clock,
  Trash2,
  ExternalLink,
  ShieldCheck,
  XCircle,
  FileCheck,
  AlertCircle
} from 'lucide-react';
import { Button } from '../../../components/ui/Button.js';
import {
  StaffProfile,
  StaffDocument,
  StaffDocumentCategory,
  StaffDocumentVerificationStatus,
  UploadStaffDocumentPayload,
  VerifyStaffDocumentPayload
} from '../../../types/index.js';
import { EntityDocumentChecklistModal } from '../../../components/documents/EntityDocumentChecklistModal.js';

interface StaffDocumentsModalProps {
  staff: StaffProfile;
  isOpen: boolean;
  onClose: () => void;
  documents: StaffDocument[];
  onUploadDocument: (payload: UploadStaffDocumentPayload) => Promise<void>;
  onDeleteDocument: (docId: string) => Promise<void>;
  onVerifyDocument: (docId: string, payload: VerifyStaffDocumentPayload) => Promise<void>;
  isProcessing?: boolean;
}

const CATEGORIES: Array<{ value: StaffDocumentCategory; label: string }> = [
  { value: 'ID_PROOF', label: 'Government National ID / Passport' },
  { value: 'RESUME_CV', label: 'Curriculum Vitae / Resume' },
  { value: 'ACADEMIC_CERTIFICATE', label: 'Degree / Academic Diploma' },
  { value: 'EXPERIENCE_LETTER', label: 'Prior Employment Certificate' },
  { value: 'CONTRACT', label: 'Signed Employment Contract' },
  { value: 'POLICE_CLEARANCE', label: 'Background & Police Clearance' },
  { value: 'MEDICAL_REPORT', label: 'Medical Fitness & Immunization' },
  { value: 'OTHER', label: 'Other Regulatory Document' }
];

export const StaffDocumentsModal: React.FC<StaffDocumentsModalProps> = ({
  staff,
  isOpen,
  onClose,
  documents,
  onUploadDocument,
  onDeleteDocument,
  onVerifyDocument,
  isProcessing = false
}) => {
  const [showUploadForm, setShowUploadForm] = useState(false);
  const [activeVerifyDocId, setActiveVerifyDocId] = useState<string | null>(null);
  const [verificationRemarks, setVerificationRemarks] = useState('');
  const [isChecklistModalOpen, setIsChecklistModalOpen] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // New Document Form state
  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState<StaffDocumentCategory>('ACADEMIC_CERTIFICATE');
  const [newDocNumber, setNewDocNumber] = useState('');
  const [newAuthority, setNewAuthority] = useState('');
  const [newIssueDate, setNewIssueDate] = useState('');
  const [newExpiryDate, setNewExpiryDate] = useState('');
  const [newFileUrl, setNewFileUrl] = useState('');

  if (!isOpen) return null;

  const handleUploadSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!newTitle.trim()) {
      setError('Document title is required.');
      return;
    }

    const empCode = (staff.employeeCode || staff.id || 'staff').toLowerCase();
    const cleanTitle = (newTitle || 'doc').toLowerCase().replace(/\s+/g, '_');
    const fileUrl = newFileUrl.trim() || `https://documents.sygmateschools.edu/staff/${empCode}/${cleanTitle}.pdf`;

    try {
      await onUploadDocument({
        title: newTitle.trim(),
        category: newCategory,
        documentNumber: newDocNumber.trim() || undefined,
        issuingAuthority: newAuthority.trim() || undefined,
        issueDate: newIssueDate || undefined,
        expiryDate: newExpiryDate || undefined,
        fileUrl,
        fileSize: '1.4 MB',
        fileType: 'pdf'
      });

      // Reset form
      setNewTitle('');
      setNewDocNumber('');
      setNewAuthority('');
      setNewIssueDate('');
      setNewExpiryDate('');
      setNewFileUrl('');
      setShowUploadForm(false);
    } catch (err: any) {
      setError(err.message || 'Failed to attach staff document.');
    }
  };

  const handleVerify = async (docId: string, status: StaffDocumentVerificationStatus) => {
    try {
      await onVerifyDocument(docId, {
        verificationStatus: status,
        verificationRemarks: verificationRemarks.trim() || undefined
      });
      setActiveVerifyDocId(null);
      setVerificationRemarks('');
    } catch (err: any) {
      setError(err.message || 'Failed to update verification status.');
    }
  };

  const handleDelete = async (docId: string, docTitle: string) => {
    if (window.confirm(`Are you sure you want to remove '${docTitle}' from staff records?`)) {
      try {
        await onDeleteDocument(docId);
      } catch (err: any) {
        setError(err.message || 'Failed to remove document.');
      }
    }
  };

  const getStatusBadge = (status: StaffDocumentVerificationStatus) => {
    switch (status) {
      case 'VERIFIED':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium bg-emerald-50 text-emerald-700 border border-emerald-200">
            <CheckCircle className="w-3 h-3" /> Verified
          </span>
        );
      case 'REJECTED':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium bg-red-50 text-red-700 border border-red-200">
            <XCircle className="w-3 h-3" /> Rejected
          </span>
        );
      case 'EXPIRED':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium bg-slate-100 text-slate-700 border border-slate-300">
            <Clock className="w-3 h-3" /> Expired
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium bg-amber-50 text-amber-700 border border-amber-200">
            <Clock className="w-3 h-3" /> Pending Review
          </span>
        );
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto"
      id="staff-docs-modal-overlay"
    >
      <div
        className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-3xl overflow-hidden my-8"
        id="staff-docs-modal-container"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50/80">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-indigo-50 text-indigo-700 border border-indigo-200">
              <FileCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-slate-900">
                Staff Credentials & Document Dossier
              </h3>
              <p className="text-xs text-slate-500">
                {staff.displayName} • {staff.employeeCode} • {staff.departmentName}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1 rounded-lg hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5">
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-lg flex items-start gap-2 text-xs text-red-700">
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {/* Top Bar: Action to add document */}
          <div className="flex items-center justify-between">
            <div>
              <h4 className="text-sm font-semibold text-slate-800">
                Attached Documents ({documents.length})
              </h4>
              <p className="text-xs text-slate-500">
                Official certificates, contracts, and HR verification records
              </p>
            </div>
            <div className="flex items-center gap-2">
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => setIsChecklistModalOpen(true)}
                className="border-indigo-200 text-indigo-700 hover:bg-indigo-50 flex items-center gap-1 font-semibold"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-indigo-600" />
                Full Checklist &amp; Vault
              </Button>
              <Button
                type="button"
                variant={showUploadForm ? 'outline' : 'primary'}
                size="sm"
                onClick={() => setShowUploadForm(!showUploadForm)}
                icon={showUploadForm ? <X className="w-3.5 h-3.5" /> : <Upload className="w-3.5 h-3.5" />}
                id="toggle-upload-doc-btn"
              >
                {showUploadForm ? 'Cancel Upload' : 'Attach Document'}
              </Button>
            </div>
          </div>

          {/* Upload Form Accordion */}
          {showUploadForm && (
            <form
              onSubmit={handleUploadSubmit}
              className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-4"
              id="upload-doc-form"
            >
              <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                <span className="text-xs font-semibold text-slate-800 uppercase tracking-wider">
                  New Document Details
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Document Title <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                    placeholder="E.g., Master of Science Degree Certificate"
                    required
                    className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                    id="new-doc-title-input"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Category <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value as StaffDocumentCategory)}
                    className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                    id="new-doc-category-select"
                  >
                    {CATEGORIES.map((c) => (
                      <option key={c.value} value={c.value}>
                        {c.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Document / Registration Number
                  </label>
                  <input
                    type="text"
                    value={newDocNumber}
                    onChange={(e) => setNewDocNumber(e.target.value)}
                    placeholder="E.g., CERT-2024-9842"
                    className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Issuing Authority
                  </label>
                  <input
                    type="text"
                    value={newAuthority}
                    onChange={(e) => setNewAuthority(e.target.value)}
                    placeholder="E.g., University of Oxford / State Board"
                    className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Issue Date
                  </label>
                  <input
                    type="date"
                    value={newIssueDate}
                    onChange={(e) => setNewIssueDate(e.target.value)}
                    className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Expiry Date (If applicable)
                  </label>
                  <input
                    type="date"
                    value={newExpiryDate}
                    onChange={(e) => setNewExpiryDate(e.target.value)}
                    className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                  />
                </div>

                <div className="md:col-span-2">
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Document File Link / Storage URL
                  </label>
                  <input
                    type="text"
                    value={newFileUrl}
                    onChange={(e) => setNewFileUrl(e.target.value)}
                    placeholder="https://... or leave empty to generate institutional vault path"
                    className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-200">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setShowUploadForm(false)}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  variant="primary"
                  size="sm"
                  isLoading={isProcessing}
                  id="submit-doc-upload-btn"
                >
                  Save & Attach Document
                </Button>
              </div>
            </form>
          )}

          {/* Document List */}
          {documents.length === 0 ? (
            <div className="text-center py-10 border-2 border-dashed border-slate-200 rounded-xl">
              <FileText className="w-10 h-10 text-slate-300 mx-auto mb-2" />
              <p className="text-xs font-medium text-slate-600">
                No documents uploaded for this staff member.
              </p>
              <p className="text-[11px] text-slate-400 mt-1">
                Attach identity proof, qualification degrees, or employment contracts.
              </p>
            </div>
          ) : (
            <div className="space-y-3" id="staff-documents-list">
              {documents.map((doc) => (
                <div
                  key={doc.id}
                  className="p-4 bg-white rounded-xl border border-slate-200 hover:border-slate-300 transition-colors"
                  id={`staff-doc-card-${doc.id}`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="flex items-start gap-3">
                      <div className="p-2 rounded-lg bg-slate-100 text-slate-600 shrink-0">
                        <FileText className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="flex flex-wrap items-center gap-2">
                          <h5 className="text-xs font-semibold text-slate-900">
                            {doc.title}
                          </h5>
                          {getStatusBadge(doc.verificationStatus)}
                          <span className="text-[10px] font-medium px-2 py-0.5 rounded bg-slate-100 text-slate-600">
                            {(doc.category || 'DOCUMENT').replace(/_/g, ' ')}
                          </span>
                        </div>

                        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 mt-1 text-[11px] text-slate-500">
                          {doc.documentNumber && (
                            <span>No: <strong className="text-slate-700">{doc.documentNumber}</strong></span>
                          )}
                          {doc.issuingAuthority && (
                            <span>Issued by: <strong className="text-slate-700">{doc.issuingAuthority}</strong></span>
                          )}
                          {doc.issueDate && (
                            <span>Issued: {doc.issueDate}</span>
                          )}
                          {doc.expiryDate && (
                            <span>Expires: {doc.expiryDate}</span>
                          )}
                          {doc.verifiedBy && (
                            <span className="text-emerald-700">
                              Verified by {doc.verifiedBy} on {new Date(doc.verifiedAt || '').toLocaleDateString()}
                            </span>
                          )}
                        </div>

                        {doc.verificationRemarks && (
                          <p className="mt-1 text-[11px] italic text-slate-500 bg-slate-50 px-2 py-0.5 rounded border border-slate-100">
                            Auditor note: {doc.verificationRemarks}
                          </p>
                        )}
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                      <a
                        href={doc.fileUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="p-1.5 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 text-xs font-medium inline-flex items-center gap-1"
                        title="View Document"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                        <span className="text-[11px]">View</span>
                      </a>

                      <button
                        type="button"
                        onClick={() => setActiveVerifyDocId(activeVerifyDocId === doc.id ? null : doc.id)}
                        className="p-1.5 rounded-lg border border-indigo-200 text-indigo-700 hover:bg-indigo-50 text-xs font-medium inline-flex items-center gap-1"
                        title="Audit & Verification"
                      >
                        <ShieldCheck className="w-3.5 h-3.5" />
                        <span className="text-[11px]">Audit</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleDelete(doc.id, doc.title)}
                        className="p-1.5 rounded-lg border border-red-200 text-red-600 hover:bg-red-50 text-xs font-medium"
                        title="Delete Document"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Verification popdown */}
                  {activeVerifyDocId === doc.id && (
                    <div className="mt-3 pt-3 border-t border-slate-100 bg-slate-50/70 p-3 rounded-lg space-y-2">
                      <span className="text-xs font-semibold text-slate-800 block">
                        Institutional Compliance Audit
                      </span>
                      <input
                        type="text"
                        value={verificationRemarks}
                        onChange={(e) => setVerificationRemarks(e.target.value)}
                        placeholder="Add optional auditor remarks or verification notes..."
                        className="w-full text-xs rounded-lg border border-slate-300 px-3 py-1.5 text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                      />
                      <div className="flex items-center justify-end gap-2 pt-1">
                        <button
                          type="button"
                          onClick={() => handleVerify(doc.id, 'REJECTED')}
                          className="px-2.5 py-1 rounded bg-red-100 hover:bg-red-200 text-red-800 text-xs font-medium inline-flex items-center gap-1"
                        >
                          <XCircle className="w-3 h-3" /> Mark Rejected
                        </button>
                        <button
                          type="button"
                          onClick={() => handleVerify(doc.id, 'VERIFIED')}
                          className="px-2.5 py-1 rounded bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-medium inline-flex items-center gap-1"
                        >
                          <CheckCircle className="w-3 h-3" /> Approve & Verify
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end px-6 py-3 border-t border-slate-200 bg-slate-50/80">
          <Button type="button" variant="outline" size="sm" onClick={onClose}>
            Close
          </Button>
        </div>
      </div>

      {/* Part 15E — Staff Document Checklist & Verification Modal */}
      {isChecklistModalOpen && (
        <EntityDocumentChecklistModal
          entityType="STAFF"
          entityId={staff.id}
          entityName={staff.displayName}
          isOpen={isChecklistModalOpen}
          onClose={() => setIsChecklistModalOpen(false)}
          canVerify={true}
        />
      )}
    </div>
  );
};
