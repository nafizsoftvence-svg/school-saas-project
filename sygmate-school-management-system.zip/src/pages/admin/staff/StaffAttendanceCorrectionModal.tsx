import React, { useState } from 'react';
import {
  X,
  AlertTriangle,
  History,
  Clock,
  User,
  CheckCircle2,
  Calendar,
  Building
} from 'lucide-react';
import { Button } from '../../../components/ui/Button.js';
import {
  StaffAttendanceRecord,
  StaffAttendanceStatus,
  CorrectStaffAttendancePayload
} from '../../../types/index.js';

interface StaffAttendanceCorrectionModalProps {
  isOpen: boolean;
  onClose: () => void;
  record: StaffAttendanceRecord | null;
  onSaveCorrection: (recordId: string, payload: CorrectStaffAttendancePayload) => Promise<void>;
}

export const StaffAttendanceCorrectionModal: React.FC<StaffAttendanceCorrectionModalProps> = ({
  isOpen,
  onClose,
  record,
  onSaveCorrection
}) => {
  const [status, setStatus] = useState<StaffAttendanceStatus>(record?.status || 'PRESENT');
  const [checkInTime, setCheckInTime] = useState<string>(record?.checkInTime || '');
  const [checkOutTime, setCheckOutTime] = useState<string>(record?.checkOutTime || '');
  const [remarks, setRemarks] = useState<string>(record?.remarks || '');
  const [reason, setReason] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  React.useEffect(() => {
    if (record) {
      setStatus(record.status);
      setCheckInTime(record.checkInTime || '');
      setCheckOutTime(record.checkOutTime || '');
      setRemarks(record.remarks || '');
      setReason('');
      setError(null);
    }
  }, [record]);

  if (!isOpen || !record) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reason.trim() || reason.trim().length < 5) {
      setError('A comprehensive correction reason (minimum 5 characters) is required for the audit trail.');
      return;
    }

    setIsSubmitting(true);
    setError(null);
    try {
      await onSaveCorrection(record.id, {
        status,
        checkInTime: checkInTime || undefined,
        checkOutTime: checkOutTime || undefined,
        remarks: remarks || undefined,
        reason: reason.trim()
      });
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to submit correction to attendance record.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const statusColors: Record<StaffAttendanceStatus, string> = {
    PRESENT: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
    ABSENT: 'bg-rose-500/20 text-rose-400 border-rose-500/30',
    LATE: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
    HALF_DAY: 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30',
    LEAVE: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
    EXCUSED: 'bg-blue-500/20 text-blue-400 border-blue-500/30'
  };

  return (
    <div
      id="staff-attendance-correction-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto"
    >
      <div className="relative w-full max-w-2xl bg-slate-900 border border-white/10 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-800/80 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <History className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white tracking-tight">
                Attendance Record Correction
              </h2>
              <p className="text-xs text-slate-400">
                Authorized override and compliance audit trail logging
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {error && (
            <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/20 flex items-start gap-3 text-rose-300 text-sm">
              <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {/* Staff & Date Summary Card */}
          <div className="p-4 rounded-xl bg-slate-950/60 border border-white/5 grid grid-cols-1 sm:grid-cols-3 gap-4 text-sm">
            <div>
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
                Staff Member
              </span>
              <span className="font-semibold text-white flex items-center gap-1.5 mt-0.5">
                <User className="w-3.5 h-3.5 text-indigo-400" />
                {record.staffName}
              </span>
              <span className="text-xs text-slate-400 font-mono">
                {record.employeeCode}
              </span>
            </div>
            <div>
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
                Department / Role
              </span>
              <span className="font-semibold text-slate-200 flex items-center gap-1.5 mt-0.5">
                <Building className="w-3.5 h-3.5 text-slate-400" />
                {record.departmentName || 'General'}
              </span>
              <span className="text-xs text-slate-400">
                {record.designation || record.staffType}
              </span>
            </div>
            <div>
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
                Attendance Date
              </span>
              <span className="font-semibold text-white flex items-center gap-1.5 mt-0.5">
                <Calendar className="w-3.5 h-3.5 text-emerald-400" />
                {record.date}
              </span>
              <span className="text-xs text-slate-400">
                Original Status:{' '}
                <span className={`inline-block px-1.5 py-0.5 text-[10px] font-bold rounded border ${statusColors[record.status]}`}>
                  {record.status}
                </span>
              </span>
            </div>
          </div>

          {/* New Status Picker */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              Corrected Status <span className="text-rose-400">*</span>
            </label>
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
              {(['PRESENT', 'ABSENT', 'LATE', 'HALF_DAY', 'LEAVE', 'EXCUSED'] as StaffAttendanceStatus[]).map(
                (st) => {
                  const isSelected = status === st;
                  return (
                    <button
                      key={st}
                      type="button"
                      onClick={() => setStatus(st)}
                      className={`px-3 py-2.5 rounded-xl text-xs font-bold border transition-all text-center ${
                        isSelected
                          ? `${statusColors[st]} ring-2 ring-indigo-500 shadow-md`
                          : 'bg-slate-800/60 border-white/10 text-slate-300 hover:bg-slate-800 hover:text-white'
                      }`}
                    >
                      {st}
                    </button>
                  );
                }
              )}
            </div>
          </div>

          {/* Timings */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Check-In Time
              </label>
              <div className="relative">
                <Clock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="time"
                  value={checkInTime}
                  onChange={(e) => setCheckInTime(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Check-Out Time
              </label>
              <div className="relative">
                <Clock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="time"
                  value={checkOutTime}
                  onChange={(e) => setCheckOutTime(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>
          </div>

          {/* Remarks */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              Attendance Remarks
            </label>
            <input
              type="text"
              value={remarks}
              onChange={(e) => setRemarks(e.target.value)}
              placeholder="e.g. Biometric reader was offline, approved by Head of HR"
              className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 placeholder-slate-500"
            />
          </div>

          {/* Mandatory Audit Reason */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              Correction Reason (Audit Trail Requirement) <span className="text-rose-400">*</span>
            </label>
            <textarea
              required
              rows={3}
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="State the justification for this correction (e.g. Correcting inadvertent absent marking; staff presented manual sign-in sheet signed by department supervisor)"
              className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 placeholder-slate-500 resize-none"
            />
            <p className="text-[11px] text-slate-400 mt-1">
              This reason will be permanently attached to this attendance record's modification history along with your user ID and timestamp.
            </p>
          </div>

          {/* Modification History View */}
          {((record?.history?.length || 0) > 0) && (
            <div className="border-t border-white/10 pt-4">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5 mb-2">
                <History className="w-3.5 h-3.5" />
                Previous Corrections ({record?.history?.length || 0})
              </span>
              <div className="space-y-2 max-h-36 overflow-y-auto pr-1">
                {record.history.map((item, idx) => (
                  <div
                    key={item.id || idx}
                    className="p-2.5 rounded-lg bg-slate-950/40 border border-white/5 text-xs text-slate-300"
                  >
                    <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1">
                      <span>By {item.correctedByUserName}</span>
                      <span>{new Date(item.correctedAt).toLocaleString()}</span>
                    </div>
                    <div>
                      Changed from <strong className="text-rose-300">{item.fromStatus}</strong> to{' '}
                      <strong className="text-emerald-300">{item.toStatus}</strong>
                    </div>
                    <p className="text-slate-400 mt-0.5 italic">"{item.reason}"</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Footer actions */}
          <div className="pt-2 flex items-center justify-end gap-3 border-t border-white/10">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={isSubmitting}
              className="border-white/10 text-slate-300 hover:bg-white/5"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={isSubmitting || !reason.trim()}
              className="bg-indigo-600 hover:bg-indigo-500 text-white font-semibold flex items-center gap-2"
            >
              <CheckCircle2 className="w-4 h-4" />
              {isSubmitting ? 'Saving Correction...' : 'Save & Log Correction'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};
