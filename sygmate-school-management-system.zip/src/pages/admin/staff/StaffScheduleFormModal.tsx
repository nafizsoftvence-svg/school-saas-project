import React, { useState, useEffect } from 'react';
import {
  X,
  Clock,
  Calendar,
  Building,
  Briefcase,
  User,
  Shield,
  Layers,
  CheckCircle2,
  AlertTriangle,
  Sparkles
} from 'lucide-react';
import { Button } from '../../../components/ui/Button.js';
import {
  StaffWorkSchedule,
  StaffWorkScheduleScope,
  StaffScheduleDayConfig,
  StaffProfile,
  Department,
  Designation,
  CreateStaffSchedulePayload,
  UpdateStaffSchedulePayload
} from '../../../types/index.js';

interface StaffScheduleFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  scheduleToEdit: StaffWorkSchedule | null;
  staffList: StaffProfile[];
  departments: Department[];
  designations: Designation[];
  onSave: (payload: CreateStaffSchedulePayload | UpdateStaffSchedulePayload, scheduleId?: string) => Promise<void>;
}

const DEFAULT_DAYS: StaffScheduleDayConfig[] = [
  { dayOfWeek: 0, dayName: 'SUNDAY', isWorkingDay: false },
  { dayOfWeek: 1, dayName: 'MONDAY', isWorkingDay: true, startTime: '08:00', endTime: '16:00', breakStartTime: '12:00', breakEndTime: '13:00', breakMinutes: 60 },
  { dayOfWeek: 2, dayName: 'TUESDAY', isWorkingDay: true, startTime: '08:00', endTime: '16:00', breakStartTime: '12:00', breakEndTime: '13:00', breakMinutes: 60 },
  { dayOfWeek: 3, dayName: 'WEDNESDAY', isWorkingDay: true, startTime: '08:00', endTime: '16:00', breakStartTime: '12:00', breakEndTime: '13:00', breakMinutes: 60 },
  { dayOfWeek: 4, dayName: 'THURSDAY', isWorkingDay: true, startTime: '08:00', endTime: '16:00', breakStartTime: '12:00', breakEndTime: '13:00', breakMinutes: 60 },
  { dayOfWeek: 5, dayName: 'FRIDAY', isWorkingDay: true, startTime: '08:00', endTime: '16:00', breakStartTime: '12:00', breakEndTime: '13:00', breakMinutes: 60 },
  { dayOfWeek: 6, dayName: 'SATURDAY', isWorkingDay: false }
];

export const StaffScheduleFormModal: React.FC<StaffScheduleFormModalProps> = ({
  isOpen,
  onClose,
  scheduleToEdit,
  staffList,
  departments,
  designations,
  onSave
}) => {
  const [name, setName] = useState<string>('');
  const [scope, setScope] = useState<StaffWorkScheduleScope>('DEPARTMENT');
  const [staffId, setStaffId] = useState<string>('');
  const [departmentId, setDepartmentId] = useState<string>('');
  const [designationId, setDesignationId] = useState<string>('');
  const [staffType, setStaffType] = useState<string>('teaching');
  const [effectiveFrom, setEffectiveFrom] = useState<string>(() => new Date().toISOString().split('T')[0]);
  const [effectiveTo, setEffectiveTo] = useState<string>('');
  const [isActive, setIsActive] = useState<boolean>(true);
  const [notes, setNotes] = useState<string>('');
  const [days, setDays] = useState<StaffScheduleDayConfig[]>(DEFAULT_DAYS);

  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (scheduleToEdit) {
      setName(scheduleToEdit.name);
      setScope(scheduleToEdit.scope);
      setStaffId(scheduleToEdit.staffId || '');
      setDepartmentId(scheduleToEdit.departmentId || '');
      setDesignationId(scheduleToEdit.designationId || '');
      setStaffType(scheduleToEdit.staffType || 'teaching');
      setEffectiveFrom(scheduleToEdit.effectiveFrom);
      setEffectiveTo(scheduleToEdit.effectiveTo || '');
      setIsActive(scheduleToEdit.isActive);
      setNotes(scheduleToEdit.notes || '');
      setDays(scheduleToEdit.days && scheduleToEdit.days.length > 0 ? scheduleToEdit.days : DEFAULT_DAYS);
    } else {
      setName('');
      setScope('DEPARTMENT');
      setStaffId('');
      setDepartmentId(departments?.[0]?.id || '');
      setDesignationId(designations?.[0]?.id || '');
      setStaffType('teaching');
      setEffectiveFrom(new Date().toISOString().split('T')[0]);
      setEffectiveTo('');
      setIsActive(true);
      setNotes('');
      setDays(DEFAULT_DAYS);
    }
  }, [scheduleToEdit, departments, designations]);

  if (!isOpen) return null;

  const handleDayChange = (dayIdx: number, field: keyof StaffScheduleDayConfig, value: any) => {
    setDays((prev) => {
      const next = [...prev];
      next[dayIdx] = { ...next[dayIdx], [field]: value };
      return next;
    });
  };

  const applyPreset = (preset: 'standard' | 'academic' | 'security') => {
    if (preset === 'standard') {
      setDays([
        { dayOfWeek: 0, dayName: 'SUNDAY', isWorkingDay: false },
        { dayOfWeek: 1, dayName: 'MONDAY', isWorkingDay: true, startTime: '08:00', endTime: '16:00', breakStartTime: '12:00', breakEndTime: '13:00', breakMinutes: 60 },
        { dayOfWeek: 2, dayName: 'TUESDAY', isWorkingDay: true, startTime: '08:00', endTime: '16:00', breakStartTime: '12:00', breakEndTime: '13:00', breakMinutes: 60 },
        { dayOfWeek: 3, dayName: 'WEDNESDAY', isWorkingDay: true, startTime: '08:00', endTime: '16:00', breakStartTime: '12:00', breakEndTime: '13:00', breakMinutes: 60 },
        { dayOfWeek: 4, dayName: 'THURSDAY', isWorkingDay: true, startTime: '08:00', endTime: '16:00', breakStartTime: '12:00', breakEndTime: '13:00', breakMinutes: 60 },
        { dayOfWeek: 5, dayName: 'FRIDAY', isWorkingDay: true, startTime: '08:00', endTime: '16:00', breakStartTime: '12:00', breakEndTime: '13:00', breakMinutes: 60 },
        { dayOfWeek: 6, dayName: 'SATURDAY', isWorkingDay: false }
      ]);
    } else if (preset === 'academic') {
      setDays([
        { dayOfWeek: 0, dayName: 'SUNDAY', isWorkingDay: false },
        { dayOfWeek: 1, dayName: 'MONDAY', isWorkingDay: true, startTime: '07:30', endTime: '14:30', breakStartTime: '11:00', breakEndTime: '11:45', breakMinutes: 45 },
        { dayOfWeek: 2, dayName: 'TUESDAY', isWorkingDay: true, startTime: '07:30', endTime: '14:30', breakStartTime: '11:00', breakEndTime: '11:45', breakMinutes: 45 },
        { dayOfWeek: 3, dayName: 'WEDNESDAY', isWorkingDay: true, startTime: '07:30', endTime: '14:30', breakStartTime: '11:00', breakEndTime: '11:45', breakMinutes: 45 },
        { dayOfWeek: 4, dayName: 'THURSDAY', isWorkingDay: true, startTime: '07:30', endTime: '14:30', breakStartTime: '11:00', breakEndTime: '11:45', breakMinutes: 45 },
        { dayOfWeek: 5, dayName: 'FRIDAY', isWorkingDay: true, startTime: '07:30', endTime: '14:30', breakStartTime: '11:00', breakEndTime: '11:45', breakMinutes: 45 },
        { dayOfWeek: 6, dayName: 'SATURDAY', isWorkingDay: true, startTime: '08:00', endTime: '12:30', breakStartTime: '10:15', breakEndTime: '10:45', breakMinutes: 30 }
      ]);
    } else if (preset === 'security') {
      setDays([
        { dayOfWeek: 0, dayName: 'SUNDAY', isWorkingDay: true, startTime: '06:00', endTime: '18:00', breakStartTime: '12:00', breakEndTime: '13:00', breakMinutes: 60 },
        { dayOfWeek: 1, dayName: 'MONDAY', isWorkingDay: true, startTime: '06:00', endTime: '18:00', breakStartTime: '12:00', breakEndTime: '13:00', breakMinutes: 60 },
        { dayOfWeek: 2, dayName: 'TUESDAY', isWorkingDay: true, startTime: '06:00', endTime: '18:00', breakStartTime: '12:00', breakEndTime: '13:00', breakMinutes: 60 },
        { dayOfWeek: 3, dayName: 'WEDNESDAY', isWorkingDay: true, startTime: '06:00', endTime: '18:00', breakStartTime: '12:00', breakEndTime: '13:00', breakMinutes: 60 },
        { dayOfWeek: 4, dayName: 'THURSDAY', isWorkingDay: true, startTime: '06:00', endTime: '18:00', breakStartTime: '12:00', breakEndTime: '13:00', breakMinutes: 60 },
        { dayOfWeek: 5, dayName: 'FRIDAY', isWorkingDay: true, startTime: '06:00', endTime: '18:00', breakStartTime: '12:00', breakEndTime: '13:00', breakMinutes: 60 },
        { dayOfWeek: 6, dayName: 'SATURDAY', isWorkingDay: true, startTime: '06:00', endTime: '18:00', breakStartTime: '12:00', breakEndTime: '13:00', breakMinutes: 60 }
      ]);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Schedule name is required.');
      return;
    }

    if (scope === 'INDIVIDUAL' && !staffId) {
      setError('Please select the specific staff member for this individual schedule.');
      return;
    }
    if (scope === 'DEPARTMENT' && !departmentId) {
      setError('Please select the target department.');
      return;
    }
    if (scope === 'DESIGNATION' && !designationId) {
      setError('Please select the target designation.');
      return;
    }

    setIsSubmitting(true);
    setError(null);

    const payload: CreateStaffSchedulePayload = {
      name: name.trim(),
      scope,
      staffId: scope === 'INDIVIDUAL' ? staffId : undefined,
      departmentId: scope === 'DEPARTMENT' ? departmentId : undefined,
      designationId: scope === 'DESIGNATION' ? designationId : undefined,
      staffType: scope === 'STAFF_TYPE' ? staffType : undefined,
      effectiveFrom,
      effectiveTo: effectiveTo || undefined,
      isActive,
      notes: notes.trim() || undefined,
      days
    };

    try {
      await onSave(payload, scheduleToEdit?.id);
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to save work schedule.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div
      id="staff-schedule-form-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto"
    >
      <div className="relative w-full max-w-3xl bg-slate-900 border border-white/10 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-800/80 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white tracking-tight">
                {scheduleToEdit ? 'Edit Work Schedule' : 'Create New Work Schedule'}
              </h2>
              <p className="text-xs text-slate-400">
                Configure hierarchical duty hours, shifts, working days, and break intervals
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6 max-h-[80vh] overflow-y-auto pr-3">
          {error && (
            <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/20 flex items-start gap-3 text-rose-300 text-sm">
              <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {/* Basic Info */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Schedule Name <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Science Lab Staff Timings, Security Shift Alpha"
                className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 placeholder-slate-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Target Scope & Priority <span className="text-rose-400">*</span>
              </label>
              <select
                value={scope}
                onChange={(e) => setScope(e.target.value as StaffWorkScheduleScope)}
                disabled={scheduleToEdit?.scope === 'SCHOOL_DEFAULT'}
                className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="INDIVIDUAL">Individual Staff (Priority 1 - Highest)</option>
                <option value="DESIGNATION">Designation Level (Priority 2)</option>
                <option value="DEPARTMENT">Department Level (Priority 3)</option>
                <option value="STAFF_TYPE">Staff Type / Category (Priority 4)</option>
                <option value="SCHOOL_DEFAULT">School Default (Priority 5 - Lowest)</option>
              </select>
            </div>
          </div>

          {/* Scope Targeted Fields */}
          {scope === 'INDIVIDUAL' && (
            <div className="p-4 rounded-xl bg-slate-950/40 border border-indigo-500/20 space-y-2">
              <label className="block text-xs font-semibold text-indigo-300 uppercase tracking-wider flex items-center gap-1.5">
                <User className="w-3.5 h-3.5" />
                Select Staff Member <span className="text-rose-400">*</span>
              </label>
              <select
                value={staffId}
                onChange={(e) => setStaffId(e.target.value)}
                className="w-full px-3 py-2 bg-slate-900 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="">-- Choose Staff Member --</option>
                {staffList.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.displayName || `${s.firstName} ${s.lastName}`} ({s.employeeCode} - {s.departmentName || s.staffType})
                  </option>
                ))}
              </select>
            </div>
          )}

          {scope === 'DEPARTMENT' && (
            <div className="p-4 rounded-xl bg-slate-950/40 border border-indigo-500/20 space-y-2">
              <label className="block text-xs font-semibold text-indigo-300 uppercase tracking-wider flex items-center gap-1.5">
                <Building className="w-3.5 h-3.5" />
                Select Department <span className="text-rose-400">*</span>
              </label>
              <select
                value={departmentId}
                onChange={(e) => setDepartmentId(e.target.value)}
                className="w-full px-3 py-2 bg-slate-900 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="">-- Choose Department --</option>
                {departments.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.name} ({d.code})
                  </option>
                ))}
              </select>
            </div>
          )}

          {scope === 'DESIGNATION' && (
            <div className="p-4 rounded-xl bg-slate-950/40 border border-indigo-500/20 space-y-2">
              <label className="block text-xs font-semibold text-indigo-300 uppercase tracking-wider flex items-center gap-1.5">
                <Briefcase className="w-3.5 h-3.5" />
                Select Designation <span className="text-rose-400">*</span>
              </label>
              <select
                value={designationId}
                onChange={(e) => setDesignationId(e.target.value)}
                className="w-full px-3 py-2 bg-slate-900 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="">-- Choose Designation --</option>
                {designations.map((des) => (
                  <option key={des.id} value={des.id}>
                    {des.title} ({des.departmentName || 'General'})
                  </option>
                ))}
              </select>
            </div>
          )}

          {scope === 'STAFF_TYPE' && (
            <div className="p-4 rounded-xl bg-slate-950/40 border border-indigo-500/20 space-y-2">
              <label className="block text-xs font-semibold text-indigo-300 uppercase tracking-wider flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5" />
                Select Staff Category <span className="text-rose-400">*</span>
              </label>
              <select
                value={staffType}
                onChange={(e) => setStaffType(e.target.value)}
                className="w-full px-3 py-2 bg-slate-900 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="teaching">Teaching Faculty</option>
                <option value="administrative">Administrative Staff</option>
                <option value="support">Support Services</option>
                <option value="management">Executive & Management</option>
                <option value="operational">Operational & Facilities</option>
              </select>
            </div>
          )}

          {/* Presets Toolbar */}
          <div className="flex flex-wrap items-center justify-between gap-2 p-3 rounded-xl bg-slate-800/40 border border-white/5">
            <span className="text-xs text-slate-400 font-semibold flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              Quick Time Presets:
            </span>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => applyPreset('standard')}
                className="px-2.5 py-1 text-[11px] font-semibold rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-white/10"
              >
                Mon-Fri 8am-4pm
              </button>
              <button
                type="button"
                onClick={() => applyPreset('academic')}
                className="px-2.5 py-1 text-[11px] font-semibold rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-white/10"
              >
                Academic 6-Day
              </button>
              <button
                type="button"
                onClick={() => applyPreset('security')}
                className="px-2.5 py-1 text-[11px] font-semibold rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-white/10"
              >
                24/7 Security Shift
              </button>
            </div>
          </div>

          {/* 7-Day Matrix Table */}
          <div className="space-y-3">
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider">
              Working Days & Shift Timings
            </label>
            <div className="border border-white/10 rounded-xl overflow-hidden bg-slate-950/40">
              <div className="grid grid-cols-12 gap-2 px-4 py-2.5 bg-slate-800/60 text-[11px] font-bold text-slate-400 uppercase tracking-wider border-b border-white/10">
                <span className="col-span-3">Day of Week</span>
                <span className="col-span-2 text-center">Working?</span>
                <span className="col-span-2 text-center">Start Time</span>
                <span className="col-span-2 text-center">End Time</span>
                <span className="col-span-3 text-center">Break (Start / End / Mins)</span>
              </div>
              <div className="divide-y divide-white/5">
                {days.map((day, idx) => (
                  <div
                    key={day.dayOfWeek}
                    className={`grid grid-cols-12 gap-2 px-4 py-2.5 items-center text-xs ${
                      day.isWorkingDay ? 'bg-transparent' : 'bg-slate-900/30 opacity-60'
                    }`}
                  >
                    <span className="col-span-3 font-semibold text-slate-200">
                      {day.dayName}
                    </span>
                    <div className="col-span-2 flex justify-center">
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input
                          type="checkbox"
                          checked={day.isWorkingDay}
                          onChange={(e) => handleDayChange(idx, 'isWorkingDay', e.target.value === 'on' ? e.target.checked : false)}
                          className="sr-only peer"
                        />
                        <div className="w-8 h-4 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[1px] after:left-[2px] after:bg-white after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-emerald-600"></div>
                      </label>
                    </div>
                    <div className="col-span-2">
                      <input
                        type="time"
                        disabled={!day.isWorkingDay}
                        value={day.startTime || '08:00'}
                        onChange={(e) => handleDayChange(idx, 'startTime', e.target.value)}
                        className="w-full px-2 py-1 bg-slate-900 border border-white/10 rounded-lg text-white text-center disabled:opacity-30 disabled:cursor-not-allowed"
                      />
                    </div>
                    <div className="col-span-2">
                      <input
                        type="time"
                        disabled={!day.isWorkingDay}
                        value={day.endTime || '16:00'}
                        onChange={(e) => handleDayChange(idx, 'endTime', e.target.value)}
                        className="w-full px-2 py-1 bg-slate-900 border border-white/10 rounded-lg text-white text-center disabled:opacity-30 disabled:cursor-not-allowed"
                      />
                    </div>
                    <div className="col-span-3 flex items-center gap-1.5 justify-center">
                      <input
                        type="time"
                        disabled={!day.isWorkingDay}
                        value={day.breakStartTime || '12:00'}
                        onChange={(e) => handleDayChange(idx, 'breakStartTime', e.target.value)}
                        className="w-20 px-1.5 py-1 bg-slate-900 border border-white/10 rounded-lg text-white text-[11px] text-center disabled:opacity-30"
                      />
                      <span className="text-slate-500">-</span>
                      <input
                        type="time"
                        disabled={!day.isWorkingDay}
                        value={day.breakEndTime || '13:00'}
                        onChange={(e) => handleDayChange(idx, 'breakEndTime', e.target.value)}
                        className="w-20 px-1.5 py-1 bg-slate-900 border border-white/10 rounded-lg text-white text-[11px] text-center disabled:opacity-30"
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Dates & Active Status */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Effective From <span className="text-rose-400">*</span>
              </label>
              <input
                type="date"
                required
                value={effectiveFrom}
                onChange={(e) => setEffectiveFrom(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Effective To (Optional)
              </label>
              <input
                type="date"
                value={effectiveTo}
                onChange={(e) => setEffectiveTo(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Schedule Status
              </label>
              <div className="flex items-center gap-3 pt-2">
                <label className="inline-flex items-center gap-2 cursor-pointer text-sm text-slate-200">
                  <input
                    type="checkbox"
                    checked={isActive}
                    onChange={(e) => setIsActive(e.target.checked)}
                    className="rounded border-white/10 bg-slate-900 text-indigo-600 focus:ring-indigo-500"
                  />
                  <span>Active for Attendance Marking</span>
                </label>
              </div>
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              Internal Schedule Notes
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Standard shift aligned with national educational authority guidelines"
              className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 placeholder-slate-500"
            />
          </div>

          {/* Footer actions */}
          <div className="pt-4 flex items-center justify-end gap-3 border-t border-white/10">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={isSubmitting}
              className="border-white/10 text-slate-300 hover:bg-white/5"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={isSubmitting}
              className="bg-indigo-600 hover:bg-indigo-500 text-white font-semibold flex items-center gap-2"
            >
              <CheckCircle2 className="w-4 h-4" />
              {isSubmitting ? 'Saving Schedule...' : scheduleToEdit ? 'Update Schedule' : 'Create Schedule'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};
