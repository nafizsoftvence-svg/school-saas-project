import React, { useState } from 'react';
import {
  Briefcase,
  Plus,
  Edit2,
  Trash2,
  Users,
  Building,
  Award,
  AlertCircle,
  X
} from 'lucide-react';
import { Button } from '../../../components/ui/Button.js';
import { Designation, Department, StaffType } from '../../../types/index.js';

interface StaffDesignationsTabProps {
  designations: Designation[];
  departments: Department[];
  onCreateDesignation: (payload: any) => Promise<void>;
  onUpdateDesignation: (id: string, payload: any) => Promise<void>;
  onDeleteDesignation: (id: string) => Promise<void>;
  onSelectDesignationForFilter?: (desId: string) => void;
  isLoading?: boolean;
}

export const StaffDesignationsTab: React.FC<StaffDesignationsTabProps> = ({
  designations,
  departments,
  onCreateDesignation,
  onUpdateDesignation,
  onDeleteDesignation,
  onSelectDesignationForFilter,
  isLoading = false
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingDes, setEditingDes] = useState<Designation | null>(null);

  // Form states
  const [title, setTitle] = useState('');
  const [code, setCode] = useState('');
  const [departmentId, setDepartmentId] = useState('');
  const [staffType, setStaffType] = useState<StaffType>('teaching');
  const [level, setLevel] = useState<'junior' | 'mid' | 'senior' | 'lead' | 'executive'>('mid');
  const [description, setDescription] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const openCreateModal = () => {
    setEditingDes(null);
    setTitle('');
    setCode('');
    setDepartmentId('');
    setStaffType('teaching');
    setLevel('mid');
    setDescription('');
    setError(null);
    setIsModalOpen(true);
  };

  const openEditModal = (des: Designation) => {
    setEditingDes(des);
    setTitle(des.title);
    setCode(des.code);
    setDepartmentId(des.departmentId || '');
    setStaffType(des.staffType);
    setLevel((des.level as any) || 'mid');
    setDescription(des.description || '');
    setError(null);
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!title.trim()) {
      setError('Designation title is required.');
      return;
    }
    if (!code.trim()) {
      setError('Designation code is required.');
      return;
    }

    setIsSubmitting(true);
    try {
      if (editingDes) {
        await onUpdateDesignation(editingDes.id, {
          title: title.trim(),
          code: code.trim().toUpperCase(),
          departmentId: departmentId || undefined,
          staffType,
          level,
          description: description.trim() || undefined
        });
      } else {
        await onCreateDesignation({
          title: title.trim(),
          code: code.trim().toUpperCase(),
          departmentId: departmentId || undefined,
          staffType,
          level,
          description: description.trim() || undefined
        });
      }
      setIsModalOpen(false);
    } catch (err: any) {
      setError(err.message || 'Failed to save designation.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async (des: Designation) => {
    if ((des.staffCount || 0) > 0) {
      alert(`Cannot delete '${des.title}' because ${des.staffCount} staff member(s) hold this title.`);
      return;
    }

    if (window.confirm(`Are you sure you want to delete designation '${des.title}'?`)) {
      try {
        await onDeleteDesignation(des.id);
      } catch (err: any) {
        alert(err.message || 'Failed to delete designation.');
      }
    }
  };

  const getLevelBadge = (lvl?: string) => {
    switch (lvl) {
      case 'executive':
        return <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-100 text-amber-900 border border-amber-200">Executive</span>;
      case 'lead':
        return <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-indigo-100 text-indigo-900 border border-indigo-200">Lead / Principal</span>;
      case 'senior':
        return <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-purple-100 text-purple-900 border border-purple-200">Senior</span>;
      case 'junior':
        return <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-100 text-slate-700 border border-slate-200">Junior</span>;
      default:
        return <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-blue-50 text-blue-800 border border-blue-200">Mid-Level</span>;
    }
  };

  return (
    <div className="space-y-6" id="staff-designations-tab">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-xl border border-slate-200">
        <div>
          <h3 className="text-base font-bold text-slate-900 tracking-tight">
            Designations, Job Titles & Hierarchy
          </h3>
          <p className="text-xs text-slate-500 mt-1">
            Define official job positions, organizational hierarchy levels, and track employee staffing
          </p>
        </div>
        <Button
          type="button"
          variant="primary"
          size="sm"
          onClick={openCreateModal}
          icon={<Plus className="w-4 h-4" />}
          id="add-designation-btn"
        >
          Add Designation
        </Button>
      </div>

      {/* Designation Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {designations.map((des) => (
          <div
            key={des.id}
            className="bg-white rounded-xl border border-slate-200 p-5 hover:border-slate-300 transition-all flex flex-col justify-between"
            id={`des-card-${des.id}`}
          >
            <div>
              <div className="flex items-start justify-between gap-2">
                <div>
                  <span className="text-[10px] font-mono font-semibold text-slate-500 uppercase tracking-wider">
                    {des.code}
                  </span>
                  <h4 className="text-sm font-bold text-slate-900 mt-0.5">
                    {des.title}
                  </h4>
                </div>
                {getLevelBadge(des.level)}
              </div>

              <div className="flex items-center gap-2 mt-2">
                <span className="text-[11px] font-semibold px-2 py-0.5 rounded bg-slate-100 text-slate-700 capitalize">
                  {des.staffType}
                </span>
                {des.departmentName && (
                  <span className="text-[11px] text-slate-500 flex items-center gap-1 truncate">
                    <Building className="w-3 h-3 text-slate-400 shrink-0" />
                    {des.departmentName}
                  </span>
                )}
              </div>

              {des.description && (
                <p className="text-xs text-slate-600 mt-3 line-clamp-2">
                  {des.description}
                </p>
              )}
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <Users className="w-4 h-4 text-indigo-600" />
                <button
                  type="button"
                  onClick={() => onSelectDesignationForFilter && onSelectDesignationForFilter(des.id)}
                  className="text-xs font-bold text-indigo-700 hover:underline"
                >
                  {des.staffCount || 0} Staff Member{(des.staffCount || 0) !== 1 ? 's' : ''}
                </button>
              </div>

              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() => openEditModal(des)}
                  className="p-1.5 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 transition-colors"
                  title="Edit Designation"
                >
                  <Edit2 className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() => handleDelete(des)}
                  className="p-1.5 rounded-lg border border-red-200 text-red-600 hover:bg-red-50 transition-colors"
                  title="Delete Designation"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50/80">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-indigo-50 text-indigo-700 border border-indigo-200">
                  <Briefcase className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-semibold text-slate-900">
                    {editingDes ? `Edit Designation: ${editingDes.title}` : 'Add Official Designation'}
                  </h3>
                  <p className="text-xs text-slate-500">
                    Job Title & Hierarchy Registration
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              {error && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-lg flex items-start gap-2 text-xs text-red-700">
                  <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                  <span>{error}</span>
                </div>
              )}

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Designation Title <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="E.g., Senior Systems Administrator"
                  required
                  className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Designation Code <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={code}
                    onChange={(e) => setCode(e.target.value.toUpperCase())}
                    placeholder="E.g., DES-SYS-ADM"
                    required
                    className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Hierarchy Level <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={level}
                    onChange={(e) => setLevel(e.target.value as any)}
                    className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                  >
                    <option value="junior">Junior / Entry Level</option>
                    <option value="mid">Mid-Level Professional</option>
                    <option value="senior">Senior Specialist</option>
                    <option value="lead">Lead / Principal</option>
                    <option value="executive">Executive Management</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Associated Department
                  </label>
                  <select
                    value={departmentId}
                    onChange={(e) => setDepartmentId(e.target.value)}
                    className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                  >
                    <option value="">All / Cross-Departmental</option>
                    {departments.map((d) => (
                      <option key={d.id} value={d.id}>
                        {d.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Staff Classification <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={staffType}
                    onChange={(e) => setStaffType(e.target.value as StaffType)}
                    className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                  >
                    <option value="teaching">Teaching Faculty</option>
                    <option value="administrative">Administrative</option>
                    <option value="support">Campus Support</option>
                    <option value="management">Executive Management</option>
                    <option value="operational">Operational & Facilities</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Job Duties & Position Overview
                </label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  rows={2}
                  placeholder="Primary requirements and role description..."
                  className="w-full text-xs rounded-lg border border-slate-300 p-2.5 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 resize-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-200">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setIsModalOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  variant="primary"
                  size="sm"
                  isLoading={isSubmitting}
                >
                  {editingDes ? 'Update Designation' : 'Create Designation'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
