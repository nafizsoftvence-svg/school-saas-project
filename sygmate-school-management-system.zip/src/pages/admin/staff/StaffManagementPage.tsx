import React, { useState, useEffect, useCallback } from 'react';
import {
  Users,
  Building,
  Briefcase,
  PieChart,
  Plus,
  RefreshCw,
  FileSpreadsheet,
  AlertCircle,
  CheckCircle2,
  GraduationCap,
  CalendarCheck,
  Clock,
  UserPlus,
  Layers,
  Award
} from 'lucide-react';
import { Button } from '../../../components/ui/Button.js';
import { useAuth } from '../../../context/AuthContext.js';
import { api } from '../../../services/api.js';
import {
  StaffProfile,
  Department,
  Designation,
  StaffDocument,
  CreateStaffPayload,
  UpdateStaffPayload,
  EmploymentStatus,
  UploadStaffDocumentPayload,
  VerifyStaffDocumentPayload,
  UserRole
} from '../../../types/index.js';

import { StaffDirectoryTab } from './StaffDirectoryTab.js';
import { StaffDepartmentsTab } from './StaffDepartmentsTab.js';
import { StaffDesignationsTab } from './StaffDesignationsTab.js';
import { StaffAnalyticsTab } from './StaffAnalyticsTab.js';
import { StaffAttendanceTab } from './StaffAttendanceTab.js';
import { StaffWorkSchedulesTab } from './StaffWorkSchedulesTab.js';
import { StaffLeavesTab } from './StaffLeavesTab.js';
import { StaffRecruitmentTab } from './recruitment/StaffRecruitmentTab.js';
import { StaffOnboardingTab } from './onboarding/StaffOnboardingTab.js';
import { StaffPerformanceTab } from './performance/StaffPerformanceTab.js';
import { StaffFormModal } from './StaffFormModal.js';
import { StaffProfileModal } from './StaffProfileModal.js';
import { StaffStatusChangeModal } from './StaffStatusChangeModal.js';
import { StaffDocumentsModal } from './StaffDocumentsModal.js';
import { StaffAccountModal } from './StaffAccountModal.js';

interface StaffManagementPageProps {
  initialTab?: 'directory' | 'recruitment' | 'onboarding' | 'attendance' | 'schedules' | 'leaves' | 'performance' | 'departments' | 'designations' | 'analytics';
  activeTab?: 'directory' | 'recruitment' | 'onboarding' | 'attendance' | 'schedules' | 'leaves' | 'performance' | 'departments' | 'designations' | 'analytics';
  onTabChange?: (tab: 'directory' | 'recruitment' | 'onboarding' | 'attendance' | 'schedules' | 'leaves' | 'performance' | 'departments' | 'designations' | 'analytics') => void;
  hideTabBar?: boolean;
}

export const StaffManagementPage: React.FC<StaffManagementPageProps> = ({
  initialTab = 'directory',
  activeTab: propActiveTab,
  onTabChange,
  hideTabBar = true
}) => {
  const { user } = useAuth();
  const [internalTab, setInternalTab] = useState<'directory' | 'recruitment' | 'onboarding' | 'attendance' | 'schedules' | 'leaves' | 'performance' | 'departments' | 'designations' | 'analytics'>(initialTab);
  const activeTab = propActiveTab || internalTab;

  const setActiveTab = (tab: 'directory' | 'recruitment' | 'onboarding' | 'attendance' | 'schedules' | 'leaves' | 'performance' | 'departments' | 'designations' | 'analytics') => {
    setInternalTab(tab);
    onTabChange?.(tab);
  };

  useEffect(() => {
    if (initialTab) {
      setInternalTab(initialTab);
    }
  }, [initialTab]);

  // Directory Data
  const [staffList, setStaffList] = useState<StaffProfile[]>([]);
  const [totalStaffCount, setTotalStaffCount] = useState<number>(0);
  const [departments, setDepartments] = useState<Array<Department & { staffCount: number; teachingCount: number; nonTeachingCount: number }>>([]);
  const [designations, setDesignations] = useState<Designation[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Filters & Pagination
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedStaffType, setSelectedStaffType] = useState<string>('');
  const [selectedDepartmentId, setSelectedDepartmentId] = useState<string>('');
  const [selectedStatus, setSelectedStatus] = useState<string>('');
  const [selectedEmploymentType, setSelectedEmploymentType] = useState<string>('');
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(10);

  // Modals
  const [isFormModalOpen, setIsFormModalOpen] = useState<boolean>(false);
  const [staffToEdit, setStaffToEdit] = useState<StaffProfile | null>(null);

  const [isProfileModalOpen, setIsProfileModalOpen] = useState<boolean>(false);
  const [selectedStaffForProfile, setSelectedStaffForProfile] = useState<(StaffProfile & { teacherDetails?: any }) | null>(null);

  const [isStatusModalOpen, setIsStatusModalOpen] = useState<boolean>(false);
  const [selectedStaffForStatus, setSelectedStaffForStatus] = useState<StaffProfile | null>(null);

  const [isDocumentsModalOpen, setIsDocumentsModalOpen] = useState<boolean>(false);
  const [selectedStaffForDocs, setSelectedStaffForDocs] = useState<StaffProfile | null>(null);
  const [staffDocuments, setStaffDocuments] = useState<StaffDocument[]>([]);

  const [isAccountModalOpen, setIsAccountModalOpen] = useState<boolean>(false);
  const [selectedStaffForAccount, setSelectedStaffForAccount] = useState<StaffProfile | null>(null);

  const [nextCode, setNextCode] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Load staff list & supporting catalogs
  const fetchData = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const [staffRes, deptsRes, desRes] = await Promise.all([
        api.staff.getDirectory({
          page: currentPage,
          limit: pageSize,
          search: searchTerm || undefined,
          staffType: selectedStaffType || undefined,
          departmentId: selectedDepartmentId || undefined,
          employmentStatus: selectedStatus || undefined,
          employmentType: selectedEmploymentType || undefined
        }),
        api.staff.getDepartmentsWithCounts(),
        api.staff.getDesignations()
      ]);

      const staffRecords: StaffProfile[] = Array.isArray(staffRes?.data) ? staffRes.data : [];
      const totalCount: number = typeof staffRes?.meta?.total === 'number' ? staffRes.meta.total : staffRecords.length;
      setStaffList(staffRecords);
      setTotalStaffCount(totalCount);
      const deptsData = Array.isArray((deptsRes as any)?.data) ? (deptsRes as any).data : Array.isArray(deptsRes) ? deptsRes : [];
      const desData = Array.isArray((desRes as any)?.data) ? (desRes as any).data : Array.isArray(desRes) ? desRes : [];
      setDepartments(deptsData);
      setDesignations(desData);
    } catch (err: any) {
      console.error('Failed to load staff management data:', err);
      setError(err.message || 'Failed to retrieve staff directory records.');
    } finally {
      setIsLoading(false);
    }
  }, [currentPage, pageSize, searchTerm, selectedStaffType, selectedDepartmentId, selectedStatus, selectedEmploymentType]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  // Auto-dismiss success message
  useEffect(() => {
    if (successMessage) {
      const timer = setTimeout(() => setSuccessMessage(null), 4000);
      return () => clearTimeout(timer);
    }
  }, [successMessage]);

  // Handle open add staff
  const handleOpenAddStaff = async () => {
    setStaffToEdit(null);
    try {
      const code = await api.staff.getNextEmployeeCode('teaching');
      setNextCode(code);
    } catch {
      setNextCode('EMP-1001');
    }
    setIsFormModalOpen(true);
  };

  // Handle open edit staff
  const handleOpenEditStaff = (staff: StaffProfile) => {
    setStaffToEdit(staff);
    setIsFormModalOpen(true);
  };

  // Submit create or edit staff
  const handleSaveStaff = async (payload: CreateStaffPayload | UpdateStaffPayload) => {
    setIsSubmitting(true);
    try {
      if (staffToEdit) {
        await api.staff.updateStaffProfile(staffToEdit.id, payload as UpdateStaffPayload);
        setSuccessMessage(`Staff member '${staffToEdit.displayName}' updated successfully.`);
      } else {
        await api.staff.createStaffProfile(payload as CreateStaffPayload);
        setSuccessMessage('New staff member onboarded successfully.');
      }
      setIsFormModalOpen(false);
      fetchData();
    } catch (err: any) {
      throw new Error(err.message || 'Failed to save staff profile.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // View Dossier
  const handleViewDossier = async (staff: StaffProfile) => {
    try {
      const fullProfile = await api.staff.getStaffProfile(staff.id);
      setSelectedStaffForProfile(fullProfile);
      setIsProfileModalOpen(true);
    } catch (err: any) {
      setError(err.message || 'Failed to fetch staff dossier details.');
    }
  };

  // Change Status
  const handleOpenStatusModal = (staff: StaffProfile) => {
    setSelectedStaffForStatus(staff);
    setIsStatusModalOpen(true);
  };

  const handleStatusTransition = async (payload: {
    newStatus: EmploymentStatus;
    reason: string;
    effectiveDate: string;
    notes?: string;
    deactivateAccount?: boolean;
  }) => {
    if (!selectedStaffForStatus) return;
    setIsSubmitting(true);
    try {
      await api.staff.changeEmploymentStatus(selectedStaffForStatus.id, payload);
      setSuccessMessage(`Employment status for ${selectedStaffForStatus.displayName} updated to ${payload.newStatus}.`);
      setIsStatusModalOpen(false);
      fetchData();
      if (isProfileModalOpen && selectedStaffForProfile?.id === selectedStaffForStatus.id) {
        handleViewDossier(selectedStaffForStatus);
      }
    } catch (err: any) {
      throw new Error(err.message || 'Failed to update employment status.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Documents modal
  const handleOpenDocumentsModal = async (staff: StaffProfile) => {
    setSelectedStaffForDocs(staff);
    try {
      const docs = await api.staff.getStaffDocuments(staff.id);
      setStaffDocuments(docs || []);
      setIsDocumentsModalOpen(true);
    } catch (err: any) {
      setError(err.message || 'Failed to load staff documents.');
    }
  };

  const handleUploadDocument = async (payload: UploadStaffDocumentPayload) => {
    if (!selectedStaffForDocs) return;
    setIsSubmitting(true);
    try {
      await api.staff.uploadStaffDocument(selectedStaffForDocs.id, payload);
      const docs = await api.staff.getStaffDocuments(selectedStaffForDocs.id);
      setStaffDocuments(docs || []);
      setSuccessMessage('Document attached and registered successfully.');
      fetchData();
    } catch (err: any) {
      throw new Error(err.message || 'Failed to upload document.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteDocument = async (docId: string) => {
    if (!selectedStaffForDocs) return;
    try {
      await api.staff.deleteStaffDocument(selectedStaffForDocs.id, docId);
      setStaffDocuments((prev) => prev.filter((d) => d.id !== docId));
      setSuccessMessage('Document deleted successfully.');
      fetchData();
    } catch (err: any) {
      throw new Error(err.message || 'Failed to delete document.');
    }
  };

  const handleVerifyDocument = async (docId: string, payload: VerifyStaffDocumentPayload) => {
    if (!selectedStaffForDocs) return;
    try {
      await api.staff.verifyStaffDocument(selectedStaffForDocs.id, docId, payload);
      const docs = await api.staff.getStaffDocuments(selectedStaffForDocs.id);
      setStaffDocuments(docs || []);
      setSuccessMessage(`Document verification status updated to ${payload.verificationStatus}.`);
    } catch (err: any) {
      throw new Error(err.message || 'Failed to verify document.');
    }
  };

  // Account Modal
  const handleOpenAccountModal = (staff: StaffProfile) => {
    setSelectedStaffForAccount(staff);
    setIsAccountModalOpen(true);
  };

  const handleLinkAccount = async (payload: { userId?: string; username?: string; password?: string; role?: UserRole }) => {
    if (!selectedStaffForAccount) return;
    setIsSubmitting(true);
    try {
      await api.staff.linkUserAccount(selectedStaffForAccount.id, payload);
      setSuccessMessage(`System account successfully linked to ${selectedStaffForAccount.displayName}.`);
      fetchData();
    } catch (err: any) {
      throw new Error(err.message || 'Failed to link system account.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleUnlinkAccount = async () => {
    if (!selectedStaffForAccount) return;
    setIsSubmitting(true);
    try {
      await api.staff.unlinkUserAccount(selectedStaffForAccount.id);
      setSuccessMessage(`System account unlinked from ${selectedStaffForAccount.displayName}.`);
      fetchData();
    } catch (err: any) {
      throw new Error(err.message || 'Failed to unlink user account.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Departments CRUD
  const handleCreateDepartment = async (payload: Partial<Department>) => {
    try {
      await api.departments.create(payload as any);
      setSuccessMessage(`Department '${payload.name}' created successfully.`);
      fetchData();
    } catch (err: any) {
      throw new Error(err.message || 'Failed to create department.');
    }
  };

  const handleUpdateDepartment = async (id: string, payload: Partial<Department>) => {
    try {
      await api.departments.update(id, payload as any);
      setSuccessMessage(`Department updated successfully.`);
      fetchData();
    } catch (err: any) {
      throw new Error(err.message || 'Failed to update department.');
    }
  };

  const handleDeleteDepartment = async (id: string) => {
    try {
      await api.departments.delete(id);
      setSuccessMessage('Department deleted successfully.');
      fetchData();
    } catch (err: any) {
      throw new Error(err.message || 'Failed to delete department.');
    }
  };

  // Designations CRUD
  const handleCreateDesignation = async (payload: any) => {
    try {
      await api.staff.createDesignation(payload);
      setSuccessMessage(`Designation '${payload.title}' created successfully.`);
      fetchData();
    } catch (err: any) {
      throw new Error(err.message || 'Failed to create designation.');
    }
  };

  const handleUpdateDesignation = async (id: string, payload: any) => {
    try {
      await api.staff.updateDesignation(id, payload);
      setSuccessMessage(`Designation updated successfully.`);
      fetchData();
    } catch (err: any) {
      throw new Error(err.message || 'Failed to update designation.');
    }
  };

  const handleDeleteDesignation = async (id: string) => {
    try {
      await api.staff.deleteDesignation(id);
      setSuccessMessage('Designation removed successfully.');
      fetchData();
    } catch (err: any) {
      throw new Error(err.message || 'Failed to delete designation.');
    }
  };

  // Export CSV
  const handleExportCsv = () => {
    const headers = [
      'Employee Code',
      'Display Name',
      'Staff Classification',
      'Department',
      'Designation',
      'Email',
      'Phone',
      'Status',
      'Terms',
      'Joining Date',
      'Username',
      'Role'
    ];

    const rows = staffList.map((s) => [
      s.employeeCode,
      `"${s.displayName}"`,
      s.staffType,
      `"${s.departmentName}"`,
      `"${s.designation}"`,
      s.email,
      s.phone,
      s.employmentStatus,
      s.employmentType,
      s.joiningDate,
      s.username || '',
      s.accountRole || ''
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Sygmate_Staff_Directory_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleResetFilters = () => {
    setSearchTerm('');
    setSelectedStaffType('');
    setSelectedDepartmentId('');
    setSelectedStatus('');
    setSelectedEmploymentType('');
    setCurrentPage(1);
  };

  return (
    <div className="space-y-6 pb-12" id="staff-management-container">
      {/* Top Banner & Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-xl border border-slate-200">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-indigo-700 uppercase tracking-wider mb-1">
            <Users className="w-4 h-4" />
            <span>Institutional Operations & Human Capital</span>
          </div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">
            Staff & Human Resource Management
          </h1>
          <p className="text-xs text-slate-500 mt-1 max-w-2xl">
            Centralized registry for teaching faculty, administrative, support, management, and operational workforce. Manages verified credentials, contract terms, departments, and status governance.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={fetchData}
            icon={<RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />}
            id="refresh-staff-btn"
          >
            Refresh Data
          </Button>

          <Button
            type="button"
            variant="primary"
            size="sm"
            onClick={handleOpenAddStaff}
            icon={<Plus className="w-3.5 h-3.5" />}
            id="top-onboard-staff-btn"
          >
            Onboard New Staff
          </Button>
        </div>
      </div>

      {/* Success / Error Alerts */}
      {successMessage && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between text-xs text-emerald-800 animate-in fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span className="font-medium">{successMessage}</span>
          </div>
          <button
            type="button"
            onClick={() => setSuccessMessage(null)}
            className="text-emerald-600 hover:text-emerald-800 font-bold ml-4"
          >
            &times;
          </button>
        </div>
      )}

      {error && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-xl flex items-center justify-between text-xs text-red-800 animate-in fade-in">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
            <span>{error}</span>
          </div>
          <button
            type="button"
            onClick={() => setError(null)}
            className="text-red-600 hover:text-red-800 font-bold ml-4"
          >
            &times;
          </button>
        </div>
      )}

      {/* Navigation Tabs (Hidden when subtabs are hosted in sidebar) */}
      {!hideTabBar && (
        <div className="flex border-b border-slate-200 bg-white rounded-t-xl px-4 gap-2 overflow-x-auto shadow-2xs">
          <button
            type="button"
            onClick={() => setActiveTab('directory')}
            className={`py-3.5 px-4 text-xs font-bold border-b-2 flex items-center gap-2 transition-colors whitespace-nowrap ${
              activeTab === 'directory'
                ? 'border-indigo-600 text-indigo-700'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
            id="tab-btn-directory"
          >
            <Users className="w-4 h-4" />
            <span>Staff Directory ({totalStaffCount})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('recruitment')}
            className={`py-3.5 px-4 text-xs font-bold border-b-2 flex items-center gap-2 transition-colors whitespace-nowrap ${
              activeTab === 'recruitment'
                ? 'border-indigo-600 text-indigo-700'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
            id="tab-btn-recruitment"
          >
            <UserPlus className="w-4 h-4" />
            <span>Recruitment & Hiring</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('onboarding')}
            className={`py-3.5 px-4 text-xs font-bold border-b-2 flex items-center gap-2 transition-colors whitespace-nowrap ${
              activeTab === 'onboarding'
                ? 'border-indigo-600 text-indigo-700'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
            id="tab-btn-onboarding"
          >
            <Layers className="w-4 h-4" />
            <span>Staff Onboarding</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('attendance')}
            className={`py-3.5 px-4 text-xs font-bold border-b-2 flex items-center gap-2 transition-colors whitespace-nowrap ${
              activeTab === 'attendance'
                ? 'border-indigo-600 text-indigo-700'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
            id="tab-btn-attendance"
          >
            <CalendarCheck className="w-4 h-4" />
            <span>Staff Attendance</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('schedules')}
            className={`py-3.5 px-4 text-xs font-bold border-b-2 flex items-center gap-2 transition-colors whitespace-nowrap ${
              activeTab === 'schedules'
                ? 'border-indigo-600 text-indigo-700'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
            id="tab-btn-schedules"
          >
            <Clock className="w-4 h-4" />
            <span>Work Schedules</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('leaves')}
            className={`py-3.5 px-4 text-xs font-bold border-b-2 flex items-center gap-2 transition-colors whitespace-nowrap ${
              activeTab === 'leaves'
                ? 'border-indigo-600 text-indigo-700'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
            id="tab-btn-leaves"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Staff Leaves</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('performance')}
            className={`py-3.5 px-4 text-xs font-bold border-b-2 flex items-center gap-2 transition-colors whitespace-nowrap ${
              activeTab === 'performance'
                ? 'border-indigo-600 text-indigo-700'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
            id="tab-btn-performance"
          >
            <Award className="w-4 h-4" />
            <span>Performance & Appraisals</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('departments')}
            className={`py-3.5 px-4 text-xs font-bold border-b-2 flex items-center gap-2 transition-colors whitespace-nowrap ${
              activeTab === 'departments'
                ? 'border-indigo-600 text-indigo-700'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
            id="tab-btn-departments"
          >
            <Building className="w-4 h-4" />
            <span>Departments & Units ({departments?.length || 0})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('designations')}
            className={`py-3.5 px-4 text-xs font-bold border-b-2 flex items-center gap-2 transition-colors whitespace-nowrap ${
              activeTab === 'designations'
                ? 'border-indigo-600 text-indigo-700'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
            id="tab-btn-designations"
          >
            <Briefcase className="w-4 h-4" />
            <span>Job Titles & Designations ({designations.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('analytics')}
            className={`py-3.5 px-4 text-xs font-bold border-b-2 flex items-center gap-2 transition-colors whitespace-nowrap ${
              activeTab === 'analytics'
                ? 'border-indigo-600 text-indigo-700'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
            id="tab-btn-analytics"
          >
            <PieChart className="w-4 h-4" />
            <span>HR Demographics & Analytics</span>
          </button>
        </div>
      )}

      {/* Tab Panels */}
      {activeTab === 'directory' && (
        <StaffDirectoryTab
          staffList={staffList}
          departments={departments}
          designations={designations}
          totalStaffCount={totalStaffCount}
          currentPage={currentPage}
          pageSize={pageSize}
          onPageChange={(p) => setCurrentPage(p)}
          onPageSizeChange={(s) => {
            setPageSize(s);
            setCurrentPage(1);
          }}
          searchTerm={searchTerm}
          onSearchChange={(s) => {
            setSearchTerm(s);
            setCurrentPage(1);
          }}
          selectedStaffType={selectedStaffType}
          onStaffTypeChange={(t) => {
            setSelectedStaffType(t);
            setCurrentPage(1);
          }}
          selectedDepartmentId={selectedDepartmentId}
          onDepartmentChange={(d) => {
            setSelectedDepartmentId(d);
            setCurrentPage(1);
          }}
          selectedStatus={selectedStatus}
          onStatusChange={(st) => {
            setSelectedStatus(st);
            setCurrentPage(1);
          }}
          selectedEmploymentType={selectedEmploymentType}
          onEmploymentTypeChange={(et) => {
            setSelectedEmploymentType(et);
            setCurrentPage(1);
          }}
          onResetFilters={handleResetFilters}
          onExportCsv={handleExportCsv}
          onAddStaff={handleOpenAddStaff}
          onViewDossier={handleViewDossier}
          onEditStaff={handleOpenEditStaff}
          onChangeStatus={handleOpenStatusModal}
          onManageDocuments={handleOpenDocumentsModal}
          onManageAccount={handleOpenAccountModal}
          isLoading={isLoading}
        />
      )}

      {activeTab === 'recruitment' && (
        <StaffRecruitmentTab
          departments={departments}
          designations={designations}
          onRefreshStaff={fetchData}
        />
      )}

      {activeTab === 'onboarding' && (
        <StaffOnboardingTab
          departments={departments}
          onRefreshStaff={fetchData}
        />
      )}

      {activeTab === 'attendance' && (
        <StaffAttendanceTab departments={departments} />
      )}

      {activeTab === 'schedules' && (
        <StaffWorkSchedulesTab
          staffList={staffList}
          departments={departments}
          designations={designations}
        />
      )}

      {activeTab === 'leaves' && (
        <StaffLeavesTab
          staffList={staffList}
          departments={departments}
          designations={designations}
        />
      )}

      {activeTab === 'performance' && (
        <StaffPerformanceTab
          departments={departments}
          designations={designations}
          currentUser={user || undefined}
        />
      )}

      {activeTab === 'departments' && (
        <StaffDepartmentsTab
          departments={departments}
          onCreateDepartment={handleCreateDepartment}
          onUpdateDepartment={handleUpdateDepartment}
          onDeleteDepartment={handleDeleteDepartment}
          onSelectDepartmentForFilter={(deptId) => {
            setSelectedDepartmentId(deptId);
            setActiveTab('directory');
          }}
          isLoading={isLoading}
        />
      )}

      {activeTab === 'designations' && (
        <StaffDesignationsTab
          designations={designations}
          departments={departments}
          onCreateDesignation={handleCreateDesignation}
          onUpdateDesignation={handleUpdateDesignation}
          onDeleteDesignation={handleDeleteDesignation}
          onSelectDesignationForFilter={(desId) => {
            const des = (designations || []).find((d) => d?.id === desId);
            if (des?.departmentId) {
              setSelectedDepartmentId(des.departmentId);
            }
            setActiveTab('directory');
          }}
          isLoading={isLoading}
        />
      )}

      {activeTab === 'analytics' && (
        <StaffAnalyticsTab
          staffList={staffList}
          departments={departments}
          designations={designations}
        />
      )}

      {/* MODALS */}
      {/* 1. Onboarding / Edit Staff Form Modal */}
      <StaffFormModal
        isOpen={isFormModalOpen}
        onClose={() => setIsFormModalOpen(false)}
        staffToEdit={staffToEdit}
        departments={departments}
        designations={designations}
        nextEmployeeCode={nextCode}
        onFetchNextCode={async (type) => {
          return await api.staff.getNextEmployeeCode(type);
        }}
        onSubmit={handleSaveStaff}
        isSubmitting={isSubmitting}
      />

      {/* 2. 360-Degree Staff Profile Dossier Modal */}
      <StaffProfileModal
        staff={selectedStaffForProfile}
        isOpen={isProfileModalOpen}
        onClose={() => setIsProfileModalOpen(false)}
        onEdit={(st) => {
          setIsProfileModalOpen(false);
          handleOpenEditStaff(st);
        }}
        onChangeStatus={(st) => {
          handleOpenStatusModal(st);
        }}
        onManageDocuments={(st) => {
          handleOpenDocumentsModal(st);
        }}
        onManageAccount={(st) => {
          handleOpenAccountModal(st);
        }}
      />

      {/* 3. Status Transition Governance Modal */}
      {selectedStaffForStatus && (
        <StaffStatusChangeModal
          staff={selectedStaffForStatus}
          isOpen={isStatusModalOpen}
          onClose={() => setIsStatusModalOpen(false)}
          onSubmit={handleStatusTransition}
          isSubmitting={isSubmitting}
        />
      )}

      {/* 4. Credentials & Documents Dossier Modal */}
      {selectedStaffForDocs && (
        <StaffDocumentsModal
          staff={selectedStaffForDocs}
          isOpen={isDocumentsModalOpen}
          onClose={() => setIsDocumentsModalOpen(false)}
          documents={staffDocuments}
          onUploadDocument={handleUploadDocument}
          onDeleteDocument={handleDeleteDocument}
          onVerifyDocument={handleVerifyDocument}
          isProcessing={isSubmitting}
        />
      )}

      {/* 5. System Login & Authentication Modal */}
      {selectedStaffForAccount && (
        <StaffAccountModal
          staff={selectedStaffForAccount}
          isOpen={isAccountModalOpen}
          onClose={() => setIsAccountModalOpen(false)}
          onLinkAccount={handleLinkAccount}
          onUnlinkAccount={handleUnlinkAccount}
          isProcessing={isSubmitting}
        />
      )}
    </div>
  );
};
