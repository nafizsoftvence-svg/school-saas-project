import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  Calendar,
  CalendarDays,
  Search,
  Filter,
  CheckCircle2,
  XCircle,
  Clock,
  AlertCircle,
  Save,
  RotateCcw,
  RefreshCw,
  Edit3,
  ChevronRight,
  ChevronLeft,
  Users,
  Building,
  GraduationCap,
  TrendingUp,
  Download,
  History,
  ShieldCheck,
  AlertTriangle,
  FileSpreadsheet,
  Check,
  Eye,
  Info
} from 'lucide-react';
import { Button } from '../../../components/ui/Button.js';
import { api } from '../../../services/api.js';
import { useAuth } from '../../../context/AuthContext.js';
import { useSettings } from '../../../context/SettingsContext.js';
import {
  StaffDailyAttendanceResponse,
  StaffDailyRosterItem,
  StaffMonthlyAttendanceResponse,
  StaffAttendanceStatus,
  StaffAttendanceRecord,
  Department,
  CorrectStaffAttendancePayload
} from '../../../types/index.js';
import { StaffAttendanceCorrectionModal } from './StaffAttendanceCorrectionModal.js';

interface StaffAttendanceTabProps {
  departments: Department[];
}

export const StaffAttendanceTab: React.FC<StaffAttendanceTabProps> = ({ departments }) => {
  const { user } = useAuth();
  const { settings, activeSession } = useSettings();

  // Mode: 'daily' | 'monthly'
  const [viewMode, setViewMode] = useState<'daily' | 'monthly'>('daily');

  // Daily Date State
  const [selectedDate, setSelectedDate] = useState<string>(() => {
    return new Date().toISOString().split('T')[0];
  });
  const [dailyData, setDailyData] = useState<StaffDailyAttendanceResponse | null>(null);
  const [dailyLoading, setDailyLoading] = useState<boolean>(false);
  const [dailyError, setDailyError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Daily Filters
  const [dailySearch, setDailySearch] = useState<string>('');
  const [dailyDepartmentId, setDailyDepartmentId] = useState<string>('ALL');
  const [dailyStaffType, setDailyStaffType] = useState<string>('ALL');
  const [dailyStatusFilter, setDailyStatusFilter] = useState<string>('ALL');

  // Draft changes state for daily roster
  const [draftRoster, setDraftRoster] = useState<
    Record<
      string,
      {
        status: StaffAttendanceStatus;
        checkInTime: string;
        checkOutTime: string;
        remarks: string;
        isDirty: boolean;
      }
    >
  >({});
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [allowOverride, setAllowOverride] = useState<boolean>(false);
  const [overrideReason, setOverrideReason] = useState<string>('');

  // Correction Modal State
  const [selectedRecordForCorrection, setSelectedRecordForCorrection] = useState<StaffAttendanceRecord | null>(null);
  const [isCorrectionModalOpen, setIsCorrectionModalOpen] = useState<boolean>(false);

  // Monthly Matrix State
  const [monthlyYear, setMonthlyYear] = useState<number>(() => new Date().getFullYear());
  const [monthlyMonth, setMonthlyMonth] = useState<number>(() => new Date().getMonth() + 1);
  const [monthlyDepartmentId, setMonthlyDepartmentId] = useState<string>('ALL');
  const [monthlyStaffType, setMonthlyStaffType] = useState<string>('ALL');
  const [monthlySearch, setMonthlySearch] = useState<string>('');
  const [monthlyData, setMonthlyData] = useState<StaffMonthlyAttendanceResponse | null>(null);
  const [monthlyLoading, setMonthlyLoading] = useState<boolean>(false);

  // Auto-dismiss success notification
  useEffect(() => {
    if (successMessage) {
      const timer = setTimeout(() => setSuccessMessage(null), 4000);
      return () => clearTimeout(timer);
    }
  }, [successMessage]);

  // Fetch Daily Roster
  const fetchDailyRoster = useCallback(async () => {
    setDailyLoading(true);
    setDailyError(null);
    try {
      const res = await api.staff.attendance.getDaily(selectedDate, {
        departmentId: dailyDepartmentId !== 'ALL' ? dailyDepartmentId : undefined,
        staffType: dailyStaffType !== 'ALL' ? dailyStaffType : undefined,
        status: dailyStatusFilter !== 'ALL' ? dailyStatusFilter : undefined,
        search: dailySearch || undefined
      });
      const dailyResult = (res as any)?.data || res;
      setDailyData(dailyResult);

      // Initialize draft roster with fetched values
      const initialDraft: typeof draftRoster = {};
      ((dailyResult?.roster) || []).forEach((item: any) => {
        initialDraft[item.staffId] = {
          status: item.status || 'PRESENT',
          checkInTime: item.checkInTime || item.effectiveSchedule?.startTime || '08:00',
          checkOutTime: item.checkOutTime || item.effectiveSchedule?.endTime || '16:00',
          remarks: item.remarks || '',
          isDirty: false
        };
      });
      setDraftRoster(initialDraft);
    } catch (err: any) {
      console.error('Failed to load daily staff attendance:', err);
      setDailyError(err.message || 'Failed to load staff attendance roster.');
    } finally {
      setDailyLoading(false);
    }
  }, [selectedDate, dailyDepartmentId, dailyStaffType, dailyStatusFilter, dailySearch]);

  // Fetch Monthly Matrix
  const fetchMonthlyMatrix = useCallback(async () => {
    setMonthlyLoading(true);
    try {
      const res = await api.staff.attendance.getMonthly(monthlyYear, monthlyMonth, {
        departmentId: monthlyDepartmentId !== 'ALL' ? monthlyDepartmentId : undefined,
        staffType: monthlyStaffType !== 'ALL' ? monthlyStaffType : undefined,
        search: monthlySearch || undefined
      });
      const monthlyResult = (res as any)?.data || res;
      setMonthlyData(monthlyResult);
    } catch (err: any) {
      console.error('Failed to load monthly staff attendance:', err);
    } finally {
      setMonthlyLoading(false);
    }
  }, [monthlyYear, monthlyMonth, monthlyDepartmentId, monthlyStaffType, monthlySearch]);

  useEffect(() => {
    if (viewMode === 'daily') {
      fetchDailyRoster();
    } else {
      fetchMonthlyMatrix();
    }
  }, [viewMode, fetchDailyRoster, fetchMonthlyMatrix]);

  // Date Navigation Helpers
  const shiftDate = (daysDelta: number) => {
    const [y, m, d] = selectedDate.split('-').map(Number);
    const dateObj = new Date(y, m - 1, d);
    dateObj.setDate(dateObj.getDate() + daysDelta);
    const newY = dateObj.getFullYear();
    const newM = String(dateObj.getMonth() + 1).padStart(2, '0');
    const newD = String(dateObj.getDate()).padStart(2, '0');
    setSelectedDate(`${newY}-${newM}-${newD}`);
  };

  const jumpToToday = () => {
    setSelectedDate(new Date().toISOString().split('T')[0]);
  };

  // Draft update helpers
  const handleStatusChange = (staffId: string, status: StaffAttendanceStatus) => {
    setDraftRoster((prev) => {
      const current = prev[staffId] || {
        status: 'PRESENT',
        checkInTime: '08:00',
        checkOutTime: '16:00',
        remarks: '',
        isDirty: false
      };
      return {
        ...prev,
        [staffId]: {
          ...current,
          status,
          isDirty: true
        }
      };
    });
  };

  const handleFieldChange = (
    staffId: string,
    field: 'checkInTime' | 'checkOutTime' | 'remarks',
    value: string
  ) => {
    setDraftRoster((prev) => {
      const current = prev[staffId];
      if (!current) return prev;
      return {
        ...prev,
        [staffId]: {
          ...current,
          [field]: value,
          isDirty: true
        }
      };
    });
  };

  // Bulk actions on draft
  const handleMarkAll = (status: StaffAttendanceStatus) => {
    setDraftRoster((prev) => {
      const updated = { ...prev };
      Object.keys(updated).forEach((staffId) => {
        updated[staffId] = {
          ...updated[staffId],
          status,
          isDirty: true
        };
      });
      return updated;
    });
  };

  const handleMarkUnmarked = (status: StaffAttendanceStatus) => {
    if (!dailyData || !Array.isArray(dailyData.roster)) return;
    setDraftRoster((prev) => {
      const updated = { ...prev };
      dailyData.roster.forEach((item) => {
        if (!item.status) {
          updated[item.staffId] = {
            ...(updated[item.staffId] || {
              checkInTime: item.effectiveSchedule?.startTime || '08:00',
              checkOutTime: item.effectiveSchedule?.endTime || '16:00',
              remarks: ''
            }),
            status,
            isDirty: true
          };
        }
      });
      return updated;
    });
  };

  // Count dirty rows
  const dirtyCount = useMemo(() => {
    return (Object.values(draftRoster) as Array<{ isDirty: boolean }>).filter((item) => item.isDirty).length;
  }, [draftRoster]);

  // Save all modified rows
  const handleSaveAll = async () => {
    if (!dailyData) return;
    const dirtyStaffIds = Object.keys(draftRoster).filter((id) => draftRoster[id].isDirty);
    if (dirtyStaffIds.length === 0) return;

    if (!dailyData.canMarkAttendance && !allowOverride) {
      setDailyError(
        `Attendance cannot be marked on a ${dailyData.dayType} (${dailyData.dayReason}) without Super Admin override confirmation.`
      );
      return;
    }

    setIsSaving(true);
    setDailyError(null);

    const recordsToSave = dirtyStaffIds.map((staffId) => ({
      staffId,
      status: draftRoster[staffId].status,
      checkInTime: draftRoster[staffId].checkInTime,
      checkOutTime: draftRoster[staffId].checkOutTime,
      remarks: draftRoster[staffId].remarks
    }));

    try {
      const result = await api.staff.attendance.bulkMark({
        date: selectedDate,
        records: recordsToSave,
        allowOverride,
        overrideReason: allowOverride ? overrideReason || 'Super Admin weekend/holiday override' : undefined
      });

      setSuccessMessage(`Successfully saved attendance for ${result.savedCount} staff members.`);
      fetchDailyRoster();
    } catch (err: any) {
      setDailyError(err.message || 'Failed to save attendance changes.');
    } finally {
      setIsSaving(false);
    }
  };

  // Open correction modal for single record
  const handleOpenCorrection = (item: StaffDailyRosterItem) => {
    const record: StaffAttendanceRecord = {
      id: item.recordId || `temp-${item.staffId}`,
      staffId: item.staffId,
      teacherProfileId: item.teacherProfileId,
      userId: item.userId,
      staffName: item.staffName,
      employeeCode: item.employeeCode,
      staffType: item.staffType,
      departmentId: item.departmentId,
      departmentName: item.departmentName,
      designation: item.designation,
      avatarUrl: item.avatarUrl,
      academicSessionId: dailyData?.academicSessionId || 'session-current',
      date: selectedDate,
      status: item.status || 'PRESENT',
      checkInTime: item.checkInTime || item.effectiveSchedule?.startTime || '08:00',
      checkOutTime: item.checkOutTime || item.effectiveSchedule?.endTime || '16:00',
      remarks: item.remarks || '',
      history: item.history || [],
      createdBy: 'current-user',
      createdByName: user?.name || 'Administrator',
      updatedBy: 'current-user',
      updatedByName: user?.name || 'Administrator',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    setSelectedRecordForCorrection(record);
    setIsCorrectionModalOpen(true);
  };

  const handleSaveCorrection = async (recordId: string, payload: CorrectStaffAttendancePayload) => {
    if (recordId.startsWith('temp-')) {
      // Mark fresh then correct
      const staffId = recordId.replace('temp-', '');
      await api.staff.attendance.mark({
        staffId,
        date: selectedDate,
        status: payload.status || 'PRESENT',
        checkInTime: payload.checkInTime,
        checkOutTime: payload.checkOutTime,
        remarks: payload.remarks,
        allowOverride: true,
        overrideReason: payload.reason
      });
    } else {
      await api.staff.attendance.correct(recordId, payload);
    }
    setSuccessMessage('Attendance record successfully corrected and logged in audit history.');
    fetchDailyRoster();
  };

  // Status colors & labels
  const statusColors: Record<StaffAttendanceStatus, string> = {
    PRESENT: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
    ABSENT: 'bg-rose-500/20 text-rose-400 border-rose-500/30',
    LATE: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
    HALF_DAY: 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30',
    LEAVE: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
    EXCUSED: 'bg-blue-500/20 text-blue-400 border-blue-500/30'
  };

  return (
    <div id="staff-attendance-tab" className="space-y-6">
      {/* View Switcher & Actions Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-2xl bg-slate-900/80 border border-white/10 backdrop-blur-md">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setViewMode('daily')}
            className={`px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2 transition-all ${
              viewMode === 'daily'
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                : 'bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700'
            }`}
          >
            <Calendar className="w-4 h-4" />
            Daily Attendance Roster
          </button>
          <button
            type="button"
            onClick={() => setViewMode('monthly')}
            className={`px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2 transition-all ${
              viewMode === 'monthly'
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                : 'bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700'
            }`}
          >
            <CalendarDays className="w-4 h-4" />
            Monthly Attendance Matrix
          </button>
        </div>

        <div className="flex items-center gap-3">
          {viewMode === 'daily' && (
            <a
              href={api.staff.attendance.getExportCsvUrl(selectedDate, dailyDepartmentId, dailyStaffType)}
              download
              className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-white/10 text-xs font-semibold flex items-center gap-2 transition-colors"
            >
              <Download className="w-3.5 h-3.5 text-indigo-400" />
              Export Daily CSV
            </a>
          )}
          <Button
            variant="outline"
            size="sm"
            onClick={() => (viewMode === 'daily' ? fetchDailyRoster() : fetchMonthlyMatrix())}
            className="border-white/10 text-slate-300 hover:bg-white/5 flex items-center gap-1.5"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            Refresh
          </Button>
        </div>
      </div>

      {/* Notifications */}
      {successMessage && (
        <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center gap-3 text-emerald-300 text-sm animate-fade-in">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <span>{successMessage}</span>
        </div>
      )}

      {dailyError && (
        <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/20 flex items-start gap-3 text-rose-300 text-sm">
          <AlertCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
          <div className="flex-1">
            <span className="font-semibold block">Attendance Alert</span>
            <span>{dailyError}</span>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 1. DAILY ATTENDANCE VIEW */}
      {/* ========================================================================= */}
      {viewMode === 'daily' && (
        <div className="space-y-6">
          {/* Calendar Status Banner & Date Controller */}
          <div className="p-5 rounded-2xl bg-slate-900 border border-white/10 space-y-4">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              {/* Date navigator */}
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => shiftDate(-1)}
                  className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-white/10 transition-colors"
                  title="Previous Day"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>

                <div className="relative">
                  <input
                    type="date"
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                    className="px-4 py-2 bg-slate-950 border border-white/10 rounded-xl text-white font-semibold text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <button
                  type="button"
                  onClick={() => shiftDate(1)}
                  className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-white/10 transition-colors"
                  title="Next Day"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>

                <Button
                  variant="outline"
                  size="sm"
                  onClick={jumpToToday}
                  className="border-white/10 text-slate-300 hover:bg-white/5 text-xs font-semibold"
                >
                  Today
                </Button>
              </div>

              {/* Calendar Working Status Badge */}
              {dailyData && (
                <div className="flex flex-wrap items-center gap-3">
                  <div
                    className={`px-3.5 py-1.5 rounded-xl border text-xs font-bold flex items-center gap-2 ${
                      dailyData.isWorkingDay
                        ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/20'
                        : dailyData.dayType === 'HOLIDAY'
                        ? 'bg-rose-500/10 text-rose-300 border-rose-500/20'
                        : 'bg-amber-500/10 text-amber-300 border-amber-500/20'
                    }`}
                  >
                    <Calendar className="w-4 h-4" />
                    <span>
                      {dailyData.dayType === 'WORKING_DAY'
                        ? 'Official School Working Day'
                        : dailyData.dayType === 'HOLIDAY'
                        ? `Institutional Holiday: ${dailyData.dayReason || 'Holiday'}`
                        : dailyData.dayType === 'SPECIAL_WORKING_DAY'
                        ? `Special Working Day: ${dailyData.dayReason || 'Open'}`
                        : `Scheduled Weekend: ${dailyData.dayReason || 'Rest Day'}`}
                    </span>
                  </div>

                  {!dailyData.canMarkAttendance && (
                    <label className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs font-semibold cursor-pointer">
                      <input
                        type="checkbox"
                        checked={allowOverride}
                        onChange={(e) => setAllowOverride(e.target.checked)}
                        className="rounded border-rose-400 bg-slate-900 text-rose-600 focus:ring-rose-500"
                      />
                      <span>Super Admin Non-Working Day Override</span>
                    </label>
                  )}
                </div>
              )}
            </div>

            {allowOverride && (
              <div className="p-3 rounded-xl bg-slate-950/60 border border-rose-500/30 flex items-center gap-3">
                <ShieldCheck className="w-5 h-5 text-rose-400 shrink-0" />
                <input
                  type="text"
                  value={overrideReason}
                  onChange={(e) => setOverrideReason(e.target.value)}
                  placeholder="State the administrative reason for recording attendance on a non-working day (e.g. Special weekend examination duty or security shift)"
                  className="w-full bg-transparent text-xs text-white placeholder-slate-500 focus:outline-none"
                />
              </div>
            )}
          </div>

          {/* Quick KPI Statistics Row */}
          {dailyData?.stats && (
            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
              <div className="p-3 rounded-xl bg-slate-900 border border-white/5 text-center">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                  Total Staff
                </span>
                <span className="text-xl font-black text-white">{dailyData.stats.totalStaff}</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-900 border border-emerald-500/20 text-center">
                <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider block">
                  Present
                </span>
                <span className="text-xl font-black text-emerald-400">{dailyData.stats.presentCount}</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-900 border border-rose-500/20 text-center">
                <span className="text-[10px] font-bold text-rose-400 uppercase tracking-wider block">
                  Absent
                </span>
                <span className="text-xl font-black text-rose-400">{dailyData.stats.absentCount}</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-900 border border-amber-500/20 text-center">
                <span className="text-[10px] font-bold text-amber-400 uppercase tracking-wider block">
                  Late
                </span>
                <span className="text-xl font-black text-amber-400">{dailyData.stats.lateCount}</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-900 border border-cyan-500/20 text-center">
                <span className="text-[10px] font-bold text-cyan-400 uppercase tracking-wider block">
                  Half Day
                </span>
                <span className="text-xl font-black text-cyan-400">{dailyData.stats.halfDayCount}</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-900 border border-purple-500/20 text-center">
                <span className="text-[10px] font-bold text-purple-400 uppercase tracking-wider block">
                  On Leave
                </span>
                <span className="text-xl font-black text-purple-400">{dailyData.stats.leaveCount}</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-700 text-center">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                  Unmarked
                </span>
                <span className="text-xl font-black text-slate-300">{dailyData.stats.unmarkedCount}</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-900 border border-indigo-500/30 text-center">
                <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-wider block">
                  Rate
                </span>
                <span className="text-xl font-black text-indigo-300">{dailyData.stats.attendanceRate}%</span>
              </div>
            </div>
          )}

          {/* Roster Controls: Filter Bar & Bulk Actions */}
          <div className="p-4 rounded-2xl bg-slate-900 border border-white/10 space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {/* Search */}
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Search staff name, code, role..."
                  value={dailySearch}
                  onChange={(e) => setDailySearch(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 placeholder-slate-500"
                />
              </div>

              {/* Department */}
              <div>
                <select
                  value={dailyDepartmentId}
                  onChange={(e) => setDailyDepartmentId(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="ALL">All Departments</option>
                  {departments.map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Staff Category */}
              <div>
                <select
                  value={dailyStaffType}
                  onChange={(e) => setDailyStaffType(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="ALL">All Staff Categories</option>
                  <option value="teaching">Teaching Faculty</option>
                  <option value="administrative">Administrative</option>
                  <option value="support">Support Services</option>
                  <option value="management">Management</option>
                  <option value="operational">Operational</option>
                </select>
              </div>

              {/* Status Filter */}
              <div>
                <select
                  value={dailyStatusFilter}
                  onChange={(e) => setDailyStatusFilter(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="ALL">All Statuses</option>
                  <option value="PRESENT">Present</option>
                  <option value="ABSENT">Absent</option>
                  <option value="LATE">Late</option>
                  <option value="HALF_DAY">Half Day</option>
                  <option value="LEAVE">On Leave</option>
                  <option value="UNMARKED">Unmarked Only</option>
                </select>
              </div>
            </div>

            {/* Bulk Actions Toolbar & Save Bar */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-white/5">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-xs font-semibold text-slate-400 mr-1">Fast Actions:</span>
                <button
                  type="button"
                  onClick={() => handleMarkAll('PRESENT')}
                  className="px-2.5 py-1 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs font-semibold"
                >
                  Mark All Present
                </button>
                <button
                  type="button"
                  onClick={() => handleMarkUnmarked('PRESENT')}
                  className="px-2.5 py-1 rounded-lg bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-xs font-semibold"
                >
                  Mark Unmarked Present
                </button>
                <button
                  type="button"
                  onClick={() => handleMarkAll('ABSENT')}
                  className="px-2.5 py-1 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 text-xs font-semibold"
                >
                  Mark All Absent
                </button>
              </div>

              <div className="flex items-center gap-3">
                {dirtyCount > 0 && (
                  <span className="text-xs font-semibold text-amber-400 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                    {dirtyCount} pending modification{dirtyCount > 1 ? 's' : ''}
                  </span>
                )}
                <Button
                  onClick={handleSaveAll}
                  disabled={dirtyCount === 0 || isSaving}
                  className="bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs flex items-center gap-2"
                >
                  <Save className="w-4 h-4" />
                  {isSaving ? 'Saving Roster...' : `Save Changes (${dirtyCount})`}
                </Button>
              </div>
            </div>
          </div>

          {/* Daily Roster Table */}
          <div className="rounded-2xl border border-white/10 bg-slate-900 overflow-hidden shadow-xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-950/80 text-slate-400 uppercase text-[11px] font-bold tracking-wider border-b border-white/10">
                    <th className="py-3.5 px-4">Staff Member</th>
                    <th className="py-3.5 px-4">Category & Department</th>
                    <th className="py-3.5 px-4">Effective Work Schedule</th>
                    <th className="py-3.5 px-4 text-center">Attendance Status</th>
                    <th className="py-3.5 px-4">Duty Hours (In / Out)</th>
                    <th className="py-3.5 px-4">Remarks</th>
                    <th className="py-3.5 px-4 text-right">Audit</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {dailyLoading ? (
                    <tr>
                      <td colSpan={7} className="py-12 text-center text-slate-400">
                        <RefreshCw className="w-6 h-6 animate-spin mx-auto text-indigo-400 mb-2" />
                        Loading daily attendance roster...
                      </td>
                    </tr>
                  ) : !dailyData || !Array.isArray(dailyData.roster) || dailyData.roster.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="py-12 text-center text-slate-400">
                        No staff members found matching the selected filters.
                      </td>
                    </tr>
                  ) : (
                    dailyData.roster.map((item) => {
                      const draft = draftRoster[item.staffId] || {
                        status: item.status || 'PRESENT',
                        checkInTime: item.checkInTime || item.effectiveSchedule?.startTime || '08:00',
                        checkOutTime: item.checkOutTime || item.effectiveSchedule?.endTime || '16:00',
                        remarks: item.remarks || '',
                        isDirty: false
                      };

                      return (
                        <tr
                          key={item.staffId}
                          className={`hover:bg-white/[0.02] transition-colors ${
                            draft.isDirty ? 'bg-indigo-500/[0.04]' : ''
                          }`}
                        >
                          {/* Staff Member Info */}
                          <td className="py-3 px-4">
                            <div className="flex items-center gap-3">
                              {item.avatarUrl ? (
                                <img
                                  src={item.avatarUrl}
                                  alt=""
                                  className="w-8 h-8 rounded-lg object-cover border border-white/10"
                                />
                              ) : (
                                <div className="w-8 h-8 rounded-lg bg-indigo-500/20 text-indigo-300 font-bold flex items-center justify-center border border-indigo-500/30">
                                  {item.staffName.charAt(0)}
                                </div>
                              )}
                              <div>
                                <div className="font-bold text-white flex items-center gap-1.5">
                                  {item.staffName}
                                  {draft.isDirty && (
                                    <span
                                      className="w-1.5 h-1.5 rounded-full bg-amber-400"
                                      title="Unsaved changes"
                                    />
                                  )}
                                </div>
                                <span className="text-[11px] text-slate-400 font-mono">
                                  {item.employeeCode}
                                </span>
                              </div>
                            </div>
                          </td>

                          {/* Category & Department */}
                          <td className="py-3 px-4">
                            <span className="font-medium text-slate-200 block">
                              {item.departmentName || 'General Administration'}
                            </span>
                            <span className="text-[11px] text-slate-400 capitalize">
                              {item.designation || item.staffType}
                            </span>
                          </td>

                          {/* Effective Work Schedule */}
                          <td className="py-3 px-4">
                            <div className="space-y-0.5">
                              <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-indigo-300 bg-indigo-500/10 px-2 py-0.5 rounded-md border border-indigo-500/20">
                                <Clock className="w-3 h-3" />
                                {item.effectiveSchedule?.startTime} - {item.effectiveSchedule?.endTime}
                              </span>
                              <p className="text-[10px] text-slate-400 truncate max-w-[160px]">
                                {item.effectiveSchedule?.scheduleName}
                              </p>
                            </div>
                          </td>

                          {/* Attendance Status Buttons */}
                          <td className="py-3 px-4">
                            <div className="flex items-center justify-center gap-1">
                              {(
                                [
                                  { key: 'PRESENT', label: 'P', title: 'Present' },
                                  { key: 'ABSENT', label: 'A', title: 'Absent' },
                                  { key: 'LATE', label: 'L', title: 'Late' },
                                  { key: 'HALF_DAY', label: 'HD', title: 'Half Day' },
                                  { key: 'LEAVE', label: 'LV', title: 'Approved Leave' },
                                  { key: 'EXCUSED', label: 'EXC', title: 'Excused' }
                                ] as const
                              ).map(({ key, label, title }) => {
                                const isSelected = draft.status === key;
                                return (
                                  <button
                                    key={key}
                                    type="button"
                                    title={title}
                                    onClick={() => handleStatusChange(item.staffId, key)}
                                    className={`w-7 h-7 rounded-lg text-xs font-bold border transition-all ${
                                      isSelected
                                        ? `${statusColors[key]} ring-2 ring-indigo-500 scale-105 shadow-sm`
                                        : 'bg-slate-950/40 border-white/5 text-slate-400 hover:text-white hover:bg-slate-800'
                                    }`}
                                  >
                                    {label}
                                  </button>
                                );
                              })}
                            </div>
                          </td>

                          {/* Duty Hours Inputs */}
                          <td className="py-3 px-4">
                            <div className="flex items-center gap-1.5">
                              <input
                                type="time"
                                value={draft.checkInTime}
                                onChange={(e) =>
                                  handleFieldChange(item.staffId, 'checkInTime', e.target.value)
                                }
                                className="w-20 px-1.5 py-1 bg-slate-950 border border-white/10 rounded-lg text-white text-center focus:outline-none focus:ring-1 focus:ring-indigo-500"
                              />
                              <span className="text-slate-500">-</span>
                              <input
                                type="time"
                                value={draft.checkOutTime}
                                onChange={(e) =>
                                  handleFieldChange(item.staffId, 'checkOutTime', e.target.value)
                                }
                                className="w-20 px-1.5 py-1 bg-slate-950 border border-white/10 rounded-lg text-white text-center focus:outline-none focus:ring-1 focus:ring-indigo-500"
                              />
                            </div>
                          </td>

                          {/* Remarks */}
                          <td className="py-3 px-4">
                            <input
                              type="text"
                              value={draft.remarks}
                              onChange={(e) =>
                                handleFieldChange(item.staffId, 'remarks', e.target.value)
                              }
                              placeholder="Notes..."
                              className="w-full min-w-[130px] px-2 py-1 bg-slate-950 border border-white/10 rounded-lg text-white text-xs placeholder-slate-600 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                            />
                          </td>

                          {/* Audit Correction */}
                          <td className="py-3 px-4 text-right">
                            <button
                              type="button"
                              onClick={() => handleOpenCorrection(item)}
                              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-white/10 transition-colors"
                              title="Audit History & Authorized Override"
                            >
                              <History className="w-4 h-4 text-amber-400" />
                            </button>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 2. MONTHLY MATRIX VIEW */}
      {/* ========================================================================= */}
      {viewMode === 'monthly' && (
        <div className="space-y-6">
          {/* Month Controller & Filter Bar */}
          <div className="p-5 rounded-2xl bg-slate-900 border border-white/10 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                {/* Year */}
                <select
                  value={monthlyYear}
                  onChange={(e) => setMonthlyYear(Number(e.target.value))}
                  className="px-3 py-2 bg-slate-950 border border-white/10 rounded-xl text-sm text-white font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  {[2024, 2025, 2026, 2027].map((y) => (
                    <option key={y} value={y}>
                      {y}
                    </option>
                  ))}
                </select>

                {/* Month */}
                <select
                  value={monthlyMonth}
                  onChange={(e) => setMonthlyMonth(Number(e.target.value))}
                  className="px-3 py-2 bg-slate-950 border border-white/10 rounded-xl text-sm text-white font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  {[
                    { val: 1, name: 'January' },
                    { val: 2, name: 'February' },
                    { val: 3, name: 'March' },
                    { val: 4, name: 'April' },
                    { val: 5, name: 'May' },
                    { val: 6, name: 'June' },
                    { val: 7, name: 'July' },
                    { val: 8, name: 'August' },
                    { val: 9, name: 'September' },
                    { val: 10, name: 'October' },
                    { val: 11, name: 'November' },
                    { val: 12, name: 'December' }
                  ].map((m) => (
                    <option key={m.val} value={m.val}>
                      {m.name}
                    </option>
                  ))}
                </select>

                <span className="text-xs text-slate-400 font-semibold">
                  Working Days: <strong className="text-white">{monthlyData?.totalWorkingDays || 0}</strong>
                </span>
              </div>

              {/* Department & Search */}
              <div className="flex items-center gap-3">
                <select
                  value={monthlyDepartmentId}
                  onChange={(e) => setMonthlyDepartmentId(e.target.value)}
                  className="px-3 py-2 bg-slate-950 border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="ALL">All Departments</option>
                  {departments.map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.name}
                    </option>
                  ))}
                </select>

                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    placeholder="Search staff..."
                    value={monthlySearch}
                    onChange={(e) => setMonthlySearch(e.target.value)}
                    className="pl-8 pr-3 py-1.5 bg-slate-950 border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:ring-1 focus:ring-indigo-500 placeholder-slate-500"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Monthly KPI Overview */}
          {monthlyData?.overallSummary && (
            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
              <div className="p-3 rounded-xl bg-slate-900 border border-white/5 text-center">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                  Staff Members
                </span>
                <span className="text-lg font-bold text-white">{monthlyData.overallSummary.totalStaff}</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-900 border border-indigo-500/20 text-center">
                <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-wider block">
                  Average Rate
                </span>
                <span className="text-lg font-bold text-indigo-300">
                  {monthlyData.overallSummary.averageAttendanceRate}%
                </span>
              </div>
              <div className="p-3 rounded-xl bg-slate-900 border border-emerald-500/20 text-center">
                <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider block">
                  Total Present
                </span>
                <span className="text-lg font-bold text-emerald-400">
                  {monthlyData.overallSummary.totalPresent}
                </span>
              </div>
              <div className="p-3 rounded-xl bg-slate-900 border border-rose-500/20 text-center">
                <span className="text-[10px] font-bold text-rose-400 uppercase tracking-wider block">
                  Total Absent
                </span>
                <span className="text-lg font-bold text-rose-400">
                  {monthlyData.overallSummary.totalAbsent}
                </span>
              </div>
              <div className="p-3 rounded-xl bg-slate-900 border border-amber-500/20 text-center">
                <span className="text-[10px] font-bold text-amber-400 uppercase tracking-wider block">
                  Total Late
                </span>
                <span className="text-lg font-bold text-amber-400">
                  {monthlyData.overallSummary.totalLate}
                </span>
              </div>
              <div className="p-3 rounded-xl bg-slate-900 border border-cyan-500/20 text-center">
                <span className="text-[10px] font-bold text-cyan-400 uppercase tracking-wider block">
                  Half Days
                </span>
                <span className="text-lg font-bold text-cyan-400">
                  {monthlyData.overallSummary.totalHalfDay}
                </span>
              </div>
              <div className="p-3 rounded-xl bg-slate-900 border border-purple-500/20 text-center">
                <span className="text-[10px] font-bold text-purple-400 uppercase tracking-wider block">
                  Leaves
                </span>
                <span className="text-lg font-bold text-purple-400">
                  {monthlyData.overallSummary.totalLeave}
                </span>
              </div>
            </div>
          )}

          {/* Matrix Grid Table */}
          <div className="rounded-2xl border border-white/10 bg-slate-900 overflow-hidden shadow-xl">
            <div className="overflow-x-auto max-h-[600px]">
              <table className="w-full text-left border-collapse text-xs">
                <thead className="sticky top-0 z-20 bg-slate-950 shadow-md">
                  <tr className="text-slate-400 uppercase text-[10px] font-bold tracking-wider border-b border-white/10">
                    <th className="py-3 px-4 sticky left-0 z-30 bg-slate-950 min-w-[200px] border-r border-white/10">
                      Staff Member
                    </th>
                    {monthlyData?.days.map((d) => (
                      <th
                        key={d.date}
                        className={`py-2 px-1 text-center min-w-[28px] ${
                          !d.isWorkingDay ? 'bg-slate-900/60 text-slate-500' : 'text-slate-300'
                        }`}
                        title={`${d.date} (${d.dayName}) - ${d.reason || d.dayType}`}
                      >
                        <div className="text-[9px] text-slate-400 font-mono">{d.dayName.charAt(0)}</div>
                        <div className="font-bold text-white">{d.dayOfMonth}</div>
                      </th>
                    ))}
                    <th className="py-3 px-3 text-center bg-slate-950 font-bold text-indigo-300 min-w-[70px] border-l border-white/10">
                      Rate
                    </th>
                    <th className="py-3 px-2 text-center bg-slate-950 text-emerald-400 min-w-[36px]">P</th>
                    <th className="py-3 px-2 text-center bg-slate-950 text-rose-400 min-w-[36px]">A</th>
                    <th className="py-3 px-2 text-center bg-slate-950 text-amber-400 min-w-[36px]">L</th>
                    <th className="py-3 px-2 text-center bg-slate-950 text-purple-400 min-w-[36px]">LV</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {monthlyLoading ? (
                    <tr>
                      <td colSpan={(monthlyData?.days?.length || 31) + 6} className="py-12 text-center text-slate-400">
                        <RefreshCw className="w-6 h-6 animate-spin mx-auto text-indigo-400 mb-2" />
                        Generating monthly attendance matrix...
                      </td>
                    </tr>
                  ) : !monthlyData || !Array.isArray(monthlyData.staff) || monthlyData.staff.length === 0 ? (
                    <tr>
                      <td colSpan={(monthlyData?.days?.length || 31) + 6} className="py-12 text-center text-slate-400">
                        No attendance records found for this period.
                      </td>
                    </tr>
                  ) : (
                    monthlyData.staff.map((s) => (
                      <tr key={s.staffId} className="hover:bg-white/[0.02] transition-colors">
                        {/* Fixed Left Column */}
                        <td className="py-2.5 px-4 sticky left-0 z-10 bg-slate-900 border-r border-white/10">
                          <span className="font-bold text-white block truncate max-w-[180px]">
                            {s.staffName}
                          </span>
                          <span className="text-[10px] text-slate-400 font-mono">
                            {s.employeeCode} • {s.departmentName}
                          </span>
                        </td>

                        {/* Days Columns */}
                        {(monthlyData.days || []).map((d) => {
                          const att = s.attendanceByDate[d.date];
                          let badgeContent = '-';
                          let badgeStyle = 'text-slate-600';

                          if (att) {
                            switch (att.status) {
                              case 'PRESENT':
                                badgeContent = 'P';
                                badgeStyle = 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';
                                break;
                              case 'ABSENT':
                                badgeContent = 'A';
                                badgeStyle = 'bg-rose-500/20 text-rose-400 border-rose-500/30 font-bold';
                                break;
                              case 'LATE':
                                badgeContent = 'L';
                                badgeStyle = 'bg-amber-500/20 text-amber-400 border-amber-500/30';
                                break;
                              case 'HALF_DAY':
                                badgeContent = 'HD';
                                badgeStyle = 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30';
                                break;
                              case 'LEAVE':
                                badgeContent = 'LV';
                                badgeStyle = 'bg-purple-500/20 text-purple-400 border-purple-500/30 font-bold';
                                break;
                              case 'EXCUSED':
                                badgeContent = 'EX';
                                badgeStyle = 'bg-blue-500/20 text-blue-400 border-blue-500/30';
                                break;
                            }
                          } else if (!d.isWorkingDay) {
                            badgeContent = '•';
                            badgeStyle = 'text-slate-600';
                          }

                          return (
                            <td
                              key={d.date}
                              className={`p-1 text-center ${
                                !d.isWorkingDay ? 'bg-slate-950/40' : ''
                              }`}
                            >
                              <span
                                className={`inline-flex items-center justify-center w-6 h-6 rounded text-[10px] font-bold border ${badgeStyle}`}
                                title={
                                  att
                                    ? `${d.date}: ${att.status}${att.remarks ? ` (${att.remarks})` : ''}`
                                    : `${d.date}: ${d.reason || d.dayType}`
                                }
                              >
                                {badgeContent}
                              </span>
                            </td>
                          );
                        })}

                        {/* Rate */}
                        <td className="py-2.5 px-3 text-center font-bold text-indigo-300 border-l border-white/10 bg-indigo-500/[0.02]">
                          {s.summary.rate}%
                        </td>
                        <td className="py-2.5 px-2 text-center text-emerald-400 font-bold">
                          {s.summary.present}
                        </td>
                        <td className="py-2.5 px-2 text-center text-rose-400 font-bold">
                          {s.summary.absent}
                        </td>
                        <td className="py-2.5 px-2 text-center text-amber-400 font-bold">
                          {s.summary.late}
                        </td>
                        <td className="py-2.5 px-2 text-center text-purple-400 font-bold">
                          {s.summary.leave}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Correction Modal */}
      <StaffAttendanceCorrectionModal
        isOpen={isCorrectionModalOpen}
        onClose={() => setIsCorrectionModalOpen(false)}
        record={selectedRecordForCorrection}
        onSaveCorrection={handleSaveCorrection}
      />
    </div>
  );
};
