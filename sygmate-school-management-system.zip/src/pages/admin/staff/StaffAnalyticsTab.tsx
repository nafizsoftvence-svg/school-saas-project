/**
 * Sygmate School Management System
 * Staff HR Reports & Analytics Suite (Part 12F)
 */

import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  Users,
  GraduationCap,
  Briefcase,
  UserCheck,
  UserX,
  Clock,
  Building,
  TrendingUp,
  Award,
  PieChart as PieChartIcon,
  Calendar,
  Layers,
  FileSpreadsheet,
  Download,
  AlertCircle,
  CheckCircle2,
  ExternalLink,
  ChevronRight,
  Target,
  UserPlus,
  RefreshCw
} from 'lucide-react';
import {
  StaffProfile,
  Department,
  Designation,
  AcademicSession,
  HRReportFilterQuery,
  HRDashboardKPIs,
  StaffHeadcountReport,
  StaffAttendanceReport,
  StaffLeaveReport,
  LeaveBalanceUtilizationReport,
  RecruitmentFunnelReport,
  RecruitmentPerformanceReport,
  OnboardingReport,
  PerformanceCompletionReport,
  GoalAchievementReport,
  StaffTurnoverReport,
  CrossSessionHRReport,
  HRDrilldownRecord
} from '../../../types/index.js';
import { api } from '../../../services/api.js';

import { HRReportFilterBar } from './reports/HRReportFilterBar.js';
import { HRDrilldownModal } from './reports/HRDrilldownModal.js';
import { HRExportModal } from './reports/HRExportModal.js';
import { HRHeadcountView } from './reports/HRHeadcountView.js';
import { HRAttendanceView } from './reports/HRAttendanceView.js';
import { HRLeaveView } from './reports/HRLeaveView.js';
import { HRRecruitmentOnboardingView } from './reports/HRRecruitmentOnboardingView.js';
import { HRPerformanceTurnoverView } from './reports/HRPerformanceTurnoverView.js';
import { HRCrossSessionView } from './reports/HRCrossSessionView.js';

type HRAnalyticsSubTab =
  | 'overview'
  | 'headcount'
  | 'attendance'
  | 'leaves'
  | 'recruitment'
  | 'performance'
  | 'cross_session';

interface StaffAnalyticsTabProps {
  staffList?: StaffProfile[];
  departments?: Department[];
  designations?: Designation[];
}

export const StaffAnalyticsTab: React.FC<StaffAnalyticsTabProps> = ({
  staffList = [],
  departments = [],
  designations = []
}) => {
  const [activeSubTab, setActiveSubTab] = useState<HRAnalyticsSubTab>('overview');
  const [filters, setFilters] = useState<HRReportFilterQuery>({});
  const [isLoading, setIsLoading] = useState(true);
  const [academicSessions, setAcademicSessions] = useState<AcademicSession[]>([]);

  // Report Data States
  const [kpis, setKpis] = useState<HRDashboardKPIs | null>(null);
  const [headcount, setHeadcount] = useState<StaffHeadcountReport | null>(null);
  const [attendance, setAttendance] = useState<StaffAttendanceReport | null>(null);
  const [leaves, setLeaves] = useState<StaffLeaveReport | null>(null);
  const [leaveBalances, setLeaveBalances] = useState<LeaveBalanceUtilizationReport | null>(null);
  const [funnel, setFunnel] = useState<RecruitmentFunnelReport | null>(null);
  const [recruitmentPerf, setRecruitmentPerf] = useState<RecruitmentPerformanceReport | null>(null);
  const [onboarding, setOnboarding] = useState<OnboardingReport | null>(null);
  const [performance, setPerformance] = useState<PerformanceCompletionReport | null>(null);
  const [goals, setGoals] = useState<GoalAchievementReport | null>(null);
  const [turnover, setTurnover] = useState<StaffTurnoverReport | null>(null);
  const [crossSession, setCrossSession] = useState<CrossSessionHRReport | null>(null);

  // Drilldown State
  const [drilldownMetric, setDrilldownMetric] = useState<{ key: string; label: string } | null>(null);
  const [drilldownRecords, setDrilldownRecords] = useState<HRDrilldownRecord[]>([]);
  const [isDrilldownLoading, setIsDrilldownLoading] = useState(false);

  // Export Modal State
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);

  // Fetch Academic Sessions on mount
  useEffect(() => {
    const fetchSessions = async () => {
      try {
        const res = await api.academic.getSessions();
        if (Array.isArray(res)) {
          setAcademicSessions(res);
        } else if ((res as any)?.data && Array.isArray((res as any).data)) {
          setAcademicSessions((res as any).data);
        }
      } catch (err) {
        console.warn('Academic sessions fetch quiet fail:', err);
      }
    };
    fetchSessions();
  }, []);

  // Fetch Reports Data
  const loadReportsData = useCallback(async () => {
    setIsLoading(true);
    try {
      const [
        kpiRes,
        headcountRes,
        attendanceRes,
        leaveRes,
        leaveBalRes,
        funnelRes,
        recPerfRes,
        onbRes,
        perfRes,
        goalsRes,
        turnoverRes,
        crossRes
      ] = await Promise.all([
        api.staff.reports.getDashboardKPIs(filters).catch(() => null),
        api.staff.reports.getHeadcountReport(filters).catch(() => null),
        api.staff.reports.getAttendanceReport(filters).catch(() => null),
        api.staff.reports.getLeaveReport(filters).catch(() => null),
        api.staff.reports.getLeaveBalanceReport(filters).catch(() => null),
        api.staff.reports.getRecruitmentFunnel(filters).catch(() => null),
        api.staff.reports.getRecruitmentPerformance().catch(() => null),
        api.staff.reports.getOnboardingReport(filters).catch(() => null),
        api.staff.reports.getPerformanceReport(filters).catch(() => null),
        api.staff.reports.getGoalsReport(filters).catch(() => null),
        api.staff.reports.getTurnoverReport().catch(() => null),
        api.staff.reports.getCrossSessionReport().catch(() => null)
      ]);

      if (kpiRes?.data) setKpis(kpiRes.data);
      if (headcountRes?.data) setHeadcount(headcountRes.data);
      if (attendanceRes?.data) setAttendance(attendanceRes.data);
      if (leaveRes?.data) setLeaves(leaveRes.data);
      if (leaveBalRes?.data) setLeaveBalances(leaveBalRes.data);
      if (funnelRes?.data) setFunnel(funnelRes.data);
      if (recPerfRes?.data) setRecruitmentPerf(recPerfRes.data);
      if (onbRes?.data) setOnboarding(onbRes.data);
      if (perfRes?.data) setPerformance(perfRes.data);
      if (goalsRes?.data) setGoals(goalsRes.data);
      if (turnoverRes?.data) setTurnover(turnoverRes.data);
      if (crossRes?.data) setCrossSession(crossRes.data);
    } catch (err) {
      console.error('Error fetching HR reports:', err);
    } finally {
      setIsLoading(false);
    }
  }, [filters]);

  useEffect(() => {
    loadReportsData();
  }, [loadReportsData]);

  // Handle Drilldown trigger
  const handleOpenDrilldown = async (metricKey: string, label: string) => {
    setDrilldownMetric({ key: metricKey, label });
    setIsDrilldownLoading(true);
    try {
      const res = await api.staff.reports.getDrilldown(metricKey, filters);
      if (res?.data?.records) {
        setDrilldownRecords(res.data.records);
      } else {
        setDrilldownRecords([]);
      }
    } catch (err) {
      console.error('Drilldown fetch failed:', err);
      setDrilldownRecords([]);
    } finally {
      setIsDrilldownLoading(false);
    }
  };

  // Build CSV supplier for current sub-tab export
  const activeCSVSupplier = useCallback(() => {
    if (activeSubTab === 'headcount' && headcount) {
      return {
        headers: ['Department', 'Code', 'Total Staff', 'Teaching', 'Support', 'Active', 'Male', 'Female'],
        rows: headcount.departments.map((d) => [
          d.departmentName,
          d.departmentCode,
          d.totalStaff,
          d.teachingStaff,
          d.nonTeachingStaff,
          d.activeStaff,
          d.maleStaff,
          d.femaleStaff
        ])
      };
    }

    if (activeSubTab === 'attendance' && attendance) {
      return {
        headers: ['Department', 'Scheduled Duty', 'Present', 'Late', 'Absent', 'Leave', 'Attendance %'],
        rows: attendance.departmentSummaries.map((d) => [
          d.departmentName,
          d.totalScheduled,
          d.presentCount,
          d.lateCount,
          d.absentCount,
          d.leaveCount,
          `${d.attendancePercentage}%`
        ])
      };
    }

    if (activeSubTab === 'leaves' && leaveBalances) {
      return {
        headers: ['Staff Name', 'Employee Code', 'Department', 'Leave Policy', 'Entitled', 'Carried Over', 'Total Pool', 'Used Days', 'Pending Days', 'Remaining Days', 'Utilization %'],
        rows: leaveBalances.staffBalances.map((b) => [
          b.staffName,
          b.employeeCode,
          b.departmentName,
          b.leaveTypeName,
          b.entitledDays,
          b.carriedForwardDays,
          b.totalAllocatedDays,
          b.usedDays,
          b.pendingDays,
          b.remainingDays,
          `${b.utilizationPercentage}%`
        ])
      };
    }

    if (activeSubTab === 'recruitment' && funnel) {
      return {
        headers: ['Position Title', 'Department', 'Status', 'Openings', 'Applications', 'Interviews', 'Offers', 'Hired'],
        rows: funnel.positionMetrics.map((p) => [
          p.title,
          p.departmentName,
          p.status,
          p.openingsCount,
          p.applicationsCount,
          p.interviewsCount,
          p.offersCount,
          p.hiredCount
        ])
      };
    }

    if (activeSubTab === 'performance' && performance) {
      return {
        headers: ['Department', 'Reviews Count', 'Completed', 'Average Score', 'Rating Band'],
        rows: performance.departmentPerformance.map((d) => [
          d.departmentName,
          d.reviewsCount,
          d.completedCount,
          `${d.averageScore}%`,
          d.ratingBand
        ])
      };
    }

    // Default Overview / Headcount CSV
    return {
      headers: ['Metric', 'Current Value', 'Reporting Unit'],
      rows: [
        ['Total Workforce Headcount', kpis?.totalStaff || 0, 'Staff Members'],
        ['Active Duty Staff', kpis?.activeStaff || 0, 'Staff Members'],
        ['Teaching / Faculty Staff', kpis?.teachingStaff || 0, 'Instructors'],
        ['Administrative & Support Staff', (kpis?.administrativeStaff || 0) + (kpis?.supportStaff || 0), 'Operations'],
        ['Staff On Authorized Leave', kpis?.staffOnLeave || 0, 'Staff Members'],
        ['Today Attendance Rate', `${kpis?.todayAttendanceRate || 0}%`, 'Percentage'],
        ['Open Job Openings', kpis?.openJobPositions || 0, 'Vacancies'],
        ['Active Candidate Pipeline', kpis?.activeCandidates || 0, 'Applicants'],
        ['Pending Onboarding Processes', kpis?.pendingOnboarding || 0, 'New Hires'],
        ['Active Appraisal Reviews', kpis?.activePerformanceReviews || 0, 'Staff']
      ]
    };
  }, [activeSubTab, kpis, headcount, attendance, leaveBalances, funnel, performance]);

  return (
    <div className="space-y-6 animate-in fade-in duration-200" id="hr-reports-analytics-root">
      {/* Header & Export Actions */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold text-slate-900">
              Institutional HR Reports & Workforce Analytics
            </h2>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-indigo-50 text-indigo-700 border border-indigo-200">
              Part 12F
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Authoritative institutional intelligence, attendance discipline, leave utilization & talent lifecycle tracking
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={() => setIsExportModalOpen(true)}
            className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-bold text-slate-800 bg-white border border-slate-300 rounded-xl hover:bg-slate-50 transition-colors shadow-xs"
            id="hr-open-export-modal-btn"
          >
            <Download className="w-4 h-4 text-indigo-600" />
            <span>Export Official Report</span>
          </button>
        </div>
      </div>

      {/* Universal Filter Bar */}
      <HRReportFilterBar
        filters={filters}
        onFilterChange={(updated) => setFilters((prev) => ({ ...prev, ...updated }))}
        onResetFilters={() => setFilters({})}
        onRefresh={loadReportsData}
        isLoading={isLoading}
        departments={departments}
        designations={designations}
        academicSessions={academicSessions}
      />

      {/* Sub-Navigation Tabs */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-1.5 flex flex-wrap gap-1">
        <button
          type="button"
          onClick={() => setActiveSubTab('overview')}
          className={`px-3.5 py-2 rounded-lg text-xs font-bold flex items-center gap-2 transition-all ${
            activeSubTab === 'overview'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
          id="hr-subtab-overview"
        >
          <PieChartIcon className="w-3.5 h-3.5" />
          <span>Executive Overview</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('headcount')}
          className={`px-3.5 py-2 rounded-lg text-xs font-bold flex items-center gap-2 transition-all ${
            activeSubTab === 'headcount'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
          id="hr-subtab-headcount"
        >
          <Users className="w-3.5 h-3.5" />
          <span>Headcount & Distribution</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('attendance')}
          className={`px-3.5 py-2 rounded-lg text-xs font-bold flex items-center gap-2 transition-all ${
            activeSubTab === 'attendance'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
          id="hr-subtab-attendance"
        >
          <Clock className="w-3.5 h-3.5" />
          <span>Attendance & Punctuality</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('leaves')}
          className={`px-3.5 py-2 rounded-lg text-xs font-bold flex items-center gap-2 transition-all ${
            activeSubTab === 'leaves'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
          id="hr-subtab-leaves"
        >
          <Calendar className="w-3.5 h-3.5" />
          <span>Leave & Balances</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('recruitment')}
          className={`px-3.5 py-2 rounded-lg text-xs font-bold flex items-center gap-2 transition-all ${
            activeSubTab === 'recruitment'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
          id="hr-subtab-recruitment"
        >
          <Briefcase className="w-3.5 h-3.5" />
          <span>Recruitment & Onboarding</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('performance')}
          className={`px-3.5 py-2 rounded-lg text-xs font-bold flex items-center gap-2 transition-all ${
            activeSubTab === 'performance'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
          id="hr-subtab-performance"
        >
          <Award className="w-3.5 h-3.5" />
          <span>Performance & Turnover</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('cross_session')}
          className={`px-3.5 py-2 rounded-lg text-xs font-bold flex items-center gap-2 transition-all ${
            activeSubTab === 'cross_session'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
          id="hr-subtab-cross-session"
        >
          <TrendingUp className="w-3.5 h-3.5" />
          <span>Cross-Session Trends</span>
        </button>
      </div>

      {/* Main Content Areas */}
      {isLoading && !kpis ? (
        <div className="py-20 flex flex-col items-center justify-center bg-white rounded-2xl border border-slate-200">
          <div className="w-9 h-9 border-3 border-indigo-600 border-t-transparent rounded-full animate-spin mb-4"></div>
          <p className="text-sm font-semibold text-slate-800">Compiling HR Analytics Engine...</p>
          <p className="text-xs text-slate-400 mt-1">Aggregating attendance, leaves, recruitment & appraisal data</p>
        </div>
      ) : (
        <>
          {/* 1. EXECUTIVE OVERVIEW SUB-TAB */}
          {activeSubTab === 'overview' && kpis && (
            <div className="space-y-6">
              {/* Interactive KPI Cards Row */}
              <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-4 gap-4">
                <div
                  onClick={() => handleOpenDrilldown('active_staff', 'Active Workforce Roster')}
                  className="bg-white p-5 rounded-xl border border-slate-200 hover:border-indigo-300 hover:shadow-xs cursor-pointer transition-all group"
                  id="kpi-total-staff"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                      Workforce Headcount
                    </span>
                    <div className="p-2 rounded-lg bg-indigo-50 text-indigo-700 group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                      <Users className="w-4 h-4" />
                    </div>
                  </div>
                  <div className="mt-2 flex items-baseline justify-between">
                    <span className="text-2xl font-bold text-slate-900">{kpis.totalStaff}</span>
                    <span className="text-xs font-semibold text-emerald-600">
                      {kpis.activeStaff} Active
                    </span>
                  </div>
                  <div className="mt-2 flex items-center justify-between text-[11px] text-slate-400">
                    <span>{kpis.teachingStaff} Teaching | {kpis.administrativeStaff + kpis.supportStaff} Admin</span>
                    <ExternalLink className="w-3 h-3 text-indigo-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                </div>

                <div
                  onClick={() => handleOpenDrilldown('active_staff', 'Duty Roster & Attendance')}
                  className="bg-white p-5 rounded-xl border border-slate-200 hover:border-emerald-300 hover:shadow-xs cursor-pointer transition-all group"
                  id="kpi-attendance-rate"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                      Attendance Compliance
                    </span>
                    <div className="p-2 rounded-lg bg-emerald-50 text-emerald-700 group-hover:bg-emerald-600 group-hover:text-white transition-colors">
                      <UserCheck className="w-4 h-4" />
                    </div>
                  </div>
                  <div className="mt-2 flex items-baseline justify-between">
                    <span className="text-2xl font-bold text-slate-900">{kpis.todayAttendanceRate}%</span>
                    <span className="text-xs font-semibold text-emerald-600">Compliant</span>
                  </div>
                  <div className="mt-2 flex items-center justify-between text-[11px] text-slate-400">
                    <span>{kpis.staffOnLeave} on approved leave</span>
                    <ExternalLink className="w-3 h-3 text-emerald-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                </div>

                <div
                  onClick={() => handleOpenDrilldown('active_candidates', 'Active Recruitment Pipeline')}
                  className="bg-white p-5 rounded-xl border border-slate-200 hover:border-blue-300 hover:shadow-xs cursor-pointer transition-all group"
                  id="kpi-recruitment-pipeline"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                      Recruitment Pipeline
                    </span>
                    <div className="p-2 rounded-lg bg-blue-50 text-blue-700 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                      <Briefcase className="w-4 h-4" />
                    </div>
                  </div>
                  <div className="mt-2 flex items-baseline justify-between">
                    <span className="text-2xl font-bold text-slate-900">{kpis.activeCandidates}</span>
                    <span className="text-xs font-semibold text-blue-600">
                      {kpis.openJobPositions} Positions
                    </span>
                  </div>
                  <div className="mt-2 flex items-center justify-between text-[11px] text-slate-400">
                    <span>{kpis.pendingInterviews} interviews scheduled</span>
                    <ExternalLink className="w-3 h-3 text-blue-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                </div>

                <div
                  onClick={() => handleOpenDrilldown('pending_reviews', 'Pending Performance Appraisals')}
                  className="bg-white p-5 rounded-xl border border-slate-200 hover:border-amber-300 hover:shadow-xs cursor-pointer transition-all group"
                  id="kpi-performance-cycle"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                      Appraisal Cycle
                    </span>
                    <div className="p-2 rounded-lg bg-amber-50 text-amber-700 group-hover:bg-amber-600 group-hover:text-white transition-colors">
                      <Award className="w-4 h-4" />
                    </div>
                  </div>
                  <div className="mt-2 flex items-baseline justify-between">
                    <span className="text-2xl font-bold text-slate-900">{kpis.pendingPerformanceReviews}</span>
                    <span className="text-xs font-semibold text-amber-600">Awaiting Action</span>
                  </div>
                  <div className="mt-2 flex items-center justify-between text-[11px] text-slate-400">
                    <span>{kpis.activePerformanceReviews} total cycle reviews</span>
                    <ExternalLink className="w-3 h-3 text-amber-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                </div>
              </div>

              {/* Institutional Health & Operational Readiness Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Workforce Composition Snapshot */}
                <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 space-y-4">
                  <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4 text-indigo-600" />
                      <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                        Workforce Composition Breakdown
                      </h3>
                    </div>
                    <button
                      type="button"
                      onClick={() => setActiveSubTab('headcount')}
                      className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
                    >
                      <span>Full Breakdown</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="space-y-3">
                    <div>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="font-semibold text-slate-700">Teaching & Faculty</span>
                        <span className="font-bold text-slate-900">
                          {kpis.teachingStaff} ({kpis.totalStaff > 0 ? Math.round((kpis.teachingStaff / kpis.totalStaff) * 100) : 0}%)
                        </span>
                      </div>
                      <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                        <div
                          className="bg-indigo-600 h-full rounded-full"
                          style={{
                            width: `${kpis.totalStaff > 0 ? (kpis.teachingStaff / kpis.totalStaff) * 100 : 0}%`
                          }}
                        ></div>
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="font-semibold text-slate-700">Administrative Operations</span>
                        <span className="font-bold text-slate-900">
                          {kpis.administrativeStaff} ({kpis.totalStaff > 0 ? Math.round((kpis.administrativeStaff / kpis.totalStaff) * 100) : 0}%)
                        </span>
                      </div>
                      <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                        <div
                          className="bg-blue-600 h-full rounded-full"
                          style={{
                            width: `${kpis.totalStaff > 0 ? (kpis.administrativeStaff / kpis.totalStaff) * 100 : 0}%`
                          }}
                        ></div>
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="font-semibold text-slate-700">Support & Facility Personnel</span>
                        <span className="font-bold text-slate-900">
                          {kpis.supportStaff} ({kpis.totalStaff > 0 ? Math.round((kpis.supportStaff / kpis.totalStaff) * 100) : 0}%)
                        </span>
                      </div>
                      <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                        <div
                          className="bg-amber-500 h-full rounded-full"
                          style={{
                            width: `${kpis.totalStaff > 0 ? (kpis.supportStaff / kpis.totalStaff) * 100 : 0}%`
                          }}
                        ></div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Critical Action Items & Attention Indicators */}
                <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 space-y-4">
                  <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                    <div className="flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 text-amber-600" />
                      <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                        HR Action Items & Governance Flags
                      </h3>
                    </div>
                    <span className="text-[11px] text-slate-400 font-semibold">Live Queue</span>
                  </div>

                  <div className="space-y-2.5">
                    <div
                      onClick={() => handleOpenDrilldown('pending_leaves', 'Pending Leave Applications')}
                      className="p-3 rounded-lg bg-amber-50/70 border border-amber-200/60 flex items-center justify-between cursor-pointer hover:bg-amber-100/60 transition-colors"
                    >
                      <div className="flex items-center gap-2.5">
                        <Clock className="w-4 h-4 text-amber-700" />
                        <div>
                          <span className="font-bold text-slate-900 block text-xs">
                            Leave Requests Requiring Approval
                          </span>
                          <span className="text-[11px] text-amber-800">
                            {kpis.leaveApplicationsPending} requests awaiting administrative sign-off
                          </span>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-amber-600" />
                    </div>

                    <div
                      onClick={() => handleOpenDrilldown('pending_onboarding', 'Pending Onboardings')}
                      className="p-3 rounded-lg bg-blue-50/70 border border-blue-200/60 flex items-center justify-between cursor-pointer hover:bg-blue-100/60 transition-colors"
                    >
                      <div className="flex items-center gap-2.5">
                        <UserPlus className="w-4 h-4 text-blue-700" />
                        <div>
                          <span className="font-bold text-slate-900 block text-xs">
                            Active Onboarding Pipelines
                          </span>
                          <span className="text-[11px] text-blue-800">
                            {kpis.pendingOnboarding} new hires in verification and orientation stages
                          </span>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-blue-600" />
                    </div>

                    <div
                      onClick={() => handleOpenDrilldown('pending_interviews', 'Scheduled Interviews')}
                      className="p-3 rounded-lg bg-emerald-50/70 border border-emerald-200/60 flex items-center justify-between cursor-pointer hover:bg-emerald-100/60 transition-colors"
                    >
                      <div className="flex items-center gap-2.5">
                        <CheckCircle2 className="w-4 h-4 text-emerald-700" />
                        <div>
                          <span className="font-bold text-slate-900 block text-xs">
                            Scheduled Candidate Interviews
                          </span>
                          <span className="text-[11px] text-emerald-800">
                            {kpis.pendingInterviews} panels scheduled for active positions
                          </span>
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-emerald-600" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 2. HEADCOUNT & DEMOGRAPHICS SUB-TAB */}
          {activeSubTab === 'headcount' && headcount && (
            <HRHeadcountView data={headcount} onDrilldown={handleOpenDrilldown} />
          )}

          {/* 3. ATTENDANCE & PUNCTUALITY SUB-TAB */}
          {activeSubTab === 'attendance' && attendance && (
            <HRAttendanceView data={attendance} onDrilldown={handleOpenDrilldown} />
          )}

          {/* 4. LEAVE & BALANCES SUB-TAB */}
          {activeSubTab === 'leaves' && leaves && leaveBalances && (
            <HRLeaveView
              leaveReport={leaves}
              utilizationReport={leaveBalances}
              onDrilldown={handleOpenDrilldown}
            />
          )}

          {/* 5. RECRUITMENT & ONBOARDING SUB-TAB */}
          {activeSubTab === 'recruitment' && funnel && recruitmentPerf && onboarding && (
            <HRRecruitmentOnboardingView
              funnelData={funnel}
              performanceData={recruitmentPerf}
              onboardingData={onboarding}
              onDrilldown={handleOpenDrilldown}
            />
          )}

          {/* 6. PERFORMANCE & TURNOVER SUB-TAB */}
          {activeSubTab === 'performance' && performance && goals && turnover && (
            <HRPerformanceTurnoverView
              performanceData={performance}
              goalData={goals}
              turnoverData={turnover}
              onDrilldown={handleOpenDrilldown}
            />
          )}

          {/* 7. CROSS-SESSION TRENDS SUB-TAB */}
          {activeSubTab === 'cross_session' && crossSession && (
            <HRCrossSessionView data={crossSession} />
          )}
        </>
      )}

      {/* Drilldown Modal */}
      {drilldownMetric && (
        <HRDrilldownModal
          isOpen={Boolean(drilldownMetric)}
          onClose={() => setDrilldownMetric(null)}
          metricKey={drilldownMetric.key}
          metricLabel={drilldownMetric.label}
          records={drilldownRecords}
          isLoading={isDrilldownLoading}
          filters={filters}
        />
      )}

      {/* Official Export Modal */}
      <HRExportModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        activeReportType={activeSubTab.toUpperCase()}
        reportTitle={`Institutional HR Report — ${(activeSubTab || 'HEADCOUNT').replace(/_/g, ' ').toUpperCase()}`}
        filters={filters}
        csvDataSupplier={activeCSVSupplier}
        recordCount={
          activeSubTab === 'headcount'
            ? headcount?.departments?.length || 0
            : activeSubTab === 'attendance'
            ? attendance?.departmentSummaries?.length || 0
            : activeSubTab === 'leaves'
            ? leaveBalances?.staffBalances?.length || 0
            : activeSubTab === 'recruitment'
            ? funnel?.positionMetrics?.length || 0
            : kpis?.totalStaff || 0
        }
      />
    </div>
  );
};
