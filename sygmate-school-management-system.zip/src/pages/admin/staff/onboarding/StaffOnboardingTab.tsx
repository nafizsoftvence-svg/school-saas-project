/**
 * Sygmate School Management System
 * Staff Onboarding Management & Induction Checklists (Part 12D)
 */

import React, { useState, useEffect, useCallback } from 'react';
import {
  Layers,
  CheckCircle2,
  Clock,
  AlertCircle,
  Search,
  Filter,
  RefreshCw,
  Plus,
  Users,
  ChevronRight,
  Building,
  Calendar,
  Award,
  ShieldCheck,
  FileText,
  UserCheck,
  Sparkles
} from 'lucide-react';
import { Button } from '../../../../components/ui/Button.js';
import { api } from '../../../../services/api.js';
import {
  OnboardingRecord,
  OnboardingTask,
  OnboardingTemplate,
  Department,
  StaffProfile
} from '../../../../types/index.js';

interface StaffOnboardingTabProps {
  departments: Department[];
  onRefreshStaff?: () => void;
}

export const StaffOnboardingTab: React.FC<StaffOnboardingTabProps> = ({
  departments,
  onRefreshStaff
}) => {
  const [subTab, setSubTab] = useState<'records' | 'templates'>('records');

  const [records, setRecords] = useState<OnboardingRecord[]>([]);
  const [templates, setTemplates] = useState<OnboardingTemplate[]>([]);
  const [staffList, setStaffList] = useState<StaffProfile[]>([]);

  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Filters
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [departmentFilter, setDepartmentFilter] = useState<string>('all');

  // Active Detail Drawer / Task Manager
  const [selectedRecord, setSelectedRecord] = useState<OnboardingRecord | null>(null);
  const [isUpdatingTask, setIsUpdatingTask] = useState<boolean>(false);

  // Add Task Modal
  const [isAddTaskOpen, setIsAddTaskOpen] = useState<boolean>(false);
  const [customTaskTitle, setCustomTaskTitle] = useState<string>('');
  const [customTaskCategory, setCustomTaskCategory] = useState<string>('DOCUMENTATION');
  const [customTaskMandatory, setCustomTaskMandatory] = useState<boolean>(true);
  const [customTaskDueDate, setCustomTaskDueDate] = useState<string>(
    new Date(Date.now() + 86400000 * 7).toISOString().split('T')[0]
  );

  // Initialize Onboarding Modal (for staff who don't have onboarding yet)
  const [isInitModalOpen, setIsInitModalOpen] = useState<boolean>(false);
  const [selectedStaffForInit, setSelectedStaffForInit] = useState<string>('');
  const [selectedTemplateForInit, setSelectedTemplateForInit] = useState<string>('');

  const fetchData = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const [recordsRes, templatesRes, staffRes] = await Promise.all([
        api.staff.onboarding.getRecords(),
        api.staff.onboarding.getTemplates(),
        api.staff.getDirectory({ limit: 100 })
      ]);

      const recordsArr = Array.isArray(recordsRes?.data)
        ? recordsRes.data
        : Array.isArray(recordsRes)
        ? recordsRes
        : [];
      setRecords(recordsArr);

      const templatesArr = Array.isArray(templatesRes?.data)
        ? templatesRes.data
        : Array.isArray(templatesRes)
        ? templatesRes
        : [];
      setTemplates(templatesArr);

      const staffArr = Array.isArray(staffRes?.data) ? staffRes.data : Array.isArray(staffRes) ? staffRes : [];
      setStaffList(staffArr);
    } catch (err: any) {
      console.error('Failed to load onboarding data', err);
      setError(err.message || 'Failed to load staff onboarding data.');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  // Task Toggle
  const handleToggleTaskStatus = async (recordId: string, taskId: string, currentStatus: string) => {
    const nextStatus = currentStatus === 'COMPLETED' ? 'PENDING' : 'COMPLETED';
    setIsUpdatingTask(true);
    try {
      const updated = await api.staff.onboarding.updateTask(recordId, taskId, {
        status: nextStatus as any,
        notes: nextStatus === 'COMPLETED' ? 'Marked complete by administrator' : undefined
      });
      // Update local state
      setRecords((prev) => prev.map((r) => (r.id === recordId ? updated.data : r)));
      if (selectedRecord?.id === recordId) {
        setSelectedRecord(updated.data);
      }
    } catch (err: any) {
      alert(err.message || 'Failed to update task.');
    } finally {
      setIsUpdatingTask(false);
    }
  };

  // Add Task to Record
  const handleAddCustomTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedRecord || !customTaskTitle.trim()) return;

    try {
      const updated = await api.staff.onboarding.addTask(selectedRecord.id, {
        title: customTaskTitle,
        category: customTaskCategory as any,
        isMandatory: customTaskMandatory,
        dueDate: customTaskDueDate
      });
      setRecords((prev) => prev.map((r) => (r.id === selectedRecord.id ? updated.data : r)));
      setSelectedRecord(updated.data);
      setIsAddTaskOpen(false);
      setCustomTaskTitle('');
    } catch (err: any) {
      alert(err.message || 'Failed to add custom task.');
    }
  };

  // Initialize for Existing Staff
  const handleInitializeOnboarding = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStaffForInit) return;

    try {
      await api.staff.onboarding.initialize(
        selectedStaffForInit,
        selectedTemplateForInit || ''
      );
      setSuccessMessage('Onboarding induction checklist initialized successfully.');
      setIsInitModalOpen(false);
      fetchData();
    } catch (err: any) {
      alert(err.message || 'Failed to initialize onboarding.');
    }
  };

  // Filtered Records
  const filteredRecords = records.filter((r) => {
    if (statusFilter !== 'all' && r.status !== statusFilter) return false;
    if (departmentFilter !== 'all' && r.departmentId !== departmentFilter) return false;
    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      const match =
        r.staffName.toLowerCase().includes(q) ||
        r.employeeCode.toLowerCase().includes(q) ||
        r.designation.toLowerCase().includes(q) ||
        r.departmentName.toLowerCase().includes(q);
      if (!match) return false;
    }
    return true;
  });

  const activeRecordsCount = records.filter((r) => r.status === 'IN_PROGRESS').length;
  const completedRecordsCount = records.filter((r) => r.status === 'COMPLETED').length;

  return (
    <div className="space-y-6" id="staff-onboarding-module">
      {/* Sub-tab Navigation */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-xl border border-slate-200">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setSubTab('records')}
            className={`px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 ${
              subTab === 'records'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>Active Induction Checklists ({records.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setSubTab('templates')}
            className={`px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 ${
              subTab === 'templates'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Checklist Templates ({templates.length})</span>
          </button>
        </div>

        <div className="flex items-center gap-2">
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={fetchData}
            icon={<RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />}
          >
            Refresh
          </Button>

          <Button
            type="button"
            variant="primary"
            size="sm"
            onClick={() => setIsInitModalOpen(true)}
            icon={<Plus className="w-3.5 h-3.5" />}
          >
            Start Staff Onboarding
          </Button>
        </div>
      </div>

      {/* Success / Error Alerts */}
      {successMessage && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between text-xs text-emerald-800 animate-in fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span className="font-semibold">{successMessage}</span>
          </div>
          <button
            type="button"
            onClick={() => setSuccessMessage(null)}
            className="text-emerald-600 hover:text-emerald-800 font-bold ml-4"
          >
            &times;
          </button>
        </div>
      )}

      {error && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-xl flex items-center justify-between text-xs text-red-800 animate-in fade-in">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
            <span>{error}</span>
          </div>
          <button
            type="button"
            onClick={() => setError(null)}
            className="text-red-600 hover:text-red-800 font-bold ml-4"
          >
            &times;
          </button>
        </div>
      )}

      {subTab === 'records' && (
        <div className="space-y-4">
          {/* Quick Metrics */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
              <span className="text-xs font-semibold text-slate-500 uppercase">Active In-Progress</span>
              <div className="mt-2 text-2xl font-bold text-indigo-600">{activeRecordsCount}</div>
              <span className="text-xs text-slate-400">staff members completing induction</span>
            </div>

            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
              <span className="text-xs font-semibold text-slate-500 uppercase">Inductions Completed</span>
              <div className="mt-2 text-2xl font-bold text-emerald-600">{completedRecordsCount}</div>
              <span className="text-xs text-slate-400">100% compliance certified</span>
            </div>

            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
              <span className="text-xs font-semibold text-slate-500 uppercase">Total Induction Checklists</span>
              <div className="mt-2 text-2xl font-bold text-slate-900">{records.length}</div>
              <span className="text-xs text-slate-400">across teaching & non-teaching staff</span>
            </div>
          </div>

          {/* Filter Bar */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex flex-col md:flex-row gap-3 items-center justify-between">
            <div className="relative w-full md:w-80">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Search staff name, code, designation..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-9 pr-4 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-slate-50/50"
              />
            </div>

            <div className="flex items-center gap-2">
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="px-3 py-2 text-xs border border-slate-200 rounded-lg bg-white text-slate-700"
              >
                <option value="all">All Statuses</option>
                <option value="IN_PROGRESS">In Progress</option>
                <option value="COMPLETED">Completed</option>
                <option value="OVERDUE">Overdue</option>
              </select>

              <select
                value={departmentFilter}
                onChange={(e) => setDepartmentFilter(e.target.value)}
                className="px-3 py-2 text-xs border border-slate-200 rounded-lg bg-white text-slate-700"
              >
                <option value="all">All Departments</option>
                {departments.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Onboarding Records Grid */}
          {filteredRecords.length === 0 ? (
            <div className="p-12 text-center bg-white rounded-xl border border-slate-200 text-slate-500 space-y-2">
              <Layers className="w-10 h-10 mx-auto text-slate-300" />
              <p className="text-sm font-semibold">No onboarding records found.</p>
              <Button type="button" variant="outline" size="sm" onClick={() => setIsInitModalOpen(true)}>
                Initialize Onboarding for Staff
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredRecords.map((record) => {
                return (
                  <div
                    key={record.id}
                    className="bg-white rounded-xl border border-slate-200 shadow-2xs p-5 space-y-4 hover:shadow-xs transition-shadow flex flex-col justify-between"
                  >
                    <div className="space-y-3">
                      <div className="flex items-start justify-between">
                        <div>
                          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-bold">
                            {record.employeeCode}
                          </span>
                          <h3 className="text-sm font-bold text-slate-900 mt-1">{record.staffName}</h3>
                          <p className="text-xs text-indigo-700 font-medium">
                            {record.designation} • {record.departmentName}
                          </p>
                        </div>

                        <span
                          className={`text-[10px] px-2.5 py-0.5 rounded-full font-bold uppercase tracking-wider ${
                            record.status === 'COMPLETED'
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-indigo-100 text-indigo-800'
                          }`}
                        >
                          {(record.status || 'PENDING').replace(/_/g, ' ')}
                        </span>
                      </div>

                      <div className="space-y-1 text-xs text-slate-500">
                        <div className="flex items-center justify-between">
                          <span>Joined:</span>
                          <span className="font-semibold text-slate-700">{record.joiningDate}</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span>Template:</span>
                          <span className="font-semibold text-slate-700">{record.templateName || 'Default'}</span>
                        </div>
                      </div>

                      {/* Progress Bar */}
                      <div className="space-y-1.5 pt-2 border-t border-slate-100">
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-slate-600 font-medium">Checklist Progress:</span>
                          <span className="font-bold text-slate-900">
                            {record.completedTasks} / {record.totalTasks} Tasks ({record.progressPercentage}%)
                          </span>
                        </div>
                        <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                          <div
                            className={`h-2 rounded-full transition-all ${
                              record.progressPercentage === 100 ? 'bg-emerald-600' : 'bg-indigo-600'
                            }`}
                            style={{ width: `${record.progressPercentage}%` }}
                          />
                        </div>
                      </div>
                    </div>

                    <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                      <span className="text-[11px] text-slate-400">
                        Target: {record.targetCompletionDate || '14 Days'}
                      </span>

                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => setSelectedRecord(record)}
                        icon={<ChevronRight className="w-3.5 h-3.5" />}
                      >
                        Manage Tasks
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* TEMPLATES SUB-TAB */}
      {subTab === 'templates' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {templates.map((tmpl) => (
              <div key={tmpl.id} className="bg-white rounded-xl border border-slate-200 shadow-2xs p-5 space-y-4">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900">{tmpl.name}</h3>
                    <span className="text-xs text-indigo-600 font-semibold uppercase">{tmpl.staffType} Faculty</span>
                  </div>
                  <span className="text-xs font-mono bg-slate-100 px-2 py-0.5 rounded font-bold text-slate-700">
                    {tmpl?.tasks?.length || 0} Tasks
                  </span>
                </div>

                <p className="text-xs text-slate-600">{tmpl.description}</p>

                <div className="space-y-2 pt-2 border-t border-slate-100">
                  <span className="text-[11px] font-bold text-slate-700 block">Default Induction Steps:</span>
                  <ul className="space-y-1.5 text-xs text-slate-600">
                    {(tmpl?.tasks || []).map((task, idx) => (
                      <li key={idx} className="flex items-center gap-2">
                        <CheckCircle2 className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
                        <span className="truncate">{task.title}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Task Drawer / Modal */}
      {selectedRecord && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in">
          <div className="bg-white rounded-2xl max-w-2xl w-full p-6 space-y-5 max-h-[90vh] overflow-y-auto shadow-xl">
            <div className="flex items-start justify-between border-b border-slate-100 pb-4">
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-base font-bold text-slate-900">{selectedRecord.staffName}</h2>
                  <span className="text-xs font-mono px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-bold">
                    {selectedRecord.employeeCode}
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-0.5">
                  {selectedRecord.designation} • {selectedRecord.departmentName} • Joined: {selectedRecord.joiningDate}
                </p>
              </div>

              <button
                type="button"
                onClick={() => setSelectedRecord(null)}
                className="text-slate-400 hover:text-slate-600 text-xl font-bold"
              >
                &times;
              </button>
            </div>

            {/* Overall Progress Banner */}
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-slate-800">
                <span>Induction Completion Status</span>
                <span className="text-indigo-600">{selectedRecord.progressPercentage}%</span>
              </div>
              <div className="w-full bg-slate-200 h-2.5 rounded-full overflow-hidden">
                <div
                  className={`h-2.5 rounded-full transition-all ${
                    selectedRecord.progressPercentage === 100 ? 'bg-emerald-600' : 'bg-indigo-600'
                  }`}
                  style={{ width: `${selectedRecord.progressPercentage}%` }}
                />
              </div>
              <div className="flex items-center justify-between text-[11px] text-slate-500">
                <span>{selectedRecord.completedTasks} of {selectedRecord.totalTasks} tasks verified</span>
                <span>Target: {selectedRecord.targetCompletionDate}</span>
              </div>
            </div>

            {/* Tasks Checklist */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-slate-900 text-xs uppercase tracking-wider">
                  Checklist Tasks & Verification
                </h4>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setIsAddTaskOpen(true)}
                  icon={<Plus className="w-3.5 h-3.5" />}
                >
                  Add Task
                </Button>
              </div>

              <div className="divide-y divide-slate-100 border border-slate-200 rounded-xl overflow-hidden">
                {selectedRecord.tasks.map((task) => {
                  const isDone = task.status === 'COMPLETED';
                  return (
                    <div
                      key={task.id}
                      className={`p-3.5 flex items-start justify-between gap-3 transition-colors ${
                        isDone ? 'bg-slate-50/50' : 'hover:bg-slate-50/30'
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <button
                          type="button"
                          disabled={isUpdatingTask}
                          onClick={() => handleToggleTaskStatus(selectedRecord.id, task.id, task.status)}
                          className={`mt-0.5 w-5 h-5 rounded-md border flex items-center justify-center transition-colors ${
                            isDone
                              ? 'bg-emerald-600 border-emerald-600 text-white'
                              : 'border-slate-300 hover:border-indigo-500 bg-white'
                          }`}
                        >
                          {isDone && <CheckCircle2 className="w-4 h-4" />}
                        </button>

                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span
                              className={`text-xs font-bold ${
                                isDone ? 'text-slate-500 line-through' : 'text-slate-900'
                              }`}
                            >
                              {task.title}
                            </span>
                            {task.isMandatory && (
                              <span className="text-[10px] px-1.5 py-0.2 rounded font-bold bg-amber-100 text-amber-800">
                                Mandatory
                              </span>
                            )}
                            <span className="text-[10px] px-1.5 py-0.2 rounded font-semibold bg-slate-100 text-slate-600">
                              {task.category}
                            </span>
                          </div>

                          {task.description && (
                            <p className="text-[11px] text-slate-500">{task.description}</p>
                          )}

                          {isDone && task.completedAt && (
                            <span className="text-[10px] text-emerald-700 block font-medium">
                              Completed: {new Date(task.completedAt).toLocaleDateString()}
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="text-right text-[11px] text-slate-400 shrink-0">
                        <span>Due: {task.dueDate || 'Standard'}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
              <Button
                type="button"
                variant="primary"
                size="sm"
                onClick={() => setSelectedRecord(null)}
              >
                Done
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Add Custom Task Modal */}
      {isAddTaskOpen && selectedRecord && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 space-y-4 shadow-xl text-xs">
            <h3 className="text-sm font-bold text-slate-900">Add Induction Task</h3>
            <p className="text-slate-500">
              Create a custom action item for <strong className="text-slate-800">{selectedRecord.staffName}</strong>.
            </p>

            <form onSubmit={handleAddCustomTask} className="space-y-3">
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Task Title</label>
                <input
                  type="text"
                  value={customTaskTitle}
                  onChange={(e) => setCustomTaskTitle(e.target.value)}
                  placeholder="e.g. Schedule laboratory safety briefing"
                  required
                  className="w-full p-2 border border-slate-200 rounded-lg bg-white"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Category</label>
                <select
                  value={customTaskCategory}
                  onChange={(e) => setCustomTaskCategory(e.target.value)}
                  className="w-full p-2 border border-slate-200 rounded-lg bg-white"
                >
                  <option value="DOCUMENTATION">Documentation & Clearances</option>
                  <option value="IT_SYSTEMS">IT Credentials & Access</option>
                  <option value="FACILITIES">Facilities & Campus Badge</option>
                  <option value="ACADEMIC">Academic / Teaching Induction</option>
                  <option value="COMPLIANCE">HR Compliance & Governance</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Due Date</label>
                  <input
                    type="date"
                    value={customTaskDueDate}
                    onChange={(e) => setCustomTaskDueDate(e.target.value)}
                    required
                    className="w-full p-2 border border-slate-200 rounded-lg bg-white"
                  />
                </div>

                <div className="flex items-center pt-6">
                  <label className="flex items-center gap-2 cursor-pointer font-semibold text-slate-700">
                    <input
                      type="checkbox"
                      checked={customTaskMandatory}
                      onChange={(e) => setCustomTaskMandatory(e.target.checked)}
                      className="rounded text-indigo-600 focus:ring-indigo-500"
                    />
                    <span>Mandatory Task</span>
                  </label>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setIsAddTaskOpen(false)}
                >
                  Cancel
                </Button>
                <Button type="submit" variant="primary" size="sm">
                  Add Task
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Initialize Onboarding Modal */}
      {isInitModalOpen && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 space-y-4 shadow-xl text-xs">
            <h3 className="text-sm font-bold text-slate-900">Start Staff Onboarding Induction</h3>
            <p className="text-slate-500">
              Assign an induction checklist to an existing staff member.
            </p>

            <form onSubmit={handleInitializeOnboarding} className="space-y-3">
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Select Staff Member</label>
                <select
                  value={selectedStaffForInit}
                  onChange={(e) => setSelectedStaffForInit(e.target.value)}
                  required
                  className="w-full p-2 border border-slate-200 rounded-lg bg-white"
                >
                  <option value="">-- Choose Staff Member --</option>
                  {staffList.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.firstName} {s.lastName} ({s.employeeCode} • {s.designation})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Select Template</label>
                <select
                  value={selectedTemplateForInit}
                  onChange={(e) => setSelectedTemplateForInit(e.target.value)}
                  className="w-full p-2 border border-slate-200 rounded-lg bg-white"
                >
                  <option value="">Default (Auto-detect by staff type)</option>
                  {templates.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name} ({t?.tasks?.length || 0} tasks)
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setIsInitModalOpen(false)}
                >
                  Cancel
                </Button>
                <Button type="submit" variant="primary" size="sm">
                  Initialize Checklist
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
