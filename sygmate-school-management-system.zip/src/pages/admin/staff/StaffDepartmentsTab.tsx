import React, { useState } from 'react';
import {
  Building,
  Plus,
  Edit2,
  Trash2,
  Users,
  MapPin,
  FileSpreadsheet,
  AlertCircle,
  CheckCircle2,
  X
} from 'lucide-react';
import { Button } from '../../../components/ui/Button.js';
import { Department } from '../../../types/index.js';

interface StaffDepartmentsTabProps {
  departments: Array<Department & { staffCount: number; teachingCount: number; nonTeachingCount: number }>;
  onCreateDepartment: (payload: Partial<Department>) => Promise<void>;
  onUpdateDepartment: (id: string, payload: Partial<Department>) => Promise<void>;
  onDeleteDepartment: (id: string) => Promise<void>;
  onSelectDepartmentForFilter?: (deptId: string) => void;
  isLoading?: boolean;
}

export const StaffDepartmentsTab: React.FC<StaffDepartmentsTabProps> = ({
  departments,
  onCreateDepartment,
  onUpdateDepartment,
  onDeleteDepartment,
  onSelectDepartmentForFilter,
  isLoading = false
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingDept, setEditingDept] = useState<Department | null>(null);

  // Form states
  const [name, setName] = useState('');
  const [code, setCode] = useState('');
  const [category, setCategory] = useState<'academic' | 'administrative' | 'support' | 'operations'>('administrative');
  const [location, setLocation] = useState('');
  const [budgetCode, setBudgetCode] = useState('');
  const [description, setDescription] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const openCreateModal = () => {
    setEditingDept(null);
    setName('');
    setCode('');
    setCategory('administrative');
    setLocation('');
    setBudgetCode('');
    setDescription('');
    setError(null);
    setIsModalOpen(true);
  };

  const openEditModal = (dept: Department) => {
    setEditingDept(dept);
    setName(dept.name);
    setCode(dept.code);
    setCategory((dept.category as any) || 'administrative');
    setLocation(dept.location || '');
    setBudgetCode(dept.budgetCode || '');
    setDescription(dept.description || '');
    setError(null);
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!name.trim()) {
      setError('Department name is required.');
      return;
    }

    setIsSubmitting(true);
    try {
      if (editingDept) {
        await onUpdateDepartment(editingDept.id, {
          name: name.trim(),
          code: code.trim().toUpperCase(),
          category,
          location: location.trim() || undefined,
          budgetCode: budgetCode.trim() || undefined,
          description: description.trim() || undefined
        });
      } else {
        await onCreateDepartment({
          name: name.trim(),
          code: code.trim().toUpperCase() || `DEP-${name.substring(0, 3).toUpperCase()}`,
          category,
          location: location.trim() || undefined,
          budgetCode: budgetCode.trim() || undefined,
          description: description.trim() || undefined
        });
      }
      setIsModalOpen(false);
    } catch (err: any) {
      setError(err.message || 'Failed to save department.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async (dept: Department & { staffCount: number }) => {
    if (dept.staffCount > 0) {
      alert(`Cannot delete '${dept.name}' because ${dept.staffCount} staff member(s) are actively assigned to it. Please reassign staff first.`);
      return;
    }

    if (window.confirm(`Are you sure you want to delete department '${dept.name}'?`)) {
      try {
        await onDeleteDepartment(dept.id);
      } catch (err: any) {
        alert(err.message || 'Failed to delete department.');
      }
    }
  };

  const getCategoryBadge = (cat?: string) => {
    switch (cat) {
      case 'academic':
        return <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200">Academic Faculty</span>;
      case 'administrative':
        return <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-purple-50 text-purple-700 border border-purple-200">Administrative</span>;
      case 'support':
        return <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-cyan-50 text-cyan-700 border border-cyan-200">Campus Support</span>;
      case 'operations':
        return <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">Operations & Logistics</span>;
      default:
        return <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-slate-100 text-slate-700">General</span>;
    }
  };

  return (
    <div className="space-y-6" id="staff-departments-tab">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-xl border border-slate-200">
        <div>
          <h3 className="text-base font-bold text-slate-900 tracking-tight">
            Organizational Departments & Operational Units
          </h3>
          <p className="text-xs text-slate-500 mt-1">
            Manage institutional departments, location wings, budget codes, and staff assignments
          </p>
        </div>
        <Button
          type="button"
          variant="primary"
          size="sm"
          onClick={openCreateModal}
          icon={<Plus className="w-4 h-4" />}
          id="add-department-btn"
        >
          Add Department
        </Button>
      </div>

      {/* Department Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {departments.map((dept) => (
          <div
            key={dept.id}
            className="bg-white rounded-xl border border-slate-200 p-5 hover:border-slate-300 transition-all flex flex-col justify-between"
            id={`dept-card-${dept.id}`}
          >
            <div>
              <div className="flex items-start justify-between gap-2">
                <div>
                  <span className="text-[10px] font-mono font-semibold text-slate-500 uppercase tracking-wider">
                    {dept.code}
                  </span>
                  <h4 className="text-sm font-bold text-slate-900 mt-0.5">
                    {dept.name}
                  </h4>
                </div>
                {getCategoryBadge(dept.category)}
              </div>

              {dept.description && (
                <p className="text-xs text-slate-600 mt-2 line-clamp-2">
                  {dept.description}
                </p>
              )}

              <div className="mt-4 pt-3 border-t border-slate-100 space-y-2 text-xs">
                {dept.location && (
                  <div className="flex items-center gap-1.5 text-slate-600">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="truncate">{dept.location}</span>
                  </div>
                )}
                {dept.budgetCode && (
                  <div className="flex items-center gap-1.5 text-slate-600">
                    <FileSpreadsheet className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span>Cost Center: <strong className="font-mono text-slate-700">{dept.budgetCode}</strong></span>
                  </div>
                )}
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <Users className="w-4 h-4 text-indigo-600" />
                <button
                  type="button"
                  onClick={() => onSelectDepartmentForFilter && onSelectDepartmentForFilter(dept.id)}
                  className="text-xs font-bold text-indigo-700 hover:underline"
                >
                  {dept.staffCount} Staff Member{dept.staffCount !== 1 ? 's' : ''}
                </button>
              </div>

              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() => openEditModal(dept)}
                  className="p-1.5 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 transition-colors"
                  title="Edit Department"
                >
                  <Edit2 className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() => handleDelete(dept)}
                  className="p-1.5 rounded-lg border border-red-200 text-red-600 hover:bg-red-50 transition-colors"
                  title="Delete Department"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Create / Edit Department Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50/80">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-indigo-50 text-indigo-700 border border-indigo-200">
                  <Building className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-semibold text-slate-900">
                    {editingDept ? `Edit Department: ${editingDept.name}` : 'Create Department / Unit'}
                  </h3>
                  <p className="text-xs text-slate-500">
                    Institutional Hierarchy Configuration
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              {error && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-lg flex items-start gap-2 text-xs text-red-700">
                  <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                  <span>{error}</span>
                </div>
              )}

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Department Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="E.g., Department of Student Counseling"
                  required
                  className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Department Code <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={code}
                    onChange={(e) => setCode(e.target.value.toUpperCase())}
                    placeholder="E.g., DEP-COU"
                    required
                    className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Classification Category <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as any)}
                    className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                  >
                    <option value="academic">Academic Faculty</option>
                    <option value="administrative">Administrative Unit</option>
                    <option value="support">Campus & Student Support</option>
                    <option value="operations">Operations & Logistics</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Campus Location / Wing
                  </label>
                  <input
                    type="text"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    placeholder="E.g., Student Center, Room 204"
                    className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Financial Budget Code
                  </label>
                  <input
                    type="text"
                    value={budgetCode}
                    onChange={(e) => setBudgetCode(e.target.value)}
                    placeholder="E.g., CC-STU-44"
                    className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Description & Scope
                </label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  rows={2}
                  placeholder="Primary operational responsibilities and scope of this department..."
                  className="w-full text-xs rounded-lg border border-slate-300 p-2.5 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 resize-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-200">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setIsModalOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  variant="primary"
                  size="sm"
                  isLoading={isSubmitting}
                >
                  {editingDept ? 'Update Department' : 'Create Department'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
