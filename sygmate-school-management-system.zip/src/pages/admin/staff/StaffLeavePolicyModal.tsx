import React, { useState, useEffect } from 'react';
import {
  X,
  ShieldCheck,
  Building,
  Briefcase,
  Layers,
  Calendar,
  AlertCircle,
  FileText,
  Clock,
  CheckCircle2
} from 'lucide-react';
import { Button } from '../../../components/ui/Button.js';
import {
  StaffLeavePolicy,
  CreateStaffLeavePolicyPayload,
  LeaveType,
  Department,
  Designation
} from '../../../types/index.js';

interface StaffLeavePolicyModalProps {
  isOpen: boolean;
  onClose: () => void;
  policy: StaffLeavePolicy | null;
  leaveTypes: LeaveType[];
  departments: Department[];
  designations: Designation[];
  onSave: (payload: CreateStaffLeavePolicyPayload, policyId?: string) => Promise<void>;
}

export const StaffLeavePolicyModal: React.FC<StaffLeavePolicyModalProps> = ({
  isOpen,
  onClose,
  policy,
  leaveTypes,
  departments,
  designations,
  onSave
}) => {
  const [name, setName] = useState<string>(policy?.name || '');
  const [code, setCode] = useState<string>(policy?.code || '');
  const [leaveTypeId, setLeaveTypeId] = useState<string>(policy?.leaveTypeId || leaveTypes?.[0]?.id || '');
  const [applicableStaffCategory, setApplicableStaffCategory] = useState<string>(policy?.applicableStaffCategory || 'ALL');
  const [applicableDepartmentId, setApplicableDepartmentId] = useState<string>(policy?.applicableDepartmentId || 'ALL');
  const [applicableDesignationId, setApplicableDesignationId] = useState<string>(policy?.applicableDesignationId || 'ALL');
  const [entitlementDays, setEntitlementDays] = useState<number>(policy?.entitlementDays ?? 12);
  const [paidType, setPaidType] = useState<'PAID' | 'UNPAID' | 'HALF_PAY'>(policy?.paidType || 'PAID');
  const [carryForwardAllowed, setCarryForwardAllowed] = useState<boolean>(policy?.carryForwardAllowed ?? false);
  const [maxCarryForwardDays, setMaxCarryForwardDays] = useState<number>(policy?.maxCarryForwardDays ?? 5);
  const [carryForwardExpiryMonths, setCarryForwardExpiryMonths] = useState<number | undefined>(policy?.carryForwardExpiryMonths);
  const [minNoticeDays, setMinNoticeDays] = useState<number>(policy?.minNoticeDays ?? 2);
  const [maxConsecutiveDays, setMaxConsecutiveDays] = useState<number>(policy?.maxConsecutiveDays ?? 14);
  const [requiresAttachment, setRequiresAttachment] = useState<boolean>(policy?.requiresAttachment ?? false);
  const [attachmentMandatoryAboveDays, setAttachmentMandatoryAboveDays] = useState<number | undefined>(policy?.attachmentMandatoryAboveDays ?? 2);
  const [approvalHierarchy, setApprovalHierarchy] = useState<'SINGLE' | 'TWO_TIER' | 'THREE_TIER'>(policy?.approvalHierarchy || 'SINGLE');
  const [allowNegativeBalance, setAllowNegativeBalance] = useState<boolean>(policy?.allowNegativeBalance ?? false);
  const [reservePendingBalance, setReservePendingBalance] = useState<boolean>(policy?.reservePendingBalance ?? true);
  const [priority, setPriority] = useState<number>(policy?.priority ?? 4);
  const [notes, setNotes] = useState<string>(policy?.notes || '');
  const [isActive, setIsActive] = useState<boolean>(policy?.isActive ?? true);

  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (policy) {
      setName(policy.name || '');
      setCode(policy.code || '');
      setLeaveTypeId(policy.leaveTypeId || leaveTypes?.[0]?.id || '');
      setApplicableStaffCategory(policy.applicableStaffCategory || 'ALL');
      setApplicableDepartmentId(policy.applicableDepartmentId || 'ALL');
      setApplicableDesignationId(policy.applicableDesignationId || 'ALL');
      setEntitlementDays(policy.entitlementDays ?? 12);
      setPaidType(policy.paidType || 'PAID');
      setCarryForwardAllowed(policy.carryForwardAllowed ?? false);
      setMaxCarryForwardDays(policy.maxCarryForwardDays ?? 5);
      setCarryForwardExpiryMonths(policy.carryForwardExpiryMonths);
      setMinNoticeDays(policy.minNoticeDays ?? 2);
      setMaxConsecutiveDays(policy.maxConsecutiveDays ?? 14);
      setRequiresAttachment(policy.requiresAttachment ?? false);
      setAttachmentMandatoryAboveDays(policy.attachmentMandatoryAboveDays ?? 2);
      setApprovalHierarchy(policy.approvalHierarchy || 'SINGLE');
      setAllowNegativeBalance(policy.allowNegativeBalance ?? false);
      setReservePendingBalance(policy.reservePendingBalance ?? true);
      setPriority(policy.priority ?? 4);
      setNotes(policy.notes || '');
      setIsActive(policy.isActive ?? true);
    }
  }, [policy, leaveTypes]);

  // Auto-generate code when name changes if new
  useEffect(() => {
    if (!policy && name) {
      setCode(name.replace(/[^a-zA-Z0-9]/g, '_').toUpperCase().substring(0, 16));
    }
  }, [name, policy]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Policy name is required.');
      return;
    }
    if (!code.trim()) {
      setError('Policy code is required.');
      return;
    }
    if (!leaveTypeId) {
      setError('Leave category reference is required.');
      return;
    }
    if (entitlementDays < 0) {
      setError('Entitlement days must be zero or positive.');
      return;
    }

    setIsSubmitting(true);
    setError(null);

    try {
      await onSave(
        {
          name: name.trim(),
          code: code.trim().toUpperCase(),
          leaveTypeId,
          applicableStaffCategory: applicableStaffCategory as any,
          applicableDepartmentId: applicableDepartmentId !== 'ALL' ? applicableDepartmentId : undefined,
          applicableDesignationId: applicableDesignationId !== 'ALL' ? applicableDesignationId : undefined,
          entitlementDays,
          paidType,
          carryForwardAllowed,
          maxCarryForwardDays: carryForwardAllowed ? maxCarryForwardDays : 0,
          carryForwardExpiryMonths: carryForwardAllowed ? carryForwardExpiryMonths : undefined,
          minNoticeDays,
          maxConsecutiveDays,
          requiresAttachment,
          attachmentMandatoryAboveDays: requiresAttachment ? attachmentMandatoryAboveDays : undefined,
          approvalHierarchy,
          allowNegativeBalance,
          reservePendingBalance,
          priority,
          notes: notes.trim() || undefined,
          isActive
        },
        policy?.id
      );
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to save leave policy.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div
      id="staff-leave-policy-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto"
    >
      <div className="relative w-full max-w-2xl bg-slate-900 border border-white/10 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-800/80 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white tracking-tight">
                {policy ? 'Edit Staff Leave Policy' : 'Create Staff Leave Policy'}
              </h2>
              <p className="text-xs text-slate-400">
                Institutional entitlement rules, carry-forward bounds, and approval hierarchy
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6 max-h-[80vh] overflow-y-auto">
          {error && (
            <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/20 flex items-start gap-3 text-rose-300 text-sm">
              <AlertCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {/* Basic Info */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                Policy Name *
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Teaching Staff Annual Casual Policy"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800/80 border border-white/10 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
                required
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                Policy Code *
              </label>
              <input
                type="text"
                value={code}
                onChange={(e) => setCode(e.target.value.toUpperCase())}
                placeholder="e.g. POL_TEACH_CASUAL"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800/80 border border-white/10 text-white text-sm font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                Leave Type Category *
              </label>
              <select
                value={leaveTypeId}
                onChange={(e) => setLeaveTypeId(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800/80 border border-white/10 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
                required
              >
                {leaveTypes.map((lt) => (
                  <option key={lt.id} value={lt.id}>
                    {lt.name} ({lt.isPaid === false ? 'Unpaid' : 'Paid'})
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                Compensation Type *
              </label>
              <select
                value={paidType}
                onChange={(e) => setPaidType(e.target.value as any)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800/80 border border-white/10 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
              >
                <option value="PAID">Paid Leave (Full Pay)</option>
                <option value="HALF_PAY">Half Pay Leave</option>
                <option value="UNPAID">Unpaid Leave (Loss of Pay)</option>
              </select>
            </div>
          </div>

          {/* Applicability Scope */}
          <div className="p-4 rounded-xl bg-slate-800/40 border border-white/5 space-y-4">
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
              <Layers className="w-4 h-4 text-indigo-400" />
              Target Eligibility & Scope Hierarchy
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] font-medium text-slate-400 mb-1">
                  Staff Category
                </label>
                <select
                  value={applicableStaffCategory}
                  onChange={(e) => setApplicableStaffCategory(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-xs focus:outline-none focus:ring-1 focus:ring-indigo-500"
                >
                  <option value="ALL">All Categories</option>
                  <option value="teaching">Teaching Staff</option>
                  <option value="administrative">Administrative Staff</option>
                  <option value="support">Support Staff</option>
                  <option value="operational">Operational Staff</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-medium text-slate-400 mb-1">
                  Department
                </label>
                <select
                  value={applicableDepartmentId}
                  onChange={(e) => setApplicableDepartmentId(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-xs focus:outline-none focus:ring-1 focus:ring-indigo-500"
                >
                  <option value="ALL">All Departments</option>
                  {departments.map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-medium text-slate-400 mb-1">
                  Designation
                </label>
                <select
                  value={applicableDesignationId}
                  onChange={(e) => setApplicableDesignationId(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-xs focus:outline-none focus:ring-1 focus:ring-indigo-500"
                >
                  <option value="ALL">All Designations</option>
                  {designations.map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.title}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            <p className="text-[11px] text-slate-500">
              Matching priority: Specific Designation (1) &gt; Department (2) &gt; Category (3) &gt; School Default (4).
            </p>
          </div>

          {/* Entitlement & Carry-Forward */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                Annual Entitlement (Days) *
              </label>
              <input
                type="number"
                min="0"
                step="0.5"
                value={entitlementDays}
                onChange={(e) => setEntitlementDays(parseFloat(e.target.value) || 0)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800/80 border border-white/10 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
                required
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                Approval Hierarchy *
              </label>
              <select
                value={approvalHierarchy}
                onChange={(e) => setApprovalHierarchy(e.target.value as any)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800/80 border border-white/10 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
              >
                <option value="SINGLE">Single-Tier (HR or Administrator Approval)</option>
                <option value="TWO_TIER">Two-Tier (Dept Head Recommends &rarr; HR Final Approval)</option>
              </select>
            </div>
          </div>

          {/* Carry-Forward Section */}
          <div className="p-4 rounded-xl bg-slate-800/40 border border-white/5 space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={carryForwardAllowed}
                  onChange={(e) => setCarryForwardAllowed(e.target.checked)}
                  className="rounded border-white/20 bg-slate-800 text-indigo-500 focus:ring-indigo-500 w-4 h-4"
                />
                Allow Unused Balance Carry-Forward to Next Session
              </label>
            </div>

            {carryForwardAllowed && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
                <div>
                  <label className="block text-[11px] font-medium text-slate-400 mb-1">
                    Max Carry-Forward Days
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="60"
                    value={maxCarryForwardDays}
                    onChange={(e) => setMaxCarryForwardDays(parseInt(e.target.value) || 0)}
                    className="w-full px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-xs focus:outline-none focus:ring-1 focus:ring-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-medium text-slate-400 mb-1">
                    Expiry Months in New Session (Optional)
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="12"
                    value={carryForwardExpiryMonths || ''}
                    onChange={(e) => setCarryForwardExpiryMonths(e.target.value ? parseInt(e.target.value) : undefined)}
                    placeholder="e.g. 6 months"
                    className="w-full px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-xs focus:outline-none focus:ring-1 focus:ring-indigo-500"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Rules & Constraints */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                Min Notice Period (Days in Advance)
              </label>
              <input
                type="number"
                min="0"
                value={minNoticeDays}
                onChange={(e) => setMinNoticeDays(parseInt(e.target.value) || 0)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800/80 border border-white/10 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                Max Consecutive Working Days Limit
              </label>
              <input
                type="number"
                min="1"
                value={maxConsecutiveDays}
                onChange={(e) => setMaxConsecutiveDays(parseInt(e.target.value) || 14)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800/80 border border-white/10 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50"
              />
            </div>
          </div>

          {/* Attachment and Negative Balance Checkboxes */}
          <div className="space-y-2">
            <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={requiresAttachment}
                onChange={(e) => setRequiresAttachment(e.target.checked)}
                className="rounded border-white/20 bg-slate-800 text-indigo-500 focus:ring-indigo-500 w-4 h-4"
              />
              Require Official Supporting Document (e.g. Medical Certificate)
            </label>

            {requiresAttachment && (
              <div className="pl-6 pt-1">
                <span className="text-[11px] text-slate-400 mr-2">Mandatory if duration exceeds:</span>
                <input
                  type="number"
                  min="0"
                  value={attachmentMandatoryAboveDays ?? 2}
                  onChange={(e) => setAttachmentMandatoryAboveDays(parseInt(e.target.value) || 0)}
                  className="w-20 px-2 py-1 rounded bg-slate-800 border border-white/10 text-white text-xs text-center inline-block"
                />
                <span className="text-[11px] text-slate-400 ml-2">working days</span>
              </div>
            )}

            <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={allowNegativeBalance}
                onChange={(e) => setAllowNegativeBalance(e.target.checked)}
                className="rounded border-white/20 bg-slate-800 text-indigo-500 focus:ring-indigo-500 w-4 h-4"
              />
              Permit Negative Balance (Advance Leave Overdraft)
            </label>

            <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={reservePendingBalance}
                onChange={(e) => setReservePendingBalance(e.target.checked)}
                className="rounded border-white/20 bg-slate-800 text-indigo-500 focus:ring-indigo-500 w-4 h-4"
              />
              Hold Pending Applications Against Available Balance (Anti-Collision)
            </label>

            <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={isActive}
                onChange={(e) => setIsActive(e.target.checked)}
                className="rounded border-white/20 bg-slate-800 text-indigo-500 focus:ring-indigo-500 w-4 h-4"
              />
              Policy is Currently Active
            </label>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              Policy Notes / Guidelines
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Institutional guidelines or terms..."
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800/80 border border-white/10 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50 resize-none"
            />
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={isSubmitting}
              className="bg-indigo-600 hover:bg-indigo-500 text-white"
            >
              {isSubmitting ? 'Saving...' : policy ? 'Update Policy' : 'Create Policy'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};
