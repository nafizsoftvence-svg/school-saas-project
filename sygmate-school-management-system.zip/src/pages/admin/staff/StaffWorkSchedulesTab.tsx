import React, { useState, useEffect, useCallback } from 'react';
import {
  Clock,
  Plus,
  Search,
  Filter,
  Layers,
  Building,
  Briefcase,
  User,
  Shield,
  Edit2,
  Trash2,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Sparkles,
  Calendar,
  HelpCircle,
  Eye,
  RefreshCw
} from 'lucide-react';
import { Button } from '../../../components/ui/Button.js';
import { api } from '../../../services/api.js';
import {
  StaffWorkSchedule,
  StaffWorkScheduleScope,
  StaffProfile,
  Department,
  Designation,
  StaffEffectiveSchedule,
  CreateStaffSchedulePayload,
  UpdateStaffSchedulePayload
} from '../../../types/index.js';
import { StaffScheduleFormModal } from './StaffScheduleFormModal.js';

interface StaffWorkSchedulesTabProps {
  staffList: StaffProfile[];
  departments: Department[];
  designations: Designation[];
}

export const StaffWorkSchedulesTab: React.FC<StaffWorkSchedulesTabProps> = ({
  staffList,
  departments,
  designations
}) => {
  const [schedules, setSchedules] = useState<StaffWorkSchedule[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Filters
  const [selectedScope, setSelectedScope] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Form Modal
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [scheduleToEdit, setScheduleToEdit] = useState<StaffWorkSchedule | null>(null);

  // Effective Schedule Tester / Simulator
  const [simStaffId, setSimStaffId] = useState<string>(staffList?.[0]?.id || '');
  const [simDate, setSimDate] = useState<string>(() => new Date().toISOString().split('T')[0]);
  const [simResult, setSimResult] = useState<StaffEffectiveSchedule | null>(null);
  const [simLoading, setSimLoading] = useState<boolean>(false);

  // Auto-dismiss notifications
  useEffect(() => {
    if (successMessage) {
      const timer = setTimeout(() => setSuccessMessage(null), 4000);
      return () => clearTimeout(timer);
    }
  }, [successMessage]);

  const fetchSchedules = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await api.staff.schedules.getAll({
        scope: selectedScope !== 'ALL' ? selectedScope : undefined,
        search: searchQuery || undefined
      });
      const schedulesList = Array.isArray((data as any)?.data)
        ? (data as any).data
        : Array.isArray(data)
        ? data
        : [];
      setSchedules(schedulesList);
    } catch (err: any) {
      setError(err.message || 'Failed to load work schedules.');
    } finally {
      setLoading(false);
    }
  }, [selectedScope, searchQuery]);

  useEffect(() => {
    fetchSchedules();
  }, [fetchSchedules]);

  // Handle Create or Update
  const handleSaveSchedule = async (
    payload: CreateStaffSchedulePayload | UpdateStaffSchedulePayload,
    scheduleId?: string
  ) => {
    if (scheduleId) {
      await api.staff.schedules.update(scheduleId, payload as UpdateStaffSchedulePayload);
      setSuccessMessage('Work schedule successfully updated.');
    } else {
      await api.staff.schedules.create(payload as CreateStaffSchedulePayload);
      setSuccessMessage('New work schedule successfully created and activated.');
    }
    fetchSchedules();
  };

  // Handle Delete
  const handleDeleteSchedule = async (schedule: StaffWorkSchedule) => {
    if (schedule.scope === 'SCHOOL_DEFAULT') {
      alert('The School Default work schedule is foundational and cannot be deleted.');
      return;
    }

    if (!confirm(`Are you sure you want to delete the schedule "${schedule.name}"?`)) {
      return;
    }

    try {
      await api.staff.schedules.delete(schedule.id);
      setSuccessMessage('Work schedule deleted successfully.');
      fetchSchedules();
    } catch (err: any) {
      setError(err.message || 'Failed to delete work schedule.');
    }
  };

  // Run Simulator
  const handleSimulate = async () => {
    if (!simStaffId) return;
    setSimLoading(true);
    try {
      const res = await api.staff.schedules.getEffective(simStaffId, simDate);
      setSimResult((res as any)?.data || res);
    } catch (err: any) {
      console.error('Failed to simulate effective schedule:', err);
    } finally {
      setSimLoading(false);
    }
  };

  useEffect(() => {
    if (simStaffId) {
      handleSimulate();
    }
  }, [simStaffId, simDate]);

  const scopeBadges: Record<
    StaffWorkScheduleScope,
    { label: string; priority: string; style: string; icon: React.ReactNode }
  > = {
    INDIVIDUAL: {
      label: 'Individual Staff',
      priority: 'Priority 1 (Highest)',
      style: 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30',
      icon: <User className="w-3.5 h-3.5" />
    },
    DESIGNATION: {
      label: 'Designation Role',
      priority: 'Priority 2',
      style: 'bg-indigo-500/10 text-indigo-300 border-indigo-500/30',
      icon: <Briefcase className="w-3.5 h-3.5" />
    },
    DEPARTMENT: {
      label: 'Department',
      priority: 'Priority 3',
      style: 'bg-cyan-500/10 text-cyan-300 border-cyan-500/30',
      icon: <Building className="w-3.5 h-3.5" />
    },
    STAFF_TYPE: {
      label: 'Staff Category',
      priority: 'Priority 4',
      style: 'bg-amber-500/10 text-amber-300 border-amber-500/30',
      icon: <Layers className="w-3.5 h-3.5" />
    },
    SCHOOL_DEFAULT: {
      label: 'School Default',
      priority: 'Priority 5 (Fallback)',
      style: 'bg-purple-500/10 text-purple-300 border-purple-500/30',
      icon: <Shield className="w-3.5 h-3.5" />
    }
  };

  return (
    <div id="staff-work-schedules-tab" className="space-y-6">
      {/* Notifications */}
      {successMessage && (
        <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center gap-3 text-emerald-300 text-sm">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <span>{successMessage}</span>
        </div>
      )}

      {error && (
        <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/20 flex items-start gap-3 text-rose-300 text-sm">
          <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
          <span>{error}</span>
        </div>
      )}

      {/* Header & Hierarchy Explanation */}
      <div className="p-6 rounded-2xl bg-slate-900 border border-white/10 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-bold text-white tracking-tight flex items-center gap-2">
              <Clock className="w-5 h-5 text-indigo-400" />
              Staff Work Schedules & Shift Hierarchy
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Multi-tiered schedule precedence engine: Individual &gt; Designation &gt; Department &gt; Staff Category &gt; School Default
            </p>
          </div>

          <div className="flex items-center gap-3">
            <Button
              variant="outline"
              size="sm"
              onClick={fetchSchedules}
              className="border-white/10 text-slate-300 hover:bg-white/5 flex items-center gap-1.5"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              Refresh
            </Button>
            <Button
              onClick={() => {
                setScheduleToEdit(null);
                setIsModalOpen(true);
              }}
              className="bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              Create Work Schedule
            </Button>
          </div>
        </div>

        {/* Hierarchy Legend */}
        <div className="grid grid-cols-1 sm:grid-cols-5 gap-2 pt-2 border-t border-white/5">
          {(
            [
              { scope: 'INDIVIDUAL', p: '1. Individual' },
              { scope: 'DESIGNATION', p: '2. Designation' },
              { scope: 'DEPARTMENT', p: '3. Department' },
              { scope: 'STAFF_TYPE', p: '4. Staff Category' },
              { scope: 'SCHOOL_DEFAULT', p: '5. School Default' }
            ] as const
          ).map((item) => (
            <div
              key={item.scope}
              className={`p-2 rounded-xl border text-center text-xs ${scopeBadges[item.scope].style}`}
            >
              <span className="font-bold block">{item.p}</span>
              <span className="text-[10px] opacity-80">{scopeBadges[item.scope].priority}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Simulator / Tester Widget */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-slate-900 to-indigo-950/40 border border-indigo-500/20 space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-indigo-300 uppercase tracking-wider flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-amber-400" />
            Live Schedule Resolution Tester & Simulator
          </span>
          <span className="text-[11px] text-slate-400">
            Verify which duty hours and hierarchy rule apply to a staff member on any given day
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1">
              Select Staff
            </label>
            <select
              value={simStaffId}
              onChange={(e) => setSimStaffId(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
            >
              {staffList.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.displayName || `${s.firstName} ${s.lastName}`} ({s.employeeCode} - {s.departmentName || s.staffType})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1">
              Test Date
            </label>
            <input
              type="date"
              value={simDate}
              onChange={(e) => setSimDate(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
            >
            </input>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1">
              Resolution Provenance
            </label>
            <div className="p-2 bg-slate-950/80 border border-white/10 rounded-xl text-xs flex items-center justify-between">
              {simLoading ? (
                <span className="text-slate-400">Resolving...</span>
              ) : simResult ? (
                <>
                  <div>
                    <strong className="text-white">
                      {simResult.isWorkingDay
                        ? `${simResult.startTime} - ${simResult.endTime}`
                        : 'Off Duty (Non-working day)'}
                    </strong>
                    <span className="text-[10px] text-indigo-300 block">
                      Rule: {simResult.scheduleName}
                    </span>
                  </div>
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                      scopeBadges[simResult.scope]?.style || 'bg-slate-800'
                    }`}
                  >
                    {simResult.scope}
                  </span>
                </>
              ) : (
                <span className="text-slate-500">No rule resolved</span>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-2xl bg-slate-900 border border-white/10">
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-slate-400" />
          <select
            value={selectedScope}
            onChange={(e) => setSelectedScope(e.target.value)}
            className="px-3 py-1.5 bg-slate-950 border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
          >
            <option value="ALL">All Schedule Scopes</option>
            <option value="INDIVIDUAL">Individual Staff (Priority 1)</option>
            <option value="DESIGNATION">Designation Role (Priority 2)</option>
            <option value="DEPARTMENT">Department (Priority 3)</option>
            <option value="STAFF_TYPE">Staff Category (Priority 4)</option>
            <option value="SCHOOL_DEFAULT">School Default (Priority 5)</option>
          </select>
        </div>

        <div className="relative">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search schedule name or target..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-64 pl-8 pr-3 py-1.5 bg-slate-950 border border-white/10 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
          />
        </div>
      </div>

      {/* Schedules List / Cards */}
      <div className="space-y-4">
        {loading ? (
          <div className="p-12 text-center text-slate-400">
            <RefreshCw className="w-6 h-6 animate-spin mx-auto text-indigo-400 mb-2" />
            Loading schedules...
          </div>
        ) : schedules.length === 0 ? (
          <div className="p-12 text-center text-slate-400 bg-slate-900 rounded-2xl border border-white/10">
            No work schedules found.
          </div>
        ) : (
          schedules.map((schedule) => {
            const badge = scopeBadges[schedule.scope];

            return (
              <div
                key={schedule.id}
                className="p-5 rounded-2xl bg-slate-900 border border-white/10 hover:border-white/20 transition-all shadow-lg space-y-4"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-slate-800 border border-white/10 flex items-center justify-center text-indigo-400">
                      <Clock className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-bold text-white text-base">{schedule.name}</h3>
                        <span
                          className={`px-2.5 py-0.5 rounded-lg text-[10px] font-bold border flex items-center gap-1 ${badge.style}`}
                        >
                          {badge.icon}
                          {badge.label} • {badge.priority}
                        </span>
                        {schedule.isActive ? (
                          <span className="px-2 py-0.5 rounded-md bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[10px] font-bold">
                            Active
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-md bg-slate-800 text-slate-400 border border-white/10 text-[10px] font-bold">
                            Inactive
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-400 mt-0.5">
                        {schedule.notes || 'Configured shift and attendance policy'}
                      </p>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setScheduleToEdit(schedule);
                        setIsModalOpen(true);
                      }}
                      className="border-white/10 text-slate-300 hover:bg-white/5 text-xs flex items-center gap-1"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                      Edit
                    </Button>
                    {schedule.scope !== 'SCHOOL_DEFAULT' && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleDeleteSchedule(schedule)}
                        className="border-rose-500/20 text-rose-400 hover:bg-rose-500/10 text-xs flex items-center gap-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        Delete
                      </Button>
                    )}
                  </div>
                </div>

                {/* Days Pills Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-7 gap-2 pt-2 border-t border-white/5">
                  {(schedule.days || []).map((day) => (
                    <div
                      key={day.dayOfWeek}
                      className={`p-2.5 rounded-xl border text-center text-xs ${
                        day.isWorkingDay
                          ? 'bg-slate-950/70 border-white/10'
                          : 'bg-slate-950/20 border-white/5 opacity-50'
                      }`}
                    >
                      <span className="font-bold text-[11px] text-slate-300 block mb-0.5">
                        {day.dayName.substring(0, 3)}
                      </span>
                      {day.isWorkingDay ? (
                        <>
                          <span className="text-[11px] font-semibold text-emerald-400 block font-mono">
                            {day.startTime} - {day.endTime}
                          </span>
                          {day.breakMinutes ? (
                            <span className="text-[10px] text-slate-400 block">
                              {day.breakMinutes}m break
                            </span>
                          ) : null}
                        </>
                      ) : (
                        <span className="text-[10px] text-slate-500 italic">Off Duty</span>
                      )}
                    </div>
                  ))}
                </div>

                {/* Scope Target & Validity */}
                <div className="flex flex-wrap items-center justify-between text-xs text-slate-400 pt-1">
                  <div>
                    {schedule.scope === 'INDIVIDUAL' && (
                      <span>
                        Target Staff: <strong className="text-white">{schedule.staffName}</strong> (
                        {schedule.employeeCode})
                      </span>
                    )}
                    {schedule.scope === 'DEPARTMENT' && (
                      <span>
                        Target Department: <strong className="text-white">{schedule.departmentName}</strong>
                      </span>
                    )}
                    {schedule.scope === 'DESIGNATION' && (
                      <span>
                        Target Designation: <strong className="text-white">{schedule.designationTitle}</strong>
                      </span>
                    )}
                    {schedule.scope === 'STAFF_TYPE' && (
                      <span>
                        Target Category: <strong className="text-white capitalize">{schedule.staffType}</strong>
                      </span>
                    )}
                    {schedule.scope === 'SCHOOL_DEFAULT' && (
                      <span>School-wide fallback baseline for all institutional personnel</span>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    <Calendar className="w-3.5 h-3.5 text-slate-500" />
                    <span>
                      Effective: <span className="text-slate-300 font-mono">{schedule.effectiveFrom}</span>
                      {schedule.effectiveTo ? (
                        <>
                          {' '}
                          to <span className="text-slate-300 font-mono">{schedule.effectiveTo}</span>
                        </>
                      ) : (
                        ' onwards'
                      )}
                    </span>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Form Modal */}
      <StaffScheduleFormModal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setScheduleToEdit(null);
        }}
        scheduleToEdit={scheduleToEdit}
        staffList={staffList}
        departments={departments}
        designations={designations}
        onSave={handleSaveSchedule}
      />
    </div>
  );
};
