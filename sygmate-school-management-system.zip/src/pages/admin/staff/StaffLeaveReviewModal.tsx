import React, { useState, useEffect } from 'react';
import {
  X,
  FileCheck,
  Calendar,
  AlertCircle,
  Building,
  User,
  CheckCircle2,
  XCircle,
  Clock,
  ShieldAlert,
  Sliders,
  Paperclip,
  ExternalLink,
  Info
} from 'lucide-react';
import { Button } from '../../../components/ui/Button.js';
import {
  LeaveApplication,
  ReviewStaffLeavePayload,
  StaffLeaveBalance
} from '../../../types/index.js';
import { api } from '../../../services/api.js';

interface StaffLeaveReviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  application: LeaveApplication | null;
  currentUserId?: string;
  onReview: (id: string, payload: ReviewStaffLeavePayload) => Promise<void>;
}

export const StaffLeaveReviewModal: React.FC<StaffLeaveReviewModalProps> = ({
  isOpen,
  onClose,
  application,
  currentUserId,
  onReview
}) => {
  // Self-approval check
  const isSelfApplication = Boolean(
    currentUserId &&
      application &&
      (application.userId === currentUserId ||
        (application as any).applicantId === currentUserId)
  );

  const [decision, setDecision] = useState<'APPROVED' | 'REJECTED'>('APPROVED');
  const [adminRemarks, setAdminRemarks] = useState<string>('');
  const [rejectionReason, setRejectionReason] = useState<string>('');
  const [allowBalanceOverride, setAllowBalanceOverride] = useState<boolean>(false);
  const [overrideReason, setOverrideReason] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // Live balance check
  const [staffBalance, setStaffBalance] = useState<StaffLeaveBalance | null>(null);
  const [loadingBalance, setLoadingBalance] = useState<boolean>(false);

  useEffect(() => {
    if (!isOpen || !application?.staffId || !application?.leaveTypeId) return;
    let active = true;
    const fetchBalance = async () => {
      setLoadingBalance(true);
      try {
        const balances = await api.staff.leaves.getStaffBalances(application.staffId!);
        if (active) {
          const balancesList = Array.isArray(balances) ? balances : (balances as any)?.data || [];
          const match = balancesList.find((b: any) => b.leaveTypeId === application.leaveTypeId) || null;
          setStaffBalance(match);
        }
      } catch (err) {
        console.warn('Could not fetch staff balance for review modal:', err);
      } finally {
        if (active) setLoadingBalance(false);
      }
    };
    fetchBalance();
    return () => {
      active = false;
    };
  }, [isOpen, application?.staffId, application?.leaveTypeId]);

  if (!isOpen || !application) return null;

  const workingDays = application.workingDays !== undefined ? application.workingDays : application.totalDays || 1;
  const isMultiTier = application.totalApprovalTiers && application.totalApprovalTiers > 1;
  const currentTier = application.currentApprovalTier || 1;
  const isFinalTier = currentTier >= (application.totalApprovalTiers || 1);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (isSelfApplication) {
      setError('Institutional Policy: Approvers are strictly forbidden from adjudicating their own leave applications.');
      return;
    }

    if (decision === 'REJECTED' && (!rejectionReason.trim() || rejectionReason.trim().length < 5)) {
      setError('An official rejection reason (minimum 5 characters) is required when declining a leave request.');
      return;
    }

    if (decision === 'APPROVED' && staffBalance && workingDays > staffBalance.remainingDays && !allowBalanceOverride) {
      setError(`Cannot approve: Requested ${workingDays} days exceeds current remaining balance (${staffBalance.remainingDays} days). Please enable Administrative Balance Override if authorized.`);
      return;
    }

    setIsSubmitting(true);
    setError(null);

    try {
      await onReview(application.id, {
        status: decision,
        adminRemarks: adminRemarks.trim() || undefined,
        rejectionReason: decision === 'REJECTED' ? rejectionReason.trim() : undefined,
        allowBalanceOverride: decision === 'APPROVED' ? allowBalanceOverride : undefined,
        overrideReason: allowBalanceOverride ? (overrideReason.trim() || 'Administrative discretion') : undefined
      });
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to submit review decision.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div
      id="staff-leave-review-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto"
    >
      <div className="relative w-full max-w-2xl bg-slate-900 border border-white/10 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-800/80 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-500/20 border border-purple-500/30 flex items-center justify-center text-purple-400">
              <FileCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white tracking-tight">
                Review Staff Leave Request
              </h2>
              <p className="text-xs text-slate-400">
                {isMultiTier
                  ? `Workflow Tier ${currentTier} of ${application.totalApprovalTiers} • Adjudication & Ledger Verification`
                  : 'Administrative Adjudication & Automated Attendance Synchronization'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5 max-h-[80vh] overflow-y-auto">
          {/* Institutional Self-Approval Violation Warning */}
          {isSelfApplication && (
            <div className="p-4 rounded-xl bg-rose-500/15 border border-rose-500/30 flex items-start gap-3 text-rose-200 text-xs">
              <ShieldAlert className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
              <div>
                <strong className="font-bold text-rose-300 block text-sm mb-1">
                  Self-Approval Strictly Forbidden
                </strong>
                Under institutional governance rules, you cannot review, recommend, or approve your own leave application. Another designated supervisor or Administrator must adjudicate this request.
              </div>
            </div>
          )}

          {error && (
            <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/20 flex items-start gap-3 text-rose-300 text-sm">
              <AlertCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {/* Applicant & Request Summary Card */}
          <div className="p-4 rounded-xl bg-slate-800/60 border border-white/5 space-y-3">
            <div className="flex items-center justify-between border-b border-white/5 pb-2.5">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-indigo-500/20 text-indigo-300 flex items-center justify-center font-bold text-xs">
                  {application.applicantName.substring(0, 2).toUpperCase()}
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white leading-tight">
                    {application.applicantName}
                  </h4>
                  <p className="text-[11px] text-slate-400">
                    {application.employeeCode || 'ID: ' + application.staffId} • {application.departmentName || 'General Staff'}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <span className="text-xs font-semibold px-2.5 py-1 rounded-lg bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
                  {application.leaveTypeName}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              <div>
                <span className="text-slate-400 block text-[11px]">Start Date:</span>
                <span className="font-medium text-white">{application.startDate}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[11px]">End Date:</span>
                <span className="font-medium text-white">{application.endDate || application.startDate}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[11px]">Working Days:</span>
                <span className="font-bold text-white font-mono">{workingDays} days</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[11px]">Remaining Balance:</span>
                <span className="font-bold font-mono text-emerald-400">
                  {loadingBalance ? '...' : staffBalance ? `${staffBalance.remainingDays} days` : 'N/A'}
                </span>
              </div>
            </div>

            <div className="text-xs pt-1 border-t border-white/5">
              <span className="text-slate-400 font-semibold block mb-0.5">Primary Reason:</span>
              <p className="text-slate-200 italic">"{application.reason}"</p>
            </div>

            {application.description && (
              <div className="text-xs">
                <span className="text-slate-400 font-semibold block mb-0.5">Handover Notes:</span>
                <p className="text-slate-300">{application.description}</p>
              </div>
            )}

            {application.attachmentUrl && (
              <div className="pt-1 flex items-center gap-2">
                <a
                  href={application.attachmentUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center gap-1.5 font-medium underline"
                >
                  <Paperclip className="w-3.5 h-3.5" />
                  View Supporting Document ({application.attachmentName || 'Attachment'})
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            )}
          </div>

          {/* Approval History Timeline (if available) */}
          {((application?.approvalHistory?.length || 0) > 0) && (
            <div className="p-3.5 rounded-xl bg-slate-800/30 border border-white/5 space-y-2">
              <h5 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-purple-400" />
                Workflow History
              </h5>
              <div className="space-y-1.5 text-xs">
                {(application?.approvalHistory || []).map((step, idx) => (
                  <div key={idx} className="flex items-center justify-between text-slate-400 py-1 border-b border-white/5 last:border-0">
                    <div>
                      <span className="text-slate-200 font-medium">Tier {step.tier}: {step.action}</span>
                      <span className="text-[11px] text-slate-500 ml-2">by {step.approverName} ({step.approverRole})</span>
                    </div>
                    <span className="text-[11px] text-slate-500">{new Date(step.decisionDate).toLocaleDateString()}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Adjudication Decision Selector */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              Adjudication Decision *
            </label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                disabled={isSelfApplication}
                onClick={() => setDecision('APPROVED')}
                className={`py-3 px-4 rounded-xl border text-sm font-bold flex items-center justify-center gap-2 transition-all ${
                  decision === 'APPROVED'
                    ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-300 ring-2 ring-emerald-500/30'
                    : 'bg-slate-800/60 border-white/10 text-slate-400 hover:text-white'
                } ${isSelfApplication ? 'opacity-50 cursor-not-allowed' : ''}`}
              >
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                {isMultiTier && !isFinalTier ? 'Recommend (Tier 1 Approve)' : 'Grant Final Approval'}
              </button>
              <button
                type="button"
                disabled={isSelfApplication}
                onClick={() => setDecision('REJECTED')}
                className={`py-3 px-4 rounded-xl border text-sm font-bold flex items-center justify-center gap-2 transition-all ${
                  decision === 'REJECTED'
                    ? 'bg-rose-500/20 border-rose-500/50 text-rose-300 ring-2 ring-rose-500/30'
                    : 'bg-slate-800/60 border-white/10 text-slate-400 hover:text-white'
                } ${isSelfApplication ? 'opacity-50 cursor-not-allowed' : ''}`}
              >
                <XCircle className="w-4 h-4 text-rose-400" />
                Decline / Reject
              </button>
            </div>
          </div>

          {/* Rejection Reason (Mandatory if declining) */}
          {decision === 'REJECTED' && (
            <div>
              <label className="block text-xs font-semibold text-rose-300 uppercase tracking-wider mb-1.5">
                Official Rejection Reason (Mandatory) *
              </label>
              <textarea
                rows={3}
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
                placeholder="e.g. Critical institutional examination duty during requested dates; lack of coverage..."
                className="w-full px-3 py-2 bg-slate-950/60 border border-rose-500/30 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-rose-500 placeholder-slate-500 resize-none"
                required
              />
            </div>
          )}

          {/* Balance Override Section */}
          {decision === 'APPROVED' && staffBalance && workingDays > staffBalance.remainingDays && (
            <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/20 space-y-2.5">
              <div className="flex items-center gap-2 text-amber-300 text-xs font-bold">
                <AlertCircle className="w-4 h-4 text-amber-400" />
                Insufficient Balance Detected ({workingDays} requested vs {staffBalance.remainingDays} remaining)
              </div>
              <label className="flex items-center gap-2 text-xs text-amber-200 cursor-pointer">
                <input
                  type="checkbox"
                  checked={allowBalanceOverride}
                  onChange={(e) => setAllowBalanceOverride(e.target.checked)}
                  className="rounded border-amber-500/40 bg-slate-800 text-amber-500 focus:ring-amber-500 w-4 h-4"
                />
                Apply Administrative Balance Override to allow this request
              </label>
              {allowBalanceOverride && (
                <input
                  type="text"
                  value={overrideReason}
                  onChange={(e) => setOverrideReason(e.target.value)}
                  placeholder="Official justification for override (e.g. Approved under Principal's discretionary quota)"
                  className="w-full px-3 py-2 bg-slate-950/80 border border-amber-500/30 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
              )}
            </div>
          )}

          {/* General Remarks */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              Administrative Review Remarks (Optional)
            </label>
            <textarea
              rows={2}
              value={adminRemarks}
              onChange={(e) => setAdminRemarks(e.target.value)}
              placeholder="e.g. Recommended subject to completion of weekly syllabus..."
              className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-purple-500 placeholder-slate-500 resize-none"
            />
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-white/10">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={isSubmitting || isSelfApplication}
              className={`font-semibold flex items-center gap-2 ${
                decision === 'APPROVED'
                  ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                  : 'bg-rose-600 hover:bg-rose-500 text-white'
              }`}
            >
              <CheckCircle2 className="w-4 h-4" />
              {isSubmitting ? 'Processing...' : `Confirm ${decision === 'APPROVED' ? (isMultiTier && !isFinalTier ? 'Recommendation' : 'Approval') : 'Rejection'}`}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};
