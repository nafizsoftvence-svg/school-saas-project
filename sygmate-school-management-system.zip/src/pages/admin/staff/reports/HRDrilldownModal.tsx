/**
 * Sygmate School Management System
 * HR Drill-Down Modal (Part 12F)
 * Inspect real records behind any KPI, metric, or analytics chart bar
 */

import React, { useState, useMemo } from 'react';
import {
  X,
  Search,
  Download,
  Users,
  FileSpreadsheet,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
  Filter
} from 'lucide-react';
import { HRDrilldownRecord, HRReportFilterQuery } from '../../../../types/index.js';
import { api } from '../../../../services/api.js';

interface HRDrilldownModalProps {
  isOpen: boolean;
  onClose: () => void;
  metricKey: string;
  metricLabel: string;
  records: HRDrilldownRecord[];
  isLoading?: boolean;
  filters?: HRReportFilterQuery;
}

export const HRDrilldownModal: React.FC<HRDrilldownModalProps> = ({
  isOpen,
  onClose,
  metricKey,
  metricLabel,
  records,
  isLoading = false,
  filters
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');

  const filteredRecords = useMemo(() => {
    return records.filter((rec) => {
      const matchesSearch =
        !searchTerm ||
        rec.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        rec.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
        rec.department.toLowerCase().includes(searchTerm.toLowerCase()) ||
        rec.designation.toLowerCase().includes(searchTerm.toLowerCase());

      const matchesStatus =
        statusFilter === 'ALL' ||
        (rec.status || '').toUpperCase() === statusFilter.toUpperCase();

      return matchesSearch && matchesStatus;
    });
  }, [records, searchTerm, statusFilter]);

  const uniqueStatuses = useMemo(() => {
    return Array.from(new Set(records.map((r) => r.status))).filter((s): s is string => Boolean(s));
  }, [records]);

  const handleExportCSV = async () => {
    if (!filteredRecords.length) return;

    const headers = ['ID/Code', 'Full Name', 'Category', 'Department', 'Designation', 'Status', 'Date', 'Details'];
    const rows = filteredRecords.map((r) => [
      `"${r.code || r.id}"`,
      `"${r.name}"`,
      `"${r.category}"`,
      `"${r.department}"`,
      `"${r.designation}"`,
      `"${r.status}"`,
      `"${r.date || ''}"`,
      `"${(r.details || '').replace(/"/g, '""')}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((row) => row.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `HR_Drilldown_${metricKey}_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    try {
      await api.staff.reports.auditExport({
        reportType: `DRILLDOWN_${metricKey.toUpperCase()}`,
        format: 'CSV',
        recordCount: filteredRecords.length,
        filtersApplied: filters || {}
      });
    } catch {
      // Quiet fail audit in offline/demo
    }
  };

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4"
      id="hr-drilldown-modal"
    >
      <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full max-h-[90vh] flex flex-col overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-6 border-b border-slate-200 bg-slate-50/80 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-100 text-indigo-700 rounded-xl">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-bold text-slate-900" id="drilldown-modal-title">
                  {metricLabel}
                </h3>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-indigo-100 text-indigo-800">
                  {records.length} {records.length === 1 ? 'Record' : 'Records'}
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Authoritative record drilldown reflecting institutional state
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleExportCSV}
              disabled={filteredRecords.length === 0}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 disabled:opacity-50 transition-colors shadow-xs"
              id="drilldown-export-csv-btn"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
              <span>Export CSV</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 rounded-lg transition-colors"
              id="drilldown-modal-close-btn"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Filter / Search Bar */}
        <div className="p-4 bg-white border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
          <div className="relative flex-1 min-w-[240px]">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search by name, employee code, department, role..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-4 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent bg-slate-50/50"
              id="drilldown-search-input"
            />
          </div>

          {uniqueStatuses.length > 1 && (
            <div className="flex items-center gap-2">
              <Filter className="w-3.5 h-3.5 text-slate-400" />
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                id="drilldown-status-filter"
              >
                <option value="ALL">All Statuses ({records.length})</option>
                {uniqueStatuses.map((st) => (
                  <option key={st} value={st}>
                    {(st || '').replace(/_/g, ' ')}
                  </option>
                ))}
              </select>
            </div>
          )}
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-slate-50/50">
          {isLoading ? (
            <div className="py-12 flex flex-col items-center justify-center text-slate-500">
              <div className="w-8 h-8 border-3 border-indigo-600 border-t-transparent rounded-full animate-spin mb-3"></div>
              <p className="text-xs font-medium">Loading authoritative records...</p>
            </div>
          ) : filteredRecords.length === 0 ? (
            <div className="py-12 text-center bg-white rounded-xl border border-slate-200 p-8">
              <AlertCircle className="w-8 h-8 text-slate-400 mx-auto mb-2" />
              <p className="text-sm font-semibold text-slate-800">No records found</p>
              <p className="text-xs text-slate-500 mt-1">
                {searchTerm || statusFilter !== 'ALL'
                  ? 'Try adjusting your search query or status filter.'
                  : 'There are currently no staff records matching this metric.'}
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white shadow-xs">
              <table className="w-full text-left text-xs" id="drilldown-records-table">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase tracking-wider text-[11px]">
                  <tr>
                    <th className="py-3 px-4">Identifier</th>
                    <th className="py-3 px-4">Full Name</th>
                    <th className="py-3 px-4">Department & Role</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4">Date / Timeline</th>
                    <th className="py-3 px-4">Context / Notes</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700">
                  {filteredRecords.map((rec) => (
                    <tr key={rec.id} className="hover:bg-indigo-50/30 transition-colors">
                      <td className="py-3 px-4 font-mono font-bold text-indigo-700">
                        {rec.code || rec.id.substring(0, 8)}
                      </td>
                      <td className="py-3 px-4 font-semibold text-slate-900">
                        {rec.name}
                        {rec.category && (
                          <span className="block text-[10px] font-normal text-slate-500">
                            {rec.category}
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-4">
                        <span className="font-medium text-slate-800">{rec.department}</span>
                        <span className="block text-[11px] text-slate-500">{rec.designation}</span>
                      </td>
                      <td className="py-3 px-4">
                        <span
                          className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold ${
                            (rec.status || '').includes('ACTIVE') || rec.status === 'HIRED' || rec.status === 'FINALIZED'
                              ? 'bg-emerald-100 text-emerald-800'
                              : (rec.status || '').includes('LEAVE') || (rec.status || '').includes('PENDING')
                              ? 'bg-amber-100 text-amber-800'
                              : (rec.status || '').includes('PROBATION') || rec.status === 'SCHEDULED'
                              ? 'bg-blue-100 text-blue-800'
                              : 'bg-slate-100 text-slate-700'
                          }`}
                        >
                          {(rec.status || 'ACTIVE').replace(/_/g, ' ')}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-slate-600 whitespace-nowrap">
                        {rec.date || '—'}
                      </td>
                      <td className="py-3 px-4 text-[11px] text-slate-500 max-w-[220px] truncate" title={rec.details}>
                        {rec.details || '—'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 bg-white flex items-center justify-between text-xs text-slate-500">
          <span>
            Showing {filteredRecords.length} of {records.length} matching entries
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold rounded-lg transition-colors"
            id="drilldown-modal-done-btn"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
