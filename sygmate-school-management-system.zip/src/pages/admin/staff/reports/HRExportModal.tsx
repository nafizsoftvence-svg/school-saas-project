/**
 * Sygmate School Management System
 * HR Export & Official Letterhead Print Modal (Part 12F)
 */

import React, { useState } from 'react';
import {
  X,
  Printer,
  FileSpreadsheet,
  FileText,
  School,
  CheckCircle2,
  Download,
  ShieldCheck
} from 'lucide-react';
import { api } from '../../../../services/api.js';
import { HRReportFilterQuery } from '../../../../types/index.js';
import { downloadTablePdf, triggerSafePrint } from '../../../../utils/printPdf.js';

interface HRExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeReportType: string;
  reportTitle: string;
  filters: HRReportFilterQuery;
  csvDataSupplier: () => { headers: string[]; rows: (string | number)[][] };
  recordCount: number;
}

export const HRExportModal: React.FC<HRExportModalProps> = ({
  isOpen,
  onClose,
  activeReportType,
  reportTitle,
  filters,
  csvDataSupplier,
  recordCount
}) => {
  const [format, setFormat] = useState<'CSV' | 'PRINT' | 'PDF'>('CSV');
  const [includeLetterhead, setIncludeLetterhead] = useState(true);
  const [includeSignatureLine, setIncludeSignatureLine] = useState(true);
  const [notes, setNotes] = useState('');
  const [isExporting, setIsExporting] = useState(false);
  const [successStatus, setSuccessStatus] = useState(false);

  if (!isOpen) return null;

  const handleExecuteExport = async () => {
    setIsExporting(true);
    setSuccessStatus(false);

    try {
      if (format === 'CSV') {
        const { headers, rows } = csvDataSupplier();
        const csvContent =
          'data:text/csv;charset=utf-8,' +
          [headers.join(','), ...rows.map((r) => r.map((c) => `"${c}"`).join(','))].join('\n');
        const encodedUri = encodeURI(csvContent);
        const link = document.createElement('a');
        link.setAttribute('href', encodedUri);
        link.setAttribute(
          'download',
          `Sygmate_${activeReportType}_Report_${new Date().toISOString().split('T')[0]}.csv`
        );
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      } else {
        // Print / Save to PDF
        const { headers, rows } = csvDataSupplier();
        const filterSummary = Object.entries(filters || {})
          .filter(([_, v]) => v && v !== 'ALL')
          .map(([k, v]) => `${k}: ${v}`)
          .join(' | ');

        await downloadTablePdf({
          title: `HR_${activeReportType}_Report`,
          schoolName: 'Sygmate Academy of Science & Arts',
          filterSummary: filterSummary || 'All HR Department Records',
          columns: headers,
          data: rows,
          filename: `Sygmate_${activeReportType}_Report_${new Date().toISOString().split('T')[0]}.pdf`,
          orientation: headers.length > 5 ? 'landscape' : 'portrait'
        });

        await triggerSafePrint({
          fallbackTitle: `HR_${activeReportType}_Report`
        });
      }

      // Log export action to backend audit system
      await api.staff.reports.auditExport({
        reportType: activeReportType,
        format: format === 'PRINT' ? 'PRINT' : 'CSV',
        recordCount,
        filtersApplied: filters || {}
      });

      setSuccessStatus(true);
      setTimeout(() => {
        setSuccessStatus(false);
        onClose();
      }, 1500);
    } catch (err) {
      console.error('Export failed:', err);
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4"
      id="hr-export-modal"
    >
      <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-200">
        {/* Modal Header */}
        <div className="p-5 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-100 text-indigo-700 rounded-xl">
              <Download className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">Export Institutional HR Report</h3>
              <p className="text-xs text-slate-500 mt-0.5">{reportTitle}</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-5 text-xs text-slate-700">
          {/* Format Selection */}
          <div>
            <label className="block text-xs font-bold text-slate-800 mb-2">Export Format</label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setFormat('CSV')}
                className={`p-3.5 rounded-xl border flex items-center gap-3 transition-all text-left ${
                  format === 'CSV'
                    ? 'border-indigo-600 bg-indigo-50/50 ring-2 ring-indigo-500/20 text-indigo-900 font-semibold'
                    : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                }`}
              >
                <div className="p-2 rounded-lg bg-emerald-100 text-emerald-800">
                  <FileSpreadsheet className="w-4 h-4" />
                </div>
                <div>
                  <span className="block font-bold">CSV Spreadsheet</span>
                  <span className="text-[11px] text-slate-500 font-normal">Excel / Sheets ready</span>
                </div>
              </button>

              <button
                type="button"
                onClick={() => setFormat('PRINT')}
                className={`p-3.5 rounded-xl border flex items-center gap-3 transition-all text-left ${
                  format === 'PRINT'
                    ? 'border-indigo-600 bg-indigo-50/50 ring-2 ring-indigo-500/20 text-indigo-900 font-semibold'
                    : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                }`}
              >
                <div className="p-2 rounded-lg bg-blue-100 text-blue-800">
                  <Printer className="w-4 h-4" />
                </div>
                <div>
                  <span className="block font-bold">Print / PDF Document</span>
                  <span className="text-[11px] text-slate-500 font-normal">Official letterhead layout</span>
                </div>
              </button>
            </div>
          </div>

          {/* Letterhead Preview Options */}
          {format === 'PRINT' && (
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
              <span className="block font-bold text-slate-800">Institutional Letterhead Settings</span>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={includeLetterhead}
                  onChange={(e) => setIncludeLetterhead(e.target.checked)}
                  className="w-4 h-4 text-indigo-600 rounded-sm border-slate-300"
                />
                <span>Include Sygmate Academy header crest, affiliation & watermark</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={includeSignatureLine}
                  onChange={(e) => setIncludeSignatureLine(e.target.checked)}
                  className="w-4 h-4 text-indigo-600 rounded-sm border-slate-300"
                />
                <span>Include Principal & HR Director verification signatures</span>
              </label>
            </div>
          )}

          {/* Audit Verification Note */}
          <div className="flex items-start gap-2.5 p-3 bg-amber-50 border border-amber-200 rounded-xl text-amber-900 text-[11px]">
            <ShieldCheck className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold">Security & Audit Compliance:</span> This export event will be
              recorded in the institutional audit log with your account ID, timestamp, record count ({recordCount}), and applied filters.
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 transition-colors"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleExecuteExport}
            disabled={isExporting}
            className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-xs transition-colors disabled:opacity-50"
            id="execute-export-confirm-btn"
          >
            {successStatus ? (
              <>
                <CheckCircle2 className="w-4 h-4 text-emerald-300" />
                <span>Export Complete!</span>
              </>
            ) : (
              <>
                <Download className="w-4 h-4" />
                <span>Download {format} Report</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
