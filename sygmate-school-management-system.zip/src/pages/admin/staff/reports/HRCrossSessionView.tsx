/**
 * Sygmate School Management System
 * Cross-Session Multi-Year HR Comparative Analytics (Part 12F)
 */

import React from 'react';
import {
  History,
  TrendingUp,
  Calendar,
  Users,
  Award,
  CheckCircle2,
  Clock
} from 'lucide-react';
import { CrossSessionHRReport } from '../../../../types/index.js';

interface HRCrossSessionViewProps {
  data: CrossSessionHRReport;
}

export const HRCrossSessionView: React.FC<HRCrossSessionViewProps> = ({ data }) => {
  const sessions = Array.isArray(data?.sessions) ? data.sessions : [];

  return (
    <div className="space-y-6" id="hr-cross-session-view">
      {/* Intro Header */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-indigo-100 text-indigo-700 rounded-xl">
            <History className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-900">
              Multi-Session Longitudinal HR Performance & Growth Trends
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Historical cross-session staffing stability, attendance discipline, recruitment yield & appraisal completion
            </p>
          </div>
        </div>
      </div>

      {/* Comparative Matrix Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-700">
            <thead className="bg-slate-50 text-[11px] font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="py-3.5 px-4">Academic Session</th>
                <th className="py-3.5 px-4">Workforce Headcount</th>
                <th className="py-3.5 px-4">New Hires</th>
                <th className="py-3.5 px-4">Departures</th>
                <th className="py-3.5 px-4">Attendance Rate</th>
                <th className="py-3.5 px-4">Leave Utilization</th>
                <th className="py-3.5 px-4">Applicant Volume</th>
                <th className="py-3.5 px-4">Appraisal Completion</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {sessions.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-400 italic">
                    No multi-session historical data available.
                  </td>
                </tr>
              ) : (
                sessions.map((sess) => (
                  <tr
                    key={sess.sessionId}
                    className={`hover:bg-slate-50/80 transition-colors ${
                      sess.isCurrent ? 'bg-indigo-50/30' : ''
                    }`}
                  >
                    <td className="py-4 px-4 font-bold text-slate-900">
                      <div className="flex items-center gap-2">
                        <span>{sess.sessionName}</span>
                        {sess.isCurrent && (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-100 text-indigo-800">
                            Active Current
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="py-4 px-4 font-bold text-slate-900 text-sm">
                      {sess.totalStaff} Staff
                    </td>
                    <td className="py-4 px-4 text-emerald-700 font-semibold">
                      +{sess.newHires} Joined
                    </td>
                    <td className="py-4 px-4 text-slate-500">
                      -{sess.staffDepartures} Exited
                    </td>
                    <td className="py-4 px-4 font-bold text-slate-800">
                      {sess.attendanceRate}%
                    </td>
                    <td className="py-4 px-4 text-slate-700">
                      {sess.leaveUtilizationRate}%
                    </td>
                    <td className="py-4 px-4 text-indigo-700 font-semibold">
                      {sess.recruitmentApplications} Apps ({sess.hiredCount} Hired)
                    </td>
                    <td className="py-4 px-4 font-bold text-purple-700">
                      {sess.performanceCompletionRate}%
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
