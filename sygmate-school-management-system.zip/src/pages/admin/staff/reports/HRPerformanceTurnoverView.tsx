/**
 * Sygmate School Management System
 * Staff Performance & Turnover Analytics View (Part 12F)
 */

import React from 'react';
import {
  Award,
  TrendingUp,
  UserCheck,
  UserMinus,
  Building,
  Target,
  Clock,
  ArrowUpRight,
  ArrowDownRight,
  ExternalLink
} from 'lucide-react';
import {
  PerformanceCompletionReport,
  GoalAchievementReport,
  StaffTurnoverReport
} from '../../../../types/index.js';

interface HRPerformanceTurnoverViewProps {
  performanceData: PerformanceCompletionReport;
  goalData: GoalAchievementReport;
  turnoverData: StaffTurnoverReport;
  onDrilldown: (metricKey: string, label: string) => void;
}

export const HRPerformanceTurnoverView: React.FC<HRPerformanceTurnoverViewProps> = ({
  performanceData,
  goalData,
  turnoverData,
  onDrilldown
}) => {
  const { summary: perfSummary = {} as any, ratingDistribution = [], departmentPerformance = [] } = performanceData || {};
  const { summary: goalSummary = {} as any } = goalData || {};
  const { movementMetrics = {} as any, statusTransitionsHistory = [] } = turnoverData || {};

  return (
    <div className="space-y-8" id="hr-performance-turnover-view">
      {/* 1. TOP PERFORMANCE & TURNOVER HIGHLIGHT CARDS */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div
          onClick={() => onDrilldown('pending_reviews', 'Pending Performance Appraisals')}
          className="bg-white p-5 rounded-xl border border-slate-200 hover:border-indigo-300 hover:shadow-xs cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Cycle Completion
            </span>
            <div className="p-2 rounded-lg bg-indigo-50 text-indigo-700 group-hover:bg-indigo-600 group-hover:text-white transition-colors">
              <Award className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-bold text-slate-900">
              {perfSummary.completionRate}%
            </span>
            <span className="text-xs font-medium text-indigo-600">
              {perfSummary.completedReviews} / {perfSummary.totalReviews}
            </span>
          </div>
          <div className="mt-2 flex items-center justify-between text-[11px] text-slate-400">
            <span>Cycle: {perfSummary.activeCycleName || 'Annual Appraisal'}</span>
            <ExternalLink className="w-3 h-3 text-indigo-400 opacity-0 group-hover:opacity-100 transition-opacity" />
          </div>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Goal Achievement
            </span>
            <div className="p-2 rounded-lg bg-emerald-50 text-emerald-700">
              <Target className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-bold text-slate-900">
              {goalSummary.goalAchievementRate}%
            </span>
            <span className="text-xs font-medium text-emerald-600">
              {goalSummary.achievedGoals} / {goalSummary.totalGoals} Goals
            </span>
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">
            Institutional OKR success rate
          </span>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Workforce Turnover
            </span>
            <div className="p-2 rounded-lg bg-purple-50 text-purple-700">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-bold text-slate-900">
              {movementMetrics.turnoverRate}%
            </span>
            <span className="text-xs font-medium text-emerald-600">Healthy Retention</span>
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">
            {movementMetrics.resignationsCount + movementMetrics.terminationsCount} separations this period
          </span>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Net Staff Movement
            </span>
            <div className="p-2 rounded-lg bg-blue-50 text-blue-700">
              <UserCheck className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-bold text-slate-900">
              {movementMetrics.netStaffChange >= 0 ? `+${movementMetrics.netStaffChange}` : movementMetrics.netStaffChange}
            </span>
            <span className="text-xs font-medium text-blue-600">
              {movementMetrics.newHiresCount} In / {movementMetrics.resignationsCount} Out
            </span>
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">
            Net institutional growth trajectory
          </span>
        </div>
      </div>

      {/* 2. RATING BAND DISTRIBUTION & WORKFLOW PROGRESSION */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Rating Band Distribution */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <Award className="w-4 h-4 text-amber-500" />
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                Appraisal Rating Band Distribution
              </h3>
            </div>
            <span className="text-[11px] text-slate-500">Staff Assessed</span>
          </div>

          <div className="space-y-3">
            {ratingDistribution.map((band) => (
              <div key={band.band} className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="font-semibold text-slate-800">{band.label}</span>
                  <span className="font-bold text-slate-900">
                    {band.count} ({band.percentage}%)
                  </span>
                </div>
                <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all ${
                      band.band === 'EXCEPTIONAL'
                        ? 'bg-purple-600'
                        : band.band === 'EXCEEDS_EXPECTATIONS'
                        ? 'bg-indigo-600'
                        : band.band === 'MEETS_EXPECTATIONS'
                        ? 'bg-emerald-600'
                        : band.band === 'NEEDS_IMPROVEMENT'
                        ? 'bg-amber-500'
                        : 'bg-rose-500'
                    }`}
                    style={{ width: `${band.percentage}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Workflow Stage Completion Rates */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-indigo-600" />
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                Review Workflow Stage Completion
              </h3>
            </div>
            <span className="text-[11px] text-slate-500">Multistage Audit</span>
          </div>

          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="font-semibold text-slate-800">1. Staff Self Assessment</span>
                <span className="font-bold text-indigo-700">
                  {perfSummary.selfAssessmentCompletionRate}% Done ({perfSummary.selfAssessmentCompletedCount}/{perfSummary.totalReviews})
                </span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                <div
                  className="bg-indigo-600 h-full rounded-full"
                  style={{ width: `${perfSummary.selfAssessmentCompletionRate}%` }}
                ></div>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="font-semibold text-slate-800">2. Supervisor Evaluation</span>
                <span className="font-bold text-blue-700">
                  {perfSummary.supervisorReviewCompletionRate}% Done ({perfSummary.supervisorReviewCompletedCount}/{perfSummary.totalReviews})
                </span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                <div
                  className="bg-blue-600 h-full rounded-full"
                  style={{ width: `${perfSummary.supervisorReviewCompletionRate}%` }}
                ></div>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="font-semibold text-slate-800">3. HR Director Review & Calibration</span>
                <span className="font-bold text-emerald-700">
                  {perfSummary.hrReviewCompletionRate}% Done ({perfSummary.hrReviewCompletedCount}/{perfSummary.totalReviews})
                </span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                <div
                  className="bg-emerald-600 h-full rounded-full"
                  style={{ width: `${perfSummary.hrReviewCompletionRate}%` }}
                ></div>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="font-semibold text-slate-800">4. Employee Sign-off / Acknowledgement</span>
                <span className="font-bold text-purple-700">
                  {perfSummary.acknowledgementRate}% Finalized ({perfSummary.acknowledgementCount}/{perfSummary.totalReviews})
                </span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                <div
                  className="bg-purple-600 h-full rounded-full"
                  style={{ width: `${perfSummary.acknowledgementRate}%` }}
                ></div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 3. DEPARTMENT PERFORMANCE COMPARISON TABLE */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-5 border-b border-slate-200 bg-slate-50/70 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Building className="w-4 h-4 text-indigo-600" />
            <h3 className="text-sm font-bold text-slate-900">Department Performance & Score Benchmarks</h3>
          </div>
          <span className="text-xs text-slate-500">{departmentPerformance.length} Departments</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-700">
            <thead className="bg-slate-50 text-[11px] font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Department</th>
                <th className="py-3 px-4">Reviews Assigned</th>
                <th className="py-3 px-4">Completed</th>
                <th className="py-3 px-4">Average Evaluation Score</th>
                <th className="py-3 px-4">Benchmark Band</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {departmentPerformance.map((dept) => (
                <tr key={dept.departmentId} className="hover:bg-slate-50/80 transition-colors">
                  <td className="py-3.5 px-4 font-bold text-slate-900">{dept.departmentName}</td>
                  <td className="py-3.5 px-4 text-slate-600">{dept.reviewsCount}</td>
                  <td className="py-3.5 px-4 font-semibold text-emerald-700">{dept.completedCount}</td>
                  <td className="py-3.5 px-4">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-900 text-sm">{dept.averageScore}%</span>
                      <div className="w-24 bg-slate-100 rounded-full h-2 overflow-hidden">
                        <div
                          className="bg-indigo-600 h-full rounded-full"
                          style={{ width: `${dept.averageScore}%` }}
                        ></div>
                      </div>
                    </div>
                  </td>
                  <td className="py-3.5 px-4">
                    <span
                      className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold ${
                        dept.ratingBand === 'EXCEPTIONAL'
                          ? 'bg-purple-100 text-purple-800'
                          : dept.ratingBand === 'EXCEEDS_EXPECTATIONS'
                          ? 'bg-indigo-100 text-indigo-800'
                          : dept.ratingBand === 'MEETS_EXPECTATIONS'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {(dept.ratingBand || 'MEETS_EXPECTATIONS').replace(/_/g, ' ')}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* 4. HISTORICAL STATUS TRANSITION LEDGER */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-5 border-b border-slate-200 bg-slate-50/70 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-900">Staff Movement & Status Change Ledger</h3>
            <p className="text-xs text-slate-500 mt-0.5">Authoritative employment lifecycle audit records</p>
          </div>
          <span className="text-xs text-slate-500 font-medium">
            {statusTransitionsHistory.length} Movement Records
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-700">
            <thead className="bg-slate-50 text-[11px] font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Staff Member</th>
                <th className="py-3 px-4">Transition</th>
                <th className="py-3 px-4">Effective Date</th>
                <th className="py-3 px-4">Institutional Reason</th>
                <th className="py-3 px-4">Authorized By</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {statusTransitionsHistory.length === 0 ? (
                <tr>
                  <td colSpan={5} className="py-8 text-center text-slate-400 italic">
                    No status movement events recorded in the system.
                  </td>
                </tr>
              ) : (
                statusTransitionsHistory.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3.5 px-4 font-bold text-slate-900">
                      {item.staffName}
                      <span className="block text-[10px] text-slate-400 font-normal">
                        {item.employeeCode}
                      </span>
                    </td>
                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-1.5 font-semibold text-xs">
                        <span className="text-slate-500">{item.previousStatus}</span>
                        <span className="text-slate-400">→</span>
                        <span className="text-indigo-700 font-bold">{item.newStatus}</span>
                      </div>
                    </td>
                    <td className="py-3.5 px-4 text-slate-600 whitespace-nowrap">{item.effectiveDate}</td>
                    <td className="py-3.5 px-4 text-slate-600 max-w-[280px] truncate">{item.reason}</td>
                    <td className="py-3.5 px-4 text-slate-500 text-[11px]">{item.changedByUserName}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
