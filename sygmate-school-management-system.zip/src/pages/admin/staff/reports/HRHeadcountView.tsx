/**
 * Sygmate School Management System
 * HR Headcount & Workforce Distribution Report View (Part 12F)
 */

import React from 'react';
import {
  Users,
  Building,
  Briefcase,
  Layers,
  GraduationCap,
  ExternalLink,
  ChevronRight,
  PieChart
} from 'lucide-react';
import { StaffHeadcountReport } from '../../../../types/index.js';

interface HRHeadcountViewProps {
  data: StaffHeadcountReport;
  onDrilldown: (metricKey: string, label: string) => void;
}

export const HRHeadcountView: React.FC<HRHeadcountViewProps> = ({
  data,
  onDrilldown
}) => {
  const {
    summary = { totalStaff: 0, activeStaff: 0, teachingStaff: 0, nonTeachingStaff: 0, newHiresThisMonth: 0, genderDiversityIndex: 0 },
    departments = [],
    designations = [],
    categories = [],
    employmentStatuses = []
  } = data || {};

  return (
    <div className="space-y-6" id="hr-headcount-view">
      {/* Top Highlights Summary Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div
          onClick={() => onDrilldown('active_staff', 'Active Workforce')}
          className="bg-white p-5 rounded-xl border border-slate-200 hover:border-indigo-300 hover:shadow-xs cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Total Workforce
            </span>
            <div className="p-2 rounded-lg bg-indigo-50 text-indigo-700 group-hover:bg-indigo-600 group-hover:text-white transition-colors">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-bold text-slate-900">{summary.totalStaff}</span>
            <span className="text-xs font-medium text-emerald-600">
              {summary.activeStaff} Active ({summary.totalStaff > 0 ? Math.round((summary.activeStaff / summary.totalStaff) * 100) : 0}%)
            </span>
          </div>
          <div className="mt-2 flex items-center justify-between text-[11px] text-slate-400">
            <span>Click for directory drilldown</span>
            <ExternalLink className="w-3 h-3 text-indigo-400 opacity-0 group-hover:opacity-100 transition-opacity" />
          </div>
        </div>

        <div
          onClick={() => onDrilldown('teaching_staff', 'Teaching & Instructional Staff')}
          className="bg-white p-5 rounded-xl border border-slate-200 hover:border-blue-300 hover:shadow-xs cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Faculty / Instructional
            </span>
            <div className="p-2 rounded-lg bg-blue-50 text-blue-700 group-hover:bg-blue-600 group-hover:text-white transition-colors">
              <GraduationCap className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-bold text-slate-900">{summary.teachingStaff}</span>
            <span className="text-xs font-medium text-blue-600">
              {summary.totalStaff > 0 ? Math.round((summary.teachingStaff / summary.totalStaff) * 100) : 0}% Ratio
            </span>
          </div>
          <div className="mt-2 flex items-center justify-between text-[11px] text-slate-400">
            <span>Core academic educators</span>
            <ExternalLink className="w-3 h-3 text-blue-400 opacity-0 group-hover:opacity-100 transition-opacity" />
          </div>
        </div>

        <div
          onClick={() => onDrilldown('active_staff', 'Administrative & Operational Staff')}
          className="bg-white p-5 rounded-xl border border-slate-200 hover:border-amber-300 hover:shadow-xs cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Administrative & Support
            </span>
            <div className="p-2 rounded-lg bg-amber-50 text-amber-700 group-hover:bg-amber-600 group-hover:text-white transition-colors">
              <Layers className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-bold text-slate-900">
              {summary.administrativeStaff + summary.supportStaff}
            </span>
            <span className="text-xs font-medium text-amber-600">Operations</span>
          </div>
          <div className="mt-2 flex items-center justify-between text-[11px] text-slate-400">
            <span>Admin: {summary.administrativeStaff} | Support: {summary.supportStaff}</span>
            <ExternalLink className="w-3 h-3 text-amber-400 opacity-0 group-hover:opacity-100 transition-opacity" />
          </div>
        </div>

        <div
          onClick={() => onDrilldown('on_leave_staff', 'Staff Currently On Leave')}
          className="bg-white p-5 rounded-xl border border-slate-200 hover:border-purple-300 hover:shadow-xs cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Inactive & On Leave
            </span>
            <div className="p-2 rounded-lg bg-purple-50 text-purple-700 group-hover:bg-purple-600 group-hover:text-white transition-colors">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-bold text-slate-900">{summary.inactiveStaff}</span>
            <span className="text-xs font-medium text-purple-600">
              {summary.totalStaff > 0 ? Math.round((summary.inactiveStaff / summary.totalStaff) * 100) : 0}% Headcount
            </span>
          </div>
          <div className="mt-2 flex items-center justify-between text-[11px] text-slate-400">
            <span>Authorized leave / inactive</span>
            <ExternalLink className="w-3 h-3 text-purple-400 opacity-0 group-hover:opacity-100 transition-opacity" />
          </div>
        </div>
      </div>

      {/* Department Breakdown Table & Progress */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-5 border-b border-slate-200 bg-slate-50/70 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Building className="w-4 h-4 text-indigo-600" />
            <h3 className="text-sm font-bold text-slate-900">Headcount by Academic & Operational Department</h3>
          </div>
          <span className="text-xs text-slate-500 font-medium">
            {departments.length} Institutional Units
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-700">
            <thead className="bg-slate-50 text-[11px] font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Department</th>
                <th className="py-3 px-4">Total Staff</th>
                <th className="py-3 px-4">Workforce Share</th>
                <th className="py-3 px-4">Faculty / Support</th>
                <th className="py-3 px-4">Active Status</th>
                <th className="py-3 px-4">Gender Ratio (M/F)</th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {departments.map((dept) => {
                const sharePercent =
                  summary.totalStaff > 0
                    ? Math.round((dept.totalStaff / summary.totalStaff) * 1000) / 10
                    : 0;

                return (
                  <tr key={dept.departmentId} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3.5 px-4">
                      <span className="font-bold text-slate-900">{dept.departmentName}</span>
                      <span className="block text-[10px] text-slate-400 font-mono">
                        {dept.departmentCode}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 font-bold text-slate-900">
                      {dept.totalStaff}
                    </td>
                    <td className="py-3.5 px-4 min-w-[150px]">
                      <div className="flex items-center gap-2">
                        <div className="flex-1 bg-slate-100 rounded-full h-2 overflow-hidden">
                          <div
                            className="bg-indigo-600 h-full rounded-full transition-all"
                            style={{ width: `${sharePercent}%` }}
                          ></div>
                        </div>
                        <span className="text-[11px] font-semibold text-slate-600 w-9 text-right">
                          {sharePercent}%
                        </span>
                      </div>
                    </td>
                    <td className="py-3.5 px-4">
                      <span className="text-slate-800 font-medium">
                        {dept.teachingStaff} Teaching
                      </span>
                      <span className="text-slate-400 mx-1">/</span>
                      <span className="text-slate-500">{dept.nonTeachingStaff} Support</span>
                    </td>
                    <td className="py-3.5 px-4">
                      <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                        {dept.activeStaff} Active
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-slate-600">
                      {dept.maleStaff} M : {dept.femaleStaff} F
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      <button
                        type="button"
                        onClick={() => onDrilldown('active_staff', `${dept.departmentName} Staff`)}
                        className="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                        title="View staff in this department"
                      >
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Grid: Category & Employment Status Distribution */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Category Distribution */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <Layers className="w-4 h-4 text-blue-600" />
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                Staff Category Balance
              </h4>
            </div>
            <span className="text-[11px] text-slate-500">Distribution %</span>
          </div>

          <div className="space-y-3">
            {categories.map((cat) => (
              <div key={cat.category} className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="font-semibold text-slate-800">{cat.displayName}</span>
                  <span className="font-bold text-slate-900">
                    {cat.count} ({cat.percentage}%)
                  </span>
                </div>
                <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                  <div
                    className="bg-blue-600 h-full rounded-full transition-all"
                    style={{ width: `${cat.percentage}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Employment Status Distribution */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-emerald-600" />
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                Employment Lifecycle Status
              </h4>
            </div>
            <span className="text-[11px] text-slate-500">Active Records</span>
          </div>

          <div className="space-y-3">
            {employmentStatuses.map((st) => (
              <div key={st.status} className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="font-semibold text-slate-800">{st.displayName}</span>
                  <span className="font-bold text-slate-900">
                    {st.count} ({st.percentage}%)
                  </span>
                </div>
                <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all ${
                      st.status === 'active'
                        ? 'bg-emerald-600'
                        : st.status === 'probation'
                        ? 'bg-blue-600'
                        : st.status === 'on_leave'
                        ? 'bg-amber-500'
                        : 'bg-slate-400'
                    }`}
                    style={{ width: `${st.percentage}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
