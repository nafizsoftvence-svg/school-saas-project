/**
 * Sygmate School Management System
 * Staff Leave Reports & Utilization View (Part 12F)
 */

import React, { useState } from 'react';
import {
  Calendar,
  CheckCircle2,
  Clock,
  XCircle,
  Building,
  TrendingUp,
  Percent,
  Search,
  FileText
} from 'lucide-react';
import {
  StaffLeaveReport,
  LeaveBalanceUtilizationReport
} from '../../../../types/index.js';

interface HRLeaveViewProps {
  leaveReport: StaffLeaveReport;
  utilizationReport: LeaveBalanceUtilizationReport;
  onDrilldown: (metricKey: string, label: string) => void;
}

export const HRLeaveView: React.FC<HRLeaveViewProps> = ({
  leaveReport,
  utilizationReport,
  onDrilldown
}) => {
  const [ledgerSearch, setLedgerSearch] = useState('');
  const { summary = {} as any, statusBreakdown = [], typeBreakdown = [], departmentBreakdown = [] } = leaveReport || {};
  const {
    overallUtilizationPercentage = 0,
    totalEntitledDays = 0,
    totalUsedDays = 0,
    totalRemainingDays = 0,
    departmentUtilization = [],
    staffBalances = []
  } = utilizationReport || {};

  const safeStaffBalances = Array.isArray(staffBalances) ? staffBalances : [];
  const filteredStaffBalances = safeStaffBalances.filter(
    (b) =>
      !ledgerSearch ||
      b.staffName.toLowerCase().includes(ledgerSearch.toLowerCase()) ||
      b.employeeCode.toLowerCase().includes(ledgerSearch.toLowerCase()) ||
      b.departmentName.toLowerCase().includes(ledgerSearch.toLowerCase()) ||
      b.leaveTypeName.toLowerCase().includes(ledgerSearch.toLowerCase())
  );

  return (
    <div className="space-y-6" id="hr-leave-view">
      {/* Top Metric Highlights */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-xl border border-slate-200">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Total Applications
            </span>
            <div className="p-2 rounded-lg bg-indigo-50 text-indigo-700">
              <FileText className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900">{summary.totalApplications}</span>
            <span className="text-xs font-medium text-indigo-600">Requests</span>
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">
            {summary.approvedApplications} approved ({summary.totalApprovedDays} total days)
          </span>
        </div>

        <div
          onClick={() => onDrilldown('pending_leaves', 'Pending Leave Applications')}
          className="bg-white p-5 rounded-xl border border-slate-200 hover:border-amber-300 hover:shadow-xs cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Pending Approvals
            </span>
            <div className="p-2 rounded-lg bg-amber-50 text-amber-700 group-hover:bg-amber-600 group-hover:text-white transition-colors">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900">{summary.pendingApplications}</span>
            <span className="text-xs font-medium text-amber-600">Action Required</span>
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">
            {summary.totalPendingDays} days awaiting supervisor decision
          </span>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Entitlement Utilized
            </span>
            <div className="p-2 rounded-lg bg-emerald-50 text-emerald-700">
              <Percent className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900">{overallUtilizationPercentage}%</span>
            <span className="text-xs font-medium text-emerald-600">Used Rate</span>
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">
            {totalUsedDays} days taken of {totalEntitledDays} allocated
          </span>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Remaining Balance
            </span>
            <div className="p-2 rounded-lg bg-blue-50 text-blue-700">
              <Calendar className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900">{totalRemainingDays}</span>
            <span className="text-xs font-medium text-blue-600">Days Available</span>
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">
            Institutional pool balance for session
          </span>
        </div>
      </div>

      {/* Grid: Leave Types & Department Utilization */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Leave Types Breakdown */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              Leave Volume by Category
            </h3>
            <span className="text-[11px] text-slate-500">{typeBreakdown.length} Active Policies</span>
          </div>

          <div className="space-y-3">
            {typeBreakdown.map((t) => (
              <div key={t.leaveTypeId} className="p-3 bg-slate-50 rounded-lg space-y-1.5 border border-slate-100">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-bold text-slate-900">{t.leaveTypeName}</span>
                  <span className="font-semibold text-slate-700">
                    {t.approvedDays} Approved Days ({t.totalApplications} Requests)
                  </span>
                </div>
                <div className="flex items-center gap-3 text-[11px] text-slate-500">
                  <span className="text-emerald-700 font-medium">✓ {t.approvedDays}d Approved</span>
                  <span className="text-amber-700 font-medium">⏳ {t.pendingDays}d Pending</span>
                  <span className="text-rose-700 font-medium">✕ {t.rejectedDays}d Rejected</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Department Utilization */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <Building className="w-4 h-4 text-indigo-600" />
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                Departmental Leave Utilization
              </h3>
            </div>
            <span className="text-[11px] text-slate-500">Consumed vs Entitled</span>
          </div>

          <div className="space-y-3">
            {departmentUtilization.map((d) => (
              <div key={d.departmentId} className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="font-semibold text-slate-800">{d.departmentName}</span>
                  <span className="font-bold text-slate-900">
                    {d.usedDays} / {d.allocatedDays} Days ({d.utilizationRate}%)
                  </span>
                </div>
                <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                  <div
                    className="bg-indigo-600 h-full rounded-full transition-all"
                    style={{ width: `${Math.min(100, d.utilizationRate)}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Staff Leave Balance Ledger Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-5 border-b border-slate-200 bg-slate-50/70 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 className="text-sm font-bold text-slate-900">Individual Staff Leave Balance Ledger</h3>
            <p className="text-xs text-slate-500 mt-0.5">Authoritative entitlement vs usage accounting</p>
          </div>
          <div className="relative min-w-[220px]">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Filter ledger by staff, code, type..."
              value={ledgerSearch}
              onChange={(e) => setLedgerSearch(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 text-xs border border-slate-200 rounded-lg bg-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-700">
            <thead className="bg-slate-50 text-[11px] font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Staff Member</th>
                <th className="py-3 px-4">Leave Policy</th>
                <th className="py-3 px-4">Entitled</th>
                <th className="py-3 px-4">Carried Over</th>
                <th className="py-3 px-4">Total Pool</th>
                <th className="py-3 px-4">Used Days</th>
                <th className="py-3 px-4">Pending</th>
                <th className="py-3 px-4">Remaining</th>
                <th className="py-3 px-4">Utilization</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredStaffBalances.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-8 text-center text-slate-400 italic">
                    No leave entitlement records match query.
                  </td>
                </tr>
              ) : (
                filteredStaffBalances.map((item, idx) => (
                  <tr key={`${item.staffId}-${item.leaveTypeName}-${idx}`} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3.5 px-4">
                      <span className="font-bold text-slate-900 block">{item.staffName}</span>
                      <span className="text-[10px] text-slate-400">
                        {item.employeeCode} • {item.departmentName}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 font-medium text-slate-800">
                      {item.leaveTypeName}
                    </td>
                    <td className="py-3.5 px-4 font-semibold text-slate-700">{item.entitledDays}d</td>
                    <td className="py-3.5 px-4 text-slate-500">{item.carriedForwardDays}d</td>
                    <td className="py-3.5 px-4 font-bold text-indigo-700">{item.totalAllocatedDays}d</td>
                    <td className="py-3.5 px-4 font-semibold text-rose-700">{item.usedDays}d</td>
                    <td className="py-3.5 px-4 text-amber-700">{item.pendingDays}d</td>
                    <td className="py-3.5 px-4 font-bold text-emerald-700">{item.remainingDays}d</td>
                    <td className="py-3.5 px-4">
                      <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-slate-100 text-slate-800">
                        {item.utilizationPercentage}%
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
