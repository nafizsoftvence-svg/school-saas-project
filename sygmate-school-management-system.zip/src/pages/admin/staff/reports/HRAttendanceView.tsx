/**
 * Sygmate School Management System
 * Staff Attendance Reports & Analytics View (Part 12F)
 */

import React from 'react';
import {
  Clock,
  UserCheck,
  UserX,
  AlertTriangle,
  Building,
  Calendar,
  ChevronRight,
  TrendingUp,
  Percent
} from 'lucide-react';
import { StaffAttendanceReport } from '../../../../types/index.js';

interface HRAttendanceViewProps {
  data: StaffAttendanceReport;
  onDrilldown: (metricKey: string, label: string) => void;
}

export const HRAttendanceView: React.FC<HRAttendanceViewProps> = ({
  data,
  onDrilldown
}) => {
  const {
    overallAttendanceRate = 0,
    totalWorkingDays = 0,
    totalRecords = 0,
    statusDistribution = [],
    departmentSummaries = [],
    lateArrivalSummary = { totalLateArrivals: 0, mostFrequentLateStaff: [] } as any,
    absenceSummary = { totalUnexcusedAbsences: 0, mostFrequentAbsentStaff: [] } as any,
    halfDaySummary = {} as any,
    leaveVsAttendanceSummary = {} as any,
    dateRange = { startDate: '', endDate: '' } as any
  } = data || {};

  const frequentLateStaff = Array.isArray(lateArrivalSummary?.mostFrequentLateStaff)
    ? lateArrivalSummary.mostFrequentLateStaff
    : [];
  const frequentAbsentStaff = Array.isArray(absenceSummary?.mostFrequentAbsentStaff)
    ? absenceSummary.mostFrequentAbsentStaff
    : [];

  return (
    <div className="space-y-6" id="hr-attendance-view">
      {/* Top Attendance Metric Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-xl border border-slate-200">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Overall Duty Rate
            </span>
            <div className="p-2 rounded-lg bg-emerald-50 text-emerald-700">
              <UserCheck className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900">{overallAttendanceRate}%</span>
            <span className="text-xs font-medium text-emerald-600">Institutional</span>
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">
            Across {totalWorkingDays} verified operating days
          </span>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Late Arrivals
            </span>
            <div className="p-2 rounded-lg bg-amber-50 text-amber-700">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900">{lateArrivalSummary.totalLateCount}</span>
            <span className="text-xs font-medium text-amber-600">Punctuality</span>
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">
            Occurrences past policy grace period
          </span>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Unexcused Absences
            </span>
            <div className="p-2 rounded-lg bg-rose-50 text-rose-700">
              <UserX className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900">{absenceSummary.totalAbsenceCount}</span>
            <span className="text-xs font-medium text-rose-600">Zero Notice</span>
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">
            Absence without approved leave record
          </span>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Leave vs Work Ratio
            </span>
            <div className="p-2 rounded-lg bg-blue-50 text-blue-700">
              <Percent className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold text-slate-900">
              {leaveVsAttendanceSummary.leaveToWorkRatio}%
            </span>
            <span className="text-xs font-medium text-blue-600">Impact</span>
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">
            {leaveVsAttendanceSummary.totalLeaveDaysCount} days leave vs {leaveVsAttendanceSummary.totalWorkDaysCount} scheduled
          </span>
        </div>
      </div>

      {/* Attendance Status Distribution Grid */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
            Daily Attendance Status Distribution ({dateRange.startDate} to {dateRange.endDate})
          </h3>
          <span className="text-xs text-slate-500">{totalRecords} Total Attendance Logs</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
          {statusDistribution.map((st) => (
            <div key={st.status} className="p-3 rounded-lg bg-slate-50 border border-slate-200/60">
              <span className="block text-[11px] font-semibold text-slate-500">{st.label}</span>
              <span className="text-lg font-bold text-slate-900 mt-1 block">{st.count}</span>
              <span className="text-[11px] font-medium text-slate-600">{st.percentage}% share</span>
            </div>
          ))}
        </div>
      </div>

      {/* Department Attendance Comparison Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-5 border-b border-slate-200 bg-slate-50/70 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Building className="w-4 h-4 text-indigo-600" />
            <h3 className="text-sm font-bold text-slate-900">Departmental Attendance & Punctuality Summary</h3>
          </div>
          <span className="text-xs text-slate-500 font-medium">Ranked by unit</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-700">
            <thead className="bg-slate-50 text-[11px] font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Department</th>
                <th className="py-3 px-4">Scheduled Duty</th>
                <th className="py-3 px-4">Present</th>
                <th className="py-3 px-4">Late Arrivals</th>
                <th className="py-3 px-4">Unexcused Absent</th>
                <th className="py-3 px-4">On Leave</th>
                <th className="py-3 px-4">Duty Compliance</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {departmentSummaries.map((dept) => (
                <tr key={dept.departmentId} className="hover:bg-slate-50/80 transition-colors">
                  <td className="py-3.5 px-4 font-bold text-slate-900">
                    {dept.departmentName}
                  </td>
                  <td className="py-3.5 px-4 text-slate-600">{dept.totalScheduled}</td>
                  <td className="py-3.5 px-4 font-semibold text-emerald-700">{dept.presentCount}</td>
                  <td className="py-3.5 px-4 text-amber-700 font-medium">{dept.lateCount}</td>
                  <td className="py-3.5 px-4 text-rose-700 font-medium">{dept.absentCount}</td>
                  <td className="py-3.5 px-4 text-blue-700 font-medium">{dept.leaveCount}</td>
                  <td className="py-3.5 px-4">
                    <div className="flex items-center gap-2">
                      <div className="w-20 bg-slate-100 rounded-full h-2 overflow-hidden">
                        <div
                          className={`h-full rounded-full ${
                            dept.attendancePercentage >= 95
                              ? 'bg-emerald-600'
                              : dept.attendancePercentage >= 90
                              ? 'bg-blue-600'
                              : 'bg-amber-500'
                          }`}
                          style={{ width: `${dept.attendancePercentage}%` }}
                        ></div>
                      </div>
                      <span className="font-bold text-slate-800">{dept.attendancePercentage}%</span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Grid: Most Frequent Late & Absent Staff */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Frequent Late Arrivals */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 space-y-3">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
            <Clock className="w-4 h-4 text-amber-600" />
            <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              Frequent Late Arrivals (Attention List)
            </h4>
          </div>

          {frequentLateStaff.length === 0 ? (
            <p className="text-xs text-slate-500 italic py-4 text-center">
              No staff members flagged for repeated late arrivals in selected period.
            </p>
          ) : (
            <div className="space-y-2">
              {frequentLateStaff.map((staff) => (
                <div
                  key={staff.staffId}
                  className="flex items-center justify-between p-2.5 rounded-lg bg-slate-50 hover:bg-amber-50/50 transition-colors"
                >
                  <div>
                    <span className="font-bold text-slate-900 block text-xs">{staff.staffName}</span>
                    <span className="text-[10px] text-slate-500">
                      {staff.employeeCode} • {staff.departmentName}
                    </span>
                  </div>
                  <span className="px-2 py-1 rounded text-xs font-bold bg-amber-100 text-amber-800">
                    {staff.count} Days Late
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Frequent Unexcused Absences */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 space-y-3">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
            <AlertTriangle className="w-4 h-4 text-rose-600" />
            <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              Unexcused Absences (Attention List)
            </h4>
          </div>

          {frequentAbsentStaff.length === 0 ? (
            <p className="text-xs text-slate-500 italic py-4 text-center">
              Zero unexcused absences recorded in the active reporting timeframe.
            </p>
          ) : (
            <div className="space-y-2">
              {frequentAbsentStaff.map((staff) => (
                <div
                  key={staff.staffId}
                  className="flex items-center justify-between p-2.5 rounded-lg bg-slate-50 hover:bg-rose-50/50 transition-colors"
                >
                  <div>
                    <span className="font-bold text-slate-900 block text-xs">{staff.staffName}</span>
                    <span className="text-[10px] text-slate-500">
                      {staff.employeeCode} • {staff.departmentName}
                    </span>
                  </div>
                  <span className="px-2 py-1 rounded text-xs font-bold bg-rose-100 text-rose-800">
                    {staff.count} Days Absent
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
