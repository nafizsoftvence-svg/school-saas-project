/**
 * Sygmate School Management System
 * Staff Recruitment & Onboarding Analytics View (Part 12F)
 */

import React from 'react';
import {
  UserPlus,
  Briefcase,
  Users,
  CheckCircle2,
  Clock,
  ArrowRight,
  TrendingUp,
  AlertCircle,
  ExternalLink
} from 'lucide-react';
import {
  RecruitmentFunnelReport,
  RecruitmentPerformanceReport,
  OnboardingReport
} from '../../../../types/index.js';

interface HRRecruitmentOnboardingViewProps {
  funnelData: RecruitmentFunnelReport;
  performanceData: RecruitmentPerformanceReport;
  onboardingData: OnboardingReport;
  onDrilldown: (metricKey: string, label: string) => void;
}

export const HRRecruitmentOnboardingView: React.FC<HRRecruitmentOnboardingViewProps> = ({
  funnelData,
  performanceData,
  onboardingData,
  onDrilldown
}) => {
  const { summary: funnelSummary = {} as any, funnelStages = [], positionMetrics = [] } = funnelData || {};
  const { summary: onbSummary = {} as any, tasksSummary = {} as any, recentOnboardingList = [] } = onboardingData || {};

  return (
    <div className="space-y-8" id="hr-recruitment-onboarding-view">
      {/* 1. TOP RECRUITMENT KPI CARDS */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div
          onClick={() => onDrilldown('open_positions', 'Active Job Openings')}
          className="bg-white p-5 rounded-xl border border-slate-200 hover:border-indigo-300 hover:shadow-xs cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Open Positions
            </span>
            <div className="p-2 rounded-lg bg-indigo-50 text-indigo-700 group-hover:bg-indigo-600 group-hover:text-white transition-colors">
              <Briefcase className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-bold text-slate-900">{funnelSummary.publishedPositions}</span>
            <span className="text-xs font-medium text-indigo-600">Active Openings</span>
          </div>
          <div className="mt-2 flex items-center justify-between text-[11px] text-slate-400">
            <span>{funnelSummary.totalPositions} total positions</span>
            <ExternalLink className="w-3 h-3 text-indigo-400 opacity-0 group-hover:opacity-100 transition-opacity" />
          </div>
        </div>

        <div
          onClick={() => onDrilldown('active_candidates', 'Candidates in Recruitment Pipeline')}
          className="bg-white p-5 rounded-xl border border-slate-200 hover:border-blue-300 hover:shadow-xs cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Candidate Pool
            </span>
            <div className="p-2 rounded-lg bg-blue-50 text-blue-700 group-hover:bg-blue-600 group-hover:text-white transition-colors">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-bold text-slate-900">{funnelSummary.totalCandidates}</span>
            <span className="text-xs font-medium text-blue-600">Candidates</span>
          </div>
          <div className="mt-2 flex items-center justify-between text-[11px] text-slate-400">
            <span>{funnelSummary.totalApplications} total applications</span>
            <ExternalLink className="w-3 h-3 text-blue-400 opacity-0 group-hover:opacity-100 transition-opacity" />
          </div>
        </div>

        <div
          onClick={() => onDrilldown('pending_interviews', 'Scheduled Interviews Pending')}
          className="bg-white p-5 rounded-xl border border-slate-200 hover:border-amber-300 hover:shadow-xs cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Offer Accept Rate
            </span>
            <div className="p-2 rounded-lg bg-amber-50 text-amber-700 group-hover:bg-amber-600 group-hover:text-white transition-colors">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-bold text-slate-900">
              {performanceData.offerAcceptanceRate}%
            </span>
            <span className="text-xs font-medium text-amber-600">High Yield</span>
          </div>
          <div className="mt-2 flex items-center justify-between text-[11px] text-slate-400">
            <span>Avg {performanceData.averageProcessingTimeDays} days to hire</span>
            <ExternalLink className="w-3 h-3 text-amber-400 opacity-0 group-hover:opacity-100 transition-opacity" />
          </div>
        </div>

        <div
          onClick={() => onDrilldown('pending_onboarding', 'Pending & In-Progress Onboardings')}
          className="bg-white p-5 rounded-xl border border-slate-200 hover:border-emerald-300 hover:shadow-xs cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Onboarding Completion
            </span>
            <div className="p-2 rounded-lg bg-emerald-50 text-emerald-700 group-hover:bg-emerald-600 group-hover:text-white transition-colors">
              <UserPlus className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-bold text-slate-900">
              {tasksSummary.overallCompletionRate}%
            </span>
            <span className="text-xs font-medium text-emerald-600">Onboarding Health</span>
          </div>
          <div className="mt-2 flex items-center justify-between text-[11px] text-slate-400">
            <span>{onbSummary.inProgressOnboarding} active / {onbSummary.completedOnboarding} finished</span>
            <ExternalLink className="w-3 h-3 text-emerald-400 opacity-0 group-hover:opacity-100 transition-opacity" />
          </div>
        </div>
      </div>

      {/* 2. RECRUITMENT FUNNEL VISUALIZATION */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-6 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div>
            <h3 className="text-sm font-bold text-slate-900">8-Stage Institutional Recruitment Pipeline Funnel</h3>
            <p className="text-xs text-slate-500 mt-0.5">Applicant stage-by-stage progression & attrition analysis</p>
          </div>
          <span className="text-xs font-semibold text-indigo-700 bg-indigo-50 px-2.5 py-1 rounded-full">
            {funnelSummary.hiredCandidates} Hired Staff Members
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-8 gap-2">
          {funnelStages.map((stage, idx) => (
            <div
              key={stage.stage}
              className="p-3 bg-slate-50/80 rounded-xl border border-slate-200 flex flex-col justify-between text-center relative hover:border-indigo-300 transition-colors"
            >
              <div>
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-tight block">
                  {stage.label}
                </span>
                <span className="text-xl font-bold text-slate-900 mt-1 block">
                  {stage.count}
                </span>
              </div>
              <div className="mt-2 pt-2 border-t border-slate-200/60 text-[10px]">
                <span className="text-emerald-700 font-bold block">
                  {stage.conversionRateFromPrevious}% step
                </span>
                <span className="text-slate-400 block">
                  {stage.conversionRateFromTotal}% total
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 3. POSITION METRICS TABLE */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-5 border-b border-slate-200 bg-slate-50/70 flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900">Active Job Positions & Recruitment Performance</h3>
          <span className="text-xs text-slate-500">{positionMetrics.length} Positions Analyzed</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-700">
            <thead className="bg-slate-50 text-[11px] font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Position Title</th>
                <th className="py-3 px-4">Department</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4">Vacancies</th>
                <th className="py-3 px-4">Applications</th>
                <th className="py-3 px-4">Interviews</th>
                <th className="py-3 px-4">Offers</th>
                <th className="py-3 px-4">Hired</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {positionMetrics.map((pos) => (
                <tr key={pos.jobOpeningId} className="hover:bg-slate-50/80 transition-colors">
                  <td className="py-3.5 px-4 font-bold text-slate-900">{pos.title}</td>
                  <td className="py-3.5 px-4 text-slate-600">{pos.departmentName}</td>
                  <td className="py-3.5 px-4">
                    <span
                      className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold ${
                        pos.status === 'APPLICATIONS_OPEN'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {(pos.status || 'OPEN').replace(/_/g, ' ')}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 font-semibold text-slate-800">{pos.openingsCount}</td>
                  <td className="py-3.5 px-4 font-bold text-indigo-700">{pos.applicationsCount}</td>
                  <td className="py-3.5 px-4 text-amber-700 font-semibold">{pos.interviewsCount}</td>
                  <td className="py-3.5 px-4 text-blue-700 font-semibold">{pos.offersCount}</td>
                  <td className="py-3.5 px-4 font-bold text-emerald-700">{pos.hiredCount}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* 4. ONBOARDING HEALTH & PROGRESS LIST */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-5 border-b border-slate-200 bg-slate-50/70 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 className="text-sm font-bold text-slate-900">New Hire Onboarding Pipeline & Task Progress</h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Tracking task compliance, document verifications & orientation completion
            </p>
          </div>
          <div className="flex items-center gap-3 text-xs">
            <span className="text-slate-600">
              Tasks: <strong className="text-slate-900">{tasksSummary.completedTasks}</strong> / {tasksSummary.totalTasks} Done
            </span>
            {tasksSummary.overdueTasks > 0 && (
              <span className="text-rose-700 bg-rose-50 px-2 py-0.5 rounded-full font-bold">
                ⚠️ {tasksSummary.overdueTasks} Overdue Tasks
              </span>
            )}
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-700">
            <thead className="bg-slate-50 text-[11px] font-semibold text-slate-500 uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Employee</th>
                <th className="py-3 px-4">Department & Role</th>
                <th className="py-3 px-4">Start Date</th>
                <th className="py-3 px-4">Target Date</th>
                <th className="py-3 px-4">Tasks Progress</th>
                <th className="py-3 px-4">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {recentOnboardingList.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-400 italic">
                    No active onboarding records in selected criteria.
                  </td>
                </tr>
              ) : (
                recentOnboardingList.map((rec) => (
                  <tr key={rec.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3.5 px-4 font-bold text-slate-900">
                      {rec.staffName}
                      <span className="block text-[10px] text-slate-400 font-normal">
                        {rec.employeeCode}
                      </span>
                    </td>
                    <td className="py-3.5 px-4">
                      <span className="font-semibold text-slate-800">{rec.departmentName}</span>
                      <span className="block text-[11px] text-slate-500">{rec.designationTitle}</span>
                    </td>
                    <td className="py-3.5 px-4 text-slate-600">{rec.startDate}</td>
                    <td className="py-3.5 px-4 text-slate-600">{rec.targetCompletionDate}</td>
                    <td className="py-3.5 px-4 min-w-[160px]">
                      <div className="flex items-center gap-2">
                        <div className="flex-1 bg-slate-100 rounded-full h-2 overflow-hidden">
                          <div
                            className={`h-full rounded-full ${
                              rec.progressPercentage === 100
                                ? 'bg-emerald-600'
                                : rec.progressPercentage >= 50
                                ? 'bg-indigo-600'
                                : 'bg-amber-500'
                            }`}
                            style={{ width: `${rec.progressPercentage}%` }}
                          ></div>
                        </div>
                        <span className="text-[11px] font-bold text-slate-800">
                          {rec.progressPercentage}%
                        </span>
                      </div>
                      <span className="text-[10px] text-slate-400 block mt-0.5">
                        {rec.completedTasksCount} of {rec.totalTasksCount} tasks verified
                      </span>
                    </td>
                    <td className="py-3.5 px-4">
                      <span
                        className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold ${
                          rec.status === 'COMPLETED'
                            ? 'bg-emerald-100 text-emerald-800'
                            : rec.status === 'IN_PROGRESS'
                            ? 'bg-blue-100 text-blue-800'
                            : rec.status === 'BLOCKED'
                            ? 'bg-rose-100 text-rose-800'
                            : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        {(rec.status || 'PENDING').replace(/_/g, ' ')}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
