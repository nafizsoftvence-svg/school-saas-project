/**
 * Sygmate School Management System
 * HR Reports Universal Filter Bar (Part 12F)
 */

import React, { useState } from 'react';
import {
  Calendar,
  Filter,
  RefreshCw,
  RotateCcw,
  Search,
  Building,
  Briefcase,
  Layers,
  ChevronDown
} from 'lucide-react';
import {
  Department,
  Designation,
  AcademicSession,
  HRReportFilterQuery
} from '../../../../types/index.js';

interface HRReportFilterBarProps {
  filters: HRReportFilterQuery;
  onFilterChange: (updated: Partial<HRReportFilterQuery>) => void;
  onResetFilters: () => void;
  onRefresh: () => void;
  isLoading: boolean;
  departments: Department[];
  designations: Designation[];
  academicSessions: AcademicSession[];
}

export const HRReportFilterBar: React.FC<HRReportFilterBarProps> = ({
  filters,
  onFilterChange,
  onResetFilters,
  onRefresh,
  isLoading,
  departments = [],
  designations = [],
  academicSessions = []
}) => {
  const [isExpanded, setIsExpanded] = useState(false);

  // Quick date presets
  const applyPreset = (preset: 'THIS_MONTH' | 'LAST_30' | 'THIS_SESSION' | 'ALL_TIME') => {
    const today = new Date();
    const todayStr = today.toISOString().split('T')[0];

    if (preset === 'THIS_MONTH') {
      const firstDay = new Date(today.getFullYear(), today.getMonth(), 1)
        .toISOString()
        .split('T')[0];
      onFilterChange({ startDate: firstDay, endDate: todayStr });
    } else if (preset === 'LAST_30') {
      const prior = new Date();
      prior.setDate(prior.getDate() - 30);
      onFilterChange({ startDate: prior.toISOString().split('T')[0], endDate: todayStr });
    } else if (preset === 'THIS_SESSION') {
      const current = (academicSessions || []).find((s) => s?.isCurrent);
      if (current) {
        onFilterChange({
          sessionId: current.id,
          startDate: current.startDate,
          endDate: current.endDate
        });
      }
    } else if (preset === 'ALL_TIME') {
      onFilterChange({ startDate: undefined, endDate: undefined });
    }
  };

  const hasActiveFilters = Boolean(
    (filters.departmentId && filters.departmentId !== 'ALL') ||
    (filters.designationId && filters.designationId !== 'ALL') ||
    (filters.staffType && filters.staffType !== 'ALL') ||
    (filters.employmentStatus && filters.employmentStatus !== 'ALL') ||
    filters.startDate ||
    filters.endDate ||
    filters.search
  );

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden" id="hr-reports-filter-bar">
      {/* Primary Bar */}
      <div className="p-4 flex flex-wrap items-center justify-between gap-3">
        {/* Search & Academic Session */}
        <div className="flex flex-wrap items-center gap-2 flex-1 min-w-[300px]">
          <div className="relative flex-1 min-w-[200px] max-w-sm">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search staff, code, department..."
              value={filters.search || ''}
              onChange={(e) => onFilterChange({ search: e.target.value })}
              className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-slate-50/50"
              id="hr-reports-search-input"
            />
          </div>

          <div className="flex items-center gap-1.5">
            <Calendar className="w-3.5 h-3.5 text-slate-500" />
            <select
              value={filters.sessionId || ''}
              onChange={(e) => onFilterChange({ sessionId: e.target.value })}
              className="px-2.5 py-2 text-xs border border-slate-200 rounded-lg bg-white text-slate-700 font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500"
              id="hr-reports-session-select"
            >
              <option value="">All Academic Sessions</option>
              {academicSessions.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} {s.isCurrent ? '(Active Session)' : ''}
                </option>
              ))}
            </select>
          </div>

          {/* Preset Buttons */}
          <div className="hidden sm:flex items-center gap-1 bg-slate-100 p-0.5 rounded-lg text-[11px] font-semibold text-slate-600">
            <button
              type="button"
              onClick={() => applyPreset('THIS_MONTH')}
              className="px-2 py-1 rounded hover:bg-white hover:text-indigo-600 transition-colors"
            >
              This Month
            </button>
            <button
              type="button"
              onClick={() => applyPreset('LAST_30')}
              className="px-2 py-1 rounded hover:bg-white hover:text-indigo-600 transition-colors"
            >
              Last 30 Days
            </button>
            <button
              type="button"
              onClick={() => applyPreset('THIS_SESSION')}
              className="px-2 py-1 rounded hover:bg-white hover:text-indigo-600 transition-colors"
            >
              Academic Term
            </button>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setIsExpanded(!isExpanded)}
            className={`inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg border transition-colors ${
              isExpanded || hasActiveFilters
                ? 'bg-indigo-50 border-indigo-200 text-indigo-700'
                : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
            id="hr-reports-toggle-filters-btn"
          >
            <Filter className="w-3.5 h-3.5" />
            <span>Filter Parameters</span>
            {hasActiveFilters && (
              <span className="w-2 h-2 rounded-full bg-indigo-600"></span>
            )}
            <ChevronDown className={`w-3.5 h-3.5 transition-transform ${isExpanded ? 'rotate-180' : ''}`} />
          </button>

          {hasActiveFilters && (
            <button
              type="button"
              onClick={onResetFilters}
              className="inline-flex items-center gap-1 px-2.5 py-2 text-xs font-medium text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-lg border border-transparent transition-colors"
              title="Reset all filters"
              id="hr-reports-reset-filters-btn"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Clear</span>
            </button>
          )}

          <button
            type="button"
            onClick={onRefresh}
            disabled={isLoading}
            className="p-2 text-slate-600 hover:text-indigo-600 hover:bg-slate-100 rounded-lg transition-colors border border-slate-200 disabled:opacity-50"
            title="Refresh analytics data"
            id="hr-reports-refresh-btn"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin text-indigo-600' : ''}`} />
          </button>
        </div>
      </div>

      {/* Expanded Multi-dimensional Filters */}
      {isExpanded && (
        <div className="px-4 pb-4 pt-2 border-t border-slate-100 bg-slate-50/50 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 text-xs">
          {/* Department */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-500 mb-1 flex items-center gap-1">
              <Building className="w-3 h-3 text-slate-400" />
              <span>Department / Unit</span>
            </label>
            <select
              value={filters.departmentId || 'ALL'}
              onChange={(e) => onFilterChange({ departmentId: e.target.value })}
              className="w-full px-2.5 py-1.5 border border-slate-200 rounded-lg bg-white text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500"
              id="filter-department-select"
            >
              <option value="ALL">All Departments</option>
              {departments.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name}
                </option>
              ))}
            </select>
          </div>

          {/* Designation */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-500 mb-1 flex items-center gap-1">
              <Briefcase className="w-3 h-3 text-slate-400" />
              <span>Designation / Role</span>
            </label>
            <select
              value={filters.designationId || 'ALL'}
              onChange={(e) => onFilterChange({ designationId: e.target.value })}
              className="w-full px-2.5 py-1.5 border border-slate-200 rounded-lg bg-white text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500"
              id="filter-designation-select"
            >
              <option value="ALL">All Designations</option>
              {designations.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.title}
                </option>
              ))}
            </select>
          </div>

          {/* Staff Type */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-500 mb-1 flex items-center gap-1">
              <Layers className="w-3 h-3 text-slate-400" />
              <span>Staff Category</span>
            </label>
            <select
              value={filters.staffType || 'ALL'}
              onChange={(e) => onFilterChange({ staffType: e.target.value as any })}
              className="w-full px-2.5 py-1.5 border border-slate-200 rounded-lg bg-white text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500"
              id="filter-staff-type-select"
            >
              <option value="ALL">All Categories</option>
              <option value="teaching">Teaching / Faculty</option>
              <option value="administrative">Administrative</option>
              <option value="management">Management & Leadership</option>
              <option value="support">Support & Facilities</option>
              <option value="operational">Operational Staff</option>
            </select>
          </div>

          {/* Employment Status */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-500 mb-1">
              Employment Status
            </label>
            <select
              value={filters.employmentStatus || 'ALL'}
              onChange={(e) => onFilterChange({ employmentStatus: e.target.value as any })}
              className="w-full px-2.5 py-1.5 border border-slate-200 rounded-lg bg-white text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500"
              id="filter-employment-status-select"
            >
              <option value="ALL">All Statuses</option>
              <option value="active">Active Regular</option>
              <option value="probation">Probationary</option>
              <option value="on_leave">On Leave</option>
              <option value="suspended">Suspended</option>
              <option value="resigned">Resigned</option>
              <option value="terminated">Terminated</option>
              <option value="retired">Retired</option>
              <option value="inactive">Inactive</option>
            </select>
          </div>

          {/* Date Range Start */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-500 mb-1">
              Start Date
            </label>
            <input
              type="date"
              value={filters.startDate || ''}
              onChange={(e) => onFilterChange({ startDate: e.target.value || undefined })}
              className="w-full px-2.5 py-1.5 border border-slate-200 rounded-lg bg-white text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500"
              id="filter-start-date-input"
            />
          </div>

          {/* Date Range End */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-500 mb-1">
              End Date
            </label>
            <input
              type="date"
              value={filters.endDate || ''}
              onChange={(e) => onFilterChange({ endDate: e.target.value || undefined })}
              className="w-full px-2.5 py-1.5 border border-slate-200 rounded-lg bg-white text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500"
              id="filter-end-date-input"
            />
          </div>
        </div>
      )}
    </div>
  );
};
