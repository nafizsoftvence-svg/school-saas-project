import React, { useState, useEffect } from 'react';
import {
  X,
  User,
  Building,
  Briefcase,
  Phone,
  Mail,
  Calendar,
  Award,
  Key,
  AlertCircle,
  Sparkles,
  MapPin,
  HeartPulse
} from 'lucide-react';
import { Button } from '../../../components/ui/Button.js';
import {
  StaffProfile,
  StaffType,
  EmploymentType,
  EmploymentStatus,
  Gender,
  Department,
  Designation,
  CreateStaffPayload,
  UpdateStaffPayload,
  UserRole
} from '../../../types/index.js';

interface StaffFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  staffToEdit?: StaffProfile | null;
  departments: Department[];
  designations: Designation[];
  nextEmployeeCode?: string;
  onFetchNextCode?: (staffType: string) => Promise<string>;
  onSubmit: (payload: CreateStaffPayload | UpdateStaffPayload) => Promise<void>;
  isSubmitting?: boolean;
}

export const StaffFormModal: React.FC<StaffFormModalProps> = ({
  isOpen,
  onClose,
  staffToEdit,
  departments,
  designations,
  nextEmployeeCode = '',
  onFetchNextCode,
  onSubmit,
  isSubmitting = false
}) => {
  const isEdit = Boolean(staffToEdit);

  // Form states
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [employeeCode, setEmployeeCode] = useState('');
  const [staffType, setStaffType] = useState<StaffType>('teaching');
  const [avatarUrl, setAvatarUrl] = useState('');

  const [departmentId, setDepartmentId] = useState('');
  const [designationId, setDesignationId] = useState('');
  const [designationCustom, setDesignationCustom] = useState('');
  const [workLocation, setWorkLocation] = useState('Main Campus');
  const [workShift, setWorkShift] = useState('general');

  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [currentAddress, setCurrentAddress] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');
  const [postalCode, setPostalCode] = useState('');
  const [country, setCountry] = useState('USA');

  const [emergencyContactName, setEmergencyContactName] = useState('');
  const [emergencyContactPhone, setEmergencyContactPhone] = useState('');
  const [emergencyContactRelation, setEmergencyContactRelation] = useState('');

  const [gender, setGender] = useState<Gender>('female');
  const [dateOfBirth, setDateOfBirth] = useState('');
  const [maritalStatus, setMaritalStatus] = useState('');
  const [nationality, setNationality] = useState('American');
  const [bloodGroup, setBloodGroup] = useState('');
  const [nationalIdNumber, setNationalIdNumber] = useState('');
  const [passportNumber, setPassportNumber] = useState('');

  const [employmentType, setEmploymentType] = useState<EmploymentType>('full_time');
  const [employmentStatus, setEmploymentStatus] = useState<EmploymentStatus>('active');
  const [joiningDate, setJoiningDate] = useState(new Date().toISOString().split('T')[0]);
  const [confirmationDate, setConfirmationDate] = useState('');
  const [contractEndDate, setContractEndDate] = useState('');
  const [qualification, setQualification] = useState('Master of Science');
  const [specialization, setSpecialization] = useState('');
  const [yearsOfExperience, setYearsOfExperience] = useState(3);

  // Account provisioning
  const [createAccount, setCreateAccount] = useState(false);
  const [accountUsername, setAccountUsername] = useState('');
  const [accountPassword, setAccountPassword] = useState('SygmateStaff@2026');
  const [accountRole, setAccountRole] = useState<UserRole>('TEACHER');

  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'profile' | 'organization' | 'contact' | 'employment'>('profile');

  // Load staff data on edit
  useEffect(() => {
    if (staffToEdit) {
      setFirstName(staffToEdit.firstName || '');
      setLastName(staffToEdit.lastName || '');
      setEmployeeCode(staffToEdit.employeeCode || '');
      setStaffType(staffToEdit.staffType || 'teaching');
      setAvatarUrl(staffToEdit.avatarUrl || '');

      setDepartmentId(staffToEdit.departmentId || '');
      setDesignationId(staffToEdit.designationId || '');
      setDesignationCustom(staffToEdit.designation || '');
      setWorkLocation(staffToEdit.workLocation || 'Main Campus');
      setWorkShift(staffToEdit.workShift || 'general');

      setEmail(staffToEdit.email || '');
      setPhone(staffToEdit.phone || '');
      setCurrentAddress(staffToEdit.currentAddress || '');
      setCity(staffToEdit.city || '');
      setState(staffToEdit.state || '');
      setPostalCode(staffToEdit.postalCode || '');
      setCountry(staffToEdit.country || 'USA');

      setEmergencyContactName(staffToEdit.emergencyContactName || '');
      setEmergencyContactPhone(staffToEdit.emergencyContactPhone || '');
      setEmergencyContactRelation(staffToEdit.emergencyContactRelation || '');

      setGender(staffToEdit.gender || 'female');
      setDateOfBirth(staffToEdit.dateOfBirth || '');
      setMaritalStatus(staffToEdit.maritalStatus || '');
      setNationality(staffToEdit.nationality || 'American');
      setBloodGroup(staffToEdit.bloodGroup || '');
      setNationalIdNumber(staffToEdit.nationalIdNumber || '');
      setPassportNumber(staffToEdit.passportNumber || '');

      setEmploymentType(staffToEdit.employmentType || 'full_time');
      setEmploymentStatus(staffToEdit.employmentStatus || 'active');
      setJoiningDate(staffToEdit.joiningDate || new Date().toISOString().split('T')[0]);
      setConfirmationDate(staffToEdit.confirmationDate || '');
      setContractEndDate(staffToEdit.contractEndDate || '');
      setQualification(staffToEdit.qualification || '');
      setSpecialization(staffToEdit.specialization || '');
      setYearsOfExperience(staffToEdit.yearsOfExperience || 0);

      setCreateAccount(false);
    } else {
      // Reset defaults
      setFirstName('');
      setLastName('');
      setEmployeeCode(nextEmployeeCode || '');
      setStaffType('teaching');
      setAvatarUrl('https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=256');
      if (Array.isArray(departments) && departments.length > 0) {
        setDepartmentId(departments?.[0]?.id || '');
      }
      setDesignationId('');
      setDesignationCustom('');
      setEmail('');
      setPhone('');
      setCurrentAddress('');
      setCity('');
      setState('');
      setPostalCode('');
      setCountry('USA');
      setEmergencyContactName('');
      setEmergencyContactPhone('');
      setEmergencyContactRelation('');
      setGender('female');
      setDateOfBirth('1988-06-15');
      setMaritalStatus('married');
      setNationality('American');
      setBloodGroup('O+');
      setNationalIdNumber('');
      setPassportNumber('');
      setEmploymentType('full_time');
      setEmploymentStatus('active');
      setJoiningDate(new Date().toISOString().split('T')[0]);
      setConfirmationDate('');
      setContractEndDate('');
      setQualification('Master of Science');
      setSpecialization('');
      setYearsOfExperience(3);
      setCreateAccount(true);
      setAccountUsername('');
      setAccountPassword('SygmateStaff@2026');
      setAccountRole('TEACHER');
    }
  }, [staffToEdit, isOpen, nextEmployeeCode]);

  // When staff type changes on create, refresh employee code and role
  const handleStaffTypeChange = async (type: StaffType) => {
    setStaffType(type);
    if (!isEdit && onFetchNextCode) {
      try {
        const code = await onFetchNextCode(type);
        setEmployeeCode(code);
      } catch (err) {
        // keep fallback
      }
    }
    if (type === 'teaching') setAccountRole('TEACHER');
    else if (type === 'management') setAccountRole('SUPER_ADMIN');
    else setAccountRole('STAFF' as any);
  };

  // Filter designations by department
  const filteredDesignations = designations.filter(
    (d) => !departmentId || !d.departmentId || d.departmentId === departmentId
  );

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!firstName.trim() || !lastName.trim()) {
      setError('First name and last name are required.');
      setActiveTab('profile');
      return;
    }
    if (!email.trim()) {
      setError('Email address is required.');
      setActiveTab('contact');
      return;
    }
    if (!phone.trim()) {
      setError('Phone number is required.');
      setActiveTab('contact');
      return;
    }
    if (!departmentId) {
      setError('Please select a department.');
      setActiveTab('organization');
      return;
    }

    const payload: any = {
      firstName: firstName.trim(),
      lastName: lastName.trim(),
      employeeCode: employeeCode.trim() || undefined,
      staffType,
      avatarUrl: avatarUrl.trim() || undefined,
      departmentId,
      designationId: designationId || undefined,
      designation: designationCustom.trim() || undefined,
      workLocation,
      workShift,
      email: email.trim().toLowerCase(),
      phone: phone.trim(),
      currentAddress: currentAddress.trim() || undefined,
      city: city.trim() || undefined,
      state: state.trim() || undefined,
      postalCode: postalCode.trim() || undefined,
      country: country.trim() || 'USA',
      emergencyContactName: emergencyContactName.trim() || undefined,
      emergencyContactPhone: emergencyContactPhone.trim() || undefined,
      emergencyContactRelation: emergencyContactRelation.trim() || undefined,
      gender,
      dateOfBirth: dateOfBirth || undefined,
      maritalStatus: maritalStatus || undefined,
      nationality: nationality || undefined,
      bloodGroup: bloodGroup || undefined,
      nationalIdNumber: nationalIdNumber.trim() || undefined,
      passportNumber: passportNumber.trim() || undefined,
      employmentType,
      employmentStatus,
      joiningDate,
      confirmationDate: confirmationDate || undefined,
      contractEndDate: contractEndDate || undefined,
      qualification: qualification.trim() || undefined,
      specialization: specialization.trim() || undefined,
      yearsOfExperience: Number(yearsOfExperience) || 0
    };

    if (!isEdit && createAccount) {
      payload.createAccount = true;
      payload.username = accountUsername.trim() || `${firstName.trim().toLowerCase()}.${lastName.trim().toLowerCase()}`;
      payload.password = accountPassword;
      payload.accountRole = accountRole;
    }

    try {
      await onSubmit(payload);
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to save staff profile.');
    }
  };

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto"
      id="staff-form-modal-overlay"
    >
      <div
        className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-3xl overflow-hidden my-8"
        id="staff-form-modal-container"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50/80">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-indigo-50 text-indigo-700 border border-indigo-200">
              <User className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-slate-900">
                {isEdit ? `Edit Staff Profile: ${staffToEdit?.displayName}` : 'Onboard New Staff Member'}
              </h3>
              <p className="text-xs text-slate-500">
                {isEdit
                  ? `Employee Code: ${staffToEdit?.employeeCode} • ${staffToEdit?.departmentName}`
                  : 'Institutional Human Resource Master Registry'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1 rounded-lg hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switcher */}
        <div className="flex border-b border-slate-200 bg-slate-50/40 px-6 gap-1 overflow-x-auto">
          <button
            type="button"
            onClick={() => setActiveTab('profile')}
            className={`py-2.5 px-3 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap ${
              activeTab === 'profile'
                ? 'border-indigo-600 text-indigo-700'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            1. Personal & Identity
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('organization')}
            className={`py-2.5 px-3 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap ${
              activeTab === 'organization'
                ? 'border-indigo-600 text-indigo-700'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            2. Department & Role
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('contact')}
            className={`py-2.5 px-3 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap ${
              activeTab === 'contact'
                ? 'border-indigo-600 text-indigo-700'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            3. Contact & Emergency
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('employment')}
            className={`py-2.5 px-3 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap ${
              activeTab === 'employment'
                ? 'border-indigo-600 text-indigo-700'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            4. Employment & Access
          </button>
        </div>

        {/* Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4" id="staff-form">
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-lg flex items-start gap-2 text-xs text-red-700">
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {/* TAB 1: Profile & Identity */}
          {activeTab === 'profile' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    First Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={firstName}
                    onChange={(e) => setFirstName(e.target.value)}
                    placeholder="E.g., Margaret"
                    required
                    className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                    id="staff-first-name-input"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Last Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={lastName}
                    onChange={(e) => setLastName(e.target.value)}
                    placeholder="E.g., Hamilton"
                    required
                    className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                    id="staff-last-name-input"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Staff Classification <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={staffType}
                    disabled={isEdit}
                    onChange={(e) => handleStaffTypeChange(e.target.value as StaffType)}
                    className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                    id="staff-type-select"
                  >
                    <option value="teaching">Teaching Faculty (Professors, Teachers, Instructors)</option>
                    <option value="administrative">Administrative (Registrar, Admissions, Finance)</option>
                    <option value="support">Student & Campus Support (Counselor, Nurse, IT)</option>
                    <option value="management">Executive & Management (Principal, Dean, Director)</option>
                    <option value="operational">Operational & Facilities (Transport, Security, Maintenance)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Employee Code <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={employeeCode}
                    onChange={(e) => setEmployeeCode(e.target.value)}
                    placeholder="Auto-generated if left empty"
                    className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 font-mono"
                    id="staff-employee-code-input"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Gender <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={gender}
                    onChange={(e) => setGender(e.target.value as Gender)}
                    className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                  >
                    <option value="female">Female</option>
                    <option value="male">Male</option>
                    <option value="other">Other / Non-Binary</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Date of Birth
                  </label>
                  <input
                    type="date"
                    value={dateOfBirth}
                    onChange={(e) => setDateOfBirth(e.target.value)}
                    className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Marital Status
                  </label>
                  <select
                    value={maritalStatus}
                    onChange={(e) => setMaritalStatus(e.target.value)}
                    className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                  >
                    <option value="">Select status</option>
                    <option value="single">Single</option>
                    <option value="married">Married</option>
                    <option value="divorced">Divorced</option>
                    <option value="widowed">Widowed</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Blood Group
                  </label>
                  <select
                    value={bloodGroup}
                    onChange={(e) => setBloodGroup(e.target.value)}
                    className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                  >
                    <option value="">Select blood group</option>
                    <option value="A+">A+</option>
                    <option value="A-">A-</option>
                    <option value="B+">B+</option>
                    <option value="B-">B-</option>
                    <option value="AB+">AB+</option>
                    <option value="AB-">AB-</option>
                    <option value="O+">O+</option>
                    <option value="O-">O-</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    National ID / SSN Number
                  </label>
                  <input
                    type="text"
                    value={nationalIdNumber}
                    onChange={(e) => setNationalIdNumber(e.target.value)}
                    placeholder="E.g., 842-10-9923"
                    className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Passport Number (If international)
                  </label>
                  <input
                    type="text"
                    value={passportNumber}
                    onChange={(e) => setPassportNumber(e.target.value)}
                    placeholder="E.g., P9823411"
                    className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 font-mono"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Profile Avatar URL
                  </label>
                  <input
                    type="text"
                    value={avatarUrl}
                    onChange={(e) => setAvatarUrl(e.target.value)}
                    placeholder="https://..."
                    className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                  />
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: Department & Role */}
          {activeTab === 'organization' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Department <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={departmentId}
                    onChange={(e) => setDepartmentId(e.target.value)}
                    required
                    className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                    id="staff-dept-select"
                  >
                    <option value="">Select Department</option>
                    {departments.map((d) => (
                      <option key={d.id} value={d.id}>
                        {d.name} ({d.category || 'unit'})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Designation / Title
                  </label>
                  <select
                    value={designationId}
                    onChange={(e) => {
                      setDesignationId(e.target.value);
                      const matched = designations.find((d) => d.id === e.target.value);
                      if (matched) setDesignationCustom(matched.title);
                    }}
                    className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                    id="staff-designation-select"
                  >
                    <option value="">Select Title / Position</option>
                    {filteredDesignations.map((d) => (
                      <option key={d.id} value={d.id}>
                        {d.title} ({d.code})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Custom Designation Title (Override)
                  </label>
                  <input
                    type="text"
                    value={designationCustom}
                    onChange={(e) => setDesignationCustom(e.target.value)}
                    placeholder="E.g., Senior Lecturer & Lab Director"
                    className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Work Location / Campus
                  </label>
                  <input
                    type="text"
                    value={workLocation}
                    onChange={(e) => setWorkLocation(e.target.value)}
                    placeholder="Main Campus / North Wing"
                    className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Work Shift Schedule
                  </label>
                  <select
                    value={workShift}
                    onChange={(e) => setWorkShift(e.target.value)}
                    className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                  >
                    <option value="morning">Morning Shift (07:30 - 15:30)</option>
                    <option value="general">General Shift (08:30 - 16:30)</option>
                    <option value="evening">Evening Shift (13:00 - 21:00)</option>
                    <option value="rotational">Rotational Shift</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: Contact & Emergency */}
          {activeTab === 'contact' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Email Address <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="staff.name@sygmateschools.edu"
                    required
                    className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                    id="staff-email-input"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Phone Number <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+1 (555) 019-2834"
                    required
                    className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                    id="staff-phone-input"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Current Residential Address
                  </label>
                  <input
                    type="text"
                    value={currentAddress}
                    onChange={(e) => setCurrentAddress(e.target.value)}
                    placeholder="Street address, apartment, suite"
                    className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    City
                  </label>
                  <input
                    type="text"
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    placeholder="Springfield"
                    className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    State / Province
                  </label>
                  <input
                    type="text"
                    value={state}
                    onChange={(e) => setState(e.target.value)}
                    placeholder="Illinois"
                    className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                  />
                </div>

                {/* Emergency Contact Header */}
                <div className="sm:col-span-2 pt-2 border-t border-slate-200">
                  <h5 className="text-xs font-semibold text-slate-900 flex items-center gap-1.5 mb-2">
                    <HeartPulse className="w-3.5 h-3.5 text-red-500" /> Emergency Contact Details
                  </h5>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Emergency Contact Name
                  </label>
                  <input
                    type="text"
                    value={emergencyContactName}
                    onChange={(e) => setEmergencyContactName(e.target.value)}
                    placeholder="E.g., James Hamilton"
                    className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Emergency Phone Number
                  </label>
                  <input
                    type="tel"
                    value={emergencyContactPhone}
                    onChange={(e) => setEmergencyContactPhone(e.target.value)}
                    placeholder="+1 (555) 984-2200"
                    className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Relationship
                  </label>
                  <input
                    type="text"
                    value={emergencyContactRelation}
                    onChange={(e) => setEmergencyContactRelation(e.target.value)}
                    placeholder="Spouse / Parent / Sibling"
                    className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                  />
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: Employment & Access */}
          {activeTab === 'employment' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Employment Type <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={employmentType}
                    onChange={(e) => setEmploymentType(e.target.value as EmploymentType)}
                    className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                  >
                    <option value="full_time">Full-Time Permanent</option>
                    <option value="part_time">Part-Time</option>
                    <option value="contract">Fixed Term Contract</option>
                    <option value="probation">Probationary Period</option>
                    <option value="visiting">Visiting Faculty</option>
                    <option value="temporary">Temporary / Seasonal</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Initial Employment Status <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={employmentStatus}
                    onChange={(e) => setEmploymentStatus(e.target.value as EmploymentStatus)}
                    className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                  >
                    <option value="active">Active</option>
                    <option value="probation">Probationary</option>
                    <option value="on_leave">On Leave</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Official Joining Date <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="date"
                    value={joiningDate}
                    onChange={(e) => setJoiningDate(e.target.value)}
                    required
                    className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Highest Educational Qualification
                  </label>
                  <input
                    type="text"
                    value={qualification}
                    onChange={(e) => setQualification(e.target.value)}
                    placeholder="E.g., Ph.D. in Computer Science"
                    className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Specialization / Major
                  </label>
                  <input
                    type="text"
                    value={specialization}
                    onChange={(e) => setSpecialization(e.target.value)}
                    placeholder="E.g., Algorithms & Applied Artificial Intelligence"
                    className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Total Prior Experience (Years)
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="60"
                    value={yearsOfExperience}
                    onChange={(e) => setYearsOfExperience(Number(e.target.value))}
                    className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                  />
                </div>
              </div>

              {/* Account Provisioning for New Staff */}
              {!isEdit && (
                <div className="pt-3 border-t border-slate-200">
                  <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={createAccount}
                        onChange={(e) => setCreateAccount(e.target.checked)}
                        className="rounded text-indigo-600 focus:ring-indigo-500 border-slate-300"
                        id="provision-account-checkbox"
                      />
                      <span className="text-xs font-semibold text-slate-900">
                        Automatically provision login credentials for this staff member
                      </span>
                    </label>

                    {createAccount && (
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                        <div>
                          <label className="block text-[11px] font-medium text-slate-700 mb-1">
                            Username
                          </label>
                          <input
                            type="text"
                            value={accountUsername}
                            onChange={(e) => setAccountUsername(e.target.value)}
                            placeholder="Defaults to first.last"
                            className="w-full text-xs rounded-lg border border-slate-300 px-3 py-1.5 text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-medium text-slate-700 mb-1">
                            Initial Password
                          </label>
                          <input
                            type="text"
                            value={accountPassword}
                            onChange={(e) => setAccountPassword(e.target.value)}
                            className="w-full text-xs rounded-lg border border-slate-300 px-3 py-1.5 text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500 font-mono"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-medium text-slate-700 mb-1">
                            System Role
                          </label>
                          <select
                            value={accountRole}
                            onChange={(e) => setAccountRole(e.target.value as UserRole)}
                            className="w-full text-xs rounded-lg border border-slate-300 px-3 py-1.5 text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                          >
                            <option value="TEACHER">TEACHER</option>
                            <option value="STAFF">STAFF</option>
                            <option value="SUPER_ADMIN">SUPER_ADMIN</option>
                          </select>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Footer controls */}
          <div className="flex items-center justify-between pt-4 border-t border-slate-200">
            <div className="flex gap-2">
              {activeTab !== 'profile' && (
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    if (activeTab === 'employment') setActiveTab('contact');
                    else if (activeTab === 'contact') setActiveTab('organization');
                    else if (activeTab === 'organization') setActiveTab('profile');
                  }}
                >
                  Previous Step
                </Button>
              )}
              {activeTab !== 'employment' && (
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    if (activeTab === 'profile') setActiveTab('organization');
                    else if (activeTab === 'organization') setActiveTab('contact');
                    else if (activeTab === 'contact') setActiveTab('employment');
                  }}
                >
                  Next Step
                </Button>
              )}
            </div>

            <div className="flex items-center gap-2">
              <Button type="button" variant="outline" size="sm" onClick={onClose}>
                Cancel
              </Button>
              <Button
                type="submit"
                variant="primary"
                size="sm"
                isLoading={isSubmitting}
                id="save-staff-profile-btn"
              >
                {isEdit ? 'Save Changes' : 'Complete Staff Onboarding'}
              </Button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
