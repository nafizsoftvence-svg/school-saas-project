/**
 * Sygmate School Management System
 * Interviews & Panel Evaluations Sub-View (Part 12D)
 */

import React, { useState } from 'react';
import {
  Calendar,
  Clock,
  MapPin,
  Video,
  Users,
  Award,
  CheckCircle2,
  AlertCircle,
  Star,
  RefreshCw,
  Search,
  ChevronRight,
  UserCheck
} from 'lucide-react';
import { Button } from '../../../../components/ui/Button.js';
import { api } from '../../../../services/api.js';
import {
  JobInterview,
  JobApplication,
  CandidateProfile,
  JobOpening,
  SubmitEvaluationPayload,
  EvaluationRecommendation
} from '../../../../types/index.js';

interface LocalEvaluationRubric {
  criterion: string;
  maxScore: number;
  score: number;
  comments?: string;
}

interface InterviewsSubViewProps {
  interviews: JobInterview[];
  applications: JobApplication[];
  candidates: CandidateProfile[];
  openings: JobOpening[];
  onRefresh: () => void;
}

export const InterviewsSubView: React.FC<InterviewsSubViewProps> = ({
  interviews,
  applications,
  candidates,
  openings,
  onRefresh
}) => {
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  // Evaluation Modal
  const [selectedInterviewForEval, setSelectedInterviewForEval] = useState<JobInterview | null>(null);
  const [evalRecommendation, setEvalRecommendation] = useState<'STRONG_HIRE' | 'HIRE' | 'RE_INTERVIEW' | 'DO_NOT_HIRE'>('HIRE');
  const [evalStrengths, setEvalStrengths] = useState<string>('');
  const [evalWeaknesses, setEvalWeaknesses] = useState<string>('');
  const [evalComments, setEvalComments] = useState<string>('');
  const [rubrics, setRubrics] = useState<LocalEvaluationRubric[]>([
    { criterion: 'Subject Knowledge & Technical Competence', maxScore: 5, score: 4, comments: 'Solid foundation' },
    { criterion: 'Pedagogy & Classroom Delivery', maxScore: 5, score: 4, comments: 'Engaging style' },
    { criterion: 'Communication & Interpersonal Skills', maxScore: 5, score: 5, comments: 'Clear & articulate' },
    { criterion: 'Problem Solving & Academic Leadership', maxScore: 5, score: 4, comments: 'Good initiative' },
    { criterion: 'Institutional Culture & Values Alignment', maxScore: 5, score: 5, comments: 'Strong alignment' }
  ]);
  const [isSubmittingEval, setIsSubmittingEval] = useState<boolean>(false);
  const [evalError, setEvalError] = useState<string | null>(null);

  // Reschedule Modal
  const [interviewToReschedule, setInterviewToReschedule] = useState<JobInterview | null>(null);
  const [rescheduleDate, setRescheduleDate] = useState<string>('');
  const [rescheduleStart, setRescheduleStart] = useState<string>('11:00');
  const [rescheduleEnd, setRescheduleEnd] = useState<string>('12:00');
  const [rescheduleReason, setRescheduleReason] = useState<string>('Faculty scheduling conflict');
  const [isSubmittingReschedule, setIsSubmittingReschedule] = useState<boolean>(false);

  const filteredInterviews = interviews.filter((i) => {
    if (statusFilter !== 'all' && i.status !== statusFilter) return false;
    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      const match =
        i.candidateName.toLowerCase().includes(q) ||
        i.jobTitle.toLowerCase().includes(q) ||
        i.interviewNumber.toLowerCase().includes(q) ||
        i.roundName.toLowerCase().includes(q);
      if (!match) return false;
    }
    return true;
  });

  const handleScoreChange = (index: number, val: number) => {
    setRubrics((prev) => {
      const updated = [...prev];
      updated[index] = { ...updated[index], score: val };
      return updated;
    });
  };

  const handleSubmitEvaluation = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedInterviewForEval) return;
    setIsSubmittingEval(true);
    setEvalError(null);

    const rec: EvaluationRecommendation =
      evalRecommendation === 'RE_INTERVIEW' ? 'MAYBE' : evalRecommendation;

    const payload: SubmitEvaluationPayload = {
      technicalSkillsScore: rubrics?.[0]?.score || 4,
      subjectKnowledgeScore: rubrics?.[0]?.score || 4,
      teachingDemonstrationScore: rubrics?.[1]?.score || 4,
      communicationScore: rubrics?.[2]?.score || 5,
      problemSolvingScore: rubrics?.[3]?.score || 4,
      professionalismScore: rubrics?.[4]?.score || 5,
      experienceScore: 4,
      recommendation: rec,
      strengthsNotes: evalStrengths,
      weaknessesNotes: evalWeaknesses,
      generalComments: evalComments
    };

    try {
      await api.staff.recruitment.submitInterviewEvaluation(selectedInterviewForEval.id, payload);
      setSelectedInterviewForEval(null);
      onRefresh();
    } catch (err: any) {
      setEvalError(err.message || 'Failed to submit evaluation.');
    } finally {
      setIsSubmittingEval(false);
    }
  };

  const handleReschedule = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!interviewToReschedule) return;
    setIsSubmittingReschedule(true);
    try {
      await api.staff.recruitment.rescheduleInterview(interviewToReschedule.id, {
        newDate: rescheduleDate,
        newStartTime: rescheduleStart,
        newEndTime: rescheduleEnd,
        reason: rescheduleReason
      });
      setInterviewToReschedule(null);
      onRefresh();
    } catch (err: any) {
      alert(err.message || 'Failed to reschedule.');
    } finally {
      setIsSubmittingReschedule(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* Filters Header */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex flex-col md:flex-row gap-3 items-center justify-between">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search candidate, job, interview ID..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-slate-50/50"
          />
        </div>

        <div className="flex items-center gap-2">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 text-xs border border-slate-200 rounded-lg bg-white text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="all">All Statuses</option>
            <option value="SCHEDULED">Scheduled</option>
            <option value="CONFIRMED">Confirmed</option>
            <option value="COMPLETED">Completed</option>
            <option value="RESCHEDULED">Rescheduled</option>
            <option value="CANCELLED">Cancelled</option>
          </select>
        </div>
      </div>

      {/* Grid of Interview Cards */}
      {filteredInterviews.length === 0 ? (
        <div className="p-12 text-center bg-white rounded-xl border border-slate-200 text-slate-500 space-y-2">
          <Calendar className="w-10 h-10 mx-auto text-slate-300" />
          <p className="text-sm font-semibold">No interviews scheduled matching criteria.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredInterviews.map((intv) => {
            const hasEvaluations = intv.evaluations && intv.evaluations.length > 0;
            return (
              <div
                key={intv.id}
                className="bg-white rounded-xl border border-slate-200 shadow-2xs p-5 space-y-4 hover:shadow-xs transition-shadow"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-100 text-slate-600 font-semibold">
                      {intv.interviewNumber}
                    </span>
                    <h3 className="text-sm font-bold text-slate-900 mt-1">{intv.candidateName}</h3>
                    <p className="text-xs text-indigo-700 font-medium">
                      {intv.jobTitle} • {intv.roundName}
                    </p>
                  </div>

                  <span
                    className={`text-[10px] px-2.5 py-1 rounded-full font-bold uppercase tracking-wider ${
                      intv.status === 'COMPLETED'
                        ? 'bg-emerald-100 text-emerald-800'
                        : intv.status === 'RESCHEDULED'
                        ? 'bg-amber-100 text-amber-800'
                        : intv.status === 'CANCELLED'
                        ? 'bg-rose-100 text-rose-800'
                        : 'bg-indigo-100 text-indigo-800'
                    }`}
                  >
                    {intv.status}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs text-slate-600 bg-slate-50/70 p-3 rounded-lg border border-slate-200">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span>{intv.interviewDate}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span>{intv.startTime} - {intv.endTime}</span>
                  </div>
                  <div className="col-span-2 flex items-center gap-2">
                    {intv.interviewType === 'IN_PERSON' ? (
                      <>
                        <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span className="truncate">{intv.location || 'Campus venue'}</span>
                      </>
                    ) : (
                      <>
                        <Video className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
                        <a
                          href={intv.meetingLink || '#'}
                          target="_blank"
                          rel="noreferrer"
                          className="text-indigo-600 hover:underline truncate"
                        >
                          {intv.meetingLink || 'Virtual Meeting'}
                        </a>
                      </>
                    )}
                  </div>
                </div>

                {/* Panel Members */}
                <div className="space-y-1">
                  <span className="text-[11px] font-bold text-slate-700 block">Interview Panel:</span>
                  <div className="flex flex-wrap gap-1.5">
                    {intv.panelMembers.map((m) => (
                      <span
                        key={m.userId}
                        className="text-[11px] px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 flex items-center gap-1"
                      >
                        <Users className="w-2.5 h-2.5 text-slate-400" />
                        <span>{m.userName}</span>
                        {m.hasSubmittedScore && (
                          <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                        )}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Evaluation Status & Consensus */}
                {hasEvaluations && (
                  <div className="p-3 bg-emerald-50/60 rounded-lg border border-emerald-100 space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-emerald-900 flex items-center gap-1">
                        <Award className="w-3.5 h-3.5 text-emerald-600" />
                        Overall Evaluation Score:
                      </span>
                      <span className="font-bold text-emerald-800 text-sm">{intv.overallScore}/100</span>
                    </div>
                    <div className="text-[11px] text-emerald-700">
                      Consensus: <strong className="capitalize">{intv.recommendation?.replace(/_/g, ' ') || 'Completed'}</strong>
                    </div>
                  </div>
                )}

                {/* Card Actions */}
                <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                  <button
                    type="button"
                    onClick={() => {
                      setInterviewToReschedule(intv);
                      setRescheduleDate(intv.interviewDate);
                      setRescheduleStart(intv.startTime);
                      setRescheduleEnd(intv.endTime);
                    }}
                    className="text-xs text-slate-600 hover:text-slate-900 font-medium"
                  >
                    Reschedule
                  </button>

                  <div className="flex items-center gap-2">
                    <Button
                      type="button"
                      variant={hasEvaluations ? 'outline' : 'primary'}
                      size="sm"
                      onClick={() => setSelectedInterviewForEval(intv)}
                      icon={<Award className="w-3.5 h-3.5" />}
                    >
                      {hasEvaluations ? 'Update Evaluation' : 'Score Candidate'}
                    </Button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Evaluation Rubric Modal */}
      {selectedInterviewForEval && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in">
          <div className="bg-white rounded-2xl max-w-2xl w-full p-6 space-y-5 max-h-[90vh] overflow-y-auto shadow-xl">
            <div className="flex items-start justify-between border-b border-slate-100 pb-4">
              <div>
                <div className="flex items-center gap-2">
                  <Award className="w-5 h-5 text-indigo-600" />
                  <h2 className="text-base font-bold text-slate-900">Candidate Evaluation & Scoring</h2>
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  Candidate: <strong className="text-slate-800">{selectedInterviewForEval.candidateName}</strong> • {selectedInterviewForEval.roundName}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setSelectedInterviewForEval(null)}
                className="text-slate-400 hover:text-slate-600 text-xl font-bold"
              >
                &times;
              </button>
            </div>

            {evalError && (
              <div className="p-3 bg-red-50 text-red-700 text-xs rounded-lg border border-red-200 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{evalError}</span>
              </div>
            )}

            <form onSubmit={handleSubmitEvaluation} className="space-y-4 text-xs">
              {/* Rubric Criteria Table */}
              <div className="space-y-2">
                <label className="font-bold text-slate-800 block text-xs">
                  Objective Evaluation Rubrics (1 - 5 Rating)
                </label>
                <div className="border border-slate-200 rounded-lg overflow-hidden">
                  <table className="w-full text-left">
                    <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold text-[10px] uppercase">
                      <tr>
                        <th className="py-2.5 px-3">Competency & Rubric</th>
                        <th className="py-2.5 px-3 text-center w-36">Score (1 to 5)</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {rubrics.map((r, idx) => (
                        <tr key={idx} className="hover:bg-slate-50/50">
                          <td className="py-2.5 px-3">
                            <span className="font-medium text-slate-800 block">{r.criterion}</span>
                          </td>
                          <td className="py-2.5 px-3">
                            <div className="flex items-center justify-center gap-1.5">
                              {[1, 2, 3, 4, 5].map((star) => (
                                <button
                                  type="button"
                                  key={star}
                                  onClick={() => handleScoreChange(idx, star)}
                                  className={`w-6 h-6 rounded-md font-bold text-xs transition-colors ${
                                    r.score >= star
                                      ? 'bg-amber-400 text-amber-950 shadow-2xs'
                                      : 'bg-slate-100 text-slate-400 hover:bg-slate-200'
                                  }`}
                                >
                                  {star}
                                </button>
                              ))}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Recommendation Selection */}
              <div>
                <label className="font-bold text-slate-800 block mb-1">Overall Hiring Recommendation</label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {[
                    { id: 'STRONG_HIRE', label: 'Strong Hire', color: 'border-emerald-500 bg-emerald-50 text-emerald-800' },
                    { id: 'HIRE', label: 'Hire / Selected', color: 'border-blue-500 bg-blue-50 text-blue-800' },
                    { id: 'RE_INTERVIEW', label: 'Re-Interview', color: 'border-amber-500 bg-amber-50 text-amber-800' },
                    { id: 'DO_NOT_HIRE', label: 'Do Not Hire', color: 'border-rose-500 bg-rose-50 text-rose-800' }
                  ].map((item) => (
                    <button
                      type="button"
                      key={item.id}
                      onClick={() => setEvalRecommendation(item.id as any)}
                      className={`p-2.5 rounded-lg border text-center font-bold text-xs transition-all ${
                        evalRecommendation === item.id
                          ? `${item.color} ring-2 ring-indigo-500`
                          : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Key Strengths Demonstrated</label>
                  <textarea
                    rows={2}
                    value={evalStrengths}
                    onChange={(e) => setEvalStrengths(e.target.value)}
                    placeholder="E.g. Exceptional command of curriculum, high energy..."
                    className="w-full p-2 border border-slate-200 rounded-lg bg-white focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Areas for Development / Concerns</label>
                  <textarea
                    rows={2}
                    value={evalWeaknesses}
                    onChange={(e) => setEvalWeaknesses(e.target.value)}
                    placeholder="E.g. Needs familiarity with school ERP..."
                    className="w-full p-2 border border-slate-200 rounded-lg bg-white focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">General Panel Remarks & Recommendation</label>
                <textarea
                  rows={2}
                  value={evalComments}
                  onChange={(e) => setEvalComments(e.target.value)}
                  placeholder="Final observations for HR and head of institution..."
                  className="w-full p-2 border border-slate-200 rounded-lg bg-white focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setSelectedInterviewForEval(null)}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  variant="primary"
                  size="sm"
                  disabled={isSubmittingEval}
                >
                  {isSubmittingEval ? 'Saving...' : 'Submit Official Evaluation'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Reschedule Modal */}
      {interviewToReschedule && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 space-y-4 shadow-xl text-xs">
            <h3 className="text-sm font-bold text-slate-900">Reschedule Interview Round</h3>
            <p className="text-slate-500">
              Update timing for candidate <strong className="text-slate-800">{interviewToReschedule.candidateName}</strong>. Panelists will be notified.
            </p>

            <form onSubmit={handleReschedule} className="space-y-3">
              <div>
                <label className="font-semibold text-slate-700 block mb-1">New Date</label>
                <input
                  type="date"
                  value={rescheduleDate}
                  onChange={(e) => setRescheduleDate(e.target.value)}
                  required
                  className="w-full p-2 border border-slate-200 rounded-lg bg-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Start Time</label>
                  <input
                    type="time"
                    value={rescheduleStart}
                    onChange={(e) => setRescheduleStart(e.target.value)}
                    required
                    className="w-full p-2 border border-slate-200 rounded-lg bg-white"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">End Time</label>
                  <input
                    type="time"
                    value={rescheduleEnd}
                    onChange={(e) => setRescheduleEnd(e.target.value)}
                    required
                    className="w-full p-2 border border-slate-200 rounded-lg bg-white"
                  />
                </div>
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Reason for Rescheduling</label>
                <input
                  type="text"
                  value={rescheduleReason}
                  onChange={(e) => setRescheduleReason(e.target.value)}
                  required
                  className="w-full p-2 border border-slate-200 rounded-lg bg-white"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setInterviewToReschedule(null)}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  variant="primary"
                  size="sm"
                  disabled={isSubmittingReschedule}
                >
                  {isSubmittingReschedule ? 'Saving...' : 'Confirm Reschedule'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
