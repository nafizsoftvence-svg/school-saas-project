/**
 * Sygmate School Management System
 * Schedule Interview Round Modal (Part 12D)
 */

import React, { useState, useEffect } from 'react';
import {
  Calendar,
  Clock,
  MapPin,
  Video,
  Users,
  AlertTriangle,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { Button } from '../../../../components/ui/Button.js';
import { api } from '../../../../services/api.js';
import {
  CandidateProfile,
  JobApplication,
  ScheduleInterviewPayload,
  StaffProfile
} from '../../../../types/index.js';

interface ScheduleInterviewModalProps {
  isOpen: boolean;
  candidate: CandidateProfile;
  application?: JobApplication;
  onClose: () => void;
  onSuccess: () => void;
}

export const ScheduleInterviewModal: React.FC<ScheduleInterviewModalProps> = ({
  isOpen,
  candidate,
  application,
  onClose,
  onSuccess
}) => {
  const [roundNumber, setRoundNumber] = useState<number>(1);
  const [roundName, setRoundName] = useState<string>('First Round Technical & Pedagogy');
  const [interviewType, setInterviewType] = useState<'IN_PERSON' | 'ONLINE_VIDEO' | 'PHONE'>('IN_PERSON');
  const [interviewDate, setInterviewDate] = useState<string>(
    new Date(Date.now() + 86400000 * 2).toISOString().split('T')[0]
  );
  const [startTime, setStartTime] = useState<string>('10:00');
  const [endTime, setEndTime] = useState<string>('11:00');
  const [location, setLocation] = useState<string>('Administrative Block, Conference Room 2');
  const [meetingLink, setMeetingLink] = useState<string>('');
  const [instructions, setInstructions] = useState<string>(
    'Please bring original academic degree transcripts and prepared 15-minute lesson demonstration outline.'
  );

  // Available staff for interview panel
  const [availableStaff, setAvailableStaff] = useState<StaffProfile[]>([]);
  const [selectedPanelIds, setSelectedPanelIds] = useState<string[]>([]);

  const [isLoadingStaff, setIsLoadingStaff] = useState<boolean>(true);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadStaff = async () => {
      try {
        const res = await api.staff.getDirectory({ limit: 50 });
        const staffList = Array.isArray((res as any)?.data)
          ? (res as any).data
          : Array.isArray((res as any)?.items)
          ? (res as any).items
          : Array.isArray(res)
          ? res
          : [];
        if (staffList.length > 0) {
          setAvailableStaff(staffList);
          setSelectedPanelIds(staffList.slice(0, 2).map((s: any) => s.id));
        }
      } catch (err) {
        console.error('Failed to load staff for interview panel', err);
      } finally {
        setIsLoadingStaff(false);
      }
    };
    loadStaff();
  }, []);

  const handleTogglePanelMember = (staffId: string) => {
    setSelectedPanelIds((prev) =>
      prev.includes(staffId) ? prev.filter((id) => id !== staffId) : [...prev, staffId]
    );
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!application && !candidate.appliedPositionId) {
      setError('Cannot schedule interview without an active application.');
      return;
    }

    if (selectedPanelIds.length === 0) {
      setError('Please select at least one panel evaluator.');
      return;
    }

    setIsSubmitting(true);
    setError(null);

    const payload: ScheduleInterviewPayload = {
      applicationId: application?.id || `app-${candidate.id}`,
      interviewRound: roundNumber,
      roundName,
      interviewType,
      interviewDate,
      startTime,
      endTime,
      location: interviewType === 'IN_PERSON' ? (location || 'School Campus') : 'Online Video Meeting',
      meetingLink: interviewType === 'ONLINE_VIDEO' ? meetingLink || 'https://meet.google.com/syg-intv-demo' : undefined,
      panelUserIds: selectedPanelIds,
      notes: instructions
    };

    try {
      await api.staff.recruitment.scheduleInterview(payload);
      onSuccess();
    } catch (err: any) {
      setError(err.message || 'Failed to schedule interview round.');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in">
      <div className="bg-white rounded-2xl max-w-xl w-full p-6 space-y-5 max-h-[90vh] overflow-y-auto shadow-xl">
        <div className="flex items-start justify-between border-b border-slate-100 pb-4">
          <div>
            <div className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-indigo-600" />
              <h2 className="text-base font-bold text-slate-900">Schedule Interview Round</h2>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Candidate: <strong className="text-slate-800">{candidate.fullName}</strong> ({candidate.appliedPositionTitle})
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 text-xl font-bold"
          >
            &times;
          </button>
        </div>

        {error && (
          <div className="p-3 bg-red-50 text-red-700 text-xs rounded-lg border border-red-200 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="font-semibold text-slate-700 block mb-1">Round Number</label>
              <select
                value={roundNumber}
                onChange={(e) => setRoundNumber(Number(e.target.value))}
                className="w-full p-2 border border-slate-200 rounded-lg bg-white focus:ring-2 focus:ring-indigo-500"
              >
                <option value={1}>Round 1: Screening / Technical</option>
                <option value={2}>Round 2: Demonstration / Pedagogy</option>
                <option value={3}>Round 3: Department Head & Leadership</option>
                <option value={4}>Round 4: Final HR & Governance</option>
              </select>
            </div>

            <div>
              <label className="font-semibold text-slate-700 block mb-1">Round Title / Label</label>
              <input
                type="text"
                value={roundName}
                onChange={(e) => setRoundName(e.target.value)}
                required
                className="w-full p-2 border border-slate-200 rounded-lg bg-white focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="font-semibold text-slate-700 block mb-1">Interview Format</label>
              <select
                value={interviewType}
                onChange={(e) => setInterviewType(e.target.value as any)}
                className="w-full p-2 border border-slate-200 rounded-lg bg-white focus:ring-2 focus:ring-indigo-500"
              >
                <option value="IN_PERSON">In-Person Campus</option>
                <option value="ONLINE_VIDEO">Online Video (Google Meet)</option>
                <option value="PHONE">Telephone Conference</option>
              </select>
            </div>

            <div>
              <label className="font-semibold text-slate-700 block mb-1">Interview Date</label>
              <input
                type="date"
                value={interviewDate}
                onChange={(e) => setInterviewDate(e.target.value)}
                required
                className="w-full p-2 border border-slate-200 rounded-lg bg-white focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-1.5">
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Start</label>
                <input
                  type="time"
                  value={startTime}
                  onChange={(e) => setStartTime(e.target.value)}
                  required
                  className="w-full p-2 border border-slate-200 rounded-lg bg-white focus:ring-2 focus:ring-indigo-500"
                />
              </div>
              <div>
                <label className="font-semibold text-slate-700 block mb-1">End</label>
                <input
                  type="time"
                  value={endTime}
                  onChange={(e) => setEndTime(e.target.value)}
                  required
                  className="w-full p-2 border border-slate-200 rounded-lg bg-white focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>
          </div>

          {interviewType === 'IN_PERSON' ? (
            <div>
              <label className="font-semibold text-slate-700 block mb-1">Campus Room / Venue</label>
              <input
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                required
                className="w-full p-2 border border-slate-200 rounded-lg bg-white focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          ) : (
            <div>
              <label className="font-semibold text-slate-700 block mb-1">Meeting Link (Video/Conference)</label>
              <input
                type="url"
                value={meetingLink}
                onChange={(e) => setMeetingLink(e.target.value)}
                placeholder="https://meet.google.com/..."
                className="w-full p-2 border border-slate-200 rounded-lg bg-white focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          )}

          {/* Panel Evaluators Selection */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="font-semibold text-slate-700 block">
                Assign Interview Panel Members ({selectedPanelIds.length} selected)
              </label>
              <span className="text-[11px] text-slate-400">Institutional Faculty & Evaluators</span>
            </div>

            <div className="border border-slate-200 rounded-lg p-2.5 max-h-36 overflow-y-auto space-y-1 bg-slate-50/50">
              {isLoadingStaff ? (
                <div className="text-center py-4 text-slate-400">Loading faculty list...</div>
              ) : availableStaff.length === 0 ? (
                <div className="text-center py-4 text-slate-400">No staff members found.</div>
              ) : (
                availableStaff.map((staff) => {
                  const isChecked = selectedPanelIds.includes(staff.id);
                  return (
                    <label
                      key={staff.id}
                      className={`flex items-center justify-between p-2 rounded-md cursor-pointer transition-colors ${
                        isChecked ? 'bg-indigo-50 border border-indigo-200' : 'hover:bg-white'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => handleTogglePanelMember(staff.id)}
                          className="rounded text-indigo-600 focus:ring-indigo-500"
                        />
                        <div>
                          <span className="font-bold text-slate-900 block text-xs">
                            {staff.firstName} {staff.lastName}
                          </span>
                          <span className="text-[10px] text-slate-500">
                            {staff.designation} • {staff.departmentName}
                          </span>
                        </div>
                      </div>
                      <span className="text-[10px] font-mono text-slate-500">{staff.employeeCode}</span>
                    </label>
                  );
                })
              )}
            </div>
          </div>

          <div>
            <label className="font-semibold text-slate-700 block mb-1">Instructions for Candidate & Panel</label>
            <textarea
              rows={2}
              value={instructions}
              onChange={(e) => setInstructions(e.target.value)}
              className="w-full p-2 border border-slate-200 rounded-lg bg-white focus:ring-2 focus:ring-indigo-500 text-xs"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
            <Button type="button" variant="outline" size="sm" onClick={onClose}>
              Cancel
            </Button>
            <Button
              type="submit"
              variant="primary"
              size="sm"
              disabled={isSubmitting}
            >
              {isSubmitting ? 'Scheduling...' : 'Confirm Interview'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};
