/**
 * Sygmate School Management System
 * Job Openings Sub-View (Part 12D)
 */

import React, { useState } from 'react';
import {
  Briefcase,
  Search,
  Filter,
  Building,
  Calendar,
  DollarSign,
  MapPin,
  CheckCircle2,
  Users,
  Edit2,
  Trash2,
  Archive,
  ExternalLink,
  Plus,
  AlertCircle
} from 'lucide-react';
import { Button } from '../../../../components/ui/Button.js';
import { api } from '../../../../services/api.js';
import {
  JobOpening,
  Department,
  Designation
} from '../../../../types/index.js';

interface JobOpeningsSubViewProps {
  openings: JobOpening[];
  departments: Department[];
  designations: Designation[];
  onRefresh: () => void;
  onOpenCreateModal: () => void;
  onViewCandidates: (jobId: string) => void;
}

export const JobOpeningsSubView: React.FC<JobOpeningsSubViewProps> = ({
  openings,
  departments,
  designations,
  onRefresh,
  onOpenCreateModal,
  onViewCandidates
}) => {
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [departmentFilter, setDepartmentFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [staffTypeFilter, setStaffTypeFilter] = useState<string>('all');

  const [selectedOpeningForDetail, setSelectedOpeningForDetail] = useState<JobOpening | null>(null);
  const [isDeleting, setIsDeleting] = useState<boolean>(false);
  const [actionError, setActionError] = useState<string | null>(null);

  // Filtered List
  const filteredOpenings = openings.filter((job) => {
    if (departmentFilter !== 'all' && job.departmentId !== departmentFilter) return false;
    if (statusFilter !== 'all' && job.status !== statusFilter) return false;
    if (staffTypeFilter !== 'all' && job.staffType !== staffTypeFilter) return false;
    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      const match =
        job.title.toLowerCase().includes(q) ||
        job.code.toLowerCase().includes(q) ||
        job.departmentName.toLowerCase().includes(q) ||
        job.designationTitle.toLowerCase().includes(q) ||
        job.requiredSkills.some((s) => s.toLowerCase().includes(q));
      if (!match) return false;
    }
    return true;
  });

  const handleDelete = async (id: string) => {
    if (!window.confirm('Are you sure you want to archive or remove this job opening?')) return;
    setIsDeleting(true);
    setActionError(null);
    try {
      await api.staff.recruitment.deleteJobOpening(id);
      onRefresh();
      if (selectedOpeningForDetail?.id === id) {
        setSelectedOpeningForDetail(null);
      }
    } catch (err: any) {
      setActionError(err.message || 'Failed to delete job opening.');
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* Filter Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex flex-col md:flex-row gap-3 items-center justify-between">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search title, code, skills..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-slate-50/50"
          />
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto flex-wrap">
          <select
            value={departmentFilter}
            onChange={(e) => setDepartmentFilter(e.target.value)}
            className="px-3 py-2 text-xs border border-slate-200 rounded-lg bg-white text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="all">All Departments</option>
            {departments.map((d) => (
              <option key={d.id} value={d.id}>
                {d.name}
              </option>
            ))}
          </select>

          <select
            value={staffTypeFilter}
            onChange={(e) => setStaffTypeFilter(e.target.value)}
            className="px-3 py-2 text-xs border border-slate-200 rounded-lg bg-white text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="all">All Classifications</option>
            <option value="teaching">Teaching Faculty</option>
            <option value="administrative">Administrative</option>
            <option value="support">Support</option>
            <option value="management">Management</option>
            <option value="operational">Operational</option>
          </select>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 text-xs border border-slate-200 rounded-lg bg-white text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="all">All Statuses</option>
            <option value="APPLICATIONS_OPEN">Applications Open</option>
            <option value="PUBLISHED">Published</option>
            <option value="DRAFT">Draft</option>
            <option value="FILLED">Filled</option>
            <option value="CLOSED">Closed</option>
            <option value="ARCHIVED">Archived</option>
          </select>

          <Button
            type="button"
            variant="primary"
            size="sm"
            onClick={onOpenCreateModal}
            icon={<Plus className="w-3.5 h-3.5" />}
          >
            New Opening
          </Button>
        </div>
      </div>

      {actionError && (
        <div className="p-3 bg-red-50 text-red-700 text-xs rounded-lg border border-red-200 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{actionError}</span>
        </div>
      )}

      {/* Main Grid View */}
      {filteredOpenings.length === 0 ? (
        <div className="p-12 text-center bg-white rounded-xl border border-slate-200 text-slate-500 space-y-3">
          <Briefcase className="w-10 h-10 mx-auto text-slate-300" />
          <p className="text-sm font-semibold">No job openings found matching the criteria.</p>
          <Button type="button" variant="outline" size="sm" onClick={onOpenCreateModal}>
            Create First Opening
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredOpenings.map((job) => {
            const fillRate = job.vacancies > 0 ? Math.round(((job.filledVacancies || 0) / job.vacancies) * 100) : 0;
            return (
              <div
                key={job.id}
                className="bg-white rounded-xl border border-slate-200 shadow-2xs hover:shadow-sm transition-shadow p-5 flex flex-col justify-between"
              >
                <div className="space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <span className="text-[10px] px-2 py-0.5 rounded font-mono font-semibold bg-slate-100 text-slate-700">
                        {job.code}
                      </span>
                      <h3 className="text-sm font-bold text-slate-900 mt-1.5">{job.title}</h3>
                      <p className="text-xs text-indigo-700 font-medium">{job.designationTitle}</p>
                    </div>

                    <span
                      className={`text-[10px] px-2.5 py-0.5 rounded-full font-bold uppercase tracking-wider shrink-0 ${
                        job.status === 'APPLICATIONS_OPEN' || job.status === 'PUBLISHED'
                          ? 'bg-emerald-100 text-emerald-800'
                          : job.status === 'FILLED'
                          ? 'bg-blue-100 text-blue-800'
                          : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {(job.status || 'DRAFT').replace(/_/g, ' ')}
                    </span>
                  </div>

                  <div className="space-y-1 text-xs text-slate-600 pt-2 border-t border-slate-100">
                    <div className="flex items-center gap-2">
                      <Building className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>{job.departmentName}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>{job.workLocation} ({job.employmentType})</span>
                    </div>
                    {job.salaryRange && (
                      <div className="flex items-center gap-2">
                        <DollarSign className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span>{job.salaryRange}</span>
                      </div>
                    )}
                    <div className="flex items-center gap-2">
                      <Calendar className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>Closes: {job.applicationClosingDate}</span>
                    </div>
                  </div>

                  {/* Skills tags */}
                  {((job?.requiredSkills?.length || 0) > 0) && (
                    <div className="flex flex-wrap gap-1 pt-2">
                      {(job?.requiredSkills || []).slice(0, 3).map((skill, idx) => (
                        <span key={idx} className="text-[10px] px-2 py-0.5 rounded bg-slate-100 text-slate-600">
                          {skill}
                        </span>
                      ))}
                      {(job?.requiredSkills?.length || 0) > 3 && (
                        <span className="text-[10px] px-1.5 py-0.5 text-slate-400">
                          +{(job?.requiredSkills?.length || 0) - 3}
                        </span>
                      )}
                    </div>
                  )}
                </div>

                {/* Footer Progress & Actions */}
                <div className="pt-4 mt-4 border-t border-slate-100 space-y-3">
                  <div className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-500 font-medium">Vacancies:</span>
                      <span className="font-bold text-slate-800">
                        {job.filledVacancies || 0} / {job.vacancies} filled ({fillRate}%)
                      </span>
                    </div>
                    <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                      <div
                        className="bg-indigo-600 h-1.5 rounded-full transition-all"
                        style={{ width: `${fillRate}%` }}
                      />
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-1">
                    <button
                      type="button"
                      onClick={() => onViewCandidates(job.id)}
                      className="text-xs font-bold text-indigo-700 hover:text-indigo-900 flex items-center gap-1"
                    >
                      <Users className="w-3.5 h-3.5" />
                      <span>Applicants ({job.applicationCount || 0})</span>
                    </button>

                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => setSelectedOpeningForDetail(job)}
                        className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-md"
                        title="View Description"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDelete(job.id)}
                        disabled={isDeleting}
                        className="p-1.5 text-red-500 hover:text-red-700 hover:bg-red-50 rounded-md"
                        title="Archive Opening"
                      >
                        <Archive className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Job Details Drawer Modal */}
      {selectedOpeningForDetail && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in">
          <div className="bg-white rounded-2xl max-w-2xl w-full p-6 space-y-5 max-h-[90vh] overflow-y-auto shadow-xl">
            <div className="flex items-start justify-between border-b border-slate-100 pb-4">
              <div>
                <span className="text-xs font-mono font-bold text-indigo-600">{selectedOpeningForDetail.code}</span>
                <h2 className="text-lg font-bold text-slate-900 mt-1">{selectedOpeningForDetail.title}</h2>
                <p className="text-xs text-slate-500">{selectedOpeningForDetail.departmentName} • {selectedOpeningForDetail.designationTitle}</p>
              </div>
              <button
                type="button"
                onClick={() => setSelectedOpeningForDetail(null)}
                className="text-slate-400 hover:text-slate-600 text-xl font-bold"
              >
                &times;
              </button>
            </div>

            <div className="space-y-4 text-xs text-slate-700">
              <div>
                <h4 className="font-bold text-slate-900 uppercase text-[11px] tracking-wider mb-1">Job Description</h4>
                <p className="whitespace-pre-line text-slate-600 bg-slate-50 p-3 rounded-lg border border-slate-200">
                  {selectedOpeningForDetail.jobDescription || 'No formal description written.'}
                </p>
              </div>

              {selectedOpeningForDetail.responsibilities && selectedOpeningForDetail.responsibilities.length > 0 && (
                <div>
                  <h4 className="font-bold text-slate-900 uppercase text-[11px] tracking-wider mb-1.5">Key Responsibilities</h4>
                  <ul className="list-disc pl-5 space-y-1 text-slate-600">
                    {selectedOpeningForDetail.responsibilities.map((r, i) => (
                      <li key={i}>{r}</li>
                    ))}
                  </ul>
                </div>
              )}

              {selectedOpeningForDetail.qualifications && selectedOpeningForDetail.qualifications.length > 0 && (
                <div>
                  <h4 className="font-bold text-slate-900 uppercase text-[11px] tracking-wider mb-1.5">Qualifications & Education</h4>
                  <ul className="list-disc pl-5 space-y-1 text-slate-600">
                    {selectedOpeningForDetail.qualifications.map((q, i) => (
                      <li key={i}>{q}</li>
                    ))}
                  </ul>
                </div>
              )}

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-3 bg-slate-50 rounded-lg border border-slate-200">
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Total Vacancies</span>
                  <span className="font-bold text-slate-900">{selectedOpeningForDetail.vacancies}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Filled Vacancies</span>
                  <span className="font-bold text-emerald-700">{selectedOpeningForDetail.filledVacancies || 0}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Experience Required</span>
                  <span className="font-bold text-slate-900">{selectedOpeningForDetail.experienceYears} Years</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-bold">Closing Date</span>
                  <span className="font-bold text-slate-900">{selectedOpeningForDetail.applicationClosingDate}</span>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => setSelectedOpeningForDetail(null)}
              >
                Close
              </Button>
              <Button
                type="button"
                variant="primary"
                size="sm"
                onClick={() => {
                  const id = selectedOpeningForDetail.id;
                  setSelectedOpeningForDetail(null);
                  onViewCandidates(id);
                }}
              >
                View Candidates
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
