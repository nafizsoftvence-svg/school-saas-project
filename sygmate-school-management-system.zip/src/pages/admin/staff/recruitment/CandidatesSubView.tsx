/**
 * Sygmate School Management System
 * Candidate Pool & Screening Pipeline (Part 12D)
 */

import React, { useState } from 'react';
import {
  Users,
  Search,
  Filter,
  Mail,
  Phone,
  Calendar,
  GraduationCap,
  Briefcase,
  CheckCircle2,
  XCircle,
  Clock,
  ArrowRight,
  UserCheck,
  FileText,
  Building,
  Plus,
  AlertCircle,
  ExternalLink
} from 'lucide-react';
import { Button } from '../../../../components/ui/Button.js';
import { api } from '../../../../services/api.js';
import {
  CandidateProfile,
  JobApplication,
  JobOpening,
  Department
} from '../../../../types/index.js';
import { ScheduleInterviewModal } from './ScheduleInterviewModal.js';

interface CandidatesSubViewProps {
  candidates: CandidateProfile[];
  applications: JobApplication[];
  openings: JobOpening[];
  departments: Department[];
  onRefresh: () => void;
  onOpenCreateModal: () => void;
  onConvertToStaff: (candidate: CandidateProfile) => void;
}

export const CandidatesSubView: React.FC<CandidatesSubViewProps> = ({
  candidates = [],
  applications = [],
  openings = [],
  departments = [],
  onRefresh,
  onOpenCreateModal,
  onConvertToStaff
}) => {
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [stageFilter, setStageFilter] = useState<string>('all');
  const [openingFilter, setOpeningFilter] = useState<string>('all');

  const [selectedCandidate, setSelectedCandidate] = useState<CandidateProfile | null>(null);
  const [candidateToInterview, setCandidateToInterview] = useState<{ candidate: CandidateProfile; application?: JobApplication } | null>(null);

  const [isScreening, setIsScreening] = useState<boolean>(false);
  const [screeningAction, setScreeningAction] = useState<'SHORTLISTED' | 'REJECTED' | 'ON_HOLD' | null>(null);
  const [screeningNotes, setScreeningNotes] = useState<string>('');
  const [screeningError, setScreeningError] = useState<string | null>(null);

  // Filter candidates
  const filteredCandidates = candidates.filter((c) => {
    if (stageFilter !== 'all' && c.currentStage !== stageFilter) return false;
    if (openingFilter !== 'all' && c.appliedPositionId !== openingFilter) return false;
    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      const match =
        c.fullName.toLowerCase().includes(q) ||
        c.candidateNumber.toLowerCase().includes(q) ||
        c.email.toLowerCase().includes(q) ||
        c.phone.toLowerCase().includes(q) ||
        c.appliedPositionTitle.toLowerCase().includes(q) ||
        c.skills.some((s) => s.toLowerCase().includes(q));
      if (!match) return false;
    }
    return true;
  });

  const handleExecuteScreening = async (appId: string) => {
    if (!screeningAction) return;
    setIsScreening(true);
    setScreeningError(null);
    try {
      await api.staff.recruitment.screenApplication(appId, {
        decision: screeningAction,
        notes: screeningNotes
      });
      setScreeningAction(null);
      setScreeningNotes('');
      onRefresh();
      // Update selectedCandidate if open
      if (selectedCandidate) {
        setSelectedCandidate((prev) =>
          prev
            ? {
                ...prev,
                currentStage: (screeningAction === 'SHORTLISTED' ? 'SHORTLISTED' : screeningAction === 'REJECTED' ? 'REJECTED' : 'SCREENING') as any
              }
            : null
        );
      }
    } catch (err: any) {
      setScreeningError(err.message || 'Failed to update candidate screening status.');
    } finally {
      setIsScreening(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* Search & Filter Header */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex flex-col md:flex-row gap-3 items-center justify-between">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search candidate name, ID, skills, email..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-slate-50/50"
          />
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto flex-wrap">
          <select
            value={stageFilter}
            onChange={(e) => setStageFilter(e.target.value)}
            className="px-3 py-2 text-xs border border-slate-200 rounded-lg bg-white text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="all">All Stages</option>
            <option value="APPLIED">Applied</option>
            <option value="SCREENING">Screening</option>
            <option value="SHORTLISTED">Shortlisted</option>
            <option value="INTERVIEW">Interview</option>
            <option value="SELECTED">Selected</option>
            <option value="OFFER">Offer Dispatched</option>
            <option value="ACCEPTED">Offer Accepted</option>
            <option value="HIRED">Converted to Staff</option>
            <option value="REJECTED">Rejected</option>
          </select>

          <select
            value={openingFilter}
            onChange={(e) => setOpeningFilter(e.target.value)}
            className="px-3 py-2 text-xs border border-slate-200 rounded-lg bg-white text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 max-w-xs"
          >
            <option value="all">All Positions</option>
            {openings.map((o) => (
              <option key={o.id} value={o.id}>
                {o.title} ({o.code})
              </option>
            ))}
          </select>

          <Button
            type="button"
            variant="primary"
            size="sm"
            onClick={onOpenCreateModal}
            icon={<Plus className="w-3.5 h-3.5" />}
          >
            Add Candidate
          </Button>
        </div>
      </div>

      {/* Candidates List / Cards */}
      {filteredCandidates.length === 0 ? (
        <div className="p-12 text-center bg-white rounded-xl border border-slate-200 text-slate-500 space-y-3">
          <Users className="w-10 h-10 mx-auto text-slate-300" />
          <p className="text-sm font-semibold">No candidates found matching the filters.</p>
          <Button type="button" variant="outline" size="sm" onClick={onOpenCreateModal}>
            Register Candidate
          </Button>
        </div>
      ) : (
        <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-700">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold uppercase text-[10px] tracking-wider">
                <tr>
                  <th className="py-3 px-4">Candidate</th>
                  <th className="py-3 px-4">Applied Position</th>
                  <th className="py-3 px-4">Education & Experience</th>
                  <th className="py-3 px-4">Pipeline Stage</th>
                  <th className="py-3 px-4">Rating / Match</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredCandidates.map((cand) => {
                  const app = (applications || []).find((a) => a?.candidateId === cand.id);
                  const isReadyForHire = ['ACCEPTED', 'SELECTED'].includes(cand.currentStage) && cand.status === 'ACTIVE';

                  return (
                    <tr key={cand.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-indigo-100 text-indigo-700 font-bold flex items-center justify-center shrink-0 text-xs">
                            {cand.firstName.charAt(0)}{cand.lastName.charAt(0)}
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-slate-900">{cand.fullName}</span>
                              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-100 text-slate-600">
                                {cand.candidateNumber}
                              </span>
                            </div>
                            <div className="text-[11px] text-slate-500 flex items-center gap-2 mt-0.5">
                              <span className="flex items-center gap-1">
                                <Mail className="w-3 h-3" />
                                {cand.email}
                              </span>
                              <span>•</span>
                              <span className="flex items-center gap-1">
                                <Phone className="w-3 h-3" />
                                {cand.phone}
                              </span>
                            </div>
                          </div>
                        </div>
                      </td>

                      <td className="py-3.5 px-4">
                        <span className="font-semibold text-slate-800 block">{cand.appliedPositionTitle}</span>
                        <span className="text-[11px] text-slate-500 flex items-center gap-1 mt-0.5">
                          <Building className="w-3 h-3 text-slate-400" />
                          {cand.departmentName}
                        </span>
                      </td>

                      <td className="py-3.5 px-4">
                        <span className="font-medium text-slate-800 block">{cand.highestQualification}</span>
                        <span className="text-[11px] text-slate-500">{cand.yearsOfExperience} years experience</span>
                      </td>

                      <td className="py-3.5 px-4">
                        <span
                          className={`inline-block text-[10px] px-2.5 py-1 rounded-full font-bold uppercase tracking-wider ${
                            cand.currentStage === 'HIRED'
                              ? 'bg-green-100 text-green-800'
                              : cand.currentStage === 'ACCEPTED'
                              ? 'bg-teal-100 text-teal-800'
                              : cand.currentStage === 'SELECTED'
                              ? 'bg-purple-100 text-purple-800'
                              : cand.currentStage === 'INTERVIEW'
                              ? 'bg-indigo-100 text-indigo-800'
                              : cand.currentStage === 'SHORTLISTED'
                              ? 'bg-blue-100 text-blue-800'
                              : cand.currentStage === 'REJECTED'
                              ? 'bg-rose-100 text-rose-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {(cand.currentStage || 'APPLIED').replace(/_/g, ' ')}
                        </span>
                      </td>

                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-1">
                          <span className="font-bold text-slate-800">
                            {cand.screeningScore ? `${cand.screeningScore}/100` : '—'}
                          </span>
                        </div>
                        {cand.skills && cand.skills.length > 0 && (
                          <div className="text-[10px] text-slate-500 truncate max-w-[150px] mt-0.5">
                            {cand.skills.slice(0, 2).join(', ')}
                          </div>
                        )}
                      </td>

                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            type="button"
                            onClick={() => setSelectedCandidate(cand)}
                            className="px-2.5 py-1 text-xs font-semibold text-slate-700 hover:bg-slate-100 rounded-md border border-slate-200"
                          >
                            Profile
                          </button>

                          {cand.currentStage === 'SCREENING' && app && (
                            <button
                              type="button"
                              onClick={() => {
                                setSelectedCandidate(cand);
                                setScreeningAction('SHORTLISTED');
                              }}
                              className="px-2.5 py-1 text-xs font-semibold text-blue-700 hover:bg-blue-50 rounded-md border border-blue-200"
                            >
                              Screen
                            </button>
                          )}

                          {['SHORTLISTED', 'INTERVIEW'].includes(cand.currentStage) && (
                            <button
                              type="button"
                              onClick={() => setCandidateToInterview({ candidate: cand, application: app })}
                              className="px-2.5 py-1 text-xs font-semibold text-indigo-700 hover:bg-indigo-50 rounded-md border border-indigo-200"
                            >
                              Schedule Intv
                            </button>
                          )}

                          {isReadyForHire && (
                            <button
                              type="button"
                              onClick={() => onConvertToStaff(cand)}
                              className="px-2.5 py-1 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-md shadow-2xs flex items-center gap-1"
                            >
                              <UserCheck className="w-3.5 h-3.5" />
                              <span>Convert to Staff</span>
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Candidate Profile / Screening Modal Drawer */}
      {selectedCandidate && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in">
          <div className="bg-white rounded-2xl max-w-2xl w-full p-6 space-y-5 max-h-[90vh] overflow-y-auto shadow-xl">
            <div className="flex items-start justify-between border-b border-slate-100 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-indigo-100 text-indigo-700 font-bold flex items-center justify-center text-sm">
                  {selectedCandidate.firstName.charAt(0)}{selectedCandidate.lastName.charAt(0)}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-base font-bold text-slate-900">{selectedCandidate.fullName}</h2>
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-100 text-slate-600">
                      {selectedCandidate.candidateNumber}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500">
                    Applying for <strong className="text-slate-800">{selectedCandidate.appliedPositionTitle}</strong> • {selectedCandidate.departmentName}
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  setSelectedCandidate(null);
                  setScreeningAction(null);
                }}
                className="text-slate-400 hover:text-slate-600 text-xl font-bold"
              >
                &times;
              </button>
            </div>

            {/* Candidate Details Tabs/Sections */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-2">
                <h4 className="font-bold text-slate-900 uppercase text-[10px] tracking-wider">Contact & Personal Details</h4>
                <div className="space-y-1 text-slate-600">
                  <div><strong>Email:</strong> {selectedCandidate.email}</div>
                  <div><strong>Phone:</strong> {selectedCandidate.phone}</div>
                  <div><strong>Address:</strong> {selectedCandidate.address || 'Not specified'}</div>
                  <div><strong>Gender:</strong> <span className="capitalize">{selectedCandidate.gender}</span></div>
                  <div><strong>DOB:</strong> {selectedCandidate.dateOfBirth || '—'}</div>
                </div>
              </div>

              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-2">
                <h4 className="font-bold text-slate-900 uppercase text-[10px] tracking-wider">Qualifications & Experience</h4>
                <div className="space-y-1 text-slate-600">
                  <div><strong>Degree:</strong> {selectedCandidate.highestQualification}</div>
                  <div><strong>Specialization:</strong> {selectedCandidate.specialization || 'General'}</div>
                  <div><strong>Years Experience:</strong> {selectedCandidate.yearsOfExperience} yrs</div>
                  <div><strong>Current Employer:</strong> {selectedCandidate.currentEmployer || 'None'}</div>
                  <div><strong>Notice Period:</strong> {selectedCandidate.noticePeriodDays || 0} days</div>
                </div>
              </div>
            </div>

            {/* Skills */}
            {selectedCandidate.skills && selectedCandidate.skills.length > 0 && (
              <div className="text-xs space-y-1">
                <span className="font-bold text-slate-800 block text-[11px]">Core Competencies & Skills:</span>
                <div className="flex flex-wrap gap-1">
                  {selectedCandidate.skills.map((skill, idx) => (
                    <span key={idx} className="px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 text-[11px] font-medium">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Resume / Cover Letter */}
            {selectedCandidate.coverLetter && (
              <div className="text-xs space-y-1">
                <span className="font-bold text-slate-800 block text-[11px]">Cover Letter / Statement:</span>
                <p className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-slate-600 whitespace-pre-line text-xs">
                  {selectedCandidate.coverLetter}
                </p>
              </div>
            )}

            {/* Screening Decision Actions */}
            {(() => {
              const app = (applications || []).find((a) => a?.candidateId === selectedCandidate.id);
              if (!app) return null;

              return (
                <div className="p-4 bg-indigo-50/50 rounded-xl border border-indigo-100 space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-xs font-bold text-slate-900">Application Screening & Review</h4>
                      <p className="text-[11px] text-slate-500">Current Stage: <strong className="text-indigo-700">{selectedCandidate.currentStage}</strong></p>
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => setScreeningAction('SHORTLISTED')}
                        className={`px-3 py-1 text-xs font-bold rounded-md transition-colors ${
                          screeningAction === 'SHORTLISTED'
                            ? 'bg-blue-600 text-white'
                            : 'bg-white text-blue-700 border border-blue-200 hover:bg-blue-50'
                        }`}
                      >
                        Shortlist
                      </button>

                      <button
                        type="button"
                        onClick={() => setScreeningAction('ON_HOLD')}
                        className={`px-3 py-1 text-xs font-bold rounded-md transition-colors ${
                          screeningAction === 'ON_HOLD'
                            ? 'bg-amber-600 text-white'
                            : 'bg-white text-amber-700 border border-amber-200 hover:bg-amber-50'
                        }`}
                      >
                        Hold
                      </button>

                      <button
                        type="button"
                        onClick={() => setScreeningAction('REJECTED')}
                        className={`px-3 py-1 text-xs font-bold rounded-md transition-colors ${
                          screeningAction === 'REJECTED'
                            ? 'bg-rose-600 text-white'
                            : 'bg-white text-rose-700 border border-rose-200 hover:bg-rose-50'
                        }`}
                      >
                        Reject
                      </button>
                    </div>
                  </div>

                  {screeningAction && (
                    <div className="space-y-2 pt-2 border-t border-indigo-100 animate-in fade-in">
                      <label className="text-[11px] font-semibold text-slate-700 block">
                        Screening Notes & Evaluation Justification:
                      </label>
                      <textarea
                        rows={2}
                        value={screeningNotes}
                        onChange={(e) => setScreeningNotes(e.target.value)}
                        placeholder="Provide reasons for shortlisting, holding, or rejecting candidate..."
                        className="w-full text-xs p-2.5 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
                      />

                      {screeningError && (
                        <p className="text-[11px] text-red-600 font-semibold">{screeningError}</p>
                      )}

                      <div className="flex justify-end gap-2">
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => setScreeningAction(null)}
                        >
                          Cancel
                        </Button>
                        <Button
                          type="button"
                          variant="primary"
                          size="sm"
                          disabled={isScreening}
                          onClick={() => handleExecuteScreening(app.id)}
                        >
                          {isScreening ? 'Updating...' : `Confirm ${screeningAction}`}
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              );
            })()}

            {/* Modal Footer */}
            <div className="flex items-center justify-between pt-4 border-t border-slate-100">
              <div className="flex items-center gap-2">
                {['ACCEPTED', 'SELECTED'].includes(selectedCandidate.currentStage) && (
                  <Button
                    type="button"
                    variant="primary"
                    size="sm"
                    onClick={() => {
                      const c = selectedCandidate;
                      setSelectedCandidate(null);
                      onConvertToStaff(c);
                    }}
                    icon={<UserCheck className="w-3.5 h-3.5" />}
                  >
                    Convert to Staff Member
                  </Button>
                )}
              </div>

              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => {
                  setSelectedCandidate(null);
                  setScreeningAction(null);
                }}
              >
                Close
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Schedule Interview Modal */}
      {candidateToInterview && (
        <ScheduleInterviewModal
          isOpen={Boolean(candidateToInterview)}
          candidate={candidateToInterview.candidate}
          application={candidateToInterview.application}
          onClose={() => setCandidateToInterview(null)}
          onSuccess={() => {
            setCandidateToInterview(null);
            onRefresh();
          }}
        />
      )}
    </div>
  );
};
