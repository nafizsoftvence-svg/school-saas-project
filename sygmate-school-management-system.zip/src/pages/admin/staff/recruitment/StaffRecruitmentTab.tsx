/**
 * Sygmate School Management System
 * Staff Recruitment & Pipeline Management (Part 12D)
 * Main Recruitment Tab Component
 */

import React, { useState, useEffect, useCallback } from 'react';
import {
  Briefcase,
  Users,
  UserCheck,
  Calendar,
  FileCheck,
  Plus,
  RefreshCw,
  Search,
  Filter,
  CheckCircle2,
  AlertCircle,
  Clock,
  Award,
  ArrowRight,
  TrendingUp,
  FileText,
  Mail,
  Building,
  UserPlus,
  Layers,
  ChevronRight
} from 'lucide-react';
import { Button } from '../../../../components/ui/Button.js';
import { api } from '../../../../services/api.js';
import {
  JobOpening,
  CandidateProfile,
  JobApplication,
  JobInterview,
  JobOffer,
  RecruitmentDashboardMetrics,
  Department,
  Designation,
  User
} from '../../../../types/index.js';

import { JobOpeningsSubView } from './JobOpeningsSubView.js';
import { CandidatesSubView } from './CandidatesSubView.js';
import { InterviewsSubView } from './InterviewsSubView.js';
import { OffersSubView } from './OffersSubView.js';
import { CandidateConversionModal } from './CandidateConversionModal.js';
import { CreateJobOpeningModal } from './CreateJobOpeningModal.js';
import { CreateCandidateModal } from './CreateCandidateModal.js';

interface StaffRecruitmentTabProps {
  departments: Department[];
  designations: Designation[];
  onStaffHired?: () => void;
}

export const StaffRecruitmentTab: React.FC<StaffRecruitmentTabProps> = ({
  departments,
  designations,
  onStaffHired
}) => {
  // Navigation between recruitment modules
  const [subView, setSubView] = useState<'overview' | 'openings' | 'candidates' | 'interviews' | 'offers'>('overview');

  // Core Data
  const [metrics, setMetrics] = useState<RecruitmentDashboardMetrics | null>(null);
  const [openings, setOpenings] = useState<JobOpening[]>([]);
  const [candidates, setCandidates] = useState<CandidateProfile[]>([]);
  const [applications, setApplications] = useState<JobApplication[]>([]);
  const [interviews, setInterviews] = useState<JobInterview[]>([]);
  const [offers, setOffers] = useState<JobOffer[]>([]);

  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Active Modals
  const [isCreateOpeningOpen, setIsCreateOpeningOpen] = useState<boolean>(false);
  const [isCreateCandidateOpen, setIsCreateCandidateOpen] = useState<boolean>(false);
  const [selectedCandidateForConversion, setSelectedCandidateForConversion] = useState<CandidateProfile | null>(null);

  const fetchData = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const [metricsRes, openingsRes, candidatesRes, applicationsRes, interviewsRes, offersRes] = await Promise.all([
        api.staff.recruitment.getMetrics(),
        api.staff.recruitment.getJobOpenings({ limit: 100 }),
        api.staff.recruitment.getCandidates({ limit: 100 }),
        api.staff.recruitment.getApplications({ limit: 100 }),
        api.staff.recruitment.getInterviews(),
        api.staff.recruitment.getOffers()
      ]);

      if (metricsRes?.data) setMetrics(metricsRes.data);
      if (openingsRes?.items) setOpenings(openingsRes.items);
      if (candidatesRes?.items) setCandidates(candidatesRes.items);
      if (applicationsRes?.items) setApplications(applicationsRes.items);
      if (interviewsRes?.data) setInterviews(interviewsRes.data);
      if (offersRes?.data) setOffers(offersRes.data);
    } catch (err: any) {
      console.error('Error fetching recruitment data:', err);
      setError(err.message || 'Failed to load recruitment data.');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  // Quick stats calculations
  const totalOpenings = openings.length;
  const activeOpenings = openings.filter((o) => ['PUBLISHED', 'APPLICATIONS_OPEN'].includes(o.status)).length;
  const totalVacancies = openings.reduce((acc, o) => acc + (o.vacancies || 0), 0);
  const filledVacancies = openings.reduce((acc, o) => acc + (o.filledVacancies || 0), 0);

  return (
    <div className="space-y-6" id="staff-recruitment-module">
      {/* Module Header Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-xl border border-slate-200">
        <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0">
          <button
            type="button"
            onClick={() => setSubView('overview')}
            className={`px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap ${
              subView === 'overview'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
            id="subview-overview-btn"
          >
            <TrendingUp className="w-3.5 h-3.5" />
            <span>Recruitment Overview</span>
          </button>

          <button
            type="button"
            onClick={() => setSubView('openings')}
            className={`px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap ${
              subView === 'openings'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
            id="subview-openings-btn"
          >
            <Briefcase className="w-3.5 h-3.5" />
            <span>Job Openings ({openings.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setSubView('candidates')}
            className={`px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap ${
              subView === 'candidates'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
            id="subview-candidates-btn"
          >
            <Users className="w-3.5 h-3.5" />
            <span>Candidate Pool ({candidates.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setSubView('interviews')}
            className={`px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap ${
              subView === 'interviews'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
            id="subview-interviews-btn"
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>Interviews & Panels ({interviews.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setSubView('offers')}
            className={`px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap ${
              subView === 'offers'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
            id="subview-offers-btn"
          >
            <FileCheck className="w-3.5 h-3.5" />
            <span>Offers & Approvals ({offers.length})</span>
          </button>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={fetchData}
            icon={<RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />}
            id="refresh-recruitment-btn"
          >
            Refresh
          </Button>

          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => setIsCreateCandidateOpen(true)}
            icon={<UserPlus className="w-3.5 h-3.5" />}
            id="add-candidate-btn"
          >
            New Candidate
          </Button>

          <Button
            type="button"
            variant="primary"
            size="sm"
            onClick={() => setIsCreateOpeningOpen(true)}
            icon={<Plus className="w-3.5 h-3.5" />}
            id="add-opening-btn"
          >
            Post Job Opening
          </Button>
        </div>
      </div>

      {/* Success / Error Alerts */}
      {successMessage && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between text-xs text-emerald-800 animate-in fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span className="font-semibold">{successMessage}</span>
          </div>
          <button
            type="button"
            onClick={() => setSuccessMessage(null)}
            className="text-emerald-600 hover:text-emerald-800 font-bold ml-4"
          >
            &times;
          </button>
        </div>
      )}

      {error && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-xl flex items-center justify-between text-xs text-red-800 animate-in fade-in">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
            <span>{error}</span>
          </div>
          <button
            type="button"
            onClick={() => setError(null)}
            className="text-red-600 hover:text-red-800 font-bold ml-4"
          >
            &times;
          </button>
        </div>
      )}

      {/* OVERVIEW SUB-VIEW */}
      {subView === 'overview' && (
        <div className="space-y-6">
          {/* Top KPI Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Active Openings</span>
                <span className="p-2 bg-indigo-50 text-indigo-600 rounded-lg">
                  <Briefcase className="w-4 h-4" />
                </span>
              </div>
              <div className="mt-3 flex items-baseline gap-2">
                <span className="text-2xl font-bold text-slate-900">{activeOpenings}</span>
                <span className="text-xs text-slate-500">of {totalOpenings} published</span>
              </div>
              <div className="mt-2 text-xs text-indigo-700 font-medium flex items-center gap-1">
                <span>{filledVacancies} / {totalVacancies} vacancies filled</span>
                <span className="text-slate-400">({totalVacancies > 0 ? Math.round((filledVacancies / totalVacancies) * 100) : 0}%)</span>
              </div>
            </div>

            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Screening & Pipeline</span>
                <span className="p-2 bg-amber-50 text-amber-600 rounded-lg">
                  <Users className="w-4 h-4" />
                </span>
              </div>
              <div className="mt-3 flex items-baseline gap-2">
                <span className="text-2xl font-bold text-slate-900">
                  {metrics?.candidatesUnderScreening || applications.filter((a) => ['APPLIED', 'SCREENING'].includes(a.stage)).length}
                </span>
                <span className="text-xs text-slate-500">applicants in review</span>
              </div>
              <div className="mt-2 text-xs text-amber-700 font-medium">
                {metrics?.shortlistedCandidates || applications.filter((a) => a.stage === 'SHORTLISTED').length} candidates shortlisted
              </div>
            </div>

            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Interviews & Panels</span>
                <span className="p-2 bg-sky-50 text-sky-600 rounded-lg">
                  <Calendar className="w-4 h-4" />
                </span>
              </div>
              <div className="mt-3 flex items-baseline gap-2">
                <span className="text-2xl font-bold text-slate-900">
                  {interviews.filter((i) => ['SCHEDULED', 'CONFIRMED'].includes(i.status)).length}
                </span>
                <span className="text-xs text-slate-500">upcoming sessions</span>
              </div>
              <div className="mt-2 text-xs text-sky-700 font-medium">
                {interviews.filter((i) => i.status === 'COMPLETED').length} evaluations conducted
              </div>
            </div>

            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Offers & Hires</span>
                <span className="p-2 bg-emerald-50 text-emerald-600 rounded-lg">
                  <UserCheck className="w-4 h-4" />
                </span>
              </div>
              <div className="mt-3 flex items-baseline gap-2">
                <span className="text-2xl font-bold text-slate-900">
                  {candidates.filter((c) => c.status === 'CONVERTED_TO_STAFF').length}
                </span>
                <span className="text-xs text-slate-500">converted to staff</span>
              </div>
              <div className="mt-2 text-xs text-emerald-700 font-medium">
                {offers.filter((o) => o.status === 'ACCEPTED').length} offers signed & accepted
              </div>
            </div>
          </div>

          {/* Interactive Recruitment Pipeline Funnel */}
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-2xs">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-sm font-bold text-slate-900">Recruitment Pipeline Funnel</h2>
                <p className="text-xs text-slate-500 mt-0.5">Live distribution of candidate applications across hiring checkpoints</p>
              </div>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => setSubView('candidates')}
                icon={<ArrowRight className="w-3.5 h-3.5" />}
              >
                Manage Candidates
              </Button>
            </div>

            {/* Stages Bar */}
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-2">
              {[
                { stage: 'APPLIED', label: '1. Applied', color: 'bg-slate-100 text-slate-800 border-slate-300' },
                { stage: 'SCREENING', label: '2. Screening', color: 'bg-amber-50 text-amber-800 border-amber-300' },
                { stage: 'SHORTLISTED', label: '3. Shortlist', color: 'bg-blue-50 text-blue-800 border-blue-300' },
                { stage: 'INTERVIEW', label: '4. Interview', color: 'bg-indigo-50 text-indigo-800 border-indigo-300' },
                { stage: 'SELECTED', label: '5. Selected', color: 'bg-purple-50 text-purple-800 border-purple-300' },
                { stage: 'OFFER', label: '6. Offer', color: 'bg-emerald-50 text-emerald-800 border-emerald-300' },
                { stage: 'ACCEPTED', label: '7. Accepted', color: 'bg-teal-50 text-teal-800 border-teal-300' },
                { stage: 'HIRED', label: '8. Hired', color: 'bg-green-100 text-green-900 border-green-400 font-bold' }
              ].map((item) => {
                const count = applications.filter((a) => a.stage === item.stage).length;
                return (
                  <div
                    key={item.stage}
                    onClick={() => setSubView('candidates')}
                    className={`p-3 rounded-lg border ${item.color} cursor-pointer hover:shadow-xs transition-shadow text-center`}
                  >
                    <span className="text-[11px] font-semibold block">{item.label}</span>
                    <span className="text-lg font-bold block mt-1">{count}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Department Openings & Recent Activity Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Active Job Openings List */}
            <div className="lg:col-span-2 bg-white p-5 rounded-xl border border-slate-200 shadow-2xs space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Current Open Positions</h3>
                  <p className="text-xs text-slate-500">Live vacancies accepting candidate submissions</p>
                </div>
                <button
                  type="button"
                  onClick={() => setSubView('openings')}
                  className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
                >
                  <span>View All Openings</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="divide-y divide-slate-100">
                {openings.slice(0, 4).map((job) => {
                  const percentFilled = job.vacancies > 0 ? Math.round(((job.filledVacancies || 0) / job.vacancies) * 100) : 0;
                  return (
                    <div key={job.id} className="py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-slate-900">{job.title}</span>
                          <span className="text-[10px] px-2 py-0.5 rounded-md font-semibold bg-slate-100 text-slate-700">
                            {job.code}
                          </span>
                          <span className={`text-[10px] px-2 py-0.5 rounded-md font-semibold ${
                            job.status === 'APPLICATIONS_OPEN' || job.status === 'PUBLISHED'
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-slate-100 text-slate-700'
                          }`}>
                            {(job.status || 'DRAFT').replace(/_/g, ' ')}
                          </span>
                        </div>
                        <div className="text-xs text-slate-500 flex items-center gap-3">
                          <span className="flex items-center gap-1">
                            <Building className="w-3 h-3 text-slate-400" />
                            {job.departmentName}
                          </span>
                          <span>•</span>
                          <span className="capitalize">{job.staffType} Faculty</span>
                          <span>•</span>
                          <span className="capitalize">{job.employmentType}</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-4 text-xs shrink-0">
                        <div className="text-right">
                          <span className="font-bold text-slate-800">{job.filledVacancies || 0} / {job.vacancies}</span>
                          <span className="text-slate-500 text-[11px] block">vacancies filled</span>
                        </div>
                        <div className="w-16 bg-slate-100 rounded-full h-2 overflow-hidden">
                          <div
                            className="bg-indigo-600 h-2 rounded-full transition-all"
                            style={{ width: `${percentFilled}%` }}
                          />
                        </div>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => setSubView('openings')}
                        >
                          Details
                        </Button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Ready for Staff Conversion Panel */}
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Ready for Staff Conversion</h3>
                  <p className="text-xs text-slate-500">Accepted candidates awaiting official staff onboarding</p>
                </div>
                <Award className="w-4 h-4 text-indigo-600" />
              </div>

              {candidates.filter((c) => ['ACCEPTED', 'SELECTED'].includes(c.currentStage) && c.status === 'ACTIVE').length === 0 ? (
                <div className="p-6 text-center bg-slate-50 rounded-lg border border-dashed border-slate-200 text-xs text-slate-500">
                  No candidates currently pending staff conversion.
                </div>
              ) : (
                <div className="space-y-3">
                  {candidates
                    .filter((c) => ['ACCEPTED', 'SELECTED'].includes(c.currentStage) && c.status === 'ACTIVE')
                    .slice(0, 3)
                    .map((c) => (
                      <div key={c.id} className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-2">
                        <div className="flex items-start justify-between">
                          <div>
                            <span className="text-xs font-bold text-slate-900 block">{c.fullName}</span>
                            <span className="text-[11px] text-slate-500">{c.appliedPositionTitle || 'Faculty Candidate'}</span>
                          </div>
                          <span className="text-[10px] px-2 py-0.5 rounded-full font-bold bg-teal-100 text-teal-800">
                            {c.currentStage}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-600 flex items-center justify-between pt-1 border-t border-slate-200">
                          <span>{c.highestQualification}</span>
                          <button
                            type="button"
                            onClick={() => setSelectedCandidateForConversion(c)}
                            className="text-xs font-bold text-indigo-700 hover:text-indigo-900 flex items-center gap-1"
                          >
                            <span>Convert to Staff</span>
                            <ArrowRight className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* JOB OPENINGS SUB-VIEW */}
      {subView === 'openings' && (
        <JobOpeningsSubView
          openings={openings}
          departments={departments}
          designations={designations}
          onRefresh={fetchData}
          onOpenCreateModal={() => setIsCreateOpeningOpen(true)}
          onViewCandidates={(jobId) => {
            setSubView('candidates');
          }}
        />
      )}

      {/* CANDIDATES SUB-VIEW */}
      {subView === 'candidates' && (
        <CandidatesSubView
          candidates={candidates}
          applications={applications}
          openings={openings}
          departments={departments}
          onRefresh={fetchData}
          onOpenCreateModal={() => setIsCreateCandidateOpen(true)}
          onConvertToStaff={(candidate) => setSelectedCandidateForConversion(candidate)}
        />
      )}

      {/* INTERVIEWS SUB-VIEW */}
      {subView === 'interviews' && (
        <InterviewsSubView
          interviews={interviews}
          applications={applications}
          candidates={candidates}
          openings={openings}
          onRefresh={fetchData}
        />
      )}

      {/* OFFERS SUB-VIEW */}
      {subView === 'offers' && (
        <OffersSubView
          offers={offers}
          applications={applications}
          candidates={candidates}
          openings={openings}
          onRefresh={fetchData}
          onConvertToStaff={(candidate) => setSelectedCandidateForConversion(candidate)}
        />
      )}

      {/* MODALS */}
      {isCreateOpeningOpen && (
        <CreateJobOpeningModal
          isOpen={isCreateOpeningOpen}
          departments={departments}
          designations={designations}
          onClose={() => setIsCreateOpeningOpen(false)}
          onSuccess={() => {
            setIsCreateOpeningOpen(false);
            setSuccessMessage('Job opening published successfully.');
            fetchData();
          }}
        />
      )}

      {isCreateCandidateOpen && (
        <CreateCandidateModal
          isOpen={isCreateCandidateOpen}
          openings={openings}
          onClose={() => setIsCreateCandidateOpen(false)}
          onSuccess={() => {
            setIsCreateCandidateOpen(false);
            setSuccessMessage('Candidate profile registered successfully.');
            fetchData();
          }}
        />
      )}

      {selectedCandidateForConversion && (
        <CandidateConversionModal
          isOpen={Boolean(selectedCandidateForConversion)}
          candidate={selectedCandidateForConversion}
          departments={departments}
          designations={designations}
          openings={openings}
          onClose={() => setSelectedCandidateForConversion(null)}
          onSuccess={(result) => {
            setSelectedCandidateForConversion(null);
            setSuccessMessage(
              `Candidate ${result.staffName} was successfully converted to staff profile (${result.employeeCode}) with onboarding initialized!`
            );
            fetchData();
            if (onStaffHired) onStaffHired();
          }}
        />
      )}
    </div>
  );
};
