/**
 * Sygmate School Management System
 * Candidate to Staff Conversion & Onboarding Initiation Modal (Part 12D)
 */

import React, { useState, useEffect } from 'react';
import {
  UserCheck,
  Building,
  KeyRound,
  CheckCircle2,
  AlertCircle,
  Briefcase,
  Layers,
  Calendar,
  ShieldAlert
} from 'lucide-react';
import { Button } from '../../../../components/ui/Button.js';
import { api } from '../../../../services/api.js';
import {
  CandidateProfile,
  Department,
  Designation,
  JobOpening,
  ConvertCandidateToStaffPayload,
  OnboardingTemplate
} from '../../../../types/index.js';

interface CandidateConversionModalProps {
  isOpen: boolean;
  candidate: CandidateProfile;
  departments: Department[];
  designations: Designation[];
  openings: JobOpening[];
  onClose: () => void;
  onSuccess: (result: { staffProfileId: string; employeeCode: string; staffName: string }) => void;
}

export const CandidateConversionModal: React.FC<CandidateConversionModalProps> = ({
  isOpen,
  candidate,
  departments = [],
  designations = [],
  openings = [],
  onClose,
  onSuccess
}) => {
  // Matching opening
  const matchingOpening = (openings || []).find((o) => o?.id === candidate.appliedPositionId);

  const [employeeCode, setEmployeeCode] = useState<string>('');
  const [departmentId, setDepartmentId] = useState<string>(
    matchingOpening?.departmentId || candidate.departmentId || departments?.[0]?.id || ''
  );
  const [designationTitle, setDesignationTitle] = useState<string>(
    matchingOpening?.designationTitle || candidate.appliedPositionTitle || designations?.[0]?.title || 'Teacher'
  );
  const [staffType, setStaffType] = useState<'teaching' | 'administrative' | 'support' | 'management' | 'operational'>(
    matchingOpening?.staffType as any || 'teaching'
  );
  const [employmentType, setEmploymentType] = useState<'full_time' | 'part_time' | 'contract' | 'temporary'>('full_time');
  const [joiningDate, setJoiningDate] = useState<string>(new Date().toISOString().split('T')[0]);

  // Account creation toggle
  const [createAccount, setCreateAccount] = useState<boolean>(true);
  const [username, setUsername] = useState<string>(
    `${candidate.firstName.toLowerCase()}.${candidate.lastName.toLowerCase()}`
  );
  const [password, setPassword] = useState<string>('Sygmate2026!');
  const [accountRole, setAccountRole] = useState<'TEACHER' | 'SUPER_ADMIN'>('TEACHER');

  // Onboarding template
  const [onboardingTemplates, setOnboardingTemplates] = useState<OnboardingTemplate[]>([]);
  const [selectedTemplateId, setSelectedTemplateId] = useState<string>('');

  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // Fetch next employee code & templates on load
  useEffect(() => {
    const initData = async () => {
      try {
        const [codeRes, tmplRes] = await Promise.all([
          api.staff.getNextEmployeeCode(),
          api.staff.onboarding.getTemplates()
        ]);
        if (codeRes?.code) setEmployeeCode(codeRes.code);
        const tmplList = (tmplRes?.data as any)?.data || (tmplRes?.data as any) || [];
        if (Array.isArray(tmplList)) {
          setOnboardingTemplates(tmplList);
          if (tmplList.length > 0) {
            setSelectedTemplateId(tmplList?.[0]?.id || '');
          }
        }
      } catch (err) {
        console.error('Failed to load initial conversion details', err);
      }
    };
    initData();
  }, []);

  if (!isOpen) return null;

  const handleConvert = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!employeeCode.trim()) {
      setError('Employee code is required.');
      return;
    }

    setIsSubmitting(true);
    setError(null);

    const payload: ConvertCandidateToStaffPayload = {
      candidateId: candidate.id,
      applicationId: undefined, // auto-discovered by service
      employeeCode,
      departmentId,
      designationTitle,
      staffType,
      employmentType,
      joiningDate,
      createAccount,
      username: createAccount ? username : undefined,
      password: createAccount ? password : undefined,
      accountRole: createAccount ? accountRole : undefined,
      onboardingTemplateId: selectedTemplateId || undefined
    };

    try {
      const { candidateId: _, ...restPayload } = payload;
      const res = await api.staff.recruitment.convertCandidateToStaff(candidate.id, restPayload);
      const resultData = (res?.data as any)?.data || (res?.data as any);
      if (resultData?.staffId) {
        onSuccess({
          staffProfileId: resultData.staffId,
          employeeCode: resultData.employeeCode,
          staffName: resultData.staffName
        });
      } else {
        onSuccess({
          staffProfileId: 'new-staff',
          employeeCode,
          staffName: candidate.fullName
        });
      }
    } catch (err: any) {
      setError(err.message || 'Failed to convert candidate to staff.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in">
      <div className="bg-white rounded-2xl max-w-2xl w-full p-6 space-y-5 max-h-[90vh] overflow-y-auto shadow-xl">
        <div className="flex items-start justify-between border-b border-slate-100 pb-3">
          <div>
            <div className="flex items-center gap-2">
              <UserCheck className="w-5 h-5 text-emerald-600" />
              <h2 className="text-base font-bold text-slate-900">Official Staff Onboarding Conversion</h2>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Promoting <strong className="text-slate-800">{candidate.fullName}</strong> into institutional workforce
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 text-xl font-bold"
          >
            &times;
          </button>
        </div>

        {error && (
          <div className="p-3 bg-red-50 text-red-700 text-xs rounded-lg border border-red-200 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleConvert} className="space-y-4 text-xs">
          {/* Candidate Summary Pill */}
          <div className="p-3 bg-emerald-50/70 border border-emerald-200 rounded-xl flex items-center justify-between">
            <div>
              <span className="font-bold text-emerald-900 block text-xs">{candidate.fullName}</span>
              <span className="text-[11px] text-emerald-700">
                {candidate.email} • {candidate.highestQualification} ({candidate.yearsOfExperience} yrs exp)
              </span>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-200/80 text-emerald-900 font-bold">
              ID: {candidate.candidateNumber}
            </span>
          </div>

          {/* Institutional Assignment */}
          <div className="space-y-3">
            <h4 className="font-bold text-slate-900 uppercase text-[10px] tracking-wider">
              1. Institutional Assignment & Employee Code
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Official Employee Code</label>
                <input
                  type="text"
                  value={employeeCode}
                  onChange={(e) => setEmployeeCode(e.target.value)}
                  required
                  className="w-full p-2 border border-slate-200 rounded-lg bg-white font-mono font-bold focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Effective Joining Date</label>
                <input
                  type="date"
                  value={joiningDate}
                  onChange={(e) => setJoiningDate(e.target.value)}
                  required
                  className="w-full p-2 border border-slate-200 rounded-lg bg-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Department</label>
                <select
                  value={departmentId}
                  onChange={(e) => setDepartmentId(e.target.value)}
                  required
                  className="w-full p-2 border border-slate-200 rounded-lg bg-white"
                >
                  {departments.map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Designation Title</label>
                <input
                  type="text"
                  value={designationTitle}
                  onChange={(e) => setDesignationTitle(e.target.value)}
                  required
                  className="w-full p-2 border border-slate-200 rounded-lg bg-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Staff Classification</label>
                <select
                  value={staffType}
                  onChange={(e) => {
                    const st = e.target.value as any;
                    setStaffType(st);
                    if (st === 'teaching') setAccountRole('TEACHER');
                  }}
                  className="w-full p-2 border border-slate-200 rounded-lg bg-white"
                >
                  <option value="teaching">Teaching Faculty</option>
                  <option value="administrative">Administrative</option>
                  <option value="support">Support</option>
                  <option value="management">Management</option>
                  <option value="operational">Operational</option>
                </select>
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Employment Terms</label>
                <select
                  value={employmentType}
                  onChange={(e) => setEmploymentType(e.target.value as any)}
                  className="w-full p-2 border border-slate-200 rounded-lg bg-white"
                >
                  <option value="full_time">Full Time Regular</option>
                  <option value="part_time">Part Time</option>
                  <option value="contract">Contractual</option>
                  <option value="temporary">Temporary</option>
                </select>
              </div>
            </div>
          </div>

          {/* Onboarding Induction Checklist Template */}
          <div className="space-y-2 pt-2 border-t border-slate-100">
            <h4 className="font-bold text-slate-900 uppercase text-[10px] tracking-wider flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-indigo-600" />
              <span>2. Staff Onboarding Checklist Template</span>
            </h4>

            <select
              value={selectedTemplateId}
              onChange={(e) => setSelectedTemplateId(e.target.value)}
              className="w-full p-2 border border-slate-200 rounded-lg bg-white"
            >
              {onboardingTemplates.map((tmpl) => (
                <option key={tmpl.id} value={tmpl.id}>
                  {tmpl.name} ({tmpl?.tasks?.length || 0} default tasks)
                </option>
              ))}
            </select>
            <p className="text-[11px] text-slate-500">
              Initializes formal tasks for document verification, campus badge creation, IT credentials, and mentorship.
            </p>
          </div>

          {/* User Account Provisioning */}
          <div className="space-y-3 pt-2 border-t border-slate-100">
            <div className="flex items-center justify-between">
              <h4 className="font-bold text-slate-900 uppercase text-[10px] tracking-wider flex items-center gap-1.5">
                <KeyRound className="w-3.5 h-3.5 text-indigo-600" />
                <span>3. System Portal Account Credentials</span>
              </h4>

              <label className="flex items-center gap-1.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={createAccount}
                  onChange={(e) => setCreateAccount(e.target.checked)}
                  className="rounded text-indigo-600 focus:ring-indigo-500"
                />
                <span className="font-semibold text-slate-700 text-xs">Provision Account</span>
              </label>
            </div>

            {createAccount && (
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 grid grid-cols-1 sm:grid-cols-3 gap-3 animate-in fade-in">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Username</label>
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    required={createAccount}
                    className="w-full p-2 border border-slate-200 rounded-lg bg-white"
                  />
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Default Password</label>
                  <input
                    type="text"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required={createAccount}
                    className="w-full p-2 border border-slate-200 rounded-lg bg-white font-mono"
                  />
                </div>

                <div>
                  <label className="font-semibold text-slate-700 block mb-1">System Portal Role</label>
                  <select
                    value={accountRole}
                    onChange={(e) => setAccountRole(e.target.value as any)}
                    className="w-full p-2 border border-slate-200 rounded-lg bg-white font-bold text-indigo-700"
                  >
                    <option value="TEACHER">TEACHER</option>
                    <option value="SUPER_ADMIN">SUPER_ADMIN</option>
                  </select>
                </div>
              </div>
            )}
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
            <Button type="button" variant="outline" size="sm" onClick={onClose}>
              Cancel
            </Button>
            <Button
              type="submit"
              variant="primary"
              size="sm"
              disabled={isSubmitting}
              icon={<UserCheck className="w-3.5 h-3.5" />}
            >
              {isSubmitting ? 'Converting...' : 'Finalize Staff Onboarding'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};
