/**
 * Sygmate School Management System
 * Create Job Opening Modal (Part 12D)
 */

import React, { useState } from 'react';
import { Briefcase, Plus, AlertCircle } from 'lucide-react';
import { Button } from '../../../../components/ui/Button.js';
import { api } from '../../../../services/api.js';
import {
  Department,
  Designation,
  CreateJobOpeningPayload
} from '../../../../types/index.js';

interface CreateJobOpeningModalProps {
  isOpen: boolean;
  departments: Department[];
  designations: Designation[];
  onClose: () => void;
  onSuccess: () => void;
}

export const CreateJobOpeningModal: React.FC<CreateJobOpeningModalProps> = ({
  isOpen,
  departments,
  designations,
  onClose,
  onSuccess
}) => {
  const [title, setTitle] = useState<string>('');
  const [departmentId, setDepartmentId] = useState<string>(departments?.[0]?.id || '');
  const [designationTitle, setDesignationTitle] = useState<string>(designations?.[0]?.title || '');
  const [staffType, setStaffType] = useState<'teaching' | 'administrative' | 'support' | 'management' | 'operational'>('teaching');
  const [employmentType, setEmploymentType] = useState<'full_time' | 'part_time' | 'contract' | 'temporary'>('full_time');
  const [vacancies, setVacancies] = useState<number>(1);
  const [experienceYears, setExperienceYears] = useState<number>(2);
  const [workLocation, setWorkLocation] = useState<string>('Main Academic Campus');
  const [salaryRange, setSalaryRange] = useState<string>('$45,000 - $60,000 / year');
  const [closingDate, setClosingDate] = useState<string>(
    new Date(Date.now() + 86400000 * 30).toISOString().split('T')[0]
  );
  const [jobDescription, setJobDescription] = useState<string>('');
  const [skillsInput, setSkillsInput] = useState<string>('Curriculum Design, Classroom Management, Assessment');
  const [responsibilitiesInput, setResponsibilitiesInput] = useState<string>('Deliver high-quality instruction\nEvaluate student homework & assessments\nParticipate in faculty committees');
  const [qualificationsInput, setQualificationsInput] = useState<string>("Bachelor's or Master's degree in relevant discipline\nValid Teacher Certification or equivalent");

  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setError('Job title is required.');
      return;
    }

    setIsSubmitting(true);
    setError(null);

    const payload: CreateJobOpeningPayload = {
      title,
      departmentId,
      designationTitle,
      staffType,
      employmentType,
      vacancies,
      experienceYears,
      workLocation,
      salaryRange,
      applicationStartDate: new Date().toISOString().split('T')[0],
      applicationClosingDate: closingDate,
      jobDescription,
      requiredSkills: skillsInput.split(',').map((s) => s.trim()).filter(Boolean),
      responsibilities: responsibilitiesInput.split('\n').map((r) => r.trim()).filter(Boolean),
      qualifications: qualificationsInput.split('\n').map((q) => q.trim()).filter(Boolean)
    };

    try {
      await api.staff.recruitment.createJobOpening(payload);
      onSuccess();
    } catch (err: any) {
      setError(err.message || 'Failed to post job opening.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in">
      <div className="bg-white rounded-2xl max-w-2xl w-full p-6 space-y-4 max-h-[90vh] overflow-y-auto shadow-xl">
        <div className="flex items-start justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <Briefcase className="w-5 h-5 text-indigo-600" />
            <h2 className="text-base font-bold text-slate-900">Post New Institutional Job Opening</h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 text-xl font-bold"
          >
            &times;
          </button>
        </div>

        {error && (
          <div className="p-3 bg-red-50 text-red-700 text-xs rounded-lg border border-red-200 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
          <div>
            <label className="font-semibold text-slate-700 block mb-1">Job Opening Title</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Senior Secondary Mathematics Teacher"
              required
              className="w-full p-2 border border-slate-200 rounded-lg bg-white focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="font-semibold text-slate-700 block mb-1">Department</label>
              <select
                value={departmentId}
                onChange={(e) => setDepartmentId(e.target.value)}
                required
                className="w-full p-2 border border-slate-200 rounded-lg bg-white"
              >
                {departments.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="font-semibold text-slate-700 block mb-1">Designation Title</label>
              <input
                type="text"
                value={designationTitle}
                onChange={(e) => setDesignationTitle(e.target.value)}
                placeholder="e.g. Teacher Grade II"
                required
                className="w-full p-2 border border-slate-200 rounded-lg bg-white"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="font-semibold text-slate-700 block mb-1">Staff Classification</label>
              <select
                value={staffType}
                onChange={(e) => setStaffType(e.target.value as any)}
                className="w-full p-2 border border-slate-200 rounded-lg bg-white"
              >
                <option value="teaching">Teaching Faculty</option>
                <option value="administrative">Administrative Staff</option>
                <option value="support">Support Staff</option>
                <option value="management">Management</option>
                <option value="operational">Operational</option>
              </select>
            </div>

            <div>
              <label className="font-semibold text-slate-700 block mb-1">Employment Terms</label>
              <select
                value={employmentType}
                onChange={(e) => setEmploymentType(e.target.value as any)}
                className="w-full p-2 border border-slate-200 rounded-lg bg-white"
              >
                <option value="full_time">Full Time</option>
                <option value="part_time">Part Time</option>
                <option value="contract">Contractual</option>
                <option value="temporary">Temporary / Adjunct</option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Vacancies</label>
                <input
                  type="number"
                  min={1}
                  value={vacancies}
                  onChange={(e) => setVacancies(Number(e.target.value))}
                  required
                  className="w-full p-2 border border-slate-200 rounded-lg bg-white"
                />
              </div>
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Exp (Yrs)</label>
                <input
                  type="number"
                  min={0}
                  value={experienceYears}
                  onChange={(e) => setExperienceYears(Number(e.target.value))}
                  required
                  className="w-full p-2 border border-slate-200 rounded-lg bg-white"
                />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="font-semibold text-slate-700 block mb-1">Campus Location</label>
              <input
                type="text"
                value={workLocation}
                onChange={(e) => setWorkLocation(e.target.value)}
                required
                className="w-full p-2 border border-slate-200 rounded-lg bg-white"
              />
            </div>

            <div>
              <label className="font-semibold text-slate-700 block mb-1">Estimated Compensation</label>
              <input
                type="text"
                value={salaryRange}
                onChange={(e) => setSalaryRange(e.target.value)}
                placeholder="$40,000 - $55,000"
                className="w-full p-2 border border-slate-200 rounded-lg bg-white"
              />
            </div>

            <div>
              <label className="font-semibold text-slate-700 block mb-1">Closing Date</label>
              <input
                type="date"
                value={closingDate}
                onChange={(e) => setClosingDate(e.target.value)}
                required
                className="w-full p-2 border border-slate-200 rounded-lg bg-white"
              />
            </div>
          </div>

          <div>
            <label className="font-semibold text-slate-700 block mb-1">Job Description</label>
            <textarea
              rows={3}
              value={jobDescription}
              onChange={(e) => setJobDescription(e.target.value)}
              placeholder="Outline the institutional role, core mission, and academic environment..."
              className="w-full p-2 border border-slate-200 rounded-lg bg-white"
            />
          </div>

          <div>
            <label className="font-semibold text-slate-700 block mb-1">
              Required Skills (Comma separated)
            </label>
            <input
              type="text"
              value={skillsInput}
              onChange={(e) => setSkillsInput(e.target.value)}
              className="w-full p-2 border border-slate-200 rounded-lg bg-white"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="font-semibold text-slate-700 block mb-1">Responsibilities (One per line)</label>
              <textarea
                rows={3}
                value={responsibilitiesInput}
                onChange={(e) => setResponsibilitiesInput(e.target.value)}
                className="w-full p-2 border border-slate-200 rounded-lg bg-white"
              />
            </div>

            <div>
              <label className="font-semibold text-slate-700 block mb-1">Qualifications (One per line)</label>
              <textarea
                rows={3}
                value={qualificationsInput}
                onChange={(e) => setQualificationsInput(e.target.value)}
                className="w-full p-2 border border-slate-200 rounded-lg bg-white"
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
            <Button type="button" variant="outline" size="sm" onClick={onClose}>
              Cancel
            </Button>
            <Button
              type="submit"
              variant="primary"
              size="sm"
              disabled={isSubmitting}
            >
              {isSubmitting ? 'Publishing...' : 'Publish Job Opening'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};
