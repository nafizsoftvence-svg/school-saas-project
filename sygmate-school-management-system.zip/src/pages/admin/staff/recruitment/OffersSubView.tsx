/**
 * Sygmate School Management System
 * Job Offers & Administrative Approvals Sub-View (Part 12D)
 * Updated with Nordic Crisp Light styling and safe data rendering
 */

import React, { useState } from 'react';
import {
  FileCheck,
  Search,
  Plus,
  CheckCircle2,
  XCircle,
  Clock,
  Send,
  UserCheck,
  AlertCircle,
  FileText,
  DollarSign,
  Calendar,
  Building,
  Award
} from 'lucide-react';
import { Button } from '../../../../components/ui/Button.js';
import { api } from '../../../../services/api.js';
import {
  JobOffer,
  JobApplication,
  CandidateProfile,
  JobOpening,
  CreateJobOfferPayload
} from '../../../../types/index.js';

interface OffersSubViewProps {
  offers: JobOffer[];
  applications: JobApplication[];
  candidates: CandidateProfile[];
  openings: JobOpening[];
  onRefresh: () => void;
  onConvertToStaff: (candidate: CandidateProfile) => void;
}

export const OffersSubView: React.FC<OffersSubViewProps> = ({
  offers = [],
  applications = [],
  candidates = [],
  openings = [],
  onRefresh,
  onConvertToStaff
}) => {
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  // Create Offer Modal
  const [isCreateModalOpen, setIsCreateModalOpen] = useState<boolean>(false);
  const [selectedCandidateId, setSelectedCandidateId] = useState<string>('');
  const [designationTitle, setDesignationTitle] = useState<string>('Senior Faculty Member');
  const [departmentId, setDepartmentId] = useState<string>('');
  const [proposedJoiningDate, setProposedJoiningDate] = useState<string>(
    new Date(Date.now() + 86400000 * 14).toISOString().split('T')[0]
  );
  const [offerExpiryDate, setOfferExpiryDate] = useState<string>(
    new Date(Date.now() + 86400000 * 7).toISOString().split('T')[0]
  );
  const [basicSalary, setBasicSalary] = useState<number>(45000);
  const [probationMonths, setProbationMonths] = useState<number>(6);
  const [terms, setTerms] = useState<string>(
    '1. Working hours conform to official institutional timetables.\n2. Subject to verified document clearance.\n3. Six months probationary evaluation.'
  );
  const [isSubmittingCreate, setIsSubmittingCreate] = useState<boolean>(false);
  const [createError, setCreateError] = useState<string | null>(null);

  // View Offer Letter Preview
  const [selectedOfferForPreview, setSelectedOfferForPreview] = useState<JobOffer | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);

  const formatCompensation = (offerItem?: Partial<JobOffer> | null) => {
    if (!offerItem) return '—';
    if (offerItem.offeredSalary) return offerItem.offeredSalary;
    if (typeof (offerItem as any).basicSalary === 'number') {
      return `$${(offerItem as any).basicSalary.toLocaleString()} / mo`;
    }
    return 'Standard Grade Scale';
  };

  const filteredOffers = (offers || []).filter((o) => {
    if (!o) return false;
    if (statusFilter !== 'all' && o.status !== statusFilter) return false;
    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      const match =
        (o.candidateName || '').toLowerCase().includes(q) ||
        (o.offerNumber || '').toLowerCase().includes(q) ||
        (o.designationTitle || '').toLowerCase().includes(q);
      if (!match) return false;
    }
    return true;
  });

  const handleApprove = async (offerId: string) => {
    try {
      await api.staff.recruitment.reviewOffer(offerId, {
        decision: 'APPROVED',
        remarks: 'Executive approved'
      });
      onRefresh();
    } catch (err: any) {
      setActionError(err.message || 'Failed to approve offer.');
    }
  };

  const handleSend = async (offerId: string) => {
    try {
      await api.staff.recruitment.sendOffer(offerId);
      onRefresh();
    } catch (err: any) {
      setActionError(err.message || 'Failed to dispatch offer.');
    }
  };

  const handleRecordResponse = async (offerId: string, response: 'ACCEPTED' | 'REJECTED') => {
    try {
      await api.staff.recruitment.recordOfferResponse(offerId, {
        response,
        reason: response === 'ACCEPTED' ? 'Candidate accepted terms formally.' : 'Candidate opted out.'
      });
      onRefresh();
    } catch (err: any) {
      setActionError(err.message || 'Failed to record response.');
    }
  };

  const handleCreateOffer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCandidateId) {
      setCreateError('Please select a candidate.');
      return;
    }

    const candidate = (candidates || []).find((c) => c?.id === selectedCandidateId);
    if (!candidate) return;

    const app = (applications || []).find((a) => a.candidateId === selectedCandidateId) || applications?.[0];
    if (!app) {
      setCreateError('No application found for candidate.');
      return;
    }

    setIsSubmittingCreate(true);
    setCreateError(null);

    const safeSalary = typeof basicSalary === 'number' && !isNaN(basicSalary) ? basicSalary : 45000;
    const payload: CreateJobOfferPayload = {
      applicationId: app.id,
      designationTitle,
      proposedJoiningDate,
      offerExpiryDate,
      offeredSalary: `$${safeSalary.toLocaleString()} / mo`,
      probationPeriodMonths: probationMonths,
      termsAndConditions: terms
    };

    try {
      await api.staff.recruitment.createOffer(payload);
      setIsCreateModalOpen(false);
      onRefresh();
    } catch (err: any) {
      setCreateError(err.message || 'Failed to create offer.');
    } finally {
      setIsSubmittingCreate(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* Filters Header */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex flex-col md:flex-row gap-3 items-center justify-between">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search candidate name, offer ID..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-sky-600 bg-slate-50/50 text-slate-900"
          />
        </div>

        <div className="flex items-center gap-2">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 text-xs border border-slate-200 rounded-lg bg-white text-slate-700 focus:outline-none focus:ring-2 focus:ring-sky-600 cursor-pointer"
          >
            <option value="all">All Offer Statuses</option>
            <option value="DRAFT">Draft</option>
            <option value="PENDING_APPROVAL">Pending Approval</option>
            <option value="APPROVED">Approved by Leadership</option>
            <option value="SENT">Sent to Candidate</option>
            <option value="ACCEPTED">Accepted by Candidate</option>
            <option value="REJECTED">Declined</option>
            <option value="CONVERTED_TO_STAFF">Converted to Staff</option>
          </select>

          <Button
            type="button"
            variant="primary"
            size="sm"
            onClick={() => setIsCreateModalOpen(true)}
            icon={<Plus className="w-3.5 h-3.5" />}
          >
            Draft Offer Letter
          </Button>
        </div>
      </div>

      {actionError && (
        <div className="p-3 bg-rose-50 text-rose-800 text-xs rounded-lg border border-rose-200 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
          <span>{actionError}</span>
        </div>
      )}

      {/* Offers Table */}
      {filteredOffers.length === 0 ? (
        <div className="p-12 text-center bg-white rounded-xl border border-slate-200 text-slate-500 space-y-2">
          <FileCheck className="w-10 h-10 mx-auto text-slate-300" />
          <p className="text-sm font-semibold text-slate-800">No offers recorded matching criteria.</p>
          <Button type="button" variant="outline" size="sm" onClick={() => setIsCreateModalOpen(true)}>
            Draft First Offer
          </Button>
        </div>
      ) : (
        <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-700">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase text-[10px] tracking-wider">
                <tr>
                  <th className="py-3 px-4">Offer ID</th>
                  <th className="py-3 px-4">Candidate</th>
                  <th className="py-3 px-4">Offered Role</th>
                  <th className="py-3 px-4">Compensation</th>
                  <th className="py-3 px-4">Proposed Joining</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredOffers.map((offer) => {
                  const candidate = (candidates || []).find((c) => c?.id === offer.candidateId);
                  return (
                    <tr key={offer.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3.5 px-4 font-mono font-bold text-sky-700">
                        {offer.offerNumber}
                      </td>

                      <td className="py-3.5 px-4">
                        <span className="font-bold text-slate-900 block">{offer.candidateName}</span>
                        <span className="text-[11px] text-slate-500">{offer.candidateEmail}</span>
                      </td>

                      <td className="py-3.5 px-4">
                        <span className="font-semibold text-slate-800 block">{offer.designationTitle || offer.positionTitle}</span>
                        <span className="text-[11px] text-slate-500">{offer.departmentName}</span>
                      </td>

                      <td className="py-3.5 px-4 font-semibold text-slate-800">
                        <div>{formatCompensation(offer)}</div>
                        <span className="text-[10px] text-slate-500 block font-normal">
                          Probation: {offer.probationPeriodMonths ?? 6} mos
                        </span>
                      </td>

                      <td className="py-3.5 px-4">
                        <span className="font-medium text-slate-800 block">{offer.proposedJoiningDate || '—'}</span>
                        <span className="text-[10px] text-slate-500">Expires: {offer.offerExpiryDate || '—'}</span>
                      </td>

                      <td className="py-3.5 px-4">
                        <span
                          className={`inline-block text-[10px] px-2.5 py-1 rounded-full font-bold uppercase tracking-wider ${
                            offer.status === 'ACCEPTED' || offer.status === 'CONVERTED_TO_STAFF'
                              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                              : offer.status === 'APPROVED'
                              ? 'bg-sky-50 text-sky-800 border border-sky-200'
                              : offer.status === 'SENT'
                              ? 'bg-blue-50 text-blue-800 border border-blue-200'
                              : offer.status === 'REJECTED'
                              ? 'bg-rose-50 text-rose-800 border border-rose-200'
                              : 'bg-amber-50 text-amber-800 border border-amber-200'
                          }`}
                        >
                          {(offer.status || 'PENDING').replace(/_/g, ' ')}
                        </span>
                      </td>

                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            type="button"
                            onClick={() => setSelectedOfferForPreview(offer)}
                            className="px-2.5 py-1 text-xs font-semibold text-slate-700 hover:text-slate-900 hover:bg-slate-100 rounded-md border border-slate-200 cursor-pointer transition-colors"
                          >
                            Letter
                          </button>

                          {offer.status === 'PENDING_APPROVAL' && (
                            <button
                              type="button"
                              onClick={() => handleApprove(offer.id)}
                              className="px-2.5 py-1 text-xs font-bold text-white bg-sky-700 hover:bg-sky-800 rounded-md cursor-pointer transition-colors shadow-2xs"
                            >
                              Approve
                            </button>
                          )}

                          {offer.status === 'APPROVED' && (
                            <button
                              type="button"
                              onClick={() => handleSend(offer.id)}
                              className="px-2.5 py-1 text-xs font-bold text-white bg-sky-700 hover:bg-sky-800 rounded-md flex items-center gap-1 cursor-pointer transition-colors shadow-2xs"
                            >
                              <Send className="w-3 h-3" />
                              <span>Dispatch</span>
                            </button>
                          )}

                          {offer.status === 'SENT' && (
                            <>
                              <button
                                type="button"
                                onClick={() => handleRecordResponse(offer.id, 'ACCEPTED')}
                                className="px-2 py-1 text-xs font-bold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-md cursor-pointer transition-colors"
                              >
                                Mark Accepted
                              </button>
                              <button
                                type="button"
                                onClick={() => handleRecordResponse(offer.id, 'REJECTED')}
                                className="px-2 py-1 text-xs font-bold text-rose-800 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded-md cursor-pointer transition-colors"
                              >
                                Decline
                              </button>
                            </>
                          )}

                          {offer.status === 'ACCEPTED' && candidate && (
                            <button
                              type="button"
                              onClick={() => onConvertToStaff(candidate)}
                              className="px-2.5 py-1 text-xs font-bold text-white bg-emerald-700 hover:bg-emerald-800 rounded-md flex items-center gap-1 shadow-2xs cursor-pointer transition-colors"
                            >
                              <UserCheck className="w-3.5 h-3.5" />
                              <span>Convert to Staff</span>
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Formal Appointment Letter Preview Modal */}
      {selectedOfferForPreview && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in">
          <div className="bg-white rounded-2xl max-w-2xl w-full p-8 space-y-6 max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-200">
            {/* Letterhead */}
            <div className="border-b-2 border-slate-900 pb-4 text-center space-y-1">
              <span className="text-[10px] tracking-widest uppercase font-bold text-sky-700 block">
                Sygmate Academic Institution
              </span>
              <h1 className="text-xl font-black text-slate-900 tracking-tight">
                OFFICIAL APPOINTMENT OFFER
              </h1>
              <p className="text-xs text-slate-500 font-mono">Reference: {selectedOfferForPreview.offerNumber}</p>
            </div>

            {/* Letter Content */}
            <div className="space-y-4 text-xs text-slate-800 leading-relaxed">
              <div className="flex justify-between items-start">
                <div>
                  <p><strong>To:</strong></p>
                  <p className="font-bold text-sm text-slate-900">{selectedOfferForPreview.candidateName}</p>
                  <p className="text-slate-600">{selectedOfferForPreview.candidateEmail}</p>
                </div>
                <div className="text-right">
                  <p><strong>Date of Issue:</strong></p>
                  <p>{selectedOfferForPreview.proposedJoiningDate || new Date().toISOString().split('T')[0]}</p>
                  <p className="text-rose-700 font-semibold">
                    <strong>Valid Until:</strong> {selectedOfferForPreview.offerExpiryDate || 'Within 14 calendar days'}
                  </p>
                </div>
              </div>

              <p>
                Dear {selectedOfferForPreview.candidateName},
              </p>
              <p>
                On behalf of the Governing Board and Academic Leadership of Sygmate School, we are delighted to formally offer you the position of{' '}
                <strong className="text-slate-900">
                  {selectedOfferForPreview.designationTitle || selectedOfferForPreview.positionTitle || 'Academic Faculty'}
                </strong>{' '}
                in the Department of{' '}
                <strong className="text-slate-900">
                  {selectedOfferForPreview.departmentName || 'Academic Department'}
                </strong>.
              </p>

              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 grid grid-cols-2 gap-3 font-medium">
                <div>
                  <strong className="text-slate-900">Designation:</strong> {selectedOfferForPreview.designationTitle || selectedOfferForPreview.positionTitle}
                </div>
                <div>
                  <strong className="text-slate-900">Department:</strong> {selectedOfferForPreview.departmentName || 'Academic Faculty'}
                </div>
                <div>
                  <strong className="text-slate-900">Monthly Compensation:</strong> {formatCompensation(selectedOfferForPreview)}
                </div>
                <div>
                  <strong className="text-slate-900">Proposed Joining:</strong> {selectedOfferForPreview.proposedJoiningDate || 'To be confirmed'}
                </div>
                <div>
                  <strong className="text-slate-900">Probationary Term:</strong> {selectedOfferForPreview.probationPeriodMonths ?? 6} Months
                </div>
                <div>
                  <strong className="text-slate-900">Offer Status:</strong>{' '}
                  <span className="uppercase font-bold text-sky-800">
                    {selectedOfferForPreview.status}
                  </span>
                </div>
              </div>

              <div className="space-y-1">
                <h4 className="font-bold uppercase text-[10px] tracking-wider text-slate-600">Terms &amp; Conditions of Employment</h4>
                <p className="whitespace-pre-line text-slate-700 p-3 bg-slate-50 rounded-lg border border-slate-200">
                  {selectedOfferForPreview.termsAndConditions || 'Subject to verified credential clearance, standard criminal background investigation, and compliance with the Sygmate Staff Code of Conduct.'}
                </p>
              </div>

              <p className="text-[11px] text-slate-500 italic">
                Please review this appointment letter carefully and signify your formal acceptance via the Sygmate Staff Portal on or before the stated validity date.
              </p>
            </div>

            <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-200">
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => setSelectedOfferForPreview(null)}
              >
                Close Preview
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Create Offer Modal */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in">
          <div className="bg-white rounded-2xl max-w-xl w-full p-6 space-y-4 max-h-[90vh] overflow-y-auto shadow-xl border border-slate-200">
            <div className="flex items-start justify-between border-b border-slate-200 pb-3">
              <div>
                <h2 className="text-base font-bold text-slate-900">Draft New Appointment Offer</h2>
                <p className="text-xs text-slate-500">Formulate official terms for selected candidates</p>
              </div>
              <button
                type="button"
                onClick={() => setIsCreateModalOpen(false)}
                className="text-slate-400 hover:text-slate-700 text-xl font-bold cursor-pointer"
              >
                &times;
              </button>
            </div>

            {createError && (
              <div className="p-3 bg-rose-50 text-rose-800 text-xs rounded-lg border border-rose-200 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
                <span>{createError}</span>
              </div>
            )}

            <form onSubmit={handleCreateOffer} className="space-y-4 text-xs">
              <div>
                <label className="font-semibold text-slate-800 block mb-1">Select Candidate</label>
                <select
                  value={selectedCandidateId}
                  onChange={(e) => {
                    const id = e.target.value;
                    setSelectedCandidateId(id);
                    const c = (candidates || []).find((cand) => cand?.id === id);
                    if (c) {
                      setDesignationTitle(c.appliedPositionTitle || 'Faculty Member');
                      setDepartmentId(c.departmentId || '');
                    }
                  }}
                  required
                  className="w-full p-2.5 border border-slate-300 rounded-xl bg-white text-slate-900 focus:ring-2 focus:ring-sky-600 focus:outline-none cursor-pointer"
                >
                  <option value="">-- Choose Candidate --</option>
                  {(candidates || [])
                    .filter((c) => c && c.status !== 'CONVERTED_TO_STAFF')
                    .map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.fullName} ({c.appliedPositionTitle} • Stage: {c.currentStage})
                      </option>
                    ))}
                </select>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-800 block mb-1">Offered Designation</label>
                  <input
                    type="text"
                    value={designationTitle}
                    onChange={(e) => setDesignationTitle(e.target.value)}
                    required
                    className="w-full p-2.5 border border-slate-300 rounded-xl bg-white text-slate-900 focus:ring-2 focus:ring-sky-600 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="font-semibold text-slate-800 block mb-1">Monthly Salary ($)</label>
                  <input
                    type="number"
                    value={basicSalary}
                    onChange={(e) => setBasicSalary(Number(e.target.value))}
                    required
                    className="w-full p-2.5 border border-slate-300 rounded-xl bg-white text-slate-900 focus:ring-2 focus:ring-sky-600 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="font-semibold text-slate-800 block mb-1">Proposed Joining Date</label>
                  <input
                    type="date"
                    value={proposedJoiningDate}
                    onChange={(e) => setProposedJoiningDate(e.target.value)}
                    required
                    className="w-full p-2.5 border border-slate-300 rounded-xl bg-white text-slate-900 focus:ring-2 focus:ring-sky-600 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="font-semibold text-slate-800 block mb-1">Offer Expiry Date</label>
                  <input
                    type="date"
                    value={offerExpiryDate}
                    onChange={(e) => setOfferExpiryDate(e.target.value)}
                    required
                    className="w-full p-2.5 border border-slate-300 rounded-xl bg-white text-slate-900 focus:ring-2 focus:ring-sky-600 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="font-semibold text-slate-800 block mb-1">Probation (Months)</label>
                  <input
                    type="number"
                    value={probationMonths}
                    onChange={(e) => setProbationMonths(Number(e.target.value))}
                    required
                    className="w-full p-2.5 border border-slate-300 rounded-xl bg-white text-slate-900 focus:ring-2 focus:ring-sky-600 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="font-semibold text-slate-800 block mb-1">Terms &amp; Conditions</label>
                <textarea
                  rows={3}
                  value={terms}
                  onChange={(e) => setTerms(e.target.value)}
                  className="w-full p-2.5 border border-slate-300 rounded-xl bg-white text-slate-900 focus:ring-2 focus:ring-sky-600 focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setIsCreateModalOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  variant="primary"
                  size="sm"
                  disabled={isSubmittingCreate}
                >
                  {isSubmittingCreate ? 'Creating...' : 'Create Appointment Offer'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
