/**
 * Sygmate School Management System
 * Create / Register Candidate Modal (Part 12D)
 */

import React, { useState } from 'react';
import { UserPlus, AlertCircle } from 'lucide-react';
import { Button } from '../../../../components/ui/Button.js';
import { api } from '../../../../services/api.js';
import {
  JobOpening,
  CreateCandidatePayload
} from '../../../../types/index.js';

interface CreateCandidateModalProps {
  isOpen: boolean;
  openings: JobOpening[];
  onClose: () => void;
  onSuccess: () => void;
}

export const CreateCandidateModal: React.FC<CreateCandidateModalProps> = ({
  isOpen,
  openings,
  onClose,
  onSuccess
}) => {
  const [firstName, setFirstName] = useState<string>('');
  const [lastName, setLastName] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [phone, setPhone] = useState<string>('');
  const [gender, setGender] = useState<'male' | 'female' | 'other'>('male');
  const [dateOfBirth, setDateOfBirth] = useState<string>('1990-05-15');
  const [address, setAddress] = useState<string>('42 Academic Avenue, Campus Town');
  const [highestQualification, setHighestQualification] = useState<string>("Master's in Education");
  const [specialization, setSpecialization] = useState<string>('Curriculum & Pedagogy');
  const [yearsOfExperience, setYearsOfExperience] = useState<number>(3);
  const [currentEmployer, setCurrentEmployer] = useState<string>('Saint Jude Academy');
  const [noticePeriodDays, setNoticePeriodDays] = useState<number>(30);
  const [appliedPositionId, setAppliedPositionId] = useState<string>(openings?.[0]?.id || '');
  const [skillsInput, setSkillsInput] = useState<string>('Classroom Instruction, Lesson Planning, Student Mentoring');
  const [coverLetter, setCoverLetter] = useState<string>(
    'I am excited to apply for this institutional faculty position at Sygmate School. With extensive classroom experience, I am eager to contribute to student academic excellence.'
  );

  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!firstName.trim() || !lastName.trim() || !email.trim() || !phone.trim()) {
      setError('Please provide candidate full name, email, and phone number.');
      return;
    }

    setIsSubmitting(true);
    setError(null);

    const payload: CreateCandidatePayload = {
      firstName,
      lastName,
      email,
      phone,
      gender,
      dateOfBirth,
      address,
      highestQualification,
      specialization,
      yearsOfExperience,
      previousEmployment: currentEmployer,
      notes: noticePeriodDays ? `Notice period: ${noticePeriodDays} days` : undefined,
      applyForJobOpeningId: appliedPositionId || undefined,
      skills: skillsInput.split(',').map((s) => s.trim()).filter(Boolean),
      coverLetter
    };

    try {
      await api.staff.recruitment.createCandidate(payload);
      onSuccess();
    } catch (err: any) {
      setError(err.message || 'Failed to register candidate.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in">
      <div className="bg-white rounded-2xl max-w-2xl w-full p-6 space-y-4 max-h-[90vh] overflow-y-auto shadow-xl">
        <div className="flex items-start justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <UserPlus className="w-5 h-5 text-indigo-600" />
            <h2 className="text-base font-bold text-slate-900">Register Candidate Profile</h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 text-xl font-bold"
          >
            &times;
          </button>
        </div>

        {error && (
          <div className="p-3 bg-red-50 text-red-700 text-xs rounded-lg border border-red-200 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="font-semibold text-slate-700 block mb-1">First Name</label>
              <input
                type="text"
                value={firstName}
                onChange={(e) => setFirstName(e.target.value)}
                required
                className="w-full p-2 border border-slate-200 rounded-lg bg-white focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="font-semibold text-slate-700 block mb-1">Last Name</label>
              <input
                type="text"
                value={lastName}
                onChange={(e) => setLastName(e.target.value)}
                required
                className="w-full p-2 border border-slate-200 rounded-lg bg-white focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="font-semibold text-slate-700 block mb-1">Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="w-full p-2 border border-slate-200 rounded-lg bg-white"
              />
            </div>
            <div>
              <label className="font-semibold text-slate-700 block mb-1">Phone</label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                required
                className="w-full p-2 border border-slate-200 rounded-lg bg-white"
              />
            </div>
            <div>
              <label className="font-semibold text-slate-700 block mb-1">Gender</label>
              <select
                value={gender}
                onChange={(e) => setGender(e.target.value as any)}
                className="w-full p-2 border border-slate-200 rounded-lg bg-white"
              >
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Other</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="font-semibold text-slate-700 block mb-1">Position Applied For</label>
              <select
                value={appliedPositionId}
                onChange={(e) => setAppliedPositionId(e.target.value)}
                className="w-full p-2 border border-slate-200 rounded-lg bg-white"
              >
                <option value="">-- Unassigned / General Pool --</option>
                {openings.map((o) => (
                  <option key={o.id} value={o.id}>
                    {o.title} ({o.code})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="font-semibold text-slate-700 block mb-1">Current Address</label>
              <input
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                className="w-full p-2 border border-slate-200 rounded-lg bg-white"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="font-semibold text-slate-700 block mb-1">Highest Qualification</label>
              <input
                type="text"
                value={highestQualification}
                onChange={(e) => setHighestQualification(e.target.value)}
                required
                className="w-full p-2 border border-slate-200 rounded-lg bg-white"
              />
            </div>

            <div>
              <label className="font-semibold text-slate-700 block mb-1">Specialization / Major</label>
              <input
                type="text"
                value={specialization}
                onChange={(e) => setSpecialization(e.target.value)}
                className="w-full p-2 border border-slate-200 rounded-lg bg-white"
              />
            </div>

            <div>
              <label className="font-semibold text-slate-700 block mb-1">Years of Experience</label>
              <input
                type="number"
                min={0}
                value={yearsOfExperience}
                onChange={(e) => setYearsOfExperience(Number(e.target.value))}
                className="w-full p-2 border border-slate-200 rounded-lg bg-white"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="font-semibold text-slate-700 block mb-1">Current Employer</label>
              <input
                type="text"
                value={currentEmployer}
                onChange={(e) => setCurrentEmployer(e.target.value)}
                className="w-full p-2 border border-slate-200 rounded-lg bg-white"
              />
            </div>

            <div>
              <label className="font-semibold text-slate-700 block mb-1">Notice Period (Days)</label>
              <input
                type="number"
                min={0}
                value={noticePeriodDays}
                onChange={(e) => setNoticePeriodDays(Number(e.target.value))}
                className="w-full p-2 border border-slate-200 rounded-lg bg-white"
              />
            </div>
          </div>

          <div>
            <label className="font-semibold text-slate-700 block mb-1">Core Skills (Comma separated)</label>
            <input
              type="text"
              value={skillsInput}
              onChange={(e) => setSkillsInput(e.target.value)}
              className="w-full p-2 border border-slate-200 rounded-lg bg-white"
            />
          </div>

          <div>
            <label className="font-semibold text-slate-700 block mb-1">Cover Letter / Statement</label>
            <textarea
              rows={3}
              value={coverLetter}
              onChange={(e) => setCoverLetter(e.target.value)}
              className="w-full p-2 border border-slate-200 rounded-lg bg-white"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
            <Button type="button" variant="outline" size="sm" onClick={onClose}>
              Cancel
            </Button>
            <Button
              type="submit"
              variant="primary"
              size="sm"
              disabled={isSubmitting}
            >
              {isSubmitting ? 'Registering...' : 'Register Candidate'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};
