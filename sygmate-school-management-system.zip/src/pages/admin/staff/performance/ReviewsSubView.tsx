import React, { useState } from 'react';
import {
  Search,
  Filter,
  Award,
  Calendar,
  User,
  Building,
  CheckCircle2,
  Clock,
  AlertCircle,
  ExternalLink,
  Plus,
  FileSpreadsheet,
  RefreshCw,
  TrendingUp,
  Layers
} from 'lucide-react';
import { Button } from '../../../../components/ui/Button.js';
import { api } from '../../../../services/api.js';
import {
  StaffPerformanceReview,
  PerformanceReviewCycle,
  Department,
  ReviewStage,
  RatingBand
} from '../../../../types/index.js';

interface ReviewsSubViewProps {
  reviews: StaffPerformanceReview[];
  cycles: PerformanceReviewCycle[];
  departments: Department[];
  isLoading: boolean;
  onRefresh: () => void;
  onSelectReview: (review: StaffPerformanceReview) => void;
  onBatchGenerate: (cycleId: string) => void;
}

export const ReviewsSubView: React.FC<ReviewsSubViewProps> = ({
  reviews,
  cycles,
  departments,
  isLoading,
  onRefresh,
  onSelectReview,
  onBatchGenerate
}) => {
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedCycleId, setSelectedCycleId] = useState<string>('');
  const [selectedDeptId, setSelectedDeptId] = useState<string>('');
  const [selectedStage, setSelectedStage] = useState<string>('');
  const [selectedBand, setSelectedBand] = useState<string>('');

  const filteredReviews = reviews.filter((r) => {
    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      const matchName = r.staffName.toLowerCase().includes(q);
      const matchCode = r.staffEmployeeCode.toLowerCase().includes(q);
      const matchDept = r.departmentName.toLowerCase().includes(q);
      if (!matchName && !matchCode && !matchDept) return false;
    }
    if (selectedCycleId && r.reviewCycleId !== selectedCycleId) return false;
    if (selectedDeptId && r.departmentId !== selectedDeptId) return false;
    if (selectedStage && r.status !== selectedStage) return false;
    if (selectedBand && r.hrReview?.finalRatingBand !== selectedBand) return false;
    return true;
  });

  const getStageBadge = (status: ReviewStage) => {
    switch (status) {
      case 'DRAFT':
        return <span className="px-2 py-0.5 rounded text-2xs font-semibold bg-slate-100 text-slate-700">Draft</span>;
      case 'SELF_ASSESSMENT':
        return <span className="px-2 py-0.5 rounded text-2xs font-semibold bg-sky-100 text-sky-800">Self-Assessment</span>;
      case 'SUPERVISOR_REVIEW':
        return <span className="px-2 py-0.5 rounded text-2xs font-semibold bg-indigo-100 text-indigo-800">Supervisor Review</span>;
      case 'HR_REVIEW':
        return <span className="px-2 py-0.5 rounded text-2xs font-semibold bg-amber-100 text-amber-800">HR Executive</span>;
      case 'FINALIZED':
        return <span className="px-2 py-0.5 rounded text-2xs font-semibold bg-emerald-100 text-emerald-800">Awaiting Sign-off</span>;
      case 'ACKNOWLEDGED':
        return <span className="px-2 py-0.5 rounded text-2xs font-semibold bg-green-100 text-green-800">Acknowledged</span>;
      case 'CLOSED':
        return <span className="px-2 py-0.5 rounded text-2xs font-semibold bg-slate-200 text-slate-800">Closed</span>;
      default:
        return <span className="px-2 py-0.5 rounded text-2xs font-semibold bg-slate-100 text-slate-700">{status}</span>;
    }
  };

  const getRatingBadge = (band?: RatingBand) => {
    if (!band) return <span className="text-2xs text-slate-400 italic">Pending HR</span>;
    switch (band) {
      case 'EXCEPTIONAL':
        return <span className="px-2 py-0.5 rounded-full text-2xs font-bold bg-purple-100 text-purple-800">Exceptional</span>;
      case 'EXCEEDS_EXPECTATIONS':
        return <span className="px-2 py-0.5 rounded-full text-2xs font-bold bg-emerald-100 text-emerald-800">Exceeds</span>;
      case 'MEETS_EXPECTATIONS':
        return <span className="px-2 py-0.5 rounded-full text-2xs font-bold bg-blue-100 text-blue-800">Meets</span>;
      case 'NEEDS_IMPROVEMENT':
        return <span className="px-2 py-0.5 rounded-full text-2xs font-bold bg-amber-100 text-amber-800">Needs Impr.</span>;
      case 'UNSATISFACTORY':
        return <span className="px-2 py-0.5 rounded-full text-2xs font-bold bg-red-100 text-red-800">Unsatisfactory</span>;
    }
  };

  const exportReviewsCsv = () => {
    const headers = [
      'Employee Code',
      'Staff Name',
      'Department',
      'Designation',
      'Cycle',
      'Stage',
      'Supervisor',
      'Calculated Score',
      'Rating Band',
      'Acknowledged'
    ];
    const rows = filteredReviews.map((r) => [
      r.staffEmployeeCode,
      `"${r.staffName}"`,
      `"${r.departmentName}"`,
      `"${r.designationTitle}"`,
      `"${r.reviewCycleName}"`,
      r.status,
      `"${r.reviewerName}"`,
      r.hrReview?.finalCalculatedScore ?? r.supervisorReview?.calculatedScore ?? '',
      r.hrReview?.finalRatingBand ?? '',
      r.acknowledgement?.isAcknowledged ? 'Yes' : 'No'
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const link = document.createElement('a');
    link.href = encodeURI(csvContent);
    link.download = `Staff_Appraisals_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
  };

  return (
    <div className="space-y-4">
      {/* Control Toolbar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 bg-white p-4 rounded-xl border border-slate-200">
        <div className="flex flex-wrap items-center gap-2 flex-1">
          <div className="relative flex-1 min-w-[200px] max-w-sm">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search by staff name, code, or department..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
            />
          </div>

          <select
            value={selectedCycleId}
            onChange={(e) => setSelectedCycleId(e.target.value)}
            className="text-xs p-2 border border-slate-200 rounded-lg bg-white"
          >
            <option value="">All Review Cycles</option>
            {cycles.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>

          <select
            value={selectedDeptId}
            onChange={(e) => setSelectedDeptId(e.target.value)}
            className="text-xs p-2 border border-slate-200 rounded-lg bg-white"
          >
            <option value="">All Departments</option>
            {departments.map((d) => (
              <option key={d.id} value={d.id}>
                {d.name}
              </option>
            ))}
          </select>

          <select
            value={selectedStage}
            onChange={(e) => setSelectedStage(e.target.value)}
            className="text-xs p-2 border border-slate-200 rounded-lg bg-white"
          >
            <option value="">All Stages</option>
            <option value="DRAFT">Draft</option>
            <option value="SELF_ASSESSMENT">Self-Assessment</option>
            <option value="SUPERVISOR_REVIEW">Supervisor Review</option>
            <option value="HR_REVIEW">HR Review</option>
            <option value="FINALIZED">Awaiting Sign-off</option>
            <option value="ACKNOWLEDGED">Acknowledged</option>
          </select>

          <select
            value={selectedBand}
            onChange={(e) => setSelectedBand(e.target.value)}
            className="text-xs p-2 border border-slate-200 rounded-lg bg-white"
          >
            <option value="">All Rating Bands</option>
            <option value="EXCEPTIONAL">Exceptional</option>
            <option value="EXCEEDS_EXPECTATIONS">Exceeds Expectations</option>
            <option value="MEETS_EXPECTATIONS">Meets Expectations</option>
            <option value="NEEDS_IMPROVEMENT">Needs Improvement</option>
            <option value="UNSATISFACTORY">Unsatisfactory</option>
          </select>
        </div>

        <div className="flex items-center gap-2">
          {selectedCycleId && (
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => onBatchGenerate(selectedCycleId)}
              icon={<Layers className="w-3.5 h-3.5" />}
            >
              Generate Reviews for Cycle
            </Button>
          )}

          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={exportReviewsCsv}
            icon={<FileSpreadsheet className="w-3.5 h-3.5" />}
          >
            Export CSV
          </Button>

          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={onRefresh}
            icon={<RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />}
          >
            Refresh
          </Button>
        </div>
      </div>

      {/* Review Dossiers Table */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-2xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-500 uppercase tracking-wider text-2xs font-bold">
                <th className="py-3 px-4">Staff Member</th>
                <th className="py-3 px-4">Department & Role</th>
                <th className="py-3 px-4">Cycle & Period</th>
                <th className="py-3 px-4">Current Stage</th>
                <th className="py-3 px-4">Supervisor</th>
                <th className="py-3 px-4">Overall Score</th>
                <th className="py-3 px-4">Rating Band</th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredReviews.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-400">
                    <Award className="w-8 h-8 mx-auto mb-2 text-slate-300" />
                    <p className="font-medium">No performance review dossiers found</p>
                    <p className="text-2xs mt-1">Select an active cycle and generate reviews or adjust filters</p>
                  </td>
                </tr>
              ) : (
                filteredReviews.map((review) => {
                  const score = review.hrReview?.finalCalculatedScore ?? review.supervisorReview?.calculatedScore;
                  return (
                    <tr
                      key={review.id}
                      className="hover:bg-slate-50/60 transition-colors cursor-pointer"
                      onClick={() => onSelectReview(review)}
                    >
                      <td className="py-3 px-4">
                        <div className="font-bold text-slate-900">{review.staffName}</div>
                        <div className="text-2xs font-mono text-slate-500">{review.staffEmployeeCode}</div>
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-medium text-slate-800">{review.departmentName}</div>
                        <div className="text-2xs text-slate-500">{review.designationTitle}</div>
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-medium text-slate-800">{review.reviewCycleName}</div>
                        <div className="text-2xs text-slate-400">{review.reviewPeriod}</div>
                      </td>
                      <td className="py-3 px-4">
                        {getStageBadge(review.status)}
                      </td>
                      <td className="py-3 px-4 font-medium text-slate-700">
                        {review.reviewerName}
                      </td>
                      <td className="py-3 px-4">
                        {score !== undefined ? (
                          <div className="flex items-center gap-1.5 font-bold text-slate-900">
                            <span className="text-sm">{score}%</span>
                          </div>
                        ) : (
                          <span className="text-2xs text-slate-400 italic">Unscored</span>
                        )}
                      </td>
                      <td className="py-3 px-4">
                        {getRatingBadge(review.hrReview?.finalRatingBand)}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <Button
                          type="button"
                          variant="ghost"
                          size="xs"
                          onClick={(e) => {
                            e.stopPropagation();
                            onSelectReview(review);
                          }}
                          icon={<ExternalLink className="w-3.5 h-3.5" />}
                        >
                          View Dossier
                        </Button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
