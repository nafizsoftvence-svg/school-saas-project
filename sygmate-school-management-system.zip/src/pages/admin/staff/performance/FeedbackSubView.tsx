import React, { useState } from 'react';
import {
  MessageSquare,
  Plus,
  Star,
  User,
  Heart,
  ShieldCheck,
  Award
} from 'lucide-react';
import { Button } from '../../../../components/ui/Button.js';
import {
  PerformanceFeedback,
  FeedbackType
} from '../../../../types/index.js';

interface FeedbackSubViewProps {
  feedbackList: PerformanceFeedback[];
  isLoading: boolean;
  onRefresh: () => void;
  onOpenCreateModal: () => void;
}

export const FeedbackSubView: React.FC<FeedbackSubViewProps> = ({
  feedbackList,
  isLoading,
  onRefresh,
  onOpenCreateModal
}) => {
  const [typeFilter, setTypeFilter] = useState<string>('ALL');

  const filtered = feedbackList.filter((f) => {
    if (typeFilter !== 'ALL' && f.feedbackType !== typeFilter) return false;
    return true;
  });

  const getTypeBadge = (t: FeedbackType) => {
    switch (t) {
      case 'COMMENDATION':
        return <span className="px-2 py-0.5 rounded text-2xs font-bold bg-amber-100 text-amber-800">Commendation & Praise</span>;
      case 'PEER_REVIEW':
        return <span className="px-2 py-0.5 rounded text-2xs font-bold bg-indigo-100 text-indigo-800">Peer Review</span>;
      case '360_FEEDBACK':
        return <span className="px-2 py-0.5 rounded text-2xs font-bold bg-purple-100 text-purple-800">360° Multi-Rater</span>;
      case 'COACHING_NOTE':
        return <span className="px-2 py-0.5 rounded text-2xs font-bold bg-blue-100 text-blue-800">Coaching Note</span>;
      default:
        return null;
    }
  };

  return (
    <div className="space-y-4">
      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 bg-white p-4 rounded-xl border border-slate-200">
        <div>
          <h3 className="text-sm font-bold text-slate-900">Continuous 360° & Peer Performance Feedback</h3>
          <p className="text-xs text-slate-500">Commendations, peer coaching notes, and formal recognitions</p>
        </div>

        <div className="flex items-center gap-2">
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="text-xs p-2 border border-slate-200 rounded-lg bg-white"
          >
            <option value="ALL">All Feedback Types</option>
            <option value="COMMENDATION">Commendation</option>
            <option value="PEER_REVIEW">Peer Review</option>
            <option value="360_FEEDBACK">360° Feedback</option>
            <option value="COACHING_NOTE">Coaching Note</option>
          </select>

          <Button
            type="button"
            variant="primary"
            size="sm"
            onClick={onOpenCreateModal}
            icon={<Plus className="w-4 h-4" />}
          >
            Record Feedback
          </Button>
        </div>
      </div>

      {/* Feedback Feed */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filtered.length === 0 ? (
          <div className="col-span-2 p-12 text-center bg-white rounded-xl border border-slate-200 text-slate-400">
            <MessageSquare className="w-8 h-8 mx-auto mb-2 text-slate-300" />
            <p className="font-medium">No performance feedback logged</p>
          </div>
        ) : (
          filtered.map((fb) => (
            <div
              key={fb.id}
              className="bg-white rounded-xl border border-slate-200 p-5 space-y-3 hover:shadow-2xs transition-all"
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="text-sm font-bold text-slate-900">{fb.staffName}</div>
                  <div className="text-2xs text-slate-500">
                    From: {fb.isAnonymous ? 'Anonymous Peer' : fb.authorName} ({fb.authorRole})
                  </div>
                </div>
                {getTypeBadge(fb.feedbackType)}
              </div>

              <p className="text-xs text-slate-700 bg-slate-50 p-3 rounded-lg border border-slate-100 italic">
                &quot;{fb.comments}&quot;
              </p>

              {(fb.strengths || fb.areasForImprovement) && (
                <div className="grid grid-cols-2 gap-2 text-2xs">
                  {fb.strengths && (
                    <div className="p-2 bg-emerald-50 text-emerald-800 rounded-lg">
                      <span className="font-bold">Strengths:</span> {fb.strengths}
                    </div>
                  )}
                  {fb.areasForImprovement && (
                    <div className="p-2 bg-amber-50 text-amber-800 rounded-lg">
                      <span className="font-bold">Areas to Grow:</span> {fb.areasForImprovement}
                    </div>
                  )}
                </div>
              )}

              <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-2xs text-slate-400">
                <div className="flex items-center gap-1 text-amber-500">
                  {fb.rating && (
                    <>
                      <Star className="w-3.5 h-3.5 fill-current" />
                      <span className="font-bold text-slate-700">{fb.rating} / 5</span>
                    </>
                  )}
                </div>
                <span>{new Date(fb.createdAt).toLocaleDateString()}</span>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
