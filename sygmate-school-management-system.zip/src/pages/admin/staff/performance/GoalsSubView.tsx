import React, { useState } from 'react';
import {
  Target,
  Plus,
  TrendingUp,
  Calendar,
  CheckCircle2,
  AlertCircle,
  Filter,
  User
} from 'lucide-react';
import { Button } from '../../../../components/ui/Button.js';
import {
  PerformanceGoal,
  StaffProfile,
  GoalStatus
} from '../../../../types/index.js';

interface GoalsSubViewProps {
  goals: PerformanceGoal[];
  staffList: StaffProfile[];
  isLoading: boolean;
  onRefresh: () => void;
  onOpenCreateModal: () => void;
  onOpenProgressModal: (goal: PerformanceGoal) => void;
}

export const GoalsSubView: React.FC<GoalsSubViewProps> = ({
  goals,
  staffList,
  isLoading,
  onRefresh,
  onOpenCreateModal,
  onOpenProgressModal
}) => {
  const [selectedStaffId, setSelectedStaffId] = useState<string>('');
  const [selectedStatus, setSelectedStatus] = useState<string>('');

  const filteredGoals = goals.filter((g) => {
    if (selectedStaffId && g.staffId !== selectedStaffId) return false;
    if (selectedStatus && g.status !== selectedStatus) return false;
    return true;
  });

  const getStatusBadge = (status: GoalStatus) => {
    switch (status) {
      case 'ACTIVE':
        return <span className="px-2 py-0.5 rounded text-2xs font-semibold bg-sky-100 text-sky-800">Active</span>;
      case 'IN_PROGRESS':
        return <span className="px-2 py-0.5 rounded text-2xs font-semibold bg-indigo-100 text-indigo-800">In Progress</span>;
      case 'ACHIEVED':
        return <span className="px-2 py-0.5 rounded text-2xs font-semibold bg-emerald-100 text-emerald-800">Achieved</span>;
      case 'NOT_ACHIEVED':
        return <span className="px-2 py-0.5 rounded text-2xs font-semibold bg-rose-100 text-rose-800">Not Achieved</span>;
      case 'DEFERRED':
        return <span className="px-2 py-0.5 rounded text-2xs font-semibold bg-slate-200 text-slate-700">Deferred</span>;
      default:
        return null;
    }
  };

  return (
    <div className="space-y-4">
      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 bg-white p-4 rounded-xl border border-slate-200">
        <div>
          <h3 className="text-sm font-bold text-slate-900">Individual Staff Performance Goals & Deliverables</h3>
          <p className="text-xs text-slate-500">Track target outcomes, milestone execution, and progress verification</p>
        </div>

        <div className="flex items-center gap-2">
          <select
            value={selectedStaffId}
            onChange={(e) => setSelectedStaffId(e.target.value)}
            className="text-xs p-2 border border-slate-200 rounded-lg bg-white"
          >
            <option value="">All Staff Members</option>
            {staffList.map((s) => (
              <option key={s.id} value={s.id}>
                {s.displayName}
              </option>
            ))}
          </select>

          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="text-xs p-2 border border-slate-200 rounded-lg bg-white"
          >
            <option value="">All Statuses</option>
            <option value="ACTIVE">Active</option>
            <option value="IN_PROGRESS">In Progress</option>
            <option value="ACHIEVED">Achieved</option>
            <option value="NOT_ACHIEVED">Not Achieved</option>
          </select>

          <Button
            type="button"
            variant="primary"
            size="sm"
            onClick={onOpenCreateModal}
            icon={<Plus className="w-4 h-4" />}
          >
            Establish Goal
          </Button>
        </div>
      </div>

      {/* Goals Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredGoals.length === 0 ? (
          <div className="col-span-2 p-12 text-center bg-white rounded-xl border border-slate-200 text-slate-400">
            <Target className="w-8 h-8 mx-auto mb-2 text-slate-300" />
            <p className="font-medium">No performance goals found</p>
          </div>
        ) : (
          filteredGoals.map((goal) => (
            <div
              key={goal.id}
              className="bg-white rounded-xl border border-slate-200 p-5 space-y-3 hover:shadow-2xs transition-all"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-900 text-sm">{goal.title}</span>
                    <span className="text-2xs font-semibold px-2 py-0.5 rounded bg-slate-100 text-slate-700">
                      {goal.category}
                    </span>
                  </div>
                  <div className="text-xs text-slate-500">
                    {goal.staffName} ({goal.staffEmployeeCode})
                  </div>
                </div>
                {getStatusBadge(goal.status)}
              </div>

              <p className="text-xs text-slate-600 line-clamp-2">{goal.description}</p>

              <div className="p-2.5 bg-slate-50 rounded-lg space-y-1 text-2xs text-slate-600">
                <div>
                  <span className="font-bold text-slate-700">Target:</span> {goal.target}
                </div>
                <div>
                  <span className="font-bold text-slate-700">Metric:</span> {goal.measurementMethod}
                </div>
              </div>

              {/* Progress Slider Display */}
              <div className="space-y-1">
                <div className="flex items-center justify-between text-2xs font-bold text-slate-700">
                  <span>Goal Completion</span>
                  <span>{goal.progressPercentage}%</span>
                </div>
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-indigo-600 h-full rounded-full transition-all"
                    style={{ width: `${goal.progressPercentage}%` }}
                  />
                </div>
              </div>

              {/* Milestones count */}
              {((goal?.milestones?.length || 0) > 0) && (
                <div className="text-2xs text-slate-500">
                  {(goal?.milestones || []).filter((m) => m.isCompleted).length} of {goal?.milestones?.length || 0} milestones completed
                </div>
              )}

              <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-2xs text-slate-400">
                <span>Due: {goal.dueDate}</span>
                <Button
                  type="button"
                  variant="outline"
                  size="xs"
                  onClick={() => onOpenProgressModal(goal)}
                  icon={<TrendingUp className="w-3.5 h-3.5" />}
                >
                  Update Progress
                </Button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
