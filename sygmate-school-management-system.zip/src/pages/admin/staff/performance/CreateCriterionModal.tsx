import React, { useState } from 'react';
import { X, Target, Plus, AlertCircle } from 'lucide-react';
import { Button } from '../../../../components/ui/Button.js';
import { api } from '../../../../services/api.js';
import {
  PerformanceCriterionCategory,
  CreatePerformanceCriterionPayload
} from '../../../../types/index.js';

interface CreateCriterionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCriterionCreated: () => void;
}

export const CreateCriterionModal: React.FC<CreateCriterionModalProps> = ({
  isOpen,
  onClose,
  onCriterionCreated
}) => {
  const [name, setName] = useState<string>('');
  const [code, setCode] = useState<string>('');
  const [description, setDescription] = useState<string>('');
  const [category, setCategory] = useState<PerformanceCriterionCategory>('TEACHING_PEDAGOGY');
  const [weight, setWeight] = useState<number>(15);
  const [maxScore, setMaxScore] = useState<number>(5);
  const [applicableStaffType, setApplicableStaffType] = useState<string>('ALL');

  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !code.trim()) {
      setError('Name and criterion code are required.');
      return;
    }

    setIsSubmitting(true);
    setError(null);
    try {
      const payload: CreatePerformanceCriterionPayload = {
        name: name.trim(),
        code: code.trim().toUpperCase(),
        description: description.trim(),
        category,
        weight: Number(weight),
        maxScore: Number(maxScore),
        applicableStaffType: applicableStaffType as any
      };

      await api.staff.performance.createCriterion(payload);
      onCriterionCreated();
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to create criterion.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto animate-in fade-in">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden flex flex-col">
        <div className="p-6 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="p-2 bg-indigo-100 text-indigo-700 rounded-xl">
              <Target className="w-5 h-5" />
            </span>
            <div>
              <h2 className="text-base font-bold text-slate-900">Add Performance KPI / Criterion</h2>
              <p className="text-xs text-slate-500">Define weighted evaluation standard</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {error && (
          <div className="mx-6 mt-4 p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Criterion Name *
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Pedagogical Innovation & Lesson Planning"
                className="w-full text-xs p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Criterion Code *
              </label>
              <input
                type="text"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="e.g. CRIT-PEDAGOGY"
                className="w-full text-xs p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 uppercase font-mono focus:outline-hidden"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Category *
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as PerformanceCriterionCategory)}
                className="w-full text-xs p-2.5 border border-slate-200 rounded-xl bg-white focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
              >
                <option value="TEACHING_PEDAGOGY">Teaching & Pedagogy</option>
                <option value="WORK_QUALITY">Work Quality & Efficiency</option>
                <option value="PROFESSIONAL_CONDUCT">Professional Conduct & Ethics</option>
                <option value="PUNCTUALITY_ATTENDANCE">Punctuality & Attendance</option>
                <option value="STUDENT_OUTCOMES">Student Academic Outcomes</option>
                <option value="LEADERSHIP_INITIATIVE">Leadership & Initiative</option>
                <option value="TEAMWORK_COMMUNICATION">Teamwork & Communication</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Target Workforce
              </label>
              <select
                value={applicableStaffType}
                onChange={(e) => setApplicableStaffType(e.target.value)}
                className="w-full text-xs p-2.5 border border-slate-200 rounded-xl bg-white focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
              >
                <option value="ALL">All Staff</option>
                <option value="TEACHING">Teaching Staff Only</option>
                <option value="NON_TEACHING">Non-Teaching Staff</option>
                <option value="ADMINISTRATIVE">Administrative</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Weight in Overall Score (%) *
              </label>
              <input
                type="number"
                min={1}
                max={100}
                value={weight}
                onChange={(e) => setWeight(Number(e.target.value))}
                className="w-full text-xs p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Maximum Score Scale
              </label>
              <input
                type="number"
                min={1}
                max={10}
                value={maxScore}
                onChange={(e) => setMaxScore(Number(e.target.value))}
                className="w-full text-xs p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Description & Evaluation Expectations
            </label>
            <textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Clarify what exemplary performance entails for this standard..."
              className="w-full text-xs p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
            />
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-slate-200">
            <Button type="button" variant="outline" size="sm" onClick={onClose}>
              Cancel
            </Button>
            <Button
              type="submit"
              variant="primary"
              size="sm"
              loading={isSubmitting}
              icon={<Plus className="w-4 h-4" />}
            >
              Add Criterion
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};
