import React, { useState, useEffect } from 'react';
import {
  X,
  Award,
  Calendar,
  CheckCircle2,
  Clock,
  AlertTriangle,
  User,
  Building,
  Briefcase,
  FileText,
  Star,
  ShieldCheck,
  Send,
  Edit3,
  TrendingUp,
  AlertCircle,
  Check,
  RotateCcw,
  BookOpen,
  CalendarCheck,
  FileCheck
} from 'lucide-react';
import { Button } from '../../../../components/ui/Button.js';
import { api } from '../../../../services/api.js';
import {
  StaffPerformanceReview,
  PerformanceCriterion,
  PerformanceGoal,
  RatingBand,
  User as UserType
} from '../../../../types/index.js';

interface PerformanceReviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  review: StaffPerformanceReview | null;
  criteria: PerformanceCriterion[];
  goals: PerformanceGoal[];
  currentUser?: UserType;
  onReviewUpdated: () => void;
}

export const PerformanceReviewModal: React.FC<PerformanceReviewModalProps> = ({
  isOpen,
  onClose,
  review,
  criteria,
  goals,
  currentUser,
  onReviewUpdated
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'self' | 'supervisor' | 'hr' | 'signoff' | 'history'>('overview');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [actionError, setActionError] = useState<string | null>(null);
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);

  // Self assessment state
  const [selfRating, setSelfRating] = useState<number>(review?.selfAssessment?.selfRating || 4);
  const [selfAchievements, setSelfAchievements] = useState<string>(review?.selfAssessment?.achievementSummary || '');
  const [selfGoalSummary, setSelfGoalSummary] = useState<string>(review?.selfAssessment?.goalProgressSummary || '');
  const [selfStrengths, setSelfStrengths] = useState<string>(review?.selfAssessment?.strengths || '');
  const [selfChallenges, setSelfChallenges] = useState<string>(review?.selfAssessment?.challenges || '');
  const [selfTraining, setSelfTraining] = useState<string>(review?.selfAssessment?.trainingNeeds || '');
  const [selfComments, setSelfComments] = useState<string>(review?.selfAssessment?.comments || '');

  // Supervisor review state
  const [criteriaScores, setCriteriaScores] = useState<Record<string, { score: number; comments: string }>>({});
  const [supRating, setSupRating] = useState<number>(review?.supervisorReview?.supervisorRating || 4);
  const [supStrengths, setSupStrengths] = useState<string>(review?.supervisorReview?.strengths || '');
  const [supAreas, setSupAreas] = useState<string>(review?.supervisorReview?.areasForImprovement || '');
  const [supRecommendations, setSupRecommendations] = useState<string>(review?.supervisorReview?.developmentRecommendations || '');
  const [supComments, setSupComments] = useState<string>(review?.supervisorReview?.generalComments || '');
  const [supTrainingTags, setSupTrainingTags] = useState<string>(review?.supervisorReview?.recommendedTraining?.join(', ') || '');

  // HR review state
  const [hrComments, setHrComments] = useState<string>(review?.hrReview?.hrComments || '');
  const [hrRatingBand, setHrRatingBand] = useState<RatingBand>(review?.hrReview?.finalRatingBand || 'MEETS_EXPECTATIONS');
  const [hrPipRecommended, setHrPipRecommended] = useState<boolean>(review?.hrReview?.pipRecommended || false);

  // Override state
  const [isOverrideOpen, setIsOverrideOpen] = useState<boolean>(false);
  const [overrideScore, setOverrideScore] = useState<number>(review?.hrReview?.finalCalculatedScore || 80);
  const [overrideBand, setOverrideBand] = useState<RatingBand>('MEETS_EXPECTATIONS');
  const [overrideReason, setOverrideReason] = useState<string>('');

  // Signoff state
  const [ackComments, setAckComments] = useState<string>(review?.acknowledgement?.comments || '');

  useEffect(() => {
    if (review) {
      // Initialize self-assessment fields
      setSelfRating(review.selfAssessment?.selfRating || 4);
      setSelfAchievements(review.selfAssessment?.achievementSummary || '');
      setSelfGoalSummary(review.selfAssessment?.goalProgressSummary || '');
      setSelfStrengths(review.selfAssessment?.strengths || '');
      setSelfChallenges(review.selfAssessment?.challenges || '');
      setSelfTraining(review.selfAssessment?.trainingNeeds || '');
      setSelfComments(review.selfAssessment?.comments || '');

      // Initialize supervisor fields
      setSupRating(review.supervisorReview?.supervisorRating || 4);
      setSupStrengths(review.supervisorReview?.strengths || '');
      setSupAreas(review.supervisorReview?.areasForImprovement || '');
      setSupRecommendations(review.supervisorReview?.developmentRecommendations || '');
      setSupComments(review.supervisorReview?.generalComments || '');
      setSupTrainingTags(review.supervisorReview?.recommendedTraining?.join(', ') || '');

      const initialScores: Record<string, { score: number; comments: string }> = {};
      if (review.supervisorReview?.criteriaScores) {
        review.supervisorReview.criteriaScores.forEach((cs) => {
          initialScores[cs.criterionId] = { score: cs.score, comments: cs.comments || '' };
        });
      } else {
        criteria.forEach((c) => {
          initialScores[c.id] = { score: 4, comments: '' };
        });
      }
      setCriteriaScores(initialScores);

      // Initialize HR
      setHrComments(review.hrReview?.hrComments || '');
      setHrRatingBand(review.hrReview?.finalRatingBand || 'MEETS_EXPECTATIONS');
      setHrPipRecommended(review.hrReview?.pipRecommended || false);
      setOverrideScore(review.hrReview?.finalCalculatedScore || 80);

      // Default active tab to current stage
      if (review.status === 'SELF_ASSESSMENT') setActiveTab('self');
      else if (review.status === 'SUPERVISOR_REVIEW') setActiveTab('supervisor');
      else if (review.status === 'HR_REVIEW') setActiveTab('hr');
      else if (review.status === 'FINALIZED') setActiveTab('signoff');
      else setActiveTab('overview');
    }
  }, [review, criteria]);

  if (!isOpen || !review) return null;

  // Real-time live score calculation for supervisor review
  const calculateLiveSupervisorScore = () => {
    let totalWeighted = 0;
    let totalMax = 0;

    criteria.forEach((c) => {
      const cs = criteriaScores[c.id];
      const score = cs?.score ?? 4;
      totalWeighted += (score / c.maxScore) * c.weight;
      totalMax += c.weight;
    });

    if (totalMax === 0) return 80;
    return Math.round((totalWeighted / totalMax) * 1000) / 10;
  };

  const liveSupervisorScore = calculateLiveSupervisorScore();

  const getRatingBadge = (band: RatingBand) => {
    switch (band) {
      case 'EXCEPTIONAL':
        return <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-purple-100 text-purple-800 border border-purple-200">★ Exceptional (90-100%)</span>;
      case 'EXCEEDS_EXPECTATIONS':
        return <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">Exceeds Expectations (75-89%)</span>;
      case 'MEETS_EXPECTATIONS':
        return <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-blue-100 text-blue-800 border border-blue-200">Meets Expectations (60-74%)</span>;
      case 'NEEDS_IMPROVEMENT':
        return <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-800 border border-amber-200">Needs Improvement (45-59%)</span>;
      case 'UNSATISFACTORY':
        return <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-red-100 text-red-800 border border-red-200">Unsatisfactory (&lt;45%)</span>;
      default:
        return null;
    }
  };

  const getStageBadge = (status: StaffPerformanceReview['status']) => {
    switch (status) {
      case 'DRAFT':
        return <span className="px-2 py-0.5 rounded text-xs font-semibold bg-slate-100 text-slate-700">Draft</span>;
      case 'SELF_ASSESSMENT':
        return <span className="px-2 py-0.5 rounded text-xs font-semibold bg-sky-100 text-sky-800 animate-pulse">Self-Assessment</span>;
      case 'SUPERVISOR_REVIEW':
        return <span className="px-2 py-0.5 rounded text-xs font-semibold bg-indigo-100 text-indigo-800">Supervisor Review</span>;
      case 'HR_REVIEW':
        return <span className="px-2 py-0.5 rounded text-xs font-semibold bg-amber-100 text-amber-800">HR Executive Review</span>;
      case 'FINALIZED':
        return <span className="px-2 py-0.5 rounded text-xs font-semibold bg-emerald-100 text-emerald-800">Pending Employee Sign-off</span>;
      case 'ACKNOWLEDGED':
        return <span className="px-2 py-0.5 rounded text-xs font-semibold bg-green-100 text-green-800">Signed Off & Acknowledged</span>;
      case 'CLOSED':
        return <span className="px-2 py-0.5 rounded text-xs font-semibold bg-slate-200 text-slate-800">Archived</span>;
      case 'RETURNED_FOR_CORRECTION':
        return <span className="px-2 py-0.5 rounded text-xs font-semibold bg-rose-100 text-rose-800">Returned for Correction</span>;
      default:
        return null;
    }
  };

  // Handlers
  const handleSubmitSelfAssessment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selfAchievements.trim()) {
      setActionError('Please outline your key achievements during this review period.');
      return;
    }
    setIsSubmitting(true);
    setActionError(null);
    try {
      await api.staff.performance.submitSelfAssessment(review.id, {
        achievementSummary: selfAchievements,
        goalProgressSummary: selfGoalSummary,
        strengths: selfStrengths,
        challenges: selfChallenges,
        trainingNeeds: selfTraining,
        comments: selfComments,
        selfRating
      });
      setActionSuccess('Self-assessment submitted successfully! Dossier forwarded to supervisor.');
      onReviewUpdated();
    } catch (err: any) {
      setActionError(err.message || 'Failed to submit self-assessment.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSubmitSupervisorReview = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setActionError(null);
    try {
      const formattedScores = Object.entries(criteriaScores).map(([critId, val]: [string, { score: number; comments: string }]) => ({
        criterionId: critId,
        score: val.score,
        comments: val.comments
      }));

      await api.staff.performance.submitSupervisorReview(review.id, {
        criteriaScores: formattedScores,
        supervisorRating: supRating,
        strengths: supStrengths,
        areasForImprovement: supAreas,
        developmentRecommendations: supRecommendations,
        recommendedTraining: supTrainingTags ? supTrainingTags.split(',').map((s) => s.trim()).filter(Boolean) : [],
        generalComments: supComments
      });

      setActionSuccess('Supervisor review recorded with authoritative weighted score!');
      onReviewUpdated();
    } catch (err: any) {
      setActionError(err.message || 'Failed to submit supervisor review.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSubmitHRReview = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setActionError(null);
    try {
      await api.staff.performance.submitHRReview(review.id, {
        hrComments,
        finalRatingBand: hrRatingBand,
        pipRecommended: hrPipRecommended
      });
      setActionSuccess('Review dossier finalized! Staff member notified for formal sign-off.');
      onReviewUpdated();
    } catch (err: any) {
      setActionError(err.message || 'Failed to finalize HR review.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleOverride = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!overrideReason.trim()) {
      setActionError('Mandatory executive justification reason is required.');
      return;
    }
    setIsSubmitting(true);
    setActionError(null);
    try {
      await api.staff.performance.overrideRating(review.id, {
        overrideScore: Number(overrideScore),
        overrideRatingBand: overrideBand,
        reason: overrideReason
      });
      setActionSuccess('Score overridden and audited successfully.');
      setIsOverrideOpen(false);
      onReviewUpdated();
    } catch (err: any) {
      setActionError(err.message || 'Failed to override score.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleAcknowledge = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setActionError(null);
    try {
      await api.staff.performance.acknowledgeReview(review.id, {
        comments: ackComments
      });
      setActionSuccess('Appraisal signed off and completed.');
      onReviewUpdated();
    } catch (err: any) {
      setActionError(err.message || 'Failed to sign off appraisal.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const staffGoals = goals.filter((g) => g.staffId === review.staffId);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto animate-in fade-in duration-150"
      id="performance-review-modal"
    >
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-5xl max-h-[90vh] flex flex-col overflow-hidden">
        {/* Modal Header */}
        <div className="p-6 border-b border-slate-200 bg-slate-50/80 flex items-start justify-between">
          <div className="space-y-1">
            <div className="flex items-center gap-3">
              <span className="p-2 bg-indigo-100 text-indigo-700 rounded-xl">
                <Award className="w-5 h-5" />
              </span>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-lg font-bold text-slate-900 tracking-tight">
                    {review.staffName}
                  </h2>
                  <span className="text-xs font-mono bg-slate-200 px-2 py-0.5 rounded text-slate-700">
                    {review.staffEmployeeCode}
                  </span>
                  {getStageBadge(review.status)}
                </div>
                <p className="text-xs text-slate-500 mt-0.5">
                  {review.designationTitle} &bull; {review.departmentName} &bull; {review.reviewCycleName} ({review.reviewPeriod})
                </p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {review.hrReview?.finalRatingBand && getRatingBadge(review.hrReview.finalRatingBand)}
            <button
              type="button"
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200 transition-colors"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Action Alerts */}
        {actionSuccess && (
          <div className="mx-6 mt-4 p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{actionSuccess}</span>
            </div>
            <button
              type="button"
              onClick={() => setActionSuccess(null)}
              className="text-emerald-700 hover:text-emerald-900 font-bold"
            >
              &times;
            </button>
          </div>
        )}

        {actionError && (
          <div className="mx-6 mt-4 p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{actionError}</span>
            </div>
            <button
              type="button"
              onClick={() => setActionError(null)}
              className="text-rose-700 hover:text-rose-900 font-bold"
            >
              &times;
            </button>
          </div>
        )}

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-200 px-6 gap-2 bg-white text-xs font-semibold overflow-x-auto">
          <button
            type="button"
            onClick={() => setActiveTab('overview')}
            className={`py-3 px-3 border-b-2 transition-colors whitespace-nowrap ${
              activeTab === 'overview'
                ? 'border-indigo-600 text-indigo-700'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            Overview & Baseline Data
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('self')}
            className={`py-3 px-3 border-b-2 transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'self'
                ? 'border-indigo-600 text-indigo-700'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <span>Employee Self-Assessment</span>
            {review.selfAssessment && <Check className="w-3.5 h-3.5 text-emerald-600" />}
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('supervisor')}
            className={`py-3 px-3 border-b-2 transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'supervisor'
                ? 'border-indigo-600 text-indigo-700'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <span>Supervisor KPI Rubric</span>
            {review.supervisorReview && <Check className="w-3.5 h-3.5 text-emerald-600" />}
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('hr')}
            className={`py-3 px-3 border-b-2 transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'hr'
                ? 'border-indigo-600 text-indigo-700'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <span>HR Review & Rating</span>
            {review.hrReview && <Check className="w-3.5 h-3.5 text-emerald-600" />}
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('signoff')}
            className={`py-3 px-3 border-b-2 transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'signoff'
                ? 'border-indigo-600 text-indigo-700'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <span>Sign-off & Signatures</span>
            {review.acknowledgement?.isAcknowledged && <Check className="w-3.5 h-3.5 text-emerald-600" />}
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('history')}
            className={`py-3 px-3 border-b-2 transition-colors whitespace-nowrap ${
              activeTab === 'history'
                ? 'border-indigo-600 text-indigo-700'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            Audit History ({review.history?.length || 0})
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {/* TAB 1: OVERVIEW & BASELINE DATA */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Supporting Institutional Data Cards */}
              <div>
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-3">
                  Institutional Attendance, Workload & Dossier Baseline
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-1">
                    <div className="flex items-center gap-2 text-xs font-medium text-slate-500">
                      <CalendarCheck className="w-4 h-4 text-emerald-600" />
                      <span>Attendance Rate</span>
                    </div>
                    <div className="text-xl font-bold text-slate-900">
                      {review.supportingData?.attendancePercentage ?? 95}%
                    </div>
                    <div className="text-2xs text-slate-500">
                      Late arrivals: {review.supportingData?.lateArrivalsCount ?? 0}
                    </div>
                  </div>

                  <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-1">
                    <div className="flex items-center gap-2 text-xs font-medium text-slate-500">
                      <Calendar className="w-4 h-4 text-blue-600" />
                      <span>Approved Leaves</span>
                    </div>
                    <div className="text-xl font-bold text-slate-900">
                      {review.supportingData?.approvedLeavesCount ?? 0} Days
                    </div>
                    <div className="text-2xs text-slate-500">
                      Approved per leave policy
                    </div>
                  </div>

                  <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-1">
                    <div className="flex items-center gap-2 text-xs font-medium text-slate-500">
                      <BookOpen className="w-4 h-4 text-indigo-600" />
                      <span>Workload / Classes</span>
                    </div>
                    <div className="text-xs font-bold text-slate-900 truncate">
                      {review.supportingData?.workloadSummary || 'Standard Load'}
                    </div>
                    <div className="text-2xs text-slate-500">
                      Marks submission: {review.supportingData?.marksSubmissionComplianceRate ?? 100}%
                    </div>
                  </div>

                  <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-1">
                    <div className="flex items-center gap-2 text-xs font-medium text-slate-500">
                      <FileCheck className="w-4 h-4 text-purple-600" />
                      <span>Credential Dossier</span>
                    </div>
                    <div className="text-xs font-bold text-slate-900 truncate">
                      {review.supportingData?.documentsComplianceStatus || 'Verified'}
                    </div>
                    <div className="text-2xs text-slate-500">
                      Compliance status
                    </div>
                  </div>
                </div>
              </div>

              {/* Scorecard Summary if already evaluated */}
              {(review.supervisorReview || review.hrReview) && (
                <div className="p-5 bg-indigo-50/60 border border-indigo-100 rounded-2xl">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                      <div className="text-xs font-bold uppercase tracking-wider text-indigo-900">
                        Current Appraisal Score
                      </div>
                      <div className="flex items-baseline gap-3 mt-1">
                        <span className="text-3xl font-extrabold text-indigo-900">
                          {review.hrReview?.finalCalculatedScore ?? review.supervisorReview?.calculatedScore}%
                        </span>
                        {review.hrReview?.finalRatingBand && getRatingBadge(review.hrReview.finalRatingBand)}
                      </div>
                      <p className="text-xs text-indigo-700 mt-1">
                        Evaluated by {review.reviewerName} (Supervisor) &bull; HR Confirmation: {review.hrReviewerName || 'Pending'}
                      </p>
                    </div>

                    {currentUser?.role === 'SUPER_ADMIN' && (
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => setIsOverrideOpen(true)}
                        icon={<ShieldCheck className="w-4 h-4" />}
                      >
                        Executive Rating Override
                      </Button>
                    )}
                  </div>
                </div>
              )}

              {/* Active Goals for this staff member */}
              <div>
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-3">
                  Active Performance Goals & Targets ({staffGoals.length})
                </h3>
                {staffGoals.length === 0 ? (
                  <p className="text-xs text-slate-500 italic p-4 bg-slate-50 rounded-xl border border-slate-200">
                    No active goals linked to this cycle.
                  </p>
                ) : (
                  <div className="space-y-3">
                    {staffGoals.map((g) => (
                      <div key={g.id} className="p-4 bg-white border border-slate-200 rounded-xl space-y-2">
                        <div className="flex items-center justify-between">
                          <div className="text-xs font-bold text-slate-900">{g.title}</div>
                          <span className="text-xs font-semibold px-2 py-0.5 rounded bg-slate-100 text-slate-700">
                            {g.progressPercentage}%
                          </span>
                        </div>
                        <p className="text-xs text-slate-600">{g.description}</p>
                        <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                          <div
                            className="bg-indigo-600 h-full rounded-full transition-all duration-300"
                            style={{ width: `${g.progressPercentage}%` }}
                          />
                        </div>
                        <div className="flex items-center justify-between text-2xs text-slate-400">
                          <span>Target: {g.target}</span>
                          <span>Due: {g.dueDate}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 2: EMPLOYEE SELF-ASSESSMENT */}
          {activeTab === 'self' && (
            <form onSubmit={handleSubmitSelfAssessment} className="space-y-4">
              <div className="p-4 bg-sky-50 border border-sky-100 rounded-xl text-xs text-sky-900">
                Staff member completes self-reflection before supervisor evaluation. Rating scale: 1 (Unsatisfactory) to 5 (Exceptional).
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Self-Assessed Overall Rating (1 - 5 Stars) *
                  </label>
                  <div className="flex items-center gap-2">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setSelfRating(star)}
                        className={`p-1.5 rounded-lg border transition-all ${
                          selfRating >= star
                            ? 'bg-amber-50 border-amber-300 text-amber-500'
                            : 'bg-slate-50 border-slate-200 text-slate-300 hover:text-amber-400'
                        }`}
                      >
                        <Star className="w-5 h-5 fill-current" />
                      </button>
                    ))}
                    <span className="text-xs font-bold text-slate-700 ml-2">
                      {selfRating} / 5 Stars
                    </span>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Key Achievements & Contributions *
                  </label>
                  <textarea
                    rows={3}
                    value={selfAchievements}
                    onChange={(e) => setSelfAchievements(e.target.value)}
                    placeholder="Summarize key accomplishments, teaching milestones, operational outcomes..."
                    className="w-full text-xs p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Key Strengths Demonstrated
                  </label>
                  <textarea
                    rows={2}
                    value={selfStrengths}
                    onChange={(e) => setSelfStrengths(e.target.value)}
                    placeholder="Classroom management, curriculum innovation, cross-department collaboration..."
                    className="w-full text-xs p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Challenges Encountered & Roadblocks
                  </label>
                  <textarea
                    rows={2}
                    value={selfChallenges}
                    onChange={(e) => setSelfChallenges(e.target.value)}
                    placeholder="Any resource constraints, scheduling friction, or professional obstacles..."
                    className="w-full text-xs p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Professional Development & Training Needs
                  </label>
                  <textarea
                    rows={2}
                    value={selfTraining}
                    onChange={(e) => setSelfTraining(e.target.value)}
                    placeholder="Workshops, certifications, pedagogical seminars, or software skills requested..."
                    className="w-full text-xs p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Additional Comments & Self-Reflection
                  </label>
                  <textarea
                    rows={2}
                    value={selfComments}
                    onChange={(e) => setSelfComments(e.target.value)}
                    placeholder="Any feedback for school administration or peer groups..."
                    className="w-full text-xs p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                  />
                </div>
              </div>

              {review.selfAssessment?.submittedAt && (
                <div className="text-2xs text-slate-500 italic">
                  Submitted at: {new Date(review.selfAssessment.submittedAt).toLocaleString()}
                </div>
              )}

              {(review.status === 'SELF_ASSESSMENT' || review.status === 'DRAFT') && (
                <div className="flex justify-end pt-2">
                  <Button
                    type="submit"
                    variant="primary"
                    size="sm"
                    loading={isSubmitting}
                    icon={<Send className="w-3.5 h-3.5" />}
                  >
                    Submit Self-Assessment & Advance to Supervisor
                  </Button>
                </div>
              )}
            </form>
          )}

          {/* TAB 3: SUPERVISOR KPI RUBRIC */}
          {activeTab === 'supervisor' && (
            <form onSubmit={handleSubmitSupervisorReview} className="space-y-6">
              {/* Live weighted score ticker */}
              <div className="p-4 bg-slate-900 text-white rounded-xl flex items-center justify-between">
                <div>
                  <div className="text-xs text-slate-400 font-semibold uppercase tracking-wider">
                    Authoritative Weighted Score (Live Preview)
                  </div>
                  <div className="text-2xl font-bold text-indigo-400">
                    {liveSupervisorScore}%
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xs text-slate-400">Criteria Count</div>
                  <div className="text-sm font-bold text-white">{criteria.length} Rubric Items</div>
                </div>
              </div>

              {/* Criteria Scoring Grid */}
              <div className="space-y-4">
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  Weighted Competency & Performance Criteria
                </h4>
                {criteria.map((crit) => {
                  const currentScore = criteriaScores[crit.id]?.score ?? 4;
                  return (
                    <div
                      key={crit.id}
                      className="p-4 bg-slate-50/70 border border-slate-200 rounded-xl space-y-3"
                    >
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-2">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-mono font-bold text-indigo-600 bg-indigo-50 px-1.5 py-0.5 rounded">
                              {crit.code}
                            </span>
                            <span className="text-xs font-bold text-slate-900">{crit.name}</span>
                            <span className="text-2xs font-semibold px-2 py-0.5 rounded-full bg-slate-200 text-slate-700">
                              Weight: {crit.weight}%
                            </span>
                          </div>
                          <p className="text-xs text-slate-500 mt-1">{crit.description}</p>
                        </div>

                        {/* 1-5 Score selector */}
                        <div className="flex items-center gap-1.5 shrink-0">
                          {[1, 2, 3, 4, 5].map((num) => (
                            <button
                              key={num}
                              type="button"
                              onClick={() => {
                                setCriteriaScores((prev) => ({
                                  ...prev,
                                  [crit.id]: {
                                    score: num,
                                    comments: prev[crit.id]?.comments || ''
                                  }
                                }));
                              }}
                              className={`w-8 h-8 rounded-lg text-xs font-bold border transition-all ${
                                currentScore === num
                                  ? 'bg-indigo-600 border-indigo-600 text-white shadow-xs'
                                  : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
                              }`}
                            >
                              {num}
                            </button>
                          ))}
                        </div>
                      </div>

                      <input
                        type="text"
                        placeholder="Evaluation notes or specific examples for this criterion..."
                        value={criteriaScores[crit.id]?.comments || ''}
                        onChange={(e) => {
                          const val = e.target.value;
                          setCriteriaScores((prev) => ({
                            ...prev,
                            [crit.id]: {
                              score: prev[crit.id]?.score || 4,
                              comments: val
                            }
                          }));
                        }}
                        className="w-full text-xs p-2 bg-white border border-slate-200 rounded-lg focus:ring-1 focus:ring-indigo-500 focus:outline-hidden"
                      />
                    </div>
                  );
                })}
              </div>

              {/* Qualitative feedback */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Key Strengths Observed *
                  </label>
                  <textarea
                    rows={2}
                    value={supStrengths}
                    onChange={(e) => setSupStrengths(e.target.value)}
                    placeholder="Specific competencies, teaching quality, student engagement..."
                    className="w-full text-xs p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Areas for Growth & Improvement *
                  </label>
                  <textarea
                    rows={2}
                    value={supAreas}
                    onChange={(e) => setSupAreas(e.target.value)}
                    placeholder="Punctuality, syllabus pacing, administrative compliance..."
                    className="w-full text-xs p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Development Recommendations
                  </label>
                  <textarea
                    rows={2}
                    value={supRecommendations}
                    onChange={(e) => setSupRecommendations(e.target.value)}
                    placeholder="Action items for next academic quarter..."
                    className="w-full text-xs p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Recommended Training / Certifications (comma separated)
                  </label>
                  <input
                    type="text"
                    value={supTrainingTags}
                    onChange={(e) => setSupTrainingTags(e.target.value)}
                    placeholder="Advanced Pedagogy, Differentiated Instruction, MS Office..."
                    className="w-full text-xs p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  General Supervisor Summary Comments
                </label>
                <textarea
                  rows={2}
                  value={supComments}
                  onChange={(e) => setSupComments(e.target.value)}
                  placeholder="Holistic assessment of contribution to Sygmate School..."
                  className="w-full text-xs p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                />
              </div>

              {review.status === 'SUPERVISOR_REVIEW' && (
                <div className="flex justify-end pt-2">
                  <Button
                    type="submit"
                    variant="primary"
                    size="sm"
                    loading={isSubmitting}
                    icon={<CheckCircle2 className="w-3.5 h-3.5" />}
                  >
                    Finalize Supervisor Evaluation & Forward to HR
                  </Button>
                </div>
              )}
            </form>
          )}

          {/* TAB 4: HR REVIEW & RATING */}
          {activeTab === 'hr' && (
            <form onSubmit={handleSubmitHRReview} className="space-y-6">
              <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl space-y-2">
                <div className="flex items-center gap-2 text-xs font-bold text-amber-900">
                  <ShieldCheck className="w-4 h-4 text-amber-700" />
                  <span>HR Executive Approval & Official Band Confirmation</span>
                </div>
                <p className="text-xs text-amber-800">
                  Reviews must be validated by HR prior to release to employee. Confirm final rating band, check compensation alignment, or flag Performance Improvement Plan (PIP).
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Confirmed Final Rating Band *
                  </label>
                  <select
                    value={hrRatingBand}
                    onChange={(e) => setHrRatingBand(e.target.value as RatingBand)}
                    className="w-full text-xs p-2.5 border border-slate-200 rounded-xl bg-white focus:ring-2 focus:ring-indigo-500 focus:outline-hidden font-medium"
                    required
                  >
                    <option value="EXCEPTIONAL">EXCEPTIONAL (90-100%)</option>
                    <option value="EXCEEDS_EXPECTATIONS">EXCEEDS EXPECTATIONS (75-89%)</option>
                    <option value="MEETS_EXPECTATIONS">MEETS EXPECTATIONS (60-74%)</option>
                    <option value="NEEDS_IMPROVEMENT">NEEDS IMPROVEMENT (45-59%)</option>
                    <option value="UNSATISFACTORY">UNSATISFACTORY (&lt;45%)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    PIP Initiation Recommendation
                  </label>
                  <div className="flex items-center gap-2 pt-2">
                    <input
                      type="checkbox"
                      id="hr-pip-check"
                      checked={hrPipRecommended}
                      onChange={(e) => setHrPipRecommended(e.target.checked)}
                      className="w-4 h-4 text-rose-600 rounded border-slate-300 focus:ring-rose-500"
                    />
                    <label htmlFor="hr-pip-check" className="text-xs font-medium text-slate-700">
                      Recommend formal Performance Improvement Plan (PIP)
                    </label>
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  HR Review & Governance Comments *
                </label>
                <textarea
                  rows={3}
                  value={hrComments}
                  onChange={(e) => setHrComments(e.target.value)}
                  placeholder="HR director comments, promotion/increment recommendations, policy compliance notes..."
                  className="w-full text-xs p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                  required
                />
              </div>

              {review.status === 'HR_REVIEW' && (
                <div className="flex justify-end pt-2">
                  <Button
                    type="submit"
                    variant="primary"
                    size="sm"
                    loading={isSubmitting}
                    icon={<Award className="w-3.5 h-3.5" />}
                  >
                    Confirm Official Rating & Release to Employee
                  </Button>
                </div>
              )}
            </form>
          )}

          {/* TAB 5: SIGN-OFF & SIGNATURES */}
          {activeTab === 'signoff' && (
            <div className="space-y-6">
              <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <div className="text-xs font-bold text-emerald-900">
                    Formal Employee Acknowledgement & Dossier Sign-Off
                  </div>
                  <p className="text-xs text-emerald-800">
                    Acknowledgement confirms that you have reviewed your scores, strengths, growth areas, and comments with your supervisor.
                  </p>
                </div>
              </div>

              {review.acknowledgement?.isAcknowledged ? (
                <div className="p-6 bg-slate-50 border border-slate-200 rounded-2xl space-y-3">
                  <div className="flex items-center gap-2 text-xs font-bold text-emerald-700">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Appraisal Officially Signed Off</span>
                  </div>
                  <div className="text-xs text-slate-600">
                    <strong>Signed at:</strong> {new Date(review.acknowledgement.acknowledgedAt).toLocaleString()}
                  </div>
                  {review.acknowledgement.comments && (
                    <div className="text-xs text-slate-600">
                      <strong>Employee Remarks:</strong> {review.acknowledgement.comments}
                    </div>
                  )}
                </div>
              ) : (
                <form onSubmit={handleAcknowledge} className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Employee Closing Remarks / Response (Optional)
                    </label>
                    <textarea
                      rows={3}
                      value={ackComments}
                      onChange={(e) => setAckComments(e.target.value)}
                      placeholder="Add any reflection or acknowledgement comments..."
                      className="w-full text-xs p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                    />
                  </div>

                  <div className="flex justify-end pt-2">
                    <Button
                      type="submit"
                      variant="primary"
                      size="sm"
                      loading={isSubmitting}
                      icon={<Check className="w-3.5 h-3.5" />}
                    >
                      I Acknowledge and Sign-Off This Appraisal
                    </Button>
                  </div>
                </form>
              )}
            </div>
          )}

          {/* TAB 6: AUDIT HISTORY */}
          {activeTab === 'history' && (
            <div className="space-y-4">
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                Immutable Lifecycle & Audit Events
              </h4>
              <div className="space-y-3">
                {review.history?.map((h, idx) => (
                  <div
                    key={idx}
                    className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl flex items-start justify-between gap-3 text-xs"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900">{h.action}</span>
                        <span className="px-1.5 py-0.5 rounded bg-slate-200 text-2xs font-semibold text-slate-700">
                          {h.stage}
                        </span>
                      </div>
                      <p className="text-slate-600 text-2xs">{h.comments}</p>
                      <div className="text-2xs text-slate-400">
                        Actor: {h.actorName}
                      </div>
                    </div>
                    <div className="text-2xs text-slate-400 font-mono shrink-0">
                      {new Date(h.timestamp).toLocaleString()}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="text-2xs text-slate-500">
            Dossier ID: <span className="font-mono">{review.id}</span>
          </div>
          <Button type="button" variant="outline" size="sm" onClick={onClose}>
            Close Dossier
          </Button>
        </div>
      </div>

      {/* Override Sub-modal */}
      {isOverrideOpen && (
        <div className="fixed inset-0 z-60 flex items-center justify-center bg-slate-900/70 p-4">
          <div className="bg-white rounded-2xl p-6 max-w-md w-full shadow-2xl border border-slate-200 space-y-4 animate-in fade-in">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-amber-600 font-bold text-sm">
                <AlertTriangle className="w-5 h-5" />
                <span>Executive Rating Override</span>
              </div>
              <button
                type="button"
                onClick={() => setIsOverrideOpen(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-600">
              Overrides replace calculated scores and require a recorded governance justification.
            </p>

            <form onSubmit={handleOverride} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  New Adjusted Score (0 - 100%) *
                </label>
                <input
                  type="number"
                  min={0}
                  max={100}
                  step={0.5}
                  value={overrideScore}
                  onChange={(e) => setOverrideScore(Number(e.target.value))}
                  className="w-full text-xs p-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Adjusted Rating Band *
                </label>
                <select
                  value={overrideBand}
                  onChange={(e) => setOverrideBand(e.target.value as RatingBand)}
                  className="w-full text-xs p-2 border border-slate-200 rounded-lg bg-white"
                  required
                >
                  <option value="EXCEPTIONAL">EXCEPTIONAL</option>
                  <option value="EXCEEDS_EXPECTATIONS">EXCEEDS EXPECTATIONS</option>
                  <option value="MEETS_EXPECTATIONS">MEETS EXPECTATIONS</option>
                  <option value="NEEDS_IMPROVEMENT">NEEDS IMPROVEMENT</option>
                  <option value="UNSATISFACTORY">UNSATISFACTORY</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Mandatory Audit Justification *
                </label>
                <textarea
                  rows={3}
                  value={overrideReason}
                  onChange={(e) => setOverrideReason(e.target.value)}
                  placeholder="Explain why score was overridden..."
                  className="w-full text-xs p-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500"
                  required
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setIsOverrideOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  variant="primary"
                  size="sm"
                  loading={isSubmitting}
                >
                  Apply Override
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
