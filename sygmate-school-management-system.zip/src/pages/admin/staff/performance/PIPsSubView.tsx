import React, { useState } from 'react';
import {
  AlertTriangle,
  Plus,
  CheckCircle2,
  Clock,
  User,
  ShieldAlert,
  ExternalLink,
  ChevronRight
} from 'lucide-react';
import { Button } from '../../../../components/ui/Button.js';
import {
  PerformanceImprovementPlan,
  PIPStatus
} from '../../../../types/index.js';

interface PIPsSubViewProps {
  pips: PerformanceImprovementPlan[];
  isLoading: boolean;
  onRefresh: () => void;
  onOpenCreateModal: () => void;
  onSelectPIP: (pip: PerformanceImprovementPlan) => void;
}

export const PIPsSubView: React.FC<PIPsSubViewProps> = ({
  pips,
  isLoading,
  onRefresh,
  onOpenCreateModal,
  onSelectPIP
}) => {
  const [statusFilter, setStatusFilter] = useState<string>('ALL');

  const filteredPips = pips.filter((p) => {
    if (statusFilter !== 'ALL' && p.status !== statusFilter) return false;
    return true;
  });

  const getStatusBadge = (status: PIPStatus) => {
    switch (status) {
      case 'DRAFT':
        return <span className="px-2 py-0.5 rounded text-2xs font-semibold bg-slate-100 text-slate-700">Draft</span>;
      case 'ACTIVE':
        return <span className="px-2 py-0.5 rounded text-2xs font-semibold bg-amber-100 text-amber-800 animate-pulse">Active Supervision</span>;
      case 'UNDER_REVIEW':
        return <span className="px-2 py-0.5 rounded text-2xs font-semibold bg-indigo-100 text-indigo-800">Under Review</span>;
      case 'RESOLVED':
        return <span className="px-2 py-0.5 rounded text-2xs font-semibold bg-emerald-100 text-emerald-800">Resolved / Closed</span>;
      case 'FAILED':
        return <span className="px-2 py-0.5 rounded text-2xs font-semibold bg-rose-100 text-rose-800">Deficient / Action Required</span>;
      default:
        return null;
    }
  };

  return (
    <div className="space-y-4">
      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 bg-white p-4 rounded-xl border border-slate-200">
        <div>
          <h3 className="text-sm font-bold text-slate-900">Performance Improvement Plans (PIP)</h3>
          <p className="text-xs text-slate-500">Corrective action tracking, coaching checkpoints, and resolution auditing</p>
        </div>

        <div className="flex items-center gap-2">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="text-xs p-2 border border-slate-200 rounded-lg bg-white"
          >
            <option value="ALL">All PIP Statuses</option>
            <option value="ACTIVE">Active Supervision</option>
            <option value="RESOLVED">Resolved / Closed</option>
            <option value="FAILED">Deficient</option>
          </select>

          <Button
            type="button"
            variant="primary"
            size="sm"
            onClick={onOpenCreateModal}
            icon={<Plus className="w-4 h-4" />}
          >
            Initiate PIP
          </Button>
        </div>
      </div>

      {/* PIP List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredPips.length === 0 ? (
          <div className="col-span-2 p-12 text-center bg-white rounded-xl border border-slate-200 text-slate-400">
            <ShieldAlert className="w-8 h-8 mx-auto mb-2 text-slate-300" />
            <p className="font-medium">No performance improvement plans found</p>
          </div>
        ) : (
          filteredPips.map((pip) => {
            const completedCount = (pip?.requiredActions || []).filter((a) => a.isCompleted).length;
            const totalCount = pip?.requiredActions?.length || 0;
            const progress = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

            return (
              <div
                key={pip.id}
                className="bg-white rounded-xl border border-slate-200 p-5 space-y-4 hover:shadow-2xs transition-all cursor-pointer"
                onClick={() => onSelectPIP(pip)}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-900 text-sm">{pip.staffName}</span>
                      <span className="font-mono text-2xs px-1.5 py-0.5 bg-slate-100 rounded text-slate-600">
                        {pip.staffEmployeeCode}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500">
                      Supervisor: <span className="font-semibold text-slate-700">{pip.assignedSupervisorName}</span>
                    </p>
                  </div>
                  {getStatusBadge(pip.status)}
                </div>

                <p className="text-xs text-slate-600 line-clamp-2">
                  <strong>Reason:</strong> {pip.reason}
                </p>

                {/* Progress */}
                <div className="space-y-1">
                  <div className="flex items-center justify-between text-2xs font-bold text-slate-700">
                    <span>Actions Completed: {completedCount} / {totalCount}</span>
                    <span>{progress}%</span>
                  </div>
                  <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-amber-500 h-full rounded-full transition-all"
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-2xs text-slate-500">
                  <span>Target Date: {pip.targetDate}</span>
                  <div className="flex items-center gap-1 font-bold text-indigo-600">
                    <span>Manage Dossier</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
