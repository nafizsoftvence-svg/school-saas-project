import React, { useState } from 'react';
import { X, AlertTriangle, Plus, AlertCircle } from 'lucide-react';
import { Button } from '../../../../components/ui/Button.js';
import { api } from '../../../../services/api.js';
import {
  StaffProfile,
  CreatePIPPayload
} from '../../../../types/index.js';

interface CreatePIPModalProps {
  isOpen: boolean;
  onClose: () => void;
  staffList: StaffProfile[];
  onPIPCreated: () => void;
}

export const CreatePIPModal: React.FC<CreatePIPModalProps> = ({
  isOpen,
  onClose,
  staffList,
  onPIPCreated
}) => {
  const [staffId, setStaffId] = useState<string>(staffList?.[0]?.id || '');
  const [assignedSupervisorId, setAssignedSupervisorId] = useState<string>(staffList?.[0]?.id || '');
  const [reason, setReason] = useState<string>('');
  const [improvementAreasStr, setImprovementAreasStr] = useState<string>('Classroom management, timely grading, student engagement');
  const [targetDate, setTargetDate] = useState<string>('2025-05-15');
  const [reviewDate, setReviewDate] = useState<string>('2025-04-15');

  const [actions, setActions] = useState<Array<{ description: string; deadline: string }>>([
    { description: 'Complete 3 peer classroom observations with senior mentors', deadline: '2025-03-31' },
    { description: 'Submit bi-weekly detailed lesson plans for HOD review', deadline: '2025-04-15' }
  ]);

  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleAddAction = () => {
    setActions([...actions, { description: '', deadline: targetDate }]);
  };

  const handleUpdateAction = (idx: number, field: 'description' | 'deadline', val: string) => {
    const next = [...actions];
    next[idx][field] = val;
    setActions(next);
  };

  const handleRemoveAction = (idx: number) => {
    setActions(actions.filter((_, i) => i !== idx));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!staffId || !reason.trim() || !assignedSupervisorId) {
      setError('Staff member, supervisor, and reason for PIP are required.');
      return;
    }

    setIsSubmitting(true);
    setError(null);
    try {
      const payload: CreatePIPPayload = {
        staffId,
        assignedSupervisorId,
        reason: reason.trim(),
        improvementAreas: improvementAreasStr.split(',').map((s) => s.trim()).filter(Boolean),
        requiredActions: actions.filter((a) => a.description.trim().length > 0),
        targetDate,
        reviewDate
      };

      await api.staff.performance.createPIP(payload);
      onPIPCreated();
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to initiate Performance Improvement Plan.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto animate-in fade-in">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-xl overflow-hidden flex flex-col">
        <div className="p-6 border-b border-slate-200 bg-amber-50/70 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="p-2 bg-amber-100 text-amber-800 rounded-xl">
              <AlertTriangle className="w-5 h-5" />
            </span>
            <div>
              <h2 className="text-base font-bold text-slate-900">Initiate Performance Improvement Plan (PIP)</h2>
              <p className="text-xs text-slate-500">Structured corrective milestones & supervisor coaching</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {error && (
          <div className="mx-6 mt-4 p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto max-h-[75vh]">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Employee Under PIP *
              </label>
              <select
                value={staffId}
                onChange={(e) => setStaffId(e.target.value)}
                className="w-full text-xs p-2.5 border border-slate-200 rounded-xl bg-white focus:ring-2 focus:ring-amber-500 focus:outline-hidden font-medium"
                required
              >
                {staffList.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.displayName} ({s.employeeCode}) &bull; {s.departmentName}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Assigned Mentor / Supervisor *
              </label>
              <select
                value={assignedSupervisorId}
                onChange={(e) => setAssignedSupervisorId(e.target.value)}
                className="w-full text-xs p-2.5 border border-slate-200 rounded-xl bg-white focus:ring-2 focus:ring-amber-500 focus:outline-hidden font-medium"
                required
              >
                {staffList.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.displayName} ({s.designation})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Reason for PIP & Core Deficiencies *
            </label>
            <textarea
              rows={3}
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="Detail specific performance deficiencies, missed benchmarks, or appraisal scores below threshold..."
              className="w-full text-xs p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Key Improvement Areas (comma separated)
            </label>
            <input
              type="text"
              value={improvementAreasStr}
              onChange={(e) => setImprovementAreasStr(e.target.value)}
              placeholder="Punctuality, syllabus pacing, student engagement..."
              className="w-full text-xs p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Interim Review Checkpoint Date *
              </label>
              <input
                type="date"
                value={reviewDate}
                onChange={(e) => setReviewDate(e.target.value)}
                className="w-full text-xs p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Target Plan Completion Date *
              </label>
              <input
                type="date"
                value={targetDate}
                onChange={(e) => setTargetDate(e.target.value)}
                className="w-full text-xs p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                required
              />
            </div>
          </div>

          {/* Action milestones */}
          <div className="space-y-2 pt-2 border-t border-slate-200">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-700">
                Required Corrective Actions ({actions.length})
              </label>
              <button
                type="button"
                onClick={handleAddAction}
                className="text-2xs font-bold text-amber-700 hover:text-amber-900"
              >
                + Add Action Item
              </button>
            </div>
            {actions.map((a, idx) => (
              <div key={idx} className="flex items-center gap-2">
                <input
                  type="text"
                  placeholder="Action item description..."
                  value={a.description}
                  onChange={(e) => handleUpdateAction(idx, 'description', e.target.value)}
                  className="flex-1 text-xs p-2 border border-slate-200 rounded-lg"
                  required
                />
                <input
                  type="date"
                  value={a.deadline}
                  onChange={(e) => handleUpdateAction(idx, 'deadline', e.target.value)}
                  className="text-xs p-2 border border-slate-200 rounded-lg w-32"
                  required
                />
                <button
                  type="button"
                  onClick={() => handleRemoveAction(idx)}
                  className="text-slate-400 hover:text-rose-600 p-1 font-bold"
                >
                  &times;
                </button>
              </div>
            ))}
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-slate-200">
            <Button type="button" variant="outline" size="sm" onClick={onClose}>
              Cancel
            </Button>
            <Button
              type="submit"
              variant="primary"
              size="sm"
              loading={isSubmitting}
              icon={<Plus className="w-4 h-4" />}
            >
              Initiate Improvement Plan
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};
