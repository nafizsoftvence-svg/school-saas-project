import React from 'react';
import {
  PieChart,
  Award,
  TrendingUp,
  BarChart2,
  Users,
  Building,
  CheckCircle2,
  Clock,
  AlertTriangle,
  FileSpreadsheet
} from 'lucide-react';
import { Button } from '../../../../components/ui/Button.js';
import {
  PerformanceDashboardMetrics,
  StaffPerformanceReview,
  Department
} from '../../../../types/index.js';

interface PerformanceAnalyticsSubViewProps {
  metrics: PerformanceDashboardMetrics | null;
  reviews: StaffPerformanceReview[];
  departments: Department[];
}

export const PerformanceAnalyticsSubView: React.FC<PerformanceAnalyticsSubViewProps> = ({
  metrics,
  reviews,
  departments: _departments
}) => {
  const dist = metrics?.ratingBandDistribution || metrics?.ratingDistribution || {};
  const exceptional = Number(dist['EXCEPTIONAL']) || 0;
  const exceeds = Number(dist['EXCEEDS_EXPECTATIONS']) || 0;
  const meets = Number(dist['MEETS_EXPECTATIONS']) || 0;
  const needsImp = Number(dist['NEEDS_IMPROVEMENT']) || 0;
  const unsatisfactory = Number(dist['UNSATISFACTORY']) || 0;
  const totalEvaluated = exceptional + exceeds + meets + needsImp + unsatisfactory;

  // Department scores comparison
  const deptPerformance: Record<string, { totalScore: number; count: number }> = {};
  reviews.forEach((r) => {
    const score = r.hrReview?.finalCalculatedScore ?? r.supervisorReview?.calculatedScore;
    if (score !== undefined && !isNaN(score)) {
      const deptName = r.departmentName || 'General';
      if (!deptPerformance[deptName]) {
        deptPerformance[deptName] = { totalScore: 0, count: 0 };
      }
      deptPerformance[deptName].totalScore += Number(score);
      deptPerformance[deptName].count += 1;
    }
  });

  const deptList = Object.entries(deptPerformance).map(([name, data]) => ({
    name,
    avg: Math.round((data.totalScore / (data.count || 1)) * 10) / 10,
    count: data.count
  })).sort((a, b) => b.avg - a.avg);

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h3 className="text-sm font-bold text-slate-900">Institutional Performance Analytics & Scoring Trends</h3>
          <p className="text-xs text-slate-500">Distribution curve, department benchmarks, and review cycle progression</p>
        </div>

        <div className="flex items-center gap-3">
          <div className="text-right">
            <div className="text-2xs font-bold uppercase tracking-wider text-slate-400">Institutional Average</div>
            <div className="text-xl font-black text-indigo-700">{metrics?.averageRating || 84.5}%</div>
          </div>
        </div>
      </div>

      {/* Grid: Rating distribution + Stage pipeline */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Rating Band Distribution */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              Rating Band Distribution (Bell Curve)
            </h4>
            <span className="text-2xs font-bold text-slate-500">{totalEvaluated} Staff Rated</span>
          </div>

          <div className="space-y-3">
            <div>
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="font-semibold text-purple-900">Exceptional (90-100%)</span>
                <span className="font-bold text-purple-700">{exceptional} ({totalEvaluated ? Math.round((exceptional / totalEvaluated) * 100) : 0}%)</span>
              </div>
              <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                <div
                  className="bg-purple-600 h-full rounded-full"
                  style={{ width: `${totalEvaluated ? (exceptional / totalEvaluated) * 100 : 0}%` }}
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="font-semibold text-emerald-900">Exceeds Expectations (75-89%)</span>
                <span className="font-bold text-emerald-700">{exceeds} ({totalEvaluated ? Math.round((exceeds / totalEvaluated) * 100) : 0}%)</span>
              </div>
              <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                <div
                  className="bg-emerald-600 h-full rounded-full"
                  style={{ width: `${totalEvaluated ? (exceeds / totalEvaluated) * 100 : 0}%` }}
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="font-semibold text-blue-900">Meets Expectations (60-74%)</span>
                <span className="font-bold text-blue-700">{meets} ({totalEvaluated ? Math.round((meets / totalEvaluated) * 100) : 0}%)</span>
              </div>
              <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                <div
                  className="bg-blue-600 h-full rounded-full"
                  style={{ width: `${totalEvaluated ? (meets / totalEvaluated) * 100 : 0}%` }}
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="font-semibold text-amber-900">Needs Improvement (45-59%)</span>
                <span className="font-bold text-amber-700">{needsImp} ({totalEvaluated ? Math.round((needsImp / totalEvaluated) * 100) : 0}%)</span>
              </div>
              <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                <div
                  className="bg-amber-600 h-full rounded-full"
                  style={{ width: `${totalEvaluated ? (needsImp / totalEvaluated) * 100 : 0}%` }}
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="font-semibold text-rose-900">Unsatisfactory (&lt;45%)</span>
                <span className="font-bold text-rose-700">{unsatisfactory} ({totalEvaluated ? Math.round((unsatisfactory / totalEvaluated) * 100) : 0}%)</span>
              </div>
              <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                <div
                  className="bg-rose-600 h-full rounded-full"
                  style={{ width: `${totalEvaluated ? (unsatisfactory / totalEvaluated) * 100 : 0}%` }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Department Comparison Table */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 space-y-4">
          <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
            Department Performance Benchmarks
          </h4>

          {deptList.length === 0 ? (
            <p className="text-xs text-slate-400 italic py-6 text-center">No departmental reviews finalized yet.</p>
          ) : (
            <div className="space-y-3">
              {deptList.map((d) => (
                <div key={d.name} className="flex items-center justify-between p-3 bg-slate-50 rounded-xl">
                  <div>
                    <div className="text-xs font-bold text-slate-800">{d.name}</div>
                    <div className="text-2xs text-slate-400">{d.count} Appraisals Recorded</div>
                  </div>
                  <div className="text-right">
                    <span className="text-sm font-extrabold text-indigo-700">{d.avg}%</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
