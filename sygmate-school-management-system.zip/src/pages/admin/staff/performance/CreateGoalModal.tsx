import React, { useState } from 'react';
import { X, Target, Plus, AlertCircle } from 'lucide-react';
import { Button } from '../../../../components/ui/Button.js';
import { api } from '../../../../services/api.js';
import {
  StaffProfile,
  PerformanceReviewCycle,
  GoalCategory,
  CreatePerformanceGoalPayload
} from '../../../../types/index.js';

interface CreateGoalModalProps {
  isOpen: boolean;
  onClose: () => void;
  staffList: StaffProfile[];
  cycles: PerformanceReviewCycle[];
  onGoalCreated: () => void;
}

export const CreateGoalModal: React.FC<CreateGoalModalProps> = ({
  isOpen,
  onClose,
  staffList,
  cycles,
  onGoalCreated
}) => {
  const [staffId, setStaffId] = useState<string>(staffList?.[0]?.id || '');
  const [reviewCycleId, setReviewCycleId] = useState<string>(cycles?.[0]?.id || '');
  const [title, setTitle] = useState<string>('');
  const [description, setDescription] = useState<string>('');
  const [category, setCategory] = useState<GoalCategory>('ACADEMIC_ACHIEVEMENT');
  const [target, setTarget] = useState<string>('');
  const [measurementMethod, setMeasurementMethod] = useState<string>('');
  const [weight, setWeight] = useState<number>(20);
  const [startDate, setStartDate] = useState<string>('2025-01-15');
  const [dueDate, setDueDate] = useState<string>('2025-06-30');

  const [milestones, setMilestones] = useState<Array<{ title: string; dueDate: string }>>([
    { title: 'Milestone 1: Preliminary outline and curriculum mapping', dueDate: '2025-02-28' },
    { title: 'Milestone 2: Interim benchmark assessment & progress check', dueDate: '2025-04-30' }
  ]);

  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleAddMilestone = () => {
    setMilestones([...milestones, { title: '', dueDate: dueDate }]);
  };

  const handleUpdateMilestone = (idx: number, field: 'title' | 'dueDate', val: string) => {
    const next = [...milestones];
    next[idx][field] = val;
    setMilestones(next);
  };

  const handleRemoveMilestone = (idx: number) => {
    setMilestones(milestones.filter((_, i) => i !== idx));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !target.trim() || !staffId) {
      setError('Staff member, goal title, and target are required.');
      return;
    }

    setIsSubmitting(true);
    setError(null);
    try {
      const payload: CreatePerformanceGoalPayload = {
        staffId,
        reviewCycleId,
        title: title.trim(),
        description: description.trim(),
        category,
        target: target.trim(),
        measurementMethod: measurementMethod.trim() || 'Verified by Department Head evaluation',
        weight: Number(weight),
        startDate,
        dueDate,
        milestones: milestones.filter((m) => m.title.trim().length > 0)
      };

      await api.staff.performance.createGoal(payload);
      onGoalCreated();
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to create performance goal.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto animate-in fade-in">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-xl overflow-hidden flex flex-col">
        <div className="p-6 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="p-2 bg-indigo-100 text-indigo-700 rounded-xl">
              <Target className="w-5 h-5" />
            </span>
            <div>
              <h2 className="text-base font-bold text-slate-900">Establish Performance Goal</h2>
              <p className="text-xs text-slate-500">Assign measurable target with milestones</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {error && (
          <div className="mx-6 mt-4 p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto max-h-[75vh]">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Staff Member *
              </label>
              <select
                value={staffId}
                onChange={(e) => setStaffId(e.target.value)}
                className="w-full text-xs p-2.5 border border-slate-200 rounded-xl bg-white focus:ring-2 focus:ring-indigo-500 focus:outline-hidden font-medium"
                required
              >
                {staffList.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.displayName} ({s.employeeCode}) &bull; {s.departmentName}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Review Cycle *
              </label>
              <select
                value={reviewCycleId}
                onChange={(e) => setReviewCycleId(e.target.value)}
                className="w-full text-xs p-2.5 border border-slate-200 rounded-xl bg-white focus:ring-2 focus:ring-indigo-500 focus:outline-hidden font-medium"
                required
              >
                {cycles.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name} ({c.code})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Goal Title *
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Enhance STEM Student Pass Rates by 15%"
              className="w-full text-xs p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
              required
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Category
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as GoalCategory)}
                className="w-full text-xs p-2.5 border border-slate-200 rounded-xl bg-white focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
              >
                <option value="ACADEMIC_ACHIEVEMENT">Academic Achievement</option>
                <option value="CURRICULUM_DEVELOPMENT">Curriculum Development</option>
                <option value="PROFESSIONAL_DEVELOPMENT">Professional Development</option>
                <option value="STUDENT_ENGAGEMENT">Student Engagement</option>
                <option value="INSTITUTIONAL_SERVICE">Institutional Service</option>
                <option value="RESEARCH_PUBLICATION">Research & Publications</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Goal Weight (%)
              </label>
              <input
                type="number"
                min={5}
                max={100}
                value={weight}
                onChange={(e) => setWeight(Number(e.target.value))}
                className="w-full text-xs p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Measurable Target *
              </label>
              <input
                type="text"
                value={target}
                onChange={(e) => setTarget(e.target.value)}
                placeholder="e.g. Minimum 85% class average in Term 2"
                className="w-full text-xs p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Measurement Method
              </label>
              <input
                type="text"
                value={measurementMethod}
                onChange={(e) => setMeasurementMethod(e.target.value)}
                placeholder="e.g. Verified via Exam Portal gradebooks"
                className="w-full text-xs p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Start Date
              </label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full text-xs p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Target Due Date
              </label>
              <input
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="w-full text-xs p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Detailed Description & Objectives
            </label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Context and specific deliverables..."
              className="w-full text-xs p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
            />
          </div>

          {/* Milestones */}
          <div className="space-y-2 pt-2 border-t border-slate-200">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-700">
                Key Milestone Checkpoints ({milestones.length})
              </label>
              <button
                type="button"
                onClick={handleAddMilestone}
                className="text-2xs font-bold text-indigo-600 hover:text-indigo-800"
              >
                + Add Milestone
              </button>
            </div>
            {milestones.map((m, idx) => (
              <div key={idx} className="flex items-center gap-2">
                <input
                  type="text"
                  placeholder="Milestone description..."
                  value={m.title}
                  onChange={(e) => handleUpdateMilestone(idx, 'title', e.target.value)}
                  className="flex-1 text-xs p-2 border border-slate-200 rounded-lg"
                />
                <input
                  type="date"
                  value={m.dueDate}
                  onChange={(e) => handleUpdateMilestone(idx, 'dueDate', e.target.value)}
                  className="text-xs p-2 border border-slate-200 rounded-lg w-32"
                />
                <button
                  type="button"
                  onClick={() => handleRemoveMilestone(idx)}
                  className="text-slate-400 hover:text-rose-600 p-1 font-bold"
                >
                  &times;
                </button>
              </div>
            ))}
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-slate-200">
            <Button type="button" variant="outline" size="sm" onClick={onClose}>
              Cancel
            </Button>
            <Button
              type="submit"
              variant="primary"
              size="sm"
              loading={isSubmitting}
              icon={<Plus className="w-4 h-4" />}
            >
              Establish Goal
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};
