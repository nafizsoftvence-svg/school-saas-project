import React, { useState } from 'react';
import { X, CheckCircle2, TrendingUp, AlertCircle } from 'lucide-react';
import { Button } from '../../../../components/ui/Button.js';
import { api } from '../../../../services/api.js';
import {
  PerformanceGoal,
  GoalStatus,
  UpdateGoalProgressPayload
} from '../../../../types/index.js';

interface UpdateGoalProgressModalProps {
  isOpen: boolean;
  onClose: () => void;
  goal: PerformanceGoal | null;
  onGoalUpdated: () => void;
}

export const UpdateGoalProgressModal: React.FC<UpdateGoalProgressModalProps> = ({
  isOpen,
  onClose,
  goal,
  onGoalUpdated
}) => {
  const [progress, setProgress] = useState<number>(goal?.progressPercentage || 0);
  const [status, setStatus] = useState<GoalStatus>(goal?.status || 'IN_PROGRESS');
  const [completedMilestones, setCompletedMilestones] = useState<string[]>(
    goal?.milestones?.filter((m) => m.isCompleted).map((m) => m.id) || []
  );
  const [note, setNote] = useState<string>('');

  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen || !goal) return null;

  const toggleMilestone = (mId: string) => {
    if (completedMilestones.includes(mId)) {
      setCompletedMilestones(completedMilestones.filter((id) => id !== mId));
    } else {
      setCompletedMilestones([...completedMilestones, mId]);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError(null);
    try {
      const payload: UpdateGoalProgressPayload = {
        progressPercentage: Number(progress),
        status,
        note: note.trim() || undefined,
        completedMilestoneIds: completedMilestones
      };

      await api.staff.performance.updateGoalProgress(goal.id, payload);
      onGoalUpdated();
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to update goal progress.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto animate-in fade-in">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden flex flex-col">
        <div className="p-6 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="p-2 bg-indigo-100 text-indigo-700 rounded-xl">
              <TrendingUp className="w-5 h-5" />
            </span>
            <div>
              <h2 className="text-base font-bold text-slate-900">Update Goal Progress</h2>
              <p className="text-xs text-slate-500">{goal.title} ({goal.staffName})</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {error && (
          <div className="mx-6 mt-4 p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs font-bold text-slate-700">
                Current Completion Percentage: {progress}%
              </label>
              <span className="text-xs font-semibold text-indigo-600 font-mono">
                {progress >= 100 ? 'Target Reached (100%)' : `${progress}%`}
              </span>
            </div>
            <input
              type="range"
              min={0}
              max={100}
              step={5}
              value={progress}
              onChange={(e) => {
                const val = Number(e.target.value);
                setProgress(val);
                if (val >= 100) setStatus('ACHIEVED');
                else if (val > 0) setStatus('IN_PROGRESS');
              }}
              className="w-full accent-indigo-600 h-2 bg-slate-200 rounded-lg cursor-pointer"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Goal Status
            </label>
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value as GoalStatus)}
              className="w-full text-xs p-2.5 border border-slate-200 rounded-xl bg-white focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
            >
              <option value="ACTIVE">ACTIVE</option>
              <option value="IN_PROGRESS">IN PROGRESS</option>
              <option value="ACHIEVED">ACHIEVED (Completed)</option>
              <option value="NOT_ACHIEVED">NOT ACHIEVED</option>
              <option value="DEFERRED">DEFERRED</option>
            </select>
          </div>

          {/* Milestones Check-off */}
          {goal.milestones && goal.milestones.length > 0 && (
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
              <div className="text-xs font-bold text-slate-900">
                Check off achieved milestone deliverables:
              </div>
              {goal.milestones.map((m) => (
                <label key={m.id} className="flex items-start gap-2.5 text-xs text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={completedMilestones.includes(m.id)}
                    onChange={() => toggleMilestone(m.id)}
                    className="w-4 h-4 text-indigo-600 rounded border-slate-300 mt-0.5"
                  />
                  <div>
                    <span className={completedMilestones.includes(m.id) ? 'line-through text-slate-400 font-medium' : 'font-medium'}>
                      {m.title}
                    </span>
                    <span className="text-2xs text-slate-400 ml-2">Due: {m.dueDate}</span>
                  </div>
                </label>
              ))}
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Log Progress Note / Deliverable Evidence
            </label>
            <textarea
              rows={3}
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Describe progress made since last check-in..."
              className="w-full text-xs p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
            />
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-slate-200">
            <Button type="button" variant="outline" size="sm" onClick={onClose}>
              Cancel
            </Button>
            <Button
              type="submit"
              variant="primary"
              size="sm"
              loading={isSubmitting}
              icon={<CheckCircle2 className="w-4 h-4" />}
            >
              Save Progress Update
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};
