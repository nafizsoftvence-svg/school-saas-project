import React, { useState } from 'react';
import { X, Calendar, Plus, CheckCircle2, AlertCircle } from 'lucide-react';
import { Button } from '../../../../components/ui/Button.js';
import { api } from '../../../../services/api.js';
import {
  Department,
  Designation,
  CreateReviewCyclePayload,
  ReviewType,
  ReviewFrequency
} from '../../../../types/index.js';

interface CreateReviewCycleModalProps {
  isOpen: boolean;
  onClose: () => void;
  departments: Department[];
  designations: Designation[];
  onCycleCreated: () => void;
}

export const CreateReviewCycleModal: React.FC<CreateReviewCycleModalProps> = ({
  isOpen,
  onClose,
  departments,
  designations,
  onCycleCreated
}) => {
  const [name, setName] = useState<string>('');
  const [code, setCode] = useState<string>('');
  const [description, setDescription] = useState<string>('');
  const [reviewPeriod, setReviewPeriod] = useState<string>('2024-2025 Annual Review');
  const [reviewType, setReviewType] = useState<ReviewType>('ANNUAL');
  const [frequency, setFrequency] = useState<ReviewFrequency>('ANNUAL');
  const [startDate, setStartDate] = useState<string>('2025-01-15');
  const [endDate, setEndDate] = useState<string>('2025-03-31');
  const [selfAssessmentDeadline, setSelfAssessmentDeadline] = useState<string>('2025-02-15');
  const [supervisorReviewDeadline, setSupervisorReviewDeadline] = useState<string>('2025-03-10');
  const [categoryScope, setCategoryScope] = useState<string>('ALL');
  const [allowSelfAssessment, setAllowSelfAssessment] = useState<boolean>(true);
  const [requireHODReview, setRequireHODReview] = useState<boolean>(true);
  const [requireHRFinalApproval, setRequireHRFinalApproval] = useState<boolean>(true);

  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !code.trim()) {
      setError('Name and cycle code are required.');
      return;
    }

    setIsSubmitting(true);
    setError(null);
    try {
      const payload: CreateReviewCyclePayload = {
        name: name.trim(),
        code: code.trim().toUpperCase(),
        description: description.trim(),
        academicSessionId: 'session-2024-2025',
        reviewPeriod: reviewPeriod.trim(),
        startDate,
        endDate,
        selfAssessmentDeadline,
        supervisorReviewDeadline,
        reviewType,
        frequency,
        applicableStaffCategories: categoryScope === 'ALL' ? ['ALL'] : [categoryScope],
        scoringModel: 'WEIGHTED_100',
        allowSelfAssessment,
        requireHODReview,
        requireHRFinalApproval
      };

      await api.staff.performance.createCycle(payload);
      onCycleCreated();
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to create review cycle.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto animate-in fade-in">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-2xl overflow-hidden flex flex-col">
        <div className="p-6 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="p-2 bg-indigo-100 text-indigo-700 rounded-xl">
              <Calendar className="w-5 h-5" />
            </span>
            <div>
              <h2 className="text-base font-bold text-slate-900">Create Performance Review Cycle</h2>
              <p className="text-xs text-slate-500">Configure appraisal timeline, stages, and eligibility</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {error && (
          <div className="mx-6 mt-4 p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto max-h-[75vh]">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Cycle Name *
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. 2024-2025 Annual Faculty Appraisal"
                className="w-full text-xs p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Cycle Code *
              </label>
              <input
                type="text"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="e.g. APP-2024-ANNUAL"
                className="w-full text-xs p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 uppercase font-mono focus:outline-hidden"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Review Period *
              </label>
              <input
                type="text"
                value={reviewPeriod}
                onChange={(e) => setReviewPeriod(e.target.value)}
                placeholder="Academic Year 2024-2025"
                className="w-full text-xs p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Appraisal Type
              </label>
              <select
                value={reviewType}
                onChange={(e) => setReviewType(e.target.value as ReviewType)}
                className="w-full text-xs p-2.5 border border-slate-200 rounded-xl bg-white focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
              >
                <option value="ANNUAL">Annual Appraisal</option>
                <option value="MID_YEAR">Mid-Year Review</option>
                <option value="QUARTERLY">Quarterly Check-in</option>
                <option value="PROBATION">Probation Confirmation</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Applicable Workforce
              </label>
              <select
                value={categoryScope}
                onChange={(e) => setCategoryScope(e.target.value)}
                className="w-full text-xs p-2.5 border border-slate-200 rounded-xl bg-white focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
              >
                <option value="ALL">All Staff Categories</option>
                <option value="TEACHING">Teaching Staff Only</option>
                <option value="NON_TEACHING">Non-Teaching Staff Only</option>
                <option value="ADMINISTRATIVE">Administrative Staff Only</option>
              </select>
            </div>
          </div>

          {/* Key Milestone Dates */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 p-4 bg-slate-50 border border-slate-200 rounded-xl">
            <div>
              <label className="block text-2xs font-bold text-slate-700 mb-1">
                Start Date *
              </label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full text-xs p-2 bg-white border border-slate-200 rounded-lg"
                required
              />
            </div>

            <div>
              <label className="block text-2xs font-bold text-slate-700 mb-1">
                Self-Assessment Due
              </label>
              <input
                type="date"
                value={selfAssessmentDeadline}
                onChange={(e) => setSelfAssessmentDeadline(e.target.value)}
                className="w-full text-xs p-2 bg-white border border-slate-200 rounded-lg"
              />
            </div>

            <div>
              <label className="block text-2xs font-bold text-slate-700 mb-1">
                Supervisor Review Due
              </label>
              <input
                type="date"
                value={supervisorReviewDeadline}
                onChange={(e) => setSupervisorReviewDeadline(e.target.value)}
                className="w-full text-xs p-2 bg-white border border-slate-200 rounded-lg"
              />
            </div>

            <div>
              <label className="block text-2xs font-bold text-slate-700 mb-1">
                Cycle End Date *
              </label>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full text-xs p-2 bg-white border border-slate-200 rounded-lg"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Description / Policy Context
            </label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Institutional objectives, evaluation directives..."
              className="w-full text-xs p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
            />
          </div>

          {/* Workflow Toggles */}
          <div className="space-y-2 pt-2 border-t border-slate-200">
            <label className="flex items-center gap-2 text-xs text-slate-700 font-medium">
              <input
                type="checkbox"
                checked={allowSelfAssessment}
                onChange={(e) => setAllowSelfAssessment(e.target.checked)}
                className="w-4 h-4 text-indigo-600 rounded border-slate-300"
              />
              <span>Enable Employee Self-Assessment Stage</span>
            </label>

            <label className="flex items-center gap-2 text-xs text-slate-700 font-medium">
              <input
                type="checkbox"
                checked={requireHODReview}
                onChange={(e) => setRequireHODReview(e.target.checked)}
                className="w-4 h-4 text-indigo-600 rounded border-slate-300"
              />
              <span>Require Department Head / Supervisor Scoring</span>
            </label>

            <label className="flex items-center gap-2 text-xs text-slate-700 font-medium">
              <input
                type="checkbox"
                checked={requireHRFinalApproval}
                onChange={(e) => setRequireHRFinalApproval(e.target.checked)}
                className="w-4 h-4 text-indigo-600 rounded border-slate-300"
              />
              <span>Require HR Executive Final Approval & Rating Confirmation</span>
            </label>
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-slate-200">
            <Button type="button" variant="outline" size="sm" onClick={onClose}>
              Cancel
            </Button>
            <Button
              type="submit"
              variant="primary"
              size="sm"
              loading={isSubmitting}
              icon={<Plus className="w-4 h-4" />}
            >
              Create Review Cycle
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};
