import React, { useState } from 'react';
import {
  Target,
  Plus,
  Edit2,
  Trash2,
  CheckCircle2,
  Award,
  Layers
} from 'lucide-react';
import { Button } from '../../../../components/ui/Button.js';
import { api } from '../../../../services/api.js';
import {
  PerformanceCriterion,
  PerformanceCriterionCategory
} from '../../../../types/index.js';

interface CriteriaSubViewProps {
  criteria: PerformanceCriterion[];
  isLoading: boolean;
  onRefresh: () => void;
  onOpenCreateModal: () => void;
}

export const CriteriaSubView: React.FC<CriteriaSubViewProps> = ({
  criteria,
  isLoading,
  onRefresh,
  onOpenCreateModal
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');

  const filteredCriteria = criteria.filter((c) => {
    if (selectedCategory !== 'ALL' && c.category !== selectedCategory) return false;
    return true;
  });

  const totalWeight = criteria.filter((c) => c.isActive).reduce((acc, curr) => acc + curr.weight, 0);

  const getCategoryLabel = (cat: PerformanceCriterionCategory) => {
    switch (cat) {
      case 'TEACHING_PEDAGOGY':
        return 'Teaching & Pedagogy';
      case 'WORK_QUALITY':
        return 'Work Quality & Output';
      case 'PROFESSIONAL_CONDUCT':
        return 'Professional Conduct';
      case 'PUNCTUALITY_ATTENDANCE':
        return 'Punctuality & Attendance';
      case 'STUDENT_OUTCOMES':
        return 'Student Outcomes';
      case 'LEADERSHIP_INITIATIVE':
        return 'Leadership & Initiative';
      case 'TEAMWORK_COMMUNICATION':
        return 'Teamwork & Collaboration';
      case 'RESEARCH_DEVELOPMENT':
        return 'Research & Innovation';
      default:
        return cat;
    }
  };

  const handleToggleActive = async (c: PerformanceCriterion) => {
    try {
      await api.staff.performance.updateCriterion(c.id, {
        isActive: !c.isActive
      });
      onRefresh();
    } catch (err: any) {
      alert(err.message || 'Failed to update criterion status.');
    }
  };

  const handleDelete = async (cId: string) => {
    if (!confirm('Are you sure you want to delete this criterion?')) return;
    try {
      await api.staff.performance.deleteCriterion(cId);
      onRefresh();
    } catch (err: any) {
      alert(err.message || 'Failed to delete criterion.');
    }
  };

  return (
    <div className="space-y-4">
      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 bg-white p-4 rounded-xl border border-slate-200">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-bold text-slate-900">Performance Criteria & Rubric Standards</h3>
            <span
              className={`text-2xs font-bold px-2 py-0.5 rounded-full ${
                totalWeight === 100
                  ? 'bg-emerald-100 text-emerald-800'
                  : 'bg-amber-100 text-amber-800'
              }`}
            >
              Active Weights Total: {totalWeight}% {totalWeight === 100 ? '(Balanced)' : '(Unbalanced)'}
            </span>
          </div>
          <p className="text-xs text-slate-500">Defines the weighted evaluation categories scored during reviews</p>
        </div>

        <div className="flex items-center gap-2">
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="text-xs p-2 border border-slate-200 rounded-lg bg-white"
          >
            <option value="ALL">All Categories</option>
            <option value="TEACHING_PEDAGOGY">Teaching & Pedagogy</option>
            <option value="WORK_QUALITY">Work Quality</option>
            <option value="PROFESSIONAL_CONDUCT">Professional Conduct</option>
            <option value="PUNCTUALITY_ATTENDANCE">Punctuality & Attendance</option>
            <option value="STUDENT_OUTCOMES">Student Outcomes</option>
            <option value="LEADERSHIP_INITIATIVE">Leadership & Initiative</option>
          </select>

          <Button
            type="button"
            variant="primary"
            size="sm"
            onClick={onOpenCreateModal}
            icon={<Plus className="w-4 h-4" />}
          >
            Add Criterion
          </Button>
        </div>
      </div>

      {/* Criteria Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredCriteria.length === 0 ? (
          <div className="col-span-3 p-12 text-center bg-white rounded-xl border border-slate-200 text-slate-400">
            <Target className="w-8 h-8 mx-auto mb-2 text-slate-300" />
            <p className="font-medium">No performance criteria registered</p>
          </div>
        ) : (
          filteredCriteria.map((crit) => (
            <div
              key={crit.id}
              className={`bg-white rounded-xl border p-4 space-y-3 transition-all ${
                crit.isActive ? 'border-slate-200 shadow-2xs' : 'border-slate-200 bg-slate-50 opacity-60'
              }`}
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-2xs px-1.5 py-0.5 bg-indigo-50 text-indigo-700 font-bold rounded">
                      {crit.code}
                    </span>
                    <span className="font-bold text-slate-900 text-xs">{crit.name}</span>
                  </div>
                  <span className="text-2xs text-slate-500 font-medium">
                    {getCategoryLabel(crit.category)}
                  </span>
                </div>
                <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700">
                  {crit.weight}%
                </span>
              </div>

              <p className="text-xs text-slate-600 line-clamp-3 min-h-[3rem]">
                {crit.description || 'Standard evaluation criterion.'}
              </p>

              <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-2xs text-slate-500">
                <span>Scale: 1 - {crit.maxScore}</span>
                <span>Scope: {crit.applicableStaffType}</span>
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => handleToggleActive(crit)}
                    className={`font-semibold hover:underline ${crit.isActive ? 'text-amber-600' : 'text-emerald-600'}`}
                  >
                    {crit.isActive ? 'Deactivate' : 'Activate'}
                  </button>
                  <button
                    type="button"
                    onClick={() => handleDelete(crit.id)}
                    className="text-rose-500 hover:text-rose-700 p-1"
                    title="Delete"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
