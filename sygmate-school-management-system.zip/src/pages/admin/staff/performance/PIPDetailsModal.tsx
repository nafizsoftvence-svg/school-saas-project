import React, { useState } from 'react';
import {
  X,
  AlertTriangle,
  CheckCircle2,
  Calendar,
  User,
  Check,
  RotateCcw,
  MessageSquare,
  AlertCircle
} from 'lucide-react';
import { Button } from '../../../../components/ui/Button.js';
import { api } from '../../../../services/api.js';
import {
  PerformanceImprovementPlan,
  PIPStatus,
  PIPOutcome
} from '../../../../types/index.js';

interface PIPDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  pip: PerformanceImprovementPlan | null;
  onPIPUpdated: () => void;
}

export const PIPDetailsModal: React.FC<PIPDetailsModalProps> = ({
  isOpen,
  onClose,
  pip,
  onPIPUpdated
}) => {
  const [activeTab, setActiveTab] = useState<'actions' | 'notes' | 'resolution'>('actions');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  // New progress note
  const [noteContent, setNoteContent] = useState<string>('');

  // Action check-off
  const [actionVerificationNote, setActionVerificationNote] = useState<string>('');

  // Resolve plan
  const [resolveOutcome, setResolveOutcome] = useState<PIPOutcome>('SUCCESSFUL');
  const [resolveStatus, setResolveStatus] = useState<PIPStatus>('RESOLVED');
  const [resolveNotes, setResolveNotes] = useState<string>('');

  if (!isOpen || !pip) return null;

  const handleToggleAction = async (actionId: string, currentStatus: boolean) => {
    setIsSubmitting(true);
    setError(null);
    try {
      await api.staff.performance.updatePIPAction(pip.id, actionId, {
        isCompleted: !currentStatus,
        verificationNotes: actionVerificationNote || 'Marked completed by supervisor evaluation'
      });
      setSuccess('Action item status updated.');
      setActionVerificationNote('');
      onPIPUpdated();
    } catch (err: any) {
      setError(err.message || 'Failed to update action status.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleAddNote = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!noteContent.trim()) return;

    setIsSubmitting(true);
    setError(null);
    try {
      await api.staff.performance.addPIPProgressNote(pip.id, noteContent.trim());
      setSuccess('Progress note logged.');
      setNoteContent('');
      onPIPUpdated();
    } catch (err: any) {
      setError(err.message || 'Failed to add progress note.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleResolvePIP = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!resolveNotes.trim()) {
      setError('Resolution evaluation notes are required.');
      return;
    }

    setIsSubmitting(true);
    setError(null);
    try {
      await api.staff.performance.resolvePIP(pip.id, {
        status: resolveStatus,
        finalOutcome: resolveOutcome,
        resolutionNotes: resolveNotes.trim()
      });
      setSuccess('Performance Improvement Plan resolved.');
      onPIPUpdated();
    } catch (err: any) {
      setError(err.message || 'Failed to resolve plan.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const completedActions = (pip?.requiredActions || []).filter((a) => a.isCompleted).length;
  const totalActions = pip?.requiredActions?.length || 0;
  const progressPercent = totalActions > 0 ? Math.round((completedActions / totalActions) * 100) : 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto animate-in fade-in">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-3xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="p-6 border-b border-slate-200 bg-amber-50/50 flex items-start justify-between">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="p-2 bg-amber-100 text-amber-800 rounded-xl">
                <AlertTriangle className="w-5 h-5" />
              </span>
              <div>
                <h2 className="text-base font-bold text-slate-900">
                  PIP Dossier: {pip.staffName} ({pip.staffEmployeeCode})
                </h2>
                <p className="text-xs text-slate-500">
                  Supervisor: {pip.assignedSupervisorName} &bull; Target Date: {pip.targetDate}
                </p>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <span
              className={`text-xs font-bold px-2.5 py-1 rounded-full border ${
                pip.status === 'ACTIVE'
                  ? 'bg-amber-100 text-amber-800 border-amber-200'
                  : pip.status === 'RESOLVED'
                  ? 'bg-emerald-100 text-emerald-800 border-emerald-200'
                  : 'bg-slate-100 text-slate-800 border-slate-200'
              }`}
            >
              {pip.status}
            </span>
            <button
              type="button"
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Alerts */}
        {success && (
          <div className="mx-6 mt-4 p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{success}</span>
            </div>
            <button type="button" onClick={() => setSuccess(null)} className="font-bold">
              &times;
            </button>
          </div>
        )}

        {error && (
          <div className="mx-6 mt-4 p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{error}</span>
            </div>
            <button type="button" onClick={() => setError(null)} className="font-bold">
              &times;
            </button>
          </div>
        )}

        {/* Progress bar */}
        <div className="px-6 pt-4">
          <div className="flex items-center justify-between text-xs font-bold text-slate-700 mb-1">
            <span>Action Milestones Completed ({completedActions} of {totalActions})</span>
            <span>{progressPercent}%</span>
          </div>
          <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
            <div
              className="bg-amber-500 h-full rounded-full transition-all"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-slate-200 px-6 gap-4 bg-white text-xs font-semibold mt-4">
          <button
            type="button"
            onClick={() => setActiveTab('actions')}
            className={`py-3 border-b-2 ${
              activeTab === 'actions'
                ? 'border-amber-600 text-amber-700'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Required Actions ({pip?.requiredActions?.length || 0})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('notes')}
            className={`py-3 border-b-2 ${
              activeTab === 'notes'
                ? 'border-amber-600 text-amber-700'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Supervision Notes ({pip.progressNotes?.length || 0})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('resolution')}
            className={`py-3 border-b-2 ${
              activeTab === 'resolution'
                ? 'border-amber-600 text-amber-700'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Resolution & Outcome
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto flex-1 space-y-4">
          {/* TAB 1: ACTIONS */}
          {activeTab === 'actions' && (
            <div className="space-y-4">
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-700">
                <strong>Deficiency Context:</strong> {pip.reason}
              </div>

              <div className="space-y-3">
                {pip.requiredActions.map((act) => (
                  <div
                    key={act.id}
                    className={`p-4 rounded-xl border transition-all ${
                      act.isCompleted
                        ? 'bg-emerald-50/50 border-emerald-200'
                        : 'bg-white border-slate-200'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            checked={act.isCompleted}
                            onChange={() => handleToggleAction(act.id, act.isCompleted)}
                            disabled={isSubmitting || pip.status !== 'ACTIVE'}
                            className="w-4 h-4 text-emerald-600 rounded border-slate-300"
                          />
                          <span className={`text-xs font-bold ${act.isCompleted ? 'line-through text-slate-400' : 'text-slate-900'}`}>
                            {act.description}
                          </span>
                        </div>
                        <div className="text-2xs text-slate-500 pl-6">
                          Target Deadline: <span className="font-semibold">{act.deadline}</span>
                          {act.completedAt && (
                            <span className="ml-2 text-emerald-700 font-semibold">
                              &bull; Verified: {new Date(act.completedAt).toLocaleDateString()}
                            </span>
                          )}
                        </div>
                        {act.verificationNote && (
                          <div className="text-2xs text-slate-600 pl-6 italic">
                            &quot;{act.verificationNote}&quot;
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 2: NOTES */}
          {activeTab === 'notes' && (
            <div className="space-y-4">
              {pip.status === 'ACTIVE' && (
                <form onSubmit={handleAddNote} className="space-y-2">
                  <textarea
                    rows={3}
                    value={noteContent}
                    onChange={(e) => setNoteContent(e.target.value)}
                    placeholder="Log coaching session observations, meeting records, or feedback..."
                    className="w-full text-xs p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                    required
                  />
                  <div className="flex justify-end">
                    <Button
                      type="submit"
                      variant="primary"
                      size="sm"
                      loading={isSubmitting}
                      icon={<MessageSquare className="w-3.5 h-3.5" />}
                    >
                      Log Supervisor Note
                    </Button>
                  </div>
                </form>
              )}

              <div className="space-y-3">
                {pip.progressNotes?.map((pn) => (
                  <div key={pn.id} className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-1">
                    <div className="flex items-center justify-between text-2xs text-slate-400">
                      <span className="font-bold text-slate-700">{pn.createdByName}</span>
                      <span>{new Date(pn.createdAt).toLocaleString()}</span>
                    </div>
                    <p className="text-xs text-slate-700">{pn.note}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: RESOLUTION */}
          {activeTab === 'resolution' && (
            <div className="space-y-4">
              {pip.status === 'RESOLVED' || pip.status === 'FAILED' ? (
                <div className="p-6 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
                  <div className="text-xs font-bold uppercase tracking-wider text-slate-500">
                    Plan Resolution Record
                  </div>
                  <div className="text-sm font-bold text-slate-900">
                    Final Outcome: <span className="text-emerald-700">{pip.finalOutcome}</span>
                  </div>
                  <p className="text-xs text-slate-700">
                    <strong>Resolution Notes:</strong> {pip.resolutionNotes}
                  </p>
                  <div className="text-2xs text-slate-400">
                    Resolved at: {pip.actualEndDate ? new Date(pip.actualEndDate).toLocaleString() : 'N/A'}
                  </div>
                </div>
              ) : (
                <form onSubmit={handleResolvePIP} className="space-y-4">
                  <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900">
                    Concluding the PIP closes active supervision checkpoints and registers final institutional outcome into staff dossier.
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Final Status
                      </label>
                      <select
                        value={resolveStatus}
                        onChange={(e) => setResolveStatus(e.target.value as PIPStatus)}
                        className="w-full text-xs p-2.5 border border-slate-200 rounded-xl bg-white"
                      >
                        <option value="RESOLVED">RESOLVED (Closed)</option>
                        <option value="EXTENDED">EXTENDED (Continue Plan)</option>
                        <option value="FAILED">FAILED (Non-compliance)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Outcome Assessment
                      </label>
                      <select
                        value={resolveOutcome}
                        onChange={(e) => setResolveOutcome(e.target.value as PIPOutcome)}
                        className="w-full text-xs p-2.5 border border-slate-200 rounded-xl bg-white"
                      >
                        <option value="SUCCESSFUL">SUCCESSFUL (Returned to Standard)</option>
                        <option value="EXTENDED">PLAN EXTENSION</option>
                        <option value="REASSIGNMENT">REASSIGNMENT RECOMMENDED</option>
                        <option value="TERMINATION">DISCIPLINARY / SEPARATION</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Final Evaluative Notes & Committee Summary *
                    </label>
                    <textarea
                      rows={3}
                      value={resolveNotes}
                      onChange={(e) => setResolveNotes(e.target.value)}
                      placeholder="Explain performance trajectory, milestones achieved, and institutional recommendation..."
                      className="w-full text-xs p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                      required
                    />
                  </div>

                  <div className="flex justify-end pt-2">
                    <Button
                      type="submit"
                      variant="primary"
                      size="sm"
                      loading={isSubmitting}
                      icon={<CheckCircle2 className="w-3.5 h-3.5" />}
                    >
                      Formalize Plan Resolution
                    </Button>
                  </div>
                </form>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 bg-slate-50 flex justify-end">
          <Button type="button" variant="outline" size="sm" onClick={onClose}>
            Close
          </Button>
        </div>
      </div>
    </div>
  );
};
