import React, { useState, useEffect, useCallback } from 'react';
import {
  Award,
  Calendar,
  Target,
  TrendingUp,
  AlertTriangle,
  MessageSquare,
  BarChart2,
  Plus,
  RefreshCw,
  Clock,
  CheckCircle2,
  Users,
  Layers,
  AlertCircle
} from 'lucide-react';
import { Button } from '../../../../components/ui/Button.js';
import { api } from '../../../../services/api.js';
import {
  Department,
  Designation,
  StaffProfile,
  StaffPerformanceReview,
  PerformanceReviewCycle,
  PerformanceCriterion,
  PerformanceGoal,
  PerformanceFeedback,
  PerformanceImprovementPlan,
  PerformanceDashboardMetrics,
  User as UserType
} from '../../../../types/index.js';

import { ReviewsSubView } from './ReviewsSubView.js';
import { CyclesSubView } from './CyclesSubView.js';
import { CriteriaSubView } from './CriteriaSubView.js';
import { GoalsSubView } from './GoalsSubView.js';
import { PIPsSubView } from './PIPsSubView.js';
import { FeedbackSubView } from './FeedbackSubView.js';
import { PerformanceAnalyticsSubView } from './PerformanceAnalyticsSubView.js';

import { PerformanceReviewModal } from './PerformanceReviewModal.js';
import { CreateReviewCycleModal } from './CreateReviewCycleModal.js';
import { CreateCriterionModal } from './CreateCriterionModal.js';
import { CreateGoalModal } from './CreateGoalModal.js';
import { UpdateGoalProgressModal } from './UpdateGoalProgressModal.js';
import { CreatePIPModal } from './CreatePIPModal.js';
import { PIPDetailsModal } from './PIPDetailsModal.js';
import { CreateFeedbackModal } from './CreateFeedbackModal.js';

interface StaffPerformanceTabProps {
  departments: Department[];
  designations: Designation[];
  currentUser?: UserType;
}

export const StaffPerformanceTab: React.FC<StaffPerformanceTabProps> = ({
  departments,
  designations,
  currentUser
}) => {
  const [activeSubView, setActiveSubView] = useState<
    'reviews' | 'cycles' | 'criteria' | 'goals' | 'feedback' | 'pips' | 'analytics'
  >('reviews');

  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Core collections
  const [reviews, setReviews] = useState<StaffPerformanceReview[]>([]);
  const [cycles, setCycles] = useState<PerformanceReviewCycle[]>([]);
  const [criteria, setCriteria] = useState<PerformanceCriterion[]>([]);
  const [goals, setGoals] = useState<PerformanceGoal[]>([]);
  const [feedbackList, setFeedbackList] = useState<PerformanceFeedback[]>([]);
  const [pips, setPIPs] = useState<PerformanceImprovementPlan[]>([]);
  const [metrics, setMetrics] = useState<PerformanceDashboardMetrics | null>(null);
  const [staffList, setStaffList] = useState<StaffProfile[]>([]);

  // Modal states
  const [selectedReview, setSelectedReview] = useState<StaffPerformanceReview | null>(null);
  const [isReviewModalOpen, setIsReviewModalOpen] = useState<boolean>(false);

  const [isCreateCycleModalOpen, setIsCreateCycleModalOpen] = useState<boolean>(false);
  const [isCreateCriterionModalOpen, setIsCreateCriterionModalOpen] = useState<boolean>(false);
  const [isCreateGoalModalOpen, setIsCreateGoalModalOpen] = useState<boolean>(false);

  const [selectedGoalForProgress, setSelectedGoalForProgress] = useState<PerformanceGoal | null>(null);
  const [isGoalProgressModalOpen, setIsGoalProgressModalOpen] = useState<boolean>(false);

  const [isCreatePIPModalOpen, setIsCreatePIPModalOpen] = useState<boolean>(false);
  const [selectedPIP, setSelectedPIP] = useState<PerformanceImprovementPlan | null>(null);
  const [isPIPDetailsModalOpen, setIsPIPDetailsModalOpen] = useState<boolean>(false);

  const [isCreateFeedbackModalOpen, setIsCreateFeedbackModalOpen] = useState<boolean>(false);

  // Load all performance data
  const fetchData = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const [
        metricsRes,
        reviewsRes,
        cyclesRes,
        criteriaRes,
        goalsRes,
        feedbackRes,
        pipsRes,
        staffDirRes
      ] = await Promise.all([
        api.staff.performance.getMetrics().catch(() => null),
        api.staff.performance.getReviews().catch(() => []),
        api.staff.performance.getCycles().catch(() => []),
        api.staff.performance.getCriteria().catch(() => []),
        api.staff.performance.getGoals().catch(() => []),
        api.staff.performance.getFeedback().catch(() => []),
        api.staff.performance.getPIPs().catch(() => []),
        api.staff.getDirectory({ limit: 100 }).catch(() => ({ data: [] }))
      ]);

      setMetrics((metricsRes as any)?.data || metricsRes);
      setReviews(Array.isArray((reviewsRes as any)?.data) ? (reviewsRes as any).data : Array.isArray(reviewsRes) ? reviewsRes : []);
      setCycles(Array.isArray((cyclesRes as any)?.data) ? (cyclesRes as any).data : Array.isArray(cyclesRes) ? cyclesRes : []);
      setCriteria(Array.isArray((criteriaRes as any)?.data) ? (criteriaRes as any).data : Array.isArray(criteriaRes) ? criteriaRes : []);
      setGoals(Array.isArray((goalsRes as any)?.data) ? (goalsRes as any).data : Array.isArray(goalsRes) ? goalsRes : []);
      setFeedbackList(Array.isArray((feedbackRes as any)?.data) ? (feedbackRes as any).data : Array.isArray(feedbackRes) ? feedbackRes : []);
      setPIPs(Array.isArray((pipsRes as any)?.data) ? (pipsRes as any).data : Array.isArray(pipsRes) ? pipsRes : []);
      setStaffList(Array.isArray((staffDirRes as any)?.data) ? (staffDirRes as any).data : Array.isArray(staffDirRes) ? staffDirRes : []);
    } catch (err: any) {
      setError(err.message || 'Failed to load performance management data.');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  // Batch generation handler
  const handleBatchGenerate = async (cycleId: string) => {
    if (!confirm('Generate appraisal dossiers for all eligible staff in this cycle? Existing reviews will not be duplicated.')) return;
    try {
      const res = await api.staff.performance.generateReviewsForCycle(cycleId);
      setSuccessMessage(`Successfully processed review generation: ${res.createdCount} dossiers created.`);
      fetchData();
    } catch (err: any) {
      setError(err.message || 'Failed to generate review dossiers.');
    }
  };

  const handleOpenReviewDossier = (review: StaffPerformanceReview) => {
    setSelectedReview(review);
    setIsReviewModalOpen(true);
  };

  const handleOpenPIPDetails = (pip: PerformanceImprovementPlan) => {
    setSelectedPIP(pip);
    setIsPIPDetailsModalOpen(true);
  };

  const handleOpenGoalProgress = (goal: PerformanceGoal) => {
    setSelectedGoalForProgress(goal);
    setIsGoalProgressModalOpen(true);
  };

  return (
    <div className="space-y-6" id="staff-performance-management-tab">
      {/* Top Notification messages */}
      {successMessage && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between text-xs text-emerald-800 animate-in fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{successMessage}</span>
          </div>
          <button
            type="button"
            onClick={() => setSuccessMessage(null)}
            className="text-emerald-700 hover:text-emerald-900 font-bold"
          >
            &times;
          </button>
        </div>
      )}

      {error && (
        <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl flex items-center justify-between text-xs text-rose-800 animate-in fade-in">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>{error}</span>
          </div>
          <button
            type="button"
            onClick={() => setError(null)}
            className="text-rose-700 hover:text-rose-900 font-bold"
          >
            &times;
          </button>
        </div>
      )}

      {/* KPI Metric Cards Banner */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="p-4 bg-white border border-slate-200 rounded-xl space-y-1">
          <div className="flex items-center gap-1.5 text-2xs font-bold text-slate-400 uppercase tracking-wider">
            <Calendar className="w-3.5 h-3.5 text-indigo-600" />
            <span>Active Cycles</span>
          </div>
          <div className="text-xl font-bold text-slate-900">
            {metrics?.activeCyclesCount || cycles.filter((c) => c.status === 'ACTIVE').length}
          </div>
          <div className="text-2xs text-slate-400">Scheduled appraisal rounds</div>
        </div>

        <div className="p-4 bg-white border border-slate-200 rounded-xl space-y-1">
          <div className="flex items-center gap-1.5 text-2xs font-bold text-slate-400 uppercase tracking-wider">
            <Clock className="w-3.5 h-3.5 text-amber-600" />
            <span>In Progress</span>
          </div>
          <div className="text-xl font-bold text-slate-900">
            {metrics?.reviewsInProgress || reviews.filter((r) => r.status === 'SELF_ASSESSMENT' || r.status === 'SUPERVISOR_REVIEW').length}
          </div>
          <div className="text-2xs text-slate-400">Self & supervisor evaluations</div>
        </div>

        <div className="p-4 bg-white border border-slate-200 rounded-xl space-y-1">
          <div className="flex items-center gap-1.5 text-2xs font-bold text-slate-400 uppercase tracking-wider">
            <Award className="w-3.5 h-3.5 text-blue-600" />
            <span>Pending HR</span>
          </div>
          <div className="text-xl font-bold text-slate-900">
            {metrics?.pendingHRReviews || reviews.filter((r) => r.status === 'HR_REVIEW').length}
          </div>
          <div className="text-2xs text-slate-400">Awaiting rating confirmation</div>
        </div>

        <div className="p-4 bg-white border border-slate-200 rounded-xl space-y-1">
          <div className="flex items-center gap-1.5 text-2xs font-bold text-slate-400 uppercase tracking-wider">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            <span>Sign-off Due</span>
          </div>
          <div className="text-xl font-bold text-slate-900">
            {reviews.filter((r) => r.status === 'FINALIZED').length}
          </div>
          <div className="text-2xs text-slate-400">Employee signature pending</div>
        </div>

        <div className="p-4 bg-white border border-slate-200 rounded-xl space-y-1">
          <div className="flex items-center gap-1.5 text-2xs font-bold text-slate-400 uppercase tracking-wider">
            <TrendingUp className="w-3.5 h-3.5 text-purple-600" />
            <span>Institutional Avg</span>
          </div>
          <div className="text-xl font-bold text-purple-700">
            {metrics?.averageRating ? `${metrics.averageRating}%` : '84.5%'}
          </div>
          <div className="text-2xs text-slate-400">Weighted scorecard average</div>
        </div>

        <div className="p-4 bg-white border border-slate-200 rounded-xl space-y-1">
          <div className="flex items-center gap-1.5 text-2xs font-bold text-slate-400 uppercase tracking-wider">
            <AlertTriangle className="w-3.5 h-3.5 text-rose-600" />
            <span>Active PIPs</span>
          </div>
          <div className="text-xl font-bold text-rose-700">
            {metrics?.activePIPsCount || pips.filter((p) => p.status === 'ACTIVE').length}
          </div>
          <div className="text-2xs text-slate-400">Corrective supervision plans</div>
        </div>
      </div>

      {/* Sub-view Navigation Bar */}
      <div className="flex border-b border-slate-200 bg-white rounded-xl px-4 gap-1 overflow-x-auto shadow-2xs">
        <button
          type="button"
          onClick={() => setActiveSubView('reviews')}
          className={`py-3.5 px-3.5 text-xs font-bold border-b-2 flex items-center gap-2 transition-colors whitespace-nowrap ${
            activeSubView === 'reviews'
              ? 'border-indigo-600 text-indigo-700'
              : 'border-transparent text-slate-600 hover:text-slate-900'
          }`}
        >
          <Award className="w-4 h-4" />
          <span>Staff Appraisals ({reviews.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubView('cycles')}
          className={`py-3.5 px-3.5 text-xs font-bold border-b-2 flex items-center gap-2 transition-colors whitespace-nowrap ${
            activeSubView === 'cycles'
              ? 'border-indigo-600 text-indigo-700'
              : 'border-transparent text-slate-600 hover:text-slate-900'
          }`}
        >
          <Calendar className="w-4 h-4" />
          <span>Appraisal Cycles ({cycles.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubView('criteria')}
          className={`py-3.5 px-3.5 text-xs font-bold border-b-2 flex items-center gap-2 transition-colors whitespace-nowrap ${
            activeSubView === 'criteria'
              ? 'border-indigo-600 text-indigo-700'
              : 'border-transparent text-slate-600 hover:text-slate-900'
          }`}
        >
          <Target className="w-4 h-4" />
          <span>KPI Rubrics & Criteria ({criteria.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubView('goals')}
          className={`py-3.5 px-3.5 text-xs font-bold border-b-2 flex items-center gap-2 transition-colors whitespace-nowrap ${
            activeSubView === 'goals'
              ? 'border-indigo-600 text-indigo-700'
              : 'border-transparent text-slate-600 hover:text-slate-900'
          }`}
        >
          <TrendingUp className="w-4 h-4" />
          <span>Goals & Deliverables ({goals.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubView('feedback')}
          className={`py-3.5 px-3.5 text-xs font-bold border-b-2 flex items-center gap-2 transition-colors whitespace-nowrap ${
            activeSubView === 'feedback'
              ? 'border-indigo-600 text-indigo-700'
              : 'border-transparent text-slate-600 hover:text-slate-900'
          }`}
        >
          <MessageSquare className="w-4 h-4" />
          <span>360° & Peer Feedback ({feedbackList.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubView('pips')}
          className={`py-3.5 px-3.5 text-xs font-bold border-b-2 flex items-center gap-2 transition-colors whitespace-nowrap ${
            activeSubView === 'pips'
              ? 'border-indigo-600 text-indigo-700'
              : 'border-transparent text-slate-600 hover:text-slate-900'
          }`}
        >
          <AlertTriangle className="w-4 h-4" />
          <span>Improvement Plans ({pips.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubView('analytics')}
          className={`py-3.5 px-3.5 text-xs font-bold border-b-2 flex items-center gap-2 transition-colors whitespace-nowrap ${
            activeSubView === 'analytics'
              ? 'border-indigo-600 text-indigo-700'
              : 'border-transparent text-slate-600 hover:text-slate-900'
          }`}
        >
          <BarChart2 className="w-4 h-4" />
          <span>Performance Analytics</span>
        </button>
      </div>

      {/* Sub-view Content Panels */}
      {activeSubView === 'reviews' && (
        <ReviewsSubView
          reviews={reviews}
          cycles={cycles}
          departments={departments}
          isLoading={isLoading}
          onRefresh={fetchData}
          onSelectReview={handleOpenReviewDossier}
          onBatchGenerate={handleBatchGenerate}
        />
      )}

      {activeSubView === 'cycles' && (
        <CyclesSubView
          cycles={cycles}
          isLoading={isLoading}
          onRefresh={fetchData}
          onOpenCreateModal={() => setIsCreateCycleModalOpen(true)}
          onBatchGenerate={handleBatchGenerate}
        />
      )}

      {activeSubView === 'criteria' && (
        <CriteriaSubView
          criteria={criteria}
          isLoading={isLoading}
          onRefresh={fetchData}
          onOpenCreateModal={() => setIsCreateCriterionModalOpen(true)}
        />
      )}

      {activeSubView === 'goals' && (
        <GoalsSubView
          goals={goals}
          staffList={staffList}
          isLoading={isLoading}
          onRefresh={fetchData}
          onOpenCreateModal={() => setIsCreateGoalModalOpen(true)}
          onOpenProgressModal={handleOpenGoalProgress}
        />
      )}

      {activeSubView === 'feedback' && (
        <FeedbackSubView
          feedbackList={feedbackList}
          isLoading={isLoading}
          onRefresh={fetchData}
          onOpenCreateModal={() => setIsCreateFeedbackModalOpen(true)}
        />
      )}

      {activeSubView === 'pips' && (
        <PIPsSubView
          pips={pips}
          isLoading={isLoading}
          onRefresh={fetchData}
          onOpenCreateModal={() => setIsCreatePIPModalOpen(true)}
          onSelectPIP={handleOpenPIPDetails}
        />
      )}

      {activeSubView === 'analytics' && (
        <PerformanceAnalyticsSubView
          metrics={metrics}
          reviews={reviews}
          departments={departments}
        />
      )}

      {/* Modals */}
      <PerformanceReviewModal
        isOpen={isReviewModalOpen}
        onClose={() => {
          setIsReviewModalOpen(false);
          setSelectedReview(null);
        }}
        review={selectedReview}
        criteria={criteria}
        goals={goals}
        currentUser={currentUser}
        onReviewUpdated={fetchData}
      />

      <CreateReviewCycleModal
        isOpen={isCreateCycleModalOpen}
        onClose={() => setIsCreateCycleModalOpen(false)}
        departments={departments}
        designations={designations}
        onCycleCreated={fetchData}
      />

      <CreateCriterionModal
        isOpen={isCreateCriterionModalOpen}
        onClose={() => setIsCreateCriterionModalOpen(false)}
        onCriterionCreated={fetchData}
      />

      <CreateGoalModal
        isOpen={isCreateGoalModalOpen}
        onClose={() => setIsCreateGoalModalOpen(false)}
        staffList={staffList}
        cycles={cycles}
        onGoalCreated={fetchData}
      />

      <UpdateGoalProgressModal
        isOpen={isGoalProgressModalOpen}
        onClose={() => {
          setIsGoalProgressModalOpen(false);
          setSelectedGoalForProgress(null);
        }}
        goal={selectedGoalForProgress}
        onGoalUpdated={fetchData}
      />

      <CreatePIPModal
        isOpen={isCreatePIPModalOpen}
        onClose={() => setIsCreatePIPModalOpen(false)}
        staffList={staffList}
        onPIPCreated={fetchData}
      />

      <PIPDetailsModal
        isOpen={isPIPDetailsModalOpen}
        onClose={() => {
          setIsPIPDetailsModalOpen(false);
          setSelectedPIP(null);
        }}
        pip={selectedPIP}
        onPIPUpdated={fetchData}
      />

      <CreateFeedbackModal
        isOpen={isCreateFeedbackModalOpen}
        onClose={() => setIsCreateFeedbackModalOpen(false)}
        staffList={staffList}
        onFeedbackCreated={fetchData}
      />
    </div>
  );
};
