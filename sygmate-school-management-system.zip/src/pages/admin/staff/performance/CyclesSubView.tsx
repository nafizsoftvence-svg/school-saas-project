import React from 'react';
import {
  Calendar,
  Plus,
  Play,
  Lock,
  CheckCircle2,
  Clock,
  Users,
  Layers,
  Award
} from 'lucide-react';
import { Button } from '../../../../components/ui/Button.js';
import { api } from '../../../../services/api.js';
import {
  PerformanceReviewCycle,
  ReviewCycleStatus
} from '../../../../types/index.js';

interface CyclesSubViewProps {
  cycles: PerformanceReviewCycle[];
  isLoading: boolean;
  onRefresh: () => void;
  onOpenCreateModal: () => void;
  onBatchGenerate: (cycleId: string) => void;
}

export const CyclesSubView: React.FC<CyclesSubViewProps> = ({
  cycles,
  isLoading,
  onRefresh,
  onOpenCreateModal,
  onBatchGenerate
}) => {
  const handleUpdateStatus = async (cycleId: string, status: ReviewCycleStatus) => {
    try {
      await api.staff.performance.updateCycle(cycleId, { status });
      onRefresh();
    } catch (err: any) {
      alert(err.message || 'Failed to update cycle status.');
    }
  };

  const getStatusBadge = (status: ReviewCycleStatus) => {
    switch (status) {
      case 'DRAFT':
        return <span className="px-2 py-0.5 rounded text-2xs font-semibold bg-slate-100 text-slate-700">Draft</span>;
      case 'ACTIVE':
        return <span className="px-2 py-0.5 rounded text-2xs font-semibold bg-emerald-100 text-emerald-800 animate-pulse">Active / In Progress</span>;
      case 'UNDER_EVALUATION':
        return <span className="px-2 py-0.5 rounded text-2xs font-semibold bg-indigo-100 text-indigo-800">Under Evaluation</span>;
      case 'COMPLETED':
        return <span className="px-2 py-0.5 rounded text-2xs font-semibold bg-blue-100 text-blue-800">Completed</span>;
      case 'CLOSED':
        return <span className="px-2 py-0.5 rounded text-2xs font-semibold bg-slate-200 text-slate-700">Archived</span>;
      default:
        return null;
    }
  };

  return (
    <div className="space-y-4">
      {/* Top action row */}
      <div className="flex items-center justify-between bg-white p-4 rounded-xl border border-slate-200">
        <div>
          <h3 className="text-sm font-bold text-slate-900">Appraisal Cycles & Performance Timelines</h3>
          <p className="text-xs text-slate-500">Manage annual reviews, probation check-ins, and automated staff review generation</p>
        </div>
        <Button
          type="button"
          variant="primary"
          size="sm"
          onClick={onOpenCreateModal}
          icon={<Plus className="w-4 h-4" />}
        >
          New Review Cycle
        </Button>
      </div>

      {/* Cycles Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {cycles.length === 0 ? (
          <div className="col-span-2 p-12 text-center bg-white rounded-xl border border-slate-200 text-slate-400">
            <Calendar className="w-8 h-8 mx-auto mb-2 text-slate-300" />
            <p className="font-medium">No review cycles registered</p>
          </div>
        ) : (
          cycles.map((cycle) => (
            <div
              key={cycle.id}
              className="bg-white rounded-xl border border-slate-200 p-5 space-y-4 hover:shadow-sm transition-all"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-900 text-sm">{cycle.name}</span>
                    <span className="font-mono text-2xs px-1.5 py-0.5 bg-slate-100 rounded text-slate-600">
                      {cycle.code}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500">{cycle.reviewPeriod}</p>
                </div>
                {getStatusBadge(cycle.status)}
              </div>

              {cycle.description && (
                <p className="text-xs text-slate-600 line-clamp-2">{cycle.description}</p>
              )}

              {/* Timeline grid */}
              <div className="grid grid-cols-2 gap-2 p-3 bg-slate-50 rounded-lg text-2xs text-slate-600">
                <div>
                  <span className="font-bold text-slate-700">Period:</span> {cycle.startDate} to {cycle.endDate}
                </div>
                <div>
                  <span className="font-bold text-slate-700">Self-Review Due:</span> {cycle.selfAssessmentDeadline || 'N/A'}
                </div>
                <div>
                  <span className="font-bold text-slate-700">Supervisor Due:</span> {cycle.supervisorReviewDeadline || 'N/A'}
                </div>
                <div>
                  <span className="font-bold text-slate-700">Scope:</span> {cycle.applicableStaffCategories.join(', ')}
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center justify-between pt-2 border-t border-slate-100">
                <div className="flex items-center gap-2">
                  {cycle.status === 'DRAFT' && (
                    <Button
                      type="button"
                      variant="outline"
                      size="xs"
                      onClick={() => handleUpdateStatus(cycle.id, 'ACTIVE')}
                      icon={<Play className="w-3 h-3 text-emerald-600" />}
                    >
                      Launch Cycle
                    </Button>
                  )}
                  {cycle.status === 'ACTIVE' && (
                    <Button
                      type="button"
                      variant="outline"
                      size="xs"
                      onClick={() => handleUpdateStatus(cycle.id, 'COMPLETED')}
                      icon={<CheckCircle2 className="w-3 h-3 text-blue-600" />}
                    >
                      Mark Completed
                    </Button>
                  )}
                  {cycle.status === 'COMPLETED' && (
                    <Button
                      type="button"
                      variant="outline"
                      size="xs"
                      onClick={() => handleUpdateStatus(cycle.id, 'CLOSED')}
                      icon={<Lock className="w-3 h-3 text-slate-500" />}
                    >
                      Close & Archive
                    </Button>
                  )}
                </div>

                <Button
                  type="button"
                  variant="primary"
                  size="xs"
                  onClick={() => onBatchGenerate(cycle.id)}
                  icon={<Layers className="w-3 h-3" />}
                >
                  Generate Staff Dossiers
                </Button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
