import React, { useState } from 'react';
import { X, MessageSquare, Plus, AlertCircle } from 'lucide-react';
import { Button } from '../../../../components/ui/Button.js';
import { api } from '../../../../services/api.js';
import {
  StaffProfile,
  FeedbackType,
  CreatePerformanceFeedbackPayload
} from '../../../../types/index.js';

interface CreateFeedbackModalProps {
  isOpen: boolean;
  onClose: () => void;
  staffList: StaffProfile[];
  onFeedbackCreated: () => void;
}

export const CreateFeedbackModal: React.FC<CreateFeedbackModalProps> = ({
  isOpen,
  onClose,
  staffList,
  onFeedbackCreated
}) => {
  const [staffId, setStaffId] = useState<string>(staffList?.[0]?.id || '');
  const [feedbackType, setFeedbackType] = useState<FeedbackType>('COMMENDATION');
  const [comments, setComments] = useState<string>('');
  const [strengths, setStrengths] = useState<string>('');
  const [areasForImprovement, setAreasForImprovement] = useState<string>('');
  const [rating, setRating] = useState<number>(5);
  const [isAnonymous, setIsAnonymous] = useState<boolean>(false);

  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!staffId || !comments.trim()) {
      setError('Staff recipient and feedback comments are required.');
      return;
    }

    setIsSubmitting(true);
    setError(null);
    try {
      const payload: CreatePerformanceFeedbackPayload = {
        staffId,
        feedbackType,
        comments: comments.trim(),
        strengths: strengths.trim() || undefined,
        areasForImprovement: areasForImprovement.trim() || undefined,
        rating: Number(rating),
        isAnonymous
      };

      await api.staff.performance.createFeedback(payload);
      onFeedbackCreated();
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to submit feedback.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto animate-in fade-in">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden flex flex-col">
        <div className="p-6 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="p-2 bg-indigo-100 text-indigo-700 rounded-xl">
              <MessageSquare className="w-5 h-5" />
            </span>
            <div>
              <h2 className="text-base font-bold text-slate-900">Record Performance Feedback</h2>
              <p className="text-xs text-slate-500">Commendation, 360° peer review, or coaching note</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {error && (
          <div className="mx-6 mt-4 p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Recipient Staff Member *
              </label>
              <select
                value={staffId}
                onChange={(e) => setStaffId(e.target.value)}
                className="w-full text-xs p-2.5 border border-slate-200 rounded-xl bg-white focus:ring-2 focus:ring-indigo-500 focus:outline-hidden font-medium"
                required
              >
                {staffList.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.displayName} ({s.employeeCode})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Feedback Type *
              </label>
              <select
                value={feedbackType}
                onChange={(e) => setFeedbackType(e.target.value as FeedbackType)}
                className="w-full text-xs p-2.5 border border-slate-200 rounded-xl bg-white focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
              >
                <option value="COMMENDATION">Formal Commendation / Praise</option>
                <option value="PEER_REVIEW">Peer Evaluation</option>
                <option value="360_FEEDBACK">360° Multi-Rater Feedback</option>
                <option value="COACHING_NOTE">Supervisor Coaching Note</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Feedback Remarks / Incident Detail *
            </label>
            <textarea
              rows={3}
              value={comments}
              onChange={(e) => setComments(e.target.value)}
              placeholder="Highlight exceptional work, exemplary student support, or developmental guidance..."
              className="w-full text-xs p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
              required
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Observed Strengths
              </label>
              <input
                type="text"
                value={strengths}
                onChange={(e) => setStrengths(e.target.value)}
                placeholder="Dedication, teamwork, patience..."
                className="w-full text-xs p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Suggested Growth Opportunities
              </label>
              <input
                type="text"
                value={areasForImprovement}
                onChange={(e) => setAreasForImprovement(e.target.value)}
                placeholder="Time management, proactive updates..."
                className="w-full text-xs p-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
              />
            </div>
          </div>

          <div className="flex items-center justify-between pt-2">
            <label className="flex items-center gap-2 text-xs text-slate-700 font-medium cursor-pointer">
              <input
                type="checkbox"
                checked={isAnonymous}
                onChange={(e) => setIsAnonymous(e.target.checked)}
                className="w-4 h-4 text-indigo-600 rounded border-slate-300"
              />
              <span>Submit anonymously to recipient</span>
            </label>

            <div className="flex items-center gap-2">
              <label className="text-xs font-bold text-slate-700">Rating:</label>
              <select
                value={rating}
                onChange={(e) => setRating(Number(e.target.value))}
                className="text-xs p-1.5 border border-slate-200 rounded-lg bg-white"
              >
                <option value={5}>5 - Outstanding</option>
                <option value={4}>4 - Commendable</option>
                <option value={3}>3 - Satisfactory</option>
                <option value={2}>2 - Marginal</option>
                <option value={1}>1 - Unsatisfactory</option>
              </select>
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-slate-200">
            <Button type="button" variant="outline" size="sm" onClick={onClose}>
              Cancel
            </Button>
            <Button
              type="submit"
              variant="primary"
              size="sm"
              loading={isSubmitting}
              icon={<Plus className="w-4 h-4" />}
            >
              Record Feedback
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};
