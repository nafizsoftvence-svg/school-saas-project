import React, { useState } from 'react';
import {
  X,
  User,
  Building,
  Briefcase,
  Phone,
  Mail,
  Calendar,
  Award,
  Shield,
  FileText,
  Clock,
  ExternalLink,
  GraduationCap,
  MapPin,
  HeartPulse,
  History,
  CheckCircle2,
  AlertCircle,
  Key
} from 'lucide-react';
import { Button } from '../../../components/ui/Button.js';
import { StaffProfile, StaffDocument, StaffStatusHistoryEntry } from '../../../types/index.js';

interface StaffProfileModalProps {
  staff: (StaffProfile & { teacherDetails?: any }) | null;
  isOpen: boolean;
  onClose: () => void;
  onEdit: (staff: StaffProfile) => void;
  onChangeStatus: (staff: StaffProfile) => void;
  onManageDocuments: (staff: StaffProfile) => void;
  onManageAccount: (staff: StaffProfile) => void;
}

export const StaffProfileModal: React.FC<StaffProfileModalProps> = ({
  staff,
  isOpen,
  onClose,
  onEdit,
  onChangeStatus,
  onManageDocuments,
  onManageAccount
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'employment' | 'documents' | 'history' | 'academic'>('overview');

  if (!isOpen || !staff) return null;

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span> Active
          </span>
        );
      case 'on_leave':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-50 text-amber-700 border border-amber-200">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-500"></span> On Leave
          </span>
        );
      case 'probation':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-200">
            <span className="w-1.5 h-1.5 rounded-full bg-blue-500"></span> Probationary
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-100 text-slate-700 border border-slate-300">
            <span className="w-1.5 h-1.5 rounded-full bg-slate-400"></span> {(status || '').replace(/_/g, ' ')}
          </span>
        );
    }
  };

  const getStaffTypeBadge = (type: string) => {
    switch (type) {
      case 'teaching':
        return <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200">Teaching Faculty</span>;
      case 'administrative':
        return <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-purple-50 text-purple-700 border border-purple-200">Administrative</span>;
      case 'support':
        return <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-cyan-50 text-cyan-700 border border-cyan-200">Campus Support</span>;
      case 'management':
        return <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-amber-50 text-amber-700 border border-amber-200">Executive Management</span>;
      case 'operational':
        return <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">Operational</span>;
      default:
        return <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-slate-100 text-slate-700">{type}</span>;
    }
  };

  const documents = staff.documents || [];
  const statusHistory = staff.statusHistory || [];
  const teacherDetails = staff.teacherDetails;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto"
      id="staff-profile-modal-overlay"
    >
      <div
        className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-4xl overflow-hidden my-8"
        id="staff-profile-modal-container"
      >
        {/* Dossier Header */}
        <div className="px-6 py-5 bg-gradient-to-r from-slate-900 to-slate-800 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <img
              src={staff.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=256'}
              alt={staff.displayName}
              className="w-16 h-16 rounded-xl object-cover border-2 border-white/20 shadow-md shrink-0"
            />
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="text-lg font-bold text-white tracking-tight">
                  {staff.displayName}
                </h2>
                <span className="px-2 py-0.5 rounded bg-white/10 text-white font-mono text-xs border border-white/10">
                  {staff.employeeCode}
                </span>
                {getStatusBadge(staff.employmentStatus)}
              </div>
              <div className="flex flex-wrap items-center gap-2 mt-1.5 text-xs text-slate-300">
                <span className="font-medium text-white">{staff.designation}</span>
                <span>•</span>
                <span>{staff.departmentName}</span>
                <span>•</span>
                {getStaffTypeBadge(staff.staffType)}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 self-end sm:self-center">
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Dossier Nav Tabs */}
        <div className="flex border-b border-slate-200 bg-slate-50/60 px-6 gap-2 overflow-x-auto">
          <button
            type="button"
            onClick={() => setActiveTab('overview')}
            className={`py-3 px-3 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap ${
              activeTab === 'overview'
                ? 'border-indigo-600 text-indigo-700'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            Overview & Demographics
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('employment')}
            className={`py-3 px-3 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap ${
              activeTab === 'employment'
                ? 'border-indigo-600 text-indigo-700'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            Employment Terms & Location
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('documents')}
            className={`py-3 px-3 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'documents'
                ? 'border-indigo-600 text-indigo-700'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <span>Credentials & Documents</span>
            <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-slate-200 text-slate-700">
              {documents.length}
            </span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('history')}
            className={`py-3 px-3 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'history'
                ? 'border-indigo-600 text-indigo-700'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <span>Status Transition Trail</span>
            <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-slate-200 text-slate-700">
              {statusHistory.length}
            </span>
          </button>
          {teacherDetails && (
            <button
              type="button"
              onClick={() => setActiveTab('academic')}
              className={`py-3 px-3 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap flex items-center gap-1.5 ${
                activeTab === 'academic'
                  ? 'border-indigo-600 text-indigo-700'
                  : 'border-transparent text-slate-600 hover:text-slate-900'
              }`}
            >
              <GraduationCap className="w-3.5 h-3.5" />
              <span>Teaching Allocation</span>
            </button>
          )}
        </div>

        {/* Dossier Body */}
        <div className="p-6 max-h-[65vh] overflow-y-auto space-y-6">
          {/* TAB 1: Overview */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Contact and Emergency Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 bg-slate-50/70 rounded-xl border border-slate-200 space-y-3">
                  <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                    <Phone className="w-3.5 h-3.5 text-indigo-600" /> Direct Contact Channels
                  </h4>
                  <div className="space-y-2 text-xs text-slate-700">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-500">Official Email:</span>
                      <a href={`mailto:${staff.email}`} className="font-semibold text-indigo-600 hover:underline">
                        {staff.email}
                      </a>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-500">Phone Number:</span>
                      <span className="font-semibold text-slate-800">{staff.phone}</span>
                    </div>
                    <div className="flex items-start justify-between">
                      <span className="text-slate-500">Campus / Address:</span>
                      <span className="font-medium text-slate-800 text-right max-w-[220px]">
                        {staff.currentAddress || 'Main Campus'}, {staff.city || ''} {staff.state || ''} {staff.country || 'USA'}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-slate-50/70 rounded-xl border border-slate-200 space-y-3">
                  <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                    <HeartPulse className="w-3.5 h-3.5 text-red-500" /> Emergency Contact
                  </h4>
                  <div className="space-y-2 text-xs text-slate-700">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-500">Primary Contact:</span>
                      <span className="font-semibold text-slate-800">
                        {staff.emergencyContactName || 'Not configured'}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-500">Emergency Phone:</span>
                      <span className="font-semibold text-slate-800">
                        {staff.emergencyContactPhone || 'Not configured'}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-500">Relationship:</span>
                      <span className="font-medium text-slate-800">
                        {staff.emergencyContactRelation || 'Not specified'}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Personal Demographics */}
              <div className="p-4 bg-white rounded-xl border border-slate-200 space-y-3">
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-indigo-600" /> Personal Identity & Records
                </h4>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
                  <div>
                    <span className="text-slate-500 block text-[11px]">Gender</span>
                    <span className="font-semibold text-slate-800 capitalize">{staff.gender}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[11px]">Date of Birth</span>
                    <span className="font-semibold text-slate-800">{staff.dateOfBirth || 'N/A'}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[11px]">Blood Group</span>
                    <span className="font-semibold text-slate-800">{staff.bloodGroup || 'N/A'}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[11px]">Nationality</span>
                    <span className="font-semibold text-slate-800">{staff.nationality || 'American'}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[11px]">National ID / SSN</span>
                    <span className="font-semibold text-slate-800 font-mono">{staff.nationalIdNumber || 'N/A'}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[11px]">Passport Number</span>
                    <span className="font-semibold text-slate-800 font-mono">{staff.passportNumber || 'N/A'}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[11px]">Marital Status</span>
                    <span className="font-semibold text-slate-800 capitalize">{staff.maritalStatus || 'N/A'}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[11px]">Work Shift</span>
                    <span className="font-semibold text-slate-800 capitalize">{staff.workShift || 'General'}</span>
                  </div>
                </div>
              </div>

              {/* Qualifications & Experience */}
              <div className="p-4 bg-white rounded-xl border border-slate-200 space-y-3">
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                  <Award className="w-3.5 h-3.5 text-amber-500" /> Professional Credentials
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
                  <div>
                    <span className="text-slate-500 block text-[11px]">Highest Degree</span>
                    <span className="font-semibold text-slate-800">{staff.qualification || 'Bachelor Degree'}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[11px]">Specialization</span>
                    <span className="font-semibold text-slate-800">{staff.specialization || 'General Studies'}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[11px]">Total Experience</span>
                    <span className="font-semibold text-slate-800">{staff.yearsOfExperience || 0} Years</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: Employment */}
          {activeTab === 'employment' && (
            <div className="space-y-4">
              <div className="p-4 bg-slate-50/70 rounded-xl border border-slate-200 space-y-4">
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  Contractual Terms & Placement
                </h4>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 text-xs">
                  <div>
                    <span className="text-slate-500 block text-[11px]">Employment Type</span>
                    <span className="font-semibold text-slate-800 capitalize">{(staff.employmentType || 'full_time').replace(/_/g, ' ')}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[11px]">Employment Status</span>
                    <span className="font-semibold text-slate-800 capitalize">{(staff.employmentStatus || 'active').replace(/_/g, ' ')}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[11px]">Official Joining Date</span>
                    <span className="font-semibold text-slate-800">{staff.joiningDate}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[11px]">Confirmation Date</span>
                    <span className="font-semibold text-slate-800">{staff.confirmationDate || 'Not specified'}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[11px]">Contract Expiration</span>
                    <span className="font-semibold text-slate-800">{staff.contractEndDate || 'Continuous / Indefinite'}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[11px]">Primary Location</span>
                    <span className="font-semibold text-slate-800">{staff.workLocation || 'Main Campus'}</span>
                  </div>
                </div>
              </div>

              {/* Linked System Account */}
              <div className="p-4 bg-white rounded-xl border border-slate-200 flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                    <Key className="w-3.5 h-3.5 text-indigo-600" /> System Authentication Status
                  </h4>
                  <p className="text-xs text-slate-600 mt-1">
                    {staff.hasAccount ? (
                      <span>
                        Active user login provisioned as <strong className="text-slate-900 font-mono">{staff.username}</strong> ({staff.accountRole}).
                      </span>
                    ) : (
                      <span>No login account linked to this staff profile.</span>
                    )}
                  </p>
                </div>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => onManageAccount(staff)}
                >
                  {staff.hasAccount ? 'Manage Account' : 'Provision Account'}
                </Button>
              </div>
            </div>
          )}

          {/* TAB 3: Documents */}
          {activeTab === 'documents' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-500">
                  {documents.length} official document(s) registered
                </span>
                <Button
                  type="button"
                  variant="primary"
                  size="sm"
                  onClick={() => onManageDocuments(staff)}
                >
                  Manage & Upload Documents
                </Button>
              </div>

              {documents.length === 0 ? (
                <div className="text-center py-8 border-2 border-dashed border-slate-200 rounded-xl">
                  <FileText className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                  <p className="text-xs font-medium text-slate-600">No documents attached yet.</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {documents.map((doc) => (
                    <div
                      key={doc.id}
                      className="p-3 bg-slate-50/70 rounded-xl border border-slate-200 flex items-center justify-between"
                    >
                      <div className="flex items-center gap-3">
                        <FileText className="w-5 h-5 text-indigo-600" />
                        <div>
                          <h5 className="text-xs font-semibold text-slate-900">{doc.title}</h5>
                          <span className="text-[11px] text-slate-500">
                            {doc.category} • Uploaded {new Date(doc.uploadedAt).toLocaleDateString()}
                          </span>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                          {doc.verificationStatus}
                        </span>
                        <a
                          href={doc.fileUrl}
                          target="_blank"
                          rel="noreferrer"
                          className="p-1.5 rounded-md hover:bg-slate-200 text-slate-600 text-xs inline-flex items-center gap-1"
                        >
                          <ExternalLink className="w-3.5 h-3.5" />
                        </a>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 4: Status History */}
          {activeTab === 'history' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-500">
                  Audit trail of employment status transitions
                </span>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => onChangeStatus(staff)}
                >
                  Change Status
                </Button>
              </div>

              {statusHistory.length === 0 ? (
                <div className="text-center py-8 border-2 border-dashed border-slate-200 rounded-xl">
                  <History className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                  <p className="text-xs font-medium text-slate-600">No previous status transitions recorded.</p>
                </div>
              ) : (
                <div className="space-y-3 relative before:absolute before:left-3.5 before:top-3 before:bottom-3 before:w-0.5 before:bg-slate-200">
                  {statusHistory.map((item, idx) => (
                    <div key={item.id || idx} className="flex items-start gap-4 relative pl-8">
                      <div className="w-3 h-3 rounded-full bg-indigo-600 ring-4 ring-white absolute left-2 top-1.5"></div>
                      <div className="flex-1 p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-semibold text-slate-900 capitalize">
                            {item.previousStatus} &rarr; {item.newStatus}
                          </span>
                          <span className="text-[11px] text-slate-500 font-mono">
                            {item.effectiveDate || new Date(item.timestamp).toLocaleDateString()}
                          </span>
                        </div>
                        <p className="text-xs text-slate-700">{item.reason}</p>
                        {item.notes && (
                          <p className="text-[11px] text-slate-500 italic">Note: {item.notes}</p>
                        )}
                        <span className="text-[10px] text-slate-400 block pt-1">
                          Authorized by {item.changedByName || 'Administrator'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 5: Teaching Allocation */}
          {activeTab === 'academic' && teacherDetails && (
            <div className="space-y-4">
              <div className="p-4 bg-indigo-50/60 rounded-xl border border-indigo-200">
                <h4 className="text-xs font-bold text-indigo-950 uppercase tracking-wider flex items-center gap-1.5 mb-3">
                  <GraduationCap className="w-4 h-4 text-indigo-700" /> Teaching Faculty Load
                </h4>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-3 bg-white rounded-lg border border-indigo-100">
                    <span className="text-xs font-semibold text-slate-800 block mb-2">
                      Assigned Classes & Sections ({teacherDetails.assignedClasses?.length || 0})
                    </span>
                    {((teacherDetails?.assignedClasses?.length || 0) > 0) ? (
                      <div className="flex flex-wrap gap-1.5">
                        {(teacherDetails?.assignedClasses || []).map((c: any) => (
                          <span
                            key={c.id}
                            className="px-2 py-0.5 rounded text-[11px] font-medium bg-slate-100 text-slate-800"
                          >
                            {c.name}
                          </span>
                        ))}
                      </div>
                    ) : (
                      <span className="text-xs text-slate-400">No classes currently assigned.</span>
                    )}
                  </div>

                  <div className="p-3 bg-white rounded-lg border border-indigo-100">
                    <span className="text-xs font-semibold text-slate-800 block mb-2">
                      Assigned Subjects ({teacherDetails.assignedSubjects?.length || 0})
                    </span>
                    {((teacherDetails?.assignedSubjects?.length || 0) > 0) ? (
                      <div className="flex flex-wrap gap-1.5">
                        {(teacherDetails?.assignedSubjects || []).map((s: any) => (
                          <span
                            key={s.id}
                            className="px-2 py-0.5 rounded text-[11px] font-medium bg-indigo-50 text-indigo-700 border border-indigo-100"
                          >
                            {s.name} ({s.code})
                          </span>
                        ))}
                      </div>
                    ) : (
                      <span className="text-xs text-slate-400">No subjects currently assigned.</span>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Dossier Footer Actions */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-slate-200 bg-slate-50/80">
          <div className="flex items-center gap-2">
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => onEdit(staff)}
            >
              Edit Profile
            </Button>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => onChangeStatus(staff)}
            >
              Change Status
            </Button>
          </div>

          <Button type="button" variant="primary" size="sm" onClick={onClose}>
            Close Dossier
          </Button>
        </div>
      </div>
    </div>
  );
};
