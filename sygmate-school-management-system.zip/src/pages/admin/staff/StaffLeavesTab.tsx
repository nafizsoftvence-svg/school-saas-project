import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  FileSpreadsheet,
  Plus,
  Search,
  Filter,
  CheckCircle2,
  XCircle,
  Clock,
  Calendar,
  AlertCircle,
  Building,
  User,
  ShieldCheck,
  RefreshCw,
  FileCheck,
  Eye,
  Info,
  Sliders,
  FastForward,
  Download,
  Layers,
  History,
  BarChart3,
  Paperclip,
  Check,
  ChevronRight,
  TrendingUp,
  Percent,
  Briefcase
} from 'lucide-react';
import { Button } from '../../../components/ui/Button.js';
import { api } from '../../../services/api.js';
import {
  LeaveApplication,
  StaffProfile,
  Department,
  Designation,
  LeaveType,
  AcademicSession,
  StaffLeavePolicy,
  StaffLeaveBalance,
  StaffLeaveBalancesResponse,
  StaffLeaveTransaction,
  StaffLeaveReportsSummary,
  StaffLeaveApplicationPayload,
  ReviewStaffLeavePayload,
  CreateStaffLeavePolicyPayload
} from '../../../types/index.js';
import { StaffLeaveReviewModal } from './StaffLeaveReviewModal.js';
import { StaffLeaveApplyModal } from './StaffLeaveApplyModal.js';
import { StaffLeavePolicyModal } from './StaffLeavePolicyModal.js';
import { StaffLeaveAdjustModal } from './StaffLeaveAdjustModal.js';
import { StaffLeaveCarryForwardModal } from './StaffLeaveCarryForwardModal.js';

interface StaffLeavesTabProps {
  staffList: StaffProfile[];
  departments: Department[];
  designations?: Designation[];
}

type SubTab = 'applications' | 'balances' | 'policies' | 'ledger' | 'reports';

export const StaffLeavesTab: React.FC<StaffLeavesTabProps> = ({
  staffList,
  departments,
  designations = []
}) => {
  const [activeSubTab, setActiveSubTab] = useState<SubTab>('applications');
  const [academicSessions, setAcademicSessions] = useState<AcademicSession[]>([]);
  const [selectedSessionId, setSelectedSessionId] = useState<string>('');
  const [leaveTypes, setLeaveTypes] = useState<LeaveType[]>([]);

  // Feedback
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Modals state
  const [isApplyModalOpen, setIsApplyModalOpen] = useState<boolean>(false);
  const [isReviewModalOpen, setIsReviewModalOpen] = useState<boolean>(false);
  const [selectedAppForReview, setSelectedAppForReview] = useState<LeaveApplication | null>(null);
  const [isPolicyModalOpen, setIsPolicyModalOpen] = useState<boolean>(false);
  const [selectedPolicyForEdit, setSelectedPolicyForEdit] = useState<StaffLeavePolicy | null>(null);
  const [isAdjustModalOpen, setIsAdjustModalOpen] = useState<boolean>(false);
  const [adjustPreselectStaffId, setAdjustPreselectStaffId] = useState<string | undefined>(undefined);
  const [adjustPreselectLeaveTypeId, setAdjustPreselectLeaveTypeId] = useState<string | undefined>(undefined);
  const [isCarryForwardModalOpen, setIsCarryForwardModalOpen] = useState<boolean>(false);

  // 1. Applications subtab state
  const [leaves, setLeaves] = useState<LeaveApplication[]>([]);
  const [appStatusFilter, setAppStatusFilter] = useState<string>('ALL');
  const [appDeptFilter, setAppDeptFilter] = useState<string>('ALL');
  const [appStaffTypeFilter, setAppStaffTypeFilter] = useState<string>('ALL');
  const [appSearchQuery, setAppSearchQuery] = useState<string>('');

  // 2. Balances subtab state
  const [balancesResponse, setBalancesResponse] = useState<StaffLeaveBalancesResponse | null>(null);
  const [balDeptFilter, setBalDeptFilter] = useState<string>('ALL');
  const [balStaffTypeFilter, setBalStaffTypeFilter] = useState<string>('ALL');
  const [balTypeFilter, setBalTypeFilter] = useState<string>('ALL');
  const [balSearchQuery, setBalSearchQuery] = useState<string>('');

  // 3. Policies subtab state
  const [policies, setPolicies] = useState<StaffLeavePolicy[]>([]);

  // 4. Ledger subtab state
  const [ledgerTransactions, setLedgerTransactions] = useState<StaffLeaveTransaction[]>([]);
  const [ledgerTypeFilter, setLedgerTypeFilter] = useState<string>('ALL');
  const [ledgerSearchQuery, setLedgerSearchQuery] = useState<string>('');

  // 5. Reports subtab state
  const [reportsSummary, setReportsSummary] = useState<StaffLeaveReportsSummary | null>(null);

  // Auto-dismiss alerts
  useEffect(() => {
    if (successMessage) {
      const timer = setTimeout(() => setSuccessMessage(null), 4000);
      return () => clearTimeout(timer);
    }
  }, [successMessage]);

  // Initial metadata loader
  useEffect(() => {
    const initMeta = async () => {
      try {
        const [typesRes, sessionsRes] = await Promise.all([
          api.getLeaveTypes().catch(() => []),
          api.getAcademicSessions().catch(() => [])
        ]);
        const types = Array.isArray((typesRes as any)?.data) ? (typesRes as any).data : Array.isArray(typesRes) ? typesRes : [];
        const sessions = Array.isArray((sessionsRes as any)?.data) ? (sessionsRes as any).data : Array.isArray(sessionsRes) ? sessionsRes : [];
        setLeaveTypes(types);
        setAcademicSessions(sessions);
        if (sessions.length > 0) {
          const active = (sessions || []).find((s: AcademicSession) => s?.status === 'ACTIVE') || sessions?.[0];
          if (active) setSelectedSessionId(active.id);
        }
      } catch (err) {
        console.warn('Metadata load error in StaffLeavesTab:', err);
      }
    };
    initMeta();
  }, []);

  // Fetch Applications
  const fetchLeaves = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await api.staff.leaves.getAll({
        status: appStatusFilter !== 'ALL' ? appStatusFilter : undefined,
        departmentId: appDeptFilter !== 'ALL' ? appDeptFilter : undefined,
        staffType: appStaffTypeFilter !== 'ALL' ? appStaffTypeFilter : undefined,
        search: appSearchQuery || undefined
      });
      const leavesList = Array.isArray((data as any)?.data) ? (data as any).data : Array.isArray(data) ? data : [];
      setLeaves(leavesList);
    } catch (err: any) {
      setError(err.message || 'Failed to load staff leave applications.');
    } finally {
      setLoading(false);
    }
  }, [appStatusFilter, appDeptFilter, appStaffTypeFilter, appSearchQuery]);

  // Fetch Balances
  const fetchBalances = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await api.staff.leaves.getBalances({
        academicSessionId: selectedSessionId || undefined,
        departmentId: balDeptFilter !== 'ALL' ? balDeptFilter : undefined,
        staffType: balStaffTypeFilter !== 'ALL' ? balStaffTypeFilter : undefined,
        leaveTypeId: balTypeFilter !== 'ALL' ? balTypeFilter : undefined,
        search: balSearchQuery || undefined,
        limit: 50
      });
      setBalancesResponse((res as any)?.data || res);
    } catch (err: any) {
      setError(err.message || 'Failed to load staff leave balances.');
    } finally {
      setLoading(false);
    }
  }, [selectedSessionId, balDeptFilter, balStaffTypeFilter, balTypeFilter, balSearchQuery]);

  // Fetch Policies
  const fetchPolicies = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const list = await api.staff.leaves.getPolicies(selectedSessionId || undefined);
      const policiesList = Array.isArray((list as any)?.data) ? (list as any).data : Array.isArray(list) ? list : [];
      setPolicies(policiesList);
    } catch (err: any) {
      setError(err.message || 'Failed to load leave policies.');
    } finally {
      setLoading(false);
    }
  }, [selectedSessionId]);

  // Fetch Ledger
  const fetchLedger = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await api.staff.leaves.getLedger({
        academicSessionId: selectedSessionId || undefined,
        transactionType: ledgerTypeFilter !== 'ALL' ? (ledgerTypeFilter as any) : undefined,
        search: ledgerSearchQuery || undefined,
        limit: 50
      });
      const transactions = Array.isArray((res as any)?.data?.items)
        ? (res as any).data.items
        : Array.isArray((res as any)?.items)
        ? (res as any).items
        : Array.isArray((res as any)?.data)
        ? (res as any).data
        : Array.isArray(res)
        ? res
        : [];
      setLedgerTransactions(transactions);
    } catch (err: any) {
      setError(err.message || 'Failed to load leave transactions ledger.');
    } finally {
      setLoading(false);
    }
  }, [selectedSessionId, ledgerTypeFilter, ledgerSearchQuery]);

  // Fetch Reports
  const fetchReports = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const rep = await api.staff.leaves.getReportsSummary(selectedSessionId || undefined);
      setReportsSummary((rep as any)?.data || rep);
    } catch (err: any) {
      setError(err.message || 'Failed to load leave reports summary.');
    } finally {
      setLoading(false);
    }
  }, [selectedSessionId]);

  // Trigger load when activeSubTab or filters change
  useEffect(() => {
    if (activeSubTab === 'applications') fetchLeaves();
    else if (activeSubTab === 'balances') fetchBalances();
    else if (activeSubTab === 'policies') fetchPolicies();
    else if (activeSubTab === 'ledger') fetchLedger();
    else if (activeSubTab === 'reports') fetchReports();
  }, [activeSubTab, fetchLeaves, fetchBalances, fetchPolicies, fetchLedger, fetchReports]);

  // Handle Application Actions
  const handleApplyLeave = async (payload: StaffLeaveApplicationPayload) => {
    await api.staff.leaves.apply(payload);
    setSuccessMessage('Staff leave application submitted successfully with policy validation.');
    if (activeSubTab === 'applications') fetchLeaves();
    else if (activeSubTab === 'balances') fetchBalances();
  };

  const handleReviewApplication = async (id: string, payload: ReviewStaffLeavePayload) => {
    await api.staff.leaves.review(id, payload);
    setSuccessMessage(
      `Leave application ${payload.status.toLowerCase()} successfully. Attendance and balance ledgers updated.`
    );
    fetchLeaves();
  };

  const handleCancelApplication = async (id: string) => {
    if (!window.confirm('Are you sure you want to cancel this leave application? Approved leaves will be refunded to the employee balance.')) {
      return;
    }
    try {
      await api.staff.leaves.cancel(id, 'Cancelled via administrator control panel');
      setSuccessMessage('Leave application cancelled and balances/attendance reversed successfully.');
      fetchLeaves();
    } catch (err: any) {
      setError(err.message || 'Failed to cancel leave application.');
    }
  };

  // Handle Policy Actions
  const handleSavePolicy = async (payload: CreateStaffLeavePolicyPayload, policyId?: string) => {
    if (policyId) {
      await api.staff.leaves.updatePolicy(policyId, payload);
      setSuccessMessage(`Policy '${payload.name}' updated successfully.`);
    } else {
      await api.staff.leaves.createPolicy(payload);
      setSuccessMessage(`Policy '${payload.name}' created successfully.`);
    }
    fetchPolicies();
  };

  const handleDeletePolicy = async (id: string, name: string) => {
    if (!window.confirm(`Are you sure you want to delete policy '${name}'?`)) return;
    try {
      await api.staff.leaves.deletePolicy(id);
      setSuccessMessage(`Policy '${name}' deleted successfully.`);
      fetchPolicies();
    } catch (err: any) {
      setError(err.message || 'Failed to delete policy.');
    }
  };

  // Export Balances CSV
  const handleExportCSV = () => {
    const q = new URLSearchParams();
    if (selectedSessionId) q.append('academicSessionId', selectedSessionId);
    if (balDeptFilter !== 'ALL') q.append('departmentId', balDeptFilter);
    if (balStaffTypeFilter !== 'ALL') q.append('staffType', balStaffTypeFilter);
    if (balTypeFilter !== 'ALL') q.append('leaveTypeId', balTypeFilter);
    if (balSearchQuery) q.append('search', balSearchQuery);
    window.location.href = `/api/staff/leaves/export/balances?${q.toString()}`;
  };

  // Status Badge Helper
  const renderStatusBadge = (status: string, currentTier?: number, totalTiers?: number) => {
    switch (status) {
      case 'PENDING':
      case 'SUBMITTED':
        return (
          <span className="px-2.5 py-1 rounded-lg text-xs font-bold bg-amber-500/10 text-amber-300 border border-amber-500/20 flex items-center gap-1.5 w-fit">
            <Clock className="w-3.5 h-3.5" />
            Pending Review
          </span>
        );
      case 'PARTIALLY_APPROVED':
        return (
          <span className="px-2.5 py-1 rounded-lg text-xs font-bold bg-indigo-500/15 text-indigo-300 border border-indigo-500/30 flex items-center gap-1.5 w-fit">
            <ShieldCheck className="w-3.5 h-3.5 text-indigo-400" />
            Tier 1 Approved (Pending HR)
          </span>
        );
      case 'APPROVED':
        return (
          <span className="px-2.5 py-1 rounded-lg text-xs font-bold bg-emerald-500/10 text-emerald-300 border border-emerald-500/20 flex items-center gap-1.5 w-fit">
            <CheckCircle2 className="w-3.5 h-3.5" />
            Final Approved
          </span>
        );
      case 'REJECTED':
        return (
          <span className="px-2.5 py-1 rounded-lg text-xs font-bold bg-rose-500/10 text-rose-300 border border-rose-500/20 flex items-center gap-1.5 w-fit">
            <XCircle className="w-3.5 h-3.5" />
            Declined
          </span>
        );
      case 'CANCELLED':
        return (
          <span className="px-2.5 py-1 rounded-lg text-xs font-bold bg-slate-500/10 text-slate-400 border border-slate-500/20 flex items-center gap-1.5 w-fit">
            Cancelled
          </span>
        );
      default:
        return (
          <span className="px-2.5 py-1 rounded-lg text-xs font-bold bg-slate-800 text-slate-300 border border-white/10 w-fit">
            {status}
          </span>
        );
    }
  };

  // Transaction Badge Helper
  const renderTxBadge = (type: string) => {
    switch (type) {
      case 'ENTITLEMENT':
        return <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-blue-500/10 text-blue-300 border border-blue-500/20">Entitlement</span>;
      case 'CARRY_FORWARD':
        return <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-teal-500/10 text-teal-300 border border-teal-500/20">Carry Forward</span>;
      case 'LEAVE_DEDUCTION':
        return <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-purple-500/10 text-purple-300 border border-purple-500/20">Used (Leave)</span>;
      case 'LEAVE_REVERSAL':
        return <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-emerald-500/10 text-emerald-300 border border-emerald-500/20">Reversal</span>;
      case 'ADJUSTMENT_ADD':
        return <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-emerald-500/10 text-emerald-300 border border-emerald-500/20">Credit (+ Adj)</span>;
      case 'ADJUSTMENT_DEDUCT':
        return <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-rose-500/10 text-rose-300 border border-rose-500/20">Debit (- Adj)</span>;
      case 'EXPIRED':
        return <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-slate-500/10 text-slate-400 border border-slate-500/20">Expired</span>;
      default:
        return <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-slate-800 text-slate-300">{type}</span>;
    }
  };

  return (
    <div id="staff-leave-management-hub" className="space-y-6">
      {/* Top Banner & Context Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900/60 p-5 rounded-2xl border border-white/10 backdrop-blur-sm">
        <div>
          <div className="flex items-center gap-2 text-indigo-400 font-semibold text-xs uppercase tracking-wider">
            <ShieldCheck className="w-4 h-4" />
            Human Resources & Governance
          </div>
          <h1 className="text-xl font-bold text-white tracking-tight mt-1">
            Staff Leave Policies, Balances & Multi-Tier Approvals
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Enterprise leave entitlement ledger, policy rule resolution, and automated attendance integration
          </p>
        </div>

        {/* Academic Session Selector & Global Primary Action */}
        <div className="flex flex-wrap items-center gap-3">
          {academicSessions.length > 0 && (
            <div className="flex items-center gap-2 bg-slate-800/80 px-3 py-1.5 rounded-xl border border-white/10 text-xs text-slate-300">
              <Calendar className="w-4 h-4 text-indigo-400" />
              <span>Session:</span>
              <select
                value={selectedSessionId}
                onChange={(e) => setSelectedSessionId(e.target.value)}
                className="bg-transparent text-white font-semibold focus:outline-none cursor-pointer"
              >
                {academicSessions.map((s) => (
                  <option key={s.id} value={s.id} className="bg-slate-900 text-white">
                    {s.name}
                  </option>
                ))}
              </select>
            </div>
          )}

          <Button
            onClick={() => setIsApplyModalOpen(true)}
            className="bg-indigo-600 hover:bg-indigo-500 text-white flex items-center gap-2 text-xs font-semibold px-4 py-2"
          >
            <Plus className="w-4 h-4" />
            Apply Leave
          </Button>
        </div>
      </div>

      {/* Alert Messages */}
      {successMessage && (
        <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 flex items-center gap-3 text-sm animate-fade-in">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <span>{successMessage}</span>
        </div>
      )}

      {error && (
        <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-300 flex items-center gap-3 text-sm animate-fade-in">
          <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Navigation Sub-Tabs */}
      <div className="flex items-center gap-2 border-b border-white/10 pb-2 overflow-x-auto text-sm">
        <button
          onClick={() => setActiveSubTab('applications')}
          className={`px-4 py-2 rounded-xl font-bold flex items-center gap-2 transition-all whitespace-nowrap ${
            activeSubTab === 'applications'
              ? 'bg-indigo-600/20 text-indigo-300 border border-indigo-500/30'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <FileCheck className="w-4 h-4" />
          Leave Applications ({leaves?.length || 0})
        </button>

        <button
          onClick={() => setActiveSubTab('balances')}
          className={`px-4 py-2 rounded-xl font-bold flex items-center gap-2 transition-all whitespace-nowrap ${
            activeSubTab === 'balances'
              ? 'bg-indigo-600/20 text-indigo-300 border border-indigo-500/30'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Layers className="w-4 h-4" />
          Leave Balances & Entitlements
        </button>

        <button
          onClick={() => setActiveSubTab('policies')}
          className={`px-4 py-2 rounded-xl font-bold flex items-center gap-2 transition-all whitespace-nowrap ${
            activeSubTab === 'policies'
              ? 'bg-indigo-600/20 text-indigo-300 border border-indigo-500/30'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <ShieldCheck className="w-4 h-4" />
          Leave Policies
        </button>

        <button
          onClick={() => setActiveSubTab('ledger')}
          className={`px-4 py-2 rounded-xl font-bold flex items-center gap-2 transition-all whitespace-nowrap ${
            activeSubTab === 'ledger'
              ? 'bg-indigo-600/20 text-indigo-300 border border-indigo-500/30'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <History className="w-4 h-4" />
          Transaction Ledger
        </button>

        <button
          onClick={() => setActiveSubTab('reports')}
          className={`px-4 py-2 rounded-xl font-bold flex items-center gap-2 transition-all whitespace-nowrap ${
            activeSubTab === 'reports'
              ? 'bg-indigo-600/20 text-indigo-300 border border-indigo-500/30'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <BarChart3 className="w-4 h-4" />
          Reports & Analytics
        </button>
      </div>

      {/* =========================================================================
          VIEW 1: LEAVE APPLICATIONS
          ========================================================================= */}
      {activeSubTab === 'applications' && (
        <div className="space-y-4">
          {/* Quick Metrics */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="p-4 rounded-xl bg-slate-900/60 border border-white/10 flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
                <Clock className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[11px] text-slate-400 uppercase font-semibold">Pending Review</span>
                <h4 className="text-xl font-bold text-white font-mono">
                  {leaves.filter((l) => l.status === 'PENDING' || l.status === 'SUBMITTED' || l.status === 'PARTIALLY_APPROVED').length}
                </h4>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-slate-900/60 border border-white/10 flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
                <CheckCircle2 className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[11px] text-slate-400 uppercase font-semibold">Approved Requests</span>
                <h4 className="text-xl font-bold text-white font-mono">
                  {leaves.filter((l) => l.status === 'APPROVED').length}
                </h4>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-slate-900/60 border border-white/10 flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center font-bold">
                <XCircle className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[11px] text-slate-400 uppercase font-semibold">Declined Requests</span>
                <h4 className="text-xl font-bold text-white font-mono">
                  {leaves.filter((l) => l.status === 'REJECTED').length}
                </h4>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-slate-900/60 border border-white/10 flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center font-bold">
                <Calendar className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[11px] text-slate-400 uppercase font-semibold">Working Days Utilized</span>
                <h4 className="text-xl font-bold text-white font-mono">
                  {leaves
                    .filter((l) => l.status === 'APPROVED')
                    .reduce((acc, curr) => acc + (curr.workingDays ?? curr.totalDays ?? 1), 0)}
                </h4>
              </div>
            </div>
          </div>

          {/* Filter Bar */}
          <div className="flex flex-wrap items-center gap-3 bg-slate-900/40 p-4 rounded-xl border border-white/5">
            <div className="flex-1 min-w-[200px] relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={appSearchQuery}
                onChange={(e) => setAppSearchQuery(e.target.value)}
                placeholder="Search by staff name, code, reason..."
                className="w-full pl-9 pr-3 py-2 bg-slate-800/80 border border-white/10 rounded-lg text-xs text-white placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
            </div>

            <select
              value={appStatusFilter}
              onChange={(e) => setAppStatusFilter(e.target.value)}
              className="px-3 py-2 bg-slate-800/80 border border-white/10 rounded-lg text-xs text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
            >
              <option value="ALL">All Statuses</option>
              <option value="PENDING">Pending Review</option>
              <option value="PARTIALLY_APPROVED">Partially Approved (Tier 1)</option>
              <option value="APPROVED">Approved</option>
              <option value="REJECTED">Declined</option>
              <option value="CANCELLED">Cancelled</option>
            </select>

            <select
              value={appDeptFilter}
              onChange={(e) => setAppDeptFilter(e.target.value)}
              className="px-3 py-2 bg-slate-800/80 border border-white/10 rounded-lg text-xs text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
            >
              <option value="ALL">All Departments</option>
              {departments.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name}
                </option>
              ))}
            </select>

            <select
              value={appStaffTypeFilter}
              onChange={(e) => setAppStaffTypeFilter(e.target.value)}
              className="px-3 py-2 bg-slate-800/80 border border-white/10 rounded-lg text-xs text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
            >
              <option value="ALL">All Categories</option>
              <option value="teaching">Teaching Staff</option>
              <option value="administrative">Administrative Staff</option>
              <option value="support">Support Staff</option>
            </select>

            <Button
              variant="outline"
              onClick={fetchLeaves}
              disabled={loading}
              className="px-3 py-2 text-xs flex items-center gap-1.5"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
          </div>

          {/* Applications Table */}
          <div className="overflow-x-auto rounded-xl border border-white/10 bg-slate-900/60">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-white/10 bg-slate-800/50 text-slate-400 font-semibold uppercase tracking-wider">
                  <th className="py-3 px-4">Staff Member</th>
                  <th className="py-3 px-4">Department / Role</th>
                  <th className="py-3 px-4">Leave Category</th>
                  <th className="py-3 px-4">Duration & Dates</th>
                  <th className="py-3 px-4">Working Days</th>
                  <th className="py-3 px-4">Status & Tier</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 text-slate-200">
                {leaves.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="text-center py-10 text-slate-400">
                      No staff leave applications matching the selected criteria.
                    </td>
                  </tr>
                ) : (
                  leaves.map((app) => (
                    <tr key={app.id} className="hover:bg-white/[0.02] transition-colors">
                      <td className="py-3 px-4">
                        <div className="font-bold text-white">{app.applicantName}</div>
                        <div className="text-[11px] text-slate-400 font-mono">{app.employeeCode || 'STAFF'}</div>
                      </td>

                      <td className="py-3 px-4">
                        <div>{app.departmentName || 'General'}</div>
                        <div className="text-[11px] text-slate-400 capitalize">{app.staffType || 'staff'}</div>
                      </td>

                      <td className="py-3 px-4">
                        <span className="font-medium text-indigo-300">{app.leaveTypeName}</span>
                        {app.attachmentUrl && (
                          <a
                            href={app.attachmentUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center gap-1 text-[11px] text-indigo-400 hover:underline mt-0.5"
                          >
                            <Paperclip className="w-3 h-3" />
                            Doc Attached
                          </a>
                        )}
                      </td>

                      <td className="py-3 px-4">
                        <div className="font-medium">
                          {app.startDate} {app.endDate && app.endDate !== app.startDate ? `→ ${app.endDate}` : ''}
                        </div>
                        <div className="text-[11px] text-slate-400 italic truncate max-w-xs" title={app.reason}>
                          "{app.reason}"
                        </div>
                      </td>

                      <td className="py-3 px-4">
                        <span className="font-mono font-bold text-white bg-slate-800 px-2 py-0.5 rounded border border-white/10">
                          {app.workingDays !== undefined ? app.workingDays : app.totalDays || 1} d
                        </span>
                      </td>

                      <td className="py-3 px-4">
                        {renderStatusBadge(app.status, app.currentApprovalTier, app.totalApprovalTiers)}
                      </td>

                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {['PENDING', 'SUBMITTED', 'UNDER_REVIEW', 'PARTIALLY_APPROVED'].includes(app.status) && (
                            <Button
                              size="sm"
                              onClick={() => {
                                setSelectedAppForReview(app);
                                setIsReviewModalOpen(true);
                              }}
                              className="bg-purple-600 hover:bg-purple-500 text-white text-xs px-2.5 py-1 flex items-center gap-1"
                            >
                              <FileCheck className="w-3.5 h-3.5" />
                              Review
                            </Button>
                          )}

                          {app.status !== 'CANCELLED' && app.status !== 'REJECTED' && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleCancelApplication(app.id)}
                              className="border-white/10 hover:border-rose-500/40 text-slate-400 hover:text-rose-300 text-xs px-2 py-1"
                              title="Cancel & Reverse Leave"
                            >
                              <XCircle className="w-3.5 h-3.5" />
                            </Button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* =========================================================================
          VIEW 2: LEAVE BALANCES & ENTITLEMENTS
          ========================================================================= */}
      {activeSubTab === 'balances' && (
        <div className="space-y-4">
          {/* Summary KPI Cards */}
          {balancesResponse && balancesResponse.summary && (
            <div className="grid grid-cols-2 md:grid-cols-6 gap-3">
              <div className="p-3.5 rounded-xl bg-slate-900/60 border border-white/10">
                <span className="text-[11px] text-slate-400 uppercase font-semibold block">Total Staff</span>
                <span className="text-lg font-bold text-white font-mono">{balancesResponse.summary.totalStaff}</span>
              </div>
              <div className="p-3.5 rounded-xl bg-slate-900/60 border border-white/10">
                <span className="text-[11px] text-slate-400 uppercase font-semibold block">Entitlement Pool</span>
                <span className="text-lg font-bold text-indigo-400 font-mono">{balancesResponse.summary.totalEntitlementDays} d</span>
              </div>
              <div className="p-3.5 rounded-xl bg-slate-900/60 border border-white/10">
                <span className="text-[11px] text-slate-400 uppercase font-semibold block">Carried Forward</span>
                <span className="text-lg font-bold text-teal-400 font-mono">{balancesResponse.summary.totalCarryForwardDays} d</span>
              </div>
              <div className="p-3.5 rounded-xl bg-slate-900/60 border border-white/10">
                <span className="text-[11px] text-slate-400 uppercase font-semibold block">Used Days</span>
                <span className="text-lg font-bold text-purple-400 font-mono">{balancesResponse.summary.totalUsedDays} d</span>
              </div>
              <div className="p-3.5 rounded-xl bg-slate-900/60 border border-white/10">
                <span className="text-[11px] text-slate-400 uppercase font-semibold block">Remaining Days</span>
                <span className="text-lg font-bold text-emerald-400 font-mono">{balancesResponse.summary.totalRemainingDays} d</span>
              </div>
              <div className="p-3.5 rounded-xl bg-slate-900/60 border border-white/10">
                <span className="text-[11px] text-slate-400 uppercase font-semibold block">Utilization Rate</span>
                <span className="text-lg font-bold text-amber-400 font-mono">{balancesResponse.summary.averageUtilizationRate}%</span>
              </div>
            </div>
          )}

          {/* Action Bar & Filters */}
          <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900/40 p-4 rounded-xl border border-white/5">
            <div className="flex flex-wrap items-center gap-3 flex-1">
              <div className="min-w-[180px] relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={balSearchQuery}
                  onChange={(e) => setBalSearchQuery(e.target.value)}
                  placeholder="Search staff or code..."
                  className="w-full pl-9 pr-3 py-2 bg-slate-800/80 border border-white/10 rounded-lg text-xs text-white placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
              </div>

              <select
                value={balDeptFilter}
                onChange={(e) => setBalDeptFilter(e.target.value)}
                className="px-3 py-2 bg-slate-800/80 border border-white/10 rounded-lg text-xs text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
              >
                <option value="ALL">All Departments</option>
                {departments.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.name}
                  </option>
                ))}
              </select>

              <select
                value={balStaffTypeFilter}
                onChange={(e) => setBalStaffTypeFilter(e.target.value)}
                className="px-3 py-2 bg-slate-800/80 border border-white/10 rounded-lg text-xs text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
              >
                <option value="ALL">All Categories</option>
                <option value="teaching">Teaching</option>
                <option value="administrative">Administrative</option>
                <option value="support">Support</option>
              </select>

              <select
                value={balTypeFilter}
                onChange={(e) => setBalTypeFilter(e.target.value)}
                className="px-3 py-2 bg-slate-800/80 border border-white/10 rounded-lg text-xs text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
              >
                <option value="ALL">All Leave Types</option>
                {leaveTypes.map((lt) => (
                  <option key={lt.id} value={lt.id}>
                    {lt.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                onClick={() => {
                  setAdjustPreselectStaffId(undefined);
                  setAdjustPreselectLeaveTypeId(undefined);
                  setIsAdjustModalOpen(true);
                }}
                className="text-xs border-amber-500/30 text-amber-300 hover:bg-amber-500/10 flex items-center gap-1.5"
              >
                <Sliders className="w-3.5 h-3.5" />
                Adjust Balance
              </Button>

              <Button
                variant="outline"
                onClick={() => setIsCarryForwardModalOpen(true)}
                className="text-xs border-teal-500/30 text-teal-300 hover:bg-teal-500/10 flex items-center gap-1.5"
              >
                <FastForward className="w-3.5 h-3.5" />
                Session Carry-Forward
              </Button>

              <Button
                variant="outline"
                onClick={handleExportCSV}
                className="text-xs border-white/10 text-slate-300 hover:bg-white/5 flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                Export CSV
              </Button>
            </div>
          </div>

          {/* Balances Table */}
          <div className="overflow-x-auto rounded-xl border border-white/10 bg-slate-900/60">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-white/10 bg-slate-800/50 text-slate-400 font-semibold uppercase tracking-wider">
                  <th className="py-3 px-4">Staff Member</th>
                  <th className="py-3 px-4">Leave Category</th>
                  <th className="py-3 px-4">Applied Policy</th>
                  <th className="py-3 px-4 text-center">Entitled</th>
                  <th className="py-3 px-4 text-center">Carried</th>
                  <th className="py-3 px-4 text-center">Adjusted</th>
                  <th className="py-3 px-4 text-center">Used</th>
                  <th className="py-3 px-4 text-center">Pending</th>
                  <th className="py-3 px-4 text-center">Remaining</th>
                  <th className="py-3 px-4 text-center font-bold text-white">Available</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 text-slate-200">
                {!balancesResponse || !Array.isArray(balancesResponse.items) || (balancesResponse.items?.length || 0) === 0 ? (
                  <tr>
                    <td colSpan={11} className="text-center py-10 text-slate-400">
                      No staff leave balance records found.
                    </td>
                  </tr>
                ) : (
                  (balancesResponse.items || []).map((bal) => (
                    <tr key={bal.id} className="hover:bg-white/[0.02] transition-colors">
                      <td className="py-3 px-4">
                        <div className="font-bold text-white">{bal.staffName}</div>
                        <div className="text-[11px] text-slate-400 font-mono">
                          {bal.employeeCode} • {bal.departmentName || bal.staffType}
                        </div>
                      </td>

                      <td className="py-3 px-4">
                        <span className="font-semibold text-indigo-300">{bal.leaveTypeName}</span>
                        <div className="text-[11px] text-slate-500 capitalize">{bal.paidType.toLowerCase()} leave</div>
                      </td>

                      <td className="py-3 px-4">
                        <span className="text-slate-300 truncate block max-w-[140px]" title={bal.policyName}>
                          {bal.policyName || 'System Default'}
                        </span>
                      </td>

                      <td className="py-3 px-4 text-center font-mono">{bal.entitlementDays}</td>
                      <td className="py-3 px-4 text-center font-mono text-teal-300">{bal.carryForwardDays > 0 ? `+${bal.carryForwardDays}` : '0'}</td>
                      <td className="py-3 px-4 text-center font-mono">
                        {bal.adjustmentsDays !== 0 ? (
                          <span className={bal.adjustmentsDays > 0 ? 'text-emerald-400' : 'text-rose-400'}>
                            {bal.adjustmentsDays > 0 ? `+${bal.adjustmentsDays}` : bal.adjustmentsDays}
                          </span>
                        ) : (
                          '0'
                        )}
                      </td>
                      <td className="py-3 px-4 text-center font-mono text-purple-300">{bal.usedDays}</td>
                      <td className="py-3 px-4 text-center font-mono text-amber-300">{bal.pendingDays > 0 ? bal.pendingDays : '0'}</td>
                      <td className="py-3 px-4 text-center font-mono font-bold text-emerald-400">{bal.remainingDays}</td>
                      <td className="py-3 px-4 text-center font-mono font-bold text-white bg-indigo-500/10 rounded">
                        {bal.availableDays}
                      </td>

                      <td className="py-3 px-4 text-right">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            setAdjustPreselectStaffId(bal.staffId);
                            setAdjustPreselectLeaveTypeId(bal.leaveTypeId);
                            setIsAdjustModalOpen(true);
                          }}
                          className="border-white/10 hover:border-amber-500/30 text-slate-300 hover:text-amber-300 text-xs px-2.5 py-1"
                        >
                          <Sliders className="w-3 h-3 mr-1" />
                          Adjust
                        </Button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* =========================================================================
          VIEW 3: LEAVE POLICIES
          ========================================================================= */}
      {activeSubTab === 'policies' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-white">Institutional Leave Policies</h3>
              <p className="text-xs text-slate-400">
                Rule configurations governing annual entitlements, carry-forward bounds, and approval tiers
              </p>
            </div>
            <Button
              onClick={() => {
                setSelectedPolicyForEdit(null);
                setIsPolicyModalOpen(true);
              }}
              className="bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold px-4 py-2 flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              Add Policy
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {policies.map((p) => (
              <div
                key={p.id}
                className="p-5 rounded-2xl bg-slate-900/60 border border-white/10 hover:border-indigo-500/30 transition-all space-y-4 relative flex flex-col justify-between"
              >
                <div className="space-y-3">
                  <div className="flex items-start justify-between">
                    <div>
                      <span className="text-[11px] font-mono text-indigo-400 font-bold bg-indigo-500/10 px-2 py-0.5 rounded border border-indigo-500/20">
                        {p.code}
                      </span>
                      <h4 className="text-base font-bold text-white mt-1.5 leading-snug">{p.name}</h4>
                      <p className="text-xs text-slate-400 mt-0.5">{p.leaveTypeName}</p>
                    </div>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        p.isActive
                          ? 'bg-emerald-500/10 text-emerald-300 border border-emerald-500/20'
                          : 'bg-slate-800 text-slate-500'
                      }`}
                    >
                      {p.isActive ? 'ACTIVE' : 'INACTIVE'}
                    </span>
                  </div>

                  {/* Scope Badges */}
                  <div className="flex flex-wrap gap-1.5 text-[11px]">
                    <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-white/5">
                      Scope: {p.applicableDesignationName || p.applicableDepartmentName || (p.applicableStaffCategory !== 'ALL' ? p.applicableStaffCategory : 'School-Wide')}
                    </span>
                    <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-white/5">
                      Tier: {p.approvalHierarchy === 'TWO_TIER' ? '2-Tier (Dept & HR)' : 'Single Tier'}
                    </span>
                    <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-white/5">
                      {p.paidType}
                    </span>
                  </div>

                  {/* Key Rules Matrix */}
                  <div className="p-3 rounded-xl bg-slate-800/40 border border-white/5 grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <span className="text-[11px] text-slate-400 block">Entitlement:</span>
                      <span className="font-bold text-white font-mono text-sm">{p.entitlementDays} days/yr</span>
                    </div>
                    <div>
                      <span className="text-[11px] text-slate-400 block">Carry-Forward:</span>
                      <span className="font-bold text-teal-300 font-mono">
                        {p.carryForwardAllowed ? `Max ${p.maxCarryForwardDays} d` : 'Disallowed'}
                      </span>
                    </div>
                    <div>
                      <span className="text-[11px] text-slate-400 block">Min Notice:</span>
                      <span className="font-medium text-slate-200">{p.minNoticeDays} days</span>
                    </div>
                    <div>
                      <span className="text-[11px] text-slate-400 block">Consecutive Cap:</span>
                      <span className="font-medium text-slate-200">{p.maxConsecutiveDays} days</span>
                    </div>
                  </div>

                  {p.notes && <p className="text-[11px] text-slate-400 italic">"{p.notes}"</p>}
                </div>

                <div className="flex items-center justify-end gap-2 pt-3 border-t border-white/10">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => {
                      setSelectedPolicyForEdit(p);
                      setIsPolicyModalOpen(true);
                    }}
                    className="text-xs px-3 py-1.5"
                  >
                    Edit Policy
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleDeletePolicy(p.id, p.name)}
                    className="text-xs px-3 py-1.5 border-rose-500/20 text-rose-400 hover:bg-rose-500/10"
                  >
                    Delete
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* =========================================================================
          VIEW 4: AUTHORITATIVE TRANSACTION LEDGER
          ========================================================================= */}
      {activeSubTab === 'ledger' && (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900/40 p-4 rounded-xl border border-white/5">
            <div className="flex-1 min-w-[200px] relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={ledgerSearchQuery}
                onChange={(e) => setLedgerSearchQuery(e.target.value)}
                placeholder="Search ledger by staff name, reason, performer..."
                className="w-full pl-9 pr-3 py-2 bg-slate-800/80 border border-white/10 rounded-lg text-xs text-white placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
            </div>

            <select
              value={ledgerTypeFilter}
              onChange={(e) => setLedgerTypeFilter(e.target.value)}
              className="px-3 py-2 bg-slate-800/80 border border-white/10 rounded-lg text-xs text-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
            >
              <option value="ALL">All Transaction Types</option>
              <option value="ENTITLEMENT">Entitlement</option>
              <option value="CARRY_FORWARD">Carry Forward</option>
              <option value="LEAVE_DEDUCTION">Leave Deduction</option>
              <option value="LEAVE_REVERSAL">Leave Reversal</option>
              <option value="ADJUSTMENT_ADD">Credit Adjustment</option>
              <option value="ADJUSTMENT_DEDUCT">Debit Adjustment</option>
              <option value="EXPIRED">Expired</option>
            </select>

            <Button
              variant="outline"
              onClick={fetchLedger}
              disabled={loading}
              className="px-3 py-2 text-xs flex items-center gap-1.5"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
              Refresh Ledger
            </Button>
          </div>

          <div className="overflow-x-auto rounded-xl border border-white/10 bg-slate-900/60">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-white/10 bg-slate-800/50 text-slate-400 font-semibold uppercase tracking-wider">
                  <th className="py-3 px-4">Date & Time</th>
                  <th className="py-3 px-4">Staff Member</th>
                  <th className="py-3 px-4">Leave Category</th>
                  <th className="py-3 px-4">Transaction Type</th>
                  <th className="py-3 px-4 text-center">Amount</th>
                  <th className="py-3 px-4 text-center">Balance Impact</th>
                  <th className="py-3 px-4">Audit Reason & Performer</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 text-slate-200">
                {ledgerTransactions.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="text-center py-10 text-slate-400">
                      No ledger transactions found matching criteria.
                    </td>
                  </tr>
                ) : (
                  ledgerTransactions.map((tx) => (
                    <tr key={tx.id} className="hover:bg-white/[0.02] transition-colors">
                      <td className="py-3 px-4 font-mono text-[11px] text-slate-400">
                        {new Date(tx.createdAt).toLocaleString()}
                      </td>

                      <td className="py-3 px-4">
                        <div className="font-bold text-white">{tx.staffName}</div>
                        <div className="text-[11px] text-slate-400 font-mono">{tx.employeeCode}</div>
                      </td>

                      <td className="py-3 px-4">
                        <span className="font-medium text-indigo-300">{tx.leaveTypeName}</span>
                      </td>

                      <td className="py-3 px-4">
                        {renderTxBadge(tx.transactionType)}
                      </td>

                      <td className="py-3 px-4 text-center font-mono font-bold">
                        <span className={tx.amount > 0 ? 'text-emerald-400' : 'text-rose-400'}>
                          {tx.amount > 0 ? `+${tx.amount}` : tx.amount} d
                        </span>
                      </td>

                      <td className="py-3 px-4 text-center font-mono text-[11px] text-slate-400">
                        <span>{tx.balanceBefore} d</span> &rarr; <span className="font-bold text-white">{tx.balanceAfter} d</span>
                      </td>

                      <td className="py-3 px-4">
                        <div className="text-slate-200">{tx.reason}</div>
                        <div className="text-[11px] text-slate-500">
                          By: <span className="text-slate-400 font-medium">{tx.performedByName}</span>
                          {tx.referenceId && <span className="ml-2 font-mono text-[10px]">Ref: {tx.referenceId}</span>}
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* =========================================================================
          VIEW 5: REPORTS & ANALYTICS
          ========================================================================= */}
      {activeSubTab === 'reports' && reportsSummary && (
        <div className="space-y-6">
          {/* Departmental Leave Consumption */}
          <div className="p-5 rounded-2xl bg-white border border-slate-200 space-y-4 shadow-2xs">
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
              <Building className="w-4 h-4 text-blue-600" />
              Departmental Leave Consumption
            </h3>

            <div className="space-y-3">
              {reportsSummary.usageByDepartment.map((dept) => {
                const maxDays = Math.max(...reportsSummary.usageByDepartment.map((d) => d.totalDays), 1);
                const pct = Math.min(100, Math.round((dept.totalDays / maxDays) * 100));

                return (
                  <div key={dept.departmentId} className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-slate-900">{dept.departmentName}</span>
                      <span className="text-slate-500 font-mono">
                        <strong className="text-blue-700 font-semibold">{dept.totalDays}</strong> days used ({dept.totalApplications} requests)
                      </span>
                    </div>
                    <div className="w-full h-2 rounded-full bg-slate-100 border border-slate-200 overflow-hidden">
                      <div
                        className="h-full bg-blue-600 rounded-full transition-all duration-500"
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Leave Type Utilization & Approval Pipeline Breakdown */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* By Leave Type */}
            <div className="p-5 rounded-2xl bg-white border border-slate-200 space-y-4 shadow-2xs">
              <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
                <Layers className="w-4 h-4 text-blue-600" />
                Consumption By Leave Category
              </h3>

              <div className="divide-y divide-slate-100 text-xs">
                {reportsSummary.usageByLeaveType.map((lt) => (
                  <div key={lt.leaveTypeId} className="py-2.5 flex items-center justify-between">
                    <div>
                      <span className="font-bold text-white">{lt.leaveTypeName}</span>
                      <span className="text-[11px] text-slate-400 ml-2">({lt.leaveTypeCode})</span>
                    </div>
                    <div className="text-right">
                      <span className="font-mono font-bold text-teal-300">{lt.totalDays} days</span>
                      <span className="text-slate-500 text-[11px] ml-2">({lt.applicationCount} apps)</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Approval Pipeline Stats */}
            <div className="p-5 rounded-2xl bg-slate-900/60 border border-white/10 space-y-4">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <FileCheck className="w-4 h-4 text-purple-400" />
                Adjudication Pipeline Stats
              </h3>

              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="p-3 rounded-xl bg-slate-800/50 border border-white/5">
                  <span className="text-slate-400 text-[11px] block">Total Applications</span>
                  <span className="text-lg font-bold text-white font-mono">{reportsSummary.approvalStats.totalSubmitted}</span>
                </div>
                <div className="p-3 rounded-xl bg-slate-800/50 border border-white/5">
                  <span className="text-slate-400 text-[11px] block">Final Approved</span>
                  <span className="text-lg font-bold text-emerald-400 font-mono">{reportsSummary.approvalStats.approved}</span>
                </div>
                <div className="p-3 rounded-xl bg-slate-800/50 border border-white/5">
                  <span className="text-slate-400 text-[11px] block">Tier 1 Approved</span>
                  <span className="text-lg font-bold text-indigo-400 font-mono">{reportsSummary.approvalStats.partiallyApproved}</span>
                </div>
                <div className="p-3 rounded-xl bg-slate-800/50 border border-white/5">
                  <span className="text-slate-400 text-[11px] block">Declined Requests</span>
                  <span className="text-lg font-bold text-rose-400 font-mono">{reportsSummary.approvalStats.rejected}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODALS INTEGRATION
          ========================================================================= */}
      {isApplyModalOpen && (
        <StaffLeaveApplyModal
          isOpen={isApplyModalOpen}
          onClose={() => setIsApplyModalOpen(false)}
          staffList={staffList}
          leaveTypes={leaveTypes}
          onApply={handleApplyLeave}
          canOverrideBalance={true}
        />
      )}

      {isReviewModalOpen && selectedAppForReview && (
        <StaffLeaveReviewModal
          isOpen={isReviewModalOpen}
          onClose={() => {
            setIsReviewModalOpen(false);
            setSelectedAppForReview(null);
          }}
          application={selectedAppForReview}
          onReview={handleReviewApplication}
        />
      )}

      {isPolicyModalOpen && (
        <StaffLeavePolicyModal
          isOpen={isPolicyModalOpen}
          onClose={() => {
            setIsPolicyModalOpen(false);
            setSelectedPolicyForEdit(null);
          }}
          policy={selectedPolicyForEdit}
          leaveTypes={leaveTypes}
          departments={departments}
          designations={designations}
          onSave={handleSavePolicy}
        />
      )}

      {isAdjustModalOpen && (
        <StaffLeaveAdjustModal
          isOpen={isAdjustModalOpen}
          onClose={() => setIsAdjustModalOpen(false)}
          staffList={staffList}
          leaveTypes={leaveTypes}
          preSelectedStaffId={adjustPreselectStaffId}
          preSelectedLeaveTypeId={adjustPreselectLeaveTypeId}
          onAdjustSuccess={() => {
            setSuccessMessage('Leave balance adjustment committed to authoritative ledger.');
            if (activeSubTab === 'balances') fetchBalances();
            else if (activeSubTab === 'ledger') fetchLedger();
          }}
        />
      )}

      {isCarryForwardModalOpen && (
        <StaffLeaveCarryForwardModal
          isOpen={isCarryForwardModalOpen}
          onClose={() => setIsCarryForwardModalOpen(false)}
          academicSessions={academicSessions}
          leaveTypes={leaveTypes}
          onComplete={() => {
            setSuccessMessage('Session carry-forward processed successfully.');
            if (activeSubTab === 'balances') fetchBalances();
            else if (activeSubTab === 'ledger') fetchLedger();
          }}
        />
      )}
    </div>
  );
};
