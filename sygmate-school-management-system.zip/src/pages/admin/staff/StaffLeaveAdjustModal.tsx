import React, { useState, useEffect } from 'react';
import {
  X,
  Sliders,
  AlertCircle,
  PlusCircle,
  MinusCircle,
  User,
  Building,
  CheckCircle2,
  Calendar
} from 'lucide-react';
import { Button } from '../../../components/ui/Button.js';
import {
  StaffProfile,
  LeaveType,
  StaffLeaveBalance,
  AdjustStaffLeaveBalancePayload
} from '../../../types/index.js';
import { api } from '../../../services/api.js';

interface StaffLeaveAdjustModalProps {
  isOpen: boolean;
  onClose: () => void;
  staffList: StaffProfile[];
  leaveTypes: LeaveType[];
  preSelectedStaffId?: string;
  preSelectedLeaveTypeId?: string;
  onAdjustSuccess: () => void;
}

export const StaffLeaveAdjustModal: React.FC<StaffLeaveAdjustModalProps> = ({
  isOpen,
  onClose,
  staffList = [],
  leaveTypes = [],
  preSelectedStaffId,
  preSelectedLeaveTypeId,
  onAdjustSuccess
}) => {
  const [staffId, setStaffId] = useState<string>(preSelectedStaffId || staffList?.[0]?.id || '');
  const [leaveTypeId, setLeaveTypeId] = useState<string>(preSelectedLeaveTypeId || leaveTypes?.[0]?.id || '');
  const [adjustmentType, setAdjustmentType] = useState<'ADD' | 'DEDUCT'>('ADD');
  const [days, setDays] = useState<number>(1);
  const [reason, setReason] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const [currentBalance, setCurrentBalance] = useState<StaffLeaveBalance | null>(null);
  const [loadingBalance, setLoadingBalance] = useState<boolean>(false);

  // Fetch current live balance for selected staff + leave type
  useEffect(() => {
    if (!isOpen || !staffId || !leaveTypeId) return;
    let active = true;
    const loadBalance = async () => {
      setLoadingBalance(true);
      try {
        const balances = await api.staff.leaves.getStaffBalances(staffId);
        if (active) {
          const match = balances.find((b) => b.leaveTypeId === leaveTypeId) || null;
          setCurrentBalance(match);
        }
      } catch (err) {
        console.warn('Failed to load live staff balance for preview:', err);
      } finally {
        if (active) setLoadingBalance(false);
      }
    };
    loadBalance();
    return () => {
      active = false;
    };
  }, [isOpen, staffId, leaveTypeId]);

  if (!isOpen) return null;

  const balanceBefore = currentBalance?.remainingDays ?? 0;
  const balanceAfter = adjustmentType === 'ADD' ? balanceBefore + days : balanceBefore - days;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!staffId) {
      setError('Please select a staff member.');
      return;
    }
    if (!leaveTypeId) {
      setError('Please select a leave category.');
      return;
    }
    if (days <= 0) {
      setError('Days to adjust must be greater than zero.');
      return;
    }
    if (!reason.trim() || reason.trim().length < 5) {
      setError('An official institutional reason (minimum 5 characters) is required for the audit trail.');
      return;
    }

    setIsSubmitting(true);
    setError(null);

    try {
      const payload: AdjustStaffLeaveBalancePayload = {
        staffId,
        leaveTypeId,
        adjustmentType,
        days,
        reason: reason.trim()
      };
      await api.staff.leaves.adjustBalance(payload);
      onAdjustSuccess();
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to apply balance adjustment.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const selectedStaff = (staffList || []).find((s) => s?.id === staffId);

  return (
    <div
      id="staff-leave-adjust-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto"
    >
      <div className="relative w-full max-w-lg bg-slate-900 border border-white/10 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-800/80 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white tracking-tight">
                Adjust Staff Leave Balance
              </h2>
              <p className="text-xs text-slate-400">
                Administrative ledger-backed balance correction with full audit trail
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {error && (
            <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/20 flex items-start gap-3 text-rose-300 text-sm">
              <AlertCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {/* Target Staff Member */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              Staff Member *
            </label>
            <select
              value={staffId}
              onChange={(e) => setStaffId(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800/80 border border-white/10 text-white text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/50"
              required
            >
              {staffList.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.fullName} ({s.employeeCode}) — {s.departmentName || s.staffType}
                </option>
              ))}
            </select>
          </div>

          {/* Leave Category */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              Leave Category *
            </label>
            <select
              value={leaveTypeId}
              onChange={(e) => setLeaveTypeId(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800/80 border border-white/10 text-white text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/50"
              required
            >
              {leaveTypes.map((lt) => (
                <option key={lt.id} value={lt.id}>
                  {lt.name} ({lt.isPaid === false ? 'Unpaid' : 'Paid'})
                </option>
              ))}
            </select>
          </div>

          {/* Live Balance Impact Preview */}
          <div className="p-4 rounded-xl bg-slate-800/40 border border-white/5 space-y-2">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>Current Remaining Balance:</span>
              <span className="font-bold text-white font-mono">
                {loadingBalance ? 'Checking...' : `${balanceBefore} days`}
              </span>
            </div>
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>Projected Balance After Adjustment:</span>
              <span className={`font-bold font-mono text-sm ${balanceAfter < 0 ? 'text-rose-400' : 'text-emerald-400'}`}>
                {loadingBalance ? '...' : `${balanceAfter} days`}
              </span>
            </div>
            {balanceAfter < 0 && (
              <p className="text-[11px] text-amber-300/80 pt-1">
                Note: Projected balance is negative. Policy must permit negative overdraft.
              </p>
            )}
          </div>

          {/* Adjustment Type & Quantity */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                Adjustment Action *
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setAdjustmentType('ADD')}
                  className={`py-2 px-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
                    adjustmentType === 'ADD'
                      ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300 ring-2 ring-emerald-500/30'
                      : 'bg-slate-800/60 border-white/10 text-slate-400 hover:text-white'
                  }`}
                >
                  <PlusCircle className="w-4 h-4 text-emerald-400" />
                  Credit (+ Add)
                </button>
                <button
                  type="button"
                  onClick={() => setAdjustmentType('DEDUCT')}
                  className={`py-2 px-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
                    adjustmentType === 'DEDUCT'
                      ? 'bg-rose-500/20 border-rose-500/40 text-rose-300 ring-2 ring-rose-500/30'
                      : 'bg-slate-800/60 border-white/10 text-slate-400 hover:text-white'
                  }`}
                >
                  <MinusCircle className="w-4 h-4 text-rose-400" />
                  Debit (- Deduct)
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                Number of Days *
              </label>
              <input
                type="number"
                min="0.5"
                step="0.5"
                value={days}
                onChange={(e) => setDays(parseFloat(e.target.value) || 0)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800/80 border border-white/10 text-white text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/50"
                required
              />
            </div>
          </div>

          {/* Reason */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              Official Institutional Reason (Mandatory) *
            </label>
            <textarea
              rows={3}
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="e.g. Compensatory leave awarded for institutional open day duty; approved by Principal..."
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800/80 border border-white/10 text-white text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/50 resize-none"
              required
            />
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={isSubmitting}
              className="bg-amber-600 hover:bg-amber-500 text-white"
            >
              {isSubmitting ? 'Applying...' : 'Commit Adjustment'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};
