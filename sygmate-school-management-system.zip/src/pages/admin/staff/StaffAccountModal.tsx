import React, { useState } from 'react';
import {
  UserCheck,
  UserX,
  X,
  Key,
  Shield,
  AlertCircle,
  CheckCircle2,
  Lock,
  User as UserIcon
} from 'lucide-react';
import { Button } from '../../../components/ui/Button.js';
import { StaffProfile, UserRole } from '../../../types/index.js';

interface StaffAccountModalProps {
  staff: StaffProfile;
  isOpen: boolean;
  onClose: () => void;
  onLinkAccount: (payload: { userId?: string; username?: string; password?: string; role?: UserRole }) => Promise<void>;
  onUnlinkAccount: () => Promise<void>;
  isProcessing?: boolean;
}

export const StaffAccountModal: React.FC<StaffAccountModalProps> = ({
  staff,
  isOpen,
  onClose,
  onLinkAccount,
  onUnlinkAccount,
  isProcessing = false
}) => {
  const [mode, setMode] = useState<'create' | 'link'>('create');
  const [username, setUsername] = useState(
    staff.username || `${(staff.firstName || '').toLowerCase()}.${(staff.lastName || '').toLowerCase()}`.replace(/[^a-z0-9.]/g, '')
  );
  const [password, setPassword] = useState('SygmateStaff@2026');
  const [role, setRole] = useState<UserRole>(
    staff.staffType === 'teaching' ? 'TEACHER' : staff.staffType === 'management' ? 'SUPER_ADMIN' : 'STAFF' as any
  );
  const [existingUserId, setExistingUserId] = useState('');
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    try {
      if (mode === 'create') {
        if (!username.trim()) {
          setError('Username is required.');
          return;
        }
        if (!password.trim() || password.length < 6) {
          setError('Password must be at least 6 characters.');
          return;
        }
        await onLinkAccount({
          username: username.trim().toLowerCase(),
          password: password.trim(),
          role
        });
      } else {
        if (!existingUserId.trim()) {
          setError('Existing User ID is required.');
          return;
        }
        await onLinkAccount({
          userId: existingUserId.trim()
        });
      }
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to link account.');
    }
  };

  const handleUnlink = async () => {
    if (window.confirm(`Are you sure you want to unlink account '${staff.username}' from ${staff.displayName}? They will no longer be able to log in with this profile.`)) {
      try {
        await onUnlinkAccount();
        onClose();
      } catch (err: any) {
        setError(err.message || 'Failed to unlink account.');
      }
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto"
      id="staff-account-modal-overlay"
    >
      <div
        className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden my-8"
        id="staff-account-modal-container"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50/80">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-indigo-50 text-indigo-700 border border-indigo-200">
              <Key className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-slate-900">
                System Account & Authentication
              </h3>
              <p className="text-xs text-slate-500">
                {staff.displayName} ({staff.employeeCode})
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1 rounded-lg hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5">
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-lg flex items-start gap-2 text-xs text-red-700">
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {/* Current Linked Status */}
          {staff.hasAccount ? (
            <div className="p-4 bg-emerald-50/70 border border-emerald-200 rounded-xl space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span className="text-xs font-semibold text-emerald-900">
                    Linked User Account
                  </span>
                </div>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-100 text-emerald-800 uppercase tracking-wider">
                  {staff.accountStatus || 'ACTIVE'}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs text-slate-700 pt-1">
                <div>
                  <span className="text-[11px] text-slate-500 block">Username</span>
                  <span className="font-semibold text-slate-900">{staff.username}</span>
                </div>
                <div>
                  <span className="text-[11px] text-slate-500 block">Assigned Role</span>
                  <span className="font-semibold text-slate-900">{staff.accountRole}</span>
                </div>
                <div>
                  <span className="text-[11px] text-slate-500 block">Email</span>
                  <span className="text-slate-800">{staff.email}</span>
                </div>
                <div>
                  <span className="text-[11px] text-slate-500 block">Last Active</span>
                  <span className="text-slate-800">
                    {staff.lastLoginAt ? new Date(staff.lastLoginAt).toLocaleDateString() : 'Never'}
                  </span>
                </div>
              </div>

              <div className="pt-2 border-t border-emerald-200 flex justify-end">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={handleUnlink}
                  isLoading={isProcessing}
                  className="text-red-600 border-red-200 hover:bg-red-50 hover:text-red-700"
                  id="unlink-staff-account-btn"
                >
                  Unlink Account
                </Button>
              </div>
            </div>
          ) : (
            <div className="p-3 bg-amber-50/80 border border-amber-200 rounded-xl flex items-start gap-2.5 text-xs text-amber-800">
              <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <span>
                This staff member does not have an active login account. Provision credentials below to enable portal access.
              </span>
            </div>
          )}

          {/* If not linked, show account setup options */}
          {!staff.hasAccount && (
            <form onSubmit={handleSubmit} className="space-y-4" id="link-account-form">
              <div className="flex rounded-lg bg-slate-100 p-1">
                <button
                  type="button"
                  onClick={() => setMode('create')}
                  className={`flex-1 text-xs py-1.5 font-medium rounded-md transition-colors ${
                    mode === 'create' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Provision New Account
                </button>
                <button
                  type="button"
                  onClick={() => setMode('link')}
                  className={`flex-1 text-xs py-1.5 font-medium rounded-md transition-colors ${
                    mode === 'link' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Link Existing User ID
                </button>
              </div>

              {mode === 'create' ? (
                <>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">
                      Username <span className="text-red-500">*</span>
                    </label>
                    <div className="relative">
                      <UserIcon className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
                      <input
                        type="text"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        required
                        className="w-full text-xs rounded-lg border border-slate-300 pl-8 pr-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                        id="staff-username-input"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">
                      Initial Password <span className="text-red-500">*</span>
                    </label>
                    <div className="relative">
                      <Lock className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
                      <input
                        type="text"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                        className="w-full text-xs rounded-lg border border-slate-300 pl-8 pr-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 font-mono"
                        id="staff-password-input"
                      />
                    </div>
                    <span className="text-[11px] text-slate-500 mt-1 block">
                      The staff member will be required to update their password upon first login.
                    </span>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">
                      System Access Role <span className="text-red-500">*</span>
                    </label>
                    <div className="relative">
                      <Shield className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
                      <select
                        value={role}
                        onChange={(e) => setRole(e.target.value as UserRole)}
                        className="w-full text-xs rounded-lg border border-slate-300 pl-8 pr-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                        id="staff-role-select"
                      >
                        <option value="TEACHER">TEACHER (Class, Routine & Mark Permissions)</option>
                        <option value="STAFF">STAFF (Operational & Non-Teaching Portal)</option>
                        <option value="SUPER_ADMIN">SUPER_ADMIN (Institutional HR & System Privileges)</option>
                      </select>
                    </div>
                  </div>
                </>
              ) : (
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Existing User ID <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={existingUserId}
                    onChange={(e) => setExistingUserId(e.target.value)}
                    placeholder="E.g., usr-teach-101"
                    required
                    className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 font-mono"
                    id="existing-userid-input"
                  />
                  <span className="text-[11px] text-slate-500 mt-1 block">
                    Attach an existing user account from the central user directory.
                  </span>
                </div>
              )}

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-200">
                <Button type="button" variant="outline" size="sm" onClick={onClose}>
                  Cancel
                </Button>
                <Button
                  type="submit"
                  variant="primary"
                  size="sm"
                  isLoading={isProcessing}
                  id="submit-link-account-btn"
                >
                  {mode === 'create' ? 'Provision Account' : 'Link Account'}
                </Button>
              </div>
            </form>
          )}
        </div>

        {/* Footer when already linked */}
        {staff.hasAccount && (
          <div className="flex items-center justify-end px-6 py-3 border-t border-slate-200 bg-slate-50/80">
            <Button type="button" variant="outline" size="sm" onClick={onClose}>
              Close
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};
