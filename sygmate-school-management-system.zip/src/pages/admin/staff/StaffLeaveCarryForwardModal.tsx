import React, { useState } from 'react';
import {
  X,
  FastForward,
  AlertCircle,
  Calendar,
  CheckCircle2,
  Layers,
  ArrowRight,
  Info
} from 'lucide-react';
import { Button } from '../../../components/ui/Button.js';
import {
  AcademicSession,
  LeaveType,
  CarryForwardProcessPayload,
  CarryForwardResult
} from '../../../types/index.js';
import { api } from '../../../services/api.js';

interface StaffLeaveCarryForwardModalProps {
  isOpen: boolean;
  onClose: () => void;
  academicSessions: AcademicSession[];
  leaveTypes: LeaveType[];
  onComplete: () => void;
}

export const StaffLeaveCarryForwardModal: React.FC<StaffLeaveCarryForwardModalProps> = ({
  isOpen,
  onClose,
  academicSessions,
  leaveTypes,
  onComplete
}) => {
  const defaultFrom = academicSessions?.[1]?.id || academicSessions?.[0]?.id || 'session-2025-2026';
  const defaultTo = academicSessions?.[0]?.id || 'session-2026-2027';

  const [fromSessionId, setFromSessionId] = useState<string>(defaultFrom);
  const [toSessionId, setToSessionId] = useState<string>(defaultTo);
  const [staffCategory, setStaffCategory] = useState<string>('ALL');
  const [leaveTypeId, setLeaveTypeId] = useState<string>('ALL');

  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<CarryForwardResult | null>(null);

  if (!isOpen) return null;

  const handleProcess = async (e: React.FormEvent) => {
    e.preventDefault();
    if (fromSessionId === toSessionId) {
      setError('Origin and target academic sessions must be distinct.');
      return;
    }

    setIsProcessing(true);
    setError(null);
    setResult(null);

    try {
      const payload: CarryForwardProcessPayload = {
        fromSessionId,
        toSessionId,
        staffCategory: staffCategory as any,
        leaveTypeId: leaveTypeId !== 'ALL' ? leaveTypeId : undefined
      };
      const res = await api.staff.leaves.runCarryForward(payload);
      setResult(res);
      onComplete();
    } catch (err: any) {
      setError(err.message || 'Failed to execute carry-forward process.');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div
      id="staff-leave-carry-forward-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto"
    >
      <div className="relative w-full max-w-xl bg-slate-900 border border-white/10 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-800/80 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-teal-500/20 border border-teal-500/30 flex items-center justify-center text-teal-400">
              <FastForward className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white tracking-tight">
                Session Leave Carry-Forward Engine
              </h2>
              <p className="text-xs text-slate-400">
                Automated rollover of unused leave balances adhering to policy limits
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5">
          {error && (
            <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/20 flex items-start gap-3 text-rose-300 text-sm">
              <AlertCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {result ? (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-sm">Carry-Forward Completed Successfully</h4>
                  <p className="text-xs text-emerald-200/80 mt-1">
                    Processed {result.processedCount} employee entitlements with a total of{' '}
                    <span className="font-bold font-mono">{result.totalDaysCarried}</span> days carried forward into the new academic session. ({result.skippedCount} skipped as ineligible or already processed).
                  </p>
                </div>
              </div>

              {((result?.details?.length || 0) > 0) && (
                <div className="max-h-56 overflow-y-auto rounded-xl border border-white/10 bg-slate-800/40 p-2 divide-y divide-white/5 text-xs">
                  {(result?.details || []).slice(0, 10).map((d, i) => (
                    <div key={i} className="py-2 px-3 flex items-center justify-between">
                      <div>
                        <span className="font-bold text-white">{d.staffName}</span>
                        <span className="text-slate-400 ml-2">({d.leaveTypeName})</span>
                      </div>
                      <div className="text-right">
                        {d.daysCarried > 0 ? (
                          <span className="text-emerald-400 font-mono font-bold">+{d.daysCarried} days carried</span>
                        ) : (
                          <span className="text-slate-500">{d.reason || 'Skipped'}</span>
                        )}
                      </div>
                    </div>
                  ))}
                  {(result?.details?.length || 0) > 10 && (
                    <div className="py-2 text-center text-slate-500 text-[11px]">
                      + {(result?.details?.length || 0) - 10} more employee records processed
                    </div>
                  )}
                </div>
              )}

              <div className="flex justify-end pt-3">
                <Button onClick={onClose} className="bg-teal-600 hover:bg-teal-500 text-white">
                  Done
                </Button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleProcess} className="space-y-5">
              {/* Session Transition Selectors */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-center">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                    Origin Session (From) *
                  </label>
                  <select
                    value={fromSessionId}
                    onChange={(e) => setFromSessionId(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800/80 border border-white/10 text-white text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/50"
                    required
                  >
                    {academicSessions.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name} ({s.academicYear || s.status})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                    Target Session (To) *
                  </label>
                  <select
                    value={toSessionId}
                    onChange={(e) => setToSessionId(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800/80 border border-white/10 text-white text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/50"
                    required
                  >
                    {academicSessions.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name} ({s.academicYear || s.status})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Filters */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                    Staff Category
                  </label>
                  <select
                    value={staffCategory}
                    onChange={(e) => setStaffCategory(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800/80 border border-white/10 text-white text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/50"
                  >
                    <option value="ALL">All Categories</option>
                    <option value="teaching">Teaching Staff</option>
                    <option value="administrative">Administrative Staff</option>
                    <option value="support">Support Staff</option>
                    <option value="operational">Operational Staff</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                    Leave Category
                  </label>
                  <select
                    value={leaveTypeId}
                    onChange={(e) => setLeaveTypeId(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800/80 border border-white/10 text-white text-sm focus:outline-none focus:ring-2 focus:ring-teal-500/50"
                  >
                    <option value="ALL">All Eligible Leave Types</option>
                    {leaveTypes.map((lt) => (
                      <option key={lt.id} value={lt.id}>
                        {lt.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-slate-800/40 border border-white/5 space-y-2 text-xs text-slate-400">
                <div className="flex items-center gap-2 font-bold text-slate-300">
                  <Info className="w-4 h-4 text-teal-400" />
                  Policy Rules & Idempotency Guarantee
                </div>
                <p>
                  • Only leave policies with <strong>Carry Forward Allowed = true</strong> will be rolled over.
                </p>
                <p>
                  • Carried forward days are strictly capped at each policy's <strong>Max Carry-Forward Days</strong> limit.
                </p>
                <p>
                  • This process is <strong>idempotent</strong>: executing it multiple times will not duplicate carry-forward transactions.
                </p>
              </div>

              {/* Actions */}
              <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
                <Button
                  type="button"
                  variant="outline"
                  onClick={onClose}
                  disabled={isProcessing}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={isProcessing}
                  className="bg-teal-600 hover:bg-teal-500 text-white"
                >
                  {isProcessing ? 'Processing Carry-Forward...' : 'Execute Carry-Forward'}
                </Button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
