import React, { useState } from 'react';
import {
  Search,
  Filter,
  Plus,
  FileSpreadsheet,
  RotateCcw,
  MoreVertical,
  Eye,
  Edit2,
  AlertTriangle,
  FileText,
  Key,
  Users,
  Building,
  GraduationCap,
  Briefcase,
  CheckCircle,
  Clock,
  LayoutGrid,
  List,
  Mail,
  Phone,
  ShieldCheck,
  UserX
} from 'lucide-react';
import { Button } from '../../../components/ui/Button.js';
import {
  StaffProfile,
  StaffType,
  EmploymentStatus,
  EmploymentType,
  Department,
  Designation
} from '../../../types/index.js';

interface StaffDirectoryTabProps {
  staffList: StaffProfile[];
  departments: Department[];
  designations: Designation[];
  totalStaffCount: number;
  currentPage: number;
  pageSize: number;
  onPageChange: (page: number) => void;
  onPageSizeChange: (size: number) => void;
  // Filters
  searchTerm: string;
  onSearchChange: (val: string) => void;
  selectedStaffType: string;
  onStaffTypeChange: (val: string) => void;
  selectedDepartmentId: string;
  onDepartmentChange: (val: string) => void;
  selectedStatus: string;
  onStatusChange: (val: string) => void;
  selectedEmploymentType: string;
  onEmploymentTypeChange: (val: string) => void;
  onResetFilters: () => void;
  onExportCsv: () => void;
  // Actions
  onAddStaff: () => void;
  onViewDossier: (staff: StaffProfile) => void;
  onEditStaff: (staff: StaffProfile) => void;
  onChangeStatus: (staff: StaffProfile) => void;
  onManageDocuments: (staff: StaffProfile) => void;
  onManageAccount: (staff: StaffProfile) => void;
  isLoading?: boolean;
}

export const StaffDirectoryTab: React.FC<StaffDirectoryTabProps> = ({
  staffList,
  departments,
  designations,
  totalStaffCount,
  currentPage,
  pageSize,
  onPageChange,
  onPageSizeChange,
  searchTerm,
  onSearchChange,
  selectedStaffType,
  onStaffTypeChange,
  selectedDepartmentId,
  onDepartmentChange,
  selectedStatus,
  onStatusChange,
  selectedEmploymentType,
  onEmploymentTypeChange,
  onResetFilters,
  onExportCsv,
  onAddStaff,
  onViewDossier,
  onEditStaff,
  onChangeStatus,
  onManageDocuments,
  onManageAccount,
  isLoading = false
}) => {
  const [viewMode, setViewMode] = useState<'table' | 'cards'>('table');
  const [activeMenuStaffId, setActiveMenuStaffId] = useState<string | null>(null);

  const totalPages = Math.ceil(totalStaffCount / pageSize) || 1;

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span> Active
          </span>
        );
      case 'on_leave':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-amber-50 text-amber-700 border border-amber-200">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-500"></span> On Leave
          </span>
        );
      case 'probation':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-blue-50 text-blue-700 border border-blue-200">
            <span className="w-1.5 h-1.5 rounded-full bg-blue-500"></span> Probation
          </span>
        );
      case 'suspended':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-orange-50 text-orange-700 border border-orange-200">
            <span className="w-1.5 h-1.5 rounded-full bg-orange-500"></span> Suspended
          </span>
        );
      case 'resigned':
      case 'retired':
      case 'terminated':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-slate-100 text-slate-700 border border-slate-300">
            <span className="w-1.5 h-1.5 rounded-full bg-slate-400"></span> {(status || '').replace(/_/g, ' ')}
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-slate-100 text-slate-700">
            {status}
          </span>
        );
    }
  };

  const getStaffTypeBadge = (type: string) => {
    switch (type) {
      case 'teaching':
        return <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200">Faculty</span>;
      case 'administrative':
        return <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-purple-50 text-purple-700 border border-purple-200">Admin</span>;
      case 'support':
        return <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-cyan-50 text-cyan-700 border border-cyan-200">Support</span>;
      case 'management':
        return <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-50 text-amber-700 border border-amber-200">Executive</span>;
      case 'operational':
        return <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">Operations</span>;
      default:
        return <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-100 text-slate-700">{type}</span>;
    }
  };

  return (
    <div className="space-y-4" id="staff-directory-tab">
      {/* Search & Filter Toolbar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-3">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          {/* Search box */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="Search by staff name, employee code, email, qualification..."
              className="w-full text-xs rounded-lg border border-slate-300 pl-9 pr-3 py-2 text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
              id="staff-search-input"
            />
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-2">
            {/* View Mode Toggle */}
            <div className="flex items-center rounded-lg border border-slate-200 p-0.5 bg-slate-50">
              <button
                type="button"
                onClick={() => setViewMode('table')}
                className={`p-1.5 rounded-md ${
                  viewMode === 'table' ? 'bg-white shadow-xs text-indigo-600' : 'text-slate-400 hover:text-slate-600'
                }`}
                title="Table View"
              >
                <List className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => setViewMode('cards')}
                className={`p-1.5 rounded-md ${
                  viewMode === 'cards' ? 'bg-white shadow-xs text-indigo-600' : 'text-slate-400 hover:text-slate-600'
                }`}
                title="Cards Grid View"
              >
                <LayoutGrid className="w-4 h-4" />
              </button>
            </div>

            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={onExportCsv}
              icon={<FileSpreadsheet className="w-3.5 h-3.5" />}
              id="export-staff-csv-btn"
            >
              Export CSV
            </Button>

            <Button
              type="button"
              variant="primary"
              size="sm"
              onClick={onAddStaff}
              icon={<Plus className="w-3.5 h-3.5" />}
              id="add-staff-btn"
            >
              Onboard Staff
            </Button>
          </div>
        </div>

        {/* Filter Dropdowns */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-5 gap-2 pt-2 border-t border-slate-100 text-xs">
          <div>
            <label className="block text-[11px] font-medium text-slate-500 mb-1">
              Staff Type
            </label>
            <select
              value={selectedStaffType}
              onChange={(e) => onStaffTypeChange(e.target.value)}
              className="w-full text-xs rounded-lg border border-slate-200 px-2.5 py-1.5 text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500"
              id="filter-staff-type"
            >
              <option value="">All Classifications</option>
              <option value="teaching">Teaching Faculty</option>
              <option value="administrative">Administrative</option>
              <option value="support">Campus Support</option>
              <option value="management">Executive Management</option>
              <option value="operational">Operational</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-medium text-slate-500 mb-1">
              Department
            </label>
            <select
              value={selectedDepartmentId}
              onChange={(e) => onDepartmentChange(e.target.value)}
              className="w-full text-xs rounded-lg border border-slate-200 px-2.5 py-1.5 text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500"
              id="filter-department"
            >
              <option value="">All Departments</option>
              {departments.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-medium text-slate-500 mb-1">
              Status
            </label>
            <select
              value={selectedStatus}
              onChange={(e) => onStatusChange(e.target.value)}
              className="w-full text-xs rounded-lg border border-slate-200 px-2.5 py-1.5 text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500"
              id="filter-status"
            >
              <option value="">All Statuses</option>
              <option value="active">Active</option>
              <option value="on_leave">On Leave</option>
              <option value="probation">Probationary</option>
              <option value="suspended">Suspended</option>
              <option value="resigned">Resigned</option>
              <option value="retired">Retired</option>
              <option value="terminated">Terminated</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-medium text-slate-500 mb-1">
              Employment Terms
            </label>
            <select
              value={selectedEmploymentType}
              onChange={(e) => onEmploymentTypeChange(e.target.value)}
              className="w-full text-xs rounded-lg border border-slate-200 px-2.5 py-1.5 text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500"
              id="filter-employment-type"
            >
              <option value="">All Terms</option>
              <option value="full_time">Full-Time</option>
              <option value="part_time">Part-Time</option>
              <option value="contract">Fixed Contract</option>
              <option value="probation">Probation</option>
              <option value="visiting">Visiting Faculty</option>
              <option value="temporary">Temporary</option>
            </select>
          </div>

          <div className="flex items-end">
            <button
              type="button"
              onClick={onResetFilters}
              className="w-full py-1.5 px-2 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 flex items-center justify-center gap-1.5 transition-colors font-medium"
              id="reset-filters-btn"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Filters</span>
            </button>
          </div>
        </div>
      </div>

      {/* Staff Records View */}
      {staffList.length === 0 ? (
        <div className="bg-white rounded-xl border border-slate-200 p-12 text-center">
          <Users className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <h4 className="text-sm font-semibold text-slate-800">No staff members found</h4>
          <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
            No employee records match the active filter criteria. Clear filters or add a new staff member.
          </p>
          <div className="mt-4">
            <Button type="button" variant="primary" size="sm" onClick={onAddStaff}>
              Onboard New Staff Member
            </Button>
          </div>
        </div>
      ) : viewMode === 'table' ? (
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs" id="staff-directory-table">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/80 text-slate-500 font-semibold uppercase tracking-wider text-[11px]">
                  <th className="py-3 px-4">Staff Member</th>
                  <th className="py-3 px-3">Classification</th>
                  <th className="py-3 px-3">Department & Role</th>
                  <th className="py-3 px-3">Contact</th>
                  <th className="py-3 px-3">Terms & Status</th>
                  <th className="py-3 px-3">System Account</th>
                  <th className="py-3 px-3 text-center">Docs</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {staffList.map((staff) => (
                  <tr
                    key={staff.id}
                    className="hover:bg-slate-50/70 transition-colors"
                    id={`staff-row-${staff.id}`}
                  >
                    {/* Staff identity */}
                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-3">
                        <img
                          src={staff.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=128'}
                          alt={staff.displayName}
                          className="w-9 h-9 rounded-lg object-cover border border-slate-200 shrink-0"
                        />
                        <div>
                          <button
                            type="button"
                            onClick={() => onViewDossier(staff)}
                            className="font-bold text-slate-900 hover:text-indigo-600 text-left tracking-tight"
                          >
                            {staff.displayName}
                          </button>
                          <div className="flex items-center gap-1.5 mt-0.5">
                            <span className="font-mono text-[11px] text-slate-500 font-semibold">
                              {staff.employeeCode}
                            </span>
                            {staff.qualification && (
                              <span className="text-[10px] text-slate-400 truncate max-w-[140px]">
                                • {staff.qualification}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    </td>

                    {/* Staff classification */}
                    <td className="py-3.5 px-3">
                      {getStaffTypeBadge(staff.staffType)}
                    </td>

                    {/* Department & designation */}
                    <td className="py-3.5 px-3">
                      <span className="font-semibold text-slate-800 block">
                        {staff.designation}
                      </span>
                      <span className="text-[11px] text-slate-500">
                        {staff.departmentName}
                      </span>
                    </td>

                    {/* Contact info */}
                    <td className="py-3.5 px-3">
                      <div className="space-y-0.5">
                        <a
                          href={`mailto:${staff.email}`}
                          className="text-slate-700 hover:text-indigo-600 flex items-center gap-1 truncate max-w-[180px]"
                        >
                          <Mail className="w-3 h-3 text-slate-400 shrink-0" />
                          <span className="truncate">{staff.email}</span>
                        </a>
                        <div className="text-slate-500 flex items-center gap-1 text-[11px]">
                          <Phone className="w-3 h-3 text-slate-400 shrink-0" />
                          <span>{staff.phone}</span>
                        </div>
                      </div>
                    </td>

                    {/* Terms & Status */}
                    <td className="py-3.5 px-3">
                      <div className="space-y-1">
                        {getStatusBadge(staff.employmentStatus)}
                        <span className="block text-[10px] text-slate-500 capitalize">
                          {(staff.employmentType || 'full_time').replace(/_/g, ' ')}
                        </span>
                      </div>
                    </td>

                    {/* System Account link */}
                    <td className="py-3.5 px-3">
                      {staff.hasAccount ? (
                        <button
                          type="button"
                          onClick={() => onManageAccount(staff)}
                          className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-medium bg-emerald-50 text-emerald-700 border border-emerald-100 hover:bg-emerald-100 transition-colors"
                          title="Click to view linked account"
                        >
                          <Key className="w-3 h-3" />
                          <span className="font-mono">{staff.username}</span>
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={() => onManageAccount(staff)}
                          className="inline-flex items-center gap-1 text-[11px] text-slate-400 hover:text-indigo-600"
                        >
                          <UserX className="w-3 h-3" />
                          <span>Unlinked</span>
                        </button>
                      )}
                    </td>

                    {/* Document count */}
                    <td className="py-3.5 px-3 text-center">
                      <button
                        type="button"
                        onClick={() => onManageDocuments(staff)}
                        className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium bg-slate-100 text-slate-700 hover:bg-indigo-50 hover:text-indigo-700 transition-colors"
                        title="Manage Documents"
                      >
                        <FileText className="w-3 h-3" />
                        <span>{staff.documentCount || 0}</span>
                      </button>
                    </td>

                    {/* Action buttons */}
                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          type="button"
                          onClick={() => onViewDossier(staff)}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-indigo-600 hover:bg-slate-100 transition-colors"
                          title="View 360° Dossier"
                        >
                          <Eye className="w-4 h-4" />
                        </button>

                        <button
                          type="button"
                          onClick={() => onEditStaff(staff)}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-slate-800 hover:bg-slate-100 transition-colors"
                          title="Edit Staff Information"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>

                        <button
                          type="button"
                          onClick={() => onChangeStatus(staff)}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-amber-600 hover:bg-amber-50 transition-colors"
                          title="Change Employment Status"
                        >
                          <AlertTriangle className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        /* Cards Grid View */
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4" id="staff-directory-cards">
          {staffList.map((staff) => (
            <div
              key={staff.id}
              className="bg-white rounded-xl border border-slate-200 p-5 hover:border-slate-300 transition-all flex flex-col justify-between"
              id={`staff-card-${staff.id}`}
            >
              <div>
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-3">
                    <img
                      src={staff.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=128'}
                      alt={staff.displayName}
                      className="w-12 h-12 rounded-xl object-cover border border-slate-200 shrink-0"
                    />
                    <div>
                      <button
                        type="button"
                        onClick={() => onViewDossier(staff)}
                        className="font-bold text-slate-900 hover:text-indigo-600 text-left text-sm"
                      >
                        {staff.displayName}
                      </button>
                      <div className="flex items-center gap-1.5 mt-0.5">
                        <span className="font-mono text-xs font-semibold text-slate-500">
                          {staff.employeeCode}
                        </span>
                        {getStaffTypeBadge(staff.staffType)}
                      </div>
                    </div>
                  </div>
                  {getStatusBadge(staff.employmentStatus)}
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 space-y-2 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">Department:</span>
                    <span className="font-semibold text-slate-800">{staff.departmentName}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">Position / Title:</span>
                    <span className="font-semibold text-slate-800">{staff.designation}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">Email:</span>
                    <span className="font-medium text-slate-700 truncate max-w-[160px]">{staff.email}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500">Phone:</span>
                    <span className="font-medium text-slate-700">{staff.phone}</span>
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => onManageDocuments(staff)}
                  className="text-xs text-slate-500 hover:text-indigo-600 flex items-center gap-1"
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>{staff.documentCount || 0} Docs</span>
                </button>

                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => onViewDossier(staff)}
                    className="p-1.5 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 text-xs font-medium inline-flex items-center gap-1"
                  >
                    <Eye className="w-3.5 h-3.5" /> Dossier
                  </button>
                  <button
                    type="button"
                    onClick={() => onEditStaff(staff)}
                    className="p-1.5 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => onChangeStatus(staff)}
                    className="p-1.5 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50"
                  >
                    <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Pagination Footer */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white px-4 py-3 rounded-xl border border-slate-200 text-xs text-slate-600">
        <div className="flex items-center gap-2">
          <span>Showing</span>
          <select
            value={pageSize}
            onChange={(e) => onPageSizeChange(Number(e.target.value))}
            className="rounded border border-slate-200 px-2 py-1 text-slate-800"
          >
            <option value={10}>10 per page</option>
            <option value={20}>20 per page</option>
            <option value={50}>50 per page</option>
          </select>
          <span>of {totalStaffCount} total staff members</span>
        </div>

        <div className="flex items-center gap-2 self-end sm:self-center">
          <span className="font-medium">
            Page {currentPage} of {totalPages}
          </span>
          <div className="flex gap-1">
            <button
              type="button"
              disabled={currentPage <= 1}
              onClick={() => onPageChange(currentPage - 1)}
              className="px-2.5 py-1 rounded border border-slate-200 text-slate-600 hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed"
            >
              Previous
            </button>
            <button
              type="button"
              disabled={currentPage >= totalPages}
              onClick={() => onPageChange(currentPage + 1)}
              className="px-2.5 py-1 rounded border border-slate-200 text-slate-600 hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed"
            >
              Next
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
