import React, { useState, useEffect } from 'react';
import {
  X,
  FilePlus,
  Calendar,
  AlertCircle,
  Building,
  User,
  CheckCircle2,
  Layers,
  Paperclip,
  Clock,
  ShieldAlert,
  Info
} from 'lucide-react';
import { Button } from '../../../components/ui/Button.js';
import {
  StaffProfile,
  LeaveType,
  StaffLeaveApplicationPayload,
  StaffLeavePolicy,
  StaffLeaveBalance
} from '../../../types/index.js';
import { api } from '../../../services/api.js';

interface StaffLeaveApplyModalProps {
  isOpen: boolean;
  onClose: () => void;
  staffList: StaffProfile[];
  leaveTypes: LeaveType[];
  onApply: (payload: StaffLeaveApplicationPayload) => Promise<void>;
  preSelectedStaffId?: string;
  canOverrideBalance?: boolean;
}

export const StaffLeaveApplyModal: React.FC<StaffLeaveApplyModalProps> = ({
  isOpen,
  onClose,
  staffList,
  leaveTypes,
  onApply,
  preSelectedStaffId,
  canOverrideBalance = false
}) => {
  const [staffId, setStaffId] = useState<string>(preSelectedStaffId || staffList?.[0]?.id || '');
  const [leaveTypeId, setLeaveTypeId] = useState<string>(leaveTypes?.[0]?.id || '');
  const [startDate, setStartDate] = useState<string>(() => new Date().toISOString().split('T')[0]);
  const [endDate, setEndDate] = useState<string>(() => new Date().toISOString().split('T')[0]);
  const [reason, setReason] = useState<string>('');
  const [description, setDescription] = useState<string>('');
  const [attachmentUrl, setAttachmentUrl] = useState<string>('');
  const [attachmentName, setAttachmentName] = useState<string>('');
  const [allowBalanceOverride, setAllowBalanceOverride] = useState<boolean>(false);

  // Validation state
  const [validating, setValidating] = useState<boolean>(false);
  const [validationData, setValidationData] = useState<{
    isValid: boolean;
    errors: string[];
    warnings: string[];
    policy: StaffLeavePolicy | null;
    balance: StaffLeaveBalance;
    workingDaysCount: number;
    workingDates: string[];
  } | null>(null);

  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // Run live validation whenever staff, leave type, or dates change
  useEffect(() => {
    if (!isOpen || !staffId || !leaveTypeId || !startDate) return;
    let active = true;

    const runValidation = async () => {
      setValidating(true);
      try {
        const res = await api.staff.leaves.validateApplication({
          staffId,
          leaveTypeId,
          startDate,
          endDate: endDate || startDate,
          attachmentUrl: attachmentUrl || undefined,
          allowBalanceOverride
        });
        if (active) {
          setValidationData(res);
        }
      } catch (err) {
        console.warn('Live leave validation failed:', err);
      } finally {
        if (active) setValidating(false);
      }
    };

    const timer = setTimeout(runValidation, 300);
    return () => {
      active = false;
      clearTimeout(timer);
    };
  }, [isOpen, staffId, leaveTypeId, startDate, endDate, attachmentUrl, allowBalanceOverride]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!staffId) {
      setError('Please select a staff member.');
      return;
    }
    if (!leaveTypeId) {
      setError('Please select a leave category.');
      return;
    }
    if (!startDate) {
      setError('Start date is required.');
      return;
    }
    if (endDate && endDate < startDate) {
      setError('End date cannot be earlier than start date.');
      return;
    }
    if (!reason.trim()) {
      setError('Please state the primary reason for this leave request.');
      return;
    }

    if (validationData && !validationData.isValid && !allowBalanceOverride) {
      setError(validationData.errors.join(' '));
      return;
    }

    setIsSubmitting(true);
    setError(null);

    try {
      await onApply({
        staffId,
        leaveTypeId,
        startDate,
        endDate: endDate || startDate,
        reason: reason.trim(),
        description: description.trim() || undefined,
        attachmentUrl: attachmentUrl.trim() || undefined,
        attachmentName: attachmentName.trim() || (attachmentUrl ? 'Supporting_Document.pdf' : undefined),
        allowBalanceOverride
      });
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to submit staff leave application.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div
      id="staff-leave-apply-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto"
    >
      <div className="relative w-full max-w-xl bg-slate-900 border border-white/10 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-800/80 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
              <FilePlus className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white tracking-tight">
                Submit Staff Leave Request
              </h2>
              <p className="text-xs text-slate-400">
                Institutional policy validation, working day calculations, and balance reservation
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5 max-h-[80vh] overflow-y-auto">
          {error && (
            <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/20 flex items-start gap-3 text-rose-300 text-sm">
              <AlertCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {/* Staff Selector */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              Staff Member <span className="text-rose-400">*</span>
            </label>
            <select
              value={staffId}
              onChange={(e) => setStaffId(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="">-- Select Staff Member --</option>
              {staffList.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.fullName || s.displayName} ({s.employeeCode} - {s.departmentName || s.staffType})
                </option>
              ))}
            </select>
          </div>

          {/* Leave Type */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              Leave Category <span className="text-rose-400">*</span>
            </label>
            <select
              value={leaveTypeId}
              onChange={(e) => setLeaveTypeId(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="">-- Choose Leave Category --</option>
              {leaveTypes.map((lt) => (
                <option key={lt.id} value={lt.id}>
                  {lt.name} ({lt.isPaid === false ? 'Unpaid' : 'Paid'})
                </option>
              ))}
            </select>
          </div>

          {/* Dates */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Start Date <span className="text-rose-400">*</span>
              </label>
              <input
                type="date"
                required
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                End Date <span className="text-rose-400">*</span>
              </label>
              <input
                type="date"
                required
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

          {/* Live Validation & Policy Intelligence Badge */}
          {validationData && (
            <div className="p-4 rounded-xl bg-slate-800/60 border border-white/10 space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                  <Clock className="w-4 h-4 text-indigo-400" />
                  Calculated Working Days:
                </span>
                <span className="font-mono font-bold text-sm text-white bg-indigo-500/20 px-2.5 py-0.5 rounded-lg border border-indigo-500/30">
                  {validating ? '...' : `${validationData.workingDaysCount} working days`}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs text-slate-400 pt-1 border-t border-white/5">
                <div>
                  Available Balance:{' '}
                  <span className={`font-bold font-mono ${validationData.balance.availableDays < validationData.workingDaysCount ? 'text-rose-400' : 'text-emerald-400'}`}>
                    {validationData.balance.availableDays} days
                  </span>
                </div>
                <div>
                  Applied Policy:{' '}
                  <span className="text-slate-300 font-medium truncate block">
                    {validationData.policy?.name || 'Default Entitlement'}
                  </span>
                </div>
              </div>

              {/* Warnings */}
              {((validationData?.warnings?.length || 0) > 0) && (
                <div className="p-2.5 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs space-y-1">
                  {validationData.warnings.map((w, i) => (
                    <div key={i} className="flex items-start gap-1.5">
                      <Info className="w-3.5 h-3.5 shrink-0 mt-0.5 text-amber-400" />
                      <span>{w}</span>
                    </div>
                  ))}
                </div>
              )}

              {/* Errors */}
              {((validationData?.errors?.length || 0) > 0) && (
                <div className="p-2.5 rounded-lg bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs space-y-1">
                  {validationData.errors.map((errItem, i) => (
                    <div key={i} className="flex items-start gap-1.5">
                      <AlertCircle className="w-3.5 h-3.5 shrink-0 mt-0.5 text-rose-400" />
                      <span>{errItem}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Reason */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              Reason for Leave <span className="text-rose-400">*</span>
            </label>
            <input
              type="text"
              required
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="e.g. Medical consultation, Family bereavement, Official conference..."
              className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 placeholder-slate-500"
            />
          </div>

          {/* Supporting Document */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5 flex items-center justify-between">
              <span>Supporting Document URL (Optional / Policy Conditional)</span>
              {validationData?.policy?.requiresAttachment && (
                <span className="text-[11px] text-amber-400 lowercase font-normal">
                  (Mandatory for &gt;{validationData.policy.attachmentMandatoryAboveDays ?? 0} days)
                </span>
              )}
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={attachmentUrl}
                onChange={(e) => setAttachmentUrl(e.target.value)}
                placeholder="https://docs.school.edu/certificates/med-cert-492.pdf"
                className="flex-1 px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 placeholder-slate-500"
              />
              <input
                type="text"
                value={attachmentName}
                onChange={(e) => setAttachmentName(e.target.value)}
                placeholder="Label / Title"
                className="w-36 px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 placeholder-slate-500"
              />
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
              Additional Handover Notes (Optional)
            </label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="e.g. Laboratory sessions transferred to Mr. Kenneth; grading sheets submitted to HOD."
              className="w-full px-3 py-2 bg-slate-950/60 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 placeholder-slate-500 resize-none"
            />
          </div>

          {/* Administrative Override */}
          {canOverrideBalance && (
            <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20">
              <label className="flex items-center gap-2 text-xs font-semibold text-amber-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={allowBalanceOverride}
                  onChange={(e) => setAllowBalanceOverride(e.target.checked)}
                  className="rounded border-amber-500/40 bg-slate-800 text-amber-500 focus:ring-amber-500 w-4 h-4"
                />
                Apply Administrative Balance Override (Discretionary Approval)
              </label>
            </div>
          )}

          {/* Footer */}
          <div className="pt-2 flex items-center justify-end gap-3 border-t border-white/10">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={isSubmitting}
              className="border-white/10 text-slate-300 hover:bg-white/5"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={isSubmitting || (validationData !== null && !validationData.isValid && !allowBalanceOverride)}
              className="bg-indigo-600 hover:bg-indigo-500 text-white font-semibold flex items-center gap-2"
            >
              <CheckCircle2 className="w-4 h-4" />
              {isSubmitting ? 'Submitting...' : 'Submit Application'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};
