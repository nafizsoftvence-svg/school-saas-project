import React, { useState, useEffect, useCallback } from 'react';
import {
  FileSpreadsheet,
  Users,
  Search,
  Filter,
  BarChart3,
  Layers,
  ShieldCheck,
  RefreshCw,
  ChevronLeft,
  ChevronRight,
  Download,
  CheckCircle2,
  AlertCircle,
  FolderDown,
  Printer
} from 'lucide-react';
import { Button } from '../../components/ui/Button.js';
import { Modal } from '../../components/ui/Modal.js';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner.js';
import { StudentSearchFilterBar, FilterState } from '../../components/student-reports/StudentSearchFilterBar.js';
import { StudentDirectoryTable } from '../../components/student-reports/StudentDirectoryTable.js';
import { BulkOperationsModal } from '../../components/student-reports/BulkOperationsModal.js';
import { StudentReportsViewer } from '../../components/student-reports/StudentReportsViewer.js';
import { StudentReportsExportToolbar, ExportColumn } from '../../components/student-reports/StudentReportsExportToolbar.js';
import { StudentMasterProfile } from '../../components/students/StudentMasterProfile.js';
import { api } from '../../services/api.js';
import {
  StudentReportItem,
  SchoolClass,
  Section,
  AcademicSession
} from '../../types/index.js';

interface AdminStudentReportsPageProps {
  activeTab?: 'directory' | 'reports';
  onTabChange?: (tab: 'directory' | 'reports') => void;
  hideTabBar?: boolean;
}

export const AdminStudentReportsPage: React.FC<AdminStudentReportsPageProps> = ({
  activeTab: propActiveTab,
  onTabChange,
  hideTabBar = true
}) => {
  const [internalViewMode, setInternalViewMode] = useState<'directory' | 'reports'>('directory');
  const viewMode = propActiveTab || internalViewMode;
  const setViewMode = (tab: 'directory' | 'reports') => {
    setInternalViewMode(tab);
    onTabChange?.(tab);
  };

  // Metadata
  const [classes, setClasses] = useState<SchoolClass[]>([]);
  const [sections, setSections] = useState<Section[]>([]);
  const [sessions, setSessions] = useState<AcademicSession[]>([]);
  const [activeSession, setActiveSession] = useState<AcademicSession | null>(null);

  // Filters state
  const [filters, setFilters] = useState<FilterState>({
    search: '',
    academicSessionId: 'ALL',
    classId: 'ALL',
    sectionId: 'ALL',
    status: 'ALL',
    enrollmentStatus: 'ALL',
    gender: 'ALL',
    bloodGroup: 'ALL',
    admissionDateFrom: '',
    admissionDateTo: '',
    enrollmentDateFrom: '',
    enrollmentDateTo: '',
    documentStatus: 'ALL',
    idCardStatus: 'ALL'
  });

  // Table Data & Pagination
  const [students, setStudents] = useState<StudentReportItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [pagination, setPagination] = useState({
    total: 0,
    page: 1,
    limit: 25,
    totalPages: 1
  });
  const [sortBy, setSortBy] = useState<string>('fullName');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');

  // Selection & Bulk Actions
  const [selectedStudentIds, setSelectedStudentIds] = useState<Set<string>>(new Set());
  const [isBulkModalOpen, setIsBulkModalOpen] = useState(false);

  // Student Profile Dossier Modal
  const [selectedStudentIdForProfile, setSelectedStudentIdForProfile] = useState<string | null>(null);

  // 1. Initial Load of Metadata (Classes, Sections, Sessions)
  useEffect(() => {
    const fetchMetadata = async () => {
      try {
        const [clsRes, secRes, sessRes] = await Promise.all([
          api.academic.getClasses(),
          api.academic.getSections(),
          api.academic.getSessions()
        ]);
        const clsList = ((clsRes as any)?.data || clsRes || []) as SchoolClass[];
        const secList = ((secRes as any)?.data || secRes || []) as Section[];
        const sessList = ((sessRes as any)?.data || sessRes || []) as AcademicSession[];

        setClasses(clsList);
        setSections(secList);
        setSessions(sessList);

        const current = sessList.find((s) => s.isCurrent) || sessList?.[0] || null;
        setActiveSession(current);
      } catch (err) {
        console.error('Failed to load classes/sessions metadata:', err);
      }
    };

    fetchMetadata();
  }, []);

  // 2. Fetch Students using Centralized Search API
  const fetchStudents = useCallback(async () => {
    setLoading(true);
    try {
      const res = (await api.studentReports.search({
        search: filters.search || undefined,
        academicSessionId: filters.academicSessionId !== 'ALL' ? filters.academicSessionId : undefined,
        classId: filters.classId !== 'ALL' ? filters.classId : undefined,
        sectionId: filters.sectionId !== 'ALL' ? filters.sectionId : undefined,
        status: filters.status !== 'ALL' ? filters.status : undefined,
        enrollmentStatus: filters.enrollmentStatus !== 'ALL' ? filters.enrollmentStatus : undefined,
        gender: filters.gender !== 'ALL' ? filters.gender : undefined,
        bloodGroup: filters.bloodGroup !== 'ALL' ? filters.bloodGroup : undefined,
        admissionDateFrom: filters.admissionDateFrom || undefined,
        admissionDateTo: filters.admissionDateTo || undefined,
        enrollmentDateFrom: filters.enrollmentDateFrom || undefined,
        enrollmentDateTo: filters.enrollmentDateTo || undefined,
        documentStatus: filters.documentStatus !== 'ALL' ? filters.documentStatus : undefined,
        idCardStatus: filters.idCardStatus !== 'ALL' ? filters.idCardStatus : undefined,
        page: pagination.page,
        limit: pagination.limit,
        sortBy,
        sortOrder
      })) as any;

      if (res.success) {
        const studentList: StudentReportItem[] = Array.isArray(res.data) ? res.data : (res.data?.data || []);
        const pag = res.pagination || res.data?.pagination;
        setStudents(studentList);
        if (pag) {
          setPagination((prev) => ({
            ...prev,
            total: pag.total || 0,
            totalPages: pag.totalPages || 1
          }));
        }
      }
    } catch (err) {
      console.error('Failed to load student reports search:', err);
    } finally {
      setLoading(false);
    }
  }, [filters, pagination.page, pagination.limit, sortBy, sortOrder]);

  useEffect(() => {
    fetchStudents();
  }, [fetchStudents]);

  // Selection Handlers
  const handleToggleSelect = (studentId: string) => {
    const updated = new Set(selectedStudentIds);
    if (updated.has(studentId)) {
      updated.delete(studentId);
    } else {
      updated.add(studentId);
    }
    setSelectedStudentIds(updated);
  };

  const handleToggleSelectAll = () => {
    const isAllVisibleSelected =
      students.length > 0 && students.every((s) => selectedStudentIds.has(s.id));

    const updated = new Set(selectedStudentIds);
    if (isAllVisibleSelected) {
      students.forEach((s) => updated.delete(s.id));
    } else {
      students.forEach((s) => updated.add(s.id));
    }
    setSelectedStudentIds(updated);
  };

  const handleSelectEntireQuery = async () => {
    try {
      const res = (await api.studentReports.search({
        search: filters.search || undefined,
        academicSessionId: filters.academicSessionId !== 'ALL' ? filters.academicSessionId : undefined,
        classId: filters.classId !== 'ALL' ? filters.classId : undefined,
        sectionId: filters.sectionId !== 'ALL' ? filters.sectionId : undefined,
        status: filters.status !== 'ALL' ? filters.status : undefined,
        enrollmentStatus: filters.enrollmentStatus !== 'ALL' ? filters.enrollmentStatus : undefined,
        gender: filters.gender !== 'ALL' ? filters.gender : undefined,
        bloodGroup: filters.bloodGroup !== 'ALL' ? filters.bloodGroup : undefined,
        admissionDateFrom: filters.admissionDateFrom || undefined,
        admissionDateTo: filters.admissionDateTo || undefined,
        enrollmentDateFrom: filters.enrollmentDateFrom || undefined,
        enrollmentDateTo: filters.enrollmentDateTo || undefined,
        documentStatus: filters.documentStatus !== 'ALL' ? filters.documentStatus : undefined,
        idCardStatus: filters.idCardStatus !== 'ALL' ? filters.idCardStatus : undefined,
        limit: 1000 // Get all
      })) as any;

      if (res.success) {
        const studentList: StudentReportItem[] = Array.isArray(res.data) ? res.data : (res.data?.data || []);
        const allIds = new Set(studentList.map((s) => s.id));
        setSelectedStudentIds(allIds);
      }
    } catch (err) {
      console.error('Failed to select all query records:', err);
    }
  };

  const handleSort = (column: string) => {
    if (sortBy === column) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(column);
      setSortOrder('asc');
    }
  };

  const handleResetFilters = () => {
    setFilters({
      search: '',
      academicSessionId: 'ALL',
      classId: 'ALL',
      sectionId: 'ALL',
      status: 'ALL',
      enrollmentStatus: 'ALL',
      gender: 'ALL',
      bloodGroup: 'ALL',
      admissionDateFrom: '',
      admissionDateTo: '',
      enrollmentDateFrom: '',
      enrollmentDateTo: '',
      documentStatus: 'ALL',
      idCardStatus: 'ALL'
    });
    setPagination((prev) => ({ ...prev, page: 1 }));
  };

  // Directory Export Columns
  const directoryExportColumns: ExportColumn[] = [
    { header: 'Admission #', key: 'admissionNumber' },
    { header: 'Roll #', key: 'rollNumber' },
    { header: 'Student Name', key: 'fullName' },
    { header: 'Class', key: 'className' },
    { header: 'Section', key: 'sectionName' },
    { header: 'Academic Session', key: 'academicSessionName' },
    { header: 'Status', key: 'status' },
    { header: 'Gender', key: 'gender' },
    { header: 'Blood Group', key: 'bloodGroup' },
    { header: 'Admission Date', key: 'admissionDate' },
    { header: 'Enrollment Date', key: 'enrollmentDate' },
    { header: 'Guardian Name', key: 'guardianName' },
    { header: 'Guardian Phone', key: 'guardianPhone' },
    { header: 'Document Compliance', key: 'documentStatus' },
    { header: 'ID Card Status', key: 'idCardStatus' }
  ];

  // Selected student objects for bulk modal
  const selectedStudentsList = students.filter((s) => selectedStudentIds.has(s.id));

  return (
    <div className="space-y-5 p-4 sm:p-6 max-w-7xl mx-auto">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center px-2 py-0.5 rounded text-3xs font-bold uppercase tracking-wider bg-indigo-50 text-indigo-700 border border-indigo-200">
              Part 9F • Institutional Intelligence
            </span>
            {activeSession && (
              <span className="text-xs text-slate-500 font-medium">
                Active Session: <strong>{activeSession.sessionName}</strong>
              </span>
            )}
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 mt-1 flex items-center gap-2">
            <Users className="w-6 h-6 text-indigo-600" />
            Student Reports, Search & Operations
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Centralized directory search, multi-criteria filtering, batch operations, and regulatory data exports.
          </p>
        </div>

        {/* View Mode Toggle & Global Actions */}
        <div className="flex items-center gap-2 w-full sm:w-auto">
          {!hideTabBar && (
            <div className="bg-slate-100 p-1 rounded-xl flex items-center border border-slate-200">
              <button
                type="button"
                onClick={() => setViewMode('directory')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
                  viewMode === 'directory'
                    ? 'bg-white text-indigo-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Users className="w-3.5 h-3.5 text-indigo-600" />
                <span>Roster & Directory</span>
              </button>

              <button
                type="button"
                onClick={() => setViewMode('reports')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
                  viewMode === 'reports'
                    ? 'bg-white text-indigo-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <BarChart3 className="w-3.5 h-3.5 text-indigo-600" />
                <span>Analytical Reports</span>
              </button>
            </div>
          )}

          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => fetchStudents()}
            disabled={loading}
            className="h-8 text-xs text-slate-700 hover:bg-slate-50"
            title="Refresh current dataset"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin text-indigo-600' : ''}`} />
          </Button>
        </div>
      </div>

      {/* VIEW MODE 1: DIRECTORY & ROSTER */}
      {viewMode === 'directory' && (
        <div className="space-y-4">
          {/* Search & Multi-criteria Filter Bar */}
          <StudentSearchFilterBar
            filters={filters}
            onChange={setFilters}
            onApply={() => {
              setPagination((prev) => ({ ...prev, page: 1 }));
              fetchStudents();
            }}
            onReset={handleResetFilters}
            sessions={sessions}
            classes={classes}
            sections={sections}
            isLoading={loading}
          />

          {/* Export Toolbar for Filtered Directory */}
          <StudentReportsExportToolbar
            reportTitle="Student_Directory_Master_Roster"
            data={students}
            columns={directoryExportColumns}
            filterContext={filters}
            disabled={students.length === 0}
          />

          {/* Directory Table */}
          <StudentDirectoryTable
            students={students}
            selectedStudentIds={selectedStudentIds}
            onToggleSelect={handleToggleSelect}
            onToggleSelectAll={handleToggleSelectAll}
            onSelectEntireQuery={handleSelectEntireQuery}
            totalMatchingQuery={pagination.total}
            allQuerySelected={selectedStudentIds.size === pagination.total && pagination.total > 0}
            onOpenBulkModal={() => setIsBulkModalOpen(true)}
            onViewStudentProfile={(id) => setSelectedStudentIdForProfile(id)}
            onSort={handleSort}
            currentSortBy={sortBy}
            currentSortOrder={sortOrder}
            isLoading={loading}
          />

          {/* Pagination Controls */}
          {pagination.total > 0 && (
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-white border border-slate-200 rounded-xl p-3 shadow-2xs">
              <div className="text-xs text-slate-500">
                Showing{' '}
                <strong className="text-slate-900 font-semibold">
                  {(pagination.page - 1) * pagination.limit + 1}
                </strong>{' '}
                to{' '}
                <strong className="text-slate-900 font-semibold">
                  {Math.min(pagination.page * pagination.limit, pagination.total)}
                </strong>{' '}
                of <strong className="text-slate-900 font-semibold">{pagination.total}</strong> scholars
              </div>

              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1 text-xs text-slate-600 mr-2">
                  <span>Page size:</span>
                  <select
                    value={pagination.limit}
                    onChange={(e) => {
                      setPagination((prev) => ({
                        ...prev,
                        limit: Number(e.target.value),
                        page: 1
                      }));
                    }}
                    className="text-xs py-1 px-1.5 border border-slate-300 rounded bg-white"
                  >
                    <option value={10}>10</option>
                    <option value={25}>25</option>
                    <option value={50}>50</option>
                    <option value={100}>100</option>
                  </select>
                </div>

                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  disabled={pagination.page <= 1 || loading}
                  onClick={() => setPagination((prev) => ({ ...prev, page: prev.page - 1 }))}
                  className="h-8 px-2.5 text-xs text-slate-700"
                >
                  <ChevronLeft className="w-4 h-4" />
                </Button>

                <span className="text-xs font-semibold text-slate-700 px-2">
                  Page {pagination.page} of {pagination.totalPages || 1}
                </span>

                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  disabled={pagination.page >= pagination.totalPages || loading}
                  onClick={() => setPagination((prev) => ({ ...prev, page: prev.page + 1 }))}
                  className="h-8 px-2.5 text-xs text-slate-700"
                >
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* VIEW MODE 2: ANALYTICAL & REGULATORY REPORTS */}
      {viewMode === 'reports' && (
        <StudentReportsViewer
          sessions={sessions}
          classes={classes}
          sections={sections}
          activeSessionId={activeSession?.id}
          onViewStudentProfile={(id) => setSelectedStudentIdForProfile(id)}
        />
      )}

      {/* BULK OPERATIONS MODAL */}
      {isBulkModalOpen && (
        <BulkOperationsModal
          isOpen={isBulkModalOpen}
          onClose={() => setIsBulkModalOpen(false)}
          selectedStudents={selectedStudentsList}
          classes={classes}
          sections={sections}
          onSuccess={() => {
            setSelectedStudentIds(new Set());
            fetchStudents();
          }}
        />
      )}

      {/* STUDENT MASTER PROFILE DOSSIER MODAL */}
      {selectedStudentIdForProfile && (
        <Modal
          isOpen={Boolean(selectedStudentIdForProfile)}
          onClose={() => setSelectedStudentIdForProfile(null)}
          title="Student Master Dossier"
          size="xl"
        >
          <div className="py-2">
            <StudentMasterProfile
              studentId={selectedStudentIdForProfile}
              allowEdit={true}
              isSelfService={false}
              onRefresh={() => fetchStudents()}
            />
          </div>
        </Modal>
      )}
    </div>
  );
};
