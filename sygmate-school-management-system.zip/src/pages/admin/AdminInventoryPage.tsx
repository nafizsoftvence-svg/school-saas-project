import React, { useState, useEffect } from 'react';
import {
  Package,
  ShieldCheck,
  Truck,
  Layers,
  Sparkles,
  RefreshCw,
  Search,
  Plus,
  AlertCircle,
  CheckCircle,
  X,
  ArrowRight,
  Filter,
  Boxes,
  ShoppingBag,
  Building,
  BarChart3
} from 'lucide-react';
import { api } from '../../services/api';
import {
  InventoryDashboardStats,
  InventoryItem,
  Asset,
  Supplier,
  InventoryCategory,
  InventoryUnit,
  InventoryLocation,
  AssetCategory,
  InventoryItemStatus,
  AssetStatus,
  CreateInventoryItemPayload,
  UpdateInventoryItemPayload,
  CreateAssetPayload,
  UpdateAssetPayload,
  CreateSupplierPayload,
  UpdateSupplierPayload
} from '../../types';

import { InventoryDashboardTab } from '../../components/inventory/InventoryDashboardTab';
import { InventoryItemsTab } from '../../components/inventory/InventoryItemsTab';
import { StockManagementTab } from '../../components/inventory/StockManagementTab';
import { ProcurementTab } from '../../components/inventory/ProcurementTab';
import { AssetsRegisterTab } from '../../components/inventory/AssetsRegisterTab';
import { SuppliersTab } from '../../components/inventory/SuppliersTab';
import { InventorySetupTab } from '../../components/inventory/InventorySetupTab';
import { IssueReturnTab } from '../../components/inventory/IssueReturnTab';
import { DepartmentAllocationTab } from '../../components/inventory/DepartmentAllocationTab';
import { InventoryReportsTab } from '../../components/inventory/InventoryReportsTab';
import { BulkAssetAllocationModal } from '../../components/inventory/BulkAssetAllocationModal';

import { ItemModal } from '../../components/inventory/ItemModal';
import { AssetModal } from '../../components/inventory/AssetModal';
import { AssetDetailModal } from '../../components/inventory/AssetDetailModal';
import { SupplierModal } from '../../components/inventory/SupplierModal';
import {
  CategoryModal,
  UnitModal,
  LocationModal
} from '../../components/inventory/SetupModals';
import { StatusChangeModal } from '../../components/inventory/StatusChangeModal';
import { Department, StaffProfile } from '../../types';

interface AdminInventoryPageProps {
  activeTab?: 'overview' | 'items' | 'stock' | 'issues' | 'assets' | 'departments' | 'procurement' | 'suppliers' | 'setup' | 'reports';
  onTabChange?: (tab: string) => void;
  hideTabBar?: boolean;
}

export const AdminInventoryPage: React.FC<AdminInventoryPageProps> = ({
  activeTab: propActiveTab,
  onTabChange,
  hideTabBar = true
}) => {
  const [internalTab, setInternalTab] = useState<
    'overview' | 'items' | 'stock' | 'issues' | 'assets' | 'departments' | 'procurement' | 'suppliers' | 'setup' | 'reports'
  >('overview');
  const activeTab = (propActiveTab as any) || internalTab;
  const setActiveTab = (tab: any) => {
    setInternalTab(tab);
    onTabChange?.(tab);
  };

  // Datasets
  const [stats, setStats] = useState<InventoryDashboardStats | null>(null);
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [assets, setAssets] = useState<Asset[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [categories, setCategories] = useState<InventoryCategory[]>([]);
  const [units, setUnits] = useState<InventoryUnit[]>([]);
  const [locations, setLocations] = useState<InventoryLocation[]>([]);
  const [assetCategories, setAssetCategories] = useState<AssetCategory[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [staffMembers, setStaffMembers] = useState<StaffProfile[]>([]);
  const [isBulkAllocationOpen, setIsBulkAllocationOpen] = useState(false);

  const [loading, setLoading] = useState(true);
  const [actionSuccessMessage, setActionSuccessMessage] = useState<string | null>(null);
  const [actionErrorMessage, setActionErrorMessage] = useState<string | null>(null);

  // Global search
  const [globalSearchQuery, setGlobalSearchQuery] = useState('');
  const [showGlobalResults, setShowGlobalResults] = useState(false);

  // Modal States
  const [isItemModalOpen, setIsItemModalOpen] = useState(false);
  const [selectedItemForEdit, setSelectedItemForEdit] = useState<InventoryItem | null>(null);

  const [isAssetModalOpen, setIsAssetModalOpen] = useState(false);
  const [selectedAssetForEdit, setSelectedAssetForEdit] = useState<Asset | null>(null);

  const [isAssetDetailOpen, setIsAssetDetailOpen] = useState(false);
  const [selectedAssetForDetail, setSelectedAssetForDetail] = useState<Asset | null>(null);

  const [isStatusModalOpen, setIsStatusModalOpen] = useState(false);
  const [selectedAssetForStatus, setSelectedAssetForStatus] = useState<Asset | null>(null);

  const [isSupplierModalOpen, setIsSupplierModalOpen] = useState(false);
  const [selectedSupplierForEdit, setSelectedSupplierForEdit] = useState<Supplier | null>(null);

  const [isCategoryModalOpen, setIsCategoryModalOpen] = useState(false);
  const [selectedCategoryForEdit, setSelectedCategoryForEdit] = useState<InventoryCategory | null>(null);

  const [isUnitModalOpen, setIsUnitModalOpen] = useState(false);
  const [selectedUnitForEdit, setSelectedUnitForEdit] = useState<InventoryUnit | null>(null);

  const [isLocationModalOpen, setIsLocationModalOpen] = useState(false);
  const [selectedLocationForEdit, setSelectedLocationForEdit] = useState<InventoryLocation | null>(null);

  // Load all initial data
  const loadAllData = async () => {
    try {
      setLoading(true);
      const [
        statsData,
        itemsData,
        assetsData,
        suppliersData,
        categoriesData,
        unitsData,
        locationsData,
        assetCategoriesData,
        departmentsData,
        staffData
      ] = await Promise.all([
        api.inventory.getDashboardStats().catch(() => null),
        api.inventory.getItems().catch(() => null),
        api.inventory.getAssets().catch(() => null),
        api.inventory.getSuppliers().catch(() => null),
        api.inventory.getCategories().catch(() => null),
        api.inventory.getUnits().catch(() => null),
        api.inventory.getLocations().catch(() => null),
        api.inventory.getAssetCategories().catch(() => null),
        api.academic.getDepartments().catch(() => null),
        api.staff.getDirectory({ limit: 100 }).then((res) => (res as any)?.staff || (res as any)?.data || []).catch(() => [])
      ]);

      const extractArray = <T,>(res: any): T[] => {
        if (!res) return [];
        if (Array.isArray(res)) return res;
        if (Array.isArray(res.data)) return res.data;
        if (Array.isArray(res.items)) return res.items;
        return [];
      };

      if (statsData) setStats((statsData as any)?.data || statsData);
      setItems(extractArray<InventoryItem>(itemsData));
      setAssets(extractArray<Asset>(assetsData));
      setSuppliers(extractArray<Supplier>(suppliersData));
      setCategories(extractArray<InventoryCategory>(categoriesData));
      setUnits(extractArray<InventoryUnit>(unitsData));
      setLocations(extractArray<InventoryLocation>(locationsData));
      setAssetCategories(extractArray<AssetCategory>(assetCategoriesData));
      setDepartments(extractArray<Department>(departmentsData));
      setStaffMembers(extractArray<StaffProfile>(staffData));
    } catch (err: any) {
      setActionErrorMessage(err.message || 'Failed to load inventory data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAllData();
  }, []);

  const showNotification = (msg: string, isError = false) => {
    if (isError) {
      setActionErrorMessage(msg);
      setTimeout(() => setActionErrorMessage(null), 5000);
    } else {
      setActionSuccessMessage(msg);
      setTimeout(() => setActionSuccessMessage(null), 4000);
    }
  };

  // ==========================================
  // Inventory Item Handlers
  // ==========================================
  const handleCreateOrUpdateItem = async (payload: CreateInventoryItemPayload | UpdateInventoryItemPayload) => {
    if (selectedItemForEdit) {
      const res = await api.inventory.updateItem(selectedItemForEdit.id, payload);
      const item = (res as any)?.data || (res as any)?.item || res;
      setItems(prev => prev.map(i => i.id === item.id ? item : i));
      showNotification(`Item '${item.name}' updated successfully.`);
    } else {
      const res = await api.inventory.createItem(payload as CreateInventoryItemPayload);
      const item = (res as any)?.data || (res as any)?.item || res;
      setItems(prev => [item, ...prev]);
      showNotification(`Item '${item.name}' created with SKU ${item.itemCode}.`);
    }
    // Refresh stats in background
    api.inventory.getDashboardStats().then(setStats).catch(() => {});
  };

  const handleUpdateItemStatus = async (id: string, status: InventoryItemStatus) => {
    try {
      const res = await api.inventory.updateItemStatus(id, status);
      const item = (res as any)?.data || (res as any)?.item || res;
      setItems(prev => prev.map(i => i.id === id ? (item.id === id ? item : { ...i, status }) : i));
      showNotification(`Item status updated to ${status}.`);
      api.inventory.getDashboardStats().then(setStats).catch(() => {});
    } catch (err: any) {
      showNotification(err.message || 'Failed to update item status', true);
    }
  };

  const handleDeleteItem = async (id: string) => {
    try {
      await api.inventory.deleteItem(id);
      setItems(prev => prev.filter(i => i.id !== id));
      showNotification('Inventory item deleted.');
      api.inventory.getDashboardStats().then(setStats).catch(() => {});
    } catch (err: any) {
      showNotification(err.message || 'Failed to delete item', true);
    }
  };

  // ==========================================
  // Asset Handlers
  // ==========================================
  const handleCreateOrUpdateAsset = async (payload: CreateAssetPayload | UpdateAssetPayload) => {
    if (selectedAssetForEdit) {
      const res = await api.inventory.updateAsset(selectedAssetForEdit.id, payload);
      const asset = (res as any)?.data || (res as any)?.asset || res;
      setAssets(prev => prev.map(a => a.id === asset.id ? asset : a));
      if (selectedAssetForDetail?.id === asset.id) {
        setSelectedAssetForDetail(asset);
      }
      showNotification(`Asset '${asset.name}' updated successfully.`);
    } else {
      const res = await api.inventory.createAsset(payload as CreateAssetPayload);
      const asset = (res as any)?.data || (res as any)?.asset || res;
      setAssets(prev => [asset, ...prev]);
      showNotification(`Asset registered with tag ${asset.assetTag}.`);
    }
    api.inventory.getDashboardStats().then(setStats).catch(() => {});
  };

  const handleUpdateAssetStatus = async (assetId: string, status: AssetStatus, remarks?: string) => {
    try {
      const res = await api.inventory.updateAssetStatus(assetId, status, remarks);
      const asset = (res as any)?.data || (res as any)?.asset || res;
      setAssets(prev => prev.map(a => a.id === assetId ? (asset.id === assetId ? asset : { ...a, status }) : a));
      if (selectedAssetForDetail?.id === assetId) {
        setSelectedAssetForDetail(asset);
      }
      showNotification(`Asset operational status transitioned to ${status}.`);
      api.inventory.getDashboardStats().then(setStats).catch(() => {});
    } catch (err: any) {
      showNotification(err.message || 'Failed to update asset status', true);
    }
  };

  const handleDeleteAsset = async (id: string) => {
    try {
      await api.inventory.deleteAsset(id);
      setAssets(prev => prev.filter(a => a.id !== id));
      if (selectedAssetForDetail?.id === id) {
        setIsAssetDetailOpen(false);
      }
      showNotification('Asset removed from register.');
      api.inventory.getDashboardStats().then(setStats).catch(() => {});
    } catch (err: any) {
      showNotification(err.message || 'Failed to delete asset', true);
    }
  };

  // ==========================================
  // Supplier Handlers
  // ==========================================
  const handleCreateOrUpdateSupplier = async (payload: CreateSupplierPayload | UpdateSupplierPayload) => {
    if (selectedSupplierForEdit) {
      const res = await api.inventory.updateSupplier(selectedSupplierForEdit.id, payload);
      const supplier = (res as any)?.data || (res as any)?.supplier || res;
      setSuppliers(prev => prev.map(s => s.id === supplier.id ? supplier : s));
      showNotification(`Supplier '${supplier.name}' updated successfully.`);
    } else {
      const res = await api.inventory.createSupplier(payload as CreateSupplierPayload);
      const supplier = (res as any)?.data || (res as any)?.supplier || res;
      setSuppliers(prev => [supplier, ...prev]);
      showNotification(`Vendor registered with code ${supplier.supplierCode}.`);
    }
    api.inventory.getDashboardStats().then(setStats).catch(() => {});
  };

  const handleDeleteSupplier = async (id: string) => {
    try {
      await api.inventory.deleteSupplier(id);
      setSuppliers(prev => prev.filter(s => s.id !== id));
      showNotification('Supplier deleted.');
      api.inventory.getDashboardStats().then(setStats).catch(() => {});
    } catch (err: any) {
      showNotification(err.message || 'Failed to delete supplier', true);
    }
  };

  // ==========================================
  // Master Setup Handlers
  // ==========================================
  const handleSaveCategory = async (payload: any) => {
    if (selectedCategoryForEdit) {
      const res = await api.inventory.updateCategory(selectedCategoryForEdit.id, payload);
      const category = (res as any)?.data || (res as any)?.category || res;
      setCategories(prev => prev.map(c => c.id === category.id ? category : c));
      showNotification(`Category '${category.name}' updated.`);
    } else {
      const res = await api.inventory.createCategory(payload);
      const category = (res as any)?.data || (res as any)?.category || res;
      setCategories(prev => [...prev, category]);
      showNotification(`Category '${category.name}' created.`);
    }
  };

  const handleDeleteCategory = async (id: string) => {
    try {
      await api.inventory.deleteCategory(id);
      setCategories(prev => prev.filter(c => c.id !== id));
      showNotification('Category deleted.');
    } catch (err: any) {
      showNotification(err.message || 'Failed to delete category', true);
    }
  };

  const handleSaveUnit = async (payload: any) => {
    if (selectedUnitForEdit) {
      const res = await api.inventory.updateUnit(selectedUnitForEdit.id, payload);
      const unit = (res as any)?.data || (res as any)?.unit || res;
      setUnits(prev => prev.map(u => u.id === unit.id ? unit : u));
      showNotification(`Unit '${unit.name}' updated.`);
    } else {
      const res = await api.inventory.createUnit(payload);
      const unit = (res as any)?.data || (res as any)?.unit || res;
      setUnits(prev => [...prev, unit]);
      showNotification(`Unit '${unit.name}' (${unit.shortCode}) created.`);
    }
  };

  const handleDeleteUnit = async (id: string) => {
    try {
      await api.inventory.deleteUnit(id);
      setUnits(prev => prev.filter(u => u.id !== id));
      showNotification('Unit of measurement deleted.');
    } catch (err: any) {
      showNotification(err.message || 'Failed to delete unit', true);
    }
  };

  const handleSaveLocation = async (payload: any) => {
    if (selectedLocationForEdit) {
      const res = await api.inventory.updateLocation(selectedLocationForEdit.id, payload);
      const location = (res as any)?.data || (res as any)?.location || res;
      setLocations(prev => prev.map(l => l.id === location.id ? location : l));
      showNotification(`Location '${location.name}' updated.`);
    } else {
      const res = await api.inventory.createLocation(payload);
      const location = (res as any)?.data || (res as any)?.location || res;
      setLocations(prev => [...prev, location]);
      showNotification(`Location '${location.name}' created.`);
    }
    api.inventory.getDashboardStats().then(setStats).catch(() => {});
  };

  const handleDeleteLocation = async (id: string) => {
    try {
      await api.inventory.deleteLocation(id);
      setLocations(prev => prev.filter(l => l.id !== id));
      showNotification('Location deleted.');
      api.inventory.getDashboardStats().then(setStats).catch(() => {});
    } catch (err: any) {
      showNotification(err.message || 'Failed to delete location', true);
    }
  };

  // Global search filtering across items, assets, and suppliers
  const safeItems = Array.isArray(items) ? items : [];
  const safeAssets = Array.isArray(assets) ? assets : [];
  const safeSuppliers = Array.isArray(suppliers) ? suppliers : [];

  const globalMatchingItems = globalSearchQuery.trim()
    ? safeItems.filter(i =>
        i.name.toLowerCase().includes(globalSearchQuery.toLowerCase()) ||
        i.itemCode.toLowerCase().includes(globalSearchQuery.toLowerCase()) ||
        (i.brand && i.brand.toLowerCase().includes(globalSearchQuery.toLowerCase()))
      ).slice(0, 4)
    : [];

  const globalMatchingAssets = globalSearchQuery.trim()
    ? safeAssets.filter(a =>
        a.name.toLowerCase().includes(globalSearchQuery.toLowerCase()) ||
        a.assetTag.toLowerCase().includes(globalSearchQuery.toLowerCase()) ||
        (a.serialNumber && a.serialNumber.toLowerCase().includes(globalSearchQuery.toLowerCase()))
      ).slice(0, 4)
    : [];

  const globalMatchingSuppliers = globalSearchQuery.trim()
    ? safeSuppliers.filter(s =>
        s.name.toLowerCase().includes(globalSearchQuery.toLowerCase()) ||
        s.supplierCode.toLowerCase().includes(globalSearchQuery.toLowerCase()) ||
        s.contactPerson.toLowerCase().includes(globalSearchQuery.toLowerCase())
      ).slice(0, 4)
    : [];

  return (
    <div className="space-y-6">
      {/* Top Notification Toast */}
      {actionSuccessMessage && (
        <div className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs flex items-center justify-between shadow-lg">
          <div className="flex items-center space-x-2">
            <CheckCircle className="w-4 h-4 flex-shrink-0" />
            <span>{actionSuccessMessage}</span>
          </div>
          <button onClick={() => setActionSuccessMessage(null)}>
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {actionErrorMessage && (
        <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs flex items-center justify-between shadow-lg">
          <div className="flex items-center space-x-2">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            <span>{actionErrorMessage}</span>
          </div>
          <button onClick={() => setActionErrorMessage(null)}>
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Page Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 p-5 rounded-2xl glass-panel border border-slate-800">
        <div>
          <div className="flex items-center space-x-2 text-xs text-indigo-400 font-semibold uppercase tracking-wider mb-1">
            <span>Institutional Operations</span>
            <span>•</span>
            <span>Logistics & Asset Control</span>
          </div>
          <h1 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2.5">
            <Package className="w-6 h-6 text-indigo-400" />
            Inventory & Asset Management
          </h1>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            Centralized register for institutional equipment, hardware asset tags, stationery catalogs, vendor contracts, and physical store facilities.
          </p>
        </div>

        {/* Search and Refresh */}
        <div className="flex items-center gap-3">
          {/* Global Search Bar */}
          <div className="relative w-full sm:w-72">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search items, tags, vendors..."
              value={globalSearchQuery}
              onChange={(e) => {
                setGlobalSearchQuery(e.target.value);
                setShowGlobalResults(true);
              }}
              onFocus={() => setShowGlobalResults(true)}
              className="w-full pl-9 pr-4 py-2 text-xs rounded-xl glass-input border border-slate-700/80 focus:outline-none focus:border-indigo-500 text-slate-100 placeholder-slate-500"
            />

            {/* Global Search Dropdown */}
            {showGlobalResults && globalSearchQuery.trim() && (
              <div className="absolute right-0 left-0 mt-2 p-3 bg-slate-900 border border-slate-700 rounded-xl shadow-2xl z-50 space-y-3 max-h-80 overflow-y-auto">
                <div className="flex items-center justify-between text-[11px] font-semibold text-slate-400 border-b border-slate-800 pb-1.5">
                  <span>Fast Search Results</span>
                  <button onClick={() => setShowGlobalResults(false)} className="text-slate-400 hover:text-white">
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Items */}
                {globalMatchingItems.length > 0 && (
                  <div>
                    <div className="text-[10px] font-bold text-indigo-400 uppercase tracking-wider mb-1">
                      Inventory Items
                    </div>
                    {globalMatchingItems.map(item => (
                      <div
                        key={item.id}
                        onClick={() => {
                          setActiveTab('items');
                          setShowGlobalResults(false);
                          setGlobalSearchQuery('');
                        }}
                        className="p-1.5 hover:bg-slate-800 rounded flex items-center justify-between cursor-pointer text-xs"
                      >
                        <span className="text-white font-medium">{item.name}</span>
                        <span className="font-mono text-[11px] text-indigo-400">{item.itemCode}</span>
                      </div>
                    ))}
                  </div>
                )}

                {/* Assets */}
                {globalMatchingAssets.length > 0 && (
                  <div>
                    <div className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider mb-1">
                      Registered Assets
                    </div>
                    {globalMatchingAssets.map(asset => (
                      <div
                        key={asset.id}
                        onClick={() => {
                          setSelectedAssetForDetail(asset);
                          setIsAssetDetailOpen(true);
                          setShowGlobalResults(false);
                          setGlobalSearchQuery('');
                        }}
                        className="p-1.5 hover:bg-slate-800 rounded flex items-center justify-between cursor-pointer text-xs"
                      >
                        <span className="text-white font-medium">{asset.name}</span>
                        <span className="font-mono text-[11px] text-emerald-400">{asset.assetTag}</span>
                      </div>
                    ))}
                  </div>
                )}

                {/* Suppliers */}
                {globalMatchingSuppliers.length > 0 && (
                  <div>
                    <div className="text-[10px] font-bold text-teal-400 uppercase tracking-wider mb-1">
                      Vendors & Suppliers
                    </div>
                    {globalMatchingSuppliers.map(sup => (
                      <div
                        key={sup.id}
                        onClick={() => {
                          setActiveTab('suppliers');
                          setShowGlobalResults(false);
                          setGlobalSearchQuery('');
                        }}
                        className="p-1.5 hover:bg-slate-800 rounded flex items-center justify-between cursor-pointer text-xs"
                      >
                        <span className="text-white font-medium">{sup.name}</span>
                        <span className="font-mono text-[11px] text-teal-400">{sup.supplierCode}</span>
                      </div>
                    ))}
                  </div>
                )}

                {globalMatchingItems.length === 0 && globalMatchingAssets.length === 0 && globalMatchingSuppliers.length === 0 && (
                  <div className="py-4 text-center text-xs text-slate-400">
                    No results found matching "{globalSearchQuery}"
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Refresh Button */}
          <button
            onClick={loadAllData}
            disabled={loading}
            className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors disabled:opacity-50"
            title="Reload entire dataset"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-indigo-400' : ''}`} />
          </button>
        </div>
      </div>

      {/* Main Tab Navigation (Hidden when subtabs are hosted in sidebar) */}
      {!hideTabBar && (
        <div className="flex overflow-x-auto space-x-2 border-b border-slate-800 pb-2">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-4 py-2 text-xs font-semibold rounded-xl transition-all flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'overview'
                ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-950'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            Command Center
          </button>

          <button
            onClick={() => setActiveTab('items')}
            className={`px-4 py-2 text-xs font-semibold rounded-xl transition-all flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'items'
                ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-950'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Package className="w-3.5 h-3.5" />
            Item Catalog
            <span className="px-1.5 py-0.5 rounded-full text-[10px] font-mono bg-slate-800 border border-slate-700">
              {items.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('stock')}
            className={`px-4 py-2 text-xs font-semibold rounded-xl transition-all flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'stock'
                ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-950'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Boxes className="w-3.5 h-3.5" />
            Stock Control
          </button>

          <button
            onClick={() => setActiveTab('issues')}
            className={`px-4 py-2 text-xs font-semibold rounded-xl transition-all flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'issues'
                ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-950'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Package className="w-3.5 h-3.5" />
            Issue & Return
          </button>

          <button
            onClick={() => setActiveTab('assets')}
            className={`px-4 py-2 text-xs font-semibold rounded-xl transition-all flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'assets'
                ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-950'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            Asset Register
            <span className="px-1.5 py-0.5 rounded-full text-[10px] font-mono bg-slate-800 border border-slate-700">
              {assets.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('departments')}
            className={`px-4 py-2 text-xs font-semibold rounded-xl transition-all flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'departments'
                ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-950'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Building className="w-3.5 h-3.5" />
            Department Allocation
          </button>

          <button
            onClick={() => setActiveTab('procurement')}
            className={`px-4 py-2 text-xs font-semibold rounded-xl transition-all flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'procurement'
                ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-950'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            Procurement & Orders
          </button>

          <button
            onClick={() => setActiveTab('suppliers')}
            className={`px-4 py-2 text-xs font-semibold rounded-xl transition-all flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'suppliers'
                ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-950'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Truck className="w-3.5 h-3.5" />
            Vendors & Suppliers
            <span className="px-1.5 py-0.5 rounded-full text-[10px] font-mono bg-slate-800 border border-slate-700">
              {suppliers.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('reports')}
            className={`px-4 py-2 text-xs font-semibold rounded-xl transition-all flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'reports'
                ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-950'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5" />
            Reports & Analytics
          </button>

          <button
            onClick={() => setActiveTab('setup')}
            className={`px-4 py-2 text-xs font-semibold rounded-xl transition-all flex items-center gap-2 whitespace-nowrap ${
              activeTab === 'setup'
                ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-950'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            Foundation Setup
          </button>
        </div>
      )}

      {/* Main View Port */}
      {activeTab === 'overview' && (
        <InventoryDashboardTab
          stats={stats}
          loading={loading}
          onNavigateTab={setActiveTab}
          onOpenNewItemModal={() => {
            setSelectedItemForEdit(null);
            setIsItemModalOpen(true);
          }}
          onOpenNewAssetModal={() => {
            setSelectedAssetForEdit(null);
            setIsAssetModalOpen(true);
          }}
          onOpenNewSupplierModal={() => {
            setSelectedSupplierForEdit(null);
            setIsSupplierModalOpen(true);
          }}
          onSelectAsset={(asset) => {
            setSelectedAssetForDetail(asset);
            setIsAssetDetailOpen(true);
          }}
        />
      )}

      {activeTab === 'items' && (
        <InventoryItemsTab
          items={items}
          categories={categories}
          locations={locations}
          suppliers={suppliers}
          loading={loading}
          onRefresh={loadAllData}
          onOpenNewItemModal={() => {
            setSelectedItemForEdit(null);
            setIsItemModalOpen(true);
          }}
          onEditItem={(item) => {
            setSelectedItemForEdit(item);
            setIsItemModalOpen(true);
          }}
          onUpdateItemStatus={handleUpdateItemStatus}
          onDeleteItem={handleDeleteItem}
        />
      )}

      {activeTab === 'stock' && (
        <StockManagementTab
          items={items}
          categories={categories}
          locations={locations}
          suppliers={suppliers}
          onRefreshParent={loadAllData}
          showNotification={showNotification}
        />
      )}

      {activeTab === 'issues' && (
        <IssueReturnTab
          items={items}
          locations={locations}
          departments={departments}
          staffMembers={staffMembers}
          onRefreshParent={loadAllData}
          showNotification={showNotification}
        />
      )}

      {activeTab === 'procurement' && (
        <ProcurementTab
          items={items}
          suppliers={suppliers}
          locations={locations}
          onNotification={showNotification}
          onRefreshAllData={loadAllData}
        />
      )}

      {activeTab === 'assets' && (
        <AssetsRegisterTab
          assets={assets}
          categories={assetCategories}
          locations={locations}
          suppliers={suppliers}
          loading={loading}
          onRefresh={loadAllData}
          onOpenNewAssetModal={() => {
            setSelectedAssetForEdit(null);
            setIsAssetModalOpen(true);
          }}
          onViewAssetDetails={(asset) => {
            setSelectedAssetForDetail(asset);
            setIsAssetDetailOpen(true);
          }}
          onEditAsset={(asset) => {
            setSelectedAssetForEdit(asset);
            setIsAssetModalOpen(true);
          }}
          onOpenStatusModal={(asset) => {
            setSelectedAssetForStatus(asset);
            setIsStatusModalOpen(true);
          }}
          onDeleteAsset={handleDeleteAsset}
        />
      )}

      {activeTab === 'departments' && (
        <DepartmentAllocationTab
          departments={departments}
          onOpenAssetDetails={(asset) => {
            setSelectedAssetForDetail(asset);
            setIsAssetDetailOpen(true);
          }}
          onOpenBulkAllocation={() => setIsBulkAllocationOpen(true)}
          showNotification={showNotification}
        />
      )}

      {activeTab === 'suppliers' && (
        <SuppliersTab
          suppliers={suppliers}
          loading={loading}
          onRefresh={loadAllData}
          onOpenNewSupplierModal={() => {
            setSelectedSupplierForEdit(null);
            setIsSupplierModalOpen(true);
          }}
          onEditSupplier={(sup) => {
            setSelectedSupplierForEdit(sup);
            setIsSupplierModalOpen(true);
          }}
          onDeleteSupplier={handleDeleteSupplier}
        />
      )}

      {activeTab === 'setup' && (
        <InventorySetupTab
          categories={categories}
          units={units}
          locations={locations}
          assetCategories={assetCategories}
          loading={loading}
          onRefresh={loadAllData}
          onOpenCategoryModal={(cat) => {
            setSelectedCategoryForEdit(cat || null);
            setIsCategoryModalOpen(true);
          }}
          onDeleteCategory={handleDeleteCategory}
          onOpenUnitModal={(unit) => {
            setSelectedUnitForEdit(unit || null);
            setIsUnitModalOpen(true);
          }}
          onDeleteUnit={handleDeleteUnit}
          onOpenLocationModal={(loc) => {
            setSelectedLocationForEdit(loc || null);
            setIsLocationModalOpen(true);
          }}
          onDeleteLocation={handleDeleteLocation}
          onOpenAssetCategoryModal={() => {}}
        />
      )}

      {activeTab === 'reports' && (
        <InventoryReportsTab
          categories={categories}
          locations={locations}
          onNavigateTab={setActiveTab}
        />
      )}

      {/* Item Modal */}
      <ItemModal
        isOpen={isItemModalOpen}
        onClose={() => {
          setIsItemModalOpen(false);
          setSelectedItemForEdit(null);
        }}
        onSubmit={handleCreateOrUpdateItem}
        item={selectedItemForEdit}
        categories={categories}
        units={units}
        locations={locations}
      />

      {/* Asset Modal */}
      <AssetModal
        isOpen={isAssetModalOpen}
        onClose={() => {
          setIsAssetModalOpen(false);
          setSelectedAssetForEdit(null);
        }}
        onSubmit={handleCreateOrUpdateAsset}
        asset={selectedAssetForEdit}
        categories={assetCategories}
        locations={locations}
        suppliers={suppliers}
      />

      {/* Asset Detail Modal */}
      <AssetDetailModal
        isOpen={isAssetDetailOpen}
        onClose={() => {
          setIsAssetDetailOpen(false);
          setSelectedAssetForDetail(null);
        }}
        asset={selectedAssetForDetail}
        onEditAsset={(asset) => {
          setSelectedAssetForEdit(asset);
          setIsAssetModalOpen(true);
        }}
        onOpenStatusModal={(asset) => {
          setSelectedAssetForStatus(asset);
          setIsStatusModalOpen(true);
        }}
        onRefreshAsset={(updatedAsset) => {
          setAssets(prev => prev.map(a => a.id === updatedAsset.id ? updatedAsset : a));
          setSelectedAssetForDetail(updatedAsset);
        }}
      />

      {/* Status Change Modal */}
      <StatusChangeModal
        isOpen={isStatusModalOpen}
        onClose={() => {
          setIsStatusModalOpen(false);
          setSelectedAssetForStatus(null);
        }}
        asset={selectedAssetForStatus}
        onSubmit={handleUpdateAssetStatus}
      />

      {/* Supplier Modal */}
      <SupplierModal
        isOpen={isSupplierModalOpen}
        onClose={() => {
          setIsSupplierModalOpen(false);
          setSelectedSupplierForEdit(null);
        }}
        onSubmit={handleCreateOrUpdateSupplier}
        supplier={selectedSupplierForEdit}
      />

      {/* Category Modal */}
      <CategoryModal
        isOpen={isCategoryModalOpen}
        onClose={() => {
          setIsCategoryModalOpen(false);
          setSelectedCategoryForEdit(null);
        }}
        onSubmit={handleSaveCategory}
        category={selectedCategoryForEdit}
      />

      {/* Unit Modal */}
      <UnitModal
        isOpen={isUnitModalOpen}
        onClose={() => {
          setIsUnitModalOpen(false);
          setSelectedUnitForEdit(null);
        }}
        onSubmit={handleSaveUnit}
        unit={selectedUnitForEdit}
      />

      {/* Location Modal */}
      <LocationModal
        isOpen={isLocationModalOpen}
        onClose={() => {
          setIsLocationModalOpen(false);
          setSelectedLocationForEdit(null);
        }}
        onSubmit={handleSaveLocation}
        location={selectedLocationForEdit}
      />

      {/* Bulk Asset Allocation Modal */}
      <BulkAssetAllocationModal
        isOpen={isBulkAllocationOpen}
        onClose={() => setIsBulkAllocationOpen(false)}
        availableAssets={assets}
        departments={departments}
        locations={locations}
        staffMembers={staffMembers}
        onSuccess={(msg) => {
          showNotification(msg);
          loadAllData();
        }}
      />
    </div>
  );
};
