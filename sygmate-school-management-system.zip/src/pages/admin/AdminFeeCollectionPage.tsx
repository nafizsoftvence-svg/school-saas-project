import React, { useState, useEffect, useCallback } from 'react';
import {
  DollarSign,
  Search,
  Filter,
  Plus,
  Receipt,
  CheckCircle2,
  AlertCircle,
  Clock,
  Printer,
  Ban,
  RotateCcw,
  CreditCard,
  Building,
  User,
  Calendar,
  Layers,
  ArrowUpRight,
  TrendingUp,
  RefreshCw,
  Eye,
  SlidersHorizontal,
  ChevronLeft,
  ChevronRight,
  Check,
  ToggleLeft,
  ToggleRight
} from 'lucide-react';
import {
  StudentFeeRecord,
  FeePaymentTransaction,
  FeePaymentReceipt,
  PaymentMethodConfig,
  FeeCollectionSummaryStats,
  AcademicSession,
  SchoolClass,
  Section,
  FeePaymentStatus
} from '../../types/index.js';
import { api } from '../../services/api.js';
import { CollectFeeModal } from '../../components/fees/CollectFeeModal.js';
import { PaymentReceiptModal } from '../../components/fees/PaymentReceiptModal.js';
import { PaymentReversalModal } from '../../components/fees/PaymentReversalModal.js';
import { InvoiceViewModal } from '../../components/fees/InvoiceViewModal.js';

interface AdminFeeCollectionPageProps {
  activeTab?: 'TERMINAL' | 'TRANSACTIONS' | 'METHODS';
  onTabChange?: (tab: 'TERMINAL' | 'TRANSACTIONS' | 'METHODS') => void;
  hideTabBar?: boolean;
}

export const AdminFeeCollectionPage: React.FC<AdminFeeCollectionPageProps> = ({
  activeTab: propActiveTab,
  onTabChange,
  hideTabBar = true
}) => {
  // Navigation & Tabs
  const [internalTab, setInternalTab] = useState<'TERMINAL' | 'TRANSACTIONS' | 'METHODS'>('TERMINAL');
  const activeTab = propActiveTab || internalTab;

  const setActiveTab = (tab: 'TERMINAL' | 'TRANSACTIONS' | 'METHODS') => {
    setInternalTab(tab);
    onTabChange?.(tab);
  };

  // Stats
  const [stats, setStats] = useState<FeeCollectionSummaryStats | null>(null);
  const [statsLoading, setStatsLoading] = useState<boolean>(false);

  // Metadata dropdowns
  const [sessions, setSessions] = useState<AcademicSession[]>([]);
  const [classes, setClasses] = useState<SchoolClass[]>([]);
  const [sections, setSections] = useState<Section[]>([]);
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethodConfig[]>([]);

  // Fee Collection Terminal State (Invoices)
  const [invoices, setInvoices] = useState<StudentFeeRecord[]>([]);
  const [invoicesLoading, setInvoicesLoading] = useState<boolean>(false);
  const [invoiceSearch, setInvoiceSearch] = useState<string>('');
  const [selectedSessionId, setSelectedSessionId] = useState<string>('');
  const [selectedClassId, setSelectedClassId] = useState<string>('ALL');
  const [selectedSectionId, setSelectedSectionId] = useState<string>('ALL');
  const [selectedInvoiceStatus, setSelectedInvoiceStatus] = useState<string>('DUE');
  const [invoicePage, setInvoicePage] = useState<number>(1);
  const [invoiceTotalPages, setInvoiceTotalPages] = useState<number>(1);
  const [invoiceTotalCount, setInvoiceTotalCount] = useState<number>(0);

  // Transactions Ledger State
  const [transactions, setTransactions] = useState<FeePaymentTransaction[]>([]);
  const [txnsLoading, setTxnsLoading] = useState<boolean>(false);
  const [txnSearch, setTxnSearch] = useState<string>('');
  const [txnStatusFilter, setTxnStatusFilter] = useState<string>('ALL');
  const [txnMethodFilter, setTxnMethodFilter] = useState<string>('ALL');
  const [txnStartDate, setTxnStartDate] = useState<string>('');
  const [txnEndDate, setTxnEndDate] = useState<string>('');
  const [txnPage, setTxnPage] = useState<number>(1);
  const [txnTotalPages, setTxnTotalPages] = useState<number>(1);
  const [txnTotalCount, setTxnTotalCount] = useState<number>(0);

  // Modals state
  const [collectModalOpen, setCollectModalOpen] = useState<boolean>(false);
  const [selectedFeeForCollect, setSelectedFeeForCollect] = useState<StudentFeeRecord | null>(null);

  const [receiptModalOpen, setReceiptModalOpen] = useState<boolean>(false);
  const [currentReceiptData, setCurrentReceiptData] = useState<FeePaymentReceipt | null>(null);
  const [receiptLoading, setReceiptLoading] = useState<boolean>(false);

  const [reversalModalOpen, setReversalModalOpen] = useState<boolean>(false);
  const [selectedTxnForReversal, setSelectedTxnForReversal] = useState<FeePaymentTransaction | null>(null);

  const [invoiceModalOpen, setInvoiceModalOpen] = useState<boolean>(false);
  const [selectedInvoiceNumber, setSelectedInvoiceNumber] = useState<string | null>(null);

  // Feedback notifications
  const [bannerAlert, setBannerAlert] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // Fetch initial meta dropdowns
  useEffect(() => {
    Promise.all([
      api.getAcademicSessions(),
      api.getClasses(),
      api.getSections(),
      api.fees.getPaymentMethods()
    ])
      .then(([sessRes, clsRes, secRes, pmtRes]) => {
        const sessList = (sessRes as any)?.data || (Array.isArray(sessRes) ? sessRes : []);
        if (sessList.length > 0) {
          setSessions(sessList);
          const current = sessList.find((s: AcademicSession) => s.isCurrent) || sessList?.[0];
          if (current) setSelectedSessionId(current.id);
        }
        const clsList = (clsRes as any)?.data || (Array.isArray(clsRes) ? clsRes : []);
        if (clsList.length > 0) setClasses(clsList);
        const secList = (secRes as any)?.data || (Array.isArray(secRes) ? secRes : []);
        if (secList.length > 0) setSections(secList);
        if (pmtRes.success && pmtRes.data) setPaymentMethods(pmtRes.data);
      })
      .catch((err) => {
        console.error('Failed to load initial metadata', err);
      });
  }, []);

  // Fetch summary stats
  const fetchStats = useCallback(() => {
    setStatsLoading(true);
    api.fees
      .getFeeCollectionStats()
      .then((res) => {
        if (res.success && res.data) {
          setStats(res.data);
        }
      })
      .catch((err) => {
        console.error('Failed to fetch stats', err);
      })
      .finally(() => {
        setStatsLoading(false);
      });
  }, []);

  useEffect(() => {
    fetchStats();
  }, [fetchStats]);

  // Fetch Invoices for Collection Terminal
  const fetchInvoices = useCallback(() => {
    setInvoicesLoading(true);
    api.fees
      .getStudentFees({
        search: invoiceSearch.trim() || undefined,
        academicSessionId: selectedSessionId || undefined,
        classId: selectedClassId !== 'ALL' ? selectedClassId : undefined,
        sectionId: selectedSectionId !== 'ALL' ? selectedSectionId : undefined,
        status: selectedInvoiceStatus !== 'ALL' ? (selectedInvoiceStatus as any) : undefined,
        page: invoicePage,
        limit: 12
      })
      .then((res) => {
        if (res.success && res.data) {
          const items = (res.data as any).data || (res.data as any).feeRecords || [];
          const total = (res.data as any).total || items.length;
          setInvoices(items);
          setInvoiceTotalPages(Math.ceil(total / 12) || 1);
          setInvoiceTotalCount(total);
        }
      })
      .catch((err) => {
        console.error('Failed to fetch invoices', err);
      })
      .finally(() => {
        setInvoicesLoading(false);
      });
  }, [
    invoiceSearch,
    selectedSessionId,
    selectedClassId,
    selectedSectionId,
    selectedInvoiceStatus,
    invoicePage
  ]);

  useEffect(() => {
    if (activeTab === 'TERMINAL') {
      fetchInvoices();
    }
  }, [activeTab, fetchInvoices]);

  // Fetch Transactions Ledger
  const fetchTransactions = useCallback(() => {
    setTxnsLoading(true);
    api.fees
      .getPaymentTransactions({
        search: txnSearch.trim() || undefined,
        status: txnStatusFilter !== 'ALL' ? (txnStatusFilter as any) : undefined,
        paymentMethod: txnMethodFilter !== 'ALL' ? txnMethodFilter : undefined,
        startDate: txnStartDate || undefined,
        endDate: txnEndDate || undefined,
        page: txnPage,
        limit: 15
      })
      .then((res) => {
        if (res.success && res.data) {
          setTransactions(res.data.transactions || []);
          setTxnTotalPages(res.data.totalPages || 1);
          setTxnTotalCount(res.data.total || 0);
        }
      })
      .catch((err) => {
        console.error('Failed to fetch transactions', err);
      })
      .finally(() => {
        setTxnsLoading(false);
      });
  }, [
    txnSearch,
    txnStatusFilter,
    txnMethodFilter,
    txnStartDate,
    txnEndDate,
    txnPage
  ]);

  useEffect(() => {
    if (activeTab === 'TRANSACTIONS') {
      fetchTransactions();
    }
  }, [activeTab, fetchTransactions]);

  // Handle successful fee payment
  const handlePaymentSuccess = async (result: any) => {
    setBannerAlert({
      type: 'success',
      message: `Payment of $${result.transaction.amountPaid.toFixed(2)} recorded successfully! Official Receipt #${result.receiptNumber} generated.`
    });

    // Refresh state
    fetchStats();
    fetchInvoices();
    if (activeTab === 'TRANSACTIONS') fetchTransactions();

    // Automatically open the Official Receipt Modal
    try {
      setReceiptLoading(true);
      setReceiptModalOpen(true);
      const res = await api.fees.getPaymentReceipt(result.transaction.id);
      if (res.success && res.data) {
        setCurrentReceiptData(res.data);
      }
    } catch (e) {
      console.error('Receipt auto-open failed', e);
    } finally {
      setReceiptLoading(false);
    }
  };

  // Handle successful reversal
  const handleReversalSuccess = (result: any) => {
    setBannerAlert({
      type: 'success',
      message: `Payment #${result.transaction.receiptNumber} successfully voided. Invoice balance restored.`
    });
    fetchStats();
    if (activeTab === 'TERMINAL') fetchInvoices();
    if (activeTab === 'TRANSACTIONS') fetchTransactions();
  };

  // Open receipt by ID
  const handleOpenReceipt = async (transactionId: string) => {
    setReceiptModalOpen(true);
    setReceiptLoading(true);
    try {
      const res = await api.fees.getPaymentReceipt(transactionId);
      if (res.success && res.data) {
        setCurrentReceiptData(res.data);
      }
    } catch (e) {
      console.error('Failed to fetch receipt', e);
    } finally {
      setReceiptLoading(false);
    }
  };

  // Toggle payment method
  const handleTogglePaymentMethod = async (methodId: string) => {
    try {
      const res = await api.fees.togglePaymentMethod(methodId);
      if (res.success) {
        setPaymentMethods((prev) =>
          prev.map((m) => (m.id === methodId || m.code === methodId ? res.data! : m))
        );
        setBannerAlert({
          type: 'success',
          message: res.message || 'Payment method updated.'
        });
      }
    } catch (e: any) {
      setBannerAlert({
        type: 'error',
        message: e.message || 'Failed to update payment method.'
      });
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2.5">
            <CreditCard className="w-7 h-7 text-indigo-400" />
            Fee Collection & Payment Management
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Super Admin &bull; Process invoice settlements, partial payments, receipts, and audit ledgers
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              fetchStats();
              if (activeTab === 'TERMINAL') fetchInvoices();
              if (activeTab === 'TRANSACTIONS') fetchTransactions();
            }}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-200 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl transition-colors cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${invoicesLoading || txnsLoading ? 'animate-spin' : ''}`} />
            Refresh
          </button>
        </div>
      </div>

      {/* Banner Alert */}
      {bannerAlert && (
        <div
          className={`p-4 rounded-2xl border text-xs flex items-center justify-between transition-all ${
            bannerAlert.type === 'success'
              ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
              : 'bg-rose-500/10 border-rose-500/30 text-rose-300'
          }`}
        >
          <div className="flex items-center gap-2.5">
            {bannerAlert.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            )}
            <span className="font-medium">{bannerAlert.message}</span>
          </div>
          <button
            onClick={() => setBannerAlert(null)}
            className="p-1 hover:bg-white/10 rounded transition-colors text-slate-400 hover:text-white"
          >
            <Check className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Top Statistics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="p-4 bg-slate-900/60 border border-white/10 rounded-2xl">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold uppercase text-slate-400">Collected Today</span>
            <div className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <p className="text-xl font-black text-emerald-400 font-mono mt-2">
            ${stats ? stats.totalCollectedToday.toFixed(2) : '0.00'}
          </p>
          <p className="text-[10px] text-slate-400 mt-1">Live counter settlement</p>
        </div>

        <div className="p-4 bg-slate-900/60 border border-white/10 rounded-2xl">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold uppercase text-slate-400">This Month</span>
            <div className="p-1.5 rounded-lg bg-indigo-500/10 text-indigo-400">
              <Calendar className="w-4 h-4" />
            </div>
          </div>
          <p className="text-xl font-black text-indigo-300 font-mono mt-2">
            ${stats ? stats.totalCollectedMonth.toFixed(2) : '0.00'}
          </p>
          <p className="text-[10px] text-slate-400 mt-1">Current billing cycle</p>
        </div>

        <div className="p-4 bg-slate-900/60 border border-white/10 rounded-2xl">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold uppercase text-slate-400">All-Time Settled</span>
            <div className="p-1.5 rounded-lg bg-cyan-500/10 text-cyan-400">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <p className="text-xl font-black text-white font-mono mt-2">
            ${stats ? stats.totalCollectedAllTime.toFixed(2) : '0.00'}
          </p>
          <p className="text-[10px] text-slate-400 mt-1">
            {stats ? stats.totalTransactions : 0} total transactions
          </p>
        </div>

        <div className="p-4 bg-slate-900/60 border border-white/10 rounded-2xl">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold uppercase text-amber-400">Outstanding Due</span>
            <div className="p-1.5 rounded-lg bg-amber-500/10 text-amber-400">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <p className="text-xl font-black text-amber-400 font-mono mt-2">
            ${stats ? stats.totalDueOutstanding.toFixed(2) : '0.00'}
          </p>
          <p className="text-[10px] text-amber-300/80 mt-1">
            Across {stats ? stats.activeInvoicesWithDue : 0} pending invoices
          </p>
        </div>

        <div className="p-4 bg-slate-900/60 border border-white/10 rounded-2xl">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold uppercase text-rose-400">Voided / Reversed</span>
            <div className="p-1.5 rounded-lg bg-rose-500/10 text-rose-400">
              <Ban className="w-4 h-4" />
            </div>
          </div>
          <p className="text-xl font-black text-rose-400 font-mono mt-2">
            ${stats ? stats.reversedAmount.toFixed(2) : '0.00'}
          </p>
          <p className="text-[10px] text-rose-300/80 mt-1">
            {stats ? stats.reversedTransactionsCount : 0} voided records
          </p>
        </div>
      </div>

      {/* Tabs Navigation (Hidden when subtabs are hosted in sidebar) */}
      {!hideTabBar && (
        <div className="flex items-center gap-2 border-b border-white/10 pb-2">
          <button
            onClick={() => setActiveTab('TERMINAL')}
            className={`flex items-center gap-2 px-4 py-2.5 text-xs font-bold rounded-xl transition-all cursor-pointer ${
              activeTab === 'TERMINAL'
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/20'
                : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
            }`}
          >
            <DollarSign className="w-4 h-4" />
            Fee Collection Terminal
          </button>

          <button
            onClick={() => setActiveTab('TRANSACTIONS')}
            className={`flex items-center gap-2 px-4 py-2.5 text-xs font-bold rounded-xl transition-all cursor-pointer ${
              activeTab === 'TRANSACTIONS'
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/20'
                : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
            }`}
          >
            <Receipt className="w-4 h-4" />
            Payment Transactions Ledger
            {stats && stats.totalTransactions > 0 && (
              <span className="px-1.5 py-0.5 rounded-full text-[10px] bg-white/20 text-white">
                {stats.totalTransactions}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('METHODS')}
            className={`flex items-center gap-2 px-4 py-2.5 text-xs font-bold rounded-xl transition-all cursor-pointer ${
              activeTab === 'METHODS'
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/20'
                : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
            }`}
          >
            <CreditCard className="w-4 h-4" />
            Payment Methods
          </button>
        </div>
      )}

      {/* TAB 1: FEE COLLECTION TERMINAL */}
      {activeTab === 'TERMINAL' && (
        <div className="space-y-4">
          {/* Search and Filters Bar */}
          <div className="p-4 bg-slate-900/60 border border-white/10 rounded-2xl space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
              {/* Search */}
              <div className="lg:col-span-2 relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={invoiceSearch}
                  onChange={(e) => {
                    setInvoiceSearch(e.target.value);
                    setInvoicePage(1);
                  }}
                  placeholder="Search by student name, admission #, invoice #..."
                  className="w-full pl-9 pr-4 py-2 bg-slate-950 border border-white/15 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                />
              </div>

              {/* Session */}
              <div>
                <select
                  value={selectedSessionId}
                  onChange={(e) => {
                    setSelectedSessionId(e.target.value);
                    setInvoicePage(1);
                  }}
                  className="w-full px-3 py-2 bg-slate-950 border border-white/15 rounded-xl text-xs text-white focus:outline-none focus:border-indigo-500 cursor-pointer"
                >
                  <option value="">All Academic Sessions</option>
                  {sessions.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name} {s.isCurrent ? '(Current)' : ''}
                    </option>
                  ))}
                </select>
              </div>

              {/* Class */}
              <div>
                <select
                  value={selectedClassId}
                  onChange={(e) => {
                    setSelectedClassId(e.target.value);
                    setInvoicePage(1);
                  }}
                  className="w-full px-3 py-2 bg-slate-950 border border-white/15 rounded-xl text-xs text-white focus:outline-none focus:border-indigo-500 cursor-pointer"
                >
                  <option value="ALL">All Classes</option>
                  {classes.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Status Filter */}
              <div>
                <select
                  value={selectedInvoiceStatus}
                  onChange={(e) => {
                    setSelectedInvoiceStatus(e.target.value);
                    setInvoicePage(1);
                  }}
                  className="w-full px-3 py-2 bg-slate-950 border border-white/15 rounded-xl text-xs text-white focus:outline-none focus:border-indigo-500 cursor-pointer"
                >
                  <option value="DUE">Outstanding Invoices (Due & Partial)</option>
                  <option value="ALL">All Invoices</option>
                  <option value="UNPAID">Unpaid Only</option>
                  <option value="PARTIAL">Partially Paid</option>
                  <option value="OVERDUE">Overdue Only</option>
                  <option value="PAID">Fully Paid</option>
                </select>
              </div>
            </div>
          </div>

          {/* Invoices List Table */}
          <div className="bg-slate-900/60 border border-white/10 rounded-2xl overflow-hidden shadow-xl">
            <div className="p-4 border-b border-white/10 flex items-center justify-between bg-slate-950/40">
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-white">
                  Payable Student Invoices
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
                  {invoiceTotalCount} Records
                </span>
              </div>
            </div>

            {invoicesLoading ? (
              <div className="flex flex-col items-center justify-center py-16 text-slate-400 space-y-3">
                <div className="w-8 h-8 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" />
                <p className="text-xs">Loading payable student records...</p>
              </div>
            ) : invoices.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-16 text-slate-400 space-y-3">
                <CheckCircle2 className="w-12 h-12 text-emerald-500/40" />
                <p className="text-sm font-semibold text-white">No Outstanding Invoices Found</p>
                <p className="text-xs text-slate-400 max-w-sm text-center">
                  All filtered student fees are either fully settled or no records match your filter criteria.
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-white/5 text-slate-400 font-semibold border-b border-white/10">
                    <tr>
                      <th className="px-4 py-3">Student Particulars</th>
                      <th className="px-4 py-3">Class & Section</th>
                      <th className="px-4 py-3">Invoice & Fee Title</th>
                      <th className="px-4 py-3 text-right">Net Payable</th>
                      <th className="px-4 py-3 text-right">Paid Amount</th>
                      <th className="px-4 py-3 text-right">Outstanding Due</th>
                      <th className="px-4 py-3 text-center">Status</th>
                      <th className="px-4 py-3 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {invoices.map((inv) => {
                      const netPayable = inv.netPayableAmount || inv.totalAmount;
                      const isFullyPaid = inv.dueAmount <= 0;
                      const percentagePaid =
                        netPayable > 0 ? Math.min(100, Math.round((inv.paidAmount / netPayable) * 100)) : 0;

                      return (
                        <tr key={inv.id} className="hover:bg-slate-50 transition-colors">
                          {/* Student Particulars */}
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-2.5">
                              <div className="w-8 h-8 rounded-lg bg-blue-600 border border-blue-700 flex items-center justify-center text-white font-bold text-xs shadow-xs">
                                {inv.studentName.charAt(0)}
                              </div>
                              <div>
                                <p className="font-semibold text-slate-900">{inv.studentName}</p>
                                <p className="text-[10px] text-slate-500 font-mono">
                                  {inv.admissionNumber || 'ADM-2026'}
                                </p>
                              </div>
                            </div>
                          </td>

                          {/* Class & Section */}
                          <td className="px-4 py-3">
                            <span className="text-slate-200">{inv.className}</span>
                            <span className="text-slate-400 text-[10px] block">{inv.sectionName}</span>
                          </td>

                          {/* Invoice & Fee Title */}
                          <td className="px-4 py-3">
                            <button
                              onClick={() => {
                                setSelectedInvoiceNumber(inv?.invoiceNumber || inv?.id || '');
                                setInvoiceModalOpen(true);
                              }}
                              className="font-mono text-indigo-400 hover:text-indigo-300 font-semibold hover:underline block cursor-pointer text-left"
                            >
                              {inv?.invoiceNumber || inv?.id || 'INV-2026'}
                            </button>
                            <p className="text-[11px] text-slate-300 line-clamp-1">{inv.title}</p>
                          </td>

                          {/* Net Payable */}
                          <td className="px-4 py-3 text-right font-mono font-semibold text-slate-200">
                            ${netPayable.toFixed(2)}
                          </td>

                          {/* Paid Amount + Progress Bar */}
                          <td className="px-4 py-3 text-right">
                            <span className="font-mono text-emerald-400 font-semibold">
                              ${inv.paidAmount.toFixed(2)}
                            </span>
                            <div className="w-20 ml-auto bg-white/10 h-1.5 rounded-full overflow-hidden mt-1">
                              <div
                                className="bg-emerald-500 h-full rounded-full"
                                style={{ width: `${percentagePaid}%` }}
                              />
                            </div>
                          </td>

                          {/* Outstanding Due */}
                          <td className="px-4 py-3 text-right">
                            <span
                              className={`font-mono font-bold text-sm ${
                                inv.dueAmount > 0 ? 'text-amber-400' : 'text-slate-400'
                              }`}
                            >
                              ${inv.dueAmount.toFixed(2)}
                            </span>
                            {inv.dueAmount > 0 && (
                              <span className="text-[10px] text-slate-400 block">
                                Due: {new Date(inv.dueDate).toLocaleDateString()}
                              </span>
                            )}
                          </td>

                          {/* Status Badge */}
                          <td className="px-4 py-3 text-center">
                            {inv.status === 'PAID' ? (
                              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                                PAID
                              </span>
                            ) : inv.status === 'PARTIAL' ? (
                              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
                                PARTIAL
                              </span>
                            ) : inv.status === 'OVERDUE' ? (
                              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-500/10 text-rose-400 border border-rose-500/20">
                                OVERDUE
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/10 text-amber-300 border border-amber-500/20">
                                DUE
                              </span>
                            )}
                          </td>

                          {/* Action */}
                          <td className="px-4 py-3 text-right">
                            <div className="flex items-center justify-end gap-2">
                              <button
                                onClick={() => {
                                  setSelectedInvoiceNumber(inv?.invoiceNumber || inv?.id || '');
                                  setInvoiceModalOpen(true);
                                }}
                                className="p-1.5 text-slate-400 hover:text-white bg-white/5 hover:bg-white/10 rounded-lg transition-colors cursor-pointer"
                                title="View Statement"
                              >
                                <Eye className="w-4 h-4" />
                              </button>

                              {!isFullyPaid ? (
                                <button
                                  onClick={() => {
                                    setSelectedFeeForCollect(inv);
                                    setCollectModalOpen(true);
                                  }}
                                  className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 rounded-xl transition-all shadow-sm shadow-emerald-600/20 cursor-pointer"
                                >
                                  <DollarSign className="w-3.5 h-3.5" />
                                  Collect
                                </button>
                              ) : (
                                <span className="text-[11px] text-emerald-400 font-semibold flex items-center gap-1 px-2 py-1 bg-emerald-500/10 rounded-lg">
                                  <Check className="w-3.5 h-3.5" /> Settled
                                </span>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}

            {/* Invoices Pagination */}
            {invoiceTotalPages > 1 && (
              <div className="flex items-center justify-between px-4 py-3 border-t border-white/10 bg-slate-950/40 text-xs text-slate-400">
                <span>
                  Page {invoicePage} of {invoiceTotalPages}
                </span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setInvoicePage((p) => Math.max(1, p - 1))}
                    disabled={invoicePage === 1}
                    className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 disabled:opacity-40 transition-colors cursor-pointer"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setInvoicePage((p) => Math.min(invoiceTotalPages, p + 1))}
                    disabled={invoicePage === invoiceTotalPages}
                    className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 disabled:opacity-40 transition-colors cursor-pointer"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 2: PAYMENT TRANSACTIONS LEDGER */}
      {activeTab === 'TRANSACTIONS' && (
        <div className="space-y-4">
          {/* Search and Filters Bar */}
          <div className="p-4 bg-slate-900/60 border border-white/10 rounded-2xl space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
              {/* Search */}
              <div className="lg:col-span-2 relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={txnSearch}
                  onChange={(e) => {
                    setTxnSearch(e.target.value);
                    setTxnPage(1);
                  }}
                  placeholder="Search receipt #, transaction ID, student, cashier..."
                  className="w-full pl-9 pr-4 py-2 bg-slate-950 border border-white/15 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                />
              </div>

              {/* Status Filter */}
              <div>
                <select
                  value={txnStatusFilter}
                  onChange={(e) => {
                    setTxnStatusFilter(e.target.value);
                    setTxnPage(1);
                  }}
                  className="w-full px-3 py-2 bg-slate-950 border border-white/15 rounded-xl text-xs text-white focus:outline-none focus:border-indigo-500 cursor-pointer"
                >
                  <option value="ALL">All Payment Statuses</option>
                  <option value="SUCCESS">Valid / Settled Payments</option>
                  <option value="REVERSED">Voided / Reversed</option>
                </select>
              </div>

              {/* Method Filter */}
              <div>
                <select
                  value={txnMethodFilter}
                  onChange={(e) => {
                    setTxnMethodFilter(e.target.value);
                    setTxnPage(1);
                  }}
                  className="w-full px-3 py-2 bg-slate-950 border border-white/15 rounded-xl text-xs text-white focus:outline-none focus:border-indigo-500 cursor-pointer"
                >
                  <option value="ALL">All Payment Methods</option>
                  {paymentMethods.map((m) => (
                    <option key={m.code} value={m.code}>
                      {m.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Date Filters */}
              <div>
                <input
                  type="date"
                  value={txnStartDate}
                  onChange={(e) => {
                    setTxnStartDate(e.target.value);
                    setTxnPage(1);
                  }}
                  className="w-full px-3 py-2 bg-slate-950 border border-white/15 rounded-xl text-xs text-white focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>
          </div>

          {/* Transactions Ledger Table */}
          <div className="bg-slate-900/60 border border-white/10 rounded-2xl overflow-hidden shadow-xl">
            <div className="p-4 border-b border-white/10 flex items-center justify-between bg-slate-950/40">
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-white">
                  Payment Transactions Ledger
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
                  {txnTotalCount} Records
                </span>
              </div>
            </div>

            {txnsLoading ? (
              <div className="flex flex-col items-center justify-center py-16 text-slate-400 space-y-3">
                <div className="w-8 h-8 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" />
                <p className="text-xs">Loading transaction records...</p>
              </div>
            ) : transactions.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-16 text-slate-400 space-y-3">
                <Receipt className="w-12 h-12 text-slate-600" />
                <p className="text-sm font-semibold text-white">No Transactions Recorded</p>
                <p className="text-xs text-slate-400 max-w-sm text-center">
                  Payments collected against student invoices will be recorded in this official audit ledger.
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-white/5 text-slate-400 font-semibold border-b border-white/10">
                    <tr>
                      <th className="px-4 py-3">Receipt / Txn ID</th>
                      <th className="px-4 py-3">Date & Time</th>
                      <th className="px-4 py-3">Student & Invoice</th>
                      <th className="px-4 py-3">Payment Method</th>
                      <th className="px-4 py-3">Cashier / Collected By</th>
                      <th className="px-4 py-3 text-right">Amount Paid</th>
                      <th className="px-4 py-3 text-center">Status</th>
                      <th className="px-4 py-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {transactions.map((txn) => {
                      const isVoid = txn.isReversed || txn.paymentStatus === 'REVERSED';
                      return (
                        <tr
                          key={txn.id}
                          className={`hover:bg-white/[0.02] transition-colors ${
                            isVoid ? 'bg-rose-500/[0.03]' : ''
                          }`}
                        >
                          {/* Receipt / Txn ID */}
                          <td className="px-4 py-3">
                            <button
                              onClick={() => handleOpenReceipt(txn.id)}
                              className="font-mono font-bold text-indigo-400 hover:text-indigo-300 hover:underline block cursor-pointer text-left"
                            >
                              {txn.receiptNumber}
                            </button>
                            <span className="text-[10px] text-slate-400 font-mono block">
                              {txn.transactionId}
                            </span>
                          </td>

                          {/* Date & Time */}
                          <td className="px-4 py-3">
                            <span className="text-slate-200">
                              {new Date(txn.paymentDate || txn.createdAt).toLocaleDateString()}
                            </span>
                            <span className="text-[10px] text-slate-400 block">
                              {new Date(txn.paymentDate || txn.createdAt).toLocaleTimeString([], {
                                hour: '2-digit',
                                minute: '2-digit'
                              })}
                            </span>
                          </td>

                          {/* Student & Invoice */}
                          <td className="px-4 py-3">
                            <span className="font-semibold text-white block">{txn.studentName}</span>
                            <span className="text-[10px] text-slate-400 font-mono">
                              {txn.invoiceNumber || 'INV-2026'} &bull; {txn.feeTitle}
                            </span>
                          </td>

                          {/* Payment Method */}
                          <td className="px-4 py-3">
                            <span className="text-slate-200 font-medium block">
                              {txn.paymentMethodLabel || txn.paymentMethod}
                            </span>
                            {txn.referenceNumber && (
                              <span className="text-[10px] text-indigo-300/80 font-mono">
                                Ref: {txn.referenceNumber}
                              </span>
                            )}
                          </td>

                          {/* Cashier / Collected By */}
                          <td className="px-4 py-3 text-slate-300">
                            {txn.collectedByName || txn.collectedBy || 'Finance Office'}
                          </td>

                          {/* Amount Paid */}
                          <td className="px-4 py-3 text-right">
                            <span
                              className={`font-mono font-extrabold text-sm ${
                                isVoid ? 'line-through text-slate-500' : 'text-emerald-400'
                              }`}
                            >
                              ${txn.amountPaid.toFixed(2)}
                            </span>
                          </td>

                          {/* Status */}
                          <td className="px-4 py-3 text-center">
                            {isVoid ? (
                              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-500/15 text-rose-300 border border-rose-500/30">
                                VOIDED
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                                SUCCESS
                              </span>
                            )}
                          </td>

                          {/* Actions */}
                          <td className="px-4 py-3 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                onClick={() => handleOpenReceipt(txn.id)}
                                className="p-1.5 text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 rounded-lg transition-colors cursor-pointer"
                                title="View & Print Official Receipt"
                              >
                                <Printer className="w-4 h-4" />
                              </button>

                              {!isVoid && (
                                <button
                                  onClick={() => {
                                    setSelectedTxnForReversal(txn);
                                    setReversalModalOpen(true);
                                  }}
                                  className="p-1.5 text-rose-400 hover:text-rose-300 bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/20 rounded-lg transition-colors cursor-pointer"
                                  title="Void / Reverse Payment"
                                >
                                  <RotateCcw className="w-4 h-4" />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}

            {/* Transactions Pagination */}
            {txnTotalPages > 1 && (
              <div className="flex items-center justify-between px-4 py-3 border-t border-white/10 bg-slate-950/40 text-xs text-slate-400">
                <span>
                  Page {txnPage} of {txnTotalPages}
                </span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setTxnPage((p) => Math.max(1, p - 1))}
                    disabled={txnPage === 1}
                    className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 disabled:opacity-40 transition-colors cursor-pointer"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setTxnPage((p) => Math.min(txnTotalPages, p + 1))}
                    disabled={txnPage === txnTotalPages}
                    className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 disabled:opacity-40 transition-colors cursor-pointer"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 3: PAYMENT METHODS CONFIGURATION */}
      {activeTab === 'METHODS' && (
        <div className="bg-slate-900/60 border border-white/10 rounded-2xl p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-white/10 pb-4">
            <div>
              <h3 className="text-base font-bold text-white">Configured Settlement Methods</h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Enable or disable payment modes supported at the school fee collection counter.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
            {paymentMethods.map((m) => (
              <div
                key={m.id}
                className="p-4 bg-slate-950 border border-white/10 rounded-xl flex items-center justify-between gap-4"
              >
                <div className="flex items-center gap-3">
                  <div className="p-2.5 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400">
                    <CreditCard className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white flex items-center gap-2">
                      {m.name}
                      <span className="font-mono text-[10px] text-slate-400 bg-white/5 px-1.5 py-0.5 rounded">
                        {m.code}
                      </span>
                    </h4>
                    <p className="text-xs text-slate-400 mt-0.5">
                      {m.requiresReference
                        ? 'Mandatory Reference / Cheque / POS Slip number required'
                        : 'Direct counter settlement (No reference required)'}
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => handleTogglePaymentMethod(m.id)}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer ${
                    m.isActive
                      ? 'bg-emerald-500/10 text-emerald-300 border border-emerald-500/30 hover:bg-emerald-500/20'
                      : 'bg-slate-800 text-slate-400 border border-white/10 hover:bg-slate-700'
                  }`}
                >
                  {m.isActive ? (
                    <>
                      <Check className="w-3.5 h-3.5" /> Active
                    </>
                  ) : (
                    <>
                      <Ban className="w-3.5 h-3.5" /> Disabled
                    </>
                  )}
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* MODAL 1: COLLECT FEE PAYMENT */}
      <CollectFeeModal
        isOpen={collectModalOpen}
        onClose={() => {
          setCollectModalOpen(false);
          setSelectedFeeForCollect(null);
        }}
        feeRecord={selectedFeeForCollect}
        onPaymentSuccess={handlePaymentSuccess}
      />

      {/* MODAL 2: OFFICIAL PAYMENT RECEIPT */}
      <PaymentReceiptModal
        isOpen={receiptModalOpen}
        onClose={() => {
          setReceiptModalOpen(false);
          setCurrentReceiptData(null);
        }}
        receiptData={currentReceiptData}
        isLoading={receiptLoading}
      />

      {/* MODAL 3: PAYMENT REVERSAL / VOID */}
      <PaymentReversalModal
        isOpen={reversalModalOpen}
        onClose={() => {
          setReversalModalOpen(false);
          setSelectedTxnForReversal(null);
        }}
        transaction={selectedTxnForReversal}
        onReversalSuccess={handleReversalSuccess}
      />

      {/* MODAL 4: INVOICE STATEMENT MODAL */}
      <InvoiceViewModal
        isOpen={invoiceModalOpen}
        onClose={() => {
          setInvoiceModalOpen(false);
          setSelectedInvoiceNumber(null);
        }}
        invoiceNumber={selectedInvoiceNumber}
        onCollectPayment={(fee) => {
          setInvoiceModalOpen(false);
          setSelectedFeeForCollect(fee);
          setCollectModalOpen(true);
        }}
        onViewReceipt={(receiptNo) => {
          setInvoiceModalOpen(false);
          handleOpenReceipt(receiptNo);
        }}
      />
    </div>
  );
};
