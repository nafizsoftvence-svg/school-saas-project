import React, { useEffect, useState } from 'react';
import {
  Users,
  GraduationCap,
  ShieldCheck,
  HeartHandshake,
  Sparkles,
  RefreshCw,
  AlertCircle,
  Building,
  Layers,
  BookOpen,
  FileSpreadsheet,
  Briefcase
} from 'lucide-react';
import { Tabs } from '../../components/ui/Tabs.js';
import { Button } from '../../components/ui/Button.js';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner.js';
import { Alert } from '../../components/ui/Alert.js';
import { api } from '../../services/api.js';
import {
  Teacher,
  Student,
  Guardian,
  SchoolClass,
  Section,
  Subject,
  Department,
  AcademicSession
} from '../../types/index.js';

import { TeachersTab } from './users/TeachersTab.js';
import { StudentsTab } from './users/StudentsTab.js';
import { GuardiansTab } from './users/GuardiansTab.js';
import { AdminsTab } from './users/AdminsTab.js';

type TabId = 'teachers' | 'students' | 'guardians' | 'admins';

interface UserDirectoryPageProps {
  onNavigate?: (view: string) => void;
  activeTab?: TabId;
  onTabChange?: (tab: string) => void;
  hideTabBar?: boolean;
}

export const UserDirectoryPage: React.FC<UserDirectoryPageProps> = ({
  onNavigate,
  activeTab: propActiveTab,
  onTabChange,
  hideTabBar = true
}) => {
  const [internalTab, setInternalTab] = useState<TabId>('teachers');
  const activeTab = propActiveTab || internalTab;
  const setActiveTab = (tab: TabId) => {
    setInternalTab(tab);
    onTabChange?.(tab);
  };
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Core Entity States
  const [teachers, setTeachers] = useState<Teacher[]>([]);
  const [students, setStudents] = useState<Student[]>([]);
  const [guardians, setGuardians] = useState<Guardian[]>([]);
  const [classes, setClasses] = useState<SchoolClass[]>([]);
  const [sections, setSections] = useState<Section[]>([]);
  const [sessions, setSessions] = useState<AcademicSession[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);

  // Deep-link state for selecting a guardian from student dossier
  const [selectedGuardianDeepLink, setSelectedGuardianDeepLink] = useState<string | undefined>(undefined);

  const loadData = async (isBackground = false) => {
    try {
      if (!isBackground) setLoading(true);
      else setRefreshing(true);
      setErrorMessage(null);

      const [
        tRes,
        sRes,
        gRes,
        classRes,
        secRes,
        sessRes,
        subRes,
        deptRes
      ] = await Promise.all([
        api.users.getTeachers(),
        api.users.getStudents(),
        api.users.getGuardians(),
        api.academic.getClasses(),
        api.academic.getSections(),
        api.academic.getSessions(),
        api.academic.getSubjects(),
        api.academic.getDepartments()
      ]);

      if (tRes.success && tRes.data) setTeachers(Array.isArray(tRes.data) ? tRes.data : []);
      if (sRes.success && sRes.data) setStudents(Array.isArray(sRes.data) ? sRes.data : []);
      if (gRes.success && gRes.data) setGuardians(Array.isArray(gRes.data) ? gRes.data : []);
      if (classRes.success && classRes.data) setClasses(Array.isArray(classRes.data) ? classRes.data : []);
      if (secRes.success && secRes.data) setSections(Array.isArray(secRes.data) ? secRes.data : []);
      if (sessRes.success && sessRes.data) setSessions(Array.isArray(sessRes.data) ? sessRes.data : []);
      if (subRes.success && subRes.data) setSubjects(Array.isArray(subRes.data) ? subRes.data : []);
      if (deptRes.success && deptRes.data) setDepartments(Array.isArray(deptRes.data) ? deptRes.data : []);

      if (!tRes.success || !sRes.success || !gRes.success) {
        setErrorMessage('Some user and guardian records failed to synchronize. Please refresh.');
      }
    } catch (err: any) {
      console.error('Failed to load user management data', err);
      setErrorMessage(err.message || 'Failed to communicate with identity and stakeholder layer.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleSelectGuardianFromStudent = (guardianId: string) => {
    setSelectedGuardianDeepLink(guardianId);
    setActiveTab('guardians');
  };

  const tabs = [
    {
      id: 'teachers',
      label: 'Faculty & Teachers',
      icon: <GraduationCap className="w-4 h-4" />,
      badge: teachers.length
    },
    {
      id: 'students',
      label: 'Enrolled Students',
      icon: <Users className="w-4 h-4" />,
      badge: students.length
    },
    {
      id: 'guardians',
      label: 'Parents & Guardians',
      icon: <HeartHandshake className="w-4 h-4" />,
      badge: guardians.length
    },
    {
      id: 'admins',
      label: 'System Administrators',
      icon: <ShieldCheck className="w-4 h-4" />,
      badge: 1
    }
  ];

  return (
    <div className="space-y-6">
      {/* Top Banner Card with High-Contrast Layout & Metrics */}
      <div className="bg-slate-900/60 backdrop-blur-xl border border-white/10 rounded-3xl p-6 sm:p-8 shadow-xl shadow-black/20 flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 text-indigo-400 text-xs font-bold uppercase tracking-wider mb-1">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Identity &amp; Stakeholder Management</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
            Teachers, Scholars &amp; Family Guardians
          </h2>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            Comprehensive lifecycle governance for faculty credentials, student enrollments, and multi-child parent-guardian associations.
          </p>

          {/* Quick Metrics Strip */}
          <div className="flex flex-wrap items-center gap-4 mt-4 text-xs font-medium">
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-300">
              <GraduationCap className="w-4 h-4" />
              <span>{teachers.length} Active Faculty</span>
            </div>
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-300">
              <Users className="w-4 h-4" />
              <span>{students.length} Enrolled Scholars</span>
            </div>
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-purple-500/10 border border-purple-500/20 text-purple-300">
              <HeartHandshake className="w-4 h-4" />
              <span>{guardians.length} Guardian Households</span>
            </div>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row md:flex-col lg:flex-row items-stretch md:items-end gap-3 shrink-0">
          {onNavigate && (
            <>
              <Button
                size="sm"
                variant="outline"
                onClick={() => onNavigate('admin-staff')}
                className="gap-1.5 text-xs text-indigo-300 border-indigo-500/30 hover:bg-indigo-500/10"
                id="goto-staff-hr-btn"
              >
                <Briefcase className="w-3.5 h-3.5" />
                <span>Staff &amp; HR Registry</span>
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => onNavigate('admin-student-reports')}
                className="gap-1.5 text-xs text-indigo-300 border-indigo-500/30 hover:bg-indigo-500/10"
              >
                <FileSpreadsheet className="w-3.5 h-3.5" />
                <span>Reports &amp; Bulk Actions</span>
              </Button>
            </>
          )}

          <Button
            size="sm"
            variant="outline"
            onClick={() => loadData(true)}
            disabled={refreshing || loading}
            className="gap-1.5"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin' : ''}`} />
            <span>{refreshing ? 'Syncing...' : 'Sync Directory'}</span>
          </Button>

          {!hideTabBar && (
            <Tabs tabs={tabs} activeTab={activeTab} onChange={(id) => setActiveTab(id as TabId)} />
          )}
        </div>
      </div>

      {errorMessage && (
        <Alert
          variant="destructive"
          title="Data Synchronization Notice"
          message={errorMessage}
          onClose={() => setErrorMessage(null)}
        />
      )}

      {/* Main Tab Content */}
      {loading ? (
        <div className="py-24 flex justify-center items-center">
          <LoadingSpinner size="lg" message="Loading stakeholder profiles and academic records..." />
        </div>
      ) : (
        <>
          {activeTab === 'teachers' && (
            <TeachersTab
              teachers={teachers}
              classes={classes}
              subjects={subjects}
              departments={departments}
              onRefresh={() => loadData(true)}
            />
          )}

          {activeTab === 'students' && (
            <StudentsTab
              students={students}
              classes={classes}
              sections={sections}
              sessions={sessions}
              guardians={guardians}
              subjects={subjects}
              onRefresh={() => loadData(true)}
              onSelectGuardian={handleSelectGuardianFromStudent}
            />
          )}

          {activeTab === 'guardians' && (
            <GuardiansTab
              guardians={guardians}
              students={students}
              onRefresh={() => loadData(true)}
              selectedGuardianId={selectedGuardianDeepLink}
            />
          )}

          {activeTab === 'admins' && <AdminsTab />}
        </>
      )}
    </div>
  );
};
