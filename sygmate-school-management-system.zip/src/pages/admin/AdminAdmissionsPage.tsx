import React, { useState, useEffect } from 'react';
import {
  UserPlus,
  FileText,
  Search,
  Filter,
  Plus,
  CheckCircle2,
  Clock,
  XCircle,
  GraduationCap,
  Users,
  Settings,
  HelpCircle,
  Calendar,
  Phone,
  Mail,
  ArrowRight,
  Sparkles,
  RefreshCw,
  Eye,
  Edit,
  Trash2,
  Check,
  Hash,
  Layers,
  ChevronRight,
  ShieldCheck,
  DollarSign,
  AlertCircle
} from 'lucide-react';
import { api } from '../../services/api';
import {
  AdmissionApplication,
  AdmissionEnquiry,
  AcademicEnrollment,
  AdmissionNumberConfig,
  SchoolClass,
  AcademicSession,
  Section
} from '../../types';
import { AdmissionApplicationWizardModal } from '../../components/admissions/AdmissionApplicationWizardModal';
import { AdmissionReviewModal } from '../../components/admissions/AdmissionReviewModal';
import { AdmissionEnquiryModal } from '../../components/admissions/AdmissionEnquiryModal';
import { EnrollmentEditModal } from '../../components/admissions/EnrollmentEditModal';

interface AdminAdmissionsPageProps {
  activeTab?: 'applications' | 'enquiries' | 'enrollments' | 'settings';
  onTabChange?: (tab: string) => void;
  hideTabBar?: boolean;
}

export const AdminAdmissionsPage: React.FC<AdminAdmissionsPageProps> = ({
  activeTab: propActiveTab,
  onTabChange,
  hideTabBar = true
}) => {
  const [internalTab, setInternalTab] = useState<'applications' | 'enquiries' | 'enrollments' | 'settings'>('applications');
  const activeTab = propActiveTab || internalTab;
  const setActiveTab = (tab: any) => {
    setInternalTab(tab);
    onTabChange?.(tab);
  };

  // Stats
  const [stats, setStats] = useState<any>(null);
  const [loadingStats, setLoadingStats] = useState(false);

  // Reference Data
  const [classes, setClasses] = useState<SchoolClass[]>([]);
  const [sessions, setSessions] = useState<AcademicSession[]>([]);
  const [sections, setSections] = useState<Section[]>([]);

  // Applications Tab State
  const [applications, setApplications] = useState<AdmissionApplication[]>([]);
  const [appSearch, setAppSearch] = useState('');
  const [appStatusFilter, setAppStatusFilter] = useState('');
  const [appClassFilter, setAppClassFilter] = useState('');
  const [appSessionFilter, setAppSessionFilter] = useState('');
  const [loadingApps, setLoadingApps] = useState(false);

  // Enquiries Tab State
  const [enquiries, setEnquiries] = useState<AdmissionEnquiry[]>([]);
  const [enqSearch, setEnqSearch] = useState('');
  const [enqStatusFilter, setEnqStatusFilter] = useState('');
  const [enqSourceFilter, setEnqSourceFilter] = useState('');
  const [loadingEnqs, setLoadingEnqs] = useState(false);

  // Enrollments Tab State
  const [enrollments, setEnrollments] = useState<AcademicEnrollment[]>([]);
  const [enrSearch, setEnrSearch] = useState('');
  const [enrClassFilter, setEnrClassFilter] = useState('');
  const [enrSectionFilter, setEnrSectionFilter] = useState('');
  const [loadingEnrs, setLoadingEnrs] = useState(false);

  // Settings Tab State
  const [config, setConfig] = useState<AdmissionNumberConfig>({
    prefix: 'ADM',
    includeYear: true,
    sequencePadding: 4,
    currentSequence: 850,
    autoAssignRoll: true
  });
  const [nextNumberPreview, setNextNumberPreview] = useState('');
  const [savingConfig, setSavingConfig] = useState(false);
  const [configSuccess, setConfigSuccess] = useState(false);

  // Modals
  const [isWizardOpen, setIsWizardOpen] = useState(false);
  const [appToEdit, setAppToEdit] = useState<AdmissionApplication | null>(null);
  const [enqToConvert, setEnqToConvert] = useState<AdmissionEnquiry | null>(null);

  const [isReviewOpen, setIsReviewOpen] = useState(false);
  const [appToReview, setAppToReview] = useState<AdmissionApplication | null>(null);

  const [isEnquiryModalOpen, setIsEnquiryModalOpen] = useState(false);
  const [enquiryToEdit, setEnquiryToEdit] = useState<AdmissionEnquiry | null>(null);

  const [isEnrollmentModalOpen, setIsEnrollmentModalOpen] = useState(false);
  const [enrollmentToEdit, setEnrollmentToEdit] = useState<AcademicEnrollment | null>(null);

  // Notification / Alert Banner
  const [notification, setNotification] = useState<{ type: 'success' | 'info'; message: string } | null>(null);

  const showNotification = (message: string, type: 'success' | 'info' = 'success') => {
    setNotification({ type, message });
    setTimeout(() => setNotification(null), 5000);
  };

  // Initial Load
  useEffect(() => {
    loadReferenceData();
    loadStats();
    loadConfig();
  }, []);

  // Tab driven loads
  useEffect(() => {
    if (activeTab === 'applications') loadApplications();
    if (activeTab === 'enquiries') loadEnquiries();
    if (activeTab === 'enrollments') loadEnrollments();
    if (activeTab === 'settings') loadConfig();
  }, [activeTab, appStatusFilter, appClassFilter, appSessionFilter, enqStatusFilter, enqSourceFilter, enrClassFilter, enrSectionFilter]);

  const loadReferenceData = async () => {
    try {
      const [clsRes, sessRes, secRes] = await Promise.all([
        api.getClasses(),
        api.getAcademicSessions(),
        api.getSections()
      ]);
      if (clsRes.success && clsRes.data) setClasses(clsRes.data);
      if (sessRes.success && sessRes.data) setSessions(sessRes.data);
      if (secRes.success && secRes.data) setSections(secRes.data);
    } catch (err) {
      console.error('Failed to load reference data', err);
    }
  };

  const loadStats = async () => {
    try {
      setLoadingStats(true);
      const res = await api.admissions.getStats();
      if (res.success && res.data) setStats(res.data);
    } catch (err) {
      console.error('Failed to load admission stats', err);
    } finally {
      setLoadingStats(false);
    }
  };

  const loadApplications = async () => {
    try {
      setLoadingApps(true);
      const res = await api.admissions.getApplications({
        status: appStatusFilter || undefined,
        classId: appClassFilter || undefined,
        sessionId: appSessionFilter || undefined,
        search: appSearch || undefined
      });
      if (res.success && res.data) {
        const list = Array.isArray(res.data) ? res.data : Array.isArray((res.data as any).data) ? (res.data as any).data : [];
        setApplications(list);
      }
    } catch (err) {
      console.error('Failed to load applications', err);
    } finally {
      setLoadingApps(false);
    }
  };

  const loadEnquiries = async () => {
    try {
      setLoadingEnqs(true);
      const res = await api.admissions.getEnquiries({
        status: enqStatusFilter || undefined,
        source: enqSourceFilter || undefined,
        search: enqSearch || undefined
      });
      if (res.success && res.data) {
        const list = Array.isArray(res.data) ? res.data : Array.isArray((res.data as any).data) ? (res.data as any).data : [];
        setEnquiries(list);
      }
    } catch (err) {
      console.error('Failed to load enquiries', err);
    } finally {
      setLoadingEnqs(false);
    }
  };

  const loadEnrollments = async () => {
    try {
      setLoadingEnrs(true);
      const res = await api.admissions.getEnrollments({
        classId: enrClassFilter || undefined,
        sectionId: enrSectionFilter || undefined,
        search: enrSearch || undefined
      });
      if (res.success && res.data) {
        const list = Array.isArray(res.data) ? res.data : Array.isArray((res.data as any).data) ? (res.data as any).data : [];
        setEnrollments(list);
      }
    } catch (err) {
      console.error('Failed to load enrollments', err);
    } finally {
      setLoadingEnrs(false);
    }
  };

  const loadConfig = async () => {
    try {
      const [cfgRes, nextRes] = await Promise.all([
        api.admissions.getConfig(),
        api.admissions.getNextNumber()
      ]);
      if (cfgRes.success && cfgRes.data) setConfig(cfgRes.data);
      if (nextRes.success && nextRes.data) setNextNumberPreview(nextRes.data.nextAdmissionNumber);
    } catch (err) {
      console.error('Failed to load config', err);
    }
  };

  const handleSaveConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setSavingConfig(true);
      const res = await api.admissions.updateConfig(config);
      if (res.success && res.data) {
        setConfig(res.data);
        setConfigSuccess(true);
        setTimeout(() => setConfigSuccess(false), 3000);
        loadConfig();
      }
    } catch (err) {
      console.error('Failed to save config', err);
    } finally {
      setSavingConfig(false);
    }
  };

  const handleDeleteEnquiry = async (id: string, number: string) => {
    if (!window.confirm(`Are you sure you want to delete enquiry ${number}?`)) return;
    try {
      const res = await api.admissions.deleteEnquiry(id);
      if (res.success) {
        showNotification(`Enquiry ${number} deleted successfully.`);
        loadEnquiries();
        loadStats();
      }
    } catch (err) {
      console.error('Failed to delete enquiry', err);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header & Actions Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-indigo-100 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300">
              Enterprise Lifecycle
            </span>
            <span className="text-xs text-slate-400">• Part 9B Architecture</span>
          </div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white mt-1">
            Student Admission & Academic Enrollment
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Front office enquiries, multi-step online admissions, duplicate detection, and transactional academic roster enrollment.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Log Enquiry */}
          <button
            onClick={() => {
              setEnquiryToEdit(null);
              setIsEnquiryModalOpen(true);
            }}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700/60 border border-slate-300 dark:border-slate-700 rounded-xl transition shadow-sm"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Log Front Office Enquiry</span>
          </button>

          {/* New Admission Wizard */}
          <button
            onClick={() => {
              setAppToEdit(null);
              setEnqToConvert(null);
              setIsWizardOpen(true);
            }}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 rounded-xl transition shadow-sm"
          >
            <UserPlus className="w-4 h-4" />
            <span>New Student Admission</span>
          </button>
        </div>
      </div>

      {/* Notification Toast */}
      {notification && (
        <div className="p-3.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 flex items-center gap-3 text-emerald-800 dark:text-emerald-300 text-xs shadow-sm">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
          <p className="font-medium">{notification.message}</p>
        </div>
      )}

      {/* Metric Dashboard Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-3">
        <div className="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm">
          <p className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Total Applications</p>
          <p className="text-xl font-bold text-slate-900 dark:text-white mt-1">
            {stats?.applications?.total ?? '--'}
          </p>
          <span className="text-[10px] text-slate-400">All submissions</span>
        </div>

        <div className="p-3.5 rounded-2xl border border-amber-200 dark:border-amber-900/40 bg-amber-50/40 dark:bg-amber-950/20 shadow-sm">
          <p className="text-[11px] font-semibold text-amber-800 dark:text-amber-400 uppercase tracking-wider">Pending Review</p>
          <p className="text-xl font-bold text-amber-900 dark:text-amber-300 mt-1">
            {stats?.applications?.pendingReview ?? '--'}
          </p>
          <span className="text-[10px] text-amber-700 dark:text-amber-500">Requires officer action</span>
        </div>

        <div className="p-3.5 rounded-2xl border border-blue-200 dark:border-blue-900/40 bg-blue-50/40 dark:bg-blue-950/20 shadow-sm">
          <p className="text-[11px] font-semibold text-blue-800 dark:text-blue-400 uppercase tracking-wider">Approved</p>
          <p className="text-xl font-bold text-blue-900 dark:text-blue-300 mt-1">
            {stats?.applications?.approved ?? '--'}
          </p>
          <span className="text-[10px] text-blue-700 dark:text-blue-500">Awaiting enrollment</span>
        </div>

        <div className="p-3.5 rounded-2xl border border-emerald-200 dark:border-emerald-900/40 bg-emerald-50/40 dark:bg-emerald-950/20 shadow-sm">
          <p className="text-[11px] font-semibold text-emerald-800 dark:text-emerald-400 uppercase tracking-wider">Admitted & Enrolled</p>
          <p className="text-xl font-bold text-emerald-900 dark:text-emerald-300 mt-1">
            {stats?.applications?.enrolled ?? '--'}
          </p>
          <span className="text-[10px] text-emerald-700 dark:text-emerald-500">Official student records</span>
        </div>

        <div className="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm">
          <p className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Front Office Enquiries</p>
          <p className="text-xl font-bold text-slate-900 dark:text-white mt-1">
            {stats?.enquiries?.total ?? '--'}
          </p>
          <span className="text-[10px] text-slate-400">Prospective leads</span>
        </div>

        <div className="p-3.5 rounded-2xl border border-indigo-200 dark:border-indigo-900/40 bg-indigo-50/40 dark:bg-indigo-950/20 shadow-sm">
          <p className="text-[11px] font-semibold text-indigo-800 dark:text-indigo-400 uppercase tracking-wider">Conversion Rate</p>
          <p className="text-xl font-bold text-indigo-900 dark:text-indigo-300 mt-1">
            {stats?.enquiries?.conversionRate ? `${stats.enquiries.conversionRate}%` : '0%'}
          </p>
          <span className="text-[10px] text-indigo-700 dark:text-indigo-500">Enquiry → Admission</span>
        </div>
      </div>

      {/* Main Tab Navigation */}
      {!hideTabBar && (
        <div className="border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-1 sm:gap-2">
            {[
              { id: 'applications', label: 'Admission Applications', count: applications?.length || 0, icon: FileText },
              { id: 'enquiries', label: 'Front Office Enquiries', count: enquiries?.length || 0, icon: HelpCircle },
              { id: 'enrollments', label: 'Academic Student Enrollments', count: enrollments?.length || 0, icon: GraduationCap },
              { id: 'settings', label: 'Admission Settings & Numbering', icon: Settings }
            ].map(tab => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center gap-2 py-3 px-3.5 text-xs font-semibold border-b-2 transition ${
                    isActive
                      ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
                      : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{tab.label}</span>
                  {tab.count !== undefined && (
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        isActive
                          ? 'bg-indigo-100 dark:bg-indigo-900/60 text-indigo-700 dark:text-indigo-300'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      {tab.count}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 1: ADMISSION APPLICATIONS */}
      {activeTab === 'applications' && (
        <div className="space-y-4">
          {/* Filter Toolbar */}
          <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2.5 flex-1 min-w-[280px]">
              {/* Search */}
              <div className="relative flex-1 min-w-[180px]">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={appSearch}
                  onChange={e => setAppSearch(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && loadApplications()}
                  placeholder="Search by student, app #, guardian, or email..."
                  className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              {/* Status Filter */}
              <select
                value={appStatusFilter}
                onChange={e => setAppStatusFilter(e.target.value)}
                className="px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="">All Statuses</option>
                <option value="DRAFT">Draft</option>
                <option value="SUBMITTED">Submitted</option>
                <option value="UNDER_REVIEW">Under Review</option>
                <option value="APPROVED">Approved</option>
                <option value="ENROLLED">Enrolled & Active</option>
                <option value="REJECTED">Rejected</option>
              </select>

              {/* Class Filter */}
              <select
                value={appClassFilter}
                onChange={e => setAppClassFilter(e.target.value)}
                className="px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="">All Classes</option>
                {classes.map(c => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            <button
              onClick={loadApplications}
              className="p-2 text-slate-500 hover:text-slate-900 dark:hover:text-white rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition"
              title="Refresh applications"
            >
              <RefreshCw className={`w-4 h-4 ${loadingApps ? 'animate-spin' : ''}`} />
            </button>
          </div>

          {/* Applications Table */}
          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 dark:bg-slate-850 text-slate-500 dark:text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-200 dark:border-slate-800">
                  <tr>
                    <th className="px-4 py-3">App #</th>
                    <th className="px-4 py-3">Applicant Name</th>
                    <th className="px-4 py-3">Class & Section</th>
                    <th className="px-4 py-3">Guardian & Phone</th>
                    <th className="px-4 py-3">Submission Date</th>
                    <th className="px-4 py-3">Status</th>
                    <th className="px-4 py-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-300">
                  {loadingApps ? (
                    <tr>
                      <td colSpan={7} className="px-4 py-8 text-center text-slate-400">
                        Loading applications...
                      </td>
                    </tr>
                  ) : (applications?.length || 0) === 0 ? (
                    <tr>
                      <td colSpan={7} className="px-4 py-12 text-center text-slate-400">
                        <FileText className="w-8 h-8 mx-auto mb-2 opacity-40" />
                        <p className="text-sm font-medium">No admission applications found.</p>
                        <p className="text-xs text-slate-400 mt-0.5">Click "New Student Admission" to start an application.</p>
                      </td>
                    </tr>
                  ) : (
                    applications.map(app => {
                      return (
                        <tr key={app.id} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40 transition">
                          <td className="px-4 py-3 font-semibold text-indigo-600 dark:text-indigo-400">
                            {app.applicationNumber}
                            {app.enquiryNumber && (
                              <p className="text-[10px] text-slate-400">via {app.enquiryNumber}</p>
                            )}
                          </td>
                          <td className="px-4 py-3">
                            <div className="font-semibold text-slate-900 dark:text-white">
                              {app.fullName}
                            </div>
                            <div className="text-[11px] text-slate-400">
                              {app.gender.toUpperCase()} • DOB: {app.dateOfBirth}
                            </div>
                          </td>
                          <td className="px-4 py-3">
                            <span className="font-medium text-slate-900 dark:text-white">{app.className}</span>
                            <span className="text-slate-400 ml-1">
                              {app.sectionName ? `(${app.sectionName})` : ''}
                            </span>
                            <p className="text-[10px] text-slate-400">{app.academicSessionName}</p>
                          </td>
                          <td className="px-4 py-3">
                            <div className="font-medium text-slate-900 dark:text-white">{app.guardianName}</div>
                            <div className="text-[11px] text-slate-400">{app.guardianPhone}</div>
                          </td>
                          <td className="px-4 py-3 text-slate-500">
                            {app.applicationDate || app.createdAt.split('T')[0]}
                          </td>
                          <td className="px-4 py-3">
                            {app.status === 'ENROLLED' ? (
                              <div>
                                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300">
                                  <Check className="w-3 h-3" />
                                  <span>Enrolled</span>
                                </span>
                                {app.admittedAdmissionNumber && (
                                  <p className="text-[10px] font-mono text-emerald-700 dark:text-emerald-400 mt-0.5">
                                    {app.admittedAdmissionNumber}
                                  </p>
                                )}
                              </div>
                            ) : app.status === 'APPROVED' ? (
                              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-blue-100 dark:bg-blue-950/60 text-blue-800 dark:text-blue-300">
                                Approved
                              </span>
                            ) : app.status === 'UNDER_REVIEW' ? (
                              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300">
                                Under Review
                              </span>
                            ) : app.status === 'REJECTED' ? (
                              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-rose-100 dark:bg-rose-950/60 text-rose-800 dark:text-rose-300">
                                Rejected
                              </span>
                            ) : app.status === 'DRAFT' ? (
                              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                                Draft
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-indigo-100 dark:bg-indigo-950/60 text-indigo-800 dark:text-indigo-300">
                                Submitted
                              </span>
                            )}
                          </td>
                          <td className="px-4 py-3 text-right">
                            <div className="inline-flex items-center gap-1.5">
                              {/* Dossier Review */}
                              <button
                                onClick={() => {
                                  setAppToReview(app);
                                  setIsReviewOpen(true);
                                }}
                                className="px-2.5 py-1 text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 rounded-lg transition"
                              >
                                Review Dossier
                              </button>

                              {/* Edit Application if not yet enrolled */}
                              {app.status !== 'ENROLLED' && (
                                <button
                                  onClick={() => {
                                    setAppToEdit(app);
                                    setEnqToConvert(null);
                                    setIsWizardOpen(true);
                                  }}
                                  className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                                  title="Edit Application"
                                >
                                  <Edit className="w-3.5 h-3.5" />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: FRONT OFFICE ENQUIRIES */}
      {activeTab === 'enquiries' && (
        <div className="space-y-4">
          {/* Toolbar */}
          <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2.5 flex-1 min-w-[280px]">
              <div className="relative flex-1 min-w-[180px]">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={enqSearch}
                  onChange={e => setEnqSearch(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && loadEnquiries()}
                  placeholder="Search student, parent, or enquiry #..."
                  className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <select
                value={enqStatusFilter}
                onChange={e => setEnqStatusFilter(e.target.value)}
                className="px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="">All Statuses</option>
                <option value="NEW">New</option>
                <option value="CONTACTED">Contacted</option>
                <option value="QUALIFIED">Qualified</option>
                <option value="CONVERTED">Converted to Admission</option>
                <option value="CLOSED">Closed</option>
              </select>

              <select
                value={enqSourceFilter}
                onChange={e => setEnqSourceFilter(e.target.value)}
                className="px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="">All Sources</option>
                <option value="WALK_IN">Walk-in</option>
                <option value="WEBSITE">Website</option>
                <option value="PHONE">Phone</option>
                <option value="REFERRAL">Referral</option>
                <option value="SOCIAL_MEDIA">Social Media</option>
              </select>
            </div>

            <button
              onClick={loadEnquiries}
              className="p-2 text-slate-500 hover:text-slate-900 dark:hover:text-white rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition"
              title="Refresh enquiries"
            >
              <RefreshCw className={`w-4 h-4 ${loadingEnqs ? 'animate-spin' : ''}`} />
            </button>
          </div>

          {/* Enquiries Table */}
          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 dark:bg-slate-850 text-slate-500 dark:text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-200 dark:border-slate-800">
                  <tr>
                    <th className="px-4 py-3">Enquiry #</th>
                    <th className="px-4 py-3">Student Name</th>
                    <th className="px-4 py-3">Applying Class</th>
                    <th className="px-4 py-3">Parent Contact</th>
                    <th className="px-4 py-3">Source</th>
                    <th className="px-4 py-3">Follow-Up Date</th>
                    <th className="px-4 py-3">Status</th>
                    <th className="px-4 py-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-300">
                  {loadingEnqs ? (
                    <tr>
                      <td colSpan={8} className="px-4 py-8 text-center text-slate-400">
                        Loading enquiries...
                      </td>
                    </tr>
                  ) : (enquiries?.length || 0) === 0 ? (
                    <tr>
                      <td colSpan={8} className="px-4 py-12 text-center text-slate-400">
                        <HelpCircle className="w-8 h-8 mx-auto mb-2 opacity-40" />
                        <p className="text-sm font-medium">No admission enquiries found.</p>
                      </td>
                    </tr>
                  ) : (
                    enquiries.map(enq => (
                      <tr key={enq.id} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40 transition">
                        <td className="px-4 py-3 font-semibold text-indigo-600 dark:text-indigo-400">
                          {enq.enquiryNumber}
                        </td>
                        <td className="px-4 py-3 font-medium text-slate-900 dark:text-white">
                          {enq.studentName}
                          {enq.gender && (
                            <span className="text-[10px] text-slate-400 block capitalize">
                              {enq.gender} • {enq.dateOfBirth || 'No DOB'}
                            </span>
                          )}
                        </td>
                        <td className="px-4 py-3 font-medium text-slate-900 dark:text-white">
                          {enq.applyingClassName}
                        </td>
                        <td className="px-4 py-3">
                          <div className="font-medium text-slate-900 dark:text-white">
                            {enq.parentName} ({enq.relationship})
                          </div>
                          <div className="text-[11px] text-slate-400">{enq.phone}</div>
                        </td>
                        <td className="px-4 py-3 text-slate-500">
                          <span className="px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-[10px] font-semibold">
                            {(enq.source || 'GENERAL').replace(/_/g, ' ')}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-slate-500">
                          {enq.followUpDate || 'None scheduled'}
                        </td>
                        <td className="px-4 py-3">
                          {enq.status === 'CONVERTED' ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300">
                              <Check className="w-3 h-3" />
                              <span>Converted</span>
                            </span>
                          ) : enq.status === 'QUALIFIED' ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-blue-100 dark:bg-blue-950/60 text-blue-800 dark:text-blue-300">
                              Qualified
                            </span>
                          ) : enq.status === 'CONTACTED' ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300">
                              Contacted
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-indigo-100 dark:bg-indigo-950/60 text-indigo-800 dark:text-indigo-300">
                              New
                            </span>
                          )}
                        </td>
                        <td className="px-4 py-3 text-right">
                          <div className="inline-flex items-center gap-2">
                            {/* Convert to Admission Button */}
                            {enq.status !== 'CONVERTED' && (
                              <button
                                onClick={() => {
                                  setEnqToConvert(enq);
                                  setAppToEdit(null);
                                  setIsWizardOpen(true);
                                }}
                                className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/40 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 border border-emerald-200 dark:border-emerald-800 rounded-lg transition"
                                title="Convert to Admission Application"
                              >
                                <span>Convert</span>
                                <ArrowRight className="w-3 h-3" />
                              </button>
                            )}

                            {/* Edit */}
                            <button
                              onClick={() => {
                                setEnquiryToEdit(enq);
                                setIsEnquiryModalOpen(true);
                              }}
                              className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                              title="Edit Enquiry"
                            >
                              <Edit className="w-3.5 h-3.5" />
                            </button>

                            {/* Delete */}
                            <button
                              onClick={() => handleDeleteEnquiry(enq.id, enq.enquiryNumber)}
                              className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-950/40 transition"
                              title="Delete Enquiry"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: ACADEMIC STUDENT ENROLLMENTS */}
      {activeTab === 'enrollments' && (
        <div className="space-y-4">
          {/* Toolbar */}
          <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2.5 flex-1 min-w-[280px]">
              <div className="relative flex-1 min-w-[180px]">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={enrSearch}
                  onChange={e => setEnrSearch(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && loadEnrollments()}
                  placeholder="Search student, admission #, or roll #..."
                  className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <select
                value={enrClassFilter}
                onChange={e => {
                  setEnrClassFilter(e.target.value);
                  setEnrSectionFilter('');
                }}
                className="px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="">All Classes</option>
                {classes.map(c => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>

              {enrClassFilter && (
                <select
                  value={enrSectionFilter}
                  onChange={e => setEnrSectionFilter(e.target.value)}
                  className="px-3 py-1.5 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="">All Sections</option>
                  {sections
                    .filter(s => s.classId === enrClassFilter)
                    .map(sec => (
                      <option key={sec.id} value={sec.id}>
                        Section {sec.name}
                      </option>
                    ))}
                </select>
              )}
            </div>

            <button
              onClick={loadEnrollments}
              className="p-2 text-slate-500 hover:text-slate-900 dark:hover:text-white rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition"
              title="Refresh enrollments"
            >
              <RefreshCw className={`w-4 h-4 ${loadingEnrs ? 'animate-spin' : ''}`} />
            </button>
          </div>

          {/* Enrollments Table */}
          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 dark:bg-slate-850 text-slate-500 dark:text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-200 dark:border-slate-800">
                  <tr>
                    <th className="px-4 py-3">Roll No</th>
                    <th className="px-4 py-3">Admission #</th>
                    <th className="px-4 py-3">Student Name</th>
                    <th className="px-4 py-3">Class & Section</th>
                    <th className="px-4 py-3">Session</th>
                    <th className="px-4 py-3">Enrollment Date</th>
                    <th className="px-4 py-3">Status</th>
                    <th className="px-4 py-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-300">
                  {loadingEnrs ? (
                    <tr>
                      <td colSpan={8} className="px-4 py-8 text-center text-slate-400">
                        Loading student enrollment records...
                      </td>
                    </tr>
                  ) : (enrollments?.length || 0) === 0 ? (
                    <tr>
                      <td colSpan={8} className="px-4 py-12 text-center text-slate-400">
                        <GraduationCap className="w-8 h-8 mx-auto mb-2 opacity-40" />
                        <p className="text-sm font-medium">No student enrollment records found.</p>
                      </td>
                    </tr>
                  ) : (
                    enrollments.map(enr => (
                      <tr key={enr.id} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40 transition">
                        <td className="px-4 py-3 font-bold text-slate-900 dark:text-white">
                          <span className="px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200">
                            {enr.rollNumber}
                          </span>
                        </td>
                        <td className="px-4 py-3 font-mono font-semibold text-indigo-600 dark:text-indigo-400">
                          {enr.studentAdmissionNumber}
                        </td>
                        <td className="px-4 py-3 font-semibold text-slate-900 dark:text-white">
                          {enr.studentName}
                        </td>
                        <td className="px-4 py-3">
                          <span className="font-medium text-slate-900 dark:text-white">{enr.className}</span>
                          <span className="text-slate-400 ml-1">({enr.sectionName})</span>
                        </td>
                        <td className="px-4 py-3 text-slate-500">
                          {enr.academicSessionName}
                        </td>
                        <td className="px-4 py-3 text-slate-500">
                          {enr.enrollmentDate}
                        </td>
                        <td className="px-4 py-3">
                          <span
                            className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold capitalize ${
                              enr.status === 'active'
                                ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300'
                                : enr.status === 'transferred'
                                ? 'bg-amber-100 text-amber-800'
                                : 'bg-slate-100 text-slate-700'
                            }`}
                          >
                            {enr.status}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-right">
                          <button
                            onClick={() => {
                              setEnrollmentToEdit(enr);
                              setIsEnrollmentModalOpen(true);
                            }}
                            className="px-2.5 py-1 text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 rounded-lg transition"
                          >
                            Manage Roll / Status
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: ADMISSION SETTINGS & NUMBERING */}
      {activeTab === 'settings' && (
        <div className="max-w-2xl space-y-6">
          <div className="p-6 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm space-y-6">
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                Admission Number Format & Sequence Generator
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Configure auto-generation rules for official student admission numbers upon enrollment.
              </p>
            </div>

            {configSuccess && (
              <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 flex items-center gap-2 text-xs text-emerald-800 dark:text-emerald-300">
                <Check className="w-4 h-4 text-emerald-600" />
                <span>Admission numbering configuration updated successfully.</span>
              </div>
            )}

            {/* Live Preview Card */}
            <div className="p-4 rounded-xl bg-indigo-50/60 dark:bg-indigo-950/30 border border-indigo-100 dark:border-indigo-900/40 flex items-center justify-between">
              <div>
                <p className="text-[11px] font-semibold text-indigo-900 dark:text-indigo-200 uppercase tracking-wider">
                  Next Generated Admission Number:
                </p>
                <p className="text-xl font-mono font-bold text-indigo-600 dark:text-indigo-400 mt-0.5">
                  {nextNumberPreview || `${config.prefix}-${new Date().getFullYear()}-${String(config.currentSequence + 1).padStart(config.sequencePadding, '0')}`}
                </p>
              </div>
              <Sparkles className="w-6 h-6 text-indigo-500 opacity-60" />
            </div>

            <form onSubmit={handleSaveConfig} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Number Prefix
                  </label>
                  <input
                    type="text"
                    required
                    value={config.prefix}
                    onChange={e => setConfig({ ...config, prefix: e.target.value.toUpperCase() })}
                    placeholder="ADM"
                    className="w-full px-3 py-2 text-sm font-mono uppercase rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Sequence Zero-Padding
                  </label>
                  <select
                    value={config.sequencePadding}
                    onChange={e => setConfig({ ...config, sequencePadding: Number(e.target.value) })}
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  >
                    <option value={3}>3 digits (e.g. 001)</option>
                    <option value={4}>4 digits (e.g. 0001)</option>
                    <option value={5}>5 digits (e.g. 00001)</option>
                    <option value={6}>6 digits (e.g. 000001)</option>
                  </select>
                </div>
              </div>

              <div className="space-y-2 pt-2">
                <label className="flex items-center gap-2.5 text-xs font-medium text-slate-700 dark:text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={config.includeYear}
                    onChange={e => setConfig({ ...config, includeYear: e.target.checked })}
                    className="w-4 h-4 text-indigo-600 rounded border-slate-300 focus:ring-indigo-500"
                  />
                  <span>Include Current Calendar Year in Admission Number (e.g. ADM-2026-XXXX)</span>
                </label>

                <label className="flex items-center gap-2.5 text-xs font-medium text-slate-700 dark:text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={config.autoAssignRoll}
                    onChange={e => setConfig({ ...config, autoAssignRoll: e.target.checked })}
                    className="w-4 h-4 text-indigo-600 rounded border-slate-300 focus:ring-indigo-500"
                  />
                  <span>Automatically assign next sequential roll number within section</span>
                </label>
              </div>

              <div className="pt-4 border-t border-slate-200 dark:border-slate-800 flex justify-end">
                <button
                  type="submit"
                  disabled={savingConfig}
                  className="px-5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition shadow-sm disabled:opacity-50"
                >
                  {savingConfig ? 'Saving...' : 'Save Configuration'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 1: ADMISSION WIZARD */}
      <AdmissionApplicationWizardModal
        isOpen={isWizardOpen}
        onClose={() => {
          setIsWizardOpen(false);
          setAppToEdit(null);
          setEnqToConvert(null);
        }}
        applicationToEdit={appToEdit}
        enquiryToConvert={enqToConvert}
        onSuccess={(app, enrolled) => {
          showNotification(
            enrolled
              ? `Student ${app.fullName} successfully admitted & enrolled as ${app.admittedAdmissionNumber}!`
              : `Admission application ${app.applicationNumber} saved successfully.`
          );
          loadApplications();
          loadEnquiries();
          loadEnrollments();
          loadStats();
        }}
      />

      {/* MODAL 2: APPLICATION REVIEW */}
      <AdmissionReviewModal
        isOpen={isReviewOpen}
        onClose={() => {
          setIsReviewOpen(false);
          setAppToReview(null);
        }}
        application={appToReview}
        onUpdated={(app, enrolledData) => {
          if (enrolledData) {
            showNotification(
              `Student ${app.fullName} officially enrolled! Admission No: ${enrolledData.admissionNumber}, Roll: ${enrolledData.rollNumber}.`
            );
          } else {
            showNotification(`Application ${app.applicationNumber} updated to ${app.status}.`);
          }
          loadApplications();
          loadEnrollments();
          loadStats();
        }}
      />

      {/* MODAL 3: ENQUIRY MODAL */}
      <AdmissionEnquiryModal
        isOpen={isEnquiryModalOpen}
        onClose={() => {
          setIsEnquiryModalOpen(false);
          setEnquiryToEdit(null);
        }}
        enquiryToEdit={enquiryToEdit}
        onSuccess={enq => {
          showNotification(`Enquiry ${enq.enquiryNumber} logged successfully.`);
          loadEnquiries();
          loadStats();
        }}
        onConvertToAdmission={enq => {
          setEnqToConvert(enq);
          setAppToEdit(null);
          setIsWizardOpen(true);
        }}
      />

      {/* MODAL 4: ENROLLMENT EDIT MODAL */}
      <EnrollmentEditModal
        isOpen={isEnrollmentModalOpen}
        onClose={() => {
          setIsEnrollmentModalOpen(false);
          setEnrollmentToEdit(null);
        }}
        enrollment={enrollmentToEdit}
        onSuccess={enr => {
          showNotification(`Enrollment record for ${enr.studentName} updated.`);
          loadEnrollments();
          loadStats();
        }}
      />
    </div>
  );
};
