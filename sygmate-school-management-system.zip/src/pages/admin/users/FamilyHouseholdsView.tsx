import React, { useState, useEffect } from 'react';
import {
  Home,
  Plus,
  Search,
  Edit2,
  Trash2,
  Users,
  GraduationCap,
  Phone,
  Mail,
  MapPin,
  CheckCircle2,
  AlertCircle,
  UserPlus,
  HeartHandshake,
  Layers,
  ChevronRight,
  ShieldAlert
} from 'lucide-react';
import { Table, Column } from '../../../components/ui/Table.js';
import { Badge } from '../../../components/ui/Badge.js';
import { Button } from '../../../components/ui/Button.js';
import { Input } from '../../../components/ui/Input.js';
import { Select } from '../../../components/ui/Select.js';
import { Modal } from '../../../components/ui/Modal.js';
import { Alert } from '../../../components/ui/Alert.js';
import { ConfirmDialog } from '../../../components/ui/ConfirmDialog.js';
import { EmptyState } from '../../../components/ui/EmptyState.js';
import { api } from '../../../services/api.js';
import { Family, Guardian, Student } from '../../../types/index.js';

interface FamilyHouseholdsViewProps {
  guardians: Guardian[];
  students: Student[];
  onRefreshParent: () => void;
}

export const FamilyHouseholdsView: React.FC<FamilyHouseholdsViewProps> = ({
  guardians,
  students,
  onRefreshParent
}) => {
  const [families, setFamilies] = useState<Family[]>([]);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');

  // Modals
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isDossierOpen, setIsDossierOpen] = useState(false);
  const [selectedFamilyDossier, setSelectedFamilyDossier] = useState<Family | null>(null);
  const [familyToEdit, setFamilyToEdit] = useState<Family | null>(null);
  const [familyToDelete, setFamilyToDelete] = useState<Family | null>(null);

  // Add Member to Family Modals
  const [isAddGuardianModalOpen, setIsAddGuardianModalOpen] = useState(false);
  const [isAddStudentModalOpen, setIsAddStudentModalOpen] = useState(false);
  const [selectedGuardianToAdd, setSelectedGuardianToAdd] = useState('');
  const [selectedStudentToAdd, setSelectedStudentToAdd] = useState('');

  // Form State
  const [formData, setFormData] = useState({
    familyName: '',
    familyCode: '',
    address: '',
    emergencyContactPhone: '',
    emergencyContactName: '',
    billingPreference: 'Primary Guardian',
    notes: '',
    status: 'active' as 'active' | 'inactive',
    guardianIds: [] as string[],
    studentIds: [] as string[]
  });

  const [formSubmitting, setFormSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);

  const fetchFamilies = async () => {
    setLoading(true);
    try {
      const res = await api.users.getFamilies();
      if (res.success && res.data) {
        setFamilies(res.data);
      }
    } catch (err: any) {
      setActionError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchFamilies();
  }, []);

  const handleOpenCreate = () => {
    setFormData({
      familyName: '',
      familyCode: `FAM-${Math.floor(1000 + Math.random() * 9000)}`,
      address: '',
      emergencyContactPhone: '',
      emergencyContactName: '',
      billingPreference: 'Primary Guardian',
      notes: '',
      status: 'active',
      guardianIds: [],
      studentIds: []
    });
    setFormError(null);
    setIsCreateModalOpen(true);
  };

  const handleOpenEdit = (family: Family) => {
    setFamilyToEdit(family);
    setFormData({
      familyName: family.familyName,
      familyCode: family.familyCode || '',
      address: family.address || '',
      emergencyContactPhone: family.emergencyContactPhone || '',
      emergencyContactName: family.emergencyContactName || '',
      billingPreference: family.billingPreference || 'Primary Guardian',
      notes: family.notes || '',
      status: family.status || 'active',
      guardianIds: family.guardianIds || [],
      studentIds: family.studentIds || []
    });
    setFormError(null);
    setIsEditModalOpen(true);
  };

  const handleCreateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormSubmitting(true);
    setFormError(null);

    try {
      const res = await api.users.createFamily(formData);
      if (res.success) {
        setIsCreateModalOpen(false);
        fetchFamilies();
        onRefreshParent();
      } else {
        setFormError(res.error || 'Failed to create family record.');
      }
    } catch (err: any) {
      setFormError(err.message);
    } finally {
      setFormSubmitting(false);
    }
  };

  const handleEditSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!familyToEdit) return;
    setFormSubmitting(true);
    setFormError(null);

    try {
      const res = await api.users.updateFamily(familyToEdit.id, formData);
      if (res.success) {
        setIsEditModalOpen(false);
        setFamilyToEdit(null);
        fetchFamilies();
        onRefreshParent();
      } else {
        setFormError(res.error || 'Failed to update family record.');
      }
    } catch (err: any) {
      setFormError(err.message);
    } finally {
      setFormSubmitting(false);
    }
  };

  const handleDeleteFamily = async () => {
    if (!familyToDelete) return;
    try {
      const res = await api.users.deleteFamily(familyToDelete.id);
      if (res.success) {
        setFamilyToDelete(null);
        fetchFamilies();
        onRefreshParent();
      } else {
        setActionError(res.error || 'Failed to delete family.');
      }
    } catch (err: any) {
      setActionError(err.message);
    }
  };

  const handleAddGuardianToFamily = async () => {
    if (!selectedFamilyDossier || !selectedGuardianToAdd) return;
    try {
      const res = await api.users.addFamilyGuardian(selectedFamilyDossier.id, selectedGuardianToAdd);
      if (res.success) {
        setIsAddGuardianModalOpen(false);
        setSelectedGuardianToAdd('');
        const updated = await api.users.getFamily(selectedFamilyDossier.id);
        if (updated.success && updated.data) {
          setSelectedFamilyDossier(updated.data);
        }
        fetchFamilies();
        onRefreshParent();
      } else {
        setActionError(res.error || 'Failed to attach guardian to family.');
      }
    } catch (err: any) {
      setActionError(err.message);
    }
  };

  const handleAddStudentToFamily = async () => {
    if (!selectedFamilyDossier || !selectedStudentToAdd) return;
    try {
      const res = await api.users.addFamilyStudent(selectedFamilyDossier.id, selectedStudentToAdd);
      if (res.success) {
        setIsAddStudentModalOpen(false);
        setSelectedStudentToAdd('');
        const updated = await api.users.getFamily(selectedFamilyDossier.id);
        if (updated.success && updated.data) {
          setSelectedFamilyDossier(updated.data);
        }
        fetchFamilies();
        onRefreshParent();
      } else {
        setActionError(res.error || 'Failed to attach student to family.');
      }
    } catch (err: any) {
      setActionError(err.message);
    }
  };

  const handleRemoveMember = async (memberType: 'guardian' | 'student', memberId: string) => {
    if (!selectedFamilyDossier) return;
    try {
      const res = await api.users.removeFamilyMember(selectedFamilyDossier.id, memberType, memberId);
      if (res.success) {
        const updated = await api.users.getFamily(selectedFamilyDossier.id);
        if (updated.success && updated.data) {
          setSelectedFamilyDossier(updated.data);
        }
        fetchFamilies();
        onRefreshParent();
      } else {
        setActionError(res.error || `Failed to remove ${memberType} from family.`);
      }
    } catch (err: any) {
      setActionError(err.message);
    }
  };

  // Filtered families
  const filteredFamilies = families.filter((f) => {
    const q = (search || '').toLowerCase().trim();
    const matchesSearch =
      !q ||
      (f.familyName || '').toLowerCase().includes(q) ||
      (f.familyCode || '').toLowerCase().includes(q) ||
      (f.address || '').toLowerCase().includes(q) ||
      (f.guardians || []).some((g: any) => (g.name || '').toLowerCase().includes(q)) ||
      (f.students || []).some((s: any) => (s.name || '').toLowerCase().includes(q));

    const matchesStatus = statusFilter === 'ALL' || (f.status || 'active').toLowerCase() === statusFilter.toLowerCase();
    return matchesSearch && matchesStatus;
  });

  const columns: Column<Family>[] = [
    {
      header: 'Family Household',
      accessor: (row) => (
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-50 border border-blue-200 text-blue-700 font-bold flex items-center justify-center text-xs shadow-2xs">
            <Home className="w-5 h-5 text-blue-600" />
          </div>
          <div>
            <div className="font-semibold text-slate-900 flex items-center gap-2">
              <span>{row.familyName}</span>
              {row.familyCode && (
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-100 text-slate-700 font-mono">
                  {row.familyCode}
                </span>
              )}
            </div>
            <div className="text-[11px] text-slate-400 flex items-center gap-1 mt-0.5 max-w-xs truncate">
              <MapPin className="w-3 h-3 text-slate-500 shrink-0" />
              <span className="truncate">{row.address || 'Address not registered'}</span>
            </div>
          </div>
        </div>
      )
    },
    {
      header: 'Co-Guardians',
      accessor: (row) => {
        const gList = row.guardians || [];
        return (
          <div className="space-y-1">
            <div className="text-xs font-semibold text-slate-200">
              {gList.length} {gList.length === 1 ? 'Parent / Guardian' : 'Parents / Guardians'}
            </div>
            <div className="flex flex-wrap gap-1 max-w-xs">
              {gList.length > 0 ? (
                gList.map((g: any) => (
                  <span
                    key={g.id}
                    className="px-2 py-0.5 rounded-md bg-indigo-500/10 text-indigo-300 text-[11px] font-medium border border-indigo-500/20"
                  >
                    {g.name} ({g.relationship || 'Guardian'})
                  </span>
                ))
              ) : (
                <span className="text-[11px] text-slate-500 italic">No guardians assigned</span>
              )}
            </div>
          </div>
        );
      }
    },
    {
      header: 'Scholar Siblings (1:N)',
      accessor: (row) => {
        const sList = row.students || [];
        return (
          <div className="space-y-1">
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-semibold text-slate-200">
                {sList.length} {sList.length === 1 ? 'Scholar' : 'Scholars'}
              </span>
              {sList.length > 1 && (
                <span className="text-[10px] px-1.5 py-0.2 rounded bg-purple-500/20 text-purple-300 font-bold">
                  Sibling Group
                </span>
              )}
            </div>
            <div className="flex flex-wrap gap-1 max-w-xs">
              {sList.length > 0 ? (
                sList.map((s: any) => (
                  <span
                    key={s.id}
                    className="px-2 py-0.5 rounded-md bg-emerald-500/10 text-emerald-300 text-[11px] font-medium border border-emerald-500/20"
                  >
                    {s.name} ({s.className || 'Class'})
                  </span>
                ))
              ) : (
                <span className="text-[11px] text-slate-500 italic">No scholars attached</span>
              )}
            </div>
          </div>
        );
      }
    },
    {
      header: 'Emergency Contact',
      accessor: (row) => (
        <div className="text-xs text-slate-300 space-y-0.5">
          <div className="font-medium text-white">{row.emergencyContactName || '—'}</div>
          {row.emergencyContactPhone && (
            <div className="text-[11px] text-indigo-400 font-mono flex items-center gap-1">
              <Phone className="w-3 h-3 text-slate-500" />
              <span>{row.emergencyContactPhone}</span>
            </div>
          )}
        </div>
      )
    },
    {
      header: 'Status',
      accessor: (row) => (
        <Badge variant={row.status === 'active' ? 'success' : 'secondary'} dot>
          {(row.status || 'ACTIVE').toUpperCase()}
        </Badge>
      )
    },
    {
      header: 'Actions',
      accessor: (row) => (
        <div className="flex items-center gap-1.5">
          <Button
            id={`btn-view-family-${row.id}`}
            size="xs"
            variant="outline"
            onClick={() => {
              setSelectedFamilyDossier(row);
              setIsDossierOpen(true);
            }}
            title="View Household Dossier"
          >
            Household Dossier
          </Button>
          <Button
            id={`btn-edit-family-${row.id}`}
            size="xs"
            variant="secondary"
            onClick={() => handleOpenEdit(row)}
            title="Edit Family Record"
          >
            <Edit2 className="w-3.5 h-3.5" />
          </Button>
          <Button
            id={`btn-delete-family-${row.id}`}
            size="xs"
            variant="danger"
            onClick={() => setFamilyToDelete(row)}
            title="Delete Family Record"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </Button>
        </div>
      )
    }
  ];

  return (
    <div className="space-y-6">
      {actionError && (
        <Alert
          variant="destructive"
          title="Household Alert"
          message={actionError}
          onClose={() => setActionError(null)}
        />
      )}

      {/* Toolbar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
        <div className="flex flex-1 flex-col sm:flex-row gap-3">
          <div className="w-full sm:w-72">
            <Input
              id="search-families-input"
              placeholder="Search by family name, code, scholar..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              leftIcon={<Search className="w-4 h-4" />}
            />
          </div>

          <div className="w-full sm:w-40">
            <Select
              id="filter-family-status"
              options={[
                { value: 'ALL', label: 'All Statuses' },
                { value: 'active', label: 'Active Only' },
                { value: 'inactive', label: 'Inactive' }
              ]}
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
            />
          </div>
        </div>

        <Button
          id="btn-create-family"
          variant="primary"
          onClick={handleOpenCreate}
          className="gap-2 shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Create Family Household</span>
        </Button>
      </div>

      {/* Table */}
      {filteredFamilies.length > 0 ? (
        <Table columns={columns} data={filteredFamilies} keyExtractor={(f) => f.id} />
      ) : (
        <EmptyState
          icon={<Home className="w-10 h-10 text-indigo-400" />}
          title="No Family Households Found"
          description={
            search || statusFilter !== 'ALL'
              ? 'No households match your active search filters.'
              : 'Group multiple guardians (co-parents) and sibling scholars under unified Family Household profiles.'
          }
          action={
            <Button size="sm" variant="primary" onClick={handleOpenCreate}>
              <Plus className="w-4 h-4 mr-1.5" />
              Create Family Household
            </Button>
          }
        />
      )}

      {/* CREATE / EDIT FAMILY MODAL */}
      <Modal
        isOpen={isCreateModalOpen || isEditModalOpen}
        onClose={() => {
          setIsCreateModalOpen(false);
          setIsEditModalOpen(false);
          setFamilyToEdit(null);
        }}
        title={isCreateModalOpen ? 'Create Family Household Unit' : `Edit Family — ${familyToEdit?.familyName}`}
        description="Unified household container linking multiple guardians and enrolled scholar siblings."
        size="lg"
      >
        <form onSubmit={isCreateModalOpen ? handleCreateSubmit : handleEditSubmit} className="space-y-4 text-xs">
          {formError && (
            <Alert variant="destructive" message={formError} onClose={() => setFormError(null)} />
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <Input
              id="fam-name"
              label="Family Household Name *"
              required
              value={formData.familyName}
              onChange={(e) => setFormData({ ...formData, familyName: e.target.value })}
              placeholder="e.g. The Williams Family"
            />
            <Input
              id="fam-code"
              label="Household Code / Identifier"
              value={formData.familyCode}
              onChange={(e) => setFormData({ ...formData, familyCode: e.target.value })}
              placeholder="e.g. FAM-1049"
            />
          </div>

          <Input
            id="fam-address"
            label="Household Residential Address"
            value={formData.address}
            onChange={(e) => setFormData({ ...formData, address: e.target.value })}
            placeholder="e.g. 742 Evergreen Terrace, Springfield"
          />

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <Input
              id="fam-emerg-name"
              label="Emergency Dispatch Contact Name"
              value={formData.emergencyContactName}
              onChange={(e) => setFormData({ ...formData, emergencyContactName: e.target.value })}
              placeholder="e.g. Eleanor Williams (Aunt)"
            />
            <Input
              id="fam-emerg-phone"
              label="Emergency Dispatch Phone Number"
              value={formData.emergencyContactPhone}
              onChange={(e) => setFormData({ ...formData, emergencyContactPhone: e.target.value })}
              placeholder="+1 (555) 019-9922"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <Select
              id="fam-billing"
              label="Fee Billing Recipient"
              options={[
                { value: 'Primary Guardian', label: 'Primary Guardian' },
                { value: 'Joint Household Billing', label: 'Joint Household Billing' },
                { value: 'External Sponsor', label: 'External Sponsor' }
              ]}
              value={formData.billingPreference}
              onChange={(e) => setFormData({ ...formData, billingPreference: e.target.value })}
            />
            <Select
              id="fam-status"
              label="Household Status"
              options={[
                { value: 'active', label: 'Active' },
                { value: 'inactive', label: 'Inactive' }
              ]}
              value={formData.status}
              onChange={(e) => setFormData({ ...formData, status: e.target.value as any })}
            />
          </div>

          {/* Select Guardians to attach */}
          {isCreateModalOpen && (
            <div className="space-y-3 pt-2 border-t border-white/5">
              <div className="font-semibold text-indigo-400 uppercase tracking-wider text-[10px]">
                Attach Initial Co-Guardians
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-36 overflow-y-auto pr-1">
                {(guardians || []).map((g) => {
                  const isSelected = formData.guardianIds.includes(g.id);
                  return (
                    <label
                      key={g.id}
                      className={`flex items-center gap-2 p-2 rounded-lg border text-xs cursor-pointer ${
                        isSelected
                          ? 'bg-indigo-600/20 border-indigo-500/50 text-white'
                          : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10'
                      }`}
                    >
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => {
                          setFormData((prev) => ({
                            ...prev,
                            guardianIds: isSelected
                              ? prev.guardianIds.filter((id) => id !== g.id)
                              : [...prev.guardianIds, g.id]
                          }));
                        }}
                        className="rounded text-indigo-600 focus:ring-indigo-500"
                      />
                      <div className="truncate">
                        <div className="font-medium text-white truncate">{g.name}</div>
                        <div className="text-[10px] text-slate-400">
                          {g.relationship} • {g.phone}
                        </div>
                      </div>
                    </label>
                  );
                })}
              </div>
            </div>
          )}

          <div className="flex justify-end gap-3 pt-4 border-t border-white/10">
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                setIsCreateModalOpen(false);
                setIsEditModalOpen(false);
              }}
            >
              Cancel
            </Button>
            <Button
              id="btn-submit-family"
              type="submit"
              variant="primary"
              disabled={formSubmitting}
            >
              {formSubmitting ? 'Saving...' : isCreateModalOpen ? 'Create Household' : 'Save Modifications'}
            </Button>
          </div>
        </form>
      </Modal>

      {/* FAMILY DOSSIER MODAL */}
      {selectedFamilyDossier && (
        <Modal
          isOpen={isDossierOpen}
          onClose={() => {
            setIsDossierOpen(false);
            setSelectedFamilyDossier(null);
          }}
          title={`Household Dossier: ${selectedFamilyDossier.familyName}`}
          description={`Code: ${selectedFamilyDossier.familyCode || 'N/A'} • Multi-Guardian Household &amp; Sibling Roster`}
          size="lg"
        >
          <div className="space-y-5 text-xs">
            {/* Header banner */}
            <div className="p-4 rounded-2xl bg-white border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-2xs">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-blue-600 border border-blue-700 text-white font-bold flex items-center justify-center text-lg shadow-xs">
                  <Home className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900">{selectedFamilyDossier.familyName}</h3>
                  <div className="text-slate-500 text-xs flex items-center gap-1.5 mt-0.5">
                    <MapPin className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                    <span>{selectedFamilyDossier.address || 'Address not listed'}</span>
                  </div>
                </div>
              </div>

              <div className="text-right space-y-1">
                <Badge variant={selectedFamilyDossier.status === 'active' ? 'success' : 'secondary'} dot>
                  {(selectedFamilyDossier.status || 'ACTIVE').toUpperCase()}
                </Badge>
                <div className="text-[11px] text-slate-400">
                  Billing: <span className="text-white font-medium">{selectedFamilyDossier.billingPreference || 'Primary'}</span>
                </div>
              </div>
            </div>

            {/* Co-Guardians Section */}
            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-indigo-400 uppercase tracking-wider flex items-center gap-1.5">
                  <HeartHandshake className="w-3.5 h-3.5" />
                  <span>Household Co-Guardians ({selectedFamilyDossier.guardians?.length || 0})</span>
                </h4>
                <Button
                  size="xs"
                  variant="outline"
                  onClick={() => setIsAddGuardianModalOpen(true)}
                >
                  <UserPlus className="w-3 h-3 mr-1" />
                  Add Guardian to Family
                </Button>
              </div>

              {((selectedFamilyDossier?.guardians?.length || 0) > 0) ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {(selectedFamilyDossier?.guardians || []).map((g: any) => (
                    <div
                      key={g.id}
                      className="p-3 rounded-xl bg-white/5 border border-white/10 flex items-center justify-between gap-2"
                    >
                      <div>
                        <div className="font-bold text-white flex items-center gap-2">
                          <span>{g.name}</span>
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300 font-medium">
                            {g.relationship}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-400 font-mono mt-0.5">{g.phone}</div>
                        <div className="text-[10px] text-slate-500">{g.occupation || 'Guardian'}</div>
                      </div>

                      <Button
                        size="xs"
                        variant="danger"
                        onClick={() => handleRemoveMember('guardian', g.id)}
                        title="Remove guardian from this family unit"
                      >
                        Remove
                      </Button>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-slate-500 italic py-2">No guardians attached to this family unit.</p>
              )}
            </div>

            {/* Enrolled Sibling Scholars Section */}
            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                  <GraduationCap className="w-3.5 h-3.5" />
                  <span>Enrolled Scholars &amp; Siblings ({selectedFamilyDossier.students?.length || 0})</span>
                </h4>
                <Button
                  size="xs"
                  variant="outline"
                  onClick={() => setIsAddStudentModalOpen(true)}
                >
                  <Plus className="w-3 h-3 mr-1" />
                  Add Scholar to Family
                </Button>
              </div>

              {((selectedFamilyDossier?.students?.length || 0) > 0) ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {(selectedFamilyDossier?.students || []).map((s: any) => (
                    <div
                      key={s.id}
                      className="p-3 rounded-xl bg-white/5 border border-white/10 flex items-center justify-between gap-2"
                    >
                      <div>
                        <div className="font-bold text-white">{s.name}</div>
                        <div className="text-[11px] text-slate-400">
                          {s.className} ({s.sectionName}) • Adm: {s.admissionNumber}
                        </div>
                        <div className="text-[10px] text-emerald-400 mt-0.5">Roll #{s.rollNumber}</div>
                      </div>

                      <Button
                        size="xs"
                        variant="danger"
                        onClick={() => handleRemoveMember('student', s.id)}
                        title="Remove scholar from this family unit"
                      >
                        Remove
                      </Button>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-slate-500 italic py-2">No scholar siblings currently grouped in this family unit.</p>
              )}
            </div>

            <div className="flex justify-between items-center pt-2 border-t border-white/10">
              <Button
                size="sm"
                variant="secondary"
                onClick={() => {
                  setIsDossierOpen(false);
                  handleOpenEdit(selectedFamilyDossier);
                }}
              >
                <Edit2 className="w-3.5 h-3.5 mr-1.5" />
                Edit Household
              </Button>

              <Button
                size="sm"
                variant="outline"
                onClick={() => {
                  setIsDossierOpen(false);
                  setSelectedFamilyDossier(null);
                }}
              >
                Close Dossier
              </Button>
            </div>
          </div>
        </Modal>
      )}

      {/* ADD GUARDIAN TO FAMILY MODAL */}
      {isAddGuardianModalOpen && selectedFamilyDossier && (
        <Modal
          isOpen={isAddGuardianModalOpen}
          onClose={() => setIsAddGuardianModalOpen(false)}
          title={`Attach Guardian to ${selectedFamilyDossier.familyName}`}
          description="Select an existing guardian from the directory to add to this family household."
          size="md"
        >
          <div className="space-y-4 text-xs">
            <Select
              id="select-guardian-to-fam"
              label="Select Guardian"
              options={[
                { value: '', label: '-- Choose a guardian --' },
                ...guardians
                  .filter((g) => !selectedFamilyDossier.guardianIds?.includes(g.id))
                  .map((g) => ({
                    value: g.id,
                    label: `${g.name} (${g.relationship}) • ${g.phone}`
                  }))
              ]}
              value={selectedGuardianToAdd}
              onChange={(e) => setSelectedGuardianToAdd(e.target.value)}
            />

            <div className="flex justify-end gap-3 pt-3 border-t border-white/10">
              <Button variant="outline" size="sm" onClick={() => setIsAddGuardianModalOpen(false)}>
                Cancel
              </Button>
              <Button
                id="btn-confirm-add-guard-fam"
                variant="primary"
                size="sm"
                disabled={!selectedGuardianToAdd}
                onClick={handleAddGuardianToFamily}
              >
                Add Guardian
              </Button>
            </div>
          </div>
        </Modal>
      )}

      {/* ADD STUDENT TO FAMILY MODAL */}
      {isAddStudentModalOpen && selectedFamilyDossier && (
        <Modal
          isOpen={isAddStudentModalOpen}
          onClose={() => setIsAddStudentModalOpen(false)}
          title={`Attach Scholar Sibling to ${selectedFamilyDossier.familyName}`}
          description="Select an enrolled scholar to add to this family sibling group."
          size="md"
        >
          <div className="space-y-4 text-xs">
            <Select
              id="select-student-to-fam"
              label="Select Enrolled Scholar"
              options={[
                { value: '', label: '-- Choose a scholar --' },
                ...students
                  .filter((s) => !selectedFamilyDossier.studentIds?.includes(s.id))
                  .map((s) => ({
                    value: s.id,
                    label: `${s.firstName} ${s.lastName} (${s.className}) • Adm: ${s.admissionNumber}`
                  }))
              ]}
              value={selectedStudentToAdd}
              onChange={(e) => setSelectedStudentToAdd(e.target.value)}
            />

            <div className="flex justify-end gap-3 pt-3 border-t border-white/10">
              <Button variant="outline" size="sm" onClick={() => setIsAddStudentModalOpen(false)}>
                Cancel
              </Button>
              <Button
                id="btn-confirm-add-student-fam"
                variant="primary"
                size="sm"
                disabled={!selectedStudentToAdd}
                onClick={handleAddStudentToFamily}
              >
                Add Scholar
              </Button>
            </div>
          </div>
        </Modal>
      )}

      {/* DELETE FAMILY CONFIRMATION */}
      {familyToDelete && (
        <ConfirmDialog
          isOpen={Boolean(familyToDelete)}
          title={`Delete Household — ${familyToDelete.familyName}`}
          message={`Are you sure you want to delete this family household? Member guardians and students will not be deleted; their family link will simply be unassigned.`}
          confirmLabel="Permanently Delete Household"
          variant="danger"
          onConfirm={handleDeleteFamily}
          onCancel={() => setFamilyToDelete(null)}
        />
      )}
    </div>
  );
};
