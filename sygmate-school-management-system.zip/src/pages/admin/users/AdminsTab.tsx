import React from 'react';
import {
  ShieldCheck,
  KeyRound,
  Lock,
  Server,
  UserCheck,
  CheckCircle2,
  AlertTriangle,
  Fingerprint
} from 'lucide-react';
import { Badge } from '../../../components/ui/Badge.js';
import { Button } from '../../../components/ui/Button.js';
import { Table, Column } from '../../../components/ui/Table.js';

export const AdminsTab: React.FC = () => {
  const adminUsers = [
    {
      id: 'usr-admin-1',
      name: 'Dr. Elena Vance',
      email: 'admin@sygmate.edu',
      role: 'SUPER_ADMIN',
      designation: 'Institutional Director & Chief Administrator',
      status: 'active',
      mfaStatus: 'Hardware Token Verified',
      lastLogin: '2026-08-14 08:30 UTC',
      clearance: 'ROOT_AUTHORITY (Level 0)'
    }
  ];

  const columns: Column<any>[] = [
    {
      header: 'Administrator',
      accessor: (row) => (
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-rose-500/20 to-amber-500/20 border border-rose-500/30 text-rose-300 font-bold flex items-center justify-center text-xs shadow-xs">
            EV
          </div>
          <div>
            <div className="font-semibold text-white flex items-center gap-2">
              <span>{row.name}</span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 font-bold font-mono">
                {row.role}
              </span>
            </div>
            <div className="text-[11px] text-slate-400 font-mono mt-0.5">{row.email}</div>
          </div>
        </div>
      )
    },
    {
      header: 'Designation & Governance',
      accessor: (row) => (
        <div>
          <div className="text-xs font-semibold text-slate-200">{row.designation}</div>
          <div className="text-[11px] text-slate-400 mt-0.5">Sygmate Institutional System OS</div>
        </div>
      )
    },
    {
      header: 'Security Clearance',
      accessor: (row) => (
        <div className="space-y-1">
          <div className="text-xs font-bold text-rose-400 flex items-center gap-1.5">
            <Lock className="w-3.5 h-3.5" />
            <span>{row.clearance}</span>
          </div>
          <div className="text-[10px] text-slate-400 flex items-center gap-1">
            <Fingerprint className="w-3 h-3 text-emerald-400" />
            <span>{row.mfaStatus}</span>
          </div>
        </div>
      )
    },
    {
      header: 'Account Status',
      accessor: (row) => (
        <Badge variant="success" dot>
          ACTIVE ROOT
        </Badge>
      )
    }
  ];

  return (
    <div className="space-y-6">
      {/* Root Authority Banner */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-rose-950/40 via-purple-950/20 to-slate-900 border border-rose-500/20 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-rose-500/20 border border-rose-500/30 text-rose-300 flex items-center justify-center shrink-0">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white">System Super Administrator Realm</h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Super Administrators possess unrestricted read, write, audit, and cryptographic oversight across all schools, academic sessions, faculty profiles, and scholar records.
            </p>
          </div>
        </div>

        <div className="flex gap-2">
          <span className="px-3 py-1.5 rounded-xl bg-white/5 border border-white/10 text-xs font-semibold text-slate-200">
            RBAC Level: 0 (Unconstrained)
          </span>
        </div>
      </div>

      {/* Admin Table */}
      <Table columns={columns} data={adminUsers} keyExtractor={(a) => a.id} />

      {/* Security Policies Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2">
          <div className="flex items-center gap-2 text-indigo-400 text-xs font-bold uppercase">
            <KeyRound className="w-4 h-4" />
            <span>Cryptographic Session Rules</span>
          </div>
          <p className="text-xs text-slate-400 leading-relaxed">
            All user sessions are secured via salted SHA-256 tokens. Token expiration and re-authentication enforce zero unauthorized lateral movement.
          </p>
        </div>

        <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2">
          <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold uppercase">
            <CheckCircle2 className="w-4 h-4" />
            <span>Immutable Audit Logging</span>
          </div>
          <p className="text-xs text-slate-400 leading-relaxed">
            Every create, update, delete, and link operation executed on faculty, students, or guardians is permanently recorded in the system audit stream.
          </p>
        </div>

        <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2">
          <div className="flex items-center gap-2 text-amber-400 text-xs font-bold uppercase">
            <Server className="w-4 h-4" />
            <span>1:N Guardian Relationship</span>
          </div>
          <p className="text-xs text-slate-400 leading-relaxed">
            Guardian households support multi-student family groups, allowing seamless household synchronizations and contact consistency across siblings.
          </p>
        </div>
      </div>
    </div>
  );
};
