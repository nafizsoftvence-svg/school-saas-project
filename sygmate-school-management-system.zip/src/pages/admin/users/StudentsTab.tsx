import React, { useState, useMemo } from 'react';
import {
  Users,
  Plus,
  Search,
  Edit2,
  Trash2,
  Mail,
  Phone,
  Calendar,
  Layers,
  BookOpen,
  UserCheck,
  UserX,
  AlertCircle,
  FileText,
  Shield,
  HeartHandshake,
  CheckCircle2,
  GraduationCap,
  Sparkles,
  ExternalLink
} from 'lucide-react';
import { Table, Column } from '../../../components/ui/Table.js';
import { Badge } from '../../../components/ui/Badge.js';
import { Button } from '../../../components/ui/Button.js';
import { Input } from '../../../components/ui/Input.js';
import { Select } from '../../../components/ui/Select.js';
import { Modal } from '../../../components/ui/Modal.js';
import { Alert } from '../../../components/ui/Alert.js';
import { ConfirmDialog } from '../../../components/ui/ConfirmDialog.js';
import { EmptyState } from '../../../components/ui/EmptyState.js';
import { api } from '../../../services/api.js';
import { Student, SchoolClass, Section, AcademicSession, Guardian, Subject } from '../../../types/index.js';
import { StudentMasterProfile } from '../../../components/students/StudentMasterProfile.js';

interface StudentsTabProps {
  students: Student[];
  classes: SchoolClass[];
  sections: Section[];
  sessions: AcademicSession[];
  guardians: Guardian[];
  subjects: Subject[];
  onRefresh: () => void;
  onSelectGuardian?: (guardianId: string) => void;
}

export const StudentsTab: React.FC<StudentsTabProps> = ({
  students = [],
  classes = [],
  sections = [],
  sessions = [],
  guardians = [],
  subjects = [],
  onRefresh,
  onSelectGuardian
}) => {
  // Filtering
  const [search, setSearch] = useState('');
  const [sessionFilter, setSessionFilter] = useState('ALL');
  const [classFilter, setClassFilter] = useState('ALL');
  const [sectionFilter, setSectionFilter] = useState('ALL');
  const [statusFilter, setStatusFilter] = useState('ALL');

  // Modals
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isDossierOpen, setIsDossierOpen] = useState(false);
  const [studentToEdit, setStudentToEdit] = useState<Student | null>(null);
  const [selectedStudentDossier, setSelectedStudentDossier] = useState<any | null>(null);
  const [studentToDelete, setStudentToDelete] = useState<Student | null>(null);

  // Guardian Mode in Form: 'existing' | 'new'
  const [guardianMode, setGuardianMode] = useState<'existing' | 'new'>('existing');

  // Form State
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    admissionNumber: '',
    rollNumber: '',
    email: '',
    phone: '',
    dateOfBirth: '2010-06-15',
    gender: 'male',
    bloodGroup: 'O+',
    address: '',
    academicSessionId: '',
    classId: '',
    sectionId: '',
    admissionDate: new Date().toISOString().split('T')[0],
    enrollmentDate: new Date().toISOString().split('T')[0],
    enrollmentStatus: 'active',
    status: 'active',
    // Guardian
    guardianId: '',
    guardianName: '',
    guardianRelation: 'Father',
    guardianPhone: '',
    guardianEmail: '',
    guardianAddress: '',
    guardianOccupation: '',
    initialPassword: 'Student@123'
  });

  const [formError, setFormError] = useState<string | null>(null);
  const [formSubmitting, setFormSubmitting] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);

  // Filter sections dynamically when a class is chosen in the filter or form
  const availableSectionsForFilter = useMemo(() => {
    if (classFilter === 'ALL') return sections;
    return sections.filter((s) => s.classId === classFilter);
  }, [sections, classFilter]);

  const availableSectionsForForm = useMemo(() => {
    if (!formData.classId) return [];
    return sections.filter((s) => s.classId === formData.classId);
  }, [sections, formData.classId]);

  const resetForm = () => {
    const defaultSession = (sessions || []).find((s) => s.isActive) || sessions?.[0];
    const defaultClass = classes?.[0];
    const defaultSec = (sections || []).find((s) => s.classId === defaultClass?.id) || sections?.[0];

    setFormData({
      firstName: '',
      lastName: '',
      admissionNumber: `ADM-2026-${Math.floor(1000 + Math.random() * 9000)}`,
      rollNumber: `R-${Math.floor(10 + Math.random() * 90)}`,
      email: '',
      phone: '',
      dateOfBirth: '2010-06-15',
      gender: 'male',
      bloodGroup: 'O+',
      address: '',
      academicSessionId: defaultSession?.id || '',
      classId: defaultClass?.id || '',
      sectionId: defaultSec?.id || '',
      admissionDate: new Date().toISOString().split('T')[0],
      enrollmentDate: new Date().toISOString().split('T')[0],
      enrollmentStatus: 'active',
      status: 'active',
      guardianId: guardians?.[0]?.id || '',
      guardianName: '',
      guardianRelation: 'Father',
      guardianPhone: '',
      guardianEmail: '',
      guardianAddress: '',
      guardianOccupation: '',
      initialPassword: 'Student@123'
    });
    setGuardianMode((guardians || []).length > 0 ? 'existing' : 'new');
    setFormError(null);
  };

  const handleOpenAdd = () => {
    resetForm();
    setIsAddModalOpen(true);
  };

  const handleOpenEdit = (student: Student) => {
    setStudentToEdit(student);
    setFormData({
      firstName: student.firstName || '',
      lastName: student.lastName || '',
      admissionNumber: student.admissionNumber || '',
      rollNumber: student.rollNumber || '',
      email: student.email || '',
      phone: student.phone || '',
      dateOfBirth: student.dateOfBirth || '2010-06-15',
      gender: student.gender || 'male',
      bloodGroup: student.bloodGroup || 'O+',
      address: student.address || '',
      academicSessionId: student.academicSessionId || sessions?.[0]?.id || '',
      classId: student.classId || classes?.[0]?.id || '',
      sectionId: student.sectionId || sections?.[0]?.id || '',
      admissionDate: student.admissionDate || new Date().toISOString().split('T')[0],
      enrollmentDate: student.enrollmentDate || new Date().toISOString().split('T')[0],
      enrollmentStatus: student.enrollmentStatus || 'active',
      status: student.status || 'active',
      guardianId: student.guardianId || '',
      guardianName: student.guardianName || '',
      guardianRelation: student.guardianRelation || 'Guardian',
      guardianPhone: student.guardianPhone || '',
      guardianEmail: student.guardianEmail || '',
      guardianAddress: student.guardianAddress || '',
      guardianOccupation: student.guardianOccupation || '',
      initialPassword: ''
    });
    setGuardianMode(student.guardianId ? 'existing' : 'new');
    setFormError(null);
    setIsEditModalOpen(true);
  };

  const handleOpenDossier = async (student: Student) => {
    try {
      const res = await api.users.getStudent(student.id);
      if (res.success && res.data) {
        setSelectedStudentDossier(res.data);
      } else {
        setSelectedStudentDossier(student);
      }
      setIsDossierOpen(true);
    } catch (err) {
      setSelectedStudentDossier(student);
      setIsDossierOpen(true);
    }
  };

  // Submit Add Student
  const handleCreateStudent = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    setFormSubmitting(true);

    try {
      const payload = {
        ...formData,
        guardianId: guardianMode === 'existing' ? formData.guardianId : undefined
      };

      const res = await api.users.createStudent(payload);
      if (res.success) {
        setIsAddModalOpen(false);
        onRefresh();
      } else {
        setFormError(res.error || 'Failed to enroll student.');
      }
    } catch (err: any) {
      setFormError(err.message || 'An unexpected error occurred.');
    } finally {
      setFormSubmitting(false);
    }
  };

  // Submit Edit Student
  const handleUpdateStudent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!studentToEdit) return;
    setFormError(null);
    setFormSubmitting(true);

    try {
      const payload = {
        ...formData,
        guardianId: guardianMode === 'existing' ? formData.guardianId : undefined
      };

      const res = await api.users.updateStudent(studentToEdit.id, payload);
      if (res.success) {
        setIsEditModalOpen(false);
        setStudentToEdit(null);
        onRefresh();
      } else {
        setFormError(res.error || 'Failed to update student.');
      }
    } catch (err: any) {
      setFormError(err.message || 'An unexpected error occurred.');
    } finally {
      setFormSubmitting(false);
    }
  };

  // Quick Status Toggle
  const handleStatusChange = async (student: Student, newStatus: string) => {
    try {
      const res = await api.users.updateStudentStatus(student.id, newStatus);
      if (res.success) {
        onRefresh();
      } else {
        setActionError(res.error || 'Failed to change student status.');
      }
    } catch (err: any) {
      setActionError(err.message);
    }
  };

  // Delete Student
  const handleDeleteStudent = async () => {
    if (!studentToDelete) return;
    try {
      const res = await api.users.deleteStudent(studentToDelete.id);
      if (res.success) {
        setStudentToDelete(null);
        onRefresh();
      } else {
        setActionError(res.error || 'Failed to delete student.');
        setStudentToDelete(null);
      }
    } catch (err: any) {
      setActionError(err.message);
      setStudentToDelete(null);
    }
  };

  // Filtered Students
  const filteredStudents = students.filter((s) => {
    const q = (search || '').toLowerCase().trim();
    const fullName = `${s.firstName || ''} ${s.lastName || ''}`.toLowerCase();
    const matchesSearch =
      !q ||
      fullName.includes(q) ||
      (s.admissionNumber ? s.admissionNumber.toLowerCase().includes(q) : false) ||
      (s.rollNumber ? s.rollNumber.toLowerCase().includes(q) : false) ||
      (s.guardianName ? s.guardianName.toLowerCase().includes(q) : false) ||
      (s.email ? s.email.toLowerCase().includes(q) : false);

    const matchesSession = sessionFilter === 'ALL' || s.academicSessionId === sessionFilter;
    const matchesClass = classFilter === 'ALL' || s.classId === classFilter;
    const matchesSection = sectionFilter === 'ALL' || s.sectionId === sectionFilter;
    const matchesStatus = statusFilter === 'ALL' || (s.status || '').toLowerCase() === (statusFilter || '').toLowerCase();

    return matchesSearch && matchesSession && matchesClass && matchesSection && matchesStatus;
  });

  const columns: Column<Student>[] = [
    {
      header: 'Enrolled Scholar',
      accessor: (row) => (
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500/20 to-teal-500/20 border border-emerald-500/30 text-emerald-300 font-bold flex items-center justify-center text-xs shadow-xs">
            {row.firstName?.[0] || 'S'}
            {row.lastName?.[0] || 'C'}
          </div>
          <div>
            <div className="font-semibold text-white flex items-center gap-2">
              <span>{row.firstName} {row.lastName}</span>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-mono">
                {row.admissionNumber}
              </span>
            </div>
            <div className="text-[11px] text-slate-400 font-mono flex items-center gap-1.5 mt-0.5">
              <span>Roll #{row.rollNumber || '—'}</span>
              <span className="text-slate-600">•</span>
              <span>{row.email || 'student@sygmate.edu'}</span>
            </div>
          </div>
        </div>
      )
    },
    {
      header: 'Class & Section',
      accessor: (row) => {
        const cls = (classes || []).find((c) => c?.id === row.classId);
        const sec = (sections || []).find((s) => s?.id === row.sectionId);
        return (
          <div>
            <div className="text-xs font-semibold text-slate-200 flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-emerald-400" />
              <span>{cls ? cls.name : row.className || 'Class'}</span>
              <span className="text-slate-400 font-normal">({sec ? sec.name : row.sectionName || 'A'})</span>
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">{row.academicSessionName || 'Current Session'}</div>
          </div>
        );
      }
    },
    {
      header: 'Guardian & Contact',
      accessor: (row) => (
        <div className="text-xs space-y-0.5">
          <div className="text-slate-200 font-medium flex items-center gap-1.5">
            <HeartHandshake className="w-3.5 h-3.5 text-indigo-400" />
            <span>{row.guardianName || 'Guardian Record'}</span>
            <span className="text-[10px] text-slate-500">({row.guardianRelation || 'Parent'})</span>
          </div>
          <div className="text-[11px] text-slate-400 font-mono flex items-center gap-1">
            <Phone className="w-3 h-3 text-slate-500" />
            <span>{row.guardianPhone || '—'}</span>
          </div>
        </div>
      )
    },
    {
      header: 'Academic Status',
      accessor: (row) => {
        const st = (row.status || 'active').toLowerCase();
        let variant: 'success' | 'warning' | 'destructive' | 'secondary' = 'success';
        if (st === 'graduated') variant = 'secondary';
        else if (st === 'transferred') variant = 'warning';
        else if (st === 'suspended' || st === 'inactive') variant = 'destructive';

        return (
          <div className="space-y-1">
            <Badge variant={variant} dot>
              {st.toUpperCase()}
            </Badge>
            <div className="flex gap-1 pt-0.5">
              {st !== 'active' && (
                <button
                  type="button"
                  onClick={() => handleStatusChange(row, 'active')}
                  className="text-[10px] text-emerald-400 hover:underline"
                >
                  Activate
                </button>
              )}
              {st === 'active' && (
                <button
                  type="button"
                  onClick={() => handleStatusChange(row, 'transferred')}
                  className="text-[10px] text-amber-400 hover:underline"
                >
                  Mark Transferred
                </button>
              )}
            </div>
          </div>
        );
      }
    },
    {
      header: 'Actions',
      accessor: (row) => (
        <div className="flex items-center gap-1.5">
          <Button
            id={`btn-view-student-${row.id}`}
            size="xs"
            variant="outline"
            onClick={() => handleOpenDossier(row)}
            title="View comprehensive student profile dossier"
          >
            Profile Dossier
          </Button>
          <Button
            id={`btn-edit-student-${row.id}`}
            size="xs"
            variant="secondary"
            onClick={() => handleOpenEdit(row)}
            title="Edit student details"
          >
            <Edit2 className="w-3.5 h-3.5" />
          </Button>
          <Button
            id={`btn-delete-student-${row.id}`}
            size="xs"
            variant="danger"
            onClick={() => setStudentToDelete(row)}
            title="Delete student"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </Button>
        </div>
      )
    }
  ];

  return (
    <div className="space-y-6">
      {actionError && (
        <Alert
          variant="destructive"
          title="Operation Alert"
          message={actionError}
          onClose={() => setActionError(null)}
        />
      )}

      {/* Control Toolbar */}
      <div className="flex flex-col xl:flex-row items-stretch xl:items-center justify-between gap-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-3 flex-1">
          <div className="sm:col-span-2 md:col-span-1">
            <Input
              id="search-students-input"
              placeholder="Search by student, ID, roll #, guardian..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              leftIcon={<Search className="w-4 h-4" />}
            />
          </div>

          <div>
            <Select
              id="filter-student-session"
              options={[
                { value: 'ALL', label: 'All Sessions' },
                ...sessions.map((s) => ({ value: s.id, label: s.sessionName }))
              ]}
              value={sessionFilter}
              onChange={(e) => setSessionFilter(e.target.value)}
            />
          </div>

          <div>
            <Select
              id="filter-student-class"
              options={[
                { value: 'ALL', label: 'All Classes' },
                ...classes.map((c) => ({ value: c.id, label: c.name }))
              ]}
              value={classFilter}
              onChange={(e) => {
                setClassFilter(e.target.value);
                setSectionFilter('ALL');
              }}
            />
          </div>

          <div>
            <Select
              id="filter-student-section"
              options={[
                { value: 'ALL', label: 'All Sections' },
                ...availableSectionsForFilter.map((s) => ({ value: s.id, label: s.name }))
              ]}
              value={sectionFilter}
              onChange={(e) => setSectionFilter(e.target.value)}
            />
          </div>

          <div>
            <Select
              id="filter-student-status"
              options={[
                { value: 'ALL', label: 'All Statuses' },
                { value: 'active', label: 'Active Only' },
                { value: 'graduated', label: 'Graduated' },
                { value: 'transferred', label: 'Transferred' },
                { value: 'suspended', label: 'Suspended' }
              ]}
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
            />
          </div>
        </div>

        <Button
          id="btn-add-student"
          variant="primary"
          onClick={handleOpenAdd}
          className="gap-2 shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Enroll New Student</span>
        </Button>
      </div>

      {/* Table */}
      {filteredStudents.length > 0 ? (
        <Table columns={columns} data={filteredStudents} keyExtractor={(s) => s.id} />
      ) : (
        <EmptyState
          icon={<Users className="w-10 h-10 text-emerald-400" />}
          title="No Students Found"
          description={
            search || classFilter !== 'ALL' || sessionFilter !== 'ALL' || statusFilter !== 'ALL'
              ? 'No enrolled scholars match your current search and academic filters.'
              : 'Start by enrolling students and assigning them to academic grades and parent guardians.'
          }
          action={
            <Button size="sm" variant="primary" onClick={handleOpenAdd}>
              <Plus className="w-4 h-4 mr-1.5" />
              Enroll Student
            </Button>
          }
        />
      )}

      {/* ADD / EDIT MODAL */}
      <Modal
        isOpen={isAddModalOpen || isEditModalOpen}
        onClose={() => {
          setIsAddModalOpen(false);
          setIsEditModalOpen(false);
          setStudentToEdit(null);
        }}
        title={isAddModalOpen ? 'Enroll New Student' : `Edit Student — ${studentToEdit?.firstName} ${studentToEdit?.lastName}`}
        description="Configure scholar identity, academic grade allocation, and parent guardian relationships."
        size="lg"
      >
        <form onSubmit={isAddModalOpen ? handleCreateStudent : handleUpdateStudent} className="space-y-5">
          {formError && (
            <Alert variant="destructive" message={formError} onClose={() => setFormError(null)} />
          )}

          {/* 1. Student Identity */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-emerald-400 uppercase tracking-wider">
              1. Student Identity &amp; Bio Data
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
              <Input
                id="stu-firstname"
                label="First Name *"
                required
                value={formData.firstName}
                onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                placeholder="e.g. Leo"
              />
              <Input
                id="stu-lastname"
                label="Last Name *"
                required
                value={formData.lastName}
                onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                placeholder="e.g. Rivera"
              />
              <Input
                id="stu-admnumber"
                label="Admission ID *"
                required
                value={formData.admissionNumber}
                onChange={(e) => setFormData({ ...formData, admissionNumber: e.target.value })}
                placeholder="ADM-2026-XXXX"
              />
              <Input
                id="stu-rollnumber"
                label="Roll Number"
                value={formData.rollNumber}
                onChange={(e) => setFormData({ ...formData, rollNumber: e.target.value })}
                placeholder="e.g. G10-A-01"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
              <Input
                id="stu-dob"
                type="date"
                label="Date of Birth"
                value={formData.dateOfBirth}
                onChange={(e) => setFormData({ ...formData, dateOfBirth: e.target.value })}
              />
              <Select
                id="stu-gender"
                label="Gender"
                options={[
                  { value: 'male', label: 'Male' },
                  { value: 'female', label: 'Female' },
                  { value: 'other', label: 'Other' }
                ]}
                value={formData.gender}
                onChange={(e) => setFormData({ ...formData, gender: e.target.value })}
              />
              <Select
                id="stu-bloodgroup"
                label="Blood Group"
                options={[
                  { value: 'O+', label: 'O+' },
                  { value: 'O-', label: 'O-' },
                  { value: 'A+', label: 'A+' },
                  { value: 'A-', label: 'A-' },
                  { value: 'B+', label: 'B+' },
                  { value: 'B-', label: 'B-' },
                  { value: 'AB+', label: 'AB+' },
                  { value: 'AB-', label: 'AB-' }
                ]}
                value={formData.bloodGroup}
                onChange={(e) => setFormData({ ...formData, bloodGroup: e.target.value })}
              />
              <Input
                id="stu-phone"
                label="Student Phone (Optional)"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                placeholder="+1 (555) 000-0000"
              />
            </div>

            <Input
              id="stu-address"
              label="Home / Residential Address"
              value={formData.address}
              onChange={(e) => setFormData({ ...formData, address: e.target.value })}
              placeholder="e.g. 12 Oak Ridge Way, Apt 3B, Boston, MA"
            />
          </div>

          {/* 2. Academic Placement */}
          <div className="space-y-3 pt-2 border-t border-white/5">
            <h4 className="text-xs font-bold text-emerald-400 uppercase tracking-wider">
              2. Academic Placement
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <Select
                id="stu-session"
                label="Academic Session *"
                options={(sessions || []).map((s) => ({ value: s.id, label: s.sessionName }))}
                value={formData.academicSessionId}
                onChange={(e) => setFormData({ ...formData, academicSessionId: e.target.value })}
              />
              <Select
                id="stu-class"
                label="Enrolled Class *"
                options={(classes || []).map((c) => ({ value: c.id, label: c.name }))}
                value={formData.classId}
                onChange={(e) => {
                  const newClassId = e.target.value;
                  const firstSec = (sections || []).find((s) => s?.classId === newClassId);
                  setFormData({
                    ...formData,
                    classId: newClassId,
                    sectionId: firstSec ? firstSec.id : ''
                  });
                }}
              />
              <Select
                id="stu-section"
                label="Enrolled Section *"
                options={
                  availableSectionsForForm.length > 0
                    ? availableSectionsForForm.map((s) => ({ value: s.id, label: s.name }))
                    : [{ value: '', label: 'No sections in this class' }]
                }
                value={formData.sectionId}
                onChange={(e) => setFormData({ ...formData, sectionId: e.target.value })}
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <Input
                id="stu-admdate"
                type="date"
                label="Admission Date"
                value={formData.admissionDate}
                onChange={(e) => setFormData({ ...formData, admissionDate: e.target.value })}
              />
              <Select
                id="stu-enrollmentstatus"
                label="Enrollment Status"
                options={[
                  { value: 'active', label: 'Active Enrolled' },
                  { value: 'probationary', label: 'Probationary' },
                  { value: 'transferred', label: 'Transferred' },
                  { value: 'graduated', label: 'Graduated' }
                ]}
                value={formData.enrollmentStatus}
                onChange={(e) => setFormData({ ...formData, enrollmentStatus: e.target.value })}
              />
              <Select
                id="stu-status"
                label="Account Status"
                options={[
                  { value: 'active', label: 'Active' },
                  { value: 'inactive', label: 'Inactive' },
                  { value: 'suspended', label: 'Suspended' }
                ]}
                value={formData.status}
                onChange={(e) => setFormData({ ...formData, status: e.target.value })}
              />
            </div>
          </div>

          {/* 3. Guardian Linking (One Guardian to Multiple Students) */}
          <div className="space-y-3 pt-2 border-t border-white/5">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                <HeartHandshake className="w-3.5 h-3.5" />
                <span>3. Parent / Guardian Association</span>
              </h4>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setGuardianMode('existing')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all ${
                    guardianMode === 'existing'
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'bg-white/5 text-slate-400 hover:bg-white/10'
                  }`}
                >
                  Link Existing Guardian
                </button>
                <button
                  type="button"
                  onClick={() => setGuardianMode('new')}
                  className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all ${
                    guardianMode === 'new'
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'bg-white/5 text-slate-400 hover:bg-white/10'
                  }`}
                >
                  Create New Guardian
                </button>
              </div>
            </div>

            {guardianMode === 'existing' ? (
              <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 space-y-3">
                <Select
                  id="stu-select-guardian"
                  label="Select Registered Guardian *"
                  options={[
                    { value: '', label: '-- Choose a guardian from directory --' },
                    ...guardians.map((g) => ({
                      value: g.id,
                      label: `${g.name} (${g.relationship}) — Tel: ${g.phone} [${g.studentIds?.length || 0} enrolled children]`
                    }))
                  ]}
                  value={formData.guardianId}
                  onChange={(e) => {
                    const selId = e.target.value;
                    const found = (guardians || []).find((g) => g?.id === selId);
                    setFormData({
                      ...formData,
                      guardianId: selId,
                      guardianName: found?.name || '',
                      guardianRelation: found?.relationship || 'Guardian',
                      guardianPhone: found?.phone || '',
                      guardianEmail: found?.email || '',
                      guardianAddress: found?.address || '',
                      guardianOccupation: found?.occupation || ''
                    });
                  }}
                  helperText="One guardian can be associated with multiple students (siblings)."
                />

                {formData.guardianId && (
                  <div className="p-3 rounded-xl bg-indigo-950/40 border border-indigo-500/20 text-xs space-y-1">
                    <div className="text-indigo-200 font-semibold">{formData.guardianName}</div>
                    <div className="text-slate-400">Relationship: {formData.guardianRelation} • Phone: {formData.guardianPhone}</div>
                    {formData.guardianAddress && <div className="text-slate-400 text-[11px]">Address: {formData.guardianAddress}</div>}
                  </div>
                )}
              </div>
            ) : (
              <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <Input
                    id="new-guard-name"
                    label="Guardian Full Name *"
                    required
                    value={formData.guardianName}
                    onChange={(e) => setFormData({ ...formData, guardianName: e.target.value })}
                    placeholder="e.g. Carlos Rivera"
                  />
                  <Select
                    id="new-guard-relation"
                    label="Relationship *"
                    options={[
                      { value: 'Father', label: 'Father' },
                      { value: 'Mother', label: 'Mother' },
                      { value: 'Legal Guardian', label: 'Legal Guardian' },
                      { value: 'Sponsor', label: 'Sponsor' },
                      { value: 'Grandparent', label: 'Grandparent' },
                      { value: 'Relative', label: 'Relative' }
                    ]}
                    value={formData.guardianRelation}
                    onChange={(e) => setFormData({ ...formData, guardianRelation: e.target.value })}
                  />
                  <Input
                    id="new-guard-phone"
                    label="Guardian Phone *"
                    required
                    value={formData.guardianPhone}
                    onChange={(e) => setFormData({ ...formData, guardianPhone: e.target.value })}
                    placeholder="+1 (555) 019-8811"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <Input
                    id="new-guard-email"
                    type="email"
                    label="Guardian Email"
                    value={formData.guardianEmail}
                    onChange={(e) => setFormData({ ...formData, guardianEmail: e.target.value })}
                    placeholder="guardian@example.com"
                  />
                  <Input
                    id="new-guard-occ"
                    label="Occupation"
                    value={formData.guardianOccupation}
                    onChange={(e) => setFormData({ ...formData, guardianOccupation: e.target.value })}
                    placeholder="e.g. Systems Engineer"
                  />
                  <Input
                    id="new-guard-addr"
                    label="Guardian Address"
                    value={formData.guardianAddress}
                    onChange={(e) => setFormData({ ...formData, guardianAddress: e.target.value })}
                    placeholder="Residential address"
                  />
                </div>
              </div>
            )}
          </div>

          {/* 4. Password Security (On Create) */}
          {isAddModalOpen && (
            <div className="space-y-3 pt-2 border-t border-white/5">
              <h4 className="text-xs font-bold text-emerald-400 uppercase tracking-wider">
                4. Student Portal Login Credentials
              </h4>
              <Input
                id="stu-initialpwd"
                label="Initial Temporary Password"
                value={formData.initialPassword}
                onChange={(e) => setFormData({ ...formData, initialPassword: e.target.value })}
                helperText="Temporary password for student portal authentication."
              />
            </div>
          )}

          <div className="flex justify-end gap-3 pt-4 border-t border-white/10">
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                setIsAddModalOpen(false);
                setIsEditModalOpen(false);
              }}
            >
              Cancel
            </Button>
            <Button
              id="btn-submit-student"
              type="submit"
              variant="primary"
              disabled={formSubmitting}
            >
              {formSubmitting
                ? 'Processing...'
                : isAddModalOpen
                ? 'Enroll Scholar'
                : 'Save Modifications'}
            </Button>
          </div>
        </form>
      </Modal>

      {/* STUDENT PROFILE DOSSIER MODAL */}
      {selectedStudentDossier && (
        <Modal
          isOpen={isDossierOpen}
          onClose={() => {
            setIsDossierOpen(false);
            setSelectedStudentDossier(null);
          }}
          title={`Student Master Dossier: ${selectedStudentDossier.firstName} ${selectedStudentDossier.lastName}`}
          description={`${selectedStudentDossier.className || 'Class'} • ${selectedStudentDossier.sectionName || 'Section'} • Roll #${selectedStudentDossier.rollNumber || '—'}`}
          size="xl"
        >
          <div className="py-2">
            <StudentMasterProfile
              studentId={selectedStudentDossier.id}
              allowEdit={true}
              isSelfService={false}
              onEdit={(student) => {
                setIsDossierOpen(false);
                handleOpenEdit(student);
              }}
              onSelectGuardian={(guardianId) => {
                setIsDossierOpen(false);
                if (onSelectGuardian) {
                  onSelectGuardian(guardianId);
                }
              }}
              onRefresh={onRefresh}
            />
          </div>
        </Modal>
      )}

      {/* DELETE CONFIRMATION DIALOG */}
      {studentToDelete && (
        <ConfirmDialog
          isOpen={Boolean(studentToDelete)}
          title={`Delete Student Record — ${studentToDelete.admissionNumber}`}
          message={`Are you sure you want to delete ${studentToDelete.firstName} ${studentToDelete.lastName}? This will revoke student portal access and safely unlink their record from parent guardian profiles.`}
          confirmLabel="Permanently Delete"
          variant="danger"
          onConfirm={handleDeleteStudent}
          onCancel={() => setStudentToDelete(null)}
        />
      )}
    </div>
  );
};
