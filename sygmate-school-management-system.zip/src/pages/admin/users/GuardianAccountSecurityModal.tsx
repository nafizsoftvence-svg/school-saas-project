import React, { useState, useEffect } from 'react';
import {
  Shield,
  ShieldCheck,
  ShieldAlert,
  KeyRound,
  Mail,
  RefreshCw,
  Copy,
  Check,
  Lock,
  Unlock,
  AlertTriangle,
  Clock,
  UserCheck,
  UserX,
  ExternalLink,
  Sparkles,
  Info
} from 'lucide-react';
import { Modal } from '../../../components/ui/Modal.js';
import { Button } from '../../../components/ui/Button.js';
import { Badge } from '../../../components/ui/Badge.js';
import { Input } from '../../../components/ui/Input.js';
import { api } from '../../../services/api.js';
import { useToast } from '../../../context/ToastContext.js';
import { Guardian, GuardianAccountInfo } from '../../../types/index.js';

interface GuardianAccountSecurityModalProps {
  isOpen: boolean;
  onClose: () => void;
  guardian: Guardian | null;
  onSuccess: () => void;
}

export const GuardianAccountSecurityModal: React.FC<GuardianAccountSecurityModalProps> = ({
  isOpen,
  onClose,
  guardian,
  onSuccess
}) => {
  const { success: toastSuccess, error: toastError, info: toastInfo } = useToast();

  const [accountInfo, setAccountInfo] = useState<GuardianAccountInfo | null>(null);
  const [loading, setLoading] = useState(false);
  const [actionLoading, setActionLoading] = useState(false);
  const [copiedLink, setCopiedLink] = useState<string | null>(null);

  // Status Change Dialog
  const [statusReason, setStatusReason] = useState('');
  const [generatedInviteUrl, setGeneratedInviteUrl] = useState<string | null>(null);
  const [generatedResetUrl, setGeneratedResetUrl] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen && guardian) {
      loadAccountData(guardian.id);
      setGeneratedInviteUrl(null);
      setGeneratedResetUrl(null);
      setStatusReason('');
    } else {
      setAccountInfo(null);
    }
  }, [isOpen, guardian]);

  const loadAccountData = async (guardianId: string) => {
    setLoading(true);
    try {
      const res = await api.users.getGuardianAccount(guardianId);
      if (res.success && res.data) {
        setAccountInfo(res.data);
      } else {
        toastError('Failed to load account', res.error || 'Could not fetch guardian account information.');
      }
    } catch (err: any) {
      toastError('Network Error', err?.message || 'Error communicating with security service.');
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedLink(label);
    toastInfo('Copied to Clipboard', `Copied ${label} link.`);
    setTimeout(() => setCopiedLink(null), 2500);
  };

  // Invite or Resend
  const handleInvite = async () => {
    if (!guardian) return;
    setActionLoading(true);
    try {
      const isResend = accountInfo?.accountStatus === 'invited';
      const res = isResend
        ? await api.users.resendGuardianInvite(guardian.id)
        : await api.users.inviteGuardian(guardian.id);

      if (res.success && res.data) {
        setGeneratedInviteUrl(res.data.activationUrl);
        toastSuccess('Invitation Dispatched', `48-hour activation link generated for ${guardian.name}`);
        loadAccountData(guardian.id);
        onSuccess();
      } else {
        toastError('Invitation Failed', res.error || 'Could not send invitation.');
      }
    } catch (err: any) {
      toastError('Error', err?.message || 'Failed to dispatch invitation.');
    } finally {
      setActionLoading(false);
    }
  };

  // Admin Reset Access
  const handleResetAccess = async () => {
    if (!guardian) return;
    setActionLoading(true);
    try {
      const res = await api.users.resetGuardianAccess(guardian.id);
      if (res.success && res.data) {
        setGeneratedResetUrl(res.data.resetUrl);
        toastSuccess('Reset Link Created', '1-hour password reset link generated successfully.');
        loadAccountData(guardian.id);
        onSuccess();
      } else {
        toastError('Reset Failed', res.error || 'Could not generate reset link.');
      }
    } catch (err: any) {
      toastError('Error', err?.message || 'Failed to create reset link.');
    } finally {
      setActionLoading(false);
    }
  };

  // Toggle Account Status
  const handleToggleStatus = async (targetStatus: 'active' | 'disabled' | 'locked' | 'suspended') => {
    if (!guardian) return;
    setActionLoading(true);
    try {
      const res = await api.users.toggleGuardianAccountStatus(guardian.id, targetStatus, statusReason);
      if (res.success) {
        toastSuccess('Status Updated', `Guardian portal access set to: ${targetStatus.toUpperCase()}`);
        setStatusReason('');
        loadAccountData(guardian.id);
        onSuccess();
      } else {
        toastError('Update Failed', res.error || 'Could not update account status.');
      }
    } catch (err: any) {
      toastError('Error', err?.message || 'Failed to toggle account status.');
    } finally {
      setActionLoading(false);
    }
  };

  if (!guardian) return null;

  const getStatusBadge = (status?: string) => {
    switch (status) {
      case 'active':
        return <Badge variant="success" dot>ACTIVE</Badge>;
      case 'invited':
        return <Badge variant="warning" dot>INVITED (PENDING)</Badge>;
      case 'locked':
        return <Badge variant="danger" dot>LOCKED</Badge>;
      case 'disabled':
        return <Badge variant="danger" dot>DISABLED</Badge>;
      case 'suspended':
        return <Badge variant="danger" dot>SUSPENDED</Badge>;
      default:
        return <Badge variant="secondary">UNPROVISIONED</Badge>;
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Parent Account &amp; Portal Security Governance"
      size="xl"
    >
      <div className="space-y-6">
        {/* Guardian Profile Header */}
        <div className="p-4 rounded-2xl bg-white/5 border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-indigo-600/30 border border-indigo-500/40 text-indigo-300 font-bold flex items-center justify-center text-base shadow-sm">
              {(guardian.name || '').split(' ').filter(Boolean).map((n) => n[0]).join('').substring(0, 2) || 'G'}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-base font-bold text-white">{guardian.name}</span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 font-medium">
                  {guardian.relationship || 'Guardian'}
                </span>
                {guardian.isPrimaryGuardian && (
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 font-bold">
                    PRIMARY
                  </span>
                )}
              </div>
              <div className="text-xs text-slate-400 mt-0.5 flex flex-wrap items-center gap-3">
                <span>{guardian.email || 'No email on record'}</span>
                <span>•</span>
                <span>{guardian.phone || 'No phone on record'}</span>
                <span>•</span>
                <span className="text-slate-300 font-mono">ID: {guardian.id}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {accountInfo ? getStatusBadge(accountInfo.accountStatus) : <Badge variant="secondary">SYNCING...</Badge>}
            <Button
              size="xs"
              variant="outline"
              onClick={() => loadAccountData(guardian.id)}
              disabled={loading}
              title="Refresh Account Data"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            </Button>
          </div>
        </div>

        {/* Account Details & Status Grid */}
        {accountInfo && (
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-white/10 space-y-1">
              <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                Portal Identifier
              </div>
              <div className="text-xs font-mono font-bold text-indigo-300 truncate">
                {accountInfo.username || '—'}
              </div>
              <div className="text-[10px] text-slate-400 truncate">
                User ID: {accountInfo.userId || 'Not Created'}
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-white/10 space-y-1">
              <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                Security Lockout State
              </div>
              <div className="text-xs font-semibold flex items-center gap-1.5">
                {accountInfo.isLocked ? (
                  <span className="text-rose-400 flex items-center gap-1">
                    <Lock className="w-3 h-3" /> Locked
                  </span>
                ) : (
                  <span className="text-emerald-400 flex items-center gap-1">
                    <Unlock className="w-3 h-3" /> Unlocked
                  </span>
                )}
              </div>
              <div className="text-[10px] text-slate-400">
                Failed Attempts: <span className="font-mono">{accountInfo.failedLoginAttempts || 0}</span>
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-white/10 space-y-1">
              <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                Session &amp; Access Log
              </div>
              <div className="text-xs text-slate-300 truncate">
                {accountInfo.lastLoginAt ? new Date(accountInfo.lastLoginAt).toLocaleString() : 'Never logged in'}
              </div>
              <div className="text-[10px] text-slate-400">
                Linked Scholars: <span className="font-mono font-bold">{accountInfo.linkedStudentsCount}</span>
              </div>
            </div>
          </div>
        )}

        {/* Section 1: Invitation Lifecycle (48h tokens) */}
        <div className="p-4 rounded-2xl bg-slate-900/40 border border-white/10 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs font-bold text-white uppercase tracking-wider">
              <Mail className="w-4 h-4 text-indigo-400" />
              <span>Portal Onboarding &amp; Activation</span>
            </div>
            <span className="text-[10px] text-slate-400 font-mono">48-Hour Cryptographic Token</span>
          </div>

          <p className="text-xs text-slate-300">
            Send or reissue an encrypted activation link allowing the parent to verify their identity, review linked children, and create a portal password.
          </p>

          <div className="flex flex-wrap items-center gap-2 pt-1">
            <Button
              id="admin-dispatch-invite-btn"
              size="sm"
              variant="primary"
              onClick={handleInvite}
              isLoading={actionLoading}
              disabled={!guardian.email}
              className="text-xs"
            >
              <KeyRound className="w-3.5 h-3.5 mr-1.5" />
              {accountInfo?.accountStatus === 'invited' ? 'Reissue Activation Invite' : 'Dispatch Activation Invite'}
            </Button>
            {!guardian.email && (
              <span className="text-xs text-amber-400 flex items-center gap-1">
                <AlertTriangle className="w-3.5 h-3.5" />
                Email address required to send invitation.
              </span>
            )}
          </div>

          {/* Generated Activation Link Display */}
          {(generatedInviteUrl || accountInfo?.activeInvitation) && (
            <div className="mt-3 p-3 rounded-xl bg-indigo-950/40 border border-indigo-500/30 space-y-1.5">
              <div className="flex items-center justify-between text-[11px] text-indigo-300 font-bold">
                <span>Active Activation Link</span>
                <span className="text-[10px] text-slate-400 font-mono">
                  Expires: {accountInfo?.activeInvitation?.expiresAt ? new Date(accountInfo.activeInvitation.expiresAt).toLocaleString() : 'in 48 hours'}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  readOnly
                  value={generatedInviteUrl || (accountInfo?.activeInvitation?.token ? `${window.location.origin}/activate?token=${accountInfo.activeInvitation.token}` : '')}
                  className="w-full px-3 py-1.5 rounded-lg bg-black/40 border border-white/10 text-xs font-mono text-slate-200 select-all"
                />
                <Button
                  size="xs"
                  variant="outline"
                  onClick={() =>
                    handleCopy(
                      generatedInviteUrl || `${window.location.origin}/activate?token=${accountInfo?.activeInvitation?.token}`,
                      'Activation'
                    )
                  }
                  className="shrink-0"
                >
                  {copiedLink === 'Activation' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </Button>
              </div>
            </div>
          )}
        </div>

        {/* Section 2: Administrative Password Reset (1h tokens) */}
        <div className="p-4 rounded-2xl bg-slate-900/40 border border-white/10 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs font-bold text-white uppercase tracking-wider">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Administrative Password Reset</span>
            </div>
            <span className="text-[10px] text-slate-400 font-mono">1-Hour Secure Token</span>
          </div>

          <p className="text-xs text-slate-300">
            Generate an expedited 1-hour password recovery token. Useful when parents cannot receive external recovery emails or request direct desk assistance.
          </p>

          <Button
            id="admin-reset-access-btn"
            size="sm"
            variant="outline"
            onClick={handleResetAccess}
            isLoading={actionLoading}
            disabled={!accountInfo?.hasAccount}
            className="text-xs border-emerald-500/30 text-emerald-300 hover:bg-emerald-500/10"
          >
            <KeyRound className="w-3.5 h-3.5 mr-1.5" />
            Generate 1-Hour Password Reset Link
          </Button>

          {/* Generated Reset Link Display */}
          {generatedResetUrl && (
            <div className="mt-3 p-3 rounded-xl bg-emerald-950/40 border border-emerald-500/30 space-y-1.5">
              <div className="flex items-center justify-between text-[11px] text-emerald-300 font-bold">
                <span>Immediate Password Reset Link (Valid 1 Hour)</span>
                <span className="text-[10px] text-slate-400 font-mono">Single-Use</span>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  readOnly
                  value={generatedResetUrl}
                  className="w-full px-3 py-1.5 rounded-lg bg-black/40 border border-white/10 text-xs font-mono text-slate-200 select-all"
                />
                <Button
                  size="xs"
                  variant="outline"
                  onClick={() => handleCopy(generatedResetUrl, 'Reset')}
                  className="shrink-0"
                >
                  {copiedLink === 'Reset' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </Button>
              </div>
            </div>
          )}
        </div>

        {/* Section 3: Status Controls & Session Invalidation */}
        <div className="p-4 rounded-2xl bg-slate-900/40 border border-white/10 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs font-bold text-white uppercase tracking-wider">
              <ShieldAlert className="w-4 h-4 text-rose-400" />
              <span>Access Status Governance &amp; Session Invalidation</span>
            </div>
          </div>

          <p className="text-xs text-slate-300">
            Modifying status to <span className="font-semibold text-rose-400">Disabled</span> or <span className="font-semibold text-rose-400">Suspended</span> immediately terminates and revokes all active parent portal sessions.
          </p>

          <div className="space-y-2">
            <Input
              id="admin-status-reason-input"
              label="Action Justification / Audit Reason (Optional)"
              placeholder="e.g. Parental custody order update or requested credential lock"
              value={statusReason}
              onChange={(e) => setStatusReason(e.target.value)}
            />

            <div className="flex flex-wrap items-center gap-2 pt-1">
              {accountInfo?.accountStatus === 'active' ? (
                <>
                  <Button
                    id="admin-disable-btn"
                    size="sm"
                    variant="danger"
                    onClick={() => handleToggleStatus('disabled')}
                    isLoading={actionLoading}
                    className="text-xs"
                  >
                    <UserX className="w-3.5 h-3.5 mr-1.5" />
                    Disable Account &amp; Revoke Sessions
                  </Button>
                  <Button
                    id="admin-suspend-btn"
                    size="sm"
                    variant="outline"
                    onClick={() => handleToggleStatus('suspended')}
                    isLoading={actionLoading}
                    className="text-xs border-amber-500/30 text-amber-300 hover:bg-amber-500/10"
                  >
                    Suspend Account
                  </Button>
                </>
              ) : (
                <Button
                  id="admin-enable-btn"
                  size="sm"
                  variant="primary"
                  onClick={() => handleToggleStatus('active')}
                  isLoading={actionLoading}
                  className="text-xs bg-emerald-600 hover:bg-emerald-500 text-white font-bold"
                >
                  <UserCheck className="w-3.5 h-3.5 mr-1.5" />
                  Activate / Restore Portal Access
                </Button>
              )}

              {accountInfo?.isLocked && (
                <Button
                  id="admin-unlock-btn"
                  size="sm"
                  variant="outline"
                  onClick={() => handleToggleStatus('active')}
                  isLoading={actionLoading}
                  className="text-xs border-indigo-500/30 text-indigo-300 hover:bg-indigo-500/10"
                >
                  <Unlock className="w-3.5 h-3.5 mr-1.5" />
                  Unlock Failed Attempts
                </Button>
              )}
            </div>
          </div>

          {/* Historical Record Preservation Notice */}
          <div className="p-3 rounded-xl bg-white/5 border border-white/10 flex items-start gap-2.5 text-xs text-slate-400">
            <Info className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
            <span>
              <strong className="text-white">Compliance Guarantee:</strong> Disabling or suspending a parent account revokes portal login privileges only. All student relationships, academic grade histories, fee records, and audit trails remain permanently preserved.
            </span>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="flex justify-end pt-2 border-t border-white/10">
          <Button variant="outline" onClick={onClose} size="sm">
            Close Panel
          </Button>
        </div>
      </div>
    </Modal>
  );
};
