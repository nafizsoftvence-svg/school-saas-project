import React, { useState, useEffect } from 'react';
import { ShieldCheck, AlertTriangle, CheckCircle2, Wrench, RefreshCw, X } from 'lucide-react';
import { Modal } from '../../../components/ui/Modal.js';
import { Button } from '../../../components/ui/Button.js';
import { Badge } from '../../../components/ui/Badge.js';
import { api } from '../../../services/api.js';

interface GuardianIntegrityModalProps {
  isOpen: boolean;
  onClose: () => void;
  onHealed?: () => void;
}

export const GuardianIntegrityModal: React.FC<GuardianIntegrityModalProps> = ({
  isOpen,
  onClose,
  onHealed
}) => {
  const [loading, setLoading] = useState(false);
  const [healing, setHealing] = useState(false);
  const [data, setData] = useState<{
    healthy: boolean;
    totalIssues: number;
    issues: string[];
    healedCount?: number;
  } | null>(null);
  const [error, setError] = useState<string | null>(null);

  const runCheck = async (autoHeal = false) => {
    if (autoHeal) setHealing(true);
    else setLoading(true);
    setError(null);

    try {
      const res = await api.users.checkGuardiansIntegrity(autoHeal);
      if (res.success && res.data) {
        setData(res.data);
        if (autoHeal && onHealed) {
          onHealed();
        }
      } else {
        setError(res.error || 'Failed to complete data integrity inspection.');
      }
    } catch (err: any) {
      setError(err.message || 'An unexpected error occurred during inspection.');
    } finally {
      setLoading(false);
      setHealing(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      runCheck(false);
    }
  }, [isOpen]);

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Parent & Family Data Integrity Diagnostics"
      description="Automated audit verifying primary guardian uniqueness, relational consistency, and orphan-free student links."
      size="lg"
    >
      <div className="space-y-5 text-xs">
        {error && (
          <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-red-300 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {loading ? (
          <div className="py-12 text-center text-slate-400 space-y-3">
            <RefreshCw className="w-6 h-6 animate-spin mx-auto text-indigo-400" />
            <p>Auditing parent-student relational database records...</p>
          </div>
        ) : data ? (
          <div className="space-y-4">
            {/* Status Summary Banner */}
            <div
              className={`p-4 rounded-2xl border flex items-center justify-between gap-4 ${
                data.healthy
                  ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                  : 'bg-amber-500/10 border-amber-500/30 text-amber-300'
              }`}
            >
              <div className="flex items-center gap-3">
                {data.healthy ? (
                  <CheckCircle2 className="w-6 h-6 text-emerald-400 shrink-0" />
                ) : (
                  <AlertTriangle className="w-6 h-6 text-amber-400 shrink-0" />
                )}
                <div>
                  <div className="font-bold text-sm">
                    {data.healthy ? 'All Relational Constraints Met' : `${data.totalIssues} Integrity Warning(s) Identified`}
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    {data.healthy
                      ? 'No orphan links, duplicate primaries, or dangling relationship records found.'
                      : 'Relational anomalies detected that can be automatically reconciled.'}
                  </div>
                </div>
              </div>

              <Badge variant={data.healthy ? 'success' : 'warning'}>
                {data.healthy ? 'HEALTHY' : `${data.totalIssues} ISSUES`}
              </Badge>
            </div>

            {data.healedCount !== undefined && data.healedCount > 0 && (
              <div className="p-3 rounded-xl bg-indigo-500/10 border border-indigo-500/30 text-indigo-200 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-indigo-400 shrink-0" />
                <span>Successfully reconciled and healed {data.healedCount} record conflict(s).</span>
              </div>
            )}

            {/* List of issues */}
            {!data.healthy && ((data?.issues?.length || 0) > 0) && (
              <div className="space-y-2">
                <div className="font-semibold text-slate-300 uppercase tracking-wider text-[10px]">
                  Detected Inconsistencies ({data?.issues?.length || 0}):
                </div>
                <div className="max-h-56 overflow-y-auto space-y-1.5 pr-1">
                  {data.issues.map((issue, idx) => (
                    <div
                      key={idx}
                      className="p-2.5 rounded-xl bg-white/5 border border-white/10 text-slate-300 text-xs flex items-start gap-2"
                    >
                      <span className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-300 font-bold flex items-center justify-center shrink-0 text-[10px]">
                        {idx + 1}
                      </span>
                      <span className="pt-0.5">{issue}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {data.healthy && (
              <div className="p-4 rounded-xl bg-white/5 border border-white/5 text-slate-400 space-y-2">
                <div className="font-semibold text-white">Integrity Verifications Passed:</div>
                <ul className="list-disc list-inside space-y-1 text-[11px] text-slate-300">
                  <li>Each enrolled scholar has strictly 0 or 1 Primary Guardian designation.</li>
                  <li>All ParentStudentRelationship records point to valid Guardian and Student IDs.</li>
                  <li>Secondary contacts and authorized pickup lists are properly mapped.</li>
                  <li>Family households and sibling groups are synchronized.</li>
                </ul>
              </div>
            )}
          </div>
        ) : null}

        {/* Footer Actions */}
        <div className="flex items-center justify-between pt-4 border-t border-white/10">
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => runCheck(false)}
            disabled={loading || healing}
          >
            <RefreshCw className={`w-3.5 h-3.5 mr-1.5 ${loading ? 'animate-spin' : ''}`} />
            Re-Run Diagnostics
          </Button>

          <div className="flex items-center gap-2">
            {data && !data.healthy && (
              <Button
                id="btn-auto-heal-guardians"
                variant="primary"
                size="sm"
                onClick={() => runCheck(true)}
                disabled={healing || loading}
              >
                <Wrench className="w-3.5 h-3.5 mr-1.5" />
                {healing ? 'Healing...' : 'Auto-Heal Discrepancies'}
              </Button>
            )}

            <Button type="button" variant="secondary" size="sm" onClick={onClose}>
              Close
            </Button>
          </div>
        </div>
      </div>
    </Modal>
  );
};
