import React, { useState, useEffect } from 'react';
import { Shield, Check, Save, User, GraduationCap, AlertCircle } from 'lucide-react';
import { Modal } from '../../../components/ui/Modal.js';
import { Button } from '../../../components/ui/Button.js';
import { Select } from '../../../components/ui/Select.js';
import { Input } from '../../../components/ui/Input.js';
import { api } from '../../../services/api.js';
import { Guardian, Student, ParentStudentRelationship } from '../../../types/index.js';

interface GuardianAuthorizationsModalProps {
  isOpen: boolean;
  onClose: () => void;
  guardian: Guardian | null;
  student: Student | null;
  onSaved: () => void;
}

export const GuardianAuthorizationsModal: React.FC<GuardianAuthorizationsModalProps> = ({
  isOpen,
  onClose,
  guardian,
  student,
  onSaved
}) => {
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [form, setForm] = useState({
    relationshipType: 'Parent',
    isPrimaryGuardian: true,
    isSecondaryGuardian: false,
    isEmergencyContact: true,
    isAuthorizedAcademic: true,
    isAuthorizedAttendance: true,
    isAuthorizedFinancial: true,
    isAuthorizedCommunication: true,
    isPickupAuthorized: true,
    notes: ''
  });

  useEffect(() => {
    if (!isOpen || !guardian || !student) return;

    // Check if relationship already exists
    const existing = (guardian.relationships || []).find((r) => r.studentId === student.id);
    if (existing) {
      setForm({
        relationshipType: existing.relationshipType || guardian.relationship || 'Parent',
        isPrimaryGuardian: !!existing.isPrimaryGuardian,
        isSecondaryGuardian: !!existing.isSecondaryGuardian,
        isEmergencyContact: existing.isEmergencyContact !== false,
        isAuthorizedAcademic: existing.isAuthorizedAcademic !== false,
        isAuthorizedAttendance: existing.isAuthorizedAttendance !== false,
        isAuthorizedFinancial: existing.isAuthorizedFinancial !== false,
        isAuthorizedCommunication: existing.isAuthorizedCommunication !== false,
        isPickupAuthorized: existing.isPickupAuthorized !== false,
        notes: existing.notes || ''
      });
    } else {
      // Default initialization
      const isCurrentlyPrimary = student.guardianId === guardian.id;
      setForm({
        relationshipType: guardian.relationship || 'Father',
        isPrimaryGuardian: isCurrentlyPrimary,
        isSecondaryGuardian: !isCurrentlyPrimary,
        isEmergencyContact: true,
        isAuthorizedAcademic: true,
        isAuthorizedAttendance: true,
        isAuthorizedFinancial: isCurrentlyPrimary,
        isAuthorizedCommunication: true,
        isPickupAuthorized: true,
        notes: ''
      });
    }
  }, [isOpen, guardian, student]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!guardian || !student) return;

    setSubmitting(true);
    setError(null);

    try {
      const res = await api.users.saveGuardianRelationship(guardian.id, {
        studentId: student.id,
        ...form
      });

      if (res.success) {
        onSaved();
        onClose();
      } else {
        setError(res.error || 'Failed to update relationship permissions.');
      }
    } catch (err: any) {
      setError(err.message || 'An error occurred while saving.');
    } finally {
      setSubmitting(false);
    }
  };

  if (!guardian || !student) return null;

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Scholar Relationship & Permissions"
      description={`Configure authorized rights for ${guardian.name} regarding scholar ${student.firstName} ${student.lastName}.`}
      size="md"
    >
      <form onSubmit={handleSubmit} className="space-y-4 text-xs">
        {error && (
          <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-red-300 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Scholar Header */}
        <div className="p-3 rounded-xl bg-white/5 border border-white/10 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-500/20 text-indigo-300 font-bold flex items-center justify-center shrink-0">
            <GraduationCap className="w-5 h-5" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="font-bold text-white text-sm truncate">
              {student.firstName} {student.lastName}
            </div>
            <div className="text-slate-400 text-[11px]">
              {student.className} • Adm: {student.admissionNumber} • Roll: {student.rollNumber}
            </div>
          </div>
        </div>

        {/* Relationship classification */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <Select
            id="rel-role-type"
            label="Specific Relationship"
            options={[
              { value: 'Father', label: 'Father' },
              { value: 'Mother', label: 'Mother' },
              { value: 'Stepfather', label: 'Stepfather' },
              { value: 'Stepmother', label: 'Stepmother' },
              { value: 'Legal Guardian', label: 'Legal Guardian' },
              { value: 'Foster Parent', label: 'Foster Parent' },
              { value: 'Grandparent', label: 'Grandparent' },
              { value: 'Uncle / Aunt', label: 'Uncle / Aunt' },
              { value: 'Sponsor', label: 'Financial Sponsor' },
              { value: 'Adult Sibling', label: 'Adult Sibling' },
              { value: 'Other', label: 'Other Relative / Custodian' }
            ]}
            value={form.relationshipType}
            onChange={(e) => setForm({ ...form, relationshipType: e.target.value })}
          />

          <div className="space-y-2 pt-5">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="radio"
                name="guardian_rank"
                checked={form.isPrimaryGuardian}
                onChange={() =>
                  setForm({
                    ...form,
                    isPrimaryGuardian: true,
                    isSecondaryGuardian: false
                  })
                }
                className="text-indigo-600 focus:ring-indigo-500"
              />
              <span className="text-white font-semibold">Primary Guardian of Record</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="radio"
                name="guardian_rank"
                checked={form.isSecondaryGuardian}
                onChange={() =>
                  setForm({
                    ...form,
                    isPrimaryGuardian: false,
                    isSecondaryGuardian: true
                  })
                }
                className="text-indigo-600 focus:ring-indigo-500"
              />
              <span className="text-slate-300">Secondary / Auxiliary Guardian</span>
            </label>
          </div>
        </div>

        {/* Authorizations toggles */}
        <div className="space-y-2 pt-2 border-t border-white/5">
          <div className="font-semibold text-indigo-400 uppercase tracking-wider text-[10px]">
            Statutory &amp; Administrative Authorizations
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            <label className="flex items-center gap-2.5 p-2 rounded-lg bg-white/5 border border-white/5 hover:bg-white/10 cursor-pointer">
              <input
                type="checkbox"
                checked={form.isEmergencyContact}
                onChange={(e) => setForm({ ...form, isEmergencyContact: e.target.checked })}
                className="rounded text-indigo-600 focus:ring-indigo-500"
              />
              <div>
                <div className="font-medium text-white">Emergency Dispatch</div>
                <div className="text-[10px] text-slate-400">Call immediately during incidents</div>
              </div>
            </label>

            <label className="flex items-center gap-2.5 p-2 rounded-lg bg-white/5 border border-white/5 hover:bg-white/10 cursor-pointer">
              <input
                type="checkbox"
                checked={form.isAuthorizedAcademic}
                onChange={(e) => setForm({ ...form, isAuthorizedAcademic: e.target.checked })}
                className="rounded text-indigo-600 focus:ring-indigo-500"
              />
              <div>
                <div className="font-medium text-white">Academic Access</div>
                <div className="text-[10px] text-slate-400">View grades, cards &amp; assignments</div>
              </div>
            </label>

            <label className="flex items-center gap-2.5 p-2 rounded-lg bg-white/5 border border-white/5 hover:bg-white/10 cursor-pointer">
              <input
                type="checkbox"
                checked={form.isAuthorizedAttendance}
                onChange={(e) => setForm({ ...form, isAuthorizedAttendance: e.target.checked })}
                className="rounded text-indigo-600 focus:ring-indigo-500"
              />
              <div>
                <div className="font-medium text-white">Attendance Alerts</div>
                <div className="text-[10px] text-slate-400">Submit leave &amp; receive absence SMS</div>
              </div>
            </label>

            <label className="flex items-center gap-2.5 p-2 rounded-lg bg-white/5 border border-white/5 hover:bg-white/10 cursor-pointer">
              <input
                type="checkbox"
                checked={form.isAuthorizedFinancial}
                onChange={(e) => setForm({ ...form, isAuthorizedFinancial: e.target.checked })}
                className="rounded text-indigo-600 focus:ring-indigo-500"
              />
              <div>
                <div className="font-medium text-white">Fee &amp; Financials</div>
                <div className="text-[10px] text-slate-400">Receive invoices and pay fees</div>
              </div>
            </label>

            <label className="flex items-center gap-2.5 p-2 rounded-lg bg-white/5 border border-white/5 hover:bg-white/10 cursor-pointer">
              <input
                type="checkbox"
                checked={form.isPickupAuthorized}
                onChange={(e) => setForm({ ...form, isPickupAuthorized: e.target.checked })}
                className="rounded text-indigo-600 focus:ring-indigo-500"
              />
              <div>
                <div className="font-medium text-white">Dismissal &amp; Pickup</div>
                <div className="text-[10px] text-slate-400">Authorized for campus release</div>
              </div>
            </label>

            <label className="flex items-center gap-2.5 p-2 rounded-lg bg-white/5 border border-white/5 hover:bg-white/10 cursor-pointer">
              <input
                type="checkbox"
                checked={form.isAuthorizedCommunication}
                onChange={(e) => setForm({ ...form, isAuthorizedCommunication: e.target.checked })}
                className="rounded text-indigo-600 focus:ring-indigo-500"
              />
              <div>
                <div className="font-medium text-white">Communications</div>
                <div className="text-[10px] text-slate-400">Circulars, newsletters &amp; broadcasts</div>
              </div>
            </label>
          </div>
        </div>

        <Input
          id="rel-notes"
          label="Custody / Relational Notes (Optional)"
          value={form.notes}
          onChange={(e) => setForm({ ...form, notes: e.target.value })}
          placeholder="e.g. Legal custody decree on file, alternate week pickup..."
        />

        <div className="flex justify-end gap-3 pt-3 border-t border-white/10">
          <Button type="button" variant="outline" size="sm" onClick={onClose}>
            Cancel
          </Button>
          <Button
            id="btn-save-guardian-rel"
            type="submit"
            variant="primary"
            size="sm"
            disabled={submitting}
          >
            <Save className="w-3.5 h-3.5 mr-1.5" />
            {submitting ? 'Saving...' : 'Save Authorizations'}
          </Button>
        </div>
      </form>
    </Modal>
  );
};
