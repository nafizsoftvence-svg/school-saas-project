import React, { useState } from 'react';
import {
  GraduationCap,
  Plus,
  Search,
  Edit2,
  Trash2,
  Mail,
  Phone,
  Calendar,
  Building,
  BookOpen,
  UserCheck,
  UserX,
  AlertCircle,
  FileText,
  Clock,
  Shield,
  Layers,
  Award,
  Filter
} from 'lucide-react';
import { Table, Column } from '../../../components/ui/Table.js';
import { Badge } from '../../../components/ui/Badge.js';
import { Button } from '../../../components/ui/Button.js';
import { Input } from '../../../components/ui/Input.js';
import { Select } from '../../../components/ui/Select.js';
import { Modal } from '../../../components/ui/Modal.js';
import { Alert } from '../../../components/ui/Alert.js';
import { ConfirmDialog } from '../../../components/ui/ConfirmDialog.js';
import { EmptyState } from '../../../components/ui/EmptyState.js';
import { api } from '../../../services/api.js';
import { Teacher, SchoolClass, Subject, Department } from '../../../types/index.js';
import { EntityDocumentChecklistModal } from '../../../components/documents/EntityDocumentChecklistModal.js';

interface TeachersTabProps {
  teachers: Teacher[];
  classes: SchoolClass[];
  subjects: Subject[];
  departments: Department[];
  onRefresh: () => void;
}

export const TeachersTab: React.FC<TeachersTabProps> = ({
  teachers = [],
  classes = [],
  subjects = [],
  departments = [],
  onRefresh
}) => {
  // Filtering & Search
  const [search, setSearch] = useState('');
  const [departmentFilter, setDepartmentFilter] = useState('ALL');
  const [statusFilter, setStatusFilter] = useState('ALL');

  // Modals
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isDossierOpen, setIsDossierOpen] = useState(false);
  const [teacherToEdit, setTeacherToEdit] = useState<Teacher | null>(null);
  const [selectedTeacherDossier, setSelectedTeacherDossier] = useState<Teacher | null>(null);
  const [selectedTeacherForDocs, setSelectedTeacherForDocs] = useState<Teacher | null>(null);
  const [teacherToDelete, setTeacherToDelete] = useState<Teacher | null>(null);

  // Form State
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    employeeCode: '',
    email: '',
    phone: '',
    emergencyContact: '',
    dateOfBirth: '1985-05-15',
    gender: 'female',
    address: '',
    departmentId: '',
    designation: 'Senior Faculty',
    qualification: 'Master of Education (M.Ed)',
    specialization: 'Core Curriculum',
    joiningDate: new Date().toISOString().split('T')[0],
    employmentStatus: 'full_time',
    status: 'active',
    assignedClassIds: [] as string[],
    assignedSubjectIds: [] as string[],
    initialPassword: 'Teacher@123'
  });

  const [formError, setFormError] = useState<string | null>(null);
  const [formSubmitting, setFormSubmitting] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);

  // Reset form
  const resetForm = () => {
    setFormData({
      firstName: '',
      lastName: '',
      employeeCode: `TCH-${Math.floor(100 + Math.random() * 900)}`,
      email: '',
      phone: '',
      emergencyContact: '',
      dateOfBirth: '1985-05-15',
      gender: 'female',
      address: '',
      departmentId: departments?.[0]?.id || '',
      designation: 'Faculty Instructor',
      qualification: 'B.Ed. / Master Degree',
      specialization: '',
      joiningDate: new Date().toISOString().split('T')[0],
      employmentStatus: 'full_time',
      status: 'active',
      assignedClassIds: [],
      assignedSubjectIds: [],
      initialPassword: 'Teacher@123'
    });
    setFormError(null);
  };

  const handleOpenAdd = () => {
    resetForm();
    setIsAddModalOpen(true);
  };

  const handleOpenEdit = (teacher: Teacher) => {
    setTeacherToEdit(teacher);
    setFormData({
      firstName: teacher.firstName || '',
      lastName: teacher.lastName || '',
      employeeCode: teacher.employeeCode || '',
      email: teacher.email || '',
      phone: teacher.phone || teacher.contactNumber || '',
      emergencyContact: teacher.emergencyContact || '',
      dateOfBirth: teacher.dateOfBirth || '1985-05-15',
      gender: teacher.gender || 'female',
      address: teacher.address || '',
      departmentId: teacher.departmentId || departments?.[0]?.id || '',
      designation: teacher.designation || 'Faculty Instructor',
      qualification: teacher.qualification || 'Master of Science',
      specialization: teacher.specialization || '',
      joiningDate: teacher.joiningDate || new Date().toISOString().split('T')[0],
      employmentStatus: teacher.employmentStatus || 'full_time',
      status: teacher.status || 'active',
      assignedClassIds: teacher.assignedClassIds || [],
      assignedSubjectIds: teacher.assignedSubjectIds || [],
      initialPassword: ''
    });
    setFormError(null);
    setIsEditModalOpen(true);
  };

  const handleOpenDossier = (teacher: Teacher) => {
    setSelectedTeacherDossier(teacher);
    setIsDossierOpen(true);
  };

  // Submit Add Teacher
  const handleCreateTeacher = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    setFormSubmitting(true);

    try {
      const res = await api.users.createTeacher(formData);
      if (res.success) {
        setIsAddModalOpen(false);
        onRefresh();
      } else {
        setFormError(res.error || 'Failed to create teacher.');
      }
    } catch (err: any) {
      setFormError(err.message || 'An unexpected error occurred.');
    } finally {
      setFormSubmitting(false);
    }
  };

  // Submit Edit Teacher
  const handleUpdateTeacher = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!teacherToEdit) return;
    setFormError(null);
    setFormSubmitting(true);

    try {
      const res = await api.users.updateTeacher(teacherToEdit.id, formData);
      if (res.success) {
        setIsEditModalOpen(false);
        setTeacherToEdit(null);
        onRefresh();
      } else {
        setFormError(res.error || 'Failed to update teacher.');
      }
    } catch (err: any) {
      setFormError(err.message || 'An unexpected error occurred.');
    } finally {
      setFormSubmitting(false);
    }
  };

  // Quick Status Toggle
  const handleStatusChange = async (teacher: Teacher, newStatus: string) => {
    try {
      const res = await api.users.updateTeacherStatus(teacher.id, newStatus);
      if (res.success) {
        onRefresh();
      } else {
        setActionError(res.error || 'Failed to change status.');
      }
    } catch (err: any) {
      setActionError(err.message);
    }
  };

  // Delete Teacher
  const handleDeleteTeacher = async () => {
    if (!teacherToDelete) return;
    try {
      const res = await api.users.deleteTeacher(teacherToDelete.id);
      if (res.success) {
        setTeacherToDelete(null);
        onRefresh();
      } else {
        setActionError(res.error || 'Failed to delete teacher.');
        setTeacherToDelete(null);
      }
    } catch (err: any) {
      setActionError(err.message);
      setTeacherToDelete(null);
    }
  };

  // Toggle Class Assignment in Form
  const toggleClassAssignment = (classId: string) => {
    setFormData((prev) => {
      const exists = prev.assignedClassIds.includes(classId);
      return {
        ...prev,
        assignedClassIds: exists
          ? prev.assignedClassIds.filter((id) => id !== classId)
          : [...prev.assignedClassIds, classId]
      };
    });
  };

  // Toggle Subject Assignment in Form
  const toggleSubjectAssignment = (subjectId: string) => {
    setFormData((prev) => {
      const exists = prev.assignedSubjectIds.includes(subjectId);
      return {
        ...prev,
        assignedSubjectIds: exists
          ? prev.assignedSubjectIds.filter((id) => id !== subjectId)
          : [...prev.assignedSubjectIds, subjectId]
      };
    });
  };

  // Filtered List
  const filteredTeachers = teachers.filter((t) => {
    const q = (search || '').toLowerCase().trim();
    const fullName = `${t.firstName || ''} ${t.lastName || ''}`.toLowerCase();
    const matchesSearch =
      !q ||
      fullName.includes(q) ||
      (t.employeeCode ? t.employeeCode.toLowerCase().includes(q) : false) ||
      (t.email ? t.email.toLowerCase().includes(q) : false) ||
      (t.department ? t.department.toLowerCase().includes(q) : false) ||
      (t.designation ? t.designation.toLowerCase().includes(q) : false);

    const matchesDept =
      departmentFilter === 'ALL' ||
      t.departmentId === departmentFilter ||
      (t.department ? t.department.toLowerCase() === (departmentFilter || '').toLowerCase() : false);

    const matchesStatus =
      statusFilter === 'ALL' || (t.status || '').toLowerCase() === (statusFilter || '').toLowerCase();

    return matchesSearch && matchesDept && matchesStatus;
  });

  const columns: Column<Teacher>[] = [
    {
      header: 'Faculty Member',
      accessor: (row) => (
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-50 border border-blue-200 text-blue-700 font-bold flex items-center justify-center text-xs shadow-2xs">
            {row.firstName?.[0] || 'T'}
            {row.lastName?.[0] || 'M'}
          </div>
          <div>
            <div className="font-semibold text-slate-900 flex items-center gap-2">
              <span>{row.firstName} {row.lastName}</span>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-100 text-slate-700 font-mono">
                {row.employeeCode}
              </span>
            </div>
            <div className="text-[11px] text-slate-400 font-mono flex items-center gap-1.5 mt-0.5">
              <Mail className="w-3 h-3 text-slate-500" />
              <span>{row.email}</span>
            </div>
          </div>
        </div>
      )
    },
    {
      header: 'Department & Role',
      accessor: (row) => (
        <div>
          <div className="text-xs font-semibold text-slate-200 flex items-center gap-1.5">
            <Building className="w-3.5 h-3.5 text-indigo-400" />
            <span>{row.departmentName || row.department || 'General Faculty'}</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">{row.designation}</div>
          <div className="text-[10px] text-slate-500 capitalize">{row.employmentStatus?.replace('_', ' ') || 'Full Time'}</div>
        </div>
      )
    },
    {
      header: 'Assigned Subjects',
      accessor: (row) => {
        const rowSubjects = subjects.filter((s) => row.assignedSubjectIds?.includes(s.id));
        return (
          <div className="flex flex-wrap gap-1 max-w-xs">
            {rowSubjects.length > 0 ? (
              rowSubjects.map((sub) => (
                <span
                  key={sub.id}
                  className="px-2 py-0.5 rounded-md bg-indigo-500/10 text-indigo-300 text-[11px] font-medium border border-indigo-500/20"
                >
                  {sub.name}
                </span>
              ))
            ) : ((row?.subjects?.length || 0) > 0) ? (
              (row?.subjects || []).map((sub) => (
                <span
                  key={sub}
                  className="px-2 py-0.5 rounded-md bg-indigo-500/10 text-indigo-300 text-[11px] font-medium border border-indigo-500/20"
                >
                  {sub}
                </span>
              ))
            ) : (
              <span className="text-[11px] text-slate-500 italic">No assigned subjects</span>
            )}
          </div>
        );
      }
    },
    {
      header: 'Contact & Joined',
      accessor: (row) => (
        <div className="text-xs space-y-0.5">
          <div className="text-slate-300 font-mono flex items-center gap-1">
            <Phone className="w-3 h-3 text-slate-500" />
            <span>{row.phone || row.contactNumber || '—'}</span>
          </div>
          <div className="text-[11px] text-slate-500 flex items-center gap-1">
            <Calendar className="w-3 h-3 text-slate-500" />
            <span>Joined: {row.joiningDate || '2024-09-01'}</span>
          </div>
        </div>
      )
    },
    {
      header: 'Account Status',
      accessor: (row) => {
        const st = (row.status || 'active').toLowerCase();
        let variant: 'success' | 'warning' | 'destructive' | 'secondary' = 'success';
        if (st === 'on_leave') variant = 'warning';
        else if (st === 'inactive' || st === 'suspended') variant = 'destructive';

        return (
          <div className="space-y-1">
            <Badge variant={variant} dot>
              {(st || 'ACTIVE').replace(/_/g, ' ').toUpperCase()}
            </Badge>
            <div className="flex gap-1 pt-0.5">
              {st !== 'active' && (
                <button
                  type="button"
                  onClick={() => handleStatusChange(row, 'active')}
                  className="text-[10px] text-emerald-400 hover:underline"
                >
                  Activate
                </button>
              )}
              {st === 'active' && (
                <button
                  type="button"
                  onClick={() => handleStatusChange(row, 'on_leave')}
                  className="text-[10px] text-amber-400 hover:underline"
                >
                  Mark Leave
                </button>
              )}
            </div>
          </div>
        );
      }
    },
    {
      header: 'Actions',
      accessor: (row) => (
        <div className="flex items-center gap-1.5">
          <Button
            id={`btn-view-teacher-${row.id}`}
            size="xs"
            variant="outline"
            onClick={() => handleOpenDossier(row)}
            title="View full faculty dossier"
          >
            Dossier
          </Button>
          <Button
            id={`btn-docs-teacher-${row.id}`}
            size="xs"
            variant="outline"
            onClick={() => setSelectedTeacherForDocs(row)}
            title="Manage Faculty Documents & Verification"
            className="text-indigo-400 border-indigo-500/30 hover:bg-indigo-500/10"
          >
            <FileText className="w-3.5 h-3.5 mr-1" />
            Docs
          </Button>
          <Button
            id={`btn-edit-teacher-${row.id}`}
            size="xs"
            variant="secondary"
            onClick={() => handleOpenEdit(row)}
            title="Edit teacher information"
          >
            <Edit2 className="w-3.5 h-3.5" />
          </Button>
          <Button
            id={`btn-delete-teacher-${row.id}`}
            size="xs"
            variant="danger"
            onClick={() => setTeacherToDelete(row)}
            title="Delete teacher"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </Button>
        </div>
      )
    }
  ];

  return (
    <div className="space-y-6">
      {actionError && (
        <Alert
          variant="destructive"
          title="Operation Alert"
          message={actionError}
          onClose={() => setActionError(null)}
        />
      )}

      {/* Control Toolbar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
        <div className="flex flex-1 flex-col sm:flex-row gap-3">
          <div className="w-full sm:w-72">
            <Input
              id="search-teachers-input"
              placeholder="Search faculty by name, ID, email..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              leftIcon={<Search className="w-4 h-4" />}
            />
          </div>

          <div className="w-full sm:w-48">
            <Select
              id="filter-teacher-department"
              options={[
                { value: 'ALL', label: 'All Departments' },
                ...departments.map((d) => ({ value: d.id, label: d.name }))
              ]}
              value={departmentFilter}
              onChange={(e) => setDepartmentFilter(e.target.value)}
            />
          </div>

          <div className="w-full sm:w-40">
            <Select
              id="filter-teacher-status"
              options={[
                { value: 'ALL', label: 'All Statuses' },
                { value: 'active', label: 'Active Only' },
                { value: 'on_leave', label: 'On Leave' },
                { value: 'inactive', label: 'Inactive' },
                { value: 'suspended', label: 'Suspended' }
              ]}
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
            />
          </div>
        </div>

        <Button
          id="btn-add-teacher"
          variant="primary"
          onClick={handleOpenAdd}
          className="gap-2 shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Add Faculty Member</span>
        </Button>
      </div>

      {/* Table */}
      {filteredTeachers.length > 0 ? (
        <Table columns={columns} data={filteredTeachers} keyExtractor={(t) => t.id} />
      ) : (
        <EmptyState
          icon={<GraduationCap className="w-10 h-10 text-indigo-400" />}
          title="No Faculty Members Found"
          description={
            search || departmentFilter !== 'ALL' || statusFilter !== 'ALL'
              ? 'No teachers match your current search and department filters.'
              : 'Start by adding faculty members and assigning them to academic departments and classes.'
          }
          action={
            <Button size="sm" variant="primary" onClick={handleOpenAdd}>
              <Plus className="w-4 h-4 mr-1.5" />
              Add Teacher
            </Button>
          }
        />
      )}

      {/* ADD / EDIT MODAL */}
      <Modal
        isOpen={isAddModalOpen || isEditModalOpen}
        onClose={() => {
          setIsAddModalOpen(false);
          setIsEditModalOpen(false);
          setTeacherToEdit(null);
        }}
        title={isAddModalOpen ? 'Create New Faculty Profile' : `Edit Faculty — ${teacherToEdit?.firstName} ${teacherToEdit?.lastName}`}
        description="Provide comprehensive teacher credentials, department affiliation, and subject assignments."
        size="lg"
      >
        <form onSubmit={isAddModalOpen ? handleCreateTeacher : handleUpdateTeacher} className="space-y-5">
          {formError && (
            <Alert variant="destructive" message={formError} onClose={() => setFormError(null)} />
          )}

          {/* Section: Basic Info */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-indigo-400 uppercase tracking-wider">
              1. Personal &amp; Identity Details
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <Input
                id="tch-firstname"
                label="First Name *"
                required
                value={formData.firstName}
                onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                placeholder="e.g. Sarah"
              />
              <Input
                id="tch-lastname"
                label="Last Name *"
                required
                value={formData.lastName}
                onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                placeholder="e.g. Jenkins"
              />
              <Input
                id="tch-empcode"
                label="Teacher ID / Code *"
                required
                value={formData.employeeCode}
                onChange={(e) => setFormData({ ...formData, employeeCode: e.target.value })}
                placeholder="e.g. TCH-204"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <Input
                id="tch-dob"
                type="date"
                label="Date of Birth"
                value={formData.dateOfBirth}
                onChange={(e) => setFormData({ ...formData, dateOfBirth: e.target.value })}
              />
              <Select
                id="tch-gender"
                label="Gender"
                options={[
                  { value: 'female', label: 'Female' },
                  { value: 'male', label: 'Male' },
                  { value: 'other', label: 'Other / Prefer not to say' }
                ]}
                value={formData.gender}
                onChange={(e) => setFormData({ ...formData, gender: e.target.value })}
              />
              <Input
                id="tch-address"
                label="Residential Address"
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                placeholder="e.g. 45 University Ave, Boston"
              />
            </div>
          </div>

          {/* Section: Contact Details */}
          <div className="space-y-3 pt-2 border-t border-white/5">
            <h4 className="text-xs font-bold text-indigo-400 uppercase tracking-wider">
              2. Contact &amp; Communications
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <Input
                id="tch-email"
                type="email"
                label="Institutional Email *"
                required
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                placeholder="sarah.jenkins@sygmate.edu"
              />
              <Input
                id="tch-phone"
                label="Phone Number"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                placeholder="+1 (555) 019-2834"
              />
              <Input
                id="tch-emergency"
                label="Emergency Contact"
                value={formData.emergencyContact}
                onChange={(e) => setFormData({ ...formData, emergencyContact: e.target.value })}
                placeholder="Name & Contact No."
              />
            </div>
          </div>

          {/* Section: Employment & Department */}
          <div className="space-y-3 pt-2 border-t border-white/5">
            <h4 className="text-xs font-bold text-indigo-400 uppercase tracking-wider">
              3. Department &amp; Academic Role
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <Select
                id="tch-department"
                label="Department *"
                options={
                  departments.length > 0
                    ? departments.map((d) => ({ value: d.id, label: d.name }))
                    : [{ value: '', label: 'General Faculty' }]
                }
                value={formData.departmentId}
                onChange={(e) => setFormData({ ...formData, departmentId: e.target.value })}
              />
              <Input
                id="tch-designation"
                label="Designation *"
                required
                value={formData.designation}
                onChange={(e) => setFormData({ ...formData, designation: e.target.value })}
                placeholder="e.g. Lead STEM Instructor"
              />
              <Input
                id="tch-qualification"
                label="Highest Qualification"
                value={formData.qualification}
                onChange={(e) => setFormData({ ...formData, qualification: e.target.value })}
                placeholder="e.g. M.Sc. Physics, MIT"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <Input
                id="tch-specialization"
                label="Specialization / Expertise"
                value={formData.specialization}
                onChange={(e) => setFormData({ ...formData, specialization: e.target.value })}
                placeholder="e.g. Quantum Mechanics, Calculus"
              />
              <Input
                id="tch-joiningdate"
                type="date"
                label="Joining Date"
                value={formData.joiningDate}
                onChange={(e) => setFormData({ ...formData, joiningDate: e.target.value })}
              />
              <Select
                id="tch-employmentstatus"
                label="Employment Status"
                options={[
                  { value: 'full_time', label: 'Full-Time Faculty' },
                  { value: 'part_time', label: 'Part-Time Faculty' },
                  { value: 'contract', label: 'Contract Instructor' },
                  { value: 'adjunct', label: 'Adjunct Specialist' }
                ]}
                value={formData.employmentStatus}
                onChange={(e) => setFormData({ ...formData, employmentStatus: e.target.value })}
              />
            </div>
          </div>

          {/* Section: Class & Subject Assignment */}
          <div className="space-y-3 pt-2 border-t border-white/5">
            <h4 className="text-xs font-bold text-indigo-400 uppercase tracking-wider">
              4. Class &amp; Subject Assignments
            </h4>
            
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                Assigned Classes
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {(classes || []).map((cls) => {
                  const isChecked = formData.assignedClassIds.includes(cls.id);
                  return (
                    <label
                      key={cls.id}
                      className={`flex items-center gap-2 p-2.5 rounded-xl border text-xs cursor-pointer transition-all ${
                        isChecked
                          ? 'bg-indigo-600/20 border-indigo-500/50 text-white'
                          : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10'
                      }`}
                    >
                      <input
                        type="checkbox"
                        checked={isChecked}
                        onChange={() => toggleClassAssignment(cls.id)}
                        className="rounded text-indigo-600 focus:ring-indigo-500"
                      />
                      <span className="font-medium">{cls.name}</span>
                    </label>
                  );
                })}
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                Assigned Teaching Subjects
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-40 overflow-y-auto pr-1">
                {(subjects || []).map((sub) => {
                  const isChecked = formData.assignedSubjectIds.includes(sub.id);
                  return (
                    <label
                      key={sub.id}
                      className={`flex items-center gap-2 p-2.5 rounded-xl border text-xs cursor-pointer transition-all ${
                        isChecked
                          ? 'bg-purple-600/20 border-purple-500/50 text-white'
                          : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10'
                      }`}
                    >
                      <input
                        type="checkbox"
                        checked={isChecked}
                        onChange={() => toggleSubjectAssignment(sub.id)}
                        className="rounded text-purple-600 focus:ring-purple-500"
                      />
                      <div className="truncate">
                        <span className="font-medium block truncate">{sub.name}</span>
                        <span className="text-[10px] text-slate-400">{sub.code}</span>
                      </div>
                    </label>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Section: Account & Password (Only on Create) */}
          {isAddModalOpen && (
            <div className="space-y-3 pt-2 border-t border-white/5">
              <h4 className="text-xs font-bold text-indigo-400 uppercase tracking-wider">
                5. Account Security
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <Input
                  id="tch-initpwd"
                  label="Initial Password"
                  value={formData.initialPassword}
                  onChange={(e) => setFormData({ ...formData, initialPassword: e.target.value })}
                  helperText="Default temporary password for initial portal login."
                />
                <Select
                  id="tch-status"
                  label="Initial Account Status"
                  options={[
                    { value: 'active', label: 'Active (Permit Portal Login)' },
                    { value: 'inactive', label: 'Inactive (Pending Activation)' }
                  ]}
                  value={formData.status}
                  onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                />
              </div>
            </div>
          )}

          <div className="flex justify-end gap-3 pt-4 border-t border-white/10">
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                setIsAddModalOpen(false);
                setIsEditModalOpen(false);
              }}
            >
              Cancel
            </Button>
            <Button
              id="btn-submit-teacher"
              type="submit"
              variant="primary"
              disabled={formSubmitting}
            >
              {formSubmitting
                ? 'Processing...'
                : isAddModalOpen
                ? 'Create Faculty Profile'
                : 'Save Modifications'}
            </Button>
          </div>
        </form>
      </Modal>

      {/* FACULTY PROFILE DOSSIER MODAL */}
      {selectedTeacherDossier && (
        <Modal
          isOpen={isDossierOpen}
          onClose={() => {
            setIsDossierOpen(false);
            setSelectedTeacherDossier(null);
          }}
          title={`Faculty Dossier: ${selectedTeacherDossier.firstName} ${selectedTeacherDossier.lastName}`}
          description={`${selectedTeacherDossier.designation} • ${selectedTeacherDossier.departmentName || selectedTeacherDossier.department}`}
          size="lg"
        >
          <div className="space-y-5 text-xs">
            {/* Header Identity Card */}
            <div className="p-5 rounded-2xl bg-white border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-2xs">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-2xl bg-blue-600 border border-blue-700 text-white font-bold flex items-center justify-center text-lg shadow-xs">
                  {selectedTeacherDossier.firstName?.[0]}
                  {selectedTeacherDossier.lastName?.[0]}
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900">
                    {selectedTeacherDossier.firstName} {selectedTeacherDossier.lastName}
                  </h3>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="px-2 py-0.5 rounded bg-blue-50 text-blue-700 font-mono font-medium border border-blue-200">
                      ID: {selectedTeacherDossier.employeeCode}
                    </span>
                    <Badge
                      variant={selectedTeacherDossier.status === 'active' ? 'success' : 'secondary'}
                      dot
                    >
                      {selectedTeacherDossier.status.toUpperCase()}
                    </Badge>
                  </div>
                </div>
              </div>

              <div className="text-right space-y-1">
                <div className="text-slate-400">Employment Type:</div>
                <div className="text-white font-semibold capitalize">
                  {selectedTeacherDossier.employmentStatus?.replace('_', ' ') || 'Full Time'}
                </div>
              </div>
            </div>

            {/* Grid Information */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Personal & Contact */}
              <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-3">
                <h4 className="font-bold text-indigo-400 uppercase tracking-wider flex items-center gap-1.5">
                  <FileText className="w-3.5 h-3.5" />
                  <span>Personal &amp; Contact</span>
                </h4>
                <div className="space-y-2">
                  <div className="flex justify-between border-b border-white/5 pb-1">
                    <span className="text-slate-400">Institutional Email:</span>
                    <span className="text-indigo-300 font-mono">{selectedTeacherDossier.email}</span>
                  </div>
                  <div className="flex justify-between border-b border-white/5 pb-1">
                    <span className="text-slate-400">Phone Number:</span>
                    <span className="text-white font-mono">
                      {selectedTeacherDossier.phone || selectedTeacherDossier.contactNumber || '—'}
                    </span>
                  </div>
                  <div className="flex justify-between border-b border-white/5 pb-1">
                    <span className="text-slate-400">Emergency Contact:</span>
                    <span className="text-white">{selectedTeacherDossier.emergencyContact || '—'}</span>
                  </div>
                  <div className="flex justify-between border-b border-white/5 pb-1">
                    <span className="text-slate-400">Gender:</span>
                    <span className="text-white capitalize">{selectedTeacherDossier.gender || '—'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Residential Address:</span>
                    <span className="text-white text-right max-w-[200px] truncate">
                      {selectedTeacherDossier.address || '—'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Academic & Credentials */}
              <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-3">
                <h4 className="font-bold text-indigo-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Award className="w-3.5 h-3.5" />
                  <span>Academic Qualifications</span>
                </h4>
                <div className="space-y-2">
                  <div className="flex justify-between border-b border-white/5 pb-1">
                    <span className="text-slate-400">Department:</span>
                    <span className="text-white font-semibold">
                      {selectedTeacherDossier.departmentName || selectedTeacherDossier.department}
                    </span>
                  </div>
                  <div className="flex justify-between border-b border-white/5 pb-1">
                    <span className="text-slate-400">Designation:</span>
                    <span className="text-white">{selectedTeacherDossier.designation}</span>
                  </div>
                  <div className="flex justify-between border-b border-white/5 pb-1">
                    <span className="text-slate-400">Qualification:</span>
                    <span className="text-white">{selectedTeacherDossier.qualification || '—'}</span>
                  </div>
                  <div className="flex justify-between border-b border-white/5 pb-1">
                    <span className="text-slate-400">Specialization:</span>
                    <span className="text-white">{selectedTeacherDossier.specialization || '—'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Joining Date:</span>
                    <span className="text-white">{selectedTeacherDossier.joiningDate || '2024-09-01'}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Assigned Classes and Subjects */}
            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-3">
              <h4 className="font-bold text-indigo-400 uppercase tracking-wider flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5" />
                <span>Teaching Schedule &amp; Allocated Classes</span>
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <div className="text-slate-400 mb-2 font-medium">Assigned Grades:</div>
                  <div className="flex flex-wrap gap-1.5">
                    {((selectedTeacherDossier?.assignedClassIds?.length || 0) > 0) ? (
                      (selectedTeacherDossier?.assignedClassIds || []).map((cid) => {
                        const cls = (classes || []).find((c) => c?.id === cid);
                        return (
                          <span
                            key={cid}
                            className="px-2.5 py-1 rounded-lg bg-indigo-600/20 text-indigo-200 border border-indigo-500/30 text-xs font-semibold"
                          >
                            {cls ? cls.name : cid}
                          </span>
                        );
                      })
                    ) : (
                      <span className="text-slate-500 italic">No classes assigned</span>
                    )}
                  </div>
                </div>

                <div>
                  <div className="text-slate-400 mb-2 font-medium">Assigned Coursework:</div>
                  <div className="flex flex-wrap gap-1.5">
                    {((selectedTeacherDossier?.assignedSubjectIds?.length || 0) > 0) ? (
                      (selectedTeacherDossier?.assignedSubjectIds || []).map((sid) => {
                        const sub = (subjects || []).find((s) => s?.id === sid);
                        return (
                          <span
                            key={sid}
                            className="px-2.5 py-1 rounded-lg bg-purple-600/20 text-purple-200 border border-purple-500/30 text-xs font-semibold"
                          >
                            {sub ? `${sub.name} (${sub.code})` : sid}
                          </span>
                        );
                      })
                    ) : (
                      <span className="text-slate-500 italic">No subjects assigned</span>
                    )}
                  </div>
                </div>
              </div>
            </div>

            <div className="flex justify-between items-center pt-2">
              <div className="flex items-center gap-2">
                <Button
                  size="sm"
                  variant="secondary"
                  onClick={() => {
                    setIsDossierOpen(false);
                    handleOpenEdit(selectedTeacherDossier);
                  }}
                >
                  <Edit2 className="w-3.5 h-3.5 mr-1.5" />
                  Edit Profile
                </Button>

                <Button
                  size="sm"
                  variant="primary"
                  onClick={() => {
                    setSelectedTeacherForDocs(selectedTeacherDossier);
                  }}
                  className="bg-indigo-600 hover:bg-indigo-500 text-white font-semibold"
                >
                  <FileText className="w-3.5 h-3.5 mr-1.5" />
                  Faculty Documents &amp; Verification
                </Button>
              </div>

              <Button
                size="sm"
                variant="outline"
                onClick={() => {
                  setIsDossierOpen(false);
                  setSelectedTeacherDossier(null);
                }}
              >
                Close Dossier
              </Button>
            </div>
          </div>
        </Modal>
      )}

      {/* Part 15E — Faculty Document Checklist & Verification Modal */}
      {selectedTeacherForDocs && (
        <EntityDocumentChecklistModal
          entityType="TEACHER"
          entityId={selectedTeacherForDocs.id}
          entityName={`${selectedTeacherForDocs.firstName} ${selectedTeacherForDocs.lastName}`}
          isOpen={!!selectedTeacherForDocs}
          onClose={() => setSelectedTeacherForDocs(null)}
          canVerify={true}
          onDocumentUpdated={onRefresh}
        />
      )}

      {/* DELETE CONFIRMATION DIALOG */}
      {teacherToDelete && (
        <ConfirmDialog
          isOpen={Boolean(teacherToDelete)}
          title={`Delete Faculty Member — ${teacherToDelete.employeeCode}`}
          message={`Are you sure you want to permanently delete the profile for ${teacherToDelete.firstName} ${teacherToDelete.lastName}? This will revoke their account credentials and remove all subject assignments.`}
          confirmLabel="Permanently Delete"
          variant="danger"
          onConfirm={handleDeleteTeacher}
          onCancel={() => setTeacherToDelete(null)}
        />
      )}
    </div>
  );
};
