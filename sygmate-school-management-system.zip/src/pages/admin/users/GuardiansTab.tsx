import React, { useState, useEffect, useRef } from 'react';
import {
  HeartHandshake,
  Plus,
  Search,
  Edit2,
  Trash2,
  Mail,
  Phone,
  Layers,
  Users,
  Link as LinkIcon,
  Unlink,
  Briefcase,
  Home,
  AlertCircle,
  CheckCircle2,
  Sparkles,
  UserPlus,
  Shield,
  ShieldCheck,
  ShieldAlert,
  GraduationCap,
  MessageSquare,
  AlertTriangle,
  FileText,
  DollarSign,
  Car,
  Settings,
  KeyRound
} from 'lucide-react';
import { Table, Column } from '../../../components/ui/Table.js';
import { Badge } from '../../../components/ui/Badge.js';
import { Button } from '../../../components/ui/Button.js';
import { Input } from '../../../components/ui/Input.js';
import { Select } from '../../../components/ui/Select.js';
import { Modal } from '../../../components/ui/Modal.js';
import { Alert } from '../../../components/ui/Alert.js';
import { ConfirmDialog } from '../../../components/ui/ConfirmDialog.js';
import { EmptyState } from '../../../components/ui/EmptyState.js';
import { api } from '../../../services/api.js';
import { Guardian, Student, Family } from '../../../types/index.js';
import { FamilyHouseholdsView } from './FamilyHouseholdsView.js';
import { GuardianAuthorizationsModal } from './GuardianAuthorizationsModal.js';
import { GuardianIntegrityModal } from './GuardianIntegrityModal.js';
import { GuardianAccountSecurityModal } from './GuardianAccountSecurityModal.js';
import { EntityDocumentChecklistModal } from '../../../components/documents/EntityDocumentChecklistModal.js';

interface GuardiansTabProps {
  guardians: Guardian[];
  students: Student[];
  onRefresh: () => void;
  selectedGuardianId?: string;
}

export const GuardiansTab: React.FC<GuardiansTabProps> = ({
  guardians,
  students,
  onRefresh,
  selectedGuardianId
}) => {
  // Top-level Navigation Subtab: 'guardians' | 'families'
  const [activeSubTab, setActiveSubTab] = useState<'guardians' | 'families'>('guardians');

  // Filtering
  const [search, setSearch] = useState('');
  const [relationFilter, setRelationFilter] = useState('ALL');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [roleFilter, setRoleFilter] = useState('ALL'); // 'ALL' | 'PRIMARY' | 'SECONDARY'

  // Families cache
  const [familiesList, setFamiliesList] = useState<Family[]>([]);

  // Modals
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isDossierOpen, setIsDossierOpen] = useState(false);
  const [isLinkModalOpen, setIsLinkModalOpen] = useState(false);
  const [isIntegrityModalOpen, setIsIntegrityModalOpen] = useState(false);
  const [securityModalGuardian, setSecurityModalGuardian] = useState<Guardian | null>(null);
  const [selectedGuardianForDocs, setSelectedGuardianForDocs] = useState<Guardian | null>(null);

  // Authorizations Modal State
  const [authModalState, setAuthModalState] = useState<{
    isOpen: boolean;
    guardian: Guardian | null;
    student: Student | null;
  }>({
    isOpen: false,
    guardian: null,
    student: null
  });

  const [guardianToEdit, setGuardianToEdit] = useState<Guardian | null>(null);
  const [selectedGuardianDossier, setSelectedGuardianDossier] = useState<any | null>(null);
  const [guardianToLink, setGuardianToLink] = useState<Guardian | null>(null);
  const [guardianToDelete, setGuardianToDelete] = useState<Guardian | null>(null);

  // Real-time duplicate detection state
  const [duplicateWarning, setDuplicateWarning] = useState<any[] | null>(null);
  const duplicateCheckTimer = useRef<any>(null);

  // Form State
  const [formData, setFormData] = useState({
    name: '',
    relationship: 'Father',
    familyRole: 'Primary Guardian',
    phone: '',
    secondaryPhone: '',
    whatsapp: '',
    email: '',
    address: '',
    permanentAddress: '',
    occupation: '',
    emergencyContact: '',
    familyId: '',
    isPrimaryGuardian: true,
    studentIds: [] as string[],
    status: 'active'
  });

  // Link Student Modal Form State
  const [linkStudentForm, setLinkStudentForm] = useState({
    studentId: '',
    relationshipType: 'Father',
    isPrimaryGuardian: true,
    isSecondaryGuardian: false,
    isEmergencyContact: true,
    isAuthorizedAcademic: true,
    isAuthorizedAttendance: true,
    isAuthorizedFinancial: true,
    isAuthorizedCommunication: true,
    isPickupAuthorized: true
  });

  const [formError, setFormError] = useState<string | null>(null);
  const [formSubmitting, setFormSubmitting] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);

  // Load Families for dropdown selection
  const loadFamilies = async () => {
    try {
      const res = await api.users.getFamilies();
      if (res.success && res.data) {
        setFamiliesList(res.data);
      }
    } catch {
      // Graceful fallback
    }
  };

  useEffect(() => {
    loadFamilies();
  }, []);

  // Deep-link trigger
  useEffect(() => {
    if (selectedGuardianId && guardians?.length > 0) {
      const found = (guardians || []).find((g) => g?.id === selectedGuardianId);
      if (found) {
        setSelectedGuardianDossier(found);
        setIsDossierOpen(true);
      }
    }
  }, [selectedGuardianId, guardians]);

  // Real-time Duplicate Check function
  const triggerDuplicateCheck = (phone: string, email: string, name: string, excludeId?: string) => {
    if (duplicateCheckTimer.current) clearTimeout(duplicateCheckTimer.current);

    if (!phone && !email && (!name || name.trim().length < 3)) {
      setDuplicateWarning(null);
      return;
    }

    duplicateCheckTimer.current = setTimeout(async () => {
      try {
        const res = await api.users.checkDuplicateGuardian({
          phone: phone || undefined,
          email: email || undefined,
          name: name || undefined,
          excludeId
        });
        if (res.success && res.data?.hasDuplicate && res.data.duplicates?.length > 0) {
          setDuplicateWarning(res.data.duplicates);
        } else {
          setDuplicateWarning(null);
        }
      } catch {
        setDuplicateWarning(null);
      }
    }, 400);
  };

  const resetForm = () => {
    setFormData({
      name: '',
      relationship: 'Father',
      familyRole: 'Primary Guardian',
      phone: '',
      secondaryPhone: '',
      whatsapp: '',
      email: '',
      address: '',
      permanentAddress: '',
      occupation: '',
      emergencyContact: '',
      familyId: '',
      isPrimaryGuardian: true,
      studentIds: [],
      status: 'active'
    });
    setDuplicateWarning(null);
    setFormError(null);
  };

  const handleOpenAdd = () => {
    resetForm();
    setIsAddModalOpen(true);
  };

  const handleOpenEdit = (guardian: Guardian) => {
    setGuardianToEdit(guardian);
    setFormData({
      name: guardian.name,
      relationship: guardian.relationship || 'Father',
      familyRole: guardian.familyRole || 'Primary Guardian',
      phone: guardian.phone || '',
      secondaryPhone: guardian.secondaryPhone || '',
      whatsapp: guardian.whatsapp || '',
      email: guardian.email || '',
      address: guardian.address || '',
      permanentAddress: guardian.permanentAddress || '',
      occupation: guardian.occupation || '',
      emergencyContact: guardian.emergencyContact || '',
      familyId: guardian.familyId || '',
      isPrimaryGuardian: guardian.isPrimaryGuardian !== false,
      studentIds: guardian.studentIds || [],
      status: guardian.status || 'active'
    });
    setDuplicateWarning(null);
    setFormError(null);
    setIsEditModalOpen(true);
  };

  const handleOpenDossier = (guardian: Guardian) => {
    setSelectedGuardianDossier(guardian);
    setIsDossierOpen(true);
  };

  const handleOpenLinkModal = (guardian: Guardian) => {
    setGuardianToLink(guardian);
    setLinkStudentForm({
      studentId: '',
      relationshipType: guardian.relationship || 'Father',
      isPrimaryGuardian: true,
      isSecondaryGuardian: false,
      isEmergencyContact: true,
      isAuthorizedAcademic: true,
      isAuthorizedAttendance: true,
      isAuthorizedFinancial: true,
      isAuthorizedCommunication: true,
      isPickupAuthorized: true
    });
    setIsLinkModalOpen(true);
  };

  // Submit Add Guardian
  const handleCreateGuardian = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    setFormSubmitting(true);

    try {
      const res = await api.users.createGuardian(formData);
      if (res.success) {
        setIsAddModalOpen(false);
        onRefresh();
        loadFamilies();
      } else {
        setFormError(res.error || 'Failed to create guardian record.');
      }
    } catch (err: any) {
      setFormError(err.message || 'An unexpected error occurred.');
    } finally {
      setFormSubmitting(false);
    }
  };

  // Submit Edit Guardian
  const handleUpdateGuardian = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!guardianToEdit) return;
    setFormError(null);
    setFormSubmitting(true);

    try {
      const res = await api.users.updateGuardian(guardianToEdit.id, formData);
      if (res.success) {
        setIsEditModalOpen(false);
        setGuardianToEdit(null);
        onRefresh();
        loadFamilies();
      } else {
        setFormError(res.error || 'Failed to update guardian record.');
      }
    } catch (err: any) {
      setFormError(err.message || 'An unexpected error occurred.');
    } finally {
      setFormSubmitting(false);
    }
  };

  // Toggle student in create/edit form
  const toggleStudentSelection = (studentId: string) => {
    setFormData((prev) => {
      const exists = prev.studentIds.includes(studentId);
      return {
        ...prev,
        studentIds: exists
          ? prev.studentIds.filter((id) => id !== studentId)
          : [...prev.studentIds, studentId]
      };
    });
  };

  // Link or Unlink Student action
  const handleLinkStudentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!guardianToLink || !linkStudentForm.studentId) return;

    try {
      const res = await api.users.linkGuardianStudent(guardianToLink.id, {
        studentId: linkStudentForm.studentId,
        action: 'link',
        relationshipType: linkStudentForm.relationshipType,
        isPrimaryGuardian: linkStudentForm.isPrimaryGuardian,
        isSecondaryGuardian: linkStudentForm.isSecondaryGuardian,
        isEmergencyContact: linkStudentForm.isEmergencyContact,
        isAuthorizedAcademic: linkStudentForm.isAuthorizedAcademic,
        isAuthorizedAttendance: linkStudentForm.isAuthorizedAttendance,
        isAuthorizedFinancial: linkStudentForm.isAuthorizedFinancial,
        isAuthorizedCommunication: linkStudentForm.isAuthorizedCommunication,
        isPickupAuthorized: linkStudentForm.isPickupAuthorized
      });

      if (res.success) {
        setIsLinkModalOpen(false);
        setGuardianToLink(null);
        if (selectedGuardianDossier) {
          // Re-fetch dossier
          const updated = await api.users.getGuardian(selectedGuardianDossier.id);
          if (updated.success && updated.data) {
            setSelectedGuardianDossier(updated.data);
          }
        }
        onRefresh();
      } else {
        setActionError(res.error || 'Failed to link scholar to guardian.');
      }
    } catch (err: any) {
      setActionError(err.message);
    }
  };

  const handleUnlinkStudent = async (guardianId: string, studentId: string) => {
    try {
      const res = await api.users.linkGuardianStudent(guardianId, {
        studentId,
        action: 'unlink'
      });

      if (res.success) {
        if (selectedGuardianDossier && selectedGuardianDossier.id === guardianId) {
          const updated = await api.users.getGuardian(guardianId);
          if (updated.success && updated.data) {
            setSelectedGuardianDossier(updated.data);
          }
        }
        onRefresh();
      } else {
        setActionError(res.error || 'Failed to unlink scholar from guardian.');
      }
    } catch (err: any) {
      setActionError(err.message);
    }
  };

  // Delete Guardian
  const handleDeleteGuardian = async () => {
    if (!guardianToDelete) return;
    try {
      const res = await api.users.deleteGuardian(guardianToDelete.id);
      if (res.success) {
        setGuardianToDelete(null);
        onRefresh();
      } else {
        setActionError(res.error || 'Failed to delete guardian.');
        setGuardianToDelete(null);
      }
    } catch (err: any) {
      setActionError(err.message);
      setGuardianToDelete(null);
    }
  };

  // Filtered Guardians
  const filteredGuardians = guardians.filter((g) => {
    const q = (search || '').toLowerCase().trim();
    const matchesSearch =
      !q ||
      (g.name || '').toLowerCase().includes(q) ||
      (g.phone || '').toLowerCase().includes(q) ||
      (g.email || '').toLowerCase().includes(q) ||
      (g.occupation ? g.occupation.toLowerCase().includes(q) : false) ||
      (g.family ? (g.family.familyName || '').toLowerCase().includes(q) : false) ||
      (g.students &&
        g.students.some(
          (st: any) =>
            (st.name || '').toLowerCase().includes(q) ||
            (st.admissionNumber || '').toLowerCase().includes(q)
        ));

    const matchesRelation =
      relationFilter === 'ALL' || (g.relationship || '').toLowerCase() === relationFilter.toLowerCase();
    const matchesStatus =
      statusFilter === 'ALL' || (g.status || 'active').toLowerCase() === statusFilter.toLowerCase();
    const matchesRole =
      roleFilter === 'ALL' ||
      (roleFilter === 'PRIMARY' && g.isPrimaryGuardian) ||
      (roleFilter === 'SECONDARY' && !g.isPrimaryGuardian);

    return matchesSearch && matchesRelation && matchesStatus && matchesRole;
  });

  const columns: Column<Guardian>[] = [
    {
      header: 'Parent / Guardian',
      accessor: (row) => (
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-50 border border-blue-200 text-blue-700 font-bold flex items-center justify-center text-xs shadow-2xs shrink-0">
            {(row.name || '')
              .split(' ')
              .filter(Boolean)
              .map((n) => n[0])
              .join('')
              .substring(0, 2) || 'G'}
          </div>
          <div className="min-w-0">
            <div className="font-semibold text-slate-900 flex items-center gap-2">
              <span className="truncate">{row.name}</span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 border border-blue-200 font-medium shrink-0">
                {row.relationship}
              </span>
              {row.isPrimaryGuardian ? (
                <span className="text-[9px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 font-bold shrink-0">
                  PRIMARY
                </span>
              ) : (
                <span className="text-[9px] px-1.5 py-0.2 rounded bg-slate-500/20 text-slate-400 font-medium shrink-0">
                  SECONDARY
                </span>
              )}
            </div>
            <div className="text-[11px] text-slate-400 flex items-center gap-1.5 mt-0.5">
              <Briefcase className="w-3 h-3 text-slate-500 shrink-0" />
              <span className="truncate">{row.occupation || 'Guardian of Record'}</span>
            </div>
          </div>
        </div>
      )
    },
    {
      header: 'Household Unit',
      accessor: (row) => {
        const fam = row.family || (familiesList || []).find((f) => f?.id === row.familyId);
        return (
          <div className="text-xs">
            {fam ? (
              <div className="space-y-0.5">
                <div className="font-semibold text-indigo-300 flex items-center gap-1.5">
                  <Home className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                  <span className="truncate max-w-[140px]">{fam.familyName}</span>
                </div>
                {fam.familyCode && (
                  <div className="text-[10px] text-slate-500 font-mono">{fam.familyCode}</div>
                )}
              </div>
            ) : (
              <span className="text-[11px] text-slate-500 italic">Independent Household</span>
            )}
          </div>
        );
      }
    },
    {
      header: 'Contact Details',
      accessor: (row) => (
        <div className="text-xs space-y-0.5">
          <div className="text-slate-300 font-mono flex items-center gap-1.5">
            <Phone className="w-3 h-3 text-indigo-400 shrink-0" />
            <span>{row.phone || '—'}</span>
          </div>
          {row.email && (
            <div className="text-[11px] text-slate-400 font-mono flex items-center gap-1.5">
              <Mail className="w-3 h-3 text-slate-500 shrink-0" />
              <span className="truncate max-w-[150px]">{row.email}</span>
            </div>
          )}
        </div>
      )
    },
    {
      header: 'Enrolled Children (1:N)',
      accessor: (row) => {
        const linkedStudents = students.filter(
          (st) => row.studentIds?.includes(st.id) || st.guardianId === row.id
        );

        return (
          <div className="space-y-1">
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-semibold text-slate-200">
                {linkedStudents.length} {linkedStudents.length === 1 ? 'Scholar' : 'Scholars'}
              </span>
              {linkedStudents.length > 1 && (
                <span className="text-[10px] px-1.5 py-0.2 rounded bg-purple-500/20 text-purple-300 font-bold">
                  Sibling Group
                </span>
              )}
            </div>

            <div className="flex flex-wrap gap-1 max-w-xs">
              {linkedStudents.length > 0 ? (
                linkedStudents.map((st) => {
                  const rel = (row.relationships || []).find((r) => r.studentId === st.id);
                  return (
                    <span
                      key={st.id}
                      className="px-2 py-0.5 rounded-md bg-emerald-500/10 text-emerald-300 text-[11px] font-medium border border-emerald-500/20 flex items-center gap-1"
                    >
                      <span>
                        {st.firstName} {st.lastName}
                      </span>
                      {rel?.isPrimaryGuardian && (
                        <span className="text-[9px] bg-amber-500/30 text-amber-200 px-1 rounded font-bold">
                          P
                        </span>
                      )}
                      {rel?.isAuthorizedFinancial && (
                        <span className="text-[9px] bg-blue-500/30 text-blue-200 px-0.5 rounded font-bold" title="Financial Sponsor">
                          $
                        </span>
                      )}
                      {rel?.isPickupAuthorized && (
                        <span className="text-[9px] bg-emerald-500/30 text-emerald-200 px-0.5 rounded font-bold" title="Authorized Pickup">
                          ✓
                        </span>
                      )}
                    </span>
                  );
                })
              ) : (
                <span className="text-[11px] text-slate-500 italic">No linked children</span>
              )}
            </div>
          </div>
        );
      }
    },
    {
      header: 'Address',
      accessor: (row) => (
        <div className="text-xs text-slate-300 max-w-xs truncate flex items-center gap-1">
          <Home className="w-3 h-3 text-slate-500 shrink-0" />
          <span className="truncate">{row.address || '—'}</span>
        </div>
      )
    },
    {
      header: 'Status',
      accessor: (row) => (
        <Badge variant={row.status === 'active' ? 'success' : 'secondary'} dot>
          {(row.status || 'ACTIVE').toUpperCase()}
        </Badge>
      )
    },
    {
      header: 'Actions',
      accessor: (row) => (
        <div className="flex items-center gap-1.5">
          <Button
            id={`btn-view-guardian-${row.id}`}
            size="xs"
            variant="outline"
            onClick={() => handleOpenDossier(row)}
            title="View Family Dossier & Authorizations"
          >
            Dossier
          </Button>
          <Button
            id={`btn-docs-guardian-${row.id}`}
            size="xs"
            variant="outline"
            onClick={() => setSelectedGuardianForDocs(row)}
            title="Manage Parent/Guardian Verification Documents"
            className="text-indigo-400 border-indigo-500/30 hover:bg-indigo-500/10"
          >
            <FileText className="w-3.5 h-3.5 mr-1" />
            Docs
          </Button>
          <Button
            id={`btn-security-guardian-${row.id}`}
            size="xs"
            variant="outline"
            className="border-indigo-500/30 text-indigo-300 hover:bg-indigo-500/10"
            onClick={() => setSecurityModalGuardian(row)}
            title="Manage Portal Account & Access Security"
          >
            <KeyRound className="w-3.5 h-3.5" />
          </Button>
          <Button
            id={`btn-link-guardian-${row.id}`}
            size="xs"
            variant="outline"
            onClick={() => handleOpenLinkModal(row)}
            title="Attach Scholar to Guardian"
          >
            <LinkIcon className="w-3.5 h-3.5" />
          </Button>
          <Button
            id={`btn-edit-guardian-${row.id}`}
            size="xs"
            variant="secondary"
            onClick={() => handleOpenEdit(row)}
            title="Edit Guardian Record"
          >
            <Edit2 className="w-3.5 h-3.5" />
          </Button>
          <Button
            id={`btn-delete-guardian-${row.id}`}
            size="xs"
            variant="danger"
            onClick={() => setGuardianToDelete(row)}
            title="Delete Guardian Record"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </Button>
        </div>
      )
    }
  ];

  return (
    <div className="space-y-6">
      {actionError && (
        <Alert
          variant="destructive"
          title="Operation Alert"
          message={actionError}
          onClose={() => setActionError(null)}
        />
      )}

      {/* Top Header & Subtabs */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 border-b border-white/10 pb-4">
        {/* Sub-tab pills */}
        <div className="flex items-center gap-2 p-1 rounded-xl bg-white/5 border border-white/10 w-fit">
          <button
            type="button"
            onClick={() => setActiveSubTab('guardians')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-2 ${
              activeSubTab === 'guardians'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Guardians &amp; Contacts</span>
            <span className="px-1.5 py-0.2 rounded-full bg-white/20 text-[10px]">
              {guardians.length}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveSubTab('families')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-2 ${
              activeSubTab === 'families'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Home className="w-4 h-4" />
            <span>Family Households</span>
            <span className="px-1.5 py-0.2 rounded-full bg-white/20 text-[10px]">
              {familiesList.length}
            </span>
          </button>
        </div>

        {/* Global Diagnostics Button */}
        <div className="flex items-center gap-2.5">
          <Button
            id="btn-integrity-audit"
            variant="outline"
            size="sm"
            onClick={() => setIsIntegrityModalOpen(true)}
            className="gap-1.5 text-xs text-indigo-300 border-indigo-500/30 hover:bg-indigo-500/10"
          >
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Integrity &amp; Diagnostics</span>
          </Button>

          {activeSubTab === 'guardians' && (
            <Button
              id="btn-add-guardian"
              variant="primary"
              size="sm"
              onClick={handleOpenAdd}
              className="gap-2 shrink-0"
            >
              <Plus className="w-4 h-4" />
              <span>Register New Guardian</span>
            </Button>
          )}
        </div>
      </div>

      {/* VIEW 1: GUARDIANS DIRECTORY */}
      {activeSubTab === 'guardians' && (
        <div className="space-y-6">
          {/* Filters Toolbar */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
            <div className="flex flex-1 flex-col sm:flex-row gap-3">
              <div className="w-full sm:w-72">
                <Input
                  id="search-guardians-input"
                  placeholder="Search guardian, child, phone, family..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  leftIcon={<Search className="w-4 h-4" />}
                />
              </div>

              <div className="w-full sm:w-44">
                <Select
                  id="filter-guardian-relation"
                  options={[
                    { value: 'ALL', label: 'All Relationships' },
                    { value: 'Father', label: 'Fathers' },
                    { value: 'Mother', label: 'Mothers' },
                    { value: 'Legal Guardian', label: 'Legal Guardians' },
                    { value: 'Sponsor', label: 'Sponsors' },
                    { value: 'Grandparent', label: 'Grandparents' },
                    { value: 'Relative', label: 'Relatives' }
                  ]}
                  value={relationFilter}
                  onChange={(e) => setRelationFilter(e.target.value)}
                />
              </div>

              <div className="w-full sm:w-40">
                <Select
                  id="filter-guardian-role"
                  options={[
                    { value: 'ALL', label: 'All Roles' },
                    { value: 'PRIMARY', label: 'Primary Only' },
                    { value: 'SECONDARY', label: 'Secondary Only' }
                  ]}
                  value={roleFilter}
                  onChange={(e) => setRoleFilter(e.target.value)}
                />
              </div>

              <div className="w-full sm:w-36">
                <Select
                  id="filter-guardian-status"
                  options={[
                    { value: 'ALL', label: 'All Statuses' },
                    { value: 'active', label: 'Active Only' },
                    { value: 'inactive', label: 'Inactive' }
                  ]}
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                />
              </div>
            </div>
          </div>

          {/* Guardians Table */}
          {filteredGuardians.length > 0 ? (
            <Table columns={columns} data={filteredGuardians} keyExtractor={(g) => g.id} />
          ) : (
            <EmptyState
              icon={<HeartHandshake className="w-10 h-10 text-indigo-400" />}
              title="No Guardian Profiles Found"
              description={
                search || relationFilter !== 'ALL' || statusFilter !== 'ALL' || roleFilter !== 'ALL'
                  ? 'No guardian records match your active search filters.'
                  : 'Register parents and legal guardians, and link them to one or more enrolled scholars.'
              }
              action={
                <Button size="sm" variant="primary" onClick={handleOpenAdd}>
                  <Plus className="w-4 h-4 mr-1.5" />
                  Register Guardian
                </Button>
              }
            />
          )}
        </div>
      )}

      {/* VIEW 2: FAMILY HOUSEHOLDS */}
      {activeSubTab === 'families' && (
        <FamilyHouseholdsView
          guardians={guardians}
          students={students}
          onRefreshParent={() => {
            onRefresh();
            loadFamilies();
          }}
        />
      )}

      {/* ADD / EDIT GUARDIAN MODAL */}
      <Modal
        isOpen={isAddModalOpen || isEditModalOpen}
        onClose={() => {
          setIsAddModalOpen(false);
          setIsEditModalOpen(false);
          setGuardianToEdit(null);
          setDuplicateWarning(null);
        }}
        title={isAddModalOpen ? 'Register Parent / Legal Guardian' : `Edit Guardian — ${guardianToEdit?.name}`}
        description="Unified contact information with duplicate detection and sibling group grouping."
        size="lg"
      >
        <form onSubmit={isAddModalOpen ? handleCreateGuardian : handleUpdateGuardian} className="space-y-5 text-xs">
          {formError && (
            <Alert variant="destructive" message={formError} onClose={() => setFormError(null)} />
          )}

          {/* Duplicate Guardian Warning Banner */}
          {duplicateWarning && duplicateWarning.length > 0 && (
            <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-200 space-y-2">
              <div className="flex items-center gap-2 font-bold text-amber-300">
                <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                <span>Existing Guardian Match Detected ({duplicateWarning.length})</span>
              </div>
              <p className="text-[11px] text-slate-300">
                A parent/guardian with matching phone number or email is already registered in the system:
              </p>
              <div className="space-y-1 pt-1">
                {duplicateWarning.map((dup) => (
                  <div
                    key={dup.id}
                    className="p-2 rounded-lg bg-black/30 border border-white/5 flex items-center justify-between text-xs"
                  >
                    <div>
                      <div className="font-semibold text-white">
                        {dup.name} ({dup.relationship || 'Guardian'})
                      </div>
                      <div className="text-[11px] text-slate-400 font-mono">
                        Phone: {dup.phone} {dup.email ? `• Email: ${dup.email}` : ''}
                      </div>
                    </div>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 font-semibold">
                      Existing Profile
                    </span>
                  </div>
                ))}
              </div>
              <p className="text-[10px] text-amber-400 italic">
                Tip: If this is the same person, associate the scholar directly to their existing profile to prevent orphan records.
              </p>
            </div>
          )}

          <div className="space-y-3">
            <h4 className="text-xs font-bold text-indigo-400 uppercase tracking-wider">
              1. Personal &amp; Relational Identity
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <Input
                id="guard-name"
                label="Full Legal Name *"
                required
                value={formData.name}
                onChange={(e) => {
                  setFormData({ ...formData, name: e.target.value });
                  triggerDuplicateCheck(formData.phone, formData.email, e.target.value, guardianToEdit?.id);
                }}
                placeholder="e.g. Carlos Rivera"
              />

              <Select
                id="guard-relation"
                label="Relationship *"
                options={[
                  { value: 'Father', label: 'Father' },
                  { value: 'Mother', label: 'Mother' },
                  { value: 'Stepfather', label: 'Stepfather' },
                  { value: 'Stepmother', label: 'Stepmother' },
                  { value: 'Legal Guardian', label: 'Legal Guardian' },
                  { value: 'Foster Parent', label: 'Foster Parent' },
                  { value: 'Grandparent', label: 'Grandparent' },
                  { value: 'Sponsor', label: 'Sponsor' },
                  { value: 'Relative', label: 'Relative' }
                ]}
                value={formData.relationship}
                onChange={(e) => setFormData({ ...formData, relationship: e.target.value })}
              />

              <Select
                id="guard-family-select"
                label="Assign to Family Household"
                options={[
                  { value: '', label: '-- Independent (No Family Group) --' },
                  ...familiesList.map((fam) => ({
                    value: fam.id,
                    label: `${fam.familyName} (${fam.familyCode || 'FAM'})`
                  }))
                ]}
                value={formData.familyId}
                onChange={(e) => setFormData({ ...formData, familyId: e.target.value })}
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <Input
                id="guard-phone"
                label="Primary Phone Number *"
                required
                value={formData.phone}
                onChange={(e) => {
                  setFormData({ ...formData, phone: e.target.value });
                  triggerDuplicateCheck(e.target.value, formData.email, formData.name, guardianToEdit?.id);
                }}
                placeholder="+1 (555) 019-8811"
              />

              <Input
                id="guard-sec-phone"
                label="Secondary / WhatsApp Phone"
                value={formData.secondaryPhone}
                onChange={(e) => setFormData({ ...formData, secondaryPhone: e.target.value })}
                placeholder="+1 (555) 019-8822"
              />

              <Input
                id="guard-email"
                type="email"
                label="Email Address"
                value={formData.email}
                onChange={(e) => {
                  setFormData({ ...formData, email: e.target.value });
                  triggerDuplicateCheck(formData.phone, e.target.value, formData.name, guardianToEdit?.id);
                }}
                placeholder="carlos.rivera@example.com"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <Input
                id="guard-occupation"
                label="Occupation / Professional Role"
                value={formData.occupation}
                onChange={(e) => setFormData({ ...formData, occupation: e.target.value })}
                placeholder="e.g. Biomedical Engineer"
              />

              <Input
                id="guard-emergency"
                label="Secondary Emergency Contact"
                value={formData.emergencyContact}
                onChange={(e) => setFormData({ ...formData, emergencyContact: e.target.value })}
                placeholder="Alternate phone / relative"
              />

              <div className="flex items-center gap-2 pt-6">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.isPrimaryGuardian}
                    onChange={(e) => setFormData({ ...formData, isPrimaryGuardian: e.target.checked })}
                    className="rounded text-indigo-600 focus:ring-indigo-500"
                  />
                  <span className="text-white font-semibold">Designate as Primary Guardian</span>
                </label>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <Input
                id="guard-address"
                label="Residential Address"
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                placeholder="e.g. 12 Oak Ridge Way, Boston, MA"
              />
              <Input
                id="guard-perm-address"
                label="Permanent Address (Optional)"
                value={formData.permanentAddress}
                onChange={(e) => setFormData({ ...formData, permanentAddress: e.target.value })}
                placeholder="If different from residential address"
              />
            </div>
          </div>

          {/* Associate Children Section */}
          <div className="space-y-3 pt-2 border-t border-white/5">
            <h4 className="text-xs font-bold text-indigo-400 uppercase tracking-wider flex items-center gap-1.5">
              <Users className="w-3.5 h-3.5" />
              <span>2. Associate Enrolled Students (1:N One Guardian → Multiple Scholars)</span>
            </h4>

            <p className="text-xs text-slate-400">
              Check all students that belong to this guardian household. Updates to contact details will automatically synchronize to all connected students.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-48 overflow-y-auto pr-1">
              {(students || []).map((st) => {
                const isSelected = formData.studentIds.includes(st.id);
                return (
                  <label
                    key={st.id}
                    className={`flex items-center gap-2.5 p-2.5 rounded-xl border text-xs cursor-pointer transition-all ${
                      isSelected
                        ? 'bg-indigo-600/20 border-indigo-500/50 text-white'
                        : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10'
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={isSelected}
                      onChange={() => toggleStudentSelection(st.id)}
                      className="rounded text-indigo-600 focus:ring-indigo-500"
                    />
                    <div className="truncate">
                      <div className="font-semibold text-white truncate">
                        {st.firstName} {st.lastName}
                      </div>
                      <div className="text-[10px] text-slate-400">
                        {st.className} ({st.sectionName}) • Adm: {st.admissionNumber}
                      </div>
                    </div>
                  </label>
                );
              })}
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-white/10">
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                setIsAddModalOpen(false);
                setIsEditModalOpen(false);
              }}
            >
              Cancel
            </Button>
            <Button
              id="btn-submit-guardian"
              type="submit"
              variant="primary"
              disabled={formSubmitting}
            >
              {formSubmitting
                ? 'Processing...'
                : isAddModalOpen
                ? 'Register Guardian'
                : 'Save Modifications'}
            </Button>
          </div>
        </form>
      </Modal>

      {/* FAMILY DOSSIER MODAL */}
      {selectedGuardianDossier && (
        <Modal
          isOpen={isDossierOpen}
          onClose={() => {
            setIsDossierOpen(false);
            setSelectedGuardianDossier(null);
          }}
          title={`Family Dossier: ${selectedGuardianDossier.name}`}
          description={`${selectedGuardianDossier.relationship || 'Guardian'} • Household &amp; Scholar Relationship Roster`}
          size="lg"
        >
          <div className="space-y-5 text-xs">
            {/* Header Card */}
            <div className="p-5 rounded-2xl bg-white border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-2xs">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-2xl bg-blue-600 border border-blue-700 text-white font-bold flex items-center justify-center text-lg shadow-xs shrink-0">
                  {(selectedGuardianDossier.name || '')
                    .split(' ')
                    .filter(Boolean)
                    .map((n: string) => n[0])
                    .join('')
                    .substring(0, 2) || 'G'}
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900">{selectedGuardianDossier.name}</h3>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="px-2 py-0.5 rounded bg-blue-50 text-blue-700 font-medium border border-blue-200">
                      {selectedGuardianDossier.relationship || 'Guardian'}
                    </span>
                    {selectedGuardianDossier.isPrimaryGuardian && (
                      <span className="px-2 py-0.5 rounded bg-amber-50 text-amber-800 border border-amber-200 font-bold">
                        PRIMARY GUARDIAN
                      </span>
                    )}
                    <Badge variant="success" dot>
                      ACTIVE RECORD
                    </Badge>
                  </div>
                </div>
              </div>

              <div className="text-right space-y-1">
                <div className="text-slate-400">Occupation:</div>
                <div className="text-white font-semibold">{selectedGuardianDossier.occupation || '—'}</div>
              </div>
            </div>

            {/* Household Family Link (if assigned) */}
            {selectedGuardianDossier.family && (
              <div className="p-3.5 rounded-xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <Home className="w-4 h-4 text-indigo-400 shrink-0" />
                  <div>
                    <div className="font-semibold text-white">
                      Part of {selectedGuardianDossier.family.familyName}
                    </div>
                    <div className="text-[11px] text-slate-400">
                      Code: {selectedGuardianDossier.family.familyCode} • Address: {selectedGuardianDossier.family.address || 'Household'}
                    </div>
                  </div>
                </div>
                <Badge variant="info">HOUSEHOLD MEMBER</Badge>
              </div>
            )}

            {/* Contact Details */}
            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-3">
              <h4 className="font-bold text-indigo-400 uppercase tracking-wider flex items-center gap-1.5">
                <Phone className="w-3.5 h-3.5" />
                <span>Contact Channels &amp; Emergency Dispatch</span>
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="flex justify-between border-b border-white/5 pb-1">
                  <span className="text-slate-400">Primary Phone:</span>
                  <span className="text-indigo-300 font-mono">{selectedGuardianDossier.phone}</span>
                </div>
                <div className="flex justify-between border-b border-white/5 pb-1">
                  <span className="text-slate-400">Alternate / WhatsApp:</span>
                  <span className="text-slate-300 font-mono">{selectedGuardianDossier.secondaryPhone || selectedGuardianDossier.whatsapp || '—'}</span>
                </div>
                <div className="flex justify-between border-b border-white/5 pb-1">
                  <span className="text-slate-400">Email Address:</span>
                  <span className="text-white font-mono">{selectedGuardianDossier.email || '—'}</span>
                </div>
                <div className="flex justify-between border-b border-white/5 pb-1">
                  <span className="text-slate-400">Secondary Emergency:</span>
                  <span className="text-white">{selectedGuardianDossier.emergencyContact || '—'}</span>
                </div>
                <div className="flex justify-between sm:col-span-2">
                  <span className="text-slate-400">Home Address:</span>
                  <span className="text-white text-right">{selectedGuardianDossier.address || '—'}</span>
                </div>
              </div>
            </div>

            {/* Enrolled Children (Siblings) */}
            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                  <GraduationCap className="w-3.5 h-3.5" />
                  <span>Enrolled Scholars &amp; Specific Permissions</span>
                </h4>
                <Button
                  size="xs"
                  variant="outline"
                  onClick={() => {
                    setGuardianToLink(selectedGuardianDossier);
                    setLinkStudentForm({
                      studentId: '',
                      relationshipType: selectedGuardianDossier.relationship || 'Father',
                      isPrimaryGuardian: true,
                      isSecondaryGuardian: false,
                      isEmergencyContact: true,
                      isAuthorizedAcademic: true,
                      isAuthorizedAttendance: true,
                      isAuthorizedFinancial: true,
                      isAuthorizedCommunication: true,
                      isPickupAuthorized: true
                    });
                    setIsLinkModalOpen(true);
                  }}
                >
                  <UserPlus className="w-3 h-3 mr-1" />
                  Attach Scholar
                </Button>
              </div>

              {(() => {
                const linkedStudents = students.filter(
                  (st) =>
                    selectedGuardianDossier.studentIds?.includes(st.id) ||
                    st.guardianId === selectedGuardianDossier.id
                );

                if (linkedStudents.length === 0) {
                  return (
                    <p className="text-slate-500 italic py-2">
                      No scholars are currently associated with this guardian profile.
                    </p>
                  );
                }

                return (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {linkedStudents.map((st) => {
                      const rel = (selectedGuardianDossier.relationships || []).find(
                        (r: any) => r.studentId === st.id
                      );

                      return (
                        <div
                          key={st.id}
                          className="p-3.5 rounded-xl bg-white/5 border border-white/10 space-y-2.5"
                        >
                          <div className="flex items-start justify-between gap-2">
                            <div>
                              <div className="font-bold text-white text-sm">
                                {st.firstName} {st.lastName}
                              </div>
                              <div className="text-[11px] text-slate-400">
                                {st.className} ({st.sectionName}) • Adm: {st.admissionNumber}
                              </div>
                              <div className="text-[10px] text-emerald-400 mt-0.5">Roll #{st.rollNumber}</div>
                            </div>

                            <div className="flex items-center gap-1">
                              <Button
                                size="xs"
                                variant="outline"
                                onClick={() => {
                                  setAuthModalState({
                                    isOpen: true,
                                    guardian: selectedGuardianDossier,
                                    student: st
                                  });
                                }}
                                title="Configure Specific Authorizations"
                              >
                                <Settings className="w-3 h-3" />
                              </Button>
                              <Button
                                size="xs"
                                variant="danger"
                                onClick={() => handleUnlinkStudent(selectedGuardianDossier.id, st.id)}
                                title="Unlink student from this guardian"
                              >
                                <Unlink className="w-3 h-3" />
                              </Button>
                            </div>
                          </div>

                          {/* Permission Badges */}
                          <div className="flex flex-wrap gap-1 pt-1 border-t border-white/5">
                            {rel?.isPrimaryGuardian && (
                              <span className="px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 text-[10px] font-bold">
                                Primary
                              </span>
                            )}
                            {rel?.isAuthorizedAcademic !== false && (
                              <span className="px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-300 text-[10px]">
                                Academics
                              </span>
                            )}
                            {rel?.isAuthorizedAttendance !== false && (
                              <span className="px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300 text-[10px]">
                                Attendance
                              </span>
                            )}
                            {rel?.isAuthorizedFinancial !== false && (
                              <span className="px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-300 text-[10px]">
                                Financial
                              </span>
                            )}
                            {rel?.isPickupAuthorized !== false && (
                              <span className="px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[10px]">
                                Pickup
                              </span>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                );
              })()}
            </div>

            <div className="flex flex-wrap justify-between items-center gap-2 pt-2 border-t border-white/10">
              <div className="flex items-center gap-2">
                <Button
                  size="sm"
                  variant="secondary"
                  onClick={() => {
                    setIsDossierOpen(false);
                    handleOpenEdit(selectedGuardianDossier);
                  }}
                >
                  <Edit2 className="w-3.5 h-3.5 mr-1.5" />
                  Edit Profile Record
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  className="border-indigo-500/30 text-indigo-300 hover:bg-indigo-500/10"
                  onClick={() => {
                    setSecurityModalGuardian(selectedGuardianDossier);
                  }}
                >
                  <KeyRound className="w-3.5 h-3.5 mr-1.5" />
                  Portal Account &amp; Security
                </Button>
                <Button
                  size="sm"
                  variant="primary"
                  className="bg-indigo-600 hover:bg-indigo-500 text-white font-semibold"
                  onClick={() => {
                    setSelectedGuardianForDocs(selectedGuardianDossier);
                  }}
                >
                  <FileText className="w-3.5 h-3.5 mr-1.5" />
                  Guardian Documents &amp; Verification
                </Button>
              </div>

              <Button
                size="sm"
                variant="outline"
                onClick={() => {
                  setIsDossierOpen(false);
                  setSelectedGuardianDossier(null);
                }}
              >
                Close Dossier
              </Button>
            </div>
          </div>
        </Modal>
      )}

      {/* Part 15E — Guardian Document Checklist & Verification Modal */}
      {selectedGuardianForDocs && (
        <EntityDocumentChecklistModal
          entityType="GUARDIAN"
          entityId={selectedGuardianForDocs.id}
          entityName={selectedGuardianForDocs.name}
          isOpen={!!selectedGuardianForDocs}
          onClose={() => setSelectedGuardianForDocs(null)}
          canVerify={true}
          onDocumentUpdated={onRefresh}
        />
      )}

      {/* LINK STUDENT MODAL */}
      {isLinkModalOpen && guardianToLink && (
        <Modal
          isOpen={isLinkModalOpen}
          onClose={() => {
            setIsLinkModalOpen(false);
            setGuardianToLink(null);
          }}
          title={`Attach Scholar to ${guardianToLink.name}`}
          description="Select an enrolled student and set initial custody and authorization attributes."
          size="md"
        >
          <form onSubmit={handleLinkStudentSubmit} className="space-y-4 text-xs">
            <Select
              id="select-student-to-link"
              label="Select Student from Directory *"
              options={[
                { value: '', label: '-- Choose a scholar --' },
                ...students
                  .filter((st) => !guardianToLink.studentIds?.includes(st.id))
                  .map((st) => ({
                    value: st.id,
                    label: `${st.firstName} ${st.lastName} (${st.className} - ${st.sectionName}) • Adm: ${st.admissionNumber}`
                  }))
              ]}
              value={linkStudentForm.studentId}
              onChange={(e) => setLinkStudentForm({ ...linkStudentForm, studentId: e.target.value })}
            />

            <Select
              id="link-rel-type"
              label="Relationship to Scholar"
              options={[
                { value: 'Father', label: 'Father' },
                { value: 'Mother', label: 'Mother' },
                { value: 'Legal Guardian', label: 'Legal Guardian' },
                { value: 'Sponsor', label: 'Financial Sponsor' },
                { value: 'Grandparent', label: 'Grandparent' },
                { value: 'Relative', label: 'Relative' }
              ]}
              value={linkStudentForm.relationshipType}
              onChange={(e) => setLinkStudentForm({ ...linkStudentForm, relationshipType: e.target.value })}
            />

            <div className="grid grid-cols-2 gap-2 pt-2 border-t border-white/5">
              <label className="flex items-center gap-2 p-2 rounded-lg bg-white/5 border border-white/5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={linkStudentForm.isPrimaryGuardian}
                  onChange={(e) =>
                    setLinkStudentForm({
                      ...linkStudentForm,
                      isPrimaryGuardian: e.target.checked,
                      isSecondaryGuardian: !e.target.checked
                    })
                  }
                  className="rounded text-indigo-600 focus:ring-indigo-500"
                />
                <div>
                  <div className="font-semibold text-white">Primary Guardian</div>
                  <div className="text-[10px] text-slate-400">Principal contact</div>
                </div>
              </label>

              <label className="flex items-center gap-2 p-2 rounded-lg bg-white/5 border border-white/5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={linkStudentForm.isAuthorizedFinancial}
                  onChange={(e) =>
                    setLinkStudentForm({ ...linkStudentForm, isAuthorizedFinancial: e.target.checked })
                  }
                  className="rounded text-indigo-600 focus:ring-indigo-500"
                />
                <div>
                  <div className="font-semibold text-white">Financial Sponsor</div>
                  <div className="text-[10px] text-slate-400">Bill payer</div>
                </div>
              </label>

              <label className="flex items-center gap-2 p-2 rounded-lg bg-white/5 border border-white/5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={linkStudentForm.isAuthorizedAcademic}
                  onChange={(e) =>
                    setLinkStudentForm({ ...linkStudentForm, isAuthorizedAcademic: e.target.checked })
                  }
                  className="rounded text-indigo-600 focus:ring-indigo-500"
                />
                <div>
                  <div className="font-semibold text-white">Academic Access</div>
                  <div className="text-[10px] text-slate-400">Grade reports</div>
                </div>
              </label>

              <label className="flex items-center gap-2 p-2 rounded-lg bg-white/5 border border-white/5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={linkStudentForm.isPickupAuthorized}
                  onChange={(e) =>
                    setLinkStudentForm({ ...linkStudentForm, isPickupAuthorized: e.target.checked })
                  }
                  className="rounded text-indigo-600 focus:ring-indigo-500"
                />
                <div>
                  <div className="font-semibold text-white">Pickup Authorized</div>
                  <div className="text-[10px] text-slate-400">Campus release</div>
                </div>
              </label>
            </div>

            <div className="flex justify-end gap-3 pt-3 border-t border-white/10">
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => {
                  setIsLinkModalOpen(false);
                  setGuardianToLink(null);
                }}
              >
                Cancel
              </Button>
              <Button
                id="btn-confirm-link-student"
                type="submit"
                variant="primary"
                size="sm"
                disabled={!linkStudentForm.studentId}
              >
                Confirm Link
              </Button>
            </div>
          </form>
        </Modal>
      )}

      {/* AUTHORIZATIONS MODAL */}
      <GuardianAuthorizationsModal
        isOpen={authModalState.isOpen}
        onClose={() =>
          setAuthModalState({
            isOpen: false,
            guardian: null,
            student: null
          })
        }
        guardian={authModalState.guardian}
        student={authModalState.student}
        onSaved={() => {
          onRefresh();
          if (selectedGuardianDossier) {
            api.users.getGuardian(selectedGuardianDossier.id).then((res) => {
              if (res.success && res.data) {
                setSelectedGuardianDossier(res.data);
              }
            });
          }
        }}
      />

      {/* INTEGRITY MODAL */}
      <GuardianIntegrityModal
        isOpen={isIntegrityModalOpen}
        onClose={() => setIsIntegrityModalOpen(false)}
        onHealed={() => {
          onRefresh();
          loadFamilies();
        }}
      />

      {/* GUARDIAN ACCOUNT SECURITY GOVERNANCE MODAL */}
      <GuardianAccountSecurityModal
        isOpen={Boolean(securityModalGuardian)}
        guardian={securityModalGuardian}
        onClose={() => setSecurityModalGuardian(null)}
        onSuccess={() => {
          onRefresh();
        }}
      />

      {/* DELETE CONFIRMATION DIALOG */}
      {guardianToDelete && (
        <ConfirmDialog
          isOpen={Boolean(guardianToDelete)}
          title={`Delete Guardian Profile — ${guardianToDelete.name}`}
          message={`Are you sure you want to remove the guardian record for ${guardianToDelete.name}? Any linked scholars will have their guardian reference cleared gracefully.`}
          confirmLabel="Permanently Delete"
          variant="danger"
          onConfirm={handleDeleteGuardian}
          onCancel={() => setGuardianToDelete(null)}
        />
      )}
    </div>
  );
};
