import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  DollarSign,
  AlertCircle,
  Clock,
  CheckCircle2,
  Calendar,
  Search,
  Filter,
  RefreshCw,
  Send,
  Download,
  Eye,
  CreditCard,
  Building,
  User,
  Users,
  Layers,
  ArrowUpRight,
  TrendingUp,
  AlertTriangle,
  ChevronRight,
  ShieldCheck,
  Mail,
  Phone,
  HelpCircle,
  FileSpreadsheet,
  Percent,
  SlidersHorizontal,
  ChevronLeft,
  X,
  History,
  FileText,
  Bell
} from 'lucide-react';
import {
  FeeDueDashboardStats,
  FeeDueStudentItem,
  FeeDueFilterParams,
  AcademicSession,
  SchoolClass,
  Section,
  FeeType,
  StudentFeeRecord,
  FeeReminderLog,
  DueAgingBracket,
  FeePaymentStatus
} from '../../types/index.js';
import { api } from '../../services/api.js';
import { useToast } from '../../context/ToastContext.js';
import { CollectFeeModal } from '../../components/fees/CollectFeeModal.js';
import { InvoiceViewModal } from '../../components/fees/InvoiceViewModal.js';
import { SendReminderModal } from '../../components/fees/SendReminderModal.js';
import { AssessLateFinesModal } from '../../components/fees/AssessLateFinesModal.js';

interface AdminDueManagementPageProps {
  activeTab?: 'students' | 'classes' | 'feetypes' | 'reminders';
  onTabChange?: (tab: 'students' | 'classes' | 'feetypes' | 'reminders') => void;
  hideTabBar?: boolean;
}

export const AdminDueManagementPage: React.FC<AdminDueManagementPageProps> = ({
  activeTab: propActiveTab,
  onTabChange,
  hideTabBar = true
}) => {
  const { showToast } = useToast();

  // Active Main Tab
  const [internalTab, setInternalTab] = useState<'students' | 'classes' | 'feetypes' | 'reminders'>('students');
  const activeTab = propActiveTab || internalTab;
  const setActiveTab = (tab: 'students' | 'classes' | 'feetypes' | 'reminders') => {
    setInternalTab(tab);
    onTabChange?.(tab);
  };

  // Master Data
  const [sessions, setSessions] = useState<AcademicSession[]>([]);
  const [selectedSessionId, setSelectedSessionId] = useState<string>('session-2026-2027');
  const [classes, setClasses] = useState<SchoolClass[]>([]);
  const [sections, setSections] = useState<Section[]>([]);
  const [feeTypes, setFeeTypes] = useState<FeeType[]>([]);

  // Statistics State
  const [stats, setStats] = useState<FeeDueDashboardStats | null>(null);
  const [isStatsLoading, setIsStatsLoading] = useState<boolean>(true);

  // Student Dues List State
  const [dueStudents, setDueStudents] = useState<FeeDueStudentItem[]>([]);
  const [isStudentsLoading, setIsStudentsLoading] = useState<boolean>(true);
  const [totalStudentsCount, setTotalStudentsCount] = useState<number>(0);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(15);
  const [totalPages, setTotalPages] = useState<number>(1);
  const [itemsSummary, setItemsSummary] = useState<any>(null);

  // Filters State
  const [selectedClassId, setSelectedClassId] = useState<string>('ALL');
  const [selectedSectionId, setSelectedSectionId] = useState<string>('ALL');
  const [selectedFeeTypeId, setSelectedFeeTypeId] = useState<string>('ALL');
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');
  const [selectedAgingBracket, setSelectedAgingBracket] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [sortBy, setSortBy] = useState<string>('daysOverdue');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
  const [minDue, setMinDue] = useState<string>('');
  const [maxDue, setMaxDue] = useState<string>('');
  const [dueDateFrom, setDueDateFrom] = useState<string>('');
  const [dueDateTo, setDueDateTo] = useState<string>('');

  // Bulk Selection
  const [selectedFeeItemIds, setSelectedFeeItemIds] = useState<string[]>([]);

  // Reminder Logs State
  const [reminderLogs, setReminderLogs] = useState<FeeReminderLog[]>([]);
  const [isLogsLoading, setIsLogsLoading] = useState<boolean>(false);
  const [reminderSearch, setReminderSearch] = useState<string>('');
  const [reminderChannelFilter, setReminderChannelFilter] = useState<string>('ALL');

  // Modals
  const [isCollectModalOpen, setIsCollectModalOpen] = useState<boolean>(false);
  const [collectTargetRecord, setCollectTargetRecord] = useState<StudentFeeRecord | null>(null);

  const [isInvoiceModalOpen, setIsInvoiceModalOpen] = useState<boolean>(false);
  const [invoiceModalNumber, setInvoiceModalNumber] = useState<string | null>(null);

  const [isReminderModalOpen, setIsReminderModalOpen] = useState<boolean>(false);
  const [reminderTargetItems, setReminderTargetItems] = useState<FeeDueStudentItem[]>([]);

  const [isAssessFinesModalOpen, setIsAssessFinesModalOpen] = useState<boolean>(false);

  // Load Initial Metadata (Sessions, Classes, Sections, Fee Types)
  useEffect(() => {
    async function loadMetadata() {
      try {
        const [sessRes, clsRes, secRes, ftRes] = await Promise.all([
          api.academic.getSessions().catch(() => ({ success: true, data: [] })),
          api.academic.getClasses().catch(() => ({ success: true, data: [] })),
          api.academic.getSections().catch(() => ({ success: true, data: [] })),
          api.fees.getFeeTypes().catch(() => ({ success: true, data: [] }))
        ]);

        if (sessRes.success && sessRes.data) setSessions(sessRes.data);
        if (clsRes.success && clsRes.data) setClasses(clsRes.data);
        if (secRes.success && secRes.data) setSections(secRes.data);
        if (ftRes.success && ftRes.data) setFeeTypes(ftRes.data);
      } catch (err) {
        console.error('Error loading metadata:', err);
      }
    }
    loadMetadata();
  }, []);

  // Fetch Dashboard Stats
  const fetchStats = useCallback(async () => {
    setIsStatsLoading(true);
    try {
      const res = await api.fees.getDueDashboardStats({
        academicSessionId: selectedSessionId !== 'ALL' ? selectedSessionId : undefined,
        classId: selectedClassId !== 'ALL' ? selectedClassId : undefined
      });
      if (res.success && res.data) {
        setStats(res.data);
      }
    } catch (err: any) {
      console.error('Failed to load due stats:', err);
    } finally {
      setIsStatsLoading(false);
    }
  }, [selectedSessionId, selectedClassId]);

  // Fetch Student Dues
  const fetchDueStudents = useCallback(async () => {
    setIsStudentsLoading(true);
    try {
      const params: FeeDueFilterParams = {
        academicSessionId: selectedSessionId !== 'ALL' ? selectedSessionId : undefined,
        classId: selectedClassId !== 'ALL' ? selectedClassId : undefined,
        sectionId: selectedSectionId !== 'ALL' ? selectedSectionId : undefined,
        feeTypeId: selectedFeeTypeId !== 'ALL' ? selectedFeeTypeId : undefined,
        status: selectedStatus !== 'ALL' ? selectedStatus : undefined,
        agingBracket: selectedAgingBracket !== 'ALL' ? (selectedAgingBracket as DueAgingBracket) : undefined,
        search: searchQuery.trim() ? searchQuery.trim() : undefined,
        minDueAmount: minDue ? parseFloat(minDue) : undefined,
        maxDueAmount: maxDue ? parseFloat(maxDue) : undefined,
        dueDateFrom: dueDateFrom || undefined,
        dueDateTo: dueDateTo || undefined,
        sortBy,
        sortOrder,
        page: currentPage,
        limit: pageSize
      };

      const res = await api.fees.getDueStudents(params);
      if (res.success && res.data) {
        setDueStudents(res.data.data || []);
        setTotalStudentsCount(res.data.total || 0);
        setTotalPages(res.data.totalPages || 1);
        setItemsSummary(res.data.summary || null);
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to load due records', 'error');
    } finally {
      setIsStudentsLoading(false);
    }
  }, [
    selectedSessionId,
    selectedClassId,
    selectedSectionId,
    selectedFeeTypeId,
    selectedStatus,
    selectedAgingBracket,
    searchQuery,
    minDue,
    maxDue,
    dueDateFrom,
    dueDateTo,
    sortBy,
    sortOrder,
    currentPage,
    pageSize,
    showToast
  ]);

  // Fetch Reminder Logs
  const fetchReminderLogs = useCallback(async () => {
    setIsLogsLoading(true);
    try {
      const res = await api.fees.getReminderLogs({
        search: reminderSearch.trim() ? reminderSearch.trim() : undefined,
        channel: reminderChannelFilter !== 'ALL' ? reminderChannelFilter : undefined,
        page: 1,
        limit: 50
      });
      if (res.success && res.data) {
        setReminderLogs(res.data);
      }
    } catch (err: any) {
      console.error('Failed to load reminder history:', err);
    } finally {
      setIsLogsLoading(false);
    }
  }, [reminderSearch, reminderChannelFilter]);

  // Trigger loads on parameter changes
  useEffect(() => {
    fetchStats();
  }, [fetchStats]);

  useEffect(() => {
    if (activeTab === 'students') {
      fetchDueStudents();
    } else if (activeTab === 'reminders') {
      fetchReminderLogs();
    }
  }, [activeTab, fetchDueStudents, fetchReminderLogs]);

  // Available sections for current class
  const filteredSections = useMemo(() => {
    if (selectedClassId === 'ALL') return sections;
    return sections.filter((s) => s.classId === selectedClassId);
  }, [sections, selectedClassId]);

  // Select all handler
  const handleSelectAll = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.checked) {
      const selectable = dueStudents.filter((i) => i.dueAmount > 0).map((i) => i.feeRecordId);
      setSelectedFeeItemIds(selectable);
    } else {
      setSelectedFeeItemIds([]);
    }
  };

  const handleToggleSelectOne = (id: string) => {
    setSelectedFeeItemIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  // Open single reminder modal
  const handleOpenSingleReminder = (item: FeeDueStudentItem) => {
    setReminderTargetItems([item]);
    setIsReminderModalOpen(true);
  };

  // Open bulk reminder modal
  const handleOpenBulkReminder = () => {
    const matched = dueStudents.filter((i) => selectedFeeItemIds.includes(i.feeRecordId));
    if (matched.length === 0) {
      showToast('Please select at least one student with outstanding due.', 'warning');
      return;
    }
    setReminderTargetItems(matched);
    setIsReminderModalOpen(true);
  };

  // Open Collect Payment Modal
  const handleOpenCollectModal = async (item: FeeDueStudentItem) => {
    try {
      const fullRecordRes = await api.fees.getStudentFeeById(item.feeRecordId);
      if (fullRecordRes.success && fullRecordRes.data && fullRecordRes.data.fee) {
        setCollectTargetRecord(fullRecordRes.data.fee);
        setIsCollectModalOpen(true);
      } else {
        // Fallback construct record
        const fallback: StudentFeeRecord = {
          id: item.feeRecordId,
          studentId: item.studentId,
          studentName: item.studentName,
          admissionNumber: item.admissionNumber,
          classId: item.classId,
          className: item.className,
          sectionId: item.sectionId,
          sectionName: item.sectionName,
          academicSessionId: item.academicSessionId,
          academicSessionName: item.academicSessionName,
          term: item.term || 'Current Term',
          feeType: item.feeType,
          title: item.feeTitle,
          description: item.feeTitle,
          invoiceNumber: item.invoiceNumber,
          totalAmount: item.totalAmount,
          discountAmount: item.discountAmount,
          scholarshipAmount: item.scholarshipAmount,
          waiverAmount: item.waiverAmount,
          fineAmount: item.fineAmount,
          netPayableAmount: item.netPayableAmount,
          paidAmount: item.paidAmount,
          dueAmount: item.dueAmount,
          dueDate: item.dueDate,
          status: item.status as FeePaymentStatus,
          createdAt: item.createdAt || new Date().toISOString(),
          updatedAt: item.createdAt || new Date().toISOString()
        };
        setCollectTargetRecord(fallback);
        setIsCollectModalOpen(true);
      }
    } catch (err: any) {
      showToast('Failed to open payment collector: ' + err.message, 'error');
    }
  };

  // Open View Invoice Modal
  const handleOpenInvoiceModal = (invoiceNum: string) => {
    setInvoiceModalNumber(invoiceNum);
    setIsInvoiceModalOpen(true);
  };

  // Export CSV
  const handleExportCSV = () => {
    if (dueStudents.length === 0) {
      showToast('No data available to export.', 'warning');
      return;
    }

    const headers = [
      'Student Name',
      'Admission No',
      'Roll No',
      'Class',
      'Section',
      'Invoice No',
      'Fee Type',
      'Original Amount',
      'Discount',
      'Scholarship',
      'Waiver',
      'Fine',
      'Net Payable',
      'Paid Amount',
      'Due Amount',
      'Due Date',
      'Days Overdue',
      'Aging Bracket',
      'Status',
      'Guardian Name',
      'Guardian Phone',
      'Guardian Email'
    ];

    const rows = dueStudents.map((i) => [
      `"${i.studentName}"`,
      `"${i.admissionNumber}"`,
      `"${i.rollNumber || ''}"`,
      `"${i.className}"`,
      `"${i.sectionName || ''}"`,
      `"${i.invoiceNumber}"`,
      `"${i.feeType}"`,
      i.totalAmount.toFixed(2),
      i.discountAmount.toFixed(2),
      i.scholarshipAmount.toFixed(2),
      i.waiverAmount.toFixed(2),
      i.fineAmount.toFixed(2),
      i.netPayableAmount.toFixed(2),
      i.paidAmount.toFixed(2),
      i.dueAmount.toFixed(2),
      `"${i.dueDate}"`,
      i.daysOverdue,
      `"${i.agingBracket}"`,
      `"${i.status}"`,
      `"${i.guardianName || ''}"`,
      `"${i.guardianPhone || ''}"`,
      `"${i.guardianEmail || ''}"`
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute(
      'download',
      `Fee_Due_Report_${new Date().toISOString().split('T')[0]}.csv`
    );
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    showToast(`Exported ${dueStudents.length} student due records to CSV.`, 'success');
  };

  // Reset Filters
  const handleResetFilters = () => {
    setSelectedClassId('ALL');
    setSelectedSectionId('ALL');
    setSelectedFeeTypeId('ALL');
    setSelectedStatus('ALL');
    setSelectedAgingBracket('ALL');
    setSearchQuery('');
    setMinDue('');
    setMaxDue('');
    setDueDateFrom('');
    setDueDateTo('');
    setCurrentPage(1);
  };

  return (
    <div id="admin-due-management-page" className="space-y-6 pb-12">
      {/* Top Header & Executive Toolbar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900/60 p-6 rounded-2xl border border-white/10 backdrop-blur-xl">
        <div className="space-y-1">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400 shadow-inner">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-xl md:text-2xl font-bold text-white tracking-tight flex items-center gap-2.5">
                Due, Overdue & Fee Tracking
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 font-medium">
                  Part 7E
                </span>
              </h1>
              <p className="text-xs md:text-sm text-slate-400">
                Monitor institutional fee receivables, overdue aging brackets, defaulter metrics & dispatch notices
              </p>
            </div>
          </div>
        </div>

        {/* Global Toolbar Actions */}
        <div className="flex flex-wrap items-center gap-2.5">
          {/* Academic Session Selector */}
          <div className="flex items-center gap-2 bg-slate-950/80 border border-white/10 rounded-xl px-3 py-1.5 text-xs text-slate-300">
            <Calendar className="w-3.5 h-3.5 text-indigo-400" />
            <select
              value={selectedSessionId}
              onChange={(e) => setSelectedSessionId(e.target.value)}
              className="bg-transparent border-none text-white focus:outline-none cursor-pointer pr-1"
            >
              <option value="ALL" className="bg-slate-900 text-white">
                All Sessions
              </option>
              {sessions.map((s) => (
                <option key={s.id} value={s.id} className="bg-slate-900 text-white">
                  {s.name}
                </option>
              ))}
            </select>
          </div>

          {/* Assess Late Fines Button */}
          <button
            onClick={() => setIsAssessFinesModalOpen(true)}
            className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-amber-600/20 hover:bg-amber-600/30 text-amber-300 border border-amber-500/30 text-xs font-semibold transition-all cursor-pointer shadow-sm"
            title="Scan past due invoices and assess dynamic late fines"
          >
            <ShieldCheck className="w-4 h-4" />
            <span>Assess Fines</span>
          </button>

          {/* Export CSV */}
          <button
            onClick={handleExportCSV}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10 text-xs font-medium transition-all cursor-pointer"
            title="Download CSV Ledger"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>

          {/* Refresh Button */}
          <button
            onClick={() => {
              fetchStats();
              if (activeTab === 'students') fetchDueStudents();
              if (activeTab === 'reminders') fetchReminderLogs();
              showToast('Data refreshed successfully', 'info');
            }}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10 text-xs font-medium transition-all cursor-pointer"
            title="Refresh Ledger Data"
          >
            <RefreshCw className={`w-4 h-4 ${isStatsLoading || isStudentsLoading ? 'animate-spin text-indigo-400' : ''}`} />
          </button>
        </div>
      </div>

      {/* 6 Executive KPI Dashboard Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-6 gap-3.5">
        {/* 1. Total Receivable */}
        <div className="bg-slate-900/70 border border-white/10 rounded-2xl p-4 relative overflow-hidden backdrop-blur-md flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
              Total Receivable
            </span>
            <div className="w-7 h-7 rounded-lg bg-blue-500/15 text-blue-400 flex items-center justify-center">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-xl font-black text-white tracking-tight">
              ${(stats?.totalReceivable || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
            <span className="text-[10px] text-slate-400 block mt-0.5">
              Across {stats?.totalActiveInvoices || 0} active invoices
            </span>
          </div>
        </div>

        {/* 2. Total Collected */}
        <div className="bg-slate-900/70 border border-emerald-500/20 rounded-2xl p-4 relative overflow-hidden backdrop-blur-md flex flex-col justify-between shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold text-emerald-400 uppercase tracking-wider">
              Total Collected
            </span>
            <div className="w-7 h-7 rounded-lg bg-emerald-500/15 text-emerald-400 flex items-center justify-center">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-xl font-black text-emerald-400 tracking-tight">
              ${(stats?.totalCollected || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
            <div className="flex items-center gap-1.5 mt-1">
              <div className="flex-1 bg-slate-950 rounded-full h-1.5 overflow-hidden">
                <div
                  className="bg-emerald-500 h-full rounded-full transition-all duration-500"
                  style={{ width: `${Math.min(100, stats?.collectionEfficiencyRate || 0)}%` }}
                />
              </div>
              <span className="text-[10px] font-bold text-emerald-400 shrink-0">
                {stats?.collectionEfficiencyRate || 0}%
              </span>
            </div>
          </div>
        </div>

        {/* 3. Total Due */}
        <div className="bg-slate-900/70 border border-amber-500/20 rounded-2xl p-4 relative overflow-hidden backdrop-blur-md flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold text-amber-400 uppercase tracking-wider">
              Total Due
            </span>
            <div className="w-7 h-7 rounded-lg bg-amber-500/15 text-amber-400 flex items-center justify-center">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-xl font-black text-amber-300 tracking-tight">
              ${(stats?.totalDue || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
            <span className="text-[10px] text-amber-400/80 block mt-0.5 font-medium">
              {stats?.dueSoonInvoicesCount || 0} due soon (≤ 7 days)
            </span>
          </div>
        </div>

        {/* 4. Total Overdue */}
        <div className="bg-slate-900/70 border border-rose-500/25 rounded-2xl p-4 relative overflow-hidden backdrop-blur-md flex flex-col justify-between shadow-lg shadow-rose-950/20">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold text-rose-400 uppercase tracking-wider">
              Total Overdue
            </span>
            <div className="w-7 h-7 rounded-lg bg-rose-500/15 text-rose-400 flex items-center justify-center animate-pulse">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-xl font-black text-rose-400 tracking-tight">
              ${(stats?.totalOverdue || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
            <span className="text-[10px] text-rose-400/80 block mt-0.5 font-semibold">
              {stats?.overdueInvoicesCount || 0} invoices past due date
            </span>
          </div>
        </div>

        {/* 5. Students With Due */}
        <div className="bg-slate-900/70 border border-white/10 rounded-2xl p-4 relative overflow-hidden backdrop-blur-md flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
              Students With Due
            </span>
            <div className="w-7 h-7 rounded-lg bg-indigo-500/15 text-indigo-400 flex items-center justify-center">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-xl font-black text-white tracking-tight">
              {stats?.studentsWithDueCount || 0}
            </span>
            <span className="text-[10px] text-slate-400 block mt-0.5">
              Carrying outstanding balances
            </span>
          </div>
        </div>

        {/* 6. Overdue Invoices Count */}
        <div className="bg-slate-900/70 border border-white/10 rounded-2xl p-4 relative overflow-hidden backdrop-blur-md flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
              Overdue Invoices
            </span>
            <div className="w-7 h-7 rounded-lg bg-purple-500/15 text-purple-400 flex items-center justify-center">
              <AlertCircle className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-xl font-black text-purple-300 tracking-tight">
              {stats?.overdueInvoicesCount || 0}
            </span>
            <span className="text-[10px] text-slate-400 block mt-0.5">
              Requires immediate notice
            </span>
          </div>
        </div>
      </div>

      {/* Interactive Aging Bracket Breakdown Cards */}
      {stats?.agingBreakdown && (
        <div className="bg-slate-900/50 p-4 rounded-2xl border border-white/10 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
              <SlidersHorizontal className="w-3.5 h-3.5 text-indigo-400" />
              Overdue Aging Bracket Distribution (Click to filter)
            </span>
            {selectedAgingBracket !== 'ALL' && (
              <button
                onClick={() => setSelectedAgingBracket('ALL')}
                className="text-[11px] text-indigo-400 hover:text-indigo-300 font-semibold underline cursor-pointer"
              >
                Clear Aging Filter ({(selectedAgingBracket || '').replace(/_/g, ' ')})
              </button>
            )}
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
            {/* Not Due */}
            <button
              type="button"
              onClick={() => {
                setSelectedAgingBracket(selectedAgingBracket === 'NOT_DUE' ? 'ALL' : 'NOT_DUE');
                setActiveTab('students');
              }}
              className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                selectedAgingBracket === 'NOT_DUE'
                  ? 'bg-blue-950/40 border-blue-500 ring-2 ring-blue-500/30'
                  : 'bg-slate-950/60 border-white/5 hover:border-white/20'
              }`}
            >
              <span className="text-[10px] font-bold text-blue-400 uppercase tracking-wider block">
                Not Due Yet (&gt; 7d)
              </span>
              <span className="text-sm font-black text-white mt-1 block">
                ${stats.agingBreakdown.notDueYet.amount.toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </span>
              <span className="text-[10px] text-slate-400 block mt-0.5">
                {stats.agingBreakdown.notDueYet.count} Invoices
              </span>
            </button>

            {/* Due Soon */}
            <button
              type="button"
              onClick={() => {
                setSelectedAgingBracket(selectedAgingBracket === 'DUE_SOON' ? 'ALL' : 'DUE_SOON');
                setActiveTab('students');
              }}
              className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                selectedAgingBracket === 'DUE_SOON'
                  ? 'bg-amber-950/40 border-amber-500 ring-2 ring-amber-500/30'
                  : 'bg-slate-950/60 border-white/5 hover:border-white/20'
              }`}
            >
              <span className="text-[10px] font-bold text-amber-400 uppercase tracking-wider block">
                Due Soon (≤ 7d)
              </span>
              <span className="text-sm font-black text-amber-300 mt-1 block">
                ${stats.agingBreakdown.dueSoon.amount.toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </span>
              <span className="text-[10px] text-slate-400 block mt-0.5">
                {stats.agingBreakdown.dueSoon.count} Invoices
              </span>
            </button>

            {/* 1-15 Days */}
            <button
              type="button"
              onClick={() => {
                setSelectedAgingBracket(selectedAgingBracket === '1_15_DAYS' ? 'ALL' : '1_15_DAYS');
                setActiveTab('students');
              }}
              className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                selectedAgingBracket === '1_15_DAYS'
                  ? 'bg-orange-950/40 border-orange-500 ring-2 ring-orange-500/30'
                  : 'bg-slate-950/60 border-white/5 hover:border-white/20'
              }`}
            >
              <span className="text-[10px] font-bold text-orange-400 uppercase tracking-wider block">
                Overdue 1–15 Days
              </span>
              <span className="text-sm font-black text-orange-300 mt-1 block">
                ${stats.agingBreakdown.overdue1to15.amount.toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </span>
              <span className="text-[10px] text-slate-400 block mt-0.5">
                {stats.agingBreakdown.overdue1to15.count} Invoices
              </span>
            </button>

            {/* 16-30 Days */}
            <button
              type="button"
              onClick={() => {
                setSelectedAgingBracket(selectedAgingBracket === '16_30_DAYS' ? 'ALL' : '16_30_DAYS');
                setActiveTab('students');
              }}
              className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                selectedAgingBracket === '16_30_DAYS'
                  ? 'bg-rose-950/40 border-rose-500 ring-2 ring-rose-500/30'
                  : 'bg-slate-950/60 border-white/5 hover:border-white/20'
              }`}
            >
              <span className="text-[10px] font-bold text-rose-400 uppercase tracking-wider block">
                Overdue 16–30 Days
              </span>
              <span className="text-sm font-black text-rose-300 mt-1 block">
                ${stats.agingBreakdown.overdue16to30.amount.toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </span>
              <span className="text-[10px] text-slate-400 block mt-0.5">
                {stats.agingBreakdown.overdue16to30.count} Invoices
              </span>
            </button>

            {/* 31-60 Days */}
            <button
              type="button"
              onClick={() => {
                setSelectedAgingBracket(selectedAgingBracket === '31_60_DAYS' ? 'ALL' : '31_60_DAYS');
                setActiveTab('students');
              }}
              className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                selectedAgingBracket === '31_60_DAYS'
                  ? 'bg-rose-950/60 border-rose-400 ring-2 ring-rose-400/40'
                  : 'bg-slate-950/60 border-white/5 hover:border-white/20'
              }`}
            >
              <span className="text-[10px] font-bold text-rose-300 uppercase tracking-wider block">
                Overdue 31–60 Days
              </span>
              <span className="text-sm font-black text-rose-200 mt-1 block">
                ${stats.agingBreakdown.overdue31to60.amount.toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </span>
              <span className="text-[10px] text-slate-400 block mt-0.5">
                {stats.agingBreakdown.overdue31to60.count} Invoices
              </span>
            </button>

            {/* 60+ Days */}
            <button
              type="button"
              onClick={() => {
                setSelectedAgingBracket(selectedAgingBracket === '60_PLUS_DAYS' ? 'ALL' : '60_PLUS_DAYS');
                setActiveTab('students');
              }}
              className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                selectedAgingBracket === '60_PLUS_DAYS'
                  ? 'bg-red-950/70 border-red-500 ring-2 ring-red-500/50'
                  : 'bg-slate-950/60 border-white/5 hover:border-white/20'
              }`}
            >
              <span className="text-[10px] font-bold text-red-400 uppercase tracking-wider block flex items-center gap-1">
                <AlertTriangle className="w-3 h-3 text-red-400" /> Overdue 60+ Days
              </span>
              <span className="text-sm font-black text-red-300 mt-1 block">
                ${stats.agingBreakdown.overdue60Plus.amount.toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </span>
              <span className="text-[10px] text-slate-400 block mt-0.5">
                {stats.agingBreakdown.overdue60Plus.count} Invoices
              </span>
            </button>
          </div>
        </div>
      )}

      {/* Navigation Tab Bar */}
      <div className="flex items-center justify-between border-b border-white/10 pb-1">
        {!hideTabBar && (
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('students')}
              className={`px-4 py-2.5 rounded-xl text-xs md:text-sm font-bold transition-all cursor-pointer flex items-center gap-2 ${
                activeTab === 'students'
                  ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/25'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <User className="w-4 h-4" />
              <span>Student-Wise Due Ledger</span>
              <span className="text-[11px] px-2 py-0.5 rounded-full bg-black/20 text-indigo-200">
                {totalStudentsCount}
              </span>
            </button>

            <button
              onClick={() => setActiveTab('classes')}
              className={`px-4 py-2.5 rounded-xl text-xs md:text-sm font-bold transition-all cursor-pointer flex items-center gap-2 ${
                activeTab === 'classes'
                  ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/25'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <Building className="w-4 h-4" />
              <span>Class-Wise Breakdown</span>
            </button>

            <button
              onClick={() => setActiveTab('feetypes')}
              className={`px-4 py-2.5 rounded-xl text-xs md:text-sm font-bold transition-all cursor-pointer flex items-center gap-2 ${
                activeTab === 'feetypes'
                  ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/25'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <Layers className="w-4 h-4" />
              <span>Fee Type Breakdown</span>
            </button>

            <button
              onClick={() => setActiveTab('reminders')}
              className={`px-4 py-2.5 rounded-xl text-xs md:text-sm font-bold transition-all cursor-pointer flex items-center gap-2 ${
                activeTab === 'reminders'
                  ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/25'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <History className="w-4 h-4" />
              <span>Reminder Audit Logs</span>
            </button>
          </div>
        )}

        {/* Bulk Reminder Trigger */}
        {activeTab === 'students' && (
          <div className="flex items-center gap-2">
            <button
              onClick={handleOpenBulkReminder}
              disabled={selectedFeeItemIds.length === 0}
              className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 disabled:hover:bg-indigo-600 text-white text-xs font-bold rounded-xl shadow-lg shadow-indigo-600/20 transition-all cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
              <span>
                Dispatch Reminders {selectedFeeItemIds.length > 0 ? `(${selectedFeeItemIds.length})` : ''}
              </span>
            </button>
          </div>
        )}
      </div>

      {/* TAB 1: STUDENT-WISE DUE LEDGER */}
      {activeTab === 'students' && (
        <div className="space-y-4">
          {/* Advanced Multi-Criteria Filter Bar */}
          <div className="bg-slate-900/70 border border-white/10 rounded-2xl p-4 space-y-3.5">
            {/* Row 1: Search & Primary Filters */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
              {/* Search */}
              <div className="lg:col-span-2 relative">
                <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => {
                    setSearchQuery(e.target.value);
                    setCurrentPage(1);
                  }}
                  placeholder="Search student, admission #, roll #, invoice #, parent, phone..."
                  className="w-full bg-slate-950/80 border border-white/10 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-indigo-500"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              {/* Class Filter */}
              <div>
                <select
                  value={selectedClassId}
                  onChange={(e) => {
                    setSelectedClassId(e.target.value);
                    setSelectedSectionId('ALL');
                    setCurrentPage(1);
                  }}
                  className="w-full bg-slate-950/80 border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500 cursor-pointer"
                >
                  <option value="ALL">All Classes</option>
                  {classes.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Section Filter */}
              <div>
                <select
                  value={selectedSectionId}
                  onChange={(e) => {
                    setSelectedSectionId(e.target.value);
                    setCurrentPage(1);
                  }}
                  disabled={selectedClassId === 'ALL'}
                  className="w-full bg-slate-950/80 border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500 cursor-pointer disabled:opacity-50"
                >
                  <option value="ALL">All Sections</option>
                  {filteredSections.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Fee Type Filter */}
              <div>
                <select
                  value={selectedFeeTypeId}
                  onChange={(e) => {
                    setSelectedFeeTypeId(e.target.value);
                    setCurrentPage(1);
                  }}
                  className="w-full bg-slate-950/80 border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500 cursor-pointer"
                >
                  <option value="ALL">All Fee Types</option>
                  {feeTypes.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Row 2: Status, Aging, Amount Range & Reset */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 items-center">
              {/* Payment Status */}
              <div>
                <select
                  value={selectedStatus}
                  onChange={(e) => {
                    setSelectedStatus(e.target.value);
                    setCurrentPage(1);
                  }}
                  className="w-full bg-slate-950/80 border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500 cursor-pointer"
                >
                  <option value="ALL">All Statuses</option>
                  <option value="OVERDUE">Overdue Only</option>
                  <option value="DUE_SOON">Due Soon Only</option>
                  <option value="PARTIAL">Partially Paid</option>
                  <option value="DUE">Outstanding Unpaid</option>
                  <option value="PAID">Fully Paid</option>
                </select>
              </div>

              {/* Overdue Aging Bracket */}
              <div>
                <select
                  value={selectedAgingBracket}
                  onChange={(e) => {
                    setSelectedAgingBracket(e.target.value);
                    setCurrentPage(1);
                  }}
                  className="w-full bg-slate-950/80 border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500 cursor-pointer"
                >
                  <option value="ALL">All Aging Brackets</option>
                  <option value="NOT_DUE">Not Due (&gt; 7d)</option>
                  <option value="DUE_SOON">Due Soon (≤ 7d)</option>
                  <option value="1_15_DAYS">1–15 Days Overdue</option>
                  <option value="16_30_DAYS">16–30 Days Overdue</option>
                  <option value="31_60_DAYS">31–60 Days Overdue</option>
                  <option value="60_PLUS_DAYS">60+ Days Overdue (Critical)</option>
                </select>
              </div>

              {/* Min Due Amount */}
              <div>
                <input
                  type="number"
                  placeholder="Min Due ($)"
                  value={minDue}
                  onChange={(e) => {
                    setMinDue(e.target.value);
                    setCurrentPage(1);
                  }}
                  className="w-full bg-slate-950/80 border border-white/10 rounded-xl px-3 py-2 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-indigo-500"
                />
              </div>

              {/* Max Due Amount */}
              <div>
                <input
                  type="number"
                  placeholder="Max Due ($)"
                  value={maxDue}
                  onChange={(e) => {
                    setMaxDue(e.target.value);
                    setCurrentPage(1);
                  }}
                  className="w-full bg-slate-950/80 border border-white/10 rounded-xl px-3 py-2 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-indigo-500"
                />
              </div>

              {/* Sort By */}
              <div>
                <select
                  value={`${sortBy}-${sortOrder}`}
                  onChange={(e) => {
                    const [sb, so] = e.target.value.split('-');
                    setSortBy(sb);
                    setSortOrder(so as 'asc' | 'desc');
                  }}
                  className="w-full bg-slate-950/80 border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500 cursor-pointer"
                >
                  <option value="daysOverdue-desc">Days Overdue (Highest First)</option>
                  <option value="dueAmount-desc">Due Amount (Highest First)</option>
                  <option value="dueDate-asc">Due Date (Earliest First)</option>
                  <option value="studentName-asc">Student Name (A-Z)</option>
                  <option value="className-asc">Class (Ascending)</option>
                </select>
              </div>

              {/* Reset Filters */}
              <div>
                <button
                  type="button"
                  onClick={handleResetFilters}
                  className="w-full py-2 px-3 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-medium border border-white/10 transition-all cursor-pointer text-center"
                >
                  Reset Filters
                </button>
              </div>
            </div>
          </div>

          {/* Student Dues Table */}
          <div className="bg-slate-900/80 border border-white/10 rounded-2xl overflow-hidden shadow-2xl backdrop-blur-xl">
            {isStudentsLoading ? (
              <div className="py-20 text-center space-y-3">
                <RefreshCw className="w-8 h-8 text-indigo-400 animate-spin mx-auto" />
                <p className="text-sm text-slate-400 font-medium">Loading student fee dues ledger...</p>
              </div>
            ) : dueStudents.length === 0 ? (
              <div className="py-20 text-center space-y-3">
                <div className="w-12 h-12 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center mx-auto text-slate-400">
                  <CheckCircle2 className="w-6 h-6 text-emerald-400" />
                </div>
                <h3 className="text-base font-bold text-white">No Outstanding Dues Found</h3>
                <p className="text-xs text-slate-400 max-w-sm mx-auto">
                  No records match the current filter criteria or all student invoices are settled.
                </p>
                <button
                  onClick={handleResetFilters}
                  className="px-4 py-2 bg-white/10 hover:bg-white/15 text-white text-xs font-semibold rounded-xl transition-all cursor-pointer mt-2"
                >
                  Reset All Filters
                </button>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-slate-950/80 border-b border-white/10 text-slate-400 font-semibold uppercase tracking-wider text-[10px]">
                      <th className="p-3.5 w-10 text-center">
                        <input
                          type="checkbox"
                          onChange={handleSelectAll}
                          checked={
                            dueStudents.length > 0 &&
                            dueStudents
                              .filter((i) => i.dueAmount > 0)
                              .every((i) => selectedFeeItemIds.includes(i.feeRecordId))
                          }
                          className="rounded border-slate-700 bg-slate-900 text-indigo-600 focus:ring-0 cursor-pointer"
                        />
                      </th>
                      <th className="p-3.5 min-w-[180px]">Student Details</th>
                      <th className="p-3.5 min-w-[110px]">Class / Sec</th>
                      <th className="p-3.5 min-w-[170px]">Invoice & Fee Type</th>
                      <th className="p-3.5 text-right min-w-[90px]">Original</th>
                      <th className="p-3.5 text-right min-w-[90px]">Concession</th>
                      <th className="p-3.5 text-right min-w-[70px]">Fine</th>
                      <th className="p-3.5 text-right min-w-[90px]">Paid</th>
                      <th className="p-3.5 text-right min-w-[100px]">Due Balance</th>
                      <th className="p-3.5 min-w-[110px]">Due Date</th>
                      <th className="p-3.5 min-w-[120px]">Aging Status</th>
                      <th className="p-3.5 min-w-[150px]">Guardian Contact</th>
                      <th className="p-3.5 text-right min-w-[140px]">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {dueStudents.map((item) => {
                      const totalConcession =
                        item.discountAmount + item.scholarshipAmount + item.waiverAmount;
                      const isSelected = selectedFeeItemIds.includes(item.feeRecordId);

                      return (
                        <tr
                          key={item.feeRecordId}
                          className={`hover:bg-white/[0.03] transition-colors ${
                            isSelected ? 'bg-indigo-950/20' : ''
                          }`}
                        >
                          {/* Select Checkbox */}
                          <td className="p-3.5 text-center">
                            <input
                              type="checkbox"
                              checked={isSelected}
                              onChange={() => handleToggleSelectOne(item.feeRecordId)}
                              disabled={item.dueAmount === 0}
                              className="rounded border-slate-700 bg-slate-900 text-indigo-600 focus:ring-0 cursor-pointer disabled:opacity-30"
                            />
                          </td>

                          {/* Student Info */}
                          <td className="p-3.5">
                            <div className="flex items-center gap-2.5">
                              <div className="w-8 h-8 rounded-full bg-slate-800 border border-white/10 flex items-center justify-center text-xs font-bold text-white shrink-0">
                                {item.studentName.charAt(0)}
                              </div>
                              <div>
                                <span className="font-bold text-white block hover:text-indigo-400 transition-colors">
                                  {item.studentName}
                                </span>
                                <div className="flex items-center gap-2 text-[10px] text-slate-400">
                                  <span>{item.admissionNumber}</span>
                                  {item.rollNumber && (
                                    <>
                                      <span>•</span>
                                      <span>Roll #{item.rollNumber}</span>
                                    </>
                                  )}
                                </div>
                              </div>
                            </div>
                          </td>

                          {/* Class / Section */}
                          <td className="p-3.5">
                            <span className="font-medium text-slate-200 block">{item.className}</span>
                            <span className="text-[10px] text-slate-400 block">{item.sectionName || 'All Sections'}</span>
                          </td>

                          {/* Invoice & Fee Title */}
                          <td className="p-3.5">
                            <button
                              onClick={() => handleOpenInvoiceModal(item?.invoiceNumber || item?.id || '')}
                              className="font-mono text-xs font-bold text-indigo-400 hover:text-indigo-300 hover:underline flex items-center gap-1 cursor-pointer"
                            >
                              <FileText className="w-3 h-3" />
                              {item?.invoiceNumber || item?.id || 'INV-2026'}
                            </button>
                            <span className="text-[10px] text-slate-300 block truncate max-w-[160px]" title={item.feeTitle}>
                              {item.feeTitle}
                            </span>
                            <span className="text-[9px] px-1.5 py-0.2 rounded bg-white/5 text-slate-400 border border-white/5 inline-block mt-0.5">
                              {item.feeType}
                            </span>
                          </td>

                          {/* Original Amount */}
                          <td className="p-3.5 text-right font-medium text-slate-300">
                            ${item.totalAmount.toFixed(2)}
                          </td>

                          {/* Concession */}
                          <td className="p-3.5 text-right">
                            {totalConcession > 0 ? (
                              <span
                                className="text-emerald-400 font-medium cursor-help"
                                title={`Discount: $${item.discountAmount.toFixed(2)}, Scholarship: $${item.scholarshipAmount.toFixed(2)}, Waiver: $${item.waiverAmount.toFixed(2)}`}
                              >
                                -${totalConcession.toFixed(2)}
                              </span>
                            ) : (
                              <span className="text-slate-500">$0.00</span>
                            )}
                          </td>

                          {/* Late Fine */}
                          <td className="p-3.5 text-right">
                            {item.fineAmount > 0 ? (
                              <span className="text-rose-400 font-medium">+${item.fineAmount.toFixed(2)}</span>
                            ) : (
                              <span className="text-slate-500">$0.00</span>
                            )}
                          </td>

                          {/* Paid */}
                          <td className="p-3.5 text-right font-medium text-emerald-400">
                            ${item.paidAmount.toFixed(2)}
                          </td>

                          {/* Due Balance */}
                          <td className="p-3.5 text-right">
                            {item.dueAmount > 0 ? (
                              <span className="font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-lg border border-amber-500/20">
                                ${item.dueAmount.toFixed(2)}
                              </span>
                            ) : (
                              <span className="font-bold text-emerald-400">Paid ($0.00)</span>
                            )}
                          </td>

                          {/* Due Date */}
                          <td className="p-3.5">
                            <span className="font-medium text-slate-200 block">{item.dueDate}</span>
                            <span className="text-[10px] text-slate-400 block">{item.term || 'Fall Term'}</span>
                          </td>

                          {/* Aging Status Badge */}
                          <td className="p-3.5">
                            {item.dueAmount === 0 ? (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                                <CheckCircle2 className="w-3 h-3" /> Paid in Full
                              </span>
                            ) : item.daysOverdue > 0 ? (
                              <div className="space-y-1">
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/15 text-rose-300 border border-rose-500/30">
                                  <AlertTriangle className="w-3 h-3" /> Overdue {item.daysOverdue}d
                                </span>
                                <span className="text-[9px] text-rose-400 block font-medium">
                                  {(item.agingBracket || '').replace(/_/g, ' ')}
                                </span>
                              </div>
                            ) : item.isDueSoon ? (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/15 text-amber-300 border border-amber-500/30">
                                <Clock className="w-3 h-3" /> Due Soon
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-500/15 text-blue-300 border border-blue-500/30">
                                Upcoming Due
                              </span>
                            )}
                          </td>

                          {/* Guardian Contact */}
                          <td className="p-3.5">
                            {item.guardianName ? (
                              <div>
                                <span className="font-medium text-slate-200 block truncate max-w-[140px]">
                                  {item.guardianName}
                                </span>
                                {item.guardianPhone && (
                                  <span className="text-[10px] text-slate-400 flex items-center gap-1">
                                    <Phone className="w-2.5 h-2.5" />
                                    {item.guardianPhone}
                                  </span>
                                )}
                              </div>
                            ) : (
                              <span className="text-slate-500 text-[10px]">No linked guardian</span>
                            )}
                          </td>

                          {/* Actions */}
                          <td className="p-3.5 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              {/* Collect Fee */}
                              {item.dueAmount > 0 && (
                                <button
                                  onClick={() => handleOpenCollectModal(item)}
                                  className="p-1.5 rounded-lg bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-400 border border-emerald-500/30 transition-all cursor-pointer"
                                  title="Collect Payment"
                                >
                                  <CreditCard className="w-3.5 h-3.5" />
                                </button>
                              )}

                              {/* Send Reminder */}
                              {item.dueAmount > 0 && (
                                <button
                                  onClick={() => handleOpenSingleReminder(item)}
                                  className="p-1.5 rounded-lg bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/30 transition-all cursor-pointer"
                                  title="Send Due Reminder"
                                >
                                  <Bell className="w-3.5 h-3.5" />
                                </button>
                              )}

                              {/* View Invoice */}
                              <button
                                onClick={() => handleOpenInvoiceModal(item?.invoiceNumber || item?.id || '')}
                                className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10 transition-all cursor-pointer"
                                title="View Itemized Invoice"
                              >
                                <Eye className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}

            {/* Pagination & Filter Summary Footer */}
            <div className="p-4 bg-slate-950/90 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
              <div className="text-slate-400">
                Showing{' '}
                <span className="font-bold text-white">
                  {dueStudents.length > 0 ? (currentPage - 1) * pageSize + 1 : 0}
                </span>{' '}
                to{' '}
                <span className="font-bold text-white">
                  {Math.min(currentPage * pageSize, totalStudentsCount)}
                </span>{' '}
                of <span className="font-bold text-white">{totalStudentsCount}</span> invoices
                {itemsSummary && (
                  <span className="ml-3 text-slate-400 border-l border-white/10 pl-3">
                    Filtered Due: <strong className="text-amber-400">${itemsSummary.totalDue?.toFixed(2) || '0.00'}</strong> (Overdue: <strong className="text-rose-400">${itemsSummary.totalOverdue?.toFixed(2) || '0.00'}</strong>)
                  </span>
                )}
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                  disabled={currentPage <= 1 || isStudentsLoading}
                  className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10 disabled:opacity-40 cursor-pointer"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <span className="px-3 py-1 bg-white/5 border border-white/10 rounded-lg text-white font-medium text-xs">
                  Page {currentPage} of {totalPages}
                </span>
                <button
                  onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                  disabled={currentPage >= totalPages || isStudentsLoading}
                  className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10 disabled:opacity-40 cursor-pointer"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: CLASS-WISE DUE BREAKDOWN MATRIX */}
      {activeTab === 'classes' && (
        <div className="space-y-4">
          <div className="bg-slate-900/80 border border-white/10 rounded-2xl overflow-hidden shadow-2xl backdrop-blur-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-base font-bold text-white">Class-Wise Fee Collection & Due Matrix</h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Aggregate billing, collection percentages, and student defaulter ratios by grade level
                </p>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-950/80 border-b border-white/10 text-slate-400 font-semibold uppercase tracking-wider text-[10px]">
                    <th className="p-3.5">Class / Grade</th>
                    <th className="p-3.5 text-center">Enrolled</th>
                    <th className="p-3.5 text-center">Students With Due</th>
                    <th className="p-3.5 min-w-[140px]">Defaulter Rate</th>
                    <th className="p-3.5 text-right">Invoiced ($)</th>
                    <th className="p-3.5 text-right">Collected ($)</th>
                    <th className="p-3.5 text-right">Due Balance ($)</th>
                    <th className="p-3.5 text-right">Overdue ($)</th>
                    <th className="p-3.5 min-w-[140px]">Collection Rate</th>
                    <th className="p-3.5 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {(stats?.classWiseBreakdown || []).map((cls, idx) => (
                    <tr key={`${cls.classId}-${idx}`} className="hover:bg-white/[0.03] transition-colors">
                      <td className="p-3.5 font-bold text-white flex items-center gap-2">
                        <Building className="w-4 h-4 text-indigo-400" />
                        {cls.className}
                      </td>
                      <td className="p-3.5 text-center font-medium text-slate-300">{cls.totalStudents}</td>
                      <td className="p-3.5 text-center">
                        <span
                          className={`font-bold px-2 py-0.5 rounded-full text-xs ${
                            cls.totalStudentsWithDue > 0
                              ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                              : 'bg-emerald-500/15 text-emerald-300'
                          }`}
                        >
                          {cls.totalStudentsWithDue}
                        </span>
                      </td>
                      {/* Defaulter Rate */}
                      <td className="p-3.5">
                        <div className="flex items-center gap-2">
                          <div className="flex-1 bg-slate-950 rounded-full h-1.5 overflow-hidden">
                            <div
                              className={`h-full rounded-full ${
                                cls.defaulterRate > 40 ? 'bg-rose-500' : cls.defaulterRate > 20 ? 'bg-amber-500' : 'bg-blue-500'
                              }`}
                              style={{ width: `${Math.min(100, cls.defaulterRate)}%` }}
                            />
                          </div>
                          <span className="text-[11px] font-bold text-slate-300 w-10 text-right">
                            {cls.defaulterRate}%
                          </span>
                        </div>
                      </td>

                      {/* Invoiced */}
                      <td className="p-3.5 text-right font-medium text-slate-300">
                        ${cls.totalReceivable.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                      </td>

                      {/* Collected */}
                      <td className="p-3.5 text-right font-bold text-emerald-400">
                        ${cls.totalCollected.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                      </td>

                      {/* Due Balance */}
                      <td className="p-3.5 text-right font-bold text-amber-400">
                        ${cls.totalDue.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                      </td>

                      {/* Overdue */}
                      <td className="p-3.5 text-right font-bold text-rose-400">
                        ${cls.totalOverdue.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                      </td>

                      {/* Collection Rate */}
                      <td className="p-3.5">
                        <div className="flex items-center gap-2">
                          <div className="flex-1 bg-slate-950 rounded-full h-1.5 overflow-hidden">
                            <div
                              className="bg-emerald-500 h-full rounded-full transition-all duration-500"
                              style={{ width: `${Math.min(100, cls.collectionRate)}%` }}
                            />
                          </div>
                          <span className="text-[11px] font-bold text-emerald-400 w-10 text-right">
                            {cls.collectionRate}%
                          </span>
                        </div>
                      </td>

                      {/* Filter Link */}
                      <td className="p-3.5 text-right">
                        <button
                          onClick={() => {
                            setSelectedClassId(cls.classId);
                            setActiveTab('students');
                          }}
                          className="px-2.5 py-1 rounded-lg bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/30 text-xs font-semibold transition-all cursor-pointer inline-flex items-center gap-1"
                        >
                          <span>View Students</span>
                          <ArrowUpRight className="w-3 h-3" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: FEE TYPE DUE BREAKDOWN MATRIX */}
      {activeTab === 'feetypes' && (
        <div className="space-y-4">
          <div className="bg-slate-900/80 border border-white/10 rounded-2xl overflow-hidden shadow-2xl backdrop-blur-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-base font-bold text-white">Fee Category & Head Breakdown</h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Financial performance, invoiced vs collected totals per academic and extracurricular fee head
                </p>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-950/80 border-b border-white/10 text-slate-400 font-semibold uppercase tracking-wider text-[10px]">
                    <th className="p-3.5">Fee Type Head</th>
                    <th className="p-3.5 text-center">Invoices Count</th>
                    <th className="p-3.5 text-right">Total Invoiced ($)</th>
                    <th className="p-3.5 text-right">Collected ($)</th>
                    <th className="p-3.5 text-right">Outstanding Due ($)</th>
                    <th className="p-3.5 text-right">Past Due Overdue ($)</th>
                    <th className="p-3.5 min-w-[160px]">Collection Efficiency</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {(stats?.feeTypeBreakdown || []).map((ft) => (
                    <tr key={ft.feeTypeName} className="hover:bg-white/[0.03] transition-colors">
                      <td className="p-3.5">
                        <span className="font-bold text-white block">{ft.feeTypeName}</span>
                        <span className="text-[10px] text-slate-400 block font-mono">{ft.feeTypeCode}</span>
                      </td>
                      <td className="p-3.5 text-center font-medium text-slate-300">{ft.totalInvoicesCount}</td>
                      <td className="p-3.5 text-right font-medium text-slate-300">
                        ${ft.totalInvoiced.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                      </td>
                      <td className="p-3.5 text-right font-bold text-emerald-400">
                        ${ft.totalCollected.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                      </td>
                      <td className="p-3.5 text-right font-bold text-amber-400">
                        ${ft.totalDue.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                      </td>
                      <td className="p-3.5 text-right font-bold text-rose-400">
                        ${ft.totalOverdue.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                      </td>
                      <td className="p-3.5">
                        <div className="flex items-center gap-2">
                          <div className="flex-1 bg-slate-950 rounded-full h-1.5 overflow-hidden">
                            <div
                              className="bg-emerald-500 h-full rounded-full transition-all duration-500"
                              style={{ width: `${Math.min(100, ft.collectionRate)}%` }}
                            />
                          </div>
                          <span className="text-[11px] font-bold text-emerald-400 w-12 text-right">
                            {ft.collectionRate}%
                          </span>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: REMINDER DISPATCH AUDIT LOGS */}
      {activeTab === 'reminders' && (
        <div className="space-y-4">
          <div className="bg-slate-900/80 border border-white/10 rounded-2xl overflow-hidden shadow-2xl backdrop-blur-xl p-6 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-base font-bold text-white">Fee Due Notice Dispatch History</h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Verifiable audit log of in-app reminders, statements and demand notices sent to parents
                </p>
              </div>

              {/* Filter Bar */}
              <div className="flex items-center gap-2">
                <div className="relative">
                  <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    value={reminderSearch}
                    onChange={(e) => setReminderSearch(e.target.value)}
                    placeholder="Search logs..."
                    className="bg-slate-950/80 border border-white/10 rounded-xl pl-8 pr-3 py-1.5 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <select
                  value={reminderChannelFilter}
                  onChange={(e) => setReminderChannelFilter(e.target.value)}
                  className="bg-slate-950/80 border border-white/10 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-indigo-500 cursor-pointer"
                >
                  <option value="ALL">All Channels</option>
                  <option value="IN_APP_NOTIFICATION">In-App Alerts</option>
                  <option value="EMAIL_PREVIEW">Email Notices</option>
                  <option value="SMS_PREVIEW">SMS Notices</option>
                </select>
              </div>
            </div>

            {isLogsLoading ? (
              <div className="py-16 text-center space-y-2">
                <RefreshCw className="w-6 h-6 text-indigo-400 animate-spin mx-auto" />
                <p className="text-xs text-slate-400">Loading reminder logs...</p>
              </div>
            ) : reminderLogs.length === 0 ? (
              <div className="py-16 text-center text-slate-400 text-xs">
                No reminder logs found matching your filter criteria.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-slate-950/80 border-b border-white/10 text-slate-400 font-semibold uppercase tracking-wider text-[10px]">
                      <th className="p-3">Timestamp</th>
                      <th className="p-3">Invoice & Student</th>
                      <th className="p-3">Guardian Recipient</th>
                      <th className="p-3">Channel / Type</th>
                      <th className="p-3">Subject / Headline</th>
                      <th className="p-3 text-right">Balance At Send</th>
                      <th className="p-3">Dispatched By</th>
                      <th className="p-3 text-center">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {reminderLogs.map((log) => (
                      <tr key={log.id} className="hover:bg-white/[0.02]">
                        <td className="p-3 text-slate-300 font-mono text-[11px]">
                          {new Date(log.sentAt).toLocaleString()}
                        </td>
                        <td className="p-3">
                          <span className="font-bold text-white block">{log.studentName}</span>
                          <span className="text-[10px] text-indigo-400 font-mono">
                            {log.invoiceNumber} • {log.className}
                          </span>
                        </td>
                        <td className="p-3">
                          <span className="text-slate-200 block font-medium">{log.guardianName || 'Guardian'}</span>
                          <span className="text-[10px] text-slate-400">{log.recipientContact}</span>
                        </td>
                        <td className="p-3">
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-500/15 text-indigo-300 border border-indigo-500/25 inline-block">
                            {(log.channel || 'EMAIL').replace(/_/g, ' ')}
                          </span>
                          <span className="text-[9px] text-slate-400 block mt-0.5">
                            {(log.reminderType || 'REMINDER').replace(/_/g, ' ')}
                          </span>
                        </td>
                        <td className="p-3">
                          <span className="text-slate-200 font-medium block truncate max-w-[200px]" title={log.title}>
                            {log.title}
                          </span>
                          <span className="text-[10px] text-slate-400 block truncate max-w-[200px]" title={log.message}>
                            {log.message}
                          </span>
                        </td>
                        <td className="p-3 text-right font-bold text-amber-400">
                          ${log.dueAmountAtSend.toFixed(2)}
                          {log.daysOverdueAtSend > 0 && (
                            <span className="text-[9px] text-rose-400 block font-normal">
                              ({log.daysOverdueAtSend}d overdue)
                            </span>
                          )}
                        </td>
                        <td className="p-3 text-slate-300 font-medium">
                          {log.sentByName}
                          <span className="text-[9px] text-slate-500 block">{log.sentByRole}</span>
                        </td>
                        <td className="p-3 text-center">
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
                            <CheckCircle2 className="w-2.5 h-2.5" /> Delivered
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Integrated Modal: Collect Fee Payment */}
      <CollectFeeModal
        isOpen={isCollectModalOpen}
        onClose={() => {
          setIsCollectModalOpen(false);
          setCollectTargetRecord(null);
        }}
        feeRecord={collectTargetRecord}
        onPaymentSuccess={() => {
          showToast('Payment collected and balance updated successfully!', 'success');
          fetchStats();
          fetchDueStudents();
        }}
      />

      {/* Integrated Modal: View Invoice */}
      <InvoiceViewModal
        isOpen={isInvoiceModalOpen}
        onClose={() => {
          setIsInvoiceModalOpen(false);
          setInvoiceModalNumber(null);
        }}
        invoiceNumber={invoiceModalNumber}
        onCollectPayment={(record) => {
          setIsInvoiceModalOpen(false);
          setCollectTargetRecord(record);
          setIsCollectModalOpen(true);
        }}
      />

      {/* Integrated Modal: Send Due Reminders */}
      <SendReminderModal
        isOpen={isReminderModalOpen}
        onClose={() => {
          setIsReminderModalOpen(false);
          setReminderTargetItems([]);
        }}
        selectedItems={reminderTargetItems}
        onSuccess={() => {
          fetchStats();
          fetchDueStudents();
          if (activeTab === 'reminders') fetchReminderLogs();
        }}
      />

      {/* Integrated Modal: Assess Late Fines */}
      <AssessLateFinesModal
        isOpen={isAssessFinesModalOpen}
        onClose={() => setIsAssessFinesModalOpen(false)}
        onSuccess={() => {
          fetchStats();
          fetchDueStudents();
        }}
      />
    </div>
  );
};
