import React from 'react';
import { ShieldCheck, Lock, CheckCircle2, XCircle, AlertTriangle, Sparkles } from 'lucide-react';
import { Badge } from '../../components/ui/Badge.js';
import { ALL_PERMISSIONS, UserRole } from '../../types/index.js';

export const RbacPermissionsPage: React.FC = () => {
  const roles: { role: UserRole; name: string; description: string; badgeVariant: 'danger' | 'primary' | 'success' }[] = [
    {
      role: 'SUPER_ADMIN',
      name: 'Super Admin',
      description: 'Root access over institutional entities, audit logs, configuration, and user provisioning.',
      badgeVariant: 'danger'
    },
    {
      role: 'TEACHER',
      name: 'Teacher / Faculty',
      description: 'Access scoped strictly to assigned classes, student rosters, subject curriculum, and attendance.',
      badgeVariant: 'primary'
    },
    {
      role: 'STUDENT',
      name: 'Student',
      description: 'Access restricted strictly to own academic enrollment, enrolled subjects, routine, and bio.',
      badgeVariant: 'success'
    }
  ];

  const permissionsList = [
    {
      perm: 'USERS_READ',
      label: 'Read User Accounts',
      admin: true,
      teacher: true,
      student: false,
      desc: 'View faculty and student profiles in the portal directory'
    },
    {
      perm: 'USERS_MANAGE',
      label: 'Manage & Provision Users',
      admin: true,
      teacher: false,
      student: false,
      desc: 'Create, update, and deactivate user accounts'
    },
    {
      perm: 'ACADEMICS_MANAGE',
      label: 'Academic Sessions & Classes',
      admin: true,
      teacher: false,
      student: false,
      desc: 'Manage sessions, grades, sections, and global curriculum'
    },
    {
      perm: 'TEACHER_CLASSES_VIEW',
      label: 'Assigned Classroom Access',
      admin: true,
      teacher: true,
      student: false,
      desc: 'View sections and student rosters assigned to the instructor'
    },
    {
      perm: 'STUDENT_PORTAL_VIEW',
      label: 'Student Workspace Access',
      admin: true,
      teacher: false,
      student: true,
      desc: 'View student profile, enrolled subjects, and class routine'
    },
    {
      perm: 'AUDIT_LOGS_VIEW',
      label: 'Audit Trail Telemetry',
      admin: true,
      teacher: false,
      student: false,
      desc: 'Inspect real-time security audit trails and actor signatures'
    },
    {
      perm: 'SETTINGS_MANAGE',
      label: 'School System Configuration',
      admin: true,
      teacher: false,
      student: false,
      desc: 'Modify institution profile, affiliation, and operational parameters'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-6 sm:p-8 shadow-xl shadow-black/20">
        <div className="flex items-center gap-2 text-indigo-400 text-xs font-bold uppercase tracking-wider mb-1">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Security Architecture &amp; Governance</span>
        </div>
        <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
          Role-Based Access Control (RBAC) Matrix
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          Cryptographic token verification and granular server-side capability gates prevent privilege escalation.
        </p>
      </div>

      {/* Role Cards Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {(roles || []).map((r) => (
          <div
            key={r.role}
            className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-5 shadow-lg shadow-black/20 space-y-3"
          >
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-white text-base">{r.name}</h3>
              <Badge variant={r.badgeVariant}>{r.role}</Badge>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">{r.description}</p>
          </div>
        ))}
      </div>

      {/* Permission Matrix Table */}
      <div className="w-full overflow-x-auto rounded-2xl border border-white/10 glass-panel shadow-xl shadow-black/20">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-white/10 bg-white/[0.03] text-xs font-semibold text-slate-400 uppercase tracking-wider">
              <th className="py-4 px-6">Capability &amp; Permission Scope</th>
              <th className="py-4 px-4 text-center">Super Admin</th>
              <th className="py-4 px-4 text-center">Teacher</th>
              <th className="py-4 px-4 text-center">Student</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5 text-xs text-slate-300">
            {(permissionsList || []).map((p) => (
              <tr key={p.perm} className="hover:bg-white/[0.02] transition-colors">
                <td className="py-3.5 px-6">
                  <div className="font-semibold text-white text-sm">{p.label}</div>
                  <div className="text-[11px] text-slate-400 font-mono mt-0.5">{p.perm} — {p.desc}</div>
                </td>
                <td className="py-3.5 px-4 text-center">
                  {p.admin ? (
                    <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                      ✓
                    </span>
                  ) : (
                    <span className="text-slate-600">—</span>
                  )}
                </td>
                <td className="py-3.5 px-4 text-center">
                  {p.teacher ? (
                    <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                      ✓
                    </span>
                  ) : (
                    <span className="text-slate-600">—</span>
                  )}
                </td>
                <td className="py-3.5 px-4 text-center">
                  {p.student ? (
                    <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                      ✓
                    </span>
                  ) : (
                    <span className="text-slate-600">—</span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
