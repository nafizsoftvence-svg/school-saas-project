import React from 'react';
import {
  Download,
  Printer,
  FileSpreadsheet,
  Users,
  Building,
  Clock,
  CheckCircle2,
  Calendar,
  AlertTriangle,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';
import {
  TeacherAttendanceReportItem,
  AttendanceReportPagination
} from '../../../../types/index.js';
import { downloadTablePdf, triggerSafePrint } from '../../../../utils/printPdf.js';

interface TeacherAttendanceReportTabProps {
  data: TeacherAttendanceReportItem[];
  pagination: AttendanceReportPagination;
  onPageChange: (page: number) => void;
  onExportCsv: () => void;
  onExportExcel: () => void;
  isLoading?: boolean;
}

export const TeacherAttendanceReportTab: React.FC<TeacherAttendanceReportTabProps> = ({
  data,
  pagination,
  onPageChange,
  onExportCsv,
  onExportExcel,
  isLoading = false
}) => {
  return (
    <div className="bg-slate-900/90 border border-white/10 rounded-2xl p-6 shadow-xl space-y-5 backdrop-blur-md">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/5 pb-4">
        <div>
          <h3 className="text-base font-bold text-white tracking-tight">
            Faculty &amp; Staff Attendance Report
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Faculty punctuality, check-in timestamps, working day counts, and department benchmarks
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onExportCsv}
            disabled={isLoading || data.length === 0}
            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 border border-white/10 transition disabled:opacity-40"
            title="Export CSV"
          >
            <Download className="w-3.5 h-3.5 text-indigo-400" />
            CSV
          </button>
          <button
            type="button"
            onClick={onExportExcel}
            disabled={isLoading || data.length === 0}
            className="px-3 py-1.5 rounded-xl bg-emerald-950/40 hover:bg-emerald-900/50 text-emerald-300 text-xs font-semibold flex items-center gap-1.5 border border-emerald-500/30 transition disabled:opacity-40"
            title="Export Excel"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
            Excel
          </button>
          <button
            type="button"
            onClick={async () => {
              if (!data || data.length === 0) {
                window.print();
                return;
              }
              const cols = ['Teacher Name', 'Emp ID', 'Department', 'Working Days', 'Present', 'Absent', 'Late', 'Attendance %'];
              const rows = data.map((item) => [
                item.teacherName,
                item.employeeId,
                item.departmentName,
                item.totalWorkingDays,
                item.present,
                item.absent,
                item.late,
                `${(item.attendancePercentage ?? 0).toFixed(1)}%`
              ]);
              await downloadTablePdf({
                title: 'Faculty & Staff Attendance Performance Report',
                columns: cols,
                data: rows,
                orientation: 'landscape'
              });
              await triggerSafePrint({
                fallbackTitle: 'Teacher_Attendance_Report'
              });
            }}
            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center gap-1.5 border border-white/10 transition"
            title="Print / PDF Roster"
          >
            <Printer className="w-3.5 h-3.5" />
            Print / PDF
          </button>
        </div>
      </div>

      {isLoading ? (
        <div className="py-16 text-center text-slate-400 text-sm">
          Loading faculty attendance report...
        </div>
      ) : data.length === 0 ? (
        <div className="py-16 text-center text-slate-400 text-sm bg-slate-800/20 rounded-xl">
          No faculty attendance records found for this period.
        </div>
      ) : (
        <div className="overflow-x-auto rounded-xl border border-white/10">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-800/80 text-slate-400 font-bold uppercase text-[10px]">
              <tr>
                <th className="px-4 py-3">Faculty Member</th>
                <th className="px-4 py-3">Department</th>
                <th className="px-4 py-3 text-center">Working Days</th>
                <th className="px-4 py-3 text-center text-emerald-400">Present</th>
                <th className="px-4 py-3 text-center text-amber-400">Late Days</th>
                <th className="px-4 py-3 text-center text-blue-400">Leave Days</th>
                <th className="px-4 py-3 text-center text-rose-400">Absent Days</th>
                <th className="px-4 py-3 text-right">Attendance %</th>
                <th className="px-4 py-3 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 text-slate-300">
              {data.map((t, idx) => {
                const pct = t.attendancePercentage ?? 0;
                const isOptimal = pct >= 90;
                const isWarning = pct >= 80 && pct < 90;
                const uniqueKey = t.teacherProfileId || (t as any).teacherId || t.employeeCode || `teacher-${idx}`;

                return (
                  <tr key={uniqueKey} className="hover:bg-white/[0.02]">
                    <td className="px-4 py-3">
                      <div className="font-bold text-white">{t.teacherName}</div>
                      <div className="text-[11px] text-slate-400">{t.designation || 'Faculty Member'}</div>
                    </td>

                    <td className="px-4 py-3">
                      <span className="px-2 py-0.5 rounded-lg bg-slate-800 text-slate-300 font-semibold border border-white/5">
                        {t.departmentName}
                      </span>
                    </td>

                    <td className="px-4 py-3 text-center font-mono font-semibold text-slate-200">
                      {t.totalWorkingDays ?? 0}
                    </td>

                    <td className="px-4 py-3 text-center font-mono font-bold text-emerald-400">
                      {t.present ?? (t as any).presentDays ?? 0}
                    </td>

                    <td className="px-4 py-3 text-center font-mono text-amber-400">
                      {t.late ?? (t as any).lateDays ?? 0}
                    </td>

                    <td className="px-4 py-3 text-center font-mono text-blue-400">
                      {t.leave ?? (t as any).leaveDays ?? 0}
                    </td>

                    <td className="px-4 py-3 text-center font-mono font-bold text-rose-400">
                      {t.absent ?? (t as any).absentDays ?? 0}
                    </td>

                    <td className="px-4 py-3 text-right font-mono font-black text-sm">
                      <span
                        className={
                          isOptimal
                            ? 'text-emerald-400'
                            : isWarning
                            ? 'text-amber-400'
                            : 'text-rose-400'
                        }
                      >
                        {pct.toFixed(1)}%
                      </span>
                    </td>

                    <td className="px-4 py-3 text-center">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                          isOptimal
                            ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                            : isWarning
                            ? 'bg-amber-500/15 text-amber-300 border-amber-500/30'
                            : 'bg-rose-500/15 text-rose-300 border-rose-500/30'
                        }`}
                      >
                        {isOptimal ? 'Punctual' : isWarning ? 'Satisfactory' : 'Action Req'}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Pagination */}
      {pagination.totalPages > 1 && (
        <div className="flex items-center justify-between pt-3 border-t border-white/5 text-xs text-slate-400">
          <div>
            Showing{' '}
            <span className="font-bold text-white">
              {(pagination.page - 1) * pagination.limit + 1}
            </span>{' '}
            to{' '}
            <span className="font-bold text-white">
              {Math.min(pagination.page * pagination.limit, pagination.total)}
            </span>{' '}
            of <span className="font-bold text-white">{pagination.total}</span> faculty
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              disabled={pagination.page <= 1}
              onClick={() => onPageChange(pagination.page - 1)}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 disabled:opacity-40 transition flex items-center gap-1"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
              Prev
            </button>
            <span className="px-2 font-bold text-white">
              Page {pagination.page} of {pagination.totalPages}
            </span>
            <button
              type="button"
              disabled={pagination.page >= pagination.totalPages}
              onClick={() => onPageChange(pagination.page + 1)}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 disabled:opacity-40 transition flex items-center gap-1"
            >
              Next
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
