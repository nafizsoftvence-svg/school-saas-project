import React, { useState, useEffect } from 'react';
import {
  X,
  User,
  Calendar,
  Clock,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  FileText,
  Printer,
  Download,
  Phone,
  Building,
  GraduationCap
} from 'lucide-react';
import { api } from '../../../../services/api.js';
import { StudentWiseAttendanceReportItem, AttendanceDetailedRecordReportItem } from '../../../../types/index.js';
import { downloadElementPdf, triggerSafePrint } from '../../../../utils/printPdf.js';

interface StudentAttendanceDetailModalProps {
  student: StudentWiseAttendanceReportItem | null;
  isOpen: boolean;
  onClose: () => void;
  academicSessionId?: string;
}

export const StudentAttendanceDetailModal: React.FC<StudentAttendanceDetailModalProps> = ({
  student,
  isOpen,
  onClose,
  academicSessionId
}) => {
  const [records, setRecords] = useState<AttendanceDetailedRecordReportItem[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  useEffect(() => {
    if (!isOpen || !student) return;

    const fetchHistory = async () => {
      setIsLoading(true);
      try {
        const res = await api.getAttendanceReportsRecords({
          studentId: student.studentId,
          academicSessionId,
          limit: 100
        });
        if (res.success && res.data) {
          setRecords(res.data.data);
        }
      } catch (err) {
        console.error('Failed to load student attendance history:', err);
      } finally {
        setIsLoading(false);
      }
    };

    fetchHistory();
  }, [isOpen, student, academicSessionId]);

  if (!isOpen || !student) return null;

  const pct = student.attendancePercentage;
  const isSatisfactory = pct >= 85;
  const isWarning = pct >= 75 && pct < 85;
  const isDefaulter = pct < 75;

  const handlePrint = async () => {
    const studentTitle = student?.studentName?.replace(/\s+/g, '_') || 'Student';
    await downloadElementPdf('printable-student-attendance-modal', `attendance_dossier_${studentTitle}.pdf`, {
      orientation: 'landscape'
    });
    await triggerSafePrint({
      elementOrId: 'printable-student-attendance-modal',
      fallbackTitle: `Attendance_Dossier_${studentTitle}`
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
      <div id="printable-student-attendance-modal" className="bg-slate-900 border border-white/10 rounded-2xl max-w-4xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="flex items-center justify-between p-6 border-b border-white/10 bg-slate-800/60">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400 font-bold text-lg">
              {student.studentName.charAt(0)}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-white tracking-tight">
                  {student.studentName}
                </h2>
                <span
                  className={`px-2.5 py-0.5 rounded-full text-xs font-bold border ${
                    isSatisfactory
                      ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                      : isWarning
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                      : 'bg-rose-500/20 text-rose-300 border-rose-500/30'
                  }`}
                >
                  {pct.toFixed(1)}% &bull;{' '}
                  {isSatisfactory ? 'Satisfactory' : isWarning ? 'Moderate' : 'Defaulter / At-Risk'}
                </span>
              </div>
              <p className="text-xs text-slate-400 flex items-center gap-2 mt-0.5">
                <span>Roll: #{student.rollNumber || 'N/A'}</span>
                <span>&bull;</span>
                <span>Adm: {student.admissionNumber}</span>
                <span>&bull;</span>
                <span>
                  {student.className} - Section {student.sectionName}
                </span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handlePrint}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center gap-1.5 border border-white/10 transition"
              title="Print Student Attendance Dossier"
            >
              <Printer className="w-3.5 h-3.5" />
              Print / PDF
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-6 overflow-y-auto">
          {/* Summary Metric Counters */}
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
            <div className="p-3 bg-slate-800/60 rounded-xl border border-white/5 text-center">
              <span className="text-[10px] font-bold text-slate-400 uppercase">Working Days</span>
              <div className="text-lg font-black text-white mt-0.5">{student.totalWorkingDays}</div>
            </div>

            <div className="p-3 bg-emerald-500/10 rounded-xl border border-emerald-500/20 text-center">
              <span className="text-[10px] font-bold text-emerald-400 uppercase">Present</span>
              <div className="text-lg font-black text-emerald-400 mt-0.5">{student.presentDays}</div>
            </div>

            <div className="p-3 bg-amber-500/10 rounded-xl border border-amber-500/20 text-center">
              <span className="text-[10px] font-bold text-amber-400 uppercase">Late</span>
              <div className="text-lg font-black text-amber-400 mt-0.5">{student.lateDays}</div>
            </div>

            <div className="p-3 bg-purple-500/10 rounded-xl border border-purple-500/20 text-center">
              <span className="text-[10px] font-bold text-purple-400 uppercase">Half Day</span>
              <div className="text-lg font-black text-purple-400 mt-0.5">{student.halfDays}</div>
            </div>

            <div className="p-3 bg-blue-500/10 rounded-xl border border-blue-500/20 text-center">
              <span className="text-[10px] font-bold text-blue-400 uppercase">Leave</span>
              <div className="text-lg font-black text-blue-400 mt-0.5">{student.leaveDays}</div>
            </div>

            <div className="p-3 bg-rose-500/10 rounded-xl border border-rose-500/20 text-center">
              <span className="text-[10px] font-bold text-rose-400 uppercase">Absent</span>
              <div className="text-lg font-black text-rose-400 mt-0.5">{student.absentDays}</div>
            </div>
          </div>

          {/* Progress towards 75% Defaulter Limit */}
          <div className="p-4 bg-slate-800/40 rounded-xl border border-white/5 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-300 font-semibold">Attendance Threshold Progress</span>
              <span className="font-mono font-bold text-white">
                {pct.toFixed(1)}% / 100%
              </span>
            </div>
            <div className="relative w-full h-3 bg-slate-800 rounded-full overflow-hidden border border-white/5">
              {/* 75% Marker Line */}
              <div
                className="absolute top-0 bottom-0 w-0.5 bg-rose-400 z-10"
                style={{ left: '75%' }}
                title="Mandatory 75% Minimum Threshold"
              />
              <div
                className={`h-full rounded-full transition-all duration-500 ${
                  isSatisfactory
                    ? 'bg-gradient-to-r from-emerald-600 to-emerald-400'
                    : isWarning
                    ? 'bg-gradient-to-r from-amber-600 to-amber-400'
                    : 'bg-gradient-to-r from-rose-600 to-rose-400'
                }`}
                style={{ width: `${Math.min(100, Math.max(0, pct))}%` }}
              />
            </div>
            <div className="flex items-center justify-between text-[11px] text-slate-400">
              <span>0%</span>
              <span className="text-rose-400 font-bold">75% Defaulter Cutoff</span>
              <span className="text-emerald-400 font-bold">85% Target</span>
              <span>100%</span>
            </div>
          </div>

          {/* Detailed Timeline Table */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Calendar className="w-3.5 h-3.5 text-indigo-400" />
              Recorded Attendance Timeline ({records.length} Logs)
            </h4>

            {isLoading ? (
              <div className="py-8 text-center text-slate-400 text-xs">
                Loading attendance history logs...
              </div>
            ) : records.length === 0 ? (
              <div className="py-8 text-center text-slate-400 text-xs bg-slate-800/30 rounded-xl">
                No attendance logs found for this student in the selected period.
              </div>
            ) : (
              <div className="overflow-x-auto rounded-xl border border-white/10">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-800/80 text-slate-400 font-bold uppercase text-[10px]">
                    <tr>
                      <th className="px-4 py-2.5">Date</th>
                      <th className="px-4 py-2.5">Status</th>
                      <th className="px-4 py-2.5">Remarks / Reason</th>
                      <th className="px-4 py-2.5">Recorded At</th>
                      <th className="px-4 py-2.5">Recorded By</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5 text-slate-300">
                    {records.map((r) => {
                      const st = r.status;
                      const badgeClass =
                        st === 'PRESENT'
                          ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                          : st === 'LATE'
                          ? 'bg-amber-500/15 text-amber-300 border-amber-500/30'
                          : st === 'HALF_DAY'
                          ? 'bg-purple-500/15 text-purple-300 border-purple-500/30'
                          : st === 'LEAVE'
                          ? 'bg-blue-500/15 text-blue-300 border-blue-500/30'
                          : 'bg-rose-500/15 text-rose-300 border-rose-500/30';

                      return (
                        <tr key={r.id} className="hover:bg-white/[0.02]">
                          <td className="px-4 py-2.5 font-mono font-bold text-white">
                            {r.date}
                          </td>
                          <td className="px-4 py-2.5">
                            <span className={`px-2 py-0.5 rounded-full text-[11px] font-bold border ${badgeClass}`}>
                              {st}
                            </span>
                          </td>
                          <td className="px-4 py-2.5 text-slate-300 max-w-xs truncate">
                            {r.remarks || '—'}
                          </td>
                          <td className="px-4 py-2.5 text-slate-400 font-mono text-[11px]">
                            {r.markedAt ? new Date(r.markedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '—'}
                          </td>
                          <td className="px-4 py-2.5 text-slate-400">
                            {r.markedByName || 'System'}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-white/10 bg-slate-800/40 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold border border-white/10 transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
