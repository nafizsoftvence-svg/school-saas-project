import React, { useState } from 'react';
import {
  Download,
  Printer,
  Eye,
  AlertTriangle,
  ArrowUpDown,
  CheckCircle2,
  XCircle,
  Clock,
  Calendar,
  ChevronLeft,
  ChevronRight,
  FileSpreadsheet
} from 'lucide-react';
import { StudentWiseAttendanceReportItem, AttendanceReportPagination } from '../../../../types/index.js';
import { StudentAttendanceDetailModal } from './StudentAttendanceDetailModal.js';
import { downloadTablePdf, triggerSafePrint } from '../../../../utils/printPdf.js';

interface StudentAttendanceReportTabProps {
  data: StudentWiseAttendanceReportItem[];
  pagination: AttendanceReportPagination;
  onPageChange: (page: number) => void;
  onSortChange: (sortBy: string, sortOrder: 'asc' | 'desc') => void;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
  onExportCsv: () => void;
  onExportExcel: () => void;
  academicSessionId?: string;
  isLoading?: boolean;
}

export const StudentAttendanceReportTab: React.FC<StudentAttendanceReportTabProps> = ({
  data,
  pagination,
  onPageChange,
  onSortChange,
  sortBy = 'attendancePercentage',
  sortOrder = 'asc',
  onExportCsv,
  onExportExcel,
  academicSessionId,
  isLoading = false
}) => {
  const [selectedStudent, setSelectedStudent] = useState<StudentWiseAttendanceReportItem | null>(null);
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);

  const handleRowClick = (student: StudentWiseAttendanceReportItem) => {
    setSelectedStudent(student);
    setIsModalOpen(true);
  };

  const handleSort = (field: string) => {
    if (sortBy === field) {
      onSortChange(field, sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      onSortChange(field, 'asc');
    }
  };

  return (
    <div className="bg-slate-900/90 border border-white/10 rounded-2xl p-6 shadow-xl space-y-5 backdrop-blur-md">
      {/* Tab Header & Action Strip */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/5 pb-4">
        <div>
          <h3 className="text-base font-bold text-white tracking-tight">
            Student-wise Cumulative Attendance Report
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Individual student attendance percentages, working days, absences, and defaulter tracking
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onExportCsv}
            disabled={isLoading || data.length === 0}
            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 border border-white/10 transition disabled:opacity-40"
            title="Export CSV"
          >
            <Download className="w-3.5 h-3.5 text-indigo-400" />
            CSV
          </button>
          <button
            type="button"
            onClick={onExportExcel}
            disabled={isLoading || data.length === 0}
            className="px-3 py-1.5 rounded-xl bg-emerald-950/40 hover:bg-emerald-900/50 text-emerald-300 text-xs font-semibold flex items-center gap-1.5 border border-emerald-500/30 transition disabled:opacity-40"
            title="Export Excel Worksheet"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
            Excel
          </button>
          <button
            type="button"
            onClick={async () => {
              if (!data || data.length === 0) {
                window.print();
                return;
              }
              const cols = ['Student Name', 'Admission No', 'Class & Sec', 'Present', 'Absent', 'Late', 'Attendance %', 'Status'];
              const rows = data.map((item) => [
                item.studentName,
                item.admissionNumber,
                `${item.className} - ${item.sectionName}`,
                item.present,
                item.absent,
                item.late,
                `${(item.attendancePercentage ?? 0).toFixed(1)}%`,
                item.defaulterStatus || ((item.attendancePercentage ?? 0) < 75 ? 'At Risk' : 'Good')
              ]);
              await downloadTablePdf({
                title: 'Student-Wise Attendance Report',
                columns: cols,
                data: rows,
                orientation: 'landscape'
              });
              await triggerSafePrint({
                fallbackTitle: 'Student_Attendance_Report'
              });
            }}
            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center gap-1.5 border border-white/10 transition"
            title="Print / PDF Report"
          >
            <Printer className="w-3.5 h-3.5" />
            Print / PDF
          </button>
        </div>
      </div>

      {/* Main Table */}
      {isLoading ? (
        <div className="py-16 text-center text-slate-400 text-sm">
          Loading student attendance data...
        </div>
      ) : data.length === 0 ? (
        <div className="py-16 text-center text-slate-400 text-sm bg-slate-800/20 rounded-xl">
          No student attendance records matched your filter criteria.
        </div>
      ) : (
        <div className="overflow-x-auto rounded-xl border border-white/10">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-800/80 text-slate-400 font-bold uppercase text-[10px]">
              <tr>
                <th
                  className="px-4 py-3 cursor-pointer hover:text-white transition"
                  onClick={() => handleSort('studentName')}
                >
                  <div className="flex items-center gap-1">
                    Student Details
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="px-4 py-3">Class &amp; Section</th>
                <th className="px-4 py-3 text-center">Working Days</th>
                <th className="px-4 py-3 text-center text-emerald-400">Present</th>
                <th className="px-4 py-3 text-center text-amber-400">Late</th>
                <th className="px-4 py-3 text-center text-purple-400">Half Day</th>
                <th className="px-4 py-3 text-center text-blue-400">Leave</th>
                <th className="px-4 py-3 text-center text-rose-400">Absent</th>
                <th
                  className="px-4 py-3 text-right cursor-pointer hover:text-white transition"
                  onClick={() => handleSort('attendancePercentage')}
                >
                  <div className="flex items-center justify-end gap-1">
                    Attendance %
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="px-4 py-3 text-center">Status</th>
                <th className="px-4 py-3 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 text-slate-300">
              {data.map((item) => {
                const pct = item.attendancePercentage;
                const isOptimal = pct >= 85;
                const isWarning = pct >= 75 && pct < 85;
                const isDefaulter = pct < 75;

                return (
                  <tr
                    key={item.studentId}
                    className={`hover:bg-white/[0.02] transition ${
                      isDefaulter ? 'bg-rose-950/10' : ''
                    }`}
                  >
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2.5">
                        <div className="w-7 h-7 rounded-lg bg-indigo-500/20 text-indigo-300 flex items-center justify-center font-bold text-xs">
                          {item.studentName.charAt(0)}
                        </div>
                        <div>
                          <div className="font-bold text-white hover:text-indigo-300 cursor-pointer transition"
                            onClick={() => handleRowClick(item)}
                          >
                            {item.studentName}
                          </div>
                          <div className="text-[11px] text-slate-400">
                            Adm: {item.admissionNumber} {item.rollNumber ? `• Roll #${item.rollNumber}` : ''}
                          </div>
                        </div>
                      </div>
                    </td>

                    <td className="px-4 py-3">
                      <span className="font-medium text-white">{item.className}</span>
                      <span className="text-slate-400 ml-1">({item.sectionName})</span>
                    </td>

                    <td className="px-4 py-3 text-center font-mono font-semibold text-slate-200">
                      {item.totalWorkingDays}
                    </td>

                    <td className="px-4 py-3 text-center font-mono font-bold text-emerald-400">
                      {item.presentDays}
                    </td>

                    <td className="px-4 py-3 text-center font-mono text-amber-400">
                      {item.lateDays}
                    </td>

                    <td className="px-4 py-3 text-center font-mono text-purple-400">
                      {item.halfDays}
                    </td>

                    <td className="px-4 py-3 text-center font-mono text-blue-400">
                      {item.leaveDays}
                    </td>

                    <td className="px-4 py-3 text-center font-mono font-bold text-rose-400">
                      {item.absentDays}
                    </td>

                    <td className="px-4 py-3 text-right font-mono font-black text-sm">
                      <span
                        className={
                          isOptimal
                            ? 'text-emerald-400'
                            : isWarning
                            ? 'text-amber-400'
                            : 'text-rose-400'
                        }
                      >
                        {pct.toFixed(1)}%
                      </span>
                    </td>

                    <td className="px-4 py-3 text-center">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                          isOptimal
                            ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                            : isWarning
                            ? 'bg-amber-500/15 text-amber-300 border-amber-500/30'
                            : 'bg-rose-500/20 text-rose-300 border-rose-500/40 animate-pulse'
                        }`}
                      >
                        {isOptimal ? 'Optimal' : isWarning ? 'Moderate' : 'Defaulter'}
                      </span>
                    </td>

                    <td className="px-4 py-3 text-center">
                      <button
                        type="button"
                        onClick={() => handleRowClick(item)}
                        className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-[11px] font-semibold flex items-center gap-1 mx-auto border border-white/10 transition"
                      >
                        <Eye className="w-3 h-3 text-indigo-400" />
                        Details
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Pagination Footer */}
      {pagination.totalPages > 1 && (
        <div className="flex items-center justify-between pt-3 border-t border-white/5 text-xs text-slate-400">
          <div>
            Showing{' '}
            <span className="font-bold text-white">
              {(pagination.page - 1) * pagination.limit + 1}
            </span>{' '}
            to{' '}
            <span className="font-bold text-white">
              {Math.min(pagination.page * pagination.limit, pagination.total)}
            </span>{' '}
            of <span className="font-bold text-white">{pagination.total}</span> students
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              disabled={pagination.page <= 1}
              onClick={() => onPageChange(pagination.page - 1)}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 disabled:opacity-40 transition flex items-center gap-1"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
              Prev
            </button>
            <span className="px-2 font-bold text-white">
              Page {pagination.page} of {pagination.totalPages}
            </span>
            <button
              type="button"
              disabled={pagination.page >= pagination.totalPages}
              onClick={() => onPageChange(pagination.page + 1)}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 disabled:opacity-40 transition flex items-center gap-1"
            >
              Next
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Drill-down Detail Modal */}
      <StudentAttendanceDetailModal
        student={selectedStudent}
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        academicSessionId={academicSessionId}
      />
    </div>
  );
};
