import React from 'react';
import {
  Download,
  Printer,
  FileSpreadsheet,
  Calendar,
  CheckCircle2,
  Clock,
  XCircle,
  ShieldCheck,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';
import { LeaveReportItem, AttendanceReportPagination } from '../../../../types/index.js';
import { downloadTablePdf, triggerSafePrint } from '../../../../utils/printPdf.js';

interface LeaveImpactReportTabProps {
  data: LeaveReportItem[];
  pagination: AttendanceReportPagination;
  onPageChange: (page: number) => void;
  onExportCsv: () => void;
  onExportExcel: () => void;
  isLoading?: boolean;
}

export const LeaveImpactReportTab: React.FC<LeaveImpactReportTabProps> = ({
  data,
  pagination,
  onPageChange,
  onExportCsv,
  onExportExcel,
  isLoading = false
}) => {
  // Aggregate stats
  const totalApproved = data.filter((d) => d.status === 'APPROVED').length;
  const totalPending = data.filter((d) => d.status === 'PENDING').length;
  const totalRejected = data.filter((d) => d.status === 'REJECTED').length;

  return (
    <div className="space-y-6">
      {/* Informational Header Box */}
      <div className="bg-slate-900/90 border border-white/10 rounded-2xl p-6 shadow-xl space-y-4 backdrop-blur-md">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/5 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-blue-500/20 text-blue-400 border border-blue-500/30">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white tracking-tight">
                Leave Impact &amp; Legitimate Absences Analytics
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Leave workflows directly correlate with daily attendance registers
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onExportCsv}
              disabled={isLoading || data.length === 0}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 border border-white/10 transition disabled:opacity-40"
              title="Export CSV"
            >
              <Download className="w-3.5 h-3.5 text-indigo-400" />
              CSV
            </button>
            <button
              type="button"
              onClick={onExportExcel}
              disabled={isLoading || data.length === 0}
              className="px-3 py-1.5 rounded-xl bg-emerald-950/40 hover:bg-emerald-900/50 text-emerald-300 text-xs font-semibold flex items-center gap-1.5 border border-emerald-500/30 transition disabled:opacity-40"
              title="Export Excel"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
              Excel
            </button>
            <button
              type="button"
              onClick={async () => {
                if (!data || data.length === 0) {
                  window.print();
                  return;
                }
                const cols = ['Applicant Name', 'Type', 'Leave Category', 'Start Date', 'End Date', 'Days', 'Status', 'Reason'];
                const rows = data.map((item) => [
                  item.applicantName,
                  item.applicantType,
                  item.leaveType,
                  item.startDate,
                  item.endDate,
                  item.totalDays,
                  item.status,
                  item.reason || '-'
                ]);
                await downloadTablePdf({
                  title: 'Institutional Leave Impact & Audit Report',
                  columns: cols,
                  data: rows,
                  orientation: 'landscape'
                });
                await triggerSafePrint({
                  fallbackTitle: 'Leave_Impact_Report'
                });
              }}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center gap-1.5 border border-white/10 transition"
              title="Print / PDF Leave Logs"
            >
              <Printer className="w-3.5 h-3.5" />
              Print / PDF
            </button>
          </div>
        </div>

        {/* Status Counters */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-between">
            <div>
              <span className="text-xs font-bold text-emerald-400 uppercase">Approved Leaves</span>
              <div className="text-2xl font-black text-white mt-1">{totalApproved}</div>
              <span className="text-[11px] text-emerald-300/80">Excused from absence totals</span>
            </div>
            <CheckCircle2 className="w-8 h-8 text-emerald-400/50" />
          </div>

          <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-between">
            <div>
              <span className="text-xs font-bold text-amber-400 uppercase">Pending Applications</span>
              <div className="text-2xl font-black text-white mt-1">{totalPending}</div>
              <span className="text-[11px] text-amber-300/80">Awaiting admin review</span>
            </div>
            <Clock className="w-8 h-8 text-amber-400/50" />
          </div>

          <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/20 flex items-center justify-between">
            <div>
              <span className="text-xs font-bold text-rose-400 uppercase">Rejected Applications</span>
              <div className="text-2xl font-black text-white mt-1">{totalRejected}</div>
              <span className="text-[11px] text-rose-300/80">Treated as unexcused if absent</span>
            </div>
            <XCircle className="w-8 h-8 text-rose-400/50" />
          </div>
        </div>
      </div>

      {/* Main Table */}
      <div className="bg-slate-900/90 border border-white/10 rounded-2xl p-6 shadow-xl space-y-4 backdrop-blur-md">
        <h4 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
          <Calendar className="w-4 h-4 text-indigo-400" />
          Leave Records &amp; Attendance Correlation Log ({data.length} records)
        </h4>

        {isLoading ? (
          <div className="py-16 text-center text-slate-400 text-sm">
            Loading leave applications impact report...
          </div>
        ) : data.length === 0 ? (
          <div className="py-16 text-center text-slate-400 text-sm bg-slate-800/20 rounded-xl">
            No leave records found matching current filters.
          </div>
        ) : (
          <div className="overflow-x-auto rounded-xl border border-white/10">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-800/80 text-slate-400 font-bold uppercase text-[10px]">
                <tr>
                  <th className="px-4 py-3">Applicant Name</th>
                  <th className="px-4 py-3">Type</th>
                  <th className="px-4 py-3">Leave Category</th>
                  <th className="px-4 py-3">Date Range</th>
                  <th className="px-4 py-3 text-center">Days</th>
                  <th className="px-4 py-3">Reason</th>
                  <th className="px-4 py-3 text-center">Workflow Status</th>
                  <th className="px-4 py-3">Reviewed By</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 text-slate-300">
                {data.map((l) => {
                  const isApproved = l.status === 'APPROVED';
                  const isPending = l.status === 'PENDING';

                  return (
                    <tr key={l.id} className="hover:bg-white/[0.02]">
                      <td className="px-4 py-3">
                        <div className="font-bold text-white">{l.applicantName}</div>
                        {l.className && (
                          <div className="text-[11px] text-slate-400">
                            {l.className} - {l.sectionName}
                          </div>
                        )}
                      </td>

                      <td className="px-4 py-3 font-semibold text-slate-300">
                        {l.applicantType}
                      </td>

                      <td className="px-4 py-3">
                        <span className="px-2 py-0.5 rounded-lg bg-slate-800 text-slate-200 border border-white/5 font-medium">
                          {l.leaveTypeName}
                        </span>
                      </td>

                      <td className="px-4 py-3 font-mono text-[11px]">
                        {l.startDate} <span className="text-slate-500">&rarr;</span> {l.endDate}
                      </td>

                      <td className="px-4 py-3 text-center font-mono font-bold text-white">
                        {l.totalDays}
                      </td>

                      <td className="px-4 py-3 max-w-xs truncate text-slate-300">
                        {l.reason}
                      </td>

                      <td className="px-4 py-3 text-center">
                        <span
                          className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${
                            isApproved
                              ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                              : isPending
                              ? 'bg-amber-500/15 text-amber-300 border-amber-500/30'
                              : 'bg-rose-500/15 text-rose-300 border-rose-500/30'
                          }`}
                        >
                          {l.status}
                        </span>
                      </td>

                      <td className="px-4 py-3 text-slate-400">
                        {l.actionTakenByName || '—'}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* Pagination */}
        {pagination.totalPages > 1 && (
          <div className="flex items-center justify-between pt-3 border-t border-white/5 text-xs text-slate-400">
            <div>
              Page <span className="font-bold text-white">{pagination.page}</span> of{' '}
              <span className="font-bold text-white">{pagination.totalPages}</span>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                disabled={pagination.page <= 1}
                onClick={() => onPageChange(pagination.page - 1)}
                className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 disabled:opacity-40 transition flex items-center gap-1"
              >
                <ChevronLeft className="w-3.5 h-3.5" />
                Prev
              </button>
              <button
                type="button"
                disabled={pagination.page >= pagination.totalPages}
                onClick={() => onPageChange(pagination.page + 1)}
                className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 disabled:opacity-40 transition flex items-center gap-1"
              >
                Next
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
