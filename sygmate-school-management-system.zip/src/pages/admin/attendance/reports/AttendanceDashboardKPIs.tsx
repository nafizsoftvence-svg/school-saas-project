import React from 'react';
import {
  TrendingUp,
  TrendingDown,
  CheckCircle2,
  XCircle,
  Clock,
  Calendar,
  AlertTriangle,
  Award,
  Users,
  ShieldCheck,
  Info,
  Layers,
  Sparkles,
  ArrowUpRight,
  ArrowDownRight
} from 'lucide-react';
import { AttendanceReportDashboardData } from '../../../../types/index.js';

interface AttendanceDashboardKPIsProps {
  data: AttendanceReportDashboardData;
  onSelectClass?: (classId: string) => void;
  onFilterDefaulters?: () => void;
}

export const AttendanceDashboardKPIs: React.FC<AttendanceDashboardKPIsProps> = ({
  data,
  onSelectClass,
  onFilterDefaulters
}) => {
  const studentStats = data?.studentStats;
  const rawSummary = data?.summary;

  const summary = {
    attendancePercentage:
      rawSummary?.attendancePercentage ??
      studentStats?.averageAttendancePercentage ??
      0,
    totalStudents: rawSummary?.totalStudents ?? studentStats?.totalEnrolled ?? 0,
    totalPresent: rawSummary?.totalPresent ?? studentStats?.present ?? 0,
    totalAbsent: rawSummary?.totalAbsent ?? studentStats?.absent ?? 0,
    totalLeaves: rawSummary?.totalLeaves ?? studentStats?.onLeave ?? 0,
    totalLate: rawSummary?.totalLate ?? studentStats?.late ?? 0,
    totalHalfDay: rawSummary?.totalHalfDay ?? studentStats?.halfDay ?? 0,
    totalRecords:
      rawSummary?.totalRecords ??
      ((studentStats?.present ?? 0) +
        (studentStats?.absent ?? 0) +
        (studentStats?.late ?? 0) +
        (studentStats?.halfDay ?? 0) +
        (studentStats?.excused ?? 0) +
        (studentStats?.onLeave ?? 0)),
    defaultersCount:
      rawSummary?.defaultersCount ??
      studentStats?.belowThresholdCount ??
      data?.studentsBelowThreshold?.length ??
      0
  };

  const classComparisons: Array<{
    classId: string;
    className: string;
    attendancePercentage: number;
    totalStudents: number;
    totalRecords: number;
  }> = Array.isArray(data?.classComparisons)
    ? data.classComparisons
    : Array.isArray(data?.classPercentages)
    ? data.classPercentages.map((cp) => ({
        classId: cp.classId,
        className: cp.className,
        attendancePercentage: cp.percentage ?? (cp as any).attendancePercentage ?? 0,
        totalStudents: (cp as any).totalStudents ?? cp.total ?? 0,
        totalRecords: (cp as any).totalRecords ?? cp.total ?? 0
      }))
    : [];

  const dailyTrends = (Array.isArray(data?.dailyTrends) ? data.dailyTrends : []).map((d) => ({
    date: d.date,
    dayName: d.dayName || '',
    present: d.present ?? 0,
    absent: d.absent ?? 0,
    late: d.late ?? 0,
    halfDay: d.halfDay ?? 0,
    leave: d.leave ?? 0,
    total:
      d.total ??
      (d.present ?? 0) +
        (d.absent ?? 0) +
        (d.late ?? 0) +
        (d.halfDay ?? 0) +
        (d.leave ?? 0),
    attendancePercentage: d.attendancePercentage ?? d.percentage ?? 0
  }));

  const rawStatusBreakdown = data?.statusBreakdown;
  const statusBreakdown = {
    present: rawStatusBreakdown?.present ?? studentStats?.present ?? summary.totalPresent,
    absent: rawStatusBreakdown?.absent ?? studentStats?.absent ?? summary.totalAbsent,
    leave: rawStatusBreakdown?.leave ?? studentStats?.onLeave ?? summary.totalLeaves,
    late: rawStatusBreakdown?.late ?? studentStats?.late ?? summary.totalLate,
    halfDay: rawStatusBreakdown?.halfDay ?? studentStats?.halfDay ?? summary.totalHalfDay
  };

  const attendanceRate = summary.attendancePercentage ?? 0;
  const isTargetMet = attendanceRate >= 85;

  return (
    <div className="space-y-6">
      {/* Top 6 KPI Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        {/* Overall Attendance Percentage */}
        <div className="bg-slate-900/90 border border-white/10 rounded-2xl p-5 shadow-lg relative overflow-hidden backdrop-blur-md">
          <div className="absolute top-0 right-0 w-24 h-24 bg-indigo-500/10 rounded-full blur-2xl -mr-6 -mt-6 pointer-events-none" />
          <div className="flex items-center justify-between text-xs text-slate-400 font-semibold mb-2">
            <span>Overall Rate</span>
            <span
              className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                isTargetMet
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                  : 'bg-amber-500/20 text-amber-300 border-amber-500/30'
              }`}
            >
              {isTargetMet ? 'Target Met (≥85%)' : 'Below Target'}
            </span>
          </div>
          <div className="text-3xl font-black text-white tracking-tight flex items-baseline gap-1">
            {attendanceRate.toFixed(1)}
            <span className="text-lg font-bold text-slate-400">%</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-2 flex items-center gap-1">
            <Info className="w-3 h-3 text-indigo-400 inline" />
            Formula: (P + L + 0.5×HD) / Total
          </p>
        </div>

        {/* Present Days */}
        <div className="bg-slate-900/90 border border-white/10 rounded-2xl p-5 shadow-lg relative overflow-hidden backdrop-blur-md">
          <div className="flex items-center justify-between text-xs text-slate-400 font-semibold mb-2">
            <span>Present</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-3xl font-black text-emerald-400 tracking-tight">
            {summary.totalPresent.toLocaleString()}
          </div>
          <div className="flex items-center justify-between text-[11px] text-slate-400 mt-2">
            <span>Marked Present</span>
            <span className="font-semibold text-emerald-400">
              {summary.totalRecords > 0
                ? ((summary.totalPresent / summary.totalRecords) * 100).toFixed(1)
                : 0}
              %
            </span>
          </div>
        </div>

        {/* Unexcused Absences */}
        <div className="bg-slate-900/90 border border-white/10 rounded-2xl p-5 shadow-lg relative overflow-hidden backdrop-blur-md">
          <div className="flex items-center justify-between text-xs text-slate-400 font-semibold mb-2">
            <span>Unexcused Absences</span>
            <XCircle className="w-4 h-4 text-rose-400" />
          </div>
          <div className="text-3xl font-black text-rose-400 tracking-tight">
            {summary.totalAbsent.toLocaleString()}
          </div>
          <div className="flex items-center justify-between text-[11px] text-slate-400 mt-2">
            <span>Marked Absent</span>
            <span className="font-semibold text-rose-400">
              {summary.totalRecords > 0
                ? ((summary.totalAbsent / summary.totalRecords) * 100).toFixed(1)
                : 0}
              %
            </span>
          </div>
        </div>

        {/* Approved Leaves */}
        <div className="bg-slate-900/90 border border-white/10 rounded-2xl p-5 shadow-lg relative overflow-hidden backdrop-blur-md">
          <div className="flex items-center justify-between text-xs text-slate-400 font-semibold mb-2">
            <span>Approved Leaves</span>
            <Calendar className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-3xl font-black text-blue-400 tracking-tight">
            {summary.totalLeaves.toLocaleString()}
          </div>
          <p className="text-[11px] text-slate-400 mt-2 truncate" title="Excused via Part 8D workflow">
            Excused via Leave Workflow
          </p>
        </div>

        {/* Late & Half Day Arrivals */}
        <div className="bg-slate-900/90 border border-white/10 rounded-2xl p-5 shadow-lg relative overflow-hidden backdrop-blur-md">
          <div className="flex items-center justify-between text-xs text-slate-400 font-semibold mb-2">
            <span>Late / Half Day</span>
            <Clock className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-3xl font-black text-amber-400 tracking-tight flex items-baseline gap-2">
            {summary.totalLate}
            <span className="text-sm font-semibold text-slate-400">
              / {summary.totalHalfDay} HD
            </span>
          </div>
          <p className="text-[11px] text-slate-400 mt-2">
            Weighted half-day in metric
          </p>
        </div>

        {/* Defaulter Count (<75%) */}
        <div
          onClick={onFilterDefaulters}
          className="bg-slate-900/90 border border-white/10 rounded-2xl p-5 shadow-lg relative overflow-hidden backdrop-blur-md cursor-pointer hover:border-rose-500/40 transition group"
        >
          <div className="flex items-center justify-between text-xs text-slate-400 font-semibold mb-2">
            <span className="text-rose-300 group-hover:text-rose-200 transition">
              Defaulters (&lt;75%)
            </span>
            <AlertTriangle className="w-4 h-4 text-rose-400 group-hover:animate-bounce" />
          </div>
          <div className="text-3xl font-black text-rose-400 tracking-tight">
            {summary.defaultersCount}
          </div>
          <p className="text-[11px] text-rose-400/80 mt-2 underline decoration-dotted">
            Click to inspect list &rarr;
          </p>
        </div>
      </div>

      {/* Analytics Visualization Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Class Comparison Performance Bars */}
        <div className="lg:col-span-2 bg-slate-900/90 border border-white/10 rounded-2xl p-6 shadow-xl backdrop-blur-md space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/5 pb-3">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Layers className="w-4 h-4 text-indigo-400" />
                Class-wise Attendance Performance Comparison
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Benchmark rates across academic grade levels (Target: 85%)
              </p>
            </div>
            <div className="flex items-center gap-3 text-xs">
              <span className="flex items-center gap-1 text-emerald-400 font-medium">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" /> ≥85% (Optimal)
              </span>
              <span className="flex items-center gap-1 text-amber-400 font-medium">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-500" /> 75-84%
              </span>
              <span className="flex items-center gap-1 text-rose-400 font-medium">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500" /> &lt;75% (Alert)
              </span>
            </div>
          </div>

          {(classComparisons?.length || 0) === 0 ? (
            <div className="py-12 text-center text-slate-400 text-sm">
              No class comparison data available for current filter selection.
            </div>
          ) : (
            <div className="space-y-4">
              {classComparisons.map((item, index) => {
                const pct = item.attendancePercentage;
                const isOptimal = pct >= 85;
                const isWarning = pct >= 75 && pct < 85;
                const isAlert = pct < 75;

                return (
                  <div
                    key={`${item.classId}-${index}`}
                    onClick={() => onSelectClass && onSelectClass(item.classId)}
                    className="p-3 rounded-xl bg-slate-800/40 hover:bg-slate-800/80 border border-white/5 hover:border-indigo-500/30 transition cursor-pointer group"
                  >
                    <div className="flex items-center justify-between text-xs mb-1.5">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-white group-hover:text-indigo-300 transition">
                          {item.className}
                        </span>
                        <span className="text-slate-400 text-[11px]">
                          ({item.totalStudents} Students &bull; {item.totalRecords} Records)
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span
                          className={`font-mono font-bold text-sm ${
                            isOptimal
                              ? 'text-emerald-400'
                              : isWarning
                              ? 'text-amber-400'
                              : 'text-rose-400'
                          }`}
                        >
                          {pct.toFixed(1)}%
                        </span>
                      </div>
                    </div>

                    {/* Progress Bar */}
                    <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden flex border border-white/5">
                      <div
                        className={`h-full transition-all duration-500 rounded-full ${
                          isOptimal
                            ? 'bg-gradient-to-r from-emerald-600 to-emerald-400'
                            : isWarning
                            ? 'bg-gradient-to-r from-amber-600 to-amber-400'
                            : 'bg-gradient-to-r from-rose-600 to-rose-400'
                        }`}
                        style={{ width: `${Math.min(100, Math.max(0, pct))}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Right 1 Col: Overall Status Distribution Donut/Rings & Highlights */}
        <div className="bg-slate-900/90 border border-white/10 rounded-2xl p-6 shadow-xl backdrop-blur-md space-y-5">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-indigo-400" />
              Status Composition
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Attendance allocation across total marked sessions
            </p>
          </div>

          {/* Breakdown items */}
          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-300 font-medium flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-400" /> Present
                </span>
                <span className="font-mono font-bold text-emerald-400">
                  {statusBreakdown.present} ({summary.totalRecords > 0 ? ((statusBreakdown.present / summary.totalRecords) * 100).toFixed(1) : 0}%)
                </span>
              </div>
              <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-emerald-500 rounded-full"
                  style={{
                    width: `${summary.totalRecords > 0 ? (statusBreakdown.present / summary.totalRecords) * 100 : 0}%`
                  }}
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-300 font-medium flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-rose-400" /> Absent (Unexcused)
                </span>
                <span className="font-mono font-bold text-rose-400">
                  {statusBreakdown.absent} ({summary.totalRecords > 0 ? ((statusBreakdown.absent / summary.totalRecords) * 100).toFixed(1) : 0}%)
                </span>
              </div>
              <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-rose-500 rounded-full"
                  style={{
                    width: `${summary.totalRecords > 0 ? (statusBreakdown.absent / summary.totalRecords) * 100 : 0}%`
                  }}
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-300 font-medium flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-blue-400" /> Approved Leaves
                </span>
                <span className="font-mono font-bold text-blue-400">
                  {statusBreakdown.leave} ({summary.totalRecords > 0 ? ((statusBreakdown.leave / summary.totalRecords) * 100).toFixed(1) : 0}%)
                </span>
              </div>
              <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-blue-500 rounded-full"
                  style={{
                    width: `${summary.totalRecords > 0 ? (statusBreakdown.leave / summary.totalRecords) * 100 : 0}%`
                  }}
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-300 font-medium flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-amber-400" /> Late Arrivals
                </span>
                <span className="font-mono font-bold text-amber-400">
                  {statusBreakdown.late} ({summary.totalRecords > 0 ? ((statusBreakdown.late / summary.totalRecords) * 100).toFixed(1) : 0}%)
                </span>
              </div>
              <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-amber-500 rounded-full"
                  style={{
                    width: `${summary.totalRecords > 0 ? (statusBreakdown.late / summary.totalRecords) * 100 : 0}%`
                  }}
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-300 font-medium flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-purple-400" /> Half Day
                </span>
                <span className="font-mono font-bold text-purple-400">
                  {statusBreakdown.halfDay} ({summary.totalRecords > 0 ? ((statusBreakdown.halfDay / summary.totalRecords) * 100).toFixed(1) : 0}%)
                </span>
              </div>
              <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-purple-500 rounded-full"
                  style={{
                    width: `${summary.totalRecords > 0 ? (statusBreakdown.halfDay / summary.totalRecords) * 100 : 0}%`
                  }}
                />
              </div>
            </div>
          </div>

          {/* Quick Notice Card */}
          <div className="p-3.5 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-xs space-y-1">
            <div className="flex items-center gap-1.5 font-bold text-indigo-300">
              <ShieldCheck className="w-4 h-4 text-indigo-400" />
              RBAC &amp; Data Integrity
            </div>
            <p className="text-[11px] text-slate-300 leading-relaxed">
              Approved leaves logged via the leave application workflow are preserved and excluded from punitive absence tallies.
            </p>
          </div>
        </div>
      </div>

      {/* Daily Trend Table Strip */}
      {((dailyTrends?.length || 0) > 0) && (
        <div className="bg-slate-900/90 border border-white/10 rounded-2xl p-6 shadow-xl backdrop-blur-md space-y-4">
          <div className="flex items-center justify-between border-b border-white/5 pb-3">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Calendar className="w-4 h-4 text-indigo-400" />
                Daily Attendance Trend Timeline
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Day-by-day attendance trends and rates within selected window
              </p>
            </div>
            <span className="text-xs text-slate-400 font-semibold">
              {dailyTrends?.length || 0} Tracked Session Days
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-white/10 text-slate-400 font-bold uppercase text-[10px]">
                  <th className="px-4 py-2.5">Date</th>
                  <th className="px-4 py-2.5 text-center">Total Marked</th>
                  <th className="px-4 py-2.5 text-center text-emerald-400">Present</th>
                  <th className="px-4 py-2.5 text-center text-amber-400">Late</th>
                  <th className="px-4 py-2.5 text-center text-purple-400">Half Day</th>
                  <th className="px-4 py-2.5 text-center text-blue-400">Leave</th>
                  <th className="px-4 py-2.5 text-center text-rose-400">Absent</th>
                  <th className="px-4 py-2.5 text-right">Daily Attendance %</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 text-slate-300">
                {dailyTrends.map((d) => {
                  const pct = d.attendancePercentage ?? 0;
                  const isGood = pct >= 85;
                  const isWarn = pct >= 75 && pct < 85;

                  return (
                    <tr key={d.date} className="hover:bg-white/[0.02]">
                      <td className="px-4 py-2.5 font-bold text-white font-mono">
                        {d.date}
                      </td>
                      <td className="px-4 py-2.5 text-center font-mono">
                        {d.total}
                      </td>
                      <td className="px-4 py-2.5 text-center font-mono font-semibold text-emerald-400">
                        {d.present}
                      </td>
                      <td className="px-4 py-2.5 text-center font-mono text-amber-400">
                        {d.late}
                      </td>
                      <td className="px-4 py-2.5 text-center font-mono text-purple-400">
                        {d.halfDay}
                      </td>
                      <td className="px-4 py-2.5 text-center font-mono text-blue-400">
                        {d.leave}
                      </td>
                      <td className="px-4 py-2.5 text-center font-mono text-rose-400 font-semibold">
                        {d.absent}
                      </td>
                      <td className="px-4 py-2.5 text-right font-mono font-bold">
                        <span
                          className={`px-2 py-0.5 rounded-full text-xs ${
                            isGood
                              ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                              : isWarn
                              ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                              : 'bg-rose-500/15 text-rose-300 border border-rose-500/30'
                          }`}
                        >
                          {pct.toFixed(1)}%
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
