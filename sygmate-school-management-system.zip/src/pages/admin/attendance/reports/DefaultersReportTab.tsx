import React, { useState } from 'react';
import {
  AlertTriangle,
  Download,
  Printer,
  FileSpreadsheet,
  Phone,
  Mail,
  Send,
  Eye,
  CheckCircle2,
  ShieldAlert,
  SlidersHorizontal,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';
import {
  StudentWiseAttendanceReportItem,
  AttendanceReportPagination
} from '../../../../types/index.js';
import { StudentAttendanceDetailModal } from './StudentAttendanceDetailModal.js';
import { downloadTablePdf, triggerSafePrint } from '../../../../utils/printPdf.js';

interface DefaultersReportTabProps {
  data: StudentWiseAttendanceReportItem[];
  pagination: AttendanceReportPagination;
  onPageChange: (page: number) => void;
  onExportCsv: () => void;
  onExportExcel: () => void;
  academicSessionId?: string;
  isLoading?: boolean;
}

export const DefaultersReportTab: React.FC<DefaultersReportTabProps> = ({
  data,
  pagination,
  onPageChange,
  onExportCsv,
  onExportExcel,
  academicSessionId,
  isLoading = false
}) => {
  const [selectedStudent, setSelectedStudent] = useState<StudentWiseAttendanceReportItem | null>(null);
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [notifiedStudents, setNotifiedStudents] = useState<Record<string, boolean>>({});

  // Filter only those < 75%
  const defaulters = (data || []).filter((s) => (s?.attendancePercentage ?? 0) < 75);

  const handleNotify = (studentId: string, studentName: string) => {
    setNotifiedStudents((prev) => ({ ...prev, [studentId]: true }));
    alert(`Attendance Defaulter Warning SMS / Notice generated for ${studentName}'s registered guardian.`);
  };

  return (
    <div className="space-y-6">
      {/* Alert Header Box */}
      <div className="bg-rose-950/30 border border-rose-500/40 rounded-2xl p-6 shadow-xl relative overflow-hidden backdrop-blur-md">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-start gap-3.5">
            <div className="p-3 rounded-xl bg-rose-500/20 text-rose-400 border border-rose-500/40 mt-0.5">
              <ShieldAlert className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-rose-500/20 text-rose-300 border border-rose-500/40 mb-1">
                Mandatory Regulatory Compliance &bull; 75% Threshold
              </div>
              <h3 className="text-xl font-black text-white tracking-tight">
                Attendance Defaulters &amp; Low Attendance Alert Registry
              </h3>
              <p className="text-xs text-slate-300 mt-1 max-w-2xl leading-relaxed">
                Students listed here currently fall below the required 75.0% institutional attendance benchmark.
                Institutional policy requires immediate guardian notifications and mandatory remedial attendance scheduling.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={onExportCsv}
              disabled={isLoading || defaulters.length === 0}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 border border-white/10 transition disabled:opacity-40"
              title="Export Defaulters CSV"
            >
              <Download className="w-3.5 h-3.5 text-rose-400" />
              CSV
            </button>
            <button
              type="button"
              onClick={onExportExcel}
              disabled={isLoading || defaulters.length === 0}
              className="px-3 py-1.5 rounded-xl bg-emerald-950/40 hover:bg-emerald-900/50 text-emerald-300 text-xs font-semibold flex items-center gap-1.5 border border-emerald-500/30 transition disabled:opacity-40"
              title="Export Defaulters Excel"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
              Excel
            </button>
            <button
              type="button"
              onClick={async () => {
                if (!defaulters || defaulters.length === 0) {
                  window.print();
                  return;
                }
                const cols = ['Student Name', 'Admission No', 'Class & Sec', 'Absent Days', 'Late Days', 'Attendance %', 'Guardian Phone'];
                const rows = defaulters.map((item) => [
                  item.studentName,
                  item.admissionNumber,
                  `${item.className} - ${item.sectionName}`,
                  item.absent,
                  item.late,
                  `${(item.attendancePercentage ?? 0).toFixed(1)}%`,
                  item.guardianPhone || 'N/A'
                ]);
                await downloadTablePdf({
                  title: 'Official Attendance Defaulters List (<75%)',
                  subtitle: `Total Defaulters: ${defaulters.length} | Academic Session: 2026-2027`,
                  columns: cols,
                  data: rows,
                  orientation: 'landscape'
                });
                await triggerSafePrint({
                  fallbackTitle: 'Attendance_Defaulters_List'
                });
              }}
              className="px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-lg shadow-rose-950/50 transition"
              title="Print Warning Notices / PDF"
            >
              <Printer className="w-3.5 h-3.5" />
              Print / PDF Defaulters
            </button>
          </div>
        </div>
      </div>

      {/* Main Defaulters Table */}
      <div className="bg-slate-900/90 border border-white/10 rounded-2xl p-6 shadow-xl space-y-5 backdrop-blur-md">
        <div className="flex items-center justify-between border-b border-white/5 pb-4">
          <h4 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-rose-400" />
            Identified Defaulter Students ({defaulters.length} in current scope)
          </h4>
          <span className="text-xs text-rose-300 font-bold bg-rose-500/15 px-2.5 py-1 rounded-full border border-rose-500/30">
            Cutoff: &lt; 75.0%
          </span>
        </div>

        {isLoading ? (
          <div className="py-16 text-center text-slate-400 text-sm">
            Evaluating attendance records for defaulter detection...
          </div>
        ) : defaulters.length === 0 ? (
          <div className="py-16 text-center text-slate-300 text-sm bg-slate-800/20 rounded-xl space-y-2">
            <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
            <div className="font-bold text-white">No Defaulters Found!</div>
            <p className="text-xs text-slate-400 max-w-md mx-auto">
              All students in the selected scope currently meet or exceed the mandatory 75% attendance threshold.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto rounded-xl border border-white/10">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-800/80 text-slate-400 font-bold uppercase text-[10px]">
                <tr>
                  <th className="px-4 py-3">Student Name</th>
                  <th className="px-4 py-3">Class &amp; Section</th>
                  <th className="px-4 py-3 text-center">Working Days</th>
                  <th className="px-4 py-3 text-center text-emerald-400">Present</th>
                  <th className="px-4 py-3 text-center text-rose-400">Absences</th>
                  <th className="px-4 py-3 text-right">Attendance %</th>
                  <th className="px-4 py-3 text-center">Deficit Severity</th>
                  <th className="px-4 py-3 text-center">Guardian Alert</th>
                  <th className="px-4 py-3 text-center">Audit Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 text-slate-300">
                {defaulters.map((item) => {
                  const pct = item?.attendancePercentage ?? 0;
                  const isSevere = pct < 50;
                  const isCritical = pct >= 50 && pct < 65;
                  const notified = notifiedStudents[item.studentId];

                  return (
                    <tr key={item.studentId} className="hover:bg-white/[0.02] bg-rose-950/10">
                      <td className="px-4 py-3">
                        <div className="font-bold text-white">{item.studentName}</div>
                        <div className="text-[11px] text-slate-400">
                          Adm: {item.admissionNumber} {item.rollNumber ? `• Roll #${item.rollNumber}` : ''}
                        </div>
                      </td>

                      <td className="px-4 py-3">
                        <span className="font-medium text-white">{item.className}</span>
                        <span className="text-slate-400 ml-1">({item.sectionName})</span>
                      </td>

                      <td className="px-4 py-3 text-center font-mono font-semibold text-slate-200">
                        {item.totalWorkingDays}
                      </td>

                      <td className="px-4 py-3 text-center font-mono font-bold text-emerald-400">
                        {item.presentDays}
                      </td>

                      <td className="px-4 py-3 text-center font-mono font-bold text-rose-400">
                        {item.absentDays}
                      </td>

                      <td className="px-4 py-3 text-right font-mono font-black text-sm text-rose-400">
                        {pct.toFixed(1)}%
                      </td>

                      <td className="px-4 py-3 text-center">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                            isSevere
                              ? 'bg-rose-600/30 text-rose-300 border-rose-500/50 animate-pulse'
                              : isCritical
                              ? 'bg-rose-500/20 text-rose-300 border-rose-500/30'
                              : 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                          }`}
                        >
                          {isSevere ? 'Severe (<50%)' : isCritical ? 'Critical (<65%)' : 'At-Risk (<75%)'}
                        </span>
                      </td>

                      <td className="px-4 py-3 text-center">
                        <button
                          type="button"
                          onClick={() => handleNotify(item.studentId, item.studentName)}
                          disabled={notified}
                          className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold flex items-center gap-1 mx-auto border transition ${
                            notified
                              ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30 cursor-default'
                              : 'bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border-rose-500/40'
                          }`}
                        >
                          {notified ? (
                            <>
                              <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                              Notified
                            </>
                          ) : (
                            <>
                              <Send className="w-3 h-3 text-rose-400" />
                              Notify Guardian
                            </>
                          )}
                        </button>
                      </td>

                      <td className="px-4 py-3 text-center">
                        <button
                          type="button"
                          onClick={() => {
                            setSelectedStudent(item);
                            setIsModalOpen(true);
                          }}
                          className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-[11px] font-semibold flex items-center gap-1 mx-auto border border-white/10 transition"
                        >
                          <Eye className="w-3 h-3 text-indigo-400" />
                          View Dossier
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Drill-down Detail Modal */}
      <StudentAttendanceDetailModal
        student={selectedStudent}
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        academicSessionId={academicSessionId}
      />
    </div>
  );
};
