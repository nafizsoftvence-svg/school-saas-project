import React from 'react';
import {
  Download,
  Printer,
  FileSpreadsheet,
  Award,
  AlertTriangle,
  Users,
  Building,
  ArrowUpRight,
  ArrowDownRight
} from 'lucide-react';
import { ClassSectionAttendanceReportItem } from '../../../../types/index.js';
import { downloadTablePdf, triggerSafePrint } from '../../../../utils/printPdf.js';

interface ClassSectionReportTabProps {
  data: ClassSectionAttendanceReportItem[];
  onExportCsv: () => void;
  onExportExcel: () => void;
  isLoading?: boolean;
}

export const ClassSectionReportTab: React.FC<ClassSectionReportTabProps> = ({
  data,
  onExportCsv,
  onExportExcel,
  isLoading = false
}) => {
  // Find highest and lowest performing classes safely
  const sorted = [...(data || [])].sort((a, b) => {
    const rateA = a?.attendancePercentage ?? a?.averageAttendancePercentage ?? 0;
    const rateB = b?.attendancePercentage ?? b?.averageAttendancePercentage ?? 0;
    return rateB - rateA;
  });
  const bestClass = sorted?.[0];
  const lowestClass = sorted.length > 1 ? sorted[sorted.length - 1] : null;

  const bestRate = bestClass ? (bestClass.attendancePercentage ?? bestClass.averageAttendancePercentage ?? 0) : 0;
  const lowestRate = lowestClass ? (lowestClass.attendancePercentage ?? lowestClass.averageAttendancePercentage ?? 0) : 0;

  return (
    <div className="space-y-6">
      {/* Top Highlights: Best Performing vs Needs Intervention */}
      {sorted.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {bestClass && (
            <div className="bg-emerald-950/20 border border-emerald-500/30 rounded-2xl p-5 shadow-lg flex items-center justify-between">
              <div className="space-y-1">
                <span className="text-[11px] font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Award className="w-4 h-4 text-emerald-400" />
                  Top Performing Class &amp; Section
                </span>
                <div className="text-xl font-black text-white">
                  {bestClass.className} - Section {bestClass.sectionName}
                </div>
                <p className="text-xs text-slate-300">
                  {bestClass.totalStudents} Enrolled &bull; {(bestClass as any).presentCount ?? bestClass.present ?? 0} Present Marks
                </p>
              </div>
              <div className="text-right">
                <div className="text-3xl font-black text-emerald-400 font-mono">
                  {bestRate.toFixed(1)}%
                </div>
                <span className="text-[10px] text-emerald-300 font-semibold">Exemplary Standing</span>
              </div>
            </div>
          )}

          {lowestClass && lowestRate < 85 && (
            <div className="bg-rose-950/20 border border-rose-500/30 rounded-2xl p-5 shadow-lg flex items-center justify-between">
              <div className="space-y-1">
                <span className="text-[11px] font-bold text-rose-400 uppercase tracking-wider flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 text-rose-400" />
                  Attendance Attention Required
                </span>
                <div className="text-xl font-black text-white">
                  {lowestClass.className} - Section {lowestClass.sectionName}
                </div>
                <p className="text-xs text-slate-300">
                  {lowestClass.totalStudents} Enrolled &bull; {(lowestClass as any).absentCount ?? lowestClass.absent ?? 0} Absences
                </p>
              </div>
              <div className="text-right">
                <div className="text-3xl font-black text-rose-400 font-mono">
                  {lowestRate.toFixed(1)}%
                </div>
                <span className="text-[10px] text-rose-300 font-semibold">Requires Intervention</span>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Main Table */}
      <div className="bg-slate-900/90 border border-white/10 rounded-2xl p-6 shadow-xl space-y-5 backdrop-blur-md">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/5 pb-4">
          <div>
            <h3 className="text-base font-bold text-white tracking-tight">
              Class &amp; Section Attendance Comparative Breakdown
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Aggregated statistics, attendance percentages, and headcount by class and section
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onExportCsv}
              disabled={isLoading || data.length === 0}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 border border-white/10 transition disabled:opacity-40"
              title="Export CSV"
            >
              <Download className="w-3.5 h-3.5 text-indigo-400" />
              CSV
            </button>
            <button
              type="button"
              onClick={onExportExcel}
              disabled={isLoading || data.length === 0}
              className="px-3 py-1.5 rounded-xl bg-emerald-950/40 hover:bg-emerald-900/50 text-emerald-300 text-xs font-semibold flex items-center gap-1.5 border border-emerald-500/30 transition disabled:opacity-40"
              title="Export Excel"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
              Excel
            </button>
            <button
              type="button"
              onClick={async () => {
                if (!data || data.length === 0) {
                  window.print();
                  return;
                }
                const cols = ['Class & Section', 'Teacher', 'Total Enrolled', 'Present', 'Absent', 'Late', 'Half Day', 'Attendance %'];
                const rows = data.map((item) => [
                  `${item.className} - ${item.sectionName}`,
                  item.classTeacherName || 'Unassigned',
                  item.totalStudents,
                  item.present,
                  item.absent,
                  item.late,
                  item.halfDay,
                  `${(item.attendancePercentage ?? item.averageAttendancePercentage ?? 0).toFixed(1)}%`
                ]);
                await downloadTablePdf({
                  title: 'Class & Section Attendance Report',
                  columns: cols,
                  data: rows,
                  orientation: 'landscape'
                });
                await triggerSafePrint({
                  fallbackTitle: 'Class_Section_Attendance_Report'
                });
              }}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center gap-1.5 border border-white/10 transition"
              title="Print / PDF Table"
            >
              <Printer className="w-3.5 h-3.5" />
              Print / PDF
            </button>
          </div>
        </div>

        {isLoading ? (
          <div className="py-16 text-center text-slate-400 text-sm">
            Loading class attendance breakdown...
          </div>
        ) : data.length === 0 ? (
          <div className="py-16 text-center text-slate-400 text-sm bg-slate-800/20 rounded-xl">
            No class attendance records found for this selection.
          </div>
        ) : (
          <div className="overflow-x-auto rounded-xl border border-white/10">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-800/80 text-slate-400 font-bold uppercase text-[10px]">
                <tr>
                  <th className="px-4 py-3">Class</th>
                  <th className="px-4 py-3">Section</th>
                  <th className="px-4 py-3 text-center">Enrolled Students</th>
                  <th className="px-4 py-3 text-center">Total Marks</th>
                  <th className="px-4 py-3 text-center text-emerald-400">Present</th>
                  <th className="px-4 py-3 text-center text-amber-400">Late</th>
                  <th className="px-4 py-3 text-center text-purple-400">Half Day</th>
                  <th className="px-4 py-3 text-center text-blue-400">Leave</th>
                  <th className="px-4 py-3 text-center text-rose-400">Absent</th>
                  <th className="px-4 py-3 text-right">Attendance Rate</th>
                  <th className="px-4 py-3 text-center">Compliance</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 text-slate-300">
                {(data || []).map((item) => {
                  const pct = item.attendancePercentage ?? item.averageAttendancePercentage ?? 0;
                  const isOptimal = pct >= 85;
                  const isWarning = pct >= 75 && pct < 85;

                  return (
                    <tr key={`${item.classId}-${item.sectionId}`} className="hover:bg-white/[0.02]">
                      <td className="px-4 py-3 font-bold text-white">
                        {item.className}
                      </td>
                      <td className="px-4 py-3">
                        <span className="px-2 py-0.5 rounded-lg bg-slate-800 text-slate-300 font-semibold border border-white/5">
                          Section {item.sectionName}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-center font-mono text-slate-200">
                        {item.totalStudents}
                      </td>
                      <td className="px-4 py-3 text-center font-mono text-slate-400">
                        {item.totalRecords}
                      </td>
                      <td className="px-4 py-3 text-center font-mono font-bold text-emerald-400">
                        {(item as any).presentCount ?? item.present ?? 0}
                      </td>
                      <td className="px-4 py-3 text-center font-mono text-amber-400">
                        {(item as any).lateCount ?? item.late ?? 0}
                      </td>
                      <td className="px-4 py-3 text-center font-mono text-purple-400">
                        {(item as any).halfDayCount ?? item.halfDay ?? 0}
                      </td>
                      <td className="px-4 py-3 text-center font-mono text-blue-400">
                        {(item as any).leaveCount ?? item.leave ?? 0}
                      </td>
                      <td className="px-4 py-3 text-center font-mono font-bold text-rose-400">
                        {(item as any).absentCount ?? item.absent ?? 0}
                      </td>
                      <td className="px-4 py-3 text-right font-mono font-black text-sm">
                        <span
                          className={
                            isOptimal
                              ? 'text-emerald-400'
                              : isWarning
                              ? 'text-amber-400'
                              : 'text-rose-400'
                          }
                        >
                          {pct.toFixed(1)}%
                        </span>
                      </td>
                      <td className="px-4 py-3 text-center">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                            isOptimal
                              ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                              : isWarning
                              ? 'bg-amber-500/15 text-amber-300 border-amber-500/30'
                              : 'bg-rose-500/15 text-rose-300 border-rose-500/30'
                          }`}
                        >
                          {isOptimal ? 'Optimal' : isWarning ? 'Moderate' : 'Under 75%'}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
