import React from 'react';
import {
  Calendar,
  Filter,
  Search,
  RotateCcw,
  AlertTriangle,
  Users,
  Building,
  CheckCircle2,
  CalendarDays
} from 'lucide-react';
import {
  AcademicSessionItem,
  ClassItem,
  SectionItem,
  AttendanceReportFilterParams
} from '../../../../types/index.js';

interface AttendanceReportsFilterBarProps {
  filters: AttendanceReportFilterParams;
  onFilterChange: (newFilters: Partial<AttendanceReportFilterParams>) => void;
  onReset: () => void;
  academicSessions: AcademicSessionItem[];
  classes: ClassItem[];
  sections: SectionItem[];
  departments?: { id: string; name: string }[];
  showTeacherFilters?: boolean;
  showDefaulterToggle?: boolean;
  showDateRange?: boolean;
  isLoading?: boolean;
}

export const AttendanceReportsFilterBar: React.FC<AttendanceReportsFilterBarProps> = ({
  filters,
  onFilterChange,
  onReset,
  academicSessions,
  classes,
  sections,
  departments = [],
  showTeacherFilters = false,
  showDefaulterToggle = true,
  showDateRange = true,
  isLoading = false
}) => {
  // Filter sections by selected class if one is chosen
  const filteredSections = React.useMemo(() => {
    if (!filters.classId || filters.classId === 'ALL') {
      return sections;
    }
    return sections.filter((s) => s.classId === filters.classId);
  }, [sections, filters.classId]);

  // Set quick date preset helper
  const handleDatePreset = (preset: 'today' | 'yesterday' | 'last7' | 'thisMonth' | 'august2026') => {
    const today = new Date('2026-09-03'); // Current platform reference date
    const formatDate = (d: Date) => d.toISOString().split('T')[0];

    if (preset === 'today') {
      const d = formatDate(today);
      onFilterChange({ date: d, startDate: d, endDate: d });
    } else if (preset === 'yesterday') {
      const y = new Date(today);
      y.setDate(y.getDate() - 1);
      const d = formatDate(y);
      onFilterChange({ date: d, startDate: d, endDate: d });
    } else if (preset === 'last7') {
      const start = new Date(today);
      start.setDate(start.getDate() - 6);
      onFilterChange({ date: undefined, startDate: formatDate(start), endDate: formatDate(today) });
    } else if (preset === 'thisMonth') {
      onFilterChange({ date: undefined, startDate: '2026-09-01', endDate: '2026-09-30', month: '2026-09' });
    } else if (preset === 'august2026') {
      onFilterChange({ date: undefined, startDate: '2026-08-01', endDate: '2026-08-31', month: '2026-08' });
    }
  };

  const hasActiveFilters =
    (filters.classId && filters.classId !== 'ALL') ||
    (filters.sectionId && filters.sectionId !== 'ALL') ||
    (filters.status && filters.status !== 'ALL') ||
    (filters.gender && filters.gender !== 'ALL') ||
    Boolean(filters.search) ||
    Boolean(filters.belowThresholdOnly);

  return (
    <div className="bg-slate-900/90 border border-white/10 rounded-2xl p-5 shadow-xl space-y-4 backdrop-blur-md">
      {/* Top row: Quick Presets & Reset */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/5 pb-3">
        <div className="flex items-center gap-2 text-xs font-semibold text-slate-300">
          <Filter className="w-4 h-4 text-indigo-400" />
          <span>Report Filters &amp; Scopes</span>
          {hasActiveFilters && (
            <span className="px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 text-[11px] font-bold border border-indigo-500/30">
              Active Filters
            </span>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Quick Date Presets */}
          <div className="inline-flex items-center rounded-lg bg-slate-800/80 p-0.5 border border-white/10 text-xs">
            <button
              type="button"
              onClick={() => handleDatePreset('today')}
              className="px-2.5 py-1 rounded-md text-slate-300 hover:text-white hover:bg-slate-700 transition"
              title="Today (Sep 3, 2026)"
            >
              Today
            </button>
            <button
              type="button"
              onClick={() => handleDatePreset('yesterday')}
              className="px-2.5 py-1 rounded-md text-slate-300 hover:text-white hover:bg-slate-700 transition"
              title="Yesterday (Sep 2, 2026)"
            >
              Yesterday
            </button>
            <button
              type="button"
              onClick={() => handleDatePreset('last7')}
              className="px-2.5 py-1 rounded-md text-slate-300 hover:text-white hover:bg-slate-700 transition"
              title="Last 7 Days"
            >
              7 Days
            </button>
            <button
              type="button"
              onClick={() => handleDatePreset('august2026')}
              className="px-2.5 py-1 rounded-md text-indigo-300 font-semibold hover:text-indigo-200 hover:bg-indigo-950/60 transition"
              title="August 2026 (Seeded Term Data)"
            >
              Aug &apos;26 Data
            </button>
          </div>

          <button
            type="button"
            onClick={onReset}
            disabled={!hasActiveFilters || isLoading}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-400 hover:text-white hover:bg-white/5 border border-transparent hover:border-white/10 transition disabled:opacity-40"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            Reset
          </button>
        </div>
      </div>

      {/* Main Filter Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-6 gap-3">
        {/* Academic Session */}
        <div className="space-y-1">
          <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
            Academic Session
          </label>
          <select
            value={filters.academicSessionId || 'ALL'}
            onChange={(e) => onFilterChange({ academicSessionId: e.target.value })}
            className="w-full h-9 rounded-xl bg-slate-800 border border-white/10 px-3 text-xs text-white focus:outline-none focus:border-indigo-500 transition"
          >
            <option value="ALL">All Active Sessions</option>
            {academicSessions.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name} {s.isCurrent ? '(Current)' : ''}
              </option>
            ))}
          </select>
        </div>

        {/* Class Selection */}
        {!showTeacherFilters && (
          <div className="space-y-1">
            <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              Class
            </label>
            <select
              value={filters.classId || 'ALL'}
              onChange={(e) => {
                const newClass = e.target.value;
                onFilterChange({
                  classId: newClass,
                  sectionId: 'ALL' // reset section when class changes
                });
              }}
              className="w-full h-9 rounded-xl bg-slate-800 border border-white/10 px-3 text-xs text-white focus:outline-none focus:border-indigo-500 transition"
            >
              <option value="ALL">All Classes</option>
              {classes.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>
        )}

        {/* Section Selection */}
        {!showTeacherFilters && (
          <div className="space-y-1">
            <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              Section
            </label>
            <select
              value={filters.sectionId || 'ALL'}
              onChange={(e) => onFilterChange({ sectionId: e.target.value })}
              className="w-full h-9 rounded-xl bg-slate-800 border border-white/10 px-3 text-xs text-white focus:outline-none focus:border-indigo-500 transition"
              disabled={filters.classId === 'ALL'}
            >
              <option value="ALL">
                {filters.classId === 'ALL' ? 'Select class first' : 'All Sections'}
              </option>
              {filteredSections.map((s) => (
                <option key={s.id} value={s.id}>
                  Section {s.name}
                </option>
              ))}
            </select>
          </div>
        )}

        {/* Teacher Department (if in teacher report mode) */}
        {showTeacherFilters && (
          <div className="space-y-1">
            <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              Department
            </label>
            <select
              value={filters.departmentId || 'ALL'}
              onChange={(e) => onFilterChange({ departmentId: e.target.value })}
              className="w-full h-9 rounded-xl bg-slate-800 border border-white/10 px-3 text-xs text-white focus:outline-none focus:border-indigo-500 transition"
            >
              <option value="ALL">All Departments</option>
              {departments.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name}
                </option>
              ))}
            </select>
          </div>
        )}

        {/* Start Date */}
        {showDateRange && (
          <div className="space-y-1">
            <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
              <Calendar className="w-3 h-3 text-indigo-400" />
              Start Date
            </label>
            <input
              type="date"
              value={filters.startDate || ''}
              onChange={(e) => onFilterChange({ startDate: e.target.value, date: undefined })}
              className="w-full h-9 rounded-xl bg-slate-800 border border-white/10 px-3 text-xs text-white focus:outline-none focus:border-indigo-500 transition"
            />
          </div>
        )}

        {/* End Date */}
        {showDateRange && (
          <div className="space-y-1">
            <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
              <Calendar className="w-3 h-3 text-indigo-400" />
              End Date
            </label>
            <input
              type="date"
              value={filters.endDate || ''}
              onChange={(e) => onFilterChange({ endDate: e.target.value, date: undefined })}
              className="w-full h-9 rounded-xl bg-slate-800 border border-white/10 px-3 text-xs text-white focus:outline-none focus:border-indigo-500 transition"
            />
          </div>
        )}

        {/* Single Date Picker (if date range is hidden) */}
        {!showDateRange && (
          <div className="space-y-1">
            <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
              <Calendar className="w-3 h-3 text-indigo-400" />
              Date
            </label>
            <input
              type="date"
              value={filters.date || '2026-09-03'}
              onChange={(e) =>
                onFilterChange({
                  date: e.target.value,
                  startDate: e.target.value,
                  endDate: e.target.value
                })
              }
              className="w-full h-9 rounded-xl bg-slate-800 border border-white/10 px-3 text-xs text-white focus:outline-none focus:border-indigo-500 transition"
            />
          </div>
        )}

        {/* Status Filter */}
        <div className="space-y-1">
          <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
            Attendance Status
          </label>
          <select
            value={filters.status || 'ALL'}
            onChange={(e) => onFilterChange({ status: e.target.value })}
            className="w-full h-9 rounded-xl bg-slate-800 border border-white/10 px-3 text-xs text-white focus:outline-none focus:border-indigo-500 transition"
          >
            <option value="ALL">All Statuses</option>
            <option value="PRESENT">Present</option>
            <option value="LATE">Late</option>
            <option value="HALF_DAY">Half Day</option>
            <option value="ABSENT">Absent</option>
            <option value="LEAVE">Approved Leave</option>
          </select>
        </div>

        {/* Gender Filter (Students only) */}
        {!showTeacherFilters && (
          <div className="space-y-1">
            <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              Gender
            </label>
            <select
              value={filters.gender || 'ALL'}
              onChange={(e) => onFilterChange({ gender: e.target.value })}
              className="w-full h-9 rounded-xl bg-slate-800 border border-white/10 px-3 text-xs text-white focus:outline-none focus:border-indigo-500 transition"
            >
              <option value="ALL">All Genders</option>
              <option value="MALE">Male</option>
              <option value="FEMALE">Female</option>
              <option value="OTHER">Other</option>
            </select>
          </div>
        )}

        {/* Search Input */}
        <div className="space-y-1 sm:col-span-2">
          <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
            Search
          </label>
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={filters.search || ''}
              onChange={(e) => onFilterChange({ search: e.target.value })}
              placeholder={
                showTeacherFilters
                  ? 'Search by teacher name or ID...'
                  : 'Search by student name, roll no, or admission no...'
              }
              className="w-full h-9 pl-9 pr-3 rounded-xl bg-slate-800 border border-white/10 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition"
            />
          </div>
        </div>

        {/* Defaulter Toggle Button */}
        {showDefaulterToggle && !showTeacherFilters && (
          <div className="flex items-end pb-0.5">
            <button
              type="button"
              onClick={() =>
                onFilterChange({
                  belowThresholdOnly: !filters.belowThresholdOnly
                })
              }
              className={`w-full h-9 rounded-xl px-3 flex items-center justify-center gap-2 text-xs font-bold border transition ${
                filters.belowThresholdOnly
                  ? 'bg-rose-500/20 text-rose-300 border-rose-500/40 shadow-lg shadow-rose-950/40'
                  : 'bg-slate-800/80 text-slate-300 border-white/10 hover:bg-slate-700/80'
              }`}
            >
              <AlertTriangle
                className={`w-3.5 h-3.5 ${
                  filters.belowThresholdOnly ? 'text-rose-400 animate-pulse' : 'text-slate-400'
                }`}
              />
              <span>Defaulters Only (&lt;75%)</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
