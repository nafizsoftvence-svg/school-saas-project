import React, { useState } from 'react';
import {
  Calendar,
  CheckCircle2,
  XCircle,
  Clock,
  Download,
  Printer,
  FileSpreadsheet,
  ChevronLeft,
  ChevronRight,
  Filter,
  Users
} from 'lucide-react';
import {
  AttendanceDetailedRecordReportItem,
  ClassSectionAttendanceReportItem,
  AttendanceReportPagination
} from '../../../../types/index.js';
import { downloadTablePdf, triggerSafePrint } from '../../../../utils/printPdf.js';

interface DailyAttendanceReportTabProps {
  date: string;
  onDateChange: (date: string) => void;
  records: AttendanceDetailedRecordReportItem[];
  classSummaries: ClassSectionAttendanceReportItem[];
  pagination: AttendanceReportPagination;
  onPageChange: (page: number) => void;
  onExportCsv: () => void;
  onExportExcel: () => void;
  isLoading?: boolean;
}

export const DailyAttendanceReportTab: React.FC<DailyAttendanceReportTabProps> = ({
  date,
  onDateChange,
  records,
  classSummaries,
  pagination,
  onPageChange,
  onExportCsv,
  onExportExcel,
  isLoading = false
}) => {
  const [selectedStatusFilter, setSelectedStatusFilter] = useState<string>('ALL');

  // Compute stats for this date from the records
  const totalMarked = records.length;
  const presentCount = records.filter((r) => r.status === 'PRESENT').length;
  const lateCount = records.filter((r) => r.status === 'LATE').length;
  const halfDayCount = records.filter((r) => r.status === 'HALF_DAY').length;
  const leaveCount = records.filter((r) => r.status === 'LEAVE').length;
  const absentCount = records.filter((r) => r.status === 'ABSENT').length;

  const dayRate =
    totalMarked > 0
      ? Math.round(((presentCount + lateCount + halfDayCount * 0.5) / totalMarked) * 1000) / 10
      : 0;

  // Filter local view by status pill if user clicked one
  const filteredRecords = React.useMemo(() => {
    if (selectedStatusFilter === 'ALL') return records;
    return records.filter((r) => r.status === selectedStatusFilter);
  }, [records, selectedStatusFilter]);

  return (
    <div className="space-y-6">
      {/* Daily Control Strip & Summary KPIs */}
      <div className="bg-slate-900/90 border border-white/10 rounded-2xl p-6 shadow-xl space-y-5 backdrop-blur-md">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/5 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white tracking-tight">
                Daily Attendance Dossier &amp; Roster
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Comprehensive operational view for {date}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center gap-1.5 bg-slate-800 rounded-xl px-3 py-1 border border-white/10 text-xs">
              <span className="text-slate-400">Date:</span>
              <input
                type="date"
                value={date}
                onChange={(e) => onDateChange(e.target.value)}
                className="bg-transparent text-white font-mono font-bold focus:outline-none"
              />
            </div>

            <button
              type="button"
              onClick={onExportCsv}
              disabled={isLoading || records.length === 0}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 border border-white/10 transition disabled:opacity-40"
              title="Export Daily CSV"
            >
              <Download className="w-3.5 h-3.5 text-indigo-400" />
              CSV
            </button>
            <button
              type="button"
              onClick={onExportExcel}
              disabled={isLoading || records.length === 0}
              className="px-3 py-1.5 rounded-xl bg-emerald-950/40 hover:bg-emerald-900/50 text-emerald-300 text-xs font-semibold flex items-center gap-1.5 border border-emerald-500/30 transition disabled:opacity-40"
              title="Export Daily Excel"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
              Excel
            </button>
            <button
              type="button"
              onClick={async () => {
                if (!records || records.length === 0) {
                  window.print();
                  return;
                }
                const cols = ['Student Name', 'Admission No', 'Class & Sec', 'Status', 'Check-In Time', 'Recorded By', 'Remarks'];
                const rows = records.map((item) => [
                  item.studentName,
                  item.admissionNumber,
                  `${item.className} - ${item.sectionName}`,
                  item.status,
                  item.checkInTime || '-',
                  item.recordedByName || 'System',
                  item.remarks || '-'
                ]);
                await downloadTablePdf({
                  title: `Daily Attendance Master Roster (${date})`,
                  columns: cols,
                  data: rows,
                  orientation: 'landscape'
                });
                await triggerSafePrint({
                  fallbackTitle: `Daily_Attendance_${date}`
                });
              }}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center gap-1.5 border border-white/10 transition"
              title="Print / PDF Daily Sheet"
            >
              <Printer className="w-3.5 h-3.5" />
              Print / PDF
            </button>
          </div>
        </div>

        {/* 6 Quick Day Status Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          <div className="p-3.5 rounded-xl bg-slate-800/60 border border-white/5">
            <span className="text-[10px] font-bold text-slate-400 uppercase">Day Attendance</span>
            <div className="text-xl font-black text-white mt-1">{dayRate.toFixed(1)}%</div>
            <span className="text-[10px] text-slate-400">{totalMarked} students marked</span>
          </div>

          <div
            onClick={() => setSelectedStatusFilter(selectedStatusFilter === 'PRESENT' ? 'ALL' : 'PRESENT')}
            className={`p-3.5 rounded-xl border transition cursor-pointer ${
              selectedStatusFilter === 'PRESENT'
                ? 'bg-emerald-500/25 border-emerald-500/50 shadow-md shadow-emerald-950/40'
                : 'bg-emerald-500/10 border-emerald-500/20 hover:bg-emerald-500/15'
            }`}
          >
            <span className="text-[10px] font-bold text-emerald-400 uppercase flex items-center justify-between">
              Present
              <CheckCircle2 className="w-3 h-3" />
            </span>
            <div className="text-xl font-black text-emerald-400 mt-1">{presentCount}</div>
            <span className="text-[10px] text-emerald-300/80">
              {totalMarked > 0 ? ((presentCount / totalMarked) * 100).toFixed(1) : 0}% of day
            </span>
          </div>

          <div
            onClick={() => setSelectedStatusFilter(selectedStatusFilter === 'ABSENT' ? 'ALL' : 'ABSENT')}
            className={`p-3.5 rounded-xl border transition cursor-pointer ${
              selectedStatusFilter === 'ABSENT'
                ? 'bg-rose-500/25 border-rose-500/50 shadow-md shadow-rose-950/40'
                : 'bg-rose-500/10 border-rose-500/20 hover:bg-rose-500/15'
            }`}
          >
            <span className="text-[10px] font-bold text-rose-400 uppercase flex items-center justify-between">
              Absent
              <XCircle className="w-3 h-3" />
            </span>
            <div className="text-xl font-black text-rose-400 mt-1">{absentCount}</div>
            <span className="text-[10px] text-rose-300/80">Unexcused absence</span>
          </div>

          <div
            onClick={() => setSelectedStatusFilter(selectedStatusFilter === 'LEAVE' ? 'ALL' : 'LEAVE')}
            className={`p-3.5 rounded-xl border transition cursor-pointer ${
              selectedStatusFilter === 'LEAVE'
                ? 'bg-blue-500/25 border-blue-500/50 shadow-md shadow-blue-950/40'
                : 'bg-blue-500/10 border-blue-500/20 hover:bg-blue-500/15'
            }`}
          >
            <span className="text-[10px] font-bold text-blue-400 uppercase flex items-center justify-between">
              Approved Leave
              <Calendar className="w-3 h-3" />
            </span>
            <div className="text-xl font-black text-blue-400 mt-1">{leaveCount}</div>
            <span className="text-[10px] text-blue-300/80">Formal leave approved</span>
          </div>

          <div
            onClick={() => setSelectedStatusFilter(selectedStatusFilter === 'LATE' ? 'ALL' : 'LATE')}
            className={`p-3.5 rounded-xl border transition cursor-pointer ${
              selectedStatusFilter === 'LATE'
                ? 'bg-amber-500/25 border-amber-500/50 shadow-md shadow-amber-950/40'
                : 'bg-amber-500/10 border-amber-500/20 hover:bg-amber-500/15'
            }`}
          >
            <span className="text-[10px] font-bold text-amber-400 uppercase flex items-center justify-between">
              Late Arrival
              <Clock className="w-3 h-3" />
            </span>
            <div className="text-xl font-black text-amber-400 mt-1">{lateCount}</div>
            <span className="text-[10px] text-amber-300/80">Tardy arrival logged</span>
          </div>

          <div
            onClick={() => setSelectedStatusFilter(selectedStatusFilter === 'HALF_DAY' ? 'ALL' : 'HALF_DAY')}
            className={`p-3.5 rounded-xl border transition cursor-pointer ${
              selectedStatusFilter === 'HALF_DAY'
                ? 'bg-purple-500/25 border-purple-500/50 shadow-md shadow-purple-950/40'
                : 'bg-purple-500/10 border-purple-500/20 hover:bg-purple-500/15'
            }`}
          >
            <span className="text-[10px] font-bold text-purple-400 uppercase flex items-center justify-between">
              Half Day
              <Clock className="w-3 h-3" />
            </span>
            <div className="text-xl font-black text-purple-400 mt-1">{halfDayCount}</div>
            <span className="text-[10px] text-purple-300/80">0.5 day credit</span>
          </div>
        </div>
      </div>

      {/* Class Roll-up Summary Table */}
      {classSummaries.length > 0 && (
        <div className="bg-slate-900/90 border border-white/10 rounded-2xl p-6 shadow-xl space-y-4 backdrop-blur-md">
          <h4 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <Users className="w-4 h-4 text-indigo-400" />
            Class-by-Class Performance Roll-up ({date})
          </h4>

          <div className="overflow-x-auto rounded-xl border border-white/10">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-800/80 text-slate-400 font-bold uppercase text-[10px]">
                <tr>
                  <th className="px-4 py-2.5">Class &amp; Section</th>
                  <th className="px-4 py-2.5 text-center">Enrolled</th>
                  <th className="px-4 py-2.5 text-center text-emerald-400">Present</th>
                  <th className="px-4 py-2.5 text-center text-amber-400">Late</th>
                  <th className="px-4 py-2.5 text-center text-blue-400">Leave</th>
                  <th className="px-4 py-2.5 text-center text-rose-400">Absent</th>
                  <th className="px-4 py-2.5 text-right">Attendance %</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 text-slate-300">
                {classSummaries.map((cs) => {
                  const pct = cs.attendancePercentage ?? 0;
                  return (
                    <tr key={`${cs.classId}-${cs.sectionId}`} className="hover:bg-white/[0.02]">
                      <td className="px-4 py-2.5 font-bold text-white">
                        {cs.className} - Section {cs.sectionName}
                      </td>
                      <td className="px-4 py-2.5 text-center font-mono text-slate-200">
                        {cs.totalStudents}
                      </td>
                      <td className="px-4 py-2.5 text-center font-mono font-semibold text-emerald-400">
                        {cs.presentCount}
                      </td>
                      <td className="px-4 py-2.5 text-center font-mono text-amber-400">
                        {cs.lateCount}
                      </td>
                      <td className="px-4 py-2.5 text-center font-mono text-blue-400">
                        {cs.leaveCount}
                      </td>
                      <td className="px-4 py-2.5 text-center font-mono text-rose-400 font-semibold">
                        {cs.absentCount}
                      </td>
                      <td className="px-4 py-2.5 text-right font-mono font-bold">
                        <span
                          className={`px-2 py-0.5 rounded-full text-xs ${
                            pct >= 85
                              ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                              : pct >= 75
                              ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                              : 'bg-rose-500/15 text-rose-300 border border-rose-500/30'
                          }`}
                        >
                          {pct.toFixed(1)}%
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Detailed Student Roster on this Date */}
      <div className="bg-slate-900/90 border border-white/10 rounded-2xl p-6 shadow-xl space-y-4 backdrop-blur-md">
        <div className="flex items-center justify-between border-b border-white/5 pb-3">
          <h4 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <Calendar className="w-4 h-4 text-indigo-400" />
            Individual Student Attendance Logs ({filteredRecords.length} records)
          </h4>
          {selectedStatusFilter !== 'ALL' && (
            <button
              type="button"
              onClick={() => setSelectedStatusFilter('ALL')}
              className="text-xs text-indigo-400 hover:text-indigo-300 font-semibold underline"
            >
              Clear {selectedStatusFilter} filter
            </button>
          )}
        </div>

        {isLoading ? (
          <div className="py-12 text-center text-slate-400 text-xs">
            Loading daily attendance logs...
          </div>
        ) : filteredRecords.length === 0 ? (
          <div className="py-12 text-center text-slate-400 text-xs bg-slate-800/20 rounded-xl">
            No attendance records found for this date.
          </div>
        ) : (
          <div className="overflow-x-auto rounded-xl border border-white/10">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-800/80 text-slate-400 font-bold uppercase text-[10px]">
                <tr>
                  <th className="px-4 py-2.5">Student</th>
                  <th className="px-4 py-2.5">Class &amp; Section</th>
                  <th className="px-4 py-2.5">Status</th>
                  <th className="px-4 py-2.5">Remarks / Reason</th>
                  <th className="px-4 py-2.5">Marked Time</th>
                  <th className="px-4 py-2.5">Marked By</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 text-slate-300">
                {filteredRecords.map((r) => {
                  const badgeClass =
                    r.status === 'PRESENT'
                      ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                      : r.status === 'LATE'
                      ? 'bg-amber-500/15 text-amber-300 border-amber-500/30'
                      : r.status === 'HALF_DAY'
                      ? 'bg-purple-500/15 text-purple-300 border-purple-500/30'
                      : r.status === 'LEAVE'
                      ? 'bg-blue-500/15 text-blue-300 border-blue-500/30'
                      : 'bg-rose-500/15 text-rose-300 border-rose-500/30';

                  return (
                    <tr key={r.id} className="hover:bg-white/[0.02]">
                      <td className="px-4 py-2.5">
                        <div className="font-bold text-white">{r.studentName}</div>
                        <div className="text-[11px] text-slate-400">Adm: {r.admissionNumber}</div>
                      </td>
                      <td className="px-4 py-2.5">
                        {r.className} - {r.sectionName}
                      </td>
                      <td className="px-4 py-2.5">
                        <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold border ${badgeClass}`}>
                          {r.status}
                        </span>
                      </td>
                      <td className="px-4 py-2.5 text-slate-300 max-w-xs truncate">
                        {r.remarks || '—'}
                      </td>
                      <td className="px-4 py-2.5 text-slate-400 font-mono text-[11px]">
                        {r.markedAt
                          ? new Date(r.markedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                          : '—'}
                      </td>
                      <td className="px-4 py-2.5 text-slate-400">
                        {r.markedByName || 'System'}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* Pagination */}
        {pagination.totalPages > 1 && (
          <div className="flex items-center justify-between pt-3 border-t border-white/5 text-xs text-slate-400">
            <div>
              Page <span className="font-bold text-white">{pagination.page}</span> of{' '}
              <span className="font-bold text-white">{pagination.totalPages}</span>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                disabled={pagination.page <= 1}
                onClick={() => onPageChange(pagination.page - 1)}
                className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 disabled:opacity-40 transition flex items-center gap-1"
              >
                <ChevronLeft className="w-3.5 h-3.5" />
                Prev
              </button>
              <button
                type="button"
                disabled={pagination.page >= pagination.totalPages}
                onClick={() => onPageChange(pagination.page + 1)}
                className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 disabled:opacity-40 transition flex items-center gap-1"
              >
                Next
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
