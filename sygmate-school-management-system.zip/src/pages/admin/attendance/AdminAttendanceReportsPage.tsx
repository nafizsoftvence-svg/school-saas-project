import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  BarChart3,
  Calendar,
  Users,
  Building,
  AlertTriangle,
  FileSpreadsheet,
  Download,
  Printer,
  RefreshCw,
  Clock,
  Layers,
  Sparkles,
  TrendingUp,
  ShieldCheck,
  CheckCircle2,
  CalendarDays,
  FileText
} from 'lucide-react';
import { api } from '../../../services/api.js';
import {
  AcademicSessionItem,
  ClassItem,
  SectionItem,
  AttendanceReportFilterParams,
  AttendanceReportDashboardData,
  StudentWiseAttendanceReportItem,
  ClassSectionAttendanceReportItem,
  TeacherAttendanceReportItem,
  AttendanceDetailedRecordReportItem,
  LeaveReportItem,
  AttendanceReportPagination
} from '../../../types/index.js';
import { AttendanceReportsFilterBar } from './reports/AttendanceReportsFilterBar.js';
import { AttendanceDashboardKPIs } from './reports/AttendanceDashboardKPIs.js';
import { DailyAttendanceReportTab } from './reports/DailyAttendanceReportTab.js';
import { StudentAttendanceReportTab } from './reports/StudentAttendanceReportTab.js';
import { ClassSectionReportTab } from './reports/ClassSectionReportTab.js';
import { DefaultersReportTab } from './reports/DefaultersReportTab.js';
import { TeacherAttendanceReportTab } from './reports/TeacherAttendanceReportTab.js';
import { LeaveImpactReportTab } from './reports/LeaveImpactReportTab.js';

interface AdminAttendanceReportsPageProps {
  onNavigate?: (viewId: string) => void;
  activeTab?: TabType;
  onTabChange?: (tab: TabType) => void;
  hideTabBar?: boolean;
}

type TabType =
  | 'DASHBOARD'
  | 'DAILY'
  | 'STUDENTS'
  | 'CLASSES'
  | 'DEFAULTERS'
  | 'TEACHERS'
  | 'LEAVES'
  | 'RAW_LOGS';

export const AdminAttendanceReportsPage: React.FC<AdminAttendanceReportsPageProps> = ({
  onNavigate,
  activeTab: propActiveTab,
  onTabChange,
  hideTabBar = true
}) => {
  const [internalTab, setInternalTab] = useState<TabType>('DASHBOARD');
  const activeTab = propActiveTab || internalTab;

  const setActiveTab = (tab: TabType) => {
    setInternalTab(tab);
    onTabChange?.(tab);
  };

  // Context metadata
  const [academicSessions, setAcademicSessions] = useState<AcademicSessionItem[]>([]);
  const [classes, setClasses] = useState<ClassItem[]>([]);
  const [sections, setSections] = useState<SectionItem[]>([]);
  const [departments, setDepartments] = useState<{ id: string; name: string }[]>([]);

  // Filter state
  const [filters, setFilters] = useState<AttendanceReportFilterParams>({
    academicSessionId: 'ALL',
    classId: 'ALL',
    sectionId: 'ALL',
    date: '2026-09-03',
    startDate: '2026-08-01',
    endDate: '2026-09-03',
    month: '',
    status: 'ALL',
    gender: 'ALL',
    search: '',
    belowThresholdOnly: false,
    page: 1,
    limit: 25,
    sortBy: 'attendancePercentage',
    sortOrder: 'asc'
  });

  // Data states
  const [dashboardData, setDashboardData] = useState<AttendanceReportDashboardData | null>(null);
  const [studentsData, setStudentsData] = useState<StudentWiseAttendanceReportItem[]>([]);
  const [studentsPagination, setStudentsPagination] = useState<AttendanceReportPagination>({
    page: 1,
    limit: 25,
    total: 0,
    totalPages: 1
  });

  const [classesData, setClassesData] = useState<ClassSectionAttendanceReportItem[]>([]);
  const [recordsData, setRecordsData] = useState<AttendanceDetailedRecordReportItem[]>([]);
  const [recordsPagination, setRecordsPagination] = useState<AttendanceReportPagination>({
    page: 1,
    limit: 50,
    total: 0,
    totalPages: 1
  });

  const [teachersData, setTeachersData] = useState<TeacherAttendanceReportItem[]>([]);
  const [teachersPagination, setTeachersPagination] = useState<AttendanceReportPagination>({
    page: 1,
    limit: 25,
    total: 0,
    totalPages: 1
  });

  const [leavesData, setLeavesData] = useState<LeaveReportItem[]>([]);
  const [leavesPagination, setLeavesPagination] = useState<AttendanceReportPagination>({
    page: 1,
    limit: 25,
    total: 0,
    totalPages: 1
  });

  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [exportNotice, setExportNotice] = useState<string | null>(null);

  // Load contextual master metadata once
  useEffect(() => {
    const fetchMetadata = async () => {
      try {
        const [sessRes, classRes, secRes, deptRes] = await Promise.all([
          api.getAcademicSessions(),
          api.getClasses(),
          api.getSections(),
          api.getDepartments()
        ]);

        if (sessRes.success && sessRes.data) {
          setAcademicSessions(sessRes.data);
        }
        if (classRes.success && classRes.data) {
          setClasses(classRes.data);
        }
        if (secRes.success && secRes.data) {
          setSections(secRes.data);
        }
        if (deptRes.success && deptRes.data) {
          setDepartments(deptRes.data);
        }
      } catch (err) {
        console.error('Failed to load attendance report metadata:', err);
      }
    };

    fetchMetadata();
  }, []);

  // Fetch report data according to current active tab and filters
  const loadActiveTabData = useCallback(async () => {
    setIsLoading(true);
    try {
      if (activeTab === 'DASHBOARD') {
        const res = await api.getAttendanceReportsDashboard(filters);
        if (res.success && res.data) {
          setDashboardData(res.data);
        }
      } else if (activeTab === 'DAILY') {
        // Fetch both the single date raw records and class roll-ups
        const [recRes, classRes] = await Promise.all([
          api.getAttendanceReportsRecords({
            ...filters,
            date: filters.date || '2026-09-03',
            startDate: undefined,
            endDate: undefined
          }),
          api.getAttendanceReportsClasses({
            ...filters,
            date: filters.date || '2026-09-03',
            startDate: undefined,
            endDate: undefined
          })
        ]);
        if (recRes.success && recRes.data) {
          const list = Array.isArray(recRes.data) ? recRes.data : Array.isArray((recRes.data as any).data) ? (recRes.data as any).data : [];
          setRecordsData(list);
          setRecordsPagination((recRes as any).pagination || (recRes.data as any)?.pagination);
        }
        if (classRes.success && classRes.data) {
          const list = Array.isArray(classRes.data) ? classRes.data : Array.isArray((classRes.data as any).data) ? (classRes.data as any).data : [];
          setClassesData(list);
        }
      } else if (activeTab === 'STUDENTS') {
        const res = await api.getAttendanceReportsStudents(filters);
        if (res.success && res.data) {
          const list = Array.isArray(res.data) ? res.data : Array.isArray((res.data as any).data) ? (res.data as any).data : [];
          setStudentsData(list);
          setStudentsPagination((res as any).pagination || (res.data as any)?.pagination);
        }
      } else if (activeTab === 'CLASSES') {
        const res = await api.getAttendanceReportsClasses(filters);
        if (res.success && res.data) {
          const list = Array.isArray(res.data) ? res.data : Array.isArray((res.data as any).data) ? (res.data as any).data : [];
          setClassesData(list);
        }
      } else if (activeTab === 'DEFAULTERS') {
        // Enforce belowThresholdOnly=true for defaulters tab
        const res = await api.getAttendanceReportsStudents({
          ...filters,
          belowThresholdOnly: true,
          limit: 100
        });
        if (res.success && res.data) {
          const list = Array.isArray(res.data) ? res.data : Array.isArray((res.data as any).data) ? (res.data as any).data : [];
          setStudentsData(list);
          setStudentsPagination((res as any).pagination || (res.data as any)?.pagination);
        }
      } else if (activeTab === 'TEACHERS') {
        const res = await api.getAttendanceReportsTeachers(filters);
        if (res.success && res.data) {
          const list = Array.isArray(res.data) ? res.data : Array.isArray((res.data as any).data) ? (res.data as any).data : [];
          setTeachersData(list);
          setTeachersPagination((res as any).pagination || (res.data as any)?.pagination);
        }
      } else if (activeTab === 'LEAVES') {
        const res = await api.getAttendanceReportsLeaves(filters);
        if (res.success && res.data) {
          const list = Array.isArray(res.data) ? res.data : Array.isArray((res.data as any).data) ? (res.data as any).data : [];
          setLeavesData(list);
          setLeavesPagination((res as any).pagination || (res.data as any)?.pagination);
        }
      } else if (activeTab === 'RAW_LOGS') {
        const res = await api.getAttendanceReportsRecords(filters);
        if (res.success && res.data) {
          const list = Array.isArray(res.data) ? res.data : Array.isArray((res.data as any).data) ? (res.data as any).data : [];
          setRecordsData(list);
          setRecordsPagination((res as any).pagination || (res.data as any)?.pagination);
        }
      }
    } catch (err) {
      console.error('Failed to load attendance report tab data:', err);
    } finally {
      setIsLoading(false);
    }
  }, [activeTab, filters]);

  // Trigger data load when activeTab or filters change
  useEffect(() => {
    loadActiveTabData();
  }, [loadActiveTabData]);

  // Export handlers with backend audit logging
  const handleExport = async (format: 'CSV' | 'EXCEL', reportName: string, headers: string[], rows: (string | number)[][]) => {
    try {
      const extension = format === 'CSV' ? 'csv' : 'xls';
      const separator = format === 'CSV' ? ',' : '\t';
      const mime = format === 'CSV' ? 'text/csv;charset=utf-8;' : 'application/vnd.ms-excel;charset=utf-8;';

      const content = [
        `SYGMATE SCHOOL MANAGEMENT SYSTEM - ATTENDANCE REPORT`,
        `Report Type: ${reportName}`,
        `Generated At: ${new Date().toLocaleString()} (System Ref: 2026-09-03)`,
        `Academic Session: ${filters.academicSessionId || 'ALL'}`,
        `Date Scope: ${filters.startDate || 'N/A'} to ${filters.endDate || 'N/A'}`,
        '',
        headers.join(separator),
        ...rows.map((r) =>
          r
            .map((val) => {
              const s = String(val ?? '');
              return s.includes(',') || s.includes('"') || s.includes('\n')
                ? `"${s.replace(/"/g, '""')}"`
                : s;
            })
            .join(separator)
        )
      ].join('\n');

      const blob = new Blob([content], { type: mime });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${reportName.replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0]}.${extension}`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      // Audit export in backend
      await api.auditAttendanceReportExport({
        reportType: reportName,
        format,
        filters,
        recordCount: rows.length
      });

      setExportNotice(`Exported ${rows.length} records to ${format}. Audit log recorded.`);
      setTimeout(() => setExportNotice(null), 4000);
    } catch (err) {
      console.error('Export failed:', err);
      alert('Failed to export report.');
    }
  };

  // Export Dispatcher for Student Report
  const exportStudents = (format: 'CSV' | 'EXCEL') => {
    const headers = [
      'Student ID',
      'Student Name',
      'Admission No',
      'Roll No',
      'Class',
      'Section',
      'Working Days',
      'Present',
      'Late',
      'Half Day',
      'Approved Leave',
      'Absent',
      'Attendance %',
      'Compliance Status'
    ];
    const rows = studentsData.map((s) => [
      s.studentId,
      s.studentName,
      s.admissionNumber,
      s.rollNumber || '',
      s.className,
      s.sectionName,
      s.totalWorkingDays,
      s.presentDays,
      s.lateDays,
      s.halfDays,
      s.leaveDays,
      s.absentDays,
      `${Number(s.attendancePercentage ?? 0).toFixed(1)}%`,
      (s.attendancePercentage ?? 0) >= 85 ? 'Optimal' : (s.attendancePercentage ?? 0) >= 75 ? 'Moderate' : 'Defaulter'
    ]);
    handleExport(format, 'Student_Attendance_Summary', headers, rows);
  };

  // Export Dispatcher for Class Report
  const exportClasses = (format: 'CSV' | 'EXCEL') => {
    const headers = [
      'Class',
      'Section',
      'Total Enrolled',
      'Total Marked',
      'Present',
      'Late',
      'Half Day',
      'Approved Leave',
      'Absent',
      'Attendance Rate %'
    ];
    const rows = classesData.map((c) => [
      c.className,
      c.sectionName,
      c.totalStudents,
      c.totalRecords,
      (c as any).presentCount ?? c.present ?? 0,
      (c as any).lateCount ?? c.late ?? 0,
      (c as any).halfDayCount ?? c.halfDay ?? 0,
      (c as any).leaveCount ?? c.leave ?? 0,
      (c as any).absentCount ?? c.absent ?? 0,
      `${(c.attendancePercentage ?? (c as any).averageAttendancePercentage ?? 0).toFixed(1)}%`
    ]);
    handleExport(format, 'Class_Section_Attendance_Report', headers, rows);
  };

  // Export Dispatcher for Daily Report
  const exportDaily = (format: 'CSV' | 'EXCEL') => {
    const headers = [
      'Record ID',
      'Date',
      'Student Name',
      'Admission No',
      'Class',
      'Section',
      'Status',
      'Marked Time',
      'Remarks',
      'Marked By'
    ];
    const rows = recordsData.map((r) => [
      r.id,
      r.date,
      r.studentName,
      r.admissionNumber,
      r.className,
      r.sectionName,
      r.status,
      r.markedAt || '',
      r.remarks || '',
      r.markedByName || 'System'
    ]);
    handleExport(format, `Daily_Attendance_${filters.date || 'Today'}`, headers, rows);
  };

  // Export Dispatcher for Faculty Report
  const exportTeachers = (format: 'CSV' | 'EXCEL') => {
    const headers = [
      'Faculty ID',
      'Faculty Name',
      'Designation',
      'Department',
      'Working Days',
      'Present Days',
      'Late Days',
      'Leave Days',
      'Absent Days',
      'Attendance %'
    ];
    const rows = teachersData.map((t) => [
      t.teacherId,
      t.teacherName,
      t.designation || '',
      t.departmentName,
      t.totalWorkingDays,
      t.presentDays,
      t.lateDays,
      t.leaveDays,
      t.absentDays,
      `${(t.attendancePercentage ?? (t as any).averageAttendancePercentage ?? 0).toFixed(1)}%`
    ]);
    handleExport(format, 'Faculty_Attendance_Report', headers, rows);
  };

  // Export Dispatcher for Leaves Report
  const exportLeaves = (format: 'CSV' | 'EXCEL') => {
    const headers = [
      'Application ID',
      'Applicant Name',
      'Applicant Type',
      'Leave Type',
      'Start Date',
      'End Date',
      'Total Days',
      'Reason',
      'Status',
      'Action Taken By'
    ];
    const rows = leavesData.map((l) => [
      l.id,
      l.applicantName,
      l.applicantType,
      l.leaveTypeName,
      l.startDate,
      l.endDate,
      l.totalDays,
      l.reason,
      l.status,
      l.actionTakenByName || ''
    ]);
    handleExport(format, 'Leave_Applications_Impact_Report', headers, rows);
  };

  return (
    <div className="space-y-6 pb-20">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-slate-900 border border-white/10 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20" />
        <div className="space-y-1 relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
            <BarChart3 className="w-3.5 h-3.5" />
            PART 8E &bull; ATTENDANCE REPORTS &amp; ANALYTICS
          </div>
          <h1 className="text-2xl font-black text-white tracking-tight">
            Institutional Attendance Reports &amp; Analytics
          </h1>
          <p className="text-xs text-slate-400 max-w-2xl leading-relaxed">
            Real-time multi-dimensional reporting across daily registers, cumulative term benchmarks,
            class comparisons, faculty tracking, leave correlation, and mandatory 75% regulatory defaulters.
          </p>
        </div>

        <div className="flex items-center gap-3 relative z-10">
          <button
            type="button"
            onClick={() => loadActiveTabData()}
            disabled={isLoading}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-2 border border-white/10 transition disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-indigo-400 ${isLoading ? 'animate-spin' : ''}`} />
            Refresh Data
          </button>
        </div>
      </div>

      {/* Export Confirmation Toast */}
      {exportNotice && (
        <div className="p-3.5 bg-emerald-500/20 border border-emerald-500/40 rounded-xl text-xs font-semibold text-emerald-300 flex items-center gap-2 shadow-lg animate-fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{exportNotice}</span>
        </div>
      )}

      {/* Primary Navigation Tabs (Hidden when subtabs are hosted in sidebar) */}
      {!hideTabBar && (
        <div className="flex items-center gap-1.5 overflow-x-auto pb-2 border-b border-white/10 scrollbar-none">
          <button
            type="button"
            onClick={() => setActiveTab('DASHBOARD')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold transition flex items-center gap-2 shrink-0 ${
              activeTab === 'DASHBOARD'
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                : 'bg-slate-900/60 text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <BarChart3 className="w-4 h-4" />
            Executive Analytics
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('DAILY')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold transition flex items-center gap-2 shrink-0 ${
              activeTab === 'DAILY'
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                : 'bg-slate-900/60 text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Calendar className="w-4 h-4" />
            Daily Register Report
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('STUDENTS')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold transition flex items-center gap-2 shrink-0 ${
              activeTab === 'STUDENTS'
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                : 'bg-slate-900/60 text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Users className="w-4 h-4" />
            Student-wise Report
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('CLASSES')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold transition flex items-center gap-2 shrink-0 ${
              activeTab === 'CLASSES'
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                : 'bg-slate-900/60 text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Layers className="w-4 h-4" />
            Class &amp; Section Breakdown
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('DEFAULTERS')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold transition flex items-center gap-2 shrink-0 ${
              activeTab === 'DEFAULTERS'
                ? 'bg-rose-600 text-white shadow-lg shadow-rose-600/30'
                : 'bg-slate-900/60 text-rose-300 hover:text-white hover:bg-slate-800'
            }`}
          >
            <AlertTriangle className="w-4 h-4 text-rose-400" />
            Defaulters (&lt;75%)
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('TEACHERS')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold transition flex items-center gap-2 shrink-0 ${
              activeTab === 'TEACHERS'
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                : 'bg-slate-900/60 text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Building className="w-4 h-4" />
            Faculty Attendance
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('LEAVES')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold transition flex items-center gap-2 shrink-0 ${
              activeTab === 'LEAVES'
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                : 'bg-slate-900/60 text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <CalendarDays className="w-4 h-4" />
            Leave Impact Analytics
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('RAW_LOGS')}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold transition flex items-center gap-2 shrink-0 ${
              activeTab === 'RAW_LOGS'
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                : 'bg-slate-900/60 text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Clock className="w-4 h-4" />
            Raw Audit Logs
          </button>
        </div>
      )}

      {/* Global Filter Bar */}
      <AttendanceReportsFilterBar
        filters={filters}
        onFilterChange={(newF) => setFilters((prev) => ({ ...prev, ...newF, page: 1 }))}
        onReset={() =>
          setFilters({
            academicSessionId: 'ALL',
            classId: 'ALL',
            sectionId: 'ALL',
            date: '2026-09-03',
            startDate: '2026-08-01',
            endDate: '2026-09-03',
            month: '',
            status: 'ALL',
            gender: 'ALL',
            search: '',
            belowThresholdOnly: false,
            page: 1,
            limit: 25,
            sortBy: 'attendancePercentage',
            sortOrder: 'asc'
          })
        }
        academicSessions={academicSessions}
        classes={classes}
        sections={sections}
        departments={departments}
        showTeacherFilters={activeTab === 'TEACHERS'}
        showDefaulterToggle={activeTab === 'STUDENTS'}
        showDateRange={activeTab !== 'DAILY'}
        isLoading={isLoading}
      />

      {/* Tab 1: Executive Dashboard View */}
      {activeTab === 'DASHBOARD' && dashboardData && (
        <AttendanceDashboardKPIs
          data={dashboardData}
          onSelectClass={(cid) => {
            setFilters((prev) => ({ ...prev, classId: cid, sectionId: 'ALL' }));
            setActiveTab('CLASSES');
          }}
          onFilterDefaulters={() => setActiveTab('DEFAULTERS')}
        />
      )}

      {/* Tab 2: Daily Attendance Report */}
      {activeTab === 'DAILY' && (
        <DailyAttendanceReportTab
          date={filters.date || '2026-09-03'}
          onDateChange={(d) => setFilters((prev) => ({ ...prev, date: d, startDate: d, endDate: d }))}
          records={recordsData}
          classSummaries={classesData}
          pagination={recordsPagination}
          onPageChange={(p) => setFilters((prev) => ({ ...prev, page: p }))}
          onExportCsv={() => exportDaily('CSV')}
          onExportExcel={() => exportDaily('EXCEL')}
          isLoading={isLoading}
        />
      )}

      {/* Tab 3: Student-wise Cumulative Report */}
      {activeTab === 'STUDENTS' && (
        <StudentAttendanceReportTab
          data={studentsData}
          pagination={studentsPagination}
          onPageChange={(p) => setFilters((prev) => ({ ...prev, page: p }))}
          onSortChange={(sb, so) => setFilters((prev) => ({ ...prev, sortBy: sb, sortOrder: so }))}
          sortBy={filters.sortBy}
          sortOrder={filters.sortOrder}
          onExportCsv={() => exportStudents('CSV')}
          onExportExcel={() => exportStudents('EXCEL')}
          academicSessionId={filters.academicSessionId}
          isLoading={isLoading}
        />
      )}

      {/* Tab 4: Class & Section Breakdown */}
      {activeTab === 'CLASSES' && (
        <ClassSectionReportTab
          data={classesData}
          onExportCsv={() => exportClasses('CSV')}
          onExportExcel={() => exportClasses('EXCEL')}
          isLoading={isLoading}
        />
      )}

      {/* Tab 5: Defaulters / At-Risk (<75%) Report */}
      {activeTab === 'DEFAULTERS' && (
        <DefaultersReportTab
          data={studentsData}
          pagination={studentsPagination}
          onPageChange={(p) => setFilters((prev) => ({ ...prev, page: p }))}
          onExportCsv={() => exportStudents('CSV')}
          onExportExcel={() => exportStudents('EXCEL')}
          academicSessionId={filters.academicSessionId}
          isLoading={isLoading}
        />
      )}

      {/* Tab 6: Faculty Attendance Report */}
      {activeTab === 'TEACHERS' && (
        <TeacherAttendanceReportTab
          data={teachersData}
          pagination={teachersPagination}
          onPageChange={(p) => setFilters((prev) => ({ ...prev, page: p }))}
          onExportCsv={() => exportTeachers('CSV')}
          onExportExcel={() => exportTeachers('EXCEL')}
          isLoading={isLoading}
        />
      )}

      {/* Tab 7: Leave Impact Analytics */}
      {activeTab === 'LEAVES' && (
        <LeaveImpactReportTab
          data={leavesData}
          pagination={leavesPagination}
          onPageChange={(p) => setFilters((prev) => ({ ...prev, page: p }))}
          onExportCsv={() => exportLeaves('CSV')}
          onExportExcel={() => exportLeaves('EXCEL')}
          isLoading={isLoading}
        />
      )}

      {/* Tab 8: Raw Detailed Attendance Records & Audit Trail */}
      {activeTab === 'RAW_LOGS' && (
        <div className="bg-slate-900/90 border border-white/10 rounded-2xl p-6 shadow-xl space-y-5 backdrop-blur-md">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/5 pb-4">
            <div>
              <h3 className="text-base font-bold text-white tracking-tight">
                Raw Attendance Audit Trail &amp; Ledger
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Low-level granular records with timestamps, modifier identities, and audit integrity
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => exportDaily('CSV')}
                disabled={isLoading || (recordsData?.length || 0) === 0}
                className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 border border-white/10 transition disabled:opacity-40"
              >
                <Download className="w-3.5 h-3.5 text-indigo-400" />
                CSV
              </button>
              <button
                type="button"
                onClick={() => exportDaily('EXCEL')}
                disabled={isLoading || (recordsData?.length || 0) === 0}
                className="px-3 py-1.5 rounded-xl bg-emerald-950/40 hover:bg-emerald-900/50 text-emerald-300 text-xs font-semibold flex items-center gap-1.5 border border-emerald-500/30 transition disabled:opacity-40"
              >
                <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
                Excel
              </button>
            </div>
          </div>

          <div className="overflow-x-auto rounded-xl border border-white/10">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-800/80 text-slate-400 font-bold uppercase text-[10px]">
                <tr>
                  <th className="px-4 py-2.5">Date</th>
                  <th className="px-4 py-2.5">Student Name</th>
                  <th className="px-4 py-2.5">Class / Section</th>
                  <th className="px-4 py-2.5">Status</th>
                  <th className="px-4 py-2.5">Remarks</th>
                  <th className="px-4 py-2.5">Marked At</th>
                  <th className="px-4 py-2.5">Marked By</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 text-slate-300">
                {recordsData.map((r) => (
                  <tr key={r.id} className="hover:bg-white/[0.02]">
                    <td className="px-4 py-2.5 font-mono font-bold text-white">{r.date}</td>
                    <td className="px-4 py-2.5 font-bold text-white">{r.studentName}</td>
                    <td className="px-4 py-2.5">{r.className} - {r.sectionName}</td>
                    <td className="px-4 py-2.5">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold border bg-slate-800 text-slate-200 border-white/10">
                        {r.status}
                      </span>
                    </td>
                    <td className="px-4 py-2.5 max-w-xs truncate text-slate-400">{r.remarks || '—'}</td>
                    <td className="px-4 py-2.5 font-mono text-slate-400">{r.markedAt ? new Date(r.markedAt).toLocaleString() : '—'}</td>
                    <td className="px-4 py-2.5 text-slate-400">{r.markedByName || 'System'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
