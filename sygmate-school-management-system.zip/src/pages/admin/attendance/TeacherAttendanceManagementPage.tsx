import React, { useState, useEffect, useMemo } from 'react';
import {
  UserCheck,
  Calendar,
  Search,
  Filter,
  CheckCircle2,
  XCircle,
  Clock,
  AlertCircle,
  Save,
  RotateCcw,
  RefreshCw,
  Edit3,
  CalendarDays,
  ChevronRight,
  ChevronLeft,
  Users,
  Building,
  GraduationCap,
  TrendingUp,
  FileText,
  Eye,
  Info,
  ShieldCheck,
  Sparkles,
  HelpCircle,
  Check,
  X,
  AlertTriangle,
  History,
  Trash2,
  Download,
  Plus
} from 'lucide-react';
import { api } from '../../../services/api.js';
import { useAuth } from '../../../context/AuthContext.js';
import { useSettings } from '../../../context/SettingsContext.js';
import {
  TeacherAttendanceRecord,
  TeacherAttendanceStatus,
  TeacherAttendanceCorrectionHistoryItem,
  TeacherDailyAttendanceResponse,
  TeacherDailyAttendanceRosterItem,
  TeacherMonthlyAttendanceResponse,
  TeacherMonthlyMatrixRow,
  Department,
  AcademicSession
} from '../../../types/index.js';
import { AdminLeaveManagementTab } from './AdminLeaveManagementTab.js';

interface TeacherAttendanceManagementPageProps {
  activeTab?: 'daily' | 'monthly' | 'history' | 'leave_management';
  onTabChange?: (tab: 'daily' | 'monthly' | 'history' | 'leave_management') => void;
  hideTabBar?: boolean;
}

export const TeacherAttendanceManagementPage: React.FC<TeacherAttendanceManagementPageProps> = ({
  activeTab: propActiveTab,
  onTabChange,
  hideTabBar = true
}) => {
  const { user } = useAuth();
  const { settings, activeSession } = useSettings();

  // Navigation tab: 'daily' | 'monthly' | 'history' | 'leave_management'
  const [internalTab, setInternalTab] = useState<'daily' | 'monthly' | 'history' | 'leave_management'>('daily');
  const activeTab = propActiveTab || internalTab;

  const setActiveTab = (tab: 'daily' | 'monthly' | 'history' | 'leave_management') => {
    setInternalTab(tab);
    onTabChange?.(tab);
  };

  // Academic Sessions & Departments
  const [academicSessions, setAcademicSessions] = useState<AcademicSession[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [selectedSessionId, setSelectedSessionId] = useState<string>('');

  // Daily View State
  const [selectedDate, setSelectedDate] = useState<string>(() => {
    return new Date().toISOString().split('T')[0];
  });
  const [dailyData, setDailyData] = useState<TeacherDailyAttendanceResponse | null>(null);
  const [dailyLoading, setDailyLoading] = useState(false);
  const [dailySearch, setDailySearch] = useState('');
  const [dailyDepartmentId, setDailyDepartmentId] = useState('ALL');
  const [dailyStatusFilter, setDailyStatusFilter] = useState<string>('ALL');

  // Local draft roster for daily marking
  const [draftRoster, setDraftRoster] = useState<
    Array<{
      teacherProfileId: string;
      status?: TeacherAttendanceStatus;
      checkInTime?: string;
      checkOutTime?: string;
      remarks?: string;
      isDirty?: boolean;
    }>
  >([]);
  const [savingDaily, setSavingDaily] = useState(false);
  const [allowOverride, setAllowOverride] = useState(false);
  const [overrideReason, setOverrideReason] = useState('');

  // Monthly Matrix State
  const [monthlyYear, setMonthlyYear] = useState<number>(() => new Date().getFullYear());
  const [monthlyMonth, setMonthlyMonth] = useState<number>(() => new Date().getMonth() + 1);
  const [monthlyDepartmentId, setMonthlyDepartmentId] = useState('ALL');
  const [monthlySearch, setMonthlySearch] = useState('');
  const [monthlyData, setMonthlyData] = useState<TeacherMonthlyAttendanceResponse | null>(null);
  const [monthlyLoading, setMonthlyLoading] = useState(false);

  // History & Audit State
  const [historyRecords, setHistoryRecords] = useState<TeacherAttendanceRecord[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);
  const [historySearch, setHistorySearch] = useState('');
  const [historyStatus, setHistoryStatus] = useState('ALL');
  const [historyDepartmentId, setHistoryDepartmentId] = useState('ALL');
  const [historyStartDate, setHistoryStartDate] = useState('');
  const [historyEndDate, setHistoryEndDate] = useState('');

  // Modals
  const [selectedRosterItemForEdit, setSelectedRosterItemForEdit] = useState<TeacherDailyAttendanceRosterItem | null>(null);
  const [editModalStatus, setEditModalStatus] = useState<TeacherAttendanceStatus>('PRESENT');
  const [editModalCheckIn, setEditModalCheckIn] = useState('');
  const [editModalCheckOut, setEditModalCheckOut] = useState('');
  const [editModalRemarks, setEditModalRemarks] = useState('');
  const [editModalReason, setEditModalReason] = useState('');
  const [savingEdit, setSavingEdit] = useState(false);

  // Correction History Modal
  const [viewHistoryRecord, setViewHistoryRecord] = useState<TeacherAttendanceRecord | null>(null);

  // Delete/Void Modal
  const [deleteModalRecordId, setDeleteModalRecordId] = useState<string | null>(null);
  const [deleteReason, setDeleteReason] = useState('');
  const [deletingRecord, setDeletingRecord] = useState(false);

  // Manual Add Modal
  const [showAddModal, setShowAddModal] = useState(false);
  const [addTeacherId, setAddTeacherId] = useState('');
  const [addDate, setAddDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [addStatus, setAddStatus] = useState<TeacherAttendanceStatus>('PRESENT');
  const [addCheckIn, setAddCheckIn] = useState('08:00');
  const [addCheckOut, setAddCheckOut] = useState('16:00');
  const [addRemarks, setAddRemarks] = useState('');
  const [addOverride, setAddOverride] = useState(false);
  const [addOverrideReason, setAddOverrideReason] = useState('');
  const [savingAdd, setSavingAdd] = useState(false);

  // Toast feedback
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error' | 'warning'; message: string } | null>(null);

  const showToast = (type: 'success' | 'error' | 'warning', message: string) => {
    setFeedback({ type, message });
    setTimeout(() => {
      setFeedback(null);
    }, 5000);
  };

  // Initial Load: Sessions & Departments
  useEffect(() => {
    const loadMetadata = async () => {
      try {
        const [sessionsRes, deptsRes] = await Promise.all([
          api.getAcademicSessions(),
          api.getDepartments()
        ]);
        const sessionsList = Array.isArray(sessionsRes) ? (sessionsRes as any) : ((sessionsRes as any)?.data || []);
        const deptsList = Array.isArray(deptsRes) ? (deptsRes as any) : ((deptsRes as any)?.data || []);
        setAcademicSessions(sessionsList);
        setDepartments(deptsList);

        const currentActive = sessionsList.find((s: AcademicSession) => s.isCurrent) || sessionsList?.[0];
        if (currentActive) {
          setSelectedSessionId(currentActive.id);
        }
      } catch (err: any) {
        console.error('Failed to load sessions/departments:', err);
      }
    };
    loadMetadata();
  }, []);

  // Fetch Daily Roster
  const fetchDailyRoster = async () => {
    if (!selectedDate) return;
    setDailyLoading(true);
    try {
      const res = await api.getTeacherDailyAttendance({
        date: selectedDate,
        academicSessionId: selectedSessionId,
        departmentId: dailyDepartmentId !== 'ALL' ? dailyDepartmentId : undefined,
        search: dailySearch.trim() || undefined
      });
      if (res && res.success) {
        setDailyData(res.data);
        // Initialize draft roster
        const drafts = (res.data.roster || []).map((item) => ({
          teacherProfileId: item.teacherProfileId,
          status: item.status,
          checkInTime: item.checkInTime || (item.status === 'PRESENT' || item.status === 'LATE' ? '08:00' : ''),
          checkOutTime: item.checkOutTime || (item.status === 'PRESENT' ? '16:00' : ''),
          remarks: item.remarks || '',
          isDirty: false
        }));
        setDraftRoster(drafts);
      }
    } catch (err: any) {
      showToast('error', err.message || 'Failed to fetch daily teacher attendance roster');
    } finally {
      setDailyLoading(false);
    }
  };

  useEffect(() => {
    if (activeTab === 'daily') {
      fetchDailyRoster();
    }
  }, [selectedDate, selectedSessionId, dailyDepartmentId, activeTab]);

  // Fetch Monthly Matrix
  const fetchMonthlyMatrix = async () => {
    setMonthlyLoading(true);
    try {
      const res = await api.getTeacherMonthlyAttendance({
        year: monthlyYear,
        month: monthlyMonth,
        academicSessionId: selectedSessionId,
        departmentId: monthlyDepartmentId !== 'ALL' ? monthlyDepartmentId : undefined,
        search: monthlySearch.trim() || undefined
      });
      if (res && res.success) {
        setMonthlyData(res.data);
      }
    } catch (err: any) {
      showToast('error', err.message || 'Failed to load monthly attendance matrix');
    } finally {
      setMonthlyLoading(false);
    }
  };

  useEffect(() => {
    if (activeTab === 'monthly') {
      fetchMonthlyMatrix();
    }
  }, [monthlyYear, monthlyMonth, selectedSessionId, monthlyDepartmentId, activeTab]);

  // Fetch History
  const fetchHistory = async () => {
    setHistoryLoading(true);
    try {
      const res = await api.getTeacherAttendanceHistory({
        academicSessionId: selectedSessionId !== 'ALL' ? selectedSessionId : undefined,
        departmentId: historyDepartmentId !== 'ALL' ? historyDepartmentId : undefined,
        status: historyStatus !== 'ALL' ? historyStatus : undefined,
        startDate: historyStartDate || undefined,
        endDate: historyEndDate || undefined,
        search: historySearch.trim() || undefined
      });
      if (res && res.success) {
        setHistoryRecords(res.data || []);
      }
    } catch (err: any) {
      showToast('error', err.message || 'Failed to load attendance history logs');
    } finally {
      setHistoryLoading(false);
    }
  };

  useEffect(() => {
    if (activeTab === 'history') {
      fetchHistory();
    }
  }, [selectedSessionId, historyDepartmentId, historyStatus, historyStartDate, historyEndDate, activeTab]);

  // Handle draft status update for a teacher
  const handleSetTeacherStatus = (teacherProfileId: string, status: TeacherAttendanceStatus) => {
    setDraftRoster((prev) =>
      prev.map((item) => {
        if (item.teacherProfileId === teacherProfileId) {
          let defaultIn = item.checkInTime;
          let defaultOut = item.checkOutTime;
          if (status === 'PRESENT' && !defaultIn) defaultIn = '08:00';
          if (status === 'PRESENT' && !defaultOut) defaultOut = '16:00';
          if (status === 'LATE' && !defaultIn) defaultIn = '08:30';
          if (status === 'HALF_DAY' && !defaultIn) defaultIn = '08:00';
          if (status === 'HALF_DAY' && !defaultOut) defaultOut = '12:00';
          if (status === 'ABSENT' || status === 'LEAVE' || status === 'EXCUSED') {
            defaultIn = '';
            defaultOut = '';
          }
          return {
            ...item,
            status,
            checkInTime: defaultIn,
            checkOutTime: defaultOut,
            isDirty: true
          };
        }
        return item;
      })
    );
  };

  const handleSetTeacherTime = (teacherProfileId: string, field: 'checkInTime' | 'checkOutTime', value: string) => {
    setDraftRoster((prev) =>
      prev.map((item) => {
        if (item.teacherProfileId === teacherProfileId) {
          return {
            ...item,
            [field]: value,
            isDirty: true
          };
        }
        return item;
      })
    );
  };

  const handleSetTeacherRemarks = (teacherProfileId: string, remarks: string) => {
    setDraftRoster((prev) =>
      prev.map((item) => {
        if (item.teacherProfileId === teacherProfileId) {
          return {
            ...item,
            remarks,
            isDirty: true
          };
        }
        return item;
      })
    );
  };

  // Bulk Actions
  const handleMarkAll = (status: TeacherAttendanceStatus) => {
    setDraftRoster((prev) =>
      prev.map((item) => {
        let defaultIn = item.checkInTime;
        let defaultOut = item.checkOutTime;
        if (status === 'PRESENT') {
          defaultIn = '08:00';
          defaultOut = '16:00';
        } else if (status === 'ABSENT') {
          defaultIn = '';
          defaultOut = '';
        }
        return {
          ...item,
          status,
          checkInTime: defaultIn,
          checkOutTime: defaultOut,
          isDirty: true
        };
      })
    );
  };

  const handleMarkUnmarkedAsPresent = () => {
    setDraftRoster((prev) =>
      prev.map((item) => {
        if (!item.status) {
          return {
            ...item,
            status: 'PRESENT',
            checkInTime: '08:00',
            checkOutTime: '16:00',
            isDirty: true
          };
        }
        return item;
      })
    );
  };

  // Save Daily Attendance Roster
  const handleSaveDailyRoster = async () => {
    if (!dailyData) return;

    if (!dailyData.isWorkingDay && !allowOverride) {
      showToast('warning', `Selected date is a ${dailyData.dayType} (${dailyData.dayReason}). Please check Super Admin Override and specify reason to proceed.`);
      return;
    }

    if (!dailyData.isWorkingDay && allowOverride && (!overrideReason || overrideReason.trim().length < 3)) {
      showToast('warning', 'Super Admin override requires an explanation reason (minimum 3 characters).');
      return;
    }

    // Filter out teachers without any status assigned
    const validRecords = draftRoster
      .filter((r) => r.status)
      .map((r) => ({
        teacherProfileId: r.teacherProfileId,
        status: r.status!,
        checkInTime: r.checkInTime || undefined,
        checkOutTime: r.checkOutTime || undefined,
        remarks: r.remarks?.trim() || undefined
      }));

    if (validRecords.length === 0) {
      showToast('warning', 'No teacher attendance statuses marked to save.');
      return;
    }

    setSavingDaily(true);
    try {
      const res = await api.bulkMarkTeacherAttendance({
        date: selectedDate,
        academicSessionId: selectedSessionId,
        records: validRecords,
        allowOverride: !dailyData.isWorkingDay && allowOverride,
        overrideReason: !dailyData.isWorkingDay && allowOverride ? overrideReason : undefined
      });

      if (res && res.success) {
        showToast('success', res.message || 'Teacher attendance saved successfully.');
        setAllowOverride(false);
        setOverrideReason('');
        await fetchDailyRoster();
      }
    } catch (err: any) {
      showToast('error', err.message || 'Failed to save daily teacher attendance.');
    } finally {
      setSavingDaily(false);
    }
  };

  // Open Edit Modal for Single Roster item
  const handleOpenEditModal = (item: TeacherDailyAttendanceRosterItem) => {
    setSelectedRosterItemForEdit(item);
    setEditModalStatus(item.status || 'PRESENT');
    setEditModalCheckIn(item.checkInTime || '08:00');
    setEditModalCheckOut(item.checkOutTime || '16:00');
    setEditModalRemarks(item.remarks || '');
    setEditModalReason('');
  };

  // Save Correction
  const handleSaveEditCorrection = async () => {
    if (!selectedRosterItemForEdit) return;

    if (!editModalReason || editModalReason.trim().length < 3) {
      showToast('warning', 'A correction justification reason (minimum 3 characters) is required for audit trail compliance.');
      return;
    }

    setSavingEdit(true);
    try {
      if (selectedRosterItemForEdit.recordId) {
        // Update existing record
        const res = await api.updateTeacherAttendanceRecord(selectedRosterItemForEdit.recordId, {
          status: editModalStatus,
          checkInTime: editModalCheckIn || undefined,
          checkOutTime: editModalCheckOut || undefined,
          remarks: editModalRemarks || undefined,
          reason: editModalReason.trim()
        });
        if (res && res.success) {
          showToast('success', res.message || 'Record corrected successfully.');
          setSelectedRosterItemForEdit(null);
          await fetchDailyRoster();
        }
      } else {
        // Mark new single record
        const res = await api.markTeacherAttendance({
          teacherProfileId: selectedRosterItemForEdit.teacherProfileId,
          date: selectedDate,
          status: editModalStatus,
          checkInTime: editModalCheckIn || undefined,
          checkOutTime: editModalCheckOut || undefined,
          remarks: editModalRemarks || undefined,
          academicSessionId: selectedSessionId,
          allowOverride: dailyData?.isWorkingDay ? false : true,
          overrideReason: editModalReason.trim()
        });
        if (res && res.success) {
          showToast('success', res.message || 'Record marked successfully.');
          setSelectedRosterItemForEdit(null);
          await fetchDailyRoster();
        }
      }
    } catch (err: any) {
      showToast('error', err.message || 'Failed to update attendance record');
    } finally {
      setSavingEdit(false);
    }
  };

  // Delete/Void Record
  const handleConfirmDelete = async () => {
    if (!deleteModalRecordId) return;
    setDeletingRecord(true);
    try {
      const res = await api.deleteTeacherAttendanceRecord(deleteModalRecordId, deleteReason);
      if (res && res.success) {
        showToast('success', res.message || 'Record voided successfully.');
        setDeleteModalRecordId(null);
        setDeleteReason('');
        if (activeTab === 'daily') fetchDailyRoster();
        if (activeTab === 'monthly') fetchMonthlyMatrix();
        if (activeTab === 'history') fetchHistory();
      }
    } catch (err: any) {
      showToast('error', err.message || 'Failed to void attendance record.');
    } finally {
      setDeletingRecord(false);
    }
  };

  // Save Manual Add Single Entry
  const handleSaveAddSingle = async () => {
    if (!addTeacherId || !addDate || !addStatus) {
      showToast('warning', 'Please select a Teacher, Date, and Status.');
      return;
    }

    setSavingAdd(true);
    try {
      const res = await api.markTeacherAttendance({
        teacherProfileId: addTeacherId,
        date: addDate,
        status: addStatus,
        checkInTime: addCheckIn || undefined,
        checkOutTime: addCheckOut || undefined,
        remarks: addRemarks || undefined,
        academicSessionId: selectedSessionId,
        allowOverride: addOverride,
        overrideReason: addOverrideReason || undefined
      });

      if (res && res.success) {
        showToast('success', res.message || 'Attendance created successfully.');
        setShowAddModal(false);
        setAddTeacherId('');
        setAddRemarks('');
        setAddOverride(false);
        setAddOverrideReason('');
        if (activeTab === 'daily' && selectedDate === addDate) fetchDailyRoster();
        if (activeTab === 'monthly') fetchMonthlyMatrix();
        if (activeTab === 'history') fetchHistory();
      }
    } catch (err: any) {
      showToast('error', err.message || 'Failed to mark attendance.');
    } finally {
      setSavingAdd(false);
    }
  };

  // Quick Prev / Next Day
  const handleNavigateDay = (offset: number) => {
    const curr = new Date(selectedDate);
    curr.setDate(curr.getDate() + offset);
    setSelectedDate(curr.toISOString().split('T')[0]);
  };

  // Quick Prev / Next Month
  const handleNavigateMonth = (offset: number) => {
    let newM = monthlyMonth + offset;
    let newY = monthlyYear;
    if (newM > 12) {
      newM = 1;
      newY += 1;
    } else if (newM < 1) {
      newM = 12;
      newY -= 1;
    }
    setMonthlyMonth(newM);
    setMonthlyYear(newY);
  };

  // Status Colors & Badges Helper
  const getStatusBadge = (status?: TeacherAttendanceStatus) => {
    switch (status) {
      case 'PRESENT':
        return <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 border border-emerald-300">Present</span>;
      case 'LATE':
        return <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-100 text-amber-800 border border-amber-300">Late</span>;
      case 'HALF_DAY':
        return <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-orange-100 text-orange-800 border border-orange-300">Half Day</span>;
      case 'LEAVE':
        return <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-100 text-blue-800 border border-blue-300">Approved Leave</span>;
      case 'EXCUSED':
        return <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-purple-100 text-purple-800 border border-purple-300">Excused</span>;
      case 'ABSENT':
        return <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-100 text-rose-800 border border-rose-300">Absent</span>;
      default:
        return <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-100 text-slate-600 border border-slate-300">Unmarked</span>;
    }
  };

  const getDayTypeBadge = (dayType?: string, reason?: string) => {
    switch (dayType) {
      case 'SPECIAL_WORKING_DAY':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-blue-100 text-blue-800 border border-blue-300">
            <Sparkles className="w-3.5 h-3.5" />
            Special Working Day: {reason || 'Designated'}
          </span>
        );
      case 'HOLIDAY':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-purple-100 text-purple-800 border border-purple-300">
            <AlertCircle className="w-3.5 h-3.5" />
            Holiday: {reason || 'School Holiday'}
          </span>
        );
      case 'WEEKEND':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-slate-100 text-slate-700 border border-slate-300">
            <Calendar className="w-3.5 h-3.5" />
            Weekend: {reason || 'Scheduled Weekend'}
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
            <CheckCircle2 className="w-3.5 h-3.5" />
            Regular Working Day
          </span>
        );
    }
  };

  // Filtered Roster for Daily View
  const filteredDailyRoster = useMemo(() => {
    if (!dailyData?.roster) return [];
    return dailyData.roster.filter((item) => {
      const draft = draftRoster.find((d) => d.teacherProfileId === item.teacherProfileId);
      const currentStatus = draft?.status || item.status || 'UNMARKED';

      if (dailyStatusFilter !== 'ALL') {
        if (dailyStatusFilter === 'UNMARKED' && currentStatus !== 'UNMARKED') return false;
        if (dailyStatusFilter !== 'UNMARKED' && currentStatus !== dailyStatusFilter) return false;
      }
      return true;
    });
  }, [dailyData, draftRoster, dailyStatusFilter]);

  return (
    <div className="space-y-6 pb-16">
      {/* Toast feedback */}
      {feedback && (
        <div
          className={`fixed top-5 right-5 z-50 flex items-center gap-3 px-4 py-3 rounded-lg shadow-lg border text-sm transition-all duration-300 ${
            feedback.type === 'success'
              ? 'bg-emerald-50 text-emerald-900 border-emerald-300'
              : feedback.type === 'error'
              ? 'bg-rose-50 text-rose-900 border-rose-300'
              : 'bg-amber-50 text-amber-900 border-amber-300'
          }`}
        >
          {feedback.type === 'success' && <CheckCircle2 className="w-5 h-5 text-emerald-600 flex-shrink-0" />}
          {feedback.type === 'error' && <XCircle className="w-5 h-5 text-rose-600 flex-shrink-0" />}
          {feedback.type === 'warning' && <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0" />}
          <span className="font-medium">{feedback.message}</span>
        </div>
      )}

      {/* Header Banner */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-sm">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-indigo-50 text-indigo-700 rounded-lg border border-indigo-100">
                <UserCheck className="w-6 h-6" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-slate-900">Teacher Attendance Management</h1>
                <p className="text-sm text-slate-500">
                  Super Admin control center for faculty daily roster marking, monthly matrix reviews, and audit corrections.
                </p>
              </div>
            </div>
          </div>

          {/* Top Controls: Session Selector & Manual Entry */}
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-lg text-sm">
              <GraduationCap className="w-4 h-4 text-slate-500" />
              <span className="text-xs font-medium text-slate-600">Session:</span>
              <select
                value={selectedSessionId}
                onChange={(e) => setSelectedSessionId(e.target.value)}
                className="bg-transparent text-slate-800 font-semibold text-sm outline-none cursor-pointer"
              >
                {academicSessions.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.sessionName} {s.isCurrent ? '(Active)' : ''}
                  </option>
                ))}
              </select>
            </div>

            <button
              onClick={() => setShowAddModal(true)}
              className="inline-flex items-center gap-2 px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-semibold rounded-lg shadow-sm transition-colors"
            >
              <Plus className="w-4 h-4" />
              Record Single Entry
            </button>
          </div>
        </div>

        {/* Tab Navigation (Hidden when subtabs are hosted in sidebar) */}
        {!hideTabBar && (
          <div className="flex items-center gap-2 border-b border-slate-200 mt-6 pt-2">
            <button
              onClick={() => setActiveTab('daily')}
              className={`flex items-center gap-2 px-4 py-2.5 text-sm font-semibold border-b-2 transition-colors ${
                activeTab === 'daily'
                  ? 'border-indigo-600 text-indigo-700 bg-indigo-50/50'
                  : 'border-transparent text-slate-600 hover:text-slate-900 hover:border-slate-300'
              }`}
            >
              <Calendar className="w-4 h-4" />
              Daily Roster & Marking
            </button>
            <button
              onClick={() => setActiveTab('monthly')}
              className={`flex items-center gap-2 px-4 py-2.5 text-sm font-semibold border-b-2 transition-colors ${
                activeTab === 'monthly'
                  ? 'border-indigo-600 text-indigo-700 bg-indigo-50/50'
                  : 'border-transparent text-slate-600 hover:text-slate-900 hover:border-slate-300'
              }`}
            >
              <CalendarDays className="w-4 h-4" />
              Monthly Matrix View
            </button>
            <button
              onClick={() => setActiveTab('history')}
              className={`flex items-center gap-2 px-4 py-2.5 text-sm font-semibold border-b-2 transition-colors ${
                activeTab === 'history'
                  ? 'border-indigo-600 text-indigo-700 bg-indigo-50/50'
                  : 'border-transparent text-slate-600 hover:text-slate-900 hover:border-slate-300'
              }`}
            >
              <History className="w-4 h-4" />
              Attendance History & Audit Logs
            </button>
            <button
              onClick={() => setActiveTab('leave_management')}
              className={`flex items-center gap-2 px-4 py-2.5 text-sm font-semibold border-b-2 transition-colors ${
                activeTab === 'leave_management'
                  ? 'border-indigo-600 text-indigo-700 bg-indigo-50/50'
                  : 'border-transparent text-slate-600 hover:text-slate-900 hover:border-slate-300'
              }`}
            >
              <ShieldCheck className="w-4 h-4" />
              Leave Applications & Policies
            </button>
          </div>
        )}
      </div>

      {/* ========================================================================= */}
      {/* TAB 1: DAILY ROSTER & MARKING */}
      {/* ========================================================================= */}
      {activeTab === 'daily' && (
        <div className="space-y-6">
          {/* Daily Filter Bar & Date Selector */}
          <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-4">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
              {/* Date Navigation */}
              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={() => handleNavigateDay(-1)}
                  className="p-2 border border-slate-200 rounded-lg hover:bg-slate-50 text-slate-700 transition"
                  title="Previous Day"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>

                <div className="flex items-center gap-2 bg-slate-50 border border-slate-300 px-3 py-1.5 rounded-lg">
                  <Calendar className="w-4 h-4 text-indigo-600" />
                  <input
                    type="date"
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                    className="bg-transparent text-sm font-bold text-slate-800 outline-none cursor-pointer"
                  />
                </div>

                <button
                  onClick={() => handleNavigateDay(1)}
                  className="p-2 border border-slate-200 rounded-lg hover:bg-slate-50 text-slate-700 transition"
                  title="Next Day"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>

                <button
                  onClick={() => setSelectedDate(new Date().toISOString().split('T')[0])}
                  className="px-3 py-1.5 text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg transition"
                >
                  Today
                </button>

                {/* Day status badge */}
                {dailyData && getDayTypeBadge(dailyData.dayType, dailyData.dayReason)}
              </div>

              {/* Department & Search Filter */}
              <div className="flex flex-wrap items-center gap-3">
                <div className="flex items-center gap-2">
                  <Building className="w-4 h-4 text-slate-400" />
                  <select
                    value={dailyDepartmentId}
                    onChange={(e) => setDailyDepartmentId(e.target.value)}
                    className="text-sm bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 font-medium text-slate-700 outline-none"
                  >
                    <option value="ALL">All Departments</option>
                    {departments.map((d) => (
                      <option key={d.id} value={d.id}>
                        {d.departmentName}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="flex items-center gap-2">
                  <Filter className="w-4 h-4 text-slate-400" />
                  <select
                    value={dailyStatusFilter}
                    onChange={(e) => setDailyStatusFilter(e.target.value)}
                    className="text-sm bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 font-medium text-slate-700 outline-none"
                  >
                    <option value="ALL">All Statuses</option>
                    <option value="PRESENT">Present</option>
                    <option value="LATE">Late</option>
                    <option value="HALF_DAY">Half Day</option>
                    <option value="LEAVE">Leave</option>
                    <option value="EXCUSED">Excused</option>
                    <option value="ABSENT">Absent</option>
                    <option value="UNMARKED">Unmarked</option>
                  </select>
                </div>

                <div className="relative">
                  <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Search faculty..."
                    value={dailySearch}
                    onChange={(e) => setDailySearch(e.target.value)}
                    className="pl-9 pr-4 py-1.5 text-sm bg-slate-50 border border-slate-200 rounded-lg font-medium text-slate-700 outline-none w-48 focus:w-60 transition-all"
                  />
                </div>

                <button
                  onClick={fetchDailyRoster}
                  className="p-2 border border-slate-200 rounded-lg hover:bg-slate-50 text-slate-700 transition"
                  title="Refresh Roster"
                >
                  <RefreshCw className={`w-4 h-4 ${dailyLoading ? 'animate-spin text-indigo-600' : ''}`} />
                </button>
              </div>
            </div>

            {/* Non-working day Super Admin override notice */}
            {dailyData && !dailyData.isWorkingDay && (
              <div className="p-4 bg-amber-50 border border-amber-300 rounded-lg flex flex-col md:flex-row md:items-center justify-between gap-3 text-sm text-amber-900">
                <div className="flex items-center gap-2.5">
                  <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0" />
                  <div>
                    <span className="font-bold">Non-Working Day Restriction:</span> Selected date ({selectedDate}) is configured as a {dailyData.dayType} ({dailyData.dayReason}). Standard marking is locked.
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <label className="flex items-center gap-2 cursor-pointer font-bold text-amber-950">
                    <input
                      type="checkbox"
                      checked={allowOverride}
                      onChange={(e) => setAllowOverride(e.target.checked)}
                      className="w-4 h-4 rounded text-amber-600 focus:ring-amber-500 border-slate-300 cursor-pointer"
                    />
                    Super Admin Override
                  </label>
                  {allowOverride && (
                    <input
                      type="text"
                      placeholder="Justification reason (required)..."
                      value={overrideReason}
                      onChange={(e) => setOverrideReason(e.target.value)}
                      className="text-xs bg-white border border-amber-400 rounded px-2.5 py-1 text-slate-800 outline-none w-64"
                    />
                  )}
                </div>
              </div>
            )}
          </div>

          {/* KPI Stat Cards */}
          {dailyData && (
            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
              <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-sm text-center">
                <div className="text-xs font-semibold text-slate-500">Total Faculty</div>
                <div className="text-xl font-bold text-slate-900 mt-1">{dailyData.stats.totalTeachers}</div>
              </div>
              <div className="bg-white p-3.5 rounded-xl border border-emerald-200 bg-emerald-50/20 shadow-sm text-center">
                <div className="text-xs font-semibold text-emerald-700">Present</div>
                <div className="text-xl font-bold text-emerald-800 mt-1">{dailyData.stats.presentCount}</div>
              </div>
              <div className="bg-white p-3.5 rounded-xl border border-amber-200 bg-amber-50/20 shadow-sm text-center">
                <div className="text-xs font-semibold text-amber-700">Late</div>
                <div className="text-xl font-bold text-amber-800 mt-1">{dailyData.stats.lateCount}</div>
              </div>
              <div className="bg-white p-3.5 rounded-xl border border-orange-200 bg-orange-50/20 shadow-sm text-center">
                <div className="text-xs font-semibold text-orange-700">Half Day</div>
                <div className="text-xl font-bold text-orange-800 mt-1">{dailyData.stats.halfDayCount}</div>
              </div>
              <div className="bg-white p-3.5 rounded-xl border border-blue-200 bg-blue-50/20 shadow-sm text-center">
                <div className="text-xs font-semibold text-blue-700">Leave</div>
                <div className="text-xl font-bold text-blue-800 mt-1">{dailyData.stats.leaveCount}</div>
              </div>
              <div className="bg-white p-3.5 rounded-xl border border-purple-200 bg-purple-50/20 shadow-sm text-center">
                <div className="text-xs font-semibold text-purple-700">Excused</div>
                <div className="text-xl font-bold text-purple-800 mt-1">{dailyData.stats.excusedCount}</div>
              </div>
              <div className="bg-white p-3.5 rounded-xl border border-rose-200 bg-rose-50/20 shadow-sm text-center">
                <div className="text-xs font-semibold text-rose-700">Absent</div>
                <div className="text-xl font-bold text-rose-800 mt-1">{dailyData.stats.absentCount}</div>
              </div>
              <div className="bg-indigo-600 p-3.5 rounded-xl text-white shadow-sm text-center">
                <div className="text-xs font-semibold text-indigo-100">Rate</div>
                <div className="text-xl font-bold text-white mt-1">{dailyData.stats.attendanceRate}%</div>
              </div>
            </div>
          )}

          {/* Quick Bulk Action Bar */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Quick Batch:</span>
              <button
                onClick={handleMarkUnmarkedAsPresent}
                className="px-3 py-1.5 text-xs font-semibold bg-emerald-50 text-emerald-800 border border-emerald-300 hover:bg-emerald-100 rounded-lg transition"
              >
                Mark Unmarked as Present
              </button>
              <button
                onClick={() => handleMarkAll('PRESENT')}
                className="px-3 py-1.5 text-xs font-semibold bg-slate-100 text-slate-700 border border-slate-300 hover:bg-slate-200 rounded-lg transition"
              >
                Mark All Present
              </button>
              <button
                onClick={() => handleMarkAll('ABSENT')}
                className="px-3 py-1.5 text-xs font-semibold bg-rose-50 text-rose-800 border border-rose-300 hover:bg-rose-100 rounded-lg transition"
              >
                Mark All Absent
              </button>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={fetchDailyRoster}
                className="px-3.5 py-2 border border-slate-300 text-slate-700 text-sm font-semibold rounded-lg hover:bg-slate-50 transition"
              >
                Reset Draft
              </button>
              <button
                onClick={handleSaveDailyRoster}
                disabled={savingDaily || (dailyData && !dailyData.isWorkingDay && !allowOverride)}
                className="inline-flex items-center gap-2 px-5 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-sm font-bold rounded-lg shadow-sm transition"
              >
                <Save className="w-4 h-4" />
                {savingDaily ? 'Saving Daily Roster...' : 'Save Daily Roster'}
              </button>
            </div>
          </div>

          {/* Roster Table */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-xs font-bold text-slate-600 uppercase tracking-wider">
                    <th className="py-3.5 px-4">Faculty Member</th>
                    <th className="py-3.5 px-4">Department</th>
                    <th className="py-3.5 px-4">Attendance Status</th>
                    <th className="py-3.5 px-4">Time (In / Out)</th>
                    <th className="py-3.5 px-4">Remarks</th>
                    <th className="py-3.5 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 text-sm">
                  {dailyLoading ? (
                    <tr>
                      <td colSpan={6} className="py-12 text-center text-slate-500">
                        <RefreshCw className="w-6 h-6 animate-spin mx-auto text-indigo-600 mb-2" />
                        Loading teacher roster...
                      </td>
                    </tr>
                  ) : filteredDailyRoster.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-12 text-center text-slate-500">
                        No teachers found matching the current filter.
                      </td>
                    </tr>
                  ) : (
                    filteredDailyRoster.map((item) => {
                      const draft = draftRoster.find((d) => d.teacherProfileId === item.teacherProfileId);
                      const currentStatus = draft?.status || item.status;
                      const checkIn = draft?.checkInTime ?? (item.checkInTime || '');
                      const checkOut = draft?.checkOutTime ?? (item.checkOutTime || '');
                      const remarks = draft?.remarks ?? (item.remarks || '');
                      const isDirty = draft?.isDirty || false;

                      return (
                        <tr
                          key={item.teacherProfileId}
                          className={`hover:bg-slate-50/80 transition-colors ${
                            isDirty ? 'bg-amber-50/30' : ''
                          }`}
                        >
                          {/* Teacher Info */}
                          <td className="py-3.5 px-4">
                            <div className="flex items-center gap-3">
                              <div className="w-9 h-9 rounded-full bg-indigo-100 text-indigo-800 font-bold flex items-center justify-center border border-indigo-200 text-xs">
                                {item.avatarUrl ? (
                                  <img src={item.avatarUrl} alt="" className="w-full h-full rounded-full object-cover" />
                                ) : (
                                  item.teacherName.substring(0, 2).toUpperCase()
                                )}
                              </div>
                              <div>
                                <div className="font-bold text-slate-900 flex items-center gap-2">
                                  {item.teacherName}
                                  {item.isOverridden && (
                                    <span className="text-[10px] font-bold bg-amber-100 text-amber-800 px-1.5 py-0.5 rounded" title={item.overrideReason || 'Super Admin Override'}>
                                      Override
                                    </span>
                                  )}
                                </div>
                                <div className="text-xs text-slate-500 font-mono">{item.employeeCode}</div>
                              </div>
                            </div>
                          </td>

                          {/* Department */}
                          <td className="py-3.5 px-4 text-slate-600 font-medium">
                            {item.departmentName || 'General Faculty'}
                          </td>

                          {/* Quick Status Buttons */}
                          <td className="py-3.5 px-4">
                            <div className="inline-flex rounded-lg border border-slate-200 p-0.5 bg-slate-100 gap-0.5">
                              {(
                                [
                                  { key: 'PRESENT', label: 'P', title: 'Present', activeBg: 'bg-emerald-600 text-white' },
                                  { key: 'LATE', label: 'L', title: 'Late', activeBg: 'bg-amber-600 text-white' },
                                  { key: 'HALF_DAY', label: 'HD', title: 'Half Day', activeBg: 'bg-orange-600 text-white' },
                                  { key: 'LEAVE', label: 'LV', title: 'Leave', activeBg: 'bg-blue-600 text-white' },
                                  { key: 'EXCUSED', label: 'EX', title: 'Excused', activeBg: 'bg-purple-600 text-white' },
                                  { key: 'ABSENT', label: 'A', title: 'Absent', activeBg: 'bg-rose-600 text-white' }
                                ] as const
                              ).map((st) => (
                                <button
                                  key={st.key}
                                  onClick={() => handleSetTeacherStatus(item.teacherProfileId, st.key)}
                                  title={st.title}
                                  className={`px-2.5 py-1 text-xs font-bold rounded transition-all ${
                                    currentStatus === st.key
                                      ? `${st.activeBg} shadow-xs`
                                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                                  }`}
                                >
                                  {st.label}
                                </button>
                              ))}
                            </div>
                          </td>

                          {/* Check-In / Out Times */}
                          <td className="py-3.5 px-4">
                            <div className="flex items-center gap-1.5 text-xs">
                              <input
                                type="time"
                                value={checkIn}
                                onChange={(e) => handleSetTeacherTime(item.teacherProfileId, 'checkInTime', e.target.value)}
                                className="w-20 bg-slate-50 border border-slate-300 rounded px-1.5 py-1 font-mono text-slate-800 outline-none focus:border-indigo-500"
                                title="Check-in time"
                              />
                              <span className="text-slate-400">-</span>
                              <input
                                type="time"
                                value={checkOut}
                                onChange={(e) => handleSetTeacherTime(item.teacherProfileId, 'checkOutTime', e.target.value)}
                                className="w-20 bg-slate-50 border border-slate-300 rounded px-1.5 py-1 font-mono text-slate-800 outline-none focus:border-indigo-500"
                                title="Check-out time"
                              />
                            </div>
                          </td>

                          {/* Remarks */}
                          <td className="py-3.5 px-4">
                            <input
                              type="text"
                              placeholder="Optional remarks..."
                              value={remarks}
                              onChange={(e) => handleSetTeacherRemarks(item.teacherProfileId, e.target.value)}
                              className="w-full bg-slate-50 border border-slate-200 rounded px-2 py-1 text-xs text-slate-700 outline-none focus:border-indigo-500"
                            />
                          </td>

                          {/* Actions */}
                          <td className="py-3.5 px-4 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                onClick={() => handleOpenEditModal(item)}
                                className="p-1.5 text-slate-600 hover:text-indigo-600 hover:bg-indigo-50 rounded transition"
                                title="Audit & Edit Record"
                              >
                                <Edit3 className="w-4 h-4" />
                              </button>

                              {((item?.history?.length || 0) > 0) && (
                                <button
                                  onClick={() => {
                                    const rec = (databaseRecordsPlaceholder: any) => item;
                                    setViewHistoryRecord(item as any);
                                  }}
                                  className="p-1.5 text-indigo-600 hover:bg-indigo-50 rounded transition"
                                  title={`${item?.history?.length || 0} audit corrections recorded`}
                                >
                                  <History className="w-4 h-4" />
                                </button>
                              )}

                              {item.recordId && (
                                <button
                                  onClick={() => setDeleteModalRecordId(item.recordId || null)}
                                  className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition"
                                  title="Void / Delete Record"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 2: MONTHLY MATRIX VIEW */}
      {/* ========================================================================= */}
      {activeTab === 'monthly' && (
        <div className="space-y-6">
          {/* Month & Filter Bar */}
          <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
              {/* Month Navigation */}
              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={() => handleNavigateMonth(-1)}
                  className="p-2 border border-slate-200 rounded-lg hover:bg-slate-50 text-slate-700 transition"
                  title="Previous Month"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>

                <div className="flex items-center gap-2 bg-slate-50 border border-slate-300 px-3 py-1.5 rounded-lg">
                  <CalendarDays className="w-4 h-4 text-indigo-600" />
                  <select
                    value={monthlyMonth}
                    onChange={(e) => setMonthlyMonth(parseInt(e.target.value, 10))}
                    className="bg-transparent text-sm font-bold text-slate-800 outline-none cursor-pointer"
                  >
                    {[
                      'January', 'February', 'March', 'April', 'May', 'June',
                      'July', 'August', 'September', 'October', 'November', 'December'
                    ].map((mName, idx) => (
                      <option key={mName} value={idx + 1}>
                        {mName}
                      </option>
                    ))}
                  </select>
                  <select
                    value={monthlyYear}
                    onChange={(e) => setMonthlyYear(parseInt(e.target.value, 10))}
                    className="bg-transparent text-sm font-bold text-slate-800 outline-none cursor-pointer"
                  >
                    {[2024, 2025, 2026, 2027, 2028].map((y) => (
                      <option key={y} value={y}>
                        {y}
                      </option>
                    ))}
                  </select>
                </div>

                <button
                  onClick={() => handleNavigateMonth(1)}
                  className="p-2 border border-slate-200 rounded-lg hover:bg-slate-50 text-slate-700 transition"
                  title="Next Month"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>

                {monthlyData && (
                  <span className="text-xs font-semibold text-slate-600 bg-slate-100 px-3 py-1.5 rounded-lg">
                    {monthlyData.totalWorkingDays} Working Days Configured
                  </span>
                )}
              </div>

              {/* Department & Search */}
              <div className="flex flex-wrap items-center gap-3">
                <div className="flex items-center gap-2">
                  <Building className="w-4 h-4 text-slate-400" />
                  <select
                    value={monthlyDepartmentId}
                    onChange={(e) => setMonthlyDepartmentId(e.target.value)}
                    className="text-sm bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 font-medium text-slate-700 outline-none"
                  >
                    <option value="ALL">All Departments</option>
                    {departments.map((d) => (
                      <option key={d.id} value={d.id}>
                        {d.departmentName}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="relative">
                  <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Search faculty..."
                    value={monthlySearch}
                    onChange={(e) => setMonthlySearch(e.target.value)}
                    className="pl-9 pr-4 py-1.5 text-sm bg-slate-50 border border-slate-200 rounded-lg font-medium text-slate-700 outline-none w-48"
                  />
                </div>

                <button
                  onClick={fetchMonthlyMatrix}
                  className="p-2 border border-slate-200 rounded-lg hover:bg-slate-50 text-slate-700 transition"
                  title="Refresh Matrix"
                >
                  <RefreshCw className={`w-4 h-4 ${monthlyLoading ? 'animate-spin text-indigo-600' : ''}`} />
                </button>
              </div>
            </div>
          </div>

          {/* Monthly KPI Overview */}
          {monthlyData && (
            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
              <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-sm text-center">
                <div className="text-xs font-semibold text-slate-500">Total Teachers</div>
                <div className="text-xl font-bold text-slate-900 mt-1">{monthlyData.overallSummary.totalTeachers}</div>
              </div>
              <div className="bg-white p-3.5 rounded-xl border border-emerald-200 bg-emerald-50/20 shadow-sm text-center">
                <div className="text-xs font-semibold text-emerald-700">Total Present</div>
                <div className="text-xl font-bold text-emerald-800 mt-1">{monthlyData.overallSummary.totalPresent}</div>
              </div>
              <div className="bg-white p-3.5 rounded-xl border border-amber-200 bg-amber-50/20 shadow-sm text-center">
                <div className="text-xs font-semibold text-amber-700">Total Late</div>
                <div className="text-xl font-bold text-amber-800 mt-1">{monthlyData.overallSummary.totalLate}</div>
              </div>
              <div className="bg-white p-3.5 rounded-xl border border-orange-200 bg-orange-50/20 shadow-sm text-center">
                <div className="text-xs font-semibold text-orange-700">Total Half Day</div>
                <div className="text-xl font-bold text-orange-800 mt-1">{monthlyData.overallSummary.totalHalfDay}</div>
              </div>
              <div className="bg-white p-3.5 rounded-xl border border-blue-200 bg-blue-50/20 shadow-sm text-center">
                <div className="text-xs font-semibold text-blue-700">Approved Leave</div>
                <div className="text-xl font-bold text-blue-800 mt-1">{monthlyData.overallSummary.totalLeave}</div>
              </div>
              <div className="bg-white p-3.5 rounded-xl border border-rose-200 bg-rose-50/20 shadow-sm text-center">
                <div className="text-xs font-semibold text-rose-700">Total Absent</div>
                <div className="text-xl font-bold text-rose-800 mt-1">{monthlyData.overallSummary.totalAbsent}</div>
              </div>
              <div className="bg-indigo-600 p-3.5 rounded-xl text-white shadow-sm text-center">
                <div className="text-xs font-semibold text-indigo-100">Avg Attendance</div>
                <div className="text-xl font-bold text-white mt-1">{monthlyData.overallSummary.averageAttendanceRate}%</div>
              </div>
            </div>
          )}

          {/* Matrix Grid */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="overflow-x-auto max-h-[600px]">
              <table className="w-full text-left border-collapse min-w-[1200px]">
                <thead className="sticky top-0 z-20 bg-slate-100 border-b border-slate-300">
                  <tr>
                    <th className="sticky left-0 z-30 bg-slate-100 py-3 px-4 text-xs font-bold text-slate-700 uppercase border-r border-slate-200 min-w-[200px]">
                      Faculty Member
                    </th>
                    {monthlyData?.days.map((day) => {
                      const isNonWorking = !day.isWorkingDay;
                      return (
                        <th
                          key={day.date}
                          className={`py-2 px-1 text-center border-r border-slate-200 min-w-[32px] ${
                            isNonWorking ? 'bg-slate-200/70 text-slate-500' : 'text-slate-800'
                          }`}
                          title={`${day.date} (${day.dayName}) - ${day.reason || day.dayType}`}
                        >
                          <div className="text-[10px] font-bold">{day.dayOfMonth}</div>
                          <div className="text-[8px] font-mono text-slate-500">{day.dayName.substring(0, 2)}</div>
                        </th>
                      );
                    })}
                    <th className="py-2 px-3 text-center text-xs font-bold text-slate-700 uppercase min-w-[70px]">
                      Rate
                    </th>
                    <th className="py-2 px-3 text-center text-xs font-bold text-slate-700 uppercase min-w-[50px]">
                      P
                    </th>
                    <th className="py-2 px-3 text-center text-xs font-bold text-slate-700 uppercase min-w-[50px]">
                      L
                    </th>
                    <th className="py-2 px-3 text-center text-xs font-bold text-slate-700 uppercase min-w-[50px]">
                      A
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 text-xs">
                  {monthlyLoading ? (
                    <tr>
                      <td colSpan={36} className="py-12 text-center text-slate-500">
                        <RefreshCw className="w-6 h-6 animate-spin mx-auto text-indigo-600 mb-2" />
                        Generating monthly matrix...
                      </td>
                    </tr>
                  ) : !monthlyData || (monthlyData?.teachers?.length || 0) === 0 ? (
                    <tr>
                      <td colSpan={36} className="py-12 text-center text-slate-500">
                        No teachers found for the selected month and department.
                      </td>
                    </tr>
                  ) : (
                    monthlyData.teachers.map((tRow) => (
                      <tr key={tRow.teacherProfileId} className="hover:bg-slate-50 transition">
                        {/* Sticky Name Column */}
                        <td className="sticky left-0 z-10 bg-white py-2.5 px-4 font-semibold text-slate-900 border-r border-slate-200 flex items-center justify-between gap-2 shadow-xs">
                          <div>
                            <div className="font-bold text-slate-900">{tRow.teacherName}</div>
                            <div className="text-[10px] text-slate-500 font-mono">{tRow.employeeCode}</div>
                          </div>
                          <span className="text-[10px] text-slate-400">{tRow.departmentName}</span>
                        </td>

                        {/* Days Grid Cells */}
                        {monthlyData.days.map((day) => {
                          const att = tRow.attendanceByDate[day.date];
                          const isNonWorking = !day.isWorkingDay;

                          let cellContent = '-';
                          let cellBg = isNonWorking ? 'bg-slate-100 text-slate-400' : 'text-slate-400';

                          if (att) {
                            if (att.status === 'PRESENT') {
                              cellContent = 'P';
                              cellBg = 'bg-emerald-500 text-white font-bold';
                            } else if (att.status === 'LATE') {
                              cellContent = 'L';
                              cellBg = 'bg-amber-500 text-white font-bold';
                            } else if (att.status === 'HALF_DAY') {
                              cellContent = 'HD';
                              cellBg = 'bg-orange-500 text-white font-bold';
                            } else if (att.status === 'LEAVE') {
                              cellContent = 'LV';
                              cellBg = 'bg-blue-500 text-white font-bold';
                            } else if (att.status === 'EXCUSED') {
                              cellContent = 'EX';
                              cellBg = 'bg-purple-500 text-white font-bold';
                            } else if (att.status === 'ABSENT') {
                              cellContent = 'A';
                              cellBg = 'bg-rose-500 text-white font-bold';
                            }
                          } else if (isNonWorking) {
                            cellContent = day.dayType === 'WEEKEND' ? 'W' : 'H';
                          }

                          return (
                            <td
                              key={day.date}
                              className={`p-1 text-center border-r border-slate-200 cursor-pointer hover:opacity-80 transition ${
                                isNonWorking && !att ? 'bg-slate-50 text-slate-400' : ''
                              }`}
                              title={`${tRow.teacherName} on ${day.date}: ${att ? att.status : isNonWorking ? day.dayType : 'Not Marked'}`}
                              onClick={() => {
                                // Click to edit this cell
                                setSelectedDate(day.date);
                                setActiveTab('daily');
                              }}
                            >
                              <span
                                className={`inline-block w-6 h-6 rounded flex items-center justify-center text-[10px] ${cellBg}`}
                              >
                                {cellContent}
                              </span>
                            </td>
                          );
                        })}

                        {/* Summary Columns */}
                        <td className="py-2 px-3 text-center font-bold text-indigo-700 bg-indigo-50/40">
                          {tRow.summary.rate}%
                        </td>
                        <td className="py-2 px-3 text-center font-semibold text-emerald-700">
                          {tRow.summary.present}
                        </td>
                        <td className="py-2 px-3 text-center font-semibold text-amber-700">
                          {tRow.summary.late}
                        </td>
                        <td className="py-2 px-3 text-center font-semibold text-rose-700">
                          {tRow.summary.absent}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 3: ATTENDANCE HISTORY & AUDIT LOGS */}
      {/* ========================================================================= */}
      {activeTab === 'history' && (
        <div className="space-y-6">
          {/* History Search & Filters */}
          <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search faculty or remarks..."
                  value={historySearch}
                  onChange={(e) => setHistorySearch(e.target.value)}
                  className="pl-9 pr-4 py-1.5 text-sm bg-slate-50 border border-slate-200 rounded-lg font-medium text-slate-700 outline-none w-full"
                />
              </div>

              <div>
                <select
                  value={historyDepartmentId}
                  onChange={(e) => setHistoryDepartmentId(e.target.value)}
                  className="text-sm bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 font-medium text-slate-700 outline-none w-full"
                >
                  <option value="ALL">All Departments</option>
                  {departments.map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.departmentName}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <select
                  value={historyStatus}
                  onChange={(e) => setHistoryStatus(e.target.value)}
                  className="text-sm bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 font-medium text-slate-700 outline-none w-full"
                >
                  <option value="ALL">All Statuses</option>
                  <option value="PRESENT">Present</option>
                  <option value="LATE">Late</option>
                  <option value="HALF_DAY">Half Day</option>
                  <option value="LEAVE">Leave</option>
                  <option value="EXCUSED">Excused</option>
                  <option value="ABSENT">Absent</option>
                </select>
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="date"
                  value={historyStartDate}
                  onChange={(e) => setHistoryStartDate(e.target.value)}
                  placeholder="From date"
                  className="text-xs bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-700 outline-none w-full"
                />
                <span className="text-slate-400">-</span>
                <input
                  type="date"
                  value={historyEndDate}
                  onChange={(e) => setHistoryEndDate(e.target.value)}
                  placeholder="To date"
                  className="text-xs bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-700 outline-none w-full"
                />
              </div>

              <div className="flex items-center gap-2 justify-end">
                <button
                  onClick={fetchHistory}
                  className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-semibold rounded-lg shadow-sm transition"
                >
                  Apply Filters
                </button>
              </div>
            </div>
          </div>

          {/* History Records Table */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-xs font-bold text-slate-600 uppercase tracking-wider">
                    <th className="py-3.5 px-4">Date</th>
                    <th className="py-3.5 px-4">Faculty Member</th>
                    <th className="py-3.5 px-4">Department</th>
                    <th className="py-3.5 px-4">Status</th>
                    <th className="py-3.5 px-4">Time (In/Out)</th>
                    <th className="py-3.5 px-4">Remarks / Overrides</th>
                    <th className="py-3.5 px-4">Audit Corrections</th>
                    <th className="py-3.5 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 text-sm">
                  {historyLoading ? (
                    <tr>
                      <td colSpan={8} className="py-12 text-center text-slate-500">
                        <RefreshCw className="w-6 h-6 animate-spin mx-auto text-indigo-600 mb-2" />
                        Loading attendance history...
                      </td>
                    </tr>
                  ) : historyRecords.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="py-12 text-center text-slate-500">
                        No historical attendance records found matching filters.
                      </td>
                    </tr>
                  ) : (
                    historyRecords.map((rec) => (
                      <tr key={rec.id} className="hover:bg-slate-50 transition">
                        <td className="py-3 px-4 font-mono font-bold text-slate-800">{rec.date}</td>
                        <td className="py-3 px-4">
                          <div className="font-bold text-slate-900">{rec.teacherName}</div>
                          <div className="text-xs text-slate-500 font-mono">{rec.employeeCode}</div>
                        </td>
                        <td className="py-3 px-4 text-slate-600">{rec.departmentName}</td>
                        <td className="py-3 px-4">{getStatusBadge(rec.status)}</td>
                        <td className="py-3 px-4 text-xs font-mono text-slate-700">
                          {rec.checkInTime || '--:--'} - {rec.checkOutTime || '--:--'}
                        </td>
                        <td className="py-3 px-4 text-xs text-slate-600">
                          <div>{rec.remarks || '-'}</div>
                          {rec.isOverridden && (
                            <span className="inline-block mt-0.5 text-[10px] font-bold text-amber-700 bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200">
                              Override: {rec.overrideReason || 'Admin Override'}
                            </span>
                          )}
                        </td>
                        <td className="py-3 px-4">
                          {((rec?.history?.length || 0) > 0) ? (
                            <button
                              onClick={() => setViewHistoryRecord(rec)}
                              className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-indigo-50 text-indigo-700 border border-indigo-200 text-xs font-semibold hover:bg-indigo-100 transition"
                            >
                              <History className="w-3.5 h-3.5" />
                              {rec?.history?.length || 0} Correction{(rec?.history?.length || 0) > 1 ? 's' : ''}
                            </button>
                          ) : (
                            <span className="text-xs text-slate-400">Original entry</span>
                          )}
                        </td>
                        <td className="py-3 px-4 text-right">
                          <div className="flex items-center justify-end gap-1">
                            <button
                              onClick={() => {
                                const dummyItem: TeacherDailyAttendanceRosterItem = {
                                  teacherProfileId: rec.teacherProfileId,
                                  userId: rec.userId,
                                  teacherName: rec.teacherName,
                                  employeeCode: rec.employeeCode,
                                  departmentId: rec.departmentId,
                                  departmentName: rec.departmentName,
                                  status: rec.status,
                                  recordId: rec.id,
                                  checkInTime: rec.checkInTime,
                                  checkOutTime: rec.checkOutTime,
                                  remarks: rec.remarks,
                                  isOverridden: rec.isOverridden,
                                  overrideReason: rec.overrideReason,
                                  history: rec.history
                                };
                                handleOpenEditModal(dummyItem);
                              }}
                              className="p-1.5 text-slate-600 hover:text-indigo-600 hover:bg-indigo-50 rounded"
                              title="Correct Record"
                            >
                              <Edit3 className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => setDeleteModalRecordId(rec.id)}
                              className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded"
                              title="Void Record"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 4: LEAVE APPLICATIONS & POLICY CONFIGURATION */}
      {/* ========================================================================= */}
      {activeTab === 'leave_management' && (
        <AdminLeaveManagementTab />
      )}

      {/* ========================================================================= */}
      {/* MODAL 1: EDIT / AUDIT CORRECTION MODAL */}
      {/* ========================================================================= */}
      {selectedRosterItemForEdit && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4 backdrop-blur-xs">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-lg w-full overflow-hidden animate-in fade-in zoom-in duration-200">
            <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2.5">
                <Edit3 className="w-5 h-5 text-indigo-600" />
                <h3 className="text-lg font-bold text-slate-900">Correct Faculty Attendance</h3>
              </div>
              <button
                onClick={() => setSelectedRosterItemForEdit(null)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              {/* Faculty Brief Card */}
              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between text-sm">
                <div>
                  <div className="font-bold text-slate-900">{selectedRosterItemForEdit.teacherName}</div>
                  <div className="text-xs text-slate-500">{selectedRosterItemForEdit.employeeCode} • {selectedRosterItemForEdit.departmentName}</div>
                </div>
                <div className="text-right">
                  <div className="text-xs text-slate-500">Date</div>
                  <div className="font-mono font-bold text-slate-800">{selectedDate}</div>
                </div>
              </div>

              {/* Status Selector */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                  Attendance Status *
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(
                    [
                      { key: 'PRESENT', label: 'Present', color: 'emerald' },
                      { key: 'LATE', label: 'Late', color: 'amber' },
                      { key: 'HALF_DAY', label: 'Half Day', color: 'orange' },
                      { key: 'LEAVE', label: 'Approved Leave', color: 'blue' },
                      { key: 'EXCUSED', label: 'Excused', color: 'purple' },
                      { key: 'ABSENT', label: 'Absent', color: 'rose' }
                    ] as const
                  ).map((s) => (
                    <button
                      key={s.key}
                      type="button"
                      onClick={() => setEditModalStatus(s.key)}
                      className={`py-2 px-3 text-xs font-bold rounded-lg border text-center transition ${
                        editModalStatus === s.key
                          ? 'border-indigo-600 bg-indigo-50 text-indigo-700 shadow-xs'
                          : 'border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      {s.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Check-In / Check-Out Times */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Check-In Time
                  </label>
                  <input
                    type="time"
                    value={editModalCheckIn}
                    onChange={(e) => setEditModalCheckIn(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-sm font-mono text-slate-800 outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Check-Out Time
                  </label>
                  <input
                    type="time"
                    value={editModalCheckOut}
                    onChange={(e) => setEditModalCheckOut(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-sm font-mono text-slate-800 outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              {/* Remarks */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  General Remarks
                </label>
                <input
                  type="text"
                  placeholder="e.g. Conducted morning lab sessions"
                  value={editModalRemarks}
                  onChange={(e) => setEditModalRemarks(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-800 outline-none focus:border-indigo-500"
                />
              </div>

              {/* Mandatory Audit Reason */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1 flex items-center justify-between">
                  <span>Correction Reason (Required for Audit Trail) *</span>
                  <span className="text-[10px] text-slate-400">Min 3 chars</span>
                </label>
                <textarea
                  rows={2}
                  placeholder="e.g. Teacher biometric sensor failure in morning; verified by Department Head."
                  value={editModalReason}
                  onChange={(e) => setEditModalReason(e.target.value)}
                  className="w-full bg-white border border-slate-300 rounded-lg p-2.5 text-sm text-slate-800 outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                />
              </div>
            </div>

            <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setSelectedRosterItemForEdit(null)}
                className="px-4 py-2 border border-slate-300 text-slate-700 text-sm font-semibold rounded-lg hover:bg-slate-100"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSaveEditCorrection}
                disabled={savingEdit || editModalReason.trim().length < 3}
                className="inline-flex items-center gap-2 px-5 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-sm font-bold rounded-lg shadow-sm transition"
              >
                <Save className="w-4 h-4" />
                {savingEdit ? 'Saving Correction...' : 'Save & Record Audit'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 2: CORRECTION HISTORY AUDIT TRAIL MODAL */}
      {/* ========================================================================= */}
      {viewHistoryRecord && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4 backdrop-blur-xs">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-2xl w-full overflow-hidden animate-in fade-in zoom-in duration-200">
            <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2.5">
                <History className="w-5 h-5 text-indigo-600" />
                <h3 className="text-lg font-bold text-slate-900">Attendance Audit Trail</h3>
              </div>
              <button
                onClick={() => setViewHistoryRecord(null)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-sm">
                <div className="font-bold text-slate-900 text-base">{viewHistoryRecord.teacherName}</div>
                <div className="text-xs text-slate-500">
                  {viewHistoryRecord.employeeCode} • {viewHistoryRecord.departmentName} • Date: <strong className="font-mono text-slate-800">{viewHistoryRecord.date}</strong>
                </div>
              </div>

              <div className="space-y-3">
                <h4 className="text-xs font-bold text-slate-600 uppercase tracking-wider">
                  Correction Timeline ({viewHistoryRecord.history?.length || 0} entries)
                </h4>

                {(viewHistoryRecord?.history?.length || 0) === 0 ? (
                  <div className="p-6 text-center text-sm text-slate-500 border border-dashed rounded-xl">
                    No manual corrections recorded. This attendance entry reflects the initial record.
                  </div>
                ) : (
                  <div className="space-y-3">
                    {viewHistoryRecord.history.map((hist, idx) => (
                      <div key={hist.id || idx} className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2 text-sm">
                        <div className="flex items-center justify-between text-xs text-slate-500">
                          <span className="font-semibold text-indigo-700">Corrected by: {hist.correctedByUserName}</span>
                          <span className="font-mono">{new Date(hist.correctedAt).toLocaleString()}</span>
                        </div>

                        <div className="flex items-center gap-2 text-sm font-semibold">
                          <span className="text-slate-500">Status Changed:</span>
                          <span className="px-2 py-0.5 rounded bg-slate-200 text-slate-700 text-xs font-mono">{hist.fromStatus}</span>
                          <span>→</span>
                          <span className="px-2 py-0.5 rounded bg-indigo-100 text-indigo-800 text-xs font-bold font-mono">{hist.toStatus}</span>
                        </div>

                        {(hist.fromCheckInTime || hist.toCheckInTime) && (
                          <div className="text-xs text-slate-600 font-mono">
                            Time: {hist.fromCheckInTime || '--:--'} - {hist.fromCheckOutTime || '--:--'} → {hist.toCheckInTime || '--:--'} - {hist.toCheckOutTime || '--:--'}
                          </div>
                        )}

                        <div className="text-xs text-slate-700 bg-white p-2.5 rounded-lg border border-slate-200">
                          <strong className="text-slate-800">Reason:</strong> {hist.reason}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-end">
              <button
                type="button"
                onClick={() => setViewHistoryRecord(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white text-sm font-semibold rounded-lg"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 3: DELETE / VOID RECORD MODAL */}
      {/* ========================================================================= */}
      {deleteModalRecordId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4 backdrop-blur-xs">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-md w-full overflow-hidden">
            <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-rose-50 text-rose-900">
              <div className="flex items-center gap-2">
                <Trash2 className="w-5 h-5 text-rose-600" />
                <h3 className="text-lg font-bold">Void Attendance Record</h3>
              </div>
              <button
                onClick={() => setDeleteModalRecordId(null)}
                className="p-1 text-rose-400 hover:text-rose-700 rounded-lg hover:bg-rose-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4 text-sm text-slate-600">
              <p>
                Are you sure you want to void/delete this attendance record? This will soft-delete the record and retain an audit entry.
              </p>
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Void Reason
                </label>
                <input
                  type="text"
                  placeholder="e.g. Duplicate entry submitted in error"
                  value={deleteReason}
                  onChange={(e) => setDeleteReason(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-sm text-slate-800 outline-none focus:border-rose-500"
                />
              </div>
            </div>

            <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setDeleteModalRecordId(null)}
                className="px-4 py-2 border border-slate-300 text-slate-700 text-sm font-semibold rounded-lg hover:bg-slate-100"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                disabled={deletingRecord}
                className="px-5 py-2 bg-rose-600 hover:bg-rose-700 disabled:opacity-50 text-white text-sm font-bold rounded-lg shadow-sm"
              >
                {deletingRecord ? 'Voiding...' : 'Void Record'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 4: RECORD SINGLE ENTRY MODAL */}
      {/* ========================================================================= */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4 backdrop-blur-xs">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-lg w-full overflow-hidden">
            <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2">
                <Plus className="w-5 h-5 text-indigo-600" />
                <h3 className="text-lg font-bold text-slate-900">Record Teacher Attendance</h3>
              </div>
              <button
                onClick={() => setShowAddModal(false)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              {/* Teacher Selector */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Select Faculty Member *
                </label>
                <select
                  value={addTeacherId}
                  onChange={(e) => setAddTeacherId(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-sm font-medium text-slate-800 outline-none"
                >
                  <option value="">-- Choose Faculty Member --</option>
                  {dailyData?.roster.map((t) => (
                    <option key={t.teacherProfileId} value={t.teacherProfileId}>
                      {t.teacherName} ({t.employeeCode}) - {t.departmentName}
                    </option>
                  ))}
                </select>
              </div>

              {/* Date */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Attendance Date *
                </label>
                <input
                  type="date"
                  value={addDate}
                  onChange={(e) => setAddDate(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-sm text-slate-800 font-bold outline-none"
                />
              </div>

              {/* Status */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Attendance Status *
                </label>
                <select
                  value={addStatus}
                  onChange={(e) => setAddStatus(e.target.value as TeacherAttendanceStatus)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-sm font-bold text-slate-800 outline-none"
                >
                  <option value="PRESENT">Present</option>
                  <option value="LATE">Late</option>
                  <option value="HALF_DAY">Half Day</option>
                  <option value="LEAVE">Approved Leave</option>
                  <option value="EXCUSED">Excused</option>
                  <option value="ABSENT">Absent</option>
                </select>
              </div>

              {/* Times */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Check-In Time
                  </label>
                  <input
                    type="time"
                    value={addCheckIn}
                    onChange={(e) => setAddCheckIn(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-sm font-mono text-slate-800 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Check-Out Time
                  </label>
                  <input
                    type="time"
                    value={addCheckOut}
                    onChange={(e) => setAddCheckOut(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-sm font-mono text-slate-800 outline-none"
                  />
                </div>
              </div>

              {/* Remarks */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Remarks
                </label>
                <input
                  type="text"
                  placeholder="Optional remarks..."
                  value={addRemarks}
                  onChange={(e) => setAddRemarks(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-800 outline-none"
                />
              </div>

              {/* Non-working override checkbox */}
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg space-y-2">
                <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-slate-700">
                  <input
                    type="checkbox"
                    checked={addOverride}
                    onChange={(e) => setAddOverride(e.target.checked)}
                    className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 border-slate-300"
                  />
                  Enable Non-Working Day Override
                </label>
                {addOverride && (
                  <input
                    type="text"
                    placeholder="Override justification reason..."
                    value={addOverrideReason}
                    onChange={(e) => setAddOverrideReason(e.target.value)}
                    className="w-full text-xs bg-white border border-slate-300 rounded px-2.5 py-1.5 text-slate-800 outline-none"
                  />
                )}
              </div>
            </div>

            <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="px-4 py-2 border border-slate-300 text-slate-700 text-sm font-semibold rounded-lg hover:bg-slate-100"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSaveAddSingle}
                disabled={savingAdd || !addTeacherId}
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-sm font-bold rounded-lg shadow-sm"
              >
                {savingAdd ? 'Recording...' : 'Record Attendance'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
export default TeacherAttendanceManagementPage;
