import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Bell,
  Mail,
  MessageSquare,
  Smartphone,
  Shield,
  CheckCircle2,
  AlertCircle,
  Clock,
  Sparkles,
  Send,
  Save,
  RotateCcw,
  Sliders,
  Users,
  Info,
  Layers,
  Radio,
  ExternalLink
} from 'lucide-react';
import { Card } from '../../../../components/ui/Card.js';
import { Badge } from '../../../../components/ui/Badge.js';
import { Button } from '../../../../components/ui/Button.js';
import {
  AttendanceNotificationSettings,
  AttendanceAlertEventConfig,
  AttendanceNotificationEventType
} from '../../../../types/index.js';

interface Props {
  onSettingsSaved?: () => void;
  onNavigateToHistory?: () => void;
  onNavigateToTemplates?: () => void;
}

const EVENT_LABELS: {
  key: keyof Omit<
    AttendanceNotificationSettings,
    'id' | 'preventDuplicates' | 'deduplicationWindowMinutes' | 'maxRetries' | 'retryDelayMinutes' | 'batchSize' | 'providerStatus' | 'updatedAt' | 'updatedBy' | 'updatedByName'
  >;
  title: string;
  description: string;
  eventType: AttendanceNotificationEventType;
  badge: string;
}[] = [
  {
    key: 'studentAbsentAlert',
    title: 'Student Absent Alert',
    description: 'Triggered when a student is recorded as ABSENT in daily roll call or period attendance.',
    eventType: 'STUDENT_ABSENT',
    badge: 'Critical'
  },
  {
    key: 'studentLateAlert',
    title: 'Student Late Arrival Alert',
    description: 'Triggered when a student arrives past the grace period and is recorded as LATE.',
    eventType: 'STUDENT_LATE',
    badge: 'Warning'
  },
  {
    key: 'studentHalfDayAlert',
    title: 'Student Half-Day Alert',
    description: 'Triggered when a student attends for only morning/afternoon session or departs early.',
    eventType: 'STUDENT_HALF_DAY',
    badge: 'Notice'
  },
  {
    key: 'leaveSubmittedAlert',
    title: 'Leave Application Filed',
    description: 'Triggered when a student, guardian, or faculty member submits a new leave application.',
    eventType: 'LEAVE_SUBMITTED',
    badge: 'Workflow'
  },
  {
    key: 'leaveApprovedAlert',
    title: 'Leave Application Approved',
    description: 'Triggered when administration officially authorizes a pending leave application.',
    eventType: 'LEAVE_APPROVED',
    badge: 'Workflow'
  },
  {
    key: 'leaveRejectedAlert',
    title: 'Leave Application Declined',
    description: 'Triggered when administration reviews and rejects a leave application with explanation.',
    eventType: 'LEAVE_REJECTED',
    badge: 'Workflow'
  },
  {
    key: 'leaveCancelledAlert',
    title: 'Leave Application Cancelled',
    description: 'Triggered when an approved or pending leave application is revoked and attendance reconciled.',
    eventType: 'LEAVE_CANCELLED',
    badge: 'Workflow'
  },
  {
    key: 'attendanceCorrectionAlert',
    title: 'Attendance Status Correction',
    description: 'Triggered when an existing attendance record is officially changed with mandatory reason.',
    eventType: 'ATTENDANCE_CORRECTION',
    badge: 'Audit Notice'
  }
];

export const AttendanceNotificationSettingsTab: React.FC<Props> = ({
  onSettingsSaved,
  onNavigateToHistory,
  onNavigateToTemplates
}) => {
  const [settings, setSettings] = useState<AttendanceNotificationSettings | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [saving, setSaving] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Test Dispatch state
  const [testEventType, setTestEventType] = useState<AttendanceNotificationEventType>('STUDENT_ABSENT');
  const [dispatchingTest, setDispatchingTest] = useState<boolean>(false);
  const [testResult, setTestResult] = useState<{
    message: string;
    sent: number;
    queued: number;
    duplicate: number;
  } | null>(null);

  const fetchNotificationSettings = async () => {
    setLoading(true);
    setError(null);
    try {
      const token = localStorage.getItem('sygmate_auth_token') || localStorage.getItem('token') || localStorage.getItem('sygmate_token');
      const res = await fetch('/api/attendance/notifications/settings', {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      const data = await res.json();
      if (!data.success) {
        throw new Error(data.error || 'Failed to fetch attendance notification settings');
      }
      setSettings(data.data);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchNotificationSettings();
  }, []);

  const handleSaveSettings = async () => {
    if (!settings) return;
    setSaving(true);
    setError(null);
    setSuccessMsg(null);

    try {
      const token = localStorage.getItem('sygmate_auth_token') || localStorage.getItem('token') || localStorage.getItem('sygmate_token');
      const res = await fetch('/api/attendance/notifications/settings', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify(settings)
      });

      const data = await res.json();
      if (!data.success) {
        throw new Error(data.error || 'Failed to update settings');
      }

      setSettings(data.data);
      setSuccessMsg('Attendance notification & alert settings saved successfully.');
      if (onSettingsSaved) onSettingsSaved();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  const handleToggleEvent = (
    key: keyof Omit<
      AttendanceNotificationSettings,
      'id' | 'preventDuplicates' | 'deduplicationWindowMinutes' | 'maxRetries' | 'retryDelayMinutes' | 'batchSize' | 'providerStatus' | 'updatedAt' | 'updatedBy' | 'updatedByName'
    >
  ) => {
    if (!settings) return;
    const current = settings[key];
    setSettings({
      ...settings,
      [key]: {
        ...current,
        enabled: !current.enabled
      }
    });
  };

  const handleToggleChannel = (
    eventKey: keyof Omit<
      AttendanceNotificationSettings,
      'id' | 'preventDuplicates' | 'deduplicationWindowMinutes' | 'maxRetries' | 'retryDelayMinutes' | 'batchSize' | 'providerStatus' | 'updatedAt' | 'updatedBy' | 'updatedByName'
    >,
    channel: 'inApp' | 'email' | 'sms' | 'push'
  ) => {
    if (!settings) return;
    const current = settings[eventKey];
    setSettings({
      ...settings,
      [eventKey]: {
        ...current,
        channels: {
          ...current.channels,
          [channel]: !current.channels[channel]
        }
      }
    });
  };

  const handleToggleRecipient = (
    eventKey: keyof Omit<
      AttendanceNotificationSettings,
      'id' | 'preventDuplicates' | 'deduplicationWindowMinutes' | 'maxRetries' | 'retryDelayMinutes' | 'batchSize' | 'providerStatus' | 'updatedAt' | 'updatedBy' | 'updatedByName'
    >,
    recipient: 'guardian' | 'student' | 'staff'
  ) => {
    if (!settings) return;
    const current = settings[eventKey];
    setSettings({
      ...settings,
      [eventKey]: {
        ...current,
        recipients: {
          ...current.recipients,
          [recipient]: !current.recipients[recipient]
        }
      }
    });
  };

  const handleSendTestDispatch = async () => {
    setDispatchingTest(true);
    setTestResult(null);
    setError(null);
    try {
      const token = localStorage.getItem('sygmate_auth_token') || localStorage.getItem('token') || localStorage.getItem('sygmate_token');
      const res = await fetch('/api/attendance/notifications/test-dispatch', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ eventType: testEventType })
      });
      const data = await res.json();
      if (!data.success) {
        throw new Error(data.error || 'Failed to dispatch test notification');
      }

      setTestResult({
        message: data.message,
        sent: data.data.sentCount,
        queued: data.data.queuedCount,
        duplicate: data.data.duplicateCount
      });
    } catch (err: any) {
      setError(err.message);
    } finally {
      setDispatchingTest(false);
    }
  };

  if (loading) {
    return (
      <div className="py-16 text-center">
        <div className="w-8 h-8 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
        <p className="text-sm text-slate-400">Loading Attendance Notification Settings...</p>
      </div>
    );
  }

  if (!settings) {
    return (
      <div className="p-8 text-center bg-slate-900/50 rounded-2xl border border-white/10">
        <AlertCircle className="w-8 h-8 text-rose-400 mx-auto mb-3" />
        <p className="text-slate-300 font-medium mb-4">Could not load notification settings.</p>
        <Button onClick={fetchNotificationSettings} variant="outline" size="sm">
          Retry Loading
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Alert Notices */}
      <AnimatePresence>
        {error && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-300 flex items-start gap-3"
          >
            <AlertCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
            <div className="flex-1 text-sm font-medium">{error}</div>
            <button
              onClick={() => setError(null)}
              className="text-xs text-rose-400 hover:text-white cursor-pointer"
            >
              Dismiss
            </button>
          </motion.div>
        )}

        {successMsg && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 flex items-center gap-3"
          >
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            <div className="flex-1 text-sm font-medium">{successMsg}</div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header Banner & Provider Status Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {/* In-App Provider */}
        <Card className="p-4 bg-slate-900/90 border-emerald-500/20 relative overflow-hidden">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2 text-emerald-400">
              <Bell className="w-4 h-4" />
              <span className="text-xs font-bold uppercase tracking-wider">In-App Stream</span>
            </div>
            <Badge variant="success" size="sm">
              Active
            </Badge>
          </div>
          <p className="text-xs text-slate-300 font-medium">Built-in Notification Feed</p>
          <p className="text-[11px] text-slate-400 mt-1">Live delivery to Student, Guardian & Faculty portals.</p>
        </Card>

        {/* Email Provider */}
        <Card className="p-4 bg-slate-900/90 border-amber-500/20 relative overflow-hidden">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2 text-amber-400">
              <Mail className="w-4 h-4" />
              <span className="text-xs font-bold uppercase tracking-wider">Email Gateway</span>
            </div>
            <Badge variant="warning" size="sm">
              Sandbox Ready
            </Badge>
          </div>
          <p className="text-xs text-slate-300 font-medium">SMTP / SendGrid Engine</p>
          <p className="text-[11px] text-slate-400 mt-1">Provider-ready queue. Logs simulated dispatches.</p>
        </Card>

        {/* SMS Provider */}
        <Card className="p-4 bg-slate-900/90 border-amber-500/20 relative overflow-hidden">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2 text-amber-400">
              <MessageSquare className="w-4 h-4" />
              <span className="text-xs font-bold uppercase tracking-wider">SMS Gateway</span>
            </div>
            <Badge variant="warning" size="sm">
              Sandbox Ready
            </Badge>
          </div>
          <p className="text-xs text-slate-300 font-medium">Twilio / AWS SNS Engine</p>
          <p className="text-[11px] text-slate-400 mt-1">Provider-ready queue. Logs simulated dispatches.</p>
        </Card>

        {/* Push Provider */}
        <Card className="p-4 bg-slate-900/90 border-amber-500/20 relative overflow-hidden">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2 text-amber-400">
              <Smartphone className="w-4 h-4" />
              <span className="text-xs font-bold uppercase tracking-wider">Push Gateway</span>
            </div>
            <Badge variant="warning" size="sm">
              Sandbox Ready
            </Badge>
          </div>
          <p className="text-xs text-slate-300 font-medium">Web Push / FCM Engine</p>
          <p className="text-[11px] text-slate-400 mt-1">Provider-ready queue. Logs simulated dispatches.</p>
        </Card>
      </div>

      {/* Event Configuration Matrix */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/10 pb-4">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Radio className="w-4 h-4 text-indigo-400" />
              Attendance Event Trigger Policies & Target Channels
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Select which attendance milestones emit alerts, which channels receive dispatches, and target recipient groups.
            </p>
          </div>

          <div className="flex items-center gap-2">
            {onNavigateToTemplates && (
              <Button
                variant="outline"
                size="sm"
                onClick={onNavigateToTemplates}
                icon={<Layers className="w-3.5 h-3.5" />}
              >
                Edit Templates
              </Button>
            )}
            {onNavigateToHistory && (
              <Button
                variant="outline"
                size="sm"
                onClick={onNavigateToHistory}
                icon={<Clock className="w-3.5 h-3.5" />}
              >
                View History
              </Button>
            )}
          </div>
        </div>

        <div className="space-y-3">
          {EVENT_LABELS.map((evt) => {
            const config = settings[evt.key];
            const isEnabled = config.enabled;

            return (
              <div
                key={evt.key}
                className={`p-4 rounded-xl border transition-all ${
                  isEnabled
                    ? 'bg-slate-900/90 border-white/15'
                    : 'bg-slate-900/40 border-white/5 opacity-70'
                }`}
              >
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                  {/* Left: Master Toggle & Description */}
                  <div className="flex items-start gap-3 flex-1">
                    <button
                      type="button"
                      onClick={() => handleToggleEvent(evt.key)}
                      className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none mt-1 ${
                        isEnabled ? 'bg-indigo-600' : 'bg-slate-700'
                      }`}
                    >
                      <span
                        className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out ${
                          isEnabled ? 'translate-x-5' : 'translate-x-0'
                        }`}
                      />
                    </button>

                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-bold text-white">{evt.title}</span>
                        <Badge
                          variant={
                            evt.badge === 'Critical'
                              ? 'danger'
                              : evt.badge === 'Warning'
                              ? 'warning'
                              : 'info'
                          }
                          size="sm"
                        >
                          {evt.badge}
                        </Badge>
                      </div>
                      <p className="text-xs text-slate-400 mt-0.5">{evt.description}</p>
                    </div>
                  </div>

                  {/* Middle: Channel Selection Pills */}
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mr-1">
                      Channels:
                    </span>

                    {/* In-App */}
                    <button
                      type="button"
                      disabled={!isEnabled}
                      onClick={() => handleToggleChannel(evt.key, 'inApp')}
                      className={`px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1.5 border transition-all cursor-pointer ${
                        config.channels.inApp && isEnabled
                          ? 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30'
                          : 'bg-slate-800/60 text-slate-500 border-slate-700/60 hover:text-slate-400'
                      }`}
                    >
                      <Bell className="w-3 h-3" />
                      In-App
                    </button>

                    {/* Email */}
                    <button
                      type="button"
                      disabled={!isEnabled}
                      onClick={() => handleToggleChannel(evt.key, 'email')}
                      className={`px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1.5 border transition-all cursor-pointer ${
                        config.channels.email && isEnabled
                          ? 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                          : 'bg-slate-800/60 text-slate-500 border-slate-700/60 hover:text-slate-400'
                      }`}
                    >
                      <Mail className="w-3 h-3" />
                      Email
                    </button>

                    {/* SMS */}
                    <button
                      type="button"
                      disabled={!isEnabled}
                      onClick={() => handleToggleChannel(evt.key, 'sms')}
                      className={`px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1.5 border transition-all cursor-pointer ${
                        config.channels.sms && isEnabled
                          ? 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                          : 'bg-slate-800/60 text-slate-500 border-slate-700/60 hover:text-slate-400'
                      }`}
                    >
                      <MessageSquare className="w-3 h-3" />
                      SMS
                    </button>

                    {/* Push */}
                    <button
                      type="button"
                      disabled={!isEnabled}
                      onClick={() => handleToggleChannel(evt.key, 'push')}
                      className={`px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1.5 border transition-all cursor-pointer ${
                        config.channels.push && isEnabled
                          ? 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                          : 'bg-slate-800/60 text-slate-500 border-slate-700/60 hover:text-slate-400'
                      }`}
                    >
                      <Smartphone className="w-3 h-3" />
                      Push
                    </button>
                  </div>

                  {/* Right: Target Recipients */}
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mr-1">
                      Recipients:
                    </span>

                    {/* Guardian */}
                    <button
                      type="button"
                      disabled={!isEnabled}
                      onClick={() => handleToggleRecipient(evt.key, 'guardian')}
                      className={`px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1.5 border transition-all cursor-pointer ${
                        config.recipients.guardian && isEnabled
                          ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                          : 'bg-slate-800/60 text-slate-500 border-slate-700/60 hover:text-slate-400'
                      }`}
                    >
                      Guardian
                    </button>

                    {/* Student */}
                    <button
                      type="button"
                      disabled={!isEnabled}
                      onClick={() => handleToggleRecipient(evt.key, 'student')}
                      className={`px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1.5 border transition-all cursor-pointer ${
                        config.recipients.student && isEnabled
                          ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                          : 'bg-slate-800/60 text-slate-500 border-slate-700/60 hover:text-slate-400'
                      }`}
                    >
                      Student
                    </button>

                    {/* Staff */}
                    <button
                      type="button"
                      disabled={!isEnabled}
                      onClick={() => handleToggleRecipient(evt.key, 'staff')}
                      className={`px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1.5 border transition-all cursor-pointer ${
                        config.recipients.staff && isEnabled
                          ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                          : 'bg-slate-800/60 text-slate-500 border-slate-700/60 hover:text-slate-400'
                      }`}
                    >
                      Faculty/Staff
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Engine & Delivery Policies */}
      <Card className="p-6 bg-slate-900/80 border-white/10">
        <h3 className="text-base font-bold text-white flex items-center gap-2 mb-1">
          <Shield className="w-4 h-4 text-indigo-400" />
          Deduplication, Queueing & Delivery Governance
        </h3>
        <p className="text-xs text-slate-400 mb-6">
          Strict server-side anti-spam throttling, duplicate suppression windows, and automatic retry policies.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
          {/* Prevent Duplicates Toggle */}
          <div className="p-4 rounded-xl bg-slate-800/40 border border-white/5 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm font-semibold text-white">Prevent Duplicates</span>
                <button
                  type="button"
                  onClick={() =>
                    setSettings({
                      ...settings,
                      preventDuplicates: !settings.preventDuplicates
                    })
                  }
                  className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                    settings.preventDuplicates ? 'bg-indigo-600' : 'bg-slate-700'
                  }`}
                >
                  <span
                    className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                      settings.preventDuplicates ? 'translate-x-4' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>
              <p className="text-[11px] text-slate-400">
                Suppresses repetitive dispatches for the exact same event, date, recipient, and status.
              </p>
            </div>
          </div>

          {/* Deduplication Window */}
          <div className="p-4 rounded-xl bg-slate-800/40 border border-white/5">
            <label className="text-xs font-semibold text-slate-300 block mb-1">
              Suppression Window (Minutes)
            </label>
            <input
              type="number"
              min={5}
              max={1440}
              value={settings.deduplicationWindowMinutes}
              onChange={(e) =>
                setSettings({
                  ...settings,
                  deduplicationWindowMinutes: Math.max(5, parseInt(e.target.value, 10) || 60)
                })
              }
              className="w-full bg-slate-900/90 border border-white/10 rounded-lg px-3 py-1.5 text-sm text-white focus:outline-none focus:border-indigo-500"
            />
            <span className="text-[11px] text-slate-400 mt-1 block">
              Default: 60 mins (Prevents spam on multi-edit).
            </span>
          </div>

          {/* Max Retries */}
          <div className="p-4 rounded-xl bg-slate-800/40 border border-white/5">
            <label className="text-xs font-semibold text-slate-300 block mb-1">
              Max Delivery Retries
            </label>
            <input
              type="number"
              min={1}
              max={10}
              value={settings.maxRetries}
              onChange={(e) =>
                setSettings({
                  ...settings,
                  maxRetries: Math.max(1, parseInt(e.target.value, 10) || 3)
                })
              }
              className="w-full bg-slate-900/90 border border-white/10 rounded-lg px-3 py-1.5 text-sm text-white focus:outline-none focus:border-indigo-500"
            />
            <span className="text-[11px] text-slate-400 mt-1 block">
              Max attempts for transient gateway timeouts.
            </span>
          </div>

          {/* Batch Processing Size */}
          <div className="p-4 rounded-xl bg-slate-800/40 border border-white/5">
            <label className="text-xs font-semibold text-slate-300 block mb-1">
              Queue Batch Size
            </label>
            <input
              type="number"
              min={10}
              max={500}
              value={settings.batchSize}
              onChange={(e) =>
                setSettings({
                  ...settings,
                  batchSize: Math.max(10, parseInt(e.target.value, 10) || 50)
                })
              }
              className="w-full bg-slate-900/90 border border-white/10 rounded-lg px-3 py-1.5 text-sm text-white focus:outline-none focus:border-indigo-500"
            />
            <span className="text-[11px] text-slate-400 mt-1 block">
              Workers process roll calls in throttled chunks.
            </span>
          </div>
        </div>
      </Card>

      {/* Test Alert Dispatcher */}
      <Card className="p-6 bg-indigo-950/20 border-indigo-500/30">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-indigo-400" />
              Live Alert Simulation & Verification
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Super Admins can simulate an immediate alert trigger to verify in-app notification appearance, template interpolation, and delivery logging.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <select
              value={testEventType}
              onChange={(e) => setTestEventType(e.target.value as AttendanceNotificationEventType)}
              className="bg-slate-900 border border-white/15 rounded-lg px-3 py-2 text-xs font-medium text-white focus:outline-none focus:border-indigo-500"
            >
              <option value="STUDENT_ABSENT">Absence Alert (STUDENT_ABSENT)</option>
              <option value="STUDENT_LATE">Late Arrival (STUDENT_LATE)</option>
              <option value="STUDENT_HALF_DAY">Half-Day (STUDENT_HALF_DAY)</option>
              <option value="LEAVE_APPROVED">Leave Approved (LEAVE_APPROVED)</option>
              <option value="ATTENDANCE_CORRECTION">Correction Notice (ATTENDANCE_CORRECTION)</option>
            </select>

            <Button
              variant="primary"
              size="sm"
              onClick={handleSendTestDispatch}
              loading={dispatchingTest}
              icon={<Send className="w-3.5 h-3.5" />}
            >
              Dispatch Test Alert
            </Button>
          </div>
        </div>

        {testResult && (
          <motion.div
            initial={{ opacity: 0, y: 4 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-4 p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-xs flex items-center justify-between"
          >
            <span>{testResult.message}</span>
            <div className="flex items-center gap-2 font-mono">
              <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300">
                Delivered: {testResult.sent}
              </span>
              <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300">
                Queued/Sandbox: {testResult.queued}
              </span>
              {testResult.duplicate > 0 && (
                <span className="px-2 py-0.5 rounded bg-slate-500/20 text-slate-300">
                  Duplicates Suppressed: {testResult.duplicate}
                </span>
              )}
            </div>
          </motion.div>
        )}
      </Card>

      {/* Bottom Action Footer */}
      <div className="flex items-center justify-between pt-4 border-t border-white/10">
        <p className="text-xs text-slate-500">
          Last modified: {new Date(settings.updatedAt).toLocaleString()} by {settings.updatedByName || 'Administrator'}
        </p>

        <div className="flex items-center gap-3">
          <Button
            variant="outline"
            onClick={fetchNotificationSettings}
            disabled={saving}
            icon={<RotateCcw className="w-4 h-4" />}
          >
            Revert
          </Button>

          <Button
            variant="primary"
            onClick={handleSaveSettings}
            loading={saving}
            icon={<Save className="w-4 h-4" />}
          >
            Save Notification Policies
          </Button>
        </div>
      </div>
    </div>
  );
};
