import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  FileText,
  Save,
  RotateCcw,
  CheckCircle2,
  AlertCircle,
  Eye,
  Sparkles,
  Layers,
  HelpCircle,
  Code2,
  Copy,
  Info
} from 'lucide-react';
import { Card } from '../../../../components/ui/Card.js';
import { Badge } from '../../../../components/ui/Badge.js';
import { Button } from '../../../../components/ui/Button.js';
import {
  AttendanceNotificationTemplate,
  AttendanceNotificationEventType
} from '../../../../types/index.js';

const SAMPLE_DATA: Record<string, string> = {
  student_name: 'Sophia Patel',
  first_name: 'Sophia',
  last_name: 'Patel',
  admission_number: 'ADM-2026-0842',
  class_name: 'Grade 10',
  section_name: 'Section A',
  date: '2026-09-04',
  status: 'ABSENT',
  previous_status: 'ABSENT',
  new_status: 'EXCUSED',
  corrected_status: 'EXCUSED',
  attendance_status: 'ABSENT',
  leave_type: 'Medical Leave',
  leave_start_date: '2026-09-04',
  leave_end_date: '2026-09-06',
  reason: 'Severe fever and prescribed medical rest',
  school_name: 'Sygmate International Academy',
  recipient_name: 'Rajesh Patel',
  review_notes: 'Valid doctor recommendation verified'
};

export const AttendanceNotificationTemplatesTab: React.FC = () => {
  const [templates, setTemplates] = useState<AttendanceNotificationTemplate[]>([]);
  const [selectedTemplateId, setSelectedTemplateId] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(true);
  const [saving, setSaving] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Active form state for selected template
  const [activeTitle, setActiveTitle] = useState<string>('');
  const [activeBody, setActiveBody] = useState<string>('');
  const [activeTargetField, setActiveTargetField] = useState<'title' | 'body'>('body');

  const fetchTemplates = async () => {
    setLoading(true);
    setError(null);
    try {
      const token = localStorage.getItem('sygmate_auth_token') || localStorage.getItem('token') || localStorage.getItem('sygmate_token');
      const res = await fetch('/api/attendance/notifications/templates', {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      const data = await res.json();
      if (!data.success) {
        throw new Error(data.error || 'Failed to fetch notification templates');
      }
      const templatesList = Array.isArray(data?.data) ? data.data : [];
      setTemplates(templatesList);
      if (templatesList.length > 0 && !selectedTemplateId) {
        setSelectedTemplateId(templatesList?.[0]?.id || '');
        setActiveTitle(templatesList?.[0]?.titleTemplate || '');
        setActiveBody(templatesList?.[0]?.bodyTemplate || '');
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTemplates();
  }, []);

  const activeTemplate = (templates || []).find((t) => t.id === selectedTemplateId) || templates?.[0];

  useEffect(() => {
    if (activeTemplate) {
      setActiveTitle(activeTemplate.titleTemplate);
      setActiveBody(activeTemplate.bodyTemplate);
    }
  }, [selectedTemplateId]);

  const handleSelectTemplate = (id: string) => {
    setSelectedTemplateId(id);
    const tmpl = (templates || []).find((t) => t?.id === id);
    if (tmpl) {
      setActiveTitle(tmpl.titleTemplate);
      setActiveBody(tmpl.bodyTemplate);
    }
  };

  const handleInsertVariable = (variable: string) => {
    const placeholder = `{{${variable}}}`;
    if (activeTargetField === 'title') {
      setActiveTitle((prev) => `${prev} ${placeholder}`);
    } else {
      setActiveBody((prev) => `${prev} ${placeholder}`);
    }
  };

  const renderInterpolation = (text: string): string => {
    if (!text) return '';
    let rendered = text;
    for (const [key, val] of Object.entries(SAMPLE_DATA)) {
      const regex = new RegExp(`{{\\s*${key}\\s*}}`, 'gi');
      rendered = rendered.replace(regex, val);
    }
    return rendered;
  };

  const handleSaveTemplate = async () => {
    if (!activeTemplate) return;
    setSaving(true);
    setError(null);
    setSuccessMsg(null);

    try {
      const token = localStorage.getItem('sygmate_auth_token') || localStorage.getItem('token') || localStorage.getItem('sygmate_token');
      const res = await fetch(`/api/attendance/notifications/templates/${activeTemplate.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          titleTemplate: activeTitle.trim(),
          bodyTemplate: activeBody.trim()
        })
      });

      const data = await res.json();
      if (!data.success) {
        throw new Error(data.error || 'Failed to update template');
      }

      setTemplates((prev) =>
        prev.map((t) => (t.id === activeTemplate.id ? data.data : t))
      );
      setSuccessMsg(`Template "${activeTemplate.name}" updated successfully.`);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  const handleResetToDefault = async () => {
    if (!activeTemplate) return;
    if (!window.confirm(`Reset template "${activeTemplate.name}" to standard system defaults?`)) {
      return;
    }
    setSaving(true);
    setError(null);

    try {
      const token = localStorage.getItem('sygmate_auth_token') || localStorage.getItem('token') || localStorage.getItem('sygmate_token');
      const res = await fetch(`/api/attendance/notifications/templates/${activeTemplate.id}/reset`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      const data = await res.json();
      if (!data.success) {
        throw new Error(data.error || 'Failed to reset template');
      }

      setActiveTitle(data.data.titleTemplate);
      setActiveBody(data.data.bodyTemplate);
      setTemplates((prev) =>
        prev.map((t) => (t.id === activeTemplate.id ? data.data : t))
      );
      setSuccessMsg(`Template restored to default standard formatting.`);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="py-16 text-center">
        <div className="w-8 h-8 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
        <p className="text-sm text-slate-400">Loading Notification Templates...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Alert Banner */}
      <AnimatePresence>
        {error && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-300 flex items-start gap-3"
          >
            <AlertCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
            <div className="flex-1 text-sm font-medium">{error}</div>
            <button
              onClick={() => setError(null)}
              className="text-xs text-rose-400 hover:text-white cursor-pointer"
            >
              Dismiss
            </button>
          </motion.div>
        )}

        {successMsg && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 flex items-center gap-3"
          >
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            <div className="flex-1 text-sm font-medium">{successMsg}</div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Template Selector List */}
        <div className="lg:col-span-4 space-y-2">
          <div className="flex items-center justify-between pb-2 border-b border-white/10">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Notification Events ({templates.length})
            </span>
          </div>

          <div className="space-y-1.5">
            {templates.map((tmpl) => {
              const isSelected = tmpl.id === activeTemplate?.id;
              return (
                <button
                  key={tmpl.id}
                  onClick={() => handleSelectTemplate(tmpl.id)}
                  className={`w-full text-left p-3 rounded-xl border transition-all cursor-pointer flex flex-col gap-1 ${
                    isSelected
                      ? 'bg-indigo-600/15 border-indigo-500/40 text-white shadow-sm'
                      : 'bg-slate-900/60 border-white/5 text-slate-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold truncate">{tmpl.name}</span>
                    <Badge variant={isSelected ? 'info' : 'outline'} size="sm">
                      {tmpl.eventType}
                    </Badge>
                  </div>
                  <p className="text-[11px] text-slate-400 line-clamp-1">{tmpl.description}</p>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right: Active Template Editor & Live Preview */}
        {activeTemplate ? (
          <div className="lg:col-span-8 space-y-6">
            <Card className="p-6 bg-slate-900/90 border-white/10 space-y-5">
              <div className="flex items-start justify-between border-b border-white/10 pb-4">
                <div>
                  <h3 className="text-base font-bold text-white flex items-center gap-2">
                    <FileText className="w-4 h-4 text-indigo-400" />
                    {activeTemplate.name}
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">{activeTemplate.description}</p>
                </div>

                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleResetToDefault}
                  icon={<RotateCcw className="w-3.5 h-3.5" />}
                >
                  Reset to Default
                </Button>
              </div>

              {/* Dynamic Variables Selector */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                    <Code2 className="w-3.5 h-3.5 text-indigo-400" />
                    Insert Dynamic Placeholder Variables
                  </label>
                  <span className="text-[11px] text-slate-500">
                    Active Target:{' '}
                    <span className="text-indigo-400 font-semibold uppercase">
                      {activeTargetField}
                    </span>
                  </span>
                </div>

                <div className="flex flex-wrap gap-1.5 p-3 rounded-xl bg-slate-800/40 border border-white/5">
                  {activeTemplate.allowedVariables.map((v) => (
                    <button
                      key={v}
                      type="button"
                      onClick={() => handleInsertVariable(v)}
                      className="px-2.5 py-1 rounded-lg text-xs font-mono font-medium bg-indigo-500/15 hover:bg-indigo-500/25 text-indigo-300 border border-indigo-500/30 transition-all cursor-pointer flex items-center gap-1"
                    >
                      <span>{`{{${v}}}`}</span>
                    </button>
                  ))}
                </div>
                <p className="text-[11px] text-slate-500 mt-1.5">
                  Click any placeholder pill to inject it into the active text input below.
                </p>
              </div>

              {/* Subject / Title Template Input */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300 flex items-center justify-between">
                  <span>Subject / Notification Title Template</span>
                  <span className="text-[11px] text-slate-400 font-normal">
                    Appears as SMS Header, Email Subject & In-App Notification Title
                  </span>
                </label>
                <input
                  type="text"
                  value={activeTitle}
                  onFocus={() => setActiveTargetField('title')}
                  onChange={(e) => setActiveTitle(e.target.value)}
                  className="w-full bg-slate-800/80 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white font-medium focus:outline-none focus:border-indigo-500"
                  placeholder="e.g. Attendance Alert: {{student_name}} marked {{status}}"
                />
              </div>

              {/* Body Template Input */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300 flex items-center justify-between">
                  <span>Notification Message Body Template</span>
                  <span className="text-[11px] text-slate-400 font-normal">
                    Supports line breaks, markdown, and full interpolation
                  </span>
                </label>
                <textarea
                  rows={5}
                  value={activeBody}
                  onFocus={() => setActiveTargetField('body')}
                  onChange={(e) => setActiveBody(e.target.value)}
                  className="w-full bg-slate-800/80 border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-indigo-500 leading-relaxed font-sans"
                  placeholder="Compose message with dynamic variables..."
                />
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-end gap-3 pt-2">
                <Button
                  variant="primary"
                  onClick={handleSaveTemplate}
                  loading={saving}
                  icon={<Save className="w-4 h-4" />}
                >
                  Save Template
                </Button>
              </div>
            </Card>

            {/* Real-Time Live Preview Card */}
            <Card className="p-6 bg-slate-900/70 border-white/10">
              <div className="flex items-center justify-between mb-4">
                <h4 className="text-sm font-bold text-white flex items-center gap-2">
                  <Eye className="w-4 h-4 text-emerald-400" />
                  Live Notification Preview (Interpolated with Real-World Sample Data)
                </h4>
                <Badge variant="success" size="sm">
                  Simulated Output
                </Badge>
              </div>

              {/* In-App / Push Notification Card Mockup */}
              <div className="p-4 rounded-xl bg-slate-800/80 border border-white/15 shadow-lg space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-indigo-300 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5" />
                    Sygmate Attendance Gateway
                  </span>
                  <span className="text-[11px] text-slate-400 font-mono">Just Now</span>
                </div>
                <h5 className="text-sm font-bold text-white">
                  {renderInterpolation(activeTitle) || 'Notification Subject'}
                </h5>
                <p className="text-xs text-slate-300 leading-relaxed whitespace-pre-wrap">
                  {renderInterpolation(activeBody) || 'Notification body message will preview here.'}
                </p>
                <div className="pt-2 flex items-center gap-2 text-[11px] text-slate-400 border-t border-white/5 font-mono">
                  <span>To: {SAMPLE_DATA.recipient_name} (Guardian)</span>
                  <span>•</span>
                  <span>Student: {SAMPLE_DATA.student_name}</span>
                </div>
              </div>
            </Card>
          </div>
        ) : null}
      </div>
    </div>
  );
};
