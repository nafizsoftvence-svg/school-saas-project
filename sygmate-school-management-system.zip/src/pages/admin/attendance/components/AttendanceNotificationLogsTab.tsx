import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Clock,
  Search,
  Filter,
  RefreshCw,
  Bell,
  Mail,
  MessageSquare,
  Smartphone,
  CheckCircle2,
  AlertCircle,
  AlertTriangle,
  RotateCcw,
  Eye,
  Calendar,
  X,
  User,
  Shield,
  Layers,
  Send
} from 'lucide-react';
import { Card } from '../../../../components/ui/Card.js';
import { Badge } from '../../../../components/ui/Badge.js';
import { Button } from '../../../../components/ui/Button.js';
import { Modal } from '../../../../components/ui/Modal.js';
import {
  AttendanceNotificationLog,
  AttendanceNotificationEventType,
  AttendanceNotificationChannel,
  AttendanceNotificationStatus
} from '../../../../types/index.js';

export const AttendanceNotificationLogsTab: React.FC = () => {
  const [logs, setLogs] = useState<AttendanceNotificationLog[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Filters
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedEventType, setSelectedEventType] = useState<string>('ALL');
  const [selectedChannel, setSelectedChannel] = useState<string>('ALL');
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');
  const [startDate, setStartDate] = useState<string>('');
  const [endDate, setEndDate] = useState<string>('');

  // Selected Log Modal
  const [selectedLog, setSelectedLog] = useState<AttendanceNotificationLog | null>(null);
  const [retryingLogId, setRetryingLogId] = useState<string | null>(null);

  const fetchLogs = async () => {
    setLoading(true);
    setError(null);
    try {
      const token = localStorage.getItem('sygmate_auth_token') || localStorage.getItem('token') || localStorage.getItem('sygmate_token');
      const params = new URLSearchParams();
      if (selectedEventType !== 'ALL') params.append('eventType', selectedEventType);
      if (selectedChannel !== 'ALL') params.append('channel', selectedChannel);
      if (selectedStatus !== 'ALL') params.append('status', selectedStatus);
      if (startDate) params.append('startDate', startDate);
      if (endDate) params.append('endDate', endDate);
      if (searchQuery.trim()) params.append('search', searchQuery.trim());

      const res = await fetch(`/api/attendance/notifications/logs?${params.toString()}`, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      const data = await res.json();
      if (!data.success) {
        throw new Error(data.error || 'Failed to fetch notification logs');
      }
      setLogs(data.data);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLogs();
  }, [selectedEventType, selectedChannel, selectedStatus, startDate, endDate]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchLogs();
  };

  const handleRetryNotification = async (logId: string) => {
    setRetryingLogId(logId);
    setError(null);
    try {
      const token = localStorage.getItem('sygmate_auth_token') || localStorage.getItem('token') || localStorage.getItem('sygmate_token');
      const res = await fetch(`/api/attendance/notifications/logs/${logId}/retry`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      const data = await res.json();
      if (!data.success) {
        throw new Error(data.error || 'Failed to retry notification dispatch');
      }
      setSuccessMsg('Notification redelivery queued and processed.');
      // Update local item
      setLogs((prev) => prev.map((l) => (l.id === logId ? data.data : l)));
      if (selectedLog?.id === logId) {
        setSelectedLog(data.data);
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setRetryingLogId(null);
    }
  };

  // Compute KPI metrics
  const totalLogs = logs.length;
  const sentLogs = logs.filter((l) => l.status === 'SENT').length;
  const queuedLogs = logs.filter((l) => l.status === 'QUEUED').length;
  const suppressedLogs = logs.filter((l) => l.status === 'SUPPRESSED').length;
  const failedLogs = logs.filter((l) => l.status === 'FAILED').length;

  const getChannelIcon = (channel: AttendanceNotificationChannel) => {
    switch (channel) {
      case 'IN_APP':
        return <Bell className="w-3.5 h-3.5 text-indigo-400" />;
      case 'EMAIL':
        return <Mail className="w-3.5 h-3.5 text-amber-400" />;
      case 'SMS':
        return <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />;
      case 'PUSH':
        return <Smartphone className="w-3.5 h-3.5 text-blue-400" />;
    }
  };

  const getStatusBadge = (status: AttendanceNotificationStatus) => {
    switch (status) {
      case 'SENT':
        return <Badge variant="success" size="sm">Sent / Delivered</Badge>;
      case 'QUEUED':
        return <Badge variant="warning" size="sm">Sandbox Queued</Badge>;
      case 'SUPPRESSED':
        return <Badge variant="slate" size="sm">Suppressed (Duplicate)</Badge>;
      case 'FAILED':
        return <Badge variant="danger" size="sm">Failed</Badge>;
      case 'PENDING':
      case 'PROCESSING':
        return <Badge variant="info" size="sm">Processing</Badge>;
      case 'RETRYING':
        return <Badge variant="warning" size="sm">Retrying</Badge>;
      case 'CANCELLED':
        return <Badge variant="slate" size="sm">Cancelled</Badge>;
      default:
        return <Badge variant="outline" size="sm">{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Alert Notices */}
      <AnimatePresence>
        {error && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-300 flex items-start gap-3"
          >
            <AlertCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
            <div className="flex-1 text-sm font-medium">{error}</div>
            <button
              onClick={() => setError(null)}
              className="text-xs text-rose-400 hover:text-white cursor-pointer"
            >
              Dismiss
            </button>
          </motion.div>
        )}

        {successMsg && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 flex items-center gap-3"
          >
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            <div className="flex-1 text-sm font-medium">{successMsg}</div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        <Card className="p-4 bg-slate-900/80 border-white/10">
          <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Total Dispatches</p>
          <p className="text-2xl font-bold text-white mt-1">{totalLogs}</p>
          <span className="text-[11px] text-slate-500">Filtered timeframe</span>
        </Card>

        <Card className="p-4 bg-slate-900/80 border-emerald-500/20">
          <p className="text-[11px] font-semibold text-emerald-400 uppercase tracking-wider">Sent / In-App Live</p>
          <p className="text-2xl font-bold text-emerald-400 mt-1">{sentLogs}</p>
          <span className="text-[11px] text-slate-500">Directly delivered</span>
        </Card>

        <Card className="p-4 bg-slate-900/80 border-amber-500/20">
          <p className="text-[11px] font-semibold text-amber-400 uppercase tracking-wider">Queued / Sandbox</p>
          <p className="text-2xl font-bold text-amber-400 mt-1">{queuedLogs}</p>
          <span className="text-[11px] text-slate-500">Ready for external gateway</span>
        </Card>

        <Card className="p-4 bg-slate-900/80 border-slate-500/20">
          <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Suppressed Duplicates</p>
          <p className="text-2xl font-bold text-slate-300 mt-1">{suppressedLogs}</p>
          <span className="text-[11px] text-slate-500">Spam prevented</span>
        </Card>

        <Card className="p-4 bg-slate-900/80 border-rose-500/20">
          <p className="text-[11px] font-semibold text-rose-400 uppercase tracking-wider">Failed Dispatches</p>
          <p className="text-2xl font-bold text-rose-400 mt-1">{failedLogs}</p>
          <span className="text-[11px] text-slate-500">Require retry</span>
        </Card>
      </div>

      {/* Filter Toolbar */}
      <Card className="p-4 bg-slate-900/80 border-white/10 space-y-3">
        <form onSubmit={handleSearchSubmit} className="flex flex-col lg:flex-row items-center gap-3">
          {/* Keyword Search */}
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search recipient name, student name, roll number, or notification title..."
              className="w-full bg-slate-800/80 border border-white/10 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div className="flex items-center gap-2 flex-wrap w-full lg:w-auto">
            {/* Event Filter */}
            <select
              value={selectedEventType}
              onChange={(e) => setSelectedEventType(e.target.value)}
              className="bg-slate-800/90 border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
            >
              <option value="ALL">All Event Types</option>
              <option value="STUDENT_ABSENT">Student Absent</option>
              <option value="STUDENT_LATE">Student Late</option>
              <option value="STUDENT_HALF_DAY">Student Half-Day</option>
              <option value="LEAVE_SUBMITTED">Leave Submitted</option>
              <option value="LEAVE_APPROVED">Leave Approved</option>
              <option value="LEAVE_REJECTED">Leave Rejected</option>
              <option value="LEAVE_CANCELLED">Leave Cancelled</option>
              <option value="ATTENDANCE_CORRECTION">Correction Notice</option>
            </select>

            {/* Channel Filter */}
            <select
              value={selectedChannel}
              onChange={(e) => setSelectedChannel(e.target.value)}
              className="bg-slate-800/90 border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
            >
              <option value="ALL">All Channels</option>
              <option value="IN_APP">In-App Stream</option>
              <option value="EMAIL">Email Gateway</option>
              <option value="SMS">SMS Gateway</option>
              <option value="PUSH">Push Gateway</option>
            </select>

            {/* Status Filter */}
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="bg-slate-800/90 border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
            >
              <option value="ALL">All Statuses</option>
              <option value="SENT">Sent / Live</option>
              <option value="QUEUED">Queued / Sandbox</option>
              <option value="SUPPRESSED">Suppressed Duplicate</option>
              <option value="FAILED">Failed</option>
            </select>

            <Button
              type="submit"
              variant="outline"
              size="sm"
              icon={<RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />}
            >
              Refresh
            </Button>
          </div>
        </form>

        {/* Date Range Sub-Bar */}
        <div className="flex items-center gap-3 pt-2 border-t border-white/5 text-xs text-slate-400">
          <span className="font-semibold flex items-center gap-1">
            <Calendar className="w-3.5 h-3.5 text-indigo-400" />
            Date Filter:
          </span>
          <div className="flex items-center gap-2">
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="bg-slate-800 border border-white/10 rounded-lg px-2 py-1 text-xs text-white focus:outline-none focus:border-indigo-500"
            />
            <span>to</span>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="bg-slate-800 border border-white/10 rounded-lg px-2 py-1 text-xs text-white focus:outline-none focus:border-indigo-500"
            />
            {(startDate || endDate) && (
              <button
                onClick={() => {
                  setStartDate('');
                  setEndDate('');
                }}
                className="text-xs text-indigo-400 hover:text-white cursor-pointer ml-1"
              >
                Clear Dates
              </button>
            )}
          </div>
        </div>
      </Card>

      {/* Logs Table */}
      <Card className="overflow-hidden bg-slate-900/90 border-white/10">
        {loading ? (
          <div className="py-16 text-center">
            <div className="w-8 h-8 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
            <p className="text-sm text-slate-400">Fetching Notification Dispatch Logs...</p>
          </div>
        ) : logs.length === 0 ? (
          <div className="py-16 text-center">
            <Bell className="w-10 h-10 text-slate-600 mx-auto mb-3" />
            <p className="text-base font-semibold text-slate-300">No Notification Logs Found</p>
            <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
              No attendance alerts match the current filter criteria. Try broadening your date range or search parameters.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-white/10 bg-slate-800/50 text-slate-400 font-semibold uppercase tracking-wider">
                  <th className="py-3 px-4">Time & Event</th>
                  <th className="py-3 px-4">Channel</th>
                  <th className="py-3 px-4">Recipient</th>
                  <th className="py-3 px-4">Student</th>
                  <th className="py-3 px-4">Subject / Message Excerpt</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {logs.map((log) => {
                  return (
                    <tr key={log.id} className="hover:bg-white/[0.02] transition-colors">
                      {/* Time & Event */}
                      <td className="py-3 px-4 whitespace-nowrap">
                        <div className="font-mono text-slate-300 font-medium">
                          {new Date(log.createdAt).toLocaleTimeString([], {
                            hour: '2-digit',
                            minute: '2-digit',
                            second: '2-digit'
                          })}
                        </div>
                        <div className="text-[11px] text-slate-500">{log.date}</div>
                        <span className="inline-block mt-1 font-semibold text-[10px] text-indigo-300 bg-indigo-500/10 px-1.5 py-0.5 rounded border border-indigo-500/20">
                          {log.eventType}
                        </span>
                      </td>

                      {/* Channel */}
                      <td className="py-3 px-4 whitespace-nowrap">
                        <div className="flex items-center gap-1.5 font-medium text-slate-300">
                          {getChannelIcon(log.channel)}
                          <span>{log.channel}</span>
                        </div>
                        <span className="text-[10px] text-slate-500">
                          {log.provider === 'IN_APP_SYSTEM' ? 'Internal Feed' : log.provider}
                        </span>
                      </td>

                      {/* Recipient */}
                      <td className="py-3 px-4 whitespace-nowrap">
                        <div className="font-bold text-white flex items-center gap-1.5">
                          <User className="w-3 h-3 text-slate-400" />
                          {log.recipientName}
                        </div>
                        <div className="text-[11px] text-slate-400 flex items-center gap-1 mt-0.5">
                          <span className="px-1.5 py-0.2 rounded bg-slate-800 text-[10px] uppercase font-semibold">
                            {log.recipientRole}
                          </span>
                          {log.recipientDestination && (
                            <span className="font-mono text-slate-500 truncate max-w-[120px]">
                              {log.recipientDestination}
                            </span>
                          )}
                        </div>
                      </td>

                      {/* Student */}
                      <td className="py-3 px-4 whitespace-nowrap">
                        <div className="text-white font-medium">{log.studentName || '—'}</div>
                        {log.className && (
                          <div className="text-[11px] text-slate-500">
                            {log.className} {log.sectionName ? `• ${log.sectionName}` : ''}
                          </div>
                        )}
                      </td>

                      {/* Title / Body Excerpt */}
                      <td className="py-3 px-4 max-w-xs">
                        <div className="font-semibold text-slate-200 truncate">{log.title}</div>
                        <div className="text-[11px] text-slate-400 truncate mt-0.5">{log.body}</div>
                      </td>

                      {/* Status */}
                      <td className="py-3 px-4 whitespace-nowrap">
                        {getStatusBadge(log.status)}
                        {log.retryCount > 0 && (
                          <div className="text-[10px] text-amber-400 mt-0.5">
                            Retried: {log.retryCount}x
                          </div>
                        )}
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1.5">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setSelectedLog(log)}
                            icon={<Eye className="w-3.5 h-3.5" />}
                          >
                            Details
                          </Button>

                          {(log.status === 'FAILED' || log.status === 'QUEUED') && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleRetryNotification(log.id)}
                              loading={retryingLogId === log.id}
                              icon={<RotateCcw className="w-3 h-3" />}
                            >
                              Retry
                            </Button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      {/* Log Detail Modal */}
      {selectedLog && (
        <Modal
          isOpen={true}
          onClose={() => setSelectedLog(null)}
          title="Attendance Notification Dispatch Record"
          size="lg"
        >
          <div className="space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div>
                <span className="font-mono text-slate-400">ID: {selectedLog.id}</span>
                <h4 className="text-base font-bold text-white mt-1">{selectedLog.title}</h4>
              </div>
              <div>{getStatusBadge(selectedLog.status)}</div>
            </div>

            <div className="grid grid-cols-2 gap-3 p-3 rounded-xl bg-slate-800/40 border border-white/5">
              <div>
                <span className="text-slate-400 block font-semibold">Event Type:</span>
                <span className="text-indigo-300 font-mono font-medium">{selectedLog.eventType}</span>
              </div>
              <div>
                <span className="text-slate-400 block font-semibold">Delivery Channel:</span>
                <span className="text-white font-medium">
                  {selectedLog.channel} ({selectedLog.provider})
                </span>
              </div>
              <div>
                <span className="text-slate-400 block font-semibold">Recipient:</span>
                <span className="text-white font-medium">
                  {selectedLog.recipientName} ({selectedLog.recipientRole})
                </span>
              </div>
              <div>
                <span className="text-slate-400 block font-semibold">Destination Address:</span>
                <span className="text-white font-mono">{selectedLog.recipientDestination || 'Direct In-App'}</span>
              </div>
              <div>
                <span className="text-slate-400 block font-semibold">Student:</span>
                <span className="text-white font-medium">
                  {selectedLog.studentName || '—'} ({selectedLog.className || 'Class'})
                </span>
              </div>
              <div>
                <span className="text-slate-400 block font-semibold">Attendance Date:</span>
                <span className="text-white font-mono">{selectedLog.date}</span>
              </div>
            </div>

            {/* Message Body Content */}
            <div className="space-y-1">
              <span className="text-slate-400 font-semibold">Dispatched Notification Payload:</span>
              <div className="p-4 rounded-xl bg-slate-900 border border-white/10 text-slate-200 whitespace-pre-wrap leading-relaxed">
                {selectedLog.body}
              </div>
            </div>

            {/* Metadata and Deduplication Details */}
            {selectedLog.dedupKey && (
              <div className="p-3 rounded-xl bg-slate-950/60 border border-white/5 font-mono text-[11px] text-slate-400">
                <span className="block text-slate-500 font-bold mb-0.5">Deduplication Key:</span>
                <span className="text-slate-300 break-all">{selectedLog.dedupKey}</span>
              </div>
            )}

            {selectedLog.failureReason && (
              <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs">
                <span className="font-bold block mb-1">Failure Reason:</span>
                {selectedLog.failureReason}
              </div>
            )}

            <div className="flex items-center justify-between pt-3 border-t border-white/10">
              <span className="text-slate-500">
                Logged at: {new Date(selectedLog.createdAt).toLocaleString()}
              </span>

              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm" onClick={() => setSelectedLog(null)}>
                  Close
                </Button>
                {(selectedLog.status === 'FAILED' || selectedLog.status === 'QUEUED') && (
                  <Button
                    variant="primary"
                    size="sm"
                    onClick={() => handleRetryNotification(selectedLog.id)}
                    loading={retryingLogId === selectedLog.id}
                    icon={<RotateCcw className="w-3 h-3" />}
                  >
                    Retry Dispatch
                  </Button>
                )}
              </div>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
