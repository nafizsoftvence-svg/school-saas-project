import React, { useState, useEffect, useMemo } from 'react';
import {
  Calendar,
  Clock,
  CheckCircle2,
  XCircle,
  AlertCircle,
  FileText,
  Plus,
  Filter,
  Search,
  RefreshCw,
  Eye,
  Check,
  X,
  AlertTriangle,
  Paperclip,
  Trash2,
  Edit2,
  ShieldCheck,
  Building,
  UserCheck,
  Tag,
  Settings2,
  RotateCcw
} from 'lucide-react';
import { api } from '../../../services/api.js';
import { Modal } from '../../../components/ui/Modal.js';
import { LoadingSpinner } from '../../../components/ui/LoadingSpinner.js';
import { LeaveType, LeaveApplication, LeaveStatus } from '../../../types/index.js';

export const AdminLeaveManagementTab: React.FC = () => {
  const [activeSubTab, setActiveSubTab] = useState<'applications' | 'leave_types'>('applications');
  const [loading, setLoading] = useState(false);

  // Data
  const [applications, setApplications] = useState<LeaveApplication[]>([]);
  const [leaveTypes, setLeaveTypes] = useState<LeaveType[]>([]);

  // Filters
  const [applicantTypeFilter, setApplicantTypeFilter] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  // Toast
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error' | 'warning'; message: string } | null>(null);

  // Detail Modal
  const [selectedApp, setSelectedApp] = useState<LeaveApplication | null>(null);
  const [detailModalOpen, setDetailModalOpen] = useState(false);

  // Review Modal (Approve / Reject)
  const [reviewModalOpen, setReviewModalOpen] = useState(false);
  const [reviewTargetApp, setReviewTargetApp] = useState<LeaveApplication | null>(null);
  const [reviewMode, setReviewMode] = useState<'APPROVE' | 'REJECT'>('APPROVE');
  const [adminRemarks, setAdminRemarks] = useState('');
  const [rejectionReason, setRejectionReason] = useState('');
  const [processing, setProcessing] = useState(false);

  // Cancel Modal
  const [cancelModalOpen, setCancelModalOpen] = useState(false);
  const [cancellingApp, setCancellingApp] = useState<LeaveApplication | null>(null);
  const [cancelReason, setCancelReason] = useState('');
  const [cancelling, setCancelling] = useState(false);

  // Leave Type Form Modal
  const [typeModalOpen, setTypeModalOpen] = useState(false);
  const [editingType, setEditingType] = useState<LeaveType | null>(null);
  const [typeCode, setTypeCode] = useState('');
  const [typeName, setTypeName] = useState('');
  const [typeApplicableTo, setTypeApplicableTo] = useState<'STUDENT' | 'TEACHER' | 'BOTH'>('BOTH');
  const [typeMaxDays, setTypeMaxDays] = useState(10);
  const [typeRequiresAttachment, setTypeRequiresAttachment] = useState(false);
  const [typeDescription, setTypeDescription] = useState('');
  const [typeIsActive, setTypeIsActive] = useState(true);
  const [savingType, setSavingType] = useState(false);

  const showToast = (type: 'success' | 'error' | 'warning', message: string) => {
    setFeedback({ type, message });
    setTimeout(() => {
      setFeedback(null);
    }, 5000);
  };

  const fetchData = async () => {
    setLoading(true);
    try {
      const [appsRes, typesRes] = await Promise.all([
        api.getLeaveApplications(),
        api.getLeaveTypes()
      ]);

      if (appsRes && appsRes.success && appsRes.data) {
        setApplications(appsRes.data);
      }
      if (typesRes && typesRes.success && typesRes.data) {
        setLeaveTypes(typesRes.data);
      }
    } catch (err: any) {
      showToast('error', err.message || 'Failed to load leave records');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleOpenReview = (app: LeaveApplication, mode: 'APPROVE' | 'REJECT') => {
    setReviewTargetApp(app);
    setReviewMode(mode);
    setAdminRemarks(mode === 'APPROVE' ? 'Approved by Administration' : '');
    setRejectionReason(mode === 'REJECT' ? 'Institutional policy constraints' : '');
    setReviewModalOpen(true);
  };

  const handleConfirmReview = async () => {
    if (!reviewTargetApp) return;

    if (reviewMode === 'REJECT' && !rejectionReason.trim()) {
      showToast('error', 'Rejection reason is required');
      return;
    }

    setProcessing(true);
    try {
      const res = await api.reviewLeaveApplication(reviewTargetApp.id, {
        status: reviewMode === 'APPROVE' ? 'APPROVED' : 'REJECTED',
        adminRemarks: adminRemarks.trim(),
        rejectionReason: reviewMode === 'REJECT' ? rejectionReason.trim() : undefined
      });

      if (res && res.success) {
        showToast(
          'success',
          reviewMode === 'APPROVE'
            ? `Leave approved! Attendance records successfully synchronized to LEAVE.`
            : `Leave application rejected.`
        );
        setReviewModalOpen(false);
        setReviewTargetApp(null);
        await fetchData();
      } else {
        showToast('error', res.error || 'Review submission failed');
      }
    } catch (e: any) {
      showToast('error', e.message || 'Error updating application');
    } finally {
      setProcessing(false);
    }
  };

  const handleMarkUnderReview = async (app: LeaveApplication) => {
    try {
      const res = await api.reviewLeaveApplication(app.id, {
        status: 'UNDER_REVIEW',
        adminRemarks: 'Administrative review initiated'
      });
      if (res && res.success) {
        showToast('success', 'Application marked as Under Review');
        await fetchData();
      } else {
        showToast('error', res.error || 'Failed to update status');
      }
    } catch (e: any) {
      showToast('error', e.message || 'Action failed');
    }
  };

  const handleOpenCancelModal = (app: LeaveApplication) => {
    setCancellingApp(app);
    setCancelReason('');
    setCancelModalOpen(true);
  };

  const handleConfirmCancel = async () => {
    if (!cancellingApp) return;
    setCancelling(true);
    try {
      const res = await api.cancelLeaveApplication(cancellingApp.id, cancelReason.trim());
      if (res && res.success) {
        showToast('success', 'Application cancelled. Attendance records reconciled.');
        setCancelModalOpen(false);
        setCancellingApp(null);
        await fetchData();
      } else {
        showToast('error', res.error || 'Failed to cancel application');
      }
    } catch (e: any) {
      showToast('error', e.message || 'Error cancelling application');
    } finally {
      setCancelling(false);
    }
  };

  // Leave Type Form Handlers
  const handleOpenCreateType = () => {
    setEditingType(null);
    setTypeCode('');
    setTypeName('');
    setTypeApplicableTo('BOTH');
    setTypeMaxDays(10);
    setTypeRequiresAttachment(false);
    setTypeDescription('');
    setTypeIsActive(true);
    setTypeModalOpen(true);
  };

  const handleOpenEditType = (type: LeaveType) => {
    setEditingType(type);
    setTypeCode(type.code);
    setTypeName(type.name);
    setTypeApplicableTo(type.applicableTo);
    setTypeMaxDays(type.maxDaysPerYear || type.maxDays || 10);
    setTypeRequiresAttachment(type.requiresAttachment);
    setTypeDescription(type.description || '');
    setTypeIsActive(type.isActive);
    setTypeModalOpen(true);
  };

  const handleSaveType = async () => {
    if (!typeName.trim() || !typeCode.trim()) {
      showToast('error', 'Name and Code are required');
      return;
    }

    setSavingType(true);
    try {
      if (editingType) {
        const res = await api.updateLeaveType(editingType.id, {
          name: typeName.trim(),
          code: typeCode.trim().toUpperCase(),
          applicableTo: typeApplicableTo,
          maxDays: Number(typeMaxDays),
          maxDaysPerYear: Number(typeMaxDays),
          requiresAttachment: typeRequiresAttachment,
          description: typeDescription.trim(),
          isActive: typeIsActive
        });
        if (res && res.success) {
          showToast('success', 'Leave type updated successfully');
          setTypeModalOpen(false);
          await fetchData();
        } else {
          showToast('error', res.error || 'Failed to update leave type');
        }
      } else {
        const res = await api.createLeaveType({
          name: typeName.trim(),
          code: typeCode.trim().toUpperCase(),
          applicableTo: typeApplicableTo,
          maxDays: Number(typeMaxDays),
          maxDaysPerYear: Number(typeMaxDays),
          requiresAttachment: typeRequiresAttachment,
          description: typeDescription.trim(),
          isActive: typeIsActive
        });
        if (res && res.success) {
          showToast('success', 'New leave type created');
          setTypeModalOpen(false);
          await fetchData();
        } else {
          showToast('error', res.error || 'Failed to create leave type');
        }
      }
    } catch (e: any) {
      showToast('error', e.message || 'Failed to save leave type');
    } finally {
      setSavingType(false);
    }
  };

  const handleDeleteType = async (id: string, name: string) => {
    if (!window.confirm(`Are you sure you want to delete leave type "${name}"?`)) return;
    try {
      const res = await api.deleteLeaveType(id);
      if (res && res.success) {
        showToast('success', 'Leave type deleted');
        await fetchData();
      } else {
        showToast('error', res.error || 'Failed to delete leave type');
      }
    } catch (e: any) {
      showToast('error', e.message || 'Error deleting leave type');
    }
  };

  // Filtered Applications
  const filteredApplications = useMemo(() => {
    return applications.filter((app) => {
      if (applicantTypeFilter !== 'ALL' && app.applicantType !== applicantTypeFilter) return false;
      if (statusFilter !== 'ALL') {
        if (statusFilter === 'SUBMITTED' && (app.status !== 'SUBMITTED' && app.status !== 'PENDING')) return false;
        if (statusFilter !== 'SUBMITTED' && app.status !== statusFilter) return false;
      }
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchName = app.applicantName?.toLowerCase().includes(q);
        const matchType = app.leaveTypeName?.toLowerCase().includes(q);
        const matchReason = app.reason?.toLowerCase().includes(q);
        const matchDate = (app.startDate || app.leaveDate || '').includes(q);
        if (!matchName && !matchType && !matchReason && !matchDate) return false;
      }
      return true;
    });
  }, [applications, applicantTypeFilter, statusFilter, searchQuery]);

  // Status Badge Helper
  const getStatusBadge = (status: LeaveStatus) => {
    switch (status) {
      case 'DRAFT':
        return <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold bg-slate-100 text-slate-700 border border-slate-300">Draft</span>;
      case 'SUBMITTED':
      case 'PENDING':
        return <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold bg-blue-100 text-blue-800 border border-blue-300">Submitted</span>;
      case 'UNDER_REVIEW':
        return <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold bg-amber-100 text-amber-800 border border-amber-300">Under Review</span>;
      case 'APPROVED':
        return <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 border border-emerald-300">Approved</span>;
      case 'REJECTED':
        return <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold bg-rose-100 text-rose-800 border border-rose-300">Rejected</span>;
      case 'CANCELLED':
        return <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold bg-slate-200 text-slate-600 border border-slate-400">Cancelled</span>;
      default:
        return <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold bg-slate-100 text-slate-700">{status}</span>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Feedback Alert */}
      {feedback && (
        <div
          className={`flex items-center gap-3 px-4 py-3 rounded-lg border text-sm transition-all duration-300 ${
            feedback.type === 'success'
              ? 'bg-emerald-50 text-emerald-900 border-emerald-300'
              : feedback.type === 'error'
              ? 'bg-rose-50 text-rose-900 border-rose-300'
              : 'bg-amber-50 text-amber-900 border-amber-300'
          }`}
        >
          {feedback.type === 'success' && <CheckCircle2 className="w-5 h-5 text-emerald-600 flex-shrink-0" />}
          {feedback.type === 'error' && <XCircle className="w-5 h-5 text-rose-600 flex-shrink-0" />}
          {feedback.type === 'warning' && <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0" />}
          <div className="flex-1 font-medium">{feedback.message}</div>
          <button onClick={() => setFeedback(null)} className="text-slate-400 hover:text-slate-600">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Sub-Tabs Selector */}
      <div className="flex items-center justify-between border-b border-slate-200 pb-4">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveSubTab('applications')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition ${
              activeSubTab === 'applications'
                ? 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>Leave Applications & Review</span>
            <span className="ml-1 px-2 py-0.5 text-xs bg-slate-200/80 rounded-full font-bold text-slate-700">
              {applications.length}
            </span>
          </button>

          <button
            onClick={() => setActiveSubTab('leave_types')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition ${
              activeSubTab === 'leave_types'
                ? 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <Settings2 className="w-4 h-4" />
            <span>Leave Types Policy</span>
            <span className="ml-1 px-2 py-0.5 text-xs bg-slate-200/80 rounded-full font-bold text-slate-700">
              {leaveTypes.length}
            </span>
          </button>
        </div>

        <button
          onClick={fetchData}
          disabled={loading}
          className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition border border-slate-200"
          title="Refresh"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
        </button>
      </div>

      {/* ========================================================================= */}
      {/* SUBTAB 1: LEAVE APPLICATIONS DIRECTORY & REVIEW                           */}
      {/* ========================================================================= */}
      {activeSubTab === 'applications' && (
        <div className="space-y-4">
          {/* Filter Bar */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-3 flex-1">
              <div className="relative flex-1 min-w-[200px] max-w-sm">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="Search applicant, type, reason..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-3 py-1.5 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                />
              </div>

              {/* Applicant Type Filter */}
              <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg text-xs font-medium text-slate-600">
                {['ALL', 'TEACHER', 'STUDENT'].map((role) => (
                  <button
                    key={role}
                    onClick={() => setApplicantTypeFilter(role)}
                    className={`px-3 py-1 rounded-md transition-colors ${
                      applicantTypeFilter === role ? 'bg-white text-indigo-700 shadow-sm font-semibold' : 'hover:text-slate-900'
                    }`}
                  >
                    {role === 'ALL' ? 'All Roles' : role === 'TEACHER' ? 'Teachers' : 'Students'}
                  </button>
                ))}
              </div>

              {/* Status Filter */}
              <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg text-xs font-medium text-slate-600 overflow-x-auto">
                {['ALL', 'SUBMITTED', 'UNDER_REVIEW', 'APPROVED', 'REJECTED', 'CANCELLED'].map((st) => (
                  <button
                    key={st}
                    onClick={() => setStatusFilter(st)}
                    className={`px-3 py-1 rounded-md transition-colors whitespace-nowrap ${
                      statusFilter === st ? 'bg-white text-indigo-700 shadow-sm font-semibold' : 'hover:text-slate-900'
                    }`}
                  >
                    {st === 'ALL' ? 'All' : (st || '').replace(/_/g, ' ')}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Table */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
            {loading ? (
              <div className="p-12 text-center">
                <LoadingSpinner message="Loading all institutional leave records..." />
              </div>
            ) : filteredApplications.length === 0 ? (
              <div className="p-12 text-center text-slate-500">
                <FileText className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                <h4 className="text-base font-semibold text-slate-700">No Leave Applications</h4>
                <p className="text-sm text-slate-500 mt-1">No leave requests match the current filters.</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm text-slate-600">
                  <thead className="bg-slate-50 text-slate-700 text-xs font-semibold uppercase tracking-wider border-b border-slate-200">
                    <tr>
                      <th className="px-5 py-3.5">Applicant</th>
                      <th className="px-5 py-3.5">Role</th>
                      <th className="px-5 py-3.5">Leave Type</th>
                      <th className="px-5 py-3.5">Period</th>
                      <th className="px-5 py-3.5 text-center">Working Days</th>
                      <th className="px-5 py-3.5">Reason</th>
                      <th className="px-5 py-3.5 text-center">Status</th>
                      <th className="px-5 py-3.5 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredApplications.map((app) => {
                      const isTeacher = app.applicantType === 'TEACHER';
                      const isPending = app.status === 'SUBMITTED' || app.status === 'PENDING';
                      const isUnderReview = app.status === 'UNDER_REVIEW';
                      const isApproved = app.status === 'APPROVED';

                      return (
                        <tr key={app.id} className="hover:bg-slate-50/70 transition-colors">
                          <td className="px-5 py-4">
                            <div className="font-bold text-slate-900">{app.applicantName}</div>
                            {isTeacher ? (
                              <div className="text-xs text-slate-500 flex items-center gap-1">
                                <Building className="w-3 h-3 text-slate-400" />
                                <span>{app.departmentName || 'Faculty'}</span>
                              </div>
                            ) : (
                              <div className="text-xs text-slate-500">
                                {app.className || 'Class'} • {app.sectionName || '-'}
                              </div>
                            )}
                          </td>
                          <td className="px-5 py-4 whitespace-nowrap">
                            <span
                              className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold ${
                                isTeacher ? 'bg-purple-100 text-purple-800' : 'bg-blue-100 text-blue-800'
                              }`}
                            >
                              {app.applicantType}
                            </span>
                          </td>
                          <td className="px-5 py-4 font-medium text-slate-800 whitespace-nowrap">
                            {app.leaveTypeName || 'Leave'}
                          </td>
                          <td className="px-5 py-4 whitespace-nowrap text-xs font-medium text-slate-800">
                            {app.startDate || app.leaveDate}
                            {app.endDate && app.endDate !== (app.startDate || app.leaveDate) && (
                              <span className="text-slate-500"> to {app.endDate}</span>
                            )}
                          </td>
                          <td className="px-5 py-4 text-center whitespace-nowrap">
                            <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-bold bg-slate-100 text-slate-800">
                              {app.totalDays} {app.totalDays === 1 ? 'day' : 'days'}
                            </span>
                          </td>
                          <td className="px-5 py-4 max-w-xs truncate" title={app.description || app.reason}>
                            <div className="font-medium text-slate-800 truncate">{app.reason}</div>
                            {app.description && <div className="text-xs text-slate-400 truncate">{app.description}</div>}
                          </td>
                          <td className="px-5 py-4 text-center whitespace-nowrap">
                            {getStatusBadge(app.status)}
                          </td>
                          <td className="px-5 py-4 text-right whitespace-nowrap">
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                onClick={() => {
                                  setSelectedApp(app);
                                  setDetailModalOpen(true);
                                }}
                                className="p-1.5 text-slate-500 hover:text-indigo-600 hover:bg-slate-100 rounded-lg transition"
                                title="View Details"
                              >
                                <Eye className="w-4 h-4" />
                              </button>

                              {isPending && (
                                <button
                                  onClick={() => handleMarkUnderReview(app)}
                                  className="px-2 py-1 text-xs bg-amber-50 hover:bg-amber-100 text-amber-700 font-semibold rounded border border-amber-200 transition"
                                  title="Mark Under Review"
                                >
                                  Review
                                </button>
                              )}

                              {(isPending || isUnderReview) && (
                                <>
                                  <button
                                    onClick={() => handleOpenReview(app, 'APPROVE')}
                                    className="px-2.5 py-1 text-xs bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded shadow-sm transition inline-flex items-center gap-1"
                                    title="Approve & Sync Attendance"
                                  >
                                    <Check className="w-3.5 h-3.5" />
                                    Approve
                                  </button>
                                  <button
                                    onClick={() => handleOpenReview(app, 'REJECT')}
                                    className="px-2.5 py-1 text-xs bg-rose-50 hover:bg-rose-100 text-rose-700 font-semibold rounded border border-rose-200 transition inline-flex items-center gap-1"
                                    title="Reject"
                                  >
                                    <X className="w-3.5 h-3.5" />
                                    Reject
                                  </button>
                                </>
                              )}

                              {(isPending || isUnderReview || isApproved) && (
                                <button
                                  onClick={() => handleOpenCancelModal(app)}
                                  className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition"
                                  title="Cancel Application"
                                >
                                  <RotateCcw className="w-4 h-4" />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* SUBTAB 2: LEAVE TYPES POLICY & CONFIGURATION                              */}
      {/* ========================================================================= */}
      {activeSubTab === 'leave_types' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
            <div>
              <h3 className="text-base font-bold text-slate-800">Leave Categories & Institutional Quotas</h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Define standard leaves for Teachers and Students with annual quotas and documentary requirements.
              </p>
            </div>
            <button
              onClick={handleOpenCreateType}
              className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-lg shadow-sm transition"
            >
              <Plus className="w-4 h-4" />
              <span>Add Leave Category</span>
            </button>
          </div>

          <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
            <table className="w-full text-left text-sm text-slate-600">
              <thead className="bg-slate-50 text-slate-700 text-xs font-semibold uppercase tracking-wider border-b border-slate-200">
                <tr>
                  <th className="px-5 py-3.5">Code</th>
                  <th className="px-5 py-3.5">Category Name</th>
                  <th className="px-5 py-3.5">Applicable To</th>
                  <th className="px-5 py-3.5 text-center">Max Days / Year</th>
                  <th className="px-5 py-3.5 text-center">Attachment</th>
                  <th className="px-5 py-3.5 text-center">Status</th>
                  <th className="px-5 py-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {leaveTypes.map((lt) => (
                  <tr key={lt.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="px-5 py-4 font-mono font-bold text-xs text-indigo-700">
                      {lt.code}
                    </td>
                    <td className="px-5 py-4 font-semibold text-slate-900">
                      <div>{lt.name}</div>
                      {lt.description && <div className="text-xs text-slate-400 font-normal mt-0.5">{lt.description}</div>}
                    </td>
                    <td className="px-5 py-4 whitespace-nowrap">
                      <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-slate-100 text-slate-700">
                        {lt.applicableTo}
                      </span>
                    </td>
                    <td className="px-5 py-4 text-center font-bold text-slate-800">
                      {lt.maxDaysPerYear || lt.maxDays || 10} days
                    </td>
                    <td className="px-5 py-4 text-center whitespace-nowrap">
                      {lt.requiresAttachment ? (
                        <span className="inline-flex items-center gap-1 text-xs text-amber-700 font-semibold bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                          <Paperclip className="w-3 h-3" />
                          Required
                        </span>
                      ) : (
                        <span className="text-xs text-slate-400">Optional</span>
                      )}
                    </td>
                    <td className="px-5 py-4 text-center whitespace-nowrap">
                      <span
                        className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold ${
                          lt.isActive ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-600'
                        }`}
                      >
                        {lt.isActive ? 'Active' : 'Disabled'}
                      </span>
                    </td>
                    <td className="px-5 py-4 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => handleOpenEditType(lt)}
                          className="p-1.5 text-slate-500 hover:text-indigo-600 hover:bg-slate-100 rounded-lg transition"
                          title="Edit Policy"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteType(lt.id, lt.name)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition"
                          title="Delete Type"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* REVIEW MODAL (SUPER ADMIN APPROVE / REJECT)                               */}
      {/* ========================================================================= */}
      <Modal
        isOpen={reviewModalOpen}
        onClose={() => setReviewModalOpen(false)}
        title={reviewMode === 'APPROVE' ? 'Approve Leave Application' : 'Reject Leave Application'}
        size="md"
      >
        <div className="space-y-4 text-sm text-slate-700">
          {reviewMode === 'APPROVE' ? (
            <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl space-y-1.5 text-emerald-900">
              <div className="flex items-center gap-2 font-bold text-emerald-800 text-xs uppercase tracking-wider">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>Attendance Integration Active</span>
              </div>
              <p className="text-xs text-emerald-800/90 leading-relaxed">
                Approving this application will automatically update attendance for{' '}
                <strong>{reviewTargetApp?.applicantName}</strong> ({reviewTargetApp?.applicantType}) across all{' '}
                {reviewTargetApp?.totalDays} working days to <strong className="underline">LEAVE</strong> status.
                Any non-working days in the range remain preserved.
              </p>
            </div>
          ) : (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-600 flex-shrink-0 mt-0.5" />
              <div>
                You are rejecting the leave application for <strong>{reviewTargetApp?.applicantName}</strong>.
                Please provide an explanatory reason.
              </div>
            </div>
          )}

          <div className="grid grid-cols-2 gap-3 text-xs bg-slate-50 p-3 rounded-lg border border-slate-200">
            <div>
              <span className="text-slate-400 uppercase font-semibold">Applicant:</span>
              <div className="font-bold text-slate-800 mt-0.5">{reviewTargetApp?.applicantName}</div>
              <div className="text-slate-500 font-medium">{reviewTargetApp?.applicantType}</div>
            </div>
            <div>
              <span className="text-slate-400 uppercase font-semibold">Date Range:</span>
              <div className="font-bold text-slate-800 mt-0.5">
                {reviewTargetApp?.startDate || reviewTargetApp?.leaveDate} to {reviewTargetApp?.endDate || reviewTargetApp?.startDate || reviewTargetApp?.leaveDate}
              </div>
              <div className="text-indigo-700 font-bold">{reviewTargetApp?.totalDays} working days</div>
            </div>
          </div>

          {reviewMode === 'APPROVE' ? (
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                Administrative Remarks (Optional)
              </label>
              <textarea
                rows={2}
                placeholder="e.g. Leave sanctioned per institutional medical leave quota."
                value={adminRemarks}
                onChange={(e) => setAdminRemarks(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>
          ) : (
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                Rejection Reason *
              </label>
              <textarea
                rows={3}
                placeholder="e.g. Exam duty schedule conflict; insufficient leave balance."
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-rose-500 focus:outline-none"
              />
            </div>
          )}

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setReviewModalOpen(false)}
              className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-800 font-medium rounded-lg hover:bg-slate-100 transition"
            >
              Cancel
            </button>
            <button
              type="button"
              disabled={processing}
              onClick={handleConfirmReview}
              className={`px-4 py-2 text-xs font-bold text-white rounded-lg shadow-sm transition inline-flex items-center gap-1.5 ${
                reviewMode === 'APPROVE' ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-rose-600 hover:bg-rose-700'
              }`}
            >
              {reviewMode === 'APPROVE' ? <Check className="w-4 h-4" /> : <X className="w-4 h-4" />}
              {processing ? 'Processing...' : reviewMode === 'APPROVE' ? 'Confirm Approval & Sync' : 'Confirm Rejection'}
            </button>
          </div>
        </div>
      </Modal>

      {/* ========================================================================= */}
      {/* CANCEL APPLICATION MODAL                                                  */}
      {/* ========================================================================= */}
      <Modal
        isOpen={cancelModalOpen}
        onClose={() => setCancelModalOpen(false)}
        title="Administrative Application Cancellation"
        size="sm"
      >
        <div className="space-y-4 text-sm text-slate-700">
          <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 flex items-start gap-2">
            <AlertTriangle className="w-4 h-4 text-rose-600 flex-shrink-0 mt-0.5" />
            <div>
              Cancel leave for <strong>{cancellingApp?.applicantName}</strong>?
              {cancellingApp?.status === 'APPROVED' && (
                <p className="mt-1 text-rose-950 font-semibold">
                  This application is currently Approved. Cancelling will automatically revert all attendance records back to their previous states.
                </p>
              )}
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
              Cancellation Reason (Optional)
            </label>
            <input
              type="text"
              placeholder="e.g. Administrative annulment / applicant resumed duties early"
              value={cancelReason}
              onChange={(e) => setCancelReason(e.target.value)}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-rose-500 focus:outline-none"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setCancelModalOpen(false)}
              className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-800 font-medium rounded-lg hover:bg-slate-100 transition"
            >
              Keep Active
            </button>
            <button
              type="button"
              disabled={cancelling}
              onClick={handleConfirmCancel}
              className="px-4 py-1.5 text-xs bg-rose-600 hover:bg-rose-700 text-white font-semibold rounded-lg shadow-sm transition inline-flex items-center gap-1.5"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              {cancelling ? 'Cancelling...' : 'Confirm Cancellation'}
            </button>
          </div>
        </div>
      </Modal>

      {/* ========================================================================= */}
      {/* LEAVE TYPE CREATE / EDIT MODAL                                            */}
      {/* ========================================================================= */}
      <Modal
        isOpen={typeModalOpen}
        onClose={() => setTypeModalOpen(false)}
        title={editingType ? 'Edit Leave Category Policy' : 'Create Leave Category Policy'}
        size="md"
      >
        <div className="space-y-4 text-sm text-slate-700">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                Category Code *
              </label>
              <input
                type="text"
                placeholder="e.g. SICK, CASUAL, MATERNITY"
                value={typeCode}
                onChange={(e) => setTypeCode(e.target.value)}
                className="w-full px-3 py-2 text-sm font-mono border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none uppercase"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                Applicable Audience *
              </label>
              <select
                value={typeApplicableTo}
                onChange={(e) => setTypeApplicableTo(e.target.value as any)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none"
              >
                <option value="BOTH">Both Teachers & Students</option>
                <option value="TEACHER">Teachers Only</option>
                <option value="STUDENT">Students Only</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
              Category Name *
            </label>
            <input
              type="text"
              placeholder="e.g. Medical / Sick Leave"
              value={typeName}
              onChange={(e) => setTypeName(e.target.value)}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                Max Days Per Year
              </label>
              <input
                type="number"
                min={0}
                max={365}
                value={typeMaxDays}
                onChange={(e) => setTypeMaxDays(parseInt(e.target.value, 10) || 0)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none"
              />
            </div>

            <div className="flex flex-col justify-end pb-1.5">
              <label className="flex items-center gap-2 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={typeRequiresAttachment}
                  onChange={(e) => setTypeRequiresAttachment(e.target.checked)}
                  className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 w-4 h-4"
                />
                <span className="text-xs font-semibold text-slate-700">Requires Document Upload</span>
              </label>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
              Description / Policy Rules
            </label>
            <textarea
              rows={2}
              placeholder="e.g. Intended for acute illness or hospitalized periods. Medical cert required for >2 days."
              value={typeDescription}
              onChange={(e) => setTypeDescription(e.target.value)}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none"
            />
          </div>

          <div className="pt-2">
            <label className="flex items-center gap-2 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={typeIsActive}
                onChange={(e) => setTypeIsActive(e.target.checked)}
                className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 w-4 h-4"
              />
              <span className="text-xs font-semibold text-slate-700">Active (Available for leave applications)</span>
            </label>
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setTypeModalOpen(false)}
              className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-800 font-medium rounded-lg hover:bg-slate-100 transition"
            >
              Cancel
            </button>
            <button
              type="button"
              disabled={savingType}
              onClick={handleSaveType}
              className="px-4 py-2 text-xs bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-lg shadow-sm transition"
            >
              {savingType ? 'Saving...' : editingType ? 'Save Changes' : 'Create Category'}
            </button>
          </div>
        </div>
      </Modal>

      {/* ========================================================================= */}
      {/* APPLICATION DETAILS MODAL                                                 */}
      {/* ========================================================================= */}
      <Modal
        isOpen={detailModalOpen}
        onClose={() => setDetailModalOpen(false)}
        title="Leave Application & Reconciliation Details"
        size="md"
      >
        {selectedApp && (
          <div className="space-y-4 text-sm text-slate-700">
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between">
              <div>
                <div className="text-xs text-slate-400 uppercase font-semibold">Applicant</div>
                <div className="font-bold text-slate-900 mt-0.5">{selectedApp.applicantName}</div>
                <div className="text-xs text-slate-500">
                  {selectedApp.applicantType} • {selectedApp.departmentName || selectedApp.className || 'General'}
                </div>
              </div>
              <div className="text-right">
                <div className="text-xs text-slate-400 uppercase font-semibold">Status</div>
                <div className="mt-1">{getStatusBadge(selectedApp.status)}</div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="p-3 bg-white border border-slate-200 rounded-xl">
                <div className="text-xs text-slate-500 uppercase font-semibold">Date Range</div>
                <div className="font-medium text-slate-900 mt-1">
                  {selectedApp.startDate || selectedApp.leaveDate} to {selectedApp.endDate || selectedApp.startDate || selectedApp.leaveDate}
                </div>
              </div>
              <div className="p-3 bg-white border border-slate-200 rounded-xl">
                <div className="text-xs text-slate-500 uppercase font-semibold">Working Days Deducted</div>
                <div className="font-bold text-indigo-700 mt-1">
                  {selectedApp.totalDays} {selectedApp.totalDays === 1 ? 'day' : 'days'}
                </div>
              </div>
            </div>

            <div>
              <div className="text-xs text-slate-500 uppercase font-semibold mb-1">Reason & Description</div>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-slate-800">
                <p className="font-semibold text-slate-900">{selectedApp.reason}</p>
                {selectedApp.description && <p className="mt-1 text-slate-600 text-xs">{selectedApp.description}</p>}
              </div>
            </div>

            {selectedApp.attachmentUrl && (
              <div>
                <div className="text-xs text-slate-500 uppercase font-semibold mb-1">Attachment</div>
                <a
                  href={selectedApp.attachmentUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 p-2.5 bg-indigo-50 text-indigo-700 border border-indigo-200 rounded-xl hover:bg-indigo-100 transition text-xs font-semibold"
                >
                  <Paperclip className="w-4 h-4" />
                  <span>{selectedApp.attachmentName || 'View Document Attachment'}</span>
                </a>
              </div>
            )}

            {/* Reconciliation Log if previously approved */}
            {((selectedApp?.previousAttendanceStates?.length || 0) > 0) && (
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-1">
                <div className="font-bold text-slate-700 uppercase tracking-wider text-[10px]">
                  Attendance State Reconciliation Snapshot
                </div>
                <div className="text-slate-500">
                  {selectedApp?.previousAttendanceStates?.length || 0} attendance date record(s) linked for rollback integrity.
                </div>
              </div>
            )}

            <div className="flex justify-end pt-3 border-t border-slate-200">
              <button
                type="button"
                onClick={() => setDetailModalOpen(false)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg transition"
              >
                Close
              </button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};
