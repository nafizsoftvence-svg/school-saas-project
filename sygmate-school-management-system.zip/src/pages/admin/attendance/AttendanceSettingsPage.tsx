import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  CheckSquare,
  Clock,
  Calendar,
  Shield,
  Save,
  RotateCcw,
  Plus,
  Trash2,
  Edit2,
  AlertCircle,
  CheckCircle2,
  Users,
  GraduationCap,
  Sparkles,
  Info,
  CalendarDays,
  Sun,
  Moon,
  Sliders,
  Bell,
  Lock,
  Layers,
  Radio
} from 'lucide-react';
import { Card } from '../../../components/ui/Card.js';
import { Badge } from '../../../components/ui/Badge.js';
import { Button } from '../../../components/ui/Button.js';
import { Input } from '../../../components/ui/Input.js';
import { Select } from '../../../components/ui/Select.js';
import { Modal } from '../../../components/ui/Modal.js';
import { LoadingSpinner } from '../../../components/ui/LoadingSpinner.js';
import { AttendanceSettings, AttendanceStatusConfig, DayOfWeekName } from '../../../types/index.js';
import { api } from '../../../services/api.js';
import { useSettings } from '../../../context/SettingsContext.js';
import { AttendanceNotificationSettingsTab } from './components/AttendanceNotificationSettingsTab.js';
import { AttendanceNotificationTemplatesTab } from './components/AttendanceNotificationTemplatesTab.js';
import { AttendanceNotificationLogsTab } from './components/AttendanceNotificationLogsTab.js';

const ALL_DAYS: { key: DayOfWeekName; label: string; short: string }[] = [
  { key: 'MONDAY', label: 'Monday', short: 'Mon' },
  { key: 'TUESDAY', label: 'Tuesday', short: 'Tue' },
  { key: 'WEDNESDAY', label: 'Wednesday', short: 'Wed' },
  { key: 'THURSDAY', label: 'Thursday', short: 'Thu' },
  { key: 'FRIDAY', label: 'Friday', short: 'Fri' },
  { key: 'SATURDAY', label: 'Saturday', short: 'Sat' },
  { key: 'SUNDAY', label: 'Sunday', short: 'Sun' }
];

const COLOR_OPTIONS = [
  { label: 'Emerald Green', value: 'emerald', bg: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' },
  { label: 'Rose Red', value: 'rose', bg: 'bg-rose-500/20 text-rose-400 border-rose-500/30' },
  { label: 'Amber Orange', value: 'amber', bg: 'bg-amber-500/20 text-amber-400 border-amber-500/30' },
  { label: 'Orange', value: 'orange', bg: 'bg-orange-500/20 text-orange-400 border-orange-500/30' },
  { label: 'Purple / Violet', value: 'purple', bg: 'bg-purple-500/20 text-purple-400 border-purple-500/30' },
  { label: 'Sky Blue', value: 'blue', bg: 'bg-blue-500/20 text-blue-400 border-blue-500/30' },
  { label: 'Indigo', value: 'indigo', bg: 'bg-indigo-500/20 text-indigo-400 border-indigo-500/30' },
  { label: 'Slate Gray', value: 'slate', bg: 'bg-slate-500/20 text-slate-400 border-slate-500/30' }
];

interface AttendanceSettingsPageProps {
  activeTab?: 'schedule' | 'student' | 'teacher' | 'statuses' | 'rules' | 'notifications' | 'templates' | 'notification-logs';
  onTabChange?: (tab: 'schedule' | 'student' | 'teacher' | 'statuses' | 'rules' | 'notifications' | 'templates' | 'notification-logs') => void;
  hideTabBar?: boolean;
}

export const AttendanceSettingsPage: React.FC<AttendanceSettingsPageProps> = ({
  activeTab: propActiveTab,
  onTabChange,
  hideTabBar = true
}) => {
  const { activeSession, settings: globalSchoolSettings } = useSettings();
  const [loading, setLoading] = useState<boolean>(true);
  const [saving, setSaving] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [errorCode, setErrorCode] = useState<'UNAUTHORIZED' | 'AUTH_EXPIRED' | 'SERVER_ERROR' | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [internalTab, setInternalTab] = useState<
    'schedule' | 'student' | 'teacher' | 'statuses' | 'rules' | 'notifications' | 'templates' | 'notification-logs'
  >('schedule');
  const activeTab = propActiveTab || internalTab;

  const setActiveTab = (tab: 'schedule' | 'student' | 'teacher' | 'statuses' | 'rules' | 'notifications' | 'templates' | 'notification-logs') => {
    setInternalTab(tab);
    onTabChange?.(tab);
  };

  const [settings, setSettings] = useState<AttendanceSettings | null>(null);
  const [originalSettings, setOriginalSettings] = useState<AttendanceSettings | null>(null);

  // Status Editor Modal State
  const [statusModalOpen, setStatusModalOpen] = useState<boolean>(false);
  const [editingStatus, setEditingStatus] = useState<Partial<AttendanceStatusConfig> | null>(null);

  const fetchSettings = async () => {
    setLoading(true);
    setError(null);
    setErrorCode(null);
    try {
      const res = await api.attendance.getSettings({
        academicSessionId: activeSession?.id
      });

      if (!res.success) {
        if (res.code === 'UNAUTHORIZED' || res.code === 'SESSION_EXPIRED' || res.code === 'HTTP_401') {
          setErrorCode('AUTH_EXPIRED');
          setError('Your session has expired. Please sign in again.');
        } else if (res.code === 'FORBIDDEN_ROLE' || res.code === 'FORBIDDEN_PERMISSION' || res.code === 'HTTP_403') {
          setErrorCode('UNAUTHORIZED');
          setError('You do not have permission to manage teacher attendance rules.');
        } else {
          setErrorCode('SERVER_ERROR');
          setError('Unable to load attendance configuration. Please try again.');
        }
        return;
      }

      if (!res.data) {
        setSettings(null);
        return;
      }

      setSettings(res.data);
      setOriginalSettings(JSON.parse(JSON.stringify(res.data)));
    } catch (err: any) {
      setErrorCode('SERVER_ERROR');
      setError('Unable to load attendance configuration. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSettings();
  }, [activeSession?.id]);

  const handleSave = async () => {
    if (!settings) return;
    setSaving(true);
    setError(null);
    setSuccessMsg(null);

    // Basic client validation
    if ((settings?.workingDays?.length || 0) === 0 && (settings?.weekendDays?.length || 0) === 0) {
      setError('At least one working or weekend day must be configured.');
      setSaving(false);
      return;
    }

    try {
      const payload: AttendanceSettings = {
        ...settings,
        academicSessionId: activeSession?.id || settings.academicSessionId || 'session-2026-2027',
        schoolId: (globalSchoolSettings as any)?.id || settings.schoolId || 'school-main'
      };

      const res = await api.attendance.updateSettings(payload);
      if (!res.success || !res.data) {
        if (res.code === 'UNAUTHORIZED' || res.code === 'SESSION_EXPIRED' || res.code === 'HTTP_401') {
          throw new Error('Your session has expired. Please sign in again.');
        } else if (res.code === 'FORBIDDEN_ROLE' || res.code === 'FORBIDDEN_PERMISSION' || res.code === 'HTTP_403') {
          throw new Error('You do not have permission to manage teacher attendance rules.');
        }
        throw new Error(res.error || 'Failed to save attendance configuration');
      }

      setSettings(res.data);
      setOriginalSettings(JSON.parse(JSON.stringify(res.data)));
      setSuccessMsg('Attendance configuration successfully updated and applied.');
      setTimeout(() => setSuccessMsg(null), 4000);
    } catch (err: any) {
      setError(err?.message || 'Unable to save attendance configuration.');
    } finally {
      setSaving(false);
    }
  };

  const handleInitializeDefaultSettings = () => {
    const defaultData: AttendanceSettings = {
      id: 'att-settings-main',
      academicSessionId: activeSession?.id || 'session-2026-2027',
      schoolId: (globalSchoolSettings as any)?.id || 'school-main',
      studentAttendance: {
        enabled: true,
        mode: 'ONCE_DAILY',
        allowTeacherEdit: true,
        teacherEditGracePeriodHours: 24,
        requireAdminApprovalForCorrection: false,
        autoNotifyParentsOnAbsent: true,
        cutoffTime: '09:30',
        lateThresholdMinutes: 15,
        halfDayThresholdMinutes: 120,
        countLateAs: 'LATE',
        consecutiveLateToAbsentThreshold: 3
      },
      teacherAttendance: {
        enabled: true,
        mode: 'MANUAL_ENTRY',
        checkInStartTime: '07:30',
        cutoffTime: '08:30',
        lateThresholdMinutes: 15,
        halfDayThresholdMinutes: 180,
        requireGeofence: false
      },
      workingDays: ['MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY'],
      weekendDays: ['SATURDAY', 'SUNDAY'],
      holidayRules: {
        autoMarkHolidayInAttendance: true,
        allowAttendanceOverrideOnHoliday: false,
        allowOvertimeOnHoliday: true
      },
      leaveRules: {
        requireAdvanceApplication: true,
        maxCasualLeavesPerYear: 12,
        maxMedicalLeavesPerYear: 14,
        autoApproveWithinDays: 3
      },
      attendanceStatuses: [
        {
          id: 'status-present',
          code: 'PRESENT',
          name: 'Present',
          color: 'emerald',
          weight: 1.0,
          isLate: false,
          isExcused: false,
          isActive: true,
          description: 'Physically present and attended all scheduled sessions.'
        },
        {
          id: 'status-absent',
          code: 'ABSENT',
          name: 'Absent',
          color: 'rose',
          weight: 0.0,
          isLate: false,
          isExcused: false,
          isActive: true,
          description: 'Unexcused absence without prior leave authorization.'
        },
        {
          id: 'status-late',
          code: 'LATE',
          name: 'Late Arrival',
          color: 'amber',
          weight: 0.5,
          isLate: true,
          isExcused: false,
          isActive: true,
          description: 'Arrived past the official institutional cutoff threshold.'
        },
        {
          id: 'status-half-day',
          code: 'HALF_DAY',
          name: 'Half Day',
          color: 'orange',
          weight: 0.5,
          isLate: false,
          isExcused: false,
          isActive: true,
          description: 'Attended only morning or afternoon session.'
        },
        {
          id: 'status-leave',
          code: 'LEAVE',
          name: 'Approved Leave',
          color: 'purple',
          weight: 1.0,
          isLate: false,
          isExcused: true,
          isActive: true,
          description: 'Officially approved student or staff leave request.'
        },
        {
          id: 'status-excused',
          code: 'EXCUSED',
          name: 'Excused Absence',
          color: 'blue',
          weight: 1.0,
          isLate: false,
          isExcused: true,
          isActive: true,
          description: 'Medical, institutional representation, or administrative exemption.'
        }
      ],
      updatedAt: new Date().toISOString(),
      updatedBy: 'usr-admin-1',
      updatedByName: 'System Administrator'
    };
    setSettings(defaultData);
    setErrorCode(null);
    setError(null);
  };

  const handleConfigureTeacherRules = () => {
    if (!settings) {
      handleInitializeDefaultSettings();
      return;
    }
    setSettings({
      ...settings,
      teacherAttendance: {
        enabled: true,
        mode: 'MANUAL_ENTRY',
        checkInStartTime: '07:30',
        cutoffTime: '08:30',
        lateThresholdMinutes: 15,
        halfDayThresholdMinutes: 180,
        requireGeofence: false
      }
    });
  };

  const handleReset = () => {
    if (originalSettings) {
      setSettings(JSON.parse(JSON.stringify(originalSettings)));
      setError(null);
      setSuccessMsg('Reverted unsaved changes to previous state.');
      setTimeout(() => setSuccessMsg(null), 3000);
    }
  };

  // Day toggle logic: Toggle between working day and weekend day
  const toggleDayStatus = (day: DayOfWeekName) => {
    if (!settings) return;
    const isCurrentlyWorking = settings.workingDays.includes(day);

    let newWorkingDays = [...settings.workingDays];
    let newWeekendDays = [...settings.weekendDays];

    if (isCurrentlyWorking) {
      // Switch from working to weekend
      newWorkingDays = newWorkingDays.filter((d) => d !== day);
      if (!newWeekendDays.includes(day)) newWeekendDays.push(day);
    } else {
      // Switch from weekend to working
      newWeekendDays = newWeekendDays.filter((d) => d !== day);
      if (!newWorkingDays.includes(day)) newWorkingDays.push(day);
    }

    setSettings({
      ...settings,
      workingDays: newWorkingDays,
      weekendDays: newWeekendDays
    });
  };

  const handleOpenStatusModal = (statusToEdit?: AttendanceStatusConfig) => {
    if (statusToEdit) {
      setEditingStatus({ ...statusToEdit });
    } else {
      setEditingStatus({
        id: `status-${Date.now()}`,
        code: '',
        name: '',
        color: 'slate',
        weight: 1.0,
        isLate: false,
        isExcused: false,
        isActive: true,
        description: ''
      });
    }
    setStatusModalOpen(true);
  };

  const handleSaveStatus = () => {
    if (!settings || !editingStatus || !editingStatus.code || !editingStatus.name) {
      setError('Status Code and Display Name are required.');
      return;
    }

    const cleanCode = editingStatus.code.toUpperCase().trim().replace(/\s+/g, '_');
    const existingIndex = settings.attendanceStatuses.findIndex(
      (s) => s.id === editingStatus.id || s.code === cleanCode
    );

    let updatedList = [...settings.attendanceStatuses];
    const newStatusItem: AttendanceStatusConfig = {
      id: editingStatus.id || `status-${cleanCode.toLowerCase()}`,
      code: cleanCode,
      name: editingStatus.name.trim(),
      color: editingStatus.color || 'slate',
      weight: typeof editingStatus.weight === 'number' ? editingStatus.weight : 1.0,
      isLate: Boolean(editingStatus.isLate),
      isExcused: Boolean(editingStatus.isExcused),
      isActive: editingStatus.isActive !== undefined ? editingStatus.isActive : true,
      description: (editingStatus.description || '').trim()
    };

    if (existingIndex >= 0) {
      updatedList[existingIndex] = newStatusItem;
    } else {
      updatedList.push(newStatusItem);
    }

    setSettings({
      ...settings,
      attendanceStatuses: updatedList
    });
    setStatusModalOpen(false);
    setEditingStatus(null);
  };

  const handleDeleteStatus = (id: string, code: string) => {
    if (!settings) return;
    // Prevent deletion of mandatory core statuses
    if (['PRESENT', 'ABSENT'].includes(code)) {
      setError(`Core status '${code}' cannot be deleted.`);
      return;
    }
    const updated = settings.attendanceStatuses.filter((s) => s.id !== id);
    setSettings({
      ...settings,
      attendanceStatuses: updated
    });
  };

  if (loading) {
    return (
      <div className="min-h-[500px] flex items-center justify-center p-8">
        <LoadingSpinner size="lg" message="Loading attendance configuration..." />
      </div>
    );
  }

  if (errorCode === 'AUTH_EXPIRED') {
    return (
      <div className="min-h-[400px] flex items-center justify-center p-8">
        <Card className="max-w-md w-full p-8 text-center bg-slate-900/90 border border-white/10 shadow-2xl">
          <div className="w-14 h-14 rounded-2xl bg-rose-500/10 border border-rose-500/20 flex items-center justify-center text-rose-400 mx-auto mb-4">
            <Lock className="w-7 h-7" />
          </div>
          <h2 className="text-xl font-bold text-white mb-2">Session Expired</h2>
          <p className="text-sm text-slate-300 mb-6">Your session has expired. Please sign in again.</p>
          <Button variant="primary" onClick={() => window.location.reload()} className="w-full justify-center">
            Sign In Again
          </Button>
        </Card>
      </div>
    );
  }

  if (errorCode === 'UNAUTHORIZED') {
    return (
      <div className="min-h-[400px] flex items-center justify-center p-8">
        <Card className="max-w-md w-full p-8 text-center bg-slate-900/90 border border-white/10 shadow-2xl">
          <div className="w-14 h-14 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 mx-auto mb-4">
            <Shield className="w-7 h-7" />
          </div>
          <h2 className="text-xl font-bold text-white mb-2">Teacher Attendance Rules</h2>
          <p className="text-sm text-slate-300 mb-6">You do not have permission to manage teacher attendance rules.</p>
        </Card>
      </div>
    );
  }

  if (errorCode === 'SERVER_ERROR') {
    return (
      <div className="min-h-[400px] flex items-center justify-center p-8">
        <Card className="max-w-md w-full p-8 text-center bg-slate-900/90 border border-white/10 shadow-2xl">
          <div className="w-14 h-14 rounded-2xl bg-rose-500/10 border border-rose-500/20 flex items-center justify-center text-rose-400 mx-auto mb-4">
            <AlertCircle className="w-7 h-7" />
          </div>
          <h2 className="text-xl font-bold text-white mb-2">Teacher Attendance Rules</h2>
          <p className="text-sm text-slate-300 mb-6">Unable to load attendance configuration. Please try again.</p>
          <Button variant="outline" onClick={fetchSettings} icon={<RotateCcw className="w-4 h-4" />} className="w-full justify-center">
            Try Again
          </Button>
        </Card>
      </div>
    );
  }

  if (!settings) {
    return (
      <div className="min-h-[400px] flex items-center justify-center p-8">
        <Card className="max-w-md w-full p-8 text-center bg-slate-900/90 border border-white/10 shadow-2xl">
          <div className="w-14 h-14 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400 mx-auto mb-4">
            <Sliders className="w-7 h-7" />
          </div>
          <h2 className="text-xl font-bold text-white mb-2">Teacher Attendance Rules</h2>
          <p className="text-sm text-slate-400 mb-6">No attendance configuration has been configured yet.</p>
          <Button variant="primary" onClick={handleInitializeDefaultSettings} className="w-full justify-center">
            Configure Rules
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-5">
        <div>
          <div className="flex items-center gap-3 mb-1">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400 shadow-lg shadow-indigo-500/10">
              <CheckSquare className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-2xl font-black tracking-tight text-white flex items-center gap-2">
                Attendance Settings & Rules
                <Badge variant="primary" size="sm" className="font-mono text-xs">
                  Part 8A
                </Badge>
              </h1>
              <p className="text-sm text-slate-400">
                Institutional policies for student & faculty attendance, configurable weekends, and status metrics.
              </p>
            </div>
          </div>
        </div>

        {/* Global Actions for Attendance Rules */}
        {['schedule', 'student', 'teacher', 'statuses', 'rules'].includes(activeTab) && (
          <div className="flex items-center gap-3">
            <Button
              variant="outline"
              onClick={handleReset}
              disabled={saving}
              icon={<RotateCcw className="w-4 h-4" />}
            >
              Reset
            </Button>
            <Button
              variant="primary"
              onClick={handleSave}
              loading={saving}
              icon={<Save className="w-4 h-4" />}
            >
              Save Changes
            </Button>
          </div>
        )}
      </div>

      {/* Alerts */}
      <AnimatePresence>
        {error && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-300 flex items-start gap-3"
          >
            <AlertCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
            <div className="flex-1 text-sm font-medium">{error}</div>
            <button
              onClick={() => setError(null)}
              className="text-xs text-rose-400 hover:text-white cursor-pointer"
            >
              Dismiss
            </button>
          </motion.div>
        )}

        {successMsg && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 flex items-center gap-3"
          >
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            <div className="flex-1 text-sm font-medium">{successMsg}</div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Navigation Tabs (Hidden when subtabs are hosted in sidebar) */}
      {!hideTabBar && (
        <div className="flex items-center gap-2 border-b border-white/10 pb-px overflow-x-auto no-scrollbar">
          <button
            onClick={() => setActiveTab('schedule')}
            className={`px-4 py-2.5 text-sm font-semibold rounded-t-xl transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
              activeTab === 'schedule'
                ? 'bg-slate-900 border-t border-x border-white/15 text-indigo-400 shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <CalendarDays className="w-4 h-4" />
            Working & Weekend Days
          </button>

          <button
            onClick={() => setActiveTab('student')}
            className={`px-4 py-2.5 text-sm font-semibold rounded-t-xl transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
              activeTab === 'student'
                ? 'bg-slate-900 border-t border-x border-white/15 text-indigo-400 shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <GraduationCap className="w-4 h-4" />
            Student Attendance Rules
          </button>

          <button
            onClick={() => setActiveTab('teacher')}
            className={`px-4 py-2.5 text-sm font-semibold rounded-t-xl transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
              activeTab === 'teacher'
                ? 'bg-slate-900 border-t border-x border-white/15 text-indigo-400 shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <Users className="w-4 h-4" />
            Teacher Attendance Rules
          </button>

          <button
            onClick={() => setActiveTab('statuses')}
            className={`px-4 py-2.5 text-sm font-semibold rounded-t-xl transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
              activeTab === 'statuses'
                ? 'bg-slate-900 border-t border-x border-white/15 text-indigo-400 shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <Sliders className="w-4 h-4" />
            Attendance Statuses ({settings?.attendanceStatuses?.length || 0})
          </button>

          <button
            onClick={() => setActiveTab('rules')}
            className={`px-4 py-2.5 text-sm font-semibold rounded-t-xl transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
              activeTab === 'rules'
                ? 'bg-slate-900 border-t border-x border-white/15 text-indigo-400 shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <Shield className="w-4 h-4" />
            Holidays & Leave Policies
          </button>

          <button
            onClick={() => setActiveTab('notifications')}
            className={`px-4 py-2.5 text-sm font-semibold rounded-t-xl transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
              activeTab === 'notifications'
                ? 'bg-slate-900 border-t border-x border-white/15 text-indigo-400 shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <Bell className="w-4 h-4" />
            Alert Policies & Channels
          </button>

          <button
            onClick={() => setActiveTab('templates')}
            className={`px-4 py-2.5 text-sm font-semibold rounded-t-xl transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
              activeTab === 'templates'
                ? 'bg-slate-900 border-t border-x border-white/15 text-indigo-400 shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <Layers className="w-4 h-4" />
            Notification Templates
          </button>

          <button
            onClick={() => setActiveTab('notification-logs')}
            className={`px-4 py-2.5 text-sm font-semibold rounded-t-xl transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
              activeTab === 'notification-logs'
                ? 'bg-slate-900 border-t border-x border-white/15 text-indigo-400 shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <Clock className="w-4 h-4" />
            Alert History & Queue
          </button>
        </div>
      )}

      {/* Tab 1: Working & Weekend Days */}
      {activeTab === 'schedule' && (
        <div className="space-y-6">
          <Card className="p-6 bg-slate-900/80 border-white/10">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  <CalendarDays className="w-5 h-5 text-indigo-400" />
                  Institutional Weekly Schedule
                </h2>
                <p className="text-sm text-slate-400">
                  Configure the official operating days for regular class sessions and institutional weekends.
                  Click a day to toggle between Working Day and Weekend.
                </p>
              </div>
              <div className="flex items-center gap-3">
                <Badge variant="success" size="sm">
                  {settings?.workingDays?.length || 0} Working Days
                </Badge>
                <Badge variant="warning" size="sm">
                  {settings?.weekendDays?.length || 0} Weekend Days
                </Badge>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-3 pt-2">
              {ALL_DAYS.map((d) => {
                const isWorking = settings.workingDays.includes(d.key);
                return (
                  <button
                    key={d.key}
                    type="button"
                    onClick={() => toggleDayStatus(d.key)}
                    className={`p-4 rounded-xl border flex flex-col items-center justify-center gap-2 transition-all cursor-pointer ${
                      isWorking
                        ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/20 shadow-lg shadow-emerald-500/5'
                        : 'bg-rose-500/10 border-rose-500/30 text-rose-400 hover:bg-rose-500/20 shadow-lg shadow-rose-500/5'
                    }`}
                  >
                    <span className="text-xs uppercase font-bold tracking-wider">{d.short}</span>
                    <span className="text-base font-black">{d.label}</span>
                    <Badge
                      variant={isWorking ? 'success' : 'danger'}
                      size="sm"
                      className="mt-1 text-[10px]"
                    >
                      {isWorking ? 'Working Day' : 'Weekend'}
                    </Badge>
                  </button>
                );
              })}
            </div>

            <div className="mt-6 p-4 rounded-xl bg-slate-800/40 border border-white/5 flex items-start gap-3">
              <Info className="w-5 h-5 text-indigo-400 shrink-0 mt-0.5" />
              <div className="text-xs text-slate-300 space-y-1">
                <p className="font-semibold text-white">Dynamic Weekend Engine Active</p>
                <p>
                  Sygmate dynamically calculates school days and attendance percentages according to this weekly schedule.
                  Weekend days are automatically excluded from mandatory attendance rosters unless a <strong>Special Working Day Override</strong> is registered in the Academic Calendar.
                </p>
              </div>
            </div>
          </Card>
        </div>
      )}

      {/* Tab 2: Student Attendance Rules */}
      {activeTab === 'student' && (
        <div className="space-y-6">
          <Card className="p-6 bg-slate-900/80 border-white/10">
            <h2 className="text-lg font-bold text-white flex items-center gap-2 mb-4">
              <GraduationCap className="w-5 h-5 text-indigo-400" />
              Student Attendance Engine Rules
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 rounded-xl bg-slate-800/40 border border-white/5">
                  <div>
                    <span className="font-bold text-white block text-sm">Student Attendance Tracking</span>
                    <span className="text-xs text-slate-400">Enable daily student attendance recording</span>
                  </div>
                  <input
                    type="checkbox"
                    checked={settings.studentAttendance.enabled}
                    onChange={(e) =>
                      setSettings({
                        ...settings,
                        studentAttendance: {
                          ...settings.studentAttendance,
                          enabled: e.target.checked
                        }
                      })
                    }
                    className="w-5 h-5 rounded text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                    Attendance Tracking Mode
                  </label>
                  <Select
                    value={settings.studentAttendance.mode}
                    onChange={(val) =>
                      setSettings({
                        ...settings,
                        studentAttendance: {
                          ...settings.studentAttendance,
                          mode: val as any
                        }
                      })
                    }
                    options={[
                      { label: 'Once Daily (Homeroom / Class Teacher)', value: 'ONCE_DAILY' },
                      { label: 'Period-Wise / Timetable Based', value: 'PERIOD_WISE' },
                      { label: 'Subject-Wise Verification', value: 'SUBJECT_WISE' }
                    ]}
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                    Daily Check-In Cutoff Time (24h)
                  </label>
                  <Input
                    type="time"
                    value={settings.studentAttendance.cutoffTime}
                    onChange={(e) =>
                      setSettings({
                        ...settings,
                        studentAttendance: {
                          ...settings.studentAttendance,
                          cutoffTime: e.target.value
                        }
                      })
                    }
                  />
                  <span className="text-[11px] text-slate-400 mt-1 block">
                    Arrivals past this time are automatically flagged as Late Arrival.
                  </span>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                    Late Arrival Threshold (Minutes)
                  </label>
                  <Input
                    type="number"
                    min={0}
                    max={120}
                    value={settings.studentAttendance.lateThresholdMinutes}
                    onChange={(e) =>
                      setSettings({
                        ...settings,
                        studentAttendance: {
                          ...settings.studentAttendance,
                          lateThresholdMinutes: parseInt(e.target.value, 10) || 0
                        }
                      })
                    }
                  />
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 rounded-xl bg-slate-800/40 border border-white/5">
                  <div>
                    <span className="font-bold text-white block text-sm">Allow Teacher Editing</span>
                    <span className="text-xs text-slate-400">Class teachers can modify past attendance</span>
                  </div>
                  <input
                    type="checkbox"
                    checked={settings.studentAttendance.allowTeacherEdit}
                    onChange={(e) =>
                      setSettings({
                        ...settings,
                        studentAttendance: {
                          ...settings.studentAttendance,
                          allowTeacherEdit: e.target.checked
                        }
                      })
                    }
                    className="w-5 h-5 rounded text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                    Teacher Edit Grace Period (Hours)
                  </label>
                  <Input
                    type="number"
                    min={1}
                    max={168}
                    value={settings.studentAttendance.teacherEditGracePeriodHours}
                    onChange={(e) =>
                      setSettings({
                        ...settings,
                        studentAttendance: {
                          ...settings.studentAttendance,
                          teacherEditGracePeriodHours: parseInt(e.target.value, 10) || 24
                        }
                      })
                    }
                  />
                  <span className="text-[11px] text-slate-400 mt-1 block">
                    After this grace period, corrections require Super Admin authorization.
                  </span>
                </div>

                <div className="flex items-center justify-between p-4 rounded-xl bg-slate-800/40 border border-white/5">
                  <div>
                    <span className="font-bold text-white block text-sm">Auto-Notify Guardians on Absent</span>
                    <span className="text-xs text-slate-400">Trigger immediate notice when student marked absent</span>
                  </div>
                  <input
                    type="checkbox"
                    checked={settings.studentAttendance.autoNotifyParentsOnAbsent}
                    onChange={(e) =>
                      setSettings({
                        ...settings,
                        studentAttendance: {
                          ...settings.studentAttendance,
                          autoNotifyParentsOnAbsent: e.target.checked
                        }
                      })
                    }
                    className="w-5 h-5 rounded text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                    Consecutive Late To Absent Conversion
                  </label>
                  <Input
                    type="number"
                    min={1}
                    max={10}
                    value={settings.studentAttendance.consecutiveLateToAbsentThreshold || 3}
                    onChange={(e) =>
                      setSettings({
                        ...settings,
                        studentAttendance: {
                          ...settings.studentAttendance,
                          consecutiveLateToAbsentThreshold: parseInt(e.target.value, 10) || 3
                        }
                      })
                    }
                  />
                  <span className="text-[11px] text-slate-400 mt-1 block">
                    Number of consecutive unexcused late arrivals counting equivalent to 1 absence.
                  </span>
                </div>
              </div>
            </div>
          </Card>
        </div>
      )}

      {/* Tab 3: Teacher Attendance Rules */}
      {activeTab === 'teacher' && (
        !settings.teacherAttendance ? (
          <div className="space-y-6">
            <Card className="p-8 text-center bg-slate-900/80 border-white/10">
              <div className="w-14 h-14 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400 mx-auto mb-4">
                <Users className="w-7 h-7" />
              </div>
              <h2 className="text-xl font-bold text-white mb-2">Teacher Attendance Rules</h2>
              <p className="text-sm text-slate-400 mb-6">No attendance rules have been configured yet.</p>
              <Button variant="primary" onClick={handleConfigureTeacherRules} className="mx-auto">
                Configure Rules
              </Button>
            </Card>
          </div>
        ) : (
          <div className="space-y-6">
            <Card className="p-6 bg-slate-900/80 border-white/10">
              <h2 className="text-lg font-bold text-white flex items-center gap-2 mb-4">
                <Users className="w-5 h-5 text-indigo-400" />
                Faculty & Staff Attendance Rules
              </h2>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 rounded-xl bg-slate-800/40 border border-white/5">
                    <div>
                      <span className="font-bold text-white block text-sm">Faculty Attendance Module</span>
                      <span className="text-xs text-slate-400">Track teacher arrivals and daily presence</span>
                    </div>
                    <input
                      type="checkbox"
                      checked={Boolean(settings.teacherAttendance?.enabled)}
                      onChange={(e) =>
                        setSettings({
                          ...settings,
                          teacherAttendance: {
                            ...settings.teacherAttendance,
                            enabled: e.target.checked
                          }
                        })
                      }
                      className="w-5 h-5 rounded text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                      Check-In Window Start
                    </label>
                    <Input
                      type="time"
                      value={settings.teacherAttendance?.checkInStartTime || '07:30'}
                      onChange={(e) =>
                        setSettings({
                          ...settings,
                          teacherAttendance: {
                            ...settings.teacherAttendance,
                            checkInStartTime: e.target.value
                          }
                        })
                      }
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                      Faculty Arrival Cutoff Time
                    </label>
                    <Input
                      type="time"
                      value={settings.teacherAttendance?.cutoffTime || '08:30'}
                      onChange={(e) =>
                        setSettings({
                          ...settings,
                          teacherAttendance: {
                            ...settings.teacherAttendance,
                            cutoffTime: e.target.value
                          }
                        })
                      }
                    />
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                      Teacher Mode
                    </label>
                    <Select
                      value={settings.teacherAttendance?.mode || 'MANUAL_ENTRY'}
                      onChange={(val) =>
                        setSettings({
                          ...settings,
                          teacherAttendance: {
                            ...settings.teacherAttendance,
                            mode: val as any
                          }
                        })
                      }
                      options={[
                        { label: 'Manual Admin / Principal Log', value: 'MANUAL_ENTRY' },
                        { label: 'Biometric Scanner Sync', value: 'BIOMETRIC' },
                        { label: 'Geofenced Mobile App Check-In', value: 'GEOFENCE' }
                      ]}
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                      Late Grace Window (Minutes)
                    </label>
                    <Input
                      type="number"
                      min={0}
                      max={60}
                      value={settings.teacherAttendance?.lateThresholdMinutes ?? 15}
                      onChange={(e) =>
                        setSettings({
                          ...settings,
                          teacherAttendance: {
                            ...settings.teacherAttendance,
                            lateThresholdMinutes: parseInt(e.target.value, 10) || 0
                          }
                        })
                      }
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                      Half-Day Departure Threshold (Minutes)
                    </label>
                    <Input
                      type="number"
                      min={60}
                      max={300}
                      value={settings.teacherAttendance?.halfDayThresholdMinutes ?? 180}
                      onChange={(e) =>
                        setSettings({
                          ...settings,
                          teacherAttendance: {
                            ...settings.teacherAttendance,
                            halfDayThresholdMinutes: parseInt(e.target.value, 10) || 180
                          }
                        })
                      }
                    />
                  </div>
                </div>
              </div>
            </Card>
          </div>
        )
      )}

      {/* Tab 4: Attendance Statuses */}
      {activeTab === 'statuses' && (
        <div className="space-y-6">
          <Card className="p-6 bg-slate-900/80 border-white/10">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  <Sliders className="w-5 h-5 text-indigo-400" />
                  Configurable Attendance Statuses
                </h2>
                <p className="text-sm text-slate-400">
                  Manage statuses, reporting weights, colors, and excused flags without hardcoded restrictions.
                </p>
              </div>
              <Button
                variant="outline"
                onClick={() => handleOpenStatusModal()}
                icon={<Plus className="w-4 h-4" />}
              >
                Add Status
              </Button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm text-slate-300">
                <thead className="bg-slate-800/60 text-slate-400 uppercase text-xs tracking-wider border-b border-white/10">
                  <tr>
                    <th className="py-3 px-4">Code</th>
                    <th className="py-3 px-4">Display Name</th>
                    <th className="py-3 px-4">Badge Color</th>
                    <th className="py-3 px-4">Weight</th>
                    <th className="py-3 px-4">Flags</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {(settings.attendanceStatuses || []).map((st) => {
                    const colorOpt = (COLOR_OPTIONS || []).find((c) => c?.value === st.color);
                    return (
                      <tr key={st.id} className="hover:bg-white/5 transition-colors">
                        <td className="py-3 px-4 font-mono font-bold text-white">{st.code}</td>
                        <td className="py-3 px-4 font-medium text-white">
                          {st.name}
                          {st.description && (
                            <span className="block text-xs text-slate-400 font-normal truncate max-w-xs">
                              {st.description}
                            </span>
                          )}
                        </td>
                        <td className="py-3 px-4">
                          <span
                            className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold border ${
                              colorOpt?.bg || 'bg-slate-500/20 text-slate-300 border-slate-500/30'
                            }`}
                          >
                            {st.color}
                          </span>
                        </td>
                        <td className="py-3 px-4 font-mono font-bold text-indigo-400">
                          {Number(st.weight).toFixed(2)}x
                        </td>
                        <td className="py-3 px-4 space-x-1">
                          {st.isLate && <Badge variant="warning" size="sm">Late</Badge>}
                          {st.isExcused && <Badge variant="info" size="sm">Excused</Badge>}
                          {!st.isLate && !st.isExcused && <span className="text-xs text-slate-500">Standard</span>}
                        </td>
                        <td className="py-3 px-4">
                          <Badge variant={st.isActive ? 'success' : 'default'} size="sm">
                            {st.isActive ? 'Active' : 'Disabled'}
                          </Badge>
                        </td>
                        <td className="py-3 px-4 text-right space-x-2">
                          <button
                            type="button"
                            onClick={() => handleOpenStatusModal(st)}
                            className="p-1 text-slate-400 hover:text-white transition-colors cursor-pointer"
                            title="Edit Status"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          {!['PRESENT', 'ABSENT'].includes(st.code) && (
                            <button
                              type="button"
                              onClick={() => handleDeleteStatus(st.id, st.code)}
                              className="p-1 text-rose-400 hover:text-rose-300 transition-colors cursor-pointer"
                              title="Delete Status"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </Card>
        </div>
      )}

      {/* Tab 5: Holiday & Leave Rules */}
      {activeTab === 'rules' && (
        <div className="space-y-6">
          <Card className="p-6 bg-slate-900/80 border-white/10">
            <h2 className="text-lg font-bold text-white flex items-center gap-2 mb-4">
              <Shield className="w-5 h-5 text-indigo-400" />
              Holiday & Leave Administration Rules
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Holiday Rules */}
              <div className="space-y-4">
                <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400">
                  Institutional Holiday Policies
                </h3>

                <div className="flex items-center justify-between p-4 rounded-xl bg-slate-800/40 border border-white/5">
                  <div>
                    <span className="font-bold text-white block text-sm">Auto-Mark Holiday In Attendance</span>
                    <span className="text-xs text-slate-400">
                      Roster automatically registers calendar holidays as non-working
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    checked={settings.holidayRules.autoMarkHolidayInAttendance}
                    onChange={(e) =>
                      setSettings({
                        ...settings,
                        holidayRules: {
                          ...settings.holidayRules,
                          autoMarkHolidayInAttendance: e.target.checked
                        }
                      })
                    }
                    className="w-5 h-5 rounded text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                  />
                </div>

                <div className="flex items-center justify-between p-4 rounded-xl bg-slate-800/40 border border-white/5">
                  <div>
                    <span className="font-bold text-white block text-sm">Allow Holiday Attendance Override</span>
                    <span className="text-xs text-slate-400">
                      Permit special event sessions on official holidays
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    checked={settings.holidayRules.allowAttendanceOverrideOnHoliday}
                    onChange={(e) =>
                      setSettings({
                        ...settings,
                        holidayRules: {
                          ...settings.holidayRules,
                          allowAttendanceOverrideOnHoliday: e.target.checked
                        }
                      })
                    }
                    className="w-5 h-5 rounded text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                  />
                </div>
              </div>

              {/* Leave Rules */}
              <div className="space-y-4">
                <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400">
                  Leave & Absence Policies
                </h3>

                <div className="flex items-center justify-between p-4 rounded-xl bg-slate-800/40 border border-white/5">
                  <div>
                    <span className="font-bold text-white block text-sm">Require Advance Application</span>
                    <span className="text-xs text-slate-400">
                      Leaves must be submitted prior to absence date
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    checked={settings.leaveRules.requireAdvanceApplication}
                    onChange={(e) =>
                      setSettings({
                        ...settings,
                        leaveRules: {
                          ...settings.leaveRules,
                          requireAdvanceApplication: e.target.checked
                        }
                      })
                    }
                    className="w-5 h-5 rounded text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                    Max Casual Leaves Per Year
                  </label>
                  <Input
                    type="number"
                    min={0}
                    max={60}
                    value={settings.leaveRules.maxCasualLeavesPerYear}
                    onChange={(e) =>
                      setSettings({
                        ...settings,
                        leaveRules: {
                          ...settings.leaveRules,
                          maxCasualLeavesPerYear: parseInt(e.target.value, 10) || 12
                        }
                      })
                    }
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                    Max Medical Leaves Per Year
                  </label>
                  <Input
                    type="number"
                    min={0}
                    max={60}
                    value={settings.leaveRules.maxMedicalLeavesPerYear}
                    onChange={(e) =>
                      setSettings({
                        ...settings,
                        leaveRules: {
                          ...settings.leaveRules,
                          maxMedicalLeavesPerYear: parseInt(e.target.value, 10) || 14
                        }
                      })
                    }
                  />
                </div>
              </div>
            </div>
          </Card>
        </div>
      )}

      {/* Tab 6: Notifications & Channels */}
      {activeTab === 'notifications' && (
        <AttendanceNotificationSettingsTab
          onSettingsSaved={() => {
            setSuccessMsg('Attendance notification & alert policies updated.');
          }}
          onNavigateToHistory={() => setActiveTab('notification-logs')}
          onNavigateToTemplates={() => setActiveTab('templates')}
        />
      )}

      {/* Tab 7: Notification Templates */}
      {activeTab === 'templates' && (
        <AttendanceNotificationTemplatesTab />
      )}

      {/* Tab 8: Alert History & Queue */}
      {activeTab === 'notification-logs' && (
        <AttendanceNotificationLogsTab />
      )}

      {/* Status Editor Modal */}
      {statusModalOpen && editingStatus && (
        <Modal
          isOpen={statusModalOpen}
          onClose={() => setStatusModalOpen(false)}
          title={editingStatus.code ? `Edit Status: ${editingStatus.code}` : 'Add Attendance Status'}
        >
          <div className="space-y-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Status Code (Uppercase Identifier)
              </label>
              <Input
                type="text"
                placeholder="e.g. EXCUSED, HALF_DAY"
                value={editingStatus.code || ''}
                onChange={(e) =>
                  setEditingStatus({
                    ...editingStatus,
                    code: e.target.value.toUpperCase().replace(/\s+/g, '_')
                  })
                }
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Display Name
              </label>
              <Input
                type="text"
                placeholder="e.g. Excused Absence"
                value={editingStatus.name || ''}
                onChange={(e) =>
                  setEditingStatus({
                    ...editingStatus,
                    name: e.target.value
                  })
                }
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Badge Color
              </label>
              <Select
                value={editingStatus.color || 'slate'}
                onChange={(val) =>
                  setEditingStatus({
                    ...editingStatus,
                    color: val
                  })
                }
                options={COLOR_OPTIONS.map((c) => ({ label: c.label, value: c.value }))}
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Attendance Percentage Weight (0.0 to 1.0)
              </label>
              <Input
                type="number"
                step="0.1"
                min="0"
                max="1"
                value={editingStatus.weight ?? 1.0}
                onChange={(e) =>
                  setEditingStatus({
                    ...editingStatus,
                    weight: parseFloat(e.target.value) || 0
                  })
                }
              />
              <span className="text-[11px] text-slate-400 mt-1 block">
                1.0 counts as 100% attendance credit (Present), 0.5 counts as half (Late/Half Day), 0.0 counts as zero credit (Absent).
              </span>
            </div>

            <div className="grid grid-cols-3 gap-3 pt-2">
              <label className="flex items-center gap-2 p-3 rounded-lg bg-slate-800/40 border border-white/5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={Boolean(editingStatus.isLate)}
                  onChange={(e) =>
                    setEditingStatus({
                      ...editingStatus,
                      isLate: e.target.checked
                    })
                  }
                  className="rounded text-indigo-600 focus:ring-indigo-500"
                />
                <span className="text-xs font-medium text-white">Is Late Flag</span>
              </label>

              <label className="flex items-center gap-2 p-3 rounded-lg bg-slate-800/40 border border-white/5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={Boolean(editingStatus.isExcused)}
                  onChange={(e) =>
                    setEditingStatus({
                      ...editingStatus,
                      isExcused: e.target.checked
                    })
                  }
                  className="rounded text-indigo-600 focus:ring-indigo-500"
                />
                <span className="text-xs font-medium text-white">Is Excused</span>
              </label>

              <label className="flex items-center gap-2 p-3 rounded-lg bg-slate-800/40 border border-white/5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={editingStatus.isActive !== false}
                  onChange={(e) =>
                    setEditingStatus({
                      ...editingStatus,
                      isActive: e.target.checked
                    })
                  }
                  className="rounded text-indigo-600 focus:ring-indigo-500"
                />
                <span className="text-xs font-medium text-white">Is Active</span>
              </label>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Description / Institutional Notes
              </label>
              <textarea
                rows={2}
                value={editingStatus.description || ''}
                onChange={(e) =>
                  setEditingStatus({
                    ...editingStatus,
                    description: e.target.value
                  })
                }
                placeholder="Institutional description of this status..."
                className="w-full px-3 py-2 bg-slate-800 border border-white/10 rounded-xl text-white text-sm focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="flex justify-end gap-3 pt-3 border-t border-white/10">
              <Button variant="outline" onClick={() => setStatusModalOpen(false)}>
                Cancel
              </Button>
              <Button variant="primary" onClick={handleSaveStatus}>
                Apply Status
              </Button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
