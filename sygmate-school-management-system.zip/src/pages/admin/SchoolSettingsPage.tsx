import React, { useState, useEffect } from 'react';
import {
  Building2,
  Globe,
  MapPin,
  Mail,
  Phone,
  Calendar,
  DollarSign,
  Clock,
  ShieldCheck,
  Save,
  RotateCcw,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  Image as ImageIcon,
  User,
  Sliders,
  Check,
  Sun,
  Moon,
  Palette,
  Laptop
} from 'lucide-react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '../../components/ui/Card.js';
import { Input } from '../../components/ui/Input.js';
import { Select } from '../../components/ui/Select.js';
import { Button } from '../../components/ui/Button.js';
import { Tabs } from '../../components/ui/Tabs.js';
import { Alert } from '../../components/ui/Alert.js';
import { Badge } from '../../components/ui/Badge.js';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner.js';
import { useSettings } from '../../context/SettingsContext.js';
import { useAuth } from '../../context/AuthContext.js';
import { useTheme } from '../../context/ThemeContext.js';
import { SchoolSettings } from '../../types/index.js';

const TIMEZONE_OPTIONS = [
  { value: 'America/New_York (EST)', label: 'America/New_York (EST / UTC-5)' },
  { value: 'America/Chicago (CST)', label: 'America/Chicago (CST / UTC-6)' },
  { value: 'America/Denver (MST)', label: 'America/Denver (MST / UTC-7)' },
  { value: 'America/Los_Angeles (PST)', label: 'America/Los_Angeles (PST / UTC-8)' },
  { value: 'Europe/London (GMT/BST)', label: 'Europe/London (GMT/BST / UTC+0)' },
  { value: 'Europe/Paris (CET)', label: 'Europe/Paris (CET / UTC+1)' },
  { value: 'Asia/Dubai (GST)', label: 'Asia/Dubai (GST / UTC+4)' },
  { value: 'Asia/Kolkata (IST)', label: 'Asia/Kolkata (IST / UTC+5:30)' },
  { value: 'Asia/Singapore (SGT)', label: 'Asia/Singapore (SGT / UTC+8)' },
  { value: 'Asia/Tokyo (JST)', label: 'Asia/Tokyo (JST / UTC+9)' },
  { value: 'Australia/Sydney (AEST)', label: 'Australia/Sydney (AEST / UTC+10)' },
  { value: 'UTC', label: 'UTC (Coordinated Universal Time)' }
];

const CURRENCY_OPTIONS = [
  { value: 'USD|$', label: 'USD ($) - US Dollar' },
  { value: 'EUR|€', label: 'EUR (€) - Euro' },
  { value: 'GBP|£', label: 'GBP (£) - British Pound' },
  { value: 'INR|₹', label: 'INR (₹) - Indian Rupee' },
  { value: 'CAD|CA$', label: 'CAD (CA$) - Canadian Dollar' },
  { value: 'AUD|A$', label: 'AUD (A$) - Australian Dollar' },
  { value: 'AED|AED ', label: 'AED (د.إ) - UAE Dirham' },
  { value: 'SGD|S$', label: 'SGD (S$) - Singapore Dollar' }
];

const DATE_FORMAT_OPTIONS = [
  { value: 'DD/MM/YYYY', label: 'DD/MM/YYYY (e.g. 14/08/2026)' },
  { value: 'MM/DD/YYYY', label: 'MM/DD/YYYY (e.g. 08/14/2026)' },
  { value: 'YYYY-MM-DD', label: 'YYYY-MM-DD (e.g. 2026-08-14)' },
  { value: 'D MMM YYYY', label: 'D MMM YYYY (e.g. 14 Aug 2026)' }
];

const TIME_FORMAT_OPTIONS = [
  { value: '12-hour', label: '12-Hour Clock (e.g. 02:30 PM)' },
  { value: '24-hour', label: '24-Hour Clock (e.g. 14:30)' }
];

const WEEK_START_OPTIONS = [
  { value: 'Monday', label: 'Monday (Standard Academic)' },
  { value: 'Sunday', label: 'Sunday' },
  { value: 'Saturday', label: 'Saturday' }
];

const SCHOOL_TYPE_OPTIONS = [
  { value: 'International', label: 'International Academy / K-12' },
  { value: 'High School', label: 'Senior High School' },
  { value: 'Middle School', label: 'Middle / Junior High School' },
  { value: 'Primary', label: 'Primary / Elementary School' },
  { value: 'Vocational', label: 'Vocational & Technical College' },
  { value: 'Private', label: 'Private Preparatory Academy' }
];

interface SchoolSettingsPageProps {
  activeTab?: string;
  onTabChange?: (tab: string) => void;
  hideTabBar?: boolean;
}

export const SchoolSettingsPage: React.FC<SchoolSettingsPageProps> = ({
  activeTab: propActiveTab,
  onTabChange,
  hideTabBar = true
}) => {
  const { settings, isLoading, updateSettings, refreshSettings } = useSettings();
  const { role } = useAuth();
  const { themeMode, setThemeMode, accentColor, setAccentColor, allAccents, activeAccent, isDark } = useTheme();
  const isSuperAdmin = role === 'SUPER_ADMIN';

  const [internalTab, setInternalTab] = useState<string>('profile');
  const activeTab = propActiveTab || internalTab;
  const setActiveTab = (tab: string) => {
    setInternalTab(tab);
    onTabChange?.(tab);
  };
  const [formData, setFormData] = useState<Partial<SchoolSettings>>({});
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [isDirty, setIsDirty] = useState<boolean>(false);

  // Sync state when settings are loaded from server
  useEffect(() => {
    if (settings) {
      setFormData({
        schoolName: settings.schoolName || settings.name || '',
        schoolCode: settings.schoolCode || settings.code || '',
        schoolType: settings.schoolType || 'International',
        tagline: settings.tagline || '',
        affiliationNumber: settings.affiliationNumber || '',
        establishedYear: settings.establishedYear || settings.foundedYear || 1998,
        principalName: settings.principalName || '',
        principalEmail: settings.principalEmail || '',
        contactEmail: settings.contactEmail || settings.email || '',
        supportEmail: settings.supportEmail || '',
        contactPhone: settings.contactPhone || settings.phone || '',
        secondaryPhone: settings.secondaryPhone || '',
        address: settings.address || '',
        city: settings.city || '',
        state: settings.state || '',
        postalCode: settings.postalCode || '',
        country: settings.country || '',
        website: settings.website || '',
        timezone: settings.timezone || 'America/New_York (EST)',
        currency: settings.currency || 'USD',
        currencySymbol: settings.currencySymbol || '$',
        dateFormat: settings.dateFormat || 'DD/MM/YYYY',
        timeFormat: settings.timeFormat || '12-hour',
        weekStartDay: settings.weekStartDay || 'Monday',
        logoUrl: settings.logoUrl || '',
        faviconUrl: settings.faviconUrl || ''
      });
      setIsDirty(false);
      setErrors({});
    }
  }, [settings]);

  const handleChange = (field: keyof SchoolSettings, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    setIsDirty(true);
    if (errors[field]) {
      setErrors((prev) => {
        const next = { ...prev };
        delete next[field];
        return next;
      });
    }
  };

  const handleCurrencyChange = (combinedValue: string) => {
    const [curr, symb] = combinedValue.split('|');
    setFormData((prev) => ({
      ...prev,
      currency: curr,
      currencySymbol: symb
    }));
    setIsDirty(true);
  };

  const validateForm = (): boolean => {
    const errs: Record<string, string> = {};

    if (!formData.schoolName?.trim()) {
      errs.schoolName = 'School Name is required.';
    }
    if (!formData.schoolCode?.trim()) {
      errs.schoolCode = 'School Identification Code is required.';
    }
    if (formData.schoolCode && formData.schoolCode.length > 20) {
      errs.schoolCode = 'School Code must be 20 characters or fewer.';
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (formData.contactEmail && !emailRegex.test(formData.contactEmail)) {
      errs.contactEmail = 'Please provide a valid administrative email.';
    }
    if (formData.supportEmail && !emailRegex.test(formData.supportEmail)) {
      errs.supportEmail = 'Please provide a valid support/admissions email.';
    }
    if (formData.principalEmail && !emailRegex.test(formData.principalEmail)) {
      errs.principalEmail = 'Please provide a valid principal email.';
    }

    if (formData.establishedYear) {
      const yr = Number(formData.establishedYear);
      if (isNaN(yr) || yr < 1800 || yr > new Date().getFullYear() + 1) {
        errs.establishedYear = `Year must be between 1800 and ${new Date().getFullYear() + 1}.`;
      }
    }

    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSave = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!isSuperAdmin) return;
    if (!validateForm()) return;

    setIsSaving(true);
    try {
      const result = await updateSettings(formData);
      if (result.success) {
        setIsDirty(false);
      }
    } finally {
      setIsSaving(false);
    }
  };

  const handleReset = () => {
    if (settings) {
      setFormData({
        schoolName: settings.schoolName || settings.name || '',
        schoolCode: settings.schoolCode || settings.code || '',
        schoolType: settings.schoolType || 'International',
        tagline: settings.tagline || '',
        affiliationNumber: settings.affiliationNumber || '',
        establishedYear: settings.establishedYear || settings.foundedYear || 1998,
        principalName: settings.principalName || '',
        principalEmail: settings.principalEmail || '',
        contactEmail: settings.contactEmail || settings.email || '',
        supportEmail: settings.supportEmail || '',
        contactPhone: settings.contactPhone || settings.phone || '',
        secondaryPhone: settings.secondaryPhone || '',
        address: settings.address || '',
        city: settings.city || '',
        state: settings.state || '',
        postalCode: settings.postalCode || '',
        country: settings.country || '',
        website: settings.website || '',
        timezone: settings.timezone || 'America/New_York (EST)',
        currency: settings.currency || 'USD',
        currencySymbol: settings.currencySymbol || '$',
        dateFormat: settings.dateFormat || 'DD/MM/YYYY',
        timeFormat: settings.timeFormat || '12-hour',
        weekStartDay: settings.weekStartDay || 'Monday',
        logoUrl: settings.logoUrl || '',
        faviconUrl: settings.faviconUrl || ''
      });
      setIsDirty(false);
      setErrors({});
    }
  };

  if (isLoading && !settings) {
    return (
      <div className="py-24 flex flex-col items-center justify-center space-y-4">
        <LoadingSpinner size="lg" message="Loading institutional configuration..." />
        <p className="text-xs text-slate-500">Querying school profile and regional parameters</p>
      </div>
    );
  }

  const selectedCurrencyCombined = `${formData.currency || 'USD'}|${formData.currencySymbol || '$'}`;

  const tabs = [
    { id: 'profile', label: 'School Profile', icon: <Building2 className="w-4 h-4" /> },
    { id: 'contact', label: 'Contact & Location', icon: <MapPin className="w-4 h-4" /> },
    { id: 'regional', label: 'Regional & Localization', icon: <Globe className="w-4 h-4" /> },
    { id: 'branding', label: 'Branding & Themes', icon: <Palette className="w-4 h-4" /> }
  ];

  return (
    <div className="space-y-8 pb-12">
      {/* Header with Title & Action Bar */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
              <Sparkles className="w-3 h-3 text-indigo-400" />
              Institutional Configuration
            </span>
            <span className="text-slate-500 text-xs font-mono">•</span>
            <span className="text-xs text-slate-400 font-mono">
              {formData.schoolCode || 'SIA-2026'}
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
            School Settings &amp; Profile
          </h1>
          <p className="text-slate-400 text-xs sm:text-sm mt-1 max-w-2xl">
            Configure institutional identity, leadership, official contact details, timezones, currency, and portal branding.
          </p>
        </div>

        {isSuperAdmin && (
          <div className="flex items-center gap-3">
            <Button
              id="reset-settings-btn"
              size="sm"
              variant="glass"
              onClick={handleReset}
              disabled={!isDirty || isSaving}
              leftIcon={<RotateCcw className="w-3.5 h-3.5" />}
            >
              Reset
            </Button>
            <Button
              id="save-settings-btn"
              size="sm"
              variant="primary"
              onClick={() => handleSave()}
              isLoading={isSaving}
              disabled={!isDirty && Object.keys(errors).length === 0}
              leftIcon={<Save className="w-3.5 h-3.5" />}
            >
              Save Settings
            </Button>
          </div>
        )}
      </div>

      {!isSuperAdmin && (
        <Alert variant="warning" title="Read-Only Access">
          You are viewing institutional settings in read-only mode. Only users with the Super Admin role have authorization to update school configuration.
        </Alert>
      )}

      {isDirty && (
        <div className="bg-indigo-950/40 border border-indigo-500/30 rounded-2xl p-4 flex items-center justify-between gap-4 backdrop-blur-xl animate-fadeIn">
          <div className="flex items-center gap-3">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-pulse" />
            <p className="text-xs text-indigo-200 font-medium">
              You have unsaved changes in school settings. Click <strong>Save Settings</strong> to apply changes across the platform.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Button size="xs" variant="glass" onClick={handleReset}>
              Discard
            </Button>
            <Button size="xs" variant="primary" onClick={() => handleSave()} isLoading={isSaving}>
              Save Now
            </Button>
          </div>
        </div>
      )}

      {/* Tabs navigation */}
      {!hideTabBar && (
        <Tabs tabs={tabs} activeTab={activeTab} onChange={setActiveTab} />
      )}

      {/* Form Content */}
      <form onSubmit={handleSave}>
        {/* TAB 1: School Profile */}
        {activeTab === 'profile' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Institutional Identity</CardTitle>
                  <CardDescription>
                    Official school name, affiliation numbers, and academic categorization.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <Input
                      id="input-school-name"
                      label="School / Institution Name *"
                      value={formData.schoolName || ''}
                      onChange={(e) => handleChange('schoolName', e.target.value)}
                      error={errors.schoolName}
                      disabled={!isSuperAdmin || isSaving}
                      placeholder="e.g. Sygmate International Academy"
                    />
                    <Input
                      id="input-school-code"
                      label="School Code (Max 20 chars) *"
                      value={formData.schoolCode || ''}
                      onChange={(e) => handleChange('schoolCode', e.target.value.toUpperCase())}
                      error={errors.schoolCode}
                      disabled={!isSuperAdmin || isSaving}
                      placeholder="e.g. SIA-2026"
                      helperText="Used on report cards, ID badges, and system headers"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <Select
                      id="select-school-type"
                      label="School Classification"
                      value={formData.schoolType || 'International'}
                      onChange={(e) => handleChange('schoolType', e.target.value)}
                      options={SCHOOL_TYPE_OPTIONS}
                      disabled={!isSuperAdmin || isSaving}
                    />
                    <Input
                      id="input-established-year"
                      label="Established / Founded Year"
                      type="number"
                      value={formData.establishedYear || ''}
                      onChange={(e) => handleChange('establishedYear', Number(e.target.value))}
                      error={errors.establishedYear}
                      disabled={!isSuperAdmin || isSaving}
                      placeholder="e.g. 1998"
                    />
                  </div>

                  <Input
                    id="input-tagline"
                    label="School Tagline / Motto"
                    value={formData.tagline || ''}
                    onChange={(e) => handleChange('tagline', e.target.value)}
                    disabled={!isSuperAdmin || isSaving}
                    placeholder="e.g. Excellence in Academic and Character Development"
                  />

                  <Input
                    id="input-affiliation"
                    label="Board Affiliation / Accreditation Code"
                    value={formData.affiliationNumber || ''}
                    onChange={(e) => handleChange('affiliationNumber', e.target.value)}
                    disabled={!isSuperAdmin || isSaving}
                    placeholder="e.g. CBSE-AFF-88291 / ISO 9001:2026"
                  />
                </CardContent>
              </Card>

              {/* Leadership & Administration */}
              <Card>
                <CardHeader>
                  <CardTitle>Institutional Leadership</CardTitle>
                  <CardDescription>
                    Executive leadership and primary administrative desk contacts.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <Input
                      id="input-principal-name"
                      label="Principal / Head of Institution"
                      value={formData.principalName || ''}
                      onChange={(e) => handleChange('principalName', e.target.value)}
                      disabled={!isSuperAdmin || isSaving}
                      placeholder="e.g. Dr. Evelyn Montgomery"
                    />
                    <Input
                      id="input-principal-email"
                      label="Principal Official Email"
                      type="email"
                      value={formData.principalEmail || ''}
                      onChange={(e) => handleChange('principalEmail', e.target.value)}
                      error={errors.principalEmail}
                      disabled={!isSuperAdmin || isSaving}
                      placeholder="e.g. principal@sygmate.edu"
                    />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Live Profile Summary Preview */}
            <div className="space-y-6">
              <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-6 shadow-xl shadow-black/20 space-y-4">
                <div className="flex items-center justify-between border-b border-white/10 pb-3">
                  <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                    Live Header Preview
                  </span>
                  <Badge variant="indigo">Simulated</Badge>
                </div>

                <div className="p-4 rounded-2xl bg-slate-900/80 border border-white/10 space-y-3">
                  <div className="flex items-center gap-3">
                    {formData.logoUrl ? (
                      <img
                        src={formData.logoUrl}
                        alt="Logo"
                        className="w-10 h-10 rounded-xl object-contain bg-white/10 p-1 border border-white/15"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center font-bold text-white text-base">
                        {formData.schoolName ? formData.schoolName.charAt(0).toUpperCase() : 'S'}
                      </div>
                    )}
                    <div className="overflow-hidden">
                      <h4 className="text-sm font-bold text-white truncate">
                        {formData.schoolName || 'School Name'}
                      </h4>
                      <p className="text-[10px] text-slate-400 font-mono truncate">
                        Code: {formData.schoolCode || 'CODE'} • {formData.schoolType || 'Academic'}
                      </p>
                    </div>
                  </div>

                  {formData.tagline && (
                    <p className="text-[11px] text-slate-300 italic border-t border-white/5 pt-2">
                      "{formData.tagline}"
                    </p>
                  )}
                </div>

                <div className="space-y-2 text-xs text-slate-400 pt-2">
                  <div className="flex justify-between">
                    <span>Affiliation</span>
                    <span className="font-mono text-white text-right">
                      {formData.affiliationNumber || 'None'}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Principal</span>
                    <span className="text-white text-right">
                      {formData.principalName || 'Dr. Evelyn Montgomery'}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Established</span>
                    <span className="font-mono text-white text-right">
                      {formData.establishedYear || 1998}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: Contact & Location */}
        {activeTab === 'contact' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Official Communications</CardTitle>
                  <CardDescription>
                    Administrative email routing and official telephone numbers.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <Input
                      id="input-contact-email"
                      label="Administrative Contact Email *"
                      type="email"
                      value={formData.contactEmail || ''}
                      onChange={(e) => handleChange('contactEmail', e.target.value)}
                      error={errors.contactEmail}
                      disabled={!isSuperAdmin || isSaving}
                      placeholder="e.g. administration@sygmate.edu"
                    />
                    <Input
                      id="input-support-email"
                      label="Admissions / Support Email"
                      type="email"
                      value={formData.supportEmail || ''}
                      onChange={(e) => handleChange('supportEmail', e.target.value)}
                      error={errors.supportEmail}
                      disabled={!isSuperAdmin || isSaving}
                      placeholder="e.g. admissions@sygmate.edu"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <Input
                      id="input-contact-phone"
                      label="Primary Telephone Number *"
                      value={formData.contactPhone || ''}
                      onChange={(e) => handleChange('contactPhone', e.target.value)}
                      disabled={!isSuperAdmin || isSaving}
                      placeholder="e.g. +1 (800) 555-0199"
                    />
                    <Input
                      id="input-secondary-phone"
                      label="Emergency / Secondary Hotline"
                      value={formData.secondaryPhone || ''}
                      onChange={(e) => handleChange('secondaryPhone', e.target.value)}
                      disabled={!isSuperAdmin || isSaving}
                      placeholder="e.g. +1 (800) 555-0198"
                    />
                  </div>

                  <Input
                    id="input-website"
                    label="Official Institutional Website"
                    value={formData.website || ''}
                    onChange={(e) => handleChange('website', e.target.value)}
                    disabled={!isSuperAdmin || isSaving}
                    placeholder="e.g. https://sygmate-school.edu"
                  />
                </CardContent>
              </Card>

              {/* Physical Address */}
              <Card>
                <CardHeader>
                  <CardTitle>Physical Campus Location</CardTitle>
                  <CardDescription>
                    Official street address, postal parameters, and regional jurisdiction.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Input
                    id="input-address"
                    label="Street Address / Campus Building"
                    value={formData.address || ''}
                    onChange={(e) => handleChange('address', e.target.value)}
                    disabled={!isSuperAdmin || isSaving}
                    placeholder="e.g. 450 Innovation Parkway, Suite 100"
                  />

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    <Input
                      id="input-city"
                      label="City"
                      value={formData.city || ''}
                      onChange={(e) => handleChange('city', e.target.value)}
                      disabled={!isSuperAdmin || isSaving}
                      placeholder="e.g. Cambridge"
                    />
                    <Input
                      id="input-state"
                      label="State / Province"
                      value={formData.state || ''}
                      onChange={(e) => handleChange('state', e.target.value)}
                      disabled={!isSuperAdmin || isSaving}
                      placeholder="e.g. Massachusetts"
                    />
                    <Input
                      id="input-postal-code"
                      label="Postal / Zip Code"
                      value={formData.postalCode || ''}
                      onChange={(e) => handleChange('postalCode', e.target.value)}
                      disabled={!isSuperAdmin || isSaving}
                      placeholder="e.g. 02142"
                    />
                    <Input
                      id="input-country"
                      label="Country"
                      value={formData.country || ''}
                      onChange={(e) => handleChange('country', e.target.value)}
                      disabled={!isSuperAdmin || isSaving}
                      placeholder="e.g. United States"
                    />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Address badge summary card */}
            <div className="space-y-6">
              <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-6 shadow-xl shadow-black/20 space-y-4">
                <div className="flex items-center gap-2 text-indigo-400">
                  <MapPin className="w-5 h-5" />
                  <h4 className="text-sm font-bold text-white">Campus Dispatch Stamp</h4>
                </div>
                <div className="p-4 rounded-2xl bg-slate-900/60 border border-white/10 text-xs space-y-2 text-slate-300">
                  <p className="font-bold text-white">{formData.schoolName || 'Sygmate Academy'}</p>
                  <p>{formData.address || 'Address not specified'}</p>
                  <p>
                    {formData.city || ''} {formData.state ? `, ${formData.state}` : ''}{' '}
                    {formData.postalCode || ''}
                  </p>
                  <p className="font-semibold text-indigo-300">{formData.country || 'Global'}</p>
                </div>
                <div className="text-xs text-slate-400 space-y-1">
                  <p className="flex items-center gap-2">
                    <Phone className="w-3.5 h-3.5 text-slate-500" />
                    <span>{formData.contactPhone || 'No telephone configured'}</span>
                  </p>
                  <p className="flex items-center gap-2">
                    <Mail className="w-3.5 h-3.5 text-slate-500" />
                    <span className="truncate">{formData.contactEmail || 'No email configured'}</span>
                  </p>
                  <p className="flex items-center gap-2">
                    <Globe className="w-3.5 h-3.5 text-slate-500" />
                    <span className="truncate">{formData.website || 'No website configured'}</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: Regional & Localization */}
        {activeTab === 'regional' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Timezone &amp; Calendar Standards</CardTitle>
                  <CardDescription>
                    Configure scheduling, time display, and attendance registers.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Select
                    id="select-timezone"
                    label="School Timezone"
                    value={formData.timezone || 'America/New_York (EST)'}
                    onChange={(e) => handleChange('timezone', e.target.value)}
                    options={TIMEZONE_OPTIONS}
                    disabled={!isSuperAdmin || isSaving}
                    helperText="Controls timetable routines, audit timestamps, and automated bells"
                  />

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <Select
                      id="select-date-format"
                      label="Standard Date Format"
                      value={formData.dateFormat || 'DD/MM/YYYY'}
                      onChange={(e) => handleChange('dateFormat', e.target.value)}
                      options={DATE_FORMAT_OPTIONS}
                      disabled={!isSuperAdmin || isSaving}
                    />
                    <Select
                      id="select-time-format"
                      label="Time Format"
                      value={formData.timeFormat || '12-hour'}
                      onChange={(e) => handleChange('timeFormat', e.target.value)}
                      options={TIME_FORMAT_OPTIONS}
                      disabled={!isSuperAdmin || isSaving}
                    />
                  </div>

                  <Select
                    id="select-week-start-day"
                    label="First Day of the Week"
                    value={formData.weekStartDay || 'Monday'}
                    onChange={(e) => handleChange('weekStartDay', e.target.value)}
                    options={WEEK_START_OPTIONS}
                    disabled={!isSuperAdmin || isSaving}
                    helperText="Determines weekly class routines and attendance calendar column layout"
                  />
                </CardContent>
              </Card>

              {/* Currency & Financial Configuration */}
              <Card>
                <CardHeader>
                  <CardTitle>Currency &amp; Financial Formats</CardTitle>
                  <CardDescription>
                    Standard currency code and symbol used across fee receipts and budgeting.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <Select
                      id="select-currency"
                      label="Base Financial Currency"
                      value={selectedCurrencyCombined}
                      onChange={(e) => handleCurrencyChange(e.target.value)}
                      options={CURRENCY_OPTIONS}
                      disabled={!isSuperAdmin || isSaving}
                    />
                    <Input
                      id="input-currency-symbol"
                      label="Currency Symbol Display"
                      value={formData.currencySymbol || '$'}
                      onChange={(e) => handleChange('currencySymbol', e.target.value)}
                      disabled={!isSuperAdmin || isSaving}
                      placeholder="e.g. $"
                    />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Regional Formatting Sample Preview */}
            <div className="space-y-6">
              <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-6 shadow-xl shadow-black/20 space-y-4">
                <div className="flex items-center gap-2 text-cyan-400">
                  <Clock className="w-5 h-5" />
                  <h4 className="text-sm font-bold text-white">Localization Live Demo</h4>
                </div>

                <div className="p-4 rounded-2xl bg-slate-900/60 border border-white/10 space-y-3 text-xs">
                  <div>
                    <span className="text-[10px] uppercase font-bold text-slate-400 block">
                      Sample Date Output
                    </span>
                    <span className="text-sm font-mono font-bold text-emerald-400">
                      {formData.dateFormat === 'MM/DD/YYYY'
                        ? '08/14/2026'
                        : formData.dateFormat === 'YYYY-MM-DD'
                        ? '2026-08-14'
                        : formData.dateFormat === 'D MMM YYYY'
                        ? '14 Aug 2026'
                        : '14/08/2026'}
                    </span>
                  </div>

                  <div>
                    <span className="text-[10px] uppercase font-bold text-slate-400 block">
                      Sample Time Output
                    </span>
                    <span className="text-sm font-mono font-bold text-cyan-400">
                      {formData.timeFormat === '24-hour' ? '14:30' : '02:30 PM'}
                    </span>
                  </div>

                  <div>
                    <span className="text-[10px] uppercase font-bold text-slate-400 block">
                      Sample Currency Display
                    </span>
                    <span className="text-sm font-mono font-bold text-amber-400">
                      {formData.currencySymbol || '$'}1,250.00 {formData.currency || 'USD'}
                    </span>
                  </div>

                  <div>
                    <span className="text-[10px] uppercase font-bold text-slate-400 block">
                      Active Timezone
                    </span>
                    <span className="text-xs text-slate-300 font-mono">
                      {formData.timezone || 'America/New_York (EST)'}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: Branding & Visuals */}
        {activeTab === 'branding' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Visual Assets &amp; Logo</CardTitle>
                  <CardDescription>
                    Custom school seal and favicon URLs applied throughout navigation bars and reports.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Input
                    id="input-logo-url"
                    label="School Emblem / Logo Image URL"
                    value={formData.logoUrl || ''}
                    onChange={(e) => handleChange('logoUrl', e.target.value)}
                    disabled={!isSuperAdmin || isSaving}
                    placeholder="https://example.com/school-logo.png"
                    helperText="Paste a secure public image URL (PNG, SVG, or JPEG with transparent background)"
                  />

                  {/* Preset Sample Emblems */}
                  <div className="space-y-2 pt-2">
                    <span className="text-xs font-semibold text-slate-400 block">
                      Sample Institutional Crests:
                    </span>
                    <div className="flex items-center gap-3 flex-wrap">
                      {[
                        {
                          name: 'Shield Emblem',
                          url: 'https://images.unsplash.com/photo-1599305445671-ac291c95aaa9?w=128&auto=format&fit=crop&q=80'
                        },
                        {
                          name: 'Academy Crest',
                          url: 'https://images.unsplash.com/photo-1546410531-bb4caa6b424d?w=128&auto=format&fit=crop&q=80'
                        }
                      ].map((preset) => (
                        <button
                          key={preset.name}
                          type="button"
                          onClick={() => handleChange('logoUrl', preset.url)}
                          className="px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs text-slate-300 flex items-center gap-2 transition-colors cursor-pointer"
                        >
                          <img
                            src={preset.url}
                            alt={preset.name}
                            className="w-4 h-4 rounded-sm object-cover"
                            referrerPolicy="no-referrer"
                          />
                          <span>{preset.name}</span>
                        </button>
                      ))}
                      {formData.logoUrl && (
                        <button
                          type="button"
                          onClick={() => handleChange('logoUrl', '')}
                          className="px-3 py-1.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/20 text-xs text-rose-300 cursor-pointer"
                        >
                          Clear Logo
                        </button>
                      )}
                    </div>
                  </div>

                  <Input
                    id="input-favicon-url"
                    label="Favicon / Browser Tab Icon URL"
                    value={formData.faviconUrl || ''}
                    onChange={(e) => handleChange('faviconUrl', e.target.value)}
                    disabled={!isSuperAdmin || isSaving}
                    placeholder="https://example.com/favicon.ico"
                  />
                </CardContent>
              </Card>

              {/* Portal Appearance & Dual Mode Theme Configuration */}
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle>Institutional Visual Theme</CardTitle>
                      <CardDescription>
                        Standardized visual identity and color palette active across all administrative and portal workspaces.
                      </CardDescription>
                    </div>
                    <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full border bg-sky-50 text-sky-800 border-sky-200">
                      Nordic Crisp Light Active
                    </span>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Active Theme Identity */}
                  <div className="p-4 rounded-2xl bg-sky-50/60 border border-sky-200 space-y-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-sky-700 text-white flex items-center justify-center font-bold text-lg shadow-xs border border-sky-800">
                        N
                      </div>
                      <div>
                        <h4 className="text-sm font-bold text-slate-900">Nordic Crisp Light Theme</h4>
                        <p className="text-xs text-slate-600">Clean Scandinavian minimalism with high-contrast slate typography and arctic fjord accents</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-2 text-xs">
                      <div className="p-2.5 rounded-xl bg-white border border-slate-200 space-y-0.5">
                        <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Contrast Standard</span>
                        <span className="font-bold text-emerald-800">100% WCAG AAA Compliant</span>
                      </div>
                      <div className="p-2.5 rounded-xl bg-white border border-slate-200 space-y-0.5">
                        <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Mode Enforcement</span>
                        <span className="font-bold text-slate-800">Light Only (Dark Deactivated)</span>
                      </div>
                      <div className="p-2.5 rounded-xl bg-white border border-slate-200 space-y-0.5">
                        <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Primary Palette</span>
                        <span className="font-bold text-sky-800">Arctic Sky (#0369a1)</span>
                      </div>
                    </div>
                  </div>

                  {/* Institutional Design Guidelines */}
                  <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2 text-xs">
                    <h5 className="font-bold text-slate-800 uppercase tracking-wider text-[11px]">Design Directives:</h5>
                    <ul className="space-y-1 text-slate-600 list-disc list-inside">
                      <li>Crisp white surfaces (#ffffff) with subtle cool slate backgrounds (#f8fafc)</li>
                      <li>High-contrast typography in deep slate (#0f172a, #1e293b, #334155) for maximum legibility</li>
                      <li>Fine hairline borders (#e2e8f0) and subtle shadows without heavy visual clutter</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Live Logo & Theme Preview Box */}
            <div className="space-y-6">
              <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs space-y-4">
                <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                  <Palette className="w-4 h-4 text-sky-700" />
                  <span>Theme Live Showcase</span>
                </h4>

                <div className="rounded-2xl border border-slate-200 p-4 bg-slate-50 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-semibold text-slate-600">
                      Active Palette:
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full border bg-sky-50 text-sky-800 border-sky-200">
                      Nordic Crisp Light
                    </span>
                  </div>

                  <div className="p-3 rounded-xl bg-white border border-slate-200 shadow-xs flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-lg bg-sky-700 text-white flex items-center justify-center font-bold text-xs shadow-xs">
                        S
                      </div>
                      <span className="text-xs font-bold text-slate-900">Sample Portal Card</span>
                    </div>
                    <button
                      type="button"
                      className="px-2.5 py-1 text-[11px] font-bold rounded-lg shadow-xs bg-sky-700 text-white"
                    >
                      Action
                    </button>
                  </div>

                  <div className="text-[11px] text-slate-600 flex items-center justify-between pt-1">
                    <span>Display Mode: <strong className="text-slate-900 font-bold capitalize">Light</strong></span>
                    <span className="text-emerald-700 font-bold">100% WCAG AAA</span>
                  </div>
                </div>

                <div className="h-32 rounded-2xl bg-slate-100 dark:bg-slate-900/80 border border-slate-200 dark:border-white/10 flex flex-col items-center justify-center p-4 text-center">
                  {formData.logoUrl ? (
                    <img
                      src={formData.logoUrl}
                      alt="Logo Preview"
                      className="max-h-20 max-w-full object-contain rounded-lg p-2 bg-white/5 border border-white/10"
                      onError={() => {
                        // fallback visual
                      }}
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <div className="flex flex-col items-center justify-center text-slate-500">
                      <div className="w-12 h-12 rounded-xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-500 font-black text-xl mb-1.5">
                        {formData.schoolName ? formData.schoolName.charAt(0).toUpperCase() : 'S'}
                      </div>
                      <span className="text-[10px]">Institutional Emblem</span>
                    </div>
                  )}
                </div>

                <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                  These visual configurations immediately apply across Super Admin, Teacher, Student, and Parent portals.
                </p>
              </div>
            </div>
          </div>
        )}
      </form>
    </div>
  );
};
