import React, { useEffect, useState } from 'react';
import {
  Calendar,
  Layers,
  Building,
  BookOpen,
  GraduationCap,
  Sparkles,
  RefreshCw,
  AlertCircle
} from 'lucide-react';
import { Tabs } from '../../components/ui/Tabs.js';
import { Button } from '../../components/ui/Button.js';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner.js';
import { Alert } from '../../components/ui/Alert.js';
import { api } from '../../services/api.js';
import {
  AcademicSession,
  SchoolClass,
  Section,
  Subject,
  Department,
  Teacher
} from '../../types/index.js';

import { AcademicSessionsTab } from './academic/AcademicSessionsTab.js';
import { ClassesTab } from './academic/ClassesTab.js';
import { SectionsTab } from './academic/SectionsTab.js';
import { SubjectsTab } from './academic/SubjectsTab.js';
import { DepartmentsTab } from './academic/DepartmentsTab.js';

type TabId = 'classes' | 'sections' | 'sessions' | 'subjects' | 'departments';

interface AcademicStructurePageProps {
  activeTab?: TabId;
  onTabChange?: (tab: TabId) => void;
  hideTabBar?: boolean;
}

export const AcademicStructurePage: React.FC<AcademicStructurePageProps> = ({
  activeTab: propActiveTab,
  onTabChange,
  hideTabBar = true
}) => {
  const [internalTab, setInternalTab] = useState<TabId>('classes');
  const activeTab = propActiveTab || internalTab;
  const setActiveTab = (tab: TabId) => {
    setInternalTab(tab);
    onTabChange?.(tab);
  };
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Entities
  const [sessions, setSessions] = useState<AcademicSession[]>([]);
  const [classes, setClasses] = useState<SchoolClass[]>([]);
  const [sections, setSections] = useState<Section[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [teachers, setTeachers] = useState<Teacher[]>([]);

  // Navigation Deep-link Filter
  const [sectionsClassFilter, setSectionsClassFilter] = useState<string>('ALL');

  const loadData = async (isBackground = false) => {
    try {
      if (!isBackground) setLoading(true);
      else setRefreshing(true);
      setErrorMessage(null);

      const [sessRes, classRes, secRes, subRes, deptRes, teachRes] = await Promise.all([
        api.academic.getSessions(),
        api.academic.getClasses(),
        api.academic.getSections(),
        api.academic.getSubjects(),
        api.academic.getDepartments(),
        api.users.getTeachers()
      ]);

      if (sessRes.success && sessRes.data) setSessions(Array.isArray(sessRes.data) ? sessRes.data : []);
      if (classRes.success && classRes.data) setClasses(Array.isArray(classRes.data) ? classRes.data : []);
      if (secRes.success && secRes.data) setSections(Array.isArray(secRes.data) ? secRes.data : []);
      if (subRes.success && subRes.data) setSubjects(Array.isArray(subRes.data) ? subRes.data : []);
      if (deptRes.success && deptRes.data) setDepartments(Array.isArray(deptRes.data) ? deptRes.data : []);
      if (teachRes.success && teachRes.data) setTeachers(Array.isArray(teachRes.data) ? teachRes.data : []);

      if (!sessRes.success || !classRes.success || !secRes.success || !subRes.success || !deptRes.success) {
        setErrorMessage('Some academic records failed to synchronize. Please refresh.');
      }
    } catch (err: any) {
      console.error('Failed to load academic management data', err);
      setErrorMessage(err.message || 'Failed to communicate with academic data layer.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleNavigateToSections = (classId?: string) => {
    if (classId) setSectionsClassFilter(classId);
    else setSectionsClassFilter('ALL');
    setActiveTab('sections');
  };

  const tabs = [
    {
      id: 'classes',
      label: 'Classes & Grades',
      icon: <Layers className="w-4 h-4" />,
      badge: classes.length
    },
    {
      id: 'sections',
      label: 'Classroom Sections',
      icon: <Building className="w-4 h-4" />,
      badge: sections.length
    },
    {
      id: 'sessions',
      label: 'Academic Sessions',
      icon: <Calendar className="w-4 h-4" />,
      badge: sessions.length
    },
    {
      id: 'subjects',
      label: 'Curriculum Subjects',
      icon: <BookOpen className="w-4 h-4" />,
      badge: subjects.length
    },
    {
      id: 'departments',
      label: 'Departments',
      icon: <GraduationCap className="w-4 h-4" />,
      badge: departments.length
    }
  ];

  return (
    <div className="space-y-6">
      {/* Top Header Card */}
      <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-6 sm:p-8 shadow-xl shadow-black/20 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 text-indigo-400 text-xs font-bold uppercase tracking-wider mb-1.5">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Academic Structure &amp; Hierarchy Management</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
            Academic Infrastructure Hub
          </h2>
          <p className="text-xs text-slate-300 mt-1 max-w-2xl leading-relaxed">
            Administer calendar sessions, grade tier hierarchies, classroom cohort sections,
            curriculum subject catalogues, and academic faculty departments.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <Button
            size="sm"
            variant="outline"
            onClick={() => loadData(true)}
            isLoading={refreshing}
            leftIcon={<RefreshCw className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin' : ''}`} />}
          >
            Refresh Records
          </Button>
        </div>
      </div>

      {/* Tabs Navigation */}
      {!hideTabBar && (
        <div className="overflow-x-auto pb-1">
          <Tabs tabs={tabs} activeTab={activeTab} onChange={(id) => setActiveTab(id as TabId)} />
        </div>
      )}

      {/* Error Alert */}
      {errorMessage && (
        <Alert variant="error" title="Synchronization Notice" onClose={() => setErrorMessage(null)}>
          {errorMessage}
        </Alert>
      )}

      {/* Content Rendering */}
      {loading ? (
        <div className="py-24 flex justify-center items-center">
          <LoadingSpinner size="lg" message="Loading academic hierarchy directory..." />
        </div>
      ) : activeTab === 'classes' ? (
        <ClassesTab
          classes={classes}
          sections={sections}
          onRefresh={() => loadData(true)}
          onNavigateToSections={handleNavigateToSections}
        />
      ) : activeTab === 'sections' ? (
        <SectionsTab
          sections={sections}
          classes={classes}
          teachers={teachers}
          initialClassFilter={sectionsClassFilter}
          onRefresh={() => loadData(true)}
        />
      ) : activeTab === 'sessions' ? (
        <AcademicSessionsTab
          sessions={sessions}
          onRefresh={() => loadData(true)}
        />
      ) : activeTab === 'subjects' ? (
        <SubjectsTab
          subjects={subjects}
          classes={classes}
          departments={departments}
          onRefresh={() => loadData(true)}
        />
      ) : (
        <DepartmentsTab
          departments={departments}
          teachers={teachers}
          subjects={subjects}
          onRefresh={() => loadData(true)}
        />
      )}
    </div>
  );
};

