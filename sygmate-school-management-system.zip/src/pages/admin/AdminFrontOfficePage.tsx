import React, { useState, useEffect } from 'react';
import {
  Building2,
  Users,
  Shield,
  Phone,
  ShieldAlert,
  FileSpreadsheet,
  Search,
  Plus,
  RefreshCw,
  Clock,
  Printer,
  Calendar,
  Layers,
  Sparkles,
  X,
  ArrowRight
} from 'lucide-react';
import { api } from '../../services/api';
import {
  FrontOfficeDashboardStats,
  VisitorRecord,
  PhoneCallLogRecord,
  ComplaintRecord,
  FrontOfficeEnquiry,
  SchoolClass,
  AcademicSession
} from '../../types';

import { FrontOfficeDashboardTab } from '../../components/front-office/FrontOfficeDashboardTab';
import { VisitorManagementTab } from '../../components/front-office/VisitorManagementTab';
import { PhoneCallLogsTab } from '../../components/front-office/PhoneCallLogsTab';
import { ComplaintManagementTab } from '../../components/front-office/ComplaintManagementTab';
import { FrontOfficeEnquiriesTab } from '../../components/front-office/FrontOfficeEnquiriesTab';
import { FrontOfficeReportsTab } from '../../components/front-office/FrontOfficeReportsTab';

import { VisitorPassModal } from '../../components/front-office/VisitorPassModal';
import { NewVisitorModal } from '../../components/front-office/NewVisitorModal';
import { NewCallLogModal } from '../../components/front-office/NewCallLogModal';
import { NewComplaintModal } from '../../components/front-office/NewComplaintModal';
import { ComplaintDetailModal } from '../../components/front-office/ComplaintDetailModal';
import { AdmissionEnquiryModal } from '../../components/admissions/AdmissionEnquiryModal';

interface AdminFrontOfficePageProps {
  activeTab?: 'overview' | 'visitors' | 'enquiries' | 'calls' | 'complaints' | 'reports';
  onTabChange?: (tab: string) => void;
  hideTabBar?: boolean;
}

export const AdminFrontOfficePage: React.FC<AdminFrontOfficePageProps> = ({
  activeTab: propActiveTab,
  onTabChange,
  hideTabBar = true
}) => {
  const [internalTab, setInternalTab] = useState<'overview' | 'visitors' | 'enquiries' | 'calls' | 'complaints' | 'reports'>('overview');
  const activeTab = (propActiveTab as any) || internalTab;
  const setActiveTab = (tab: 'overview' | 'visitors' | 'enquiries' | 'calls' | 'complaints' | 'reports') => {
    setInternalTab(tab);
    onTabChange?.(tab);
  };

  // Authoritative Dashboard Stats
  const [stats, setStats] = useState<FrontOfficeDashboardStats | null>(null);
  const [loadingStats, setLoadingStats] = useState(false);

  // Common datasets for fast previews
  const [visitors, setVisitors] = useState<VisitorRecord[]>([]);
  const [calls, setCalls] = useState<PhoneCallLogRecord[]>([]);
  const [complaints, setComplaints] = useState<ComplaintRecord[]>([]);
  const [enquiries, setEnquiries] = useState<FrontOfficeEnquiry[]>([]);

  // Metadata
  const [classes, setClasses] = useState<SchoolClass[]>([]);
  const [sessions, setSessions] = useState<AcademicSession[]>([]);
  const [staffList, setStaffList] = useState<Array<{ id: string; name: string; department?: string }>>([]);

  // Modals
  const [selectedVisitorForPass, setSelectedVisitorForPass] = useState<VisitorRecord | null>(null);
  const [isPassModalOpen, setIsPassModalOpen] = useState(false);
  const [isNewVisitorModalOpen, setIsNewVisitorModalOpen] = useState(false);

  const [isNewCallModalOpen, setIsNewCallModalOpen] = useState(false);

  const [isNewComplaintModalOpen, setIsNewComplaintModalOpen] = useState(false);
  const [selectedComplaint, setSelectedComplaint] = useState<ComplaintRecord | null>(null);
  const [isComplaintDetailOpen, setIsComplaintDetailOpen] = useState(false);

  const [isNewEnquiryModalOpen, setIsNewEnquiryModalOpen] = useState(false);

  // Global Search state
  const [globalSearchQuery, setGlobalSearchQuery] = useState('');
  const [globalSearchResults, setGlobalSearchResults] = useState<any | null>(null);
  const [isSearchingGlobal, setIsSearchingGlobal] = useState(false);
  const [showGlobalResults, setShowGlobalResults] = useState(false);

  const loadDashboardData = async () => {
    try {
      setLoadingStats(true);
      const [statsRes, visitorsRes, callsRes, complaintsRes, enquiriesRes] = await Promise.all([
        api.frontOffice.getStats(),
        api.frontOffice.getVisitors({ limit: 50 }),
        api.frontOffice.getCalls({ limit: 50 }),
        api.frontOffice.getComplaints({ limit: 50 }),
        api.frontOffice.getEnquiries({ limit: 50 })
      ]);

      if (statsRes.success && statsRes.data) setStats(statsRes.data);
      if (visitorsRes.success && visitorsRes.data) setVisitors(visitorsRes.data);
      if (callsRes.success && callsRes.data) setCalls(callsRes.data);
      if (complaintsRes.success && complaintsRes.data) setComplaints(complaintsRes.data);
      if (enquiriesRes.success && enquiriesRes.data) setEnquiries(enquiriesRes.data);
    } catch (err) {
      console.error('Failed to load front office stats:', err);
    } finally {
      setLoadingStats(false);
    }
  };

  const loadReferenceData = async () => {
    try {
      const [clsRes, sessRes, staffRes] = await Promise.all([
        api.academic.getClasses(),
        api.academic.getSessions(),
        api.frontOffice.getStaff()
      ]);

      if (clsRes.success && clsRes.data) setClasses(clsRes.data);
      if (sessRes.success && sessRes.data) setSessions(sessRes.data);
      if (staffRes.success && staffRes.data) {
        setStaffList(staffRes.data.map(s => ({
          id: s.id,
          name: s.name,
          department: s.department
        })));
      }
    } catch (err) {
      console.error('Failed to load reference data:', err);
    }
  };

  useEffect(() => {
    loadDashboardData();
    loadReferenceData();
  }, []);

  const handleGlobalSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!globalSearchQuery.trim()) return;

    try {
      setIsSearchingGlobal(true);
      setShowGlobalResults(true);
      const res = await api.frontOffice.search(globalSearchQuery.trim());
      if (res.success && res.data) {
        setGlobalSearchResults(res.data);
      }
    } catch (err) {
      console.error('Global search error:', err);
    } finally {
      setIsSearchingGlobal(false);
    }
  };

  const handleCheckOut = async (id: string) => {
    try {
      const res = await api.frontOffice.checkOutVisitor(id);
      if (res.success) {
        loadDashboardData();
      }
    } catch (err) {
      console.error('Check-out failed', err);
    }
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-2xl bg-indigo-600/10 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-slate-900 dark:text-white">Front Office & Visitor Desk</h1>
              <p className="text-xs text-slate-500">
                Gate security, visitor badges, admissions pipeline, telephone desk, and grievance SLA operations
              </p>
            </div>
          </div>
        </div>

        {/* Global Fast Search Bar */}
        <div className="relative w-full md:w-96">
          <form onSubmit={handleGlobalSearch} className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={globalSearchQuery}
              onChange={e => {
                setGlobalSearchQuery(e.target.value);
                if (!e.target.value) setShowGlobalResults(false);
              }}
              placeholder="Search visitor pass #, phone, student, complaint..."
              className="w-full pl-9 pr-8 py-2 text-xs rounded-2xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 shadow-sm"
            />
            {globalSearchQuery && (
              <button
                type="button"
                onClick={() => {
                  setGlobalSearchQuery('');
                  setShowGlobalResults(false);
                }}
                className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </form>

          {/* Global Search Results Dropdown */}
          {showGlobalResults && globalSearchResults && (
            <div className="absolute top-11 left-0 right-0 z-50 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl p-4 max-h-96 overflow-y-auto space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                  Search Results for "{globalSearchQuery}"
                </span>
                <button
                  onClick={() => setShowGlobalResults(false)}
                  className="text-slate-400 hover:text-slate-600 text-xs"
                >
                  Close
                </button>
              </div>

              {/* Visitors match */}
              {globalSearchResults.visitors?.length > 0 && (
                <div className="space-y-1.5">
                  <span className="text-[10px] font-bold uppercase text-indigo-500 block">
                    Visitors ({globalSearchResults.visitors.length})
                  </span>
                  {globalSearchResults.visitors.map((v: any) => (
                    <div
                      key={v.id}
                      onClick={() => {
                        setSelectedVisitorForPass(v);
                        setIsPassModalOpen(true);
                        setShowGlobalResults(false);
                      }}
                      className="p-2 rounded-xl bg-slate-50 dark:bg-slate-800/60 hover:bg-indigo-50/60 dark:hover:bg-indigo-950/40 text-xs flex items-center justify-between cursor-pointer transition"
                    >
                      <div>
                        <span className="font-bold text-slate-900 dark:text-white block">{v.visitorName}</span>
                        <span className="text-[10px] text-slate-500 font-mono">
                          {v.visitorPassNumber} • Host: {v.personToMeet}
                        </span>
                      </div>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-200 dark:bg-slate-700 font-bold">
                        {v.status}
                      </span>
                    </div>
                  ))}
                </div>
              )}

              {/* Enquiries match */}
              {globalSearchResults.enquiries?.length > 0 && (
                <div className="space-y-1.5">
                  <span className="text-[10px] font-bold uppercase text-emerald-500 block">
                    Admission Enquiries ({globalSearchResults.enquiries.length})
                  </span>
                  {globalSearchResults.enquiries.map((e: any) => (
                    <div
                      key={e.id}
                      onClick={() => {
                        setActiveTab('enquiries');
                        setShowGlobalResults(false);
                      }}
                      className="p-2 rounded-xl bg-slate-50 dark:bg-slate-800/60 hover:bg-emerald-50/60 dark:hover:bg-emerald-950/40 text-xs flex items-center justify-between cursor-pointer transition"
                    >
                      <div>
                        <span className="font-bold text-slate-900 dark:text-white block">{e.studentName}</span>
                        <span className="text-[10px] text-slate-500">
                          {e.enquiryNumber} • Parent: {e.parentName} ({e.phone})
                        </span>
                      </div>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-200 dark:bg-slate-700 font-bold">
                        {e.status}
                      </span>
                    </div>
                  ))}
                </div>
              )}

              {/* Complaints match */}
              {globalSearchResults.complaints?.length > 0 && (
                <div className="space-y-1.5">
                  <span className="text-[10px] font-bold uppercase text-rose-500 block">
                    Complaints ({globalSearchResults.complaints.length})
                  </span>
                  {globalSearchResults.complaints.map((c: any) => (
                    <div
                      key={c.id}
                      onClick={() => {
                        setSelectedComplaint(c);
                        setIsComplaintDetailOpen(true);
                        setShowGlobalResults(false);
                      }}
                      className="p-2 rounded-xl bg-slate-50 dark:bg-slate-800/60 hover:bg-rose-50/60 dark:hover:bg-rose-950/40 text-xs flex items-center justify-between cursor-pointer transition"
                    >
                      <div>
                        <span className="font-bold text-slate-900 dark:text-white block">{c.subject}</span>
                        <span className="text-[10px] text-slate-500">
                          {c.complaintNumber} • {c.complainantName}
                        </span>
                      </div>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-200 dark:bg-slate-700 font-bold">
                        {c.status}
                      </span>
                    </div>
                  ))}
                </div>
              )}

              {/* Calls match */}
              {globalSearchResults.calls?.length > 0 && (
                <div className="space-y-1.5">
                  <span className="text-[10px] font-bold uppercase text-blue-500 block">
                    Phone Logs ({globalSearchResults.calls.length})
                  </span>
                  {globalSearchResults.calls.map((cl: any) => (
                    <div
                      key={cl.id}
                      onClick={() => {
                        setActiveTab('calls');
                        setShowGlobalResults(false);
                      }}
                      className="p-2 rounded-xl bg-slate-50 dark:bg-slate-800/60 hover:bg-blue-50/60 dark:hover:bg-blue-950/40 text-xs flex items-center justify-between cursor-pointer transition"
                    >
                      <div>
                        <span className="font-bold text-slate-900 dark:text-white block">{cl.callerName}</span>
                        <span className="text-[10px] text-slate-500">
                          {cl.callNumber} • {cl.phone} • {cl.purpose}
                        </span>
                      </div>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-200 dark:bg-slate-700 font-bold">
                        {cl.direction}
                      </span>
                    </div>
                  ))}
                </div>
              )}

              {(!globalSearchResults.visitors || globalSearchResults.visitors.length === 0) &&
                (!globalSearchResults.enquiries || globalSearchResults.enquiries.length === 0) &&
                (!globalSearchResults.complaints || globalSearchResults.complaints.length === 0) &&
                (!globalSearchResults.calls || globalSearchResults.calls.length === 0) && (
                  <p className="text-center py-4 text-slate-400 text-xs">
                    No records found matching "{globalSearchQuery}"
                  </p>
                )}
            </div>
          )}
        </div>
      </div>

      {/* Tab Navigation Pill Bar (Hidden when subtabs are hosted in sidebar) */}
      {!hideTabBar && (
        <div className="flex items-center gap-1.5 p-1 bg-slate-100 dark:bg-slate-900/60 border border-slate-200/80 dark:border-slate-800 rounded-2xl overflow-x-auto">
          <button
            onClick={() => setActiveTab('overview')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition shrink-0 ${
              activeTab === 'overview'
                ? 'bg-white dark:bg-slate-800 text-indigo-600 dark:text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Layers className="w-4 h-4" />
            Command Center
          </button>

          <button
            onClick={() => setActiveTab('visitors')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition shrink-0 ${
              activeTab === 'visitors'
                ? 'bg-white dark:bg-slate-800 text-indigo-600 dark:text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Shield className="w-4 h-4" />
            Visitor Register
          </button>

          <button
            onClick={() => setActiveTab('enquiries')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition shrink-0 ${
              activeTab === 'enquiries'
                ? 'bg-white dark:bg-slate-800 text-indigo-600 dark:text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Users className="w-4 h-4" />
            Admission Enquiries
          </button>

          <button
            onClick={() => setActiveTab('calls')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition shrink-0 ${
              activeTab === 'calls'
                ? 'bg-white dark:bg-slate-800 text-indigo-600 dark:text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Phone className="w-4 h-4" />
            Phone Call Logs
          </button>

          <button
            onClick={() => setActiveTab('complaints')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition shrink-0 ${
              activeTab === 'complaints'
                ? 'bg-white dark:bg-slate-800 text-indigo-600 dark:text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <ShieldAlert className="w-4 h-4" />
            Grievance Desk
          </button>

          <button
            onClick={() => setActiveTab('reports')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition shrink-0 ${
              activeTab === 'reports'
                ? 'bg-white dark:bg-slate-800 text-indigo-600 dark:text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <FileSpreadsheet className="w-4 h-4" />
            Official Ledgers
          </button>
        </div>
      )}

      {/* Main Tab Content View */}
      {activeTab === 'overview' && (
        <FrontOfficeDashboardTab
          stats={stats}
          visitors={visitors}
          calls={calls}
          complaints={complaints}
          enquiries={enquiries}
          sessions={sessions}
          staffList={staffList}
          onOpenNewVisitor={() => setIsNewVisitorModalOpen(true)}
          onOpenNewCall={() => setIsNewCallModalOpen(true)}
          onOpenNewComplaint={() => setIsNewComplaintModalOpen(true)}
          onOpenNewEnquiry={() => setIsNewEnquiryModalOpen(true)}
          onViewPass={v => {
            setSelectedVisitorForPass(v);
            setIsPassModalOpen(true);
          }}
          onCheckOutVisitor={handleCheckOut}
          onViewComplaint={c => {
            setSelectedComplaint(c);
            setIsComplaintDetailOpen(true);
          }}
          onSwitchTab={tabId => setActiveTab(tabId as any)}
        />
      )}

      {activeTab === 'visitors' && (
        <VisitorManagementTab
          onRefreshStats={loadDashboardData}
          staffList={staffList}
        />
      )}

      {activeTab === 'enquiries' && (
        <FrontOfficeEnquiriesTab
          onRefreshStats={loadDashboardData}
          classes={classes}
          sessions={sessions}
        />
      )}

      {activeTab === 'calls' && (
        <PhoneCallLogsTab
          onRefreshStats={loadDashboardData}
          staffList={staffList}
          onViewComplaint={c => {
            setSelectedComplaint(c);
            setIsComplaintDetailOpen(true);
          }}
        />
      )}

      {activeTab === 'complaints' && (
        <ComplaintManagementTab
          onRefreshStats={loadDashboardData}
          staffList={staffList}
        />
      )}

      {activeTab === 'reports' && (
        <FrontOfficeReportsTab
          staffList={staffList}
          sessions={sessions}
          classes={classes}
        />
      )}

      {/* Global Modals for Fast Operations */}
      <VisitorPassModal
        visitor={selectedVisitorForPass}
        isOpen={isPassModalOpen}
        onClose={() => {
          setIsPassModalOpen(false);
          setSelectedVisitorForPass(null);
        }}
        onPrint={() => window.print()}
      />

      <NewVisitorModal
        isOpen={isNewVisitorModalOpen}
        onClose={() => setIsNewVisitorModalOpen(false)}
        staffList={staffList}
        onSuccess={() => {
          loadDashboardData();
        }}
      />

      <NewCallLogModal
        isOpen={isNewCallModalOpen}
        onClose={() => setIsNewCallModalOpen(false)}
        staffList={staffList}
        onSuccess={() => {
          loadDashboardData();
        }}
      />

      <NewComplaintModal
        isOpen={isNewComplaintModalOpen}
        onClose={() => setIsNewComplaintModalOpen(false)}
        staffList={staffList}
        onSuccess={() => {
          loadDashboardData();
        }}
      />

      <ComplaintDetailModal
        complaint={selectedComplaint}
        isOpen={isComplaintDetailOpen}
        onClose={() => {
          setIsComplaintDetailOpen(false);
          setSelectedComplaint(null);
        }}
        staffList={staffList}
        onUpdated={() => {
          loadDashboardData();
        }}
      />

      <AdmissionEnquiryModal
        isOpen={isNewEnquiryModalOpen}
        onClose={() => setIsNewEnquiryModalOpen(false)}
        onSuccess={() => {
          loadDashboardData();
        }}
      />
    </div>
  );
};
