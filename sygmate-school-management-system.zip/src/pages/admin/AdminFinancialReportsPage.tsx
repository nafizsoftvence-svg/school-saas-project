import React, { useState, useEffect, useMemo } from 'react';
import {
  BarChart3,
  TrendingUp,
  TrendingDown,
  DollarSign,
  Receipt,
  FileText,
  Calendar,
  Filter,
  Download,
  Printer,
  RefreshCw,
  Search,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Ban,
  Building,
  User,
  CreditCard,
  Layers,
  PieChart,
  ArrowUpRight,
  ArrowDownRight,
  ChevronRight,
  ChevronDown,
  Info,
  ShieldCheck,
  Eye,
  SlidersHorizontal,
  FileSpreadsheet
} from 'lucide-react';
import { triggerSafePrint } from '../../utils/printPdf.js';
import {
  FinancialReportDashboardStats,
  CollectionReportResponse,
  FeeSummaryReportResponse,
  PaymentMethodReportResponse,
  FeePaymentReceipt,
  ClassItem,
  SectionItem,
  FeeTypeItem,
  AcademicSessionItem,
  StudentItem,
  FeePaymentTransaction
} from '../../types/index.js';
import { api } from '../../services/api.js';
import { PaymentReceiptModal } from '../../components/fees/PaymentReceiptModal.js';
import { StudentStatementModal } from '../../components/fees/StudentStatementModal.js';
import { InvoiceViewModal } from '../../components/fees/InvoiceViewModal.js';

type TabKey = 'DASHBOARD' | 'COLLECTIONS' | 'DUE_OVERDUE' | 'FEE_SUMMARY' | 'PAYMENT_METHODS' | 'RECEIPTS' | 'STATEMENTS';

interface AdminFinancialReportsPageProps {
  activeTab?: TabKey;
  onTabChange?: (tab: TabKey) => void;
  hideTabBar?: boolean;
}

export const AdminFinancialReportsPage: React.FC<AdminFinancialReportsPageProps> = ({
  activeTab: propActiveTab,
  onTabChange,
  hideTabBar = true
}) => {
  // Navigation tabs
  const [internalTab, setInternalTab] = useState<TabKey>('DASHBOARD');
  const activeTab = propActiveTab || internalTab;

  const setActiveTab = (tab: TabKey) => {
    setInternalTab(tab);
    onTabChange?.(tab);
  };

  // Common Filter / Context States
  const [academicSessions, setAcademicSessions] = useState<AcademicSessionItem[]>([]);
  const [classes, setClasses] = useState<ClassItem[]>([]);
  const [sections, setSections] = useState<SectionItem[]>([]);
  const [feeTypes, setFeeTypes] = useState<FeeTypeItem[]>([]);
  const [students, setStudents] = useState<StudentItem[]>([]);
  const [selectedSessionId, setSelectedSessionId] = useState<string>('ALL');

  // Tab 1: Dashboard Stats State
  const [dashboardStats, setDashboardStats] = useState<FinancialReportDashboardStats | null>(null);
  const [dashboardLoading, setDashboardLoading] = useState<boolean>(true);

  // Tab 2: Collection Report State
  const [collectionReport, setCollectionReport] = useState<CollectionReportResponse | null>(null);
  const [collectionLoading, setCollectionLoading] = useState<boolean>(false);
  const [collectionFilters, setCollectionFilters] = useState({
    startDate: '',
    endDate: '',
    classId: 'ALL',
    sectionId: 'ALL',
    feeTypeId: 'ALL',
    paymentMethod: 'ALL',
    collectorId: 'ALL',
    status: 'ALL',
    page: 1,
    limit: 20
  });

  // Tab 3: Fee Summary State
  const [feeSummaryReport, setFeeSummaryReport] = useState<FeeSummaryReportResponse | null>(null);
  const [feeSummaryLoading, setFeeSummaryLoading] = useState<boolean>(false);
  const [feeSummaryClassId, setFeeSummaryClassId] = useState<string>('ALL');

  // Tab 4: Payment Methods State
  const [paymentMethodReport, setPaymentMethodReport] = useState<PaymentMethodReportResponse | null>(null);
  const [paymentMethodLoading, setPaymentMethodLoading] = useState<boolean>(false);
  const [paymentMethodDateRange, setPaymentMethodDateRange] = useState({ startDate: '', endDate: '' });

  // Tab 5: Due & Overdue State
  const [dueReportData, setDueReportData] = useState<any>(null);
  const [dueReportLoading, setDueReportLoading] = useState<boolean>(false);
  const [dueClassFilter, setDueClassFilter] = useState<string>('ALL');
  const [dueOverdueOnly, setDueOverdueOnly] = useState<boolean>(false);
  const [dueSearchQuery, setDueSearchQuery] = useState<string>('');

  // Tab 6: Receipts Archive State
  const [receiptsList, setReceiptsList] = useState<FeePaymentReceipt[]>([]);
  const [receiptsLoading, setReceiptsLoading] = useState<boolean>(false);
  const [receiptsSearch, setReceiptsSearch] = useState<string>('');
  const [receiptsStatus, setReceiptsStatus] = useState<string>('ALL');
  const [receiptsMethod, setReceiptsMethod] = useState<string>('ALL');
  const [receiptsPage, setReceiptsPage] = useState<number>(1);
  const [receiptsTotalPages, setReceiptsTotalPages] = useState<number>(1);
  const [receiptsTotalCount, setReceiptsTotalCount] = useState<number>(0);

  // Tab 7: Statement Lookup State
  const [selectedStudentForStatement, setSelectedStudentForStatement] = useState<string>('');
  const [statementStudentSearch, setStatementStudentSearch] = useState<string>('');
  const [statementModalOpen, setStatementModalOpen] = useState<boolean>(false);
  const [statementModalStudentId, setStatementModalStudentId] = useState<string | null>(null);

  // Receipt Modal State
  const [selectedReceipt, setSelectedReceipt] = useState<FeePaymentReceipt | null>(null);
  const [isReceiptModalOpen, setIsReceiptModalOpen] = useState<boolean>(false);
  const [receiptModalLoading, setReceiptModalLoading] = useState<boolean>(false);

  // Invoice Modal State
  const [selectedInvoiceId, setSelectedInvoiceId] = useState<string | null>(null);
  const [isInvoiceModalOpen, setIsInvoiceModalOpen] = useState<boolean>(false);

  // Initial Data Fetching
  useEffect(() => {
    fetchPrerequisites();
    loadDashboardStats();
  }, []);

  // Sync session changes with active tab
  useEffect(() => {
    if (activeTab === 'DASHBOARD') loadDashboardStats();
    if (activeTab === 'COLLECTIONS') loadCollectionReport();
    if (activeTab === 'FEE_SUMMARY') loadFeeSummaryReport();
    if (activeTab === 'PAYMENT_METHODS') loadPaymentMethodReport();
    if (activeTab === 'DUE_OVERDUE') loadDueReport();
    if (activeTab === 'RECEIPTS') loadReceiptsArchive();
  }, [activeTab, selectedSessionId]);

  const fetchPrerequisites = async () => {
    try {
      const [sessionsRes, classesRes, feeTypesRes, studentsRes] = await Promise.all([
        api.academic.getSessions().catch(() => ({ success: true, data: [] })),
        api.academic.getClasses().catch(() => ({ success: true, data: [] })),
        api.fees.getFeeTypes().catch(() => ({ success: true, data: [] })),
        api.users.getStudents().catch(() => ({ success: true, data: [] }))
      ]);

      if (sessionsRes.success && sessionsRes.data) setAcademicSessions(sessionsRes.data);
      if (classesRes.success && classesRes.data) setClasses(classesRes.data);
      if (feeTypesRes.success && feeTypesRes.data) setFeeTypes(feeTypesRes.data);
      if (studentsRes.success && studentsRes.data) {
        const studentItems = Array.isArray(studentsRes.data) ? studentsRes.data : (studentsRes.data as any).students || [];
        setStudents(studentItems);
        if (studentItems && studentItems.length > 0 && !selectedStudentForStatement) {
          setSelectedStudentForStatement(studentItems?.[0]?.id || '');
        }
      }
    } catch (err) {
      console.error('Error loading report prerequisites:', err);
    }
  };

  // Section fetch on class selection
  const handleClassChange = async (classId: string) => {
    setCollectionFilters((prev) => ({ ...prev, classId, sectionId: 'ALL' }));
    if (classId && classId !== 'ALL') {
      try {
        const res = await api.academic.getSections(classId);
        if (res.success && res.data) setSections(res.data);
      } catch {
        setSections([]);
      }
    } else {
      setSections([]);
    }
  };

  // API Call: Dashboard Stats
  const loadDashboardStats = async () => {
    try {
      setDashboardLoading(true);
      const res = await api.fees.getFinancialReportDashboard({
        academicSessionId: selectedSessionId !== 'ALL' ? selectedSessionId : undefined
      });
      if (res.success && res.data) {
        setDashboardStats(res.data);
      }
    } catch (err) {
      console.error('Failed to load financial dashboard:', err);
    } finally {
      setDashboardLoading(false);
    }
  };

  // API Call: Collections Report
  const loadCollectionReport = async () => {
    try {
      setCollectionLoading(true);
      const res = await api.fees.getCollectionReport({
        academicSessionId: selectedSessionId !== 'ALL' ? selectedSessionId : undefined,
        classId: collectionFilters.classId !== 'ALL' ? collectionFilters.classId : undefined,
        sectionId: collectionFilters.sectionId !== 'ALL' ? collectionFilters.sectionId : undefined,
        feeTypeId: collectionFilters.feeTypeId !== 'ALL' ? collectionFilters.feeTypeId : undefined,
        paymentMethod: collectionFilters.paymentMethod !== 'ALL' ? collectionFilters.paymentMethod : undefined,
        status: collectionFilters.status !== 'ALL' ? collectionFilters.status : undefined,
        startDate: collectionFilters.startDate || undefined,
        endDate: collectionFilters.endDate || undefined,
        page: collectionFilters.page,
        limit: collectionFilters.limit
      });
      if (res.success && res.data) {
        setCollectionReport(res.data);
      }
    } catch (err) {
      console.error('Failed to load collections report:', err);
    } finally {
      setCollectionLoading(false);
    }
  };

  // API Call: Fee Summary Report
  const loadFeeSummaryReport = async () => {
    try {
      setFeeSummaryLoading(true);
      const res = await api.fees.getFeeSummaryReport({
        academicSessionId: selectedSessionId !== 'ALL' ? selectedSessionId : undefined,
        classId: feeSummaryClassId !== 'ALL' ? feeSummaryClassId : undefined
      });
      if (res.success && res.data) {
        setFeeSummaryReport(res.data);
      }
    } catch (err) {
      console.error('Failed to load fee summary report:', err);
    } finally {
      setFeeSummaryLoading(false);
    }
  };

  // API Call: Payment Method Report
  const loadPaymentMethodReport = async () => {
    try {
      setPaymentMethodLoading(true);
      const res = await api.fees.getPaymentMethodsReport({
        academicSessionId: selectedSessionId !== 'ALL' ? selectedSessionId : undefined,
        startDate: paymentMethodDateRange.startDate || undefined,
        endDate: paymentMethodDateRange.endDate || undefined
      });
      if (res.success && res.data) {
        setPaymentMethodReport(res.data);
      }
    } catch (err) {
      console.error('Failed to load payment methods report:', err);
    } finally {
      setPaymentMethodLoading(false);
    }
  };

  // API Call: Due & Overdue Report
  const loadDueReport = async () => {
    try {
      setDueReportLoading(true);
      const res = await api.fees.getDueDashboardStats({
        academicSessionId: selectedSessionId !== 'ALL' ? selectedSessionId : undefined,
        classId: dueClassFilter !== 'ALL' ? dueClassFilter : undefined
      });
      if (res.success && res.data) {
        setDueReportData(res.data);
      }
    } catch (err) {
      console.error('Failed to load due report:', err);
    } finally {
      setDueReportLoading(false);
    }
  };

  // API Call: Receipts Archive
  const loadReceiptsArchive = async () => {
    try {
      setReceiptsLoading(true);
      const res = await api.fees.getPaymentReceiptsArchive({
        search: receiptsSearch || undefined,
        paymentMethod: receiptsMethod !== 'ALL' ? receiptsMethod : undefined,
        status: receiptsStatus !== 'ALL' ? receiptsStatus : undefined,
        page: receiptsPage,
        limit: 20
      });
      if (res.success && res.data) {
        const payload = res.data as any;
        const items = Array.isArray(payload) ? payload : payload.data || [];
        setReceiptsList(items);
        setReceiptsTotalCount(payload.total || items.length);
        setReceiptsTotalPages(payload.totalPages || 1);
      }
    } catch (err) {
      console.error('Failed to load receipts archive:', err);
    } finally {
      setReceiptsLoading(false);
    }
  };

  // View Receipt Handler
  const handleViewReceipt = async (receiptOrTxnId: string) => {
    try {
      setReceiptModalLoading(true);
      setIsReceiptModalOpen(true);
      const res = await api.fees.getPaymentReceipt(receiptOrTxnId);
      if (res.success && res.data) {
        setSelectedReceipt(res.data);
      }
    } catch (err) {
      console.error('Error fetching receipt detail:', err);
    } finally {
      setReceiptModalLoading(false);
    }
  };

  // Quick Export CSV Helpers
  const handleExportCollectionsCsv = () => {
    const transactions = collectionReport?.transactions || collectionReport?.data || [];
    if (!transactions.length) return;
    const headers = [
      'Transaction ID',
      'Receipt No',
      'Date & Time',
      'Student Name',
      'Admission No',
      'Class & Section',
      'Fee Head',
      'Payment Method',
      'Reference No',
      'Collector',
      'Amount ($)',
      'Status',
      'Reversal Reason'
    ];
    const rows = transactions.map((t) => [
      `"${t.transactionId}"`,
      `"${t.receiptNumber}"`,
      `"${new Date(t.paymentDate).toLocaleString()}"`,
      `"${t.studentName}"`,
      `"${t.studentAdmissionNumber || t.admissionNumber || ''}"`,
      `"${t.className || ''} ${t.sectionName || ''}"`,
      `"${t.feeTitle}"`,
      `"${t.paymentMethodLabel || t.paymentMethod}"`,
      `"${t.referenceNumber || t.gatewayReference || ''}"`,
      `"${t.collectedByName || t.collectedBy || ''}"`,
      t.amountPaid.toFixed(2),
      `"${t.paymentStatus}"`,
      `"${(t.reversalReason || '').replace(/"/g, '""')}"`
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [`COLLECTION REPORT - SYGMATE INTERNATIONAL ACADEMY`, `Generated: ${new Date().toLocaleString()}`, '']
        .concat([headers.join(',')])
        .concat(rows.map((r) => r.join(',')))
        .join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Collection_Report_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExportFeeSummaryCsv = () => {
    const feeTypes = feeSummaryReport?.feeTypes || feeSummaryReport?.data || [];
    if (!feeTypes.length) return;
    const headers = [
      'Fee Type',
      'Code',
      'Category',
      'Students Assigned',
      'Gross Invoiced ($)',
      'Discounts ($)',
      'Scholarships ($)',
      'Waivers ($)',
      'Late Fines ($)',
      'Net Payable ($)',
      'Collected ($)',
      'Outstanding Due ($)',
      'Recovery Rate (%)'
    ];
    const rows = feeTypes.map((f) => [
      `"${f.name || f.feeTypeName || ''}"`,
      `"${f.code || ''}"`,
      `"${f.category || f.feeCategory || ''}"`,
      f.assignedStudentsCount ?? f.assignedCount ?? 0,
      (f.totalInvoiced ?? f.totalOriginalAmount ?? 0).toFixed(2),
      (f.totalDiscounts ?? f.totalDiscount ?? 0).toFixed(2),
      (f.totalScholarships ?? f.totalScholarship ?? 0).toFixed(2),
      (f.totalWaivers ?? f.totalWaiver ?? 0).toFixed(2),
      (f.totalFines ?? f.totalFine ?? 0).toFixed(2),
      (f.netPayable ?? f.netPayableAmount ?? 0).toFixed(2),
      (f.totalCollected ?? 0).toFixed(2),
      (f.totalDue ?? 0).toFixed(2),
      `${(f.collectionRate ?? 0).toFixed(1)}%`
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [`FEE HEAD SUMMARY REPORT`, `Generated: ${new Date().toLocaleString()}`, '']
        .concat([headers.join(',')])
        .concat(rows.map((r) => r.join(',')))
        .join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Fee_Summary_Report_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Filtered students for Statement explorer
  const filteredStudentsForStatement = useMemo(() => {
    if (!statementStudentSearch.trim()) return students;
    const q = statementStudentSearch.toLowerCase();
    return students.filter(
      (s) =>
        `${s.firstName} ${s.lastName}`.toLowerCase().includes(q) ||
        s.admissionNumber?.toLowerCase().includes(q) ||
        s.className?.toLowerCase().includes(q)
    );
  }, [students, statementStudentSearch]);

  const activeStudentProfile = useMemo(() => {
    return (students || []).find((s) => s?.id === selectedStudentForStatement);
  }, [students, selectedStudentForStatement]);

  return (
    <div className="space-y-6 pb-16">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-slate-900 border border-white/10 rounded-2xl p-6 shadow-xl">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
            <BarChart3 className="w-3.5 h-3.5" />
            PART 7F &bull; FINANCIAL REPORTS & AUDITING
          </div>
          <h1 className="text-2xl font-black text-white tracking-tight">
            Financial Reports, Receipts & Statements
          </h1>
          <p className="text-sm text-slate-400">
            Comprehensive institutional revenue reporting, payment audits, receipt archives, and chronological student ledgers.
          </p>
        </div>

        {/* Academic Session Selector & Global Actions */}
        <div className="flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-2 bg-slate-950 px-3 py-1.5 rounded-xl border border-white/10 text-xs">
            <Calendar className="w-3.5 h-3.5 text-indigo-400" />
            <span className="text-slate-400 font-semibold">Session:</span>
            <select
              value={selectedSessionId}
              onChange={(e) => setSelectedSessionId(e.target.value)}
              className="bg-transparent text-white font-bold focus:outline-hidden cursor-pointer"
            >
              <option value="ALL" className="bg-slate-900 text-white">All Sessions</option>
              {academicSessions.map((session) => (
                <option key={session.id} value={session.id} className="bg-slate-900 text-white">
                  {session.name} {session.isCurrent ? '(Active)' : ''}
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={() => {
              if (activeTab === 'DASHBOARD') loadDashboardStats();
              if (activeTab === 'COLLECTIONS') loadCollectionReport();
              if (activeTab === 'FEE_SUMMARY') loadFeeSummaryReport();
              if (activeTab === 'PAYMENT_METHODS') loadPaymentMethodReport();
              if (activeTab === 'DUE_OVERDUE') loadDueReport();
              if (activeTab === 'RECEIPTS') loadReceiptsArchive();
            }}
            className="p-2 text-slate-400 hover:text-white bg-slate-950 border border-white/10 rounded-xl hover:bg-white/5 transition-colors cursor-pointer"
            title="Refresh current report view"
          >
            <RefreshCw
              className={`w-4 h-4 ${
                dashboardLoading || collectionLoading || feeSummaryLoading || paymentMethodLoading || dueReportLoading || receiptsLoading
                  ? 'animate-spin text-indigo-400'
                  : ''
              }`}
            />
          </button>

          <button
            onClick={() => triggerSafePrint({ fallbackTitle: `Financial_Report_${activeTab}` })}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-white/5 hover:bg-white/10 text-slate-200 border border-white/10 text-xs font-semibold rounded-xl transition-colors cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            Print Report
          </button>
        </div>
      </div>

      {/* Navigation Tabs (Hidden when subtabs are hosted in sidebar) */}
      {!hideTabBar && (
        <div className="flex items-center gap-2 overflow-x-auto pb-1 border-b border-white/10">
          {[
            { key: 'DASHBOARD', label: 'Financial Overview', icon: PieChart },
            { key: 'COLLECTIONS', label: 'Collection Report', icon: DollarSign },
            { key: 'DUE_OVERDUE', label: 'Due & Overdue Report', icon: AlertTriangle },
            { key: 'FEE_SUMMARY', label: 'Fee Head Summary', icon: Layers },
            { key: 'PAYMENT_METHODS', label: 'Payment Channels', icon: CreditCard },
            { key: 'RECEIPTS', label: 'Receipts Archive', icon: Receipt },
            { key: 'STATEMENTS', label: 'Student Statement Generator', icon: FileText }
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.key;
            return (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key as TabKey)}
                className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                  isActive
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                    : 'bg-slate-900/60 text-slate-400 hover:text-white hover:bg-slate-900 border border-white/5'
                }`}
              >
                <Icon className="w-4 h-4" />
                {tab.label}
              </button>
            );
          })}
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 1: FINANCIAL OVERVIEW DASHBOARD */}
      {/* ========================================================================= */}
      {activeTab === 'DASHBOARD' && (
        <div className="space-y-6">
          {dashboardLoading ? (
            <div className="flex flex-col items-center justify-center py-24 text-slate-400 space-y-3">
              <div className="w-8 h-8 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" />
              <p className="text-xs">Compiling real-time institutional financial metrics...</p>
            </div>
          ) : dashboardStats ? (
            <>
              {/* Primary KPI Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {/* 1. Total Generated */}
                <div className="p-5 bg-slate-900 border border-white/10 rounded-2xl space-y-3 relative overflow-hidden group">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                      Total Invoiced Fees
                    </span>
                    <div className="p-2 rounded-xl bg-blue-500/10 border border-blue-500/20 text-blue-400">
                      <FileText className="w-4 h-4" />
                    </div>
                  </div>
                  <div>
                    <div className="text-2xl font-black font-mono text-white">
                      ${(dashboardStats.kpis?.totalFeesGenerated ?? dashboardStats.totalFeesGenerated ?? 0).toLocaleString('en-US', { minimumFractionDigits: 2 })}
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1">
                      Net Payable:{' '}
                      <strong className="text-slate-200 font-mono">
                        ${(dashboardStats.kpis?.totalNetPayable ?? dashboardStats.totalNetPayable ?? 0).toLocaleString('en-US', { minimumFractionDigits: 2 })}
                      </strong>
                    </p>
                  </div>
                </div>

                {/* 2. Total Collected */}
                <div className="p-5 bg-slate-900 border border-emerald-500/30 bg-emerald-500/5 rounded-2xl space-y-3 relative overflow-hidden group">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold uppercase tracking-wider text-emerald-400">
                      Total Collections
                    </span>
                    <div className="p-2 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
                      <DollarSign className="w-4 h-4" />
                    </div>
                  </div>
                  <div>
                    <div className="text-2xl font-black font-mono text-emerald-300">
                      ${(dashboardStats.kpis?.totalCollected ?? dashboardStats.totalCollected ?? 0).toLocaleString('en-US', { minimumFractionDigits: 2 })}
                    </div>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-400">
                        <TrendingUp className="w-3 h-3" />
                        {(dashboardStats.kpis?.collectionEfficiencyRate ?? dashboardStats.collectionRate ?? 0).toFixed(1)}% Recovery Rate
                      </span>
                    </div>
                  </div>
                </div>

                {/* 3. Total Outstanding */}
                <div className="p-5 bg-slate-900 border border-amber-500/30 bg-amber-500/5 rounded-2xl space-y-3 relative overflow-hidden group">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold uppercase tracking-wider text-amber-400">
                      Outstanding Receivable
                    </span>
                    <div className="p-2 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400">
                      <Clock className="w-4 h-4" />
                    </div>
                  </div>
                  <div>
                    <div className="text-2xl font-black font-mono text-amber-300">
                      ${(dashboardStats.kpis?.totalOutstanding ?? dashboardStats.totalOutstanding ?? 0).toLocaleString('en-US', { minimumFractionDigits: 2 })}
                    </div>
                    <p className="text-[11px] text-amber-300/80 mt-1">
                      Total Overdue:{' '}
                      <strong className="text-rose-400 font-mono">
                        ${(dashboardStats.kpis?.totalOverdue ?? dashboardStats.totalOverdue ?? 0).toLocaleString('en-US', { minimumFractionDigits: 2 })}
                      </strong>
                    </p>
                  </div>
                </div>

                {/* 4. Concessions & Adjustments */}
                <div className="p-5 bg-slate-900 border border-white/10 rounded-2xl space-y-3 relative overflow-hidden group">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold uppercase tracking-wider text-indigo-400">
                      Total Concessions
                    </span>
                    <div className="p-2 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400">
                      <ArrowDownRight className="w-4 h-4" />
                    </div>
                  </div>
                  <div>
                    <div className="text-2xl font-black font-mono text-indigo-300">
                      -$
                      {(
                        (dashboardStats.kpis?.totalDiscounts ?? dashboardStats.totalDiscounts ?? 0) +
                        (dashboardStats.kpis?.totalScholarshipsAndWaivers ?? dashboardStats.totalScholarshipsWaivers ?? 0)
                      ).toLocaleString('en-US', { minimumFractionDigits: 2 })}
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1">
                      Fines Applied:{' '}
                      <strong className="text-rose-400 font-mono">
                        +${(dashboardStats.kpis?.totalFines ?? dashboardStats.totalFines ?? 0).toLocaleString('en-US', { minimumFractionDigits: 2 })}
                      </strong>
                    </p>
                  </div>
                </div>
              </div>

              {/* Secondary Visual Metrics: Invoices Status & Category Breakdown */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Invoice Status Distribution */}
                <div className="p-6 bg-slate-900 border border-white/10 rounded-2xl space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                      <PieChart className="w-4 h-4 text-indigo-400" />
                      Invoice Status Portfolio
                    </h3>
                    <span className="text-xs text-slate-400 font-mono">
                      {dashboardStats.invoicesCount?.total ?? 0} Total Invoices
                    </span>
                  </div>

                  <div className="space-y-3 pt-2">
                    {/* Paid */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span className="text-emerald-400 font-semibold flex items-center gap-1.5">
                          <CheckCircle2 className="w-3.5 h-3.5" /> Fully Paid / Settled
                        </span>
                        <span className="font-mono text-slate-200 font-bold">
                          {dashboardStats.invoicesCount?.paid ?? 0} ({Math.round(((dashboardStats.invoicesCount?.paid ?? 0) / (dashboardStats.invoicesCount?.total || 1)) * 100)}%)
                        </span>
                      </div>
                      <div className="h-2 w-full bg-slate-950 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-emerald-500 rounded-full"
                          style={{
                            width: `${((dashboardStats.invoicesCount?.paid ?? 0) / (dashboardStats.invoicesCount?.total || 1)) * 100}%`
                          }}
                        />
                      </div>
                    </div>

                    {/* Partial */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span className="text-amber-400 font-semibold flex items-center gap-1.5">
                          <Clock className="w-3.5 h-3.5" /> Partially Paid
                        </span>
                        <span className="font-mono text-slate-200 font-bold">
                          {dashboardStats.invoicesCount?.partiallyPaid ?? 0} (
                          {Math.round(((dashboardStats.invoicesCount?.partiallyPaid ?? 0) / (dashboardStats.invoicesCount?.total || 1)) * 100)}%)
                        </span>
                      </div>
                      <div className="h-2 w-full bg-slate-950 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-amber-500 rounded-full"
                          style={{
                            width: `${((dashboardStats.invoicesCount?.partiallyPaid ?? 0) / (dashboardStats.invoicesCount?.total || 1)) * 100}%`
                          }}
                        />
                      </div>
                    </div>

                    {/* Unpaid */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span className="text-slate-400 font-semibold flex items-center gap-1.5">
                          <AlertTriangle className="w-3.5 h-3.5" /> Unpaid Active
                        </span>
                        <span className="font-mono text-slate-200 font-bold">
                          {dashboardStats.invoicesCount?.unpaid ?? 0} (
                          {Math.round(((dashboardStats.invoicesCount?.unpaid ?? 0) / (dashboardStats.invoicesCount?.total || 1)) * 100)}%)
                        </span>
                      </div>
                      <div className="h-2 w-full bg-slate-950 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-slate-600 rounded-full"
                          style={{
                            width: `${((dashboardStats.invoicesCount?.unpaid ?? 0) / (dashboardStats.invoicesCount?.total || 1)) * 100}%`
                          }}
                        />
                      </div>
                    </div>

                    {/* Overdue */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span className="text-rose-400 font-semibold flex items-center gap-1.5">
                          <Ban className="w-3.5 h-3.5" /> Overdue Delinquent
                        </span>
                        <span className="font-mono text-rose-300 font-bold">
                          {dashboardStats.invoicesCount?.overdue ?? 0} (
                          {Math.round(((dashboardStats.invoicesCount?.overdue ?? 0) / (dashboardStats.invoicesCount?.total || 1)) * 100)}%)
                        </span>
                      </div>
                      <div className="h-2 w-full bg-slate-950 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-rose-500 rounded-full"
                          style={{
                            width: `${((dashboardStats.invoicesCount?.overdue ?? 0) / (dashboardStats.invoicesCount?.total || 1)) * 100}%`
                          }}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="pt-3 border-t border-white/5 flex items-center justify-between text-xs text-slate-400">
                    <span>Reversals Audited:</span>
                    <span className="font-mono font-bold text-rose-400">
                      {dashboardStats.reversals?.count ?? dashboardStats.transactionsCount?.reversed ?? 0} (${(dashboardStats.reversals?.volume ?? dashboardStats.totalReversedAmount ?? 0).toFixed(2)})
                    </span>
                  </div>
                </div>

                {/* Category Revenue Breakdown */}
                <div className="lg:col-span-2 p-6 bg-slate-900 border border-white/10 rounded-2xl space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                      <Layers className="w-4 h-4 text-indigo-400" />
                      Revenue by Fee Category
                    </h3>
                    <span className="text-xs text-slate-400">All Active Categories</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                    {(dashboardStats.categoryBreakdown || []).map((cat) => {
                      const invAmt = cat.invoicedAmount ?? cat.generated ?? 0;
                      const colAmt = cat.collectedAmount ?? cat.collected ?? 0;
                      const recoveryPercent =
                        invAmt > 0 ? Math.round((colAmt / invAmt) * 100) : 0;

                      return (
                        <div
                          key={cat.category}
                          className="p-3.5 bg-slate-950 border border-white/5 rounded-xl space-y-2 hover:border-white/15 transition-all"
                        >
                          <div className="flex items-center justify-between text-xs">
                            <span className="font-bold text-white capitalize">{cat.category.toLowerCase()}</span>
                            <span className="font-mono text-emerald-400 font-bold">{recoveryPercent}%</span>
                          </div>

                          <div className="flex justify-between text-[11px] text-slate-400 font-mono">
                            <span>Invoiced: ${invAmt.toLocaleString()}</span>
                            <span className="text-emerald-300">Paid: ${colAmt.toLocaleString()}</span>
                          </div>

                          <div className="h-1.5 w-full bg-slate-900 rounded-full overflow-hidden">
                            <div
                              className="h-full bg-indigo-500 rounded-full"
                              style={{ width: `${Math.min(100, recoveryPercent)}%` }}
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Monthly Trend Strip */}
              {((dashboardStats?.monthlyTrends?.length || 0) > 0) && (
                <div className="p-6 bg-slate-900 border border-white/10 rounded-2xl space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                      <BarChart3 className="w-4 h-4 text-indigo-400" />
                      Monthly Revenue & Collection Timeline
                    </h3>
                    <span className="text-xs text-slate-400">Institutional Ledger History</span>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs">
                      <thead>
                        <tr className="border-b border-white/10 text-slate-400 font-bold uppercase text-[10px]">
                          <th className="px-4 py-2.5">Month</th>
                          <th className="px-4 py-2.5 text-right">Invoiced ($)</th>
                          <th className="px-4 py-2.5 text-right">Collected ($)</th>
                          <th className="px-4 py-2.5 text-right">Outstanding ($)</th>
                          <th className="px-4 py-2.5 text-right">Recovery Rate</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/5 text-slate-300">
                        {dashboardStats.monthlyTrends.map((trend) => {
                          const invoicedVal = trend.invoiced ?? trend.generated ?? 0;
                          const collectedVal = trend.collected ?? 0;
                          const rate = invoicedVal > 0 ? ((collectedVal / invoicedVal) * 100).toFixed(1) : '100.0';
                          return (
                            <tr key={trend.month} className="hover:bg-white/[0.02]">
                              <td className="px-4 py-2.5 font-bold text-white">{trend.month}</td>
                              <td className="px-4 py-2.5 text-right font-mono font-semibold text-slate-200">
                                ${invoicedVal.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                              </td>
                              <td className="px-4 py-2.5 text-right font-mono font-semibold text-emerald-400">
                                ${collectedVal.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                              </td>
                              <td className="px-4 py-2.5 text-right font-mono font-semibold text-amber-400">
                                ${(invoicedVal - collectedVal > 0 ? invoicedVal - collectedVal : 0).toLocaleString(
                                  'en-US',
                                  { minimumFractionDigits: 2 }
                                )}
                              </td>
                              <td className="px-4 py-2.5 text-right font-mono font-bold text-indigo-300">
                                {rate}%
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </>
          ) : null}
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 2: COLLECTION REPORT */}
      {/* ========================================================================= */}
      {activeTab === 'COLLECTIONS' && (
        <div className="space-y-6">
          {/* Multi-Dimensional Filter Toolbar */}
          <div className="p-5 bg-slate-900 border border-white/10 rounded-2xl space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <Filter className="w-4 h-4 text-indigo-400" />
                <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                  Filter Collection Transactions
                </h3>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleExportCollectionsCsv}
                  disabled={!collectionReport || !collectionReport?.transactions?.length}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 rounded-xl transition-colors cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  Export CSV
                </button>
                <button
                  onClick={() => {
                    setCollectionFilters({
                      startDate: '',
                      endDate: '',
                      classId: 'ALL',
                      sectionId: 'ALL',
                      feeTypeId: 'ALL',
                      paymentMethod: 'ALL',
                      collectorId: 'ALL',
                      status: 'ALL',
                      page: 1,
                      limit: 20
                    });
                    loadCollectionReport();
                  }}
                  className="px-3 py-1.5 text-xs font-semibold text-slate-400 hover:text-white bg-white/5 rounded-xl transition-colors cursor-pointer"
                >
                  Reset Filters
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 text-xs">
              {/* Date Start */}
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">From Date</label>
                <input
                  type="date"
                  value={collectionFilters.startDate}
                  onChange={(e) => setCollectionFilters((prev) => ({ ...prev, startDate: e.target.value, page: 1 }))}
                  className="w-full px-2.5 py-1.5 bg-slate-950 border border-white/10 rounded-xl text-slate-200 text-xs focus:outline-hidden focus:border-indigo-500"
                />
              </div>

              {/* Date End */}
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">To Date</label>
                <input
                  type="date"
                  value={collectionFilters.endDate}
                  onChange={(e) => setCollectionFilters((prev) => ({ ...prev, endDate: e.target.value, page: 1 }))}
                  className="w-full px-2.5 py-1.5 bg-slate-950 border border-white/10 rounded-xl text-slate-200 text-xs focus:outline-hidden focus:border-indigo-500"
                />
              </div>

              {/* Class Filter */}
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Class</label>
                <select
                  value={collectionFilters.classId}
                  onChange={(e) => handleClassChange(e.target.value)}
                  className="w-full px-2.5 py-1.5 bg-slate-950 border border-white/10 rounded-xl text-slate-200 text-xs focus:outline-hidden focus:border-indigo-500 cursor-pointer"
                >
                  <option value="ALL">All Classes</option>
                  {classes.map((cls) => (
                    <option key={cls.id} value={cls.id}>
                      {cls.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Section Filter */}
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Section</label>
                <select
                  value={collectionFilters.sectionId}
                  onChange={(e) => setCollectionFilters((prev) => ({ ...prev, sectionId: e.target.value, page: 1 }))}
                  disabled={collectionFilters.classId === 'ALL'}
                  className="w-full px-2.5 py-1.5 bg-slate-950 border border-white/10 rounded-xl text-slate-200 text-xs focus:outline-hidden focus:border-indigo-500 disabled:opacity-50 cursor-pointer"
                >
                  <option value="ALL">All Sections</option>
                  {sections.map((sec) => (
                    <option key={sec.id} value={sec.id}>
                      {sec.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Payment Method */}
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Method</label>
                <select
                  value={collectionFilters.paymentMethod}
                  onChange={(e) => setCollectionFilters((prev) => ({ ...prev, paymentMethod: e.target.value, page: 1 }))}
                  className="w-full px-2.5 py-1.5 bg-slate-950 border border-white/10 rounded-xl text-slate-200 text-xs focus:outline-hidden focus:border-indigo-500 cursor-pointer"
                >
                  <option value="ALL">All Methods</option>
                  <option value="CASH">Cash Counter</option>
                  <option value="BANK_TRANSFER">Bank Transfer</option>
                  <option value="ONLINE_PAYMENT">Online / Gateway</option>
                  <option value="CHEQUE">Cheque / Demand Draft</option>
                  <option value="POS_CARD">POS Terminal</option>
                </select>
              </div>

              {/* Transaction Status */}
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Audit Status</label>
                <select
                  value={collectionFilters.status}
                  onChange={(e) => setCollectionFilters((prev) => ({ ...prev, status: e.target.value, page: 1 }))}
                  className="w-full px-2.5 py-1.5 bg-slate-950 border border-white/10 rounded-xl text-slate-200 text-xs focus:outline-hidden focus:border-indigo-500 cursor-pointer"
                >
                  <option value="ALL">All Transactions</option>
                  <option value="SUCCESS">Valid / Settled</option>
                  <option value="REVERSED">Voided / Reversed</option>
                </select>
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={loadCollectionReport}
                className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs rounded-xl transition-colors cursor-pointer shadow-sm shadow-indigo-600/20"
              >
                Apply Filters & Generate
              </button>
            </div>
          </div>

          {/* Collection Summary Strip */}
          {collectionReport && (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div className="p-4 bg-slate-900 border border-white/10 rounded-xl space-y-1">
                <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Total Transactions</p>
                <p className="text-xl font-black font-mono text-white">{collectionReport.summary.totalTransactions}</p>
                <p className="text-[10px] text-slate-400">Filtered Entries</p>
              </div>

              <div className="p-4 bg-slate-900 border border-white/10 rounded-xl space-y-1">
                <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Gross Collected</p>
                <p className="text-xl font-black font-mono text-slate-200">
                  ${collectionReport.summary.grossCollected.toFixed(2)}
                </p>
                <p className="text-[10px] text-slate-400">All Collections</p>
              </div>

              <div className="p-4 bg-slate-900 border border-rose-500/30 bg-rose-500/5 rounded-xl space-y-1">
                <p className="text-[10px] font-bold uppercase tracking-wider text-rose-400">Reversals / Voids</p>
                <p className="text-xl font-black font-mono text-rose-300">
                  -${collectionReport.summary.reversedVolume.toFixed(2)}
                </p>
                <p className="text-[10px] text-rose-400/80">{collectionReport.summary.reversedTransactions} Reversals</p>
              </div>

              <div className="p-4 bg-slate-900 border border-emerald-500/30 bg-emerald-500/5 rounded-xl space-y-1">
                <p className="text-[10px] font-bold uppercase tracking-wider text-emerald-400">Net Realized Collection</p>
                <p className="text-xl font-black font-mono text-emerald-300">
                  ${collectionReport.summary.netCollected.toFixed(2)}
                </p>
                <p className="text-[10px] text-emerald-400/80">Audited Revenue</p>
              </div>
            </div>
          )}

          {/* Collection Transactions Table */}
          <div className="border border-white/10 rounded-2xl overflow-hidden bg-slate-900 shadow-xl">
            <div className="px-6 py-4 bg-slate-950/80 border-b border-white/10 flex items-center justify-between">
              <div>
                <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                  Detailed Collection Ledger
                </h4>
                <p className="text-[11px] text-slate-400">
                  Showing {(collectionReport?.transactions || collectionReport?.data || []).length} of {collectionReport?.total || 0} transactions
                </p>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-white/10 bg-white/[0.02] text-slate-400 font-bold uppercase text-[10px]">
                    <th className="px-4 py-3">Receipt / Txn ID</th>
                    <th className="px-4 py-3">Date & Time</th>
                    <th className="px-4 py-3">Student</th>
                    <th className="px-4 py-3">Fee Head</th>
                    <th className="px-3 py-3">Method</th>
                    <th className="px-3 py-3">Collector</th>
                    <th className="px-4 py-3 text-right">Amount Paid</th>
                    <th className="px-3 py-3 text-center">Status</th>
                    <th className="px-4 py-3 text-center">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5 text-slate-300">
                  {collectionLoading ? (
                    <tr>
                      <td colSpan={9} className="px-4 py-16 text-center text-slate-400">
                        <div className="w-6 h-6 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin mx-auto mb-2" />
                        Loading collection transactions...
                      </td>
                    </tr>
                  ) : (collectionReport?.transactions || collectionReport?.data || []).length === 0 ? (
                    <tr>
                      <td colSpan={9} className="px-4 py-12 text-center text-slate-400">
                        No transactions match the selected filter criteria.
                      </td>
                    </tr>
                  ) : (
                    (collectionReport?.transactions || collectionReport?.data || []).map((txn) => {
                      const isReversed = txn.paymentStatus === 'REVERSED';

                      return (
                        <tr
                          key={txn.id}
                          className={`hover:bg-white/[0.02] transition-colors ${
                            isReversed ? 'bg-rose-500/5' : ''
                          }`}
                        >
                          <td className="px-4 py-3 font-mono">
                            <div className="font-bold text-indigo-300">{txn.receiptNumber}</div>
                            <div className="text-[10px] text-slate-500">{txn.transactionId}</div>
                          </td>
                          <td className="px-4 py-3 whitespace-nowrap text-slate-400">
                            <div>{new Date(txn.paymentDate).toLocaleDateString()}</div>
                            <div className="text-[10px] text-slate-500">
                              {new Date(txn.paymentDate).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </div>
                          </td>
                          <td className="px-4 py-3">
                            <div className="font-bold text-white">{txn.studentName}</div>
                            <div className="text-[10px] text-slate-400">
                              {txn.studentAdmissionNumber ? `Adm: ${txn.studentAdmissionNumber} • ` : ''}
                              {txn.className || 'Grade 10'} {txn.sectionName ? `(${txn.sectionName})` : ''}
                            </div>
                          </td>
                          <td className="px-4 py-3">
                            <div className="font-semibold text-slate-200">{txn.feeTitle}</div>
                            <div className="text-[10px] text-slate-400 capitalize">
                              {(txn.feeType || '').toLowerCase()}
                            </div>
                          </td>
                          <td className="px-3 py-3">
                            <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-white/10 text-slate-200">
                              {txn.paymentMethodLabel || txn.paymentMethod}
                            </span>
                            {txn.referenceNumber && (
                              <div className="text-[9px] font-mono text-slate-400 truncate max-w-[100px] mt-0.5">
                                Ref: {txn.referenceNumber}
                              </div>
                            )}
                          </td>
                          <td className="px-3 py-3 text-slate-400 text-[11px]">
                            {txn.collectedByName || 'Finance Counter'}
                          </td>
                          <td className="px-4 py-3 text-right font-mono font-bold text-sm">
                            <span className={isReversed ? 'text-rose-400 line-through' : 'text-emerald-400'}>
                              ${(txn.amountPaid || 0).toFixed(2)}
                            </span>
                          </td>
                          <td className="px-3 py-3 text-center">
                            {isReversed ? (
                              <span
                                className="px-2 py-0.5 text-[9px] font-black uppercase rounded bg-rose-500/20 text-rose-300 border border-rose-500/30 cursor-help"
                                title={`Voided: ${txn.reversalReason || 'Administrative correction'}`}
                              >
                                VOIDED
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 text-[9px] font-black uppercase rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                                SETTLED
                              </span>
                            )}
                          </td>
                          <td className="px-4 py-3 text-center">
                            <button
                              onClick={() => handleViewReceipt(txn.receiptNumber)}
                              className="p-1.5 text-slate-400 hover:text-indigo-400 bg-white/5 hover:bg-white/10 rounded-lg transition-colors cursor-pointer"
                              title="View & Print Official Receipt"
                            >
                              <Receipt className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>

            {/* Pagination Controls */}
            {collectionReport && (collectionReport.totalPages || 0) > 1 && (
              <div className="px-6 py-3 bg-slate-950 border-t border-white/10 flex items-center justify-between text-xs text-slate-400">
                <span>
                  Page {collectionReport.page || 1} of {collectionReport.totalPages || 1}
                </span>
                <div className="flex items-center gap-2">
                  <button
                    disabled={(collectionReport.page || 1) <= 1}
                    onClick={() =>
                      setCollectionFilters((prev) => ({ ...prev, page: Math.max(1, prev.page - 1) }))
                    }
                    className="px-3 py-1 bg-white/5 hover:bg-white/10 rounded-lg disabled:opacity-50 transition-colors cursor-pointer"
                  >
                    Previous
                  </button>
                  <button
                    disabled={(collectionReport.page || 1) >= (collectionReport.totalPages || 1)}
                    onClick={() =>
                      setCollectionFilters((prev) => ({ ...prev, page: prev.page + 1 }))
                    }
                    className="px-3 py-1 bg-white/5 hover:bg-white/10 rounded-lg disabled:opacity-50 transition-colors cursor-pointer"
                  >
                    Next
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 3: DUE & OVERDUE REPORT */}
      {/* ========================================================================= */}
      {activeTab === 'DUE_OVERDUE' && (
        <div className="space-y-6">
          {/* Controls Bar */}
          <div className="p-5 bg-slate-900 border border-white/10 rounded-2xl flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3 flex-wrap">
              <div className="flex items-center gap-2 bg-slate-950 px-3 py-1.5 rounded-xl border border-white/10 text-xs">
                <span className="text-slate-400 font-semibold">Class Filter:</span>
                <select
                  value={dueClassFilter}
                  onChange={(e) => {
                    setDueClassFilter(e.target.value);
                  }}
                  className="bg-transparent text-white font-bold focus:outline-hidden cursor-pointer"
                >
                  <option value="ALL" className="bg-slate-900">All Classes</option>
                  {classes.map((c) => (
                    <option key={c.id} value={c.id} className="bg-slate-900">
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="relative">
                <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
                <input
                  type="text"
                  value={dueSearchQuery}
                  onChange={(e) => setDueSearchQuery(e.target.value)}
                  placeholder="Search student or admission #..."
                  className="pl-8 pr-3 py-1.5 bg-slate-950 border border-white/10 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-hidden focus:border-indigo-500"
                />
              </div>

              <button
                onClick={loadDueReport}
                className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs rounded-xl transition-colors cursor-pointer"
              >
                Refresh Due Stats
              </button>
            </div>
          </div>

          {/* Aging Summary Metrics */}
          {dueReportData && dueReportData.agingBreakdown && (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
              <div className="p-4 bg-slate-900 border border-white/10 rounded-xl space-y-1">
                <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Current (Not Due)</p>
                <p className="text-base font-black font-mono text-white">
                  ${dueReportData.agingBreakdown.notDueYet.amount.toFixed(2)}
                </p>
                <p className="text-[10px] text-slate-400">{dueReportData.agingBreakdown.notDueYet.count} Invoices</p>
              </div>

              <div className="p-4 bg-slate-900 border border-amber-500/30 bg-amber-500/5 rounded-xl space-y-1">
                <p className="text-[10px] font-bold uppercase tracking-wider text-amber-400">Due Soon (&lt; 7d)</p>
                <p className="text-base font-black font-mono text-amber-300">
                  ${dueReportData.agingBreakdown.dueSoon.amount.toFixed(2)}
                </p>
                <p className="text-[10px] text-amber-400/80">{dueReportData.agingBreakdown.dueSoon.count} Invoices</p>
              </div>

              <div className="p-4 bg-slate-900 border border-rose-500/20 bg-rose-500/5 rounded-xl space-y-1">
                <p className="text-[10px] font-bold uppercase tracking-wider text-rose-300">Overdue 1–15 Days</p>
                <p className="text-base font-black font-mono text-rose-300">
                  ${dueReportData.agingBreakdown.overdue1to15.amount.toFixed(2)}
                </p>
                <p className="text-[10px] text-rose-300/80">{dueReportData.agingBreakdown.overdue1to15.count} Invoices</p>
              </div>

              <div className="p-4 bg-slate-900 border border-rose-500/30 bg-rose-500/5 rounded-xl space-y-1">
                <p className="text-[10px] font-bold uppercase tracking-wider text-rose-400">Overdue 16–30 Days</p>
                <p className="text-base font-black font-mono text-rose-400">
                  ${dueReportData.agingBreakdown.overdue16to30.amount.toFixed(2)}
                </p>
                <p className="text-[10px] text-rose-400/80">{dueReportData.agingBreakdown.overdue16to30.count} Invoices</p>
              </div>

              <div className="p-4 bg-slate-900 border border-rose-500/40 bg-rose-500/10 rounded-xl space-y-1">
                <p className="text-[10px] font-bold uppercase tracking-wider text-rose-400">Overdue 31–60 Days</p>
                <p className="text-base font-black font-mono text-rose-400">
                  ${dueReportData.agingBreakdown.overdue31to60.amount.toFixed(2)}
                </p>
                <p className="text-[10px] text-rose-400/80">{dueReportData.agingBreakdown.overdue31to60.count} Invoices</p>
              </div>

              <div className="p-4 bg-slate-900 border border-rose-600/50 bg-rose-600/10 rounded-xl space-y-1">
                <p className="text-[10px] font-bold uppercase tracking-wider text-rose-300">Overdue 60+ Days</p>
                <p className="text-base font-black font-mono text-rose-300">
                  ${dueReportData.agingBreakdown.overdue60Plus.amount.toFixed(2)}
                </p>
                <p className="text-[10px] text-rose-300/80">{dueReportData.agingBreakdown.overdue60Plus.count} Invoices</p>
              </div>
            </div>
          )}

          {/* Class-wise Due & Defaulter Breakdown */}
          {dueReportData && dueReportData.classWiseBreakdown && (
            <div className="p-6 bg-slate-900 border border-white/10 rounded-2xl space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                  <Building className="w-4 h-4 text-indigo-400" />
                  Class-wise Fee Due & Defaulter Analysis
                </h3>
                <span className="text-xs text-slate-400">Recovery vs Defaulter Rate</span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-white/10 bg-white/[0.02] text-slate-400 font-bold uppercase text-[10px]">
                      <th className="px-4 py-3">Class</th>
                      <th className="px-3 py-3 text-right">Students</th>
                      <th className="px-3 py-3 text-right">With Dues</th>
                      <th className="px-4 py-3 text-right">Receivable ($)</th>
                      <th className="px-4 py-3 text-right">Collected ($)</th>
                      <th className="px-4 py-3 text-right">Total Due ($)</th>
                      <th className="px-4 py-3 text-right">Overdue ($)</th>
                      <th className="px-3 py-3 text-right">Collection Rate</th>
                      <th className="px-3 py-3 text-right">Defaulter Rate</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5 text-slate-300">
                    {dueReportData.classWiseBreakdown.map((row: any, idx: number) => (
                      <tr key={`${row.classId}-${idx}`} className="hover:bg-white/[0.02]">
                        <td className="px-4 py-3 font-bold text-white">{row.className}</td>
                        <td className="px-3 py-3 text-right font-mono text-slate-300">{row.totalStudents}</td>
                        <td className="px-3 py-3 text-right font-mono font-bold text-amber-400">
                          {row.totalStudentsWithDue}
                        </td>
                        <td className="px-4 py-3 text-right font-mono text-slate-300">
                          ${row.totalReceivable.toLocaleString()}
                        </td>
                        <td className="px-4 py-3 text-right font-mono font-semibold text-emerald-400">
                          ${row.totalCollected.toLocaleString()}
                        </td>
                        <td className="px-4 py-3 text-right font-mono font-semibold text-amber-400">
                          ${row.totalDue.toLocaleString()}
                        </td>
                        <td className="px-4 py-3 text-right font-mono font-bold text-rose-400">
                          ${row.totalOverdue.toLocaleString()}
                        </td>
                        <td className="px-3 py-3 text-right font-mono font-bold text-indigo-300">
                          {Number(row.collectionRate ?? 0).toFixed(1)}%
                        </td>
                        <td className="px-3 py-3 text-right font-mono font-bold text-rose-400">
                          {Number(row.defaulterRate ?? 0).toFixed(1)}%
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 4: FEE HEAD SUMMARY REPORT */}
      {/* ========================================================================= */}
      {activeTab === 'FEE_SUMMARY' && (
        <div className="space-y-6">
          {/* Actions Bar */}
          <div className="p-5 bg-slate-900 border border-white/10 rounded-2xl flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2 bg-slate-950 px-3 py-1.5 rounded-xl border border-white/10 text-xs">
                <span className="text-slate-400 font-semibold">Filter by Class:</span>
                <select
                  value={feeSummaryClassId}
                  onChange={(e) => {
                    setFeeSummaryClassId(e.target.value);
                  }}
                  className="bg-transparent text-white font-bold focus:outline-hidden cursor-pointer"
                >
                  <option value="ALL" className="bg-slate-900">All Classes</option>
                  {classes.map((c) => (
                    <option key={c.id} value={c.id} className="bg-slate-900">
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>

              <button
                onClick={loadFeeSummaryReport}
                className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs rounded-xl transition-colors cursor-pointer"
              >
                Apply Filter
              </button>
            </div>

            <button
              onClick={handleExportFeeSummaryCsv}
              disabled={!feeSummaryReport || !(feeSummaryReport.feeTypes || feeSummaryReport.data || []).length}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 rounded-xl transition-colors cursor-pointer shadow-sm shadow-indigo-600/20"
            >
              <Download className="w-3.5 h-3.5" />
              Export CSV
            </button>
          </div>

          {/* Fee Summary Table */}
          <div className="border border-white/10 rounded-2xl overflow-hidden bg-slate-900 shadow-xl">
            <div className="px-6 py-4 bg-slate-950/80 border-b border-white/10 flex items-center justify-between">
              <div>
                <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                  Fee Type & Structure Breakdown
                </h4>
                <p className="text-[11px] text-slate-400">
                  Comprehensive audit of invoiced vs collected revenue per fee category
                </p>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-white/10 bg-white/[0.02] text-slate-400 font-bold uppercase text-[10px]">
                    <th className="px-4 py-3">Fee Type / Category</th>
                    <th className="px-3 py-3 text-right">Students</th>
                    <th className="px-3 py-3 text-right">Invoiced ($)</th>
                    <th className="px-3 py-3 text-right">Concessions ($)</th>
                    <th className="px-3 py-3 text-right">Fines ($)</th>
                    <th className="px-3 py-3 text-right">Net Payable ($)</th>
                    <th className="px-3 py-3 text-right">Collected ($)</th>
                    <th className="px-3 py-3 text-right">Outstanding ($)</th>
                    <th className="px-4 py-3 text-right">Recovery Rate</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5 text-slate-300">
                  {feeSummaryLoading ? (
                    <tr>
                      <td colSpan={9} className="px-4 py-16 text-center text-slate-400">
                        <div className="w-6 h-6 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin mx-auto mb-2" />
                        Generating fee structure summaries...
                      </td>
                    </tr>
                  ) : !(feeSummaryReport?.feeTypes || feeSummaryReport?.data || []).length ? (
                    <tr>
                      <td colSpan={9} className="px-4 py-12 text-center text-slate-400">
                        No fee type records found for this academic session.
                      </td>
                    </tr>
                  ) : (
                    (feeSummaryReport?.feeTypes || feeSummaryReport?.data || []).map((item) => {
                      const totalInvoiced = item.totalInvoiced ?? item.totalOriginalAmount ?? 0;
                      const totalDiscounts = item.totalDiscounts ?? item.totalDiscount ?? 0;
                      const totalScholarships = item.totalScholarships ?? item.totalScholarship ?? 0;
                      const totalWaivers = item.totalWaivers ?? item.totalWaiver ?? 0;
                      const totalFines = item.totalFines ?? item.totalFine ?? 0;
                      const netPayable = item.netPayable ?? item.netPayableAmount ?? 0;
                      const totalCollected = item.totalCollected ?? 0;
                      const totalDue = item.totalDue ?? 0;
                      const collectionRate = item.collectionRate ?? 0;
                      const totalConcessions = totalDiscounts + totalScholarships + totalWaivers;

                      return (
                        <tr key={item.id || item.feeTypeId || item.name} className="hover:bg-white/[0.02]">
                          <td className="px-4 py-3">
                            <div className="font-bold text-white">{item.name || item.feeTypeName}</div>
                            <div className="text-[10px] text-slate-400 flex items-center gap-1.5 mt-0.5">
                              <span className="font-mono text-indigo-300">{item.code || ''}</span> &bull;{' '}
                              <span className="capitalize">{(item.category || item.feeCategory || '').toLowerCase()}</span>
                            </div>
                          </td>
                          <td className="px-3 py-3 text-right font-mono font-semibold text-slate-200">
                            {item.assignedStudentsCount ?? item.assignedCount ?? 0}
                          </td>
                          <td className="px-3 py-3 text-right font-mono text-slate-200">
                            ${totalInvoiced.toFixed(2)}
                          </td>
                          <td className="px-3 py-3 text-right font-mono text-emerald-400">
                            {totalConcessions > 0 ? `-$${totalConcessions.toFixed(2)}` : '—'}
                          </td>
                          <td className="px-3 py-3 text-right font-mono text-rose-400">
                            {totalFines > 0 ? `+$${totalFines.toFixed(2)}` : '—'}
                          </td>
                          <td className="px-3 py-3 text-right font-mono font-bold text-slate-100">
                            ${netPayable.toFixed(2)}
                          </td>
                          <td className="px-3 py-3 text-right font-mono font-bold text-emerald-400">
                            ${totalCollected.toFixed(2)}
                          </td>
                          <td className="px-3 py-3 text-right font-mono font-bold text-amber-400">
                            ${totalDue.toFixed(2)}
                          </td>
                          <td className="px-4 py-3 text-right font-mono font-bold text-indigo-300">
                            {collectionRate.toFixed(1)}%
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
                {feeSummaryReport && feeSummaryReport.summary && (
                  <tfoot className="border-t-2 border-white/10 bg-slate-950 font-mono text-xs">
                    <tr>
                      <td className="px-4 py-3 font-bold text-white">Institutional Total</td>
                      <td className="px-3 py-3 text-right font-bold text-slate-300">
                        {feeSummaryReport.summary.totalStudents ?? feeSummaryReport.summary.totalAssignedCount ?? 0}
                      </td>
                      <td className="px-3 py-3 text-right font-bold text-slate-300">
                        ${(feeSummaryReport.summary.totalInvoiced ?? feeSummaryReport.summary.totalOriginal ?? 0).toFixed(2)}
                      </td>
                      <td className="px-3 py-3 text-right font-bold text-emerald-400">
                        -$
                        {(
                          (feeSummaryReport.summary.totalDiscounts ?? feeSummaryReport.summary.totalDiscount ?? 0) +
                          (feeSummaryReport.summary.totalScholarships ?? feeSummaryReport.summary.totalScholarship ?? 0) +
                          (feeSummaryReport.summary.totalWaivers ?? feeSummaryReport.summary.totalWaiver ?? 0)
                        ).toFixed(2)}
                      </td>
                      <td className="px-3 py-3 text-right font-bold text-rose-400">
                        +${(feeSummaryReport.summary.totalFines ?? feeSummaryReport.summary.totalFine ?? 0).toFixed(2)}
                      </td>
                      <td className="px-3 py-3 text-right font-bold text-indigo-300">
                        ${(feeSummaryReport.summary.totalNetPayable ?? feeSummaryReport.summary.netPayable ?? 0).toFixed(2)}
                      </td>
                      <td className="px-3 py-3 text-right font-bold text-emerald-400">
                        ${(feeSummaryReport.summary.totalCollected ?? 0).toFixed(2)}
                      </td>
                      <td className="px-3 py-3 text-right font-bold text-amber-400">
                        ${(feeSummaryReport.summary.totalDue ?? 0).toFixed(2)}
                      </td>
                      <td className="px-4 py-3 text-right font-black text-indigo-300">
                        {(feeSummaryReport.summary.overallCollectionRate ?? 0).toFixed(1)}%
                      </td>
                    </tr>
                  </tfoot>
                )}
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 5: PAYMENT METHODS / CHANNELS REPORT */}
      {/* ========================================================================= */}
      {activeTab === 'PAYMENT_METHODS' && (
        <div className="space-y-6">
          {paymentMethodReport && (
            <>
              {/* Summary Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                <div className="p-4 bg-slate-900 border border-white/10 rounded-xl space-y-1">
                  <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Total Transactions</p>
                  <p className="text-2xl font-black font-mono text-white">
                    {paymentMethodReport.summary?.totalTransactions ?? 0}
                  </p>
                  <p className="text-[10px] text-slate-400">All Channels</p>
                </div>

                <div className="p-4 bg-slate-900 border border-white/10 rounded-xl space-y-1">
                  <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Gross Processed</p>
                  <p className="text-2xl font-black font-mono text-slate-200">
                    ${(paymentMethodReport.summary?.totalVolume ?? 0).toFixed(2)}
                  </p>
                  <p className="text-[10px] text-slate-400">All Collections</p>
                </div>

                <div className="p-4 bg-slate-900 border border-rose-500/30 bg-rose-500/5 rounded-xl space-y-1">
                  <p className="text-[10px] font-bold uppercase tracking-wider text-rose-400">Reversals Volume</p>
                  <p className="text-2xl font-black font-mono text-rose-300">
                    -${(paymentMethodReport.summary?.reversedVolume ?? 0).toFixed(2)}
                  </p>
                  <p className="text-[10px] text-rose-400/80">
                    {paymentMethodReport.summary?.reversedTransactions ?? 0} Reversals
                  </p>
                </div>

                <div className="p-4 bg-slate-900 border border-emerald-500/30 bg-emerald-500/5 rounded-xl space-y-1">
                  <p className="text-[10px] font-bold uppercase tracking-wider text-emerald-400">Net Realized Revenue</p>
                  <p className="text-2xl font-black font-mono text-emerald-300">
                    ${(paymentMethodReport.summary?.netVolume ?? 0).toFixed(2)}
                  </p>
                  <p className="text-[10px] text-emerald-400/80">Net Deposited</p>
                </div>
              </div>

              {/* Methods Table */}
              <div className="p-6 bg-slate-900 border border-white/10 rounded-2xl space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                    <CreditCard className="w-4 h-4 text-indigo-400" />
                    Payment Channel Breakdown & Share of Revenue
                  </h3>
                  <span className="text-xs text-slate-400">Institutional Gateway Audit</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {(paymentMethodReport.methods || []).map((method) => (
                    <div
                      key={method.methodCode}
                      className="p-4 bg-slate-950 border border-white/10 rounded-xl space-y-3"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2.5">
                          <div className="p-2 rounded-lg bg-indigo-500/10 text-indigo-400">
                            <CreditCard className="w-4 h-4" />
                          </div>
                          <div>
                            <h4 className="text-sm font-bold text-white">{method.methodName}</h4>
                            <p className="text-[10px] font-mono text-slate-400">{method.methodCode}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <span className="px-2.5 py-1 rounded-full text-xs font-black bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                            {method.sharePercentage ?? 0}% Share
                          </span>
                        </div>
                      </div>

                      <div className="grid grid-cols-3 gap-2 pt-2 border-t border-white/5 text-xs">
                        <div>
                          <p className="text-[10px] text-slate-400">Transactions</p>
                          <p className="font-bold font-mono text-white">{method.transactionCount ?? 0}</p>
                        </div>
                        <div>
                          <p className="text-[10px] text-slate-400">Net Volume</p>
                          <p className="font-bold font-mono text-emerald-400">${(method.netVolume ?? 0).toFixed(2)}</p>
                        </div>
                        <div>
                          <p className="text-[10px] text-slate-400">Avg Ticket</p>
                          <p className="font-bold font-mono text-slate-200">${(method.averageTransactionValue ?? 0).toFixed(2)}</p>
                        </div>
                      </div>

                      {(method.reversedVolume || 0) > 0 && (
                        <div className="p-2 bg-rose-500/10 border border-rose-500/20 rounded-lg text-[11px] text-rose-300 flex items-center justify-between">
                          <span>Reversals Volume:</span>
                          <span className="font-mono font-bold">-${(method.reversedVolume || 0).toFixed(2)}</span>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 6: RECEIPTS ARCHIVE & VERIFICATION */}
      {/* ========================================================================= */}
      {activeTab === 'RECEIPTS' && (
        <div className="space-y-6">
          {/* Search & Filter Bar */}
          <div className="p-5 bg-slate-900 border border-white/10 rounded-2xl flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3 flex-wrap flex-1">
              <div className="relative flex-1 min-w-[240px]">
                <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                <input
                  type="text"
                  value={receiptsSearch}
                  onChange={(e) => {
                    setReceiptsSearch(e.target.value);
                    setReceiptsPage(1);
                  }}
                  placeholder="Search receipt #, transaction ID, student name..."
                  className="w-full pl-9 pr-4 py-2 bg-slate-950 border border-white/10 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-hidden focus:border-indigo-500"
                />
              </div>

              <select
                value={receiptsStatus}
                onChange={(e) => {
                  setReceiptsStatus(e.target.value);
                  setReceiptsPage(1);
                }}
                className="px-3 py-2 bg-slate-950 border border-white/10 rounded-xl text-xs text-white focus:outline-hidden cursor-pointer"
              >
                <option value="ALL">All Statuses</option>
                <option value="SUCCESS">Valid Settled</option>
                <option value="REVERSED">Voided / Reversed</option>
              </select>

              <button
                onClick={loadReceiptsArchive}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs rounded-xl transition-colors cursor-pointer"
              >
                Search
              </button>
            </div>
          </div>

          {/* Receipts Table */}
          <div className="border border-white/10 rounded-2xl overflow-hidden bg-slate-900 shadow-xl">
            <div className="px-6 py-4 bg-slate-950/80 border-b border-white/10 flex items-center justify-between">
              <div>
                <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                  Payment Receipts Archive
                </h4>
                <p className="text-[11px] text-slate-400">
                  {receiptsTotalCount} Total Official Receipts Issued
                </p>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-white/10 bg-white/[0.02] text-slate-400 font-bold uppercase text-[10px]">
                    <th className="px-4 py-3">Receipt Number</th>
                    <th className="px-4 py-3">Date Issued</th>
                    <th className="px-4 py-3">Student Name</th>
                    <th className="px-4 py-3">Class / Admission</th>
                    <th className="px-3 py-3">Fee Title</th>
                    <th className="px-3 py-3">Method</th>
                    <th className="px-4 py-3 text-right">Amount</th>
                    <th className="px-3 py-3 text-center">Status</th>
                    <th className="px-4 py-3 text-center">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5 text-slate-300">
                  {receiptsLoading ? (
                    <tr>
                      <td colSpan={9} className="px-4 py-16 text-center text-slate-400">
                        <div className="w-6 h-6 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin mx-auto mb-2" />
                        Querying official receipts archive...
                      </td>
                    </tr>
                  ) : receiptsList.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="px-4 py-12 text-center text-slate-400">
                        No receipts match your search parameters.
                      </td>
                    </tr>
                  ) : (
                    receiptsList.map((receipt) => {
                      const isReversed = receipt.paymentDetails?.isReversed;

                      return (
                        <tr
                          key={receipt.receiptNumber}
                          className={`hover:bg-white/[0.02] transition-colors ${
                            isReversed ? 'bg-rose-500/5' : ''
                          }`}
                        >
                          <td className="px-4 py-3 font-mono font-bold text-indigo-300">
                            {receipt.receiptNumber}
                          </td>
                          <td className="px-4 py-3 text-slate-400 whitespace-nowrap">
                            {new Date(receipt.issuedAt || receipt.paymentDetails.paymentDate).toLocaleDateString()}
                          </td>
                          <td className="px-4 py-3 font-bold text-white">
                            {receipt.studentInfo?.name}
                          </td>
                          <td className="px-4 py-3 text-slate-400">
                            {receipt.studentInfo?.className} {receipt.studentInfo?.sectionName ? `(${receipt.studentInfo.sectionName})` : ''}
                            <div className="text-[10px] font-mono text-slate-500">
                              Adm: {receipt.studentInfo?.admissionNumber}
                            </div>
                          </td>
                          <td className="px-3 py-3 font-medium text-slate-200">
                            {receipt.feeInfo?.title}
                          </td>
                          <td className="px-3 py-3">
                            <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-white/10 text-slate-200">
                              {receipt.paymentDetails?.paymentMethodLabel || receipt.paymentDetails?.paymentMethod}
                            </span>
                          </td>
                          <td className="px-4 py-3 text-right font-mono font-bold text-sm">
                            <span className={isReversed ? 'text-rose-400 line-through' : 'text-emerald-400'}>
                              ${(receipt.feeInfo?.amountPaidNow || 0).toFixed(2)}
                            </span>
                          </td>
                          <td className="px-3 py-3 text-center">
                            {isReversed ? (
                              <span className="px-2 py-0.5 text-[9px] font-black uppercase rounded bg-rose-500/20 text-rose-300 border border-rose-500/30">
                                VOID
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 text-[9px] font-black uppercase rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                                VALID
                              </span>
                            )}
                          </td>
                          <td className="px-4 py-3 text-center">
                            <button
                              onClick={() => handleViewReceipt(receipt.receiptNumber)}
                              className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg transition-colors cursor-pointer"
                            >
                              <Eye className="w-3.5 h-3.5" />
                              View
                            </button>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 7: STUDENT STATEMENT GENERATOR */}
      {/* ========================================================================= */}
      {activeTab === 'STATEMENTS' && (
        <div className="space-y-6">
          {/* Student Selector Card */}
          <div className="p-6 bg-slate-900 border border-white/10 rounded-2xl space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                  <User className="w-4 h-4 text-indigo-400" />
                  Select Student for Financial Statement
                </h3>
                <p className="text-xs text-slate-400">
                  Search through the enrolled student roster to open an audited account ledger statement.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                <input
                  type="text"
                  value={statementStudentSearch}
                  onChange={(e) => setStatementStudentSearch(e.target.value)}
                  placeholder="Filter student list by name, roll, or admission number..."
                  className="w-full pl-9 pr-4 py-2 bg-slate-950 border border-white/10 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-hidden focus:border-indigo-500"
                />
              </div>

              <div>
                <select
                  value={selectedStudentForStatement}
                  onChange={(e) => setSelectedStudentForStatement(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-white/10 rounded-xl text-xs text-white focus:outline-hidden focus:border-indigo-500 cursor-pointer"
                >
                  <option value="">-- Choose a Student --</option>
                  {filteredStudentsForStatement.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.firstName} {s.lastName} (Adm: {s.admissionNumber} &bull; {s.className})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {activeStudentProfile && (
              <div className="p-4 bg-slate-950 border border-white/5 rounded-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-300 font-bold text-sm">
                    {activeStudentProfile.firstName.charAt(0)}
                    {activeStudentProfile.lastName.charAt(0)}
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white">
                      {activeStudentProfile.firstName} {activeStudentProfile.lastName}
                    </h4>
                    <p className="text-xs text-slate-400">
                      Admission No: <span className="font-mono text-indigo-300">{activeStudentProfile.admissionNumber}</span> &bull; Class: {activeStudentProfile.className}
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => {
                    setStatementModalStudentId(activeStudentProfile.id);
                    setStatementModalOpen(true);
                  }}
                  className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl transition-colors cursor-pointer shadow-lg shadow-indigo-600/20"
                >
                  <FileText className="w-4 h-4" />
                  Open Full Financial Ledger Statement
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Payment Receipt Modal */}
      <PaymentReceiptModal
        isOpen={isReceiptModalOpen}
        onClose={() => {
          setIsReceiptModalOpen(false);
          setSelectedReceipt(null);
        }}
        receiptData={selectedReceipt}
        isLoading={receiptModalLoading}
      />

      {/* Student Financial Statement Modal */}
      <StudentStatementModal
        isOpen={statementModalOpen}
        onClose={() => {
          setStatementModalOpen(false);
          setStatementModalStudentId(null);
        }}
        studentId={statementModalStudentId}
        academicSessionId={selectedSessionId}
      />

      {/* Invoice Detail Modal */}
      <InvoiceViewModal
        isOpen={isInvoiceModalOpen}
        onClose={() => {
          setIsInvoiceModalOpen(false);
          setSelectedInvoiceId(null);
        }}
        feeRecordId={selectedInvoiceId}
        onPayFee={() => {
          setIsInvoiceModalOpen(false);
        }}
      />
    </div>
  );
};
export default AdminFinancialReportsPage;
