import React, { useState, useEffect, useCallback } from 'react';
import {
  Percent,
  ShieldCheck,
  Award,
  AlertTriangle,
  Clock,
  Plus,
  Search,
  Filter,
  RefreshCw,
  Eye,
  CheckCircle2,
  XCircle,
  Play,
  Layers,
  Sparkles,
  DollarSign,
  Calendar,
  Trash2,
  Edit2,
  FileSpreadsheet,
  ArrowUpRight,
  History,
  Check,
  X,
  AlertCircle
} from 'lucide-react';
import {
  FeeDiscountRule,
  FeeWaiver,
  FeeScholarship,
  FeeFineRule,
  AppliedFineRecord,
  FeeAdjustmentAudit,
  FeeAdjustmentSummaryStats,
  AcademicSession,
  SchoolClass,
  Section,
  FeeType
} from '../../types/index.js';
import { api } from '../../services/api.js';
import { useToast } from '../../context/ToastContext.js';
import { useSettings } from '../../context/SettingsContext.js';

import { CreateDiscountModal } from '../../components/fees/CreateDiscountModal.js';
import { BatchApplyDiscountModal } from '../../components/fees/BatchApplyDiscountModal.js';
import { GrantWaiverModal } from '../../components/fees/GrantWaiverModal.js';
import { GrantScholarshipModal } from '../../components/fees/GrantScholarshipModal.js';
import { CreateFineRuleModal } from '../../components/fees/CreateFineRuleModal.js';
import { AssessLateFinesModal } from '../../components/fees/AssessLateFinesModal.js';
import { ManualFineModal } from '../../components/fees/ManualFineModal.js';
import { WaiveFineModal } from '../../components/fees/WaiveFineModal.js';

type TabType = 'DISCOUNTS' | 'WAIVERS' | 'SCHOLARSHIPS' | 'FINES' | 'AUDIT_TRAIL';

interface AdminFeeAdjustmentsPageProps {
  activeTab?: TabType;
  onTabChange?: (tab: TabType) => void;
  hideTabBar?: boolean;
}

export const AdminFeeAdjustmentsPage: React.FC<AdminFeeAdjustmentsPageProps> = ({
  activeTab: propActiveTab,
  onTabChange,
  hideTabBar = true
}) => {
  const { showToast } = useToast();
  const { activeSession } = useSettings();

  // Active Tab
  const [internalTab, setInternalTab] = useState<TabType>('DISCOUNTS');
  const activeTab = propActiveTab || internalTab;
  const setActiveTab = (tab: TabType) => {
    setInternalTab(tab);
    onTabChange?.(tab);
  };

  // Metadata dropdowns
  const [sessions, setSessions] = useState<AcademicSession[]>([]);
  const [classes, setClasses] = useState<SchoolClass[]>([]);
  const [sections, setSections] = useState<Section[]>([]);
  const [feeTypes, setFeeTypes] = useState<FeeType[]>([]);

  // Overview Stats
  const [stats, setStats] = useState<FeeAdjustmentSummaryStats | null>(null);
  const [isLoadingStats, setIsLoadingStats] = useState<boolean>(true);

  // Tab 1: Discounts
  const [discounts, setDiscounts] = useState<FeeDiscountRule[]>([]);
  const [discountSearch, setDiscountSearch] = useState('');
  const [discountStatusFilter, setDiscountStatusFilter] = useState('ALL');
  const [discountTypeFilter, setDiscountTypeFilter] = useState('ALL');
  const [isLoadingDiscounts, setIsLoadingDiscounts] = useState(false);
  const [selectedDiscountForEdit, setSelectedDiscountForEdit] = useState<FeeDiscountRule | null>(null);
  const [isDiscountModalOpen, setIsDiscountModalOpen] = useState(false);
  const [selectedDiscountForBatch, setSelectedDiscountForBatch] = useState<FeeDiscountRule | null>(null);
  const [isBatchModalOpen, setIsBatchModalOpen] = useState(false);

  // Tab 2: Waivers
  const [waivers, setWaivers] = useState<FeeWaiver[]>([]);
  const [waiverSearch, setWaiverSearch] = useState('');
  const [waiverStatusFilter, setWaiverStatusFilter] = useState('ALL');
  const [isLoadingWaivers, setIsLoadingWaivers] = useState(false);
  const [isWaiverModalOpen, setIsWaiverModalOpen] = useState(false);

  // Tab 3: Scholarships
  const [scholarships, setScholarships] = useState<FeeScholarship[]>([]);
  const [scholarshipSearch, setScholarshipSearch] = useState('');
  const [scholarshipTypeFilter, setScholarshipTypeFilter] = useState('ALL');
  const [isLoadingScholarships, setIsLoadingScholarships] = useState(false);
  const [selectedScholarshipForEdit, setSelectedScholarshipForEdit] = useState<FeeScholarship | null>(null);
  const [isScholarshipModalOpen, setIsScholarshipModalOpen] = useState(false);

  // Tab 4: Fines & Rules
  const [fineRules, setFineRules] = useState<FeeFineRule[]>([]);
  const [appliedFines, setAppliedFines] = useState<AppliedFineRecord[]>([]);
  const [fineSearch, setFineSearch] = useState('');
  const [fineStatusFilter, setFineStatusFilter] = useState('ALL');
  const [isLoadingFines, setIsLoadingFines] = useState(false);
  const [selectedRuleForEdit, setSelectedRuleForEdit] = useState<FeeFineRule | null>(null);
  const [isFineRuleModalOpen, setIsFineRuleModalOpen] = useState(false);
  const [isAssessModalOpen, setIsAssessModalOpen] = useState(false);
  const [isManualFineModalOpen, setIsManualFineModalOpen] = useState(false);
  const [selectedFineForWaive, setSelectedFineForWaive] = useState<AppliedFineRecord | null>(null);
  const [isWaiveFineModalOpen, setIsWaiveFineModalOpen] = useState(false);

  // Tab 5: Audit History
  const [auditLogs, setAuditLogs] = useState<FeeAdjustmentAudit[]>([]);
  const [auditSearch, setAuditSearch] = useState('');
  const [auditTypeFilter, setAuditTypeFilter] = useState('ALL');
  const [auditActionFilter, setAuditActionFilter] = useState('ALL');
  const [isLoadingAudit, setIsLoadingAudit] = useState(false);

  // Fetch initial metadata
  useEffect(() => {
    const fetchMetadata = async () => {
      try {
        const [sessRes, classRes, secRes, ftRes] = await Promise.all([
          api.academic.getSessions(),
          api.academic.getClasses(),
          api.academic.getSections(),
          api.fees.getFeeTypes()
        ]);
        if (sessRes.success && sessRes.data) setSessions(sessRes.data);
        if (classRes.success && classRes.data) setClasses(classRes.data);
        if (secRes.success && secRes.data) setSections(secRes.data);
        if (ftRes.success && ftRes.data) setFeeTypes(ftRes.data);
      } catch (err) {
        console.error('Error fetching metadata:', err);
      }
    };
    fetchMetadata();
  }, []);

  // Fetch Stats
  const fetchStats = useCallback(async () => {
    setIsLoadingStats(true);
    try {
      const res = await api.fees.getAdjustmentStats();
      if (res.success && res.data) {
        setStats(res.data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoadingStats(false);
    }
  }, []);

  // Fetch Tab Specific Data
  const fetchDiscounts = useCallback(async () => {
    setIsLoadingDiscounts(true);
    try {
      const res = await api.fees.getDiscounts({
        search: discountSearch || undefined,
        status: discountStatusFilter !== 'ALL' ? discountStatusFilter : undefined,
        discountType: discountTypeFilter !== 'ALL' ? discountTypeFilter : undefined
      });
      if (res.success && res.data) {
        setDiscounts(res.data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoadingDiscounts(false);
    }
  }, [discountSearch, discountStatusFilter, discountTypeFilter]);

  const fetchWaivers = useCallback(async () => {
    setIsLoadingWaivers(true);
    try {
      const res = await api.fees.getWaivers({
        search: waiverSearch || undefined,
        status: waiverStatusFilter !== 'ALL' ? waiverStatusFilter : undefined
      });
      if (res.success && res.data) {
        setWaivers(res.data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoadingWaivers(false);
    }
  }, [waiverSearch, waiverStatusFilter]);

  const fetchScholarships = useCallback(async () => {
    setIsLoadingScholarships(true);
    try {
      const res = await api.fees.getScholarships({
        search: scholarshipSearch || undefined,
        scholarshipType: scholarshipTypeFilter !== 'ALL' ? scholarshipTypeFilter : undefined
      });
      if (res.success && res.data) {
        setScholarships(res.data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoadingScholarships(false);
    }
  }, [scholarshipSearch, scholarshipTypeFilter]);

  const fetchFinesData = useCallback(async () => {
    setIsLoadingFines(true);
    try {
      const [rulesRes, appliedRes] = await Promise.all([
        api.fees.getFineRules(),
        api.fees.getAppliedFines({
          search: fineSearch || undefined,
          status: fineStatusFilter !== 'ALL' ? fineStatusFilter : undefined
        })
      ]);
      if (rulesRes.success && rulesRes.data) setFineRules(rulesRes.data);
      if (appliedRes.success && appliedRes.data) setAppliedFines(appliedRes.data);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoadingFines(false);
    }
  }, [fineSearch, fineStatusFilter]);

  const fetchAuditLogs = useCallback(async () => {
    setIsLoadingAudit(true);
    try {
      const res = await api.fees.getAdjustmentHistory({
        search: auditSearch || undefined,
        adjustmentType: auditTypeFilter !== 'ALL' ? auditTypeFilter : undefined,
        action: auditActionFilter !== 'ALL' ? auditActionFilter : undefined
      });
      if (res.success && res.data) {
        setAuditLogs(res.data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoadingAudit(false);
    }
  }, [auditSearch, auditTypeFilter, auditActionFilter]);

  // Load data based on active tab
  useEffect(() => {
    fetchStats();
    if (activeTab === 'DISCOUNTS') fetchDiscounts();
    else if (activeTab === 'WAIVERS') fetchWaivers();
    else if (activeTab === 'SCHOLARSHIPS') fetchScholarships();
    else if (activeTab === 'FINES') fetchFinesData();
    else if (activeTab === 'AUDIT_TRAIL') fetchAuditLogs();
  }, [activeTab, fetchStats, fetchDiscounts, fetchWaivers, fetchScholarships, fetchFinesData, fetchAuditLogs]);

  // Approve Discount
  const handleApproveDiscount = async (discountId: string) => {
    try {
      const res = await api.fees.approveDiscount(discountId);
      if (res.success) {
        showToast('Discount rule approved and activated', 'success');
        fetchDiscounts();
        fetchStats();
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to approve discount', 'error');
    }
  };

  // Toggle Discount Status
  const handleToggleDiscountStatus = async (discount: FeeDiscountRule) => {
    const nextStatus = discount.status === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE';
    try {
      const res = await api.fees.updateDiscountStatus(discount.id, nextStatus);
      if (res.success) {
        showToast(`Discount rule status changed to ${nextStatus}`, 'success');
        fetchDiscounts();
        fetchStats();
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to update discount status', 'error');
    }
  };

  // Delete Discount
  const handleDeleteDiscount = async (discount: FeeDiscountRule) => {
    if (!window.confirm(`Are you sure you want to delete discount rule "${discount.name}"?`)) return;
    try {
      const res = await api.fees.deleteDiscount(discount.id);
      if (res.success) {
        showToast('Discount rule deleted', 'success');
        fetchDiscounts();
        fetchStats();
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to delete discount rule', 'error');
    }
  };

  // Approve Waiver
  const handleApproveWaiver = async (waiverId: string) => {
    try {
      const res = await api.fees.approveWaiver(waiverId, { notes: 'Approved in Admin Fee Adjustments Desk' });
      if (res.success) {
        showToast('Waiver approved and applied to invoice balance', 'success');
        fetchWaivers();
        fetchStats();
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to approve waiver', 'error');
    }
  };

  // Reject Waiver
  const handleRejectWaiver = async (waiverId: string) => {
    const reason = window.prompt('Please enter a rejection reason:', 'Policy limits exceeded / Ineligible');
    if (reason === null) return;
    try {
      const res = await api.fees.rejectWaiver(waiverId, { rejectionReason: reason });
      if (res.success) {
        showToast('Waiver request rejected', 'info');
        fetchWaivers();
        fetchStats();
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to reject waiver', 'error');
    }
  };

  // Cancel Waiver
  const handleCancelWaiver = async (waiverId: string) => {
    if (!window.confirm('Cancel this waiver? The waived amount will be restored to the net invoice balance.')) return;
    try {
      const res = await api.fees.cancelWaiver(waiverId);
      if (res.success) {
        showToast('Waiver cancelled and invoice recalculated', 'success');
        fetchWaivers();
        fetchStats();
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to cancel waiver', 'error');
    }
  };

  // Approve Scholarship
  const handleApproveScholarship = async (scholarshipId: string) => {
    try {
      const res = await api.fees.approveScholarship(scholarshipId);
      if (res.success) {
        showToast('Scholarship award approved and activated', 'success');
        fetchScholarships();
        fetchStats();
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to approve scholarship', 'error');
    }
  };

  // Delete Scholarship
  const handleDeleteScholarship = async (scholarship: FeeScholarship) => {
    if (!window.confirm(`Revoke / Delete scholarship award "${scholarship.scholarshipName}"?`)) return;
    try {
      const res = await api.fees.deleteScholarship(scholarship.id);
      if (res.success) {
        showToast('Scholarship removed', 'success');
        fetchScholarships();
        fetchStats();
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to remove scholarship', 'error');
    }
  };

  // Toggle Fine Rule Status
  const handleToggleFineRuleStatus = async (rule: FeeFineRule) => {
    const next = rule.status === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE';
    try {
      const res = await api.fees.updateFineRuleStatus(rule.id, next);
      if (res.success) {
        showToast(`Policy status updated to ${next}`, 'success');
        fetchFinesData();
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to update rule status', 'error');
    }
  };

  return (
    <div className="space-y-6">
      {/* Overview Cards Header */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Discounts */}
        <div className="p-4 bg-slate-900/80 border border-white/10 rounded-2xl relative overflow-hidden backdrop-blur-md">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400">Total Discounts Granted</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Percent className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-white">
              ${stats ? stats.discounts.totalDisbursed.toLocaleString('en-US', { minimumFractionDigits: 2 }) : '0.00'}
            </span>
          </div>
          <div className="mt-2 text-[11px] text-slate-400 flex items-center justify-between">
            <span>Active Rules: {stats?.discounts.activeRulesCount || 0}</span>
            <span>Applied: {stats?.discounts.totalApplications || 0}</span>
          </div>
        </div>

        {/* Card 2: Waivers */}
        <div className="p-4 bg-slate-900/80 border border-white/10 rounded-2xl relative overflow-hidden backdrop-blur-md">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400">Approved Fee Waivers</span>
            <div className="w-8 h-8 rounded-lg bg-teal-500/15 border border-teal-500/30 flex items-center justify-center text-teal-400">
              <ShieldCheck className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-teal-300">
              ${stats ? stats.waivers.totalAmountWaived.toLocaleString('en-US', { minimumFractionDigits: 2 }) : '0.00'}
            </span>
          </div>
          <div className="mt-2 text-[11px] text-slate-400 flex items-center justify-between">
            <span>Approved: {stats?.waivers.approvedCount || 0}</span>
            <span className="text-amber-400">Pending: {stats?.waivers.pendingCount || 0}</span>
          </div>
        </div>

        {/* Card 3: Scholarships */}
        <div className="p-4 bg-slate-900/80 border border-white/10 rounded-2xl relative overflow-hidden backdrop-blur-md">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400">Scholarship Aid</span>
            <div className="w-8 h-8 rounded-lg bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Award className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-amber-300">
              ${stats ? stats.scholarships.totalDisbursed.toLocaleString('en-US', { minimumFractionDigits: 2 }) : '0.00'}
            </span>
          </div>
          <div className="mt-2 text-[11px] text-slate-400 flex items-center justify-between">
            <span>Recipients: {stats?.scholarships.uniqueRecipients || 0}</span>
            <span>Active Grants: {stats?.scholarships.activeCount || 0}</span>
          </div>
        </div>

        {/* Card 4: Fines */}
        <div className="p-4 bg-slate-900/80 border border-white/10 rounded-2xl relative overflow-hidden backdrop-blur-md">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400">Late Fines & Penalties</span>
            <div className="w-8 h-8 rounded-lg bg-rose-500/15 border border-rose-500/30 flex items-center justify-center text-rose-400">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-rose-300">
              ${stats ? stats.fines.totalFinesAssessed.toLocaleString('en-US', { minimumFractionDigits: 2 }) : '0.00'}
            </span>
          </div>
          <div className="mt-2 text-[11px] text-slate-400 flex items-center justify-between">
            <span>Active Fines: {stats?.fines?.activeFinesCount || 0}</span>
            <span className="text-teal-400">Waived: ${Number(stats?.fines?.totalFinesWaived ?? 0).toFixed(2)}</span>
          </div>
        </div>
      </div>

      {/* Navigation Tabs Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 pb-4">
        {!hideTabBar && (
          <div className="flex items-center gap-1.5 p-1 bg-slate-950/80 border border-white/10 rounded-xl overflow-x-auto">
            <button
              onClick={() => setActiveTab('DISCOUNTS')}
              className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 ${
                activeTab === 'DISCOUNTS'
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Percent className="w-3.5 h-3.5" />
              <span>Discounts Hub</span>
              {stats && (
                <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-white/10 text-slate-300">
                  {stats.discounts.activeRulesCount}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('WAIVERS')}
              className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 ${
                activeTab === 'WAIVERS'
                  ? 'bg-teal-500/20 text-teal-300 border border-teal-500/40 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Fee Waivers Desk</span>
              {stats && stats.waivers.pendingCount > 0 && (
                <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-amber-500/20 text-amber-300 border border-amber-500/30 font-bold">
                  {stats.waivers.pendingCount}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('SCHOLARSHIPS')}
              className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 ${
                activeTab === 'SCHOLARSHIPS'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Award className="w-3.5 h-3.5" />
              <span>Scholarships & Grants</span>
            </button>

            <button
              onClick={() => setActiveTab('FINES')}
              className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 ${
                activeTab === 'FINES'
                  ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>Late Fines & Penalties</span>
            </button>

            <button
              onClick={() => setActiveTab('AUDIT_TRAIL')}
              className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 ${
                activeTab === 'AUDIT_TRAIL'
                  ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <History className="w-3.5 h-3.5" />
              <span>Adjustment Audit Log</span>
            </button>
          </div>
        )}

        {/* Tab Action Buttons */}
        <div className="flex items-center gap-2">
          {activeTab === 'DISCOUNTS' && (
            <button
              onClick={() => {
                setSelectedDiscountForEdit(null);
                setIsDiscountModalOpen(true);
              }}
              className="px-3.5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 rounded-xl shadow-md shadow-emerald-600/20 transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Create Discount Rule</span>
            </button>
          )}

          {activeTab === 'WAIVERS' && (
            <button
              onClick={() => setIsWaiverModalOpen(true)}
              className="px-3.5 py-2 text-xs font-bold text-white bg-teal-600 hover:bg-teal-500 rounded-xl shadow-md shadow-teal-600/20 transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Grant / Request Waiver</span>
            </button>
          )}

          {activeTab === 'SCHOLARSHIPS' && (
            <button
              onClick={() => {
                setSelectedScholarshipForEdit(null);
                setIsScholarshipModalOpen(true);
              }}
              className="px-3.5 py-2 text-xs font-bold text-white bg-amber-600 hover:bg-amber-500 rounded-xl shadow-md shadow-amber-600/20 transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Award Scholarship</span>
            </button>
          )}

          {activeTab === 'FINES' && (
            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsAssessModalOpen(true)}
                className="px-3.5 py-2 text-xs font-bold text-white bg-rose-700 hover:bg-rose-600 rounded-xl shadow-md shadow-rose-700/20 transition-all flex items-center gap-1.5 cursor-pointer"
              >
                <Play className="w-3.5 h-3.5" />
                <span>Run Late Assessment</span>
              </button>
              <button
                onClick={() => setIsManualFineModalOpen(true)}
                className="px-3 py-2 text-xs font-bold text-slate-200 bg-white/10 hover:bg-white/20 rounded-xl transition-all flex items-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Manual Fine</span>
              </button>
              <button
                onClick={() => {
                  setSelectedRuleForEdit(null);
                  setIsFineRuleModalOpen(true);
                }}
                className="px-3 py-2 text-xs font-bold text-slate-200 bg-white/10 hover:bg-white/20 rounded-xl transition-all flex items-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Fine Rule</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* ========================================================
          TAB 1: DISCOUNTS HUB
         ======================================================== */}
      {activeTab === 'DISCOUNTS' && (
        <div className="space-y-4">
          {/* Filters Bar */}
          <div className="p-4 bg-slate-900/60 border border-white/10 rounded-2xl backdrop-blur-md flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="relative w-full sm:w-72">
              <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
              <input
                type="text"
                value={discountSearch}
                onChange={(e) => setDiscountSearch(e.target.value)}
                placeholder="Search discount rules..."
                className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-950 border border-white/10 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <select
                value={discountStatusFilter}
                onChange={(e) => setDiscountStatusFilter(e.target.value)}
                className="px-3 py-1.5 text-xs bg-slate-950 border border-white/10 rounded-xl text-white focus:outline-none"
              >
                <option value="ALL">All Statuses</option>
                <option value="ACTIVE">Active</option>
                <option value="INACTIVE">Inactive</option>
              </select>

              <select
                value={discountTypeFilter}
                onChange={(e) => setDiscountTypeFilter(e.target.value)}
                className="px-3 py-1.5 text-xs bg-slate-950 border border-white/10 rounded-xl text-white focus:outline-none"
              >
                <option value="ALL">All Types</option>
                <option value="PERCENTAGE">Percentage (%)</option>
                <option value="FIXED">Fixed Amount ($)</option>
              </select>

              <button
                onClick={fetchDiscounts}
                className="p-1.5 text-slate-400 hover:text-white bg-white/5 hover:bg-white/10 rounded-xl transition-colors cursor-pointer"
                title="Refresh"
              >
                <RefreshCw className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Discounts Table */}
          <div className="bg-slate-900/80 border border-white/10 rounded-2xl overflow-hidden backdrop-blur-md">
            {isLoadingDiscounts ? (
              <div className="p-12 text-center text-xs text-slate-400">Loading discount policies...</div>
            ) : discounts.length === 0 ? (
              <div className="p-12 text-center text-xs text-slate-400 space-y-2">
                <Percent className="w-8 h-8 text-slate-600 mx-auto" />
                <p>No discount rules found matching the criteria.</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-950/70 border-b border-white/10 text-slate-400">
                    <tr>
                      <th className="px-4 py-3 font-semibold">Rule Name & Code</th>
                      <th className="px-4 py-3 font-semibold">Type & Value</th>
                      <th className="px-4 py-3 font-semibold">Scope & Fee Type</th>
                      <th className="px-4 py-3 font-semibold">Academic Session</th>
                      <th className="px-4 py-3 font-semibold">Approval & Status</th>
                      <th className="px-4 py-3 font-semibold text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {discounts.map((disc) => (
                      <tr key={disc.id} className="hover:bg-white/[0.02] transition-colors">
                        <td className="px-4 py-3">
                          <div className="font-bold text-white">{disc.name}</div>
                          <div className="flex items-center gap-1.5 mt-0.5">
                            <span className="font-mono text-[10px] text-emerald-400 bg-emerald-500/10 px-1.5 py-0.2 rounded border border-emerald-500/20">
                              {disc.code}
                            </span>
                            {disc.description && (
                              <span className="text-[11px] text-slate-400 truncate max-w-xs">
                                {disc.description}
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          <span className="font-mono font-bold text-emerald-400 text-sm">
                            {disc.discountType === 'PERCENTAGE' ? `${disc.value}%` : `$${Number(disc.value ?? 0).toFixed(2)}`}
                          </span>
                          <p className="text-[10px] text-slate-400">
                            {disc.discountType === 'PERCENTAGE' ? 'Percentage Deduction' : 'Fixed Flat Amount'}
                          </p>
                        </td>
                        <td className="px-4 py-3">
                          <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-white/5 border border-white/10 text-slate-300">
                            {disc.scope}
                          </span>
                          <p className="text-[11px] text-slate-400 mt-1">
                            Fee: <span className="text-slate-200">{disc.applicableFeeType || 'All Types'}</span>
                          </p>
                        </td>
                        <td className="px-4 py-3 text-slate-300">
                          <div>{disc.academicSessionName}</div>
                          <div className="text-[10px] text-slate-400">
                            {disc.startDate} → {disc.endDate}
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-1.5">
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                                disc.status === 'ACTIVE'
                                  ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30'
                                  : 'bg-slate-800 text-slate-400 border-white/10'
                              }`}
                            >
                              {disc.status}
                            </span>
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                                disc.approvalStatus === 'APPROVED'
                                  ? 'bg-blue-500/15 text-blue-400 border-blue-500/30'
                                  : 'bg-amber-500/15 text-amber-400 border-amber-500/30'
                              }`}
                            >
                              {disc.approvalStatus}
                            </span>
                          </div>
                        </td>
                        <td className="px-4 py-3 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            {disc.approvalStatus === 'PENDING' && (
                              <button
                                onClick={() => handleApproveDiscount(disc.id)}
                                className="px-2.5 py-1 text-[11px] font-bold text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-colors cursor-pointer"
                                title="Approve rule"
                              >
                                Approve
                              </button>
                            )}

                            <button
                              onClick={() => {
                                setSelectedDiscountForBatch(disc);
                                setIsBatchModalOpen(true);
                              }}
                              className="px-2.5 py-1 text-[11px] font-bold text-indigo-300 bg-indigo-500/10 hover:bg-indigo-500/20 border border-indigo-500/30 rounded-lg transition-colors cursor-pointer flex items-center gap-1"
                              title="Batch apply to open student invoices"
                            >
                              <Layers className="w-3 h-3" /> Batch Apply
                            </button>

                            <button
                              onClick={() => handleToggleDiscountStatus(disc)}
                              className="p-1 text-slate-400 hover:text-slate-200 bg-white/5 hover:bg-white/10 rounded-lg transition-colors cursor-pointer"
                              title={disc.status === 'ACTIVE' ? 'Deactivate' : 'Activate'}
                            >
                              {disc.status === 'ACTIVE' ? (
                                <XCircle className="w-4 h-4 text-amber-400" />
                              ) : (
                                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                              )}
                            </button>

                            <button
                              onClick={() => {
                                setSelectedDiscountForEdit(disc);
                                setIsDiscountModalOpen(true);
                              }}
                              className="p-1 text-slate-400 hover:text-white bg-white/5 hover:bg-white/10 rounded-lg transition-colors cursor-pointer"
                              title="Edit"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>

                            <button
                              onClick={() => handleDeleteDiscount(disc)}
                              className="p-1 text-rose-400 hover:text-rose-300 bg-rose-500/10 hover:bg-rose-500/20 rounded-lg transition-colors cursor-pointer"
                              title="Delete"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================
          TAB 2: WAIVERS DESK
         ======================================================== */}
      {activeTab === 'WAIVERS' && (
        <div className="space-y-4">
          {/* Filters Bar */}
          <div className="p-4 bg-slate-900/60 border border-white/10 rounded-2xl backdrop-blur-md flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="relative w-full sm:w-72">
              <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
              <input
                type="text"
                value={waiverSearch}
                onChange={(e) => setWaiverSearch(e.target.value)}
                placeholder="Search waivers by student or invoice..."
                className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-950 border border-white/10 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-teal-500"
              />
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <select
                value={waiverStatusFilter}
                onChange={(e) => setWaiverStatusFilter(e.target.value)}
                className="px-3 py-1.5 text-xs bg-slate-950 border border-white/10 rounded-xl text-white focus:outline-none"
              >
                <option value="ALL">All Statuses</option>
                <option value="APPROVED">Approved</option>
                <option value="PENDING">Pending</option>
                <option value="REJECTED">Rejected</option>
                <option value="CANCELLED">Cancelled</option>
              </select>

              <button
                onClick={fetchWaivers}
                className="p-1.5 text-slate-400 hover:text-white bg-white/5 hover:bg-white/10 rounded-xl transition-colors cursor-pointer"
                title="Refresh"
              >
                <RefreshCw className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Waivers Table */}
          <div className="bg-slate-900/80 border border-white/10 rounded-2xl overflow-hidden backdrop-blur-md">
            {isLoadingWaivers ? (
              <div className="p-12 text-center text-xs text-slate-400">Loading fee waivers...</div>
            ) : waivers.length === 0 ? (
              <div className="p-12 text-center text-xs text-slate-400 space-y-2">
                <ShieldCheck className="w-8 h-8 text-slate-600 mx-auto" />
                <p>No fee waivers found matching the criteria.</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-950/70 border-b border-white/10 text-slate-400">
                    <tr>
                      <th className="px-4 py-3 font-semibold">Waiver No. & Student</th>
                      <th className="px-4 py-3 font-semibold">Target Invoice</th>
                      <th className="px-4 py-3 font-semibold">Waiver Type & Amount</th>
                      <th className="px-4 py-3 font-semibold">Justification Reason</th>
                      <th className="px-4 py-3 font-semibold">Status & Date</th>
                      <th className="px-4 py-3 font-semibold text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {waivers.map((w) => (
                      <tr key={w.id} className="hover:bg-white/[0.02] transition-colors">
                        <td className="px-4 py-3">
                          <div className="font-bold text-white">{w.studentName}</div>
                          <div className="flex items-center gap-1.5 mt-0.5">
                            <span className="font-mono text-[10px] text-teal-400 bg-teal-500/10 px-1.5 py-0.2 rounded border border-teal-500/20">
                              {w.waiverNumber}
                            </span>
                            <span className="text-[10px] text-slate-400">{w.admissionNumber}</span>
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          <div className="font-mono text-slate-200">{w.invoiceNumber}</div>
                          <div className="text-[10px] text-slate-400">{w.className}</div>
                        </td>
                        <td className="px-4 py-3">
                          <span className="font-mono font-bold text-teal-300 text-sm">
                            ${Number(w.amount ?? 0).toFixed(2)}
                          </span>
                          <p className="text-[10px] text-slate-400">{(w.waiverType || 'STANDARD').replace(/_/g, ' ')}</p>
                        </td>
                        <td className="px-4 py-3 max-w-xs">
                          <div className="text-slate-200 truncate">{w.reason}</div>
                          {w.notes && <div className="text-[10px] text-slate-400 truncate">{w.notes}</div>}
                          {w.rejectionReason && (
                            <div className="text-[10px] text-rose-400 font-semibold truncate">
                              Rejected: {w.rejectionReason}
                            </div>
                          )}
                        </td>
                        <td className="px-4 py-3">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                              w.status === 'APPROVED'
                                ? 'bg-teal-500/15 text-teal-400 border-teal-500/30'
                                : w.status === 'PENDING'
                                ? 'bg-amber-500/15 text-amber-400 border-amber-500/30'
                                : w.status === 'REJECTED'
                                ? 'bg-rose-500/15 text-rose-400 border-rose-500/30'
                                : 'bg-slate-800 text-slate-400 border-white/10'
                            }`}
                          >
                            {w.status}
                          </span>
                          <p className="text-[10px] text-slate-400 mt-0.5">
                            {new Date(w.createdAt).toLocaleDateString()}
                          </p>
                        </td>
                        <td className="px-4 py-3 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            {w.status === 'PENDING' && (
                              <>
                                <button
                                  onClick={() => handleApproveWaiver(w.id)}
                                  className="px-2.5 py-1 text-[11px] font-bold text-white bg-teal-600 hover:bg-teal-500 rounded-lg transition-colors cursor-pointer"
                                >
                                  Approve
                                </button>
                                <button
                                  onClick={() => handleRejectWaiver(w.id)}
                                  className="px-2.5 py-1 text-[11px] font-bold text-rose-300 bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 rounded-lg transition-colors cursor-pointer"
                                >
                                  Reject
                                </button>
                              </>
                            )}

                            {w.status === 'APPROVED' && (
                              <button
                                onClick={() => handleCancelWaiver(w.id)}
                                className="px-2 py-1 text-[11px] font-medium text-slate-400 hover:text-rose-400 bg-white/5 hover:bg-rose-500/10 rounded-lg transition-colors cursor-pointer"
                                title="Cancel waiver"
                              >
                                Cancel Waiver
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================
          TAB 3: SCHOLARSHIPS & ENDOWMENTS
         ======================================================== */}
      {activeTab === 'SCHOLARSHIPS' && (
        <div className="space-y-4">
          {/* Filters Bar */}
          <div className="p-4 bg-slate-900/60 border border-white/10 rounded-2xl backdrop-blur-md flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="relative w-full sm:w-72">
              <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
              <input
                type="text"
                value={scholarshipSearch}
                onChange={(e) => setScholarshipSearch(e.target.value)}
                placeholder="Search scholarship grants..."
                className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-950 border border-white/10 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
              />
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <select
                value={scholarshipTypeFilter}
                onChange={(e) => setScholarshipTypeFilter(e.target.value)}
                className="px-3 py-1.5 text-xs bg-slate-950 border border-white/10 rounded-xl text-white focus:outline-none"
              >
                <option value="ALL">All Categories</option>
                <option value="MERIT">Merit / Academic</option>
                <option value="NEED_BASED">Need-Based Aid</option>
                <option value="SPORTS">Sports & Athletics</option>
                <option value="SPECIAL_TALENT">Creative Arts</option>
                <option value="GOVERNMENT_ENDOWMENT">Government / Endowment</option>
              </select>

              <button
                onClick={fetchScholarships}
                className="p-1.5 text-slate-400 hover:text-white bg-white/5 hover:bg-white/10 rounded-xl transition-colors cursor-pointer"
                title="Refresh"
              >
                <RefreshCw className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Scholarships Table */}
          <div className="bg-slate-900/80 border border-white/10 rounded-2xl overflow-hidden backdrop-blur-md">
            {isLoadingScholarships ? (
              <div className="p-12 text-center text-xs text-slate-400">Loading scholarship allocations...</div>
            ) : scholarships.length === 0 ? (
              <div className="p-12 text-center text-xs text-slate-400 space-y-2">
                <Award className="w-8 h-8 text-slate-600 mx-auto" />
                <p>No scholarships found matching the criteria.</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-950/70 border-b border-white/10 text-slate-400">
                    <tr>
                      <th className="px-4 py-3 font-semibold">Scholarship & Awardee</th>
                      <th className="px-4 py-3 font-semibold">Coverage & Value</th>
                      <th className="px-4 py-3 font-semibold">Category & Sponsor</th>
                      <th className="px-4 py-3 font-semibold">Disbursed Total</th>
                      <th className="px-4 py-3 font-semibold">Status</th>
                      <th className="px-4 py-3 font-semibold text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {scholarships.map((sch) => (
                      <tr key={sch.id} className="hover:bg-white/[0.02] transition-colors">
                        <td className="px-4 py-3">
                          <div className="font-bold text-white">{sch.scholarshipName}</div>
                          <div className="text-[11px] text-amber-300/90 font-medium">
                            {sch.studentName} ({sch.admissionNumber})
                          </div>
                          <div className="text-[10px] text-slate-400">{sch.className}</div>
                        </td>
                        <td className="px-4 py-3">
                          <span className="font-mono font-bold text-amber-400 text-sm">
                            {sch.coverageType === 'PERCENTAGE' ? `${sch.value}%` : `$${Number(sch.value ?? 0).toFixed(2)}`}
                          </span>
                          <p className="text-[10px] text-slate-400">{sch.applicableFeeType || 'All Fee Types'}</p>
                        </td>
                        <td className="px-4 py-3">
                          <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-500/10 text-amber-300 border border-amber-500/30">
                            {(sch.scholarshipType || 'MERIT').replace(/_/g, ' ')}
                          </span>
                          {sch.sponsorName && (
                            <p className="text-[10px] text-slate-400 mt-1">Sponsor: {sch.sponsorName}</p>
                          )}
                        </td>
                        <td className="px-4 py-3">
                          <span className="font-mono font-bold text-white">
                            ${Number(sch.disbursedAmount ?? 0).toFixed(2)}
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                              sch.status === 'ACTIVE'
                                ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30'
                                : sch.status === 'PENDING'
                                ? 'bg-amber-500/15 text-amber-400 border-amber-500/30'
                                : 'bg-slate-800 text-slate-400 border-white/10'
                            }`}
                          >
                            {sch.status}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            {sch.status === 'PENDING' && (
                              <button
                                onClick={() => handleApproveScholarship(sch.id)}
                                className="px-2.5 py-1 text-[11px] font-bold text-white bg-amber-600 hover:bg-amber-500 rounded-lg transition-colors cursor-pointer"
                              >
                                Approve
                              </button>
                            )}

                            <button
                              onClick={() => {
                                setSelectedScholarshipForEdit(sch);
                                setIsScholarshipModalOpen(true);
                              }}
                              className="p-1 text-slate-400 hover:text-white bg-white/5 hover:bg-white/10 rounded-lg transition-colors cursor-pointer"
                              title="Edit"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>

                            <button
                              onClick={() => handleDeleteScholarship(sch)}
                              className="p-1 text-rose-400 hover:text-rose-300 bg-rose-500/10 hover:bg-rose-500/20 rounded-lg transition-colors cursor-pointer"
                              title="Delete"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================
          TAB 4: LATE FINES & PENALTIES
         ======================================================== */}
      {activeTab === 'FINES' && (
        <div className="space-y-6">
          {/* Sub-Section A: Active Fine Policy Rules */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-400" />
                <span>Late Fee Policy Rules</span>
              </h3>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {fineRules.map((rule) => (
                <div
                  key={rule.id}
                  className="p-4 bg-slate-900/80 border border-white/10 rounded-2xl relative overflow-hidden backdrop-blur-md space-y-3"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-xs text-white">{rule.ruleName}</span>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                        rule.status === 'ACTIVE'
                          ? 'bg-rose-500/15 text-rose-400 border-rose-500/30'
                          : 'bg-slate-800 text-slate-400 border-white/10'
                      }`}
                    >
                      {rule.status}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-xs text-slate-300 pt-2 border-t border-white/5">
                    <div>
                      <span className="text-slate-400">Formula:</span>{' '}
                      <span className="font-semibold text-rose-300">
                        {rule.fineType === 'DAILY_FIXED'
                          ? `$${rule.amount}/day`
                          : rule.fineType === 'PERCENTAGE'
                          ? `${rule.amount}%`
                          : `$${rule.amount} flat`}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-400">Grace:</span>{' '}
                      <span className="font-semibold text-white">{rule.gracePeriodDays} days</span>
                    </div>
                    {rule.maxFineLimit && (
                      <div className="col-span-2">
                        <span className="text-slate-400">Cap Limit:</span>{' '}
                        <span className="font-mono text-slate-200">${Number(rule.maxFineLimit ?? 0).toFixed(2)}</span>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center justify-end gap-2 pt-2 border-t border-white/5">
                    <button
                      onClick={() => handleToggleFineRuleStatus(rule)}
                      className="px-2 py-1 text-[10px] font-bold text-slate-300 bg-white/5 hover:bg-white/10 rounded-lg transition-colors cursor-pointer"
                    >
                      {rule.status === 'ACTIVE' ? 'Deactivate' : 'Activate'}
                    </button>
                    <button
                      onClick={() => {
                        setSelectedRuleForEdit(rule);
                        setIsFineRuleModalOpen(true);
                      }}
                      className="p-1 text-slate-400 hover:text-white bg-white/5 hover:bg-white/10 rounded-lg transition-colors cursor-pointer"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Sub-Section B: Applied Fines Table */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <Clock className="w-4 h-4 text-slate-400" />
                <span>Assessed & Applied Student Penalties</span>
              </h3>
            </div>

            {/* Filters */}
            <div className="p-4 bg-slate-900/60 border border-white/10 rounded-2xl backdrop-blur-md flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="relative w-full sm:w-72">
                <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                <input
                  type="text"
                  value={fineSearch}
                  onChange={(e) => setFineSearch(e.target.value)}
                  placeholder="Search penalties by student or invoice..."
                  className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-950 border border-white/10 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-rose-500"
                />
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto">
                <select
                  value={fineStatusFilter}
                  onChange={(e) => setFineStatusFilter(e.target.value)}
                  className="px-3 py-1.5 text-xs bg-slate-950 border border-white/10 rounded-xl text-white focus:outline-none"
                >
                  <option value="ALL">All Fine Statuses</option>
                  <option value="APPLIED">Applied (Active)</option>
                  <option value="WAIVED">Waived (Exempt)</option>
                </select>

                <button
                  onClick={fetchFinesData}
                  className="p-1.5 text-slate-400 hover:text-white bg-white/5 hover:bg-white/10 rounded-xl transition-colors cursor-pointer"
                  title="Refresh"
                >
                  <RefreshCw className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Table */}
            <div className="bg-slate-900/80 border border-white/10 rounded-2xl overflow-hidden backdrop-blur-md">
              {isLoadingFines ? (
                <div className="p-12 text-center text-xs text-slate-400">Loading fine assessments...</div>
              ) : appliedFines.length === 0 ? (
                <div className="p-12 text-center text-xs text-slate-400 space-y-2">
                  <AlertTriangle className="w-8 h-8 text-slate-600 mx-auto" />
                  <p>No applied student fines found matching filters.</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-950/70 border-b border-white/10 text-slate-400">
                      <tr>
                        <th className="px-4 py-3 font-semibold">Student & Invoice</th>
                        <th className="px-4 py-3 font-semibold">Fine Type & Amount</th>
                        <th className="px-4 py-3 font-semibold">Days Overdue / Reason</th>
                        <th className="px-4 py-3 font-semibold">Assessed Date</th>
                        <th className="px-4 py-3 font-semibold">Status</th>
                        <th className="px-4 py-3 font-semibold text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                      {appliedFines.map((af) => (
                        <tr key={af.id} className="hover:bg-white/[0.02] transition-colors">
                          <td className="px-4 py-3">
                            <div className="font-bold text-white">{af.studentName}</div>
                            <div className="flex items-center gap-1.5 text-[10px] text-slate-400">
                              <span className="font-mono text-slate-200">{af.invoiceNumber}</span>
                              <span>• {af.className}</span>
                            </div>
                          </td>
                          <td className="px-4 py-3">
                            <span className="font-mono font-bold text-rose-400 text-sm">
                              +${Number(af.amount ?? 0).toFixed(2)}
                            </span>
                            <p className="text-[10px] text-slate-400">{(af.fineType || 'LATE_FEE').replace(/_/g, ' ')}</p>
                          </td>
                          <td className="px-4 py-3 max-w-xs">
                            <div className="text-slate-200 truncate">{af.reason}</div>
                            {af.daysOverdue !== undefined && (
                              <p className="text-[10px] text-rose-300">{af.daysOverdue} days past due date</p>
                            )}
                            {af.waiveReason && (
                              <p className="text-[10px] text-teal-400 font-semibold truncate">
                                Waive Reason: {af.waiveReason}
                              </p>
                            )}
                          </td>
                          <td className="px-4 py-3 text-slate-300">
                            <div>{new Date(af.createdAt).toLocaleDateString()}</div>
                          </td>
                          <td className="px-4 py-3">
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                                af.status === 'APPLIED'
                                  ? 'bg-rose-500/15 text-rose-400 border-rose-500/30'
                                  : 'bg-teal-500/15 text-teal-400 border-teal-500/30'
                              }`}
                            >
                              {af.status}
                            </span>
                          </td>
                          <td className="px-4 py-3 text-right">
                            {af.status === 'APPLIED' && (
                              <button
                                onClick={() => {
                                  setSelectedFineForWaive(af);
                                  setIsWaiveFineModalOpen(true);
                                }}
                                className="px-2.5 py-1 text-[11px] font-bold text-teal-300 bg-teal-500/10 hover:bg-teal-500/20 border border-teal-500/30 rounded-lg transition-colors cursor-pointer"
                              >
                                Waive Fine
                              </button>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          TAB 5: ADJUSTMENT AUDIT LOG
         ======================================================== */}
      {activeTab === 'AUDIT_TRAIL' && (
        <div className="space-y-4">
          {/* Filters Bar */}
          <div className="p-4 bg-slate-900/60 border border-white/10 rounded-2xl backdrop-blur-md flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="relative w-full sm:w-72">
              <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
              <input
                type="text"
                value={auditSearch}
                onChange={(e) => setAuditSearch(e.target.value)}
                placeholder="Search audit trail..."
                className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-950 border border-white/10 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <select
                value={auditTypeFilter}
                onChange={(e) => setAuditTypeFilter(e.target.value)}
                className="px-3 py-1.5 text-xs bg-slate-950 border border-white/10 rounded-xl text-white focus:outline-none"
              >
                <option value="ALL">All Categories</option>
                <option value="DISCOUNT">Discounts</option>
                <option value="WAIVER">Waivers</option>
                <option value="SCHOLARSHIP">Scholarships</option>
                <option value="FINE">Fines</option>
              </select>

              <select
                value={auditActionFilter}
                onChange={(e) => setAuditActionFilter(e.target.value)}
                className="px-3 py-1.5 text-xs bg-slate-950 border border-white/10 rounded-xl text-white focus:outline-none"
              >
                <option value="ALL">All Actions</option>
                <option value="CREATED">Created</option>
                <option value="APPLIED">Applied</option>
                <option value="APPROVED">Approved</option>
                <option value="REJECTED">Rejected</option>
                <option value="WAIVED">Waived</option>
                <option value="CANCELLED">Cancelled</option>
              </select>

              <button
                onClick={fetchAuditLogs}
                className="p-1.5 text-slate-400 hover:text-white bg-white/5 hover:bg-white/10 rounded-xl transition-colors cursor-pointer"
                title="Refresh"
              >
                <RefreshCw className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Audit Logs Table */}
          <div className="bg-slate-900/80 border border-white/10 rounded-2xl overflow-hidden backdrop-blur-md">
            {isLoadingAudit ? (
              <div className="p-12 text-center text-xs text-slate-400">Loading audit history...</div>
            ) : auditLogs.length === 0 ? (
              <div className="p-12 text-center text-xs text-slate-400 space-y-2">
                <History className="w-8 h-8 text-slate-600 mx-auto" />
                <p>No adjustment audit records found.</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-950/70 border-b border-white/10 text-slate-400">
                    <tr>
                      <th className="px-4 py-3 font-semibold">Timestamp</th>
                      <th className="px-4 py-3 font-semibold">Type & Action</th>
                      <th className="px-4 py-3 font-semibold">Target Entity / Invoice</th>
                      <th className="px-4 py-3 font-semibold">Amount Involved</th>
                      <th className="px-4 py-3 font-semibold">Performed By</th>
                      <th className="px-4 py-3 font-semibold">Details & Reason</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {auditLogs.map((log) => (
                      <tr key={log.id} className="hover:bg-white/[0.02] transition-colors">
                        <td className="px-4 py-3 font-mono text-[11px] text-slate-400 whitespace-nowrap">
                          {new Date(log.timestamp).toLocaleString()}
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-1.5">
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                                log.adjustmentType === 'DISCOUNT'
                                  ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30'
                                  : log.adjustmentType === 'WAIVER'
                                  ? 'bg-teal-500/15 text-teal-400 border-teal-500/30'
                                  : log.adjustmentType === 'SCHOLARSHIP'
                                  ? 'bg-amber-500/15 text-amber-400 border-amber-500/30'
                                  : 'bg-rose-500/15 text-rose-400 border-rose-500/30'
                              }`}
                            >
                              {log.adjustmentType}
                            </span>
                            <span className="px-1.5 py-0.2 rounded text-[10px] font-mono bg-white/5 text-slate-300">
                              {log.action}
                            </span>
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          <div className="font-semibold text-white">
                            {log.studentName || log.invoiceNumber || 'Rule Config'}
                          </div>
                          {log.invoiceNumber && (
                            <span className="font-mono text-[10px] text-slate-400">{log.invoiceNumber}</span>
                          )}
                        </td>
                        <td className="px-4 py-3">
                          {log.amount !== undefined ? (
                            <span
                              className={`font-mono font-bold ${
                                log.adjustmentType === 'FINE' ? 'text-rose-400' : 'text-emerald-400'
                              }`}
                            >
                              {log.adjustmentType === 'FINE' ? '+' : '-'}${Number(log.amount ?? 0).toFixed(2)}
                            </span>
                          ) : (
                            <span className="text-slate-500">—</span>
                          )}
                        </td>
                        <td className="px-4 py-3 text-slate-300">
                          <div>{log.performedByName}</div>
                          <div className="text-[10px] text-slate-400">{log.performedByRole}</div>
                        </td>
                        <td className="px-4 py-3 max-w-xs text-slate-300">
                          <div className="truncate">{log.reason || 'Standard transaction'}</div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Modals */}
      <CreateDiscountModal
        isOpen={isDiscountModalOpen}
        onClose={() => setIsDiscountModalOpen(false)}
        discountToEdit={selectedDiscountForEdit}
        sessions={sessions}
        classes={classes}
        sections={sections}
        feeTypes={feeTypes}
        onSuccess={() => {
          fetchDiscounts();
          fetchStats();
        }}
      />

      <BatchApplyDiscountModal
        isOpen={isBatchModalOpen}
        onClose={() => setIsBatchModalOpen(false)}
        discount={selectedDiscountForBatch}
        onSuccess={() => {
          fetchDiscounts();
          fetchStats();
        }}
      />

      <GrantWaiverModal
        isOpen={isWaiverModalOpen}
        onClose={() => setIsWaiverModalOpen(false)}
        onSuccess={() => {
          fetchWaivers();
          fetchStats();
        }}
      />

      <GrantScholarshipModal
        isOpen={isScholarshipModalOpen}
        onClose={() => setIsScholarshipModalOpen(false)}
        scholarshipToEdit={selectedScholarshipForEdit}
        sessions={sessions}
        feeTypes={feeTypes}
        onSuccess={() => {
          fetchScholarships();
          fetchStats();
        }}
      />

      <CreateFineRuleModal
        isOpen={isFineRuleModalOpen}
        onClose={() => setIsFineRuleModalOpen(false)}
        ruleToEdit={selectedRuleForEdit}
        feeTypes={feeTypes}
        onSuccess={() => {
          fetchFinesData();
        }}
      />

      <AssessLateFinesModal
        isOpen={isAssessModalOpen}
        onClose={() => setIsAssessModalOpen(false)}
        fineRules={fineRules}
        sessions={sessions}
        onSuccess={() => {
          fetchFinesData();
          fetchStats();
        }}
      />

      <ManualFineModal
        isOpen={isManualFineModalOpen}
        onClose={() => setIsManualFineModalOpen(false)}
        onSuccess={() => {
          fetchFinesData();
          fetchStats();
        }}
      />

      <WaiveFineModal
        isOpen={isWaiveFineModalOpen}
        onClose={() => setIsWaiveFineModalOpen(false)}
        fineRecord={selectedFineForWaive}
        onSuccess={() => {
          fetchFinesData();
          fetchStats();
        }}
      />
    </div>
  );
};
