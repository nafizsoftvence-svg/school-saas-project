import React, { useEffect, useState, useCallback } from 'react';
import {
  Users,
  GraduationCap,
  BookOpen,
  Building2,
  ShieldCheck,
  Activity,
  ArrowUpRight,
  Sparkles,
  Calendar,
  Layers,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  Clock,
  ExternalLink,
  ChevronRight,
  Lock,
  Database,
  Globe,
  Settings,
  CalendarDays,
  CheckSquare,
  BarChart3,
  Coins
} from 'lucide-react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '../../components/ui/Card.js';
import { Button } from '../../components/ui/Button.js';
import { Badge } from '../../components/ui/Badge.js';
import { Alert } from '../../components/ui/Alert.js';
import { EmptyState } from '../../components/ui/EmptyState.js';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner.js';
import { api } from '../../services/api.js';
import { SuperAdminDashboardData } from '../../types/index.js';
import { useSettings } from '../../context/SettingsContext.js';

interface AdminDashboardProps {
  onNavigate: (viewId: string) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onNavigate }) => {
  const [data, setData] = useState<SuperAdminDashboardData | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const { settings, activeSession, formatDate } = useSettings();

  const loadDashboard = useCallback(async (isSilent = false) => {
    try {
      if (!isSilent) setLoading(true);
      else setIsRefreshing(true);
      setError(null);

      const res = await api.getAdminDashboard();
      if (res.success && res.data) {
        setData(res.data);
      } else {
        setError(res.error || 'Failed to fetch dashboard telemetry.');
      }
    } catch (err: any) {
      console.error('Error loading admin dashboard:', err);
      setError(err?.message || 'Network communication failure loading dashboard.');
    } finally {
      setLoading(false);
      setIsRefreshing(false);
    }
  }, []);

  useEffect(() => {
    loadDashboard();
  }, [loadDashboard]);

  if (loading) {
    return (
      <div className="py-24 flex flex-col items-center justify-center space-y-4">
        <LoadingSpinner size="lg" message="Loading architecture overview telemetry..." />
        <p className="text-xs text-slate-500">Querying real-time database state and audit registers</p>
      </div>
    );
  }

  if (error && !data) {
    return (
      <div className="py-12 max-w-xl mx-auto space-y-4">
        <Alert variant="error" title="Dashboard Telemetry Error">
          <p className="mb-3">{error}</p>
          <Button
            size="sm"
            variant="glass"
            onClick={() => loadDashboard()}
            leftIcon={<RefreshCw className="w-3.5 h-3.5" />}
          >
            Retry Connection
          </Button>
        </Alert>
      </div>
    );
  }

  const metrics = data?.metrics;
  const isProfileComplete = metrics?.isProfileComplete ?? true;
  const hasActiveSession = Boolean(data?.activeSession);

  return (
    <div className="space-y-8 pb-10">
      {/* Top Welcome Banner */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-blue-50 text-blue-700 border border-blue-200">
              <Sparkles className="w-3 h-3 text-blue-600" />
              Super Admin Command Center
            </span>
            <span className="text-slate-400 text-xs font-mono">•</span>
            <span className="text-xs text-slate-500 font-mono">
              {metrics?.schoolCode || settings?.schoolCode || 'SIA-2026'}
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
            Institutional Dashboard &amp; Overview
          </h1>
          <p className="text-slate-600 text-xs sm:text-sm mt-1 max-w-2xl">
            Real-time statistical overview for {metrics?.schoolName || settings?.schoolName || 'Sygmate International Academy'}. All core partition gates, database schemas, and RBAC policies are active.
          </p>
        </div>

        <div className="flex items-center gap-3 flex-wrap">
          <Button
            id="refresh-dashboard-btn"
            size="sm"
            variant="outline"
            onClick={() => loadDashboard(true)}
            isLoading={isRefreshing}
            leftIcon={<RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />}
          >
            Refresh
          </Button>
          <Button
            id="header-nav-exams-btn"
            size="sm"
            variant="outline"
            leftIcon={<CalendarDays className="w-3.5 h-3.5 text-blue-600" />}
            onClick={() => onNavigate('admin-examinations')}
          >
            Examinations
          </Button>
          <Button
            id="header-nav-settings-btn"
            size="sm"
            variant="outline"
            leftIcon={<Settings className="w-3.5 h-3.5 text-slate-600" />}
            onClick={() => onNavigate('admin-settings')}
          >
            School Settings
          </Button>
          <Button
            id="header-nav-academic-btn"
            size="sm"
            variant="primary"
            leftIcon={<Calendar className="w-3.5 h-3.5" />}
            onClick={() => onNavigate('admin-academic')}
          >
            Academic Structure
          </Button>
        </div>
      </div>

      {/* Profile & Session Setup Alerts (if incomplete) */}
      {!isProfileComplete && (
        <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-2xs">
          <div className="flex items-start gap-3.5">
            <div className="p-2 rounded-xl bg-amber-100 text-amber-700 border border-amber-200 flex-shrink-0 mt-0.5 sm:mt-0">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-amber-900">School Profile Incomplete</h4>
              <p className="text-xs text-amber-800 mt-0.5 leading-relaxed">
                Complete your institution's profile (official contact numbers, address, and branding logo) to ensure consistent reports and student portal branding.
              </p>
            </div>
          </div>
          <Button
            id="alert-complete-profile-btn"
            size="sm"
            variant="outline"
            className="border-amber-300 text-amber-900 hover:bg-amber-100 whitespace-nowrap"
            onClick={() => onNavigate('admin-settings')}
          >
            Complete Profile
          </Button>
        </div>
      )}

      {!hasActiveSession && (
        <div className="bg-rose-50 border border-rose-200 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-2xs">
          <div className="flex items-start gap-3.5">
            <div className="p-2 rounded-xl bg-rose-100 text-rose-700 border border-rose-200 flex-shrink-0 mt-0.5 sm:mt-0">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-rose-900">No Active Academic Session Configured</h4>
              <p className="text-xs text-rose-800 mt-0.5 leading-relaxed">
                No academic session is currently marked as active. Please activate an academic year in Academic Structure to enable regular student routines and attendance.
              </p>
            </div>
          </div>
          <Button
            id="alert-activate-session-btn"
            size="sm"
            variant="outline"
            className="border-rose-300 text-rose-900 hover:bg-rose-100 whitespace-nowrap"
            onClick={() => onNavigate('admin-academic')}
          >
            Manage Academic Sessions
          </Button>
        </div>
      )}

      {/* 4 Primary Statistics Cards (Real Data) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {/* 1. Student Statistics */}
        <div
          id="stat-card-students"
          onClick={() => onNavigate('admin-users')}
          className="bg-white border border-slate-200 hover:border-blue-400 p-6 rounded-2xl shadow-2xs hover:shadow-xs relative overflow-hidden group cursor-pointer transition-all duration-150"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Student Enrollment
            </span>
            <div className="w-8 h-8 rounded-xl bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-600 group-hover:scale-110 transition-transform">
              <GraduationCap className="w-4 h-4" />
            </div>
          </div>

          <div className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
            {metrics?.totalStudents !== undefined ? metrics.totalStudents.toLocaleString() : '0'}
          </div>

          <div className="mt-3 flex items-center gap-2 flex-wrap">
            <span className="inline-flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-800 border border-emerald-200">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-600" />
              {metrics?.activeStudents ?? 0} Active
            </span>
            <span className="inline-flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 border border-slate-200">
              {metrics?.inactiveStudents ?? 0} Inactive
            </span>
          </div>

          <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500 group-hover:text-blue-600 transition-colors">
            <span>View directory</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </div>
        </div>

        {/* 2. Teachers Statistics */}
        <div
          id="stat-card-teachers"
          onClick={() => onNavigate('admin-users')}
          className="bg-white border border-slate-200 hover:border-blue-400 p-6 rounded-2xl shadow-2xs hover:shadow-xs relative overflow-hidden group cursor-pointer transition-all duration-150"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Faculty &amp; Staff
            </span>
            <div className="w-8 h-8 rounded-xl bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-600 group-hover:scale-110 transition-transform">
              <BookOpen className="w-4 h-4" />
            </div>
          </div>

          <div className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
            {metrics?.totalTeachers !== undefined ? metrics.totalTeachers.toLocaleString() : '0'}
          </div>

          <div className="mt-3 flex items-center gap-2 flex-wrap">
            <span className="inline-flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded-md bg-blue-50 text-blue-800 border border-blue-200">
              <span className="w-1.5 h-1.5 rounded-full bg-blue-600" />
              {metrics?.activeTeachers ?? 0} Active
            </span>
            <span className="inline-flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 border border-slate-200">
              {metrics?.inactiveTeachers ?? 0} On Leave
            </span>
          </div>

          <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500 group-hover:text-blue-600 transition-colors">
            <span>View faculty list</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </div>
        </div>

        {/* 3. Academic Structure */}
        <div
          id="stat-card-academic"
          onClick={() => onNavigate('admin-academic')}
          className="bg-white border border-slate-200 hover:border-blue-400 p-6 rounded-2xl shadow-2xs hover:shadow-xs relative overflow-hidden group cursor-pointer transition-all duration-150"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Academic Structure
            </span>
            <div className="w-8 h-8 rounded-xl bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-600 group-hover:scale-110 transition-transform">
              <Layers className="w-4 h-4" />
            </div>
          </div>

          <div className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
            {metrics?.totalClasses !== undefined ? metrics.totalClasses : 0}
            <span className="text-sm font-semibold text-slate-500 ml-1.5">Classes</span>
          </div>

          <div className="mt-3 flex items-center gap-2 flex-wrap">
            <span className="inline-flex items-center text-[11px] font-semibold px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-800 border border-emerald-200">
              {metrics?.totalSections ?? 0} Sections
            </span>
            <span className="inline-flex items-center text-[11px] font-semibold px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 border border-slate-200">
              {metrics?.totalSubjects ?? 0} Subjects
            </span>
          </div>

          <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500 group-hover:text-blue-600 transition-colors">
            <span>Manage structure</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </div>
        </div>

        {/* 4. Active Session & School Info */}
        <div
          id="stat-card-school-info"
          onClick={() => onNavigate('admin-settings')}
          className="bg-white border border-slate-200 hover:border-blue-400 p-6 rounded-2xl shadow-2xs hover:shadow-xs relative overflow-hidden group cursor-pointer transition-all duration-150"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Institutional Status
            </span>
            <div className="w-8 h-8 rounded-xl bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-600 group-hover:scale-110 transition-transform">
              <Building2 className="w-4 h-4" />
            </div>
          </div>

          <div className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight truncate">
            {metrics?.currentAcademicSession || 'No Active Session'}
          </div>

          <div className="mt-3 flex items-center gap-2 flex-wrap">
            <span className="inline-flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-800 border border-emerald-200">
              <CheckCircle2 className="w-3 h-3 text-emerald-600" />
              Health {metrics?.systemHealth || '100%'}
            </span>
            <span className="inline-flex items-center text-[11px] font-mono px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 border border-slate-200">
              {metrics?.schoolType || 'Academic'}
            </span>
          </div>

          <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500 group-hover:text-blue-600 transition-colors">
            <span>Configure settings</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </div>
        </div>
      </div>

      {/* Middle Grid: Quick Actions & Portal Architecture */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Columns: Quick Actions Grid & Institutional Profile Card */}
        <div className="lg:col-span-2 space-y-6">
          {/* Quick Actions Panel */}
          <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-7 shadow-2xs">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-lg font-bold text-slate-900 tracking-tight">Administrative Quick Actions</h3>
                <p className="text-xs text-slate-500">Direct shortcuts to primary management workspaces</p>
              </div>
              <Badge variant="primary">Super Admin</Badge>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3.5">
              <button
                id="quick-action-attendance-reports"
                onClick={() => onNavigate('admin-attendance-reports')}
                className="p-4 rounded-2xl bg-white hover:bg-slate-50 border border-slate-200 hover:border-blue-400 text-left transition-all duration-150 group cursor-pointer shadow-2xs"
              >
                <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 border border-blue-200 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                  <BarChart3 className="w-4 h-4" />
                </div>
                <div className="text-xs font-bold text-slate-900 group-hover:text-blue-600 transition-colors">
                  Attendance Reports
                </div>
                <div className="text-[10px] text-slate-500 mt-0.5">Analytics &amp; Defaulters</div>
              </button>

              <button
                id="quick-action-calendar"
                onClick={() => onNavigate('admin-academic-calendar')}
                className="p-4 rounded-2xl bg-white hover:bg-slate-50 border border-slate-200 hover:border-blue-400 text-left transition-all duration-150 group cursor-pointer shadow-2xs"
              >
                <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 border border-blue-200 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                  <CalendarDays className="w-4 h-4" />
                </div>
                <div className="text-xs font-bold text-slate-900 group-hover:text-blue-600 transition-colors">
                  Academic Calendar
                </div>
                <div className="text-[10px] text-slate-500 mt-0.5">Holidays &amp; Events</div>
              </button>

              <button
                id="quick-action-attendance-settings"
                onClick={() => onNavigate('admin-attendance-settings')}
                className="p-4 rounded-2xl bg-white hover:bg-slate-50 border border-slate-200 hover:border-blue-400 text-left transition-all duration-150 group cursor-pointer shadow-2xs"
              >
                <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                  <CheckSquare className="w-4 h-4" />
                </div>
                <div className="text-xs font-bold text-slate-900 group-hover:text-blue-600 transition-colors">
                  Attendance Rules
                </div>
                <div className="text-[10px] text-slate-500 mt-0.5">Policy &amp; Statuses</div>
              </button>

              <button
                id="quick-action-settings"
                onClick={() => onNavigate('admin-settings')}
                className="p-4 rounded-2xl bg-white hover:bg-slate-50 border border-slate-200 hover:border-blue-400 text-left transition-all duration-150 group cursor-pointer shadow-2xs"
              >
                <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 border border-blue-200 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                  <Settings className="w-4 h-4" />
                </div>
                <div className="text-xs font-bold text-slate-900 group-hover:text-blue-600 transition-colors">
                  School Profile
                </div>
                <div className="text-[10px] text-slate-500 mt-0.5">Branding &amp; Regional</div>
              </button>

              <button
                id="quick-action-academic"
                onClick={() => onNavigate('admin-academic')}
                className="p-4 rounded-2xl bg-white hover:bg-slate-50 border border-slate-200 hover:border-blue-400 text-left transition-all duration-150 group cursor-pointer shadow-2xs"
              >
                <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 border border-blue-200 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                  <Calendar className="w-4 h-4" />
                </div>
                <div className="text-xs font-bold text-slate-900 group-hover:text-blue-600 transition-colors">
                  Academics
                </div>
                <div className="text-[10px] text-slate-500 mt-0.5">Sessions &amp; Classes</div>
              </button>

              <button
                id="quick-action-users"
                onClick={() => onNavigate('admin-users')}
                className="p-4 rounded-2xl bg-white hover:bg-slate-50 border border-slate-200 hover:border-blue-400 text-left transition-all duration-150 group cursor-pointer shadow-2xs"
              >
                <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 border border-blue-200 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                  <Users className="w-4 h-4" />
                </div>
                <div className="text-xs font-bold text-slate-900 group-hover:text-blue-600 transition-colors">
                  User Directory
                </div>
                <div className="text-[10px] text-slate-500 mt-0.5">Students &amp; Faculty</div>
              </button>

              <button
                id="quick-action-rbac"
                onClick={() => onNavigate('admin-rbac')}
                className="p-4 rounded-2xl bg-white hover:bg-slate-50 border border-slate-200 hover:border-blue-400 text-left transition-all duration-150 group cursor-pointer shadow-2xs"
              >
                <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-700 border border-amber-200 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <div className="text-xs font-bold text-slate-900 group-hover:text-blue-600 transition-colors">
                  RBAC Matrix
                </div>
                <div className="text-[10px] text-slate-500 mt-0.5">Role Permissions</div>
              </button>

              <button
                id="quick-action-audit"
                onClick={() => onNavigate('admin-audit')}
                className="p-4 rounded-2xl bg-white hover:bg-slate-50 border border-slate-200 hover:border-blue-400 text-left transition-all duration-150 group cursor-pointer shadow-2xs"
              >
                <div className="w-9 h-9 rounded-xl bg-rose-50 text-rose-700 border border-rose-200 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                  <Activity className="w-4 h-4" />
                </div>
                <div className="text-xs font-bold text-slate-900 group-hover:text-blue-600 transition-colors">
                  Audit Logs
                </div>
                <div className="text-[10px] text-slate-500 mt-0.5">Security Register</div>
              </button>

              <button
                id="quick-action-fees"
                onClick={() => onNavigate('admin-fee-structures')}
                className="p-4 rounded-2xl bg-white hover:bg-slate-50 border border-slate-200 hover:border-blue-400 text-left transition-all duration-150 group cursor-pointer shadow-2xs"
              >
                <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 border border-blue-200 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                  <Coins className="w-4 h-4" />
                </div>
                <div className="text-xs font-bold text-slate-900 group-hover:text-blue-600 transition-colors">
                  Fee Structures
                </div>
                <div className="text-[10px] text-slate-500 mt-0.5">Tuition &amp; Fee Types</div>
              </button>

              <button
                id="quick-action-preview-portal"
                onClick={() => onNavigate('admin-users')}
                className="p-4 rounded-2xl bg-white hover:bg-slate-50 border border-slate-200 hover:border-blue-400 text-left transition-all duration-150 group cursor-pointer shadow-2xs"
              >
                <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 border border-blue-200 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                  <Globe className="w-4 h-4" />
                </div>
                <div className="text-xs font-bold text-slate-900 group-hover:text-blue-600 transition-colors">
                  Personas
                </div>
                <div className="text-[10px] text-slate-500 mt-0.5">Role Switcher Test</div>
              </button>
            </div>
          </div>

          {/* School Profile Summary Card */}
          <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-7 shadow-2xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-4">
              <div className="flex items-center gap-3">
                {settings?.logoUrl ? (
                  <img
                    src={settings.logoUrl}
                    alt="School Logo"
                    className="w-12 h-12 rounded-2xl object-contain bg-slate-50 p-1.5 border border-slate-200"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className="w-12 h-12 rounded-2xl bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-700 font-bold text-lg">
                    {settings?.schoolName ? settings.schoolName.charAt(0) : 'S'}
                  </div>
                )}
                <div>
                  <h3 className="text-base font-bold text-slate-900 tracking-tight">
                    {settings?.schoolName || 'Sygmate International Academy'}
                  </h3>
                  <p className="text-xs text-slate-500 font-mono">
                    Code: {settings?.schoolCode || 'SIA-2026'} • Est. {settings?.establishedYear || 1998}
                  </p>
                </div>
              </div>
              <Button
                id="edit-school-profile-btn"
                size="xs"
                variant="outline"
                onClick={() => onNavigate('admin-settings')}
                leftIcon={<Settings className="w-3.5 h-3.5" />}
              >
                Edit Profile
              </Button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-1 text-xs">
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                <span className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider block">
                  Leadership
                </span>
                <span className="font-bold text-slate-900 block">
                  {settings?.principalName || 'Dr. Evelyn Montgomery'}
                </span>
                <span className="text-[11px] text-slate-500 truncate block">
                  {settings?.principalEmail || 'principal@sygmate.edu'}
                </span>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                <span className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider block">
                  Regional &amp; Currency
                </span>
                <span className="font-bold text-slate-900 block">
                  {settings?.currency || 'USD'} ({settings?.currencySymbol || '$'})
                </span>
                <span className="text-[11px] text-slate-500 truncate block">
                  {settings?.timezone || 'America/New_York (EST)'}
                </span>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                <span className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider block">
                  Campus Address
                </span>
                <span className="font-bold text-slate-900 truncate block">
                  {settings?.city || 'Cambridge'}, {settings?.country || 'United States'}
                </span>
                <span className="text-[11px] text-slate-500 truncate block">
                  {settings?.address || '450 Innovation Parkway'}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Right 1 Column: Architectural Partition Matrix */}
        <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-7 shadow-2xs flex flex-col justify-between space-y-6">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-900 tracking-tight">Portal Partitions</h3>
              <Badge variant="success" dot>
                Online
              </Badge>
            </div>

            <div className="space-y-3">
              <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-blue-700">Super Admin Portal</span>
                  <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-blue-100 text-blue-800 font-semibold">
                    Full Control
                  </span>
                </div>
                <p className="text-[11px] text-slate-600">
                  Settings, RBAC Matrix, Sessions, Classes &amp; Audit Logs.
                </p>
              </div>

              <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-800">Teacher Portal</span>
                  <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-slate-200 text-slate-800 font-semibold">
                    Scoped
                  </span>
                </div>
                <p className="text-[11px] text-slate-600">
                  Assigned Classes, Subject Syllabus &amp; Attendance registers.
                </p>
              </div>

              <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-emerald-800">Student Portal</span>
                  <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-800 font-semibold">
                    Read-Only
                  </span>
                </div>
                <p className="text-[11px] text-slate-600">
                  Timetable Routine, Enrolled Subjects &amp; Bio profile.
                </p>
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-200 space-y-2">
            <div className="flex items-center justify-between text-xs text-slate-500">
              <span>Audit Entries Captured</span>
              <span className="font-mono text-slate-900 font-bold">{metrics?.recentAuditCount || 0}</span>
            </div>
            <div className="flex items-center justify-between text-xs text-slate-500">
              <span>RBAC Engine Status</span>
              <span className="text-emerald-700 font-semibold">Strict Enforced</span>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Security & Activity Audit Feed */}
      <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-2xs">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-6">
          <div>
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 text-blue-600" />
              <h3 className="text-lg font-bold text-slate-900 tracking-tight">Recent Administrative Activity</h3>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Live audit event logs captured by the security verification engine
            </p>
          </div>
          <Button
            id="view-all-audit-logs-btn"
            size="xs"
            variant="outline"
            onClick={() => onNavigate('admin-audit')}
            rightIcon={<ArrowUpRight className="w-3.5 h-3.5" />}
          >
            View Complete Audit Trail
          </Button>
        </div>

        {(data?.recentAuditLogs?.length || 0) === 0 ? (
          <EmptyState
            title="No Activity Recorded Yet"
            description="All administrative actions, settings changes, and logins will automatically be logged here."
          />
        ) : (
          <div className="divide-y divide-slate-100">
            {data.recentAuditLogs.slice(0, 6).map((log) => {
              const actionColors: Record<string, string> = {
                SETTINGS_UPDATE: 'bg-amber-50 text-amber-800 border-amber-200',
                SETTINGS_CHANGE: 'bg-amber-50 text-amber-800 border-amber-200',
                LOGIN: 'bg-blue-50 text-blue-700 border-blue-200',
                LOGOUT: 'bg-slate-100 text-slate-700 border-slate-200',
                CREATE: 'bg-emerald-50 text-emerald-800 border-emerald-200',
                UPDATE: 'bg-blue-50 text-blue-700 border-blue-200',
                DELETE: 'bg-rose-50 text-rose-800 border-rose-200'
              };
              const badgeClass = actionColors[log.action] || 'bg-slate-100 text-slate-700 border-slate-200';

              return (
                <div
                  key={log.id}
                  className="py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-50/80 px-2 rounded-xl transition-colors"
                >
                  <div className="flex items-start sm:items-center gap-3">
                    <span className={`text-[10px] font-mono uppercase font-bold px-2 py-0.5 rounded-md border ${badgeClass}`}>
                      {log.action}
                    </span>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-semibold text-slate-900">
                          {log.userName || log.performedBy || 'System'}
                        </span>
                        <span className="text-[10px] font-mono text-slate-400">
                          [{log.entity || log.entityType || 'SYSTEM'}]
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-600 mt-0.5">{log.details}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 self-end sm:self-auto text-right text-[11px] text-slate-500">
                    <span className="font-mono text-[10px] text-slate-400 hidden md:inline">
                      {log.ipAddress}
                    </span>
                    <span className="text-slate-500 font-medium">
                      {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} • {new Date(log.timestamp).toLocaleDateString()}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
