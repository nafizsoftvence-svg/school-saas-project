import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  ArrowRightLeft,
  GraduationCap,
  Users,
  Search,
  Filter,
  Plus,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  FileBadge,
  FileText,
  Clock,
  Shuffle,
  Eye,
  Calendar,
  Layers,
  Award,
  AlertCircle,
  TrendingUp,
  UserCheck,
  Building,
  RefreshCw,
  Printer
} from 'lucide-react';
import { api } from '../../services/api';
import {
  AcademicSession,
  SchoolClass,
  Section,
  StudentProfile,
  TransferCertificate,
  BulkPromotionBatch
} from '../../types';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner';
import { BulkPromotionWizard } from '../../components/promotions/BulkPromotionWizard';
import { IndividualPromotionModal } from '../../components/promotions/IndividualPromotionModal';
import { InternalTransferModal } from '../../components/promotions/InternalTransferModal';
import { IssueTransferCertificateModal } from '../../components/promotions/IssueTransferCertificateModal';
import { TransferCertificateViewerModal } from '../../components/promotions/TransferCertificateViewerModal';
import { StudentStatusChangeModal } from '../../components/promotions/StudentStatusChangeModal';
import { StudentAcademicTimelineModal } from '../../components/promotions/StudentAcademicTimelineModal';

interface AdminStudentPromotionTransferPageProps {
  activeTab?: 'promotions' | 'transfers' | 'status' | 'enrollments' | 'batches';
  onTabChange?: (tab: string) => void;
  hideTabBar?: boolean;
}

export const AdminStudentPromotionTransferPage: React.FC<AdminStudentPromotionTransferPageProps> = ({
  activeTab: propActiveTab,
  onTabChange,
  hideTabBar = true
}) => {
  const [internalTab, setInternalTab] = useState<'promotions' | 'transfers' | 'status' | 'enrollments' | 'batches'>('promotions');
  const activeTab = propActiveTab || internalTab;
  const setActiveTab = (tab: any) => {
    setInternalTab(tab);
    onTabChange?.(tab);
  };

  // Reference Data
  const [sessions, setSessions] = useState<AcademicSession[]>([]);
  const [classes, setClasses] = useState<SchoolClass[]>([]);
  const [sections, setSections] = useState<Section[]>([]);
  const [students, setStudents] = useState<StudentProfile[]>([]);

  // Page State
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSessionId, setSelectedSessionId] = useState('');
  const [selectedClassId, setSelectedClassId] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('');

  // Data Collections
  const [enrollments, setEnrollments] = useState<any[]>([]);
  const [promotions, setPromotions] = useState<any[]>([]);
  const [transfers, setTransfers] = useState<any[]>([]);
  const [certificates, setCertificates] = useState<TransferCertificate[]>([]);
  const [batches, setBatches] = useState<BulkPromotionBatch[]>([]);

  // Modals
  const [showBulkWizard, setShowBulkWizard] = useState(false);
  const [showIndividualModal, setShowIndividualModal] = useState(false);
  const [showInternalTransferModal, setShowInternalTransferModal] = useState(false);
  const [showIssueTCModal, setShowIssueTCModal] = useState(false);
  const [selectedTC, setSelectedTC] = useState<TransferCertificate | null>(null);
  const [selectedTimelineStudentId, setSelectedTimelineStudentId] = useState<string | null>(null);
  const [statusChangeStudent, setStatusChangeStudent] = useState<StudentProfile | null>(null);

  // Load all foundational data
  const loadData = async () => {
    setLoading(true);
    try {
      const [
        statsRes,
        sessionsRes,
        classesRes,
        sectionsRes,
        studentsRes,
        enrollmentsRes,
        promotionsRes,
        transfersRes,
        certificatesRes,
        batchesRes
      ] = await Promise.all([
        api.promotionsTransfers.getStats(),
        api.getSessions(),
        api.getClasses(),
        api.getSections(),
        api.getStudents(),
        api.promotionsTransfers.getEnrollments(),
        api.promotionsTransfers.getPromotionRecords(),
        api.promotionsTransfers.getTransferRecords(),
        api.promotionsTransfers.getTransferCertificates(),
        api.promotionsTransfers.getPromotionBatches()
      ]);

      if (statsRes.success) setStats(statsRes.stats);
      if (sessionsRes.data) setSessions(sessionsRes.data);
      if (classesRes.data) setClasses(classesRes.data);
      if (sectionsRes.data) setSections(sectionsRes.data);
      if (studentsRes.data) setStudents(studentsRes.data as any);
      if (enrollmentsRes.success) setEnrollments(enrollmentsRes.enrollments);
      if (promotionsRes.success) setPromotions(promotionsRes.promotions);
      if (transfersRes.success) setTransfers(transfersRes.transfers);
      if (certificatesRes.success) setCertificates(certificatesRes.certificates);
      if (batchesRes.success) setBatches(batchesRes.batches);
    } catch (err) {
      console.error('Failed to load promotions/transfers data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // Filtered Students Roster
  const filteredStudents = students.filter((s) => {
    const matchesSearch =
      searchTerm === '' ||
      s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.admissionNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (s.rollNumber && s.rollNumber.toLowerCase().includes(searchTerm.toLowerCase()));

    const matchesClass = !selectedClassId || s.classId === selectedClassId;
    const matchesStatus = !selectedStatus || s.status === selectedStatus;

    return matchesSearch && matchesClass && matchesStatus;
  });

  // Filtered Enrollments
  const filteredEnrollments = enrollments.filter((e) => {
    const matchesSearch =
      searchTerm === '' ||
      (e.studentName && e.studentName.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (e.admissionNumber && e.admissionNumber.toLowerCase().includes(searchTerm.toLowerCase()));

    const matchesClass = !selectedClassId || e.classId === selectedClassId;
    const matchesSession = !selectedSessionId || e.academicSessionId === selectedSessionId;
    const matchesStatus = !selectedStatus || e.status === selectedStatus;

    return matchesSearch && matchesClass && matchesSession && matchesStatus;
  });

  return (
    <div className="space-y-6">
      {/* Top Banner & Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2.5">
            <ArrowRightLeft className="w-7 h-7 text-indigo-400" />
            Student Promotion, Transfer & Status Management
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            PART 9E: Session progression engine, internal section reassignments, official Transfer Certificates, and lifetime status tracking.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setShowBulkWizard(true)}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold flex items-center gap-2 shadow-lg shadow-indigo-600/20 transition-all"
          >
            <Sparkles className="w-4 h-4" />
            Batch Promotion Wizard
          </button>
          <button
            onClick={() => setShowIndividualModal(true)}
            className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-medium flex items-center gap-1.5 transition-colors"
          >
            <GraduationCap className="w-4 h-4 text-indigo-400" />
            Individual Promotion
          </button>
          <button
            onClick={() => setShowInternalTransferModal(true)}
            className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-medium flex items-center gap-1.5 transition-colors"
          >
            <Shuffle className="w-4 h-4 text-amber-400" />
            Internal Transfer
          </button>
          <button
            onClick={() => setShowIssueTCModal(true)}
            className="px-3.5 py-2 bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 rounded-xl text-xs font-medium flex items-center gap-1.5 transition-colors"
          >
            <FileBadge className="w-4 h-4 text-emerald-400" />
            Issue TC
          </button>
        </div>
      </div>

      {/* KPI Stats Grid */}
      {stats && (
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3.5">
          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-4 flex flex-col justify-between">
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Active Students</span>
            <div className="flex items-baseline justify-between mt-2">
              <span className="text-2xl font-bold text-white">{stats.activeStudents}</span>
              <span className="text-xs text-emerald-400 font-medium">Enrolled</span>
            </div>
          </div>

          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-4 flex flex-col justify-between">
            <span className="text-[11px] font-semibold text-indigo-400 uppercase tracking-wider">Promoted Records</span>
            <div className="flex items-baseline justify-between mt-2">
              <span className="text-2xl font-bold text-indigo-300">{stats.totalPromoted}</span>
              <span className="text-xs text-slate-400">Total</span>
            </div>
          </div>

          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-4 flex flex-col justify-between">
            <span className="text-[11px] font-semibold text-amber-400 uppercase tracking-wider">Internal Transfers</span>
            <div className="flex items-baseline justify-between mt-2">
              <span className="text-2xl font-bold text-amber-300">{stats.internalTransfers}</span>
              <span className="text-xs text-slate-400">Reassigned</span>
            </div>
          </div>

          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-4 flex flex-col justify-between">
            <span className="text-[11px] font-semibold text-emerald-400 uppercase tracking-wider">TCs Issued</span>
            <div className="flex items-baseline justify-between mt-2">
              <span className="text-2xl font-bold text-emerald-300">{stats.certificatesIssued}</span>
              <span className="text-xs text-slate-400">Certificates</span>
            </div>
          </div>

          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-4 flex flex-col justify-between col-span-2 sm:col-span-1">
            <span className="text-[11px] font-semibold text-purple-400 uppercase tracking-wider">Special Status</span>
            <div className="flex items-baseline justify-between mt-2">
              <span className="text-2xl font-bold text-purple-300">
                {(stats.suspendedCount || 0) + (stats.withdrawnCount || 0) + (stats.graduatedCount || 0)}
              </span>
              <span className="text-[10px] text-slate-400">Susp / With / Grad</span>
            </div>
          </div>
        </div>
      )}

      {/* Main Tabs Navigation */}
      {!hideTabBar && (
        <div className="border-b border-slate-800 flex items-center gap-2 overflow-x-auto pb-1 text-xs">
          <button
            onClick={() => setActiveTab('promotions')}
            className={`px-4 py-2.5 rounded-xl font-semibold transition-colors flex items-center gap-2 ${
              activeTab === 'promotions'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            Promotion Engine & Records
          </button>

          <button
            onClick={() => setActiveTab('transfers')}
            className={`px-4 py-2.5 rounded-xl font-semibold transition-colors flex items-center gap-2 ${
              activeTab === 'transfers'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <FileBadge className="w-4 h-4" />
            Transfers & Transfer Certificates (TC)
          </button>

          <button
            onClick={() => setActiveTab('status')}
            className={`px-4 py-2.5 rounded-xl font-semibold transition-colors flex items-center gap-2 ${
              activeTab === 'status'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <UserCheck className="w-4 h-4" />
            Status Lifecycle Manager
          </button>

          <button
            onClick={() => setActiveTab('enrollments')}
            className={`px-4 py-2.5 rounded-xl font-semibold transition-colors flex items-center gap-2 ${
              activeTab === 'enrollments'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <Layers className="w-4 h-4" />
            Academic Enrollments Roster
          </button>

          <button
            onClick={() => setActiveTab('batches')}
            className={`px-4 py-2.5 rounded-xl font-semibold transition-colors flex items-center gap-2 ${
              activeTab === 'batches'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <Clock className="w-4 h-4" />
            Batch History & Rollbacks
          </button>
        </div>
      )}

      {/* TAB 1: PROMOTIONS */}
      {activeTab === 'promotions' && (
        <div className="space-y-6">
          {/* Quick Launch Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="bg-white border border-slate-200 rounded-2xl p-5 flex flex-col justify-between shadow-2xs">
              <div>
                <div className="w-10 h-10 rounded-xl bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-600 mb-3 shadow-2xs">
                  <Sparkles className="w-5 h-5" />
                </div>
                <h3 className="font-bold text-slate-900 text-base">Bulk Annual Class Promotion</h3>
                <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                  Evaluate passing criteria (GPA, attendance thresholds, financial clearance), preview dry-run decisions, and commit atomic class-wide advancement.
                </p>
              </div>
              <button
                onClick={() => setShowBulkWizard(true)}
                className="mt-4 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-semibold self-start flex items-center gap-1.5 transition-colors shadow-xs border border-blue-700 cursor-pointer"
              >
                Launch Promotion Wizard
                <ArrowRightLeft className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="bg-white border border-slate-200 rounded-2xl p-5 flex flex-col justify-between shadow-2xs">
              <div>
                <div className="w-10 h-10 rounded-xl bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-600 mb-3 shadow-2xs">
                  <GraduationCap className="w-5 h-5" />
                </div>
                <h3 className="font-bold text-slate-900 text-base">Individual Promotion / Retention</h3>
                <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                  Promote a single student, record grade repeats (retention), or issue accelerated double promotion with administrative override controls.
                </p>
              </div>
              <button
                onClick={() => setShowIndividualModal(true)}
                className="mt-4 px-4 py-2 bg-white hover:bg-slate-50 border border-slate-300 text-slate-800 rounded-xl text-xs font-semibold self-start flex items-center gap-1.5 transition-colors shadow-2xs cursor-pointer"
              >
                Promote Single Student
                <GraduationCap className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Promotion Records Table */}
          <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-2xs">
            <div className="p-4 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Award className="w-4 h-4 text-blue-600" />
                Historical Promotion Transactions ({promotions.length})
              </h3>
              <button
                onClick={loadData}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 self-start sm:self-auto"
              >
                <RefreshCw className="w-4 h-4" />
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-950/80 text-slate-400 uppercase text-[10px]">
                  <tr>
                    <th className="px-4 py-3">Student</th>
                    <th className="px-4 py-3">From Class / Session</th>
                    <th className="px-4 py-3">To Class / Session</th>
                    <th className="px-4 py-3">Type</th>
                    <th className="px-4 py-3">Status</th>
                    <th className="px-4 py-3">Promoted By / Date</th>
                    <th className="px-4 py-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {promotions.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="text-center py-10 text-slate-500">
                        No promotion transactions recorded yet.
                      </td>
                    </tr>
                  ) : (
                    promotions.map((p) => (
                      <tr key={p.id} className="hover:bg-slate-800/30">
                        <td className="px-4 py-3">
                          <div className="font-bold text-white">{p.studentName}</div>
                          <div className="text-[11px] text-slate-400 font-mono">{p.admissionNumber}</div>
                        </td>
                        <td className="px-4 py-3">
                          <div className="font-semibold text-slate-200">{p.fromClassName}</div>
                          <div className="text-[10px] text-slate-400">{p.fromSessionName} (Roll #{p.fromRollNumber})</div>
                        </td>
                        <td className="px-4 py-3">
                          <div className="font-semibold text-indigo-400">{p.toClassName}</div>
                          <div className="text-[10px] text-slate-400">{p.toSessionName} (Roll #{p.toRollNumber})</div>
                        </td>
                        <td className="px-4 py-3">
                          <span className="font-mono text-[11px] text-slate-300 font-semibold">{p.promotionType}</span>
                        </td>
                        <td className="px-4 py-3">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-semibold uppercase ${
                              p.status === 'COMPLETED'
                                ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                                : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                            }`}
                          >
                            {p.status}
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          <div>{p.promotedByName}</div>
                          <div className="text-[10px] text-slate-500">{p.promotedAt ? p.promotedAt.split('T')[0] : 'N/A'}</div>
                        </td>
                        <td className="px-4 py-3 text-right">
                          <button
                            onClick={() => setSelectedTimelineStudentId(p.studentId)}
                            className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-indigo-400 border border-slate-700 rounded text-[11px] font-medium transition-colors"
                          >
                            View Timeline
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: TRANSFERS & TRANSFER CERTIFICATES */}
      {activeTab === 'transfers' && (
        <div className="space-y-6">
          {/* Action Row */}
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowIssueTCModal(true)}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold flex items-center gap-2 shadow-lg shadow-emerald-600/20"
              >
                <FileBadge className="w-4 h-4" />
                Issue New Transfer Certificate
              </button>
              <button
                onClick={() => setShowInternalTransferModal(true)}
                className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-medium flex items-center gap-1.5"
              >
                <Shuffle className="w-4 h-4 text-amber-400" />
                Internal Section Reassignment
              </button>
            </div>
          </div>

          {/* Transfer Certificates Table */}
          <div className="bg-slate-900/50 border border-slate-800 rounded-2xl overflow-hidden">
            <div className="p-4 border-b border-slate-800">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <FileBadge className="w-4 h-4 text-emerald-400" />
                Issued Transfer Certificates ({certificates.length})
              </h3>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-950/80 text-slate-400 uppercase text-[10px]">
                  <tr>
                    <th className="px-4 py-3">TC Serial Number</th>
                    <th className="px-4 py-3">Student Name</th>
                    <th className="px-4 py-3">Class Left</th>
                    <th className="px-4 py-3">Issue Date</th>
                    <th className="px-4 py-3">Reason for Leaving</th>
                    <th className="px-4 py-3">Conduct</th>
                    <th className="px-4 py-3">Dues Cleared</th>
                    <th className="px-4 py-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {certificates.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="text-center py-10 text-slate-500">
                        No Transfer Certificates issued yet.
                      </td>
                    </tr>
                  ) : (
                    certificates.map((tc) => (
                      <tr key={tc.id} className="hover:bg-slate-800/30">
                        <td className="px-4 py-3">
                          <span className="font-mono font-bold text-indigo-400">{tc.tcNumber}</span>
                        </td>
                        <td className="px-4 py-3">
                          <div className="font-bold text-white">{tc.studentName}</div>
                          <div className="text-[11px] text-slate-400 font-mono">{tc.admissionNumber}</div>
                        </td>
                        <td className="px-4 py-3">
                          <span className="font-semibold text-slate-200">{tc.classLeft} - {tc.sectionLeft}</span>
                        </td>
                        <td className="px-4 py-3 text-slate-300">{tc.issueDate}</td>
                        <td className="px-4 py-3 text-slate-300 max-w-xs truncate">{tc.reasonForLeaving}</td>
                        <td className="px-4 py-3">
                          <span className="font-semibold text-slate-200">{tc.generalConduct}</span>
                        </td>
                        <td className="px-4 py-3">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-semibold uppercase ${
                              tc.hasClearedAllDues
                                ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                                : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                            }`}
                          >
                            {tc.hasClearedAllDues ? 'Cleared' : 'Conditional'}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-right">
                          <button
                            onClick={() => setSelectedTC(tc)}
                            className="px-3 py-1 bg-indigo-600 hover:bg-indigo-500 text-white rounded text-[11px] font-medium inline-flex items-center gap-1 transition-colors"
                          >
                            <FileText className="w-3 h-3" />
                            View TC
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Internal Transfers Table */}
          <div className="bg-slate-900/50 border border-slate-800 rounded-2xl overflow-hidden">
            <div className="p-4 border-b border-slate-800">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Shuffle className="w-4 h-4 text-amber-400" />
                Internal Reassignment History ({transfers.length})
              </h3>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-950/80 text-slate-400 uppercase text-[10px]">
                  <tr>
                    <th className="px-4 py-3">Student</th>
                    <th className="px-4 py-3">Transfer Type</th>
                    <th className="px-4 py-3">Origin</th>
                    <th className="px-4 py-3">Destination</th>
                    <th className="px-4 py-3">Effective Date</th>
                    <th className="px-4 py-3">Reason</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {transfers.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="text-center py-10 text-slate-500">
                        No internal transfers recorded yet.
                      </td>
                    </tr>
                  ) : (
                    transfers.map((tr) => (
                      <tr key={tr.id} className="hover:bg-slate-800/30">
                        <td className="px-4 py-3">
                          <div className="font-bold text-white">{tr.studentName}</div>
                          <div className="text-[11px] text-slate-400 font-mono">{tr.admissionNumber}</div>
                        </td>
                        <td className="px-4 py-3 font-mono text-[11px] text-slate-300">{tr.type}</td>
                        <td className="px-4 py-3 font-semibold text-slate-300">
                          {tr.fromClassName} - {tr.fromSectionName}
                        </td>
                        <td className="px-4 py-3 font-semibold text-indigo-400">
                          {tr.toClassName ? `${tr.toClassName} - ` : ''}{tr.toSectionName}
                        </td>
                        <td className="px-4 py-3 text-slate-400">{tr.effectiveDate}</td>
                        <td className="px-4 py-3 text-slate-300 max-w-xs truncate">{tr.reason}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: STATUS LIFECYCLE MANAGER */}
      {activeTab === 'status' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900/60 p-4 rounded-2xl border border-slate-800">
            <div className="flex items-center gap-3">
              <Search className="w-4 h-4 text-slate-400" />
              <input
                type="text"
                placeholder="Search students by name, admission no, roll..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="bg-transparent text-xs text-white placeholder-slate-500 focus:outline-none w-64"
              />
            </div>

            <div className="flex items-center gap-2">
              <select
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
                className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-300"
              >
                <option value="">All Statuses</option>
                <option value="active">Active</option>
                <option value="suspended">Suspended</option>
                <option value="withdrawn">Withdrawn</option>
                <option value="graduated">Graduated</option>
                <option value="transferred">Transferred</option>
                <option value="inactive">Inactive</option>
              </select>
            </div>
          </div>

          <div className="bg-slate-900/50 border border-slate-800 rounded-2xl overflow-hidden">
            <div className="p-4 border-b border-slate-800 flex justify-between items-center">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <UserCheck className="w-4 h-4 text-amber-400" />
                Student Lifecycle Registry ({filteredStudents.length})
              </h3>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-950/80 text-slate-400 uppercase text-[10px]">
                  <tr>
                    <th className="px-4 py-3">Student Name</th>
                    <th className="px-4 py-3">Class & Section</th>
                    <th className="px-4 py-3">Roll Number</th>
                    <th className="px-4 py-3">Current Status</th>
                    <th className="px-4 py-3">Session</th>
                    <th className="px-4 py-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {filteredStudents.map((st) => (
                    <tr key={st.id} className="hover:bg-slate-800/30">
                      <td className="px-4 py-3">
                        <div className="font-bold text-white">{st.name}</div>
                        <div className="text-[11px] text-slate-400 font-mono">{st.admissionNumber}</div>
                      </td>
                      <td className="px-4 py-3 font-medium text-slate-200">
                        {st.className} ({st.sectionName || 'N/A'})
                      </td>
                      <td className="px-4 py-3 font-mono text-slate-300">#{st.rollNumber || 'N/A'}</td>
                      <td className="px-4 py-3">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-semibold uppercase ${
                            st.status === 'active'
                              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                              : st.status === 'suspended'
                              ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                              : st.status === 'graduated'
                              ? 'bg-purple-500/10 text-purple-400 border border-purple-500/20'
                              : st.status === 'transferred'
                              ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20'
                              : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                          }`}
                        >
                          {st.status}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-slate-400">{st.academicSessionName || '2025-2026'}</td>
                      <td className="px-4 py-3 text-right space-x-2">
                        <button
                          onClick={() => setStatusChangeStudent(st)}
                          className="px-2.5 py-1 bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded text-[11px] font-medium transition-colors"
                        >
                          Transition Status
                        </button>
                        <button
                          onClick={() => setSelectedTimelineStudentId(st.id)}
                          className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-[11px] font-medium"
                        >
                          Lifecycle
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: ENROLLMENTS ROSTER */}
      {activeTab === 'enrollments' && (
        <div className="space-y-6">
          <div className="flex flex-wrap items-center gap-3 bg-slate-900/60 p-4 rounded-2xl border border-slate-800">
            <div className="flex items-center gap-2 flex-1 min-w-[200px]">
              <Search className="w-4 h-4 text-slate-400" />
              <input
                type="text"
                placeholder="Search enrollments by student name or ID..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="bg-transparent text-xs text-white placeholder-slate-500 focus:outline-none w-full"
              />
            </div>

            <select
              value={selectedSessionId}
              onChange={(e) => setSelectedSessionId(e.target.value)}
              className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-300"
            >
              <option value="">All Academic Sessions</option>
              {sessions.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>

            <select
              value={selectedClassId}
              onChange={(e) => setSelectedClassId(e.target.value)}
              className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-300"
            >
              <option value="">All Classes</option>
              {classes.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          <div className="bg-slate-900/50 border border-slate-800 rounded-2xl overflow-hidden">
            <div className="p-4 border-b border-slate-800">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Layers className="w-4 h-4 text-indigo-400" />
                Preserved Academic Enrollments ({filteredEnrollments.length})
              </h3>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-950/80 text-slate-400 uppercase text-[10px]">
                  <tr>
                    <th className="px-4 py-3">Student</th>
                    <th className="px-4 py-3">Session</th>
                    <th className="px-4 py-3">Class & Section</th>
                    <th className="px-4 py-3">Roll No</th>
                    <th className="px-4 py-3">Enrollment Status</th>
                    <th className="px-4 py-3">Enrolled Date</th>
                    <th className="px-4 py-3 text-right">Academic History</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {filteredEnrollments.map((enr) => (
                    <tr key={enr.id} className="hover:bg-slate-800/30">
                      <td className="px-4 py-3">
                        <div className="font-bold text-white">{enr.studentName}</div>
                        <div className="text-[11px] text-slate-400 font-mono">{enr.admissionNumber}</div>
                      </td>
                      <td className="px-4 py-3 font-medium text-slate-200">{enr.academicSessionName}</td>
                      <td className="px-4 py-3 font-semibold text-slate-200">
                        {enr.className} ({enr.sectionName || 'A'})
                      </td>
                      <td className="px-4 py-3 font-mono">#{enr.rollNumber || 'N/A'}</td>
                      <td className="px-4 py-3">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-semibold uppercase ${
                            enr.status === 'active'
                              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                              : enr.status === 'promoted'
                              ? 'bg-indigo-500/10 text-indigo-400 border border-indigo-500/20'
                              : enr.status === 'transferred'
                              ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                              : 'bg-slate-800 text-slate-400 border border-slate-700'
                          }`}
                        >
                          {enr.status}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-slate-400">{enr.enrollmentDate}</td>
                      <td className="px-4 py-3 text-right">
                        <button
                          onClick={() => setSelectedTimelineStudentId(enr.studentId)}
                          className="px-2.5 py-1 bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/30 rounded text-[11px] font-medium"
                        >
                          View Timeline
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: BATCHES & ROLLBACKS */}
      {activeTab === 'batches' && (
        <div className="space-y-6">
          <div className="bg-slate-900/50 border border-slate-800 rounded-2xl overflow-hidden">
            <div className="p-4 border-b border-slate-800">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Clock className="w-4 h-4 text-indigo-400" />
                Bulk Promotion Batches Archive ({batches.length})
              </h3>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-300">
                <thead className="bg-slate-950/80 text-slate-400 uppercase text-[10px]">
                  <tr>
                    <th className="px-4 py-3">Batch Reference</th>
                    <th className="px-4 py-3">Batch Description</th>
                    <th className="px-4 py-3">Source & Destination</th>
                    <th className="px-4 py-3">Students Processed</th>
                    <th className="px-4 py-3">Outcome Breakdown</th>
                    <th className="px-4 py-3">Executed By</th>
                    <th className="px-4 py-3">Timestamp</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {batches.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="text-center py-10 text-slate-500">
                        No batch promotion operations executed yet.
                      </td>
                    </tr>
                  ) : (
                    batches.map((b) => (
                      <tr key={b.id} className="hover:bg-slate-800/30">
                        <td className="px-4 py-3 font-mono font-bold text-indigo-400">{b.id}</td>
                        <td className="px-4 py-3 font-semibold text-white">{b.title}</td>
                        <td className="px-4 py-3">
                          <div>
                            {b.sourceClassName} <ArrowRightLeft className="w-3 h-3 inline text-slate-500 mx-1" />{' '}
                            {b.targetClassName}
                          </div>
                          <div className="text-[10px] text-slate-500">{b.targetSessionName}</div>
                        </td>
                        <td className="px-4 py-3 font-bold text-white">{b.totalProcessed}</td>
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-2 text-[10px]">
                            <span className="text-emerald-400 font-semibold">{b.promotedCount} Promoted</span>
                            <span className="text-slate-600">•</span>
                            <span className="text-amber-400 font-semibold">{b.retainedCount} Retained</span>
                            {b.graduatedCount > 0 && (
                              <>
                                <span className="text-slate-600">•</span>
                                <span className="text-purple-400 font-semibold">{b.graduatedCount} Graduated</span>
                              </>
                            )}
                          </div>
                        </td>
                        <td className="px-4 py-3">{b.executedByName}</td>
                        <td className="px-4 py-3 text-slate-400">{b.executedAt ? b.executedAt.split('T')[0] : 'N/A'}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* MODALS */}
      {showBulkWizard && (
        <BulkPromotionWizard
          sessions={sessions}
          classes={classes}
          sections={sections}
          onClose={() => setShowBulkWizard(false)}
          onCompleted={async () => {
            setShowBulkWizard(false);
            await loadData();
          }}
        />
      )}

      {showIndividualModal && (
        <IndividualPromotionModal
          students={students}
          sessions={sessions}
          classes={classes}
          sections={sections}
          onClose={() => setShowIndividualModal(false)}
          onCompleted={async () => {
            setShowIndividualModal(false);
            await loadData();
          }}
        />
      )}

      {showInternalTransferModal && (
        <InternalTransferModal
          students={students}
          classes={classes}
          sections={sections}
          onClose={() => setShowInternalTransferModal(false)}
          onCompleted={async () => {
            setShowInternalTransferModal(false);
            await loadData();
          }}
        />
      )}

      {showIssueTCModal && (
        <IssueTransferCertificateModal
          students={students}
          onClose={() => setShowIssueTCModal(false)}
          onSuccess={(newCert) => {
            setShowIssueTCModal(false);
            loadData();
            setSelectedTC(newCert);
          }}
        />
      )}

      {selectedTC && (
        <TransferCertificateViewerModal
          certificate={selectedTC}
          onClose={() => setSelectedTC(null)}
        />
      )}

      {selectedTimelineStudentId && (
        <StudentAcademicTimelineModal
          studentId={selectedTimelineStudentId}
          onClose={() => setSelectedTimelineStudentId(null)}
          onPromotionReverted={loadData}
        />
      )}

      {statusChangeStudent && (
        <StudentStatusChangeModal
          student={statusChangeStudent}
          onClose={() => setStatusChangeStudent(null)}
          onSuccess={async () => {
            setStatusChangeStudent(null);
            await loadData();
          }}
        />
      )}
    </div>
  );
};
