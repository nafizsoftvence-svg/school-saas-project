import React, { useEffect, useState, useMemo } from 'react';
import {
  Activity,
  Clock,
  ShieldCheck,
  Search,
  Filter,
  RefreshCw,
  Terminal,
  Sparkles,
  Copy,
  Check,
  Eye,
  SlidersHorizontal,
  FileCode
} from 'lucide-react';
import { Table, Column } from '../../components/ui/Table.js';
import { Badge } from '../../components/ui/Badge.js';
import { Button } from '../../components/ui/Button.js';
import { Input } from '../../components/ui/Input.js';
import { Select } from '../../components/ui/Select.js';
import { Modal } from '../../components/ui/Modal.js';
import { api } from '../../services/api.js';
import { AuditLog } from '../../types/index.js';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner.js';
import { useToast } from '../../context/ToastContext.js';

export const AuditTrailPage: React.FC = () => {
  const { showToast } = useToast();
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [search, setSearch] = useState('');
  const [actionCategory, setActionCategory] = useState<string>('ALL');
  const [roleFilter, setRoleFilter] = useState<string>('ALL');
  const [selectedLog, setSelectedLog] = useState<AuditLog | null>(null);
  const [copied, setCopied] = useState(false);

  // Sorting
  const [sortKey, setSortKey] = useState<string>('timestamp');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');

  const fetchLogs = async (isManual = false) => {
    try {
      if (isManual) setRefreshing(true);
      else setLoading(true);

      const res = await api.getAuditLogs(200);
      if (res.success && res.data) {
        setLogs(res.data);
      }
    } catch (err) {
      console.error('Failed to load audit logs', err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchLogs();
  }, []);

  const handleCopyPayload = (log: AuditLog) => {
    try {
      const payloadString = JSON.stringify(
        {
          id: log.id,
          timestamp: log.timestamp,
          action: log.action,
          entity: log.entity || log.entityType,
          entityId: log.entityId,
          performedBy: log.userName || log.performedBy || log.userId,
          userRole: log.userRole,
          ipAddress: log.ipAddress,
          details: log.details,
          metadata: log.metadata
        },
        null,
        2
      );
      navigator.clipboard.writeText(payloadString);
      setCopied(true);
      showToast('Payload Copied', 'Audit log JSON copied to clipboard.', 'success');
      setTimeout(() => setCopied(false), 2500);
    } catch (err) {
      showToast('Copy Failed', 'Unable to access clipboard.', 'error');
    }
  };

  const columns: Column<AuditLog>[] = [
    {
      header: 'Timestamp',
      sortable: true,
      sortKey: 'timestamp',
      accessor: (row) => (
        <div className="font-mono text-xs text-slate-300">
          <div className="font-semibold text-slate-200">{new Date(row.timestamp).toLocaleDateString()}</div>
          <div className="text-[11px] text-slate-400">
            {new Date(row.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
          </div>
        </div>
      )
    },
    {
      header: 'Action',
      sortable: true,
      sortKey: 'action',
      accessor: (row) => {
        const action = row.action || '';
        const isAuth = action.includes('AUTH') || action.includes('LOGIN');
        const isDelete = action.includes('DELETE') || action.includes('REMOVE');
        const isArchive = action.includes('ARCHIVE');
        const isUpdate = action.includes('UPDATE') || action.includes('EDIT') || action.includes('ASSIGN') || action.includes('ACTIVATE');
        const isCreate = action.includes('CREATE') || action.includes('ADD') || action.includes('REGISTER');

        const variant = isDelete
          ? 'danger'
          : isArchive
          ? 'warning'
          : isAuth
          ? 'info'
          : isUpdate
          ? 'warning'
          : isCreate
          ? 'success'
          : 'neutral';

        return <Badge variant={variant}>{action}</Badge>;
      }
    },
    {
      header: 'Target Entity',
      sortable: true,
      sortKey: 'entityType',
      accessor: (row) => (
        <div>
          <span className="font-semibold text-white text-xs">{row.entity || row.entityType || 'System'}</span>
          {row.entityId && <span className="text-[10px] text-slate-400 font-mono ml-1.5 font-medium">({row.entityId})</span>}
        </div>
      )
    },
    {
      header: 'Actor & Role',
      sortable: true,
      sortKey: 'userName',
      accessor: (row) => {
        const actorName = row.userName || row.performedBy || 'System Administrator';
        const role = row.userRole || 'SUPER_ADMIN';
        const isSuperAdmin = role === 'SUPER_ADMIN';

        return (
          <div className="space-y-0.5">
            <div className="text-xs font-semibold text-slate-200">{actorName}</div>
            <span
              className={`text-[10px] px-2 py-0.5 rounded font-mono font-bold border ${
                isSuperAdmin
                  ? 'bg-rose-500/10 text-rose-300 border-rose-500/20'
                  : role === 'TEACHER'
                  ? 'bg-indigo-500/10 text-indigo-300 border-indigo-500/20'
                  : 'bg-emerald-500/10 text-emerald-300 border-emerald-500/20'
              }`}
            >
              {role}
            </span>
          </div>
        );
      }
    },
    {
      header: 'Event Summary & Details',
      accessor: (row) => <span className="text-xs text-slate-300 line-clamp-2">{row.details}</span>
    },
    {
      header: 'Inspection',
      align: 'right',
      accessor: (row) => (
        <div className="flex items-center justify-end gap-1.5">
          <Button
            size="xs"
            variant="outline"
            onClick={(e) => {
              e.stopPropagation();
              setSelectedLog(row);
            }}
            leftIcon={<Eye className="w-3 h-3" />}
          >
            Payload
          </Button>
        </div>
      )
    }
  ];

  // Filtering & Sorting Data
  const processedLogs = useMemo(() => {
    let list = logs.filter((l) => {
      const actor = (l.userName || l.performedBy || l.userId || '').toLowerCase();
      const action = (l.action || '').toLowerCase();
      const entity = (l.entity || l.entityType || '').toLowerCase();
      const details = (l.details || '').toLowerCase();
      const q = search.toLowerCase().trim();

      const matchesSearch = !q || actor.includes(q) || action.includes(q) || entity.includes(q) || details.includes(q);

      if (!matchesSearch) return false;

      // Category filter
      if (actionCategory !== 'ALL') {
        if (actionCategory === 'ACADEMIC') {
          const isAcademic =
            action.includes('ACADEMIC') ||
            action.includes('CLASS') ||
            action.includes('SECTION') ||
            action.includes('SUBJECT') ||
            action.includes('DEPARTMENT');
          if (!isAcademic) return false;
        } else if (actionCategory === 'USERS') {
          const isUser =
            action.includes('USER') ||
            action.includes('TEACHER') ||
            action.includes('STUDENT') ||
            action.includes('GUARDIAN');
          if (!isUser) return false;
        } else if (actionCategory === 'AUTH') {
          const isAuth = action.includes('AUTH') || action.includes('LOGIN') || action.includes('SESSION');
          if (!isAuth) return false;
        } else if (actionCategory === 'MUTATIONS') {
          const isMutation =
            action.includes('CREATE') || action.includes('UPDATE') || action.includes('DELETE') || action.includes('ARCHIVE');
          if (!isMutation) return false;
        }
      }

      // Role filter
      if (roleFilter !== 'ALL') {
        if (l.userRole !== roleFilter) return false;
      }

      return true;
    });

    // Sort
    list.sort((a: any, b: any) => {
      let aVal = a[sortKey];
      let bVal = b[sortKey];

      if (sortKey === 'timestamp') {
        const aTime = new Date(a.timestamp).getTime();
        const bTime = new Date(b.timestamp).getTime();
        return sortDirection === 'asc' ? aTime - bTime : bTime - aTime;
      }

      if (typeof aVal === 'string' && typeof bVal === 'string') {
        return sortDirection === 'asc' ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
      }

      return 0;
    });

    return list;
  }, [logs, search, actionCategory, roleFilter, sortKey, sortDirection]);

  return (
    <div className="space-y-6">
      {/* Top Header Card */}
      <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-6 sm:p-8 shadow-xl shadow-black/20 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-rose-400 text-xs font-bold uppercase tracking-wider mb-1">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Cryptographic Security Log &amp; System Telemetry</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">Audit Trail &amp; Data Governance</h2>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            Every administrative mutation, user role transition, academic configuration update, and authentication event is recorded with non-repudiation timestamps.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <Button
            size="sm"
            variant="glass"
            leftIcon={<RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin' : ''}`} />}
            onClick={() => fetchLogs(true)}
            isLoading={refreshing}
          >
            Refresh Records
          </Button>
        </div>
      </div>

      {/* Search & Filter Bar */}
      <div className="p-4 rounded-2xl bg-white/5 border border-white/10 flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3">
        <div className="flex-1 max-w-md">
          <Input
            id="audit-search-input"
            placeholder="Search events by actor, entity ID, action, or details..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            leftIcon={<Search className="w-4 h-4" />}
          />
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="w-44">
            <Select
              id="audit-category-filter"
              value={actionCategory}
              onChange={(e) => setActionCategory(e.target.value)}
              options={[
                { value: 'ALL', label: 'All Action Categories' },
                { value: 'ACADEMIC', label: 'Academic Hierarchy' },
                { value: 'USERS', label: 'Faculty & Scholar Accounts' },
                { value: 'MUTATIONS', label: 'Create / Update / Delete' },
                { value: 'AUTH', label: 'Authentication & Sessions' }
              ]}
            />
          </div>

          <div className="w-36">
            <Select
              id="audit-role-filter"
              value={roleFilter}
              onChange={(e) => setRoleFilter(e.target.value)}
              options={[
                { value: 'ALL', label: 'All Roles' },
                { value: 'SUPER_ADMIN', label: 'Super Admin' },
                { value: 'TEACHER', label: 'Teachers' },
                { value: 'STUDENT', label: 'Students' }
              ]}
            />
          </div>
        </div>
      </div>

      {/* Audit Log Table with Sorting & Auto-Pagination */}
      {loading ? (
        <div className="py-20 flex justify-center">
          <LoadingSpinner size="lg" message="Loading cryptographic audit trail..." />
        </div>
      ) : (
        <Table
          columns={columns}
          data={processedLogs}
          keyExtractor={(l) => l.id}
          sortColumn={sortKey}
          sortDirection={sortDirection}
          onSort={(key, dir) => {
            setSortKey(key);
            setSortDirection(dir);
          }}
          autoPaginate={true}
          pageSize={10}
          pageSizeOptions={[10, 20, 50, 100]}
          itemLabel="audit events"
          emptyMessage="No audit logs matched the specified filters."
        />
      )}

      {/* Detailed Payload Inspector Modal */}
      {selectedLog && (
        <Modal
          isOpen={Boolean(selectedLog)}
          onClose={() => setSelectedLog(null)}
          title={`Audit Event: ${selectedLog.action}`}
          description={`Recorded at ${new Date(selectedLog.timestamp).toLocaleString()} from ${selectedLog.ipAddress || '127.0.0.1'}`}
          size="lg"
        >
          <div className="space-y-4 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-4 rounded-2xl bg-black/40 border border-white/10">
              <div>
                <span className="text-slate-400 font-mono">Event ID:</span>
                <p className="font-mono text-white text-[11px] select-all">{selectedLog.id}</p>
              </div>
              <div>
                <span className="text-slate-400 font-mono">Actor / Operator:</span>
                <p className="font-medium text-white">
                  {selectedLog.userName || selectedLog.performedBy || 'System Administrator'} ({selectedLog.userRole})
                </p>
              </div>
              <div>
                <span className="text-slate-400 font-mono">Entity Type / ID:</span>
                <p className="font-medium text-white">
                  {selectedLog.entity || selectedLog.entityType || 'N/A'}{' '}
                  {selectedLog.entityId && <span className="font-mono text-indigo-300">({selectedLog.entityId})</span>}
                </p>
              </div>
              <div>
                <span className="text-slate-400 font-mono">Origin IP:</span>
                <p className="font-mono text-emerald-400">{selectedLog.ipAddress || '127.0.0.1'}</p>
              </div>
              <div className="sm:col-span-2 pt-2 border-t border-white/10">
                <span className="text-slate-400 font-mono">Summary:</span>
                <p className="text-slate-200 text-xs mt-0.5">{selectedLog.details}</p>
              </div>
            </div>

            {selectedLog.metadata && (
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-slate-300 font-semibold">
                  <div className="flex items-center gap-1.5">
                    <FileCode className="w-3.5 h-3.5 text-indigo-400" />
                    <span>Event Metadata Payload (Sanitized JSON)</span>
                  </div>
                  <Button
                    size="xs"
                    variant="outline"
                    onClick={() => handleCopyPayload(selectedLog)}
                    leftIcon={copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  >
                    {copied ? 'Copied' : 'Copy JSON'}
                  </Button>
                </div>
                <pre className="p-4 rounded-2xl bg-black/70 border border-white/10 text-emerald-400 font-mono text-[11px] overflow-x-auto max-h-72">
                  {JSON.stringify(selectedLog.metadata, null, 2)}
                </pre>
              </div>
            )}

            <div className="flex justify-end gap-2 pt-3 border-t border-white/10">
              <Button size="sm" variant="outline" onClick={() => setSelectedLog(null)}>
                Close
              </Button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
