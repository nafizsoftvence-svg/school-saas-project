import React, { useState, useEffect, useMemo } from 'react';
import {
  CreditCard,
  FileText,
  ShieldCheck,
  QrCode,
  Printer,
  Upload,
  RefreshCw,
  Search,
  Filter,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Clock,
  Eye,
  Lock,
  Unlock,
  SlidersHorizontal,
  ChevronRight,
  Download,
  Building2,
  Users,
  Sparkles,
  LayoutGrid,
  List
} from 'lucide-react';
import {
  StudentIDCard,
  StudentDocument,
  StudentIDCardTemplateLayout,
  ClassItem,
  SectionItem
} from '../../types';
import { StudentIDCardVisual } from '../../components/idcards/StudentIDCardVisual';
import { BulkIDCardPrintSheet } from '../../components/idcards/BulkIDCardPrintSheet';
import { StudentIDCardReissueModal } from '../../components/idcards/StudentIDCardReissueModal';
import { StudentIDCardGenerateModal } from '../../components/idcards/StudentIDCardGenerateModal';
import { StudentIDCardScannerModal } from '../../components/idcards/StudentIDCardScannerModal';
import { StudentDocumentReviewModal } from '../../components/documents/StudentDocumentReviewModal';
import { StudentDocumentUploadModal } from '../../components/documents/StudentDocumentUploadModal';

interface AdminIDCardAndDocumentsPageProps {
  onNavigate?: (view: string) => void;
  activeTab?: 'id-cards' | 'documents' | 'compliance' | 'templates';
  onTabChange?: (tab: 'id-cards' | 'documents' | 'compliance' | 'templates') => void;
  hideTabBar?: boolean;
}

export const AdminIDCardAndDocumentsPage: React.FC<AdminIDCardAndDocumentsPageProps> = ({
  onNavigate,
  activeTab: propActiveTab,
  onTabChange,
  hideTabBar = true
}) => {
  // Navigation tabs
  const [internalTab, setInternalTab] = useState<'id-cards' | 'documents' | 'compliance' | 'templates'>('id-cards');
  const activeTab = propActiveTab || internalTab;
  const setActiveTab = (tab: 'id-cards' | 'documents' | 'compliance' | 'templates') => {
    setInternalTab(tab);
    onTabChange?.(tab);
  };

  // Core Data
  const [idCards, setIdCards] = useState<StudentIDCard[]>([]);
  const [documents, setDocuments] = useState<StudentDocument[]>([]);
  const [classes, setClasses] = useState<ClassItem[]>([]);
  const [sections, setSections] = useState<SectionItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Filters - ID Cards
  const [cardSearch, setCardSearch] = useState('');
  const [cardClassFilter, setCardClassFilter] = useState('');
  const [cardSectionFilter, setCardSectionFilter] = useState('');
  const [cardStatusFilter, setCardStatusFilter] = useState('ALL');
  const [viewMode, setViewMode] = useState<'grid' | 'table'>('grid');

  // Selection for batch actions
  const [selectedCardIds, setSelectedCardIds] = useState<string[]>([]);

  // Filters - Documents
  const [docSearch, setDocSearch] = useState('');
  const [docStatusFilter, setDocStatusFilter] = useState('ALL');
  const [docCategoryFilter, setDocCategoryFilter] = useState('ALL');

  // Modals state
  const [printSheetCards, setPrintSheetCards] = useState<StudentIDCard[] | null>(null);
  const [reissueTargetCard, setReissueTargetCard] = useState<StudentIDCard | null>(null);
  const [isGenerateModalOpen, setIsGenerateModalOpen] = useState(false);
  const [isScannerModalOpen, setIsScannerModalOpen] = useState(false);
  const [reviewingDoc, setReviewingDoc] = useState<StudentDocument | null>(null);
  const [uploadDocTarget, setUploadDocTarget] = useState<{ studentId: string; studentName?: string; admissionNumber?: string } | null>(null);

  // Selected Template for Studio tab
  const [studioTemplate, setStudioTemplate] = useState<StudentIDCardTemplateLayout>('modern-vertical');

  // Fetch initial data
  const fetchData = async () => {
    setLoading(true);
    setError(null);
    try {
      const token = localStorage.getItem('sygmate_auth_token') || localStorage.getItem('token');
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {})
      };

      // Parallel fetch cards, documents, classes
      const [cardsRes, docsRes, classesRes, sectionsRes] = await Promise.all([
        fetch('/api/documents-idcards/id-cards', { headers }),
        fetch('/api/documents-idcards/documents', { headers }),
        fetch('/api/academic/classes', { headers }),
        fetch('/api/academic/sections', { headers })
      ]);

      if (cardsRes.ok && (cardsRes.headers.get('content-type') || '').includes('application/json')) {
        const d = await cardsRes.json();
        if (d.success) setIdCards(d.data || []);
      }
      if (docsRes.ok && (docsRes.headers.get('content-type') || '').includes('application/json')) {
        const d = await docsRes.json();
        if (d.success) setDocuments(d.data || []);
      }
      if (classesRes.ok && (classesRes.headers.get('content-type') || '').includes('application/json')) {
        const d = await classesRes.json();
        if (d.success) setClasses(d.data || []);
      }
      if (sectionsRes.ok && (sectionsRes.headers.get('content-type') || '').includes('application/json')) {
        const d = await sectionsRes.json();
        if (d.success) setSections(d.data || []);
      }
    } catch (err: any) {
      setError(err.message || 'Failed to load document and ID card records');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // Quick Action: Mark card status as ISSUED or PRINTED
  const handleUpdateCardStatus = async (cardId: string, newStatus: 'ISSUED' | 'PRINTED') => {
    try {
      const token = localStorage.getItem('sygmate_auth_token') || localStorage.getItem('token');
      const res = await fetch(`/api/documents-idcards/id-cards/${cardId}/issue`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {})
        },
        body: JSON.stringify({ status: newStatus })
      });
      if (res.ok && (res.headers.get('content-type') || '').includes('application/json')) {
        const data = await res.json();
        if (data.success) {
          setIdCards(prev => prev.map(c => (c.id === cardId ? data.data : c)));
        }
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Quick Action: Block / Unblock card
  const handleToggleBlockCard = async (card: StudentIDCard) => {
    const isBlocked = card.status === 'BLOCKED_LOST';
    const reason = isBlocked
      ? 'Administrative unblock after security clearance'
      : (window.prompt('Enter reason for blocking card (e.g. Reported lost by student):') || 'Reported lost by student');

    if (!isBlocked && !reason) return;

    try {
      const token = localStorage.getItem('sygmate_auth_token') || localStorage.getItem('token');
      const endpoint = isBlocked
        ? `/api/documents-idcards/id-cards/${card.id}/unblock`
        : `/api/documents-idcards/id-cards/${card.id}/block`;

      const res = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {})
        },
        body: JSON.stringify({ reason })
      });
      if (res.ok && (res.headers.get('content-type') || '').includes('application/json')) {
        const data = await res.json();
        if (data.success) {
          setIdCards(prev => prev.map(c => (c.id === card.id ? data.data : c)));
        }
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Quick Verify Document
  const handleQuickVerifyDoc = async (docId: string, status: 'VERIFIED' | 'REJECTED') => {
    try {
      const token = localStorage.getItem('sygmate_auth_token') || localStorage.getItem('token');
      const res = await fetch(`/api/documents-idcards/documents/${docId}/verify`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {})
        },
        body: JSON.stringify({ verificationStatus: status })
      });
      if (res.ok && (res.headers.get('content-type') || '').includes('application/json')) {
        const data = await res.json();
        if (data.success) {
          setDocuments(prev => prev.map(d => (d.id === docId ? data.data : d)));
        }
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Filtered Cards
  const filteredCards = useMemo(() => {
    return idCards.filter(c => {
      const matchesSearch =
        !cardSearch.trim() ||
        c.studentName?.toLowerCase().includes(cardSearch.toLowerCase()) ||
        c.admissionNumber?.toLowerCase().includes(cardSearch.toLowerCase()) ||
        c.cardNumber?.toLowerCase().includes(cardSearch.toLowerCase());

      const matchesClass = !cardClassFilter || c.classId === cardClassFilter;
      const matchesSection = !cardSectionFilter || c.sectionId === cardSectionFilter;
      const matchesStatus = cardStatusFilter === 'ALL' || c.status === cardStatusFilter;

      return matchesSearch && matchesClass && matchesSection && matchesStatus;
    });
  }, [idCards, cardSearch, cardClassFilter, cardSectionFilter, cardStatusFilter]);

  // Filtered Documents
  const filteredDocs = useMemo(() => {
    return documents.filter(d => {
      const matchesSearch =
        !docSearch.trim() ||
        (d.title || d.name)?.toLowerCase().includes(docSearch.toLowerCase()) ||
        d.studentName?.toLowerCase().includes(docSearch.toLowerCase()) ||
        d.admissionNumber?.toLowerCase().includes(docSearch.toLowerCase()) ||
        d.documentNumber?.toLowerCase().includes(docSearch.toLowerCase());

      const matchesStatus = docStatusFilter === 'ALL' || d.verificationStatus === docStatusFilter;
      const matchesCategory = docCategoryFilter === 'ALL' || d.category === docCategoryFilter;

      return matchesSearch && matchesStatus && matchesCategory;
    });
  }, [documents, docSearch, docStatusFilter, docCategoryFilter]);

  // Mandatory Compliance Analytics
  const complianceData = useMemo(() => {
    // Group documents by student admission
    const studentsMap = new Map<string, {
      studentName: string;
      admissionNumber: string;
      className: string;
      hasBirthCert: boolean;
      hasTC: boolean;
      hasImmunization: boolean;
      hasPhoto: boolean;
      studentId: string;
    }>();

    // Populate from idCards & documents
    idCards.forEach(c => {
      if (!studentsMap.has(c.admissionNumber)) {
        studentsMap.set(c.admissionNumber, {
          studentName: c.studentName,
          admissionNumber: c.admissionNumber,
          className: `${c.className} - ${c.sectionName}`,
          hasBirthCert: false,
          hasTC: false,
          hasImmunization: false,
          hasPhoto: !!c.avatarUrl,
          studentId: c.studentId
        });
      }
    });

    documents.forEach(d => {
      if (d.admissionNumber && studentsMap.has(d.admissionNumber)) {
        const s = studentsMap.get(d.admissionNumber)!;
        const cat = d.category || '';
        const title = (d.title || d.name || '').toLowerCase();

        if (cat === 'IDENTIFICATION' || title.includes('birth')) s.hasBirthCert = true;
        if (cat === 'ACADEMIC' || title.includes('transfer') || title.includes('tc')) s.hasTC = true;
        if (cat === 'MEDICAL' || title.includes('immuniz') || title.includes('vaccin')) s.hasImmunization = true;
        if (cat === 'IDENTITY_PHOTOS' || title.includes('photo')) s.hasPhoto = true;
      }
    });

    return Array.from(studentsMap.values());
  }, [idCards, documents]);

  // Card Selection Handlers
  const toggleSelectCard = (id: string) => {
    setSelectedCardIds(prev =>
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  const selectAllFilteredCards = () => {
    if (selectedCardIds.length === filteredCards.length) {
      setSelectedCardIds([]);
    } else {
      setSelectedCardIds(filteredCards.map(c => c.id));
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header & Metric Banner */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono font-bold text-indigo-600 bg-indigo-50 px-2.5 py-0.5 rounded-full border border-indigo-100 uppercase tracking-wide">
              Module 9D • Enterprise Credential Engine
            </span>
            <span className="text-xs text-slate-400 font-medium">• Academic Session 2026-2027</span>
          </div>
          <h1 className="text-2xl font-black text-slate-900 mt-1">Student Documents & ID Cards</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Manage encrypted student credentials, institutional identity cards, compliance verification, and campus gate security.
          </p>
        </div>

        {/* Global Action Bar */}
        <div className="flex items-center gap-2.5 flex-wrap">
          <button
            type="button"
            onClick={() => setIsScannerModalOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold shadow-xs transition"
          >
            <QrCode className="w-3.5 h-3.5 text-indigo-400" />
            Gate Scanner
          </button>

          <button
            type="button"
            onClick={() => setIsGenerateModalOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-xs transition"
          >
            <CreditCard className="w-3.5 h-3.5" />
            Generate Cards
          </button>
        </div>
      </div>

      {/* Navigation Tabs */}
      {!hideTabBar && (
        <div className="flex border-b border-slate-200 gap-6 text-xs font-bold text-slate-500">
          <button
            type="button"
            onClick={() => setActiveTab('id-cards')}
            className={`pb-3 flex items-center gap-2 border-b-2 transition ${
              activeTab === 'id-cards'
                ? 'border-indigo-600 text-indigo-600'
                : 'border-transparent hover:text-slate-800'
            }`}
          >
            <CreditCard className="w-4 h-4" />
            ID Card Command Center ({idCards.length})
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('documents')}
            className={`pb-3 flex items-center gap-2 border-b-2 transition ${
              activeTab === 'documents'
                ? 'border-indigo-600 text-indigo-600'
                : 'border-transparent hover:text-slate-800'
            }`}
          >
            <FileText className="w-4 h-4" />
            Document Verification Queue ({documents.length})
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('compliance')}
            className={`pb-3 flex items-center gap-2 border-b-2 transition ${
              activeTab === 'compliance'
                ? 'border-indigo-600 text-indigo-600'
                : 'border-transparent hover:text-slate-800'
            }`}
          >
            <ShieldCheck className="w-4 h-4" />
            Mandatory Compliance Audit ({complianceData.length})
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('templates')}
            className={`pb-3 flex items-center gap-2 border-b-2 transition ${
              activeTab === 'templates'
                ? 'border-indigo-600 text-indigo-600'
                : 'border-transparent hover:text-slate-800'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            Template Studio & Layouts
          </button>
        </div>
      )}

      {/* ===================================================================== */}
      {/* TAB 1: ID CARD COMMAND CENTER                                          */}
      {/* ===================================================================== */}
      {activeTab === 'id-cards' && (
        <div className="space-y-4">
          {/* Summary Stat Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
            {[
              { label: 'Total Cards', value: idCards.length, color: 'indigo', icon: CreditCard },
              { label: 'Active Issued', value: idCards.filter(c => c.status === 'ISSUED').length, color: 'emerald', icon: CheckCircle2 },
              { label: 'Printed Badges', value: idCards.filter(c => c.status === 'PRINTED').length, color: 'sky', icon: Printer },
              { label: 'Generated (Pending)', value: idCards.filter(c => c.status === 'GENERATED' || c.status === 'NOT_ISSUED').length, color: 'amber', icon: Clock },
              { label: 'Blocked / Lost', value: idCards.filter(c => c.status === 'BLOCKED_LOST').length, color: 'rose', icon: Lock }
            ].map(stat => (
              <div key={stat.label} className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex items-center justify-between">
                <div>
                  <span className="text-[10.5px] uppercase font-bold text-slate-400 block">{stat.label}</span>
                  <span className="text-xl font-black text-slate-900 mt-0.5 block">{stat.value}</span>
                </div>
                <div className="w-9 h-9 rounded-xl bg-slate-50 flex items-center justify-center text-slate-600 border border-slate-100">
                  <stat.icon className="w-4 h-4" />
                </div>
              </div>
            ))}
          </div>

          {/* Filtering & View Switcher Bar */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row items-center justify-between gap-3">
            <div className="flex items-center gap-2.5 flex-1 w-full md:w-auto flex-wrap">
              <div className="relative flex-1 min-w-[200px]">
                <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                <input
                  type="text"
                  value={cardSearch}
                  onChange={(e) => setCardSearch(e.target.value)}
                  placeholder="Search student, admission #, card #..."
                  className="w-full text-xs pl-9 pr-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <select
                value={cardClassFilter}
                onChange={(e) => {
                  setCardClassFilter(e.target.value);
                  setCardSectionFilter('');
                }}
                className="text-xs py-2 px-3 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="">All Classes</option>
                {classes.map(c => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>

              <select
                value={cardStatusFilter}
                onChange={(e) => setCardStatusFilter(e.target.value)}
                className="text-xs py-2 px-3 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-medium"
              >
                <option value="ALL">All Statuses</option>
                <option value="ISSUED">Issued (Active)</option>
                <option value="PRINTED">Printed</option>
                <option value="GENERATED">Generated</option>
                <option value="BLOCKED_LOST">Blocked / Lost</option>
              </select>
            </div>

            {/* Batch Printing & View Mode Toggle */}
            <div className="flex items-center gap-2 w-full md:w-auto justify-between md:justify-end">
              {selectedCardIds.length > 0 && (
                <button
                  type="button"
                  onClick={() => {
                    const cardsToPrint = idCards.filter(c => selectedCardIds.includes(c.id));
                    setPrintSheetCards(cardsToPrint);
                  }}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-lg shadow-xs transition"
                >
                  <Printer className="w-3.5 h-3.5" />
                  Print Selected ({selectedCardIds.length})
                </button>
              )}

              <button
                type="button"
                onClick={() => setPrintSheetCards(filteredCards)}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-lg transition"
                title="Print all filtered cards"
              >
                <Printer className="w-3.5 h-3.5 text-slate-500" />
                Print Filtered ({filteredCards.length})
              </button>

              <div className="flex items-center bg-slate-100 p-0.5 rounded-lg border border-slate-200">
                <button
                  type="button"
                  onClick={() => setViewMode('grid')}
                  className={`p-1.5 rounded transition ${viewMode === 'grid' ? 'bg-white shadow-xs text-indigo-600' : 'text-slate-500'}`}
                  title="Grid visual view"
                >
                  <LayoutGrid className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => setViewMode('table')}
                  className={`p-1.5 rounded transition ${viewMode === 'table' ? 'bg-white shadow-xs text-indigo-600' : 'text-slate-500'}`}
                  title="List table view"
                >
                  <List className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>

          {/* Cards Display */}
          {loading ? (
            <div className="bg-white rounded-2xl p-12 text-center text-slate-400">
              <RefreshCw className="w-8 h-8 animate-spin mx-auto text-indigo-600 mb-2" />
              Loading student ID cards...
            </div>
          ) : filteredCards.length === 0 ? (
            <div className="bg-white rounded-2xl p-12 text-center border border-dashed border-slate-300">
              <CreditCard className="w-10 h-10 text-slate-300 mx-auto mb-2" />
              <h3 className="text-sm font-bold text-slate-700">No Student ID Cards Match Filter</h3>
              <p className="text-xs text-slate-400 mt-1">Try adjusting your search criteria or click "Generate Cards" above.</p>
            </div>
          ) : viewMode === 'grid' ? (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
              {filteredCards.map(card => {
                const isSelected = selectedCardIds.includes(card.id);
                const isBlocked = card.status === 'BLOCKED_LOST';

                return (
                  <div
                    key={card.id}
                    className={`bg-white rounded-2xl p-4 border transition-all flex flex-col items-center justify-between ${
                      isSelected ? 'border-indigo-500 ring-2 ring-indigo-500/20 shadow-md' : 'border-slate-200 shadow-xs hover:border-slate-300'
                    }`}
                  >
                    {/* Top Item Control Bar */}
                    <div className="w-full flex items-center justify-between mb-3">
                      <label className="flex items-center gap-2 cursor-pointer text-xs font-semibold text-slate-700">
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => toggleSelectCard(card.id)}
                          className="w-4 h-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                        />
                        <span className="font-mono text-[11px] font-bold text-slate-800">{card.admissionNumber}</span>
                      </label>

                      <div className="flex items-center gap-1.5">
                        <span className={`text-[9.5px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                          isBlocked
                            ? 'bg-rose-100 text-rose-800 border border-rose-200'
                            : (card.status === 'ISSUED'
                                ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                                : (card.status === 'PRINTED'
                                    ? 'bg-sky-100 text-sky-800 border border-sky-200'
                                    : 'bg-amber-100 text-amber-800 border border-amber-200'))
                        }`}>
                          {card.status}
                        </span>
                        {card.reissueCount ? (
                          <span className="text-[9px] font-mono font-bold bg-amber-50 text-amber-800 px-1.5 py-0.5 rounded border border-amber-200">
                            R{card.reissueCount}
                          </span>
                        ) : null}
                      </div>
                    </div>

                    {/* Interactive 3D Card Visual */}
                    <div className="my-2">
                      <StudentIDCardVisual
                        card={card}
                        scale={0.88}
                        interactive={true}
                        showFlipControls={true}
                        onPrint={() => setPrintSheetCards([card])}
                      />
                    </div>

                    {/* Bottom Action Strip */}
                    <div className="w-full pt-3 mt-2 border-t border-slate-100 flex items-center justify-between text-xs">
                      <div className="flex items-center gap-1">
                        {card.status !== 'PRINTED' && (
                          <button
                            type="button"
                            onClick={() => handleUpdateCardStatus(card.id, 'PRINTED')}
                            className="px-2.5 py-1 bg-sky-50 text-sky-700 hover:bg-sky-100 font-semibold rounded-lg transition"
                          >
                            Mark Printed
                          </button>
                        )}
                        {card.status !== 'ISSUED' && (
                          <button
                            type="button"
                            onClick={() => handleUpdateCardStatus(card.id, 'ISSUED')}
                            className="px-2.5 py-1 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 font-semibold rounded-lg transition"
                          >
                            Issue
                          </button>
                        )}
                      </div>

                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => setReissueTargetCard(card)}
                          className="p-1.5 text-slate-500 hover:text-amber-700 hover:bg-amber-50 rounded-lg transition"
                          title="Reissue lost or damaged card"
                        >
                          <RefreshCw className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleToggleBlockCard(card)}
                          className={`p-1.5 rounded-lg transition ${
                            isBlocked
                              ? 'text-rose-600 bg-rose-50 hover:bg-rose-100'
                              : 'text-slate-500 hover:text-rose-600 hover:bg-rose-50'
                          }`}
                          title={isBlocked ? 'Card is blocked. Click to unblock' : 'Block card'}
                        >
                          {isBlocked ? <Lock className="w-4 h-4" /> : <Unlock className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            /* Table View */
            <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-400 font-bold uppercase tracking-wider border-b border-slate-200 text-[10px]">
                  <tr>
                    <th className="p-3 w-10">
                      <input
                        type="checkbox"
                        checked={selectedCardIds.length === filteredCards.length && filteredCards.length > 0}
                        onChange={selectAllFilteredCards}
                        className="w-4 h-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                      />
                    </th>
                    <th className="p-3">Student</th>
                    <th className="p-3">Admission #</th>
                    <th className="p-3">Card #</th>
                    <th className="p-3">Class & Section</th>
                    <th className="p-3">Template</th>
                    <th className="p-3">Status</th>
                    <th className="p-3">Valid Until</th>
                    <th className="p-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredCards.map(card => {
                    const isSelected = selectedCardIds.includes(card.id);
                    return (
                      <tr key={card.id} className={`hover:bg-slate-50/80 transition ${isSelected ? 'bg-indigo-50/30' : ''}`}>
                        <td className="p-3">
                          <input
                            type="checkbox"
                            checked={isSelected}
                            onChange={() => toggleSelectCard(card.id)}
                            className="w-4 h-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                          />
                        </td>
                        <td className="p-3">
                          <div className="flex items-center gap-2.5">
                            <img
                              src={card.avatarUrl || 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&q=80&w=256'}
                              alt={card.studentName}
                              className="w-8 h-8 rounded-lg object-cover bg-slate-100 border border-slate-200"
                              referrerPolicy="no-referrer"
                            />
                            <div>
                              <strong className="text-slate-900 block font-bold">{card.studentName}</strong>
                              <span className="text-[10.5px] text-slate-500">Roll: {card.rollNumber || 'N/A'}</span>
                            </div>
                          </div>
                        </td>
                        <td className="p-3 font-mono font-bold text-slate-800">{card.admissionNumber}</td>
                        <td className="p-3 font-mono text-indigo-600 font-semibold">{card.cardNumber}</td>
                        <td className="p-3 text-slate-700">{card.className} • {card.sectionName}</td>
                        <td className="p-3 font-mono text-[11px] text-slate-600">{card.templateId}</td>
                        <td className="p-3">
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${
                            card.status === 'ISSUED'
                              ? 'bg-emerald-100 text-emerald-800'
                              : (card.status === 'PRINTED'
                                  ? 'bg-sky-100 text-sky-800'
                                  : (card.status === 'BLOCKED_LOST'
                                      ? 'bg-rose-100 text-rose-800'
                                      : 'bg-amber-100 text-amber-800'))
                          }`}>
                            {card.status}
                          </span>
                        </td>
                        <td className="p-3 text-slate-600 font-mono text-[11px]">{card.expiryDate}</td>
                        <td className="p-3 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              type="button"
                              onClick={() => setPrintSheetCards([card])}
                              className="p-1.5 text-slate-500 hover:text-indigo-600 hover:bg-slate-100 rounded-lg transition"
                              title="Print Single Card"
                            >
                              <Printer className="w-4 h-4" />
                            </button>
                            <button
                              type="button"
                              onClick={() => setReissueTargetCard(card)}
                              className="p-1.5 text-slate-500 hover:text-amber-600 hover:bg-slate-100 rounded-lg transition"
                              title="Reissue Card"
                            >
                              <RefreshCw className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* ===================================================================== */}
      {/* TAB 2: DOCUMENT VERIFICATION QUEUE                                     */}
      {/* ===================================================================== */}
      {activeTab === 'documents' && (
        <div className="space-y-4">
          {/* Document Metrics */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[
              { label: 'Total In Repository', value: documents.length, icon: FileText, color: 'indigo' },
              { label: 'Verified & Approved', value: documents.filter(d => d.verificationStatus === 'VERIFIED').length, icon: CheckCircle2, color: 'emerald' },
              { label: 'Pending Verification', value: documents.filter(d => d.verificationStatus === 'PENDING_VERIFICATION' || !d.verificationStatus).length, icon: Clock, color: 'amber' },
              { label: 'Rejected / Re-upload Needed', value: documents.filter(d => d.verificationStatus === 'REJECTED').length, icon: XCircle, color: 'rose' }
            ].map(stat => (
              <div key={stat.label} className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex items-center justify-between">
                <div>
                  <span className="text-[10.5px] uppercase font-bold text-slate-400 block">{stat.label}</span>
                  <span className="text-xl font-black text-slate-900 mt-0.5 block">{stat.value}</span>
                </div>
                <div className="w-9 h-9 rounded-xl bg-slate-50 flex items-center justify-center text-slate-600 border border-slate-100">
                  <stat.icon className="w-4 h-4" />
                </div>
              </div>
            ))}
          </div>

          {/* Filtering bar */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row items-center justify-between gap-3">
            <div className="flex items-center gap-2.5 flex-1 w-full md:w-auto flex-wrap">
              <div className="relative flex-1 min-w-[220px]">
                <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                <input
                  type="text"
                  value={docSearch}
                  onChange={(e) => setDocSearch(e.target.value)}
                  placeholder="Search document title, student, or doc number..."
                  className="w-full text-xs pl-9 pr-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <select
                value={docStatusFilter}
                onChange={(e) => setDocStatusFilter(e.target.value)}
                className="text-xs py-2 px-3 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="ALL">All Verification Statuses</option>
                <option value="PENDING_VERIFICATION">Pending Verification</option>
                <option value="VERIFIED">Verified & Approved</option>
                <option value="REJECTED">Rejected</option>
              </select>

              <select
                value={docCategoryFilter}
                onChange={(e) => setDocCategoryFilter(e.target.value)}
                className="text-xs py-2 px-3 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="ALL">All Categories</option>
                <option value="IDENTIFICATION">Identification (Birth Cert, Passport)</option>
                <option value="ACADEMIC">Academic (Transfer Certificate)</option>
                <option value="MEDICAL">Medical (Immunization)</option>
                <option value="LEGAL_GUARDIANSHIP">Legal Guardianship</option>
                <option value="IDENTITY_PHOTOS">Photos</option>
                <option value="OTHER">Other</option>
              </select>
            </div>
          </div>

          {/* Documents Table */}
          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-400 font-bold uppercase tracking-wider border-b border-slate-200 text-[10px]">
                <tr>
                  <th className="p-3.5">Document Title</th>
                  <th className="p-3.5">Student</th>
                  <th className="p-3.5">Category</th>
                  <th className="p-3.5">Certificate #</th>
                  <th className="p-3.5">Uploaded</th>
                  <th className="p-3.5">Status</th>
                  <th className="p-3.5 text-right">Verification Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredDocs.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="p-12 text-center text-slate-400">
                      No documents found matching the specified filters.
                    </td>
                  </tr>
                ) : (
                  filteredDocs.map(doc => {
                    const status = doc.verificationStatus || 'PENDING_VERIFICATION';

                    return (
                      <tr key={doc.id} className="hover:bg-slate-50/80 transition">
                        <td className="p-3.5">
                          <div className="flex items-center gap-2.5">
                            <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center border border-indigo-100 shrink-0">
                              <FileText className="w-4 h-4" />
                            </div>
                            <div>
                              <strong className="text-slate-900 block font-bold">{doc.title || doc.name}</strong>
                              <span className="text-[10.5px] text-slate-400">
                                {doc.fileName || 'file.pdf'} • {doc.fileSize || doc.size || '320 KB'}
                              </span>
                            </div>
                          </div>
                        </td>
                        <td className="p-3.5">
                          <strong className="text-slate-800 block">{doc.studentName || 'Student'}</strong>
                          <span className="font-mono text-[10.5px] text-slate-500">{doc.admissionNumber || 'ADM-2026-0842'}</span>
                        </td>
                        <td className="p-3.5">
                          <span className="text-[11px] font-semibold text-slate-700 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                            {doc.category || 'OTHER'}
                          </span>
                        </td>
                        <td className="p-3.5 font-mono text-[11px] text-slate-700">
                          {doc.documentNumber || '—'}
                        </td>
                        <td className="p-3.5 text-slate-500 text-[11px]">
                          {new Date(doc.uploadedAt).toLocaleDateString()}
                        </td>
                        <td className="p-3.5">
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                            status === 'VERIFIED'
                              ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                              : (status === 'REJECTED'
                                  ? 'bg-rose-100 text-rose-800 border border-rose-200'
                                  : 'bg-amber-100 text-amber-800 border border-amber-200')
                          }`}>
                            {status}
                          </span>
                        </td>
                        <td className="p-3.5 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              type="button"
                              onClick={() => setReviewingDoc(doc)}
                              className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-lg transition flex items-center gap-1 text-xs"
                            >
                              <Eye className="w-3.5 h-3.5 text-slate-500" />
                              Inspect
                            </button>

                            {status !== 'VERIFIED' && (
                              <button
                                type="button"
                                onClick={() => handleQuickVerifyDoc(doc.id, 'VERIFIED')}
                                className="p-1 text-emerald-600 hover:bg-emerald-50 rounded-lg transition"
                                title="Quick Approve"
                              >
                                <CheckCircle2 className="w-4 h-4" />
                              </button>
                            )}

                            {status !== 'REJECTED' && (
                              <button
                                type="button"
                                onClick={() => setReviewingDoc(doc)}
                                className="p-1 text-rose-600 hover:bg-rose-50 rounded-lg transition"
                                title="Reject Document"
                              >
                                <XCircle className="w-4 h-4" />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* TAB 3: MANDATORY COMPLIANCE AUDIT CHECKLIST                           */}
      {/* ===================================================================== */}
      {activeTab === 'compliance' && (
        <div className="space-y-4">
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-slate-900">Institutional Admission Document Compliance</h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Audit mandatory documentation required for state accreditation and student enrollment validation.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-slate-600">
                Mandatory: Birth Certificate • Previous TC • Immunization • Official Photo
              </span>
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-400 font-bold uppercase tracking-wider border-b border-slate-200 text-[10px]">
                <tr>
                  <th className="p-3.5">Student</th>
                  <th className="p-3.5">Admission #</th>
                  <th className="p-3.5">Class / Section</th>
                  <th className="p-3.5 text-center">Birth Certificate</th>
                  <th className="p-3.5 text-center">Transfer Cert (TC)</th>
                  <th className="p-3.5 text-center">Immunization Record</th>
                  <th className="p-3.5 text-center">Badge Photo</th>
                  <th className="p-3.5">Compliance Level</th>
                  <th className="p-3.5 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {complianceData.map(item => {
                  const verifiedCount = [item.hasBirthCert, item.hasTC, item.hasImmunization, item.hasPhoto].filter(Boolean).length;
                  const isComplete = verifiedCount === 4;
                  const isPartial = verifiedCount >= 2 && verifiedCount < 4;

                  return (
                    <tr key={item.admissionNumber} className="hover:bg-slate-50/80 transition">
                      <td className="p-3.5">
                        <strong className="text-slate-900 block font-bold">{item.studentName}</strong>
                      </td>
                      <td className="p-3.5 font-mono font-bold text-slate-700">{item.admissionNumber}</td>
                      <td className="p-3.5 text-slate-600">{item.className}</td>

                      {/* 4 Document Checkpoints */}
                      <td className="p-3.5 text-center">
                        {item.hasBirthCert ? (
                          <span className="inline-flex items-center text-emerald-600 font-bold gap-1 text-[11px]">
                            <CheckCircle2 className="w-4 h-4" /> Submitted
                          </span>
                        ) : (
                          <span className="inline-flex items-center text-rose-500 font-semibold gap-1 text-[11px]">
                            <AlertTriangle className="w-3.5 h-3.5" /> Missing
                          </span>
                        )}
                      </td>
                      <td className="p-3.5 text-center">
                        {item.hasTC ? (
                          <span className="inline-flex items-center text-emerald-600 font-bold gap-1 text-[11px]">
                            <CheckCircle2 className="w-4 h-4" /> Submitted
                          </span>
                        ) : (
                          <span className="inline-flex items-center text-rose-500 font-semibold gap-1 text-[11px]">
                            <AlertTriangle className="w-3.5 h-3.5" /> Missing
                          </span>
                        )}
                      </td>
                      <td className="p-3.5 text-center">
                        {item.hasImmunization ? (
                          <span className="inline-flex items-center text-emerald-600 font-bold gap-1 text-[11px]">
                            <CheckCircle2 className="w-4 h-4" /> Submitted
                          </span>
                        ) : (
                          <span className="inline-flex items-center text-rose-500 font-semibold gap-1 text-[11px]">
                            <AlertTriangle className="w-3.5 h-3.5" /> Missing
                          </span>
                        )}
                      </td>
                      <td className="p-3.5 text-center">
                        {item.hasPhoto ? (
                          <span className="inline-flex items-center text-emerald-600 font-bold gap-1 text-[11px]">
                            <CheckCircle2 className="w-4 h-4" /> Submitted
                          </span>
                        ) : (
                          <span className="inline-flex items-center text-rose-500 font-semibold gap-1 text-[11px]">
                            <AlertTriangle className="w-3.5 h-3.5" /> Missing
                          </span>
                        )}
                      </td>

                      {/* Compliance Status Badge */}
                      <td className="p-3.5">
                        <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider ${
                          isComplete
                            ? 'bg-emerald-100 text-emerald-800'
                            : (isPartial
                                ? 'bg-amber-100 text-amber-800'
                                : 'bg-rose-100 text-rose-800')
                        }`}>
                          {isComplete ? '100% COMPLIANT' : (isPartial ? 'PARTIAL COMPLIANCE' : 'CRITICAL MISSING')}
                        </span>
                      </td>

                      <td className="p-3.5 text-right">
                        <button
                          type="button"
                          onClick={() => setUploadDocTarget({
                            studentId: item.studentId,
                            studentName: item.studentName,
                            admissionNumber: item.admissionNumber
                          })}
                          className="px-2.5 py-1 text-xs font-semibold text-indigo-600 hover:bg-indigo-50 rounded-lg transition"
                        >
                          + Upload Doc
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* TAB 4: TEMPLATE STUDIO & LAYOUTS                                       */}
      {/* ===================================================================== */}
      {activeTab === 'templates' && (
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row items-center justify-between gap-4">
            <div>
              <h3 className="text-base font-bold text-slate-900">Official Student ID Card Design Templates</h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Preview and configure school branding, dimensions, anti-counterfeit security elements, and print presets.
              </p>
            </div>

            <div className="flex items-center gap-2">
              {(['modern-vertical', 'classic-horizontal', 'minimalist-academic', 'smart-card'] as StudentIDCardTemplateLayout[]).map(t => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setStudioTemplate(t)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition capitalize ${
                    studioTemplate === t
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {(t || '').replace(/-/g, ' ')}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Live Interactive Preview Box */}
            <div className="lg:col-span-2 bg-slate-50 p-8 rounded-2xl border border-slate-200 flex flex-col items-center justify-center min-h-[480px]">
              <span className="text-[11px] font-mono text-slate-400 mb-4 uppercase tracking-wider font-semibold">
                Live Studio Rendering • {studioTemplate}
              </span>

              <StudentIDCardVisual
                card={{
                  studentName: 'Julian Sterling Vance',
                  admissionNumber: 'ADM-2026-0842',
                  cardNumber: 'IDC-2026-00842',
                  templateId: studioTemplate,
                  status: 'ISSUED',
                  academicSessionName: '2026-2027 Academic Year',
                  className: 'Grade 10',
                  sectionName: 'Section A (Advanced)',
                  rollNumber: 'G10-A-01',
                  bloodGroup: 'O+',
                  emergencyContact: '+1 (555) 012-3456',
                  avatarUrl: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&q=80&w=256',
                  issueDate: '2026-08-20',
                  expiryDate: '2027-06-30'
                }}
                scale={1}
                interactive={true}
                showFlipControls={true}
              />
            </div>

            {/* Template Specs & Feature List */}
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4 text-xs">
              <h4 className="font-bold text-slate-900 uppercase tracking-wider text-[11px]">
                Template Specifications
              </h4>

              <div className="space-y-3 text-slate-600">
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                  <strong className="block text-slate-800 mb-1">Standard Physical Sizing:</strong>
                  <span>CR80 ISO/IEC 7810 ID-1 standard (85.60 mm × 53.98 mm) with 30-mil PVC high-durability lamination.</span>
                </div>

                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                  <strong className="block text-slate-800 mb-1">Integrated Security Features:</strong>
                  <ul className="list-disc list-inside space-y-1 text-slate-500 mt-1">
                    <li>Dynamic 256-bit encrypted token QR Code</li>
                    <li>GS1 Code-128 barcode encoding admission serial</li>
                    <li>Guilloche fine-line anti-counterfeit background</li>
                    <li>Principal signature stamp watermark</li>
                  </ul>
                </div>

                <div className="p-3 bg-indigo-50/50 rounded-xl border border-indigo-100 text-indigo-950">
                  <strong className="block text-indigo-900 mb-1">Gate Verification API:</strong>
                  <span className="text-[11px] text-indigo-900">
                    Compatible with contactless handheld barcode scanners, campus turnstiles, and mobile security cameras.
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ===================================================================== */}
      {/* MODALS & OVERLAYS                                                     */}
      {/* ===================================================================== */}

      {/* Batch / Single Print Sheet */}
      {printSheetCards && (
        <BulkIDCardPrintSheet
          cards={printSheetCards}
          onClose={() => setPrintSheetCards(null)}
        />
      )}

      {/* Reissue Modal */}
      {reissueTargetCard && (
        <StudentIDCardReissueModal
          card={reissueTargetCard}
          isOpen={!!reissueTargetCard}
          onClose={() => setReissueTargetCard(null)}
          onSuccess={(updated) => {
            setIdCards(prev => prev.map(c => (c.id === updated.id ? updated : c)));
            setReissueTargetCard(null);
          }}
        />
      )}

      {/* Generate Modal */}
      <StudentIDCardGenerateModal
        isOpen={isGenerateModalOpen}
        onClose={() => setIsGenerateModalOpen(false)}
        onSuccess={() => {
          fetchData();
          setIsGenerateModalOpen(false);
        }}
        classes={classes}
        sections={sections}
      />

      {/* Gate Security Scanner Modal */}
      <StudentIDCardScannerModal
        isOpen={isScannerModalOpen}
        onClose={() => setIsScannerModalOpen(false)}
      />

      {/* Document Review & Verification Modal */}
      {reviewingDoc && (
        <StudentDocumentReviewModal
          document={reviewingDoc}
          isOpen={!!reviewingDoc}
          onClose={() => setReviewingDoc(null)}
          onVerified={(updated) => {
            setDocuments(prev => prev.map(d => (d.id === updated.id ? updated : d)));
            setReviewingDoc(null);
          }}
        />
      )}

      {/* Document Upload Modal */}
      {uploadDocTarget && (
        <StudentDocumentUploadModal
          studentId={uploadDocTarget.studentId}
          studentName={uploadDocTarget.studentName}
          admissionNumber={uploadDocTarget.admissionNumber}
          isOpen={!!uploadDocTarget}
          onClose={() => setUploadDocTarget(null)}
          onSuccess={(newDoc) => {
            setDocuments(prev => [newDoc, ...prev]);
            setUploadDocTarget(null);
          }}
        />
      )}
    </div>
  );
};
