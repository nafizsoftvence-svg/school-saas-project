/**
 * Part 15A — Central Certificate & Document Management Foundation Page
 * Sygmate School Management System
 */

import React, { useState, useEffect, useMemo } from 'react';
import {
  FileText,
  ShieldCheck,
  Upload,
  RefreshCw,
  Search,
  Filter,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Clock,
  Eye,
  Lock,
  Download,
  Building2,
  Users,
  GraduationCap,
  User,
  LayoutGrid,
  List,
  SlidersHorizontal,
  Award,
  History,
  Tag,
  Plus,
  ArrowUpDown,
  ExternalLink,
  ChevronRight,
  FolderLock,
  Sparkles,
  Ban,
  ShieldAlert,
  Send,
  Shield,
  Calendar
} from 'lucide-react';
import {
  ManagedDocument,
  DocumentTypeConfig,
  CertificateTemplate,
  DocumentDashboardMetrics,
  DocumentEntityType,
  DocumentStatus,
  DocumentVerificationStatus,
  IssuedCertificate,
  CertificateTypeConfig,
  CertificateStatsMetrics,
  DocumentRequirementConfig,
  ExpiringDocumentItem
} from '../../types';
import { api } from '../../services/api';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { Button } from '../../components/ui/Button';
import { Card } from '../../components/ui/Card';
import { DocumentDetailModal } from '../../components/documents/DocumentDetailModal';
import { UniversalDocumentUploadModal } from '../../components/documents/UniversalDocumentUploadModal';
import { UploadVersionModal } from '../../components/documents/UploadVersionModal';
import { DocumentTypeConfigModal } from '../../components/documents/DocumentTypeConfigModal';
import { CertificateTemplatePreviewModal } from '../../components/documents/CertificateTemplatePreviewModal';
import { CertificateViewerModal } from '../../components/documents/CertificateViewerModal';
import { GenerateCertificateModal } from '../../components/documents/GenerateCertificateModal';
import { ReissueCertificateModal } from '../../components/documents/ReissueCertificateModal';
import { RevokeCancelCertificateModal } from '../../components/documents/RevokeCancelCertificateModal';
import { CertificateTypeModal } from '../../components/documents/CertificateTypeModal';
import { CertificateVerificationModal } from '../../components/documents/CertificateVerificationModal';
import { CertificateApprovalModal } from '../../components/documents/CertificateApprovalModal';
import { CertificateWorkflowTimelineModal } from '../../components/documents/CertificateWorkflowTimelineModal';
import { EntityDocumentChecklistModal } from '../../components/documents/EntityDocumentChecklistModal';
import { DocumentRequirementConfigModal } from '../../components/documents/DocumentRequirementConfigModal';
import { DocumentReportsTab } from '../../components/documents/reports/DocumentReportsTab';

interface AdminDocumentsPageProps {
  onNavigate?: (view: string) => void;
  activeTab?:
    | 'certificates'
    | 'cert-types'
    | 'all'
    | 'students'
    | 'staff'
    | 'guardians'
    | 'school'
    | 'types'
    | 'templates'
    | 'requirements'
    | 'expiring'
    | 'reports';
  onTabChange?: (tab: string) => void;
  hideTabBar?: boolean;
}

export const AdminDocumentsPage: React.FC<AdminDocumentsPageProps> = ({
  onNavigate,
  activeTab: propActiveTab,
  onTabChange,
  hideTabBar = true
}) => {
  const { user } = useAuth();
  const { showToast } = useToast();

  // Navigation tab
  const [internalTab, setInternalTab] = useState<
    'certificates' | 'cert-types' | 'all' | 'students' | 'staff' | 'guardians' | 'school' | 'types' | 'templates' | 'requirements' | 'expiring' | 'reports'
  >('certificates');
  const activeTab = propActiveTab || internalTab;
  const setActiveTab = (tab: any) => {
    setInternalTab(tab);
    onTabChange?.(tab);
  };

  // Core Data
  const [documents, setDocuments] = useState<ManagedDocument[]>([]);
  const [documentTypes, setDocumentTypes] = useState<DocumentTypeConfig[]>([]);
  const [certificateTemplates, setCertificateTemplates] = useState<CertificateTemplate[]>([]);
  const [metrics, setMetrics] = useState<DocumentDashboardMetrics | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Pagination & Filtering
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('ALL');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [verificationFilter, setVerificationFilter] = useState('ALL');
  const [expiryFilter, setExpiryFilter] = useState<'ALL' | 'EXPIRING_SOON' | 'EXPIRED'>('ALL');
  const [viewMode, setViewMode] = useState<'table' | 'grid'>('table');
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(15);
  const [totalItems, setTotalItems] = useState(0);
  const [totalPages, setTotalPages] = useState(1);

  // Modals state
  const [selectedDocForDetail, setSelectedDocForDetail] = useState<ManagedDocument | null>(null);
  const [selectedDocForVersion, setSelectedDocForVersion] = useState<ManagedDocument | null>(null);
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [uploadEntityPreset, setUploadEntityPreset] = useState<DocumentEntityType>('STUDENT');
  const [isTypeModalOpen, setIsTypeModalOpen] = useState(false);
  const [editingType, setEditingType] = useState<DocumentTypeConfig | null>(null);
  const [previewingTemplate, setPreviewingTemplate] = useState<CertificateTemplate | null>(null);

  // Part 15C — Certificate Generation & Issuance State
  const [certificates, setCertificates] = useState<IssuedCertificate[]>([]);
  const [certificateTypes, setCertificateTypes] = useState<CertificateTypeConfig[]>([]);
  const [certMetrics, setCertMetrics] = useState<CertificateStatsMetrics | null>(null);
  const [certSearch, setCertSearch] = useState('');
  const [certTypeFilter, setCertTypeFilter] = useState('ALL');
  const [certStatusFilter, setCertStatusFilter] = useState('ALL');
  const [certLoading, setCertLoading] = useState(false);

  // Certificate Modals
  const [viewingCertificate, setViewingCertificate] = useState<IssuedCertificate | null>(null);
  const [isGenerateModalOpen, setIsGenerateModalOpen] = useState(false);
  const [reissuingCertificate, setReissuingCertificate] = useState<IssuedCertificate | null>(null);
  const [revokeCancelCert, setRevokeCancelCert] = useState<{ cert: IssuedCertificate; mode: 'CANCEL' | 'REVOKE' } | null>(null);
  const [isCertTypeModalOpen, setIsCertTypeModalOpen] = useState(false);
  const [editingCertType, setEditingCertType] = useState<CertificateTypeConfig | null>(null);

  // Part 15D — Verification, Approval & Timeline Modals State
  const [verifyingCertificate, setVerifyingCertificate] = useState<IssuedCertificate | null>(null);
  const [approvingCertificate, setApprovingCertificate] = useState<IssuedCertificate | null>(null);
  const [timelineCertificate, setTimelineCertificate] = useState<IssuedCertificate | null>(null);

  // Part 15E — Requirements & Expiring State
  const [requirements, setRequirements] = useState<DocumentRequirementConfig[]>([]);
  const [expiringDocuments, setExpiringDocuments] = useState<ExpiringDocumentItem[]>([]);
  const [reqEntityTypeFilter, setReqEntityTypeFilter] = useState<string>('ALL');
  const [expiringEntityFilter, setExpiringEntityFilter] = useState<string>('ALL');
  const [expiringHorizonFilter, setExpiringHorizonFilter] = useState<string>('30');
  const [selectedEntityForChecklist, setSelectedEntityForChecklist] = useState<{
    entityType: DocumentEntityType;
    entityId: string;
    entityName?: string;
  } | null>(null);
  const [isRequirementModalOpen, setIsRequirementModalOpen] = useState(false);
  const [editingRequirement, setEditingRequirement] = useState<DocumentRequirementConfig | null>(null);

  // Helper to extract array safely from API response envelopes
  const extractArray = <T,>(res: any): T[] => {
    if (!res) return [];
    if (Array.isArray(res)) return res;
    if (Array.isArray(res.data)) return res.data;
    if (Array.isArray(res.items)) return res.items;
    return [];
  };

  // Fetch metrics & supporting metadata
  const loadSupportingData = async () => {
    try {
      const [metricsRes, typesRes, templatesRes, reqsRes, expiringRes] = await Promise.all([
        api.documents.getMetrics(),
        api.documents.getTypes(),
        api.documents.getCertificateTemplates(),
        api.documents.getRequirements(),
        api.documents.getExpiringDocuments({ daysThreshold: 60 })
      ]);

      if (metricsRes) setMetrics((metricsRes as any)?.data || metricsRes);
      if (typesRes) setDocumentTypes(extractArray<DocumentTypeConfig>(typesRes));
      if (templatesRes) setCertificateTemplates(extractArray<CertificateTemplate>(templatesRes));
      if (reqsRes) setRequirements(extractArray<DocumentRequirementConfig>(reqsRes));
      if (expiringRes) setExpiringDocuments(extractArray<ExpiringDocumentItem>(expiringRes));
    } catch (err: any) {
      console.error('Failed loading document metadata', err);
    }
  };

  // Load Certificates
  const loadCertificates = async () => {
    try {
      setCertLoading(true);
      const [certsRes, metricsRes, typesRes] = await Promise.all([
        api.certificates.getCertificates({
          search: certSearch || undefined,
          certificateTypeId: certTypeFilter !== 'ALL' ? certTypeFilter : undefined,
          status: certStatusFilter !== 'ALL' ? (certStatusFilter as any) : undefined,
          limit: 100
        }),
        api.certificates.getMetrics(),
        api.certificates.getTypes()
      ]);
      if (certsRes?.items) {
        setCertificates(certsRes.items);
      } else if (Array.isArray((certsRes as any)?.data)) {
        setCertificates((certsRes as any).data);
      } else if (Array.isArray(certsRes)) {
        setCertificates(certsRes);
      }
      if (metricsRes) setCertMetrics((metricsRes as any)?.data || metricsRes);
      if (typesRes) setCertificateTypes(extractArray<CertificateTypeConfig>(typesRes));
    } catch (err: any) {
      console.error('Failed loading certificates', err);
    } finally {
      setCertLoading(false);
    }
  };

  // Fetch documents list based on tab & filters
  const loadDocuments = async () => {
    setLoading(true);
    setError(null);
    try {
      let entityTypeParam: DocumentEntityType | 'ALL' | undefined = undefined;
      if (activeTab === 'students') entityTypeParam = 'STUDENT';
      else if (activeTab === 'staff') entityTypeParam = 'TEACHER'; // Or STAFF, handled below
      else if (activeTab === 'guardians') entityTypeParam = 'GUARDIAN';
      else if (activeTab === 'school') entityTypeParam = 'SCHOOL';

      const filterParams: any = {
        search: search.trim() || undefined,
        category: categoryFilter !== 'ALL' ? categoryFilter : undefined,
        status: statusFilter !== 'ALL' ? statusFilter : undefined,
        verificationStatus: verificationFilter !== 'ALL' ? verificationFilter : undefined,
        page,
        limit
      };

      if (activeTab === 'staff') {
        // We will fetch all and filter in client or pass entityType
      } else if (entityTypeParam && entityTypeParam !== 'ALL') {
        filterParams.entityType = entityTypeParam;
      }

      if (expiryFilter === 'EXPIRED') {
        filterParams.isExpired = true;
      } else if (expiryFilter === 'EXPIRING_SOON') {
        filterParams.expiringWithinDays = 30;
      }

      const res = await api.documents.getDocuments(filterParams);
      if (res && 'data' in res && Array.isArray((res as any).data)) {
        let items: ManagedDocument[] = (res as any).data;
        if (activeTab === 'staff') {
          items = items.filter((d: ManagedDocument) => d.entityType === 'TEACHER' || d.entityType === 'STAFF');
        }
        setDocuments(items);
        if ((res as any).pagination) {
          setTotalItems((res as any).pagination.total);
          setTotalPages((res as any).pagination.totalPages);
        }
      }
    } catch (err: any) {
      setError(err.message || 'Failed to retrieve documents.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadSupportingData();
    loadCertificates();
  }, []);

  useEffect(() => {
    if (
      activeTab !== 'types' &&
      activeTab !== 'templates' &&
      activeTab !== 'certificates' &&
      activeTab !== 'cert-types' &&
      activeTab !== 'reports'
    ) {
      loadDocuments();
    }
  }, [activeTab, search, categoryFilter, statusFilter, verificationFilter, expiryFilter, page]);

  useEffect(() => {
    if (activeTab === 'certificates' || activeTab === 'cert-types') {
      loadCertificates();
    }
  }, [activeTab, certSearch, certTypeFilter, certStatusFilter]);

  // Actions
  const handleVerifyDocument = async (
    doc: ManagedDocument,
    status: 'VERIFIED' | 'REJECTED',
    remarks?: string
  ) => {
    try {
      const updated = await api.documents.verifyDocument(doc.id, {
        verificationStatus: status,
        verificationRemarks: remarks,
        rejectionReason: status === 'REJECTED' ? remarks : undefined
      });
      showToast({
        title: status === 'VERIFIED' ? 'Document Verified' : 'Document Rejected',
        message: `"${doc.documentTitle}" is now marked as ${status}.`,
        type: status === 'VERIFIED' ? 'success' : 'info'
      });
      loadDocuments();
      loadSupportingData();
      if (selectedDocForDetail?.id === doc.id) {
        setSelectedDocForDetail(updated);
      }
    } catch (err: any) {
      showToast({
        title: 'Action Failed',
        message: err.message || 'Failed to update verification status.',
        type: 'error'
      });
      throw err;
    }
  };

  const handleArchiveDocument = async (doc: ManagedDocument) => {
    try {
      await api.documents.archiveDocument(doc.id);
      showToast({
        title: 'Document Archived',
        message: `"${doc.documentTitle}" has been archived.`,
        type: 'success'
      });
      loadDocuments();
      loadSupportingData();
      if (selectedDocForDetail?.id === doc.id) {
        setSelectedDocForDetail(null);
      }
    } catch (err: any) {
      showToast({
        title: 'Archive Failed',
        message: err.message || 'Failed to archive document.',
        type: 'error'
      });
    }
  };

  const handleClearFilters = () => {
    setSearch('');
    setCategoryFilter('ALL');
    setStatusFilter('ALL');
    setVerificationFilter('ALL');
    setExpiryFilter('ALL');
    setPage(1);
  };

  const getEntityIcon = (entityType: DocumentEntityType) => {
    switch (entityType) {
      case 'STUDENT':
        return <GraduationCap className="w-3.5 h-3.5 text-sky-400" />;
      case 'TEACHER':
      case 'STAFF':
        return <User className="w-3.5 h-3.5 text-purple-400" />;
      case 'GUARDIAN':
        return <Users className="w-3.5 h-3.5 text-amber-400" />;
      case 'SCHOOL':
      case 'DEPARTMENT':
        return <Building2 className="w-3.5 h-3.5 text-emerald-400" />;
      default:
        return <FileText className="w-3.5 h-3.5 text-slate-400" />;
    }
  };

  const getStatusBadge = (doc: ManagedDocument) => {
    const isExpired = doc.expiryDate && new Date(doc.expiryDate) < new Date();
    const isExpiringSoon =
      doc.expiryDate &&
      !isExpired &&
      new Date(doc.expiryDate) <= new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);

    if (isExpired) {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-500/10 text-rose-400 border border-rose-500/20">
          <AlertTriangle className="w-3 h-3" /> Expired
        </span>
      );
    }
    if (doc.verificationStatus === 'VERIFIED') {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
          <CheckCircle2 className="w-3 h-3" /> Verified
        </span>
      );
    }
    if (doc.verificationStatus === 'REJECTED') {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-red-500/10 text-red-400 border border-red-500/20">
          <XCircle className="w-3 h-3" /> Rejected
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/20">
        <Clock className="w-3 h-3" /> Pending Review
      </span>
    );
  };

  return (
    <div className="space-y-6">
      {/* Top Banner Header */}
      <div className="p-6 md:p-8 rounded-3xl bg-gradient-to-r from-slate-900 via-slate-800 to-indigo-950 border border-slate-700/60 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 rounded-full text-xs font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              Part 15A • Foundation Architecture
            </span>
            <span className="px-3 py-1 rounded-full text-xs font-semibold bg-slate-800 text-slate-300 border border-slate-700">
              Institutional Vault
            </span>
          </div>
          <h1 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight flex items-center gap-3">
            <FolderLock className="w-8 h-8 text-indigo-400" />
            Certificate & Document Management
          </h1>
          <p className="text-sm text-slate-300 max-w-2xl leading-relaxed">
            Centralized document depository and certificate foundation supporting multi-entity verifications, immutable version histories, and regulatory compliance.
          </p>
        </div>

        <div className="flex items-center gap-3 flex-wrap">
          <Button
            size="md"
            variant="outline"
            onClick={() => {
              loadDocuments();
              loadSupportingData();
            }}
            className="flex items-center gap-2 border-slate-700 hover:bg-slate-800 text-slate-200"
          >
            <RefreshCw className="w-4 h-4" />
            Refresh
          </Button>
          <Button
            size="md"
            variant="default"
            onClick={() => setIsGenerateModalOpen(true)}
            className="bg-indigo-600 hover:bg-indigo-500 text-white flex items-center gap-2 shadow-lg font-bold"
          >
            <Award className="w-4 h-4" />
            Generate Certificate
          </Button>

          <Button
            size="md"
            variant="outline"
            onClick={() => {
              setEditingCertType(null);
              setIsCertTypeModalOpen(true);
            }}
            className="flex items-center gap-2 border-slate-700 hover:bg-slate-800 text-slate-200"
          >
            <Plus className="w-4 h-4 text-indigo-400" />
            New Certificate Type
          </Button>

          <Button
            size="md"
            variant="outline"
            onClick={() => {
              setUploadEntityPreset('STUDENT');
              setIsUploadModalOpen(true);
            }}
            className="border-slate-700 hover:bg-slate-800 text-slate-200 flex items-center gap-2"
          >
            <Upload className="w-4 h-4" />
            Upload Document
          </Button>

          <Button
            size="md"
            variant="outline"
            onClick={() => {
              loadDocuments();
              loadCertificates();
              loadSupportingData();
            }}
            className="flex items-center gap-2 border-slate-700 hover:bg-slate-800"
          >
            <RefreshCw className="w-4 h-4" />
            Refresh
          </Button>
        </div>
      </div>

      {/* Metrics Dashboard Row */}
      {metrics && (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
          <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-1 shadow-sm">
            <div className="flex items-center justify-between text-slate-400">
              <span className="text-xs font-semibold uppercase tracking-wider">Total Vault</span>
              <FileText className="w-4 h-4 text-indigo-400" />
            </div>
            <div className="text-2xl font-extrabold text-white">{metrics.totalDocuments}</div>
            <p className="text-[11px] text-slate-500">Across all institutional records</p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-1 shadow-sm">
            <div className="flex items-center justify-between text-slate-400">
              <span className="text-xs font-semibold uppercase tracking-wider">Active</span>
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="text-2xl font-extrabold text-white">{metrics.activeDocuments}</div>
            <p className="text-[11px] text-emerald-400/80 font-medium">Valid credentials</p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-900 border border-amber-500/20 bg-amber-500/5 space-y-1 shadow-sm">
            <div className="flex items-center justify-between text-amber-400">
              <span className="text-xs font-semibold uppercase tracking-wider">Pending Review</span>
              <Clock className="w-4 h-4 text-amber-400" />
            </div>
            <div className="text-2xl font-extrabold text-amber-300">{metrics.pendingReview}</div>
            <p className="text-[11px] text-amber-400/80 font-medium">Awaiting administrator review</p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-1 shadow-sm">
            <div className="flex items-center justify-between text-slate-400">
              <span className="text-xs font-semibold uppercase tracking-wider">Verified</span>
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="text-2xl font-extrabold text-white">{metrics.verified}</div>
            <p className="text-[11px] text-slate-500">Seal & authenticity confirmed</p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-900 border border-indigo-500/20 bg-indigo-500/5 space-y-1 shadow-sm">
            <div className="flex items-center justify-between text-indigo-400">
              <span className="text-xs font-semibold uppercase tracking-wider">Certificates</span>
              <Award className="w-4 h-4 text-indigo-400" />
            </div>
            <div className="text-2xl font-extrabold text-indigo-300">
              {certMetrics?.totalCertificates ?? (certificates?.length || 0)}
            </div>
            <p className="text-[11px] text-indigo-400/80 font-medium">
              {certMetrics?.issued ?? 0} officially issued
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-900 border border-rose-500/20 bg-rose-500/5 space-y-1 shadow-sm">
            <div className="flex items-center justify-between text-rose-400">
              <span className="text-xs font-semibold uppercase tracking-wider">Expired</span>
              <XCircle className="w-4 h-4 text-rose-400" />
            </div>
            <div className="text-2xl font-extrabold text-rose-300">{metrics.expired}</div>
            <p className="text-[11px] text-rose-400/80 font-medium">Renewal required</p>
          </div>
        </div>
      )}

      {/* Main Tabs Navigation */}
      {!hideTabBar && (
        <div className="border-b border-slate-800 flex items-center justify-between gap-4 overflow-x-auto pb-px">
          <div className="flex items-center gap-1 sm:gap-2">
            {[
              { id: 'certificates', label: 'Issued Certificates', count: certMetrics?.totalCertificates ?? (Array.isArray(certificates) ? certificates.length : 0) },
              { id: 'cert-types', label: 'Certificate Types', count: Array.isArray(certificateTypes) ? certificateTypes.length : 0 },
              { id: 'templates', label: 'Certificate Templates', count: Array.isArray(certificateTemplates) ? certificateTemplates.length : 0 },
              { id: 'all', label: 'All Vault Docs', count: metrics?.totalDocuments },
              { id: 'students', label: 'Student Docs', count: metrics?.entityBreakdown?.student },
              { id: 'staff', label: 'Staff & Teachers', count: (metrics?.entityBreakdown?.teacher || 0) + (metrics?.entityBreakdown?.staff || 0) },
              { id: 'guardians', label: 'Guardian Docs', count: metrics?.entityBreakdown?.guardian },
              { id: 'school', label: 'School & Institutional', count: metrics?.entityBreakdown?.school },
              { id: 'requirements', label: 'Doc Requirements', count: Array.isArray(requirements) ? requirements.length : 0 },
              { id: 'expiring', label: 'Expiring & Overdue', count: Array.isArray(expiringDocuments) ? expiringDocuments.length : 0 },
              { id: 'types', label: 'Doc Types', count: Array.isArray(documentTypes) ? documentTypes.length : 0 },
              { id: 'reports', label: 'Reports & Analytics', badge: '15F' }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => {
                  setActiveTab(tab.id as any);
                  setPage(1);
                }}
                className={`py-3 px-4 text-sm font-semibold rounded-t-xl transition-all whitespace-nowrap flex items-center gap-2 border-b-2 -mb-px ${
                  activeTab === tab.id
                    ? 'border-indigo-500 text-white bg-slate-800/40'
                    : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/20'
                }`}
              >
                <span>{tab.label}</span>
                {typeof tab.count === 'number' && (
                  <span
                    className={`px-2 py-0.5 rounded-full text-xs font-bold ${
                      activeTab === tab.id
                        ? 'bg-indigo-600 text-white'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {tab.count}
                  </span>
                )}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* TAB 1-5: Documents List Views */}
      {activeTab !== 'types' && activeTab !== 'templates' && activeTab !== 'certificates' && activeTab !== 'cert-types' && activeTab !== 'requirements' && activeTab !== 'expiring' && (
        <div className="space-y-4">
          {/* Search & Filter Toolbar */}
          <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col lg:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3 w-full lg:w-auto flex-1 flex-wrap">
              {/* Search Bar */}
              <div className="relative flex-1 min-w-[240px]">
                <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  value={search}
                  onChange={(e) => {
                    setSearch(e.target.value);
                    setPage(1);
                  }}
                  placeholder="Search by title, owner, ref #, or file name..."
                  className="w-full pl-10 pr-4 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 placeholder-slate-500"
                />
              </div>

              {/* Category Filter */}
              <select
                value={categoryFilter}
                onChange={(e) => {
                  setCategoryFilter(e.target.value);
                  setPage(1);
                }}
                className="px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="ALL">All Categories</option>
                <option value="IDENTIFICATION">IDENTIFICATION</option>
                <option value="ACADEMIC">ACADEMIC</option>
                <option value="EMPLOYMENT">EMPLOYMENT</option>
                <option value="LEGAL">LEGAL</option>
                <option value="MEDICAL">MEDICAL</option>
                <option value="FINANCIAL">FINANCIAL</option>
                <option value="INSTITUTIONAL">INSTITUTIONAL</option>
                <option value="OTHER">OTHER</option>
              </select>

              {/* Status Filter */}
              <select
                value={verificationFilter}
                onChange={(e) => {
                  setVerificationFilter(e.target.value);
                  setPage(1);
                }}
                className="px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="ALL">All Verification States</option>
                <option value="PENDING_REVIEW">Pending Review</option>
                <option value="VERIFIED">Verified</option>
                <option value="REJECTED">Rejected</option>
              </select>

              {/* Expiry Filter */}
              <select
                value={expiryFilter}
                onChange={(e) => {
                  setExpiryFilter(e.target.value as any);
                  setPage(1);
                }}
                className="px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="ALL">All Expiry States</option>
                <option value="EXPIRING_SOON">Expiring Soon (30 Days)</option>
                <option value="EXPIRED">Expired</option>
              </select>

              {(search || categoryFilter !== 'ALL' || verificationFilter !== 'ALL' || expiryFilter !== 'ALL') && (
                <button
                  onClick={handleClearFilters}
                  className="px-3 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 transition-colors"
                >
                  Clear Filters
                </button>
              )}
            </div>

            {/* View Mode Toggle */}
            <div className="flex items-center gap-1 p-1 bg-slate-800 rounded-xl border border-slate-700 shrink-0">
              <button
                onClick={() => setViewMode('table')}
                className={`p-1.5 rounded-lg transition-colors ${
                  viewMode === 'table' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
                title="Table View"
              >
                <List className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewMode('grid')}
                className={`p-1.5 rounded-lg transition-colors ${
                  viewMode === 'grid' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
                title="Card Grid View"
              >
                <LayoutGrid className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Documents Content */}
          {loading ? (
            <div className="p-16 text-center rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
              <RefreshCw className="w-8 h-8 text-indigo-400 animate-spin mx-auto" />
              <p className="text-sm font-semibold text-slate-300">Loading document vault records...</p>
            </div>
          ) : error ? (
            <div className="p-8 text-center rounded-2xl bg-red-500/10 border border-red-500/20 text-red-300 space-y-2">
              <AlertTriangle className="w-8 h-8 text-red-400 mx-auto" />
              <p className="text-sm font-semibold">{error}</p>
              <Button size="sm" variant="outline" onClick={loadDocuments}>
                Retry
              </Button>
            </div>
          ) : (documents?.length || 0) === 0 ? (
            <div className="p-16 text-center rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
              <FileText className="w-10 h-10 text-slate-600 mx-auto" />
              <h3 className="text-base font-bold text-white">No documents found</h3>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                No document records match your current filter parameters or search term.
              </p>
              <Button
                size="sm"
                variant="default"
                onClick={() => setIsUploadModalOpen(true)}
                className="bg-indigo-600 hover:bg-indigo-500 mt-2"
              >
                <Upload className="w-4 h-4 mr-1.5" />
                Upload New Document
              </Button>
            </div>
          ) : viewMode === 'table' ? (
            /* Table View */
            <div className="rounded-2xl bg-slate-900 border border-slate-800 overflow-hidden shadow-xl">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm text-slate-300">
                  <thead className="bg-slate-800/60 text-xs font-semibold text-slate-400 uppercase tracking-wider border-b border-slate-800">
                    <tr>
                      <th className="px-6 py-4">Document Title & File</th>
                      <th className="px-4 py-4">Entity / Owner</th>
                      <th className="px-4 py-4">Category & Type</th>
                      <th className="px-4 py-4">Reference #</th>
                      <th className="px-4 py-4">Version</th>
                      <th className="px-4 py-4">Expiry Date</th>
                      <th className="px-4 py-4">Verification</th>
                      <th className="px-6 py-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {(Array.isArray(documents) ? documents : []).map((doc) => (
                      <tr
                        key={doc.id}
                        className="hover:bg-slate-800/30 transition-colors group cursor-pointer"
                        onClick={() => setSelectedDocForDetail(doc)}
                      >
                        <td className="px-6 py-4">
                          <div className="flex items-start gap-3">
                            <div className="p-2 rounded-xl bg-indigo-500/10 text-indigo-400 shrink-0 mt-0.5">
                              <FileText className="w-4 h-4" />
                            </div>
                            <div className="min-w-0">
                              <div className="flex items-center gap-1.5">
                                <span className="font-semibold text-white group-hover:text-indigo-300 transition-colors truncate">
                                  {doc.documentTitle}
                                </span>
                                {doc.isConfidential && (
                                  <Lock className="w-3 h-3 text-rose-400 shrink-0" title="Confidential" />
                                )}
                              </div>
                              <span className="text-xs text-slate-400 block truncate" title={doc.fileName}>
                                {doc.fileName} • {doc.fileSize}
                              </span>
                            </div>
                          </div>
                        </td>

                        <td className="px-4 py-4 whitespace-nowrap">
                          <div className="flex items-center gap-2">
                            {getEntityIcon(doc.entityType)}
                            <div>
                              <span className="font-medium text-slate-200 block text-xs">
                                {doc.entityName || doc.entityId}
                              </span>
                              {doc.entityCode && (
                                <span className="text-[10px] text-slate-500 font-mono">
                                  {doc.entityCode}
                                </span>
                              )}
                            </div>
                          </div>
                        </td>

                        <td className="px-4 py-4 whitespace-nowrap">
                          <span className="px-2 py-0.5 rounded text-xs bg-slate-800 text-slate-300 border border-slate-700 block w-max">
                            {doc.documentTypeName}
                          </span>
                          <span className="text-[10px] text-indigo-300 font-mono block mt-0.5">
                            {doc.category}
                          </span>
                        </td>

                        <td className="px-4 py-4 whitespace-nowrap font-mono text-xs text-slate-400">
                          {doc.referenceNumber || '—'}
                        </td>

                        <td className="px-4 py-4 whitespace-nowrap">
                          <span className="px-2 py-0.5 rounded text-xs font-bold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                            v{doc.version}
                          </span>
                        </td>

                        <td className="px-4 py-4 whitespace-nowrap text-xs">
                          {doc.expiryDate ? (
                            <span
                              className={
                                new Date(doc.expiryDate) < new Date()
                                  ? 'text-rose-400 font-semibold'
                                  : 'text-slate-300'
                              }
                            >
                              {new Date(doc.expiryDate).toLocaleDateString()}
                            </span>
                          ) : (
                            <span className="text-slate-500">None</span>
                          )}
                        </td>

                        <td className="px-4 py-4 whitespace-nowrap">
                          {getStatusBadge(doc)}
                        </td>

                        <td className="px-6 py-4 whitespace-nowrap text-right" onClick={(e) => e.stopPropagation()}>
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => setSelectedEntityForChecklist({
                                entityType: doc.entityType,
                                entityId: doc.entityId,
                                entityName: doc.entityName
                              })}
                              className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-400 hover:bg-slate-800 transition-colors"
                              title="View Entity Compliance Checklist"
                            >
                              <ShieldCheck className="w-4 h-4 text-indigo-400" />
                            </button>

                            <button
                              onClick={() => setSelectedDocForDetail(doc)}
                              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                              title="View Document Details & Preview"
                            >
                              <Eye className="w-4 h-4" />
                            </button>

                            <button
                              onClick={() => setSelectedDocForVersion(doc)}
                              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                              title="Upload New Version"
                            >
                              <Upload className="w-4 h-4" />
                            </button>

                            <a
                              href={doc.fileUrl}
                              download={doc.fileName}
                              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                              title="Download File"
                            >
                              <Download className="w-4 h-4" />
                            </a>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Pagination Footer */}
              <div className="p-4 border-t border-slate-800 bg-slate-900/60 flex items-center justify-between text-xs text-slate-400">
                <div>
                  Showing {documents?.length || 0} of {totalItems} documents
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    disabled={page <= 1}
                    onClick={() => setPage((p) => Math.max(1, p - 1))}
                  >
                    Previous
                  </Button>
                  <span className="px-2 font-medium text-slate-300">
                    Page {page} of {totalPages}
                  </span>
                  <Button
                    size="sm"
                    variant="outline"
                    disabled={page >= totalPages}
                    onClick={() => setPage((p) => p + 1)}
                  >
                    Next
                  </Button>
                </div>
              </div>
            </div>
          ) : (
            /* Card Grid View */
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {(Array.isArray(documents) ? documents : []).map((doc) => (
                <div
                  key={doc.id}
                  onClick={() => setSelectedDocForDetail(doc)}
                  className="p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all hover:shadow-xl flex flex-col justify-between space-y-4 cursor-pointer group"
                >
                  <div className="space-y-3">
                    <div className="flex items-start justify-between gap-2">
                      <div className="p-2.5 rounded-xl bg-indigo-500/10 text-indigo-400">
                        <FileText className="w-5 h-5" />
                      </div>
                      <div className="flex items-center gap-1.5">
                        <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                          v{doc.version}
                        </span>
                        {getStatusBadge(doc)}
                      </div>
                    </div>

                    <div>
                      <h4 className="font-bold text-white group-hover:text-indigo-300 transition-colors line-clamp-1 text-base">
                        {doc.documentTitle}
                      </h4>
                      <p className="text-xs text-slate-400 truncate mt-0.5" title={doc.fileName}>
                        {doc.fileName} • {doc.fileSize}
                      </p>
                    </div>

                    <div className="p-2.5 rounded-xl bg-slate-800/40 border border-slate-800 space-y-1.5 text-xs">
                      <div className="flex items-center justify-between text-slate-400">
                        <span className="flex items-center gap-1">
                          {getEntityIcon(doc.entityType)}
                          <strong className="text-slate-300">{doc.entityName || doc.entityId}</strong>
                        </span>
                        <span className="text-[10px] text-slate-500">{doc.entityType}</span>
                      </div>
                      <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-800">
                        <span>Type: {doc.documentTypeName}</span>
                        {doc.referenceNumber && <span className="font-mono">{doc.referenceNumber}</span>}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 text-xs text-slate-400">
                    <span>Updated {new Date(doc.updatedAt).toLocaleDateString()}</span>
                    <span className="text-indigo-400 font-semibold group-hover:translate-x-0.5 transition-transform flex items-center gap-1">
                      Details <ChevronRight className="w-3.5 h-3.5" />
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 6: Configurable Document Types Management */}
      {activeTab === 'types' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between gap-4 flex-wrap">
            <div>
              <h3 className="text-base font-bold text-white">Configurable Document Categories & Types</h3>
              <p className="text-xs text-slate-400">
                Manage allowed file formats, mandatory requirements, and validity periods across all entities.
              </p>
            </div>
            <Button
              size="sm"
              variant="default"
              onClick={() => {
                setEditingType(null);
                setIsTypeModalOpen(true);
              }}
              className="bg-indigo-600 hover:bg-indigo-500 text-white flex items-center gap-1.5 shadow"
            >
              <Plus className="w-4 h-4" />
              Add Document Type
            </Button>
          </div>

          <div className="rounded-2xl bg-slate-900 border border-slate-800 overflow-hidden shadow-xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm text-slate-300">
                <thead className="bg-slate-800/60 text-xs font-semibold text-slate-400 uppercase tracking-wider border-b border-slate-800">
                  <tr>
                    <th className="px-6 py-4">Document Type</th>
                    <th className="px-4 py-4">Scope</th>
                    <th className="px-4 py-4">Category</th>
                    <th className="px-4 py-4">Requirement</th>
                    <th className="px-4 py-4">Expiry Tracking</th>
                    <th className="px-4 py-4">Allowed Extensions</th>
                    <th className="px-4 py-4">Max Size</th>
                    <th className="px-6 py-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {(Array.isArray(documentTypes) ? documentTypes : []).map((dt) => (
                    <tr key={dt.id} className="hover:bg-slate-800/30 transition-colors">
                      <td className="px-6 py-4">
                        <span className="font-semibold text-white block">{dt.name}</span>
                        <span className="text-xs text-slate-400 line-clamp-1">{dt.description}</span>
                      </td>
                      <td className="px-4 py-4 whitespace-nowrap">
                        <span className="px-2.5 py-1 rounded-full text-xs font-medium bg-slate-800 text-slate-300 border border-slate-700">
                          {dt.applicableEntityType}
                        </span>
                      </td>
                      <td className="px-4 py-4 whitespace-nowrap font-mono text-xs text-indigo-400">
                        {dt.category}
                      </td>
                      <td className="px-4 py-4 whitespace-nowrap">
                        {dt.isRequired ? (
                          <span className="px-2 py-0.5 rounded text-xs font-bold bg-rose-500/10 text-rose-400 border border-rose-500/20">
                            Mandatory
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded text-xs text-slate-400 bg-slate-800">
                            Optional
                          </span>
                        )}
                      </td>
                      <td className="px-4 py-4 whitespace-nowrap text-xs">
                        {dt.hasExpiry ? (
                          <span className="text-amber-400 font-medium">
                            Yes ({dt.defaultExpiryMonths || 12} mo)
                          </span>
                        ) : (
                          <span className="text-slate-500">None</span>
                        )}
                      </td>
                      <td className="px-4 py-4 whitespace-nowrap font-mono text-xs text-slate-300">
                        {dt.allowedExtensions.join(', ')}
                      </td>
                      <td className="px-4 py-4 whitespace-nowrap text-xs text-slate-400">
                        {(dt.maxSizeBytes / (1024 * 1024)).toFixed(0)} MB
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            setEditingType(dt);
                            setIsTypeModalOpen(true);
                          }}
                        >
                          Edit
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 7: Foundational Certificate Templates */}
      {activeTab === 'templates' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between gap-4 flex-wrap">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Award className="w-5 h-5 text-amber-400" />
                Certificate Templates Foundation
              </h3>
              <p className="text-xs text-slate-400">
                Pre-configured institutional certificate designs prepared for Part 15B certificate generation & QR verification workflows.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {(Array.isArray(certificateTemplates) ? certificateTemplates : []).map((tmpl) => (
              <div
                key={tmpl.id}
                onClick={() => setPreviewingTemplate(tmpl)}
                className="p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-amber-500/40 transition-all hover:shadow-xl flex flex-col justify-between space-y-4 cursor-pointer group"
              >
                <div className="space-y-3">
                  <div className="flex items-start justify-between">
                    <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-400">
                      <Award className="w-5 h-5" />
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-slate-300 border border-slate-700">
                        {tmpl.orientation}
                      </span>
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/10 text-amber-400 border border-amber-500/20">
                        {tmpl.category}
                      </span>
                    </div>
                  </div>

                  <div>
                    <h4 className="font-bold text-white group-hover:text-amber-300 transition-colors text-base">
                      {tmpl.name}
                    </h4>
                    <p className="text-xs text-slate-400 line-clamp-2 mt-1">
                      {tmpl.description}
                    </p>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-800/40 border border-slate-800 text-xs space-y-1">
                    <div className="flex justify-between text-slate-400">
                      <span>Target Entity:</span>
                      <strong className="text-slate-200">{tmpl.entityType}</strong>
                    </div>
                    <div className="flex justify-between text-slate-400">
                      <span>Layout Design:</span>
                      <span className="font-mono text-amber-300">{tmpl.layoutDesign}</span>
                    </div>
                    <div className="flex justify-between text-slate-400">
                      <span>QR Verification:</span>
                      <span className="text-emerald-400 font-semibold">{tmpl.qrCodeEnabled ? 'Enabled' : 'Disabled'}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-xs">
                  <span className="text-slate-500">Signatories: {tmpl.signatories?.length || 0}</span>
                  <span className="text-amber-400 font-semibold flex items-center gap-1 group-hover:translate-x-0.5 transition-transform">
                    Preview Canvas <ChevronRight className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB: Issued & Generated Certificates */}
      {activeTab === 'certificates' && (
        <div className="space-y-4">
          {/* Search & Filter Toolbar */}
          <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col lg:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3 w-full lg:w-auto flex-1 flex-wrap">
              {/* Search */}
              <div className="relative flex-1 min-w-[240px]">
                <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  value={certSearch}
                  onChange={(e) => setCertSearch(e.target.value)}
                  placeholder="Search by serial #, student name, admission, or remarks..."
                  className="w-full pl-10 pr-4 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 placeholder-slate-500"
                />
              </div>

              {/* Certificate Type Filter */}
              <select
                value={certTypeFilter}
                onChange={(e) => setCertTypeFilter(e.target.value)}
                className="px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="ALL">All Certificate Types</option>
                {(Array.isArray(certificateTypes) ? certificateTypes : []).map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.name}
                  </option>
                ))}
              </select>

              {/* Status Filter */}
              <select
                value={certStatusFilter}
                onChange={(e) => setCertStatusFilter(e.target.value)}
                className="px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="ALL">All Statuses</option>
                <option value="ISSUED">Officially Issued</option>
                <option value="APPROVED">Approved (Ready for Issuance)</option>
                <option value="PENDING_APPROVAL">Pending Leadership Approval</option>
                <option value="VERIFIED">Verified</option>
                <option value="PENDING_VERIFICATION">Pending Review / Verification</option>
                <option value="GENERATED">Generated (Pending Review)</option>
                <option value="DRAFT">Draft</option>
                <option value="VERIFICATION_REJECTED">Verification Rejected</option>
                <option value="APPROVAL_REJECTED">Approval Rejected</option>
                <option value="REVOKED">Revoked</option>
                <option value="CANCELLED">Cancelled</option>
              </select>

              {(certSearch || certTypeFilter !== 'ALL' || certStatusFilter !== 'ALL') && (
                <button
                  onClick={() => {
                    setCertSearch('');
                    setCertTypeFilter('ALL');
                    setCertStatusFilter('ALL');
                  }}
                  className="text-xs text-slate-400 hover:text-white underline px-1"
                >
                  Reset Filters
                </button>
              )}
            </div>

            <div className="flex items-center gap-2">
              <Button
                size="sm"
                variant="default"
                onClick={() => setIsGenerateModalOpen(true)}
                className="bg-indigo-600 hover:bg-indigo-500 text-white flex items-center gap-1.5 shadow"
              >
                <Award className="w-4 h-4" />
                Generate New Certificate
              </Button>
            </div>
          </div>

          {/* Certificates Table */}
          <div className="rounded-2xl bg-slate-900 border border-slate-800 overflow-hidden shadow-xl">
            {certLoading ? (
              <div className="p-12 text-center text-slate-400 text-sm">
                Loading academic certificates from institutional registry...
              </div>
            ) : (certificates?.length || 0) === 0 ? (
              <div className="p-12 text-center text-slate-400 space-y-3">
                <div className="w-12 h-12 rounded-full bg-slate-800 text-slate-400 mx-auto flex items-center justify-center">
                  <Award className="w-6 h-6" />
                </div>
                <h4 className="text-sm font-bold text-white">No Certificates Found</h4>
                <p className="text-xs text-slate-400 max-w-sm mx-auto">
                  No certificate records match your filter criteria. Click &ldquo;Generate New Certificate&rdquo; to issue official credentials.
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm text-slate-300">
                  <thead className="bg-slate-800/60 text-xs font-semibold text-slate-400 uppercase tracking-wider border-b border-slate-800">
                    <tr>
                      <th className="px-6 py-4">Certificate Serial</th>
                      <th className="px-4 py-4">Classification</th>
                      <th className="px-4 py-4">Student Recipient</th>
                      <th className="px-4 py-4">Session & Class</th>
                      <th className="px-4 py-4">Issue Date</th>
                      <th className="px-4 py-4">Status</th>
                      <th className="px-6 py-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {(Array.isArray(certificates) ? certificates : []).map((cert) => (
                      <tr key={cert.id} className="hover:bg-slate-800/30 transition-colors">
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className="font-mono font-bold text-indigo-400 block text-xs">
                            {cert.certificateNumber}
                          </span>
                          {cert.version > 1 && (
                            <span className="text-[10px] text-purple-400 font-bold bg-purple-500/10 px-1.5 py-0.5 rounded border border-purple-500/20">
                              v{cert.version} (Reissued)
                            </span>
                          )}
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap text-xs text-white font-medium">
                          {cert.certificateTypeName}
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap">
                          <strong className="text-white block text-xs">{cert.studentName}</strong>
                          <span className="text-[11px] font-mono text-slate-400">
                            ADM: {cert.admissionNumber}
                          </span>
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap text-xs text-slate-300">
                          <span>{cert.academicSessionName}</span>
                          <span className="block text-slate-400 text-[11px]">{cert.className || 'Grade 10'}</span>
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap font-mono text-xs text-slate-300">
                          {cert.issueDate}
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap">
                          {cert.status === 'ISSUED' ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                              <CheckCircle2 className="w-3 h-3" /> Issued
                            </span>
                          ) : cert.status === 'APPROVED' ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-teal-500/10 text-teal-400 border border-teal-500/20">
                              <CheckCircle2 className="w-3 h-3" /> Approved
                            </span>
                          ) : cert.status === 'PENDING_APPROVAL' ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                              <Clock className="w-3 h-3" /> Pending Approval
                            </span>
                          ) : cert.status === 'VERIFIED' ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-sky-500/10 text-sky-400 border border-sky-500/20">
                              <ShieldCheck className="w-3 h-3" /> Verified
                            </span>
                          ) : cert.status === 'PENDING_VERIFICATION' ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/20">
                              <ShieldAlert className="w-3 h-3" /> Pending Verification
                            </span>
                          ) : cert.status === 'GENERATED' ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-500/10 text-blue-400 border border-blue-500/20">
                              <Sparkles className="w-3 h-3" /> Generated
                            </span>
                          ) : cert.status === 'DRAFT' ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-500/10 text-slate-400 border border-slate-500/20">
                              <Clock className="w-3 h-3" /> Draft
                            </span>
                          ) : cert.status === 'VERIFICATION_REJECTED' ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-500/10 text-rose-400 border border-rose-500/20">
                              <Ban className="w-3 h-3" /> Verif. Rejected
                            </span>
                          ) : cert.status === 'APPROVAL_REJECTED' ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-500/10 text-rose-400 border border-rose-500/20">
                              <Ban className="w-3 h-3" /> Appr. Rejected
                            </span>
                          ) : cert.status === 'REVOKED' ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-500/10 text-rose-400 border border-rose-500/20">
                              <Ban className="w-3 h-3" /> Revoked
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-500/10 text-slate-400 border border-slate-500/20">
                              <Ban className="w-3 h-3" /> Cancelled
                            </span>
                          )}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-right space-x-1.5">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => setViewingCertificate(cert)}
                            className="text-xs"
                          >
                            <Eye className="w-3.5 h-3.5 mr-1" />
                            View
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => setTimelineCertificate(cert)}
                            className="text-indigo-400 hover:text-indigo-300 text-xs"
                            title="Workflow Timeline & Audit Log"
                          >
                            <History className="w-3.5 h-3.5" />
                          </Button>

                          {/* Workflow Step 1: Submit for Verification */}
                          {(cert.status === 'GENERATED' || cert.status === 'DRAFT' || cert.status === 'VERIFICATION_REJECTED') && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={async () => {
                                try {
                                  await api.certificates.submitForVerification(cert.id);
                                  showToast({
                                    title: 'Submitted for Verification',
                                    message: `"${cert.certificateNumber}" forwarded to administrative review.`,
                                    type: 'info'
                                  });
                                  loadCertificates();
                                } catch (err: any) {
                                  showToast({ title: 'Submission Failed', message: err.message, type: 'error' });
                                }
                              }}
                              className="text-blue-400 border-blue-500/30 hover:bg-blue-500/10 text-xs"
                              title="Submit for verification review"
                            >
                              <Send className="w-3 h-3 mr-1" />
                              Submit Verif
                            </Button>
                          )}

                          {/* Workflow Step 2: Verification Decision */}
                          {(cert.status === 'PENDING_VERIFICATION' || (cert.status === 'GENERATED' && (user?.role === 'SUPER_ADMIN' || user?.role === 'TEACHER'))) && (
                            <Button
                              size="sm"
                              variant="default"
                              onClick={() => setVerifyingCertificate(cert)}
                              className="bg-blue-600 hover:bg-blue-500 text-white text-xs"
                              title="Review and verify certificate"
                            >
                              <ShieldCheck className="w-3.5 h-3.5 mr-1" />
                              Verify
                            </Button>
                          )}

                          {/* Workflow Step 3: Leadership Approval Decision */}
                          {(cert.status === 'PENDING_APPROVAL' || cert.status === 'VERIFIED') && (
                            <Button
                              size="sm"
                              variant="default"
                              onClick={() => setApprovingCertificate(cert)}
                              className="bg-purple-600 hover:bg-purple-500 text-white text-xs"
                              title="Review and approve certificate"
                            >
                              <CheckCircle2 className="w-3.5 h-3.5 mr-1" />
                              Approve
                            </Button>
                          )}

                          {/* Workflow Step 4: Official Issuance */}
                          {cert.status === 'APPROVED' && (
                            <Button
                              size="sm"
                              variant="default"
                              onClick={async () => {
                                try {
                                  await api.certificates.issue(cert.id);
                                  showToast({
                                    title: 'Certificate Officially Issued',
                                    message: `"${cert.certificateNumber}" is officially issued with active digital verification reference.`,
                                    type: 'success'
                                  });
                                  loadCertificates();
                                } catch (err: any) {
                                  showToast({ title: 'Issue Failed', message: err.message, type: 'error' });
                                }
                              }}
                              className="bg-emerald-600 hover:bg-emerald-500 text-white text-xs"
                              title="Formally issue official credential"
                            >
                              Issue
                            </Button>
                          )}

                          {cert.status === 'ISSUED' && (
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => setReissuingCertificate(cert)}
                              className="text-purple-400 hover:text-purple-300 text-xs"
                              title="Reissue certificate"
                            >
                              Reissue
                            </Button>
                          )}
                          {cert.status === 'ISSUED' && (
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => setRevokeCancelCert({ cert, mode: 'REVOKE' })}
                              className="text-rose-400 hover:text-rose-300 text-xs"
                              title="Revoke certificate"
                            >
                              Revoke
                            </Button>
                          )}
                          {cert.status !== 'ISSUED' && cert.status !== 'CANCELLED' && cert.status !== 'REVOKED' && (
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => setRevokeCancelCert({ cert, mode: 'CANCEL' })}
                              className="text-slate-400 hover:text-slate-300 text-xs"
                              title="Cancel certificate"
                            >
                              Cancel
                            </Button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB: Certificate Types Configuration */}
      {activeTab === 'cert-types' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between gap-4 flex-wrap">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Award className="w-5 h-5 text-indigo-400" />
                Configurable Certificate Classifications
              </h3>
              <p className="text-xs text-slate-400">
                Manage institutional certificate types, serial numbering prefixes, patterns, and dynamic requirements.
              </p>
            </div>
            <Button
              size="sm"
              variant="default"
              onClick={() => {
                setEditingCertType(null);
                setIsCertTypeModalOpen(true);
              }}
              className="bg-indigo-600 hover:bg-indigo-500 text-white flex items-center gap-1.5 shadow"
            >
              <Plus className="w-4 h-4" />
              Add Certificate Type
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {(Array.isArray(certificateTypes) ? certificateTypes : []).map((t) => (
              <div
                key={t.id}
                className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex flex-col justify-between space-y-4"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs font-bold text-indigo-400 bg-indigo-500/10 px-2 py-0.5 rounded border border-indigo-500/20">
                      {t.code}
                    </span>
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                        t.isActive ? 'bg-emerald-500/10 text-emerald-400' : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {t.isActive ? 'Active' : 'Inactive'}
                    </span>
                  </div>

                  <div>
                    <h4 className="font-bold text-white text-sm">{t.name}</h4>
                    <p className="text-xs text-slate-400 mt-1 line-clamp-2">
                      {t.description || 'Configured certificate classification.'}
                    </p>
                  </div>

                  <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800 space-y-1.5 text-xs">
                    <div className="flex justify-between text-slate-400">
                      <span>Prefix:</span>
                      <strong className="text-white font-mono">{t.numberingPrefix}</strong>
                    </div>
                    <div className="flex justify-between text-slate-400">
                      <span>Pattern:</span>
                      <span className="font-mono text-indigo-300 text-[11px]">{t.numberingFormat}</span>
                    </div>
                    <div className="flex justify-between text-slate-400">
                      <span>Next Seq:</span>
                      <span className="font-mono text-slate-200">#{t.nextSequenceNumber}</span>
                    </div>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-800 flex justify-end">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => {
                      setEditingCertType(t);
                      setIsCertTypeModalOpen(true);
                    }}
                    className="text-xs"
                  >
                    Edit Configuration
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB: Document Requirements & Checklist Configurations */}
      {activeTab === 'requirements' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between gap-4 flex-wrap">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-indigo-400" />
                Institutional Document Requirements &amp; Checklist Rules
              </h3>
              <p className="text-xs text-slate-400">
                Configure mandatory documents and verification rules for Teachers, Staff, Parents, School, and Students
              </p>
            </div>

            <div className="flex items-center gap-3">
              <select
                value={reqEntityTypeFilter}
                onChange={(e) => setReqEntityTypeFilter(e.target.value)}
                className="text-xs p-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-300 focus:outline-hidden focus:border-indigo-500"
              >
                <option value="ALL">All Entity Scopes</option>
                <option value="TEACHER">Teachers / Faculty</option>
                <option value="STAFF">Non-Teaching Staff &amp; HR</option>
                <option value="GUARDIAN">Parents / Guardians</option>
                <option value="SCHOOL">School Institutional</option>
                <option value="STUDENT">Students</option>
              </select>

              <Button
                size="sm"
                variant="primary"
                onClick={() => {
                  setEditingRequirement(null);
                  setIsRequirementModalOpen(true);
                }}
                className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold flex items-center gap-1.5"
              >
                <Plus className="w-4 h-4" />
                New Requirement Rule
              </Button>
            </div>
          </div>

          {(requirements || []).filter(r => reqEntityTypeFilter === 'ALL' || r.entityType === reqEntityTypeFilter).length === 0 ? (
            <div className="p-12 text-center rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
              <Shield className="w-12 h-12 text-slate-600 mx-auto" />
              <h4 className="text-base font-bold text-white">No Document Requirements Configured</h4>
              <p className="text-xs text-slate-400 max-w-md mx-auto">
                No active document requirements match your selected scope filter. Click "New Requirement Rule" to define institutional criteria.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {(Array.isArray(requirements) ? requirements : [])
                .filter(r => reqEntityTypeFilter === 'ALL' || r.entityType === reqEntityTypeFilter)
                .map((req) => (
                  <div
                    key={req.id}
                    className="p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all flex flex-col justify-between space-y-4 shadow-sm"
                  >
                    <div className="space-y-3">
                      <div className="flex items-start justify-between gap-2">
                        <div className="p-2.5 rounded-xl bg-indigo-500/10 text-indigo-400">
                          {getEntityIcon(req.entityType)}
                        </div>
                        <div className="flex items-center gap-1.5">
                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded-md uppercase tracking-wider ${
                              req.isRequired
                                ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                                : 'bg-slate-800 text-slate-400 border border-slate-700'
                            }`}
                          >
                            {req.isRequired ? 'Mandatory' : 'Optional'}
                          </span>
                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                              req.isActive
                                ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                                : 'bg-slate-800 text-slate-500'
                            }`}
                          >
                            {req.isActive ? 'Active' : 'Inactive'}
                          </span>
                        </div>
                      </div>

                      <div>
                        <div className="text-[10px] uppercase font-bold tracking-wider text-indigo-400">
                          {req.entityType} Requirement
                        </div>
                        <h4 className="text-base font-bold text-white line-clamp-1 mt-0.5">
                          {req.documentTypeName}
                        </h4>
                        {req.documentTypeCode && (
                          <span className="text-[10px] font-mono text-slate-500">{req.documentTypeCode}</span>
                        )}
                      </div>

                      <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80 space-y-1.5 text-xs">
                        <div className="flex items-center justify-between text-slate-400">
                          <span>Target Role:</span>
                          <strong className="text-slate-300 font-semibold">{req.applicableRole || 'ALL'}</strong>
                        </div>
                        {req.description && (
                          <p className="text-[11px] text-slate-400 italic line-clamp-2 pt-1 border-t border-slate-800/60">
                            "{req.description}"
                          </p>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800/80">
                      <Button
                        size="xs"
                        variant="outline"
                        onClick={() => {
                          setEditingRequirement(req);
                          setIsRequirementModalOpen(true);
                        }}
                        className="border-slate-700 hover:bg-slate-800 text-slate-300 text-xs"
                      >
                        Edit Rule
                      </Button>

                      <Button
                        size="xs"
                        variant="danger"
                        onClick={async () => {
                          if (window.confirm(`Delete document requirement for "${req.documentTypeName}"?`)) {
                            try {
                              await api.documents.deleteRequirement(req.id);
                              showToast({
                                title: 'Requirement Deleted',
                                message: `Removed requirement for ${req.documentTypeName}.`,
                                type: 'info'
                              });
                              loadSupportingData();
                            } catch (err: any) {
                              showToast({
                                title: 'Deletion Failed',
                                message: err.message,
                                type: 'error'
                              });
                            }
                          }
                        }}
                        className="text-xs"
                      >
                        Remove
                      </Button>
                    </div>
                  </div>
                ))}
            </div>
          )}
        </div>
      )}

      {/* TAB: Expiring & Overdue Documents Horizon */}
      {activeTab === 'expiring' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between gap-4 flex-wrap">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Clock className="w-5 h-5 text-amber-400" />
                Expiring &amp; Overdue Institutional Documents
              </h3>
              <p className="text-xs text-slate-400">
                Track professional licenses, police vetting clearances, contracts, and municipal compliance certificates
              </p>
            </div>

            <div className="flex items-center gap-3">
              <select
                value={expiringEntityFilter}
                onChange={(e) => setExpiringEntityFilter(e.target.value)}
                className="text-xs p-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-300 focus:outline-hidden focus:border-indigo-500"
              >
                <option value="ALL">All Entity Scopes</option>
                <option value="TEACHER">Faculty Members</option>
                <option value="STAFF">HR / Staff</option>
                <option value="SCHOOL">School Institutional</option>
                <option value="GUARDIAN">Parents / Guardians</option>
                <option value="STUDENT">Students</option>
              </select>

              <select
                value={expiringHorizonFilter}
                onChange={(e) => setExpiringHorizonFilter(e.target.value)}
                className="text-xs p-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-300 focus:outline-hidden focus:border-indigo-500"
              >
                <option value="30">Within 30 Days</option>
                <option value="60">Within 60 Days</option>
                <option value="90">Within 90 Days</option>
                <option value="EXPIRED_ONLY">Overdue Expired Only</option>
              </select>
            </div>
          </div>

          {/* Expiring List Table */}
          {(expiringDocuments || [])
            .filter((item) => {
              if (expiringEntityFilter !== 'ALL' && item.document.entityType !== expiringEntityFilter) return false;
              if (expiringHorizonFilter === 'EXPIRED_ONLY') return item.isExpired;
              const days = Number(expiringHorizonFilter) || 30;
              return item.daysRemaining <= days;
            }).length === 0 ? (
            <div className="p-12 text-center rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
              <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto" />
              <h4 className="text-base font-bold text-white">All Credentials Up to Date</h4>
              <p className="text-xs text-slate-400 max-w-md mx-auto">
                No institutional documents or faculty credentials are approaching expiration within this horizon.
              </p>
            </div>
          ) : (
            <div className="bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden shadow-xl">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm text-slate-300">
                  <thead className="bg-slate-950/80 text-[11px] uppercase tracking-wider text-slate-400 border-b border-slate-800">
                    <tr>
                      <th className="px-6 py-4 font-semibold">Document &amp; File</th>
                      <th className="px-4 py-4 font-semibold">Entity Owner</th>
                      <th className="px-4 py-4 font-semibold">Expiry Date</th>
                      <th className="px-4 py-4 font-semibold">Horizon / Urgency</th>
                      <th className="px-4 py-4 font-semibold">Verification</th>
                      <th className="px-6 py-4 font-semibold text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {(Array.isArray(expiringDocuments) ? expiringDocuments : [])
                      .filter((item) => {
                        if (expiringEntityFilter !== 'ALL' && item.document.entityType !== expiringEntityFilter) return false;
                        if (expiringHorizonFilter === 'EXPIRED_ONLY') return item.isExpired;
                        const days = Number(expiringHorizonFilter) || 30;
                        return item.daysRemaining <= days;
                      })
                      .map((item) => (
                        <tr
                          key={item.document.id}
                          className="hover:bg-slate-800/40 transition-colors"
                        >
                          <td className="px-6 py-4">
                            <div className="flex items-center gap-3">
                              <div className="p-2 rounded-xl bg-indigo-500/10 text-indigo-400 shrink-0">
                                <FileText className="w-4 h-4" />
                              </div>
                              <div className="min-w-0">
                                <div className="font-bold text-white text-sm line-clamp-1">
                                  {item.document.documentTitle}
                                </div>
                                <div className="text-xs text-slate-400 flex items-center gap-1 font-mono">
                                  <span>{item.document.fileName}</span>
                                  <span>•</span>
                                  <span>v{item.document.version}</span>
                                </div>
                              </div>
                            </div>
                          </td>

                          <td className="px-4 py-4 whitespace-nowrap">
                            <div className="flex items-center gap-1.5 text-xs">
                              {getEntityIcon(item.document.entityType)}
                              <span className="font-semibold text-white">
                                {item.document.entityName || item.document.entityId}
                              </span>
                            </div>
                            <span className="text-[10px] text-slate-500 font-mono">
                              {item.document.entityType} {item.document.entityCode ? `• ${item.document.entityCode}` : ''}
                            </span>
                          </td>

                          <td className="px-4 py-4 whitespace-nowrap text-xs">
                            <div className="flex items-center gap-1.5">
                              <Calendar className="w-3.5 h-3.5 text-slate-400" />
                              <span className={item.isExpired ? 'text-rose-400 font-bold' : 'text-slate-200'}>
                                {item.document.expiryDate ? new Date(item.document.expiryDate).toLocaleDateString() : '—'}
                              </span>
                            </div>
                          </td>

                          <td className="px-4 py-4 whitespace-nowrap">
                            {item.isExpired ? (
                              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-rose-500/10 text-rose-400 border border-rose-500/20">
                                <AlertTriangle className="w-3.5 h-3.5" />
                                Overdue ({Math.abs(item.daysRemaining)} days)
                              </span>
                            ) : item.daysRemaining <= 15 ? (
                              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-orange-500/10 text-orange-400 border border-orange-500/20">
                                <Clock className="w-3.5 h-3.5" />
                                {item.daysRemaining} days remaining
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-amber-500/10 text-amber-400 border border-amber-500/20">
                                <Clock className="w-3.5 h-3.5" />
                                {item.daysRemaining} days remaining
                              </span>
                            )}
                          </td>

                          <td className="px-4 py-4 whitespace-nowrap">
                            {getStatusBadge(item.document)}
                          </td>

                          <td className="px-6 py-4 whitespace-nowrap text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                onClick={() => setSelectedEntityForChecklist({
                                  entityType: item.document.entityType,
                                  entityId: item.document.entityId,
                                  entityName: item.document.entityName
                                })}
                                className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-400 hover:bg-slate-800 transition-colors"
                                title="Inspect Entity Checklist"
                              >
                                <ShieldCheck className="w-4 h-4 text-indigo-400" />
                              </button>

                              <button
                                onClick={() => setSelectedDocForDetail(item.document)}
                                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                                title="Inspect Document Details"
                              >
                                <Eye className="w-4 h-4" />
                              </button>

                              <button
                                onClick={() => setSelectedDocForVersion(item.document)}
                                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                                title="Upload Renewal / Replacement Version"
                              >
                                <Upload className="w-4 h-4 text-indigo-400" />
                              </button>

                              <a
                                href={item.document.fileUrl}
                                download={item.document.fileName}
                                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                                title="Download File"
                              >
                                <Download className="w-4 h-4" />
                              </a>
                            </div>
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Part 15F — Reports, Analytics & Compliance Tab */}
      {activeTab === 'reports' && (
        <DocumentReportsTab
          onOpenChecklistModal={(entityType, entityId, entityName) => {
            setSelectedEntityForChecklist({ entityType, entityId, entityName });
          }}
          onOpenDocumentDetail={async (documentId) => {
            try {
              const res = await api.documents.getDocumentById(documentId);
              if (res.success && res.data) {
                setSelectedDocForDetail(res.data);
              }
            } catch (err) {
              console.error('Failed to load document details', err);
            }
          }}
        />
      )}

      {/* Detail Modal */}
      {selectedDocForDetail && (
        <DocumentDetailModal
          document={selectedDocForDetail}
          currentUser={user}
          onClose={() => setSelectedDocForDetail(null)}
          onUploadNewVersion={(doc) => {
            setSelectedDocForDetail(null);
            setSelectedDocForVersion(doc);
          }}
          onVerify={handleVerifyDocument}
          onEditMetadata={(doc) => {
            // Can be opened or refreshed
          }}
          onArchive={handleArchiveDocument}
        />
      )}

      {/* Universal Upload Modal */}
      {isUploadModalOpen && (
        <UniversalDocumentUploadModal
          documentTypes={documentTypes}
          initialEntityType={uploadEntityPreset}
          onClose={() => setIsUploadModalOpen(false)}
          onSuccess={(newDoc) => {
            showToast({
              title: 'Document Uploaded',
              message: `Document "${newDoc.documentTitle}" has been staged in the vault.`,
              type: 'success'
            });
            loadDocuments();
            loadSupportingData();
          }}
        />
      )}

      {/* Upload Revision / Version Modal */}
      {selectedDocForVersion && (
        <UploadVersionModal
          document={selectedDocForVersion}
          onClose={() => setSelectedDocForVersion(null)}
          onSuccess={(updated) => {
            showToast({
              title: 'Version Committed',
              message: `Version ${updated.version} of "${updated.documentTitle}" has been saved.`,
              type: 'success'
            });
            loadDocuments();
            loadSupportingData();
          }}
        />
      )}

      {/* Document Type Configuration Modal */}
      {isTypeModalOpen && (
        <DocumentTypeConfigModal
          existingType={editingType}
          onClose={() => setIsTypeModalOpen(false)}
          onSuccess={(savedType) => {
            showToast({
              title: editingType ? 'Type Updated' : 'Type Created',
              message: `Document type "${savedType.name}" is now active.`,
              type: 'success'
            });
            loadSupportingData();
          }}
        />
      )}

      {/* Foundational Certificate Template Preview Modal */}
      {previewingTemplate && (
        <CertificateTemplatePreviewModal
          template={previewingTemplate}
          onClose={() => setPreviewingTemplate(null)}
        />
      )}

      {/* Part 15C — Certificate Modals */}
      {isGenerateModalOpen && (
        <GenerateCertificateModal
          isOpen={isGenerateModalOpen}
          onClose={() => setIsGenerateModalOpen(false)}
          certificateTypes={Array.isArray(certificateTypes) ? certificateTypes : []}
          certificateTemplates={Array.isArray(certificateTemplates) ? certificateTemplates : []}
          onSuccess={(newCert) => {
            showToast({
              title: newCert.status === 'ISSUED' ? 'Certificate Issued' : 'Certificate Generated',
              message: `Certificate "${newCert.certificateNumber}" is recorded in vault.`,
              type: 'success'
            });
            loadCertificates();
            loadSupportingData();
          }}
        />
      )}

      {viewingCertificate && (
        <CertificateViewerModal
          certificate={viewingCertificate}
          onClose={() => setViewingCertificate(null)}
          onIssue={async (cert) => {
            try {
              const issued = await api.certificates.issue(cert.id);
              showToast({
                title: 'Certificate Issued',
                message: `Certificate "${issued.certificateNumber}" is now officially issued.`,
                type: 'success'
              });
              loadCertificates();
              setViewingCertificate(issued);
            } catch (err: any) {
              showToast({ title: 'Issue Failed', message: err.message, type: 'error' });
            }
          }}
          onReissue={(cert) => {
            setViewingCertificate(null);
            setReissuingCertificate(cert);
          }}
          onRevoke={(cert) => {
            setViewingCertificate(null);
            setRevokeCancelCert({ cert, mode: 'REVOKE' });
          }}
          onCancel={(cert) => {
            setViewingCertificate(null);
            setRevokeCancelCert({ cert, mode: 'CANCEL' });
          }}
          userRole={user?.role || 'SUPER_ADMIN'}
        />
      )}

      {reissuingCertificate && (
        <ReissueCertificateModal
          isOpen={!!reissuingCertificate}
          certificate={reissuingCertificate}
          onClose={() => setReissuingCertificate(null)}
          onSuccess={(reissued) => {
            showToast({
              title: 'Certificate Reissued',
              message: `New certificate serial "${reissued.certificateNumber}" created.`,
              type: 'success'
            });
            loadCertificates();
            loadSupportingData();
          }}
        />
      )}

      {revokeCancelCert && (
        <RevokeCancelCertificateModal
          isOpen={!!revokeCancelCert}
          certificate={revokeCancelCert.cert}
          mode={revokeCancelCert.mode}
          onClose={() => setRevokeCancelCert(null)}
          onSuccess={(updated) => {
            showToast({
              title: revokeCancelCert.mode === 'REVOKE' ? 'Certificate Revoked' : 'Certificate Cancelled',
              message: `Certificate "${updated.certificateNumber}" status updated to ${updated.status}.`,
              type: 'info'
            });
            loadCertificates();
            loadSupportingData();
          }}
        />
      )}

      {isCertTypeModalOpen && (
        <CertificateTypeModal
          isOpen={isCertTypeModalOpen}
          certificateType={editingCertType}
          templates={certificateTemplates}
          onClose={() => setIsCertTypeModalOpen(false)}
          onSuccess={(saved) => {
            showToast({
              title: editingCertType ? 'Certificate Type Updated' : 'Certificate Type Created',
              message: `Type "${saved.name}" (${saved.code}) saved.`,
              type: 'success'
            });
            loadCertificates();
          }}
        />
      )}

      {verifyingCertificate && (
        <CertificateVerificationModal
          isOpen={!!verifyingCertificate}
          certificate={verifyingCertificate}
          onClose={() => setVerifyingCertificate(null)}
          onSuccess={(updated) => {
            showToast({
              title: updated.verificationStatus === 'VERIFIED' ? 'Certificate Verified' : 'Verification Rejected',
              message: `Certificate "${updated.certificateNumber}" is now ${updated.status}.`,
              type: updated.verificationStatus === 'VERIFIED' ? 'success' : 'info'
            });
            loadCertificates();
          }}
        />
      )}

      {approvingCertificate && (
        <CertificateApprovalModal
          isOpen={!!approvingCertificate}
          certificate={approvingCertificate}
          onClose={() => setApprovingCertificate(null)}
          onSuccess={(updated) => {
            showToast({
              title: updated.approvalStatus === 'APPROVED' ? 'Certificate Approved' : 'Approval Rejected',
              message: `Certificate "${updated.certificateNumber}" is now ${updated.status}.`,
              type: updated.approvalStatus === 'APPROVED' ? 'success' : 'info'
            });
            loadCertificates();
          }}
        />
      )}

      {timelineCertificate && (
        <CertificateWorkflowTimelineModal
          isOpen={!!timelineCertificate}
          certificate={timelineCertificate}
          onClose={() => setTimelineCertificate(null)}
        />
      )}

      {/* Part 15E — Entity Document Checklist Modal */}
      {selectedEntityForChecklist && (
        <EntityDocumentChecklistModal
          entityType={selectedEntityForChecklist.entityType}
          entityId={selectedEntityForChecklist.entityId}
          entityName={selectedEntityForChecklist.entityName}
          isOpen={!!selectedEntityForChecklist}
          canVerify={user?.role === 'SUPER_ADMIN'}
          onClose={() => setSelectedEntityForChecklist(null)}
          onDocumentUpdated={() => {
            loadDocuments();
            loadSupportingData();
          }}
        />
      )}

      {/* Part 15E — Document Requirement Configuration Modal */}
      {isRequirementModalOpen && (
        <DocumentRequirementConfigModal
          isOpen={isRequirementModalOpen}
          documentTypes={documentTypes}
          requirementToEdit={editingRequirement}
          onClose={() => {
            setIsRequirementModalOpen(false);
            setEditingRequirement(null);
          }}
          onSuccess={(saved) => {
            showToast({
              title: editingRequirement ? 'Requirement Updated' : 'Requirement Created',
              message: `Document requirement for "${saved.documentTypeName}" (${saved.entityType}) saved.`,
              type: 'success'
            });
            loadSupportingData();
          }}
        />
      )}
    </div>
  );
};
