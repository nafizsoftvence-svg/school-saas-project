import React, { useState, useEffect, useCallback } from 'react';
import {
  CreditCard,
  Plus,
  Search,
  Filter,
  RefreshCw,
  Eye,
  Percent,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Ban,
  Trash2,
  ArrowUpDown,
  Download,
  Calendar,
  GraduationCap,
  Users,
  DollarSign,
  ChevronLeft,
  ChevronRight,
  Sparkles,
  FileSpreadsheet,
  Layers,
  ArrowDownRight
} from 'lucide-react';
import {
  StudentFeeRecord,
  StudentFeeSummaryStats,
  AcademicSession,
  SchoolClass,
  Section,
  FeeType,
  FeePaymentStatus,
  InvoiceDetailResponse
} from '../../types/index.js';
import { api } from '../../services/api.js';
import { useToast } from '../../context/ToastContext.js';
import { useSettings } from '../../context/SettingsContext.js';
import { InvoiceViewModal } from '../../components/fees/InvoiceViewModal.js';
import { AssignFeeModal } from '../../components/fees/AssignFeeModal.js';
import { ApplyDiscountModal } from '../../components/fees/ApplyDiscountModal.js';
import { ApplyFineModal } from '../../components/fees/ApplyFineModal.js';
import { CollectFeeModal } from '../../components/fees/CollectFeeModal.js';
import { PaymentReceiptModal } from '../../components/fees/PaymentReceiptModal.js';
import { FeePaymentReceipt } from '../../types/index.js';

export const AdminStudentFeesPage: React.FC = () => {
  const { showToast } = useToast();
  const { activeSession } = useSettings();

  // State: Filter parameters
  const [selectedSessionId, setSelectedSessionId] = useState<string>('ALL');
  const [selectedClassId, setSelectedClassId] = useState<string>('ALL');
  const [selectedSectionId, setSelectedSectionId] = useState<string>('ALL');
  const [selectedFeeTypeId, setSelectedFeeTypeId] = useState<string>('ALL');
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');
  const [dueDateFrom, setDueDateFrom] = useState<string>('');
  const [dueDateTo, setDueDateTo] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(15);

  // State: Data
  const [feeRecords, setFeeRecords] = useState<StudentFeeRecord[]>([]);
  const [summaryStats, setSummaryStats] = useState<StudentFeeSummaryStats | null>(null);
  const [totalRecords, setTotalRecords] = useState<number>(0);
  const [totalPages, setTotalPages] = useState<number>(1);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Metadata dropdowns
  const [sessions, setSessions] = useState<AcademicSession[]>([]);
  const [classes, setClasses] = useState<SchoolClass[]>([]);
  const [sections, setSections] = useState<Section[]>([]);
  const [feeTypes, setFeeTypes] = useState<FeeType[]>([]);

  // Modals
  const [isAssignModalOpen, setIsAssignModalOpen] = useState<boolean>(false);
  const [viewInvoiceData, setViewInvoiceData] = useState<InvoiceDetailResponse | null>(null);
  const [isInvoiceModalOpen, setIsInvoiceModalOpen] = useState<boolean>(false);
  const [isLoadingInvoice, setIsLoadingInvoice] = useState<boolean>(false);

  const [discountRecord, setDiscountRecord] = useState<StudentFeeRecord | null>(null);
  const [isDiscountModalOpen, setIsDiscountModalOpen] = useState<boolean>(false);

  const [fineRecord, setFineRecord] = useState<StudentFeeRecord | null>(null);
  const [isFineModalOpen, setIsFineModalOpen] = useState<boolean>(false);

  // Fee Collection & Payment Receipt Modals
  const [selectedFeeForCollect, setSelectedFeeForCollect] = useState<StudentFeeRecord | null>(null);
  const [isCollectModalOpen, setIsCollectModalOpen] = useState<boolean>(false);
  const [currentReceiptData, setCurrentReceiptData] = useState<FeePaymentReceipt | null>(null);
  const [isReceiptModalOpen, setIsReceiptModalOpen] = useState<boolean>(false);
  const [isLoadingReceipt, setIsLoadingReceipt] = useState<boolean>(false);

  const handleOpenReceipt = async (transactionId: string) => {
    setIsReceiptModalOpen(true);
    setIsLoadingReceipt(true);
    try {
      const res = await api.fees.getPaymentReceipt(transactionId);
      if (res.success && res.data) {
        setCurrentReceiptData(res.data);
      }
    } catch (e) {
      console.error('Failed to fetch receipt', e);
    } finally {
      setIsLoadingReceipt(false);
    }
  };

  // Load dropdown metadata
  useEffect(() => {
    const fetchMetadata = async () => {
      try {
        const [sessRes, classRes, typeRes] = await Promise.all([
          api.getAcademicSessions(),
          api.getClasses(),
          api.fees.getFeeTypes()
        ]);
        setSessions((sessRes as any)?.data || (Array.isArray(sessRes) ? sessRes : []));
        setClasses((classRes as any)?.data || (Array.isArray(classRes) ? classRes : []));
        setFeeTypes((typeRes as any)?.data || (Array.isArray(typeRes) ? typeRes : []));
      } catch (err) {
        console.error('Failed to load fee filter metadata', err);
      }
    };
    fetchMetadata();
  }, []);

  // Update dynamic sections when class changes
  useEffect(() => {
    if (selectedClassId === 'ALL') {
      setSections([]);
      setSelectedSectionId('ALL');
    } else {
      const cls = (classes || []).find((c) => c?.id === selectedClassId);
      setSections(cls?.sections || []);
      setSelectedSectionId('ALL');
    }
  }, [selectedClassId, classes]);

  // Main data fetch
  const fetchFeeRecords = useCallback(async () => {
    setIsLoading(true);
    try {
      const res = await api.fees.getStudentFees({
        academicSessionId: selectedSessionId !== 'ALL' ? selectedSessionId : undefined,
        classId: selectedClassId !== 'ALL' ? selectedClassId : undefined,
        sectionId: selectedSectionId !== 'ALL' ? selectedSectionId : undefined,
        feeTypeId: selectedFeeTypeId !== 'ALL' ? selectedFeeTypeId : undefined,
        status: selectedStatus !== 'ALL' ? (selectedStatus as FeePaymentStatus) : undefined,
        dueDateFrom: dueDateFrom || undefined,
        dueDateTo: dueDateTo || undefined,
        search: searchQuery.trim() || undefined,
        page: currentPage,
        limit: pageSize
      });

      const responsePayload = (res as any)?.data || res;
      setFeeRecords(responsePayload?.data || []);
      setSummaryStats(responsePayload?.summary || null);
      setTotalRecords(responsePayload?.total || 0);
      setTotalPages(responsePayload?.totalPages || 1);
    } catch (err: any) {
      showToast(err.message || 'Failed to fetch student fee records', 'error');
    } finally {
      setIsLoading(false);
    }
  }, [
    selectedSessionId,
    selectedClassId,
    selectedSectionId,
    selectedFeeTypeId,
    selectedStatus,
    dueDateFrom,
    dueDateTo,
    searchQuery,
    currentPage,
    pageSize,
    showToast
  ]);

  useEffect(() => {
    fetchFeeRecords();
  }, [fetchFeeRecords]);

  // Invoice Details View
  const handleOpenInvoice = async (record: StudentFeeRecord) => {
    setIsInvoiceModalOpen(true);
    setIsLoadingInvoice(true);
    try {
      const res = await api.fees.getStudentFeeById(record.id);
      const detail = (res as any)?.data || res;
      setViewInvoiceData(detail);
    } catch (err: any) {
      showToast(err.message || 'Failed to load invoice details', 'error');
      setIsInvoiceModalOpen(false);
    } finally {
      setIsLoadingInvoice(false);
    }
  };

  // Status Change
  const handleStatusChange = async (record: StudentFeeRecord, newStatus: 'DRAFT' | 'UNPAID' | 'CANCELLED') => {
    if (newStatus === 'CANCELLED') {
      const confirmed = window.confirm(
        `Are you sure you want to cancel invoice ${record.invoiceNumber} for ${record.studentName}?`
      );
      if (!confirmed) return;
    }

    try {
      await api.fees.updateStudentFeeStatus(record.id, {
        status: newStatus,
        reason: `Admin status changed to ${newStatus}`
      });
      showToast(`Invoice ${record.invoiceNumber} updated to ${newStatus}.`, 'success');
      fetchFeeRecords();
    } catch (err: any) {
      showToast(err.message || 'Failed to update status', 'error');
    }
  };

  // Delete Invoice
  const handleDelete = async (record: StudentFeeRecord) => {
    if (record.paidAmount > 0) {
      showToast('Cannot delete an invoice that has collected payments.', 'error');
      return;
    }

    const confirmed = window.confirm(
      `Permanently delete invoice ${record.invoiceNumber} for ${record.studentName}? This action cannot be undone.`
    );
    if (!confirmed) return;

    try {
      await api.fees.deleteStudentFee(record.id);
      showToast(`Invoice ${record.invoiceNumber} deleted successfully.`, 'success');
      fetchFeeRecords();
    } catch (err: any) {
      showToast(err.message || 'Failed to delete fee record', 'error');
    }
  };

  // Reset Filters
  const handleResetFilters = () => {
    setSelectedSessionId('ALL');
    setSelectedClassId('ALL');
    setSelectedSectionId('ALL');
    setSelectedFeeTypeId('ALL');
    setSelectedStatus('ALL');
    setDueDateFrom('');
    setDueDateTo('');
    setSearchQuery('');
    setCurrentPage(1);
  };

  // Render Status Badge
  const renderStatusBadge = (record: StudentFeeRecord) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const isOverdue =
      record.status === 'OVERDUE' ||
      (new Date(record.dueDate) < today && record.dueAmount > 0 && record.status !== 'CANCELLED');

    if (record.status === 'PAID') {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
          <CheckCircle2 className="w-3 h-3" />
          PAID
        </span>
      );
    }
    if (record.status === 'PARTIAL' || record.status === 'PARTIALLY_PAID') {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-amber-500/15 text-amber-400 border border-amber-500/30">
          <Clock className="w-3 h-3" />
          PARTIAL
        </span>
      );
    }
    if (isOverdue) {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-rose-500/15 text-rose-400 border border-rose-500/30">
          <AlertTriangle className="w-3 h-3" />
          OVERDUE
        </span>
      );
    }
    if (record.status === 'DRAFT') {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-slate-500/15 text-slate-400 border border-slate-500/30">
          <Clock className="w-3 h-3" />
          DRAFT
        </span>
      );
    }
    if (record.status === 'CANCELLED') {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-gray-500/15 text-gray-400 border border-gray-500/30 line-through">
          <Ban className="w-3 h-3" />
          CANCELLED
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-indigo-500/15 text-indigo-400 border border-indigo-500/30">
        <AlertTriangle className="w-3 h-3" />
        UNPAID
      </span>
    );
  };

  return (
    <div className="space-y-6">
      {/* Top Header & Primary Action Bar */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2.5">
            <CreditCard className="w-7 h-7 text-indigo-400" />
            Student Fee Invoices & Assignment
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Super Admin &bull; Manage student fee invoices, bulk assignments, discounts & outstanding dues
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={fetchFeeRecords}
            disabled={isLoading}
            className="p-2.5 bg-white/5 hover:bg-white/10 text-slate-300 rounded-xl border border-white/10 transition-colors cursor-pointer"
            title="Refresh Fee Invoices"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
          </button>

          <button
            id="btn-assign-fees"
            onClick={() => setIsAssignModalOpen(true)}
            className="inline-flex items-center gap-2 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-indigo-600/30 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Assign Fees / Generate Invoices</span>
          </button>
        </div>
      </div>

      {/* Financial Analytics & Summary Stats Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {/* Total Invoiced Gross */}
        <div className="p-4 bg-slate-900/80 border border-white/10 rounded-2xl">
          <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
            Total Invoiced
          </p>
          <p className="text-lg font-mono font-bold text-white mt-1">
            ${summaryStats ? summaryStats.totalAmount.toFixed(2) : '0.00'}
          </p>
          <p className="text-[11px] text-slate-400 mt-0.5">
            {summaryStats?.totalInvoices || 0} total invoices
          </p>
        </div>

        {/* Discounts Approved */}
        <div className="p-4 bg-slate-900/80 border border-white/10 rounded-2xl">
          <p className="text-[10px] font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1">
            <ArrowDownRight className="w-3 h-3" /> Total Discounts
          </p>
          <p className="text-lg font-mono font-bold text-emerald-400 mt-1">
            ${summaryStats ? summaryStats.totalDiscount.toFixed(2) : '0.00'}
          </p>
          <p className="text-[11px] text-slate-400 mt-0.5">Concessions & waivers</p>
        </div>

        {/* Late Fines Adjusted */}
        <div className="p-4 bg-slate-900/80 border border-white/10 rounded-2xl">
          <p className="text-[10px] font-bold uppercase tracking-wider text-rose-400">
            Late Fines
          </p>
          <p className="text-lg font-mono font-bold text-rose-400 mt-1">
            +${summaryStats ? summaryStats.totalFine.toFixed(2) : '0.00'}
          </p>
          <p className="text-[11px] text-slate-400 mt-0.5">Penalties applied</p>
        </div>

        {/* Net Payable Invoiced */}
        <div className="p-4 bg-slate-900/80 border border-white/10 rounded-2xl">
          <p className="text-[10px] font-bold uppercase tracking-wider text-indigo-300">
            Net Invoiced
          </p>
          <p className="text-lg font-mono font-bold text-indigo-300 mt-1">
            ${summaryStats ? summaryStats.totalNetPayable.toFixed(2) : '0.00'}
          </p>
          <p className="text-[11px] text-slate-400 mt-0.5">Gross - Disc + Fine</p>
        </div>

        {/* Collected Amount */}
        <div className="p-4 bg-slate-900/80 border border-white/10 rounded-2xl">
          <p className="text-[10px] font-bold uppercase tracking-wider text-emerald-300">
            Paid & Collected
          </p>
          <p className="text-lg font-mono font-bold text-emerald-300 mt-1">
            ${summaryStats ? summaryStats.totalPaid.toFixed(2) : '0.00'}
          </p>
          <p className="text-[11px] text-emerald-400/80 mt-0.5 font-medium">
            {summaryStats?.paidCount || 0} fully settled
          </p>
        </div>

        {/* Total Outstanding Dues */}
        <div className="p-4 bg-slate-900/80 border border-amber-500/20 bg-amber-500/[0.03] rounded-2xl">
          <p className="text-[10px] font-bold uppercase tracking-wider text-amber-400">
            Outstanding Due
          </p>
          <p className="text-lg font-mono font-bold text-amber-400 mt-1">
            ${summaryStats ? summaryStats.totalDue.toFixed(2) : '0.00'}
          </p>
          <p className="text-[11px] text-amber-400/80 mt-0.5 font-medium">
            {summaryStats?.studentsWithDuesCount || 0} students with balance
          </p>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-slate-900/90 border border-white/10 rounded-2xl p-4 space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
          {/* Search */}
          <div className="lg:col-span-2 relative">
            <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
            <input
              type="text"
              placeholder="Search student, admission no, invoice #..."
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full pl-9 pr-3 py-2 text-xs bg-slate-950 border border-white/10 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
            />
          </div>

          {/* Academic Session */}
          <div>
            <select
              value={selectedSessionId}
              onChange={(e) => {
                setSelectedSessionId(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full px-3 py-2 text-xs bg-slate-950 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500"
            >
              <option value="ALL">All Academic Sessions</option>
              {sessions.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} {s.status === 'ACTIVE' ? '(Active)' : ''}
                </option>
              ))}
            </select>
          </div>

          {/* Class */}
          <div>
            <select
              value={selectedClassId}
              onChange={(e) => {
                setSelectedClassId(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full px-3 py-2 text-xs bg-slate-950 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500"
            >
              <option value="ALL">All Classes</option>
              {classes.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          {/* Section */}
          <div>
            <select
              value={selectedSectionId}
              disabled={selectedClassId === 'ALL'}
              onChange={(e) => {
                setSelectedSectionId(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full px-3 py-2 text-xs bg-slate-950 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500 disabled:opacity-40"
            >
              <option value="ALL">All Sections</option>
              {sections.map((sec) => (
                <option key={sec.id} value={sec.id}>
                  Section {sec.name}
                </option>
              ))}
            </select>
          </div>

          {/* Fee Type */}
          <div>
            <select
              value={selectedFeeTypeId}
              onChange={(e) => {
                setSelectedFeeTypeId(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full px-3 py-2 text-xs bg-slate-950 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500"
            >
              <option value="ALL">All Fee Types</option>
              {feeTypes.map((ft) => (
                <option key={ft.id} value={ft.id}>
                  {ft.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Second row filters: Status, Dates, Reset */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-white/5">
          <div className="flex flex-wrap items-center gap-3">
            {/* Status */}
            <div className="flex items-center gap-1.5 text-xs text-slate-300">
              <span className="text-slate-400">Status:</span>
              <select
                value={selectedStatus}
                onChange={(e) => {
                  setSelectedStatus(e.target.value);
                  setCurrentPage(1);
                }}
                className="px-2.5 py-1.5 text-xs bg-slate-950 border border-white/10 rounded-xl text-white focus:outline-none focus:border-indigo-500"
              >
                <option value="ALL">All Statuses</option>
                <option value="DUE">Unpaid / Due</option>
                <option value="PARTIAL">Partially Paid</option>
                <option value="PAID">Paid in Full</option>
                <option value="OVERDUE">Overdue Only</option>
                <option value="DRAFT">Draft</option>
                <option value="CANCELLED">Cancelled</option>
              </select>
            </div>

            {/* Due Date Range */}
            <div className="flex items-center gap-1.5 text-xs text-slate-300">
              <span className="text-slate-400">Due:</span>
              <input
                type="date"
                value={dueDateFrom}
                onChange={(e) => {
                  setDueDateFrom(e.target.value);
                  setCurrentPage(1);
                }}
                className="px-2 py-1 text-xs bg-slate-950 border border-white/10 rounded-lg text-white"
              />
              <span className="text-slate-500">to</span>
              <input
                type="date"
                value={dueDateTo}
                onChange={(e) => {
                  setDueDateTo(e.target.value);
                  setCurrentPage(1);
                }}
                className="px-2 py-1 text-xs bg-slate-950 border border-white/10 rounded-lg text-white"
              />
            </div>
          </div>

          <button
            onClick={handleResetFilters}
            className="text-xs text-indigo-400 hover:text-indigo-300 font-medium px-2 py-1 cursor-pointer"
          >
            Reset Filters
          </button>
        </div>
      </div>

      {/* Main Student Fees Table */}
      <div className="bg-slate-900/90 border border-white/10 rounded-2xl overflow-hidden">
        <div className="p-4 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
              Student Fee Invoices
            </span>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
              {totalRecords} Record{totalRecords !== 1 ? 's' : ''}
            </span>
          </div>

          <div className="flex items-center gap-2 text-xs text-slate-400">
            <span>Show:</span>
            <select
              value={pageSize}
              onChange={(e) => {
                setPageSize(parseInt(e.target.value, 10));
                setCurrentPage(1);
              }}
              className="px-2 py-1 bg-slate-950 border border-white/10 rounded-lg text-white text-xs"
            >
              <option value={15}>15</option>
              <option value={25}>25</option>
              <option value={50}>50</option>
              <option value={100}>100</option>
            </select>
          </div>
        </div>

        {isLoading ? (
          <div className="py-20 text-center text-slate-400">
            <div className="w-8 h-8 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
            <p className="text-xs">Loading student fee records...</p>
          </div>
        ) : feeRecords.length === 0 ? (
          <div className="py-16 text-center text-slate-400">
            <CreditCard className="w-10 h-10 mx-auto mb-3 text-slate-600" />
            <p className="text-sm font-semibold text-white">No student fee records found</p>
            <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
              No fee invoices match the active filters. Assign fees or adjust your filter selection.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950/60 border-b border-white/10 text-slate-400 font-semibold uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="px-4 py-3">Invoice & Date</th>
                  <th className="px-4 py-3">Student Dossier</th>
                  <th className="px-4 py-3">Fee Item & Type</th>
                  <th className="px-3 py-3 text-right">Gross</th>
                  <th className="px-3 py-3 text-right">Discount</th>
                  <th className="px-3 py-3 text-right">Fine</th>
                  <th className="px-3 py-3 text-right">Net Payable</th>
                  <th className="px-3 py-3 text-right">Paid</th>
                  <th className="px-3 py-3 text-right">Due Balance</th>
                  <th className="px-3 py-3 text-center">Due Date</th>
                  <th className="px-3 py-3 text-center">Status</th>
                  <th className="px-4 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 text-slate-300">
                {feeRecords.map((fee) => {
                  const today = new Date();
                  today.setHours(0, 0, 0, 0);
                  const isOverdue =
                    new Date(fee.dueDate) < today &&
                    fee.dueAmount > 0 &&
                    fee.status !== 'CANCELLED';

                  return (
                    <tr key={fee.id} className="hover:bg-white/[0.02] transition-colors">
                      {/* Invoice & Date */}
                      <td className="px-4 py-3">
                        <span className="font-mono font-bold text-white block">
                          {fee?.invoiceNumber || fee?.id || 'INV-2026'}
                        </span>
                        <span className="text-[10px] text-slate-400">
                          {new Date(fee.createdAt).toLocaleDateString()}
                        </span>
                      </td>

                      {/* Student Dossier */}
                      <td className="px-4 py-3">
                        <span className="font-bold text-white block">{fee.studentName}</span>
                        <span className="text-[11px] text-slate-400">
                          {fee.className} ({fee.sectionName || 'General'}) &bull; Adm:{' '}
                          {fee.admissionNumber}
                        </span>
                      </td>

                      {/* Fee Item & Type */}
                      <td className="px-4 py-3">
                        <span className="font-medium text-slate-200 block">{fee.title}</span>
                        <div className="flex items-center gap-1.5 mt-0.5">
                          <span className="px-1.5 py-0.2 rounded text-[10px] bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
                            {fee.feeType}
                          </span>
                          <span className="text-[10px] text-slate-400">
                            {fee.frequency || 'ONE_TIME'}
                          </span>
                        </div>
                      </td>

                      {/* Gross Amount */}
                      <td className="px-3 py-3 text-right font-mono text-slate-300">
                        ${Number(fee.totalAmount ?? 0).toFixed(2)}
                      </td>

                      {/* Discount */}
                      <td className="px-3 py-3 text-right font-mono">
                        {(fee.discountAmount ?? 0) > 0 ? (
                          <span className="text-emerald-400 font-medium" title={fee.discountReason}>
                            -${Number(fee.discountAmount ?? 0).toFixed(2)}
                          </span>
                        ) : (
                          <span className="text-slate-400">-</span>
                        )}
                      </td>

                      {/* Fine */}
                      <td className="px-3 py-3 text-right font-mono">
                        {fee.fineAmount && fee.fineAmount > 0 ? (
                          <span className="text-rose-400 font-medium" title={fee.fineReason}>
                            +${Number(fee.fineAmount ?? 0).toFixed(2)}
                          </span>
                        ) : (
                          <span className="text-slate-400">-</span>
                        )}
                      </td>

                      {/* Net Payable */}
                      <td className="px-3 py-3 text-right font-mono font-bold text-indigo-300">
                        ${Number(fee.netPayableAmount ?? 0).toFixed(2)}
                      </td>

                      {/* Paid Amount */}
                      <td className="px-3 py-3 text-right font-mono text-emerald-400 font-semibold">
                        ${Number(fee.paidAmount ?? 0).toFixed(2)}
                      </td>

                      {/* Due Balance */}
                      <td className="px-3 py-3 text-right font-mono font-bold">
                        <span className={(fee.dueAmount ?? 0) > 0 ? 'text-amber-400' : 'text-emerald-400'}>
                          ${Number(fee.dueAmount ?? 0).toFixed(2)}
                        </span>
                      </td>

                      {/* Due Date */}
                      <td className="px-3 py-3 text-center">
                        <span
                          className={`font-mono ${
                            isOverdue ? 'text-rose-400 font-bold' : 'text-slate-300'
                          }`}
                        >
                          {fee.dueDate}
                        </span>
                      </td>

                      {/* Status */}
                      <td className="px-3 py-3 text-center">{renderStatusBadge(fee)}</td>

                      {/* Actions */}
                      <td className="px-4 py-3 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {/* Collect Fee Action */}
                          {fee.dueAmount > 0 && (
                            <button
                              onClick={() => {
                                setSelectedFeeForCollect(fee);
                                setIsCollectModalOpen(true);
                              }}
                              className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg transition-colors shadow-sm shadow-emerald-600/20 cursor-pointer"
                              title="Collect Fee Payment"
                            >
                              <DollarSign className="w-3 h-3" />
                              Collect
                            </button>
                          )}

                          {/* View Invoice Modal */}
                          <button
                            onClick={() => handleOpenInvoice(fee)}
                            className="p-1.5 text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 rounded-lg transition-colors cursor-pointer"
                            title="View / Print Invoice"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>

                          {/* Discount Action */}
                          <button
                            onClick={() => {
                              setDiscountRecord(fee);
                              setIsDiscountModalOpen(true);
                            }}
                            className="p-1.5 text-emerald-400 hover:text-emerald-300 bg-emerald-500/10 hover:bg-emerald-500/20 rounded-lg transition-colors cursor-pointer"
                            title="Apply / Adjust Discount"
                          >
                            <Percent className="w-3.5 h-3.5" />
                          </button>

                          {/* Fine Action */}
                          <button
                            onClick={() => {
                              setFineRecord(fee);
                              setIsFineModalOpen(true);
                            }}
                            className="p-1.5 text-rose-400 hover:text-rose-300 bg-rose-500/10 hover:bg-rose-500/20 rounded-lg transition-colors cursor-pointer"
                            title="Adjust Fine"
                          >
                            <AlertTriangle className="w-3.5 h-3.5" />
                          </button>

                          {/* Delete (if unpaid) */}
                          {fee.paidAmount === 0 && (
                            <button
                              onClick={() => handleDelete(fee)}
                              className="p-1.5 text-slate-400 hover:text-rose-400 bg-white/5 hover:bg-rose-500/10 rounded-lg transition-colors cursor-pointer"
                              title="Delete Invoice"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* Pagination Bar */}
        <div className="p-4 border-t border-white/10 flex flex-col sm:flex-row justify-between items-center gap-3 text-xs text-slate-400">
          <div>
            Showing{' '}
            <span className="font-semibold text-white">
              {(feeRecords?.length || 0) > 0 ? (currentPage - 1) * pageSize + 1 : 0}
            </span>{' '}
            to{' '}
            <span className="font-semibold text-white">
              {Math.min(currentPage * pageSize, totalRecords)}
            </span>{' '}
            of <span className="font-semibold text-white">{totalRecords}</span> invoices
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              disabled={currentPage <= 1 || isLoading}
              className="inline-flex items-center gap-1 px-3 py-1.5 bg-white/5 hover:bg-white/10 disabled:opacity-40 disabled:cursor-not-allowed rounded-lg text-slate-300 text-xs cursor-pointer transition-colors"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
              Previous
            </button>

            <span className="px-2 py-1 text-slate-400">
              Page {currentPage} of {totalPages}
            </span>

            <button
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              disabled={currentPage >= totalPages || isLoading}
              className="inline-flex items-center gap-1 px-3 py-1.5 bg-white/5 hover:bg-white/10 disabled:opacity-40 disabled:cursor-not-allowed rounded-lg text-slate-300 text-xs cursor-pointer transition-colors"
            >
              Next
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Assign Fees Modal */}
      <AssignFeeModal
        isOpen={isAssignModalOpen}
        onClose={() => setIsAssignModalOpen(false)}
        sessions={sessions}
        classes={classes}
        onSuccess={() => fetchFeeRecords()}
      />

      {/* Invoice Detail / Printable View Modal */}
      <InvoiceViewModal
        isOpen={isInvoiceModalOpen}
        onClose={() => {
          setIsInvoiceModalOpen(false);
          setViewInvoiceData(null);
        }}
        invoiceData={viewInvoiceData}
        isLoading={isLoadingInvoice}
        onCollectPayment={(fee) => {
          setIsInvoiceModalOpen(false);
          setSelectedFeeForCollect(fee);
          setIsCollectModalOpen(true);
        }}
        onViewReceipt={(receiptNo) => {
          setIsInvoiceModalOpen(false);
          handleOpenReceipt(receiptNo);
        }}
      />

      {/* Collect Fee Modal */}
      <CollectFeeModal
        isOpen={isCollectModalOpen}
        onClose={() => {
          setIsCollectModalOpen(false);
          setSelectedFeeForCollect(null);
        }}
        feeRecord={selectedFeeForCollect}
        onPaymentSuccess={async (result) => {
          showToast(`Payment of $${result.transaction.amountPaid.toFixed(2)} recorded successfully!`, 'success');
          fetchFeeRecords();
          // Open receipt
          if (result.transaction?.id) {
            handleOpenReceipt(result.transaction.id);
          }
        }}
      />

      {/* Payment Receipt Modal */}
      <PaymentReceiptModal
        isOpen={isReceiptModalOpen}
        onClose={() => {
          setIsReceiptModalOpen(false);
          setCurrentReceiptData(null);
        }}
        receiptData={currentReceiptData}
        isLoading={isLoadingReceipt}
      />

      {/* Discount Modal */}
      <ApplyDiscountModal
        isOpen={isDiscountModalOpen}
        onClose={() => {
          setIsDiscountModalOpen(false);
          setDiscountRecord(null);
        }}
        feeRecord={discountRecord}
        onSuccess={() => fetchFeeRecords()}
      />

      {/* Fine Modal */}
      <ApplyFineModal
        isOpen={isFineModalOpen}
        onClose={() => {
          setIsFineModalOpen(false);
          setFineRecord(null);
        }}
        feeRecord={fineRecord}
        onSuccess={() => fetchFeeRecords()}
      />
    </div>
  );
};
