import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  CalendarDays,
  Calendar,
  Plus,
  Trash2,
  Edit2,
  ChevronLeft,
  ChevronRight,
  Sparkles,
  AlertCircle,
  CheckCircle2,
  Info,
  Clock,
  MapPin,
  Users,
  Flag,
  Sun,
  Shield,
  Tag,
  BookOpen,
  Layers,
  GraduationCap
} from 'lucide-react';
import { Card } from '../../../components/ui/Card.js';
import { Badge } from '../../../components/ui/Badge.js';
import { Button } from '../../../components/ui/Button.js';
import { Input } from '../../../components/ui/Input.js';
import { Select } from '../../../components/ui/Select.js';
import { Modal } from '../../../components/ui/Modal.js';
import { LoadingSpinner } from '../../../components/ui/LoadingSpinner.js';
import {
  AcademicCalendarMonthViewResponse,
  CalendarDayDetails,
  HolidayRecord,
  SpecialWorkingDayRecord,
  SchoolCalendarEvent,
  AcademicSession
} from '../../../types/index.js';

interface AcademicCalendarPageProps {
  activeTab?: 'calendar' | 'holidays' | 'special-days' | 'events';
  onTabChange?: (tab: 'calendar' | 'holidays' | 'special-days' | 'events') => void;
  hideTabBar?: boolean;
}

export const AcademicCalendarPage: React.FC<AcademicCalendarPageProps> = ({
  activeTab: propActiveTab,
  onTabChange,
  hideTabBar = true
}) => {
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Date State
  const now = new Date();
  const [selectedYear, setSelectedYear] = useState<number>(now.getFullYear());
  const [selectedMonth, setSelectedMonth] = useState<number>(now.getMonth() + 1); // 1-12
  const [selectedSessionId, setSelectedSessionId] = useState<string>('');

  // Data State
  const [sessions, setSessions] = useState<AcademicSession[]>([]);
  const [monthData, setMonthData] = useState<AcademicCalendarMonthViewResponse | null>(null);

  // Tab View State: 'calendar' | 'holidays' | 'special-days' | 'events'
  const [internalTab, setInternalTab] = useState<'calendar' | 'holidays' | 'special-days' | 'events'>('calendar');
  const activeTab = propActiveTab || internalTab;

  const setActiveTab = (tab: 'calendar' | 'holidays' | 'special-days' | 'events') => {
    setInternalTab(tab);
    onTabChange?.(tab);
  };

  // Modals State
  const [holidayModalOpen, setHolidayModalOpen] = useState<boolean>(false);
  const [editingHoliday, setEditingHoliday] = useState<Partial<HolidayRecord> | null>(null);

  const [specialDayModalOpen, setSpecialDayModalOpen] = useState<boolean>(false);
  const [editingSpecialDay, setEditingSpecialDay] = useState<Partial<SpecialWorkingDayRecord> | null>(null);

  const [eventModalOpen, setEventModalOpen] = useState<boolean>(false);
  const [editingEvent, setEditingEvent] = useState<Partial<SchoolCalendarEvent> | null>(null);

  const [inspectDay, setInspectDay] = useState<CalendarDayDetails | null>(null);

  // Fetch Academic Sessions
  const fetchSessions = async () => {
    try {
      const token = localStorage.getItem('sygmate_auth_token') || localStorage.getItem('token') || localStorage.getItem('sygmate_token');
      const res = await fetch('/api/academic/sessions', {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      if (data.success && Array.isArray(data.data)) {
        setSessions(data.data);
        const active = data.data.find((s: AcademicSession) => s.isActive);
        if (active && !selectedSessionId) {
          setSelectedSessionId(active.id);
        } else if (data.data.length > 0 && !selectedSessionId) {
          setSelectedSessionId(data?.data?.[0]?.id || '');
        }
      }
    } catch (err: any) {
      console.error('Failed to load sessions:', err);
    }
  };

  // Fetch Month Data
  const fetchCalendarMonth = async () => {
    setLoading(true);
    setError(null);
    try {
      const token = localStorage.getItem('sygmate_auth_token') || localStorage.getItem('token') || localStorage.getItem('sygmate_token');
      const url = `/api/attendance/academic-calendar?year=${selectedYear}&month=${selectedMonth}${
        selectedSessionId ? `&academicSessionId=${selectedSessionId}` : ''
      }`;
      const res = await fetch(url, {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      if (!data.success) {
        throw new Error(data.error || 'Failed to fetch academic calendar data');
      }
      setMonthData(data.data);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSessions();
  }, []);

  useEffect(() => {
    fetchCalendarMonth();
  }, [selectedYear, selectedMonth, selectedSessionId]);

  // Month navigation
  const handlePrevMonth = () => {
    if (selectedMonth === 1) {
      setSelectedMonth(12);
      setSelectedYear((prev) => prev - 1);
    } else {
      setSelectedMonth((prev) => prev - 1);
    }
  };

  const handleNextMonth = () => {
    if (selectedMonth === 12) {
      setSelectedMonth(1);
      setSelectedYear((prev) => prev + 1);
    } else {
      setSelectedMonth((prev) => prev + 1);
    }
  };

  const handleJumpToday = () => {
    const today = new Date();
    setSelectedYear(today.getFullYear());
    setSelectedMonth(today.getMonth() + 1);
  };

  // Holiday CRUD
  const handleSaveHoliday = async () => {
    if (!editingHoliday || !editingHoliday.holidayName || !editingHoliday.startDate || !editingHoliday.endDate) {
      setError('Holiday Name, Start Date, and End Date are mandatory.');
      return;
    }

    try {
      const token = localStorage.getItem('sygmate_auth_token') || localStorage.getItem('token') || localStorage.getItem('sygmate_token');
      const isEdit = Boolean(editingHoliday.id);
      const url = isEdit ? `/api/attendance/holidays/${editingHoliday.id}` : '/api/attendance/holidays';
      const method = isEdit ? 'PUT' : 'POST';

      const res = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          ...editingHoliday,
          academicSessionId: selectedSessionId || monthData?.academicSessionId
        })
      });

      const data = await res.json();
      if (!data.success) throw new Error(data.error || 'Failed to save holiday');

      setHolidayModalOpen(false);
      setEditingHoliday(null);
      setSuccessMsg(`Holiday '${data.data.holidayName}' successfully saved.`);
      setTimeout(() => setSuccessMsg(null), 3500);
      fetchCalendarMonth();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleDeleteHoliday = async (id: string, name: string) => {
    if (!confirm(`Are you sure you want to delete holiday '${name}'?`)) return;
    try {
      const token = localStorage.getItem('sygmate_auth_token') || localStorage.getItem('token') || localStorage.getItem('sygmate_token');
      const res = await fetch(`/api/attendance/holidays/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      if (!data.success) throw new Error(data.error || 'Failed to delete holiday');

      setSuccessMsg(`Holiday '${name}' deleted.`);
      setTimeout(() => setSuccessMsg(null), 3000);
      fetchCalendarMonth();
    } catch (err: any) {
      setError(err.message);
    }
  };

  // Special Working Day CRUD
  const handleSaveSpecialDay = async () => {
    if (!editingSpecialDay || !editingSpecialDay.date || !editingSpecialDay.reason) {
      setError('Date and Reason are mandatory for special working day override.');
      return;
    }

    try {
      const token = localStorage.getItem('sygmate_auth_token') || localStorage.getItem('token') || localStorage.getItem('sygmate_token');
      const res = await fetch('/api/attendance/special-working-days', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          ...editingSpecialDay,
          academicSessionId: selectedSessionId || monthData?.academicSessionId
        })
      });

      const data = await res.json();
      if (!data.success) throw new Error(data.error || 'Failed to save special working day');

      setSpecialDayModalOpen(false);
      setEditingSpecialDay(null);
      setSuccessMsg(`Special working day on ${data.data.date} registered.`);
      setTimeout(() => setSuccessMsg(null), 3500);
      fetchCalendarMonth();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleDeleteSpecialDay = async (id: string, dateStr: string) => {
    if (!confirm(`Are you sure you want to remove special working day override for ${dateStr}?`)) return;
    try {
      const token = localStorage.getItem('sygmate_auth_token') || localStorage.getItem('token') || localStorage.getItem('sygmate_token');
      const res = await fetch(`/api/attendance/special-working-days/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      if (!data.success) throw new Error(data.error || 'Failed to delete special working day');

      setSuccessMsg(`Special working day override for ${dateStr} removed.`);
      setTimeout(() => setSuccessMsg(null), 3000);
      fetchCalendarMonth();
    } catch (err: any) {
      setError(err.message);
    }
  };

  // Calendar Event CRUD
  const handleSaveEvent = async () => {
    if (!editingEvent || !editingEvent.title || !editingEvent.startDate || !editingEvent.endDate) {
      setError('Title, Start Date, and End Date are required.');
      return;
    }

    try {
      const token = localStorage.getItem('sygmate_auth_token') || localStorage.getItem('token') || localStorage.getItem('sygmate_token');
      const res = await fetch('/api/attendance/calendar-events', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          ...editingEvent,
          academicSessionId: selectedSessionId || monthData?.academicSessionId
        })
      });

      const data = await res.json();
      if (!data.success) throw new Error(data.error || 'Failed to save event');

      setEventModalOpen(false);
      setEditingEvent(null);
      setSuccessMsg(`Event '${data.data.title}' scheduled.`);
      setTimeout(() => setSuccessMsg(null), 3500);
      fetchCalendarMonth();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleDeleteEvent = async (id: string, title: string) => {
    if (!confirm(`Are you sure you want to delete event '${title}'?`)) return;
    try {
      const token = localStorage.getItem('sygmate_auth_token') || localStorage.getItem('token') || localStorage.getItem('sygmate_token');
      const res = await fetch(`/api/attendance/calendar-events/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      if (!data.success) throw new Error(data.error || 'Failed to delete event');

      setSuccessMsg(`Event '${title}' deleted.`);
      setTimeout(() => setSuccessMsg(null), 3000);
      fetchCalendarMonth();
    } catch (err: any) {
      setError(err.message);
    }
  };

  // Build Month Grid matrix with starting blank padding
  const buildCalendarMatrix = () => {
    if (!monthData || !Array.isArray(monthData.days) || monthData.days.length === 0) return [];
    const firstDayOfWeek = monthData?.days?.[0]?.dayOfWeek || 0; // 0=Sunday
    const blanks = Array.from({ length: firstDayOfWeek }, (_, i) => null);
    return [...blanks, ...monthData.days];
  };

  const calendarMatrix = buildCalendarMatrix();

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-white/10 pb-5">
        <div>
          <div className="flex items-center gap-3 mb-1">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400 shadow-lg shadow-indigo-500/10">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-2xl font-black tracking-tight text-white flex items-center gap-2">
                Academic Calendar Management
                <Badge variant="primary" size="sm" className="font-mono text-xs">
                  Part 8A
                </Badge>
              </h1>
              <p className="text-sm text-slate-400">
                Institutional calendar, official holidays, special working days, exams & scheduled school events.
              </p>
            </div>
          </div>
        </div>

        {/* Global Action Modals */}
        <div className="flex flex-wrap items-center gap-2.5">
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              setEditingHoliday({
                holidayName: '',
                startDate: `${selectedYear}-${String(selectedMonth).padStart(2, '0')}-01`,
                endDate: `${selectedYear}-${String(selectedMonth).padStart(2, '0')}-01`,
                holidayType: 'INSTITUTIONAL',
                description: '',
                status: 'ACTIVE'
              });
              setHolidayModalOpen(true);
            }}
            icon={<Plus className="w-4 h-4" />}
          >
            Add Holiday
          </Button>

          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              setEditingSpecialDay({
                date: `${selectedYear}-${String(selectedMonth).padStart(2, '0')}-01`,
                reason: '',
                overridesDayType: 'WEEKEND',
                status: 'ACTIVE'
              });
              setSpecialDayModalOpen(true);
            }}
            icon={<Sun className="w-4 h-4" />}
          >
            Special Working Day
          </Button>

          <Button
            variant="primary"
            size="sm"
            onClick={() => {
              setEditingEvent({
                title: '',
                startDate: `${selectedYear}-${String(selectedMonth).padStart(2, '0')}-01`,
                endDate: `${selectedYear}-${String(selectedMonth).padStart(2, '0')}-01`,
                eventType: 'ACADEMIC',
                targetAudience: 'ALL',
                description: '',
                color: '#3b82f6'
              });
              setEventModalOpen(true);
            }}
            icon={<Sparkles className="w-4 h-4" />}
          >
            Create Event
          </Button>
        </div>
      </div>

      {/* Filter & Month Navigation Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-2xl bg-slate-900/80 border border-white/10 shadow-lg">
        {/* Session Selector */}
        <div className="flex items-center gap-3">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-400 shrink-0">
            Academic Session:
          </span>
          <select
            value={selectedSessionId}
            onChange={(e) => setSelectedSessionId(e.target.value)}
            className="px-3 py-1.5 bg-slate-800 border border-white/10 rounded-xl text-white text-sm font-semibold focus:outline-none focus:border-indigo-500"
          >
            {sessions.map((s) => (
              <option key={s.id} value={s.id}>
                {s.sessionName} {s.isActive ? '(Active)' : ''}
              </option>
            ))}
          </select>
        </div>

        {/* Month Navigation */}
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={handlePrevMonth} icon={<ChevronLeft className="w-4 h-4" />}>
            Prev
          </Button>

          <div className="text-center px-3">
            <span className="text-base font-black text-white">
              {monthData?.monthName || 'Month'} {selectedYear}
            </span>
          </div>

          <Button variant="outline" size="sm" onClick={handleNextMonth} icon={<ChevronRight className="w-4 h-4" />}>
            Next
          </Button>

          <Button variant="secondary" size="sm" onClick={handleJumpToday}>
            Today
          </Button>
        </div>
      </div>

      {/* Feedback Alerts */}
      <AnimatePresence>
        {error && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-300 flex items-start gap-3"
          >
            <AlertCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
            <div className="flex-1 text-sm font-medium">{error}</div>
            <button onClick={() => setError(null)} className="text-xs text-rose-400 hover:text-white cursor-pointer">
              Dismiss
            </button>
          </motion.div>
        )}

        {successMsg && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 flex items-center gap-3"
          >
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            <div className="flex-1 text-sm font-medium">{successMsg}</div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Metrics Row */}
      {monthData && (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          <Card className="p-3.5 bg-slate-900/60 border-white/10 text-center">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Total Days</span>
            <p className="text-xl font-black text-white mt-1">{monthData.totalDays}</p>
          </Card>

          <Card className="p-3.5 bg-emerald-500/5 border-emerald-500/20 text-center">
            <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-400">Working Days</span>
            <p className="text-xl font-black text-emerald-300 mt-1">{monthData.totalWorkingDays}</p>
          </Card>

          <Card className="p-3.5 bg-slate-900/60 border-white/10 text-center">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Weekends</span>
            <p className="text-xl font-black text-slate-300 mt-1">{monthData.totalWeekends}</p>
          </Card>

          <Card className="p-3.5 bg-rose-500/5 border-rose-500/20 text-center">
            <span className="text-[11px] font-bold uppercase tracking-wider text-rose-400">Holidays</span>
            <p className="text-xl font-black text-rose-300 mt-1">{monthData.totalHolidays}</p>
          </Card>

          <Card className="p-3.5 bg-amber-500/5 border-amber-500/20 text-center">
            <span className="text-[11px] font-bold uppercase tracking-wider text-amber-400">Special Days</span>
            <p className="text-xl font-black text-amber-300 mt-1">{monthData.totalSpecialWorkingDays}</p>
          </Card>

          <Card className="p-3.5 bg-indigo-500/5 border-indigo-500/20 text-center">
            <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-400">Events / Exams</span>
            <p className="text-xl font-black text-indigo-300 mt-1">{monthData.totalEvents}</p>
          </Card>
        </div>
      )}

      {/* Navigation Sub-Tabs (Hidden when subtabs are hosted in sidebar) */}
      {!hideTabBar && (
        <div className="flex items-center gap-2 border-b border-white/10 pb-px overflow-x-auto no-scrollbar">
          <button
            onClick={() => setActiveTab('calendar')}
            className={`px-4 py-2.5 text-sm font-semibold rounded-t-xl transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
              activeTab === 'calendar'
                ? 'bg-slate-900 border-t border-x border-white/15 text-indigo-400 shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <CalendarDays className="w-4 h-4" />
            Interactive Calendar Grid
          </button>

          <button
            onClick={() => setActiveTab('holidays')}
            className={`px-4 py-2.5 text-sm font-semibold rounded-t-xl transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
              activeTab === 'holidays'
                ? 'bg-slate-900 border-t border-x border-white/15 text-indigo-400 shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <Flag className="w-4 h-4" />
            Holidays Roster ({monthData?.holidays?.length || 0})
          </button>

          <button
            onClick={() => setActiveTab('special-days')}
            className={`px-4 py-2.5 text-sm font-semibold rounded-t-xl transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
              activeTab === 'special-days'
                ? 'bg-slate-900 border-t border-x border-white/15 text-indigo-400 shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <Sun className="w-4 h-4" />
            Special Working Days ({monthData?.specialWorkingDays?.length || 0})
          </button>

          <button
            onClick={() => setActiveTab('events')}
            className={`px-4 py-2.5 text-sm font-semibold rounded-t-xl transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
              activeTab === 'events'
                ? 'bg-slate-900 border-t border-x border-white/15 text-indigo-400 shadow-md'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            School Calendar Events ({monthData?.events?.length || 0})
          </button>
        </div>
      )}

      {loading && !monthData ? (
        <div className="min-h-[400px] flex items-center justify-center">
          <LoadingSpinner size="lg" message="Rendering academic calendar..." />
        </div>
      ) : null}

      {/* Tab 1: Interactive Month Calendar Grid */}
      {activeTab === 'calendar' && monthData && (
        <div className="space-y-4">
          <div className="grid grid-cols-7 gap-2 bg-slate-900/90 p-4 rounded-2xl border border-white/10 shadow-2xl">
            {/* Weekday headers */}
            {['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'].map((d, idx) => {
              const isWknd = monthData.weekendDays.includes(
                idx === 0
                  ? 'SUNDAY'
                  : idx === 1
                  ? 'MONDAY'
                  : idx === 2
                  ? 'TUESDAY'
                  : idx === 3
                  ? 'WEDNESDAY'
                  : idx === 4
                  ? 'THURSDAY'
                  : idx === 5
                  ? 'FRIDAY'
                  : 'SATURDAY'
              );
              return (
                <div
                  key={d}
                  className={`text-center py-2 text-xs font-bold uppercase tracking-wider rounded-lg ${
                    isWknd ? 'bg-rose-500/10 text-rose-400' : 'bg-slate-800/60 text-slate-300'
                  }`}
                >
                  <span className="hidden sm:inline">{d}</span>
                  <span className="sm:hidden">{d.substring(0, 3)}</span>
                </div>
              );
            })}

            {/* Calendar Cells */}
            {calendarMatrix.map((dayItem, index) => {
              if (!dayItem) {
                return (
                  <div
                    key={`blank-${index}`}
                    className="min-h-[100px] sm:min-h-[120px] rounded-xl bg-slate-950/40 border border-dashed border-white/5 p-2 opacity-30"
                  />
                );
              }

              const isToday =
                dayItem.date ===
                `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;

              const isHoliday = dayItem.dayType === 'HOLIDAY';
              const isWeekend = dayItem.dayType === 'WEEKEND';
              const isSpecialDay = dayItem.dayType === 'SPECIAL_WORKING_DAY';

              return (
                <div
                  key={dayItem.date}
                  onClick={() => setInspectDay(dayItem)}
                  className={`min-h-[100px] sm:min-h-[120px] rounded-xl p-2.5 border transition-all flex flex-col justify-between cursor-pointer group hover:scale-[1.02] hover:z-10 ${
                    isToday
                      ? 'bg-indigo-950/40 border-indigo-500/50 ring-1 ring-indigo-400 shadow-lg shadow-indigo-500/10'
                      : isHoliday
                      ? 'bg-rose-950/20 border-rose-500/30 hover:border-rose-400'
                      : isSpecialDay
                      ? 'bg-amber-950/20 border-amber-500/30 hover:border-amber-400'
                      : isWeekend
                      ? 'bg-slate-950/60 border-white/5 opacity-80'
                      : 'bg-slate-900/60 border-white/10 hover:border-indigo-400/40'
                  }`}
                >
                  {/* Top Day Header */}
                  <div className="flex items-center justify-between">
                    <span
                      className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs font-black ${
                        isToday
                          ? 'bg-indigo-600 text-white shadow-md'
                          : isHoliday
                          ? 'bg-rose-500/20 text-rose-300'
                          : isSpecialDay
                          ? 'bg-amber-500/20 text-amber-300'
                          : isWeekend
                          ? 'text-slate-400'
                          : 'text-white'
                      }`}
                    >
                      {parseInt(dayItem.date.split('-')[2], 10)}
                    </span>

                    <span className="text-[10px] font-bold uppercase tracking-tight">
                      {isSpecialDay ? (
                        <span className="text-amber-400">Override</span>
                      ) : isHoliday ? (
                        <span className="text-rose-400">Holiday</span>
                      ) : isWeekend ? (
                        <span className="text-slate-400">Weekend</span>
                      ) : (
                        <span className="text-emerald-400">Workday</span>
                      )}
                    </span>
                  </div>

                  {/* Day Badges Stack */}
                  <div className="space-y-1 my-1 overflow-hidden">
                    {dayItem.holidays.map((h) => (
                      <div
                        key={h.id}
                        className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-rose-500/20 text-rose-300 border border-rose-500/30 truncate"
                        title={h.holidayName}
                      >
                        🎌 {h.holidayName}
                      </div>
                    ))}

                    {dayItem.specialWorkingDays.map((s) => (
                      <div
                        key={s.id}
                        className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 truncate"
                        title={s.reason}
                      >
                        ⚡ {s.reason}
                      </div>
                    ))}

                    {dayItem.events.map((e) => (
                      <div
                        key={e.id}
                        className="text-[10px] font-semibold px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 truncate"
                        title={e.title}
                      >
                        📌 {e.title}
                      </div>
                    ))}

                    {dayItem.exams &&
                      dayItem.exams.map((ex) => (
                        <div
                          key={ex.id}
                          className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-300 border border-purple-500/30 truncate"
                          title={`${ex.subjectName} Exam (${ex.startTime}-${ex.endTime})`}
                        >
                          📝 {ex.subjectName}
                        </div>
                      ))}
                  </div>

                  {/* Footer metadata */}
                  <div className="text-[9px] text-slate-400 flex items-center justify-between">
                    <span>{dayItem.dayName.substring(0, 3)}</span>
                    <span className="opacity-0 group-hover:opacity-100 transition-opacity text-indigo-400 font-bold">
                      View →
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Tab 2: Holidays Roster Table */}
      {activeTab === 'holidays' && monthData && (
        <Card className="p-6 bg-slate-900/80 border-white/10">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <Flag className="w-5 h-5 text-rose-400" />
                Institutional Holidays Roster
              </h2>
              <p className="text-sm text-slate-400">
                Official holiday definitions for {monthData.academicSessionName}.
              </p>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setEditingHoliday({
                  holidayName: '',
                  startDate: `${selectedYear}-${String(selectedMonth).padStart(2, '0')}-01`,
                  endDate: `${selectedYear}-${String(selectedMonth).padStart(2, '0')}-01`,
                  holidayType: 'INSTITUTIONAL',
                  description: '',
                  status: 'ACTIVE'
                });
                setHolidayModalOpen(true);
              }}
              icon={<Plus className="w-4 h-4" />}
            >
              Add Holiday
            </Button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-slate-300">
              <thead className="bg-slate-800/60 text-slate-400 uppercase text-xs tracking-wider border-b border-white/10">
                <tr>
                  <th className="py-3 px-4">Holiday Name</th>
                  <th className="py-3 px-4">Type</th>
                  <th className="py-3 px-4">Dates</th>
                  <th className="py-3 px-4">Duration</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {(monthData?.holidays?.length || 0) === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-slate-400">
                      No holidays scheduled for this month.
                    </td>
                  </tr>
                ) : (
                  monthData.holidays.map((h) => {
                    const [sY, sM, sD] = h.startDate.split('-').map(Number);
                    const [eY, eM, eD] = h.endDate.split('-').map(Number);
                    const diffDays =
                      Math.round(
                        (new Date(eY, eM - 1, eD).getTime() - new Date(sY, sM - 1, sD).getTime()) /
                          (1000 * 60 * 60 * 24)
                      ) + 1;

                    return (
                      <tr key={h.id} className="hover:bg-white/5 transition-colors">
                        <td className="py-3 px-4">
                          <span className="font-bold text-white block">{h.holidayName}</span>
                          {h.description && (
                            <span className="text-xs text-slate-400 block max-w-sm truncate">{h.description}</span>
                          )}
                        </td>
                        <td className="py-3 px-4">
                          <Badge variant="warning" size="sm">
                            {h.holidayType}
                          </Badge>
                        </td>
                        <td className="py-3 px-4 font-mono text-xs">
                          {h.startDate} {h.startDate !== h.endDate ? `to ${h.endDate}` : ''}
                        </td>
                        <td className="py-3 px-4 font-bold text-rose-400">
                          {diffDays} {diffDays === 1 ? 'Day' : 'Days'}
                        </td>
                        <td className="py-3 px-4">
                          <Badge variant={h.status === 'ACTIVE' ? 'success' : 'default'} size="sm">
                            {h.status}
                          </Badge>
                        </td>
                        <td className="py-3 px-4 text-right space-x-2">
                          <button
                            type="button"
                            onClick={() => {
                              setEditingHoliday(h);
                              setHolidayModalOpen(true);
                            }}
                            className="p-1 text-slate-400 hover:text-white transition-colors cursor-pointer"
                            title="Edit Holiday"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteHoliday(h.id, h.holidayName)}
                            className="p-1 text-rose-400 hover:text-rose-300 transition-colors cursor-pointer"
                            title="Delete Holiday"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      {/* Tab 3: Special Working Days */}
      {activeTab === 'special-days' && monthData && (
        <Card className="p-6 bg-slate-900/80 border-white/10">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <Sun className="w-5 h-5 text-amber-400" />
                Special Working Days Overrides
              </h2>
              <p className="text-sm text-slate-400">
                Operating days on scheduled institutional weekends or holidays (e.g., cyclone makeup days).
              </p>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setEditingSpecialDay({
                  date: `${selectedYear}-${String(selectedMonth).padStart(2, '0')}-01`,
                  reason: '',
                  overridesDayType: 'WEEKEND',
                  status: 'ACTIVE'
                });
                setSpecialDayModalOpen(true);
              }}
              icon={<Plus className="w-4 h-4" />}
            >
              Add Override
            </Button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-slate-300">
              <thead className="bg-slate-800/60 text-slate-400 uppercase text-xs tracking-wider border-b border-white/10">
                <tr>
                  <th className="py-3 px-4">Date</th>
                  <th className="py-3 px-4">Reason / Purpose</th>
                  <th className="py-3 px-4">Overrides</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {(monthData?.specialWorkingDays?.length || 0) === 0 ? (
                  <tr>
                    <td colSpan={5} className="py-8 text-center text-slate-400">
                      No special working days scheduled for this month.
                    </td>
                  </tr>
                ) : (
                  monthData.specialWorkingDays.map((s) => (
                    <tr key={s.id} className="hover:bg-white/5 transition-colors">
                      <td className="py-3 px-4 font-mono font-bold text-white">{s.date}</td>
                      <td className="py-3 px-4 font-medium text-amber-300">{s.reason}</td>
                      <td className="py-3 px-4">
                        <Badge variant="warning" size="sm">
                          Overrides {s.overridesDayType}
                        </Badge>
                      </td>
                      <td className="py-3 px-4">
                        <Badge variant="success" size="sm">
                          {s.status}
                        </Badge>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <button
                          type="button"
                          onClick={() => handleDeleteSpecialDay(s.id, s.date)}
                          className="p-1 text-rose-400 hover:text-rose-300 transition-colors cursor-pointer"
                          title="Remove Special Working Day"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      {/* Tab 4: School Calendar Events */}
      {activeTab === 'events' && monthData && (
        <Card className="p-6 bg-slate-900/80 border-white/10">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-indigo-400" />
                Institutional Events & Milestones
              </h2>
              <p className="text-sm text-slate-400">
                Academic milestones, sports tournaments, cultural ceremonies, and staff meetings.
              </p>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setEditingEvent({
                  title: '',
                  startDate: `${selectedYear}-${String(selectedMonth).padStart(2, '0')}-01`,
                  endDate: `${selectedYear}-${String(selectedMonth).padStart(2, '0')}-01`,
                  eventType: 'ACADEMIC',
                  targetAudience: 'ALL',
                  description: '',
                  color: '#3b82f6'
                });
                setEventModalOpen(true);
              }}
              icon={<Plus className="w-4 h-4" />}
            >
              Create Event
            </Button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-slate-300">
              <thead className="bg-slate-800/60 text-slate-400 uppercase text-xs tracking-wider border-b border-white/10">
                <tr>
                  <th className="py-3 px-4">Event Title</th>
                  <th className="py-3 px-4">Category</th>
                  <th className="py-3 px-4">Target Audience</th>
                  <th className="py-3 px-4">Date Span</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {(monthData?.events?.length || 0) === 0 ? (
                  <tr>
                    <td colSpan={5} className="py-8 text-center text-slate-400">
                      No school calendar events scheduled for this month.
                    </td>
                  </tr>
                ) : (
                  monthData.events.map((e) => (
                    <tr key={e.id} className="hover:bg-white/5 transition-colors">
                      <td className="py-3 px-4">
                        <span className="font-bold text-white block">{e.title}</span>
                        {e.description && (
                          <span className="text-xs text-slate-400 block max-w-sm truncate">{e.description}</span>
                        )}
                      </td>
                      <td className="py-3 px-4">
                        <Badge variant="primary" size="sm">
                          {e.eventType}
                        </Badge>
                      </td>
                      <td className="py-3 px-4">
                        <Badge variant="outline" size="sm">
                          {e.targetAudience}
                        </Badge>
                      </td>
                      <td className="py-3 px-4 font-mono text-xs">
                        {e.startDate} {e.startDate !== e.endDate ? `to ${e.endDate}` : ''}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <button
                          type="button"
                          onClick={() => handleDeleteEvent(e.id, e.title)}
                          className="p-1 text-rose-400 hover:text-rose-300 transition-colors cursor-pointer"
                          title="Delete Event"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      {/* Add / Edit Holiday Modal */}
      {holidayModalOpen && editingHoliday && (
        <Modal
          isOpen={holidayModalOpen}
          onClose={() => setHolidayModalOpen(false)}
          title={editingHoliday.id ? 'Edit Holiday Record' : 'Create New Holiday'}
        >
          <div className="space-y-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Holiday Name *
              </label>
              <Input
                type="text"
                placeholder="e.g. Independence Day, Eid-ul-Fitr, Winter Recess"
                value={editingHoliday.holidayName || ''}
                onChange={(e) => setEditingHoliday({ ...editingHoliday, holidayName: e.target.value })}
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                  Start Date (YYYY-MM-DD) *
                </label>
                <Input
                  type="date"
                  value={editingHoliday.startDate || ''}
                  onChange={(e) => setEditingHoliday({ ...editingHoliday, startDate: e.target.value })}
                />
              </div>
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                  End Date (YYYY-MM-DD) *
                </label>
                <Input
                  type="date"
                  value={editingHoliday.endDate || ''}
                  onChange={(e) => setEditingHoliday({ ...editingHoliday, endDate: e.target.value })}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                  Holiday Classification
                </label>
                <Select
                  value={editingHoliday.holidayType || 'INSTITUTIONAL'}
                  onChange={(val) => setEditingHoliday({ ...editingHoliday, holidayType: val as any })}
                  options={[
                    { label: 'National Holiday', value: 'NATIONAL' },
                    { label: 'Religious Festival', value: 'RELIGIOUS' },
                    { label: 'Institutional Recess', value: 'INSTITUTIONAL' },
                    { label: 'Seasonal Vacation', value: 'SEASONAL' },
                    { label: 'Emergency / Weather Closure', value: 'EMERGENCY' }
                  ]}
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                  Status
                </label>
                <Select
                  value={editingHoliday.status || 'ACTIVE'}
                  onChange={(val) => setEditingHoliday({ ...editingHoliday, status: val as any })}
                  options={[
                    { label: 'Active', value: 'ACTIVE' },
                    { label: 'Archived / Inactive', value: 'ARCHIVED' }
                  ]}
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Description / Memo
              </label>
              <textarea
                rows={2}
                value={editingHoliday.description || ''}
                onChange={(e) => setEditingHoliday({ ...editingHoliday, description: e.target.value })}
                placeholder="Institutional note or government gazette reference..."
                className="w-full px-3 py-2 bg-slate-800 border border-white/10 rounded-xl text-white text-sm focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="flex justify-end gap-3 pt-3 border-t border-white/10">
              <Button variant="outline" onClick={() => setHolidayModalOpen(false)}>
                Cancel
              </Button>
              <Button variant="primary" onClick={handleSaveHoliday}>
                Save Holiday
              </Button>
            </div>
          </div>
        </Modal>
      )}

      {/* Add Special Working Day Modal */}
      {specialDayModalOpen && editingSpecialDay && (
        <Modal
          isOpen={specialDayModalOpen}
          onClose={() => setSpecialDayModalOpen(false)}
          title="Register Special Working Day Override"
        >
          <div className="space-y-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Override Date (YYYY-MM-DD) *
              </label>
              <Input
                type="date"
                value={editingSpecialDay.date || ''}
                onChange={(e) => setEditingSpecialDay({ ...editingSpecialDay, date: e.target.value })}
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Reason / Academic Purpose *
              </label>
              <Input
                type="text"
                placeholder="e.g. Saturday Make-up Class for Flood Makeup"
                value={editingSpecialDay.reason || ''}
                onChange={(e) => setEditingSpecialDay({ ...editingSpecialDay, reason: e.target.value })}
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Overrides Day Classification
              </label>
              <Select
                value={editingSpecialDay.overridesDayType || 'WEEKEND'}
                onChange={(val) => setEditingSpecialDay({ ...editingSpecialDay, overridesDayType: val as any })}
                options={[
                  { label: 'Overrides Weekend Day', value: 'WEEKEND' },
                  { label: 'Overrides Official Holiday', value: 'HOLIDAY' }
                ]}
              />
            </div>

            <div className="flex justify-end gap-3 pt-3 border-t border-white/10">
              <Button variant="outline" onClick={() => setSpecialDayModalOpen(false)}>
                Cancel
              </Button>
              <Button variant="primary" onClick={handleSaveSpecialDay}>
                Register Override
              </Button>
            </div>
          </div>
        </Modal>
      )}

      {/* Add Calendar Event Modal */}
      {eventModalOpen && editingEvent && (
        <Modal
          isOpen={eventModalOpen}
          onClose={() => setEventModalOpen(false)}
          title="Create Institutional Event"
        >
          <div className="space-y-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Event Title *
              </label>
              <Input
                type="text"
                placeholder="e.g. Annual Science Fair, Parent-Teacher Meeting"
                value={editingEvent.title || ''}
                onChange={(e) => setEditingEvent({ ...editingEvent, title: e.target.value })}
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                  Start Date *
                </label>
                <Input
                  type="date"
                  value={editingEvent.startDate || ''}
                  onChange={(e) => setEditingEvent({ ...editingEvent, startDate: e.target.value })}
                />
              </div>
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                  End Date *
                </label>
                <Input
                  type="date"
                  value={editingEvent.endDate || ''}
                  onChange={(e) => setEditingEvent({ ...editingEvent, endDate: e.target.value })}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                  Event Category
                </label>
                <Select
                  value={editingEvent.eventType || 'ACADEMIC'}
                  onChange={(val) => setEditingEvent({ ...editingEvent, eventType: val as any })}
                  options={[
                    { label: 'Academic Activity', value: 'ACADEMIC' },
                    { label: 'Cultural Program', value: 'CULTURAL' },
                    { label: 'Sports Meet', value: 'SPORTS' },
                    { label: 'Examination Schedule', value: 'EXAM' },
                    { label: 'Institutional Meeting', value: 'MEETING' },
                    { label: 'Ceremony / Convocation', value: 'CEREMONY' }
                  ]}
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                  Target Audience
                </label>
                <Select
                  value={editingEvent.targetAudience || 'ALL'}
                  onChange={(val) => setEditingEvent({ ...editingEvent, targetAudience: val as any })}
                  options={[
                    { label: 'All School Stakeholders', value: 'ALL' },
                    { label: 'Students Only', value: 'STUDENTS' },
                    { label: 'Teachers / Faculty', value: 'TEACHERS' },
                    { label: 'Guardians / Parents', value: 'PARENTS' }
                  ]}
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                Description / Details
              </label>
              <textarea
                rows={2}
                value={editingEvent.description || ''}
                onChange={(e) => setEditingEvent({ ...editingEvent, description: e.target.value })}
                placeholder="Event agenda, venue, participation requirements..."
                className="w-full px-3 py-2 bg-slate-800 border border-white/10 rounded-xl text-white text-sm focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="flex justify-end gap-3 pt-3 border-t border-white/10">
              <Button variant="outline" onClick={() => setEventModalOpen(false)}>
                Cancel
              </Button>
              <Button variant="primary" onClick={handleSaveEvent}>
                Publish Event
              </Button>
            </div>
          </div>
        </Modal>
      )}

      {/* Day Inspector Modal */}
      {inspectDay && (
        <Modal
          isOpen={Boolean(inspectDay)}
          onClose={() => setInspectDay(null)}
          title={`Day Inspector: ${inspectDay.date} (${inspectDay.dayName})`}
        >
          <div className="space-y-4">
            {/* Status overview banner */}
            <div
              className={`p-4 rounded-xl border flex items-center justify-between ${
                inspectDay.dayType === 'SPECIAL_WORKING_DAY'
                  ? 'bg-amber-500/10 border-amber-500/30 text-amber-300'
                  : inspectDay.dayType === 'HOLIDAY'
                  ? 'bg-rose-500/10 border-rose-500/30 text-rose-300'
                  : inspectDay.dayType === 'WEEKEND'
                  ? 'bg-slate-800/60 border-white/10 text-slate-300'
                  : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
              }`}
            >
              <div>
                <span className="text-xs uppercase font-bold tracking-wider block opacity-80">
                  Institutional Day Status
                </span>
                <span className="text-lg font-black">{(inspectDay.dayType || 'REGULAR').replace(/_/g, ' ')}</span>
              </div>
              <Badge
                variant={inspectDay.isWorkingDay ? 'success' : 'danger'}
                size="md"
                className="text-xs font-bold"
              >
                {inspectDay.isWorkingDay ? 'Working Day' : 'Non-Working Day'}
              </Badge>
            </div>

            {/* Holidays on this date */}
            {((inspectDay?.holidays?.length || 0) > 0) && (
              <div className="space-y-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-rose-400 flex items-center gap-1.5">
                  <Flag className="w-3.5 h-3.5" /> Official Holidays ({inspectDay?.holidays?.length || 0})
                </h4>
                {inspectDay.holidays.map((h) => (
                  <div key={h.id} className="p-3 rounded-lg bg-rose-500/10 border border-rose-500/20">
                    <span className="font-bold text-white block text-sm">{h.holidayName}</span>
                    <span className="text-xs text-rose-300 block">
                      Type: {h.holidayType} | Span: {h.startDate} to {h.endDate}
                    </span>
                    {h.description && <p className="text-xs text-slate-300 mt-1">{h.description}</p>}
                  </div>
                ))}
              </div>
            )}

            {/* Special Working Day Overrides */}
            {((inspectDay?.specialWorkingDays?.length || 0) > 0) && (
              <div className="space-y-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
                  <Sun className="w-3.5 h-3.5" /> Special Working Overrides ({inspectDay?.specialWorkingDays?.length || 0})
                </h4>
                {inspectDay.specialWorkingDays.map((s) => (
                  <div key={s.id} className="p-3 rounded-lg bg-amber-500/10 border border-amber-500/20">
                    <span className="font-bold text-white block text-sm">{s.reason}</span>
                    <span className="text-xs text-amber-300 block">Overrides: {s.overridesDayType}</span>
                  </div>
                ))}
              </div>
            )}

            {/* School Events */}
            {((inspectDay?.events?.length || 0) > 0) && (
              <div className="space-y-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-indigo-400 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" /> Scheduled School Events ({inspectDay?.events?.length || 0})
                </h4>
                {inspectDay.events.map((e) => (
                  <div key={e.id} className="p-3 rounded-lg bg-indigo-500/10 border border-indigo-500/20">
                    <span className="font-bold text-white block text-sm">{e.title}</span>
                    <span className="text-xs text-indigo-300 block">
                      Audience: {e.targetAudience} | Category: {e.eventType}
                    </span>
                    {e.description && <p className="text-xs text-slate-300 mt-1">{e.description}</p>}
                  </div>
                ))}
              </div>
            )}

            {/* Scheduled Exam Papers */}
            {((inspectDay?.exams?.length || 0) > 0) && (
              <div className="space-y-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-purple-400 flex items-center gap-1.5">
                  <BookOpen className="w-3.5 h-3.5" /> Scheduled Exam Papers ({inspectDay?.exams?.length || 0})
                </h4>
                {inspectDay.exams.map((ex) => (
                  <div key={ex.id} className="p-3 rounded-lg bg-purple-500/10 border border-purple-500/20">
                    <span className="font-bold text-white block text-sm">
                      {ex.subjectName} ({ex.examName})
                    </span>
                    <span className="text-xs text-purple-300 block">
                      Time: {ex.startTime} - {ex.endTime} | Room: {ex.roomNumber || 'Assigned Hall'} | Max Marks: {ex.maxMarks}
                    </span>
                  </div>
                ))}
              </div>
            )}

            {(inspectDay?.holidays?.length || 0) === 0 &&
              (inspectDay?.specialWorkingDays?.length || 0) === 0 &&
              (inspectDay?.events?.length || 0) === 0 &&
              (inspectDay?.exams?.length || 0) === 0 && (
                <div className="p-4 rounded-xl bg-slate-800/40 text-center text-slate-400 text-xs">
                  Standard operating schedule with no special events or holiday closures on this date.
                </div>
              )}

            <div className="flex justify-end pt-3 border-t border-white/10">
              <Button variant="outline" onClick={() => setInspectDay(null)}>
                Close
              </Button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
