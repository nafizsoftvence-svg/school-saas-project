import React, { useState, useEffect, useMemo } from 'react';
import {
  Bell,
  Mail,
  MessageSquare,
  Smartphone,
  Shield,
  Send,
  RefreshCw,
  Search,
  Filter,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Clock,
  Eye,
  Edit3,
  Sliders,
  FileText,
  Key,
  RotateCcw,
  Check,
  ChevronRight,
  ExternalLink,
  Layers,
  Sparkles,
  Info,
  Megaphone,
  Activity
} from 'lucide-react';
import { api } from '../../../services/api.js';
import {
  CommunicationSettings,
  CommunicationTemplate,
  CommunicationLog,
  CommunicationStats,
  NotificationChannel,
  CommunicationDeliveryStatus
} from '../../../types/index.js';
import { AnnouncementsManagementTab } from './AnnouncementsManagementTab.js';
import { InboxPage } from '../../../components/inbox/InboxPage.js';
import { BulkCampaignsManagementTab } from './BulkCampaignsManagementTab.js';
import { CommunicationAnalyticsTab } from './CommunicationAnalyticsTab.js';

interface CommunicationManagementPageProps {
  initialTab?: 'overview' | 'inbox' | 'campaigns' | 'announcements' | 'analytics' | 'channels' | 'templates' | 'logs' | 'policy';
  activeTab?: 'overview' | 'inbox' | 'campaigns' | 'announcements' | 'analytics' | 'channels' | 'templates' | 'logs' | 'policy';
  onTabChange?: (tab: string) => void;
  hideTabBar?: boolean;
}

export const CommunicationManagementPage: React.FC<CommunicationManagementPageProps> = ({
  initialTab,
  activeTab: propActiveTab,
  onTabChange,
  hideTabBar = true
}) => {
  const [internalTab, setInternalTab] = useState<'overview' | 'inbox' | 'campaigns' | 'announcements' | 'analytics' | 'channels' | 'templates' | 'logs' | 'policy'>(
    initialTab || 'overview'
  );
  const activeTab = propActiveTab || internalTab;
  const setActiveTab = (tab: any) => {
    setInternalTab(tab);
    onTabChange?.(tab);
  };
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Core Data States
  const [settings, setSettings] = useState<CommunicationSettings | null>(null);
  const [templates, setTemplates] = useState<CommunicationTemplate[]>([]);
  const [logs, setLogs] = useState<CommunicationLog[]>([]);
  const [stats, setStats] = useState<CommunicationStats | null>(null);

  // Filters for Templates
  const [templateSearch, setTemplateSearch] = useState('');
  const [templateCategoryFilter, setTemplateCategoryFilter] = useState<string>('all');

  // Filters for Logs
  const [logSearch, setLogSearch] = useState('');
  const [logChannelFilter, setLogChannelFilter] = useState<string>('all');
  const [logStatusFilter, setLogStatusFilter] = useState<string>('all');
  const [selectedLog, setSelectedLog] = useState<CommunicationLog | null>(null);

  // Template Editing & Preview Modals
  const [editingTemplate, setEditingTemplate] = useState<CommunicationTemplate | null>(null);
  const [previewTemplate, setPreviewTemplate] = useState<{
    template: CommunicationTemplate;
    title: string;
    body: string;
    emailSubject: string;
    emailHtml: string;
    sms: string;
  } | null>(null);

  // Provider Test Modal
  const [testModalChannel, setTestModalChannel] = useState<NotificationChannel | null>(null);
  const [testRecipient, setTestRecipient] = useState('');
  const [isTestingProvider, setIsTestingProvider] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; status: string; message: string } | null>(null);

  // Load All Communications Data
  const loadData = async () => {
    setIsLoading(true);
    setErrorMessage(null);
    try {
      const [settingsRes, templatesRes, logsRes, statsRes] = await Promise.all([
        api.communication.getSettings(),
        api.communication.getTemplates(),
        api.communication.getLogs({ limit: 100 }),
        api.communication.getStats()
      ]);

      if (settingsRes.success && settingsRes.data) {
        setSettings(settingsRes.data);
      }
      if (templatesRes.success && templatesRes.data) {
        setTemplates(templatesRes.data);
      }
      if (logsRes.success && logsRes.data) {
        setLogs(logsRes.data);
      }
      if (statsRes.success && statsRes.data) {
        setStats(statsRes.data);
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to load communication configuration and logs.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const showNotification = (msg: string, isError = false) => {
    if (isError) {
      setErrorMessage(msg);
      setTimeout(() => setErrorMessage(null), 5000);
    } else {
      setSuccessMessage(msg);
      setTimeout(() => setSuccessMessage(null), 4000);
    }
  };

  // Save Settings
  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!settings) return;
    setIsSaving(true);
    setErrorMessage(null);
    try {
      const res = await api.communication.updateSettings(settings);
      if (res.success && res.data) {
        setSettings(res.data);
        showNotification('Communication and gateway settings saved successfully.');
      } else {
        showNotification((res as any).error || 'Failed to save settings.', true);
      }
    } catch (err: any) {
      showNotification(err.message || 'An error occurred while saving settings.', true);
    } finally {
      setIsSaving(false);
    }
  };

  // Run Provider Test
  const handleRunTest = async () => {
    if (!testModalChannel) return;
    setIsTestingProvider(true);
    setTestResult(null);
    try {
      const res = await api.communication.testProvider(testModalChannel, testRecipient);
      setTestResult(res);
      // Reload logs and stats
      const [logsRes, statsRes] = await Promise.all([
        api.communication.getLogs({ limit: 100 }),
        api.communication.getStats()
      ]);
      if (logsRes.success && logsRes.data) setLogs(logsRes.data);
      if (statsRes.success && statsRes.data) setStats(statsRes.data);
    } catch (err: any) {
      setTestResult({
        success: false,
        status: 'FAILED',
        message: err.message || 'An error occurred during channel test.'
      });
    } finally {
      setIsTestingProvider(false);
    }
  };

  // Toggle Template Status
  const handleToggleTemplate = async (templateId: string) => {
    try {
      const res = await api.communication.toggleTemplate(templateId);
      if (res.success) {
        setTemplates((prev) =>
          prev.map((t) => (t.id === templateId ? { ...t, isActive: res.isActive } : t))
        );
        showNotification(res.message);
      }
    } catch (err: any) {
      showNotification(err.message || 'Failed to toggle template status.', true);
    }
  };

  // Save Template Edit
  const handleSaveTemplateEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingTemplate) return;
    setIsSaving(true);
    try {
      const res = await api.communication.updateTemplate(editingTemplate.id, editingTemplate);
      if (res.success && res.data) {
        setTemplates((prev) => prev.map((t) => (t.id === editingTemplate.id ? res.data! : t)));
        setEditingTemplate(null);
        showNotification('Notification template updated successfully.');
      } else {
        showNotification((res as any).error || 'Failed to update template.', true);
      }
    } catch (err: any) {
      showNotification(err.message || 'An error occurred updating the template.', true);
    } finally {
      setIsSaving(false);
    }
  };

  // Preview Template
  const handleOpenPreview = async (template: CommunicationTemplate) => {
    try {
      const res = await api.communication.previewTemplate({
        templateId: template.id
      });
      if (res.success && res.data) {
        setPreviewTemplate({
          template,
          title: res.data.title,
          body: res.data.body,
          emailSubject: res.data.emailSubject,
          emailHtml: res.data.emailHtml,
          sms: res.data.sms
        });
      }
    } catch (err: any) {
      showNotification(err.message || 'Failed to generate preview.', true);
    }
  };

  // Reset Templates to Default
  const handleResetTemplates = async () => {
    if (!window.confirm('Are you sure you want to reset all notification templates to system defaults? Any custom wording will be restored to default baseline.')) {
      return;
    }
    setIsLoading(true);
    try {
      const res = await api.communication.resetTemplates();
      if (res.success && res.data) {
        setTemplates(res.data);
        showNotification('Templates have been successfully restored to system defaults.');
      }
    } catch (err: any) {
      showNotification(err.message || 'Failed to reset templates.', true);
    } finally {
      setIsLoading(false);
    }
  };

  // Retry Failed Log
  const handleRetryLog = async (logId: string) => {
    try {
      const res = await api.communication.retryLog(logId);
      if (res.success && res.data) {
        setLogs((prev) => prev.map((l) => (l.id === logId ? res.data! : l)));
        if (selectedLog?.id === logId) {
          setSelectedLog(res.data);
        }
        showNotification('Delivery retry completed.');
        // Refresh stats
        const sRes = await api.communication.getStats();
        if (sRes.success && sRes.data) setStats(sRes.data);
      } else {
        showNotification((res as any).error || 'Retry failed.', true);
      }
    } catch (err: any) {
      showNotification(err.message || 'Failed to retry delivery.', true);
    }
  };

  // Filtered Templates Memo
  const filteredTemplates = useMemo(() => {
    return templates.filter((t) => {
      if (templateCategoryFilter !== 'all' && t.category !== templateCategoryFilter) return false;
      if (templateSearch.trim()) {
        const q = templateSearch.toLowerCase();
        return (
          t.name.toLowerCase().includes(q) ||
          t.eventType.toLowerCase().includes(q) ||
          t.description.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [templates, templateCategoryFilter, templateSearch]);

  // Filtered Logs Memo
  const filteredLogs = useMemo(() => {
    return logs.filter((l) => {
      if (logChannelFilter !== 'all' && l.channel !== logChannelFilter) return false;
      if (logStatusFilter !== 'all' && l.status !== logStatusFilter) return false;
      if (logSearch.trim()) {
        const q = logSearch.toLowerCase();
        return (
          l.recipientName.toLowerCase().includes(q) ||
          (l.recipientContact && l.recipientContact.toLowerCase().includes(q)) ||
          l.title.toLowerCase().includes(q) ||
          (l.relatedStudentName && l.relatedStudentName.toLowerCase().includes(q)) ||
          l.eventType.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [logs, logChannelFilter, logStatusFilter, logSearch]);

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Header */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-50 border border-indigo-100 rounded-xl text-indigo-600">
              <Bell className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Communication & Alerts Foundation</h1>
              <p className="text-sm text-slate-500 mt-0.5">
                Centralized multi-channel notification engine, gateway credentials, templates, and delivery audit.
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={loadData}
            disabled={isLoading}
            className="inline-flex items-center gap-2 px-4 py-2 border border-slate-200 text-sm font-medium rounded-lg text-slate-700 bg-white hover:bg-slate-50 transition-colors"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin text-indigo-600' : ''}`} />
            Refresh
          </button>
          <button
            onClick={() => {
              setTestModalChannel('IN_APP');
              setTestRecipient('');
              setTestResult(null);
            }}
            className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white text-sm font-medium rounded-lg hover:bg-indigo-700 shadow-sm transition-colors"
          >
            <Send className="w-4 h-4" />
            Test Channel
          </button>
        </div>
      </div>

      {/* Notifications / Feedback */}
      {successMessage && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-sm flex items-center justify-between animate-fadeIn">
          <div className="flex items-center gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 flex-shrink-0" />
            <span>{successMessage}</span>
          </div>
          <button onClick={() => setSuccessMessage(null)} className="text-emerald-600 hover:text-emerald-800 text-xs font-semibold">
            Dismiss
          </button>
        </div>
      )}

      {errorMessage && (
        <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-sm flex items-center justify-between animate-fadeIn">
          <div className="flex items-center gap-3">
            <AlertTriangle className="w-5 h-5 text-rose-600 flex-shrink-0" />
            <span>{errorMessage}</span>
          </div>
          <button onClick={() => setErrorMessage(null)} className="text-rose-600 hover:text-rose-800 text-xs font-semibold">
            Dismiss
          </button>
        </div>
      )}

      {/* Navigation Tabs */}
      {!hideTabBar && (
        <div className="flex border-b border-slate-200 gap-2 overflow-x-auto">
          <button
            onClick={() => setActiveTab('overview')}
          className={`pb-3 px-4 text-sm font-medium border-b-2 transition-colors whitespace-nowrap flex items-center gap-2 ${
            activeTab === 'overview'
              ? 'border-indigo-600 text-indigo-600'
              : 'border-transparent text-slate-500 hover:text-slate-700'
          }`}
        >
          <Layers className="w-4 h-4" />
          Overview & Status
        </button>

        <button
          id="admin-comm-tab-inbox"
          onClick={() => setActiveTab('inbox')}
          className={`pb-3 px-4 text-sm font-medium border-b-2 transition-colors whitespace-nowrap flex items-center gap-2 ${
            activeTab === 'inbox'
              ? 'border-indigo-600 text-indigo-600'
              : 'border-transparent text-slate-500 hover:text-slate-700'
          }`}
        >
          <Mail className="w-4 h-4" />
          Messages & Inbox
        </button>

        <button
          onClick={() => setActiveTab('announcements')}
          className={`pb-3 px-4 text-sm font-medium border-b-2 transition-colors whitespace-nowrap flex items-center gap-2 ${
            activeTab === 'announcements'
              ? 'border-indigo-600 text-indigo-600'
              : 'border-transparent text-slate-500 hover:text-slate-700'
          }`}
        >
          <Megaphone className="w-4 h-4" />
          Announcements & Circulars
        </button>

        <button
          id="admin-comm-tab-campaigns"
          onClick={() => setActiveTab('campaigns')}
          className={`pb-3 px-4 text-sm font-medium border-b-2 transition-colors whitespace-nowrap flex items-center gap-2 ${
            activeTab === 'campaigns'
              ? 'border-indigo-600 text-indigo-600'
              : 'border-transparent text-slate-500 hover:text-slate-700'
          }`}
        >
          <Send className="w-4 h-4" />
          Bulk Campaigns
        </button>

        <button
          id="admin-comm-tab-analytics"
          onClick={() => setActiveTab('analytics')}
          className={`pb-3 px-4 text-sm font-medium border-b-2 transition-colors whitespace-nowrap flex items-center gap-2 ${
            activeTab === 'analytics'
              ? 'border-indigo-600 text-indigo-600'
              : 'border-transparent text-slate-500 hover:text-slate-700'
          }`}
        >
          <Activity className="w-4 h-4" />
          Analytics & Delivery Reports
        </button>

        <button
          onClick={() => setActiveTab('channels')}
          className={`pb-3 px-4 text-sm font-medium border-b-2 transition-colors whitespace-nowrap flex items-center gap-2 ${
            activeTab === 'channels'
              ? 'border-indigo-600 text-indigo-600'
              : 'border-transparent text-slate-500 hover:text-slate-700'
          }`}
        >
          <Sliders className="w-4 h-4" />
          Gateways & Providers
        </button>

        <button
          onClick={() => setActiveTab('templates')}
          className={`pb-3 px-4 text-sm font-medium border-b-2 transition-colors whitespace-nowrap flex items-center gap-2 ${
            activeTab === 'templates'
              ? 'border-indigo-600 text-indigo-600'
              : 'border-transparent text-slate-500 hover:text-slate-700'
          }`}
        >
          <FileText className="w-4 h-4" />
          Notification Templates ({templates.length})
        </button>

        <button
          onClick={() => setActiveTab('logs')}
          className={`pb-3 px-4 text-sm font-medium border-b-2 transition-colors whitespace-nowrap flex items-center gap-2 ${
            activeTab === 'logs'
              ? 'border-indigo-600 text-indigo-600'
              : 'border-transparent text-slate-500 hover:text-slate-700'
          }`}
        >
          <Clock className="w-4 h-4" />
          Delivery Logs ({logs.length})
        </button>

        <button
          onClick={() => setActiveTab('policy')}
          className={`pb-3 px-4 text-sm font-medium border-b-2 transition-colors whitespace-nowrap flex items-center gap-2 ${
            activeTab === 'policy'
              ? 'border-indigo-600 text-indigo-600'
              : 'border-transparent text-slate-500 hover:text-slate-700'
          }`}
        >
          <Shield className="w-4 h-4" />
          Mandatory Policies
        </button>
      </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 1: OVERVIEW & SYSTEM HEALTH */}
      {/* ========================================================================= */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          {/* Channel Readiness Status Grid */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {/* In-App Channel */}
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
              <div className="flex items-center justify-between mb-3">
                <div className="p-2 bg-emerald-50 text-emerald-600 rounded-lg">
                  <Bell className="w-5 h-5" />
                </div>
                <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 text-xs font-semibold rounded-full flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" /> Active
                </span>
              </div>
              <h3 className="font-semibold text-slate-900">In-App Notifications</h3>
              <p className="text-xs text-slate-500 mt-1">Real-time alerts stored in database with instant read state.</p>
              <div className="mt-4 pt-3 border-t border-slate-100 flex justify-between text-xs text-slate-600">
                <span>Retention:</span>
                <span className="font-semibold text-slate-800">{settings?.inApp.retentionDays || 90} Days</span>
              </div>
            </div>

            {/* Email Gateway */}
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
              <div className="flex items-center justify-between mb-3">
                <div className="p-2 bg-blue-50 text-blue-600 rounded-lg">
                  <Mail className="w-5 h-5" />
                </div>
                <span
                  className={`px-2 py-0.5 text-xs font-semibold rounded-full flex items-center gap-1 ${
                    settings?.email.status === 'ACTIVE'
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-amber-100 text-amber-800'
                  }`}
                >
                  {settings?.email.status === 'ACTIVE' ? (
                    <>
                      <CheckCircle2 className="w-3 h-3" /> Active
                    </>
                  ) : (
                    <>
                      <Info className="w-3 h-3" /> Sandbox / Auth Req.
                    </>
                  )}
                </span>
              </div>
              <h3 className="font-semibold text-slate-900">Email Gateway</h3>
              <p className="text-xs text-slate-500 mt-1">
                {settings?.email.senderEmail} ({settings?.email.provider})
              </p>
              <div className="mt-4 pt-3 border-t border-slate-100 flex justify-between text-xs text-slate-600">
                <span>Status:</span>
                <span className="font-medium text-slate-800">
                  {settings?.email.status === 'ACTIVE' ? 'Credentials Verified' : 'In-App Safe Fallback'}
                </span>
              </div>
            </div>

            {/* SMS Gateway */}
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
              <div className="flex items-center justify-between mb-3">
                <div className="p-2 bg-purple-50 text-purple-600 rounded-lg">
                  <MessageSquare className="w-5 h-5" />
                </div>
                <span
                  className={`px-2 py-0.5 text-xs font-semibold rounded-full flex items-center gap-1 ${
                    settings?.sms.status === 'ACTIVE'
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-slate-100 text-slate-700'
                  }`}
                >
                  {settings?.sms.status === 'ACTIVE' ? 'Active' : 'Not Configured'}
                </span>
              </div>
              <h3 className="font-semibold text-slate-900">SMS Gateway</h3>
              <p className="text-xs text-slate-500 mt-1">Provider: {settings?.sms.provider} (Sender: {settings?.sms.senderId})</p>
              <div className="mt-4 pt-3 border-t border-slate-100 flex justify-between text-xs text-slate-600">
                <span>Enabled:</span>
                <span className="font-semibold text-slate-800">{settings?.sms.enabled ? 'Yes' : 'Disabled'}</span>
              </div>
            </div>

            {/* Push Notifications */}
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
              <div className="flex items-center justify-between mb-3">
                <div className="p-2 bg-rose-50 text-rose-600 rounded-lg">
                  <Smartphone className="w-5 h-5" />
                </div>
                <span
                  className={`px-2 py-0.5 text-xs font-semibold rounded-full flex items-center gap-1 ${
                    settings?.push.status === 'ACTIVE'
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-slate-100 text-slate-700'
                  }`}
                >
                  {settings?.push.status === 'ACTIVE' ? 'Active' : 'Not Configured'}
                </span>
              </div>
              <h3 className="font-semibold text-slate-900">Push Notifications</h3>
              <p className="text-xs text-slate-500 mt-1">Provider: {settings?.push.provider}</p>
              <div className="mt-4 pt-3 border-t border-slate-100 flex justify-between text-xs text-slate-600">
                <span>Enabled:</span>
                <span className="font-semibold text-slate-800">{settings?.push.enabled ? 'Yes' : 'Disabled'}</span>
              </div>
            </div>
          </div>

          {/* Delivery & Operational Metrics */}
          {stats && (
            <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
              <h2 className="text-base font-semibold text-slate-900 mb-4 flex items-center gap-2">
                <Shield className="w-4 h-4 text-indigo-600" />
                Delivery Statistics & Reliability Metrics
              </h2>

              <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                <div className="p-4 bg-slate-50 border border-slate-100 rounded-xl">
                  <span className="text-xs text-slate-500">Total Logged Alerts</span>
                  <p className="text-2xl font-bold text-slate-900 mt-1">{stats.totalLogged}</p>
                </div>
                <div className="p-4 bg-emerald-50 border border-emerald-100 rounded-xl">
                  <span className="text-xs text-emerald-700">Delivered</span>
                  <p className="text-2xl font-bold text-emerald-900 mt-1">{stats.deliveredCount}</p>
                </div>
                <div className="p-4 bg-blue-50 border border-blue-100 rounded-xl">
                  <span className="text-xs text-blue-700">Sent / In Flight</span>
                  <p className="text-2xl font-bold text-blue-900 mt-1">{stats.sentCount}</p>
                </div>
                <div className="p-4 bg-rose-50 border border-rose-100 rounded-xl">
                  <span className="text-xs text-rose-700">Sandbox / Unconfigured</span>
                  <p className="text-2xl font-bold text-rose-900 mt-1">{stats.failedCount}</p>
                </div>
                <div className="p-4 bg-indigo-50 border border-indigo-100 rounded-xl">
                  <span className="text-xs text-indigo-700">In-App Success Rate</span>
                  <p className="text-2xl font-bold text-indigo-900 mt-1">{stats.deliveryRate}%</p>
                </div>
              </div>

              {/* Deduplication & Reliability Policy info banner */}
              <div className="mt-6 p-4 bg-slate-50 border border-slate-200 rounded-xl flex items-start gap-3">
                <Info className="w-5 h-5 text-indigo-600 flex-shrink-0 mt-0.5" />
                <div className="text-xs text-slate-600 leading-relaxed">
                  <strong className="text-slate-800">Deduplication & Truthful Channel Policy:</strong> When external gateways (SMTP/SMS) operate without live production secrets, the system truthfully logs them as unconfigured and safely records instant In-App delivery. Deduplication keys prevent spamming parent mobile inboxes when pages are refreshed or records re-marked.
                </div>
              </div>
            </div>
          )}

          {/* Recent Delivery Stream preview */}
          <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-base font-semibold text-slate-900">Recent Communication Dispatches</h3>
                <p className="text-xs text-slate-500">Live feed of notifications across attendance, examination, finance, and admissions.</p>
              </div>
              <button
                onClick={() => setActiveTab('logs')}
                className="text-xs text-indigo-600 hover:text-indigo-800 font-semibold flex items-center gap-1"
              >
                View all logs ({logs.length}) <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-600">
                <thead className="bg-slate-50 text-slate-700 border-y border-slate-200 uppercase font-semibold">
                  <tr>
                    <th className="py-2.5 px-3">Recipient</th>
                    <th className="py-2.5 px-3">Channel</th>
                    <th className="py-2.5 px-3">Event Type</th>
                    <th className="py-2.5 px-3">Title / Subject</th>
                    <th className="py-2.5 px-3">Status</th>
                    <th className="py-2.5 px-3">Timestamp</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {logs.slice(0, 5).map((log) => (
                    <tr key={log.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3 px-3 font-medium text-slate-900">
                        {log.recipientName}
                        <span className="block text-[10px] text-slate-400 uppercase">{log.recipientRole}</span>
                      </td>
                      <td className="py-3 px-3">
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-medium bg-slate-100 text-slate-700">
                          {log.channel}
                        </span>
                      </td>
                      <td className="py-3 px-3 font-mono text-[11px] text-slate-600">{log.eventType}</td>
                      <td className="py-3 px-3 max-w-xs truncate text-slate-800 font-medium">{log.title}</td>
                      <td className="py-3 px-3">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-semibold uppercase ${
                            log.status === 'DELIVERED'
                              ? 'bg-emerald-100 text-emerald-800'
                              : log.status === 'SENT'
                              ? 'bg-blue-100 text-blue-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {log.status}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-slate-400 whitespace-nowrap">
                        {new Date(log.createdAt).toLocaleString()}
                      </td>
                    </tr>
                  ))}
                  {logs.length === 0 && (
                    <tr>
                      <td colSpan={6} className="py-6 text-center text-slate-400">
                        No communication logs recorded yet.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB: MESSAGES & INBOX (PART 11C) */}
      {/* ========================================================================= */}
      {activeTab === 'inbox' && (
        <div className="pt-2">
          <InboxPage />
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB: ANNOUNCEMENTS & CIRCULARS (PART 11B) */}
      {/* ========================================================================= */}
      {activeTab === 'announcements' && <AnnouncementsManagementTab />}

      {/* ========================================================================= */}
      {/* TAB: BULK CAMPAIGNS (PART 11D) */}
      {/* ========================================================================= */}
      {activeTab === 'campaigns' && <BulkCampaignsManagementTab />}

      {/* ========================================================================= */}
      {/* TAB: COMMUNICATION ANALYTICS & DELIVERY LEDGER (PART 11E) */}
      {/* ========================================================================= */}
      {activeTab === 'analytics' && <CommunicationAnalyticsTab onNavigateToTab={(t: any) => setActiveTab(t)} />}

      {/* ========================================================================= */}
      {/* TAB 2: GATEWAYS & PROVIDER CONFIGURATION */}
      {/* ========================================================================= */}
      {activeTab === 'channels' && settings && (
        <form onSubmit={handleSaveSettings} className="space-y-6">
          {/* General Deduplication & Retries */}
          <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
            <h2 className="text-base font-semibold text-slate-900 mb-1 flex items-center gap-2">
              <Sliders className="w-4 h-4 text-indigo-600" />
              Global Deduplication & Reliability Engine
            </h2>
            <p className="text-xs text-slate-500 mb-4">
              Protects recipients against spam, rapid refreshes, and manages automated retry windows for delivery failures.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1.5">
                  Deduplication Window (Minutes)
                </label>
                <input
                  type="number"
                  min="1"
                  max="1440"
                  value={settings.general.deduplicationWindowMinutes}
                  onChange={(e) =>
                    setSettings({
                      ...settings,
                      general: {
                        ...settings.general,
                        deduplicationWindowMinutes: parseInt(e.target.value, 10) || 30
                      }
                    })
                  }
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500"
                />
                <span className="text-[11px] text-slate-400 mt-1 block">
                  Identical alerts for the same event and recipient will be suppressed.
                </span>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1.5">Max Delivery Retries</label>
                <input
                  type="number"
                  min="0"
                  max="10"
                  value={settings.general.maxRetries}
                  onChange={(e) =>
                    setSettings({
                      ...settings,
                      general: {
                        ...settings.general,
                        maxRetries: parseInt(e.target.value, 10) || 3
                      }
                    })
                  }
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500"
                />
                <span className="text-[11px] text-slate-400 mt-1 block">Maximum attempts permitted for failed dispatches.</span>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1.5">In-App Notification Retention</label>
                <input
                  type="number"
                  min="7"
                  max="365"
                  value={settings.inApp.retentionDays}
                  onChange={(e) =>
                    setSettings({
                      ...settings,
                      inApp: {
                        ...settings.inApp,
                        retentionDays: parseInt(e.target.value, 10) || 90
                      }
                    })
                  }
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500"
                />
                <span className="text-[11px] text-slate-400 mt-1 block">Days before past in-app alerts are pruned.</span>
              </div>
            </div>

            <div className="mt-4 pt-4 border-t border-slate-100 flex items-center justify-between">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.general.allowUserChannelPreferences}
                  onChange={(e) =>
                    setSettings({
                      ...settings,
                      general: {
                        ...settings.general,
                        allowUserChannelPreferences: e.target.checked
                      }
                    })
                  }
                  className="rounded text-indigo-600 focus:ring-indigo-500 w-4 h-4"
                />
                <span className="text-xs font-medium text-slate-700">
                  Allow recipients to customize non-mandatory notification preferences
                </span>
              </label>
            </div>
          </div>

          {/* Email Gateway Configuration */}
          <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-blue-50 text-blue-600 rounded-lg">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-base font-semibold text-slate-900">Institutional Email Gateway</h2>
                  <p className="text-xs text-slate-500">
                    Outbound SMTP / SendGrid service for notifications, invitations, and receipts.
                  </p>
                </div>
              </div>

              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.email.enabled}
                  onChange={(e) =>
                    setSettings({
                      ...settings,
                      email: { ...settings.email, enabled: e.target.checked }
                    })
                  }
                  className="rounded text-indigo-600 focus:ring-indigo-500 w-4 h-4"
                />
                <span className="text-xs font-semibold text-slate-700">Enable Email Channel</span>
              </label>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Provider Type</label>
                <select
                  value={settings.email.provider}
                  onChange={(e) =>
                    setSettings({
                      ...settings,
                      email: { ...settings.email, provider: e.target.value as any }
                    })
                  }
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm bg-white"
                >
                  <option value="SMTP">Standard SMTP Server</option>
                  <option value="SENDGRID">SendGrid API</option>
                  <option value="AWS_SES">Amazon Simple Email Service (SES)</option>
                  <option value="MAILGUN">Mailgun API</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">SMTP Host / Endpoint</label>
                <input
                  type="text"
                  value={settings.email.host || ''}
                  onChange={(e) =>
                    setSettings({
                      ...settings,
                      email: { ...settings.email, host: e.target.value }
                    })
                  }
                  placeholder="smtp.school.edu"
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Port</label>
                <input
                  type="number"
                  value={settings.email.port || 587}
                  onChange={(e) =>
                    setSettings({
                      ...settings,
                      email: { ...settings.email, port: parseInt(e.target.value, 10) || 587 }
                    })
                  }
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Sender Name</label>
                <input
                  type="text"
                  value={settings.email.senderName}
                  onChange={(e) =>
                    setSettings({
                      ...settings,
                      email: { ...settings.email, senderName: e.target.value }
                    })
                  }
                  placeholder="Sygmate Academy"
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Sender Email Address</label>
                <input
                  type="email"
                  value={settings.email.senderEmail}
                  onChange={(e) =>
                    setSettings({
                      ...settings,
                      email: { ...settings.email, senderEmail: e.target.value }
                    })
                  }
                  placeholder="notifications@sygmate-school.edu"
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  SMTP Password / API Key (Masked)
                </label>
                <div className="relative">
                  <input
                    type="password"
                    placeholder="Enter new credential to update"
                    defaultValue={settings.email.passwordMasked || '••••••••••••1234'}
                    onChange={(e) =>
                      setSettings({
                        ...settings,
                        email: { ...settings.email, password: e.target.value }
                      })
                    }
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm font-mono"
                  />
                  <span className="absolute right-3 top-2.5 text-xs text-slate-400">
                    <Key className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
              <button
                type="button"
                onClick={() => {
                  setTestModalChannel('EMAIL');
                  setTestRecipient(settings.email.senderEmail);
                  setTestResult(null);
                }}
                className="text-xs text-blue-600 hover:text-blue-800 font-semibold flex items-center gap-1.5"
              >
                <Send className="w-3.5 h-3.5" /> Test Email Delivery
              </button>
              <span className="text-[11px] text-slate-400">
                Secrets are stored server-side and never exposed across client sessions.
              </span>
            </div>
          </div>

          {/* SMS Gateway Configuration */}
          <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-purple-50 text-purple-600 rounded-lg">
                  <MessageSquare className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-base font-semibold text-slate-900">SMS Gateway Configuration</h2>
                  <p className="text-xs text-slate-500">Short message service for high-priority absences and emergencies.</p>
                </div>
              </div>

              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.sms.enabled}
                  onChange={(e) =>
                    setSettings({
                      ...settings,
                      sms: { ...settings.sms, enabled: e.target.checked }
                    })
                  }
                  className="rounded text-indigo-600 focus:ring-indigo-500 w-4 h-4"
                />
                <span className="text-xs font-semibold text-slate-700">Enable SMS Channel</span>
              </label>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Provider</label>
                <select
                  value={settings.sms.provider}
                  onChange={(e) =>
                    setSettings({
                      ...settings,
                      sms: { ...settings.sms, provider: e.target.value as any }
                    })
                  }
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm bg-white"
                >
                  <option value="TWILIO">Twilio SMS</option>
                  <option value="AWS_SNS">AWS SNS</option>
                  <option value="MESSAGEBIRD">MessageBird</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Sender ID / Alphanumeric Header</label>
                <input
                  type="text"
                  value={settings.sms.senderId}
                  onChange={(e) =>
                    setSettings({
                      ...settings,
                      sms: { ...settings.sms, senderId: e.target.value }
                    })
                  }
                  placeholder="SYGMATE"
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Auth Token / Secret Key (Masked)</label>
                <div className="relative">
                  <input
                    type="password"
                    placeholder="Enter new credential"
                    defaultValue={settings.sms.authTokenMasked || '••••••••••••5678'}
                    onChange={(e) =>
                      setSettings({
                        ...settings,
                        sms: { ...settings.sms, authToken: e.target.value }
                      })
                    }
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm font-mono"
                  />
                  <span className="absolute right-3 top-2.5 text-xs text-slate-400">
                    <Key className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
              <button
                type="button"
                onClick={() => {
                  setTestModalChannel('SMS');
                  setTestRecipient('+15550192834');
                  setTestResult(null);
                }}
                className="text-xs text-purple-600 hover:text-purple-800 font-semibold flex items-center gap-1.5"
              >
                <Send className="w-3.5 h-3.5" /> Test SMS Delivery
              </button>
              <span className="text-[11px] text-slate-400">Honest status reporting prevents pseudo-success alerts.</span>
            </div>
          </div>

          {/* Submit button */}
          <div className="flex justify-end gap-3 pt-4 border-t border-slate-200">
            <button
              type="submit"
              disabled={isSaving}
              className="inline-flex items-center gap-2 px-6 py-2.5 bg-indigo-600 text-white text-sm font-medium rounded-lg hover:bg-indigo-700 transition-colors shadow-sm disabled:opacity-50"
            >
              {isSaving ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  Saving Settings...
                </>
              ) : (
                <>
                  <Check className="w-4 h-4" />
                  Save Communication Settings
                </>
              )}
            </button>
          </div>
        </form>
      )}

      {/* ========================================================================= */}
      {/* TAB 3: NOTIFICATION TEMPLATES */}
      {/* ========================================================================= */}
      {activeTab === 'templates' && (
        <div className="space-y-6">
          {/* Controls Bar */}
          <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div className="flex flex-col sm:flex-row gap-3 flex-1">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <input
                  type="text"
                  placeholder="Search templates by event type, title, or keyword..."
                  value={templateSearch}
                  onChange={(e) => setTemplateSearch(e.target.value)}
                  className="w-full pl-9 pr-4 py-2 border border-slate-200 rounded-lg text-sm"
                />
              </div>

              <select
                value={templateCategoryFilter}
                onChange={(e) => setTemplateCategoryFilter(e.target.value)}
                className="px-3 py-2 border border-slate-200 rounded-lg text-sm bg-white"
              >
                <option value="all">All Categories</option>
                <option value="attendance">Attendance & Leaves</option>
                <option value="exam">Examination & Academics</option>
                <option value="fee">Fees & Finance</option>
                <option value="admission">Admissions & Promotions</option>
                <option value="security">Account & Security</option>
                <option value="general">General Bulletins</option>
              </select>
            </div>

            <button
              onClick={handleResetTemplates}
              className="inline-flex items-center gap-2 px-3 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Reset System Defaults
            </button>
          </div>

          {/* Templates Grid / Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredTemplates.map((template) => (
              <div
                key={template.id}
                className={`bg-white border rounded-xl p-5 shadow-sm transition-all flex flex-col justify-between ${
                  template.isActive ? 'border-slate-200' : 'border-slate-200 opacity-60 bg-slate-50/50'
                }`}
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div>
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-indigo-50 text-indigo-700 border border-indigo-100">
                        {template.category}
                      </span>
                      {template.isMandatory && (
                        <span className="ml-2 px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-rose-50 text-rose-700 border border-rose-100">
                          Mandatory
                        </span>
                      )}
                      <h3 className="font-semibold text-slate-900 mt-1">{template.name}</h3>
                      <p className="font-mono text-xs text-slate-400">{template.eventType}</p>
                    </div>

                    <label className="flex items-center gap-1.5 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={template.isActive}
                        onChange={() => handleToggleTemplate(template.id)}
                        className="rounded text-indigo-600 focus:ring-indigo-500 w-4 h-4"
                      />
                      <span className="text-xs font-medium text-slate-600">Active</span>
                    </label>
                  </div>

                  <p className="text-xs text-slate-500 mt-1 line-clamp-2">{template.description}</p>

                  {/* Message Title Preview */}
                  <div className="mt-3 p-2.5 bg-slate-50 rounded-lg border border-slate-100">
                    <span className="text-[10px] text-slate-400 font-semibold uppercase block mb-1">Subject / Header:</span>
                    <p className="text-xs font-medium text-slate-800 truncate">{template.titleTemplate}</p>
                  </div>

                  {/* Channel Badges */}
                  <div className="mt-3 flex items-center gap-1.5">
                    <span className="text-[11px] text-slate-400 mr-1">Channels:</span>
                    {template.channels.inApp && (
                      <span className="px-2 py-0.5 bg-slate-100 text-slate-700 rounded text-[10px] font-medium">In-App</span>
                    )}
                    {template.channels.email && (
                      <span className="px-2 py-0.5 bg-blue-50 text-blue-700 rounded text-[10px] font-medium">Email</span>
                    )}
                    {template.channels.sms && (
                      <span className="px-2 py-0.5 bg-purple-50 text-purple-700 rounded text-[10px] font-medium">SMS</span>
                    )}
                    {template.channels.push && (
                      <span className="px-2 py-0.5 bg-rose-50 text-rose-700 rounded text-[10px] font-medium">Push</span>
                    )}
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                  <span className="text-[11px] text-slate-400">
                    Vars: {template.allowedVariables.slice(0, 3).join(', ')}...
                  </span>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleOpenPreview(template)}
                      className="px-2.5 py-1 text-xs font-medium text-slate-600 hover:text-indigo-600 hover:bg-indigo-50 rounded border border-slate-200 transition-colors flex items-center gap-1"
                    >
                      <Eye className="w-3.5 h-3.5" /> Preview
                    </button>
                    <button
                      onClick={() => setEditingTemplate(template)}
                      className="px-2.5 py-1 text-xs font-medium text-indigo-600 hover:bg-indigo-50 rounded border border-indigo-200 transition-colors flex items-center gap-1"
                    >
                      <Edit3 className="w-3.5 h-3.5" /> Edit
                    </button>
                  </div>
                </div>
              </div>
            ))}

            {filteredTemplates.length === 0 && (
              <div className="col-span-2 py-12 text-center text-slate-400 bg-white border border-slate-200 rounded-xl">
                No notification templates found matching your search or category filter.
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 4: DELIVERY LOGS & AUDIT */}
      {/* ========================================================================= */}
      {activeTab === 'logs' && (
        <div className="space-y-6">
          {/* Filters */}
          <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm flex flex-col md:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                type="text"
                placeholder="Search logs by recipient, student, title, or event..."
                value={logSearch}
                onChange={(e) => setLogSearch(e.target.value)}
                className="w-full pl-9 pr-4 py-2 border border-slate-200 rounded-lg text-sm"
              />
            </div>

            <select
              value={logChannelFilter}
              onChange={(e) => setLogChannelFilter(e.target.value)}
              className="px-3 py-2 border border-slate-200 rounded-lg text-sm bg-white"
            >
              <option value="all">All Channels</option>
              <option value="IN_APP">In-App</option>
              <option value="EMAIL">Email</option>
              <option value="SMS">SMS</option>
              <option value="PUSH">Push</option>
            </select>

            <select
              value={logStatusFilter}
              onChange={(e) => setLogStatusFilter(e.target.value)}
              className="px-3 py-2 border border-slate-200 rounded-lg text-sm bg-white"
            >
              <option value="all">All Statuses</option>
              <option value="DELIVERED">Delivered</option>
              <option value="SENT">Sent</option>
              <option value="FAILED">Failed / Sandbox</option>
              <option value="PENDING">Pending</option>
            </select>
          </div>

          {/* Logs Table */}
          <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-600">
                <thead className="bg-slate-50 text-slate-700 border-b border-slate-200 uppercase font-semibold">
                  <tr>
                    <th className="py-3 px-4">Recipient</th>
                    <th className="py-3 px-4">Channel</th>
                    <th className="py-3 px-4">Event Type</th>
                    <th className="py-3 px-4">Subject / Message</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4">Timestamp</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredLogs.map((log) => (
                    <tr key={log.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3 px-4 font-medium text-slate-900">
                        {log.recipientName}
                        <span className="block text-[10px] text-slate-400 uppercase">
                          {log.recipientRole} {log.recipientContact ? `• ${log.recipientContact}` : ''}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium bg-slate-100 text-slate-700">
                          {log.channel}
                        </span>
                      </td>
                      <td className="py-3 px-4 font-mono text-[11px] text-slate-700">{log.eventType}</td>
                      <td className="py-3 px-4 max-w-xs">
                        <div className="font-medium text-slate-800 truncate">{log.title}</div>
                        <div className="text-[11px] text-slate-400 truncate">{log.message}</div>
                      </td>
                      <td className="py-3 px-4">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-semibold uppercase ${
                            log.status === 'DELIVERED'
                              ? 'bg-emerald-100 text-emerald-800'
                              : log.status === 'SENT'
                              ? 'bg-blue-100 text-blue-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {log.status}
                        </span>
                        {log.status === 'FAILED' && log.retryCount > 0 && (
                          <span className="block text-[10px] text-slate-400 mt-0.5">
                            Retries: {log.retryCount}/{log.maxRetries}
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-slate-400 whitespace-nowrap">
                        {new Date(log.createdAt).toLocaleString()}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <button
                          onClick={() => setSelectedLog(log)}
                          className="px-2.5 py-1 text-xs font-medium text-slate-600 hover:text-indigo-600 hover:bg-slate-100 rounded transition-colors"
                        >
                          Details
                        </button>
                      </td>
                    </tr>
                  ))}

                  {filteredLogs.length === 0 && (
                    <tr>
                      <td colSpan={7} className="py-8 text-center text-slate-400">
                        No communication logs found matching your filters.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 5: MANDATORY POLICIES & PREFERENCES */}
      {/* ========================================================================= */}
      {activeTab === 'policy' && (
        <div className="space-y-6">
          <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
            <h2 className="text-base font-semibold text-slate-900 mb-1 flex items-center gap-2">
              <Shield className="w-4 h-4 text-indigo-600" />
              Institutional Mandatory Notification Policy
            </h2>
            <p className="text-xs text-slate-500 mb-4 leading-relaxed">
              School governance rules require critical safety, legal, and academic alerts to bypass recipient opt-outs.
              When an event is designated as Mandatory, recipients will receive alerts through all authorized channels even if they have muted general category notifications.
            </p>

            <div className="space-y-3">
              {templates
                .filter((t) => t.isMandatory)
                .map((t) => (
                  <div key={t.id} className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg flex items-center justify-between">
                    <div>
                      <span className="text-xs font-semibold text-slate-900">{t.name}</span>
                      <span className="font-mono text-[11px] text-slate-400 ml-2">({t.eventType})</span>
                      <p className="text-xs text-slate-500 mt-0.5">{t.description}</p>
                    </div>
                    <span className="px-2.5 py-1 bg-rose-50 text-rose-700 border border-rose-200 rounded text-xs font-semibold whitespace-nowrap">
                      Policy Enforced
                    </span>
                  </div>
                ))}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: EDIT TEMPLATE */}
      {/* ========================================================================= */}
      {editingTemplate && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 shadow-xl">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div>
                <h3 className="text-lg font-bold text-slate-900">Edit Notification Template</h3>
                <p className="text-xs font-mono text-slate-400">{editingTemplate.eventType}</p>
              </div>
              <button onClick={() => setEditingTemplate(null)} className="text-slate-400 hover:text-slate-600">
                <XCircle className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveTemplateEdit} className="space-y-4 mt-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Title / Subject Template</label>
                <input
                  type="text"
                  value={editingTemplate.titleTemplate}
                  onChange={(e) => setEditingTemplate({ ...editingTemplate, titleTemplate: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">In-App & SMS Body Template</label>
                <textarea
                  rows={3}
                  value={editingTemplate.bodyTemplate}
                  onChange={(e) => setEditingTemplate({ ...editingTemplate, bodyTemplate: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Email Subject Template</label>
                <input
                  type="text"
                  value={editingTemplate.emailSubjectTemplate || ''}
                  onChange={(e) => setEditingTemplate({ ...editingTemplate, emailSubjectTemplate: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Email HTML Body Template</label>
                <textarea
                  rows={4}
                  value={editingTemplate.emailHtmlTemplate || ''}
                  onChange={(e) => setEditingTemplate({ ...editingTemplate, emailHtmlTemplate: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-mono"
                />
              </div>

              {/* Channel Checkboxes */}
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1.5">Enabled Delivery Channels</label>
                <div className="flex flex-wrap gap-4 text-xs text-slate-700">
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={editingTemplate.channels.inApp}
                      onChange={(e) =>
                        setEditingTemplate({
                          ...editingTemplate,
                          channels: { ...editingTemplate.channels, inApp: e.target.checked }
                        })
                      }
                      className="rounded text-indigo-600 focus:ring-indigo-500"
                    />
                    In-App
                  </label>

                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={editingTemplate.channels.email}
                      onChange={(e) =>
                        setEditingTemplate({
                          ...editingTemplate,
                          channels: { ...editingTemplate.channels, email: e.target.checked }
                        })
                      }
                      className="rounded text-indigo-600 focus:ring-indigo-500"
                    />
                    Email
                  </label>

                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={editingTemplate.channels.sms}
                      onChange={(e) =>
                        setEditingTemplate({
                          ...editingTemplate,
                          channels: { ...editingTemplate.channels, sms: e.target.checked }
                        })
                      }
                      className="rounded text-indigo-600 focus:ring-indigo-500"
                    />
                    SMS
                  </label>

                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={editingTemplate.channels.push}
                      onChange={(e) =>
                        setEditingTemplate({
                          ...editingTemplate,
                          channels: { ...editingTemplate.channels, push: e.target.checked }
                        })
                      }
                      className="rounded text-indigo-600 focus:ring-indigo-500"
                    />
                    Push
                  </label>
                </div>
              </div>

              {/* Allowed Variables List */}
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
                <span className="text-[11px] font-semibold text-slate-700 uppercase block mb-1.5">
                  Available Interpolation Variables:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {editingTemplate.allowedVariables.map((v) => (
                    <span
                      key={v}
                      className="px-2 py-0.5 bg-white border border-slate-200 rounded text-[11px] font-mono text-indigo-600 select-all"
                    >
                      {`{{${v}}}`}
                    </span>
                  ))}
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setEditingTemplate(null)}
                  className="px-4 py-2 border border-slate-200 text-sm font-medium rounded-lg text-slate-600 hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSaving}
                  className="px-5 py-2 bg-indigo-600 text-white text-sm font-medium rounded-lg hover:bg-indigo-700 disabled:opacity-50"
                >
                  {isSaving ? 'Saving...' : 'Save Template Changes'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: PREVIEW TEMPLATE */}
      {/* ========================================================================= */}
      {previewTemplate && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 shadow-xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-lg font-bold text-slate-900">Multi-Channel Render Preview</h3>
                <p className="text-xs text-slate-400">{previewTemplate.template.name}</p>
              </div>
              <button onClick={() => setPreviewTemplate(null)} className="text-slate-400 hover:text-slate-600">
                <XCircle className="w-5 h-5" />
              </button>
            </div>

            {/* In-App Notification Preview */}
            <div>
              <span className="text-xs font-semibold text-slate-700 uppercase tracking-wide block mb-1.5 flex items-center gap-1.5">
                <Bell className="w-3.5 h-3.5 text-indigo-600" /> In-App Notification Banner
              </span>
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl">
                <h4 className="font-semibold text-slate-900 text-sm">{previewTemplate.title}</h4>
                <p className="text-xs text-slate-600 mt-1 leading-relaxed">{previewTemplate.body}</p>
              </div>
            </div>

            {/* Email HTML Preview */}
            <div>
              <span className="text-xs font-semibold text-slate-700 uppercase tracking-wide block mb-1.5 flex items-center gap-1.5">
                <Mail className="w-3.5 h-3.5 text-blue-600" /> Email Subject & Body Preview
              </span>
              <div className="border border-slate-200 rounded-xl overflow-hidden">
                <div className="bg-slate-100 px-4 py-2 border-b border-slate-200 text-xs font-medium text-slate-700">
                  Subject: <span className="font-semibold text-slate-900">{previewTemplate.emailSubject}</span>
                </div>
                <div
                  className="p-4 bg-white text-xs text-slate-700 leading-relaxed"
                  dangerouslySetInnerHTML={{ __html: previewTemplate.emailHtml }}
                />
              </div>
            </div>

            {/* SMS Preview */}
            <div>
              <span className="text-xs font-semibold text-slate-700 uppercase tracking-wide block mb-1.5 flex items-center gap-1.5">
                <MessageSquare className="w-3.5 h-3.5 text-purple-600" /> SMS Text Preview
              </span>
              <div className="p-3 bg-purple-50/50 border border-purple-100 rounded-xl text-xs font-mono text-purple-950">
                {previewTemplate.sms}
              </div>
            </div>

            <div className="flex justify-end pt-3 border-t border-slate-100">
              <button
                onClick={() => setPreviewTemplate(null)}
                className="px-4 py-2 bg-slate-100 text-slate-700 text-sm font-medium rounded-lg hover:bg-slate-200"
              >
                Close Preview
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: LOG DETAILS & RETRY */}
      {/* ========================================================================= */}
      {selectedLog && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-2xl max-w-xl w-full max-h-[90vh] overflow-y-auto p-6 shadow-xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-lg font-bold text-slate-900">Communication Delivery Record</h3>
                <p className="text-xs font-mono text-slate-400">ID: {selectedLog.id}</p>
              </div>
              <button onClick={() => setSelectedLog(null)} className="text-slate-400 hover:text-slate-600">
                <XCircle className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs text-slate-700">
              <div className="grid grid-cols-2 gap-2 p-3 bg-slate-50 rounded-lg">
                <div>
                  <span className="text-slate-400 block">Recipient:</span>
                  <span className="font-semibold text-slate-900">{selectedLog.recipientName}</span>
                </div>
                <div>
                  <span className="text-slate-400 block">Role & Contact:</span>
                  <span className="font-medium text-slate-800">{selectedLog.recipientRole} ({selectedLog.recipientContact || 'N/A'})</span>
                </div>
                <div>
                  <span className="text-slate-400 block">Channel:</span>
                  <span className="font-medium text-slate-800">{selectedLog.channel}</span>
                </div>
                <div>
                  <span className="text-slate-400 block">Status:</span>
                  <span
                    className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-semibold uppercase ${
                      selectedLog.status === 'DELIVERED'
                        ? 'bg-emerald-100 text-emerald-800'
                        : selectedLog.status === 'SENT'
                        ? 'bg-blue-100 text-blue-800'
                        : 'bg-rose-100 text-rose-800'
                    }`}
                  >
                    {selectedLog.status}
                  </span>
                </div>
              </div>

              <div>
                <span className="text-slate-400 block mb-0.5">Deduplication Key:</span>
                <span className="font-mono text-[11px] text-slate-600 break-all p-2 bg-slate-50 rounded block border border-slate-100">
                  {selectedLog.dedupKey}
                </span>
              </div>

              <div>
                <span className="text-slate-400 block mb-0.5">Alert Header / Title:</span>
                <p className="font-semibold text-slate-900">{selectedLog.title}</p>
              </div>

              <div>
                <span className="text-slate-400 block mb-0.5">Dispatched Message:</span>
                <p className="p-3 bg-slate-50 border border-slate-100 rounded-lg leading-relaxed text-slate-800">
                  {selectedLog.message}
                </p>
              </div>

              {selectedLog.failureReason && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-rose-900">
                  <strong className="block text-[11px] uppercase tracking-wide text-rose-800 mb-1">
                    Failure / Gateway Note:
                  </strong>
                  {selectedLog.failureReason}
                </div>
              )}
            </div>

            <div className="flex justify-between items-center pt-4 border-t border-slate-100">
              <span className="text-xs text-slate-400">
                Created: {new Date(selectedLog.createdAt).toLocaleString()}
              </span>

              <div className="flex gap-2">
                {selectedLog.status === 'FAILED' && selectedLog.retryCount < selectedLog.maxRetries && (
                  <button
                    onClick={() => handleRetryLog(selectedLog.id)}
                    className="px-4 py-2 bg-indigo-600 text-white text-xs font-semibold rounded-lg hover:bg-indigo-700 flex items-center gap-1.5"
                  >
                    <RefreshCw className="w-3.5 h-3.5" /> Retry Delivery
                  </button>
                )}
                <button
                  onClick={() => setSelectedLog(null)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 text-xs font-semibold rounded-lg hover:bg-slate-200"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: CHANNEL TEST DISPATCH */}
      {/* ========================================================================= */}
      {testModalChannel && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-2xl max-w-md w-full p-6 shadow-xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-base font-bold text-slate-900">Run Gateway Test</h3>
                <p className="text-xs text-slate-400">Channel: {testModalChannel}</p>
              </div>
              <button onClick={() => setTestModalChannel(null)} className="text-slate-400 hover:text-slate-600">
                <XCircle className="w-5 h-5" />
              </button>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Target Recipient (Email / Phone / User)
              </label>
              <input
                type="text"
                placeholder={testModalChannel === 'EMAIL' ? 'test@sygmate-school.edu' : '+15551234567'}
                value={testRecipient}
                onChange={(e) => setTestRecipient(e.target.value)}
                className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm"
              />
              <span className="text-[11px] text-slate-400 mt-1 block">
                Leave blank to test using administrative system recipient.
              </span>
            </div>

            {testResult && (
              <div
                className={`p-3 rounded-lg text-xs leading-relaxed border ${
                  testResult.success
                    ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                    : 'bg-rose-50 border-rose-200 text-rose-800'
                }`}
              >
                <div className="font-semibold uppercase tracking-wide mb-1">
                  Status: {testResult.status}
                </div>
                {testResult.message}
              </div>
            )}

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setTestModalChannel(null)}
                className="px-4 py-2 border border-slate-200 text-xs font-medium rounded-lg text-slate-600 hover:bg-slate-50"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={isTestingProvider}
                onClick={handleRunTest}
                className="px-4 py-2 bg-indigo-600 text-white text-xs font-semibold rounded-lg hover:bg-indigo-700 disabled:opacity-50 flex items-center gap-1.5"
              >
                {isTestingProvider ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
                {isTestingProvider ? 'Testing Gateway...' : 'Execute Test'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
export default CommunicationManagementPage;
