import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  Activity,
  TrendingUp,
  CheckCircle2,
  XCircle,
  Clock,
  AlertTriangle,
  Download,
  Search,
  Filter,
  Calendar,
  ChevronLeft,
  ChevronRight,
  RefreshCw,
  Mail,
  MessageSquare,
  Send,
  Megaphone,
  Bell,
  ShieldAlert,
  Server,
  Check,
  Eye,
  Trash2,
  HelpCircle,
  Layers,
  Cpu,
  Info,
  Smartphone,
  MessageCircle,
  ArrowUpRight,
  SlidersHorizontal,
  FileSpreadsheet,
  FileJson
} from 'lucide-react';
import { api } from '../../../services/api.js';
import {
  CommunicationAnalyticsOverview,
  CommunicationAnalyticsFilterParams,
  CommunicationDatePreset,
  DeliveryReportItem,
  DeliveryReportQuery,
  ExportReportType,
  ExportFormat,
  NotificationChannel,
  CommunicationDeliveryStatus
} from '../../../types/index.js';

interface CommunicationAnalyticsTabProps {
  onNavigateToTab?: (tab: string) => void;
}

export const CommunicationAnalyticsTab: React.FC<CommunicationAnalyticsTabProps> = ({ onNavigateToTab }) => {
  // Filters for Analytics Overview
  const [datePreset, setDatePreset] = useState<CommunicationDatePreset>('LAST_30_DAYS');
  const [customStartDate, setCustomStartDate] = useState<string>('');
  const [customEndDate, setCustomEndDate] = useState<string>('');
  const [channelFilter, setChannelFilter] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [roleFilter, setRoleFilter] = useState<string>('ALL');

  // Overview Data State
  const [overview, setOverview] = useState<CommunicationAnalyticsOverview | null>(null);
  const [isLoadingOverview, setIsLoadingOverview] = useState<boolean>(true);
  const [overviewError, setOverviewError] = useState<string | null>(null);

  // Delivery Ledger State (Paginated)
  const [ledgerData, setLedgerData] = useState<DeliveryReportItem[]>([]);
  const [ledgerTotal, setLedgerTotal] = useState<number>(0);
  const [ledgerPage, setLedgerPage] = useState<number>(1);
  const [ledgerLimit, setLedgerLimit] = useState<number>(15);
  const [ledgerTotalPages, setLedgerTotalPages] = useState<number>(1);
  const [ledgerSearch, setLedgerSearch] = useState<string>('');
  const [ledgerStats, setLedgerStats] = useState<{ totalDelivered: number; totalFailed: number; totalPending: number }>({
    totalDelivered: 0,
    totalFailed: 0,
    totalPending: 0
  });
  const [isLoadingLedger, setIsLoadingLedger] = useState<boolean>(false);

  // Failure Detail Modal State
  const [selectedFailureCategory, setSelectedFailureCategory] = useState<string | null>(null);

  // Cancellation State
  const [cancellingId, setCancellingId] = useState<string | null>(null);
  const [cancelModalItem, setCancelModalItem] = useState<{ id: string; type: 'CAMPAIGN' | 'ANNOUNCEMENT'; title: string } | null>(null);

  // Notification / Toast
  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  const showToast = (text: string, type: 'success' | 'error' = 'success') => {
    setToastMessage({ text, type });
    setTimeout(() => setToastMessage(null), 4000);
  };

  // Fetch Overview Data
  const loadOverview = useCallback(async () => {
    setIsLoadingOverview(true);
    setOverviewError(null);
    try {
      const params: CommunicationAnalyticsFilterParams = {
        datePreset,
        startDate: datePreset === 'CUSTOM' ? customStartDate : undefined,
        endDate: datePreset === 'CUSTOM' ? customEndDate : undefined,
        channel: channelFilter !== 'ALL' ? (channelFilter as NotificationChannel) : undefined,
        status: statusFilter !== 'ALL' ? (statusFilter as CommunicationDeliveryStatus) : undefined,
        recipientRole: roleFilter !== 'ALL' ? roleFilter : undefined
      };

      const res = await api.communication.analytics.getOverview(params);
      if (res.success && res.data) {
        setOverview(res.data);
      } else {
        setOverviewError('Failed to load communication analytics.');
      }
    } catch (err: any) {
      setOverviewError(err.message || 'An error occurred while loading communication analytics.');
    } finally {
      setIsLoadingOverview(false);
    }
  }, [datePreset, customStartDate, customEndDate, channelFilter, statusFilter, roleFilter]);

  // Fetch Delivery Ledger Data
  const loadDeliveryLedger = useCallback(async () => {
    setIsLoadingLedger(true);
    try {
      const query: DeliveryReportQuery = {
        page: ledgerPage,
        limit: ledgerLimit,
        search: ledgerSearch.trim() || undefined,
        channel: channelFilter !== 'ALL' ? channelFilter : undefined,
        status: statusFilter !== 'ALL' ? statusFilter : undefined,
        recipientRole: roleFilter !== 'ALL' ? roleFilter : undefined,
        startDate: datePreset === 'CUSTOM' ? customStartDate : undefined,
        endDate: datePreset === 'CUSTOM' ? customEndDate : undefined
      };

      const res = await api.communication.analytics.getDeliveryReport(query);
      if (res.success && res.data) {
        setLedgerData(res.data);
        setLedgerTotal(res.total);
        setLedgerTotalPages(res.totalPages);
        if (res.stats) {
          setLedgerStats(res.stats);
        }
      }
    } catch (err: any) {
      console.error('Error fetching delivery reports:', err);
    } finally {
      setIsLoadingLedger(false);
    }
  }, [ledgerPage, ledgerLimit, ledgerSearch, channelFilter, statusFilter, roleFilter, datePreset, customStartDate, customEndDate]);

  // Initial and trigger load
  useEffect(() => {
    loadOverview();
  }, [loadOverview]);

  useEffect(() => {
    loadDeliveryLedger();
  }, [loadDeliveryLedger]);

  // Handle Export Trigger
  const handleExport = (type: ExportReportType, format: ExportFormat = 'csv') => {
    try {
      const filters = {
        datePreset,
        startDate: datePreset === 'CUSTOM' ? customStartDate : undefined,
        endDate: datePreset === 'CUSTOM' ? customEndDate : undefined,
        channel: channelFilter !== 'ALL' ? channelFilter : undefined,
        status: statusFilter !== 'ALL' ? statusFilter : undefined,
        recipientRole: roleFilter !== 'ALL' ? roleFilter : undefined,
        search: ledgerSearch.trim() || undefined
      };

      const exportUrl = api.communication.analytics.exportReportUrl(type, format, filters);
      window.open(exportUrl, '_blank');
      showToast(`Export initiated for ${type} in ${format.toUpperCase()} format.`);
    } catch (err: any) {
      showToast(err.message || 'Export failed.', 'error');
    }
  };

  // Handle Cancel Scheduled Item
  const handleConfirmCancel = async () => {
    if (!cancelModalItem) return;
    setCancellingId(cancelModalItem.id);
    try {
      const res = await api.communication.analytics.cancelScheduled(cancelModalItem.id, cancelModalItem.type);
      if (res.success) {
        showToast(res.message || 'Scheduled item cancelled successfully.');
        setCancelModalItem(null);
        loadOverview();
      } else {
        showToast(res.message || 'Failed to cancel scheduled item.', 'error');
      }
    } catch (err: any) {
      showToast(err.message || 'Error cancelling scheduled item.', 'error');
    } finally {
      setCancellingId(null);
    }
  };

  const selectedCategoryExamples = useMemo(() => {
    if (!overview || !selectedFailureCategory) return null;
    return overview.failureAnalysis.find((f) => f.category === selectedFailureCategory);
  }, [overview, selectedFailureCategory]);

  return (
    <div className="space-y-6" id="communication-analytics-tab">
      {/* Toast Banner */}
      {toastMessage && (
        <div
          className={`p-4 rounded-xl text-sm flex items-center justify-between shadow-sm border transition-all ${
            toastMessage.type === 'error'
              ? 'bg-rose-50 border-rose-200 text-rose-800'
              : 'bg-emerald-50 border-emerald-200 text-emerald-800'
          }`}
        >
          <div className="flex items-center gap-2.5">
            {toastMessage.type === 'error' ? (
              <AlertTriangle className="w-5 h-5 text-rose-600 flex-shrink-0" />
            ) : (
              <CheckCircle2 className="w-5 h-5 text-emerald-600 flex-shrink-0" />
            )}
            <span className="font-medium">{toastMessage.text}</span>
          </div>
          <button
            onClick={() => setToastMessage(null)}
            className="text-xs font-semibold px-2 py-1 rounded hover:bg-black/5"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Control Bar: Date Presets & Multi-Dimensional Filters */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div>
            <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center gap-2">
              <Activity className="w-5 h-5 text-indigo-600" />
              Communication Analytics & Delivery Ledger
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Comprehensive telemetry, cross-channel verification, queue benchmarks, and audit trail.
            </p>
          </div>

          {/* Action Tools: Refresh & Export */}
          <div className="flex items-center flex-wrap gap-2.5">
            <button
              onClick={() => {
                loadOverview();
                loadDeliveryLedger();
              }}
              disabled={isLoadingOverview || isLoadingLedger}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 border border-slate-200 text-xs font-semibold rounded-lg text-slate-700 bg-white hover:bg-slate-50 transition-colors shadow-xs"
              id="analytics-refresh-button"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isLoadingOverview || isLoadingLedger ? 'animate-spin text-indigo-600' : ''}`} />
              Refresh
            </button>

            {/* Export Delivery Ledger CSV */}
            <button
              onClick={() => handleExport('delivery', 'csv')}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-indigo-50 border border-indigo-200 text-indigo-700 hover:bg-indigo-100 text-xs font-semibold rounded-lg transition-colors shadow-xs"
              title="Export filtered delivery log records as CSV"
              id="analytics-export-csv-btn"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-indigo-600" />
              Export Ledger (CSV)
            </button>

            {/* Export Summary JSON */}
            <button
              onClick={() => handleExport('summary', 'json')}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 border border-slate-200 text-slate-700 hover:bg-slate-200 text-xs font-semibold rounded-lg transition-colors shadow-xs"
              title="Export complete metric snapshot as JSON"
              id="analytics-export-json-btn"
            >
              <FileJson className="w-3.5 h-3.5 text-slate-600" />
              Summary (JSON)
            </button>
          </div>
        </div>

        {/* Filter Controls Row */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-3 pt-3 border-t border-slate-100 text-xs">
          {/* Date Preset */}
          <div>
            <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
              Time Range
            </label>
            <select
              value={datePreset}
              onChange={(e) => setDatePreset(e.target.value as CommunicationDatePreset)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 font-medium focus:outline-none focus:ring-1 focus:ring-indigo-500"
              id="analytics-date-preset-select"
            >
              <option value="TODAY">Today</option>
              <option value="YESTERDAY">Yesterday</option>
              <option value="LAST_7_DAYS">Last 7 Days</option>
              <option value="LAST_30_DAYS">Last 30 Days</option>
              <option value="CURRENT_MONTH">Current Month</option>
              <option value="PREVIOUS_MONTH">Previous Month</option>
              <option value="CUSTOM">Custom Date Range</option>
            </select>
          </div>

          {/* Custom Date Inputs if CUSTOM */}
          {datePreset === 'CUSTOM' && (
            <div className="flex gap-1.5 sm:col-span-2">
              <div className="flex-1">
                <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                  Start Date
                </label>
                <input
                  type="date"
                  value={customStartDate}
                  onChange={(e) => setCustomStartDate(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
              </div>
              <div className="flex-1">
                <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
                  End Date
                </label>
                <input
                  type="date"
                  value={customEndDate}
                  onChange={(e) => setCustomEndDate(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                />
              </div>
            </div>
          )}

          {/* Channel Filter */}
          <div>
            <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
              Channel
            </label>
            <select
              value={channelFilter}
              onChange={(e) => setChannelFilter(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 font-medium focus:outline-none focus:ring-1 focus:ring-indigo-500"
              id="analytics-channel-select"
            >
              <option value="ALL">All Channels</option>
              <option value="IN_APP">In-App Notification</option>
              <option value="EMAIL">Email Gateway</option>
              <option value="SMS">SMS Gateway</option>
              <option value="PUSH">Push Notifications</option>
            </select>
          </div>

          {/* Delivery Status Filter */}
          <div>
            <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
              Status
            </label>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 font-medium focus:outline-none focus:ring-1 focus:ring-indigo-500"
              id="analytics-status-select"
            >
              <option value="ALL">All Statuses</option>
              <option value="DELIVERED">Delivered</option>
              <option value="FAILED">Failed</option>
              <option value="PENDING">Pending / Queued</option>
              <option value="PROCESSING">Processing</option>
              <option value="RETRYING">Retrying</option>
            </select>
          </div>

          {/* Recipient Role Filter */}
          <div>
            <label className="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1">
              Audience Role
            </label>
            <select
              value={roleFilter}
              onChange={(e) => setRoleFilter(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 font-medium focus:outline-none focus:ring-1 focus:ring-indigo-500"
              id="analytics-role-select"
            >
              <option value="ALL">All Roles</option>
              <option value="STUDENT">Student</option>
              <option value="GUARDIAN">Guardian / Parent</option>
              <option value="TEACHER">Teacher</option>
              <option value="STAFF">Staff</option>
              <option value="SUPER_ADMIN">Administrator</option>
            </select>
          </div>
        </div>
      </div>

      {/* Loading & Error State */}
      {isLoadingOverview && !overview && (
        <div className="bg-white border border-slate-200 rounded-xl p-12 text-center shadow-sm">
          <RefreshCw className="w-8 h-8 text-indigo-600 animate-spin mx-auto mb-3" />
          <p className="text-sm font-semibold text-slate-700">Calculating communication metrics...</p>
          <p className="text-xs text-slate-400 mt-1">Aggregating multi-channel logs, campaign queues, and gateway latency.</p>
        </div>
      )}

      {overviewError && (
        <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-sm flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-rose-600" />
            <span>{overviewError}</span>
          </div>
          <button
            onClick={loadOverview}
            className="text-xs font-semibold px-2 py-1 bg-white border border-rose-300 rounded text-rose-700 hover:bg-rose-100"
          >
            Retry
          </button>
        </div>
      )}

      {overview && (
        <>
          {/* Executive Summary Metrics Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Metric 1: Total Dispatch & Overall Delivery Rate */}
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm relative overflow-hidden">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                  Total Dispatches
                </span>
                <div className="p-2 bg-indigo-50 text-indigo-600 rounded-lg">
                  <Send className="w-4 h-4" />
                </div>
              </div>
              <div className="mt-3 flex items-baseline gap-2">
                <span className="text-2xl font-extrabold text-slate-900 tracking-tight">
                  {overview.summary.totalRecipients.toLocaleString()}
                </span>
                <span className="text-xs font-semibold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">
                  {overview.summary.overallDeliveryRate}% delivered
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-2 flex items-center justify-between">
                <span>{overview.summary.successfulDeliveries} successful</span>
                <span className="text-rose-600 font-medium">{overview.summary.failedDeliveries} failed</span>
              </p>
            </div>

            {/* Metric 2: School Announcements & Read Engagement */}
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                  Announcements
                </span>
                <div className="p-2 bg-amber-50 text-amber-600 rounded-lg">
                  <Megaphone className="w-4 h-4" />
                </div>
              </div>
              <div className="mt-3 flex items-baseline gap-2">
                <span className="text-2xl font-extrabold text-slate-900 tracking-tight">
                  {overview.announcements.publishedCount}
                </span>
                <span className="text-xs text-slate-500">
                  of {overview.announcements.totalAnnouncements} total
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-2 flex items-center justify-between">
                <span>{overview.announcements.totalReadReceipts} receipts recorded</span>
                <span className="text-amber-600 font-medium">{overview.announcements.averageReadRate}% read rate</span>
              </p>
            </div>

            {/* Metric 3: Internal Messaging & Conversations */}
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                  Internal Messages
                </span>
                <div className="p-2 bg-sky-50 text-sky-600 rounded-lg">
                  <MessageSquare className="w-4 h-4" />
                </div>
              </div>
              <div className="mt-3 flex items-baseline gap-2">
                <span className="text-2xl font-extrabold text-slate-900 tracking-tight">
                  {overview.messaging.totalMessages.toLocaleString()}
                </span>
                <span className="text-xs text-slate-500">
                  in {overview.messaging.totalConversations} threads
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-2 flex items-center justify-between">
                <span>{overview.messaging.parentTeacherVolume} parent-teacher</span>
                <span className="text-sky-600 font-medium">{overview.messaging.staffInternalVolume} staff internal</span>
              </p>
            </div>

            {/* Metric 4: Queue Health & Latency SLA */}
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                  Processing SLA
                </span>
                <div className="p-2 bg-emerald-50 text-emerald-600 rounded-lg">
                  <Cpu className="w-4 h-4" />
                </div>
              </div>
              <div className="mt-3 flex items-baseline gap-2">
                <span className="text-2xl font-extrabold text-slate-900 tracking-tight">
                  {overview.performance.avgDeliveryProcessingMs}
                  <span className="text-xs font-normal text-slate-500 ml-1">ms</span>
                </span>
                <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded">
                  Healthy SLA
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-2 flex items-center justify-between">
                <span>Queue wait: {overview.performance.avgQueueWaitMs}ms</span>
                <span className="text-slate-600 font-medium">Failure: {overview.performance.deliveryFailureRate}%</span>
              </p>
            </div>
          </div>

          {/* Honest Channel Analytics Cards */}
          <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-sm font-bold text-slate-900 tracking-tight flex items-center gap-2">
                  <SlidersHorizontal className="w-4 h-4 text-indigo-600" />
                  Channel Performance & Read Verification Matrix
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Direct audit of delivery rates and read acknowledgment by transport mechanism.
                </p>
              </div>

              {/* Informative transparency badge */}
              <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-amber-50 border border-amber-200 rounded-lg text-amber-800 text-[11px]">
                <Info className="w-3.5 h-3.5 text-amber-600 flex-shrink-0" />
                <span>Read receipts are tracked natively for In-App only; external gateways report verified delivery ACK.</span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 pt-1">
              {/* IN_APP CHANNEL */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                      <Bell className="w-4 h-4 text-indigo-600" />
                      In-App Notifications
                    </span>
                    <span className="text-[10px] font-semibold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full">
                      Native Engine
                    </span>
                  </div>
                  <div className="space-y-1.5 text-xs text-slate-600 mt-3">
                    <div className="flex justify-between">
                      <span className="text-slate-500">Dispatched:</span>
                      <span className="font-semibold text-slate-800">{overview.channelAnalytics.IN_APP.sent}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Delivered:</span>
                      <span className="font-semibold text-emerald-700">{overview.channelAnalytics.IN_APP.delivered}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Read Receipts:</span>
                      <span className="font-semibold text-indigo-700">
                        {overview.channelAnalytics.IN_APP.read ?? 0}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Delivery Rate:</span>
                      <span className="font-bold text-slate-900">{overview.channelAnalytics.IN_APP.deliveryRate}%</span>
                    </div>
                  </div>
                </div>
                <div className="mt-3 pt-2.5 border-t border-slate-200 text-[11px] text-slate-500">
                  {overview.channelAnalytics.IN_APP.statusNote}
                </div>
              </div>

              {/* EMAIL CHANNEL */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                      <Mail className="w-4 h-4 text-emerald-600" />
                      Email Gateway
                    </span>
                    <span
                      className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                        overview.channelAnalytics.EMAIL.providerVerified
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {overview.channelAnalytics.EMAIL.providerVerified ? 'Active Gateway' : 'Sandbox Mode'}
                    </span>
                  </div>
                  <div className="space-y-1.5 text-xs text-slate-600 mt-3">
                    <div className="flex justify-between">
                      <span className="text-slate-500">Dispatched:</span>
                      <span className="font-semibold text-slate-800">{overview.channelAnalytics.EMAIL.sent}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Delivered ACK:</span>
                      <span className="font-semibold text-emerald-700">{overview.channelAnalytics.EMAIL.delivered}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Read Receipts:</span>
                      <span className="font-normal text-slate-400 italic">Not Tracked (No Pixels)</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Delivery Rate:</span>
                      <span className="font-bold text-slate-900">{overview.channelAnalytics.EMAIL.deliveryRate}%</span>
                    </div>
                  </div>
                </div>
                <div className="mt-3 pt-2.5 border-t border-slate-200 text-[11px] text-slate-500">
                  {overview.channelAnalytics.EMAIL.statusNote}
                </div>
              </div>

              {/* SMS CHANNEL */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                      <MessageCircle className="w-4 h-4 text-sky-600" />
                      SMS Gateway
                    </span>
                    <span
                      className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                        overview.channelAnalytics.SMS.providerVerified
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {overview.channelAnalytics.SMS.providerVerified ? 'Active Gateway' : 'Sandbox Mode'}
                    </span>
                  </div>
                  <div className="space-y-1.5 text-xs text-slate-600 mt-3">
                    <div className="flex justify-between">
                      <span className="text-slate-500">Dispatched:</span>
                      <span className="font-semibold text-slate-800">{overview.channelAnalytics.SMS.sent}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Carrier Delivered:</span>
                      <span className="font-semibold text-emerald-700">{overview.channelAnalytics.SMS.delivered}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Read Receipts:</span>
                      <span className="font-normal text-slate-400 italic">Unsupported (SMS)</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Delivery Rate:</span>
                      <span className="font-bold text-slate-900">{overview.channelAnalytics.SMS.deliveryRate}%</span>
                    </div>
                  </div>
                </div>
                <div className="mt-3 pt-2.5 border-t border-slate-200 text-[11px] text-slate-500">
                  {overview.channelAnalytics.SMS.statusNote}
                </div>
              </div>

              {/* PUSH NOTIFICATIONS */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                      <Smartphone className="w-4 h-4 text-purple-600" />
                      Push Notifications
                    </span>
                    <span
                      className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                        overview.channelAnalytics.PUSH.providerVerified
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {overview.channelAnalytics.PUSH.providerVerified ? 'FCM Active' : 'Sandbox Mode'}
                    </span>
                  </div>
                  <div className="space-y-1.5 text-xs text-slate-600 mt-3">
                    <div className="flex justify-between">
                      <span className="text-slate-500">Dispatched:</span>
                      <span className="font-semibold text-slate-800">{overview.channelAnalytics.PUSH.sent}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Handled:</span>
                      <span className="font-semibold text-emerald-700">{overview.channelAnalytics.PUSH.delivered}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Read Receipts:</span>
                      <span className="font-normal text-slate-400 italic">Device Foreground Only</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Delivery Rate:</span>
                      <span className="font-bold text-slate-900">{overview.channelAnalytics.PUSH.deliveryRate}%</span>
                    </div>
                  </div>
                </div>
                <div className="mt-3 pt-2.5 border-t border-slate-200 text-[11px] text-slate-500">
                  {overview.channelAnalytics.PUSH.statusNote}
                </div>
              </div>
            </div>
          </div>

          {/* Failure Categorization & Diagnostic Drill-down */}
          <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-sm font-bold text-slate-900 tracking-tight flex items-center gap-2">
                  <ShieldAlert className="w-4 h-4 text-rose-600" />
                  Delivery Failure Diagnostic & Root-Cause Analysis
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Automatic taxonomy grouping of failed dispatches with error details and samples.
                </p>
              </div>
              <button
                onClick={() => handleExport('failures', 'csv')}
                className="inline-flex items-center gap-1 text-xs font-semibold text-rose-700 bg-rose-50 hover:bg-rose-100 px-3 py-1.5 rounded-lg border border-rose-200 transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                Export Failure Audit (CSV)
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 pt-1">
              {overview.failureAnalysis.map((item) => (
                <div
                  key={item.category}
                  onClick={() => setSelectedFailureCategory(item.category)}
                  className={`border rounded-xl p-4 cursor-pointer transition-all hover:border-indigo-300 hover:shadow-xs ${
                    selectedFailureCategory === item.category
                      ? 'bg-indigo-50/50 border-indigo-400 ring-1 ring-indigo-400'
                      : 'bg-slate-50 border-slate-200'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <span className="text-xs font-bold text-slate-800 block">{item.label}</span>
                      <span className="text-[11px] text-slate-500 mt-0.5 block">
                        {item.count} occurrences ({item.percentage}% of failures)
                      </span>
                    </div>
                    <span
                      className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                        item.count > 0 ? 'bg-rose-100 text-rose-800' : 'bg-slate-200 text-slate-600'
                      }`}
                    >
                      {item.count}
                    </span>
                  </div>

                  {Array.isArray(item.recentExamples) && item.recentExamples.length > 0 && (
                    <div className="mt-3 pt-2 border-t border-slate-200/80 text-[11px] text-slate-600">
                      <span className="font-semibold text-slate-700">Latest Reason:</span>{' '}
                      <span className="text-slate-500 truncate block">
                        {item.recentExamples?.[0]?.reason || 'N/A'}
                      </span>
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* Drill-down modal or expanded card for selected category */}
            {selectedCategoryExamples && (
              <div className="mt-4 p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
                <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-rose-600" />
                    <span className="text-xs font-bold text-slate-800">
                      Sample Incidents for: {selectedCategoryExamples.label}
                    </span>
                  </div>
                  <button
                    onClick={() => setSelectedFailureCategory(null)}
                    className="text-xs text-slate-500 hover:text-slate-700 font-semibold"
                  >
                    Close Preview
                  </button>
                </div>

                {(selectedCategoryExamples?.recentExamples?.length || 0) === 0 ? (
                  <p className="text-xs text-slate-500 italic py-2">No failure incidents recorded in this category for the selected time window.</p>
                ) : (
                  <div className="space-y-2">
                    {selectedCategoryExamples.recentExamples.map((ex, idx) => (
                      <div key={idx} className="bg-white border border-slate-200 rounded-lg p-3 text-xs flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-slate-900">{ex.recipientName}</span>
                            <span className="px-2 py-0.5 bg-slate-100 text-slate-700 rounded text-[10px] font-semibold">
                              {ex.channel}
                            </span>
                            <span className="text-[11px] text-slate-400">
                              {new Date(ex.timestamp).toLocaleString()}
                            </span>
                          </div>
                          <p className="text-rose-700 font-mono text-[11px] mt-1 bg-rose-50 px-2 py-1 rounded border border-rose-100 inline-block">
                            {ex.reason}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Upcoming Scheduled Communications Monitor */}
          <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-sm font-bold text-slate-900 tracking-tight flex items-center gap-2">
                  <Clock className="w-4 h-4 text-amber-600" />
                  Scheduled Communications & Circular Dispatch Monitor
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Automated background cron evaluates pending dispatches every 60 seconds.
                </p>
              </div>
              <span className="text-xs font-semibold px-2.5 py-1 bg-amber-50 text-amber-800 rounded-full border border-amber-200">
                {overview?.scheduledItems?.length || 0} Scheduled
              </span>
            </div>

            {(overview?.scheduledItems?.length || 0) === 0 ? (
              <div className="p-8 text-center text-slate-500 text-xs border border-dashed border-slate-200 rounded-xl">
                <CheckCircle2 className="w-6 h-6 text-emerald-500 mx-auto mb-2" />
                No communications currently queued for future schedule. All messages and campaigns are in sync.
              </div>
            ) : (
              <div className="overflow-x-auto border border-slate-200 rounded-xl">
                <table className="w-full text-left text-xs text-slate-700">
                  <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase text-[10px] font-bold tracking-wider">
                    <tr>
                      <th className="px-4 py-3">Type</th>
                      <th className="px-4 py-3">Title / Campaign</th>
                      <th className="px-4 py-3">Target Audience</th>
                      <th className="px-4 py-3">Scheduled For</th>
                      <th className="px-4 py-3">Author</th>
                      <th className="px-4 py-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {overview.scheduledItems.map((item) => (
                      <tr key={item.id} className="hover:bg-slate-50/50">
                        <td className="px-4 py-3">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              item.type === 'CAMPAIGN'
                                ? 'bg-indigo-100 text-indigo-800'
                                : 'bg-amber-100 text-amber-800'
                            }`}
                          >
                            {item.type}
                          </span>
                        </td>
                        <td className="px-4 py-3 font-semibold text-slate-900">{item.title}</td>
                        <td className="px-4 py-3 text-slate-600">{item.audience}</td>
                        <td className="px-4 py-3 text-slate-600 font-medium">
                          {new Date(item.scheduledAt).toLocaleString()}
                        </td>
                        <td className="px-4 py-3 text-slate-500">{item.createdByName}</td>
                        <td className="px-4 py-3 text-right">
                          <button
                            onClick={() =>
                              setCancelModalItem({ id: item.id, type: item.type, title: item.title })
                            }
                            className="inline-flex items-center gap-1 text-xs text-rose-600 hover:text-rose-800 font-semibold px-2 py-1 rounded hover:bg-rose-50 border border-transparent hover:border-rose-200 transition-colors"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            Cancel
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </>
      )}

      {/* Interactive Delivery Ledger (Paginated Ledger with Privacy Masking) */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm space-y-4" id="delivery-ledger-section">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 border-b border-slate-100 pb-3">
          <div>
            <h3 className="text-sm font-bold text-slate-900 tracking-tight flex items-center gap-2">
              <FileSpreadsheet className="w-4 h-4 text-indigo-600" />
              Delivery Ledger & Communication Audit Trail
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Authoritative dispatch records with masked contact info (FERPA/GDPR compliance).
            </p>
          </div>

          <div className="flex items-center gap-2">
            {/* Search Input */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={ledgerSearch}
                onChange={(e) => {
                  setLedgerSearch(e.target.value);
                  setLedgerPage(1);
                }}
                placeholder="Search recipient, title..."
                className="pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-indigo-500 w-56"
              />
            </div>

            {/* Limit Selector */}
            <select
              value={ledgerLimit}
              onChange={(e) => {
                setLedgerLimit(Number(e.target.value));
                setLedgerPage(1);
              }}
              className="bg-slate-50 border border-slate-200 rounded-lg px-2 py-1.5 text-xs text-slate-700 focus:outline-none"
            >
              <option value={10}>10 / page</option>
              <option value={15}>15 / page</option>
              <option value={25}>25 / page</option>
              <option value={50}>50 / page</option>
            </select>
          </div>
        </div>

        {/* Ledger Table */}
        <div className="overflow-x-auto border border-slate-200 rounded-xl">
          <table className="w-full text-left text-xs text-slate-700">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase text-[10px] font-bold tracking-wider">
              <tr>
                <th className="px-4 py-3">Queued At</th>
                <th className="px-4 py-3">Title / Event</th>
                <th className="px-4 py-3">Recipient</th>
                <th className="px-4 py-3">Masked Contact</th>
                <th className="px-4 py-3">Channel</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3">Delivery Latency</th>
                <th className="px-4 py-3 text-right">Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {isLoadingLedger ? (
                <tr>
                  <td colSpan={8} className="px-4 py-8 text-center text-slate-500">
                    <RefreshCw className="w-5 h-5 text-indigo-600 animate-spin mx-auto mb-2" />
                    Loading delivery ledger records...
                  </td>
                </tr>
              ) : ledgerData.length === 0 ? (
                <tr>
                  <td colSpan={8} className="px-4 py-8 text-center text-slate-500">
                    No delivery records match the specified filters.
                  </td>
                </tr>
              ) : (
                ledgerData.map((item) => {
                  let latencyStr = '—';
                  if (item.sentAt && item.deliveredAt) {
                    const diffMs = new Date(item.deliveredAt).getTime() - new Date(item.sentAt).getTime();
                    latencyStr = `${Math.max(1, Math.round(diffMs))}ms`;
                  }

                  return (
                    <tr key={item.id} className="hover:bg-slate-50/60 transition-colors">
                      <td className="px-4 py-3 text-slate-500 whitespace-nowrap">
                        {new Date(item.createdAt).toLocaleString(undefined, {
                          month: 'short',
                          day: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </td>
                      <td className="px-4 py-3">
                        <span className="font-semibold text-slate-900 block max-w-xs truncate" title={item.title}>
                          {item.title}
                        </span>
                        <span className="text-[10px] text-slate-400 font-mono block">
                          {item.eventType}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <span className="font-medium text-slate-800 block">{item.recipientName}</span>
                        <span className="inline-block px-1.5 py-0.5 bg-slate-100 text-slate-600 rounded text-[10px] font-semibold mt-0.5">
                          {item.recipientRole}
                        </span>
                      </td>
                      <td className="px-4 py-3 font-mono text-[11px] text-slate-600">
                        {item.recipientContactMasked}
                      </td>
                      <td className="px-4 py-3">
                        <span
                          className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold ${
                            item.channel === 'IN_APP'
                              ? 'bg-indigo-100 text-indigo-800'
                              : item.channel === 'EMAIL'
                              ? 'bg-emerald-100 text-emerald-800'
                              : item.channel === 'SMS'
                              ? 'bg-sky-100 text-sky-800'
                              : 'bg-purple-100 text-purple-800'
                          }`}
                        >
                          {item.channel}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <span
                          className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            item.status === 'DELIVERED'
                              ? 'bg-emerald-100 text-emerald-800'
                              : item.status === 'FAILED'
                              ? 'bg-rose-100 text-rose-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {item.status === 'DELIVERED' && <CheckCircle2 className="w-3 h-3" />}
                          {item.status === 'FAILED' && <XCircle className="w-3 h-3" />}
                          {item.status !== 'DELIVERED' && item.status !== 'FAILED' && <Clock className="w-3 h-3" />}
                          {item.status}
                        </span>
                      </td>
                      <td className="px-4 py-3 font-mono text-[11px] text-slate-500 whitespace-nowrap">
                        {latencyStr}
                      </td>
                      <td className="px-4 py-3 text-right">
                        {item.failureReason ? (
                          <span
                            className="text-[11px] text-rose-600 font-mono bg-rose-50 px-2 py-0.5 rounded border border-rose-200 inline-block max-w-[160px] truncate"
                            title={item.failureReason}
                          >
                            {item.failureReason}
                          </span>
                        ) : (
                          <span className="text-[11px] text-slate-400">Normal</span>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Ledger Pagination Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 text-xs text-slate-600 pt-2">
          <div>
            Showing <span className="font-bold text-slate-800">{ledgerData.length}</span> of{' '}
            <span className="font-bold text-slate-800">{ledgerTotal}</span> records (Page{' '}
            <span className="font-bold text-slate-800">{ledgerPage}</span> of {ledgerTotalPages})
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setLedgerPage((p) => Math.max(1, p - 1))}
              disabled={ledgerPage <= 1 || isLoadingLedger}
              className="inline-flex items-center gap-1 px-3 py-1.5 border border-slate-200 rounded-lg bg-white hover:bg-slate-50 disabled:opacity-50 disabled:cursor-not-allowed text-slate-700 font-medium transition-colors"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
              Previous
            </button>
            <button
              onClick={() => setLedgerPage((p) => Math.min(ledgerTotalPages, p + 1))}
              disabled={ledgerPage >= ledgerTotalPages || isLoadingLedger}
              className="inline-flex items-center gap-1 px-3 py-1.5 border border-slate-200 rounded-lg bg-white hover:bg-slate-50 disabled:opacity-50 disabled:cursor-not-allowed text-slate-700 font-medium transition-colors"
            >
              Next
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Confirmation Modal for Cancelling Scheduled Communication */}
      {cancelModalItem && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-md w-full p-6 shadow-xl border border-slate-200 space-y-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-rose-50 text-rose-600 rounded-xl">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">Cancel Scheduled Communication</h3>
                <p className="text-xs text-slate-500 mt-0.5">This action will prevent future dispatch.</p>
              </div>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed bg-slate-50 p-3 rounded-lg border border-slate-200">
              Are you sure you want to cancel the scheduled {cancelModalItem.type.toLowerCase()}{' '}
              <strong className="text-slate-900">"{cancelModalItem.title}"</strong>? Once cancelled, it will not be executed by the background scheduler.
            </p>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setCancelModalItem(null)}
                disabled={!!cancellingId}
                className="px-4 py-2 border border-slate-200 text-xs font-semibold rounded-lg text-slate-700 bg-white hover:bg-slate-50"
              >
                Never mind
              </button>
              <button
                type="button"
                onClick={handleConfirmCancel}
                disabled={!!cancellingId}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold rounded-lg shadow-sm flex items-center gap-1.5"
              >
                {cancellingId ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    Cancelling...
                  </>
                ) : (
                  <>
                    <Trash2 className="w-3.5 h-3.5" />
                    Confirm Cancellation
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
