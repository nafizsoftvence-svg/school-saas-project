import React, { useState, useEffect, useMemo } from 'react';
import {
  Megaphone,
  Plus,
  Search,
  Filter,
  Calendar,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Pin,
  Trash2,
  Edit3,
  Eye,
  Archive,
  RefreshCw,
  Sparkles,
  Users,
  Bell,
  Mail,
  MessageSquare,
  Smartphone,
  Paperclip,
  UploadCloud,
  FileText,
  X,
  Radio,
  PinOff,
  ExternalLink,
  ChevronRight,
  ShieldAlert,
  Send,
  UserCheck,
  Info
} from 'lucide-react';
import { api } from '../../../services/api.js';
import { useAuth } from '../../../context/AuthContext.js';
import { useToast } from '../../../context/ToastContext.js';
import {
  ClassAnnouncement,
  AnnouncementAudience,
  AnnouncementCategory,
  AnnouncementPriority,
  AnnouncementStatus,
  AnnouncementAttachment,
  AnnouncementFilterParams,
  CommunicationLog,
  SchoolClass,
  Section
} from '../../../types/index.js';
import { Modal } from '../../../components/ui/Modal.js';
import { Badge } from '../../../components/ui/Badge.js';
import { Button } from '../../../components/ui/Button.js';
import { LoadingSpinner } from '../../../components/ui/LoadingSpinner.js';

const CATEGORIES: { value: AnnouncementCategory; label: string; color: string }[] = [
  { value: 'GENERAL', label: 'General Circular', color: 'bg-slate-100 text-slate-700 border-slate-200' },
  { value: 'ACADEMIC', label: 'Academic & Curriculum', color: 'bg-blue-100 text-blue-700 border-blue-200' },
  { value: 'EXAMINATION', label: 'Examinations & Dates', color: 'bg-indigo-100 text-indigo-700 border-indigo-200' },
  { value: 'EMERGENCY', label: 'Emergency Alert', color: 'bg-rose-100 text-rose-700 border-rose-200' },
  { value: 'EVENT', label: 'School Event', color: 'bg-purple-100 text-purple-700 border-purple-200' },
  { value: 'HOLIDAY', label: 'Holiday & Vacation', color: 'bg-amber-100 text-amber-700 border-amber-200' },
  { value: 'FEE_FINANCE', label: 'Fees & Finance', color: 'bg-emerald-100 text-emerald-700 border-emerald-200' },
  { value: 'ADMINISTRATIVE', label: 'Administrative Notice', color: 'bg-cyan-100 text-cyan-700 border-cyan-200' },
  { value: 'SPORTS_COCURRICULAR', label: 'Sports & Clubs', color: 'bg-teal-100 text-teal-700 border-teal-200' }
];

const AUDIENCES: { value: AnnouncementAudience; label: string; desc: string }[] = [
  { value: 'SCHOOL_WIDE', label: 'School-Wide (Everyone)', desc: 'Broadcast to all students, teachers, and guardians' },
  { value: 'CLASS', label: 'Specific Class / Section', desc: 'Target students and guardians of a specific cohort' },
  { value: 'STUDENTS', label: 'All Students', desc: 'Target all enrolled student portals' },
  { value: 'PARENTS', label: 'All Parents & Guardians', desc: 'Target verified guardians across all grades' },
  { value: 'TEACHERS', label: 'Faculty & Teachers', desc: 'Target academic faculty and staff' },
  { value: 'CUSTOM', label: 'Custom Targeted Roles', desc: 'Select arbitrary combinations of roles' }
];

export const AnnouncementsManagementTab: React.FC = () => {
  const { user } = useAuth();
  const { showToast } = useToast();

  const [announcements, setAnnouncements] = useState<ClassAnnouncement[]>([]);
  const [loading, setLoading] = useState(true);
  const [classes, setClasses] = useState<SchoolClass[]>([]);
  const [sections, setSections] = useState<Section[]>([]);
  const [stats, setStats] = useState<{
    total: number;
    published: number;
    scheduled: number;
    drafts: number;
    expired: number;
    archived: number;
  }>({ total: 0, published: 0, scheduled: 0, drafts: 0, expired: 0, archived: 0 });

  // Filters
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [categoryFilter, setCategoryFilter] = useState<string>('ALL');
  const [priorityFilter, setPriorityFilter] = useState<string>('ALL');
  const [audienceFilter, setAudienceFilter] = useState<string>('ALL');
  const [classFilter, setClassFilter] = useState<string>('ALL');

  // Modals
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [activeItem, setActiveItem] = useState<ClassAnnouncement | null>(null);
  const [activeDeliveryLogs, setActiveDeliveryLogs] = useState<CommunicationLog[]>([]);
  const [loadingLogs, setLoadingLogs] = useState(false);

  // Form State
  const [formData, setFormData] = useState<{
    title: string;
    message: string;
    category: AnnouncementCategory;
    targetAudience: AnnouncementAudience;
    targetRoles: string[];
    classId: string;
    sectionId: string;
    priority: AnnouncementPriority;
    channels: {
      inApp: boolean;
      email: boolean;
      sms: boolean;
      push: boolean;
    };
    publishMode: 'now' | 'schedule' | 'draft';
    publishDate: string;
    publishTime: string;
    expiryDate: string;
    isPinned: boolean;
    attachments: AnnouncementAttachment[];
  }>({
    title: '',
    message: '',
    category: 'GENERAL',
    targetAudience: 'SCHOOL_WIDE',
    targetRoles: [],
    classId: 'ALL',
    sectionId: 'ALL',
    priority: 'normal',
    channels: { inApp: true, email: false, sms: false, push: false },
    publishMode: 'now',
    publishDate: new Date().toISOString().split('T')[0],
    publishTime: '08:00',
    expiryDate: '',
    isPinned: false,
    attachments: []
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isUploading, setIsUploading] = useState(false);

  // Load Classes & Announcements
  const loadContext = async () => {
    try {
      const [clsRes, secRes] = await Promise.all([
        api.academic.getClasses(),
        api.academic.getSections()
      ]);
      if (clsRes.success && clsRes.data) setClasses(clsRes.data);
      if (secRes.success && secRes.data) setSections(secRes.data);
    } catch (err) {
      console.error('Failed to load academic context', err);
    }
  };

  const loadAnnouncements = async () => {
    try {
      setLoading(true);
      const params: AnnouncementFilterParams = {
        search: search || undefined,
        status: statusFilter !== 'ALL' ? statusFilter : undefined,
        category: categoryFilter !== 'ALL' ? categoryFilter : undefined,
        priority: priorityFilter !== 'ALL' ? priorityFilter : undefined,
        targetAudience: audienceFilter !== 'ALL' ? audienceFilter : undefined,
        classId: classFilter !== 'ALL' ? classFilter : undefined
      };

      const res = await api.communication.announcements.getAll(params);
      if (res.success && res.data) {
        setAnnouncements(res.data);
        if (res.stats) {
          setStats(res.stats);
        }
      }
    } catch (err: any) {
      console.error('Failed to load announcements', err);
      showToast(err.message || 'Error fetching announcements', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadContext();
  }, []);

  useEffect(() => {
    loadAnnouncements();
  }, [statusFilter, categoryFilter, priorityFilter, audienceFilter, classFilter]);

  const availableSections = useMemo(() => {
    if (!formData.classId || formData.classId === 'ALL') return [];
    return sections.filter((s) => s.classId === formData.classId);
  }, [formData.classId, sections]);

  // Handle Form Submit
  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title.trim()) {
      showToast('Announcement title is required.', 'error');
      return;
    }
    if (!formData.message.trim()) {
      showToast('Announcement body message is required.', 'error');
      return;
    }

    try {
      setIsSubmitting(true);

      let status: AnnouncementStatus = 'published';
      let scheduledFor: string | undefined = undefined;

      if (formData.publishMode === 'draft') {
        status = 'draft';
      } else if (formData.publishMode === 'schedule') {
        status = 'scheduled';
        scheduledFor = `${formData.publishDate}T${formData.publishTime || '08:00'}:00.000Z`;
      }

      const payload: Partial<ClassAnnouncement> = {
        title: formData.title.trim(),
        message: formData.message.trim(),
        category: formData.category,
        targetAudience: formData.targetAudience,
        targetRoles: formData.targetRoles,
        classId: formData.classId,
        sectionId: formData.sectionId,
        priority: formData.priority,
        channels: formData.channels,
        status,
        scheduledFor,
        publishDate: formData.publishDate,
        expiryDate: formData.expiryDate || undefined,
        isPinned: formData.isPinned,
        attachments: formData.attachments
      };

      if (showEditModal && activeItem) {
        const res = await api.communication.announcements.update(activeItem.id, payload);
        if (res.success) {
          showToast('Announcement successfully updated.', 'success');
          setShowEditModal(false);
          loadAnnouncements();
        }
      } else {
        const res = await api.communication.announcements.create(payload);
        if (res.success) {
          showToast(
            formData.publishMode === 'schedule'
              ? 'Announcement scheduled for automated broadcast.'
              : formData.publishMode === 'draft'
              ? 'Announcement saved as draft.'
              : 'Announcement published and broadcast sent.',
            'success'
          );
          setShowCreateModal(false);
          loadAnnouncements();
        }
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to save announcement', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Open Create Modal
  const openCreate = () => {
    setFormData({
      title: '',
      message: '',
      category: 'GENERAL',
      targetAudience: 'SCHOOL_WIDE',
      targetRoles: [],
      classId: 'ALL',
      sectionId: 'ALL',
      priority: 'normal',
      channels: { inApp: true, email: false, sms: false, push: false },
      publishMode: 'now',
      publishDate: new Date().toISOString().split('T')[0],
      publishTime: '08:00',
      expiryDate: '',
      isPinned: false,
      attachments: []
    });
    setShowCreateModal(true);
  };

  // Open Edit Modal
  const openEdit = (item: ClassAnnouncement) => {
    setActiveItem(item);
    setFormData({
      title: item.title,
      message: item.message,
      category: item.category || 'GENERAL',
      targetAudience: item.targetAudience || (item.classId === 'ALL' ? 'SCHOOL_WIDE' : 'CLASS'),
      targetRoles: item.targetRoles || [],
      classId: item.classId || 'ALL',
      sectionId: item.sectionId || 'ALL',
      priority: item.priority || 'normal',
      channels: item.channels || { inApp: true, email: false, sms: false, push: false },
      publishMode: item.status === 'scheduled' ? 'schedule' : item.status === 'draft' ? 'draft' : 'now',
      publishDate: item.publishDate || new Date().toISOString().split('T')[0],
      publishTime: item.scheduledFor ? item.scheduledFor.split('T')[1]?.substring(0, 5) || '08:00' : '08:00',
      expiryDate: item.expiryDate || '',
      isPinned: !!item.isPinned,
      attachments: item.attachments || []
    });
    setShowEditModal(true);
  };

  // Open Details Modal
  const openDetail = async (item: ClassAnnouncement) => {
    setActiveItem(item);
    setShowDetailModal(true);
    setLoadingLogs(true);
    try {
      const res = await api.communication.announcements.getById(item.id);
      if (res.success && res.data) {
        setActiveItem(res.data);
        if (res.deliveryLogs) {
          setActiveDeliveryLogs(res.deliveryLogs);
        }
      }
    } catch (err) {
      console.error('Failed to load detail logs', err);
    } finally {
      setLoadingLogs(false);
    }
  };

  // Pin / Unpin
  const handleTogglePin = async (item: ClassAnnouncement) => {
    try {
      const res = await api.communication.announcements.togglePin(item.id);
      if (res.success) {
        showToast(res.isPinned ? 'Notice pinned to top.' : 'Notice unpinned.', 'info');
        loadAnnouncements();
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to update pin state', 'error');
    }
  };

  // Publish Now
  const handlePublishNow = async (item: ClassAnnouncement) => {
    try {
      const res = await api.communication.announcements.publish(item.id);
      if (res.success) {
        showToast('Announcement published and dispatched.', 'success');
        loadAnnouncements();
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to publish announcement', 'error');
    }
  };

  // Cancel Schedule
  const handleCancelSchedule = async (item: ClassAnnouncement) => {
    try {
      const res = await api.communication.announcements.cancelSchedule(item.id);
      if (res.success) {
        showToast('Scheduled announcement cancelled and reverted to draft.', 'info');
        loadAnnouncements();
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to cancel schedule', 'error');
    }
  };

  // Archive / Unarchive
  const handleToggleArchive = async (item: ClassAnnouncement) => {
    try {
      if (item.status === 'archived') {
        await api.communication.announcements.unarchive(item.id);
        showToast('Announcement restored from archive.', 'info');
      } else {
        await api.communication.announcements.archive(item.id);
        showToast('Announcement archived.', 'info');
      }
      loadAnnouncements();
    } catch (err: any) {
      showToast(err.message || 'Failed to update archive status', 'error');
    }
  };

  // Delete
  const handleDelete = async () => {
    if (!activeItem) return;
    try {
      const res = await api.communication.announcements.delete(activeItem.id);
      if (res.success) {
        showToast('Announcement deleted successfully.', 'success');
        setShowDeleteModal(false);
        loadAnnouncements();
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to delete announcement', 'error');
    }
  };

  // Mock / Real File Upload with Validation
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check size limit: 15MB
    const MAX_SIZE = 15 * 1024 * 1024;
    if (file.size > MAX_SIZE) {
      showToast('File size exceeds maximum allowed 15MB limit.', 'error');
      return;
    }

    try {
      setIsUploading(true);
      const res = await api.communication.announcements.uploadAttachment({
        fileName: file.name,
        fileSizeBytes: file.size,
        fileType: file.type
      });

      if (res.success && res.data) {
        setFormData((prev) => ({
          ...prev,
          attachments: [...prev.attachments, res.data]
        }));
        showToast(`Attachment '${file.name}' verified and attached.`, 'success');
      }
    } catch (err: any) {
      showToast(err.message || 'Failed to upload attachment', 'error');
    } finally {
      setIsUploading(false);
      e.target.value = '';
    }
  };

  const removeAttachment = (index: number) => {
    setFormData((prev) => ({
      ...prev,
      attachments: prev.attachments.filter((_, i) => i !== index)
    }));
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Metric Badges */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-indigo-50 text-indigo-700 border border-indigo-200 uppercase tracking-wider flex items-center gap-1.5">
              <Megaphone className="w-3.5 h-3.5 text-indigo-600" />
              School Noticeboard & Broadcast Center
            </span>
            <span className="text-xs text-slate-400">Part 11B</span>
          </div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">
            School Announcements, Notices & Circulars
          </h2>
          <p className="text-sm text-slate-500 mt-1 max-w-2xl">
            Publish official announcements, emergency broadcasts, and academic circulars across multi-channel gateways with real-time read receipt verification.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <Button
            variant="outline"
            size="sm"
            onClick={loadAnnouncements}
            disabled={loading}
            className="flex items-center gap-1.5 text-slate-700 border-slate-200"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
          <Button
            variant="primary"
            size="sm"
            onClick={openCreate}
            className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white shadow-sm"
          >
            <Plus className="w-4 h-4" />
            New Announcement
          </Button>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 md:grid-cols-6 gap-3">
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Total Bulletins</div>
          <div className="text-2xl font-bold text-slate-900 mt-1">{stats.total}</div>
          <div className="text-[11px] text-slate-400 mt-0.5 flex items-center gap-1">
            <Radio className="w-3 h-3 text-indigo-500" /> System notices
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
          <div className="text-xs font-semibold text-emerald-600 uppercase tracking-wider">Published</div>
          <div className="text-2xl font-bold text-emerald-600 mt-1">{stats.published}</div>
          <div className="text-[11px] text-slate-400 mt-0.5 flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3 text-emerald-500" /> Live on portals
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
          <div className="text-xs font-semibold text-blue-600 uppercase tracking-wider">Scheduled</div>
          <div className="text-2xl font-bold text-blue-600 mt-1">{stats.scheduled}</div>
          <div className="text-[11px] text-slate-400 mt-0.5 flex items-center gap-1">
            <Clock className="w-3 h-3 text-blue-500" /> Auto-publish queue
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
          <div className="text-xs font-semibold text-amber-600 uppercase tracking-wider">Drafts</div>
          <div className="text-2xl font-bold text-amber-600 mt-1">{stats.drafts}</div>
          <div className="text-[11px] text-slate-400 mt-0.5 flex items-center gap-1">
            <Edit3 className="w-3 h-3 text-amber-500" /> Unreleased
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
          <div className="text-xs font-semibold text-rose-600 uppercase tracking-wider">Expired</div>
          <div className="text-2xl font-bold text-rose-600 mt-1">{stats.expired}</div>
          <div className="text-[11px] text-slate-400 mt-0.5 flex items-center gap-1">
            <Clock className="w-3 h-3 text-rose-500" /> Past validity
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Archived</div>
          <div className="text-2xl font-bold text-slate-600 mt-1">{stats.archived}</div>
          <div className="text-[11px] text-slate-400 mt-0.5 flex items-center gap-1">
            <Archive className="w-3 h-3 text-slate-400" /> Stored records
          </div>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm space-y-3">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-3">
          {/* Search */}
          <div className="relative lg:col-span-2">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && loadAnnouncements()}
              placeholder="Search notices by title, content or author..."
              className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-none focus:border-indigo-500"
            />
          </div>

          {/* Status Filter */}
          <div>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-none focus:border-indigo-500 bg-white"
            >
              <option value="ALL">All Statuses</option>
              <option value="published">Published</option>
              <option value="scheduled">Scheduled</option>
              <option value="draft">Drafts</option>
              <option value="expired">Expired</option>
              <option value="archived">Archived</option>
            </select>
          </div>

          {/* Category Filter */}
          <div>
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-none focus:border-indigo-500 bg-white"
            >
              <option value="ALL">All Categories</option>
              {CATEGORIES.map((c) => (
                <option key={c.value} value={c.value}>
                  {c.label}
                </option>
              ))}
            </select>
          </div>

          {/* Audience Filter */}
          <div>
            <select
              value={audienceFilter}
              onChange={(e) => setAudienceFilter(e.target.value)}
              className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-none focus:border-indigo-500 bg-white"
            >
              <option value="ALL">All Audiences</option>
              {AUDIENCES.map((a) => (
                <option key={a.value} value={a.value}>
                  {a.label}
                </option>
              ))}
            </select>
          </div>

          {/* Priority Filter */}
          <div>
            <select
              value={priorityFilter}
              onChange={(e) => setPriorityFilter(e.target.value)}
              className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-none focus:border-indigo-500 bg-white"
            >
              <option value="ALL">All Priorities</option>
              <option value="urgent">Urgent</option>
              <option value="high">High</option>
              <option value="normal">Normal</option>
            </select>
          </div>
        </div>
      </div>

      {/* Announcements List */}
      {loading ? (
        <div className="p-12 flex flex-col items-center justify-center min-h-[300px] bg-white rounded-2xl border border-slate-200">
          <LoadingSpinner size="md" message="Loading school announcements & delivery stats..." />
        </div>
      ) : announcements.length === 0 ? (
        <div className="p-12 text-center bg-white rounded-2xl border border-slate-200 space-y-3">
          <div className="w-12 h-12 rounded-xl bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
            <Megaphone className="w-6 h-6" />
          </div>
          <h3 className="text-base font-bold text-slate-800">No Announcements Found</h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            There are no announcements matching your current filters. Clear the search or create a new school circular.
          </p>
          <Button
            size="sm"
            variant="outline"
            onClick={() => {
              setSearch('');
              setStatusFilter('ALL');
              setCategoryFilter('ALL');
              setPriorityFilter('ALL');
              setAudienceFilter('ALL');
              setClassFilter('ALL');
            }}
          >
            Clear All Filters
          </Button>
        </div>
      ) : (
        <div className="space-y-3">
          {announcements.map((item) => {
            const cat = CATEGORIES.find((c) => c.value === item.category);
            const aud = AUDIENCES.find((a) => a.value === item.targetAudience);
            const readPercentage = item.stats?.totalRecipients
              ? Math.round((item.stats.readCount / item.stats.totalRecipients) * 100)
              : 0;

            return (
              <div
                key={item.id}
                className={`bg-white rounded-2xl border p-5 shadow-sm transition-all hover:border-slate-300 relative ${
                  item.isPinned ? 'border-amber-300 bg-amber-50/20' : 'border-slate-200'
                }`}
              >
                <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-4">
                  <div className="space-y-2 flex-1">
                    {/* Header Badges */}
                    <div className="flex flex-wrap items-center gap-2">
                      {item.isPinned && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-300 flex items-center gap-1">
                          <Pin className="w-3 h-3" /> Pinned
                        </span>
                      )}

                      {/* Status */}
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                          item.status === 'published'
                            ? 'bg-emerald-100 text-emerald-800'
                            : item.status === 'scheduled'
                            ? 'bg-blue-100 text-blue-800'
                            : item.status === 'draft'
                            ? 'bg-amber-100 text-amber-800'
                            : item.status === 'expired'
                            ? 'bg-rose-100 text-rose-800'
                            : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        {item.status}
                      </span>

                      {/* Category */}
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${cat?.color || 'bg-slate-100 text-slate-700'}`}>
                        {cat?.label || item.category || 'General'}
                      </span>

                      {/* Priority */}
                      {item.priority === 'urgent' && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800 border border-rose-200 flex items-center gap-1">
                          <AlertTriangle className="w-3 h-3" /> Urgent
                        </span>
                      )}

                      {/* Audience */}
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-slate-100 text-slate-600 border border-slate-200 flex items-center gap-1">
                        <Users className="w-3 h-3 text-slate-500" />
                        {item.targetAudience === 'CLASS'
                          ? `Class ${item.className}${item.sectionName ? ` • ${item.sectionName}` : ''}`
                          : aud?.label || item.targetAudience || 'School-Wide'}
                      </span>

                      {/* Channels Indicator */}
                      <div className="flex items-center gap-1 text-slate-400 pl-2">
                        {item.channels?.inApp && <Bell className="w-3 h-3 text-emerald-600" title="In-App Alert Active" />}
                        {item.channels?.email && <Mail className="w-3 h-3 text-blue-600" title="Email Dispatch Active" />}
                        {item.channels?.sms && <MessageSquare className="w-3 h-3 text-indigo-600" title="SMS Dispatch Active" />}
                        {item.channels?.push && <Smartphone className="w-3 h-3 text-purple-600" title="Mobile Push Active" />}
                      </div>
                    </div>

                    {/* Title */}
                    <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                      {item.title}
                    </h3>

                    {/* Content Preview */}
                    <p className="text-xs text-slate-600 leading-relaxed line-clamp-2">
                      {item.message}
                    </p>

                    {/* Attachments pills */}
                    {item.attachments && item.attachments.length > 0 && (
                      <div className="flex flex-wrap items-center gap-1.5 pt-1">
                        {item.attachments.map((att, i) => (
                          <span
                            key={i}
                            className="inline-flex items-center gap-1 px-2 py-1 rounded-lg text-[11px] bg-slate-50 border border-slate-200 text-slate-700 font-medium"
                          >
                            <Paperclip className="w-3 h-3 text-slate-400" />
                            <span className="truncate max-w-[180px]">{att.fileName}</span>
                            <span className="text-[10px] text-slate-400">({att.fileSize})</span>
                          </span>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Read Receipts & Right Actions */}
                  <div className="shrink-0 flex flex-col lg:items-end justify-between gap-3 min-w-[200px]">
                    <div className="text-xs text-slate-500 lg:text-right space-y-0.5">
                      <div className="font-semibold text-slate-700">
                        {item.authorName || item.teacherName || 'Administration'}
                      </div>
                      <div className="text-[11px] text-slate-400 flex items-center lg:justify-end gap-1">
                        <Calendar className="w-3 h-3" />
                        {item.status === 'scheduled' && item.scheduledFor
                          ? `Scheduled: ${new Date(item.scheduledFor).toLocaleDateString()}`
                          : `Published: ${item.publishDate}`}
                      </div>
                      {item.expiryDate && (
                        <div className="text-[10px] text-amber-600 flex items-center lg:justify-end gap-1">
                          <Clock className="w-3 h-3" /> Valid until {item.expiryDate}
                        </div>
                      )}
                    </div>

                    {/* Read Receipts Counter */}
                    <div className="bg-slate-50 border border-slate-200 rounded-xl p-2.5 w-full space-y-1.5">
                      <div className="flex items-center justify-between text-[11px]">
                        <span className="text-slate-500 font-medium flex items-center gap-1">
                          <UserCheck className="w-3.5 h-3.5 text-indigo-500" />
                          Read Receipts
                        </span>
                        <span className="font-bold text-slate-800">
                          {item.stats?.readCount || 0} / {item.stats?.totalRecipients || 0} ({readPercentage}%)
                        </span>
                      </div>
                      <div className="w-full h-1.5 bg-slate-200 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-indigo-600 rounded-full transition-all duration-300"
                          style={{ width: `${Math.min(100, readPercentage)}%` }}
                        />
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center gap-1 self-end">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => openDetail(item)}
                        title="View Details & Read Receipts"
                        className="p-1.5 text-slate-600 hover:text-indigo-600"
                      >
                        <Eye className="w-4 h-4" />
                      </Button>

                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleTogglePin(item)}
                        title={item.isPinned ? 'Unpin Announcement' : 'Pin to Top'}
                        className={`p-1.5 ${item.isPinned ? 'text-amber-600' : 'text-slate-400 hover:text-amber-600'}`}
                      >
                        {item.isPinned ? <PinOff className="w-4 h-4" /> : <Pin className="w-4 h-4" />}
                      </Button>

                      {item.status === 'scheduled' && (
                        <>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handlePublishNow(item)}
                            title="Publish Immediately Now"
                            className="p-1.5 text-emerald-600 hover:text-emerald-700"
                          >
                            <Send className="w-4 h-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleCancelSchedule(item)}
                            title="Cancel Scheduled Broadcast"
                            className="p-1.5 text-amber-600 hover:text-amber-700"
                          >
                            <Clock className="w-4 h-4" />
                          </Button>
                        </>
                      )}

                      {item.status === 'draft' && (
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handlePublishNow(item)}
                          title="Publish Draft"
                          className="p-1.5 text-emerald-600 hover:text-emerald-700"
                        >
                          <Send className="w-4 h-4" />
                        </Button>
                      )}

                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleToggleArchive(item)}
                        title={item.status === 'archived' ? 'Unarchive' : 'Archive'}
                        className="p-1.5 text-slate-400 hover:text-slate-700"
                      >
                        <Archive className="w-4 h-4" />
                      </Button>

                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => openEdit(item)}
                        title="Edit Announcement"
                        className="p-1.5 text-slate-400 hover:text-indigo-600"
                      >
                        <Edit3 className="w-4 h-4" />
                      </Button>

                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => {
                          setActiveItem(item);
                          setShowDeleteModal(true);
                        }}
                        title="Delete Announcement"
                        className="p-1.5 text-slate-400 hover:text-rose-600"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* CREATE & EDIT MODAL */}
      {(showCreateModal || showEditModal) && (
        <Modal
          isOpen={showCreateModal || showEditModal}
          onClose={() => {
            setShowCreateModal(false);
            setShowEditModal(false);
          }}
          title={showEditModal ? 'Edit Announcement' : 'Broadcast New Announcement'}
          size="lg"
        >
          <form onSubmit={handleFormSubmit} className="space-y-4">
            {/* Title */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Announcement Title <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                placeholder="e.g. Annual Sports Day Schedule & Registration Guidelines"
                className="w-full px-3.5 py-2 text-xs border border-slate-200 rounded-xl focus:outline-none focus:border-indigo-500"
              />
            </div>

            {/* Category & Priority */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Category</label>
                <select
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value as AnnouncementCategory })}
                  className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-none focus:border-indigo-500 bg-white"
                >
                  {CATEGORIES.map((c) => (
                    <option key={c.value} value={c.value}>
                      {c.label}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Priority</label>
                <select
                  value={formData.priority}
                  onChange={(e) => setFormData({ ...formData, priority: e.target.value as AnnouncementPriority })}
                  className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-none focus:border-indigo-500 bg-white"
                >
                  <option value="normal">Normal Priority</option>
                  <option value="high">High Priority</option>
                  <option value="urgent">Urgent Notice</option>
                </select>
              </div>
            </div>

            {/* Target Audience & Classes */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Target Audience</label>
                <select
                  value={formData.targetAudience}
                  onChange={(e) => setFormData({ ...formData, targetAudience: e.target.value as AnnouncementAudience })}
                  className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-none focus:border-indigo-500 bg-white"
                >
                  {AUDIENCES.map((a) => (
                    <option key={a.value} value={a.value}>
                      {a.label}
                    </option>
                  ))}
                </select>
              </div>

              {formData.targetAudience === 'CLASS' ? (
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Target Class & Section</label>
                  <div className="grid grid-cols-2 gap-2">
                    <select
                      value={formData.classId}
                      onChange={(e) => setFormData({ ...formData, classId: e.target.value, sectionId: 'ALL' })}
                      className="w-full px-2.5 py-2 text-xs border border-slate-200 rounded-xl focus:outline-none focus:border-indigo-500 bg-white"
                    >
                      <option value="ALL">All Classes</option>
                      {classes.map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.name}
                        </option>
                      ))}
                    </select>

                    <select
                      value={formData.sectionId}
                      onChange={(e) => setFormData({ ...formData, sectionId: e.target.value })}
                      disabled={formData.classId === 'ALL'}
                      className="w-full px-2.5 py-2 text-xs border border-slate-200 rounded-xl focus:outline-none focus:border-indigo-500 bg-white disabled:opacity-50"
                    >
                      <option value="ALL">All Sections</option>
                      {availableSections.map((s) => (
                        <option key={s.id} value={s.id}>
                          {s.name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              ) : formData.targetAudience === 'CUSTOM' ? (
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Custom Roles</label>
                  <div className="flex flex-wrap gap-2 pt-1">
                    {['STUDENT', 'GUARDIAN', 'TEACHER', 'SUPER_ADMIN'].map((role) => (
                      <label key={role} className="inline-flex items-center gap-1.5 text-xs text-slate-600 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={formData.targetRoles.includes(role)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setFormData({ ...formData, targetRoles: [...formData.targetRoles, role] });
                            } else {
                              setFormData({ ...formData, targetRoles: formData.targetRoles.filter((r) => r !== role) });
                            }
                          }}
                          className="rounded text-indigo-600 focus:ring-indigo-500"
                        />
                        <span>{role}</span>
                      </label>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-500 flex items-center gap-2">
                  <Info className="w-4 h-4 text-indigo-500 shrink-0" />
                  <span>Broadcast targets entire school registry across authorized portals.</span>
                </div>
              )}
            </div>

            {/* Notification Channels */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Dispatch Channels</label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                <label className="p-2.5 rounded-xl border border-slate-200 bg-slate-50 flex items-center gap-2 text-xs font-medium text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.channels.inApp}
                    onChange={(e) =>
                      setFormData({ ...formData, channels: { ...formData.channels, inApp: e.target.checked } })
                    }
                    className="rounded text-indigo-600 focus:ring-indigo-500"
                  />
                  <Bell className="w-3.5 h-3.5 text-emerald-600" />
                  <span>In-App Feed</span>
                </label>

                <label className="p-2.5 rounded-xl border border-slate-200 bg-slate-50 flex items-center gap-2 text-xs font-medium text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.channels.email}
                    onChange={(e) =>
                      setFormData({ ...formData, channels: { ...formData.channels, email: e.target.checked } })
                    }
                    className="rounded text-indigo-600 focus:ring-indigo-500"
                  />
                  <Mail className="w-3.5 h-3.5 text-blue-600" />
                  <span>Email Dispatch</span>
                </label>

                <label className="p-2.5 rounded-xl border border-slate-200 bg-slate-50 flex items-center gap-2 text-xs font-medium text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.channels.sms}
                    onChange={(e) =>
                      setFormData({ ...formData, channels: { ...formData.channels, sms: e.target.checked } })
                    }
                    className="rounded text-indigo-600 focus:ring-indigo-500"
                  />
                  <MessageSquare className="w-3.5 h-3.5 text-indigo-600" />
                  <span>SMS Dispatch</span>
                </label>

                <label className="p-2.5 rounded-xl border border-slate-200 bg-slate-50 flex items-center gap-2 text-xs font-medium text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.channels.push}
                    onChange={(e) =>
                      setFormData({ ...formData, channels: { ...formData.channels, push: e.target.checked } })
                    }
                    className="rounded text-indigo-600 focus:ring-indigo-500"
                  />
                  <Smartphone className="w-3.5 h-3.5 text-purple-600" />
                  <span>Mobile Push</span>
                </label>
              </div>
            </div>

            {/* Message Body */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Notice Message Content <span className="text-rose-500">*</span>
              </label>
              <textarea
                required
                rows={5}
                value={formData.message}
                onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                placeholder="Write the full circular body. Server automatically sanitizes HTML and script tags..."
                className="w-full px-3.5 py-2.5 text-xs border border-slate-200 rounded-xl focus:outline-none focus:border-indigo-500 leading-relaxed font-sans"
              />
            </div>

            {/* Publishing Lifecycle & Expiry */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-3.5 bg-slate-50 border border-slate-200 rounded-xl">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Publish Action</label>
                <select
                  value={formData.publishMode}
                  onChange={(e) =>
                    setFormData({ ...formData, publishMode: e.target.value as 'now' | 'schedule' | 'draft' })
                  }
                  className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-none focus:border-indigo-500 bg-white"
                >
                  <option value="now">Publish Immediately</option>
                  <option value="schedule">Schedule for Future</option>
                  <option value="draft">Save as Draft</option>
                </select>
              </div>

              {formData.publishMode === 'schedule' ? (
                <>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Publish Date</label>
                    <input
                      type="date"
                      value={formData.publishDate}
                      onChange={(e) => setFormData({ ...formData, publishDate: e.target.value })}
                      className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-none focus:border-indigo-500 bg-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Publish Time</label>
                    <input
                      type="time"
                      value={formData.publishTime}
                      onChange={(e) => setFormData({ ...formData, publishTime: e.target.value })}
                      className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-none focus:border-indigo-500 bg-white"
                    />
                  </div>
                </>
              ) : (
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Expiry Date (Optional)</label>
                  <input
                    type="date"
                    value={formData.expiryDate}
                    onChange={(e) => setFormData({ ...formData, expiryDate: e.target.value })}
                    className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-none focus:border-indigo-500 bg-white"
                  />
                </div>
              )}

              <div className="sm:col-span-1 flex items-end">
                <label className="inline-flex items-center gap-2 text-xs font-semibold text-slate-700 cursor-pointer pb-2">
                  <input
                    type="checkbox"
                    checked={formData.isPinned}
                    onChange={(e) => setFormData({ ...formData, isPinned: e.target.checked })}
                    className="rounded text-indigo-600 focus:ring-indigo-500"
                  />
                  <span>Pin Notice to Top</span>
                </label>
              </div>
            </div>

            {/* Attachments Section */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                  <Paperclip className="w-3.5 h-3.5 text-slate-500" />
                  <span>Attachments & Documents (Max 15MB each)</span>
                </label>
                <label className="cursor-pointer inline-flex items-center gap-1.5 px-3 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-medium rounded-lg transition-colors">
                  <UploadCloud className="w-3.5 h-3.5 text-indigo-600" />
                  <span>{isUploading ? 'Validating...' : 'Upload File'}</span>
                  <input
                    type="file"
                    className="hidden"
                    onChange={handleFileUpload}
                    disabled={isUploading}
                    accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.jpg,.jpeg,.png,.webp,.zip"
                  />
                </label>
              </div>

              {((formData?.attachments?.length || 0) > 0) && (
                <div className="space-y-1.5">
                  {formData.attachments.map((att, idx) => (
                    <div
                      key={idx}
                      className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between text-xs"
                    >
                      <div className="flex items-center gap-2 truncate">
                        <FileText className="w-4 h-4 text-indigo-600 shrink-0" />
                        <span className="font-semibold text-slate-800 truncate">{att.fileName}</span>
                        <span className="text-slate-400">({att.fileSize})</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => removeAttachment(idx)}
                        className="text-slate-400 hover:text-rose-600 p-1"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Modal Actions */}
            <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setShowCreateModal(false);
                  setShowEditModal(false);
                }}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                variant="primary"
                disabled={isSubmitting}
                className="bg-indigo-600 hover:bg-indigo-700 text-white"
              >
                {isSubmitting ? 'Processing...' : showEditModal ? 'Update Announcement' : 'Confirm & Save'}
              </Button>
            </div>
          </form>
        </Modal>
      )}

      {/* DETAIL & READ RECEIPTS MODAL */}
      {showDetailModal && activeItem && (
        <Modal
          isOpen={showDetailModal}
          onClose={() => setShowDetailModal(null as any)}
          title="Circular Notice & Read Receipt Analytics"
          size="lg"
        >
          <div className="space-y-5">
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
              <div className="flex flex-wrap items-center gap-2">
                {activeItem.isPinned && (
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-300 flex items-center gap-1">
                    <Pin className="w-3 h-3" /> Pinned
                  </span>
                )}
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 uppercase">
                  {activeItem.status}
                </span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-100 text-indigo-800">
                  {activeItem.category || 'General'}
                </span>
                <span className="text-xs text-slate-500">
                  Audience: <strong>{activeItem.targetAudience}</strong>
                </span>
              </div>
              <h3 className="text-lg font-bold text-slate-900">{activeItem.title}</h3>
              <p className="text-xs text-slate-600 leading-relaxed whitespace-pre-wrap">
                {activeItem.message}
              </p>
            </div>

            {/* Read Receipts Progress Summary */}
            <div className="grid grid-cols-3 gap-3 text-center">
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
                <div className="text-[11px] text-slate-500 uppercase">Eligible Recipients</div>
                <div className="text-xl font-bold text-slate-800 mt-0.5">{activeItem.stats?.totalRecipients || 0}</div>
              </div>
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl">
                <div className="text-[11px] text-emerald-700 uppercase">Confirmed Read</div>
                <div className="text-xl font-bold text-emerald-700 mt-0.5">{activeItem.stats?.readCount || 0}</div>
              </div>
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl">
                <div className="text-[11px] text-amber-700 uppercase">Unread</div>
                <div className="text-xl font-bold text-amber-700 mt-0.5">{activeItem.stats?.unreadCount || 0}</div>
              </div>
            </div>

            {/* Read Receipts User List */}
            <div>
              <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <UserCheck className="w-4 h-4 text-indigo-600" />
                <span>Verified User Read Receipts ({activeItem.readReceipts?.length || 0})</span>
              </h4>

              {(activeItem?.readReceipts?.length || 0) === 0 ? (
                <div className="p-4 text-center bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-500">
                  No verified read receipts recorded yet for this circular.
                </div>
              ) : (
                <div className="max-h-48 overflow-y-auto border border-slate-200 rounded-xl divide-y divide-slate-100">
                  {activeItem.readReceipts.map((r, i) => (
                    <div key={i} className="p-2.5 text-xs flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-6 h-6 rounded-full bg-indigo-100 text-indigo-700 font-bold text-[10px] flex items-center justify-center">
                          {r.userName?.charAt(0) || 'U'}
                        </div>
                        <div>
                          <span className="font-semibold text-slate-800">{r.userName || r.userId}</span>
                          <span className="text-[10px] text-slate-400 ml-1.5 px-1.5 py-0.2 bg-slate-100 rounded">
                            {r.userRole}
                          </span>
                        </div>
                      </div>
                      <div className="text-[11px] text-slate-500">
                        {new Date(r.readAt).toLocaleString()}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Linked Delivery Logs */}
            {activeDeliveryLogs.length > 0 && (
              <div>
                <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <Send className="w-4 h-4 text-blue-600" />
                  <span>Gateway Delivery Transmissions ({activeDeliveryLogs.length})</span>
                </h4>
                <div className="max-h-40 overflow-y-auto border border-slate-200 rounded-xl divide-y divide-slate-100 text-xs">
                  {activeDeliveryLogs.map((log) => (
                    <div key={log.id} className="p-2 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-slate-700">{log.channel}</span>
                        <span className="text-slate-500">{log.recipientName} ({log.recipientContact})</span>
                      </div>
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        log.status === 'DELIVERED' ? 'bg-emerald-100 text-emerald-800' : 'bg-blue-100 text-blue-800'
                      }`}>
                        {log.status}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="flex justify-end pt-2">
              <Button onClick={() => setShowDetailModal(false)} variant="secondary">
                Close
              </Button>
            </div>
          </div>
        </Modal>
      )}

      {/* CONFIRM DELETE MODAL */}
      {showDeleteModal && activeItem && (
        <Modal
          isOpen={showDeleteModal}
          onClose={() => setShowDeleteModal(false)}
          title="Delete Announcement"
          size="sm"
        >
          <div className="space-y-4 text-center">
            <div className="w-12 h-12 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">Are you sure?</h3>
              <p className="text-xs text-slate-500 mt-1">
                This will permanently remove circular <strong>"{activeItem.title}"</strong> and all its associated read receipts.
              </p>
            </div>
            <div className="flex justify-center gap-2 pt-2">
              <Button variant="outline" onClick={() => setShowDeleteModal(false)}>
                Cancel
              </Button>
              <Button variant="danger" onClick={handleDelete} className="bg-rose-600 hover:bg-rose-700 text-white">
                Delete Permanently
              </Button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
