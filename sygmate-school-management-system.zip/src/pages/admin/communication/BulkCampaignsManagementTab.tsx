import React, { useState, useEffect, useMemo } from 'react';
import {
  Send,
  Users,
  CheckCircle2,
  Clock,
  AlertTriangle,
  XCircle,
  Search,
  Filter,
  Plus,
  RefreshCw,
  FileText,
  Mail,
  MessageSquare,
  Bell,
  Smartphone,
  Calendar,
  Paperclip,
  Trash2,
  Eye,
  Archive,
  Check,
  ChevronRight,
  ChevronLeft,
  Info,
  ShieldAlert,
  Layers,
  Sparkles,
  X,
  GraduationCap,
  HeartHandshake,
  UserCheck,
  Building,
  RotateCcw,
  Edit3
} from 'lucide-react';
import { api } from '../../../services/api.js';
import {
  BulkCampaign,
  BulkCampaignRecipient,
  BulkCampaignFilterParams,
  BulkCampaignAudienceType,
  BulkCampaignPriority,
  BulkCampaignScheduleType,
  BulkCampaignRelationshipType,
  BulkCampaignAttachment,
  RecipientPreviewResult,
  BulkCampaignStats,
  NotificationChannel,
  CommunicationTemplate,
  CommunicationSettings,
  SchoolClass,
  Section,
  AcademicSession,
  UserRole
} from '../../../types/index.js';

export const BulkCampaignsManagementTab: React.FC = () => {
  // Main Data States
  const [campaigns, setCampaigns] = useState<BulkCampaign[]>([]);
  const [stats, setStats] = useState<BulkCampaignStats | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isProcessingAction, setIsProcessingAction] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Filter & Pagination States
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [audienceFilter, setAudienceFilter] = useState('all');
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalCount, setTotalCount] = useState(0);

  // Metadata for Selectors
  const [classes, setClasses] = useState<SchoolClass[]>([]);
  const [sections, setSections] = useState<Section[]>([]);
  const [sessions, setSessions] = useState<AcademicSession[]>([]);
  const [templates, setTemplates] = useState<CommunicationTemplate[]>([]);
  const [commSettings, setCommSettings] = useState<CommunicationSettings | null>(null);

  // Creation / Editing Modal State
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [editingCampaignId, setEditingCampaignId] = useState<string | null>(null);
  const [wizardStep, setWizardStep] = useState<1 | 2 | 3 | 4 | 5>(1);

  // Form Data
  const [formName, setFormName] = useState('');
  const [formDescription, setFormDescription] = useState('');
  const [formTitle, setFormTitle] = useState('');
  const [formBody, setFormBody] = useState('');
  const [formCategory, setFormCategory] = useState<string>('general');
  const [formPriority, setFormPriority] = useState<BulkCampaignPriority>('NORMAL');
  const [formAudienceType, setFormAudienceType] = useState<BulkCampaignAudienceType>('ROLE_BASED');
  const [formSessionId, setFormSessionId] = useState('');
  const [formClassId, setFormClassId] = useState('');
  const [formSectionId, setFormSectionId] = useState('');
  const [formTargetRoles, setFormTargetRoles] = useState<(UserRole | string)[]>(['GUARDIAN', 'STUDENT']);
  const [formRelationshipType, setFormRelationshipType] = useState<BulkCampaignRelationshipType>('PARENTS_OF_CLASS');
  const [formSelectedTemplateId, setFormSelectedTemplateId] = useState('');
  const [formChannels, setFormChannels] = useState<NotificationChannel[]>(['IN_APP', 'EMAIL']);
  const [formAttachments, setFormAttachments] = useState<BulkCampaignAttachment[]>([]);
  const [formScheduleType, setFormScheduleType] = useState<BulkCampaignScheduleType>('IMMEDIATE');
  const [formScheduledAt, setFormScheduledAt] = useState('');

  // Audience Preview State
  const [previewResult, setPreviewResult] = useState<RecipientPreviewResult | null>(null);
  const [isPreviewLoading, setIsPreviewLoading] = useState(false);

  // Safety Send Confirmation Dialog State
  const [isSendConfirmOpen, setIsSendConfirmOpen] = useState(false);
  const [campaignToSend, setCampaignToSend] = useState<BulkCampaign | null>(null);

  // Detail / Inspector Modal State
  const [inspectingCampaign, setInspectingCampaign] = useState<BulkCampaign | null>(null);
  const [inspectingRecipients, setInspectingRecipients] = useState<BulkCampaignRecipient[]>([]);
  const [recipientSearch, setRecipientSearch] = useState('');
  const [recipientStatusFilter, setRecipientStatusFilter] = useState('all');
  const [recipientPage, setRecipientPage] = useState(1);
  const [recipientTotalPages, setRecipientTotalPages] = useState(1);
  const [recipientTotal, setRecipientTotal] = useState(0);
  const [isRecipientsLoading, setIsRecipientsLoading] = useState(false);

  // Flash message notification helper
  const showNotification = (msg: string, isError = false) => {
    if (isError) {
      setErrorMessage(msg);
      setSuccessMessage(null);
    } else {
      setSuccessMessage(msg);
      setErrorMessage(null);
    }
    setTimeout(() => {
      setSuccessMessage(null);
      setErrorMessage(null);
    }, 5000);
  };

  // Load Campaigns & Metadata
  const loadCampaigns = async () => {
    setIsLoading(true);
    try {
      const res = await api.communication.campaigns.getAll({
        search: searchQuery,
        status: statusFilter,
        category: categoryFilter,
        audienceType: audienceFilter,
        page: currentPage,
        limit: 10
      });

      if (res && res.data) {
        setCampaigns(res.data);
        setTotalCount(res.total);
        setTotalPages(res.pagination?.totalPages || 1);
        if (res.stats) setStats(res.stats);
      }
    } catch (err: any) {
      showNotification(err.message || 'Failed to load campaigns.', true);
    } finally {
      setIsLoading(false);
    }
  };

  // Load Metadata
  const loadMetadata = async () => {
    try {
      const [clsRes, secRes, sesRes, tmplRes, setRes] = await Promise.all([
        api.academic.getClasses(),
        api.academic.getSections(),
        api.academic.getSessions(),
        api.communication.getTemplates({ isActive: true }),
        api.communication.getSettings()
      ]);

      if (clsRes.success && clsRes.data) setClasses(clsRes.data);
      if (secRes.success && secRes.data) setSections(secRes.data);
      if (sesRes.success && sesRes.data) setSessions(sesRes.data);
      if (tmplRes.success && tmplRes.data) setTemplates(tmplRes.data);
      if (setRes.success && setRes.data) setCommSettings(setRes.data);
    } catch (err) {
      console.error('Failed to load campaign metadata:', err);
    }
  };

  useEffect(() => {
    loadMetadata();
  }, []);

  useEffect(() => {
    loadCampaigns();
  }, [searchQuery, statusFilter, categoryFilter, audienceFilter, currentPage]);

  // Recipient live preview recalculation
  const handleCalculatePreview = async () => {
    setIsPreviewLoading(true);
    try {
      const res = await api.communication.campaigns.previewRecipients({
        audienceType: formAudienceType,
        academicSessionId: formSessionId || undefined,
        classId: formClassId || undefined,
        sectionId: formSectionId || undefined,
        targetRoles: formTargetRoles,
        relationshipType: formRelationshipType,
        channels: formChannels
      });

      if (res.success && res.data) {
        setPreviewResult(res.data);
      }
    } catch (err: any) {
      console.error('Failed to preview recipients:', err);
    } finally {
      setIsPreviewLoading(false);
    }
  };

  // Recalculate preview when audience configuration changes in wizard step 2
  useEffect(() => {
    if (isCreateModalOpen && wizardStep === 2) {
      handleCalculatePreview();
    }
  }, [
    isCreateModalOpen,
    wizardStep,
    formAudienceType,
    formSessionId,
    formClassId,
    formSectionId,
    formTargetRoles,
    formRelationshipType
  ]);

  // Handle template selection
  const handleTemplateSelect = (templateId: string) => {
    setFormSelectedTemplateId(templateId);
    const tmpl = templates.find((t) => t.id === templateId);
    if (tmpl) {
      setFormTitle(tmpl.titleTemplate);
      setFormBody(tmpl.bodyTemplate);
      const activeChannels: NotificationChannel[] = [];
      if (tmpl.channels.inApp) activeChannels.push('IN_APP');
      if (tmpl.channels.email) activeChannels.push('EMAIL');
      if (tmpl.channels.sms) activeChannels.push('SMS');
      if (tmpl.channels.push) activeChannels.push('PUSH');
      if (activeChannels.length > 0) setFormChannels(activeChannels);
    }
  };

  // Variable insertion helper
  const insertVariable = (variableKey: string) => {
    const token = `{{${variableKey}}}`;
    setFormBody((prev) => prev + token);
  };

  // Reset Form
  const resetForm = () => {
    setFormName('');
    setFormDescription('');
    setFormTitle('');
    setFormBody('');
    setFormCategory('general');
    setFormPriority('NORMAL');
    setFormAudienceType('ROLE_BASED');
    setFormSessionId('');
    setFormClassId('');
    setFormSectionId('');
    setFormTargetRoles(['GUARDIAN', 'STUDENT']);
    setFormRelationshipType('PARENTS_OF_CLASS');
    setFormSelectedTemplateId('');
    setFormChannels(['IN_APP', 'EMAIL']);
    setFormAttachments([]);
    setFormScheduleType('IMMEDIATE');
    setFormScheduledAt('');
    setPreviewResult(null);
    setEditingCampaignId(null);
    setWizardStep(1);
  };

  // Open Create Modal
  const handleOpenCreateModal = () => {
    resetForm();
    setIsCreateModalOpen(true);
  };

  // Open Edit Modal for Draft
  const handleOpenEditModal = (campaign: BulkCampaign) => {
    resetForm();
    setEditingCampaignId(campaign.id);
    setFormName(campaign.name);
    setFormDescription(campaign.internalDescription || '');
    setFormTitle(campaign.title);
    setFormBody(campaign.body);
    setFormCategory(campaign.category);
    setFormPriority(campaign.priority);
    setFormAudienceType(campaign.audienceType);
    setFormSessionId(campaign.academicSessionId || '');
    setFormClassId(campaign.classId || '');
    setFormSectionId(campaign.sectionId || '');
    setFormTargetRoles(campaign.targetRoles || ['GUARDIAN', 'STUDENT']);
    if (campaign.relationshipType) setFormRelationshipType(campaign.relationshipType);
    setFormSelectedTemplateId(campaign.templateId || '');
    setFormChannels(campaign.channels);
    setFormAttachments(campaign.attachments || []);
    setFormScheduleType(campaign.scheduleType);
    if (campaign.scheduledAt) {
      setFormScheduledAt(campaign.scheduledAt.slice(0, 16));
    }
    setIsCreateModalOpen(true);
  };

  // Add simulated attachment
  const handleAddAttachment = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    const file = files?.[0];
    if (!file) return;

    if (file.size > 10 * 1024 * 1024) {
      alert('Attachment exceeds maximum limit of 10 MB.');
      return;
    }

    const newAtt: BulkCampaignAttachment = {
      id: `att-${Date.now()}`,
      name: file.name,
      size: `${(file.size / (1024 * 1024)).toFixed(1)} MB`,
      sizeBytes: file.size,
      type: file.type || 'application/octet-stream',
      url: `/attachments/${file.name}`
    };

    setFormAttachments((prev) => [...prev, newAtt]);
  };

  const handleRemoveAttachment = (attId: string) => {
    setFormAttachments((prev) => prev.filter((a) => a.id !== attId));
  };

  // Save or submit campaign
  const handleSaveCampaign = async (asDraft = false) => {
    if (!formName.trim()) {
      showNotification('Please provide a campaign name.', true);
      return;
    }
    if (!formTitle.trim()) {
      showNotification('Please provide a message subject/title.', true);
      return;
    }
    if (!formBody.trim()) {
      showNotification('Please provide message content.', true);
      return;
    }
    if (formChannels.length === 0) {
      showNotification('Please select at least one communication channel.', true);
      return;
    }
    if (!asDraft && formScheduleType === 'SCHEDULED' && !formScheduledAt) {
      showNotification('Please select a scheduled delivery date and time.', true);
      return;
    }

    setIsProcessingAction(true);
    try {
      const payload: Partial<BulkCampaign> = {
        name: formName.trim(),
        internalDescription: formDescription.trim(),
        title: formTitle.trim(),
        body: formBody.trim(),
        category: formCategory as any,
        priority: formPriority,
        audienceType: formAudienceType,
        academicSessionId: formSessionId || undefined,
        classId: formClassId || undefined,
        sectionId: formSectionId || undefined,
        targetRoles: formTargetRoles,
        relationshipType: formAudienceType === 'RELATIONSHIP_BASED' ? formRelationshipType : undefined,
        templateId: formSelectedTemplateId || undefined,
        templateName: templates.find((t) => t.id === formSelectedTemplateId)?.name,
        channels: formChannels,
        attachments: formAttachments,
        scheduleType: formScheduleType,
        scheduledAt: formScheduleType === 'SCHEDULED' && formScheduledAt ? new Date(formScheduledAt).toISOString() : undefined,
        status: asDraft ? 'DRAFT' : formScheduleType === 'SCHEDULED' ? 'SCHEDULED' : 'PROCESSING'
      };

      if (editingCampaignId) {
        const res = await api.communication.campaigns.update(editingCampaignId, payload);
        if (res.success) {
          showNotification('Campaign updated successfully.');
          setIsCreateModalOpen(false);
          loadCampaigns();
        }
      } else {
        const res = await api.communication.campaigns.create(payload);
        if (res.success) {
          showNotification(res.message || 'Campaign created successfully.');
          setIsCreateModalOpen(false);
          loadCampaigns();
        }
      }
    } catch (err: any) {
      showNotification(err.message || 'Failed to save campaign.', true);
    } finally {
      setIsProcessingAction(false);
    }
  };

  // Immediate send action from table or modal
  const handleTriggerSendNow = (campaign: BulkCampaign) => {
    setCampaignToSend(campaign);
    setIsSendConfirmOpen(true);
  };

  const handleConfirmSendNow = async () => {
    if (!campaignToSend) return;
    setIsProcessingAction(true);
    try {
      const res = await api.communication.campaigns.sendNow(campaignToSend.id);
      if (res.success) {
        showNotification(res.message || 'Campaign placed into processing queue.');
        setIsSendConfirmOpen(false);
        setCampaignToSend(null);
        loadCampaigns();
      }
    } catch (err: any) {
      showNotification(err.message || 'Failed to dispatch campaign.', true);
    } finally {
      setIsProcessingAction(false);
    }
  };

  // Cancel campaign
  const handleCancelCampaign = async (campaign: BulkCampaign) => {
    const reason = window.prompt(`Cancel campaign '${campaign.name}'? Enter cancellation reason:`, 'Administrative cancellation');
    if (reason === null) return;

    setIsProcessingAction(true);
    try {
      const res = await api.communication.campaigns.cancel(campaign.id, { reason });
      if (res.success) {
        showNotification('Campaign cancelled successfully.');
        loadCampaigns();
      }
    } catch (err: any) {
      showNotification(err.message || 'Failed to cancel campaign.', true);
    } finally {
      setIsProcessingAction(false);
    }
  };

  // Archive campaign
  const handleArchiveCampaign = async (campaign: BulkCampaign) => {
    if (!window.confirm(`Are you sure you want to archive campaign '${campaign.name}'?`)) return;
    setIsProcessingAction(true);
    try {
      const res = await api.communication.campaigns.archive(campaign.id);
      if (res.success) {
        showNotification('Campaign moved to archive.');
        loadCampaigns();
      }
    } catch (err: any) {
      showNotification(err.message || 'Failed to archive campaign.', true);
    } finally {
      setIsProcessingAction(false);
    }
  };

  // Open Campaign Details & Recipient Inspector
  const handleOpenInspector = async (campaign: BulkCampaign) => {
    setInspectingCampaign(campaign);
    setRecipientPage(1);
    setRecipientSearch('');
    setRecipientStatusFilter('all');
    loadInspectingRecipients(campaign.id, 1, '', 'all');
  };

  const loadInspectingRecipients = async (campaignId: string, page: number, search: string, status: string) => {
    setIsRecipientsLoading(true);
    try {
      const res = await api.communication.campaigns.getRecipients(campaignId, {
        page,
        limit: 15,
        search,
        status: status !== 'all' ? status : undefined
      });

      if (res.success && res.data) {
        setInspectingRecipients(res.data);
        setRecipientTotal(res.total);
        setRecipientTotalPages(res.pagination?.totalPages || 1);
        setRecipientPage(page);
      }
    } catch (err: any) {
      console.error('Failed to load campaign recipients:', err);
    } finally {
      setIsRecipientsLoading(false);
    }
  };

  // Status Badge Helper
  const renderStatusBadge = (status: string) => {
    switch (status) {
      case 'COMPLETED':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            Completed
          </span>
        );
      case 'PARTIALLY_FAILED':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-100 text-amber-800">
            <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
            Partially Failed
          </span>
        );
      case 'SCHEDULED':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-sky-100 text-sky-800">
            <Clock className="w-3.5 h-3.5 text-sky-600" />
            Scheduled
          </span>
        );
      case 'PROCESSING':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-indigo-100 text-indigo-800 animate-pulse">
            <RefreshCw className="w-3.5 h-3.5 text-indigo-600 animate-spin" />
            Processing
          </span>
        );
      case 'DRAFT':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-100 text-slate-700">
            <Edit3 className="w-3.5 h-3.5 text-slate-500" />
            Draft
          </span>
        );
      case 'CANCELLED':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-100 text-rose-800">
            <XCircle className="w-3.5 h-3.5 text-rose-600" />
            Cancelled
          </span>
        );
      case 'ARCHIVED':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-200 text-slate-800">
            <Archive className="w-3.5 h-3.5 text-slate-600" />
            Archived
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-gray-100 text-gray-700">
            {status}
          </span>
        );
    }
  };

  // Priority Badge Helper
  const renderPriorityBadge = (priority: string) => {
    switch (priority) {
      case 'URGENT':
        return <span className="px-2 py-0.5 text-xs font-bold rounded bg-rose-600 text-white">URGENT</span>;
      case 'HIGH':
        return <span className="px-2 py-0.5 text-xs font-semibold rounded bg-amber-500 text-white">HIGH</span>;
      case 'LOW':
        return <span className="px-2 py-0.5 text-xs font-medium rounded bg-slate-200 text-slate-700">LOW</span>;
      default:
        return <span className="px-2 py-0.5 text-xs font-medium rounded bg-slate-100 text-slate-600">NORMAL</span>;
    }
  };

  // Channel Icon Helper
  const renderChannelIcons = (channels: NotificationChannel[]) => {
    return (
      <div className="flex items-center gap-1.5 text-slate-500">
        {channels.includes('IN_APP') && (
          <span title="In-App Notification" className="p-1 rounded bg-slate-100 text-indigo-600">
            <Bell className="w-3.5 h-3.5" />
          </span>
        )}
        {channels.includes('EMAIL') && (
          <span title="Email" className="p-1 rounded bg-slate-100 text-sky-600">
            <Mail className="w-3.5 h-3.5" />
          </span>
        )}
        {channels.includes('SMS') && (
          <span title="SMS" className="p-1 rounded bg-slate-100 text-emerald-600">
            <MessageSquare className="w-3.5 h-3.5" />
          </span>
        )}
        {channels.includes('PUSH') && (
          <span title="Push Notification" className="p-1 rounded bg-slate-100 text-purple-600">
            <Smartphone className="w-3.5 h-3.5" />
          </span>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Toast Notifications */}
      {successMessage && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-sm flex items-center justify-between shadow-sm animate-fadeIn">
          <div className="flex items-center gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 flex-shrink-0" />
            <span className="font-medium">{successMessage}</span>
          </div>
          <button onClick={() => setSuccessMessage(null)} className="text-emerald-700 hover:text-emerald-900 text-xs font-bold">
            Dismiss
          </button>
        </div>
      )}

      {errorMessage && (
        <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-sm flex items-center justify-between shadow-sm animate-fadeIn">
          <div className="flex items-center gap-3">
            <AlertTriangle className="w-5 h-5 text-rose-600 flex-shrink-0" />
            <span className="font-medium">{errorMessage}</span>
          </div>
          <button onClick={() => setErrorMessage(null)} className="text-rose-700 hover:text-rose-900 text-xs font-bold">
            Dismiss
          </button>
        </div>
      )}

      {/* Metrics Header */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">Total Campaigns</span>
            <div className="p-2 bg-indigo-50 rounded-lg text-indigo-600">
              <Send className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-slate-800">{stats?.totalCampaigns ?? campaigns.length}</div>
          <div className="text-xs text-slate-500 mt-1">Operational school campaigns</div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">Scheduled / Active</span>
            <div className="p-2 bg-sky-50 rounded-lg text-sky-600">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-sky-700">
            {(stats?.scheduledCount ?? 0) + (stats?.processingCount ?? 0)}
          </div>
          <div className="text-xs text-slate-500 mt-1">
            {stats?.scheduledCount ?? 0} scheduled, {stats?.processingCount ?? 0} in progress
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">Recipients Reached</span>
            <div className="p-2 bg-emerald-50 rounded-lg text-emerald-600">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-emerald-700">{stats?.totalRecipientsReached ?? 0}</div>
          <div className="text-xs text-slate-500 mt-1">Deduplicated unique targets</div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">Delivery Rate</span>
            <div className="p-2 bg-purple-50 rounded-lg text-purple-600">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-purple-700">{stats?.overallDeliveryRate ?? 100}%</div>
          <div className="text-xs text-slate-500 mt-1">Successful across all channels</div>
        </div>
      </div>

      {/* Action Bar & Filters */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-3">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <h2 className="text-lg font-bold text-slate-800">Targeted Campaigns</h2>
            <span className="px-2.5 py-0.5 text-xs font-semibold bg-slate-100 text-slate-600 rounded-full">
              {totalCount} record{totalCount === 1 ? '' : 's'}
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={loadCampaigns}
              disabled={isLoading}
              className="px-3 py-2 text-sm font-medium text-slate-700 hover:text-indigo-600 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl transition-colors flex items-center gap-1.5"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
              Refresh
            </button>

            <button
              id="btn-create-bulk-campaign"
              onClick={handleOpenCreateModal}
              className="px-4 py-2 text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-sm transition-colors flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              Create Campaign
            </button>
          </div>
        </div>

        {/* Search & Select Filters */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-2 border-t border-slate-100">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
            <input
              type="text"
              placeholder="Search campaigns by name or title..."
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full pl-9 pr-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div>
            <select
              value={statusFilter}
              onChange={(e) => {
                setStatusFilter(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="all">All Statuses</option>
              <option value="DRAFT">Draft</option>
              <option value="SCHEDULED">Scheduled</option>
              <option value="PROCESSING">Processing</option>
              <option value="COMPLETED">Completed</option>
              <option value="PARTIALLY_FAILED">Partially Failed</option>
              <option value="FAILED">Failed</option>
              <option value="CANCELLED">Cancelled</option>
              <option value="ARCHIVED">Archived</option>
            </select>
          </div>

          <div>
            <select
              value={categoryFilter}
              onChange={(e) => {
                setCategoryFilter(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="all">All Categories</option>
              <option value="general">General Operational</option>
              <option value="academic">Academic & Curricular</option>
              <option value="exam">Examination</option>
              <option value="attendance">Attendance</option>
              <option value="fee">Fees & Finance</option>
              <option value="admission">Admissions</option>
              <option value="security">Safety & Security</option>
            </select>
          </div>

          <div>
            <select
              value={audienceFilter}
              onChange={(e) => {
                setAudienceFilter(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="all">All Audiences</option>
              <option value="SCHOOL_WIDE">School-Wide</option>
              <option value="ROLE_BASED">Role-Based</option>
              <option value="ACADEMIC_COHORT">Academic Cohort</option>
              <option value="RELATIONSHIP_BASED">Relationship-Based</option>
              <option value="RECIPIENT_LIST">Specific Recipient List</option>
            </select>
          </div>
        </div>
      </div>

      {/* Campaigns Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        {isLoading ? (
          <div className="p-12 text-center text-slate-500 flex flex-col items-center justify-center gap-3">
            <RefreshCw className="w-8 h-8 text-indigo-600 animate-spin" />
            <span className="text-sm font-medium">Loading campaigns...</span>
          </div>
        ) : campaigns.length === 0 ? (
          <div className="p-12 text-center text-slate-500 flex flex-col items-center justify-center gap-3">
            <div className="p-4 bg-slate-50 rounded-full text-slate-400">
              <Send className="w-8 h-8" />
            </div>
            <div className="font-semibold text-slate-700">No communication campaigns found</div>
            <p className="text-xs text-slate-500 max-w-md">
              Create a targeted campaign to broadcast notices, circulars, or alerts to parents, students, or staff with server-side duplicate prevention.
            </p>
            <button
              onClick={handleOpenCreateModal}
              className="mt-2 px-4 py-2 text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-sm"
            >
              Create First Campaign
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50/75 border-b border-slate-200 text-xs font-semibold text-slate-500 uppercase tracking-wider">
                  <th className="py-3.5 px-4">Campaign & Subject</th>
                  <th className="py-3.5 px-4">Audience</th>
                  <th className="py-3.5 px-4">Channels</th>
                  <th className="py-3.5 px-4">Status & Priority</th>
                  <th className="py-3.5 px-4">Dispatch Progress</th>
                  <th className="py-3.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm text-slate-700">
                {campaigns.map((camp) => {
                  const deliveryPct = camp.sentCount > 0 ? Math.round((camp.deliveredCount / camp.sentCount) * 100) : 0;
                  return (
                    <tr key={camp.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3.5 px-4 max-w-xs">
                        <div className="font-bold text-slate-900 truncate">{camp.name}</div>
                        <div className="text-xs text-slate-500 truncate mt-0.5">{camp.title}</div>
                        <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-2">
                          <span>{new Date(camp.createdAt).toLocaleDateString()}</span>
                          <span>•</span>
                          <span>By {camp.createdByName}</span>
                          {camp.attachments && camp.attachments.length > 0 && (
                            <span className="flex items-center gap-1 text-indigo-600 font-medium">
                              <Paperclip className="w-3 h-3" />
                              {camp?.attachments?.length || 0}
                            </span>
                          )}
                        </div>
                      </td>

                      <td className="py-3.5 px-4">
                        <div className="space-y-1">
                          <span className="inline-flex items-center px-2 py-0.5 text-xs font-medium bg-slate-100 text-slate-800 rounded">
                            {(camp.audienceType || 'ALL').replace(/_/g, ' ')}
                          </span>
                          {camp.className && (
                            <div className="text-xs text-slate-600 flex items-center gap-1 font-medium">
                              <GraduationCap className="w-3 h-3 text-slate-400" />
                              {camp.className} {camp.sectionName ? `(${camp.sectionName})` : ''}
                            </div>
                          )}
                          {camp.relationshipType && (
                            <div className="text-xs text-indigo-600 font-medium">
                              {(camp.relationshipType || '').replace(/_/g, ' ')}
                            </div>
                          )}
                        </div>
                      </td>

                      <td className="py-3.5 px-4">
                        {renderChannelIcons(camp.channels)}
                      </td>

                      <td className="py-3.5 px-4 space-y-1.5">
                        <div>{renderStatusBadge(camp.status)}</div>
                        <div>{renderPriorityBadge(camp.priority)}</div>
                      </td>

                      <td className="py-3.5 px-4 min-w-[140px]">
                        <div className="flex items-center justify-between text-xs font-semibold text-slate-700 mb-1">
                          <span>{camp.deliveredCount} / {camp.totalRecipientsCount}</span>
                          <span className="text-slate-500">{deliveryPct}%</span>
                        </div>
                        <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full transition-all duration-300 ${
                              camp.failedCount > 0 ? 'bg-amber-500' : 'bg-emerald-500'
                            }`}
                            style={{ width: `${Math.min(deliveryPct, 100)}%` }}
                          />
                        </div>
                        {camp.status === 'SCHEDULED' && camp.scheduledAt && (
                          <div className="text-[11px] text-sky-600 mt-1 flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {new Date(camp.scheduledAt).toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                          </div>
                        )}
                      </td>

                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => handleOpenInspector(camp)}
                            title="Inspect Delivery & Recipients"
                            className="p-1.5 text-slate-500 hover:text-indigo-600 hover:bg-slate-100 rounded-lg transition-colors"
                          >
                            <Eye className="w-4 h-4" />
                          </button>

                          {camp.status === 'DRAFT' && (
                            <button
                              onClick={() => handleOpenEditModal(camp)}
                              title="Edit Draft"
                              className="p-1.5 text-slate-500 hover:text-amber-600 hover:bg-slate-100 rounded-lg transition-colors"
                            >
                              <Edit3 className="w-4 h-4" />
                            </button>
                          )}

                          {(camp.status === 'DRAFT' || camp.status === 'SCHEDULED') && (
                            <button
                              onClick={() => handleTriggerSendNow(camp)}
                              title="Dispatch Now"
                              className="p-1.5 text-slate-500 hover:text-emerald-600 hover:bg-slate-100 rounded-lg transition-colors"
                            >
                              <Send className="w-4 h-4" />
                            </button>
                          )}

                          {(camp.status === 'SCHEDULED' || camp.status === 'PROCESSING') && (
                            <button
                              onClick={() => handleCancelCampaign(camp)}
                              title="Cancel Campaign"
                              className="p-1.5 text-slate-500 hover:text-rose-600 hover:bg-slate-100 rounded-lg transition-colors"
                            >
                              <XCircle className="w-4 h-4" />
                            </button>
                          )}

                          {(camp.status === 'COMPLETED' || camp.status === 'PARTIALLY_FAILED' || camp.status === 'FAILED' || camp.status === 'CANCELLED') && (
                            <button
                              onClick={() => handleArchiveCampaign(camp)}
                              title="Archive Campaign"
                              className="p-1.5 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors"
                            >
                              <Archive className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* Pagination Footer */}
        {totalPages > 1 && (
          <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
            <div className="text-xs text-slate-500">
              Page {currentPage} of {totalPages} ({totalCount} campaigns)
            </div>
            <div className="flex items-center gap-1">
              <button
                disabled={currentPage <= 1}
                onClick={() => setCurrentPage((p) => Math.max(p - 1, 1))}
                className="p-1.5 border border-slate-200 rounded-lg bg-white disabled:opacity-40 hover:bg-slate-50 text-slate-600"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                disabled={currentPage >= totalPages}
                onClick={() => setCurrentPage((p) => Math.min(p + 1, totalPages))}
                className="p-1.5 border border-slate-200 rounded-lg bg-white disabled:opacity-40 hover:bg-slate-50 text-slate-600"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* ========================================================================= */}
      {/* CAMPAIGN CREATION / EDITING WIZARD MODAL */}
      {/* ========================================================================= */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-3xl w-full my-8 overflow-hidden flex flex-col max-h-[90vh] animate-fadeIn">
            {/* Modal Header */}
            <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <div>
                <h3 className="text-lg font-bold text-slate-800">
                  {editingCampaignId ? 'Edit Campaign Draft' : 'Create Bulk Communication Campaign'}
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Targeted administrative messaging with server-side duplicate prevention and multi-channel delivery.
                </p>
              </div>
              <button
                onClick={() => setIsCreateModalOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Stepper Tabs */}
            <div className="px-6 py-2.5 bg-slate-100/75 border-b border-slate-200 flex items-center justify-between text-xs font-semibold overflow-x-auto gap-2">
              <button
                onClick={() => setWizardStep(1)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap ${
                  wizardStep === 1 ? 'bg-indigo-600 text-white' : 'text-slate-600 hover:bg-slate-200'
                }`}
              >
                <span>1.</span> Profile
              </button>
              <ChevronRight className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
              <button
                onClick={() => setWizardStep(2)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap ${
                  wizardStep === 2 ? 'bg-indigo-600 text-white' : 'text-slate-600 hover:bg-slate-200'
                }`}
              >
                <span>2.</span> Audience & Preview
              </button>
              <ChevronRight className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
              <button
                onClick={() => setWizardStep(3)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap ${
                  wizardStep === 3 ? 'bg-indigo-600 text-white' : 'text-slate-600 hover:bg-slate-200'
                }`}
              >
                <span>3.</span> Message & Template
              </button>
              <ChevronRight className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
              <button
                onClick={() => setWizardStep(4)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap ${
                  wizardStep === 4 ? 'bg-indigo-600 text-white' : 'text-slate-600 hover:bg-slate-200'
                }`}
              >
                <span>4.</span> Channels
              </button>
              <ChevronRight className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
              <button
                onClick={() => setWizardStep(5)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap ${
                  wizardStep === 5 ? 'bg-indigo-600 text-white' : 'text-slate-600 hover:bg-slate-200'
                }`}
              >
                <span>5.</span> Schedule & Send
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 overflow-y-auto space-y-5 flex-1">
              {/* STEP 1: CAMPAIGN PROFILE */}
              {wizardStep === 1 && (
                <div className="space-y-4 animate-fadeIn">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                      Campaign Name <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Q1 Parent-Teacher Academic Consultation Notice"
                      value={formName}
                      onChange={(e) => setFormName(e.target.value)}
                      className="w-full px-3.5 py-2.5 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                    <p className="text-[11px] text-slate-500 mt-1">Internal identifier for logs and tracking.</p>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                      Internal Purpose / Description
                    </label>
                    <textarea
                      rows={2}
                      placeholder="Optional brief administrative context for audit trails..."
                      value={formDescription}
                      onChange={(e) => setFormDescription(e.target.value)}
                      className="w-full px-3.5 py-2 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                        Category
                      </label>
                      <select
                        value={formCategory}
                        onChange={(e) => setFormCategory(e.target.value)}
                        className="w-full px-3.5 py-2 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      >
                        <option value="general">General Operational</option>
                        <option value="academic">Academic & Curriculum</option>
                        <option value="exam">Examinations</option>
                        <option value="attendance">Attendance & Punctuality</option>
                        <option value="fee">Fees & Billing</option>
                        <option value="admission">Admissions & Registration</option>
                        <option value="security">Safety & Emergency</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                        Dispatch Priority
                      </label>
                      <select
                        value={formPriority}
                        onChange={(e) => setFormPriority(e.target.value as BulkCampaignPriority)}
                        className="w-full px-3.5 py-2 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      >
                        <option value="NORMAL">Normal Priority</option>
                        <option value="HIGH">High Priority (Urgent Notices)</option>
                        <option value="URGENT">Urgent (Emergency Weather / Closures)</option>
                        <option value="LOW">Low Priority (General Newsletters)</option>
                      </select>
                    </div>
                  </div>
                </div>
              )}

              {/* STEP 2: AUDIENCE TARGETING & REAL-TIME PREVIEW */}
              {wizardStep === 2 && (
                <div className="space-y-4 animate-fadeIn">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                      Target Audience Type <span className="text-rose-500">*</span>
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                      {[
                        { id: 'ROLE_BASED', label: 'Role-Based', desc: 'All users by role' },
                        { id: 'ACADEMIC_COHORT', label: 'Academic Cohort', desc: 'Specific Class / Section' },
                        { id: 'RELATIONSHIP_BASED', label: 'Relationship-Based', desc: 'Parents of Class' },
                        { id: 'SCHOOL_WIDE', label: 'School-Wide', desc: 'All eligible active users' }
                      ].map((item) => (
                        <button
                          type="button"
                          key={item.id}
                          onClick={() => setFormAudienceType(item.id as BulkCampaignAudienceType)}
                          className={`p-3 text-left rounded-xl border transition-all ${
                            formAudienceType === item.id
                              ? 'border-indigo-600 bg-indigo-50 text-indigo-900 shadow-sm'
                              : 'border-slate-200 hover:border-slate-300 text-slate-700'
                          }`}
                        >
                          <div className="font-bold text-xs">{item.label}</div>
                          <div className="text-[11px] text-slate-500 mt-0.5">{item.desc}</div>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Role-Based checkboxes */}
                  {(formAudienceType === 'ROLE_BASED' || formAudienceType === 'ACADEMIC_COHORT' || formAudienceType === 'SCHOOL_WIDE') && (
                    <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
                      <span className="text-xs font-bold text-slate-700 uppercase tracking-wider block">
                        Included Roles
                      </span>
                      <div className="flex flex-wrap gap-4 text-xs font-semibold text-slate-700">
                        {[
                          { id: 'GUARDIAN', label: 'Parents / Guardians' },
                          { id: 'STUDENT', label: 'Students' },
                          { id: 'TEACHER', label: 'Teachers' },
                          { id: 'STAFF', label: 'Staff' }
                        ].map((role) => (
                          <label key={role.id} className="flex items-center gap-2 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={formTargetRoles.includes(role.id as any)}
                              onChange={(e) => {
                                if (e.target.checked) {
                                  setFormTargetRoles((prev) => [...prev, role.id]);
                                } else {
                                  setFormTargetRoles((prev) => prev.filter((r) => r !== role.id));
                                }
                              }}
                              className="rounded text-indigo-600 focus:ring-indigo-500"
                            />
                            <span>{role.label}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Academic Cohort & Relationship Dropdowns */}
                  {(formAudienceType === 'ACADEMIC_COHORT' || formAudienceType === 'RELATIONSHIP_BASED') && (
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200">
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">Class</label>
                        <select
                          value={formClassId}
                          onChange={(e) => setFormClassId(e.target.value)}
                          className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                        >
                          <option value="">All Classes</option>
                          {classes.map((c) => (
                            <option key={c.id} value={c.id}>
                              {c.name}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">Section</label>
                        <select
                          value={formSectionId}
                          onChange={(e) => setFormSectionId(e.target.value)}
                          className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                        >
                          <option value="">All Sections</option>
                          {sections
                            .filter((s) => !formClassId || s.classId === formClassId)
                            .map((s) => (
                              <option key={s.id} value={s.id}>
                                {s.name}
                              </option>
                            ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">Academic Session</label>
                        <select
                          value={formSessionId}
                          onChange={(e) => setFormSessionId(e.target.value)}
                          className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                        >
                          <option value="">Current Active Session</option>
                          {sessions.map((s) => (
                            <option key={s.id} value={s.id}>
                              {s.name} {s.isCurrent ? '(Active)' : ''}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>
                  )}

                  {/* Real-Time Recipient Preview Box */}
                  <div className="border border-indigo-200 bg-indigo-50/50 rounded-xl p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <UserCheck className="w-4 h-4 text-indigo-600" />
                        <span className="text-xs font-bold text-indigo-950 uppercase tracking-wider">
                          Authoritative Audience Preview
                        </span>
                      </div>
                      <span className="text-[11px] font-semibold text-indigo-700 bg-indigo-100 px-2.5 py-0.5 rounded-full">
                        Resolved Server-Side
                      </span>
                    </div>

                    {isPreviewLoading ? (
                      <div className="py-4 text-center text-xs text-indigo-700 flex items-center justify-center gap-2">
                        <RefreshCw className="w-4 h-4 animate-spin text-indigo-600" />
                        Calculating authoritative recipient targets...
                      </div>
                    ) : previewResult ? (
                      <div className="space-y-3">
                        <div className="grid grid-cols-3 gap-2 text-center">
                          <div className="bg-white p-2.5 rounded-lg border border-indigo-100 shadow-sm">
                            <div className="text-lg font-bold text-indigo-900">{previewResult.totalCount}</div>
                            <div className="text-[10px] uppercase font-semibold text-slate-500">Unique Targets</div>
                          </div>
                          <div className="bg-white p-2.5 rounded-lg border border-indigo-100 shadow-sm">
                            <div className="text-lg font-bold text-emerald-700">{previewResult.duplicatesRemoved}</div>
                            <div className="text-[10px] uppercase font-semibold text-slate-500">Duplicates Deduplicated</div>
                          </div>
                          <div className="bg-white p-2.5 rounded-lg border border-indigo-100 shadow-sm">
                            <div className="text-lg font-bold text-slate-700">{previewResult.ineligibleExcluded}</div>
                            <div className="text-[10px] uppercase font-semibold text-slate-500">Ineligible Excluded</div>
                          </div>
                        </div>

                        {/* Sample list preview */}
                        {((previewResult?.sampleRecipients?.length || 0) > 0) && (
                          <div className="bg-white rounded-lg border border-indigo-100 p-2 text-xs">
                            <div className="text-[11px] font-bold text-slate-600 mb-1 px-1">
                              Sample Recipients (First {previewResult?.sampleRecipients?.length || 0} Resolved):
                            </div>
                            <div className="max-h-32 overflow-y-auto space-y-1">
                              {previewResult.sampleRecipients.map((rec) => (
                                <div key={rec.id} className="flex items-center justify-between px-2 py-1 bg-slate-50 rounded text-slate-700">
                                  <span className="font-semibold">{rec.name} ({rec.role})</span>
                                  <span className="text-slate-400">{rec.studentName ? `Child: ${rec.studentName}` : rec.contactMasked}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    ) : (
                      <button
                        type="button"
                        onClick={handleCalculatePreview}
                        className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-lg transition-colors"
                      >
                        Calculate Audience Target Count
                      </button>
                    )}
                  </div>
                </div>
              )}

              {/* STEP 3: MESSAGE CONTENT & TEMPLATE REUSE */}
              {wizardStep === 3 && (
                <div className="space-y-4 animate-fadeIn">
                  {/* Template selector */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                      Reuse Part 11A Communication Template (Optional)
                    </label>
                    <select
                      value={formSelectedTemplateId}
                      onChange={(e) => handleTemplateSelect(e.target.value)}
                      className="w-full px-3.5 py-2 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500"
                    >
                      <option value="">-- Compose Custom Campaign Text --</option>
                      {templates.map((t) => (
                        <option key={t.id} value={t.id}>
                          {t.name} ({t.category})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                      Subject / Notification Title <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. SIA Annual Sports Day 2026: Schedule & Athlete Participation Consent"
                      value={formTitle}
                      onChange={(e) => setFormTitle(e.target.value)}
                      className="w-full px-3.5 py-2.5 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                        Message Content (Plain or Safe Formatted Text) <span className="text-rose-500">*</span>
                      </label>
                      <span className="text-[11px] text-slate-400">Personalization tags will resolve automatically</span>
                    </div>

                    {/* Variable insertion buttons */}
                    <div className="flex flex-wrap gap-1.5 mb-2">
                      {[
                        { label: 'Recipient Name', key: 'recipient_name' },
                        { label: 'Student Name', key: 'student_name' },
                        { label: 'Class Name', key: 'class_name' },
                        { label: 'Section Name', key: 'section_name' },
                        { label: 'School Name', key: 'school_name' },
                        { label: 'Date', key: 'date' }
                      ].map((chip) => (
                        <button
                          type="button"
                          key={chip.key}
                          onClick={() => insertVariable(chip.key)}
                          className="px-2 py-0.5 text-xs font-medium bg-slate-100 hover:bg-indigo-50 text-indigo-700 border border-slate-200 rounded-md transition-colors"
                        >
                          + {`{{${chip.key}}}`}
                        </button>
                      ))}
                    </div>

                    <textarea
                      rows={6}
                      placeholder="Dear {{recipient_name}}, We are pleased to announce..."
                      value={formBody}
                      onChange={(e) => setFormBody(e.target.value)}
                      className="w-full px-3.5 py-2.5 text-sm bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono"
                    />
                  </div>
                </div>
              )}

              {/* STEP 4: CHANNELS & ATTACHMENTS */}
              {wizardStep === 4 && (
                <div className="space-y-4 animate-fadeIn">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                      Dispatch Channels <span className="text-rose-500">*</span>
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {[
                        {
                          id: 'IN_APP',
                          label: 'In-App Alerts',
                          desc: 'Immediate notification inside portal top bar & bell',
                          icon: Bell,
                          active: commSettings?.inApp.enabled ?? true
                        },
                        {
                          id: 'EMAIL',
                          label: 'Email Dispatch',
                          desc: 'Sent to primary contact emails via configured SMTP / SES',
                          icon: Mail,
                          active: commSettings?.email.enabled ?? true
                        },
                        {
                          id: 'SMS',
                          label: 'SMS Gateway',
                          desc: 'Sent to verified mobile numbers via Twilio / SNS',
                          icon: MessageSquare,
                          active: commSettings?.sms.enabled ?? false
                        },
                        {
                          id: 'PUSH',
                          label: 'Push Notifications',
                          desc: 'Sent to mobile devices and browsers via FCM / WebPush',
                          icon: Smartphone,
                          active: commSettings?.push.enabled ?? false
                        }
                      ].map((chan) => {
                        const isSelected = formChannels.includes(chan.id as NotificationChannel);
                        const Icon = chan.icon;
                        return (
                          <label
                            key={chan.id}
                            className={`p-3.5 rounded-xl border flex items-start gap-3 cursor-pointer transition-all ${
                              isSelected
                                ? 'border-indigo-600 bg-indigo-50 text-indigo-900'
                                : 'border-slate-200 hover:border-slate-300 text-slate-700'
                            }`}
                          >
                            <input
                              type="checkbox"
                              checked={isSelected}
                              onChange={(e) => {
                                if (e.target.checked) {
                                  setFormChannels((prev) => [...prev, chan.id as NotificationChannel]);
                                } else {
                                  setFormChannels((prev) => prev.filter((c) => c !== chan.id));
                                }
                              }}
                              className="mt-1 rounded text-indigo-600 focus:ring-indigo-500"
                            />
                            <div className="flex-1">
                              <div className="flex items-center justify-between">
                                <span className="font-bold text-xs flex items-center gap-1.5">
                                  <Icon className="w-3.5 h-3.5 text-indigo-600" />
                                  {chan.label}
                                </span>
                                <span className={`text-[10px] px-1.5 py-0.5 rounded font-bold ${chan.active ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-500'}`}>
                                  {chan.active ? 'Configured' : 'Inactive'}
                                </span>
                              </div>
                              <p className="text-[11px] text-slate-500 mt-1">{chan.desc}</p>
                            </div>
                          </label>
                        );
                      })}
                    </div>
                  </div>

                  {/* Attachments */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                      Attachments (PDF, Word, Excel, Images - Max 10 MB each)
                    </label>

                    <div className="space-y-2">
                      {formAttachments.map((att) => (
                        <div key={att.id} className="flex items-center justify-between p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs">
                          <div className="flex items-center gap-2 text-slate-700 font-medium">
                            <Paperclip className="w-4 h-4 text-indigo-600" />
                            <span>{att.name}</span>
                            <span className="text-slate-400 text-[11px]">({att.size})</span>
                          </div>
                          <button
                            type="button"
                            onClick={() => handleRemoveAttachment(att.id)}
                            className="text-rose-600 hover:text-rose-800 p-1"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      ))}

                      <label className="border-2 border-dashed border-slate-200 hover:border-indigo-400 p-4 rounded-xl flex flex-col items-center justify-center gap-1 cursor-pointer transition-colors bg-slate-50/50">
                        <Paperclip className="w-5 h-5 text-slate-400" />
                        <span className="text-xs font-semibold text-indigo-600">Choose Attachment File</span>
                        <span className="text-[10px] text-slate-400">PDF, PNG, JPG, DOCX, XLSX up to 10 MB</span>
                        <input
                          type="file"
                          onChange={handleAddAttachment}
                          className="hidden"
                          accept=".pdf,.png,.jpg,.jpeg,.docx,.xlsx,.txt,.csv"
                        />
                      </label>
                    </div>
                  </div>
                </div>
              )}

              {/* STEP 5: SCHEDULE & FINAL REVIEW */}
              {wizardStep === 5 && (
                <div className="space-y-4 animate-fadeIn">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                      Delivery Timing
                    </label>
                    <div className="grid grid-cols-2 gap-3">
                      <button
                        type="button"
                        onClick={() => setFormScheduleType('IMMEDIATE')}
                        className={`p-3.5 rounded-xl border text-left transition-all ${
                          formScheduleType === 'IMMEDIATE'
                            ? 'border-indigo-600 bg-indigo-50 text-indigo-900 font-bold'
                            : 'border-slate-200 text-slate-700'
                        }`}
                      >
                        <div className="text-xs">Dispatch Immediately</div>
                        <div className="text-[11px] font-normal text-slate-500 mt-0.5">
                          Enqueues campaign for instant batch delivery.
                        </div>
                      </button>

                      <button
                        type="button"
                        onClick={() => setFormScheduleType('SCHEDULED')}
                        className={`p-3.5 rounded-xl border text-left transition-all ${
                          formScheduleType === 'SCHEDULED'
                            ? 'border-indigo-600 bg-indigo-50 text-indigo-900 font-bold'
                            : 'border-slate-200 text-slate-700'
                        }`}
                      >
                        <div className="text-xs">Schedule for Later</div>
                        <div className="text-[11px] font-normal text-slate-500 mt-0.5">
                          Background scheduler triggers dispatch at specified time.
                        </div>
                      </button>
                    </div>
                  </div>

                  {formScheduleType === 'SCHEDULED' && (
                    <div className="bg-sky-50 p-4 rounded-xl border border-sky-200">
                      <label className="block text-xs font-bold text-sky-900 mb-1">
                        Scheduled Date & Time (Future Timestamp) <span className="text-rose-500">*</span>
                      </label>
                      <input
                        type="datetime-local"
                        value={formScheduledAt}
                        onChange={(e) => setFormScheduledAt(e.target.value)}
                        className="w-full px-3 py-2 text-sm bg-white border border-sky-300 rounded-lg focus:ring-2 focus:ring-sky-500"
                      />
                    </div>
                  )}

                  {/* Summary card */}
                  <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2 text-xs text-slate-700">
                    <div className="font-bold text-slate-900 uppercase tracking-wider text-[11px] border-b border-slate-200 pb-1">
                      Campaign Dispatch Summary
                    </div>
                    <div className="grid grid-cols-2 gap-2 pt-1">
                      <div><span className="font-semibold text-slate-500">Name:</span> {formName || '—'}</div>
                      <div><span className="font-semibold text-slate-500">Priority:</span> {formPriority}</div>
                      <div><span className="font-semibold text-slate-500">Audience:</span> {formAudienceType}</div>
                      <div><span className="font-semibold text-slate-500">Channels:</span> {formChannels.join(', ')}</div>
                      <div><span className="font-semibold text-slate-500">Estimated Targets:</span> {previewResult?.totalCount ?? 'Ready for preview'}</div>
                      <div><span className="font-semibold text-slate-500">Attachments:</span> {formAttachments.length} file(s)</div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
              <div>
                {wizardStep > 1 && (
                  <button
                    type="button"
                    onClick={() => setWizardStep((s) => (s - 1) as any)}
                    className="px-3.5 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-200 rounded-xl transition-colors"
                  >
                    Back
                  </button>
                )}
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleSaveCampaign(true)}
                  disabled={isProcessingAction}
                  className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-100 rounded-xl transition-colors"
                >
                  Save as Draft
                </button>

                {wizardStep < 5 ? (
                  <button
                    type="button"
                    onClick={() => setWizardStep((s) => (s + 1) as any)}
                    className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-sm transition-colors flex items-center gap-1.5"
                  >
                    Next Step
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => handleSaveCampaign(false)}
                    disabled={isProcessingAction}
                    className="px-4 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-sm transition-colors flex items-center gap-1.5"
                  >
                    <Send className="w-3.5 h-3.5" />
                    {formScheduleType === 'SCHEDULED' ? 'Schedule Campaign' : 'Send Immediately'}
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* FINAL SEND CONFIRMATION SAFETY MODAL */}
      {/* ========================================================================= */}
      {isSendConfirmOpen && campaignToSend && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-md w-full p-6 space-y-4">
            <div className="flex items-center gap-3 text-rose-600">
              <div className="p-2.5 bg-rose-50 rounded-xl">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">Confirm Campaign Dispatch</h3>
                <p className="text-xs text-slate-500">Non-reversible operational broadcast</p>
              </div>
            </div>

            <div className="p-3.5 bg-rose-50/70 border border-rose-200 rounded-xl text-xs text-rose-900 space-y-1.5">
              <div className="font-bold">Important Operational Safety Notice:</div>
              <p>
                You are about to broadcast <strong>{campaignToSend.name}</strong> across{' '}
                <strong>{campaignToSend.channels.join(', ')}</strong>.
              </p>
              <p>
                Recipients will receive in-app and external messages immediately. This action cannot be undone once delivery begins.
              </p>
            </div>

            <div className="space-y-1 text-xs text-slate-600 bg-slate-50 p-3 rounded-lg border border-slate-200">
              <div><strong>Campaign:</strong> {campaignToSend.name}</div>
              <div><strong>Audience:</strong> {campaignToSend.audienceType}</div>
              <div><strong>Channels:</strong> {campaignToSend.channels.join(', ')}</div>
              <div><strong>Priority:</strong> {campaignToSend.priority}</div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsSendConfirmOpen(false)}
                disabled={isProcessingAction}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmSendNow}
                disabled={isProcessingAction}
                className="px-4 py-2 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-xl shadow-sm transition-colors flex items-center gap-1.5"
              >
                {isProcessingAction ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                Confirm & Dispatch
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* CAMPAIGN INSPECTOR & RECIPIENT LEDGER MODAL */}
      {/* ========================================================================= */}
      {inspectingCampaign && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-4xl w-full my-8 overflow-hidden flex flex-col max-h-[90vh] animate-fadeIn">
            {/* Header */}
            <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-lg font-bold text-slate-800">{inspectingCampaign.name}</h3>
                  {renderStatusBadge(inspectingCampaign.status)}
                </div>
                <p className="text-xs text-slate-500 mt-0.5">Campaign Delivery Inspector & Recipient Audit Ledger</p>
              </div>
              <button
                onClick={() => setInspectingCampaign(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Inspector Body */}
            <div className="p-6 overflow-y-auto space-y-6 flex-1">
              {/* Channel Stats Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-center">
                  <div className="text-xs font-bold text-slate-500 uppercase">In-App Alerts</div>
                  <div className="text-lg font-bold text-indigo-700 mt-1">{inspectingCampaign.channelStats?.inApp?.sent ?? 0}</div>
                  <div className="text-[11px] text-slate-400">{inspectingCampaign.channelStats?.inApp?.read ?? 0} read</div>
                </div>

                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-center">
                  <div className="text-xs font-bold text-slate-500 uppercase">Email Sent</div>
                  <div className="text-lg font-bold text-sky-700 mt-1">{inspectingCampaign.channelStats?.email?.delivered ?? 0}</div>
                  <div className="text-[11px] text-slate-400">{inspectingCampaign.channelStats?.email?.failed ?? 0} failed</div>
                </div>

                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-center">
                  <div className="text-xs font-bold text-slate-500 uppercase">SMS Sent</div>
                  <div className="text-lg font-bold text-emerald-700 mt-1">{inspectingCampaign.channelStats?.sms?.delivered ?? 0}</div>
                  <div className="text-[11px] text-slate-400">{inspectingCampaign.channelStats?.sms?.failed ?? 0} failed</div>
                </div>

                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-center">
                  <div className="text-xs font-bold text-slate-500 uppercase">Push Sent</div>
                  <div className="text-lg font-bold text-purple-700 mt-1">{inspectingCampaign.channelStats?.push?.delivered ?? 0}</div>
                  <div className="text-[11px] text-slate-400">{inspectingCampaign.channelStats?.push?.failed ?? 0} failed</div>
                </div>
              </div>

              {/* Message Content & Preview */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
                <div className="text-xs font-bold text-slate-500 uppercase tracking-wider">Subject</div>
                <div className="font-semibold text-slate-900 text-sm">{inspectingCampaign.title}</div>
                <div className="text-xs font-bold text-slate-500 uppercase tracking-wider pt-2">Message Body</div>
                <div className="text-xs text-slate-700 whitespace-pre-wrap bg-white p-3 rounded-lg border border-slate-200 font-sans leading-relaxed">
                  {inspectingCampaign.body}
                </div>
              </div>

              {/* Recipient Ledger Header & Filters */}
              <div className="space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <h4 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                    <Users className="w-4 h-4 text-indigo-600" />
                    Recipient Delivery Ledger ({recipientTotal})
                  </h4>

                  <div className="flex items-center gap-2">
                    <div className="relative">
                      <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-400" />
                      <input
                        type="text"
                        placeholder="Search recipient or student..."
                        value={recipientSearch}
                        onChange={(e) => {
                          setRecipientSearch(e.target.value);
                          loadInspectingRecipients(inspectingCampaign.id, 1, e.target.value, recipientStatusFilter);
                        }}
                        className="pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      />
                    </div>

                    <select
                      value={recipientStatusFilter}
                      onChange={(e) => {
                        setRecipientStatusFilter(e.target.value);
                        loadInspectingRecipients(inspectingCampaign.id, 1, recipientSearch, e.target.value);
                      }}
                      className="px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    >
                      <option value="all">All Statuses</option>
                      <option value="DELIVERED">Delivered</option>
                      <option value="FAILED">Failed</option>
                      <option value="QUEUED">Queued</option>
                    </select>
                  </div>
                </div>

                {/* Recipient Ledger Table */}
                <div className="border border-slate-200 rounded-xl overflow-hidden">
                  {isRecipientsLoading ? (
                    <div className="p-8 text-center text-xs text-slate-500 flex items-center justify-center gap-2">
                      <RefreshCw className="w-4 h-4 animate-spin text-indigo-600" />
                      Loading recipient ledger...
                    </div>
                  ) : inspectingRecipients.length === 0 ? (
                    <div className="p-8 text-center text-xs text-slate-500">
                      No recipient delivery records found matching filter.
                    </div>
                  ) : (
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className="bg-slate-50 border-b border-slate-200 font-semibold text-slate-500 uppercase text-[11px]">
                          <th className="py-2.5 px-3">Recipient & Contact</th>
                          <th className="py-2.5 px-3">Role</th>
                          <th className="py-2.5 px-3">Student Context</th>
                          <th className="py-2.5 px-3">Channels</th>
                          <th className="py-2.5 px-3">Status</th>
                          <th className="py-2.5 px-3">Delivered At</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 text-slate-700">
                        {inspectingRecipients.map((rec) => (
                          <tr key={rec.id} className="hover:bg-slate-50">
                            <td className="py-2.5 px-3 font-semibold text-slate-900">
                              <div>{rec.recipientName}</div>
                              <div className="text-[11px] text-slate-400 font-normal">{rec.contact || '—'}</div>
                            </td>
                            <td className="py-2.5 px-3">
                              <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-medium">
                                {rec.recipientRole}
                              </span>
                            </td>
                            <td className="py-2.5 px-3 font-medium text-indigo-700">
                              {rec.studentName || '—'}
                            </td>
                            <td className="py-2.5 px-3">
                              {renderChannelIcons(rec.channels)}
                            </td>
                            <td className="py-2.5 px-3">
                              {rec.status === 'DELIVERED' ? (
                                <span className="inline-flex items-center gap-1 text-emerald-700 font-semibold">
                                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                                  Delivered
                                </span>
                              ) : rec.status === 'FAILED' ? (
                                <span className="inline-flex items-center gap-1 text-rose-700 font-semibold" title={JSON.stringify(rec.failureReasons || '')}>
                                  <XCircle className="w-3.5 h-3.5 text-rose-600" />
                                  Failed
                                </span>
                              ) : (
                                <span className="inline-flex items-center gap-1 text-slate-600 font-semibold">
                                  <Clock className="w-3.5 h-3.5 text-slate-400" />
                                  Queued
                                </span>
                              )}
                            </td>
                            <td className="py-2.5 px-3 text-slate-500 text-[11px]">
                              {rec.deliveredAt ? new Date(rec.deliveredAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '—'}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}
                </div>

                {/* Recipient Pagination */}
                {recipientTotalPages > 1 && (
                  <div className="flex items-center justify-between text-xs text-slate-500 pt-1">
                    <span>
                      Page {recipientPage} of {recipientTotalPages}
                    </span>
                    <div className="flex items-center gap-1">
                      <button
                        disabled={recipientPage <= 1}
                        onClick={() => {
                          const p = recipientPage - 1;
                          loadInspectingRecipients(inspectingCampaign.id, p, recipientSearch, recipientStatusFilter);
                        }}
                        className="p-1 border border-slate-200 rounded disabled:opacity-40"
                      >
                        <ChevronLeft className="w-3.5 h-3.5" />
                      </button>
                      <button
                        disabled={recipientPage >= recipientTotalPages}
                        onClick={() => {
                          const p = recipientPage + 1;
                          loadInspectingRecipients(inspectingCampaign.id, p, recipientSearch, recipientStatusFilter);
                        }}
                        className="p-1 border border-slate-200 rounded disabled:opacity-40"
                      >
                        <ChevronRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Footer */}
            <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 flex items-center justify-end">
              <button
                type="button"
                onClick={() => setInspectingCampaign(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-100 rounded-xl transition-colors"
              >
                Close Inspector
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
