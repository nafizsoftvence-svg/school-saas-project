import React, { useState } from 'react';
import {
  Calendar,
  Plus,
  CheckCircle2,
  Clock,
  Archive,
  Trash2,
  Edit2,
  Sparkles,
  Search,
  Check,
  AlertCircle
} from 'lucide-react';
import { Table, Column } from '../../../components/ui/Table.js';
import { Badge } from '../../../components/ui/Badge.js';
import { Button } from '../../../components/ui/Button.js';
import { Modal } from '../../../components/ui/Modal.js';
import { Input } from '../../../components/ui/Input.js';
import { Select } from '../../../components/ui/Select.js';
import { ConfirmDialog } from '../../../components/ui/ConfirmDialog.js';
import { EmptyState } from '../../../components/ui/EmptyState.js';
import { AcademicSession } from '../../../types/index.js';
import { api } from '../../../services/api.js';
import { useToast } from '../../../context/ToastContext.js';

interface AcademicSessionsTabProps {
  sessions: AcademicSession[];
  onRefresh: () => Promise<void>;
}

export const AcademicSessionsTab: React.FC<AcademicSessionsTabProps> = ({ sessions = [], onRefresh }) => {
  const { showToast } = useToast();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');

  // Modal States
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [editingSession, setEditingSession] = useState<AcademicSession | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Form State
  const [formData, setFormData] = useState({
    sessionName: '',
    startDate: '',
    endDate: '',
    terms: 'Term 1 / Fall, Term 2 / Spring',
    description: '',
    isActive: false,
    status: 'upcoming' as 'active' | 'upcoming' | 'archived' | 'completed'
  });
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});

  // Confirmation States
  const [actionSession, setActionSession] = useState<AcademicSession | null>(null);
  const [confirmAction, setConfirmAction] = useState<'activate' | 'archive' | 'delete' | null>(null);
  const [isActionLoading, setIsActionLoading] = useState(false);

  const openCreateModal = () => {
    setEditingSession(null);
    setFormData({
      sessionName: '',
      startDate: '',
      endDate: '',
      terms: 'Term 1 / Fall, Term 2 / Spring',
      description: '',
      isActive: false,
      status: 'upcoming'
    });
    setFormErrors({});
    setIsCreateOpen(true);
  };

  const openEditModal = (session: AcademicSession) => {
    setEditingSession(session);
    setFormData({
      sessionName: session.sessionName || session.name || '',
      startDate: session.startDate || '',
      endDate: session.endDate || '',
      terms: Array.isArray(session.terms) ? session.terms.join(', ') : 'Term 1, Term 2',
      description: session.description || '',
      isActive: Boolean(session.isActive || session.isCurrent),
      status: (session.status?.toLowerCase() as any) || 'active'
    });
    setFormErrors({});
    setIsCreateOpen(true);
  };

  const validateForm = () => {
    const errors: Record<string, string> = {};
    if (!formData.sessionName.trim()) {
      errors.sessionName = 'Session name is required (e.g., 2026-2027 Academic Year).';
    }
    if (!formData.startDate) {
      errors.startDate = 'Start date is required.';
    }
    if (!formData.endDate) {
      errors.endDate = 'End date is required.';
    }
    if (formData.startDate && formData.endDate && new Date(formData.startDate) >= new Date(formData.endDate)) {
      errors.endDate = 'End date must be strictly after start date.';
    }
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    try {
      setIsSubmitting(true);
      const termsArray = formData.terms
        .split(',')
        .map((t) => t.trim())
        .filter(Boolean);

      const payload = {
        sessionName: formData.sessionName.trim(),
        startDate: formData.startDate,
        endDate: formData.endDate,
        terms: termsArray.length > 0 ? termsArray : ['Term 1', 'Term 2'],
        description: formData.description.trim(),
        isActive: formData.isActive,
        status: formData.isActive ? ('active' as const) : formData.status
      };

      if (editingSession) {
        const res = await api.academic.updateSession(editingSession.id, payload);
        if (res.success) {
          showToast('Academic Session Updated', `Session '${payload.sessionName}' updated successfully.`, 'success');
          setIsCreateOpen(false);
          await onRefresh();
        } else {
          showToast('Update Failed', res.error || 'Failed to update academic session.', 'error');
        }
      } else {
        const res = await api.academic.createSession(payload);
        if (res.success) {
          showToast('Academic Session Created', `New session '${payload.sessionName}' has been added.`, 'success');
          setIsCreateOpen(false);
          await onRefresh();
        } else {
          showToast('Creation Failed', res.error || 'Failed to create academic session.', 'error');
        }
      }
    } catch (err: any) {
      showToast('Error', err.message || 'An unexpected error occurred.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleConfirmAction = async () => {
    if (!actionSession || !confirmAction) return;

    try {
      setIsActionLoading(true);
      if (confirmAction === 'activate') {
        const res = await api.academic.activateSession(actionSession.id);
        if (res.success) {
          showToast('Session Activated', `'${actionSession.sessionName || actionSession.name}' is now the current active session.`, 'success');
          await onRefresh();
        } else {
          showToast('Activation Failed', res.error || 'Could not activate session.', 'error');
        }
      } else if (confirmAction === 'archive') {
        const res = await api.academic.archiveSession(actionSession.id);
        if (res.success) {
          showToast('Session Archived', `'${actionSession.sessionName || actionSession.name}' was moved to archived records.`, 'info');
          await onRefresh();
        } else {
          showToast('Archive Failed', res.error || 'Could not archive session.', 'error');
        }
      } else if (confirmAction === 'delete') {
        const res = await api.academic.deleteSession(actionSession.id);
        if (res.success) {
          showToast('Session Deleted', `'${actionSession.sessionName || actionSession.name}' was permanently removed.`, 'success');
          await onRefresh();
        } else {
          showToast('Deletion Blocked', res.error || 'Could not delete session.', 'error');
        }
      }
    } catch (err: any) {
      showToast('Action Failed', err.message || 'Network error occurred.', 'error');
    } finally {
      setIsActionLoading(false);
      setActionSession(null);
      setConfirmAction(null);
    }
  };

  // Filtered list
  const filteredSessions = sessions.filter((s) => {
    const name = (s.sessionName || s.name || '').toLowerCase();
    const matchesSearch = name.includes(search.toLowerCase()) || s.startDate?.includes(search) || s.endDate?.includes(search);
    if (!matchesSearch) return false;

    if (statusFilter === 'ALL') return true;
    if (statusFilter === 'ACTIVE') return s.isActive || s.isCurrent || s.status?.toLowerCase() === 'active';
    if (statusFilter === 'UPCOMING') return s.status?.toLowerCase() === 'upcoming';
    if (statusFilter === 'ARCHIVED') return s.isArchived || s.status?.toLowerCase() === 'archived';
    if (statusFilter === 'COMPLETED') return s.status?.toLowerCase() === 'completed';
    return true;
  });

  const activeSession = (sessions || []).find((s) => s?.isActive || s?.isCurrent);

  const columns: Column<AcademicSession>[] = [
    {
      header: 'Academic Session',
      accessor: (row) => (
        <div>
          <div className="font-semibold text-white flex items-center gap-2">
            <span>{row.sessionName || row.name}</span>
            {(row.isActive || row.isCurrent) && (
              <span className="px-2 py-0.5 text-[10px] bg-emerald-500/20 text-emerald-300 rounded-md border border-emerald-500/30 font-bold tracking-wide">
                CURRENT ACTIVE
              </span>
            )}
          </div>
          {row.description && <div className="text-xs text-slate-400 mt-0.5 max-w-sm line-clamp-1">{row.description}</div>}
        </div>
      )
    },
    {
      header: 'Timeline',
      accessor: (row) => (
        <div className="text-xs">
          <div className="font-mono text-slate-200">
            {row.startDate} <span className="text-slate-500">→</span> {row.endDate}
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">
            {Math.max(1, Math.round((new Date(row.endDate).getTime() - new Date(row.startDate).getTime()) / (1000 * 60 * 60 * 24 * 30)))} Months Cycle
          </div>
        </div>
      )
    },
    {
      header: 'Terms / Semesters',
      accessor: (row) => (
        <div className="flex flex-wrap gap-1">
          {Array.isArray(row.terms) && row.terms.length > 0 ? (
            row.terms.map((term, i) => (
              <span
                key={i}
                className="px-2 py-0.5 rounded-md bg-white/5 border border-white/10 text-slate-300 text-xs"
              >
                {term}
              </span>
            ))
          ) : (
            <span className="text-xs text-slate-500 italic">Standard 2 Terms</span>
          )}
        </div>
      )
    },
    {
      header: 'Status',
      accessor: (row) => {
        const isCurrent = row.isActive || row.isCurrent;
        const normalized = (row.status || '').toUpperCase();
        return (
          <Badge
            variant={
              isCurrent || normalized === 'ACTIVE'
                ? 'success'
                : normalized === 'UPCOMING'
                ? 'info'
                : normalized === 'ARCHIVED'
                ? 'secondary'
                : 'warning'
            }
            dot
          >
            {isCurrent ? 'ACTIVE' : normalized || 'PLANNED'}
          </Badge>
        );
      }
    },
    {
      header: 'Actions',
      accessor: (row) => {
        const isCurrent = row.isActive || row.isCurrent;
        return (
          <div className="flex items-center gap-1.5">
            {!isCurrent && (
              <Button
                size="xs"
                variant="subtle"
                onClick={() => {
                  setActionSession(row);
                  setConfirmAction('activate');
                }}
                title="Set as current active school session"
              >
                <Check className="w-3.5 h-3.5" />
                <span>Make Active</span>
              </Button>
            )}
            <Button
              size="xs"
              variant="outline"
              onClick={() => openEditModal(row)}
              title="Edit session details"
            >
              <Edit2 className="w-3.5 h-3.5" />
            </Button>
            {!isCurrent && !row.isArchived && (
              <Button
                size="xs"
                variant="ghost"
                onClick={() => {
                  setActionSession(row);
                  setConfirmAction('archive');
                }}
                title="Archive session"
              >
                <Archive className="w-3.5 h-3.5 text-slate-400 hover:text-amber-400" />
              </Button>
            )}
            {!isCurrent && (
              <Button
                size="xs"
                variant="ghost"
                onClick={() => {
                  setActionSession(row);
                  setConfirmAction('delete');
                }}
                title="Delete session"
              >
                <Trash2 className="w-3.5 h-3.5 text-slate-400 hover:text-rose-400" />
              </Button>
            )}
          </div>
        );
      }
    }
  ];

  return (
    <div className="space-y-6">
      {/* Overview Metric Banners */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-blue-700 text-xs font-semibold uppercase tracking-wider mb-2">
            <span>Current Active Session</span>
            <Sparkles className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-xl font-bold text-slate-900 tracking-tight">
            {activeSession ? activeSession.sessionName || activeSession.name : 'Not Configured'}
          </div>
          <div className="text-xs text-slate-600 mt-1">
            {activeSession ? `${activeSession.startDate} to ${activeSession.endDate}` : 'Please set an active session'}
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold uppercase tracking-wider mb-2">
            <span>Total Sessions</span>
            <Calendar className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900 tracking-tight">{sessions.length}</div>
          <div className="text-xs text-slate-600 mt-1">Managed calendar cycles</div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold uppercase tracking-wider mb-2">
            <span>Upcoming / Planned</span>
            <Clock className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900 tracking-tight">
            {sessions.filter((s) => s.status?.toLowerCase() === 'upcoming').length}
          </div>
          <div className="text-xs text-slate-600 mt-1">Future academic terms ready</div>
        </div>
      </div>

      {/* Control Bar: Search, Filters & Action */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
        <div className="flex flex-1 items-center gap-3">
          <div className="max-w-md w-full">
            <Input
              id="session-search-input"
              placeholder="Search academic sessions..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              leftIcon={<Search className="w-4 h-4" />}
            />
          </div>
          <div className="w-44">
            <Select
              id="session-status-filter"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              options={[
                { value: 'ALL', label: 'All Statuses' },
                { value: 'ACTIVE', label: 'Active Session' },
                { value: 'UPCOMING', label: 'Upcoming' },
                { value: 'COMPLETED', label: 'Completed' },
                { value: 'ARCHIVED', label: 'Archived' }
              ]}
            />
          </div>
        </div>

        <Button
          id="btn-create-session"
          variant="primary"
          onClick={openCreateModal}
          leftIcon={<Plus className="w-4 h-4" />}
        >
          New Academic Session
        </Button>
      </div>

      {/* Table / Empty State */}
      {filteredSessions.length === 0 ? (
        <EmptyState
          icon={<Calendar className="w-8 h-8 text-indigo-400" />}
          title="No Academic Sessions Found"
          description={
            search || statusFilter !== 'ALL'
              ? 'No academic sessions matched your search filters.'
              : 'Define your first school academic year or calendar term to begin organizing student enrollments.'
          }
          actionLabel={search || statusFilter !== 'ALL' ? undefined : 'Create Academic Session'}
          onAction={openCreateModal}
        />
      ) : (
        <Table columns={columns} data={filteredSessions} keyExtractor={(s) => s.id} />
      )}

      {/* Create / Edit Modal */}
      <Modal
        isOpen={isCreateOpen}
        onClose={() => setIsCreateOpen(false)}
        title={editingSession ? 'Edit Academic Session' : 'Create Academic Session'}
        description="Configure academic calendar cycle, date spans, and term partitions."
        size="md"
        id="session-form-modal"
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <Input
            id="session-name"
            label="Session Name *"
            placeholder="e.g. 2026-2027 Academic Year"
            value={formData.sessionName}
            onChange={(e) => setFormData({ ...formData, sessionName: e.target.value })}
            error={formErrors.sessionName}
            helperText="Clear naming helps staff, students, and parents identify the term."
          />

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input
              id="session-start-date"
              type="date"
              label="Start Date *"
              value={formData.startDate}
              onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
              error={formErrors.startDate}
            />
            <Input
              id="session-end-date"
              type="date"
              label="End Date *"
              value={formData.endDate}
              onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
              error={formErrors.endDate}
            />
          </div>

          <Input
            id="session-terms"
            label="Terms / Semesters (Comma-Separated)"
            placeholder="Term 1 / Fall, Term 2 / Spring, Summer Term"
            value={formData.terms}
            onChange={(e) => setFormData({ ...formData, terms: e.target.value })}
            helperText="Specify the academic periods or semesters within this session."
          />

          <div className="w-full">
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              Description / Notes
            </label>
            <textarea
              id="session-description"
              rows={2}
              className="block w-full rounded-xl border border-white/10 bg-slate-900/60 text-slate-100 placeholder-slate-500 focus:border-indigo-500 focus:ring-indigo-500/30 p-3 text-sm"
              placeholder="Optional notes regarding session guidelines or regional mandates..."
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            />
          </div>

          <div className="p-4 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-between">
            <div>
              <div className="font-semibold text-white text-sm">Set as Current Active Session</div>
              <div className="text-xs text-slate-400">
                Making this active will set all school operations and new enrollments to this session.
              </div>
            </div>
            <input
              id="session-is-active-toggle"
              type="checkbox"
              checked={formData.isActive}
              onChange={(e) => setFormData({ ...formData, isActive: e.target.checked })}
              className="w-5 h-5 accent-indigo-600 rounded cursor-pointer"
            />
          </div>

          <div className="pt-4 border-t border-white/10 flex items-center justify-end gap-3">
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => setIsCreateOpen(false)}
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              variant="primary"
              size="sm"
              isLoading={isSubmitting}
            >
              {editingSession ? 'Save Changes' : 'Create Session'}
            </Button>
          </div>
        </form>
      </Modal>

      {/* Confirmation Dialogs */}
      <ConfirmDialog
        isOpen={Boolean(confirmAction)}
        onClose={() => {
          setConfirmAction(null);
          setActionSession(null);
        }}
        onConfirm={handleConfirmAction}
        isLoading={isActionLoading}
        title={
          confirmAction === 'activate'
            ? 'Activate Academic Session?'
            : confirmAction === 'archive'
            ? 'Archive Academic Session?'
            : 'Delete Academic Session?'
        }
        message={
          confirmAction === 'activate'
            ? `Setting '${actionSession?.sessionName || actionSession?.name}' as the active session will make it the default session across all modules, classes, and student enrollments.`
            : confirmAction === 'archive'
            ? `Archiving '${actionSession?.sessionName || actionSession?.name}' will preserve all existing historical logs but mark it inactive for future enrollments.`
            : `Are you sure you want to permanently delete '${actionSession?.sessionName || actionSession?.name}'? This action cannot be undone.`
        }
        confirmLabel={
          confirmAction === 'activate'
            ? 'Activate Session'
            : confirmAction === 'archive'
            ? 'Archive Record'
            : 'Delete Session'
        }
        variant={confirmAction === 'delete' ? 'danger' : confirmAction === 'archive' ? 'warning' : 'primary'}
      />
    </div>
  );
};
