import React, { useState } from 'react';
import {
  Layers,
  Plus,
  Edit2,
  Archive,
  Trash2,
  Users,
  Search,
  ExternalLink,
  BookOpen,
  Sparkles,
  Building
} from 'lucide-react';
import { Table, Column } from '../../../components/ui/Table.js';
import { Badge } from '../../../components/ui/Badge.js';
import { Button } from '../../../components/ui/Button.js';
import { Modal } from '../../../components/ui/Modal.js';
import { Input } from '../../../components/ui/Input.js';
import { Select } from '../../../components/ui/Select.js';
import { ConfirmDialog } from '../../../components/ui/ConfirmDialog.js';
import { EmptyState } from '../../../components/ui/EmptyState.js';
import { SchoolClass, Section } from '../../../types/index.js';
import { api } from '../../../services/api.js';
import { useToast } from '../../../context/ToastContext.js';

interface ClassesTabProps {
  classes: SchoolClass[];
  sections: Section[];
  onRefresh: () => Promise<void>;
  onNavigateToSections?: (classId?: string) => void;
}

export const ClassesTab: React.FC<ClassesTabProps> = ({
  classes = [],
  sections = [],
  onRefresh,
  onNavigateToSections
}) => {
  const { showToast } = useToast();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'ACTIVE' | 'ARCHIVED'>('ALL');

  // Modal States
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingClass, setEditingClass] = useState<SchoolClass | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Inspector Modal State
  const [inspectClass, setInspectClass] = useState<SchoolClass | null>(null);

  // Form State
  const [formData, setFormData] = useState({
    name: '',
    code: '',
    numericGrade: '10',
    displayOrder: '1',
    description: '',
    status: 'active' as 'active' | 'archived'
  });
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});

  // Action / Confirm States
  const [actionClass, setActionClass] = useState<SchoolClass | null>(null);
  const [confirmAction, setConfirmAction] = useState<'archive' | 'delete' | null>(null);
  const [isActionLoading, setIsActionLoading] = useState(false);

  const openCreateModal = () => {
    setEditingClass(null);
    setFormData({
      name: '',
      code: '',
      numericGrade: String(classes.length + 1),
      displayOrder: String(classes.length + 1),
      description: '',
      status: 'active'
    });
    setFormErrors({});
    setIsFormOpen(true);
  };

  const openEditModal = (cls: SchoolClass) => {
    setEditingClass(cls);
    setFormData({
      name: cls.name,
      code: cls.code,
      numericGrade: String(cls.numericGrade || ''),
      displayOrder: String(cls.displayOrder || 1),
      description: cls.description || '',
      status: cls.status || 'active'
    });
    setFormErrors({});
    setIsFormOpen(true);
  };

  const validateForm = () => {
    const errors: Record<string, string> = {};
    if (!formData.name.trim()) {
      errors.name = 'Class name is required (e.g., Grade 10, Class 8).';
    }
    if (!formData.code.trim()) {
      errors.code = 'Class code is required (e.g., G10, CLS-8).';
    }
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    try {
      setIsSubmitting(true);
      const payload = {
        name: formData.name.trim(),
        code: formData.code.trim().toUpperCase(),
        numericGrade: formData.numericGrade ? Number(formData.numericGrade) : undefined,
        displayOrder: Number(formData.displayOrder) || 1,
        description: formData.description.trim(),
        status: formData.status
      };

      if (editingClass) {
        const res = await api.academic.updateClass(editingClass.id, payload);
        if (res.success) {
          showToast('Class Updated', `Grade tier '${payload.name}' was updated successfully.`, 'success');
          setIsFormOpen(false);
          await onRefresh();
        } else {
          showToast('Update Failed', res.error || 'Failed to update class.', 'error');
        }
      } else {
        const res = await api.academic.createClass(payload);
        if (res.success) {
          showToast('Class Created', `Grade tier '${payload.name}' has been added.`, 'success');
          setIsFormOpen(false);
          await onRefresh();
        } else {
          showToast('Creation Failed', res.error || 'Failed to create class.', 'error');
        }
      }
    } catch (err: any) {
      showToast('Error', err.message || 'An unexpected error occurred.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleConfirmAction = async () => {
    if (!actionClass || !confirmAction) return;

    try {
      setIsActionLoading(true);
      if (confirmAction === 'archive') {
        const res = await api.academic.archiveClass(actionClass.id);
        if (res.success) {
          showToast('Class Archived', `'${actionClass.name}' has been archived.`, 'info');
          await onRefresh();
        } else {
          showToast('Archive Blocked', res.error || 'Could not archive class.', 'error');
        }
      } else if (confirmAction === 'delete') {
        const res = await api.academic.deleteClass(actionClass.id);
        if (res.success) {
          showToast('Class Deleted', `'${actionClass.name}' was permanently deleted.`, 'success');
          await onRefresh();
        } else {
          showToast('Deletion Blocked', res.error || 'Could not delete class.', 'error');
        }
      }
    } catch (err: any) {
      showToast('Action Failed', err.message || 'Network error occurred.', 'error');
    } finally {
      setIsActionLoading(false);
      setActionClass(null);
      setConfirmAction(null);
    }
  };

  // Filtered classes
  const filteredClasses = classes.filter((c) => {
    const q = (search || '').toLowerCase();
    const matchesSearch =
      (c.name || '').toLowerCase().includes(q) ||
      (c.code || '').toLowerCase().includes(q) ||
      (c.description ? c.description.toLowerCase().includes(q) : false);

    if (!matchesSearch) return false;
    if (statusFilter === 'ACTIVE') return c.status === 'active';
    if (statusFilter === 'ARCHIVED') return c.status === 'archived';
    return true;
  });

  // Calculate totals
  const totalCapacity = classes.reduce((acc, c) => {
    const cap = c.sections?.reduce((sAcc, s) => sAcc + (s.capacity || 0), 0) || 0;
    return acc + cap;
  }, 0);

  const totalEnrolled = classes.reduce((acc, c) => {
    const enrolled = c.sections?.reduce((sAcc, s) => sAcc + (s.studentCount || 0), 0) || 0;
    return acc + enrolled;
  }, 0);

  const totalSectionsCount = sections.length;

  const columns: Column<SchoolClass>[] = [
    {
      header: 'Grade / Class Name',
      accessor: (row) => (
        <div>
          <div className="font-semibold text-white flex items-center gap-2">
            <span>{row.name}</span>
            <span className="px-2 py-0.5 text-[10px] font-mono bg-white/10 text-slate-300 rounded border border-white/10 font-bold">
              {row.code}
            </span>
          </div>
          {row.description && <div className="text-xs text-slate-400 mt-0.5 line-clamp-1">{row.description}</div>}
        </div>
      )
    },
    {
      header: 'Grade Level & Order',
      accessor: (row) => (
        <div className="text-xs text-slate-300">
          <div className="font-medium text-slate-200">
            {row.numericGrade ? `Grade ${row.numericGrade}` : 'Standard Grade'}
          </div>
          <div className="text-[11px] text-slate-400 font-mono">Order: #{row.displayOrder || 1}</div>
        </div>
      )
    },
    {
      header: 'Assigned Sections',
      accessor: (row) => {
        const classSections = row.sections || sections.filter((s) => s.classId === row.id);
        return (
          <div className="flex flex-wrap items-center gap-1.5">
            {classSections.length > 0 ? (
              classSections.map((sec) => (
                <button
                  key={sec.id}
                  onClick={() => setInspectClass(row)}
                  className="px-2 py-0.5 rounded-lg bg-indigo-500/15 text-indigo-300 border border-indigo-500/25 text-xs font-semibold hover:bg-indigo-500/30 transition-all cursor-pointer"
                  title="Click to view section details"
                >
                  Sec {sec.name} ({sec.studentCount || 0})
                </button>
              ))
            ) : (
              <span className="text-xs text-slate-500 italic">No sections created</span>
            )}
          </div>
        );
      }
    },
    {
      header: 'Capacity & Enrollment',
      accessor: (row) => {
        const classSections = row.sections || sections.filter((s) => s.classId === row.id);
        const total = classSections.reduce((acc, s) => acc + (s.capacity || 0), 0);
        const current = classSections.reduce((acc, s) => acc + (s.studentCount || 0), 0);
        const percentage = total > 0 ? Math.min(100, Math.round((current / total) * 100)) : 0;

        return (
          <div className="min-w-[130px]">
            <div className="flex items-center justify-between text-xs mb-1">
              <span className="text-slate-300 font-medium">{current} / {total || '—'} Enrolled</span>
              <span className="text-slate-400 text-[11px] font-mono">{percentage}%</span>
            </div>
            <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden">
              <div
                className={`h-full rounded-full transition-all duration-300 ${
                  percentage >= 95 ? 'bg-rose-500' : percentage >= 80 ? 'bg-amber-500' : 'bg-indigo-500'
                }`}
                style={{ width: `${percentage}%` }}
              />
            </div>
          </div>
        );
      }
    },
    {
      header: 'Status',
      accessor: (row) => (
        <Badge variant={row.status === 'active' ? 'success' : 'secondary'} dot>
          {row.status ? row.status.toUpperCase() : 'ACTIVE'}
        </Badge>
      )
    },
    {
      header: 'Actions',
      accessor: (row) => (
        <div className="flex items-center gap-1.5">
          <Button
            size="xs"
            variant="outline"
            onClick={() => setInspectClass(row)}
            title="Inspect sections and capacity breakdown"
          >
            Inspect
          </Button>
          <Button
            size="xs"
            variant="ghost"
            onClick={() => openEditModal(row)}
            title="Edit class settings"
          >
            <Edit2 className="w-3.5 h-3.5" />
          </Button>
          {row.status !== 'archived' && (
            <Button
              size="xs"
              variant="ghost"
              onClick={() => {
                setActionClass(row);
                setConfirmAction('archive');
              }}
              title="Archive class"
            >
              <Archive className="w-3.5 h-3.5 text-slate-400 hover:text-amber-400" />
            </Button>
          )}
          <Button
            size="xs"
            variant="ghost"
            onClick={() => {
              setActionClass(row);
              setConfirmAction('delete');
            }}
            title="Delete class"
          >
            <Trash2 className="w-3.5 h-3.5 text-slate-400 hover:text-rose-400" />
          </Button>
        </div>
      )
    }
  ];

  return (
    <div className="space-y-6">
      {/* Metric Banners */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="bg-white/5 p-5 rounded-2xl border border-white/10 shadow-md">
          <div className="flex items-center justify-between text-slate-400 text-xs font-semibold uppercase tracking-wider mb-2">
            <span>Total Classes</span>
            <Layers className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="text-2xl font-bold text-white tracking-tight">{classes.length}</div>
          <div className="text-xs text-slate-400 mt-1">Grade levels defined</div>
        </div>

        <div className="bg-white/5 p-5 rounded-2xl border border-white/10 shadow-md">
          <div className="flex items-center justify-between text-slate-400 text-xs font-semibold uppercase tracking-wider mb-2">
            <span>Active Classes</span>
            <Sparkles className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold text-emerald-400 tracking-tight">
            {classes.filter((c) => c.status === 'active').length}
          </div>
          <div className="text-xs text-slate-400 mt-1">Available for student entry</div>
        </div>

        <div className="bg-white/5 p-5 rounded-2xl border border-white/10 shadow-md">
          <div className="flex items-center justify-between text-slate-400 text-xs font-semibold uppercase tracking-wider mb-2">
            <span>Sections Count</span>
            <Building className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-bold text-white tracking-tight">{totalSectionsCount}</div>
          <div className="text-xs text-slate-400 mt-1">Classroom cohorts</div>
        </div>

        <div className="bg-white/5 p-5 rounded-2xl border border-white/10 shadow-md">
          <div className="flex items-center justify-between text-slate-400 text-xs font-semibold uppercase tracking-wider mb-2">
            <span>Total Class Capacity</span>
            <Users className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-bold text-white tracking-tight">
            {totalEnrolled} <span className="text-xs font-normal text-slate-400">/ {totalCapacity}</span>
          </div>
          <div className="text-xs text-slate-400 mt-1">Across all active classrooms</div>
        </div>
      </div>

      {/* Control Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
        <div className="flex flex-1 items-center gap-3">
          <div className="max-w-md w-full">
            <Input
              id="class-search-input"
              placeholder="Search classes by name or code..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              leftIcon={<Search className="w-4 h-4" />}
            />
          </div>
          <div className="w-40">
            <Select
              id="class-status-filter"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
              options={[
                { value: 'ALL', label: 'All Statuses' },
                { value: 'ACTIVE', label: 'Active Only' },
                { value: 'ARCHIVED', label: 'Archived' }
              ]}
            />
          </div>
        </div>

        <Button
          id="btn-create-class"
          variant="primary"
          onClick={openCreateModal}
          leftIcon={<Plus className="w-4 h-4" />}
        >
          New Grade / Class
        </Button>
      </div>

      {/* Table / Empty State */}
      {filteredClasses.length === 0 ? (
        <EmptyState
          icon={<Layers className="w-8 h-8 text-indigo-400" />}
          title="No Classes Found"
          description={
            search || statusFilter !== 'ALL'
              ? 'No classes match your search query.'
              : 'Add your first class or grade level tier to begin configuring your school structure.'
          }
          actionLabel={search || statusFilter !== 'ALL' ? undefined : 'Add Class'}
          onAction={openCreateModal}
        />
      ) : (
        <Table columns={columns} data={filteredClasses} keyExtractor={(c) => c.id} />
      )}

      {/* Create / Edit Modal */}
      <Modal
        isOpen={isFormOpen}
        onClose={() => setIsFormOpen(false)}
        title={editingClass ? 'Edit Grade / Class Tier' : 'Create Grade / Class Tier'}
        description="Establish grade levels, hierarchy ordering, and unique academic class codes."
        size="md"
        id="class-form-modal"
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <Input
            id="class-name-input"
            label="Class Name *"
            placeholder="e.g. Grade 10 or Kindergarten"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            error={formErrors.name}
          />

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input
              id="class-code-input"
              label="Class Code *"
              placeholder="e.g. G10"
              value={formData.code}
              onChange={(e) => setFormData({ ...formData, code: e.target.value })}
              error={formErrors.code}
              helperText="Unique uppercase identifier for reporting."
            />
            <Input
              id="class-numeric-grade"
              type="number"
              label="Numeric Grade Level"
              placeholder="e.g. 10"
              value={formData.numericGrade}
              onChange={(e) => setFormData({ ...formData, numericGrade: e.target.value })}
              helperText="Used for automated sequential student progression."
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input
              id="class-display-order"
              type="number"
              label="Display Order"
              placeholder="1"
              value={formData.displayOrder}
              onChange={(e) => setFormData({ ...formData, displayOrder: e.target.value })}
              helperText="Sort priority in dropdown menus."
            />
            <Select
              id="class-status-select"
              label="Status"
              value={formData.status}
              onChange={(e) => setFormData({ ...formData, status: e.target.value as any })}
              options={[
                { value: 'active', label: 'Active' },
                { value: 'archived', label: 'Archived' }
              ]}
            />
          </div>

          <div className="w-full">
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              Class Description
            </label>
            <textarea
              id="class-description-input"
              rows={2}
              className="block w-full rounded-xl border border-white/10 bg-slate-900/60 text-slate-100 placeholder-slate-500 focus:border-indigo-500 focus:ring-indigo-500/30 p-3 text-sm"
              placeholder="Optional notes regarding curriculum track or age brackets..."
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            />
          </div>

          <div className="pt-4 border-t border-white/10 flex items-center justify-end gap-3">
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => setIsFormOpen(false)}
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              variant="primary"
              size="sm"
              isLoading={isSubmitting}
            >
              {editingClass ? 'Save Changes' : 'Create Class'}
            </Button>
          </div>
        </form>
      </Modal>

      {/* Class Sections Inspector Modal */}
      {inspectClass && (
        <Modal
          isOpen={Boolean(inspectClass)}
          onClose={() => setInspectClass(null)}
          title={`Grade Cohorts: ${inspectClass.name}`}
          description={`Class Code: ${inspectClass.code} • Total Cohorts: ${
            (inspectClass.sections || (sections || []).filter((s) => s?.classId === inspectClass.id)).length
          }`}
          size="lg"
          id="class-inspect-modal"
        >
          <div className="space-y-5">
            {(() => {
              const classSections = inspectClass.sections || (sections || []).filter((s) => s?.classId === inspectClass.id);
              if (classSections.length === 0) {
                return (
                  <div className="p-8 text-center rounded-2xl bg-white/5 border border-white/10">
                    <p className="text-sm text-slate-300">No active sections assigned to this class yet.</p>
                    <p className="text-xs text-slate-400 mt-1">
                      Navigate to the Sections tab to add sections such as Section A, Section B.
                    </p>
                  </div>
                );
              }

              return (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {(classSections || []).map((sec) => (
                    <div
                      key={sec.id}
                      className="bg-white/5 border border-white/10 rounded-2xl p-4 space-y-3 hover:border-indigo-500/30 transition-all"
                    >
                      <div className="flex items-center justify-between">
                        <div className="font-bold text-white text-base">Section {sec.name}</div>
                        <Badge variant="primary">{sec.roomNumber ? `Room ${sec.roomNumber}` : 'General Hall'}</Badge>
                      </div>

                      <div className="space-y-1 text-xs">
                        <div className="flex justify-between text-slate-400">
                          <span>Assigned Class Teacher:</span>
                          <span className="font-medium text-slate-200">
                            {sec.classTeacherName || 'Dr. Elena Vance'}
                          </span>
                        </div>
                        <div className="flex justify-between text-slate-400">
                          <span>Enrollment:</span>
                          <span className="font-mono text-emerald-300 font-semibold">
                            {sec.studentCount || 0} / {sec.capacity} students
                          </span>
                        </div>
                      </div>

                      <div className="w-full bg-white/10 h-2 rounded-full overflow-hidden">
                        <div
                          className="bg-emerald-500 h-full rounded-full transition-all duration-300"
                          style={{
                            width: `${Math.min(100, Math.round(((sec.studentCount || 0) / (sec.capacity || 1)) * 100))}%`
                          }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              );
            })()}

            <div className="pt-4 border-t border-white/10 flex items-center justify-between">
              {onNavigateToSections && (
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => {
                    const cId = inspectClass.id;
                    setInspectClass(null);
                    onNavigateToSections(cId);
                  }}
                  leftIcon={<ExternalLink className="w-3.5 h-3.5" />}
                >
                  Manage in Sections Tab
                </Button>
              )}
              <div className="flex-1 flex justify-end">
                <Button size="sm" variant="primary" onClick={() => setInspectClass(null)}>
                  Close
                </Button>
              </div>
            </div>
          </div>
        </Modal>
      )}

      {/* Confirmation Dialog */}
      <ConfirmDialog
        isOpen={Boolean(confirmAction)}
        onClose={() => {
          setConfirmAction(null);
          setActionClass(null);
        }}
        onConfirm={handleConfirmAction}
        isLoading={isActionLoading}
        title={confirmAction === 'archive' ? 'Archive Grade Tier?' : 'Delete Grade Tier?'}
        message={
          confirmAction === 'archive'
            ? `Archiving '${actionClass?.name}' will retain historical student logs but remove this grade tier from active enrollment dropdowns.`
            : `Are you sure you want to delete '${actionClass?.name}' (${actionClass?.code})? Deletion is blocked if sections or enrolled students are attached.`
        }
        confirmLabel={confirmAction === 'archive' ? 'Archive Class' : 'Delete Class'}
        variant={confirmAction === 'delete' ? 'danger' : 'warning'}
      />
    </div>
  );
};
