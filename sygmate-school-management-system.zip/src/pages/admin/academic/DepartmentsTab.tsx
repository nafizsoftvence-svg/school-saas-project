import React, { useState } from 'react';
import {
  GraduationCap,
  Plus,
  Edit2,
  Archive,
  Trash2,
  Search,
  BookOpen,
  Users,
  Sparkles,
  Building
} from 'lucide-react';
import { Table, Column } from '../../../components/ui/Table.js';
import { Badge } from '../../../components/ui/Badge.js';
import { Button } from '../../../components/ui/Button.js';
import { Modal } from '../../../components/ui/Modal.js';
import { Input } from '../../../components/ui/Input.js';
import { Select } from '../../../components/ui/Select.js';
import { ConfirmDialog } from '../../../components/ui/ConfirmDialog.js';
import { EmptyState } from '../../../components/ui/EmptyState.js';
import { Department, Teacher, Subject } from '../../../types/index.js';
import { api } from '../../../services/api.js';
import { useToast } from '../../../context/ToastContext.js';

interface DepartmentsTabProps {
  departments: Department[];
  teachers: Teacher[];
  subjects: Subject[];
  onRefresh: () => Promise<void>;
}

export const DepartmentsTab: React.FC<DepartmentsTabProps> = ({
  departments = [],
  teachers = [],
  subjects = [],
  onRefresh
}) => {
  const { showToast } = useToast();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'ACTIVE' | 'ARCHIVED'>('ALL');

  // Modal States
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingDept, setEditingDept] = useState<Department | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Form State
  const [formData, setFormData] = useState({
    name: '',
    code: '',
    headOfDepartmentId: '',
    description: '',
    status: 'active' as 'active' | 'archived'
  });
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});

  // Action Confirmation
  const [actionDept, setActionDept] = useState<Department | null>(null);
  const [confirmAction, setConfirmAction] = useState<'archive' | 'delete' | null>(null);
  const [isActionLoading, setIsActionLoading] = useState(false);

  const openCreateModal = () => {
    setEditingDept(null);
    setFormData({
      name: '',
      code: '',
      headOfDepartmentId: '',
      description: '',
      status: 'active'
    });
    setFormErrors({});
    setIsFormOpen(true);
  };

  const openEditModal = (dept: Department) => {
    setEditingDept(dept);
    setFormData({
      name: dept.name,
      code: dept.code,
      headOfDepartmentId: dept.headOfDepartmentId || '',
      description: dept.description || '',
      status: dept.status || 'active'
    });
    setFormErrors({});
    setIsFormOpen(true);
  };

  const validateForm = () => {
    const errors: Record<string, string> = {};
    if (!formData.name.trim()) {
      errors.name = 'Department name is required (e.g., Department of Mathematics).';
    }
    if (!formData.code.trim()) {
      errors.code = 'Department code is required (e.g., DEP-MTH).';
    }
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    try {
      setIsSubmitting(true);
      const selectedHead = (teachers || []).find((t) => t?.id === formData.headOfDepartmentId || t?.userId === formData.headOfDepartmentId);

      const payload = {
        name: formData.name.trim(),
        code: formData.code.trim().toUpperCase(),
        headOfDepartmentId: formData.headOfDepartmentId || undefined,
        headOfDepartmentName: selectedHead ? `${selectedHead.firstName} ${selectedHead.lastName}` : undefined,
        description: formData.description.trim(),
        status: formData.status
      };

      if (editingDept) {
        const res = await api.academic.updateDepartment(editingDept.id, payload);
        if (res.success) {
          showToast('Department Updated', `Department '${payload.name}' was updated successfully.`, 'success');
          setIsFormOpen(false);
          await onRefresh();
        } else {
          showToast('Update Failed', res.error || 'Failed to update department.', 'error');
        }
      } else {
        const res = await api.academic.createDepartment(payload);
        if (res.success) {
          showToast('Department Created', `Department '${payload.name}' has been created.`, 'success');
          setIsFormOpen(false);
          await onRefresh();
        } else {
          showToast('Creation Failed', res.error || 'Failed to create department.', 'error');
        }
      }
    } catch (err: any) {
      showToast('Error', err.message || 'An unexpected error occurred.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleConfirmAction = async () => {
    if (!actionDept || !confirmAction) return;

    try {
      setIsActionLoading(true);
      if (confirmAction === 'archive') {
        const res = await api.academic.archiveDepartment(actionDept.id);
        if (res.success) {
          showToast('Department Archived', `'${actionDept.name}' is now archived.`, 'info');
          await onRefresh();
        } else {
          showToast('Archive Failed', res.error || 'Could not archive department.', 'error');
        }
      } else if (confirmAction === 'delete') {
        const res = await api.academic.deleteDepartment(actionDept.id);
        if (res.success) {
          showToast('Department Deleted', `'${actionDept.name}' was deleted.`, 'success');
          await onRefresh();
        } else {
          showToast('Deletion Blocked', res.error || 'Could not delete department.', 'error');
        }
      }
    } catch (err: any) {
      showToast('Action Failed', err.message || 'Network error occurred.', 'error');
    } finally {
      setIsActionLoading(false);
      setActionDept(null);
      setConfirmAction(null);
    }
  };

  // Filtered departments
  const filteredDepartments = departments.filter((d) => {
    const q = (search || '').toLowerCase();
    const headName = d.headOfDepartmentName || '';
    const matchesSearch =
      (d.name || '').toLowerCase().includes(q) ||
      (d.code || '').toLowerCase().includes(q) ||
      headName.toLowerCase().includes(q) ||
      (d.description ? d.description.toLowerCase().includes(q) : false);

    if (!matchesSearch) return false;
    if (statusFilter === 'ACTIVE') return d.status === 'active';
    if (statusFilter === 'ARCHIVED') return d.status === 'archived';
    return true;
  });

  const totalSubjectCount = subjects.filter((s) => s.departmentId).length;
  const headsAssignedCount = departments.filter((d) => d.headOfDepartmentId || d.headOfDepartmentName).length;

  const columns: Column<Department>[] = [
    {
      header: 'Department Name & Code',
      accessor: (row) => (
        <div>
          <div className="font-semibold text-white flex items-center gap-2">
            <span>{row.name}</span>
            <span className="px-2 py-0.5 text-[10px] font-mono bg-white/10 text-slate-300 rounded border border-white/10 font-bold">
              {row.code}
            </span>
          </div>
          {row.description && <div className="text-xs text-slate-400 mt-0.5 line-clamp-1">{row.description}</div>}
        </div>
      )
    },
    {
      header: 'Head of Department',
      accessor: (row) => (
        <div className="text-xs">
          {row.headOfDepartmentName ? (
            <div className="flex items-center gap-1.5 text-slate-200 font-medium">
              <GraduationCap className="w-3.5 h-3.5 text-indigo-400" />
              <span>{row.headOfDepartmentName}</span>
            </div>
          ) : (
            <span className="text-slate-500 italic">No Head Appointed</span>
          )}
        </div>
      )
    },
    {
      header: 'Governed Subjects',
      accessor: (row) => {
        const governedSubjects = subjects.filter((s) => s.departmentId === row.id);
        const count = row.subjectCount ?? governedSubjects.length;
        return (
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-lg bg-indigo-500/15 text-indigo-300 border border-indigo-500/25 text-xs font-semibold">
              {count} Subjects
            </span>
          </div>
        );
      }
    },
    {
      header: 'Faculty Members',
      accessor: (row) => {
        const count = row.teacherCount ?? 0;
        return (
          <div className="text-xs text-slate-300">
            <span className="font-mono font-medium text-slate-200">{count}</span> Educators
          </div>
        );
      }
    },
    {
      header: 'Status',
      accessor: (row) => (
        <Badge variant={row.status === 'active' ? 'success' : 'secondary'} dot>
          {row.status ? row.status.toUpperCase() : 'ACTIVE'}
        </Badge>
      )
    },
    {
      header: 'Actions',
      accessor: (row) => (
        <div className="flex items-center gap-1.5">
          <Button
            size="xs"
            variant="outline"
            onClick={() => openEditModal(row)}
            title="Edit department"
          >
            <Edit2 className="w-3.5 h-3.5" />
          </Button>
          {row.status !== 'archived' && (
            <Button
              size="xs"
              variant="ghost"
              onClick={() => {
                setActionDept(row);
                setConfirmAction('archive');
              }}
              title="Archive department"
            >
              <Archive className="w-3.5 h-3.5 text-slate-400 hover:text-amber-400" />
            </Button>
          )}
          <Button
            size="xs"
            variant="ghost"
            onClick={() => {
              setActionDept(row);
              setConfirmAction('delete');
            }}
            title="Delete department"
          >
            <Trash2 className="w-3.5 h-3.5 text-slate-400 hover:text-rose-400" />
          </Button>
        </div>
      )
    }
  ];

  return (
    <div className="space-y-6">
      {/* Metric Banners */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white/5 p-5 rounded-2xl border border-white/10 shadow-md">
          <div className="flex items-center justify-between text-slate-400 text-xs font-semibold uppercase tracking-wider mb-2">
            <span>Total Departments</span>
            <Building className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="text-2xl font-bold text-white tracking-tight">{departments.length}</div>
          <div className="text-xs text-slate-400 mt-1">Academic faculties</div>
        </div>

        <div className="bg-white/5 p-5 rounded-2xl border border-white/10 shadow-md">
          <div className="flex items-center justify-between text-slate-400 text-xs font-semibold uppercase tracking-wider mb-2">
            <span>Governed Subjects</span>
            <BookOpen className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold text-emerald-400 tracking-tight">{totalSubjectCount}</div>
          <div className="text-xs text-slate-400 mt-1">Curriculum courses tied to departments</div>
        </div>

        <div className="bg-white/5 p-5 rounded-2xl border border-white/10 shadow-md">
          <div className="flex items-center justify-between text-slate-400 text-xs font-semibold uppercase tracking-wider mb-2">
            <span>Department Heads</span>
            <GraduationCap className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-bold text-cyan-400 tracking-tight">
            {headsAssignedCount} <span className="text-xs font-normal text-slate-400">/ {departments.length}</span>
          </div>
          <div className="text-xs text-slate-400 mt-1">Faculties with designated leads</div>
        </div>
      </div>

      {/* Control Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
        <div className="flex flex-1 items-center gap-3">
          <div className="max-w-md w-full">
            <Input
              id="department-search-input"
              placeholder="Search departments, heads, codes..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              leftIcon={<Search className="w-4 h-4" />}
            />
          </div>
          <div className="w-40">
            <Select
              id="dept-status-filter"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
              options={[
                { value: 'ALL', label: 'All Statuses' },
                { value: 'ACTIVE', label: 'Active Only' },
                { value: 'ARCHIVED', label: 'Archived' }
              ]}
            />
          </div>
        </div>

        <Button
          id="btn-create-dept"
          variant="primary"
          onClick={openCreateModal}
          leftIcon={<Plus className="w-4 h-4" />}
        >
          New Department
        </Button>
      </div>

      {/* Table / Empty State */}
      {filteredDepartments.length === 0 ? (
        <EmptyState
          icon={<GraduationCap className="w-8 h-8 text-indigo-400" />}
          title="No Departments Found"
          description={
            search || statusFilter !== 'ALL'
              ? 'No academic departments matched your filter settings.'
              : 'Add academic departments (e.g. Science, Mathematics, Humanities) to group curriculum subjects and faculty.'
          }
          actionLabel={search || statusFilter !== 'ALL' ? undefined : 'Add Department'}
          onAction={openCreateModal}
        />
      ) : (
        <Table columns={columns} data={filteredDepartments} keyExtractor={(d) => d.id} />
      )}

      {/* Create / Edit Modal */}
      <Modal
        isOpen={isFormOpen}
        onClose={() => setIsFormOpen(false)}
        title={editingDept ? 'Edit Department' : 'Create Academic Department'}
        description="Configure academic department faculty name, unique code, and designated department head."
        size="md"
        id="dept-form-modal"
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <Input
            id="dept-name-input"
            label="Department Name *"
            placeholder="e.g. Department of Mathematics"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            error={formErrors.name}
          />

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input
              id="dept-code-input"
              label="Department Code *"
              placeholder="e.g. DEP-MTH"
              value={formData.code}
              onChange={(e) => setFormData({ ...formData, code: e.target.value })}
              error={formErrors.code}
            />
            <Select
              id="dept-status-select"
              label="Status"
              value={formData.status}
              onChange={(e) => setFormData({ ...formData, status: e.target.value as any })}
              options={[
                { value: 'active', label: 'Active' },
                { value: 'archived', label: 'Archived' }
              ]}
            />
          </div>

          <Select
            id="dept-head-select"
            label="Head of Department"
            value={formData.headOfDepartmentId}
            onChange={(e) => setFormData({ ...formData, headOfDepartmentId: e.target.value })}
            options={[
              { value: '', label: '— No Head Appointed —' },
              ...teachers.map((t) => ({
                value: t.id || t.userId,
                label: `${t.firstName} ${t.lastName} (${t.designation || 'Faculty'})`
              }))
            ]}
            helperText="Designated senior faculty leading curriculum and reviews."
          />

          <div className="w-full">
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              Department Description
            </label>
            <textarea
              id="dept-description-input"
              rows={2}
              className="block w-full rounded-xl border border-white/10 bg-slate-900/60 text-slate-100 placeholder-slate-500 focus:border-indigo-500 focus:ring-indigo-500/30 p-3 text-sm"
              placeholder="Optional overview of department specializations, research, labs..."
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            />
          </div>

          <div className="pt-4 border-t border-white/10 flex items-center justify-end gap-3">
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => setIsFormOpen(false)}
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              variant="primary"
              size="sm"
              isLoading={isSubmitting}
            >
              {editingDept ? 'Save Changes' : 'Create Department'}
            </Button>
          </div>
        </form>
      </Modal>

      {/* Confirmation Dialog */}
      <ConfirmDialog
        isOpen={Boolean(confirmAction)}
        onClose={() => {
          setConfirmAction(null);
          setActionDept(null);
        }}
        onConfirm={handleConfirmAction}
        isLoading={isActionLoading}
        title={confirmAction === 'archive' ? 'Archive Department?' : 'Delete Department?'}
        message={
          confirmAction === 'archive'
            ? `Archiving '${actionDept?.name}' (${actionDept?.code}) will retain historical subject linkages while marking it inactive.`
            : `Are you sure you want to delete '${actionDept?.name}'? Deletion will be rejected if active subjects are assigned to this department.`
        }
        confirmLabel={confirmAction === 'archive' ? 'Archive Department' : 'Delete Department'}
        variant={confirmAction === 'delete' ? 'danger' : 'warning'}
      />
    </div>
  );
};
