import React, { useState } from 'react';
import {
  BookOpen,
  Plus,
  Edit2,
  Archive,
  Trash2,
  Search,
  CheckCircle2,
  Layers,
  GraduationCap,
  Sparkles,
  Check
} from 'lucide-react';
import { Table, Column } from '../../../components/ui/Table.js';
import { Badge } from '../../../components/ui/Badge.js';
import { Button } from '../../../components/ui/Button.js';
import { Modal } from '../../../components/ui/Modal.js';
import { Input } from '../../../components/ui/Input.js';
import { Select } from '../../../components/ui/Select.js';
import { ConfirmDialog } from '../../../components/ui/ConfirmDialog.js';
import { EmptyState } from '../../../components/ui/EmptyState.js';
import { Subject, SchoolClass, Department } from '../../../types/index.js';
import { api } from '../../../services/api.js';
import { useToast } from '../../../context/ToastContext.js';

interface SubjectsTabProps {
  subjects: Subject[];
  classes: SchoolClass[];
  departments: Department[];
  onRefresh: () => Promise<void>;
}

export const SubjectsTab: React.FC<SubjectsTabProps> = ({
  subjects = [],
  classes = [],
  departments = [],
  onRefresh
}) => {
  const { showToast } = useToast();
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('ALL');
  const [departmentFilter, setDepartmentFilter] = useState<string>('ALL');
  const [classFilter, setClassFilter] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'ACTIVE' | 'ARCHIVED'>('ALL');

  // Modal States
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingSubject, setEditingSubject] = useState<Subject | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Assign Classes Modal State
  const [assignSubject, setAssignSubject] = useState<Subject | null>(null);
  const [selectedClassIds, setSelectedClassIds] = useState<string[]>([]);
  const [isAssigning, setIsAssigning] = useState(false);

  // Form State
  const [formData, setFormData] = useState({
    name: '',
    code: '',
    type: 'core' as 'core' | 'elective' | 'optional' | 'practical' | 'lab',
    credits: '3',
    departmentId: '',
    classIds: [] as string[],
    description: '',
    status: 'active' as 'active' | 'archived'
  });
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});

  // Action Confirmation
  const [actionSubject, setActionSubject] = useState<Subject | null>(null);
  const [confirmAction, setConfirmAction] = useState<'archive' | 'delete' | null>(null);
  const [isActionLoading, setIsActionLoading] = useState(false);

  const openCreateModal = () => {
    setEditingSubject(null);
    setFormData({
      name: '',
      code: '',
      type: 'core',
      credits: '3',
      departmentId: departments?.[0]?.id || '',
      classIds: classes?.map((c) => c.id) || [],
      description: '',
      status: 'active'
    });
    setFormErrors({});
    setIsFormOpen(true);
  };

  const openEditModal = (sub: Subject) => {
    setEditingSubject(sub);
    setFormData({
      name: sub.name,
      code: sub.code,
      type: (sub.type?.toLowerCase() as any) || 'core',
      credits: String(sub.credits || 3),
      departmentId: sub.departmentId || '',
      classIds: sub.classIds || (sub.classId ? [sub.classId] : []),
      description: sub.description || '',
      status: sub.status || 'active'
    });
    setFormErrors({});
    setIsFormOpen(true);
  };

  const openAssignModal = (sub: Subject) => {
    setAssignSubject(sub);
    setSelectedClassIds(sub.classIds || (sub.classId ? [sub.classId] : []));
  };

  const handleSaveAssignments = async () => {
    if (!assignSubject) return;
    try {
      setIsAssigning(true);
      const res = await api.academic.assignSubjectClasses(assignSubject.id, selectedClassIds);
      if (res.success) {
        showToast('Class Assignments Saved', `Updated class levels for '${assignSubject.name}'.`, 'success');
        setAssignSubject(null);
        await onRefresh();
      } else {
        showToast('Assignment Failed', res.error || 'Failed to update class assignments.', 'error');
      }
    } catch (err: any) {
      showToast('Error', err.message || 'An error occurred.', 'error');
    } finally {
      setIsAssigning(false);
    }
  };

  const validateForm = () => {
    const errors: Record<string, string> = {};
    if (!formData.name.trim()) {
      errors.name = 'Subject name is required (e.g., Advanced Mathematics).';
    }
    if (!formData.code.trim()) {
      errors.code = 'Subject code is required (e.g., MTH-101).';
    }
    if (!formData.credits || Number(formData.credits) <= 0) {
      errors.credits = 'Credits must be at least 1.';
    }
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    try {
      setIsSubmitting(true);
      const payload = {
        name: formData.name.trim(),
        code: formData.code.trim().toUpperCase(),
        type: formData.type,
        credits: Number(formData.credits) || 3,
        departmentId: formData.departmentId || undefined,
        classIds: formData.classIds,
        description: formData.description.trim(),
        status: formData.status
      };

      if (editingSubject) {
        const res = await api.academic.updateSubject(editingSubject.id, payload);
        if (res.success) {
          showToast('Subject Updated', `Subject '${payload.name}' was updated successfully.`, 'success');
          setIsFormOpen(false);
          await onRefresh();
        } else {
          showToast('Update Failed', res.error || 'Failed to update subject.', 'error');
        }
      } else {
        const res = await api.academic.createSubject(payload);
        if (res.success) {
          showToast('Subject Created', `Subject '${payload.name}' has been created.`, 'success');
          setIsFormOpen(false);
          await onRefresh();
        } else {
          showToast('Creation Failed', res.error || 'Failed to create subject.', 'error');
        }
      }
    } catch (err: any) {
      showToast('Error', err.message || 'An unexpected error occurred.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleConfirmAction = async () => {
    if (!actionSubject || !confirmAction) return;

    try {
      setIsActionLoading(true);
      if (confirmAction === 'archive') {
        const res = await api.academic.archiveSubject(actionSubject.id);
        if (res.success) {
          showToast('Subject Archived', `'${actionSubject.name}' is now archived.`, 'info');
          await onRefresh();
        } else {
          showToast('Archive Failed', res.error || 'Could not archive subject.', 'error');
        }
      } else if (confirmAction === 'delete') {
        const res = await api.academic.deleteSubject(actionSubject.id);
        if (res.success) {
          showToast('Subject Deleted', `'${actionSubject.name}' was deleted.`, 'success');
          await onRefresh();
        } else {
          showToast('Deletion Blocked', res.error || 'Could not delete subject.', 'error');
        }
      }
    } catch (err: any) {
      showToast('Action Failed', err.message || 'Network error occurred.', 'error');
    } finally {
      setIsActionLoading(false);
      setActionSubject(null);
      setConfirmAction(null);
    }
  };

  // Filtered subjects
  const filteredSubjects = subjects.filter((s) => {
    const subType = (s.type || '').toUpperCase();
    const q = (search || '').toLowerCase();
    const matchesSearch =
      (s.name || '').toLowerCase().includes(q) ||
      (s.code || '').toLowerCase().includes(q) ||
      (s.departmentName ? s.departmentName.toLowerCase().includes(q) : false);

    if (!matchesSearch) return false;
    if (typeFilter !== 'ALL' && subType !== typeFilter) return false;
    if (departmentFilter !== 'ALL' && s.departmentId !== departmentFilter) return false;
    if (classFilter !== 'ALL') {
      const ids = s.classIds || (s.classId ? [s.classId] : []);
      if (!ids.includes(classFilter)) return false;
    }
    if (statusFilter === 'ACTIVE') return s.status === 'active';
    if (statusFilter === 'ARCHIVED') return s.status === 'archived';
    return true;
  });

  const coreCount = subjects.filter((s) => (s.type || '').toUpperCase() === 'CORE').length;
  const electiveCount = subjects.filter((s) => (s.type || '').toUpperCase() !== 'CORE').length;

  const columns: Column<Subject>[] = [
    {
      header: 'Subject Name & Code',
      accessor: (row) => (
        <div>
          <div className="font-semibold text-white flex items-center gap-2">
            <span>{row.name}</span>
            <span className="px-2 py-0.5 text-[10px] font-mono bg-white/10 text-slate-300 rounded border border-white/10 font-bold">
              {row.code}
            </span>
          </div>
          {row.description && <div className="text-xs text-slate-400 mt-0.5 line-clamp-1">{row.description}</div>}
        </div>
      )
    },
    {
      header: 'Subject Type',
      accessor: (row) => {
        const typeStr = (row.type || 'core').toUpperCase();
        return (
          <Badge
            variant={
              typeStr === 'CORE'
                ? 'primary'
                : typeStr === 'ELECTIVE'
                ? 'cyan'
                : typeStr === 'LAB' || typeStr === 'PRACTICAL'
                ? 'warning'
                : 'secondary'
            }
          >
            {typeStr}
          </Badge>
        );
      }
    },
    {
      header: 'Credits',
      accessor: (row) => <span className="font-mono text-slate-200 font-semibold">{row.credits} Units</span>
    },
    {
      header: 'Department',
      accessor: (row) => {
        const dept = (departments || []).find((d) => d?.id === row.departmentId);
        return (
          <div className="text-xs text-slate-300 font-medium">
            {dept ? dept.name : row.departmentName || <span className="text-slate-500 italic">General Studies</span>}
          </div>
        );
      }
    },
    {
      header: 'Assigned Classes',
      accessor: (row) => {
        const cIds = row.classIds || (row.classId ? [row.classId] : []);
        return (
          <div className="flex flex-wrap items-center gap-1">
            {cIds.length > 0 ? (
              cIds.map((cId) => {
                const foundClass = (classes || []).find((c) => c?.id === cId);
                return (
                  <span
                    key={cId}
                    className="px-2 py-0.5 rounded bg-white/5 border border-white/10 text-slate-300 text-xs font-mono"
                    title={foundClass?.name}
                  >
                    {foundClass ? foundClass.code : cId.toUpperCase()}
                  </span>
                );
              })
            ) : (
              <span className="text-xs text-slate-500 italic">All Grades</span>
            )}
          </div>
        );
      }
    },
    {
      header: 'Status',
      accessor: (row) => (
        <Badge variant={row.status === 'active' ? 'success' : 'secondary'} dot>
          {row.status ? row.status.toUpperCase() : 'ACTIVE'}
        </Badge>
      )
    },
    {
      header: 'Actions',
      accessor: (row) => (
        <div className="flex items-center gap-1.5">
          <Button
            size="xs"
            variant="outline"
            onClick={() => openAssignModal(row)}
            title="Assign / Unassign Grade Classes"
          >
            Classes
          </Button>
          <Button
            size="xs"
            variant="ghost"
            onClick={() => openEditModal(row)}
            title="Edit subject"
          >
            <Edit2 className="w-3.5 h-3.5" />
          </Button>
          {row.status !== 'archived' && (
            <Button
              size="xs"
              variant="ghost"
              onClick={() => {
                setActionSubject(row);
                setConfirmAction('archive');
              }}
              title="Archive subject"
            >
              <Archive className="w-3.5 h-3.5 text-slate-400 hover:text-amber-400" />
            </Button>
          )}
          <Button
            size="xs"
            variant="ghost"
            onClick={() => {
              setActionSubject(row);
              setConfirmAction('delete');
            }}
            title="Delete subject"
          >
            <Trash2 className="w-3.5 h-3.5 text-slate-400 hover:text-rose-400" />
          </Button>
        </div>
      )
    }
  ];

  return (
    <div className="space-y-6">
      {/* Metric Banners */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="bg-white/5 p-5 rounded-2xl border border-white/10 shadow-md">
          <div className="flex items-center justify-between text-slate-400 text-xs font-semibold uppercase tracking-wider mb-2">
            <span>Total Subjects</span>
            <BookOpen className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="text-2xl font-bold text-white tracking-tight">{subjects.length}</div>
          <div className="text-xs text-slate-400 mt-1">Curriculum units mapped</div>
        </div>

        <div className="bg-white/5 p-5 rounded-2xl border border-white/10 shadow-md">
          <div className="flex items-center justify-between text-slate-400 text-xs font-semibold uppercase tracking-wider mb-2">
            <span>Core Subjects</span>
            <Sparkles className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold text-emerald-400 tracking-tight">{coreCount}</div>
          <div className="text-xs text-slate-400 mt-1">Mandatory graduation units</div>
        </div>

        <div className="bg-white/5 p-5 rounded-2xl border border-white/10 shadow-md">
          <div className="flex items-center justify-between text-slate-400 text-xs font-semibold uppercase tracking-wider mb-2">
            <span>Electives &amp; Labs</span>
            <Layers className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-bold text-white tracking-tight">{electiveCount}</div>
          <div className="text-xs text-slate-400 mt-1">Optional &amp; specialty tracks</div>
        </div>

        <div className="bg-white/5 p-5 rounded-2xl border border-white/10 shadow-md">
          <div className="flex items-center justify-between text-slate-400 text-xs font-semibold uppercase tracking-wider mb-2">
            <span>Departments</span>
            <GraduationCap className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-bold text-white tracking-tight">{departments.length}</div>
          <div className="text-xs text-slate-400 mt-1">Academic faculties</div>
        </div>
      </div>

      {/* Control Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
        <div className="flex flex-1 flex-wrap items-center gap-3">
          <div className="max-w-xs w-full">
            <Input
              id="subject-search-input"
              placeholder="Search subjects, codes..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              leftIcon={<Search className="w-4 h-4" />}
            />
          </div>
          <div className="w-36">
            <Select
              id="subject-type-filter"
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
              options={[
                { value: 'ALL', label: 'All Types' },
                { value: 'CORE', label: 'Core Only' },
                { value: 'ELECTIVE', label: 'Electives' },
                { value: 'OPTIONAL', label: 'Optional' },
                { value: 'LAB', label: 'Practical / Lab' }
              ]}
            />
          </div>
          <div className="w-44">
            <Select
              id="subject-dept-filter"
              value={departmentFilter}
              onChange={(e) => setDepartmentFilter(e.target.value)}
              options={[
                { value: 'ALL', label: 'All Departments' },
                ...departments.map((d) => ({ value: d.id, label: d.name }))
              ]}
            />
          </div>
          <div className="w-36">
            <Select
              id="subject-class-filter"
              value={classFilter}
              onChange={(e) => setClassFilter(e.target.value)}
              options={[
                { value: 'ALL', label: 'All Classes' },
                ...classes.map((c) => ({ value: c.id, label: c.name }))
              ]}
            />
          </div>
        </div>

        <Button
          id="btn-create-subject"
          variant="primary"
          onClick={openCreateModal}
          leftIcon={<Plus className="w-4 h-4" />}
        >
          New Subject
        </Button>
      </div>

      {/* Table / Empty State */}
      {filteredSubjects.length === 0 ? (
        <EmptyState
          icon={<BookOpen className="w-8 h-8 text-indigo-400" />}
          title="No Subjects Found"
          description={
            search || typeFilter !== 'ALL' || departmentFilter !== 'ALL' || classFilter !== 'ALL'
              ? 'No curriculum subjects matched your active filters.'
              : 'Add your first academic subject or curriculum course to begin structuring class schedules.'
          }
          actionLabel={search || typeFilter !== 'ALL' ? undefined : 'Add Subject'}
          onAction={openCreateModal}
        />
      ) : (
        <Table columns={columns} data={filteredSubjects} keyExtractor={(s) => s.id} />
      )}

      {/* Create / Edit Modal */}
      <Modal
        isOpen={isFormOpen}
        onClose={() => setIsFormOpen(false)}
        title={editingSubject ? 'Edit Subject' : 'Create Curriculum Subject'}
        description="Define curriculum title, credit value, academic faculty department, and assigned grade tiers."
        size="lg"
        id="subject-form-modal"
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="sm:col-span-2">
              <Input
                id="subject-name-input"
                label="Subject Name *"
                placeholder="e.g. Advanced Mathematics"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                error={formErrors.name}
              />
            </div>
            <Input
              id="subject-code-input"
              label="Subject Code *"
              placeholder="e.g. MTH-101"
              value={formData.code}
              onChange={(e) => setFormData({ ...formData, code: e.target.value })}
              error={formErrors.code}
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <Select
              id="subject-type-select"
              label="Subject Type"
              value={formData.type}
              onChange={(e) => setFormData({ ...formData, type: e.target.value as any })}
              options={[
                { value: 'core', label: 'Core / Mandatory' },
                { value: 'elective', label: 'Elective' },
                { value: 'optional', label: 'Optional' },
                { value: 'practical', label: 'Practical / Lab' }
              ]}
            />
            <Input
              id="subject-credits-input"
              type="number"
              label="Credits / Units *"
              placeholder="3"
              value={formData.credits}
              onChange={(e) => setFormData({ ...formData, credits: e.target.value })}
              error={formErrors.credits}
            />
            <Select
              id="subject-status-select"
              label="Status"
              value={formData.status}
              onChange={(e) => setFormData({ ...formData, status: e.target.value as any })}
              options={[
                { value: 'active', label: 'Active' },
                { value: 'archived', label: 'Archived' }
              ]}
            />
          </div>

          <Select
            id="subject-department-select"
            label="Academic Department"
            value={formData.departmentId}
            onChange={(e) => setFormData({ ...formData, departmentId: e.target.value })}
            options={[
              { value: '', label: '— Unassigned Department —' },
              ...departments.map((d) => ({ value: d.id, label: `${d.name} (${d.code})` }))
            ]}
          />

          {/* Assigned Classes Multi-check */}
          <div className="w-full">
            <div className="flex items-center justify-between mb-2">
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider">
                Assigned Grade Levels / Classes ({formData?.classIds?.length || 0} Selected)
              </label>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setFormData({ ...formData, classIds: classes.map((c) => c.id) })}
                  className="text-xs text-indigo-400 hover:text-indigo-300 cursor-pointer"
                >
                  Select All
                </button>
                <span className="text-slate-600">•</span>
                <button
                  type="button"
                  onClick={() => setFormData({ ...formData, classIds: [] })}
                  className="text-xs text-slate-400 hover:text-slate-300 cursor-pointer"
                >
                  Clear
                </button>
              </div>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 p-3.5 bg-white/5 border border-white/10 rounded-2xl max-h-48 overflow-y-auto">
              {(classes || []).map((cls) => {
                const isSelected = formData.classIds.includes(cls.id);
                return (
                  <label
                    key={cls.id}
                    className={`flex items-center gap-2.5 p-2.5 rounded-xl border text-xs cursor-pointer transition-all ${
                      isSelected
                        ? 'bg-indigo-500/20 border-indigo-500/40 text-white font-medium'
                        : 'bg-white/5 border-white/5 text-slate-300 hover:border-white/15'
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={isSelected}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setFormData({ ...formData, classIds: [...formData.classIds, cls.id] });
                        } else {
                          setFormData({ ...formData, classIds: formData.classIds.filter((id) => id !== cls.id) });
                        }
                      }}
                      className="w-4 h-4 accent-indigo-600 rounded cursor-pointer"
                    />
                    <span>{cls.name}</span>
                  </label>
                );
              })}
            </div>
          </div>

          <div className="w-full">
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              Description &amp; Syllabus Objectives
            </label>
            <textarea
              id="subject-description-input"
              rows={2}
              className="block w-full rounded-xl border border-white/10 bg-slate-900/60 text-slate-100 placeholder-slate-500 focus:border-indigo-500 focus:ring-indigo-500/30 p-3 text-sm"
              placeholder="Optional course objectives or curriculum outline..."
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            />
          </div>

          <div className="pt-4 border-t border-white/10 flex items-center justify-end gap-3">
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => setIsFormOpen(false)}
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              variant="primary"
              size="sm"
              isLoading={isSubmitting}
            >
              {editingSubject ? 'Save Changes' : 'Create Subject'}
            </Button>
          </div>
        </form>
      </Modal>

      {/* Class Level Assignment Modal */}
      {assignSubject && (
        <Modal
          isOpen={Boolean(assignSubject)}
          onClose={() => setAssignSubject(null)}
          title={`Assign Grade Levels: ${assignSubject.name}`}
          description={`Map which classes / grade tiers offer this curriculum course (${assignSubject.code}).`}
          size="md"
          id="subject-assign-modal"
        >
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-400">
                {selectedClassIds.length} of {classes.length} grade tiers selected
              </span>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedClassIds(classes.map((c) => c.id))}
                  className="text-xs text-indigo-400 hover:text-indigo-300 cursor-pointer"
                >
                  Select All
                </button>
                <span className="text-slate-600">•</span>
                <button
                  type="button"
                  onClick={() => setSelectedClassIds([])}
                  className="text-xs text-slate-400 hover:text-slate-300 cursor-pointer"
                >
                  Deselect All
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 max-h-64 overflow-y-auto p-1">
              {(classes || []).map((cls) => {
                const isSelected = selectedClassIds.includes(cls.id);
                return (
                  <div
                    key={cls.id}
                    onClick={() => {
                      if (isSelected) {
                        setSelectedClassIds(selectedClassIds.filter((id) => id !== cls.id));
                      } else {
                        setSelectedClassIds([...selectedClassIds, cls.id]);
                      }
                    }}
                    className={`p-3 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                      isSelected
                        ? 'bg-indigo-500/20 border-indigo-500/40 text-white'
                        : 'bg-white/5 border-white/10 text-slate-300 hover:border-white/20'
                    }`}
                  >
                    <div>
                      <div className="font-semibold text-sm">{cls.name}</div>
                      <div className="text-[11px] text-slate-400 font-mono">Code: {cls.code}</div>
                    </div>
                    <div
                      className={`w-5 h-5 rounded-md flex items-center justify-center border ${
                        isSelected
                          ? 'bg-indigo-600 border-indigo-500 text-white'
                          : 'border-white/20 bg-white/5'
                      }`}
                    >
                      {isSelected && <Check className="w-3.5 h-3.5" />}
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="pt-4 border-t border-white/10 flex items-center justify-end gap-3">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setAssignSubject(null)}
                disabled={isAssigning}
              >
                Cancel
              </Button>
              <Button
                variant="primary"
                size="sm"
                onClick={handleSaveAssignments}
                isLoading={isAssigning}
              >
                Save Class Mappings
              </Button>
            </div>
          </div>
        </Modal>
      )}

      {/* Confirmation Dialog */}
      <ConfirmDialog
        isOpen={Boolean(confirmAction)}
        onClose={() => {
          setConfirmAction(null);
          setActionSubject(null);
        }}
        onConfirm={handleConfirmAction}
        isLoading={isActionLoading}
        title={confirmAction === 'archive' ? 'Archive Subject?' : 'Delete Subject?'}
        message={
          confirmAction === 'archive'
            ? `Archiving '${actionSubject?.name}' (${actionSubject?.code}) will retain past transcript records while preventing new student course enrollments.`
            : `Are you sure you want to delete '${actionSubject?.name}' (${actionSubject?.code})? This action cannot be undone.`
        }
        confirmLabel={confirmAction === 'archive' ? 'Archive Subject' : 'Delete Subject'}
        variant={confirmAction === 'delete' ? 'danger' : 'warning'}
      />
    </div>
  );
};
