import React, { useState } from 'react';
import {
  Building,
  Plus,
  Edit2,
  Archive,
  Trash2,
  Users,
  Search,
  CheckCircle2,
  GraduationCap,
  Layers,
  Sparkles
} from 'lucide-react';
import { Table, Column } from '../../../components/ui/Table.js';
import { Badge } from '../../../components/ui/Badge.js';
import { Button } from '../../../components/ui/Button.js';
import { Modal } from '../../../components/ui/Modal.js';
import { Input } from '../../../components/ui/Input.js';
import { Select } from '../../../components/ui/Select.js';
import { ConfirmDialog } from '../../../components/ui/ConfirmDialog.js';
import { EmptyState } from '../../../components/ui/EmptyState.js';
import { Section, SchoolClass, Teacher } from '../../../types/index.js';
import { api } from '../../../services/api.js';
import { useToast } from '../../../context/ToastContext.js';

interface SectionsTabProps {
  sections: Section[];
  classes: SchoolClass[];
  teachers: Teacher[];
  initialClassFilter?: string;
  onRefresh: () => Promise<void>;
}

export const SectionsTab: React.FC<SectionsTabProps> = ({
  sections = [],
  classes = [],
  teachers = [],
  initialClassFilter = 'ALL',
  onRefresh
}) => {
  const { showToast } = useToast();
  const [search, setSearch] = useState('');
  const [classFilter, setClassFilter] = useState<string>(initialClassFilter);
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'ACTIVE' | 'ARCHIVED'>('ALL');

  // Modal States
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingSection, setEditingSection] = useState<Section | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Form State
  const [formData, setFormData] = useState({
    name: '',
    classId: classes?.[0]?.id || '',
    roomNumber: '',
    capacity: '35',
    classTeacherId: '',
    description: '',
    status: 'active' as 'active' | 'archived'
  });
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});

  // Action Confirmation
  const [actionSection, setActionSection] = useState<Section | null>(null);
  const [confirmAction, setConfirmAction] = useState<'archive' | 'delete' | null>(null);
  const [isActionLoading, setIsActionLoading] = useState(false);

  const openCreateModal = () => {
    setEditingSection(null);
    setFormData({
      name: '',
      classId: classFilter !== 'ALL' ? classFilter : classes?.[0]?.id || '',
      roomNumber: '',
      capacity: '35',
      classTeacherId: '',
      description: '',
      status: 'active'
    });
    setFormErrors({});
    setIsFormOpen(true);
  };

  const openEditModal = (sec: Section) => {
    setEditingSection(sec);
    setFormData({
      name: sec.name,
      classId: sec.classId,
      roomNumber: sec.roomNumber || '',
      capacity: String(sec.capacity || 35),
      classTeacherId: sec.classTeacherId || '',
      description: sec.description || '',
      status: sec.status || 'active'
    });
    setFormErrors({});
    setIsFormOpen(true);
  };

  const validateForm = () => {
    const errors: Record<string, string> = {};
    if (!formData.name.trim()) {
      errors.name = 'Section name is required (e.g., Section A, Section B).';
    }
    if (!formData.classId) {
      errors.classId = 'Please select a parent class tier.';
    }
    if (!formData.capacity || Number(formData.capacity) <= 0) {
      errors.capacity = 'Capacity must be at least 1 student.';
    }
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    try {
      setIsSubmitting(true);
      const selectedTeacher = (teachers || []).find((t) => t?.id === formData.classTeacherId || t?.userId === formData.classTeacherId);

      const payload = {
        name: formData.name.trim(),
        classId: formData.classId,
        roomNumber: formData.roomNumber.trim(),
        capacity: Number(formData.capacity) || 35,
        classTeacherId: formData.classTeacherId || undefined,
        classTeacherName: selectedTeacher ? `${selectedTeacher.firstName} ${selectedTeacher.lastName}` : undefined,
        description: formData.description.trim(),
        status: formData.status
      };

      if (editingSection) {
        const res = await api.academic.updateSection(editingSection.id, payload);
        if (res.success) {
          showToast('Section Updated', `Section '${payload.name}' was updated successfully.`, 'success');
          setIsFormOpen(false);
          await onRefresh();
        } else {
          showToast('Update Failed', res.error || 'Failed to update section.', 'error');
        }
      } else {
        const res = await api.academic.createSection(payload);
        if (res.success) {
          showToast('Section Created', `Section '${payload.name}' has been created.`, 'success');
          setIsFormOpen(false);
          await onRefresh();
        } else {
          showToast('Creation Failed', res.error || 'Failed to create section.', 'error');
        }
      }
    } catch (err: any) {
      showToast('Error', err.message || 'An unexpected error occurred.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleConfirmAction = async () => {
    if (!actionSection || !confirmAction) return;

    try {
      setIsActionLoading(true);
      if (confirmAction === 'archive') {
        const res = await api.academic.archiveSection(actionSection.id);
        if (res.success) {
          showToast('Section Archived', `'${actionSection.name}' is now archived.`, 'info');
          await onRefresh();
        } else {
          showToast('Archive Blocked', res.error || 'Could not archive section.', 'error');
        }
      } else if (confirmAction === 'delete') {
        const res = await api.academic.deleteSection(actionSection.id);
        if (res.success) {
          showToast('Section Deleted', `'${actionSection.name}' was deleted.`, 'success');
          await onRefresh();
        } else {
          showToast('Deletion Blocked', res.error || 'Could not delete section.', 'error');
        }
      }
    } catch (err: any) {
      showToast('Action Failed', err.message || 'Network error occurred.', 'error');
    } finally {
      setIsActionLoading(false);
      setActionSection(null);
      setConfirmAction(null);
    }
  };

  // Filtered sections
  const filteredSections = (sections || []).filter((s) => {
    const parentClass = (classes || []).find((c) => c?.id === s.classId);
    const className = parentClass ? parentClass.name : s.className || '';
    const teacherName = s.classTeacherName || '';

    const q = (search || '').toLowerCase();
    const matchesSearch =
      (s.name || '').toLowerCase().includes(q) ||
      className.toLowerCase().includes(q) ||
      teacherName.toLowerCase().includes(q) ||
      (s.roomNumber ? s.roomNumber.toLowerCase().includes(q) : false);

    if (!matchesSearch) return false;
    if (classFilter !== 'ALL' && s.classId !== classFilter) return false;
    if (statusFilter === 'ACTIVE') return s.status === 'active';
    if (statusFilter === 'ARCHIVED') return s.status === 'archived';
    return true;
  });

  // Calculate totals
  const totalStudentsEnrolled = sections.reduce((acc, s) => acc + (s.studentCount || 0), 0);
  const totalCapacity = sections.reduce((acc, s) => acc + (s.capacity || 0), 0);
  const assignedTeachersCount = sections.filter((s) => s.classTeacherId || s.classTeacherName).length;

  const columns: Column<Section>[] = [
    {
      header: 'Section Name',
      accessor: (row) => (
        <div>
          <div className="font-semibold text-white flex items-center gap-2">
            <span>{row.name}</span>
            {row.code && (
              <span className="text-[10px] font-mono text-slate-400">({row.code})</span>
            )}
          </div>
          {row.description && <div className="text-xs text-slate-400 mt-0.5 line-clamp-1">{row.description}</div>}
        </div>
      )
    },
    {
      header: 'Assigned Grade / Class',
      accessor: (row) => {
        const parentClass = (classes || []).find((c) => c?.id === row.classId);
        return (
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-1 rounded-lg bg-indigo-500/15 text-indigo-300 border border-indigo-500/25 text-xs font-semibold">
              {parentClass ? parentClass.name : row.className || 'Unassigned Grade'}
            </span>
          </div>
        );
      }
    },
    {
      header: 'Room Number',
      accessor: (row) => (
        <div className="text-xs font-medium text-slate-200">
          {row.roomNumber ? `Room ${row.roomNumber}` : <span className="text-slate-500 italic">Not Assigned</span>}
        </div>
      )
    },
    {
      header: 'Class Teacher',
      accessor: (row) => (
        <div className="text-xs">
          {row.classTeacherName ? (
            <div className="flex items-center gap-1.5 text-slate-200 font-medium">
              <GraduationCap className="w-3.5 h-3.5 text-indigo-400" />
              <span>{row.classTeacherName}</span>
            </div>
          ) : (
            <span className="text-slate-500 italic">No Teacher Assigned</span>
          )}
        </div>
      )
    },
    {
      header: 'Capacity & Students',
      accessor: (row) => {
        const enrolled = row.studentCount || 0;
        const capacity = row.capacity || 35;
        const percentage = Math.min(100, Math.round((enrolled / capacity) * 100));

        return (
          <div className="min-w-[130px]">
            <div className="flex items-center justify-between text-xs mb-1">
              <span className="text-slate-300 font-medium">{enrolled} / {capacity}</span>
              <span className="text-slate-400 text-[11px] font-mono">{percentage}%</span>
            </div>
            <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden">
              <div
                className={`h-full rounded-full transition-all duration-300 ${
                  percentage >= 95 ? 'bg-rose-500' : percentage >= 80 ? 'bg-amber-500' : 'bg-emerald-500'
                }`}
                style={{ width: `${percentage}%` }}
              />
            </div>
          </div>
        );
      }
    },
    {
      header: 'Status',
      accessor: (row) => (
        <Badge variant={row.status === 'active' ? 'success' : 'secondary'} dot>
          {row.status ? row.status.toUpperCase() : 'ACTIVE'}
        </Badge>
      )
    },
    {
      header: 'Actions',
      accessor: (row) => (
        <div className="flex items-center gap-1.5">
          <Button
            size="xs"
            variant="outline"
            onClick={() => openEditModal(row)}
            title="Edit section"
          >
            <Edit2 className="w-3.5 h-3.5" />
          </Button>
          {row.status !== 'archived' && (
            <Button
              size="xs"
              variant="ghost"
              onClick={() => {
                setActionSection(row);
                setConfirmAction('archive');
              }}
              title="Archive section"
            >
              <Archive className="w-3.5 h-3.5 text-slate-400 hover:text-amber-400" />
            </Button>
          )}
          <Button
            size="xs"
            variant="ghost"
            onClick={() => {
              setActionSection(row);
              setConfirmAction('delete');
            }}
            title="Delete section"
          >
            <Trash2 className="w-3.5 h-3.5 text-slate-400 hover:text-rose-400" />
          </Button>
        </div>
      )
    }
  ];

  return (
    <div className="space-y-6">
      {/* Metric Banners */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="bg-white/5 p-5 rounded-2xl border border-white/10 shadow-md">
          <div className="flex items-center justify-between text-slate-400 text-xs font-semibold uppercase tracking-wider mb-2">
            <span>Total Sections</span>
            <Building className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="text-2xl font-bold text-white tracking-tight">{sections.length}</div>
          <div className="text-xs text-slate-400 mt-1">Classroom divisions</div>
        </div>

        <div className="bg-white/5 p-5 rounded-2xl border border-white/10 shadow-md">
          <div className="flex items-center justify-between text-slate-400 text-xs font-semibold uppercase tracking-wider mb-2">
            <span>Enrolled Students</span>
            <Users className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold text-emerald-400 tracking-tight">{totalStudentsEnrolled}</div>
          <div className="text-xs text-slate-400 mt-1">Active student count</div>
        </div>

        <div className="bg-white/5 p-5 rounded-2xl border border-white/10 shadow-md">
          <div className="flex items-center justify-between text-slate-400 text-xs font-semibold uppercase tracking-wider mb-2">
            <span>Total Capacity</span>
            <Sparkles className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-bold text-white tracking-tight">{totalCapacity}</div>
          <div className="text-xs text-slate-400 mt-1">Max capacity across cohorts</div>
        </div>

        <div className="bg-white/5 p-5 rounded-2xl border border-white/10 shadow-md">
          <div className="flex items-center justify-between text-slate-400 text-xs font-semibold uppercase tracking-wider mb-2">
            <span>Assigned Teachers</span>
            <GraduationCap className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-bold text-white tracking-tight">
            {assignedTeachersCount} <span className="text-xs font-normal text-slate-400">/ {sections.length}</span>
          </div>
          <div className="text-xs text-slate-400 mt-1">Class supervisors assigned</div>
        </div>
      </div>

      {/* Control Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
        <div className="flex flex-1 flex-wrap items-center gap-3">
          <div className="max-w-xs w-full">
            <Input
              id="section-search-input"
              placeholder="Search sections, rooms, teachers..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              leftIcon={<Search className="w-4 h-4" />}
            />
          </div>
          <div className="w-48">
            <Select
              id="section-class-filter"
              value={classFilter}
              onChange={(e) => setClassFilter(e.target.value)}
              options={[
                { value: 'ALL', label: 'All Classes' },
                ...classes.map((c) => ({ value: c.id, label: `${c.name} (${c.code})` }))
              ]}
            />
          </div>
          <div className="w-36">
            <Select
              id="section-status-filter"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
              options={[
                { value: 'ALL', label: 'All Statuses' },
                { value: 'ACTIVE', label: 'Active Only' },
                { value: 'ARCHIVED', label: 'Archived' }
              ]}
            />
          </div>
        </div>

        <Button
          id="btn-create-section"
          variant="primary"
          onClick={openCreateModal}
          leftIcon={<Plus className="w-4 h-4" />}
        >
          New Section
        </Button>
      </div>

      {/* Table / Empty State */}
      {filteredSections.length === 0 ? (
        <EmptyState
          icon={<Building className="w-8 h-8 text-indigo-400" />}
          title="No Sections Found"
          description={
            search || classFilter !== 'ALL' || statusFilter !== 'ALL'
              ? 'No sections matched your filter settings.'
              : 'Add your first class section (e.g. Section A) to assign students, rooms, and teachers.'
          }
          actionLabel={search || classFilter !== 'ALL' || statusFilter !== 'ALL' ? undefined : 'Add Section'}
          onAction={openCreateModal}
        />
      ) : (
        <Table columns={columns} data={filteredSections} keyExtractor={(s) => s.id} />
      )}

      {/* Create / Edit Modal */}
      <Modal
        isOpen={isFormOpen}
        onClose={() => setIsFormOpen(false)}
        title={editingSection ? 'Edit Classroom Section' : 'Create Classroom Section'}
        description="Configure cohort name, parent grade tier, room assignment, and capacity limits."
        size="md"
        id="section-form-modal"
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <Input
            id="section-name-input"
            label="Section Name *"
            placeholder="e.g. Section A, Blue Cohort"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            error={formErrors.name}
          />

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Select
              id="section-parent-class-select"
              label="Parent Grade / Class *"
              value={formData.classId}
              onChange={(e) => setFormData({ ...formData, classId: e.target.value })}
              error={formErrors.classId}
              options={(classes || []).map((c) => ({ value: c.id, label: `${c.name} (${c.code})` }))}
            />

            <Input
              id="section-room-input"
              label="Room Number / Location"
              placeholder="e.g. Room 302"
              value={formData.roomNumber}
              onChange={(e) => setFormData({ ...formData, roomNumber: e.target.value })}
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input
              id="section-capacity-input"
              type="number"
              label="Student Capacity *"
              placeholder="35"
              value={formData.capacity}
              onChange={(e) => setFormData({ ...formData, capacity: e.target.value })}
              error={formErrors.capacity}
              helperText="Maximum allowed students."
            />

            <Select
              id="section-status-select"
              label="Status"
              value={formData.status}
              onChange={(e) => setFormData({ ...formData, status: e.target.value as any })}
              options={[
                { value: 'active', label: 'Active' },
                { value: 'archived', label: 'Archived' }
              ]}
            />
          </div>

          <Select
            id="section-teacher-select"
            label="Assigned Class Teacher"
            value={formData.classTeacherId}
            onChange={(e) => setFormData({ ...formData, classTeacherId: e.target.value })}
            options={[
              { value: '', label: '— Unassigned Class Teacher —' },
              ...teachers.map((t) => ({
                value: t.id || t.userId,
                label: `${t.firstName} ${t.lastName} (${t.employeeCode || t.department || 'Teacher'})`
              }))
            ]}
            helperText="Supervising teacher for daily attendance and student welfare."
          />

          <div className="w-full">
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              Section Description
            </label>
            <textarea
              id="section-description-input"
              rows={2}
              className="block w-full rounded-xl border border-white/10 bg-slate-900/60 text-slate-100 placeholder-slate-500 focus:border-indigo-500 focus:ring-indigo-500/30 p-3 text-sm"
              placeholder="Optional notes regarding section equipment, lab wing, etc..."
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            />
          </div>

          <div className="pt-4 border-t border-white/10 flex items-center justify-end gap-3">
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => setIsFormOpen(false)}
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              variant="primary"
              size="sm"
              isLoading={isSubmitting}
            >
              {editingSection ? 'Save Changes' : 'Create Section'}
            </Button>
          </div>
        </form>
      </Modal>

      {/* Confirmation Dialog */}
      <ConfirmDialog
        isOpen={Boolean(confirmAction)}
        onClose={() => {
          setConfirmAction(null);
          setActionSection(null);
        }}
        onConfirm={handleConfirmAction}
        isLoading={isActionLoading}
        title={confirmAction === 'archive' ? 'Archive Classroom Section?' : 'Delete Classroom Section?'}
        message={
          confirmAction === 'archive'
            ? `Archiving '${actionSection?.name}' will retain historical student logs but remove it from active enrollment lists.`
            : `Are you sure you want to permanently delete '${actionSection?.name}'? Deletion will be rejected if students are actively enrolled.`
        }
        confirmLabel={confirmAction === 'archive' ? 'Archive Section' : 'Delete Section'}
        variant={confirmAction === 'delete' ? 'danger' : 'warning'}
      />
    </div>
  );
};
