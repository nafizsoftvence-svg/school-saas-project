/**
 * Centralized API Client with token injection & typed endpoints
 */
import {
  ApiResponse,
  AuthSession,
  DashboardStats,
  SuperAdminDashboardData,
  TeacherDashboardData,
  StudentDashboardData,
  UserRole,
  AcademicSession,
  SchoolClass,
  Section,
  Subject,
  Department,
  Teacher,
  TeacherProfile,
  Student,
  StudentProfile,
  Guardian,
  ParentStudentRelationship,
  Family,
  AuditLog,
  School,
  SchoolMembership,
  SchoolSettings,
  NotificationItem,
  TeacherClassInfo,
  TeacherSectionInfo,
  TeacherStudentInfo,
  TeacherStudentsResponse,
  AttendanceRecord,
  AttendanceStatus,
  AttendanceSettings,
  AttendanceSheetData,
  AttendanceFilterParams,
  AttendanceSummaryStats,
  StudentAttendanceHistoryData,
  LeaveType,
  LeaveApplication,
  LeaveStatus,
  Homework,
  HomeworkFilterParams,
  Assignment,
  AssignmentFilterParams,
  StudyMaterial,
  StudyMaterialFilterParams,
  ClassAnnouncement,
  AnnouncementFilterParams,
  AnnouncementAttachment,
  StudentClassInfo,
  StudentEnrolledSubject,
  StudentSubjectDetailData,
  StudentAcademicInfoData,
  StudentSubjectFilterParams,
  StudentAttendanceOverviewData,
  StudentLeaveApplication,
  StudentHomeworkItem,
  StudentAssignmentItem,
  StudentHomeworkFilterParams,
  StudentAssignmentFilterParams,
  StudentMaterialFilterParams,
  StudentAnnouncementFilterParams,
  StudentActivitiesSummary,
  ExamScheduleItem,
  ExamScheduleFilterParams,
  StudentExamResult,
  StudentResultsFilterParams,
  StudentAcademicProgressOverview,
  GradingScaleItem,
  GuardianChildSummary,
  GuardianChildDossier,
  GuardianDashboardData,
  GuardianProfileUpdatePayload,
  GuardianNotificationFilterParams,
  GuardianChildAcademicOverview,
  GuardianChildAttendanceOverviewData,
  GuardianLeaveSubmissionPayload,
  GuardianChildHomeworkResponse,
  GuardianChildAssignmentResponse,
  GuardianChildMaterialResponse,
  GuardianChildAnnouncementResponse,
  GuardianChildActivitiesSummaryResponse,
  ParentInvitation,
  PasswordResetToken,
  GuardianAccountInfo,
  GuardianContextData,
  ParentActivationPayload,
  ParentPasswordChangePayload,
  ParentResetPasswordPayload,
  GuardianChildExaminationsResponse,
  GuardianChildResultsResponse,
  GuardianChildProgressResponse,
  GuardianChildrenComparisonResponse,
  StudentFeeRecord,
  FeePaymentTransaction,
  FeePaymentReceipt,
  GuardianChildFeesResponse,
  GuardianChildFeeDetailResponse,
  GuardianPaymentHistoryResponse,
  GuardianFamilyFeeOverviewResponse,
  Examination,
  ExamSubjectConfig,
  ExaminationStatus,
  ExamFilterParams,
  CreateExamPayload,
  UpdateExamPayload,
  ExamSubjectConfigPayload,
  ExamStatus,
  ExamScheduleConflict,
  ScheduleConflictCheckPayload,
  ExamScheduleAdminFilterParams,
  CreateExamSchedulePayload,
  UpdateExamSchedulePayload,
  TeacherAssignedExamSubject,
  SaveDraftMarksPayload,
  SubmitMarksPayload,
  ExamMarksSubmission,
  AdminMarksSubmissionFilterParams,
  StudentMarkItem,
  CalculateResultsPayload,
  CalculationReadinessInfo,
  AdminResultPreviewFilterParams,
  ResultCalculationSummaryStats,
  ResultWorkflowStatus,
  ResultStatusHistoryItem,
  ResultReviewFilterParams,
  ResultReviewResponse,
  ResultReviewSummaryStats,
  ChangeResultStatusPayload,
  BulkChangeResultStatusPayload,
  ReturnCorrectionPayload,
  BulkApproveResultsPayload,
  PublishResultsPayload,
  UnpublishReopenPayload,
  MeritRankingConfig,
  MeritListResponse,
  ReportCardDetail,
  ClassResultSummaryData,
  SubjectPerformanceReportResponse,
  StudentPerformanceHistoryResponse,
  FeeType,
  FeeStructure,
  FeeTypeStatus,
  FeeStructureStatus,
  CreateFeeTypePayload,
  UpdateFeeTypePayload,
  CreateFeeStructurePayload,
  UpdateFeeStructurePayload,
  FeeStructureFilterParams,
  FeeStructureSummaryStats,
  AssignStudentFeePayload,
  AssignStudentFeeResponse,
  ApplicableFeeStructureItem,
  StudentFeeFilterParams,
  StudentFeeSummaryStats,
  StudentFeeListResponse,
  ApplyFeeDiscountPayload,
  ApplyFeeFinePayload,
  UpdateStudentFeeStatusPayload,
  InvoiceDetailResponse,
  CollectFeePaymentPayload,
  CollectFeePaymentResponse,
  ReverseFeePaymentPayload,
  ReverseFeePaymentResponse,
  FeePaymentFilterParams,
  FeePaymentListResponse,
  FeeCollectionSummaryStats,
  PaymentMethodConfig,
  FeeDiscountRule,
  CreateDiscountRulePayload,
  UpdateDiscountRulePayload,
  ApplyDiscountBatchPayload,
  ApplyDiscountBatchResponse,
  FeeWaiver,
  CreateWaiverPayload,
  ApproveWaiverPayload,
  RejectWaiverPayload,
  FeeScholarship,
  CreateScholarshipPayload,
  UpdateScholarshipPayload,
  FeeFineRule,
  CreateFineRulePayload,
  UpdateFineRulePayload,
  AppliedFineRecord,
  ApplyManualFinePayload,
  WaiveFinePayload,
  AssessLateFinesPayload,
  AssessLateFinesResponse,
  FeeAdjustmentAudit,
  FeeAdjustmentSummaryStats,
  FeeDueAgingSummary,
  ClassWiseDueSummary,
  FeeTypeDueSummary,
  FeeDueDashboardStats,
  FeeDueStudentItem,
  FeeDueFilterParams,
  FeeDueStudentListResponse,
  FeeReminderLog,
  SendFeeReminderPayload,
  SendFeeReminderResponse,
  FinancialReportDashboardStats,
  CollectionReportFilterParams,
  CollectionReportTransactionItem,
  CollectionReportResponse,
  FeeSummaryReportItem,
  FeeSummaryReportResponse,
  StudentStatementEntry,
  StudentAccountStatement,
  PaymentMethodReportResponse,
  TeacherAttendanceRecord,
  TeacherAttendanceStatus,
  TeacherAttendanceCorrectionHistoryItem,
  TeacherDailyAttendanceResponse,
  TeacherMonthlyAttendanceResponse,
  TeacherMyAttendanceResponse,
  AttendanceReportFilterParams,
  AttendanceReportPagination,
  AttendanceReportDashboardData,
  StudentWiseAttendanceReportItem,
  ClassSectionAttendanceReportItem,
  TeacherAttendanceReportItem,
  AttendanceDetailedRecordReportItem,
  LeaveReportItem,
  StudentMasterDossier,
  StudentDocument,
  AdmissionEnquiry,
  AdmissionApplication,
  AcademicEnrollment,
  AdmissionNumberConfig,
  DuplicateStudentCheckResult,
  StudentReportFilterParams,
  StudentReportItem,
  StudentReportsSummaryData,
  ClassWiseReportItem,
  StatusReportData,
  AcademicAssignmentReportItem,
  BulkStudentActionPayload,
  BulkStudentActionResult,
  CommunicationSettings,
  CommunicationTemplate,
  CommunicationLog,
  CommunicationStats,
  UserNotificationPreference,
  CommunicationFilterParams,
  NotificationChannel,
  CommunicationDeliveryStatus,
  Conversation,
  MessageItem,
  MessageReport,
  EligibleRecipient,
  ConversationFilterParams,
  BulkCampaign,
  BulkCampaignRecipient,
  BulkCampaignFilterParams,
  RecipientPreviewResult,
  BulkCampaignStats,
  BulkCampaignAudienceType,
  BulkCampaignPriority,
  BulkCampaignScheduleType,
  BulkCampaignRelationshipType,
  CommunicationAnalyticsFilterParams,
  CommunicationAnalyticsOverview,
  DeliveryReportQuery,
  DeliveryReportItem,
  ExportReportType,
  ExportFormat,
  StaffProfile,
  StaffDirectoryQuery,
  StaffDirectoryResponse,
  StaffStatsResponse,
  CreateStaffPayload,
  UpdateStaffPayload,
  ChangeStaffStatusPayload,
  UploadStaffDocumentPayload,
  VerifyStaffDocumentPayload,
  CreateDesignationPayload,
  UpdateDesignationPayload,
  Designation,
  StaffDocument,
  // Front Office (Part 13A, 13B, 13C, 13D, 13E)
  FrontOfficeEnquiry,
  EnquiryFollowUp,
  EnquiryDuplicateCheckResult,
  EnquiryMetricsSummary,
  EnquirySourceConfig,
  VisitorRecord,
  TodaysFrontDeskOverview,
  VisitorPassVerificationResult,
  PhoneCallLogRecord,
  CallMetricsSummary,
  ComplaintRecord,
  ComplaintMetricsSummary,
  FrontOfficeDashboardStats,
  FrontOfficeAnalyticsData,
  FrontOfficeReportFilter,
  FrontOfficeReportResult,
  FrontOfficeGlobalSearchResult,
  // Inventory & Asset Management (Part 14A)
  InventoryItem,
  InventoryCategory,
  InventoryUnit,
  InventoryLocation,
  Supplier,
  Asset,
  AssetCategory,
  AssetDocument,
  AssetHistoryEntry,
  InventoryDashboardStats,
  InventoryFilterParams,
  AssetFilterParams,
  CreateInventoryItemPayload,
  UpdateInventoryItemPayload,
  CreateAssetPayload,
  UpdateAssetPayload,
  CreateSupplierPayload,
  UpdateSupplierPayload,
  CreateInventoryCategoryPayload,
  CreateInventoryUnitPayload,
  CreateInventoryLocationPayload,
  CreateAssetCategoryPayload,
  PaginatedInventoryResponse,
  ItemStockBalance,
  StockMovement,
  StockTransaction,
  StockSummary,
  OpeningStockPayload,
  StockInPayload,
  StockOutPayload,
  StockTransferPayload,
  StockReturnPayload,
  StockAdjustmentPayload,
  StockBalanceFilterParams,
  StockMovementFilterParams,
  StockTransactionFilterParams,
  AssetAssignment,
  AssetTransfer,
  AssetReturn,
  AssetTimelineEvent,
  AssignAssetPayload,
  ReturnAssetPayload,
  TransferAssetPayload,
  SendForRepairPayload,
  CompleteRepairPayload,
  MarkDamagedPayload,
  MarkLostPayload,
  MarkRecoveredPayload,
  RetireAssetPayload,
  DisposeAssetPayload
} from '../types/index.js';

const API_BASE = '/api';

class ApiService {
  getAuthToken(): string | null {
    return (
      localStorage.getItem('sygmate_auth_token') ||
      localStorage.getItem('token') ||
      localStorage.getItem('sygmate_token')
    );
  }

  private getToken(): string | null {
    return this.getAuthToken();
  }

  private async request<T>(endpoint: string, options: RequestInit = {}): Promise<ApiResponse<T>> {
    const token = this.getToken();

    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      ...(options.headers as Record<string, string>)
    };

    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    const activeSchoolId = typeof window !== 'undefined' ? localStorage.getItem('sygmate_active_school_id') : null;
    if (activeSchoolId && !headers['X-School-Id']) {
      headers['X-School-Id'] = activeSchoolId;
    }

    try {
      const response = await fetch(`${API_BASE}${endpoint}`, {
        ...options,
        headers
      });

      const contentType = response.headers.get('content-type') || '';
      let data: any;

      if (contentType.includes('application/json')) {
        data = await response.json();
      } else {
        return {
          success: false,
          error: response.ok
            ? 'Unexpected non-JSON response from server.'
            : `HTTP error ${response.status}: ${response.statusText}`,
          code: `HTTP_${response.status}`
        };
      }

      if (!response.ok) {
        return {
          success: false,
          error: data.error || `HTTP error ${response.status}: ${response.statusText}`,
          code: data.code || `HTTP_${response.status}`
        };
      }

      return data;
    } catch (error: any) {
      return {
        success: false,
        error: error.message || 'Network communication failure.',
        code: 'NETWORK_ERROR'
      };
    }
  }

  // Auth Endpoints
  auth = {
    login: (credentials: { identifier: string; password: string }) =>
      this.request<{ session: AuthSession; redirectTo: string }>('/auth/login', {
        method: 'POST',
        body: JSON.stringify(credentials)
      }),
    switchDemo: (role: UserRole) =>
      this.request<{ session: AuthSession; redirectTo: string }>('/auth/switch-demo', {
        method: 'POST',
        body: JSON.stringify({ role })
      }),
    demoStatus: () =>
      this.request<{ isDemoEnabled: boolean }>('/auth/demo-status'),
    switchSchool: (schoolId: string) =>
      this.request<{ schoolId: string; school: School; session: AuthSession }>('/auth/switch-school', {
        method: 'POST',
        body: JSON.stringify({ schoolId })
      }),
    getMe: () => this.request<AuthSession>('/auth/me'),
    logout: () =>
      this.request('/auth/logout', {
        method: 'POST'
      }),
    // Part 10B: Invitation & Password Lifecycle
    verifyInvitation: (token: string) =>
      this.request<{
        valid: boolean;
        invitation: ParentInvitation;
        guardian: Guardian;
        students: any[];
      }>(`/auth/invitation/verify?token=${encodeURIComponent(token)}`),
    activateAccount: (payload: ParentActivationPayload) =>
      this.request<{
        message: string;
        session: AuthSession;
        user: any;
        guardian: any;
        redirectTo: string;
      }>('/auth/invitation/activate', {
        method: 'POST',
        body: JSON.stringify(payload)
      }),
    forgotPassword: (identifier: string) =>
      this.request<{
        message: string;
        expiresIn?: string;
        simulationDirectUrl?: string;
      }>('/auth/forgot-password', {
        method: 'POST',
        body: JSON.stringify({ identifier })
      }),
    verifyResetToken: (token: string) =>
      this.request<{
        valid: boolean;
        userId: string;
        email: string;
        name: string;
        expiresAt: string;
      }>(`/auth/reset-password/verify?token=${encodeURIComponent(token)}`),
    resetPassword: (payload: ParentResetPasswordPayload) =>
      this.request<{
        message: string;
        username: string;
      }>('/auth/reset-password', {
        method: 'POST',
        body: JSON.stringify(payload)
      }),
    changePassword: (payload: ParentPasswordChangePayload) =>
      this.request<{
        message: string;
      }>('/auth/change-password', {
        method: 'POST',
        body: JSON.stringify(payload)
      })
  };

  // Dashboard Endpoints
  dashboard = {
    getStats: () => this.request<DashboardStats>('/dashboard/stats')
  };

  getAdminDashboard = () => this.request<SuperAdminDashboardData>('/dashboard/admin');
  getTeacherDashboard = () => this.request<TeacherDashboardData>('/dashboard/teacher');
  getStudentDashboard = () => this.request<StudentDashboardData>('/dashboard/student');
  getStudentRoutine = () =>
    this.request<{
      schedule: Array<{
        day: string;
        slots: Array<{
          time: string;
          subject: string;
          teacher: string;
          room: string;
        }>;
      }>;
      className?: string;
      sectionName?: string;
      sessionName?: string;
    }>('/student/routine');

  // Academic Endpoints
  academic = {
    // Sessions
    getSessions: () => this.request<AcademicSession[]>('/academic/sessions'),
    createSession: (data: Partial<AcademicSession>) =>
      this.request<AcademicSession>('/academic/sessions', {
        method: 'POST',
        body: JSON.stringify(data)
      }),
    updateSession: (id: string, data: Partial<AcademicSession>) =>
      this.request<AcademicSession>(`/academic/sessions/${id}`, {
        method: 'PUT',
        body: JSON.stringify(data)
      }),
    activateSession: (id: string) =>
      this.request<AcademicSession>(`/academic/sessions/${id}/activate`, {
        method: 'POST'
      }),
    archiveSession: (id: string) =>
      this.request<AcademicSession>(`/academic/sessions/${id}/archive`, {
        method: 'POST'
      }),
    deleteSession: (id: string) =>
      this.request(`/academic/sessions/${id}`, {
        method: 'DELETE'
      }),

    // Classes
    getClasses: () => this.request<SchoolClass[]>('/academic/classes'),
    createClass: (data: Partial<SchoolClass>) =>
      this.request<SchoolClass>('/academic/classes', {
        method: 'POST',
        body: JSON.stringify(data)
      }),
    updateClass: (id: string, data: Partial<SchoolClass>) =>
      this.request<SchoolClass>(`/academic/classes/${id}`, {
        method: 'PUT',
        body: JSON.stringify(data)
      }),
    archiveClass: (id: string) =>
      this.request<SchoolClass>(`/academic/classes/${id}/archive`, {
        method: 'POST'
      }),
    deleteClass: (id: string) =>
      this.request(`/academic/classes/${id}`, {
        method: 'DELETE'
      }),

    // Sections
    getSections: (classId?: string) => {
      const qs = classId ? `?classId=${classId}` : '';
      return this.request<Section[]>(`/academic/sections${qs}`);
    },
    createSection: (data: Partial<Section>) =>
      this.request<Section>('/academic/sections', {
        method: 'POST',
        body: JSON.stringify(data)
      }),
    updateSection: (id: string, data: Partial<Section>) =>
      this.request<Section>(`/academic/sections/${id}`, {
        method: 'PUT',
        body: JSON.stringify(data)
      }),
    archiveSection: (id: string) =>
      this.request<Section>(`/academic/sections/${id}/archive`, {
        method: 'POST'
      }),
    deleteSection: (id: string) =>
      this.request(`/academic/sections/${id}`, {
        method: 'DELETE'
      }),

    // Subjects
    getSubjects: () => this.request<Subject[]>('/academic/subjects'),
    createSubject: (data: Partial<Subject>) =>
      this.request<Subject>('/academic/subjects', {
        method: 'POST',
        body: JSON.stringify(data)
      }),
    updateSubject: (id: string, data: Partial<Subject>) =>
      this.request<Subject>(`/academic/subjects/${id}`, {
        method: 'PUT',
        body: JSON.stringify(data)
      }),
    assignSubjectClasses: (id: string, classIds: string[]) =>
      this.request<Subject>(`/academic/subjects/${id}/assign-classes`, {
        method: 'POST',
        body: JSON.stringify({ classIds })
      }),
    archiveSubject: (id: string) =>
      this.request<Subject>(`/academic/subjects/${id}/archive`, {
        method: 'POST'
      }),
    deleteSubject: (id: string) =>
      this.request(`/academic/subjects/${id}`, {
        method: 'DELETE'
      }),

    // Departments
    getDepartments: () => this.request<Department[]>('/academic/departments'),
    createDepartment: (data: Partial<Department>) =>
      this.request<Department>('/academic/departments', {
        method: 'POST',
        body: JSON.stringify(data)
      }),
    updateDepartment: (id: string, data: Partial<Department>) =>
      this.request<Department>(`/academic/departments/${id}`, {
        method: 'PUT',
        body: JSON.stringify(data)
      }),
    archiveDepartment: (id: string) =>
      this.request<Department>(`/academic/departments/${id}/archive`, {
        method: 'POST'
      }),
    deleteDepartment: (id: string) =>
      this.request(`/academic/departments/${id}`, {
        method: 'DELETE'
      })
  };

  getAcademicSessions = () => this.academic.getSessions();
  getSessions = () => this.academic.getSessions();
  getClasses = () => this.academic.getClasses();
  getSections = () => this.academic.getSections();
  getSubjects = () => this.academic.getSubjects();
  getDepartments = () => this.academic.getDepartments();

  // Users & Management Endpoints
  users = {
    // Teachers
    getTeachers: (params?: { search?: string; departmentId?: string; status?: string }) => {
      const query = new URLSearchParams();
      if (params?.search) query.set('search', params.search);
      if (params?.departmentId) query.set('departmentId', params.departmentId);
      if (params?.status) query.set('status', params.status);
      const qs = query.toString();
      return this.request<Teacher[]>(`/users/teachers${qs ? `?${qs}` : ''}`);
    },
    getTeacher: (id: string) => this.request<Teacher>(`/users/teachers/${id}`),
    createTeacher: (data: any) =>
      this.request<Teacher>('/users/teachers', {
        method: 'POST',
        body: JSON.stringify(data)
      }),
    updateTeacher: (id: string, data: any) =>
      this.request<Teacher>(`/users/teachers/${id}`, {
        method: 'PUT',
        body: JSON.stringify(data)
      }),
    updateTeacherStatus: (id: string, status: string) =>
      this.request<Teacher>(`/users/teachers/${id}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status })
      }),
    deleteTeacher: (id: string) =>
      this.request(`/users/teachers/${id}`, {
        method: 'DELETE'
      }),

    // Students
    getStudents: (params?: {
      search?: string;
      academicSessionId?: string;
      classId?: string;
      sectionId?: string;
      status?: string;
      limit?: number;
      page?: number;
    }) => {
      const query = new URLSearchParams();
      if (params?.search) query.set('search', params.search);
      if (params?.academicSessionId) query.set('academicSessionId', params.academicSessionId);
      if (params?.classId) query.set('classId', params.classId);
      if (params?.sectionId) query.set('sectionId', params.sectionId);
      if (params?.status) query.set('status', params.status);
      if (params?.limit) query.set('limit', String(params.limit));
      if (params?.page) query.set('page', String(params.page));
      const qs = query.toString();
      return this.request<Student[]>(`/users/students${qs ? `?${qs}` : ''}`);
    },
    getStudent: (id: string) => this.request<any>(`/users/students/${id}`),
    getStudentMasterDossier: (id: string) => this.request<StudentMasterDossier>(`/users/students/${id}`),
    uploadStudentPhoto: (id: string, avatarUrl: string) =>
      this.request<{ id: string; avatarUrl: string }>(`/users/students/${id}/photo`, {
        method: 'POST',
        body: JSON.stringify({ avatarUrl })
      }),
    deleteStudentPhoto: (id: string) =>
      this.request<{ id: string }>(`/users/students/${id}/photo`, {
        method: 'DELETE'
      }),
    uploadStudentDocument: (id: string, doc: Partial<StudentDocument>) =>
      this.request<StudentDocument>(`/users/students/${id}/documents`, {
        method: 'POST',
        body: JSON.stringify(doc)
      }),
    deleteStudentDocument: (id: string, docId: string) =>
      this.request<{ message: string }>(`/users/students/${id}/documents/${docId}`, {
        method: 'DELETE'
      }),
    createStudent: (data: any) =>
      this.request<Student>('/users/students', {
        method: 'POST',
        body: JSON.stringify(data)
      }),
    updateStudent: (id: string, data: any) =>
      this.request<Student>(`/users/students/${id}`, {
        method: 'PUT',
        body: JSON.stringify(data)
      }),
    updateStudentStatus: (id: string, status: string) =>
      this.request<Student>(`/users/students/${id}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status })
      }),
    deleteStudent: (id: string) =>
      this.request(`/users/students/${id}`, {
        method: 'DELETE'
      }),

    // Guardians & Family Household Management (Part 10A)
    getGuardians: (params?: { search?: string; status?: string; relationship?: string; academicSessionId?: string; familyId?: string; page?: number; limit?: number }) => {
      const query = new URLSearchParams();
      if (params?.search) query.set('search', params.search);
      if (params?.status) query.set('status', params.status);
      if (params?.relationship) query.set('relationship', params.relationship);
      if (params?.academicSessionId) query.set('academicSessionId', params.academicSessionId);
      if (params?.familyId) query.set('familyId', params.familyId);
      if (params?.page) query.set('page', String(params.page));
      if (params?.limit) query.set('limit', String(params.limit));
      const qs = query.toString();
      return this.request<Guardian[]>(`/users/guardians${qs ? `?${qs}` : ''}`);
    },
    getGuardian: (id: string) => this.request<Guardian>(`/users/guardians/${id}`),
    checkDuplicateGuardian: (data: { phone?: string; email?: string; name?: string; excludeId?: string }) =>
      this.request<{ success: boolean; hasDuplicate: boolean; duplicates: any[] }>('/users/guardians/check-duplicate', {
        method: 'POST',
        body: JSON.stringify(data)
      }),
    createGuardian: (data: any) =>
      this.request<Guardian>('/users/guardians', {
        method: 'POST',
        body: JSON.stringify(data)
      }),
    updateGuardian: (id: string, data: any) =>
      this.request<Guardian>(`/users/guardians/${id}`, {
        method: 'PUT',
        body: JSON.stringify(data)
      }),
    linkGuardianStudent: (id: string, payload: { studentId: string; action: 'link' | 'unlink'; relationshipType?: string; isPrimaryGuardian?: boolean; isSecondaryGuardian?: boolean; isEmergencyContact?: boolean; isAuthorizedAcademic?: boolean; isAuthorizedAttendance?: boolean; isAuthorizedFinancial?: boolean; isAuthorizedCommunication?: boolean; isPickupAuthorized?: boolean }) =>
      this.request<Guardian>(`/users/guardians/${id}/link-student`, {
        method: 'POST',
        body: JSON.stringify(payload)
      }),
    deleteGuardian: (id: string) =>
      this.request(`/users/guardians/${id}`, {
        method: 'DELETE'
      }),
    // Part 10B: Guardian Account Management (Admin Controls)
    getGuardianAccount: (id: string) =>
      this.request<GuardianAccountInfo>(`/users/guardians/${id}/account`),
    inviteGuardian: (id: string) =>
      this.request<{ invitation: ParentInvitation; activationUrl: string }>(
        `/users/guardians/${id}/invite`,
        { method: 'POST' }
      ),
    resendGuardianInvite: (id: string) =>
      this.request<{ invitation: ParentInvitation; activationUrl: string }>(
        `/users/guardians/${id}/resend-invite`,
        { method: 'POST' }
      ),
    toggleGuardianAccountStatus: (
      id: string,
      status: 'active' | 'disabled' | 'locked' | 'suspended',
      reason?: string
    ) =>
      this.request<{ userId: string; status: string }>(
        `/users/guardians/${id}/toggle-account-status`,
        {
          method: 'POST',
          body: JSON.stringify({ status, reason })
        }
      ),
    resetGuardianAccess: (id: string) =>
      this.request<{ resetToken: string; resetUrl: string }>(
        `/users/guardians/${id}/reset-access`,
        { method: 'POST' }
      ),
    getGuardianRelationships: (id: string) =>
      this.request<ParentStudentRelationship[]>(`/users/guardians/${id}/relationships`),
    saveGuardianRelationship: (id: string, data: any) =>
      this.request<ParentStudentRelationship>(`/users/guardians/${id}/relationships`, {
        method: 'POST',
        body: JSON.stringify(data)
      }),

    // Families
    getFamilies: (params?: { search?: string; status?: string; page?: number; limit?: number }) => {
      const query = new URLSearchParams();
      if (params?.search) query.set('search', params.search);
      if (params?.status) query.set('status', params.status);
      if (params?.page) query.set('page', String(params.page));
      if (params?.limit) query.set('limit', String(params.limit));
      const qs = query.toString();
      return this.request<Family[]>(`/users/families${qs ? `?${qs}` : ''}`);
    },
    getFamily: (id: string) => this.request<Family>(`/users/families/${id}`),
    createFamily: (data: any) =>
      this.request<Family>('/users/families', {
        method: 'POST',
        body: JSON.stringify(data)
      }),
    updateFamily: (id: string, data: any) =>
      this.request<Family>(`/users/families/${id}`, {
        method: 'PUT',
        body: JSON.stringify(data)
      }),
    deleteFamily: (id: string) =>
      this.request(`/users/families/${id}`, {
        method: 'DELETE'
      }),
    addFamilyGuardian: (id: string, guardianId: string) =>
      this.request<Family>(`/users/families/${id}/add-guardian`, {
        method: 'POST',
        body: JSON.stringify({ guardianId })
      }),
    addFamilyStudent: (id: string, studentId: string) =>
      this.request<Family>(`/users/families/${id}/add-student`, {
        method: 'POST',
        body: JSON.stringify({ studentId })
      }),
    removeFamilyMember: (id: string, memberType: 'guardian' | 'student', memberId: string) =>
      this.request<Family>(`/users/families/${id}/remove-member`, {
        method: 'POST',
        body: JSON.stringify({ memberType, memberId })
      }),
    checkGuardiansIntegrity: (autoHeal?: boolean) =>
      this.request<{ success: boolean; healthy: boolean; totalIssues: number; issues: string[]; autoHealed: boolean; healedCount: number }>(
        `/users/guardians-integrity-check${autoHeal ? '?autoHeal=true' : ''}`
      ),

    // Directory
    getDirectorySummary: () => this.request<any>('/users/directory'),
    getMyProfile: () => this.request<any>('/users/me/profile'),
    updateMyProfile: (data: {
      phone?: string;
      phoneNumber?: string;
      contactNumber?: string;
      email?: string;
      emergencyContact?: string;
      address?: string;
      avatarUrl?: string;
    }) =>
      this.request<any>('/users/me/profile', {
        method: 'PUT',
        body: JSON.stringify(data)
      }),
    getMyTeacherClasses: () => this.request<TeacherClassInfo[]>('/users/teachers/my-classes'),
    getMyTeacherClassSections: (classId: string) => this.request<TeacherSectionInfo[]>(`/users/teachers/my-classes/${classId}/sections`),
    getMyTeacherSubjects: () => this.request<any[]>('/users/teachers/my-subjects'),
    getMyTeacherStudents: (params?: { classId?: string; sectionId?: string; status?: string; search?: string; page?: number; limit?: number }) => {
      const q = new URLSearchParams();
      if (params?.classId) q.append('classId', params.classId);
      if (params?.sectionId) q.append('sectionId', params.sectionId);
      if (params?.status) q.append('status', params.status);
      if (params?.search) q.append('search', params.search);
      if (params?.page) q.append('page', params.page.toString());
      if (params?.limit) q.append('limit', params.limit.toString());
      const qs = q.toString();
      return this.request<TeacherStudentInfo[]>(`/users/teachers/my-students${qs ? `?${qs}` : ''}`);
    },
    getMyTeacherStudent: (studentId: string) => this.request<TeacherStudentInfo>(`/users/teachers/my-students/${studentId}`)
  };

  getMyProfile = () => this.users.getMyProfile();
  updateMyProfile = (data: any) => this.users.updateMyProfile(data);
  getMyTeacherClasses = () => this.users.getMyTeacherClasses();
  getMyTeacherClassSections = (classId: string) => this.users.getMyTeacherClassSections(classId);
  getMyTeacherSubjects = () => this.users.getMyTeacherSubjects();
  getMyTeacherStudents = (params?: { classId?: string; sectionId?: string; status?: string; search?: string; page?: number; limit?: number }) => this.users.getMyTeacherStudents(params);
  getMyTeacherStudent = (studentId: string) => this.users.getMyTeacherStudent(studentId);
  getTeachers = (params?: any) => this.users.getTeachers(params);
  getStudents = (params?: any) => this.users.getStudents(params);
  getStudentMasterDossier = (id: string) => this.users.getStudentMasterDossier(id);
  uploadStudentPhoto = (id: string, avatarUrl: string) => this.users.uploadStudentPhoto(id, avatarUrl);
  deleteStudentPhoto = (id: string) => this.users.deleteStudentPhoto(id);
  uploadStudentDocument = (id: string, doc: Partial<StudentDocument>) => this.users.uploadStudentDocument(id, doc);
  deleteStudentDocument = (id: string, docId: string) => this.users.deleteStudentDocument(id, docId);
  getGuardians = (params?: any) => this.users.getGuardians(params);
  getTeacherAssignedStudents = () => this.request<TeacherStudentInfo[]>('/users/teachers/my-students');

  // Audit Logs
  audit = {
    getLogs: (limit: number = 50) => this.request<AuditLog[]>(`/audit-logs?limit=${limit}`)
  };

  getAuditLogs = (limit: number = 50) => this.request<AuditLog[]>(`/audit-logs?limit=${limit}`);

  // Notifications
  notifications = {
    getAll: () => this.request<NotificationItem[]>('/notifications'),
    markRead: (id: string) => this.request(`/notifications/${id}/read`, { method: 'POST' }),
    markAllRead: () => this.request('/notifications/read-all', { method: 'POST' })
  };

  getNotifications = () => this.request<NotificationItem[]>('/notifications');
  markNotificationAsRead = (id: string) => this.request(`/notifications/${id}/read`, { method: 'POST' });
  markAllNotificationsAsRead = () => this.request('/notifications/read-all', { method: 'POST' });

  // Settings
  settings = {
    get: () => this.request<SchoolSettings>('/settings'),
    update: (data: Partial<SchoolSettings>) =>
      this.request<SchoolSettings>('/settings', {
        method: 'PUT',
        body: JSON.stringify(data)
      })
  };

  getSchoolSettings = () => this.request<SchoolSettings>('/settings');
  updateSchoolSettings = (data: Partial<SchoolSettings>) =>
    this.request<SchoolSettings>('/settings', {
      method: 'PUT',
      body: JSON.stringify(data)
    });

  // Attendance Management
  attendance = {
    getSettings: (params?: { academicSessionId?: string }) => {
      const q = new URLSearchParams();
      if (params?.academicSessionId) q.append('academicSessionId', params.academicSessionId);
      const qs = q.toString();
      return this.request<AttendanceSettings>(`/attendance/settings${qs ? `?${qs}` : ''}`);
    },
    updateSettings: (data: AttendanceSettings) =>
      this.request<AttendanceSettings>('/attendance/settings', {
        method: 'PUT',
        body: JSON.stringify(data)
      }),
    getSheet: (params: { classId: string; sectionId: string; date?: string; subjectId?: string }) => {
      const q = new URLSearchParams();
      q.append('classId', params.classId);
      q.append('sectionId', params.sectionId);
      if (params.date) q.append('date', params.date);
      if (params.subjectId && params.subjectId !== 'ALL') q.append('subjectId', params.subjectId);
      return this.request<AttendanceSheetData>(`/attendance/sheet?${q.toString()}`);
    },
    submit: (data: {
      classId: string;
      sectionId: string;
      subjectId?: string;
      date: string;
      records: Array<{ studentId: string; status: string; remarks?: string }>;
    }) =>
      this.request<{
        totalRecorded: number;
        presentCount: number;
        absentCount: number;
        lateCount: number;
        excusedCount: number;
        date: string;
        records: AttendanceRecord[];
      }>('/attendance', {
        method: 'POST',
        body: JSON.stringify(data)
      }),
    update: (data: {
      classId: string;
      sectionId: string;
      subjectId?: string;
      date: string;
      records: Array<{ studentId: string; status: string; remarks?: string }>;
      changeReason?: string;
    }) =>
      this.request<{ modifiedCount: number; updatedRecords: AttendanceRecord[] }>('/attendance', {
        method: 'PUT',
        body: JSON.stringify(data)
      }),
    getHistory: (params?: AttendanceFilterParams) => {
      const q = new URLSearchParams();
      if (params?.classId && params.classId !== 'ALL') q.append('classId', params.classId);
      if (params?.sectionId && params.sectionId !== 'ALL') q.append('sectionId', params.sectionId);
      if (params?.subjectId && params.subjectId !== 'ALL') q.append('subjectId', params.subjectId);
      if (params?.studentId) q.append('studentId', params.studentId);
      if (params?.date) q.append('date', params.date);
      if (params?.startDate) q.append('startDate', params.startDate);
      if (params?.endDate) q.append('endDate', params.endDate);
      if (params?.status && params.status !== 'ALL') q.append('status', params.status);
      if (params?.search) q.append('search', params.search);
      if (params?.page) q.append('page', params.page.toString());
      if (params?.limit) q.append('limit', params.limit.toString());
      const qs = q.toString();
      return this.request<AttendanceRecord[]>(`/attendance/history${qs ? `?${qs}` : ''}`);
    },
    getSummary: (params?: { classId?: string; sectionId?: string; subjectId?: string; date?: string; startDate?: string; endDate?: string }) => {
      const q = new URLSearchParams();
      if (params?.classId && params.classId !== 'ALL') q.append('classId', params.classId);
      if (params?.sectionId && params.sectionId !== 'ALL') q.append('sectionId', params.sectionId);
      if (params?.subjectId && params.subjectId !== 'ALL') q.append('subjectId', params.subjectId);
      if (params?.date) q.append('date', params.date);
      if (params?.startDate) q.append('startDate', params.startDate);
      if (params?.endDate) q.append('endDate', params.endDate);
      const qs = q.toString();
      return this.request<AttendanceSummaryStats>(`/attendance/summary${qs ? `?${qs}` : ''}`);
    },
    getStudentHistory: (studentId: string, params?: { startDate?: string; endDate?: string; subjectId?: string }) => {
      const q = new URLSearchParams();
      if (params?.startDate) q.append('startDate', params.startDate);
      if (params?.endDate) q.append('endDate', params.endDate);
      if (params?.subjectId && params.subjectId !== 'ALL') q.append('subjectId', params.subjectId);
      const qs = q.toString();
      return this.request<StudentAttendanceHistoryData>(`/attendance/students/${studentId}${qs ? `?${qs}` : ''}`);
    },

    markStudentAttendance: (data: {
      studentId: string;
      date: string;
      status: AttendanceStatus;
      remarks?: string;
      changeReason?: string;
      classId?: string;
      sectionId?: string;
      subjectId?: string;
      academicSessionId?: string;
      allowOverride?: boolean;
      overrideReason?: string;
    }) =>
      this.request<AttendanceRecord>('/attendance/students/mark', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      }),

    updateAttendanceRecord: (
      id: string,
      data: {
        status?: AttendanceStatus;
        remarks?: string;
        reason: string;
      }
    ) =>
      this.request<AttendanceRecord>(`/attendance/records/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      }),

    deleteAttendanceRecord: (id: string, reason: string) =>
      this.request<{ message: string }>(`/attendance/records/${id}`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reason })
      }),

    // Part 8B: Teacher Attendance Endpoints
    getTeacherDaily: (params?: { date?: string; academicSessionId?: string; departmentId?: string; search?: string }) => {
      const q = new URLSearchParams();
      if (params?.date) q.append('date', params.date);
      if (params?.academicSessionId) q.append('academicSessionId', params.academicSessionId);
      if (params?.departmentId) q.append('departmentId', params.departmentId);
      if (params?.search) q.append('search', params.search);
      const qs = q.toString();
      return this.request<TeacherDailyAttendanceResponse>(`/attendance/teacher/daily${qs ? `?${qs}` : ''}`);
    },

    getTeacherMonthly: (params?: { year?: number; month?: number; academicSessionId?: string; teacherProfileId?: string; departmentId?: string; search?: string }) => {
      const q = new URLSearchParams();
      if (params?.year) q.append('year', String(params.year));
      if (params?.month) q.append('month', String(params.month));
      if (params?.academicSessionId) q.append('academicSessionId', params.academicSessionId);
      if (params?.teacherProfileId) q.append('teacherProfileId', params.teacherProfileId);
      if (params?.departmentId) q.append('departmentId', params.departmentId);
      if (params?.search) q.append('search', params.search);
      const qs = q.toString();
      return this.request<TeacherMonthlyAttendanceResponse>(`/attendance/teacher/monthly${qs ? `?${qs}` : ''}`);
    },

    getMyTeacherAttendance: (params?: { year?: number; month?: number; academicSessionId?: string; teacherProfileId?: string }) => {
      const q = new URLSearchParams();
      if (params?.year) q.append('year', String(params.year));
      if (params?.month) q.append('month', String(params.month));
      if (params?.academicSessionId) q.append('academicSessionId', params.academicSessionId);
      if (params?.teacherProfileId) q.append('teacherProfileId', params.teacherProfileId);
      const qs = q.toString();
      return this.request<TeacherMyAttendanceResponse>(`/attendance/teacher/my-attendance${qs ? `?${qs}` : ''}`);
    },

    getTeacherHistory: (params?: { teacherProfileId?: string; startDate?: string; endDate?: string; status?: string; departmentId?: string; search?: string; academicSessionId?: string }) => {
      const q = new URLSearchParams();
      if (params?.teacherProfileId) q.append('teacherProfileId', params.teacherProfileId);
      if (params?.startDate) q.append('startDate', params.startDate);
      if (params?.endDate) q.append('endDate', params.endDate);
      if (params?.status) q.append('status', params.status);
      if (params?.departmentId) q.append('departmentId', params.departmentId);
      if (params?.search) q.append('search', params.search);
      if (params?.academicSessionId) q.append('academicSessionId', params.academicSessionId);
      const qs = q.toString();
      return this.request<TeacherAttendanceRecord[]>(`/attendance/teacher/history${qs ? `?${qs}` : ''}`);
    },

    markTeacherAttendance: (data: {
      teacherProfileId: string;
      date: string;
      status: TeacherAttendanceStatus;
      checkInTime?: string;
      checkOutTime?: string;
      remarks?: string;
      academicSessionId?: string;
      allowOverride?: boolean;
      overrideReason?: string;
    }) =>
      this.request<TeacherAttendanceRecord>('/attendance/teacher/mark', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      }),

    bulkMarkTeacherAttendance: (data: {
      date: string;
      academicSessionId?: string;
      records: Array<{ teacherProfileId: string; status: TeacherAttendanceStatus; checkInTime?: string; checkOutTime?: string; remarks?: string }>;
      allowOverride?: boolean;
      overrideReason?: string;
    }) =>
      this.request<{ createdCount: number; updatedCount: number; records: TeacherAttendanceRecord[] }>('/attendance/teacher/bulk-mark', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      }),

    updateTeacherAttendanceRecord: (
      id: string,
      data: {
        status?: TeacherAttendanceStatus;
        checkInTime?: string;
        checkOutTime?: string;
        remarks?: string;
        reason: string;
      }
    ) =>
      this.request<TeacherAttendanceRecord>(`/attendance/teacher/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      }),

    deleteTeacherAttendanceRecord: (id: string, reason?: string) =>
      this.request<{ message: string }>(`/attendance/teacher/${id}`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reason })
      }),

    teacherCheckIn: () =>
      this.request<TeacherAttendanceRecord>('/attendance/teacher/check-in', {
        method: 'POST'
      }),

    teacherCheckOut: () =>
      this.request<TeacherAttendanceRecord>('/attendance/teacher/check-out', {
        method: 'POST'
      }),

    // Part 8E: Reports & Analytics Endpoints
    getReportsDashboard: (params?: AttendanceReportFilterParams) => {
      const q = new URLSearchParams();
      if (params?.academicSessionId) q.append('academicSessionId', params.academicSessionId);
      if (params?.date) q.append('date', params.date);
      if (params?.startDate) q.append('startDate', params.startDate);
      if (params?.endDate) q.append('endDate', params.endDate);
      if (params?.month) q.append('month', params.month);
      if (params?.classId) q.append('classId', params.classId);
      if (params?.sectionId) q.append('sectionId', params.sectionId);
      const qs = q.toString();
      return this.request<AttendanceReportDashboardData>(`/attendance/reports/dashboard${qs ? `?${qs}` : ''}`);
    },

    getReportsStudents: (params?: AttendanceReportFilterParams) => {
      const q = new URLSearchParams();
      if (params?.academicSessionId) q.append('academicSessionId', params.academicSessionId);
      if (params?.classId) q.append('classId', params.classId);
      if (params?.sectionId) q.append('sectionId', params.sectionId);
      if (params?.studentId) q.append('studentId', params.studentId);
      if (params?.date) q.append('date', params.date);
      if (params?.startDate) q.append('startDate', params.startDate);
      if (params?.endDate) q.append('endDate', params.endDate);
      if (params?.month) q.append('month', params.month);
      if (params?.status) q.append('status', params.status);
      if (params?.gender) q.append('gender', params.gender);
      if (params?.search) q.append('search', params.search);
      if (params?.belowThresholdOnly !== undefined) q.append('belowThresholdOnly', String(params.belowThresholdOnly));
      if (params?.page) q.append('page', String(params.page));
      if (params?.limit) q.append('limit', String(params.limit));
      if (params?.sortBy) q.append('sortBy', params.sortBy);
      if (params?.sortOrder) q.append('sortOrder', params.sortOrder);
      const qs = q.toString();
      return this.request<{ data: StudentWiseAttendanceReportItem[]; pagination: AttendanceReportPagination }>(
        `/attendance/reports/students${qs ? `?${qs}` : ''}`
      );
    },

    getReportsClasses: (params?: AttendanceReportFilterParams) => {
      const q = new URLSearchParams();
      if (params?.academicSessionId) q.append('academicSessionId', params.academicSessionId);
      if (params?.classId) q.append('classId', params.classId);
      if (params?.sectionId) q.append('sectionId', params.sectionId);
      if (params?.date) q.append('date', params.date);
      if (params?.startDate) q.append('startDate', params.startDate);
      if (params?.endDate) q.append('endDate', params.endDate);
      if (params?.month) q.append('month', params.month);
      const qs = q.toString();
      return this.request<ClassSectionAttendanceReportItem[]>(`/attendance/reports/classes${qs ? `?${qs}` : ''}`);
    },

    getReportsRecords: (params?: AttendanceReportFilterParams) => {
      const q = new URLSearchParams();
      if (params?.academicSessionId) q.append('academicSessionId', params.academicSessionId);
      if (params?.classId) q.append('classId', params.classId);
      if (params?.sectionId) q.append('sectionId', params.sectionId);
      if (params?.studentId) q.append('studentId', params.studentId);
      if (params?.date) q.append('date', params.date);
      if (params?.startDate) q.append('startDate', params.startDate);
      if (params?.endDate) q.append('endDate', params.endDate);
      if (params?.month) q.append('month', params.month);
      if (params?.status) q.append('status', params.status);
      if (params?.search) q.append('search', params.search);
      if (params?.page) q.append('page', String(params.page));
      if (params?.limit) q.append('limit', String(params.limit));
      const qs = q.toString();
      return this.request<{ data: AttendanceDetailedRecordReportItem[]; pagination: AttendanceReportPagination }>(
        `/attendance/reports/records${qs ? `?${qs}` : ''}`
      );
    },

    getReportsTeachers: (params?: AttendanceReportFilterParams) => {
      const q = new URLSearchParams();
      if (params?.academicSessionId) q.append('academicSessionId', params.academicSessionId);
      if (params?.departmentId) q.append('departmentId', params.departmentId);
      if (params?.teacherId) q.append('teacherProfileId', params.teacherId);
      if (params?.date) q.append('date', params.date);
      if (params?.startDate) q.append('startDate', params.startDate);
      if (params?.endDate) q.append('endDate', params.endDate);
      if (params?.month) q.append('month', params.month);
      if (params?.status) q.append('status', params.status);
      if (params?.search) q.append('search', params.search);
      if (params?.page) q.append('page', String(params.page));
      if (params?.limit) q.append('limit', String(params.limit));
      const qs = q.toString();
      return this.request<{ data: TeacherAttendanceReportItem[]; pagination: AttendanceReportPagination }>(
        `/attendance/reports/teachers${qs ? `?${qs}` : ''}`
      );
    },

    getReportsLeaves: (params?: AttendanceReportFilterParams & { applicantType?: string }) => {
      const q = new URLSearchParams();
      if (params?.applicantType) q.append('applicantType', params.applicantType);
      if (params?.status) q.append('status', params.status);
      if (params?.leaveTypeId) q.append('leaveTypeId', params.leaveTypeId);
      if (params?.classId) q.append('classId', params.classId);
      if (params?.sectionId) q.append('sectionId', params.sectionId);
      if (params?.startDate) q.append('startDate', params.startDate);
      if (params?.endDate) q.append('endDate', params.endDate);
      if (params?.search) q.append('search', params.search);
      if (params?.page) q.append('page', String(params.page));
      if (params?.limit) q.append('limit', String(params.limit));
      const qs = q.toString();
      return this.request<{ data: LeaveReportItem[]; pagination: AttendanceReportPagination }>(
        `/attendance/reports/leaves${qs ? `?${qs}` : ''}`
      );
    },

    auditExport: (data: { reportType: string; format: string; filters?: any; recordCount: number }) =>
      this.request<{ success: boolean; message: string }>('/attendance/reports/audit-export', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      })
  };

  getAttendanceSheet = (params: { classId: string; sectionId: string; date?: string; subjectId?: string }) =>
    this.attendance.getSheet(params);
  submitAttendance = (data: any) => this.attendance.submit(data);
  updateAttendance = (data: any) => this.attendance.update(data);
  markStudentAttendance = (data: any) => this.attendance.markStudentAttendance(data);
  updateStudentAttendanceRecord = (id: string, data: any) => this.attendance.updateAttendanceRecord(id, data);
  deleteStudentAttendanceRecord = (id: string, reason: string) => this.attendance.deleteAttendanceRecord(id, reason);
  getAttendanceHistory = (params?: AttendanceFilterParams) => this.attendance.getHistory(params);
  getAttendanceSummary = (params?: any) => this.attendance.getSummary(params);
  getStudentAttendanceHistory = (studentId: string, params?: any) => this.attendance.getStudentHistory(studentId, params);

  // Part 8B Teacher Attendance Helpers
  getTeacherDailyAttendance = (params?: any) => this.attendance.getTeacherDaily(params);
  getTeacherMonthlyAttendance = (params?: any) => this.attendance.getTeacherMonthly(params);
  getMyTeacherAttendance = (params?: any) => this.attendance.getMyTeacherAttendance(params);
  getTeacherAttendanceHistory = (params?: any) => this.attendance.getTeacherHistory(params);
  markTeacherAttendance = (data: any) => this.attendance.markTeacherAttendance(data);
  bulkMarkTeacherAttendance = (data: any) => this.attendance.bulkMarkTeacherAttendance(data);
  updateTeacherAttendanceRecord = (id: string, data: any) => this.attendance.updateTeacherAttendanceRecord(id, data);
  deleteTeacherAttendanceRecord = (id: string, reason?: string) => this.attendance.deleteTeacherAttendanceRecord(id, reason);
  teacherCheckIn = () => this.attendance.teacherCheckIn();
  teacherCheckOut = () => this.attendance.teacherCheckOut();

  // Part 8E Attendance Reports & Analytics Helpers
  getAttendanceReportsDashboard = (params?: AttendanceReportFilterParams) => this.attendance.getReportsDashboard(params);
  getAttendanceReportsStudents = (params?: AttendanceReportFilterParams) => this.attendance.getReportsStudents(params);
  getAttendanceReportsClasses = (params?: AttendanceReportFilterParams) => this.attendance.getReportsClasses(params);
  getAttendanceReportsRecords = (params?: AttendanceReportFilterParams) => this.attendance.getReportsRecords(params);
  getAttendanceReportsTeachers = (params?: AttendanceReportFilterParams) => this.attendance.getReportsTeachers(params);
  getAttendanceReportsLeaves = (params?: AttendanceReportFilterParams & { applicantType?: string }) => this.attendance.getReportsLeaves(params);
  auditAttendanceReportExport = (data: { reportType: string; format: string; filters?: any; recordCount: number }) => this.attendance.auditExport(data);

  // ==========================================
  // Part 8D: Leave Types & Leave Applications
  // ==========================================
  getLeaveTypes = (params?: { applicableTo?: string; isActive?: boolean }) => {
    const q = new URLSearchParams();
    if (params?.applicableTo && params.applicableTo !== 'ALL') q.append('applicableTo', params.applicableTo);
    if (params?.isActive !== undefined) q.append('isActive', String(params.isActive));
    const qs = q.toString();
    return this.request<LeaveType[]>(`/attendance/leave-types${qs ? `?${qs}` : ''}`);
  };

  createLeaveType = (data: Partial<LeaveType>) =>
    this.request<LeaveType>('/attendance/leave-types', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });

  updateLeaveType = (id: string, data: Partial<LeaveType>) =>
    this.request<LeaveType>(`/attendance/leave-types/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });

  deleteLeaveType = (id: string) =>
    this.request<{ success: boolean; message: string }>(`/attendance/leave-types/${id}`, {
      method: 'DELETE'
    });

  calculateLeaveWorkingDays = (params: { startDate: string; endDate: string; academicSessionId?: string }) => {
    const q = new URLSearchParams();
    q.append('startDate', params.startDate);
    q.append('endDate', params.endDate);
    if (params.academicSessionId) q.append('academicSessionId', params.academicSessionId);
    return this.request<{
      startDate: string;
      endDate: string;
      totalCalendarDays: number;
      totalWorkingLeaveDays: number;
      workingDates: string[];
      nonWorkingDates: { date: string; dayType: string; reason: string }[];
    }>(`/attendance/leave/calculate-working-days?${q.toString()}`);
  };

  getLeaveApplications = (params?: {
    applicantType?: string;
    status?: string;
    classId?: string;
    sectionId?: string;
    departmentId?: string;
    search?: string;
    startDate?: string;
    endDate?: string;
  }) => {
    const q = new URLSearchParams();
    if (params?.applicantType && params.applicantType !== 'ALL') q.append('applicantType', params.applicantType);
    if (params?.status && params.status !== 'ALL') q.append('status', params.status);
    if (params?.classId && params.classId !== 'ALL') q.append('classId', params.classId);
    if (params?.sectionId && params.sectionId !== 'ALL') q.append('sectionId', params.sectionId);
    if (params?.departmentId && params.departmentId !== 'ALL') q.append('departmentId', params.departmentId);
    if (params?.search) q.append('search', params.search);
    if (params?.startDate) q.append('startDate', params.startDate);
    if (params?.endDate) q.append('endDate', params.endDate);
    const qs = q.toString();
    return this.request<LeaveApplication[]>(`/attendance/leave-applications${qs ? `?${qs}` : ''}`);
  };

  getLeaveApplicationDetail = (id: string) =>
    this.request<LeaveApplication & { workingBreakdown?: any }>(`/attendance/leave-applications/${id}`);

  submitTeacherLeave = (data: {
    leaveTypeId: string;
    startDate: string;
    endDate: string;
    reason: string;
    description?: string;
    remarks?: string;
    attachmentUrl?: string;
    attachmentName?: string;
    attachmentSize?: number;
    attachmentType?: string;
    status?: 'DRAFT' | 'SUBMITTED';
  }) =>
    this.request<LeaveApplication>('/attendance/teacher/leave', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });

  reviewLeaveApplication = (
    id: string,
    data: {
      status: 'APPROVED' | 'REJECTED' | 'UNDER_REVIEW';
      adminRemarks?: string;
      rejectionReason?: string;
    }
  ) =>
    this.request<{ success: boolean; message: string; data: LeaveApplication }>(
      `/attendance/leave-applications/${id}/review`,
      {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      }
    );

  cancelLeaveApplication = (id: string, reason?: string) =>
    this.request<{ success: boolean; message: string; data: LeaveApplication }>(
      `/attendance/leave-applications/${id}/cancel`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reason })
      }
    );

  getStudentLeaves = (params?: { status?: string }) => {
    const q = new URLSearchParams();
    if (params?.status && params.status !== 'ALL') q.append('status', params.status);
    const qs = q.toString();
    return this.request<LeaveApplication[]>(`/student/attendance/leave${qs ? `?${qs}` : ''}`);
  };

  submitStudentLeave = (data: {
    leaveTypeId?: string;
    startDate: string;
    endDate: string;
    reason: string;
    description?: string;
    remarks?: string;
    attachmentUrl?: string;
    attachmentName?: string;
    attachmentSize?: number;
    attachmentType?: string;
    status?: 'DRAFT' | 'SUBMITTED';
  }) =>
    this.request<LeaveApplication>('/student/attendance/leave', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });

  cancelStudentLeave = (id: string) =>
    this.request<{ success: boolean; message: string }>(`/student/attendance/leave/${id}`, {
      method: 'DELETE'
    });

  // ==========================================
  // Part 3D: Academic Activities Endpoints
  // ==========================================
  activities = {
    getSummary: () => this.request<any>('/activities/summary'),

    uploadFile: (payload: { fileName: string; fileSizeBytes: number; fileData?: string; fileType?: string }) =>
      this.request<{ fileUrl: string; fileName: string; fileSize: string; fileSizeBytes: number; fileType: string }>(
        '/activities/upload-file',
        {
          method: 'POST',
          body: JSON.stringify(payload)
        }
      ),

    // Homework
    getHomework: (params?: HomeworkFilterParams) => {
      const q = new URLSearchParams();
      if (params?.classId && params.classId !== 'ALL') q.append('classId', params.classId);
      if (params?.sectionId && params.sectionId !== 'ALL') q.append('sectionId', params.sectionId);
      if (params?.subjectId && params.subjectId !== 'ALL') q.append('subjectId', params.subjectId);
      if (params?.status && params.status !== 'ALL') q.append('status', params.status);
      if (params?.dueDate) q.append('dueDate', params.dueDate);
      if (params?.search) q.append('search', params.search);
      if (params?.page) q.append('page', params.page.toString());
      if (params?.limit) q.append('limit', params.limit.toString());
      const qs = q.toString();
      return this.request<Homework[]>(`/activities/homework${qs ? `?${qs}` : ''}`);
    },
    getHomeworkById: (id: string) => this.request<Homework>(`/activities/homework/${id}`),
    createHomework: (data: Partial<Homework>) =>
      this.request<Homework>('/activities/homework', {
        method: 'POST',
        body: JSON.stringify(data)
      }),
    updateHomework: (id: string, data: Partial<Homework>) =>
      this.request<Homework>(`/activities/homework/${id}`, {
        method: 'PUT',
        body: JSON.stringify(data)
      }),
    deleteHomework: (id: string) =>
      this.request(`/activities/homework/${id}`, {
        method: 'DELETE'
      }),

    // Assignments
    getAssignments: (params?: AssignmentFilterParams) => {
      const q = new URLSearchParams();
      if (params?.classId && params.classId !== 'ALL') q.append('classId', params.classId);
      if (params?.sectionId && params.sectionId !== 'ALL') q.append('sectionId', params.sectionId);
      if (params?.subjectId && params.subjectId !== 'ALL') q.append('subjectId', params.subjectId);
      if (params?.status && params.status !== 'ALL') q.append('status', params.status);
      if (params?.startDate) q.append('startDate', params.startDate);
      if (params?.dueDate) q.append('dueDate', params.dueDate);
      if (params?.search) q.append('search', params.search);
      if (params?.page) q.append('page', params.page.toString());
      if (params?.limit) q.append('limit', params.limit.toString());
      const qs = q.toString();
      return this.request<Assignment[]>(`/activities/assignments${qs ? `?${qs}` : ''}`);
    },
    getAssignmentById: (id: string) => this.request<Assignment>(`/activities/assignments/${id}`),
    createAssignment: (data: Partial<Assignment>) =>
      this.request<Assignment>('/activities/assignments', {
        method: 'POST',
        body: JSON.stringify(data)
      }),
    updateAssignment: (id: string, data: Partial<Assignment>) =>
      this.request<Assignment>(`/activities/assignments/${id}`, {
        method: 'PUT',
        body: JSON.stringify(data)
      }),
    deleteAssignment: (id: string) =>
      this.request(`/activities/assignments/${id}`, {
        method: 'DELETE'
      }),

    // Study Materials
    getMaterials: (params?: StudyMaterialFilterParams) => {
      const q = new URLSearchParams();
      if (params?.classId && params.classId !== 'ALL') q.append('classId', params.classId);
      if (params?.sectionId && params.sectionId !== 'ALL') q.append('sectionId', params.sectionId);
      if (params?.subjectId && params.subjectId !== 'ALL') q.append('subjectId', params.subjectId);
      if (params?.fileType && params.fileType !== 'ALL') q.append('fileType', params.fileType);
      if (params?.status && params.status !== 'ALL') q.append('status', params.status);
      if (params?.search) q.append('search', params.search);
      if (params?.page) q.append('page', params.page.toString());
      if (params?.limit) q.append('limit', params.limit.toString());
      const qs = q.toString();
      return this.request<StudyMaterial[]>(`/activities/materials${qs ? `?${qs}` : ''}`);
    },
    getMaterialById: (id: string) => this.request<StudyMaterial>(`/activities/materials/${id}`),
    createMaterial: (data: Partial<StudyMaterial>) =>
      this.request<StudyMaterial>('/activities/materials', {
        method: 'POST',
        body: JSON.stringify(data)
      }),
    updateMaterial: (id: string, data: Partial<StudyMaterial>) =>
      this.request<StudyMaterial>(`/activities/materials/${id}`, {
        method: 'PUT',
        body: JSON.stringify(data)
      }),
    deleteMaterial: (id: string) =>
      this.request(`/activities/materials/${id}`, {
        method: 'DELETE'
      }),

    // Class Announcements
    getAnnouncements: (params?: AnnouncementFilterParams) => {
      const q = new URLSearchParams();
      if (params?.classId && params.classId !== 'ALL') q.append('classId', params.classId);
      if (params?.sectionId && params.sectionId !== 'ALL') q.append('sectionId', params.sectionId);
      if (params?.priority && params.priority !== 'ALL') q.append('priority', params.priority);
      if (params?.status && params.status !== 'ALL') q.append('status', params.status);
      if (params?.search) q.append('search', params.search);
      if (params?.page) q.append('page', params.page.toString());
      if (params?.limit) q.append('limit', params.limit.toString());
      const qs = q.toString();
      return this.request<ClassAnnouncement[]>(`/activities/announcements${qs ? `?${qs}` : ''}`);
    },
    getAnnouncementById: (id: string) => this.request<ClassAnnouncement>(`/activities/announcements/${id}`),
    createAnnouncement: (data: Partial<ClassAnnouncement>) =>
      this.request<ClassAnnouncement>('/activities/announcements', {
        method: 'POST',
        body: JSON.stringify(data)
      }),
    updateAnnouncement: (id: string, data: Partial<ClassAnnouncement>) =>
      this.request<ClassAnnouncement>(`/activities/announcements/${id}`, {
        method: 'PUT',
        body: JSON.stringify(data)
      }),
    deleteAnnouncement: (id: string) =>
      this.request(`/activities/announcements/${id}`, {
        method: 'DELETE'
      })
  };

  // Student Portal (Part 4B & 4C)
  student = {
    getClassInfo: () => this.request<StudentClassInfo>('/student/class'),
    getSubjects: (params?: StudentSubjectFilterParams) => {
      const q = new URLSearchParams();
      if (params?.search) q.append('search', params.search);
      if (params?.type && params.type !== 'ALL' && params.type !== 'all') q.append('type', params.type);
      if (params?.status && params.status !== 'ALL' && params.status !== 'all') q.append('status', params.status);
      const qs = q.toString();
      return this.request<StudentEnrolledSubject[]>(`/student/subjects${qs ? `?${qs}` : ''}`);
    },
    getSubjectDetail: (subjectId: string) => this.request<StudentSubjectDetailData>(`/student/subjects/${subjectId}`),
    getAcademicInfo: () => this.request<StudentAcademicInfoData>('/student/academic-info'),

    // Part 4C: Student Attendance & Leave Application
    getAttendance: (params?: { month?: string; academicSessionId?: string; startDate?: string; endDate?: string }) => {
      const q = new URLSearchParams();
      if (params?.month) q.append('month', params.month);
      if (params?.academicSessionId) q.append('academicSessionId', params.academicSessionId);
      if (params?.startDate) q.append('startDate', params.startDate);
      if (params?.endDate) q.append('endDate', params.endDate);
      const qs = q.toString();
      return this.request<StudentAttendanceOverviewData>(`/student/attendance${qs ? `?${qs}` : ''}`);
    },
    getLeaveApplications: (params?: { status?: string }) => {
      const q = new URLSearchParams();
      if (params?.status && params.status !== 'ALL') q.append('status', params.status);
      const qs = q.toString();
      return this.request<StudentLeaveApplication[]>(`/student/attendance/leave${qs ? `?${qs}` : ''}`);
    },
    submitLeaveApplication: (data: {
      leaveDate: string;
      endDate?: string;
      reason: string;
      description: string;
      attachmentUrl?: string;
      attachmentName?: string;
    }) =>
      this.request<StudentLeaveApplication>('/student/attendance/leave', {
        method: 'POST',
        body: JSON.stringify(data)
      }),
    cancelLeaveApplication: (id: string) =>
      this.request(`/student/attendance/leave/${id}`, {
        method: 'DELETE'
      }),

    // Part 4D: Student Academic Activities
    getHomework: (params?: StudentHomeworkFilterParams) => {
      const q = new URLSearchParams();
      if (params?.subjectId && params.subjectId !== 'ALL' && params.subjectId !== 'all') q.append('subjectId', params.subjectId);
      if (params?.status && params.status !== 'ALL' && params.status !== 'all') q.append('status', params.status);
      if (params?.search) q.append('search', params.search);
      if (params?.dueDate) q.append('dueDate', params.dueDate);
      if (params?.assignedDate) q.append('assignedDate', params.assignedDate);
      const qs = q.toString();
      return this.request<StudentHomeworkItem[]>(`/student/homework${qs ? `?${qs}` : ''}`);
    },
    getHomeworkById: (id: string) => this.request<StudentHomeworkItem>(`/student/homework/${id}`),

    getAssignments: (params?: StudentAssignmentFilterParams) => {
      const q = new URLSearchParams();
      if (params?.subjectId && params.subjectId !== 'ALL' && params.subjectId !== 'all') q.append('subjectId', params.subjectId);
      if (params?.status && params.status !== 'ALL' && params.status !== 'all') q.append('status', params.status);
      if (params?.search) q.append('search', params.search);
      if (params?.startDate) q.append('startDate', params.startDate);
      if (params?.dueDate) q.append('dueDate', params.dueDate);
      const qs = q.toString();
      return this.request<StudentAssignmentItem[]>(`/student/assignments${qs ? `?${qs}` : ''}`);
    },
    getAssignmentById: (id: string) => this.request<StudentAssignmentItem>(`/student/assignments/${id}`),

    getMaterials: (params?: StudentMaterialFilterParams) => {
      const q = new URLSearchParams();
      if (params?.subjectId && params.subjectId !== 'ALL' && params.subjectId !== 'all') q.append('subjectId', params.subjectId);
      if (params?.fileType && params.fileType !== 'ALL' && params.fileType !== 'all') q.append('fileType', params.fileType);
      if (params?.search) q.append('search', params.search);
      const qs = q.toString();
      return this.request<StudyMaterial[]>(`/student/materials${qs ? `?${qs}` : ''}`);
    },
    getMaterialById: (id: string) => this.request<StudyMaterial>(`/student/materials/${id}`),

    getAnnouncements: (params?: StudentAnnouncementFilterParams) => {
      const q = new URLSearchParams();
      if (params?.priority && params.priority !== 'ALL' && params.priority !== 'all') q.append('priority', params.priority);
      if (params?.search) q.append('search', params.search);
      const qs = q.toString();
      return this.request<ClassAnnouncement[]>(`/student/announcements${qs ? `?${qs}` : ''}`);
    },
    getAnnouncementById: (id: string) => this.request<ClassAnnouncement>(`/student/announcements/${id}`),

    getActivitiesSummary: () => this.request<StudentActivitiesSummary>('/student/activities/summary'),

    // Part 4E: Examinations, Results, Academic Progress
    getExaminations: (params?: ExamScheduleFilterParams) => {
      const q = new URLSearchParams();
      if (params?.academicSessionId && params.academicSessionId !== 'ALL') q.append('academicSessionId', params.academicSessionId);
      if (params?.examId && params.examId !== 'ALL') q.append('examId', params.examId);
      if (params?.subjectId && params.subjectId !== 'ALL') q.append('subjectId', params.subjectId);
      if (params?.status && params.status !== 'ALL') q.append('status', params.status);
      if (params?.search) q.append('search', params.search);
      const qs = q.toString();
      return this.request<ExamScheduleItem[]>(
        `/student/examinations${qs ? `?${qs}` : ''}`
      );
    },
    getExaminationById: (id: string) => this.request<ExamScheduleItem>(`/student/examinations/${id}`),

    getResults: (params?: StudentResultsFilterParams) => {
      const q = new URLSearchParams();
      if (params?.academicSessionId && params.academicSessionId !== 'ALL') q.append('academicSessionId', params.academicSessionId);
      if (params?.examId && params.examId !== 'ALL') q.append('examId', params.examId);
      if (params?.academicYear && params.academicYear !== 'ALL') q.append('academicYear', params.academicYear);
      if (params?.search) q.append('search', params.search);
      const qs = q.toString();
      return this.request<StudentExamResult[]>(
        `/student/results${qs ? `?${qs}` : ''}`
      );
    },
    getResultById: (id: string) => this.request<StudentExamResult>(`/student/results/${id}`),
    getLatestResultSummary: () => this.request<{ latestResult: StudentExamResult; totalExamsTaken: number; cumulativeGPA: number; currentSessionGPA: number } | null>('/student/results/summary/latest'),
    getAcademicProgress: () => this.request<StudentAcademicProgressOverview>('/student/progress'),
    getGradingScale: () => this.request<GradingScaleItem[]>('/student/grading-scale'),
    getFees: () => this.request<{ fees: StudentFeeRecord[]; summary: any }>('/student/fees'),
    getFeeById: (id: string) => this.request<InvoiceDetailResponse>(`/student/fees/${id}`),
    getInvoice: (invoiceNumber: string) => this.request<InvoiceDetailResponse>(`/student/invoices/${invoiceNumber}`)
  };

  getMyClassInfo = () => this.student.getClassInfo();
  getMyEnrolledSubjects = (params?: StudentSubjectFilterParams) => this.student.getSubjects(params);
  getMySubjectDetail = (subjectId: string) => this.student.getSubjectDetail(subjectId);
  getMyAcademicInfo = () => this.student.getAcademicInfo();
  getMyAttendance = (params?: { month?: string; academicSessionId?: string; startDate?: string; endDate?: string }) =>
    this.student.getAttendance(params);
  getMyLeaveApplications = (params?: { status?: string }) => this.student.getLeaveApplications(params);
  submitMyLeaveApplication = (data: {
    leaveDate: string;
    endDate?: string;
    reason: string;
    description: string;
    attachmentUrl?: string;
    attachmentName?: string;
  }) => this.student.submitLeaveApplication(data);
  cancelMyLeaveApplication = (id: string) => this.student.cancelLeaveApplication(id);

  // Top-level Student Academic Activity helpers
  getMyHomework = (params?: StudentHomeworkFilterParams) => this.student.getHomework(params);
  getMyHomeworkById = (id: string) => this.student.getHomeworkById(id);
  getMyAssignments = (params?: StudentAssignmentFilterParams) => this.student.getAssignments(params);
  getMyAssignmentById = (id: string) => this.student.getAssignmentById(id);
  getMyMaterials = (params?: StudentMaterialFilterParams) => this.student.getMaterials(params);
  getMyMaterialById = (id: string) => this.student.getMaterialById(id);
  getMyAnnouncements = (params?: StudentAnnouncementFilterParams) => this.student.getAnnouncements(params);
  getMyAnnouncementById = (id: string) => this.student.getAnnouncementById(id);
  getMyActivitiesSummary = () => this.student.getActivitiesSummary();

  // Part 4E helpers
  getMyExaminations = (params?: ExamScheduleFilterParams) => this.student.getExaminations(params);
  getMyExaminationById = (id: string) => this.student.getExaminationById(id);
  getMyResults = (params?: StudentResultsFilterParams) => this.student.getResults(params);
  getMyResultById = (id: string) => this.student.getResultById(id);
  getMyLatestResultSummary = () => this.student.getLatestResultSummary();
  getMyAcademicProgress = () => this.student.getAcademicProgress();
  getGradingScale = () => this.student.getGradingScale();

  // Part 7B Student Fee Helpers
  getMyFees = () => this.student.getFees();
  getMyFeeById = (id: string) => this.student.getFeeById(id);

  // Part 5A & 10B: Guardian Portal API Namespace
  guardian = {
    getContext: (childId?: string) => {
      const q = childId ? `?childId=${encodeURIComponent(childId)}` : '';
      return this.request<GuardianContextData>(`/guardian/context${q}`);
    },
    switchChild: (studentId: string) =>
      this.request<{
        selectedChildId: string;
        selectedChild: GuardianChildSummary;
        permissions: any;
      }>('/guardian/switch-child', {
        method: 'POST',
        body: JSON.stringify({ studentId })
      }),
    getDashboard: (childId?: string) => {
      const q = childId ? `?childId=${encodeURIComponent(childId)}` : '';
      return this.request<GuardianDashboardData>(`/guardian/dashboard${q}`);
    },
    getChildDashboardSnapshot: (studentId: string) =>
      this.request<{
        studentSummary: GuardianChildSummary;
        academicSnapshot: import('../types/index.js').GuardianChildAcademicSnapshot;
        attendanceSnapshot: import('../types/index.js').GuardianChildAttendanceSnapshot;
        feesSnapshot: import('../types/index.js').GuardianChildFeesSnapshot;
        recentActivities: import('../types/index.js').GuardianChildActivityItem[];
        permissions: any;
      }>(`/guardian/children/${studentId}/dashboard-snapshot`),
    getChildren: () => this.request<GuardianChildSummary[]>('/guardian/children'),
    getChildDossier: (studentId: string) => this.request<GuardianChildDossier>(`/guardian/children/${studentId}`),
    getChildAcademicOverview: (
      studentId: string,
      params?: { search?: string; type?: string; sessionId?: string }
    ) => {
      const q = new URLSearchParams();
      if (params?.search) q.append('search', params.search);
      if (params?.type && params.type !== 'all') q.append('type', params.type);
      if (params?.sessionId) q.append('sessionId', params.sessionId);
      const qs = q.toString();
      return this.request<GuardianChildAcademicOverview>(
        `/guardian/children/${studentId}/academic-overview${qs ? `?${qs}` : ''}`
      );
    },
    getProfile: () => this.request<Guardian>('/guardian/profile'),
    updateProfile: (payload: GuardianProfileUpdatePayload) =>
      this.request<Guardian>('/guardian/profile', {
        method: 'PUT',
        body: JSON.stringify(payload)
      }),
    getNotifications: (params?: GuardianNotificationFilterParams) => {
      const q = new URLSearchParams();
      if (params?.category && params.category !== 'all') q.append('category', params.category);
      if (params?.unreadOnly !== undefined) q.append('unreadOnly', String(params.unreadOnly));
      if (params?.search) q.append('search', params.search);
      const qs = q.toString();
      return this.request<NotificationItem[]>(`/guardian/notifications${qs ? `?${qs}` : ''}`);
    },
    markNotificationRead: (id: string) =>
      this.request<void>(`/guardian/notifications/${id}/read`, {
        method: 'PATCH'
      }),
    markAllNotificationsRead: () =>
      this.request<void>('/guardian/notifications/mark-all-read', {
        method: 'POST'
      }),
    getChildAttendance: (
      studentId: string,
      params?: { month?: string; academicSessionId?: string; startDate?: string; endDate?: string }
    ) => {
      const q = new URLSearchParams();
      if (params?.month) q.append('month', params.month);
      if (params?.academicSessionId && params.academicSessionId !== 'ALL') q.append('academicSessionId', params.academicSessionId);
      if (params?.startDate) q.append('startDate', params.startDate);
      if (params?.endDate) q.append('endDate', params.endDate);
      const qs = q.toString();
      return this.request<GuardianChildAttendanceOverviewData>(
        `/guardian/children/${studentId}/attendance${qs ? `?${qs}` : ''}`
      );
    },
    getChildLeaveApplications: (studentId: string, params?: { status?: string }) => {
      const q = new URLSearchParams();
      if (params?.status && params.status !== 'ALL') q.append('status', params.status);
      const qs = q.toString();
      return this.request<StudentLeaveApplication[]>(
        `/guardian/children/${studentId}/leave-applications${qs ? `?${qs}` : ''}`
      );
    },
    submitChildLeaveApplication: (
      studentId: string,
      payload: {
        leaveDate: string;
        endDate?: string;
        reason: string;
        description: string;
        attachmentUrl?: string;
        attachmentName?: string;
      }
    ) =>
      this.request<StudentLeaveApplication>(`/guardian/children/${studentId}/leave-applications`, {
        method: 'POST',
        body: JSON.stringify(payload)
      }),
    cancelChildLeaveApplication: (studentId: string, leaveId: string) =>
      this.request<{ message: string }>(`/guardian/children/${studentId}/leave-applications/${leaveId}`, {
        method: 'DELETE'
      }),
    getChildHomework: (
      studentId: string,
      params?: { subjectId?: string; status?: string; search?: string; dueDate?: string; assignedDate?: string }
    ) => {
      const q = new URLSearchParams();
      if (params?.subjectId && params.subjectId !== 'ALL') q.append('subjectId', params.subjectId);
      if (params?.status && params.status !== 'ALL') q.append('status', params.status);
      if (params?.search) q.append('search', params.search);
      if (params?.dueDate) q.append('dueDate', params.dueDate);
      if (params?.assignedDate) q.append('assignedDate', params.assignedDate);
      const qs = q.toString();
      return this.request<GuardianChildHomeworkResponse>(
        `/guardian/children/${studentId}/homework${qs ? `?${qs}` : ''}`
      );
    },
    getChildHomeworkDetail: (studentId: string, homeworkId: string) =>
      this.request<StudentHomeworkItem>(`/guardian/children/${studentId}/homework/${homeworkId}`),
    getChildAssignments: (
      studentId: string,
      params?: { subjectId?: string; status?: string; search?: string; startDate?: string; dueDate?: string }
    ) => {
      const q = new URLSearchParams();
      if (params?.subjectId && params.subjectId !== 'ALL') q.append('subjectId', params.subjectId);
      if (params?.status && params.status !== 'ALL') q.append('status', params.status);
      if (params?.search) q.append('search', params.search);
      if (params?.startDate) q.append('startDate', params.startDate);
      if (params?.dueDate) q.append('dueDate', params.dueDate);
      const qs = q.toString();
      return this.request<GuardianChildAssignmentResponse>(
        `/guardian/children/${studentId}/assignments${qs ? `?${qs}` : ''}`
      );
    },
    getChildAssignmentDetail: (studentId: string, assignmentId: string) =>
      this.request<StudentAssignmentItem>(`/guardian/children/${studentId}/assignments/${assignmentId}`),
    getChildStudyMaterials: (
      studentId: string,
      params?: { subjectId?: string; fileType?: string; search?: string }
    ) => {
      const q = new URLSearchParams();
      if (params?.subjectId && params.subjectId !== 'ALL') q.append('subjectId', params.subjectId);
      if (params?.fileType && params.fileType !== 'ALL') q.append('fileType', params.fileType);
      if (params?.search) q.append('search', params.search);
      const qs = q.toString();
      return this.request<GuardianChildMaterialResponse>(
        `/guardian/children/${studentId}/study-materials${qs ? `?${qs}` : ''}`
      );
    },
    getChildStudyMaterialDetail: (studentId: string, materialId: string) =>
      this.request<StudyMaterial>(`/guardian/children/${studentId}/study-materials/${materialId}`),
    getChildAnnouncements: (
      studentId: string,
      params?: { priority?: string; search?: string }
    ) => {
      const q = new URLSearchParams();
      if (params?.priority && params.priority !== 'ALL') q.append('priority', params.priority);
      if (params?.search) q.append('search', params.search);
      const qs = q.toString();
      return this.request<GuardianChildAnnouncementResponse>(
        `/guardian/children/${studentId}/announcements${qs ? `?${qs}` : ''}`
      );
    },
    getChildAnnouncementDetail: (studentId: string, announcementId: string) =>
      this.request<ClassAnnouncement>(`/guardian/children/${studentId}/announcements/${announcementId}`),
    markAnnouncementRead: (studentId: string, announcementId: string) =>
      this.request<{ success: boolean; message: string; data: any }>(
        `/guardian/children/${studentId}/announcements/${announcementId}/read`,
        { method: 'POST' }
      ),
    getChildActivitiesSummary: (studentId: string) =>
      this.request<GuardianChildActivitiesSummaryResponse>(
        `/guardian/children/${studentId}/activities-summary`
      ),

    // Part 5E: Examinations & Schedules
    getChildExaminations: (
      studentId: string,
      params?: {
        academicSessionId?: string;
        examId?: string;
        subjectId?: string;
        status?: string;
        search?: string;
      }
    ) => {
      const q = new URLSearchParams();
      if (params?.academicSessionId && params.academicSessionId !== 'ALL') q.append('academicSessionId', params.academicSessionId);
      if (params?.examId && params.examId !== 'ALL') q.append('examId', params.examId);
      if (params?.subjectId && params.subjectId !== 'ALL') q.append('subjectId', params.subjectId);
      if (params?.status && params.status !== 'ALL') q.append('status', params.status);
      if (params?.search) q.append('search', params.search);
      const qs = q.toString();
      return this.request<GuardianChildExaminationsResponse>(
        `/guardian/children/${studentId}/examinations${qs ? `?${qs}` : ''}`
      );
    },
    getChildExaminationDetail: (studentId: string, examScheduleId: string) =>
      this.request<ExamScheduleItem>(`/guardian/children/${studentId}/examinations/${examScheduleId}`),

    // Part 5E: Results & Marks
    getChildResults: (
      studentId: string,
      params?: {
        academicSessionId?: string;
        examId?: string;
        academicYear?: string;
        search?: string;
      }
    ) => {
      const q = new URLSearchParams();
      if (params?.academicSessionId && params.academicSessionId !== 'ALL') q.append('academicSessionId', params.academicSessionId);
      if (params?.examId && params.examId !== 'ALL') q.append('examId', params.examId);
      if (params?.academicYear && params.academicYear !== 'ALL') q.append('academicYear', params.academicYear);
      if (params?.search) q.append('search', params.search);
      const qs = q.toString();
      return this.request<GuardianChildResultsResponse>(
        `/guardian/children/${studentId}/results${qs ? `?${qs}` : ''}`
      );
    },
    getChildResultDetail: (studentId: string, resultId: string) =>
      this.request<StudentExamResult>(`/guardian/children/${studentId}/results/${resultId}`),
    getChildReportCard: (studentId: string, resultId: string) =>
      this.request<ReportCardDetail>(`/guardian/children/${studentId}/results/${resultId}/report-card`),

    // Part 5E: Academic Progress Analytics
    getChildProgress: (studentId: string) =>
      this.request<GuardianChildProgressResponse>(
        `/guardian/children/${studentId}/progress`
      ),

    // Part 5E: Children Comparison Overview
    getChildrenComparison: () =>
      this.request<GuardianChildrenComparisonResponse>('/guardian/children-comparison'),

    // Part 5F: Fee & Payment Management
    getChildFees: (params?: {
      studentId?: string;
      status?: string;
      sessionId?: string;
      term?: string;
      feeType?: string;
      search?: string;
    }) => {
      const q = new URLSearchParams();
      if (params?.studentId) q.append('studentId', params.studentId);
      if (params?.status && params.status !== 'ALL') q.append('status', params.status);
      if (params?.sessionId && params.sessionId !== 'ALL') q.append('sessionId', params.sessionId);
      if (params?.term && params.term !== 'ALL') q.append('term', params.term);
      if (params?.feeType && params.feeType !== 'ALL') q.append('feeType', params.feeType);
      if (params?.search) q.append('search', params.search);
      const qs = q.toString();
      return this.request<GuardianChildFeesResponse>(`/guardian/fees${qs ? `?${qs}` : ''}`);
    },

    getFamilyFeeOverview: () =>
      this.request<GuardianFamilyFeeOverviewResponse>('/guardian/fees/family-overview'),

    getFeeDetail: (feeId: string) =>
      this.request<GuardianChildFeeDetailResponse>(`/guardian/fees/${feeId}`),

    getPaymentHistory: (params?: {
      studentId?: string;
      paymentMethod?: string;
      status?: string;
      startDate?: string;
      endDate?: string;
      search?: string;
    }) => {
      const q = new URLSearchParams();
      if (params?.studentId && params.studentId !== 'ALL') q.append('studentId', params.studentId);
      if (params?.paymentMethod && params.paymentMethod !== 'ALL') q.append('paymentMethod', params.paymentMethod);
      if (params?.status && params.status !== 'ALL') q.append('status', params.status);
      if (params?.startDate) q.append('startDate', params.startDate);
      if (params?.endDate) q.append('endDate', params.endDate);
      if (params?.search) q.append('search', params.search);
      const qs = q.toString();
      return this.request<GuardianPaymentHistoryResponse>(`/guardian/payments${qs ? `?${qs}` : ''}`);
    },

    payFee: (payload: {
      feeId: string;
      amount: number;
      paymentMethod: string;
      cardholderName?: string;
      notes?: string;
      idempotencyKey?: string;
    }) =>
      this.request<{
        transaction: FeePaymentTransaction;
        feeRecord: StudentFeeRecord;
        receiptNumber: string;
      }>('/guardian/fees/pay', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    getPaymentReceipt: (transactionId: string) =>
      this.request<FeePaymentReceipt>(`/guardian/payments/${transactionId}/receipt`)
  };

  // ==========================================
  // Part 6A: Examination Setup & Management
  // ==========================================
  examinations = {
    getExamTypes: () => this.request<string[]>('/examinations/exam-types'),

    addExamType: (name: string) =>
      this.request<string[]>('/examinations/exam-types', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name })
      }),

    getExaminations: (params?: ExamFilterParams) => {
      const q = new URLSearchParams();
      if (params?.academicSessionId && params.academicSessionId !== 'ALL')
        q.append('academicSessionId', params.academicSessionId);
      if (params?.classId && params.classId !== 'ALL')
        q.append('classId', params.classId);
      if (params?.sectionId && params.sectionId !== 'ALL')
        q.append('sectionId', params.sectionId);
      if (params?.status && params.status !== 'ALL')
        q.append('status', params.status);
      if (params?.examType && params.examType !== 'ALL')
        q.append('examType', params.examType);
      if (params?.search)
        q.append('search', params.search);
      if (params?.includeArchived)
        q.append('includeArchived', 'true');
      const qs = q.toString();
      return this.request<{
        data: Examination[];
        stats: {
          total: number;
          draft: number;
          scheduled: number;
          ongoing: number;
          completed: number;
          published: number;
          archived: number;
        };
      }>(`/examinations${qs ? `?${qs}` : ''}`);
    },

    getExamById: (id: string) =>
      this.request<{
        data: Examination;
        metadata: {
          availableClassSubjects: Subject[];
          availableTeachers: Array<{ id: string; name: string; designation: string; department: string }>;
        };
      }>(`/examinations/${id}`),

    createExam: (payload: CreateExamPayload) =>
      this.request<Examination>('/examinations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    updateExam: (id: string, payload: UpdateExamPayload) =>
      this.request<Examination>(`/examinations/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    updateExamStatus: (id: string, status: ExaminationStatus) =>
      this.request<Examination>(`/examinations/${id}/status`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status })
      }),

    archiveExam: (id: string) =>
      this.request<Examination>(`/examinations/${id}/archive`, {
        method: 'POST'
      }),

    deleteExam: (id: string) =>
      this.request<{ success: boolean; message: string }>(`/examinations/${id}`, {
        method: 'DELETE'
      }),

    addSubjectConfig: (examId: string, payload: ExamSubjectConfigPayload) =>
      this.request<Examination>(`/examinations/${examId}/subjects`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    updateSubjectConfig: (
      examId: string,
      configId: string,
      payload: Partial<ExamSubjectConfigPayload>
    ) =>
      this.request<Examination>(`/examinations/${examId}/subjects/${configId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    deleteSubjectConfig: (examId: string, configId: string) =>
      this.request<Examination>(`/examinations/${examId}/subjects/${configId}`, {
        method: 'DELETE'
      }),

    bulkImportClassSubjects: (
      examId: string,
      options?: { defaultFullMarks?: number; defaultPassMarks?: number; defaultDuration?: number }
    ) =>
      this.request<Examination>(`/examinations/${examId}/bulk-subjects`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(options || {})
      }),

    // Part 6B: Master Schedule & Conflict Engine
    validateScheduleConflict: (payload: ScheduleConflictCheckPayload) =>
      this.request<{
        success: boolean;
        hasConflicts: boolean;
        conflicts: ExamScheduleConflict[];
      }>('/examinations/schedules/validate-conflict', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    getSchedules: (params?: ExamScheduleAdminFilterParams) => {
      const q = new URLSearchParams();
      if (params?.academicSessionId && params.academicSessionId !== 'ALL')
        q.append('academicSessionId', params.academicSessionId);
      if (params?.examId && params.examId !== 'ALL')
        q.append('examId', params.examId);
      if (params?.classId && params.classId !== 'ALL')
        q.append('classId', params.classId);
      if (params?.sectionId && params.sectionId !== 'ALL')
        q.append('sectionId', params.sectionId);
      if (params?.subjectId && params.subjectId !== 'ALL')
        q.append('subjectId', params.subjectId);
      if (params?.teacherId && params.teacherId !== 'ALL')
        q.append('teacherId', params.teacherId);
      if (params?.roomNumber && params.roomNumber !== 'ALL')
        q.append('roomNumber', params.roomNumber);
      if (params?.status && params.status !== 'ALL')
        q.append('status', params.status);
      if (params?.date)
        q.append('date', params.date);
      if (params?.startDate)
        q.append('startDate', params.startDate);
      if (params?.endDate)
        q.append('endDate', params.endDate);
      if (params?.search)
        q.append('search', params.search);
      if (params?.page)
        q.append('page', params.page.toString());
      if (params?.limit)
        q.append('limit', params.limit.toString());
      const qs = q.toString();
      return this.request<{
        data: ExamScheduleItem[];
        total: number;
        stats: {
          total: number;
          scheduled: number;
          ongoing: number;
          completed: number;
          postponed: number;
          cancelled: number;
        };
        filterOptions: {
          distinctRooms: string[];
          distinctDates: string[];
        };
      }>(`/examinations/schedules${qs ? `?${qs}` : ''}`);
    },

    getScheduleById: (id: string) =>
      this.request<{
        data: ExamScheduleItem & {
          examDetails?: any;
          invigilatorDetails?: any;
        };
      }>(`/examinations/schedules/${id}`),

    createSchedule: (payload: CreateExamSchedulePayload) =>
      this.request<{ success: boolean; message: string; data: ExamScheduleItem }>('/examinations/schedules', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    updateSchedule: (id: string, payload: UpdateExamSchedulePayload) =>
      this.request<{ success: boolean; message: string; data: ExamScheduleItem }>(`/examinations/schedules/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    updateScheduleStatus: (id: string, status: ExamStatus) =>
      this.request<{ success: boolean; message: string; data: ExamScheduleItem }>(`/examinations/schedules/${id}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status })
      }),

    assignScheduleInvigilator: (id: string, teacherId?: string) =>
      this.request<{ success: boolean; message: string; data: ExamScheduleItem }>(`/examinations/schedules/${id}/invigilator`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ teacherId })
      }),

    deleteSchedule: (id: string) =>
      this.request<{ success: boolean; message: string }>(`/examinations/schedules/${id}`, {
        method: 'DELETE'
      }),

    getAssignedSchedules: () =>
      this.request<{
        data: ExamScheduleItem[];
        total: number;
      }>('/examinations/assigned-schedules'),

    // Part 6C: Teacher Marks Entry & Admin Review
    getTeacherAssignedSubjects: () =>
      this.request<TeacherAssignedExamSubject[]>('/examinations/teacher/assigned-subjects'),

    getTeacherMarksSheet: (examId: string, subjectId: string) =>
      this.request<{
        exam: any;
        subject: any;
        submission: any;
        status: any;
        isEditable: boolean;
        stats: {
          totalStudents: number;
          enteredCount: number;
          absentCount: number;
          exemptCount: number;
          passedCount: number;
          failedCount: number;
          isComplete: boolean;
        };
        students: StudentMarkItem[];
      }>(`/examinations/teacher/marks-sheet?examId=${encodeURIComponent(examId)}&subjectId=${encodeURIComponent(subjectId)}`),

    saveDraftMarks: (payload: SaveDraftMarksPayload) =>
      this.request<ExamMarksSubmission>('/examinations/teacher/save-draft', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    submitMarks: (payload: SubmitMarksPayload) =>
      this.request<ExamMarksSubmission>('/examinations/teacher/submit-marks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    getAdminMarksSubmissions: (params?: AdminMarksSubmissionFilterParams) => {
      const query = new URLSearchParams();
      if (params?.academicSessionId) query.append('academicSessionId', params.academicSessionId);
      if (params?.examId) query.append('examId', params.examId);
      if (params?.classId) query.append('classId', params.classId);
      if (params?.sectionId) query.append('sectionId', params.sectionId);
      if (params?.subjectId) query.append('subjectId', params.subjectId);
      if (params?.teacherId) query.append('teacherId', params.teacherId);
      if (params?.status) query.append('status', params.status);
      if (params?.search) query.append('search', params.search);
      if (params?.page) query.append('page', params.page.toString());
      if (params?.limit) query.append('limit', params.limit.toString());
      const qs = query.toString();
      return this.request<ExamMarksSubmission[]>(`/examinations/admin/marks-submissions${qs ? `?${qs}` : ''}`);
    },

    returnMarksToTeacher: (submissionId: string, reason: string) =>
      this.request<ExamMarksSubmission>(`/examinations/admin/return-marks/${submissionId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reason })
      }),

    unlockMarks: (submissionId: string) =>
      this.request<ExamMarksSubmission>(`/examinations/admin/unlock-marks/${submissionId}`, {
        method: 'POST'
      }),

    // Part 6D: Grading Scale Management
    getGradingScale: () =>
      this.request<GradingScaleItem[]>('/examinations/grading-scale'),

    createGradeRule: (data: Partial<GradingScaleItem>) =>
      this.request<GradingScaleItem[]>('/examinations/grading-scale', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      }),

    updateGradeRule: (gradeName: string, data: Partial<GradingScaleItem>) =>
      this.request<GradingScaleItem[]>(`/examinations/grading-scale/${encodeURIComponent(gradeName)}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      }),

    deleteGradeRule: (gradeName: string) =>
      this.request<GradingScaleItem[]>(`/examinations/grading-scale/${encodeURIComponent(gradeName)}`, {
        method: 'DELETE'
      }),

    batchUpdateGradingScale: (items: GradingScaleItem[]) =>
      this.request<GradingScaleItem[]>('/examinations/grading-scale/batch', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ items })
      }),

    resetDefaultGradingScale: () =>
      this.request<GradingScaleItem[]>('/examinations/grading-scale/reset-default', {
        method: 'POST'
      }),

    // Part 6D: Result Calculation & Status
    getCalculationStatus: (examId: string) =>
      this.request<CalculationReadinessInfo>(`/examinations/calculation-status/${examId}`),

    calculateResults: (payload: CalculateResultsPayload) =>
      this.request<{
        totalCalculated: number;
        passedCount: number;
        failedCount: number;
        distinctionCount: number;
        averageGpa: number;
        averagePercentage: number;
      }>('/examinations/calculate-results', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    getResultsPreview: (params?: AdminResultPreviewFilterParams) => {
      const query = new URLSearchParams();
      if (params?.academicSessionId) query.append('academicSessionId', params.academicSessionId);
      if (params?.examId) query.append('examId', params.examId);
      if (params?.classId) query.append('classId', params.classId);
      if (params?.sectionId) query.append('sectionId', params.sectionId);
      if (params?.status) query.append('status', params.status);
      if (params?.search) query.append('search', params.search);
      if (params?.page) query.append('page', params.page.toString());
      if (params?.limit) query.append('limit', params.limit.toString());
      const qs = query.toString();
      return this.request<StudentExamResult[]>(`/examinations/results-preview${qs ? `?${qs}` : ''}`);
    },

    getResultDetail: (resultId: string) =>
      this.request<StudentExamResult>(`/examinations/results-preview/${resultId}`),

    // Part 6E: Result Review, Approval & Publishing
    getResultsReview: (params?: ResultReviewFilterParams) => {
      const query = new URLSearchParams();
      if (params?.academicSessionId) query.append('academicSessionId', params.academicSessionId);
      if (params?.examId) query.append('examId', params.examId);
      if (params?.classId) query.append('classId', params.classId);
      if (params?.sectionId) query.append('sectionId', params.sectionId);
      if (params?.subjectId) query.append('subjectId', params.subjectId);
      if (params?.workflowStatus) query.append('workflowStatus', params.workflowStatus);
      if (params?.resultStatus) query.append('resultStatus', params.resultStatus);
      if (params?.search) query.append('search', params.search);
      if (params?.page) query.append('page', params.page.toString());
      if (params?.limit) query.append('limit', params.limit.toString());
      const qs = query.toString();
      return this.request<ResultReviewResponse>(`/examinations/results/review${qs ? `?${qs}` : ''}`);
    },

    getResultReviewDetail: (resultId: string) =>
      this.request<StudentExamResult>(`/examinations/results/review/${resultId}`),

    changeResultStatus: (resultId: string, payload: ChangeResultStatusPayload) =>
      this.request<StudentExamResult>(`/examinations/results/${resultId}/status`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    bulkChangeResultStatus: (payload: BulkChangeResultStatusPayload) =>
      this.request<{
        message: string;
        updatedCount: number;
        failedCount: number;
        failedItems: Array<{ id: string; message: string }>;
        data: StudentExamResult[];
      }>('/examinations/results/bulk-status', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    returnResultsForCorrection: (payload: ReturnCorrectionPayload) =>
      this.request<{
        message: string;
        updatedCount: number;
        data: StudentExamResult[];
      }>('/examinations/results/return-correction', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    bulkApproveResults: (payload: BulkApproveResultsPayload) =>
      this.request<{
        message: string;
        approvedCount: number;
        skippedCount: number;
        data: StudentExamResult[];
      }>('/examinations/results/bulk-approve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    publishResults: (payload: PublishResultsPayload) =>
      this.request<{
        message: string;
        publishedCount: number;
        skippedUnapprovedCount: number;
        data: StudentExamResult[];
      }>('/examinations/results/publish', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    unpublishReopenResults: (payload: UnpublishReopenPayload) =>
      this.request<{
        message: string;
        reopenedCount: number;
        data: StudentExamResult[];
      }>('/examinations/results/unpublish-reopen', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    // Part 6F: Report Cards, Merit & Academic Reports
    getMeritConfig: () =>
      this.request<MeritRankingConfig>('/examinations/merit-config'),

    updateMeritConfig: (payload: MeritRankingConfig) =>
      this.request<MeritRankingConfig>('/examinations/merit-config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    calculateMeritPositions: (payload: { examId: string; classId?: string; sectionId?: string }) =>
      this.request<{
        message: string;
        updatedCount: number;
        data: any[];
      }>('/examinations/calculate-merit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    getMeritList: (params?: {
      academicSessionId?: string;
      examId?: string;
      classId?: string;
      sectionId?: string;
      includeUnpublished?: boolean;
    }) => {
      const query = new URLSearchParams();
      if (params?.academicSessionId) query.append('academicSessionId', params.academicSessionId);
      if (params?.examId) query.append('examId', params.examId);
      if (params?.classId) query.append('classId', params.classId);
      if (params?.sectionId) query.append('sectionId', params.sectionId);
      if (params?.includeUnpublished) query.append('includeUnpublished', 'true');
      const qs = query.toString();
      return this.request<MeritListResponse>(`/examinations/merit-list${qs ? `?${qs}` : ''}`);
    },

    getReportCardsList: (params?: {
      academicSessionId?: string;
      examId?: string;
      classId?: string;
      sectionId?: string;
      studentId?: string;
      search?: string;
      page?: number;
      limit?: number;
    }) => {
      const query = new URLSearchParams();
      if (params?.academicSessionId) query.append('academicSessionId', params.academicSessionId);
      if (params?.examId) query.append('examId', params.examId);
      if (params?.classId) query.append('classId', params.classId);
      if (params?.sectionId) query.append('sectionId', params.sectionId);
      if (params?.studentId) query.append('studentId', params.studentId);
      if (params?.search) query.append('search', params.search);
      if (params?.page) query.append('page', params.page.toString());
      if (params?.limit) query.append('limit', params.limit.toString());
      const qs = query.toString();
      return this.request<StudentExamResult[]>(`/examinations/report-cards${qs ? `?${qs}` : ''}`);
    },

    getReportCardDetail: (resultId: string) =>
      this.request<ReportCardDetail>(`/examinations/report-cards/${resultId}`),

    getClassResultSummary: (params?: {
      academicSessionId?: string;
      examId?: string;
      classId?: string;
      sectionId?: string;
    }) => {
      const query = new URLSearchParams();
      if (params?.academicSessionId) query.append('academicSessionId', params.academicSessionId);
      if (params?.examId) query.append('examId', params.examId);
      if (params?.classId) query.append('classId', params.classId);
      if (params?.sectionId) query.append('sectionId', params.sectionId);
      const qs = query.toString();
      return this.request<ClassResultSummaryData>(`/examinations/class-summary${qs ? `?${qs}` : ''}`);
    },

    getSubjectPerformanceReport: (params?: {
      academicSessionId?: string;
      examId?: string;
      classId?: string;
      sectionId?: string;
      subjectId?: string;
    }) => {
      const query = new URLSearchParams();
      if (params?.academicSessionId) query.append('academicSessionId', params.academicSessionId);
      if (params?.examId) query.append('examId', params.examId);
      if (params?.classId) query.append('classId', params.classId);
      if (params?.sectionId) query.append('sectionId', params.sectionId);
      if (params?.subjectId) query.append('subjectId', params.subjectId);
      const qs = query.toString();
      return this.request<SubjectPerformanceReportResponse>(`/examinations/subject-performance${qs ? `?${qs}` : ''}`);
    },

    getStudentPerformanceHistory: (studentId: string) =>
      this.request<StudentPerformanceHistoryResponse>(`/examinations/student-performance/${studentId}`)
  };

  // ==========================================
  // PART 7A: FEE STRUCTURE & FEE TYPES API
  // ==========================================
  fees = {
    // Fee Types
    getFeeTypes: (params?: { status?: string; category?: string; search?: string }) => {
      const query = new URLSearchParams();
      if (params?.status) query.append('status', params.status);
      if (params?.category) query.append('category', params.category);
      if (params?.search) query.append('search', params.search);
      const qs = query.toString();
      return this.request<FeeType[]>(`/fees/types${qs ? `?${qs}` : ''}`);
    },

    getFeeTypeById: (id: string) =>
      this.request<FeeType & { linkedStructuresCount: number }>(`/fees/types/${id}`),

    createFeeType: (payload: CreateFeeTypePayload) =>
      this.request<FeeType>('/fees/types', {
        method: 'POST',
        body: JSON.stringify(payload)
      }),

    updateFeeType: (id: string, payload: UpdateFeeTypePayload) =>
      this.request<FeeType>(`/fees/types/${id}`, {
        method: 'PUT',
        body: JSON.stringify(payload)
      }),

    updateFeeTypeStatus: (id: string, status: FeeTypeStatus) =>
      this.request<FeeType>(`/fees/types/${id}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status })
      }),

    deleteFeeType: (id: string) =>
      this.request<{ message: string }>(`/fees/types/${id}`, {
        method: 'DELETE'
      }),

    // Fee Structures
    getFeeStructures: (params?: FeeStructureFilterParams) => {
      const query = new URLSearchParams();
      if (params?.academicSessionId) query.append('academicSessionId', params.academicSessionId);
      if (params?.classId) query.append('classId', params.classId);
      if (params?.sectionId) query.append('sectionId', params.sectionId);
      if (params?.feeTypeId) query.append('feeTypeId', params.feeTypeId);
      if (params?.status) query.append('status', params.status);
      if (params?.feeCategory) query.append('feeCategory', params.feeCategory);
      if (params?.frequency) query.append('frequency', params.frequency);
      if (params?.search) query.append('search', params.search);
      if (params?.page) query.append('page', params.page.toString());
      if (params?.limit) query.append('limit', params.limit.toString());
      const qs = query.toString();
      return this.request<FeeStructure[]>(`/fees/structures${qs ? `?${qs}` : ''}`);
    },

    getFeeStructureStats: () =>
      this.request<FeeStructureSummaryStats>('/fees/structures/stats'),

    getFeeStructureById: (id: string) =>
      this.request<
        FeeStructure & {
          feeTypeDetails?: FeeType | null;
          academicSessionDetails?: any;
          classDetails?: any;
          sectionDetails?: any;
        }
      >(`/fees/structures/${id}`),

    createFeeStructure: (payload: CreateFeeStructurePayload) =>
      this.request<FeeStructure>('/fees/structures', {
        method: 'POST',
        body: JSON.stringify(payload)
      }),

    updateFeeStructure: (id: string, payload: UpdateFeeStructurePayload) =>
      this.request<FeeStructure>(`/fees/structures/${id}`, {
        method: 'PUT',
        body: JSON.stringify(payload)
      }),

    updateFeeStructureStatus: (id: string, status: FeeStructureStatus) =>
      this.request<FeeStructure>(`/fees/structures/${id}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status })
      }),

    deleteFeeStructure: (id: string) =>
      this.request<{ message: string }>(`/fees/structures/${id}`, {
        method: 'DELETE'
      }),

    batchUpdateFeeStructureStatus: (ids: string[], status: FeeStructureStatus) =>
      this.request<{ updated: string[]; skipped: { id: string; reason: string }[] }>(
        '/fees/structures/batch-status',
        {
          method: 'POST',
          body: JSON.stringify({ ids, status })
        }
      ),

    // Part 7B: Student Fee Assignment & Invoices
    getStudentFees: (params?: StudentFeeFilterParams) => {
      const query = new URLSearchParams();
      if (params?.academicSessionId) query.append('academicSessionId', params.academicSessionId);
      if (params?.classId) query.append('classId', params.classId);
      if (params?.sectionId) query.append('sectionId', params.sectionId);
      if (params?.studentId) query.append('studentId', params.studentId);
      if (params?.feeTypeId) query.append('feeTypeId', params.feeTypeId);
      if (params?.feeStructureId) query.append('feeStructureId', params.feeStructureId);
      if (params?.status) query.append('status', params.status);
      if (params?.dueDateFrom) query.append('dueDateFrom', params.dueDateFrom);
      if (params?.dueDateTo) query.append('dueDateTo', params.dueDateTo);
      if (params?.search) query.append('search', params.search);
      if (params?.page) query.append('page', params.page.toString());
      if (params?.limit) query.append('limit', params.limit.toString());
      const qs = query.toString();
      return this.request<StudentFeeListResponse>(`/fees/student-fees${qs ? `?${qs}` : ''}`);
    },

    getStudentFeeStats: () =>
      this.request<StudentFeeSummaryStats>('/fees/student-fees/stats'),

    getApplicableStructures: (params: {
      academicSessionId: string;
      classId: string;
      sectionId?: string;
      studentId?: string;
    }) => {
      const query = new URLSearchParams();
      query.append('academicSessionId', params.academicSessionId);
      query.append('classId', params.classId);
      if (params.sectionId) query.append('sectionId', params.sectionId);
      if (params.studentId) query.append('studentId', params.studentId);
      return this.request<ApplicableFeeStructureItem[]>(
        `/fees/applicable-structures?${query.toString()}`
      );
    },

    assignStudentFees: (payload: AssignStudentFeePayload) =>
      this.request<AssignStudentFeeResponse>('/fees/assign', {
        method: 'POST',
        body: JSON.stringify(payload)
      }),

    getStudentFeeById: (id: string) =>
      this.request<InvoiceDetailResponse>(`/fees/student-fees/${id}`),

    applyDiscount: (id: string, payload: ApplyFeeDiscountPayload) =>
      this.request<StudentFeeRecord>(`/fees/student-fees/${id}/discount`, {
        method: 'POST',
        body: JSON.stringify(payload)
      }),

    applyFine: (id: string, payload: ApplyFeeFinePayload) =>
      this.request<StudentFeeRecord>(`/fees/student-fees/${id}/fine`, {
        method: 'POST',
        body: JSON.stringify(payload)
      }),

    updateStudentFeeStatus: (id: string, payload: UpdateStudentFeeStatusPayload) =>
      this.request<StudentFeeRecord>(`/fees/student-fees/${id}/status`, {
        method: 'PATCH',
        body: JSON.stringify(payload)
      }),

    deleteStudentFee: (id: string) =>
      this.request<{ message: string }>(`/fees/student-fees/${id}`, {
        method: 'DELETE'
      }),

    getInvoiceByNumber: (invoiceNumber: string) =>
      this.request<InvoiceDetailResponse>(`/fees/invoices/${invoiceNumber}`),

    // Part 7C: Fee Collection & Payment Management
    getPaymentMethods: () =>
      this.request<PaymentMethodConfig[]>('/fees/payment-methods'),

    togglePaymentMethod: (id: string) =>
      this.request<PaymentMethodConfig>(`/fees/payment-methods/${id}/toggle`, {
        method: 'POST'
      }),

    collectFeePayment: (payload: CollectFeePaymentPayload) =>
      this.request<CollectFeePaymentResponse['data']>('/fees/collect', {
        method: 'POST',
        body: JSON.stringify(payload)
      }),

    getPaymentTransactions: (params?: FeePaymentFilterParams) => {
      const query = new URLSearchParams();
      if (params?.search) query.append('search', params.search);
      if (params?.studentId) query.append('studentId', params.studentId);
      if (params?.feeRecordId) query.append('feeRecordId', params.feeRecordId);
      if (params?.classId) query.append('classId', params.classId);
      if (params?.paymentMethod) query.append('paymentMethod', params.paymentMethod);
      if (params?.status) query.append('status', params.status);
      if (params?.startDate) query.append('startDate', params.startDate);
      if (params?.endDate) query.append('endDate', params.endDate);
      if (params?.page) query.append('page', params.page.toString());
      if (params?.limit) query.append('limit', params.limit.toString());
      const qs = query.toString();
      return this.request<FeePaymentListResponse>(`/fees/payments${qs ? `?${qs}` : ''}`);
    },

    getFeeCollectionStats: () =>
      this.request<FeeCollectionSummaryStats>('/fees/payments/stats'),

    getPaymentReceipt: (transactionIdOrReceipt: string) =>
      this.request<FeePaymentReceipt>(`/fees/payments/${transactionIdOrReceipt}/receipt`),

    reversePayment: (transactionId: string, payload: ReverseFeePaymentPayload) =>
      this.request<ReverseFeePaymentResponse['data']>(`/fees/payments/${transactionId}/reverse`, {
        method: 'POST',
        body: JSON.stringify(payload)
      }),

    // ==========================================
    // PART 7D: DISCOUNTS, WAIVERS, SCHOLARSHIPS & FINES API
    // ==========================================

    // Discounts
    getDiscounts: (params?: {
      search?: string;
      status?: string;
      discountType?: string;
      scope?: string;
      academicSessionId?: string;
      approvalStatus?: string;
    }) => {
      const query = new URLSearchParams();
      if (params?.search) query.append('search', params.search);
      if (params?.status) query.append('status', params.status);
      if (params?.discountType) query.append('discountType', params.discountType);
      if (params?.scope) query.append('scope', params.scope);
      if (params?.academicSessionId) query.append('academicSessionId', params.academicSessionId);
      if (params?.approvalStatus) query.append('approvalStatus', params.approvalStatus);
      const qs = query.toString();
      return this.request<FeeDiscountRule[]>(`/fees/discounts${qs ? `?${qs}` : ''}`);
    },

    getDiscountStats: () =>
      this.request<{
        totalCount: number;
        activeCount: number;
        pendingCount: number;
        totalDiscountDisbursed: number;
        totalApplications: number;
      }>('/fees/discounts/stats'),

    getDiscountById: (id: string) =>
      this.request<FeeDiscountRule & { appliedFees?: any[] }>(`/fees/discounts/${id}`),

    createDiscount: (payload: CreateDiscountRulePayload) =>
      this.request<FeeDiscountRule>('/fees/discounts', {
        method: 'POST',
        body: JSON.stringify(payload)
      }),

    updateDiscount: (id: string, payload: UpdateDiscountRulePayload) =>
      this.request<FeeDiscountRule>(`/fees/discounts/${id}`, {
        method: 'PUT',
        body: JSON.stringify(payload)
      }),

    updateDiscountStatus: (id: string, status: string) =>
      this.request<FeeDiscountRule>(`/fees/discounts/${id}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status })
      }),

    approveDiscount: (id: string) =>
      this.request<FeeDiscountRule>(`/fees/discounts/${id}/approve`, {
        method: 'POST'
      }),

    applyDiscountBatch: (id: string, payload: ApplyDiscountBatchPayload) =>
      this.request<ApplyDiscountBatchResponse['data']>(`/fees/discounts/${id}/apply`, {
        method: 'POST',
        body: JSON.stringify(payload)
      }),

    deleteDiscount: (id: string) =>
      this.request<{ message: string }>(`/fees/discounts/${id}`, {
        method: 'DELETE'
      }),

    // Waivers
    getWaivers: (params?: {
      search?: string;
      status?: string;
      studentId?: string;
      academicSessionId?: string;
      waiverType?: string;
    }) => {
      const query = new URLSearchParams();
      if (params?.search) query.append('search', params.search);
      if (params?.status) query.append('status', params.status);
      if (params?.studentId) query.append('studentId', params.studentId);
      if (params?.academicSessionId) query.append('academicSessionId', params.academicSessionId);
      if (params?.waiverType) query.append('waiverType', params.waiverType);
      const qs = query.toString();
      return this.request<FeeWaiver[]>(`/fees/waivers${qs ? `?${qs}` : ''}`);
    },

    getWaiverStats: () =>
      this.request<{
        totalCount: number;
        approvedCount: number;
        pendingCount: number;
        rejectedCount: number;
        totalWaivedAmount: number;
      }>('/fees/waivers/stats'),

    getWaiverById: (id: string) =>
      this.request<FeeWaiver & { feeRecord?: any }>(`/fees/waivers/${id}`),

    createWaiver: (payload: CreateWaiverPayload) =>
      this.request<FeeWaiver>('/fees/waivers', {
        method: 'POST',
        body: JSON.stringify(payload)
      }),

    approveWaiver: (id: string, payload: ApproveWaiverPayload) =>
      this.request<FeeWaiver>(`/fees/waivers/${id}/approve`, {
        method: 'POST',
        body: JSON.stringify(payload)
      }),

    rejectWaiver: (id: string, payload: RejectWaiverPayload) =>
      this.request<FeeWaiver>(`/fees/waivers/${id}/reject`, {
        method: 'POST',
        body: JSON.stringify(payload)
      }),

    cancelWaiver: (id: string) =>
      this.request<FeeWaiver>(`/fees/waivers/${id}/cancel`, {
        method: 'POST'
      }),

    // Scholarships
    getScholarships: (params?: {
      search?: string;
      status?: string;
      studentId?: string;
      academicSessionId?: string;
      scholarshipType?: string;
    }) => {
      const query = new URLSearchParams();
      if (params?.search) query.append('search', params.search);
      if (params?.status) query.append('status', params.status);
      if (params?.studentId) query.append('studentId', params.studentId);
      if (params?.academicSessionId) query.append('academicSessionId', params.academicSessionId);
      if (params?.scholarshipType) query.append('scholarshipType', params.scholarshipType);
      const qs = query.toString();
      return this.request<FeeScholarship[]>(`/fees/scholarships${qs ? `?${qs}` : ''}`);
    },

    getScholarshipStats: () =>
      this.request<{
        totalCount: number;
        activeCount: number;
        totalDisbursed: number;
        uniqueRecipients: number;
      }>('/fees/scholarships/stats'),

    getScholarshipById: (id: string) =>
      this.request<FeeScholarship & { linkedFees?: any[] }>(`/fees/scholarships/${id}`),

    createScholarship: (payload: CreateScholarshipPayload) =>
      this.request<FeeScholarship>('/fees/scholarships', {
        method: 'POST',
        body: JSON.stringify(payload)
      }),

    updateScholarship: (id: string, payload: UpdateScholarshipPayload) =>
      this.request<FeeScholarship>(`/fees/scholarships/${id}`, {
        method: 'PUT',
        body: JSON.stringify(payload)
      }),

    approveScholarship: (id: string) =>
      this.request<FeeScholarship>(`/fees/scholarships/${id}/approve`, {
        method: 'POST'
      }),

    deleteScholarship: (id: string) =>
      this.request<{ message: string }>(`/fees/scholarships/${id}`, {
        method: 'DELETE'
      }),

    // Fine Policies & Late Assessment
    getFineRules: () =>
      this.request<FeeFineRule[]>('/fees/fines/rules'),

    getFineRuleById: (id: string) =>
      this.request<FeeFineRule>(`/fees/fines/rules/${id}`),

    createFineRule: (payload: CreateFineRulePayload) =>
      this.request<FeeFineRule>('/fees/fines/rules', {
        method: 'POST',
        body: JSON.stringify(payload)
      }),

    updateFineRule: (id: string, payload: UpdateFineRulePayload) =>
      this.request<FeeFineRule>(`/fees/fines/rules/${id}`, {
        method: 'PUT',
        body: JSON.stringify(payload)
      }),

    updateFineRuleStatus: (id: string, status: string) =>
      this.request<FeeFineRule>(`/fees/fines/rules/${id}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status })
      }),

    deleteFineRule: (id: string) =>
      this.request<{ message: string }>(`/fees/fines/rules/${id}`, {
        method: 'DELETE'
      }),

    getAppliedFines: (params?: { search?: string; status?: string; studentId?: string; feeRecordId?: string }) => {
      const query = new URLSearchParams();
      if (params?.search) query.append('search', params.search);
      if (params?.status) query.append('status', params.status);
      if (params?.studentId) query.append('studentId', params.studentId);
      if (params?.feeRecordId) query.append('feeRecordId', params.feeRecordId);
      const qs = query.toString();
      return this.request<AppliedFineRecord[]>(`/fees/fines/applied${qs ? `?${qs}` : ''}`);
    },

    assessLateFines: (payload: AssessLateFinesPayload) =>
      this.request<AssessLateFinesResponse['data']>('/fees/fines/assess-overdue', {
        method: 'POST',
        body: JSON.stringify(payload)
      }),

    applyManualFine: (payload: ApplyManualFinePayload) =>
      this.request<{ fineRecord: AppliedFineRecord; feeRecord: any }>('/fees/fines/apply-manual', {
        method: 'POST',
        body: JSON.stringify(payload)
      }),

    waiveFine: (id: string, payload: WaiveFinePayload) =>
      this.request<AppliedFineRecord>(`/fees/fines/${id}/waive`, {
        method: 'POST',
        body: JSON.stringify(payload)
      }),

    // Consolidated Adjustments Stats & Audit History
    getAdjustmentStats: () =>
      this.request<FeeAdjustmentSummaryStats>('/fees/adjustments/stats'),

    getAdjustmentHistory: (params?: { search?: string; adjustmentType?: string; action?: string; studentId?: string }) => {
      const query = new URLSearchParams();
      if (params?.search) query.append('search', params.search);
      if (params?.adjustmentType) query.append('adjustmentType', params.adjustmentType);
      if (params?.action) query.append('action', params.action);
      if (params?.studentId) query.append('studentId', params.studentId);
      const qs = query.toString();
      return this.request<FeeAdjustmentAudit[]>(`/fees/adjustments/history${qs ? `?${qs}` : ''}`);
    },

    recalculateStudentFee: (feeRecordId: string) =>
      this.request<any>(`/fees/student-fees/${feeRecordId}/recalculate`, {
        method: 'POST'
      }),

    // Part 7E: Fee Due, Overdue & Fee Tracking
    getDueDashboardStats: (params?: { academicSessionId?: string; classId?: string }) => {
      const query = new URLSearchParams();
      if (params?.academicSessionId) query.append('academicSessionId', params.academicSessionId);
      if (params?.classId) query.append('classId', params.classId);
      const qs = query.toString();
      return this.request<FeeDueDashboardStats>(`/fees/due-management/stats${qs ? `?${qs}` : ''}`);
    },

    getDueStudents: (params?: FeeDueFilterParams) => {
      const query = new URLSearchParams();
      if (params?.academicSessionId) query.append('academicSessionId', params.academicSessionId);
      if (params?.classId) query.append('classId', params.classId);
      if (params?.sectionId) query.append('sectionId', params.sectionId);
      if (params?.feeTypeId) query.append('feeTypeId', params.feeTypeId);
      if (params?.status) query.append('status', params.status);
      if (params?.agingBracket) query.append('agingBracket', params.agingBracket);
      if (params?.minDueAmount !== undefined) query.append('minDueAmount', String(params.minDueAmount));
      if (params?.maxDueAmount !== undefined) query.append('maxDueAmount', String(params.maxDueAmount));
      if (params?.dueDateFrom) query.append('dueDateFrom', params.dueDateFrom);
      if (params?.dueDateTo) query.append('dueDateTo', params.dueDateTo);
      if (params?.search) query.append('search', params.search);
      if (params?.sortBy) query.append('sortBy', params.sortBy);
      if (params?.sortOrder) query.append('sortOrder', params.sortOrder);
      if (params?.page) query.append('page', String(params.page));
      if (params?.limit) query.append('limit', String(params.limit));
      const qs = query.toString();
      return this.request<FeeDueStudentListResponse>(`/fees/due-management/students${qs ? `?${qs}` : ''}`);
    },

    sendDueReminders: (payload: SendFeeReminderPayload) =>
      this.request<SendFeeReminderResponse>('/fees/due-management/reminders', {
        method: 'POST',
        body: JSON.stringify(payload)
      }),

    getReminderLogs: (params?: { search?: string; feeRecordId?: string; studentId?: string; channel?: string; page?: number; limit?: number }) => {
      const query = new URLSearchParams();
      if (params?.search) query.append('search', params.search);
      if (params?.feeRecordId) query.append('feeRecordId', params.feeRecordId);
      if (params?.studentId) query.append('studentId', params.studentId);
      if (params?.channel) query.append('channel', params.channel);
      if (params?.page) query.append('page', String(params.page));
      if (params?.limit) query.append('limit', String(params.limit));
      const qs = query.toString();
      return this.request<{ data: FeeReminderLog[]; total: number }>(`/fees/due-management/reminders/history${qs ? `?${qs}` : ''}`);
    },

    // Part 7F: Financial Reports, Receipts & Statements
    getFinancialReportDashboardStats: (params?: { academicSessionId?: string; classId?: string }) => {
      const query = new URLSearchParams();
      if (params?.academicSessionId) query.append('academicSessionId', params.academicSessionId);
      if (params?.classId) query.append('classId', params.classId);
      const qs = query.toString();
      return this.request<FinancialReportDashboardStats>(`/fees/reports/dashboard${qs ? `?${qs}` : ''}`);
    },

    getFinancialReportDashboard: (params?: { academicSessionId?: string; classId?: string }) => {
      const query = new URLSearchParams();
      if (params?.academicSessionId) query.append('academicSessionId', params.academicSessionId);
      if (params?.classId) query.append('classId', params.classId);
      const qs = query.toString();
      return this.request<FinancialReportDashboardStats>(`/fees/reports/dashboard${qs ? `?${qs}` : ''}`);
    },

    getCollectionReport: (params?: CollectionReportFilterParams) => {
      const query = new URLSearchParams();
      if (params?.startDate) query.append('startDate', params.startDate);
      if (params?.endDate) query.append('endDate', params.endDate);
      if (params?.academicSessionId) query.append('academicSessionId', params.academicSessionId);
      if (params?.classId) query.append('classId', params.classId);
      if (params?.sectionId) query.append('sectionId', params.sectionId);
      if (params?.feeTypeId) query.append('feeTypeId', params.feeTypeId);
      if (params?.paymentMethod) query.append('paymentMethod', params.paymentMethod);
      if (params?.collectedBy) query.append('collectedBy', params.collectedBy);
      if (params?.status) query.append('status', params.status);
      if (params?.search) query.append('search', params.search);
      if (params?.page) query.append('page', String(params.page));
      if (params?.limit) query.append('limit', String(params.limit));
      const qs = query.toString();
      return this.request<CollectionReportResponse>(`/fees/reports/collections${qs ? `?${qs}` : ''}`);
    },

    getFeeSummaryReport: (params?: { academicSessionId?: string; classId?: string; sectionId?: string }) => {
      const query = new URLSearchParams();
      if (params?.academicSessionId) query.append('academicSessionId', params.academicSessionId);
      if (params?.classId) query.append('classId', params.classId);
      if (params?.sectionId) query.append('sectionId', params.sectionId);
      const qs = query.toString();
      return this.request<FeeSummaryReportResponse>(`/fees/reports/fee-summary${qs ? `?${qs}` : ''}`);
    },

    getPaymentMethodsReport: (params?: { academicSessionId?: string; startDate?: string; endDate?: string }) => {
      const query = new URLSearchParams();
      if (params?.academicSessionId) query.append('academicSessionId', params.academicSessionId);
      if (params?.startDate) query.append('startDate', params.startDate);
      if (params?.endDate) query.append('endDate', params.endDate);
      const qs = query.toString();
      return this.request<PaymentMethodReportResponse>(`/fees/reports/payment-methods${qs ? `?${qs}` : ''}`);
    },

    getStudentAccountStatement: (studentId: string, params?: { academicSessionId?: string; startDate?: string; endDate?: string }) => {
      const query = new URLSearchParams();
      if (params?.academicSessionId) query.append('academicSessionId', params.academicSessionId);
      if (params?.startDate) query.append('startDate', params.startDate);
      if (params?.endDate) query.append('endDate', params.endDate);
      const qs = query.toString();
      return this.request<StudentAccountStatement>(`/fees/reports/statements/students/${studentId}${qs ? `?${qs}` : ''}`);
    },

    getReceiptsArchive: (params?: {
      search?: string;
      studentId?: string;
      classId?: string;
      paymentMethod?: string;
      status?: string;
      startDate?: string;
      endDate?: string;
      page?: number;
      limit?: number;
    }) => {
      const query = new URLSearchParams();
      if (params?.search) query.append('search', params.search);
      if (params?.studentId) query.append('studentId', params.studentId);
      if (params?.classId) query.append('classId', params.classId);
      if (params?.paymentMethod) query.append('paymentMethod', params.paymentMethod);
      if (params?.status) query.append('status', params.status);
      if (params?.startDate) query.append('startDate', params.startDate);
      if (params?.endDate) query.append('endDate', params.endDate);
      if (params?.page) query.append('page', String(params.page));
      if (params?.limit) query.append('limit', String(params.limit));
      const qs = query.toString();
      return this.request<{ data: FeePaymentReceipt[]; total: number; page: number; limit: number; totalPages: number }>(
        `/fees/reports/receipts${qs ? `?${qs}` : ''}`
      );
    },

    getPaymentReceiptsArchive: (params?: {
      search?: string;
      studentId?: string;
      classId?: string;
      paymentMethod?: string;
      status?: string;
      startDate?: string;
      endDate?: string;
      page?: number;
      limit?: number;
    }) => {
      const query = new URLSearchParams();
      if (params?.search) query.append('search', params.search);
      if (params?.studentId) query.append('studentId', params.studentId);
      if (params?.classId) query.append('classId', params.classId);
      if (params?.paymentMethod) query.append('paymentMethod', params.paymentMethod);
      if (params?.status) query.append('status', params.status);
      if (params?.startDate) query.append('startDate', params.startDate);
      if (params?.endDate) query.append('endDate', params.endDate);
      if (params?.page) query.append('page', String(params.page));
      if (params?.limit) query.append('limit', String(params.limit));
      const qs = query.toString();
      return this.request<{ data: FeePaymentReceipt[]; total: number; page: number; limit: number; totalPages: number }>(
        `/fees/reports/receipts${qs ? `?${qs}` : ''}`
      );
    },

    getReceiptDetail: (receiptNumberOrTxnId: string) =>
      this.request<FeePaymentReceipt>(`/fees/reports/receipts/${receiptNumberOrTxnId}`)
  };

  // =========================================================================
  // PART 9B: STUDENT ADMISSION & ENROLLMENT MANAGEMENT
  // =========================================================================
  admissions = {
    getStats: () =>
      this.request<{
        applications: {
          total: number;
          pendingReview: number;
          approved: number;
          enrolled: number;
          rejected: number;
          drafts: number;
        };
        enquiries: {
          total: number;
          converted: number;
          conversionRate: number;
        };
        enrollments: {
          total: number;
          active: number;
        };
      }>('/admissions/stats'),

    getConfig: () => this.request<AdmissionNumberConfig>('/admissions/config'),
    updateConfig: (data: Partial<AdmissionNumberConfig>) =>
      this.request<AdmissionNumberConfig>('/admissions/config', {
        method: 'PUT',
        body: JSON.stringify(data)
      }),
    getNextNumber: () =>
      this.request<{ nextAdmissionNumber: string; nextSequence: number }>('/admissions/next-number'),

    // Enquiries
    getEnquiries: (params?: {
      status?: string;
      classId?: string;
      sessionId?: string;
      source?: string;
      search?: string;
      page?: number;
      limit?: number;
    }) => {
      const q = new URLSearchParams();
      if (params?.status) q.append('status', params.status);
      if (params?.classId) q.append('classId', params.classId);
      if (params?.sessionId) q.append('sessionId', params.sessionId);
      if (params?.source) q.append('source', params.source);
      if (params?.search) q.append('search', params.search);
      if (params?.page) q.append('page', String(params.page));
      if (params?.limit) q.append('limit', String(params.limit));
      const qs = q.toString();
      return this.request<{
        data: AdmissionEnquiry[];
        pagination: { total: number; page: number; limit: number; totalPages: number };
      }>(`/admissions/enquiries${qs ? `?${qs}` : ''}`);
    },
    getEnquiryById: (id: string) => this.request<AdmissionEnquiry>(`/admissions/enquiries/${id}`),
    createEnquiry: (data: Partial<AdmissionEnquiry>) =>
      this.request<AdmissionEnquiry>('/admissions/enquiries', {
        method: 'POST',
        body: JSON.stringify(data)
      }),
    updateEnquiry: (id: string, data: Partial<AdmissionEnquiry>) =>
      this.request<AdmissionEnquiry>(`/admissions/enquiries/${id}`, {
        method: 'PUT',
        body: JSON.stringify(data)
      }),
    deleteEnquiry: (id: string) =>
      this.request<{ success: boolean; message: string }>(`/admissions/enquiries/${id}`, {
        method: 'DELETE'
      }),
    convertEnquiry: (id: string) =>
      this.request<AdmissionApplication>(`/admissions/enquiries/${id}/convert`, {
        method: 'POST'
      }),

    // Applications
    getApplications: (params?: {
      status?: string;
      classId?: string;
      sessionId?: string;
      search?: string;
      page?: number;
      limit?: number;
    }) => {
      const q = new URLSearchParams();
      if (params?.status) q.append('status', params.status);
      if (params?.classId) q.append('classId', params.classId);
      if (params?.sessionId) q.append('sessionId', params.sessionId);
      if (params?.search) q.append('search', params.search);
      if (params?.page) q.append('page', String(params.page));
      if (params?.limit) q.append('limit', String(params.limit));
      const qs = q.toString();
      return this.request<{
        data: AdmissionApplication[];
        pagination: { total: number; page: number; limit: number; totalPages: number };
      }>(`/admissions/applications${qs ? `?${qs}` : ''}`);
    },
    getApplicationById: (id: string) =>
      this.request<AdmissionApplication>(`/admissions/applications/${id}`),
    createApplication: (data: any) =>
      this.request<AdmissionApplication>('/admissions/applications', {
        method: 'POST',
        body: JSON.stringify(data)
      }),
    updateApplication: (id: string, data: any) =>
      this.request<AdmissionApplication>(`/admissions/applications/${id}`, {
        method: 'PUT',
        body: JSON.stringify(data)
      }),
    checkDuplicates: (data: any) =>
      this.request<DuplicateStudentCheckResult>('/admissions/applications/check-duplicates', {
        method: 'POST',
        body: JSON.stringify(data)
      }),
    updateApplicationStatus: (
      id: string,
      data: { targetStatus: string; reason?: string; reviewRemarks?: string }
    ) =>
      this.request<AdmissionApplication>(`/admissions/applications/${id}/status`, {
        method: 'POST',
        body: JSON.stringify(data)
      }),
    approveAndEnroll: (id: string) =>
      this.request<{
        application: AdmissionApplication;
        studentProfile: StudentProfile;
        enrollment: AcademicEnrollment;
        admissionNumber: string;
        rollNumber: string;
      }>(`/admissions/applications/${id}/approve-and-enroll`, {
        method: 'POST'
      }),

    // Enrollments
    getEnrollments: (params?: {
      classId?: string;
      sectionId?: string;
      sessionId?: string;
      status?: string;
      search?: string;
      page?: number;
      limit?: number;
    }) => {
      const q = new URLSearchParams();
      if (params?.classId) q.append('classId', params.classId);
      if (params?.sectionId) q.append('sectionId', params.sectionId);
      if (params?.sessionId) q.append('sessionId', params.sessionId);
      if (params?.status) q.append('status', params.status);
      if (params?.search) q.append('search', params.search);
      if (params?.page) q.append('page', String(params.page));
      if (params?.limit) q.append('limit', String(params.limit));
      const qs = q.toString();
      return this.request<{
        data: AcademicEnrollment[];
        pagination: { total: number; page: number; limit: number; totalPages: number };
      }>(`/admissions/enrollments${qs ? `?${qs}` : ''}`);
    },
    updateEnrollmentRollNumber: (id: string, newRollNumber: string) =>
      this.request<AcademicEnrollment>(`/admissions/enrollments/${id}/roll-number`, {
        method: 'PUT',
        body: JSON.stringify({ newRollNumber })
      }),
    updateEnrollmentStatus: (id: string, status: string, remarks?: string) =>
      this.request<AcademicEnrollment>(`/admissions/enrollments/${id}/status`, {
        method: 'PUT',
        body: JSON.stringify({ status, remarks })
      })
  };

  // ==========================================================================
  // PART 9E: Student Promotion, Transfer & Status Management API
  // ==========================================================================
  promotionsTransfers = {
    getStats: () =>
      this.request<{ success: boolean; stats: any }>(`/promotions-transfers/stats`),

    getEnrollments: (params?: {
      studentId?: string;
      academicSessionId?: string;
      classId?: string;
      sectionId?: string;
      status?: string;
      search?: string;
    }) => {
      const q = new URLSearchParams();
      if (params?.studentId) q.append('studentId', params.studentId);
      if (params?.academicSessionId) q.append('academicSessionId', params.academicSessionId);
      if (params?.classId) q.append('classId', params.classId);
      if (params?.sectionId) q.append('sectionId', params.sectionId);
      if (params?.status) q.append('status', params.status);
      if (params?.search) q.append('search', params.search);
      const qs = q.toString();
      return this.request<{ success: boolean; total: number; enrollments: any[] }>(
        `/promotions-transfers/enrollments${qs ? `?${qs}` : ''}`
      );
    },

    getStudentTimeline: (studentId: string) =>
      this.request<{
        success: boolean;
        student: any;
        enrollments: any[];
        promotions: any[];
        transfers: any[];
        transferCertificates: any[];
        statusHistory: any[];
        standing: any;
      }>(`/promotions-transfers/student/${studentId}/timeline`),

    getStudentStanding: (studentId: string, sessionId?: string) => {
      const qs = sessionId ? `?sessionId=${sessionId}` : '';
      return this.request<{ success: boolean; studentId: string; studentName: string; standing: any }>(
        `/promotions-transfers/student/${studentId}/standing${qs}`
      );
    },

    previewBulkPromotion: (payload: {
      sourceSessionId: string;
      sourceClassId: string;
      sourceSectionId?: string;
      targetSessionId: string;
      targetClassId: string;
      targetSectionId?: string;
      minGpa?: number;
      minAttendanceRate?: number;
      requireFeeClearance?: boolean;
    }) =>
      this.request<{
        success: boolean;
        sourceSessionName: string;
        targetSessionName: string;
        sourceClassName: string;
        targetClassName: string;
        summary: any;
        students: any[];
      }>(`/promotions-transfers/preview-bulk`, {
        method: 'POST',
        body: JSON.stringify(payload)
      }),

    executeBulkPromotion: (payload: any) =>
      this.request<{
        success: boolean;
        batchId: string;
        summary: any;
        records: any[];
      }>(`/promotions-transfers/execute-bulk`, {
        method: 'POST',
        body: JSON.stringify(payload)
      }),

    promoteIndividual: (payload: {
      studentId: string;
      targetSessionId: string;
      targetClassId: string;
      targetSectionId: string;
      targetRollNumber: string;
      promotionType?: string;
      feeOverrideApproved?: boolean;
      feeOverrideReason?: string;
      remarks?: string;
    }) =>
      this.request<{
        success: boolean;
        message: string;
        record: any;
        enrollment: any;
      }>(`/promotions-transfers/promote-individual`, {
        method: 'POST',
        body: JSON.stringify(payload)
      }),

    transferInternal: (payload: {
      studentId: string;
      transferType?: string;
      targetClassId?: string;
      targetSectionId: string;
      targetRollNumber?: string;
      reason: string;
      effectiveDate?: string;
      libraryCleared?: boolean;
      feesCleared?: boolean;
    }) =>
      this.request<{
        success: boolean;
        message: string;
        record: any;
        enrollment: any;
      }>(`/promotions-transfers/transfer-internal`, {
        method: 'POST',
        body: JSON.stringify(payload)
      }),

    getTransferCertificates: (params?: { search?: string; status?: string }) => {
      const q = new URLSearchParams();
      if (params?.search) q.append('search', params.search);
      if (params?.status) q.append('status', params.status);
      const qs = q.toString();
      return this.request<{ success: boolean; total: number; certificates: any[] }>(
        `/promotions-transfers/transfer-certificates${qs ? `?${qs}` : ''}`
      );
    },

    getTransferCertificateById: (id: string) =>
      this.request<{ success: boolean; certificate: any }>(
        `/promotions-transfers/transfer-certificates/${id}`
      ),

    issueTransferCertificate: (payload: {
      studentId: string;
      dateOfLeaving?: string;
      reasonForLeaving: string;
      generalConduct?: string;
      targetSchoolName?: string;
      libraryCleared?: boolean;
      feesCleared?: boolean;
      labSportsCleared?: boolean;
      clearanceOverride?: boolean;
      remarks?: string;
    }) =>
      this.request<{
        success: boolean;
        message: string;
        certificate: any;
        transferRecord: any;
      }>(`/promotions-transfers/transfer-certificate/issue`, {
        method: 'POST',
        body: JSON.stringify(payload)
      }),

    changeStudentStatus: (payload: {
      studentId: string;
      newStatus: string;
      effectiveDate: string;
      endDate?: string;
      reason: string;
      suspensionTerms?: string;
      remarks?: string;
      documentUrl?: string;
    }) =>
      this.request<{
        success: boolean;
        message: string;
        historyEntry: any;
        student: any;
      }>(`/promotions-transfers/status-change`, {
        method: 'POST',
        body: JSON.stringify(payload)
      }),

    getStudentStatusHistory: (studentId: string) =>
      this.request<{ success: boolean; history: any[] }>(
        `/promotions-transfers/status-history/${studentId}`
      ),

    getPromotionBatches: () =>
      this.request<{ success: boolean; total: number; batches: any[] }>(
        `/promotions-transfers/batches`
      ),

    getPromotionRecords: (params?: { studentId?: string; batchId?: string; sessionId?: string }) => {
      const q = new URLSearchParams();
      if (params?.studentId) q.append('studentId', params.studentId);
      if (params?.batchId) q.append('batchId', params.batchId);
      if (params?.sessionId) q.append('sessionId', params.sessionId);
      const qs = q.toString();
      return this.request<{ success: boolean; total: number; promotions: any[] }>(
        `/promotions-transfers/promotions${qs ? `?${qs}` : ''}`
      );
    },

    getTransferRecords: (params?: { studentId?: string; type?: string }) => {
      const q = new URLSearchParams();
      if (params?.studentId) q.append('studentId', params.studentId);
      if (params?.type) q.append('type', params.type);
      const qs = q.toString();
      return this.request<{ success: boolean; total: number; transfers: any[] }>(
        `/promotions-transfers/transfers${qs ? `?${qs}` : ''}`
      );
    },

    revertPromotion: (recordId: string, reason?: string) =>
      this.request<{ success: boolean; message: string; record: any }>(
        `/promotions-transfers/revert-promotion/${recordId}`,
        {
          method: 'POST',
          body: JSON.stringify({ reason })
        }
      )
  };

  // ==========================================
  // PART 9F: STUDENT REPORTS, SEARCH, BULK OPERATIONS & DATA EXPORT
  // ==========================================
  public studentReports = {
    search: (params?: StudentReportFilterParams) => {
      const q = new URLSearchParams();
      if (params?.search) q.append('search', params.search);
      if (params?.q) q.append('q', params.q);
      if (params?.academicSessionId) q.append('academicSessionId', params.academicSessionId);
      if (params?.classId) q.append('classId', params.classId);
      if (params?.sectionId) q.append('sectionId', params.sectionId);
      if (params?.status) q.append('status', params.status);
      if (params?.enrollmentStatus) q.append('enrollmentStatus', params.enrollmentStatus);
      if (params?.gender) q.append('gender', params.gender);
      if (params?.bloodGroup) q.append('bloodGroup', params.bloodGroup);
      if (params?.admissionDateFrom) q.append('admissionDateFrom', params.admissionDateFrom);
      if (params?.admissionDateTo) q.append('admissionDateTo', params.admissionDateTo);
      if (params?.enrollmentDateFrom) q.append('enrollmentDateFrom', params.enrollmentDateFrom);
      if (params?.enrollmentDateTo) q.append('enrollmentDateTo', params.enrollmentDateTo);
      if (params?.documentStatus) q.append('documentStatus', params.documentStatus);
      if (params?.idCardStatus) q.append('idCardStatus', params.idCardStatus);
      if (params?.page) q.append('page', params.page.toString());
      if (params?.limit) q.append('limit', params.limit.toString());
      if (params?.sortBy) q.append('sortBy', params.sortBy);
      if (params?.sortOrder) q.append('sortOrder', params.sortOrder);
      const qs = q.toString();
      return this.request<{
        success: boolean;
        data: StudentReportItem[];
        pagination: { total: number; page: number; limit: number; totalPages: number };
        activeFilters: any;
      }>(`/student-reports/search${qs ? `?${qs}` : ''}`);
    },

    getSummary: (params?: { academicSessionId?: string; classId?: string; sectionId?: string }) => {
      const q = new URLSearchParams();
      if (params?.academicSessionId) q.append('academicSessionId', params.academicSessionId);
      if (params?.classId) q.append('classId', params.classId);
      if (params?.sectionId) q.append('sectionId', params.sectionId);
      const qs = q.toString();
      return this.request<{ success: boolean; data: StudentReportsSummaryData }>(
        `/student-reports/summary${qs ? `?${qs}` : ''}`
      );
    },

    getClassWiseReport: (params?: { academicSessionId?: string; classId?: string; sectionId?: string; status?: string }) => {
      const q = new URLSearchParams();
      if (params?.academicSessionId) q.append('academicSessionId', params.academicSessionId);
      if (params?.classId) q.append('classId', params.classId);
      if (params?.sectionId) q.append('sectionId', params.sectionId);
      if (params?.status) q.append('status', params.status);
      const qs = q.toString();
      return this.request<{ success: boolean; data: ClassWiseReportItem[]; totalStudentsCount: number }>(
        `/student-reports/class-wise${qs ? `?${qs}` : ''}`
      );
    },

    getStatusReport: (params?: { academicSessionId?: string; classId?: string; status?: string }) => {
      const q = new URLSearchParams();
      if (params?.academicSessionId) q.append('academicSessionId', params.academicSessionId);
      if (params?.classId) q.append('classId', params.classId);
      if (params?.status) q.append('status', params.status);
      const qs = q.toString();
      return this.request<{ success: boolean; data: StatusReportData }>(
        `/student-reports/status-report${qs ? `?${qs}` : ''}`
      );
    },

    getAdmissionsReport: (params?: {
      academicSessionId?: string;
      classId?: string;
      sectionId?: string;
      dateFrom?: string;
      dateTo?: string;
      enrollmentStatus?: string;
    }) => {
      const q = new URLSearchParams();
      if (params?.academicSessionId) q.append('academicSessionId', params.academicSessionId);
      if (params?.classId) q.append('classId', params.classId);
      if (params?.sectionId) q.append('sectionId', params.sectionId);
      if (params?.dateFrom) q.append('dateFrom', params.dateFrom);
      if (params?.dateTo) q.append('dateTo', params.dateTo);
      if (params?.enrollmentStatus) q.append('enrollmentStatus', params.enrollmentStatus);
      const qs = q.toString();
      return this.request<{ success: boolean; data: StudentReportItem[]; totalCount: number }>(
        `/student-reports/admissions${qs ? `?${qs}` : ''}`
      );
    },

    getAcademicAssignmentsReport: (params?: { academicSessionId?: string; classId?: string; sectionId?: string }) => {
      const q = new URLSearchParams();
      if (params?.academicSessionId) q.append('academicSessionId', params.academicSessionId);
      if (params?.classId) q.append('classId', params.classId);
      if (params?.sectionId) q.append('sectionId', params.sectionId);
      const qs = q.toString();
      return this.request<{ success: boolean; data: AcademicAssignmentReportItem[]; totalCount: number }>(
        `/student-reports/academic-assignments${qs ? `?${qs}` : ''}`
      );
    },

    getPromotionsReport: (params?: { sourceSessionId?: string; targetSessionId?: string; status?: string }) => {
      const q = new URLSearchParams();
      if (params?.sourceSessionId) q.append('sourceSessionId', params.sourceSessionId);
      if (params?.targetSessionId) q.append('targetSessionId', params.targetSessionId);
      if (params?.status) q.append('status', params.status);
      const qs = q.toString();
      return this.request<{ success: boolean; data: any[]; totalCount: number }>(
        `/student-reports/promotions${qs ? `?${qs}` : ''}`
      );
    },

    getTransfersReport: (params?: { transferType?: string; status?: string }) => {
      const q = new URLSearchParams();
      if (params?.transferType) q.append('transferType', params.transferType);
      if (params?.status) q.append('status', params.status);
      const qs = q.toString();
      return this.request<{ success: boolean; data: any[]; totalCount: number }>(
        `/student-reports/transfers${qs ? `?${qs}` : ''}`
      );
    },

    executeBulkAction: (payload: BulkStudentActionPayload) =>
      this.request<BulkStudentActionResult>('/student-reports/bulk-action', {
        method: 'POST',
        body: JSON.stringify(payload)
      }),

    auditExport: (payload: { reportType: string; format: string; filterContext?: any; recordCount: number }) =>
      this.request<{ success: boolean; message: string }>('/student-reports/export-audit', {
        method: 'POST',
        body: JSON.stringify(payload)
      })
  };

  // Part 11A: Centralized Communication & Notification Services
  communication = {
    getSettings: () => this.request<CommunicationSettings>('/communication/settings'),
    updateSettings: (updates: Partial<CommunicationSettings>) =>
      this.request<CommunicationSettings>('/communication/settings', {
        method: 'PUT',
        body: JSON.stringify(updates)
      }),
    testProvider: (channel: NotificationChannel, recipientContact?: string) =>
      this.request<{ success: boolean; status: CommunicationDeliveryStatus; message: string; details?: any }>(
        '/communication/providers/test',
        {
          method: 'POST',
          body: JSON.stringify({ channel, recipientContact })
        }
      ),
    getTemplates: (params?: { category?: string; eventType?: string; isActive?: boolean; search?: string }) => {
      const q = new URLSearchParams();
      if (params?.category) q.append('category', params.category);
      if (params?.eventType) q.append('eventType', params.eventType);
      if (params?.isActive !== undefined) q.append('isActive', String(params.isActive));
      if (params?.search) q.append('search', params.search);
      const qs = q.toString();
      return this.request<CommunicationTemplate[]>(
        `/communication/templates${qs ? `?${qs}` : ''}`
      );
    },
    getTemplateById: (id: string) =>
      this.request<CommunicationTemplate>(`/communication/templates/${id}`),
    createTemplate: (payload: Partial<CommunicationTemplate>) =>
      this.request<CommunicationTemplate>('/communication/templates', {
        method: 'POST',
        body: JSON.stringify(payload)
      }),
    updateTemplate: (id: string, updates: Partial<CommunicationTemplate>) =>
      this.request<CommunicationTemplate>(
        `/communication/templates/${id}`,
        {
          method: 'PUT',
          body: JSON.stringify(updates)
        }
      ),
    toggleTemplate: (id: string) =>
      this.request<{ success: boolean; message: string; isActive: boolean }>(
        `/communication/templates/${id}/toggle`,
        {
          method: 'POST'
        }
      ),
    previewTemplate: (payload: {
      templateId?: string;
      titleTemplate?: string;
      bodyTemplate?: string;
      emailSubjectTemplate?: string;
      emailHtmlTemplate?: string;
      smsTemplate?: string;
      variables?: Record<string, any>;
    }) =>
      this.request<{
        title: string;
        body: string;
        emailSubject: string;
        emailHtml: string;
        sms: string;
        variablesUsed: Record<string, any>;
      }>('/communication/templates/preview', {
        method: 'POST',
        body: JSON.stringify(payload)
      }),
    resetTemplates: () =>
      this.request<CommunicationTemplate[]>('/communication/templates/reset', {
        method: 'POST'
      }),
    getLogs: (params?: CommunicationFilterParams) => {
      const q = new URLSearchParams();
      if (params?.eventType) q.append('eventType', params.eventType);
      if (params?.channel) q.append('channel', params.channel);
      if (params?.status) q.append('status', params.status);
      if (params?.recipientRole) q.append('recipientRole', params.recipientRole);
      if (params?.search) q.append('search', params.search);
      if (params?.startDate) q.append('startDate', params.startDate);
      if (params?.endDate) q.append('endDate', params.endDate);
      if (params?.page) q.append('page', String(params.page));
      if (params?.limit) q.append('limit', String(params.limit));
      const qs = q.toString();
      return this.request<CommunicationLog[]>(`/communication/logs${qs ? `?${qs}` : ''}`);
    },
    getLogById: (id: string) =>
      this.request<CommunicationLog>(`/communication/logs/${id}`),
    retryLog: (id: string) =>
      this.request<CommunicationLog>(`/communication/logs/${id}/retry`, {
        method: 'POST'
      }),
    getStats: () => this.request<CommunicationStats>('/communication/stats'),
    getPreferences: () =>
      this.request<UserNotificationPreference>('/communication/preferences'),
    updatePreferences: (updates: Partial<UserNotificationPreference>) =>
      this.request<UserNotificationPreference>('/communication/preferences', {
        method: 'PUT',
        body: JSON.stringify(updates)
      }),
    getUserPreferences: (userId: string) =>
      this.request<UserNotificationPreference>(`/communication/preferences/${userId}`),
    updateUserPreferences: (userId: string, updates: Partial<UserNotificationPreference>) =>
      this.request<UserNotificationPreference>(`/communication/preferences/${userId}`, {
        method: 'PUT',
        body: JSON.stringify(updates)
      }),
    dispatch: (payload: any) =>
      this.request<any>('/communication/dispatch', {
        method: 'POST',
        body: JSON.stringify(payload)
      }),
    announcements: {
      getAll: (params?: AnnouncementFilterParams) => {
        const q = new URLSearchParams();
        if (params?.classId) q.append('classId', params.classId);
        if (params?.sectionId) q.append('sectionId', params.sectionId);
        if (params?.category) q.append('category', params.category);
        if (params?.priority) q.append('priority', params.priority);
        if (params?.status) q.append('status', params.status);
        if (params?.targetAudience) q.append('targetAudience', params.targetAudience);
        if (params?.search) q.append('search', params.search);
        if (params?.page) q.append('page', String(params.page));
        if (params?.limit) q.append('limit', String(params.limit));
        const qs = q.toString();
        return this.request<{
          data: ClassAnnouncement[];
          stats: {
            total: number;
            published: number;
            scheduled: number;
            drafts: number;
            expired: number;
            archived: number;
          };
          pagination: { page: number; limit: number; total: number; totalPages: number };
        }>(`/communication/announcements${qs ? `?${qs}` : ''}`);
      },
      getById: (id: string) =>
        this.request<{ data: ClassAnnouncement; deliveryLogs?: CommunicationLog[] }>(
          `/communication/announcements/${id}`
        ),
      getStats: () =>
        this.request<{
          total: number;
          published: number;
          scheduled: number;
          drafts: number;
          expired: number;
          archived: number;
          pinned: number;
          totalReads: number;
          byCategory: Record<string, number>;
          byAudience: Record<string, number>;
        }>('/communication/announcements/stats'),
      create: (payload: Partial<ClassAnnouncement>) =>
        this.request<{ success: boolean; message: string; data: ClassAnnouncement }>(
          '/communication/announcements',
          {
            method: 'POST',
            body: JSON.stringify(payload)
          }
        ),
      update: (id: string, updates: Partial<ClassAnnouncement>) =>
        this.request<{ success: boolean; message: string; data: ClassAnnouncement }>(
          `/communication/announcements/${id}`,
          {
            method: 'PUT',
            body: JSON.stringify(updates)
          }
        ),
      publish: (id: string) =>
        this.request<{ success: boolean; message: string; data: ClassAnnouncement }>(
          `/communication/announcements/${id}/publish`,
          { method: 'POST' }
        ),
      cancelSchedule: (id: string) =>
        this.request<{ success: boolean; message: string; data: ClassAnnouncement }>(
          `/communication/announcements/${id}/cancel-schedule`,
          { method: 'POST' }
        ),
      archive: (id: string) =>
        this.request<{ success: boolean; message: string; data: ClassAnnouncement }>(
          `/communication/announcements/${id}/archive`,
          { method: 'POST' }
        ),
      unarchive: (id: string) =>
        this.request<{ success: boolean; message: string; data: ClassAnnouncement }>(
          `/communication/announcements/${id}/unarchive`,
          { method: 'POST' }
        ),
      togglePin: (id: string) =>
        this.request<{ success: boolean; message: string; isPinned: boolean }>(
          `/communication/announcements/${id}/pin`,
          { method: 'POST' }
        ),
      delete: (id: string) =>
        this.request<{ success: boolean; message: string }>(
          `/communication/announcements/${id}`,
          { method: 'DELETE' }
        ),
      markAsRead: (id: string) =>
        this.request<{ success: boolean; message: string }>(
          `/communication/announcements/${id}/read`,
          { method: 'POST' }
        ),
      uploadAttachment: (payload: { fileName: string; fileSizeBytes: number; fileData?: string; fileType?: string }) =>
        this.request<{ success: boolean; message: string; data: AnnouncementAttachment }>(
          '/communication/announcements/upload-attachment',
          {
            method: 'POST',
            body: JSON.stringify(payload)
          }
        ),
      preview: (payload: any) =>
        this.request<{
          data: {
            title: string;
            content: string;
            estimatedRecipients: number;
            targetAudience: string;
          };
        }>('/communication/announcements/preview', {
          method: 'POST',
          body: JSON.stringify(payload)
        })
    },
    inbox: {
      getConversations: (params?: ConversationFilterParams) => {
        const q = new URLSearchParams();
        if (params?.folder) q.append('folder', params.folder);
        if (params?.category) q.append('category', params.category);
        if (params?.search) q.append('search', params.search);
        if (params?.studentId) q.append('studentId', params.studentId);
        if (params?.unreadOnly !== undefined) q.append('unreadOnly', String(params.unreadOnly));
        if (params?.page) q.append('page', String(params.page));
        if (params?.limit) q.append('limit', String(params.limit));
        const qs = q.toString();
        return this.request<{
          data: Conversation[];
          unreadCount: number;
          pagination: { page: number; limit: number; total: number; totalPages: number };
        }>(`/communication/inbox/conversations${qs ? `?${qs}` : ''}`);
      },
      getConversationById: (id: string) =>
        this.request<{
          data: Conversation;
          messages: MessageItem[];
        }>(`/communication/inbox/conversations/${id}`),
      createConversation: (payload: {
        recipientId: string;
        studentId?: string;
        subject: string;
        message: string;
        category?: string;
        attachments?: any[];
        isDraft?: boolean;
      }) =>
        this.request<{
          success: boolean;
          message: string;
          data: Conversation;
          messageItem?: MessageItem;
        }>('/communication/inbox/conversations', {
          method: 'POST',
          body: JSON.stringify(payload)
        }),
      reply: (
        conversationId: string,
        payload: { message: string; attachments?: any[]; idempotencyKey?: string }
      ) =>
        this.request<{
          success: boolean;
          message: string;
          data: MessageItem;
          conversation: Conversation;
        }>(`/communication/inbox/conversations/${conversationId}/reply`, {
          method: 'POST',
          body: JSON.stringify(payload)
        }),
      markAsRead: (id: string) =>
        this.request<{ success: boolean; message: string }>(
          `/communication/inbox/conversations/${id}/read`,
          { method: 'POST' }
        ),
      markAsUnread: (id: string) =>
        this.request<{ success: boolean; message: string }>(
          `/communication/inbox/conversations/${id}/unread`,
          { method: 'POST' }
        ),
      toggleArchive: (id: string) =>
        this.request<{ success: boolean; message: string; isArchived: boolean }>(
          `/communication/inbox/conversations/${id}/archive`,
          { method: 'POST' }
        ),
      toggleStar: (id: string) =>
        this.request<{ success: boolean; message: string; isStarred: boolean }>(
          `/communication/inbox/conversations/${id}/star`,
          { method: 'POST' }
        ),
      reportConversation: (id: string, payload: { reason: string; details?: string }) =>
        this.request<{ success: boolean; message: string; data: MessageReport }>(
          `/communication/inbox/conversations/${id}/report`,
          {
            method: 'POST',
            body: JSON.stringify(payload)
          }
        ),
      discardDraft: (id: string) =>
        this.request<{ success: boolean; message: string }>(
          `/communication/inbox/conversations/${id}/draft`,
          { method: 'DELETE' }
        ),
      getEligibleRecipients: (studentId?: string) => {
        const qs = studentId ? `?studentId=${encodeURIComponent(studentId)}` : '';
        return this.request<{ success: boolean; data: EligibleRecipient[] }>(
          `/communication/inbox/eligible-recipients${qs}`
        );
      },
      getUnreadCount: () =>
        this.request<{ success: boolean; unreadCount: number }>(
          '/communication/inbox/unread-count'
        ),
      getReports: () =>
        this.request<{ success: boolean; data: MessageReport[] }>('/communication/inbox/reports'),
      resolveReport: (id: string, payload: { status: string; resolutionNotes?: string }) =>
        this.request<{ success: boolean; message: string; data: MessageReport }>(
          `/communication/inbox/reports/${id}/resolve`,
          {
            method: 'POST',
            body: JSON.stringify(payload)
          }
        )
    },
    campaigns: {
      getAll: (params?: BulkCampaignFilterParams) => {
        const q = new URLSearchParams();
        if (params?.search) q.append('search', params.search);
        if (params?.status) q.append('status', params.status);
        if (params?.category) q.append('category', params.category);
        if (params?.audienceType) q.append('audienceType', params.audienceType);
        if (params?.startDate) q.append('startDate', params.startDate);
        if (params?.endDate) q.append('endDate', params.endDate);
        if (params?.page) q.append('page', String(params.page));
        if (params?.limit) q.append('limit', String(params.limit));
        const qs = q.toString();
        return this.request<{
          data: BulkCampaign[];
          total: number;
          stats: BulkCampaignStats;
          pagination: { page: number; limit: number; totalPages: number };
        }>(`/communication/campaigns${qs ? `?${qs}` : ''}`);
      },
      getById: (id: string) =>
        this.request<{
          success: boolean;
          data: BulkCampaign;
          recipients: BulkCampaignRecipient[];
        }>(`/communication/campaigns/${id}`),
      getStats: () =>
        this.request<{ success: boolean; data: BulkCampaignStats }>(
          '/communication/campaigns/stats'
        ),
      previewRecipients: (payload: {
        audienceType: BulkCampaignAudienceType;
        academicSessionId?: string;
        classId?: string;
        sectionId?: string;
        targetRoles?: (UserRole | string)[];
        selectedRecipientIds?: string[];
        relationshipType?: BulkCampaignRelationshipType;
        subjectId?: string;
        channels?: NotificationChannel[];
      }) =>
        this.request<{ success: boolean; data: RecipientPreviewResult }>(
          '/communication/campaigns/preview-recipients',
          {
            method: 'POST',
            body: JSON.stringify(payload)
          }
        ),
      create: (payload: Partial<BulkCampaign>) =>
        this.request<{ success: boolean; message: string; data: BulkCampaign }>(
          '/communication/campaigns',
          {
            method: 'POST',
            body: JSON.stringify(payload)
          }
        ),
      update: (id: string, updates: Partial<BulkCampaign>) =>
        this.request<{ success: boolean; message: string; data: BulkCampaign }>(
          `/communication/campaigns/${id}`,
          {
            method: 'PUT',
            body: JSON.stringify(updates)
          }
        ),
      sendNow: (id: string) =>
        this.request<{ success: boolean; message: string; data: BulkCampaign }>(
          `/communication/campaigns/${id}/send`,
          { method: 'POST' }
        ),
      schedule: (id: string, payload: { scheduledAt: string }) =>
        this.request<{ success: boolean; message: string; data: BulkCampaign }>(
          `/communication/campaigns/${id}/schedule`,
          {
            method: 'POST',
            body: JSON.stringify(payload)
          }
        ),
      cancel: (id: string, payload?: { reason?: string }) =>
        this.request<{ success: boolean; message: string; data: BulkCampaign }>(
          `/communication/campaigns/${id}/cancel`,
          {
            method: 'POST',
            body: JSON.stringify(payload || {})
          }
        ),
      archive: (id: string) =>
        this.request<{ success: boolean; message: string; data: BulkCampaign }>(
          `/communication/campaigns/${id}/archive`,
          { method: 'POST' }
        ),
      getRecipients: (
        id: string,
        params?: { page?: number; limit?: number; search?: string; status?: string }
      ) => {
        const q = new URLSearchParams();
        if (params?.page) q.append('page', String(params.page));
        if (params?.limit) q.append('limit', String(params.limit));
        if (params?.search) q.append('search', params.search);
        if (params?.status) q.append('status', params.status);
        const qs = q.toString();
        return this.request<{
          success: boolean;
          data: BulkCampaignRecipient[];
          total: number;
          pagination: { page: number; limit: number; totalPages: number };
        }>(`/communication/campaigns/${id}/recipients${qs ? `?${qs}` : ''}`);
      }
    },
    analytics: {
      getOverview: (filters?: CommunicationAnalyticsFilterParams) => {
        const q = new URLSearchParams();
        if (filters?.datePreset) q.append('datePreset', filters.datePreset);
        if (filters?.startDate) q.append('startDate', filters.startDate);
        if (filters?.endDate) q.append('endDate', filters.endDate);
        if (filters?.academicSessionId) q.append('academicSessionId', filters.academicSessionId);
        if (filters?.classId) q.append('classId', filters.classId);
        if (filters?.sectionId) q.append('sectionId', filters.sectionId);
        if (filters?.recipientRole) q.append('recipientRole', filters.recipientRole);
        if (filters?.category) q.append('category', filters.category);
        if (filters?.channel) q.append('channel', filters.channel);
        if (filters?.status) q.append('status', filters.status);
        const qs = q.toString();
        return this.request<{ success: boolean; data: CommunicationAnalyticsOverview }>(
          `/communication/analytics/overview${qs ? `?${qs}` : ''}`
        );
      },
      getDeliveryReport: (params?: DeliveryReportQuery) => {
        const q = new URLSearchParams();
        if (params?.page) q.append('page', String(params.page));
        if (params?.limit) q.append('limit', String(params.limit));
        if (params?.search) q.append('search', params.search);
        if (params?.channel) q.append('channel', params.channel);
        if (params?.status) q.append('status', params.status);
        if (params?.recipientRole) q.append('recipientRole', params.recipientRole);
        if (params?.eventType) q.append('eventType', params.eventType);
        if (params?.startDate) q.append('startDate', params.startDate);
        if (params?.endDate) q.append('endDate', params.endDate);
        if (params?.sortBy) q.append('sortBy', params.sortBy);
        if (params?.sortOrder) q.append('sortOrder', params.sortOrder);
        const qs = q.toString();
        return this.request<{
          success: boolean;
          data: DeliveryReportItem[];
          total: number;
          page: number;
          limit: number;
          totalPages: number;
          stats: { totalDelivered: number; totalFailed: number; totalPending: number };
        }>(`/communication/analytics/delivery-reports${qs ? `?${qs}` : ''}`);
      },
      exportReportUrl: (type: ExportReportType, format: ExportFormat = 'csv', filters?: any) => {
        const q = new URLSearchParams();
        q.append('type', type);
        q.append('format', format);
        if (filters?.datePreset) q.append('datePreset', filters.datePreset);
        if (filters?.startDate) q.append('startDate', filters.startDate);
        if (filters?.endDate) q.append('endDate', filters.endDate);
        if (filters?.channel) q.append('channel', filters.channel);
        if (filters?.status) q.append('status', filters.status);
        if (filters?.recipientRole) q.append('recipientRole', filters.recipientRole);
        if (filters?.search) q.append('search', filters.search);
        return `/api/communication/analytics/export?${q.toString()}`;
      },
      cancelScheduled: (id: string, type: 'CAMPAIGN' | 'ANNOUNCEMENT') => {
        return this.request<{ success: boolean; message: string }>(
          '/communication/analytics/cancel-scheduled',
          {
            method: 'POST',
            body: JSON.stringify({ id, type })
          }
        );
      }
    }
  };

  // =========================================================================
  // PART 12A: STAFF & HUMAN RESOURCE MANAGEMENT FOUNDATION
  // =========================================================================
  staff = {
    getDirectory: (query?: StaffDirectoryQuery) => {
      const q = new URLSearchParams();
      if (query?.search) q.append('search', query.search);
      if (query?.staffType) q.append('staffType', query.staffType);
      if (query?.departmentId) q.append('departmentId', query.departmentId);
      if (query?.designationId) q.append('designationId', query.designationId);
      if (query?.employmentStatus) q.append('employmentStatus', query.employmentStatus);
      if (query?.employmentType) q.append('employmentType', query.employmentType);
      if (query?.gender) q.append('gender', query.gender);
      if (query?.page) q.append('page', query.page.toString());
      if (query?.limit) q.append('limit', query.limit.toString());
      if (query?.sortBy) q.append('sortBy', query.sortBy);
      if (query?.sortOrder) q.append('sortOrder', query.sortOrder);
      const qs = q.toString();
      return this.request<StaffDirectoryResponse>(`/staff${qs ? `?${qs}` : ''}`);
    },
    getStats: () =>
      this.request<StaffStatsResponse>('/staff/stats'),
    getNextEmployeeCode: (staffType: string = 'teaching') =>
      this.request<{ employeeCode: string; staffType: string }>(
        `/staff/code/next?staffType=${encodeURIComponent(staffType)}`
      ).then((res) => (typeof res === 'string' ? res : res.employeeCode)),
    getNextCode: (staffType: string = 'teaching') =>
      this.request<{ employeeCode: string; staffType: string }>(
        `/staff/code/next?staffType=${encodeURIComponent(staffType)}`
      ),
    getStaffProfile: (id: string) =>
      this.request<StaffProfile & { teacherDetails?: any }>(`/staff/${id}`),
    getStaffById: (id: string) =>
      this.request<StaffProfile & { teacherDetails?: any }>(`/staff/${id}`),
    createStaffProfile: (payload: CreateStaffPayload) =>
      this.request<StaffProfile>('/staff', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),
    createStaff: (payload: CreateStaffPayload) =>
      this.request<StaffProfile>('/staff', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),
    updateStaffProfile: (id: string, payload: UpdateStaffPayload) =>
      this.request<StaffProfile>(`/staff/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),
    updateStaff: (id: string, payload: UpdateStaffPayload) =>
      this.request<StaffProfile>(`/staff/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),
    changeEmploymentStatus: (id: string, payload: ChangeStaffStatusPayload) =>
      this.request<StaffProfile>(`/staff/${id}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),
    changeStatus: (id: string, payload: ChangeStaffStatusPayload) =>
      this.request<StaffProfile>(`/staff/${id}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),
    getStaffDocuments: (id: string) =>
      this.request<StaffDocument[]>(`/staff/${id}/documents`),
    uploadStaffDocument: (id: string, payload: UploadStaffDocumentPayload) =>
      this.request<StaffDocument>(`/staff/${id}/documents`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),
    uploadDocument: (id: string, payload: UploadStaffDocumentPayload) =>
      this.request<StaffDocument>(`/staff/${id}/documents`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),
    deleteStaffDocument: (id: string, docId: string) =>
      this.request<{ message: string }>(`/staff/${id}/documents/${docId}`, {
        method: 'DELETE'
      }),
    deleteDocument: (id: string, docId: string) =>
      this.request<{ message: string }>(`/staff/${id}/documents/${docId}`, {
        method: 'DELETE'
      }),
    verifyStaffDocument: (id: string, docId: string, payload: VerifyStaffDocumentPayload) =>
      this.request<StaffDocument>(`/staff/${id}/documents/${docId}/verify`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),
    verifyDocument: (id: string, docId: string, payload: VerifyStaffDocumentPayload) =>
      this.request<StaffDocument>(`/staff/${id}/documents/${docId}/verify`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),
    linkUserAccount: (id: string, payload: { userId?: string; username?: string; password?: string; role?: any }) =>
      this.request<StaffProfile>(`/staff/${id}/link-account`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),
    linkAccount: (id: string, payload: { userId?: string; username?: string; password?: string; role?: any }) =>
      this.request<StaffProfile>(`/staff/${id}/link-account`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),
    unlinkUserAccount: (id: string) =>
      this.request<StaffProfile>(`/staff/${id}/unlink-account`, {
        method: 'POST'
      }),
    unlinkAccount: (id: string) =>
      this.request<StaffProfile>(`/staff/${id}/unlink-account`, {
        method: 'POST'
      }),
    getDepartmentsWithCounts: () =>
      this.request<Array<Department & { staffCount: number; teachingCount: number; nonTeachingCount: number }>>(
        '/staff/meta/departments'
      ),
    getDepartments: () =>
      this.request<Array<Department & { staffCount: number; teachingCount: number; nonTeachingCount: number }>>(
        '/staff/meta/departments'
      ),
    createDepartment: (payload: Partial<Department>) =>
      this.request<Department>('/staff/meta/departments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),
    updateDepartment: (id: string, payload: Partial<Department>) =>
      this.request<Department>(`/staff/meta/departments/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),
    deleteDepartment: (id: string) =>
      this.request<{ message: string }>(`/staff/meta/departments/${id}`, {
        method: 'DELETE'
      }),
    getDesignations: (departmentId?: string, staffType?: string) => {
      const q = new URLSearchParams();
      if (departmentId) q.append('departmentId', departmentId);
      if (staffType) q.append('staffType', staffType);
      const qs = q.toString();
      return this.request<Designation[]>(`/staff/meta/designations${qs ? `?${qs}` : ''}`);
    },
    createDesignation: (payload: CreateDesignationPayload) =>
      this.request<Designation>('/staff/meta/designations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),
    updateDesignation: (id: string, payload: UpdateDesignationPayload) =>
      this.request<Designation>(`/staff/meta/designations/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),
    deleteDesignation: (id: string) =>
      this.request<{ message: string }>(`/staff/meta/designations/${id}`, {
        method: 'DELETE'
      }),
    getExportCsvUrl: (query?: StaffDirectoryQuery) => {
      const q = new URLSearchParams();
      if (query?.search) q.append('search', query.search);
      if (query?.staffType) q.append('staffType', query.staffType);
      if (query?.departmentId) q.append('departmentId', query.departmentId);
      if (query?.designationId) q.append('designationId', query.designationId);
      if (query?.employmentStatus) q.append('employmentStatus', query.employmentStatus);
      if (query?.employmentType) q.append('employmentType', query.employmentType);
      if (query?.gender) q.append('gender', query.gender);
      return `/api/staff/export?${q.toString()}`;
    },

    // Staff Attendance (Part 12B)
    attendance: {
      getDaily: (date?: string, filters?: { departmentId?: string; staffType?: string; status?: string; search?: string; academicSessionId?: string }) => {
        const q = new URLSearchParams();
        if (date) q.append('date', date);
        if (filters?.departmentId) q.append('departmentId', filters.departmentId);
        if (filters?.staffType) q.append('staffType', filters.staffType);
        if (filters?.status) q.append('status', filters.status);
        if (filters?.search) q.append('search', filters.search);
        if (filters?.academicSessionId) q.append('academicSessionId', filters.academicSessionId);
        const qs = q.toString();
        return this.request<import('../types/index.js').StaffDailyAttendanceResponse>(`/staff/attendance/daily${qs ? `?${qs}` : ''}`);
      },
      getMonthly: (year: number, month: number, filters?: { departmentId?: string; staffType?: string; search?: string; academicSessionId?: string }) => {
        const q = new URLSearchParams();
        q.append('year', year.toString());
        q.append('month', month.toString());
        if (filters?.departmentId) q.append('departmentId', filters.departmentId);
        if (filters?.staffType) q.append('staffType', filters.staffType);
        if (filters?.search) q.append('search', filters.search);
        if (filters?.academicSessionId) q.append('academicSessionId', filters.academicSessionId);
        const qs = q.toString();
        return this.request<import('../types/index.js').StaffMonthlyAttendanceResponse>(`/staff/attendance/monthly${qs ? `?${qs}` : ''}`);
      },
      getStats: (date?: string) => {
        const q = new URLSearchParams();
        if (date) q.append('date', date);
        const qs = q.toString();
        return this.request<import('../types/index.js').StaffAttendanceStatsResponse>(`/staff/attendance/stats${qs ? `?${qs}` : ''}`);
      },
      mark: (payload: import('../types/index.js').MarkStaffAttendancePayload) =>
        this.request<import('../types/index.js').StaffAttendanceRecord>('/staff/attendance/mark', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }),
      bulkMark: (payload: import('../types/index.js').BulkMarkStaffAttendancePayload) =>
        this.request<{ savedCount: number; records: import('../types/index.js').StaffAttendanceRecord[] }>('/staff/attendance/bulk', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }),
      correct: (id: string, payload: import('../types/index.js').CorrectStaffAttendancePayload) =>
        this.request<import('../types/index.js').StaffAttendanceRecord>(`/staff/attendance/${id}/correct`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }),
      getExportCsvUrl: (date?: string, departmentId?: string, staffType?: string) => {
        const q = new URLSearchParams();
        if (date) q.append('date', date);
        if (departmentId && departmentId !== 'ALL') q.append('departmentId', departmentId);
        if (staffType && staffType !== 'ALL') q.append('staffType', staffType);
        const qs = q.toString();
        return `/api/staff/attendance/export${qs ? `?${qs}` : ''}`;
      }
    },

    // Staff Work Schedules (Part 12B)
    schedules: {
      getAll: (filters?: { scope?: string; isActive?: boolean; departmentId?: string; designationId?: string; search?: string }) => {
        const q = new URLSearchParams();
        if (filters?.scope) q.append('scope', filters.scope);
        if (filters?.isActive !== undefined) q.append('isActive', String(filters.isActive));
        if (filters?.departmentId) q.append('departmentId', filters.departmentId);
        if (filters?.designationId) q.append('designationId', filters.designationId);
        if (filters?.search) q.append('search', filters.search);
        const qs = q.toString();
        return this.request<import('../types/index.js').StaffWorkSchedule[]>(`/staff/schedules${qs ? `?${qs}` : ''}`);
      },
      getById: (id: string) =>
        this.request<import('../types/index.js').StaffWorkSchedule>(`/staff/schedules/${id}`),
      getEffective: (staffId: string, date?: string) => {
        const q = new URLSearchParams();
        if (date) q.append('date', date);
        const qs = q.toString();
        return this.request<import('../types/index.js').StaffEffectiveSchedule>(`/staff/schedules/effective/${staffId}${qs ? `?${qs}` : ''}`);
      },
      create: (payload: import('../types/index.js').CreateStaffSchedulePayload) =>
        this.request<import('../types/index.js').StaffWorkSchedule>('/staff/schedules', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }),
      update: (id: string, payload: import('../types/index.js').UpdateStaffSchedulePayload) =>
        this.request<import('../types/index.js').StaffWorkSchedule>(`/staff/schedules/${id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }),
      delete: (id: string) =>
        this.request<{ message: string }>(`/staff/schedules/${id}`, {
          method: 'DELETE'
        })
    },

    // Staff Leave Integration & Management (Part 12B & Part 12C)
    leaves: {
      getAll: (filters?: { status?: string; departmentId?: string; staffType?: string; search?: string }) => {
        const q = new URLSearchParams();
        if (filters?.status) q.append('status', filters.status);
        if (filters?.departmentId) q.append('departmentId', filters.departmentId);
        if (filters?.staffType) q.append('staffType', filters.staffType);
        if (filters?.search) q.append('search', filters.search);
        const qs = q.toString();
        return this.request<import('../types/index.js').LeaveApplication[]>(`/staff/leaves${qs ? `?${qs}` : ''}`);
      },
      apply: (payload: import('../types/index.js').StaffLeaveApplicationPayload) =>
        this.request<import('../types/index.js').LeaveApplication>('/staff/leaves', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }),
      review: (id: string, payload: import('../types/index.js').ReviewStaffLeavePayload) =>
        this.request<import('../types/index.js').LeaveApplication>(`/staff/leaves/${id}/review`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }),
      cancel: (id: string, reason?: string) =>
        this.request<import('../types/index.js').LeaveApplication>(`/staff/leaves/${id}/cancel`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ reason })
        }),
      getPolicies: (academicSessionId?: string) => {
        const qs = academicSessionId ? `?academicSessionId=${academicSessionId}` : '';
        return this.request<import('../types/index.js').StaffLeavePolicy[]>(`/staff/leaves/policies${qs}`);
      },
      createPolicy: (payload: import('../types/index.js').CreateStaffLeavePolicyPayload) =>
        this.request<import('../types/index.js').StaffLeavePolicy>('/staff/leaves/policies', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }),
      updatePolicy: (id: string, payload: import('../types/index.js').UpdateStaffLeavePolicyPayload) =>
        this.request<import('../types/index.js').StaffLeavePolicy>(`/staff/leaves/policies/${id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }),
      deletePolicy: (id: string) =>
        this.request<{ message: string }>(`/staff/leaves/policies/${id}`, {
          method: 'DELETE'
        }),
      getBalances: (query?: import('../types/index.js').StaffLeaveBalancesQuery) => {
        const q = new URLSearchParams();
        if (query?.academicSessionId) q.append('academicSessionId', query.academicSessionId);
        if (query?.departmentId) q.append('departmentId', query.departmentId);
        if (query?.staffType) q.append('staffType', query.staffType);
        if (query?.leaveTypeId) q.append('leaveTypeId', query.leaveTypeId);
        if (query?.search) q.append('search', query.search);
        if (query?.page) q.append('page', String(query.page));
        if (query?.limit) q.append('limit', String(query.limit));
        const qs = q.toString();
        return this.request<import('../types/index.js').StaffLeaveBalancesResponse>(`/staff/leaves/balances${qs ? `?${qs}` : ''}`);
      },
      getMyBalances: (academicSessionId?: string) => {
        const qs = academicSessionId ? `?academicSessionId=${academicSessionId}` : '';
        return this.request<import('../types/index.js').StaffLeaveBalance[]>(`/staff/leaves/my-balances${qs}`);
      },
      getStaffBalances: (staffId: string, academicSessionId?: string) => {
        const qs = academicSessionId ? `?academicSessionId=${academicSessionId}` : '';
        return this.request<import('../types/index.js').StaffLeaveBalance[]>(`/staff/leaves/staff/${staffId}/balances${qs}`);
      },
      validateApplication: (payload: {
        staffId?: string;
        leaveTypeId: string;
        startDate: string;
        endDate?: string;
        attachmentUrl?: string;
        allowBalanceOverride?: boolean;
      }) =>
        this.request<{
          isValid: boolean;
          errors: string[];
          warnings: string[];
          policy: import('../types/index.js').StaffLeavePolicy | null;
          balance: import('../types/index.js').StaffLeaveBalance;
          workingDaysCount: number;
          workingDates: string[];
        }>('/staff/leaves/validate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }),
      adjustBalance: (payload: import('../types/index.js').AdjustStaffLeaveBalancePayload) =>
        this.request<import('../types/index.js').StaffLeaveTransaction>('/staff/leaves/adjust', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }),
      getLedger: (query?: import('../types/index.js').StaffLeaveLedgerQuery) => {
        const q = new URLSearchParams();
        if (query?.academicSessionId) q.append('academicSessionId', query.academicSessionId);
        if (query?.staffId) q.append('staffId', query.staffId);
        if (query?.leaveTypeId) q.append('leaveTypeId', query.leaveTypeId);
        if (query?.transactionType) q.append('transactionType', query.transactionType);
        if (query?.startDate) q.append('startDate', query.startDate);
        if (query?.endDate) q.append('endDate', query.endDate);
        if (query?.search) q.append('search', query.search);
        if (query?.page) q.append('page', String(query.page));
        if (query?.limit) q.append('limit', String(query.limit));
        const qs = q.toString();
        return this.request<import('../types/index.js').StaffLeaveLedgerResponse>(`/staff/leaves/ledger${qs ? `?${qs}` : ''}`);
      },
      runCarryForward: (payload: import('../types/index.js').CarryForwardProcessPayload) =>
        this.request<import('../types/index.js').CarryForwardResult>('/staff/leaves/carry-forward', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }),
      getReportsSummary: (academicSessionId?: string) => {
        const qs = academicSessionId ? `?academicSessionId=${academicSessionId}` : '';
        return this.request<import('../types/index.js').StaffLeaveReportsSummary>(`/staff/leaves/reports/summary${qs}`);
      }
    },
    // Staff Recruitment & Pipeline Management (Part 12D)
    recruitment: {
      getMetrics: () =>
        this.request<{ success: boolean; data: import('../types/index.js').RecruitmentDashboardMetrics }>('/staff/recruitment/metrics'),
      getJobOpenings: (query?: import('../types/index.js').RecruitmentFilterQuery) => {
        const q = new URLSearchParams();
        if (query?.search) q.append('search', query.search);
        if (query?.departmentId) q.append('departmentId', query.departmentId);
        if (query?.staffType) q.append('staffType', query.staffType);
        if (query?.status) q.append('status', query.status);
        if (query?.page) q.append('page', String(query.page));
        if (query?.limit) q.append('limit', String(query.limit));
        const qs = q.toString();
        return this.request<{ items: import('../types/index.js').JobOpening[]; total: number; summary: any }>(
          `/staff/recruitment/jobs${qs ? `?${qs}` : ''}`
        );
      },
      getJobOpening: (id: string) =>
        this.request<{ success: boolean; data: import('../types/index.js').JobOpening }>(`/staff/recruitment/jobs/${id}`),
      createJobOpening: (payload: import('../types/index.js').CreateJobOpeningPayload) =>
        this.request<{ success: boolean; data: import('../types/index.js').JobOpening; message: string }>('/staff/recruitment/jobs', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }),
      updateJobOpening: (id: string, payload: import('../types/index.js').UpdateJobOpeningPayload) =>
        this.request<{ success: boolean; data: import('../types/index.js').JobOpening; message: string }>(`/staff/recruitment/jobs/${id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }),
      deleteJobOpening: (id: string) =>
        this.request<{ success: boolean; message: string }>(`/staff/recruitment/jobs/${id}`, {
          method: 'DELETE'
        }),
      getCandidates: (query?: import('../types/index.js').RecruitmentFilterQuery) => {
        const q = new URLSearchParams();
        if (query?.search) q.append('search', query.search);
        if (query?.departmentId) q.append('departmentId', query.departmentId);
        if (query?.status) q.append('status', query.status);
        if (query?.page) q.append('page', String(query.page));
        if (query?.limit) q.append('limit', String(query.limit));
        const qs = q.toString();
        return this.request<{ items: import('../types/index.js').CandidateProfile[]; total: number }>(
          `/staff/recruitment/candidates${qs ? `?${qs}` : ''}`
        );
      },
      getCandidate: (id: string) =>
        this.request<{ success: boolean; data: import('../types/index.js').CandidateProfile & { applications: any[]; interviews: any[]; offers: any[]; staffProfile?: any } }>(
          `/staff/recruitment/candidates/${id}`
        ),
      createCandidate: (payload: import('../types/index.js').CreateCandidatePayload) =>
        this.request<{ success: boolean; data: import('../types/index.js').CandidateProfile; message: string }>('/staff/recruitment/candidates', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }),
      updateCandidate: (id: string, payload: import('../types/index.js').UpdateCandidatePayload) =>
        this.request<{ success: boolean; data: import('../types/index.js').CandidateProfile; message: string }>(`/staff/recruitment/candidates/${id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }),
      getApplications: (query?: any) => {
        const q = new URLSearchParams();
        if (query?.candidateId) q.append('candidateId', query.candidateId);
        if (query?.jobOpeningId) q.append('jobOpeningId', query.jobOpeningId);
        if (query?.departmentId) q.append('departmentId', query.departmentId);
        if (query?.stage) q.append('stage', query.stage);
        if (query?.search) q.append('search', query.search);
        if (query?.page) q.append('page', String(query.page));
        if (query?.limit) q.append('limit', String(query.limit));
        const qs = q.toString();
        return this.request<{ items: import('../types/index.js').JobApplication[]; total: number }>(
          `/staff/recruitment/applications${qs ? `?${qs}` : ''}`
        );
      },
      getApplication: (id: string) =>
        this.request<{ success: boolean; data: import('../types/index.js').JobApplication & { interviews: any[]; offers: any[]; candidate?: any; jobOpening?: any } }>(
          `/staff/recruitment/applications/${id}`
        ),
      createApplication: (payload: import('../types/index.js').CreateJobApplicationPayload) =>
        this.request<{ success: boolean; data: import('../types/index.js').JobApplication; message: string }>('/staff/recruitment/applications', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }),
      screenApplication: (id: string, payload: import('../types/index.js').ScreenApplicationPayload) =>
        this.request<{ success: boolean; data: import('../types/index.js').JobApplication; message: string }>(`/staff/recruitment/applications/${id}/screen`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }),
      transitionApplicationStage: (id: string, payload: import('../types/index.js').TransitionApplicationStagePayload) =>
        this.request<{ success: boolean; data: import('../types/index.js').JobApplication; message: string }>(`/staff/recruitment/applications/${id}/stage`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }),
      selectCandidate: (applicationId: string) =>
        this.request<{ success: boolean; data: import('../types/index.js').JobApplication; message: string }>(`/staff/recruitment/applications/${applicationId}/select`, {
          method: 'POST'
        }),
      getInterviews: (query?: any) => {
        const q = new URLSearchParams();
        if (query?.applicationId) q.append('applicationId', query.applicationId);
        if (query?.candidateId) q.append('candidateId', query.candidateId);
        if (query?.jobOpeningId) q.append('jobOpeningId', query.jobOpeningId);
        if (query?.status) q.append('status', query.status);
        if (query?.date) q.append('date', query.date);
        const qs = q.toString();
        return this.request<{ success: boolean; data: import('../types/index.js').JobInterview[]; total: number }>(
          `/staff/recruitment/interviews${qs ? `?${qs}` : ''}`
        );
      },
      getInterview: (id: string) =>
        this.request<{ success: boolean; data: import('../types/index.js').JobInterview }>(`/staff/recruitment/interviews/${id}`),
      scheduleInterview: (payload: import('../types/index.js').ScheduleInterviewPayload) =>
        this.request<{ success: boolean; data: import('../types/index.js').JobInterview; message: string }>('/staff/recruitment/interviews', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }),
      submitInterviewEvaluation: (id: string, payload: import('../types/index.js').SubmitEvaluationPayload) =>
        this.request<{ success: boolean; data: import('../types/index.js').JobInterview; message: string }>(`/staff/recruitment/interviews/${id}/evaluations`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }),
      rescheduleInterview: (id: string, payload: import('../types/index.js').RescheduleInterviewPayload) =>
        this.request<{ success: boolean; data: import('../types/index.js').JobInterview; message: string }>(`/staff/recruitment/interviews/${id}/reschedule`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }),
      getOffers: (query?: any) => {
        const q = new URLSearchParams();
        if (query?.applicationId) q.append('applicationId', query.applicationId);
        if (query?.candidateId) q.append('candidateId', query.candidateId);
        if (query?.jobOpeningId) q.append('jobOpeningId', query.jobOpeningId);
        if (query?.status) q.append('status', query.status);
        const qs = q.toString();
        return this.request<{ success: boolean; data: import('../types/index.js').JobOffer[]; total: number }>(
          `/staff/recruitment/offers${qs ? `?${qs}` : ''}`
        );
      },
      getOffer: (id: string) =>
        this.request<{ success: boolean; data: import('../types/index.js').JobOffer }>(`/staff/recruitment/offers/${id}`),
      createOffer: (payload: import('../types/index.js').CreateJobOfferPayload) =>
        this.request<{ success: boolean; data: import('../types/index.js').JobOffer; message: string }>('/staff/recruitment/offers', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }),
      reviewOffer: (id: string, payload: import('../types/index.js').ReviewOfferPayload) =>
        this.request<{ success: boolean; data: import('../types/index.js').JobOffer; message: string }>(`/staff/recruitment/offers/${id}/review`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }),
      sendOffer: (id: string) =>
        this.request<{ success: boolean; data: import('../types/index.js').JobOffer; message: string }>(`/staff/recruitment/offers/${id}/send`, {
          method: 'POST'
        }),
      recordOfferResponse: (id: string, payload: import('../types/index.js').CandidateOfferResponsePayload) =>
        this.request<{ success: boolean; data: import('../types/index.js').JobOffer; message: string }>(`/staff/recruitment/offers/${id}/respond`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }),
      convertCandidateToStaff: (candidateId: string, payload: Omit<import('../types/index.js').ConvertCandidateToStaffPayload, 'candidateId'>) =>
        this.request<{ success: boolean; data: import('../types/index.js').CandidateConversionResult; message: string }>(
          `/staff/recruitment/candidates/${candidateId}/convert-to-staff`,
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
          }
        )
    },
    // Staff Onboarding & Checklist Management (Part 12D)
    onboarding: {
      getRecords: (query?: { status?: string; departmentId?: string; staffType?: string; search?: string }) => {
        const q = new URLSearchParams();
        if (query?.status) q.append('status', query.status);
        if (query?.departmentId) q.append('departmentId', query.departmentId);
        if (query?.staffType) q.append('staffType', query.staffType);
        if (query?.search) q.append('search', query.search);
        const qs = q.toString();
        return this.request<{ success: boolean; data: import('../types/index.js').OnboardingRecord[]; total: number }>(
          `/staff/onboarding${qs ? `?${qs}` : ''}`
        );
      },
      getRecord: (id: string) =>
        this.request<{ success: boolean; data: import('../types/index.js').OnboardingRecord }>(`/staff/onboarding/${id}`),
      getRecordByStaffId: (staffId: string) =>
        this.request<{ success: boolean; data: import('../types/index.js').OnboardingRecord }>(`/staff/onboarding/staff/${staffId}`),
      getTemplates: () =>
        this.request<{ success: boolean; data: import('../types/index.js').OnboardingTemplate[] }>('/staff/onboarding/templates'),
      getTemplate: (id: string) =>
        this.request<{ success: boolean; data: import('../types/index.js').OnboardingTemplate }>(`/staff/onboarding/templates/${id}`),
      initialize: (staffId: string, templateId: string) =>
        this.request<{ success: boolean; data: import('../types/index.js').OnboardingRecord; message: string }>('/staff/onboarding/initialize', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ staffId, templateId })
        }),
      addTask: (onboardingId: string, payload: import('../types/index.js').CreateOnboardingTaskPayload) =>
        this.request<{ success: boolean; data: import('../types/index.js').OnboardingRecord; message: string }>(`/staff/onboarding/${onboardingId}/tasks`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }),
      updateTask: (onboardingId: string, taskId: string, payload: import('../types/index.js').UpdateOnboardingTaskPayload) =>
        this.request<{ success: boolean; data: import('../types/index.js').OnboardingRecord; message: string }>(`/staff/onboarding/${onboardingId}/tasks/${taskId}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        })
    },
    performance: {
      getMetrics: () =>
        this.request<{ success: boolean; data: import('../types/index.js').PerformanceDashboardMetrics }>('/staff/performance/metrics'),
      getCycles: (query?: any) => {
        const q = new URLSearchParams();
        if (query?.search) q.append('search', query.search);
        if (query?.status) q.append('status', query.status);
        if (query?.academicSessionId) q.append('academicSessionId', query.academicSessionId);
        const qs = q.toString();
        return this.request<{ success: boolean; data: { items: import('../types/index.js').PerformanceReviewCycle[]; total: number } }>(
          `/staff/performance/cycles${qs ? `?${qs}` : ''}`
        );
      },
      getCycle: (id: string) =>
        this.request<{ success: boolean; data: import('../types/index.js').PerformanceReviewCycle }>(`/staff/performance/cycles/${id}`),
      createCycle: (payload: import('../types/index.js').CreateReviewCyclePayload) =>
        this.request<{ success: boolean; data: import('../types/index.js').PerformanceReviewCycle; message: string }>('/staff/performance/cycles', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }),
      updateCycle: (id: string, payload: import('../types/index.js').UpdateReviewCyclePayload) =>
        this.request<{ success: boolean; data: import('../types/index.js').PerformanceReviewCycle; message: string }>(`/staff/performance/cycles/${id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }),
      transitionCycleStatus: (id: string, status: string) =>
        this.request<{ success: boolean; data: import('../types/index.js').PerformanceReviewCycle }>(`/staff/performance/cycles/${id}/status`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ status })
        }),
      generateReviews: (cycleId: string) =>
        this.request<{ success: boolean; message: string; data: { generatedCount: number; cycle: import('../types/index.js').PerformanceReviewCycle } }>(
          `/staff/performance/cycles/${cycleId}/generate-reviews`,
          { method: 'POST' }
        ),
      generateReviewsForCycle: (cycleId: string) =>
        this.request<{ success: boolean; message: string; data: { generatedCount: number; cycle: import('../types/index.js').PerformanceReviewCycle } }>(
          `/staff/performance/cycles/${cycleId}/generate-reviews`,
          { method: 'POST' }
        ),
      getCriteria: (query?: any) => {
        const q = new URLSearchParams();
        if (query?.category) q.append('category', query.category);
        if (query?.applicableStaffType) q.append('applicableStaffType', query.applicableStaffType);
        if (query?.search) q.append('search', query.search);
        const qs = q.toString();
        return this.request<{ success: boolean; data: import('../types/index.js').PerformanceCriterion[] }>(
          `/staff/performance/criteria${qs ? `?${qs}` : ''}`
        );
      },
      getCriterion: (id: string) =>
        this.request<{ success: boolean; data: import('../types/index.js').PerformanceCriterion }>(`/staff/performance/criteria/${id}`),
      deleteCriterion: (id: string) =>
        this.request<{ success: boolean; message: string }>(`/staff/performance/criteria/${id}`, {
          method: 'DELETE'
        }),
      createCriterion: (payload: import('../types/index.js').CreatePerformanceCriterionPayload) =>
        this.request<{ success: boolean; data: import('../types/index.js').PerformanceCriterion; message: string }>('/staff/performance/criteria', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }),
      updateCriterion: (id: string, payload: import('../types/index.js').UpdatePerformanceCriterionPayload) =>
        this.request<{ success: boolean; data: import('../types/index.js').PerformanceCriterion; message: string }>(`/staff/performance/criteria/${id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }),
      toggleCriterion: (id: string) =>
        this.request<{ success: boolean; data: import('../types/index.js').PerformanceCriterion }>(`/staff/performance/criteria/${id}/toggle`, {
          method: 'POST'
        }),
      getGoals: (query?: any) => {
        const q = new URLSearchParams();
        if (query?.staffId) q.append('staffId', query.staffId);
        if (query?.reviewCycleId) q.append('reviewCycleId', query.reviewCycleId);
        if (query?.status) q.append('status', query.status);
        if (query?.search) q.append('search', query.search);
        const qs = q.toString();
        return this.request<{ success: boolean; data: import('../types/index.js').PerformanceGoal[] }>(
          `/staff/performance/goals${qs ? `?${qs}` : ''}`
        );
      },
      getGoal: (id: string) =>
        this.request<{ success: boolean; data: import('../types/index.js').PerformanceGoal }>(`/staff/performance/goals/${id}`),
      createGoal: (payload: import('../types/index.js').CreatePerformanceGoalPayload) =>
        this.request<{ success: boolean; data: import('../types/index.js').PerformanceGoal; message: string }>('/staff/performance/goals', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }),
      updateGoal: (id: string, payload: import('../types/index.js').UpdatePerformanceGoalPayload) =>
        this.request<{ success: boolean; data: import('../types/index.js').PerformanceGoal; message: string }>(`/staff/performance/goals/${id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }),
      updateGoalProgress: (id: string, payload: import('../types/index.js').UpdateGoalProgressPayload) =>
        this.request<{ success: boolean; data: import('../types/index.js').PerformanceGoal; message: string }>(`/staff/performance/goals/${id}/progress`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }),
      getReviews: (query?: any) => {
        const q = new URLSearchParams();
        if (query?.search) q.append('search', query.search);
        if (query?.reviewCycleId) q.append('reviewCycleId', query.reviewCycleId);
        if (query?.departmentId) q.append('departmentId', query.departmentId);
        if (query?.staffType) q.append('staffType', query.staffType);
        if (query?.status) q.append('status', query.status);
        if (query?.ratingBand) q.append('ratingBand', query.ratingBand);
        if (query?.staffId) q.append('staffId', query.staffId);
        const qs = q.toString();
        return this.request<{ success: boolean; data: { items: import('../types/index.js').StaffPerformanceReview[]; total: number } }>(
          `/staff/performance/reviews${qs ? `?${qs}` : ''}`
        );
      },
      getReview: (id: string) =>
        this.request<{ success: boolean; data: import('../types/index.js').StaffPerformanceReview }>(`/staff/performance/reviews/${id}`),
      getMyReview: () =>
        this.request<{ success: boolean; data: import('../types/index.js').StaffPerformanceReview | null }>('/staff/performance/reviews/my-review'),
      createReview: (payload: import('../types/index.js').CreatePerformanceReviewPayload) =>
        this.request<{ success: boolean; data: import('../types/index.js').StaffPerformanceReview; message: string }>('/staff/performance/reviews', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }),
      submitSelfAssessment: (id: string, payload: import('../types/index.js').SubmitSelfAssessmentPayload) =>
        this.request<{ success: boolean; data: import('../types/index.js').StaffPerformanceReview; message: string }>(`/staff/performance/reviews/${id}/self-assessment`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }),
      submitSupervisorReview: (id: string, payload: import('../types/index.js').SubmitSupervisorReviewPayload) =>
        this.request<{ success: boolean; data: import('../types/index.js').StaffPerformanceReview; message: string }>(`/staff/performance/reviews/${id}/supervisor-review`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }),
      submitHRReview: (id: string, payload: import('../types/index.js').SubmitHRReviewPayload) =>
        this.request<{ success: boolean; data: import('../types/index.js').StaffPerformanceReview; message: string }>(`/staff/performance/reviews/${id}/hr-review`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }),
      overrideRating: (id: string, payload: import('../types/index.js').OverrideRatingPayload) =>
        this.request<{ success: boolean; data: import('../types/index.js').StaffPerformanceReview; message: string }>(`/staff/performance/reviews/${id}/override`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }),
      acknowledgeReview: (id: string, payload: import('../types/index.js').AcknowledgeReviewPayload) =>
        this.request<{ success: boolean; data: import('../types/index.js').StaffPerformanceReview; message: string }>(`/staff/performance/reviews/${id}/acknowledge`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }),
      transitionReview: (id: string, payload: import('../types/index.js').TransitionReviewWorkflowPayload) =>
        this.request<{ success: boolean; data: import('../types/index.js').StaffPerformanceReview }>(`/staff/performance/reviews/${id}/transition`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }),
      getFeedback: (query?: { staffId?: string; reviewId?: string }) => {
        const q = new URLSearchParams();
        if (query?.staffId) q.append('staffId', query.staffId);
        if (query?.reviewId) q.append('reviewId', query.reviewId);
        const qs = q.toString();
        return this.request<{ success: boolean; data: import('../types/index.js').PerformanceFeedbackItem[] }>(
          `/staff/performance/feedback${qs ? `?${qs}` : ''}`
        );
      },
      createFeedback: (payload: import('../types/index.js').CreatePerformanceFeedbackPayload) =>
        this.request<{ success: boolean; data: import('../types/index.js').PerformanceFeedbackItem; message: string }>('/staff/performance/feedback', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }),
      acknowledgeFeedback: (id: string, note?: string) =>
        this.request<{ success: boolean; data: import('../types/index.js').PerformanceFeedbackItem }>(`/staff/performance/feedback/${id}/acknowledge`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ note })
        }),
      getPIPs: (query?: any) => {
        const q = new URLSearchParams();
        if (query?.staffId) q.append('staffId', query.staffId);
        if (query?.status) q.append('status', query.status);
        if (query?.departmentId) q.append('departmentId', query.departmentId);
        if (query?.search) q.append('search', query.search);
        const qs = q.toString();
        return this.request<{ success: boolean; data: import('../types/index.js').PerformanceImprovementPlan[] }>(
          `/staff/performance/pips${qs ? `?${qs}` : ''}`
        );
      },
      getPIP: (id: string) =>
        this.request<{ success: boolean; data: import('../types/index.js').PerformanceImprovementPlan }>(`/staff/performance/pips/${id}`),
      createPIP: (payload: import('../types/index.js').CreatePIPPayload) =>
        this.request<{ success: boolean; data: import('../types/index.js').PerformanceImprovementPlan; message: string }>('/staff/performance/pips', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }),
      updatePIP: (id: string, payload: import('../types/index.js').UpdatePIPPayload) =>
        this.request<{ success: boolean; data: import('../types/index.js').PerformanceImprovementPlan; message: string }>(`/staff/performance/pips/${id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }),
      addPIPNote: (id: string, payload: import('../types/index.js').AddPIPProgressNotePayload) =>
        this.request<{ success: boolean; data: import('../types/index.js').PerformanceImprovementPlan; message: string }>(`/staff/performance/pips/${id}/notes`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }),
      addPIPProgressNote: (id: string, note: string) =>
        this.request<{ success: boolean; data: import('../types/index.js').PerformanceImprovementPlan; message: string }>(`/staff/performance/pips/${id}/notes`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ note })
        }),
      updatePIPAction: (id: string, actionId: string, payload: import('../types/index.js').UpdatePIPActionPayload) =>
        this.request<{ success: boolean; data: import('../types/index.js').PerformanceImprovementPlan; message: string }>(`/staff/performance/pips/${id}/actions/${actionId}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }),
      closePIP: (id: string, payload: import('../types/index.js').ClosePIPPayload) =>
        this.request<{ success: boolean; data: import('../types/index.js').PerformanceImprovementPlan; message: string }>(`/staff/performance/pips/${id}/close`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }),
      resolvePIP: (id: string, payload?: any) =>
        this.request<{ success: boolean; data: import('../types/index.js').PerformanceImprovementPlan; message: string }>(`/staff/performance/pips/${id}/close`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ outcome: 'IMPROVED_SATISFACTORY', finalNotes: payload?.finalNotes || 'Resolved successfully' })
        }),
      getReportsSummary: (cycleId: string) =>
        this.request<{ success: boolean; data: import('../types/index.js').PerformanceReportSummary }>(`/staff/performance/reports/summary?cycleId=${cycleId}`)
    },
    reports: {
      getDashboardKPIs: (query?: import('../types/index.js').HRReportFilterQuery) => {
        const q = new URLSearchParams();
        if (query?.departmentId) q.append('departmentId', query.departmentId);
        if (query?.designationId) q.append('designationId', query.designationId);
        if (query?.staffType) q.append('staffType', query.staffType);
        if (query?.employmentStatus) q.append('employmentStatus', query.employmentStatus);
        if (query?.startDate) q.append('startDate', query.startDate);
        if (query?.endDate) q.append('endDate', query.endDate);
        if (query?.search) q.append('search', query.search);
        const qs = q.toString();
        return this.request<import('../types/index.js').HRDashboardKPIs>(
          `/staff/reports/dashboard${qs ? `?${qs}` : ''}`
        );
      },
      getHeadcountReport: (query?: import('../types/index.js').HRReportFilterQuery) => {
        const q = new URLSearchParams();
        if (query?.departmentId) q.append('departmentId', query.departmentId);
        if (query?.designationId) q.append('designationId', query.designationId);
        if (query?.staffType) q.append('staffType', query.staffType);
        if (query?.employmentStatus) q.append('employmentStatus', query.employmentStatus);
        if (query?.search) q.append('search', query.search);
        const qs = q.toString();
        return this.request<import('../types/index.js').StaffHeadcountReport>(
          `/staff/reports/headcount${qs ? `?${qs}` : ''}`
        );
      },
      getAttendanceReport: (query?: import('../types/index.js').HRReportFilterQuery) => {
        const q = new URLSearchParams();
        if (query?.departmentId) q.append('departmentId', query.departmentId);
        if (query?.designationId) q.append('designationId', query.designationId);
        if (query?.staffType) q.append('staffType', query.staffType);
        if (query?.startDate) q.append('startDate', query.startDate);
        if (query?.endDate) q.append('endDate', query.endDate);
        const qs = q.toString();
        return this.request<import('../types/index.js').StaffAttendanceReport>(
          `/staff/reports/attendance${qs ? `?${qs}` : ''}`
        );
      },
      getLeaveReport: (query?: import('../types/index.js').HRReportFilterQuery) => {
        const q = new URLSearchParams();
        if (query?.departmentId) q.append('departmentId', query.departmentId);
        if (query?.leaveTypeId) q.append('leaveTypeId', query.leaveTypeId);
        if (query?.startDate) q.append('startDate', query.startDate);
        if (query?.endDate) q.append('endDate', query.endDate);
        const qs = q.toString();
        return this.request<import('../types/index.js').StaffLeaveReport>(
          `/staff/reports/leaves${qs ? `?${qs}` : ''}`
        );
      },
      getLeaveBalanceReport: (query?: import('../types/index.js').HRReportFilterQuery) => {
        const q = new URLSearchParams();
        if (query?.departmentId) q.append('departmentId', query.departmentId);
        if (query?.leaveTypeId) q.append('leaveTypeId', query.leaveTypeId);
        const qs = q.toString();
        return this.request<import('../types/index.js').LeaveBalanceUtilizationReport>(
          `/staff/reports/leave-balances${qs ? `?${qs}` : ''}`
        );
      },
      getRecruitmentFunnel: (query?: import('../types/index.js').HRReportFilterQuery) => {
        const q = new URLSearchParams();
        if (query?.jobOpeningId) q.append('jobOpeningId', query.jobOpeningId);
        const qs = q.toString();
        return this.request<import('../types/index.js').RecruitmentFunnelReport>(
          `/staff/reports/recruitment${qs ? `?${qs}` : ''}`
        );
      },
      getRecruitmentPerformance: () =>
        this.request<import('../types/index.js').RecruitmentPerformanceReport>(
          '/staff/reports/recruitment-performance'
        ),
      getOnboardingReport: (query?: import('../types/index.js').HRReportFilterQuery) => {
        const q = new URLSearchParams();
        if (query?.departmentId) q.append('departmentId', query.departmentId);
        const qs = q.toString();
        return this.request<import('../types/index.js').OnboardingReport>(
          `/staff/reports/onboarding${qs ? `?${qs}` : ''}`
        );
      },
      getPerformanceReport: (query?: import('../types/index.js').HRReportFilterQuery) => {
        const q = new URLSearchParams();
        if (query?.reviewCycleId) q.append('reviewCycleId', query.reviewCycleId);
        const qs = q.toString();
        return this.request<import('../types/index.js').PerformanceCompletionReport>(
          `/staff/reports/performance${qs ? `?${qs}` : ''}`
        );
      },
      getGoalsReport: (query?: import('../types/index.js').HRReportFilterQuery) => {
        const q = new URLSearchParams();
        if (query?.departmentId) q.append('departmentId', query.departmentId);
        const qs = q.toString();
        return this.request<import('../types/index.js').GoalAchievementReport>(
          `/staff/reports/goals${qs ? `?${qs}` : ''}`
        );
      },
      getTurnoverReport: () =>
        this.request<import('../types/index.js').StaffTurnoverReport>(
          '/staff/reports/turnover'
        ),
      getCrossSessionReport: () =>
        this.request<import('../types/index.js').CrossSessionHRReport>(
          '/staff/reports/cross-session'
        ),
      getDrilldown: (metricKey: string, query?: import('../types/index.js').HRReportFilterQuery) => {
        const q = new URLSearchParams();
        q.append('metricKey', metricKey);
        if (query?.departmentId) q.append('departmentId', query.departmentId);
        if (query?.designationId) q.append('designationId', query.designationId);
        if (query?.staffType) q.append('staffType', query.staffType);
        const qs = q.toString();
        return this.request<import('../types/index.js').HRDrilldownResponse>(
          `/staff/reports/drilldown?${qs}`
        );
      },
      auditExport: (payload: import('../types/index.js').HRExportAuditPayload) =>
        this.request<{ message: string }>('/staff/reports/export/audit', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        })
    }
  };

  departments = {
    getAll: () =>
      this.request<Department[]>('/academic/departments'),
    create: (payload: Partial<Department>) =>
      this.request<Department>('/staff/meta/departments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),
    update: (id: string, payload: Partial<Department>) =>
      this.request<Department>(`/staff/meta/departments/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),
    delete: (id: string) =>
      this.request<{ message: string }>(`/staff/meta/departments/${id}`, {
        method: 'DELETE'
      })
  };

  // =========================================================================
  // FRONT OFFICE & VISITOR MANAGEMENT (Part 13A - 13E)
  // =========================================================================
  frontOffice = {
    getStats: (params?: { datePreset?: string; startDate?: string; endDate?: string; academicSessionId?: string }) => {
      const q = new URLSearchParams();
      if (params) {
        Object.entries(params).forEach(([k, v]) => {
          if (v !== undefined && v !== null && v !== '') q.append(k, String(v));
        });
      }
      const qs = q.toString();
      return this.request<FrontOfficeDashboardStats>(`/front-office/dashboard/stats${qs ? `?${qs}` : ''}`);
    },
    getAnalytics: (params?: { datePreset?: string; startDate?: string; endDate?: string; academicSessionId?: string }) => {
      const q = new URLSearchParams();
      if (params) {
        Object.entries(params).forEach(([k, v]) => {
          if (v !== undefined && v !== null && v !== '') q.append(k, String(v));
        });
      }
      const qs = q.toString();
      return this.request<FrontOfficeAnalyticsData>(`/front-office/dashboard/analytics${qs ? `?${qs}` : ''}`);
    },
    getOverview: () => this.request<any>('/front-office/dashboard/overview'),

    // Enquiries
    getEnquiries: (params?: {
      status?: string;
      classId?: string;
      sessionId?: string;
      source?: string;
      enquiryType?: string;
      assignedStaffId?: string;
      search?: string;
      startDate?: string;
      endDate?: string;
      page?: number;
      limit?: number;
    }) => {
      const q = new URLSearchParams();
      if (params) {
        Object.entries(params).forEach(([k, v]) => {
          if (v !== undefined && v !== null && v !== '') q.append(k, String(v));
        });
      }
      const qs = q.toString();
      return this.request<FrontOfficeEnquiry[]>(`/front-office/enquiries${qs ? `?${qs}` : ''}`);
    },
    getEnquiry: (id: string) => this.request<FrontOfficeEnquiry>(`/front-office/enquiries/${id}`),
    createEnquiry: (data: Partial<FrontOfficeEnquiry>) =>
      this.request<FrontOfficeEnquiry>('/front-office/enquiries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      }),
    updateEnquiry: (id: string, data: Partial<FrontOfficeEnquiry>) =>
      this.request<FrontOfficeEnquiry>(`/front-office/enquiries/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      }),
    deleteEnquiry: (id: string) =>
      this.request<{ message: string }>(`/front-office/enquiries/${id}`, {
        method: 'DELETE'
      }),
    addFollowUp: (enquiryId: string, data: {
      followUpDate?: string;
      followUpTime?: string;
      contactMethod?: string;
      contactOutcome: string;
      notes?: string;
      nextStatus?: string;
      sendReminder?: boolean;
    }) =>
      this.request<{ enquiry: FrontOfficeEnquiry; followUp: EnquiryFollowUp }>(`/front-office/enquiries/${enquiryId}/follow-ups`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      }),
    getFollowUps: (enquiryId: string) =>
      this.request<EnquiryFollowUp[]>(`/front-office/enquiries/${enquiryId}/follow-ups`),
    convertEnquiry: (enquiryId: string) =>
      this.request<{ enquiry: FrontOfficeEnquiry; application: any }>(`/front-office/enquiries/${enquiryId}/convert`, {
        method: 'POST'
      }),
    checkEnquiryDuplicates: (params: {
      phone?: string;
      email?: string;
      studentName?: string;
      parentName?: string;
      excludeId?: string;
    }) => {
      const q = new URLSearchParams();
      if (params.phone) q.append('phone', params.phone);
      if (params.email) q.append('email', params.email);
      if (params.studentName) q.append('studentName', params.studentName);
      if (params.parentName) q.append('parentName', params.parentName);
      if (params.excludeId) q.append('excludeId', params.excludeId);
      return this.request<EnquiryDuplicateCheckResult>(`/front-office/enquiries/check-duplicates?${q.toString()}`);
    },
    getEnquiryMetricsSummary: () =>
      this.request<EnquiryMetricsSummary>('/front-office/enquiries/metrics/summary'),
    getEnquirySources: () =>
      this.request<EnquirySourceConfig[]>('/front-office/enquiry-sources'),
    createEnquirySource: (data: { name: string; code?: string }) =>
      this.request<EnquirySourceConfig>('/front-office/enquiry-sources', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      }),
    updateEnquirySource: (id: string, data: Partial<EnquirySourceConfig>) =>
      this.request<EnquirySourceConfig>(`/front-office/enquiry-sources/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      }),
    updateEnquiryStatus: (id: string, data: { status: string; remarks?: string }) =>
      this.request<FrontOfficeEnquiry>(`/front-office/enquiries/${id}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      }),
    updateEnquiryPriority: (id: string, priority: string) =>
      this.request<FrontOfficeEnquiry>(`/front-office/enquiries/${id}/priority`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ priority })
      }),
    assignEnquiry: (id: string, data: { assignedStaffId: string; notes?: string }) =>
      this.request<FrontOfficeEnquiry>(`/front-office/enquiries/${id}/assign`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      }),
    sendFollowUpReminder: (id: string) =>
      this.request<{ success: boolean; message: string }>(`/front-office/enquiries/${id}/send-reminder`, {
        method: 'POST'
      }),
    exportEnquiriesUrl: (params?: {
      status?: string;
      source?: string;
      priority?: string;
      classId?: string;
      startDate?: string;
      endDate?: string;
      format?: 'csv' | 'json';
    }) => {
      const q = new URLSearchParams();
      if (params) {
        Object.entries(params).forEach(([k, v]) => {
          if (v) q.append(k, String(v));
        });
      }
      return `/api/front-office/enquiries/export?${q.toString()}`;
    },

    // Visitors (Part 13A & Part 13B Advanced Visitor Management)
    getVisitors: (params?: {
      status?: string;
      date?: string;
      dateRange?: string;
      visitorType?: string;
      department?: string;
      personToMeet?: string;
      search?: string;
      entryType?: string;
      page?: number;
      limit?: number;
    }) => {
      const q = new URLSearchParams();
      if (params) {
        Object.entries(params).forEach(([k, v]) => {
          if (v !== undefined && v !== null && v !== '') q.append(k, String(v));
        });
      }
      const qs = q.toString();
      return this.request<VisitorRecord[]>(`/front-office/visitors${qs ? `?${qs}` : ''}`);
    },
    getVisitor: (id: string) => this.request<VisitorRecord>(`/front-office/visitors/${id}`),
    getVisitorHistoryByPhone: (phone: string) =>
      this.request<VisitorRecord[]>(`/front-office/visitors/history/phone/${encodeURIComponent(phone)}`),
    getVisitorHistory: (params?: {
      search?: string;
      visitorType?: string;
      status?: string;
      limit?: number;
    }) => {
      const q = new URLSearchParams();
      if (params) {
        Object.entries(params).forEach(([k, v]) => {
          if (v !== undefined && v !== null && v !== '') q.append(k, String(v));
        });
      }
      q.append('history', 'true');
      const qs = q.toString();
      return this.request<VisitorRecord[]>(`/front-office/visitors${qs ? `?${qs}` : ''}`);
    },
    getTodayOverview: () =>
      this.request<TodaysFrontDeskOverview>('/front-office/visitors/today'),
    createVisitor: (data: Partial<VisitorRecord> & { autoCheckIn?: boolean }) =>
      this.request<VisitorRecord>('/front-office/visitors', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      }),
    updateVisitor: (id: string, data: Partial<VisitorRecord>) =>
      this.request<VisitorRecord>(`/front-office/visitors/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      }),
    confirmVisitor: (id: string) =>
      this.request<VisitorRecord>(`/front-office/visitors/${id}/confirm`, {
        method: 'POST'
      }),
    rejectVisitor: (id: string, reason: string) =>
      this.request<VisitorRecord>(`/front-office/visitors/${id}/reject`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reason })
      }),
    markVisitorNoShow: (id: string) =>
      this.request<VisitorRecord>(`/front-office/visitors/${id}/no-show`, {
        method: 'POST'
      }),
    checkInVisitor: (id: string) =>
      this.request<VisitorRecord>(`/front-office/visitors/${id}/check-in`, {
        method: 'POST'
      }),
    checkOutVisitor: (id: string) =>
      this.request<VisitorRecord>(`/front-office/visitors/${id}/check-out`, {
        method: 'POST'
      }),
    sendVisitorReminder: (id: string) =>
      this.request<{ success: boolean; message: string }>(`/front-office/visitors/${id}/send-reminder`, {
        method: 'POST'
      }),
    verifyVisitorPass: (tokenOrPassNumber: string) =>
      this.request<VisitorPassVerificationResult>('/front-office/visitors/verify-pass', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token: tokenOrPassNumber })
      }),
    getAdvancedVisitorReports: (params?: {
      date?: string;
      startDate?: string;
      endDate?: string;
      department?: string;
      visitorType?: string;
      status?: string;
    }) => {
      const q = new URLSearchParams();
      if (params) {
        Object.entries(params).forEach(([k, v]) => {
          if (v !== undefined && v !== null && v !== '') q.append(k, String(v));
        });
      }
      const qs = q.toString();
      return this.request<any>(`/front-office/visitors/reports/advanced${qs ? `?${qs}` : ''}`);
    },
    cancelVisitor: (id: string, reason?: string) =>
      this.request<VisitorRecord>(`/front-office/visitors/${id}/cancel`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reason })
      }),
    deleteVisitor: (id: string) =>
      this.request<{ message: string }>(`/front-office/visitors/${id}`, {
        method: 'DELETE'
      }),

    // Calls (Part 13D Advanced Phone Call Log Workflow)
    getCalls: (params?: {
      direction?: string;
      status?: string;
      callType?: string;
      department?: string;
      assignedStaffId?: string;
      followUpRequired?: boolean;
      followUpStatus?: string;
      search?: string;
      startDate?: string;
      endDate?: string;
      page?: number;
      limit?: number;
    }) => {
      const q = new URLSearchParams();
      if (params) {
        Object.entries(params).forEach(([k, v]) => {
          if (v !== undefined && v !== null && v !== '') q.append(k, String(v));
        });
      }
      const qs = q.toString();
      return this.request<PhoneCallLogRecord[]>(`/front-office/calls${qs ? `?${qs}` : ''}`);
    },
    getCall: (id: string) => this.request<PhoneCallLogRecord>(`/front-office/calls/${id}`),
    createCall: (data: Partial<PhoneCallLogRecord>) =>
      this.request<PhoneCallLogRecord>('/front-office/calls', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      }),
    updateCall: (id: string, data: Partial<PhoneCallLogRecord>) =>
      this.request<PhoneCallLogRecord>(`/front-office/calls/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      }),
    deleteCall: (id: string) =>
      this.request<{ message: string }>(`/front-office/calls/${id}`, {
        method: 'DELETE'
      }),
    getCallMetricsSummary: () =>
      this.request<CallMetricsSummary>('/front-office/calls/metrics/summary'),
    getCallHistoryByPhone: (phone: string) =>
      this.request<{ calls: PhoneCallLogRecord[]; complaints: ComplaintRecord[] }>(
        `/front-office/calls/history/by-phone?phone=${encodeURIComponent(phone)}`
      ),
    completeCallFollowUp: (id: string, data: { toStatus?: 'COMPLETED' | 'CANCELLED'; followUpOutcome?: string; followUpNotes?: string }) =>
      this.request<PhoneCallLogRecord>(`/front-office/calls/${id}/follow-up`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      }),
    convertCallToComplaint: (id: string, data?: {
      complaintCategory?: string;
      subject?: string;
      description?: string;
      priority?: string;
      assignedDepartment?: string;
      assignedStaffId?: string;
      complainantType?: string;
    }) =>
      this.request<{ complaint: ComplaintRecord; call: PhoneCallLogRecord; message?: string }>(
        `/front-office/calls/${id}/convert-to-complaint`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(data || {})
        }
      ),

    // Complaints (Part 13D Advanced Complaint Management Workflow)
    getComplaints: (params?: {
      status?: string;
      priority?: string;
      category?: string;
      complainantType?: string;
      assignedDepartment?: string;
      assignedStaffId?: string;
      isEscalated?: string | boolean;
      slaStatus?: string;
      search?: string;
      startDate?: string;
      endDate?: string;
      page?: number;
      limit?: number;
    }) => {
      const q = new URLSearchParams();
      if (params) {
        Object.entries(params).forEach(([k, v]) => {
          if (v !== undefined && v !== null && v !== '') q.append(k, String(v));
        });
      }
      const qs = q.toString();
      return this.request<ComplaintRecord[]>(`/front-office/complaints${qs ? `?${qs}` : ''}`);
    },
    getComplaint: (id: string) => this.request<ComplaintRecord>(`/front-office/complaints/${id}`),
    createComplaint: (data: Partial<ComplaintRecord>) =>
      this.request<ComplaintRecord>('/front-office/complaints', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      }),
    updateComplaint: (id: string, data: Partial<ComplaintRecord>) =>
      this.request<ComplaintRecord>(`/front-office/complaints/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      }),
    transitionComplaintStatus: (id: string, data: {
      toStatus: string;
      remarks?: string;
      resolution?: string;
      resolutionCategory?: string;
      remedyActionTaken?: string;
      feedbackRating?: number;
      feedbackRemarks?: string;
      closureNotes?: string;
      reopenReason?: string;
      rejectionReason?: string;
      assignedStaffId?: string;
      assignedDepartment?: string;
    }) =>
      this.request<ComplaintRecord>(`/front-office/complaints/${id}/status`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      }),
    escalateComplaint: (id: string, data: {
      escalationLevel: string;
      escalationReason: string;
      targetDepartment?: string;
      targetStaffId?: string;
      upgradePriority?: boolean;
      bumpPriority?: boolean;
    }) =>
      this.request<ComplaintRecord>(
        `/front-office/complaints/${id}/escalate`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(data)
        }
      ),
    getComplaintMetricsSummary: () =>
      this.request<ComplaintMetricsSummary>('/front-office/complaints/metrics/summary'),
    deleteComplaint: (id: string) =>
      this.request<{ message: string }>(`/front-office/complaints/${id}`, {
        method: 'DELETE'
      }),

    // Global Search
    search: (query: string) =>
      this.request<FrontOfficeGlobalSearchResult>(`/front-office/search?q=${encodeURIComponent(query)}`),

    // Reports & Analytics (Part 13E)
    getReports: (params?: FrontOfficeReportFilter) => {
      const q = new URLSearchParams();
      if (params) {
        Object.entries(params).forEach(([k, v]) => {
          if (v !== undefined && v !== null && v !== '') q.append(k, String(v));
        });
      }
      const qs = q.toString();
      return this.request<FrontOfficeReportResult>(`/front-office/reports${qs ? `?${qs}` : ''}`);
    },
    exportReportsUrl: (params?: FrontOfficeReportFilter & { format?: 'csv' | 'json' }) => {
      const q = new URLSearchParams();
      if (params) {
        Object.entries(params).forEach(([k, v]) => {
          if (v !== undefined && v !== null && v !== '') q.append(k, String(v));
        });
      }
      const qs = q.toString();
      return `/api/front-office/reports/export${qs ? `?${qs}` : ''}`;
    },
    exportReports: (params?: FrontOfficeReportFilter & { format?: 'csv' | 'json' }) =>
      this.request<any>('/front-office/reports/export', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params || {})
      }),

    // Staff
    getStaff: () =>
      this.request<Array<{ id: string; name: string; email: string; role: string; department?: string }>>('/front-office/staff')
  };

  // ============================================================================
  // INVENTORY & ASSET MANAGEMENT (Part 14A)
  // ============================================================================
  readonly inventory = {
    // Dashboard & Global Search
    getDashboardStats: () =>
      this.request<InventoryDashboardStats>('/inventory/dashboard'),

    getComprehensiveAnalytics: (params?: import('../types/index.js').InventoryAnalyticsFilters) => {
      const q = new URLSearchParams();
      if (params) {
        Object.entries(params).forEach(([k, v]) => {
          if (v !== undefined && v !== null && v !== '') q.append(k, String(v));
        });
      }
      const qs = q.toString();
      return this.request<{
        success: boolean;
        data: import('../types/index.js').ComprehensiveInventoryAnalytics;
      }>(`/inventory/analytics/comprehensive${qs ? `?${qs}` : ''}`);
    },

    getReconciliationAudit: () =>
      this.request<{
        success: boolean;
        data: import('../types/index.js').ReconciliationAudit;
      }>('/inventory/analytics/reconciliation'),

    globalSearch: (query: string) =>
      this.request<{
        items: InventoryItem[];
        assets: Asset[];
        suppliers: Supplier[];
        locations: InventoryLocation[];
        purchaseOrders?: import('../types/index.js').PurchaseOrder[];
        issueRequests?: import('../types/index.js').IssueRequest[];
        stockIssues?: import('../types/index.js').StockIssue[];
      }>(`/inventory/global-search?q=${encodeURIComponent(query)}`),

    // Inventory Items
    getItems: (params?: InventoryFilterParams) => {
      const q = new URLSearchParams();
      if (params) {
        Object.entries(params).forEach(([k, v]) => {
          if (v !== undefined && v !== null && v !== '') q.append(k, String(v));
        });
      }
      const qs = q.toString();
      return this.request<InventoryItem[]>(`/inventory/items${qs ? `?${qs}` : ''}`);
    },

    getItemById: (id: string) =>
      this.request<InventoryItem>(`/inventory/items/${id}`),

    createItem: (payload: CreateInventoryItemPayload) =>
      this.request<InventoryItem>('/inventory/items', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    updateItem: (id: string, payload: UpdateInventoryItemPayload) =>
      this.request<InventoryItem>(`/inventory/items/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    updateItemStatus: (id: string, status: 'ACTIVE' | 'INACTIVE' | 'DISCONTINUED') =>
      this.request<InventoryItem>(`/inventory/items/${id}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status })
      }),

    deleteItem: (id: string) =>
      this.request<{ message: string }>(`/inventory/items/${id}`, {
        method: 'DELETE'
      }),

    // Categories
    getCategories: (params?: { search?: string; status?: string }) => {
      const q = new URLSearchParams();
      if (params?.search) q.append('search', params.search);
      if (params?.status) q.append('status', params.status);
      const qs = q.toString();
      return this.request<InventoryCategory[]>(`/inventory/categories${qs ? `?${qs}` : ''}`);
    },

    createCategory: (payload: CreateInventoryCategoryPayload) =>
      this.request<InventoryCategory>('/inventory/categories', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    updateCategory: (id: string, payload: Partial<CreateInventoryCategoryPayload>) =>
      this.request<InventoryCategory>(`/inventory/categories/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    deleteCategory: (id: string) =>
      this.request<{ message: string }>(`/inventory/categories/${id}`, {
        method: 'DELETE'
      }),

    // Units
    getUnits: (params?: { search?: string; status?: string }) => {
      const q = new URLSearchParams();
      if (params?.search) q.append('search', params.search);
      if (params?.status) q.append('status', params.status);
      const qs = q.toString();
      return this.request<InventoryUnit[]>(`/inventory/units${qs ? `?${qs}` : ''}`);
    },

    createUnit: (payload: CreateInventoryUnitPayload) =>
      this.request<InventoryUnit>('/inventory/units', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    updateUnit: (id: string, payload: Partial<CreateInventoryUnitPayload>) =>
      this.request<InventoryUnit>(`/inventory/units/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    deleteUnit: (id: string) =>
      this.request<{ message: string }>(`/inventory/units/${id}`, {
        method: 'DELETE'
      }),

    // Locations
    getLocations: (params?: { search?: string; status?: string; department?: string }) => {
      const q = new URLSearchParams();
      if (params?.search) q.append('search', params.search);
      if (params?.status) q.append('status', params.status);
      if (params?.department) q.append('department', params.department);
      const qs = q.toString();
      return this.request<InventoryLocation[]>(`/inventory/locations${qs ? `?${qs}` : ''}`);
    },

    createLocation: (payload: CreateInventoryLocationPayload) =>
      this.request<InventoryLocation>('/inventory/locations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    updateLocation: (id: string, payload: Partial<CreateInventoryLocationPayload>) =>
      this.request<InventoryLocation>(`/inventory/locations/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    deleteLocation: (id: string) =>
      this.request<{ message: string }>(`/inventory/locations/${id}`, {
        method: 'DELETE'
      }),

    // Suppliers
    getSuppliers: (params?: { search?: string; status?: string; page?: number; limit?: number }) => {
      const q = new URLSearchParams();
      if (params?.search) q.append('search', params.search);
      if (params?.status) q.append('status', params.status);
      if (params?.page) q.append('page', String(params.page));
      if (params?.limit) q.append('limit', String(params.limit));
      const qs = q.toString();
      return this.request<Supplier[]>(`/inventory/suppliers${qs ? `?${qs}` : ''}`);
    },

    getSupplierById: (id: string) =>
      this.request<Supplier & { assets: Asset[] }>(`/inventory/suppliers/${id}`),

    createSupplier: (payload: CreateSupplierPayload) =>
      this.request<Supplier>('/inventory/suppliers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    updateSupplier: (id: string, payload: UpdateSupplierPayload) =>
      this.request<Supplier>(`/inventory/suppliers/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    deleteSupplier: (id: string) =>
      this.request<{ message: string }>(`/inventory/suppliers/${id}`, {
        method: 'DELETE'
      }),

    // Asset Categories
    getAssetCategories: () =>
      this.request<AssetCategory[]>('/inventory/assets/categories'),

    createAssetCategory: (payload: CreateAssetCategoryPayload) =>
      this.request<AssetCategory>('/inventory/assets/categories', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    // Assets
    getAssets: (params?: AssetFilterParams) => {
      const q = new URLSearchParams();
      if (params) {
        Object.entries(params).forEach(([k, v]) => {
          if (v !== undefined && v !== null && v !== '') q.append(k, String(v));
        });
      }
      const qs = q.toString();
      return this.request<Asset[]>(`/inventory/assets${qs ? `?${qs}` : ''}`);
    },

    getAssetById: (id: string) =>
      this.request<Asset>(`/inventory/assets/${id}`),

    createAsset: (payload: CreateAssetPayload) =>
      this.request<Asset>('/inventory/assets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    updateAsset: (id: string, payload: UpdateAssetPayload) =>
      this.request<Asset>(`/inventory/assets/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    updateAssetStatus: (id: string, status: string, remarks?: string) =>
      this.request<Asset>(`/inventory/assets/${id}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status, remarks })
      }),

    attachAssetDocument: (id: string, payload: { title: string; fileName: string; fileUrl?: string; fileType?: string; fileSize?: string; documentType?: string }) =>
      this.request<{ message: string; asset: Asset; document: AssetDocument }>(`/inventory/assets/${id}/documents`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    deleteAssetDocument: (assetId: string, docId: string) =>
      this.request<{ message: string }>(`/inventory/assets/${assetId}/documents/${docId}`, {
        method: 'DELETE'
      }),

    deleteAsset: (id: string) =>
      this.request<{ message: string }>(`/inventory/assets/${id}`, {
        method: 'DELETE'
      }),

    // ==========================================
    // PART 14C: ASSET LIFECYCLE ENDPOINTS
    // ==========================================

    getAssetLifecycleSummary: () =>
      this.request<any>('/inventory/assets/summary'),

    getAssetByTag: (tag: string) =>
      this.request<Asset>(`/inventory/assets/tag/${encodeURIComponent(tag)}`),

    assignAsset: (id: string, payload: AssignAssetPayload) =>
      this.request<{ asset: Asset; assignment: AssetAssignment; message: string }>(
        `/inventory/assets/${id}/assign`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }
      ),

    returnAsset: (id: string, payload: ReturnAssetPayload) =>
      this.request<{ asset: Asset; returnRecord: AssetReturn; message: string }>(
        `/inventory/assets/${id}/return`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        }
      ),

    transferAsset: (id: string, payload: TransferAssetPayload) =>
      this.request<{
        asset: Asset;
        transferRecord: AssetTransfer;
        newAssignment: AssetAssignment;
        message: string;
      }>(`/inventory/assets/${id}/transfer`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    sendAssetForRepair: (id: string, payload: SendForRepairPayload) =>
      this.request<{ asset: Asset; message: string }>(`/inventory/assets/${id}/send-repair`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    completeAssetRepair: (id: string, payload: CompleteRepairPayload) =>
      this.request<{ asset: Asset; message: string }>(`/inventory/assets/${id}/complete-repair`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    markAssetDamaged: (id: string, payload: MarkDamagedPayload) =>
      this.request<{ asset: Asset; message: string }>(`/inventory/assets/${id}/mark-damaged`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    markAssetLost: (id: string, payload: MarkLostPayload) =>
      this.request<{ asset: Asset; message: string }>(`/inventory/assets/${id}/mark-lost`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    recoverAsset: (id: string, payload: MarkRecoveredPayload) =>
      this.request<{ asset: Asset; message: string }>(`/inventory/assets/${id}/recover`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    retireAsset: (id: string, payload: RetireAssetPayload) =>
      this.request<{ asset: Asset; message: string }>(`/inventory/assets/${id}/retire`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    disposeAsset: (id: string, payload: DisposeAssetPayload) =>
      this.request<{ asset: Asset; message: string }>(`/inventory/assets/${id}/dispose`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    getAssetTimeline: (id: string) =>
      this.request<AssetTimelineEvent[]>(`/inventory/assets/${id}/timeline`),

    getAssetAssignments: (id: string) =>
      this.request<AssetAssignment[]>(`/inventory/assets/${id}/assignments`),

    // ==========================================
    // PART 14B: STOCK MANAGEMENT ENDPOINTS
    // ==========================================

    getStockSummary: () =>
      this.request<StockSummary>('/inventory/stock/summary'),

    getStockBalances: (params?: StockBalanceFilterParams) => {
      const q = new URLSearchParams();
      if (params) {
        Object.entries(params).forEach(([k, v]) => {
          if (v !== undefined && v !== null && v !== '') q.append(k, String(v));
        });
      }
      const qs = q.toString();
      return this.request<{ data: ItemStockBalance[]; pagination: { total: number; page: number; limit: number; pages: number } }>(
        `/inventory/stock${qs ? `?${qs}` : ''}`
      );
    },

    getItemStockDetail: (itemId: string) =>
      this.request<{
        item: InventoryItem;
        totalQuantity: number;
        locationBalances: ItemStockBalance[];
        recentMovements: StockMovement[];
      }>(`/inventory/stock/items/${itemId}`),

    recordOpeningStock: (payload: OpeningStockPayload) =>
      this.request<{
        balance: ItemStockBalance;
        transaction: StockTransaction;
        movement: StockMovement;
      }>('/inventory/stock/opening', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    recordStockIn: (payload: StockInPayload) =>
      this.request<{
        balance: ItemStockBalance;
        transaction: StockTransaction;
        movement: StockMovement;
      }>('/inventory/stock/in', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    recordStockOut: (payload: StockOutPayload) =>
      this.request<{
        balance: ItemStockBalance;
        transaction: StockTransaction;
        movement: StockMovement;
      }>('/inventory/stock/out', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    recordStockTransfer: (payload: StockTransferPayload) =>
      this.request<{
        sourceBalance: ItemStockBalance;
        destBalance: ItemStockBalance;
        transaction: StockTransaction;
        sourceMovement: StockMovement;
        destMovement: StockMovement;
      }>('/inventory/stock/transfer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    recordStockReturn: (payload: StockReturnPayload) =>
      this.request<{
        balance: ItemStockBalance;
        transaction: StockTransaction;
        movement: StockMovement;
      }>('/inventory/stock/return', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    recordStockAdjustment: (payload: StockAdjustmentPayload) =>
      this.request<{
        balance: ItemStockBalance;
        transaction: StockTransaction;
        movement: StockMovement;
      }>('/inventory/stock/adjust', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    getStockLedger: (params?: StockMovementFilterParams) => {
      const q = new URLSearchParams();
      if (params) {
        Object.entries(params).forEach(([k, v]) => {
          if (v !== undefined && v !== null && v !== '') q.append(k, String(v));
        });
      }
      const qs = q.toString();
      return this.request<{ data: StockMovement[]; pagination: { total: number; page: number; limit: number; pages: number } }>(
        `/inventory/stock/ledger${qs ? `?${qs}` : ''}`
      );
    },

    getStockTransactions: (params?: StockTransactionFilterParams) => {
      const q = new URLSearchParams();
      if (params) {
        Object.entries(params).forEach(([k, v]) => {
          if (v !== undefined && v !== null && v !== '') q.append(k, String(v));
        });
      }
      const qs = q.toString();
      return this.request<{ data: StockTransaction[]; pagination: { total: number; page: number; limit: number; pages: number } }>(
        `/inventory/stock/transactions${qs ? `?${qs}` : ''}`
      );
    },

    getStockTransactionById: (id: string) =>
      this.request<{ transaction: StockTransaction; movements: StockMovement[] }>(
        `/inventory/stock/transactions/${id}`
      ),

    // ==========================================
    // PART 14D: PROCUREMENT & PURCHASE WORKFLOW
    // ==========================================

    getProcurementDashboard: () =>
      this.request<import('../types/index.js').ProcurementDashboardSummary>(
        '/inventory/procurement/dashboard'
      ),

    getPurchaseRequests: (params?: {
      status?: string;
      priority?: string;
      department?: string;
      search?: string;
      page?: number;
      limit?: number;
    }) => {
      const q = new URLSearchParams();
      if (params) {
        Object.entries(params).forEach(([k, v]) => {
          if (v !== undefined && v !== null && v !== '') q.append(k, String(v));
        });
      }
      const qs = q.toString();
      return this.request<{
        data: import('../types/index.js').PurchaseRequest[];
        pagination: { total: number; page: number; limit: number; totalPages: number };
      }>(`/inventory/procurement/requests${qs ? `?${qs}` : ''}`);
    },

    getPurchaseRequestById: (id: string) =>
      this.request<import('../types/index.js').PurchaseRequest>(
        `/inventory/procurement/requests/${id}`
      ),

    createPurchaseRequest: (payload: import('../types/index.js').CreatePurchaseRequestPayload) =>
      this.request<{
        data: import('../types/index.js').PurchaseRequest;
        message: string;
      }>('/inventory/procurement/requests', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    updatePurchaseRequest: (id: string, payload: import('../types/index.js').UpdatePurchaseRequestPayload) =>
      this.request<{
        data: import('../types/index.js').PurchaseRequest;
        message: string;
      }>(`/inventory/procurement/requests/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    reviewPurchaseRequest: (id: string, payload: import('../types/index.js').ReviewPurchaseRequestPayload) =>
      this.request<{
        data: import('../types/index.js').PurchaseRequest;
        message: string;
      }>(`/inventory/procurement/requests/${id}/review`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    cancelPurchaseRequest: (id: string, reason?: string) =>
      this.request<{
        data: import('../types/index.js').PurchaseRequest;
        message: string;
      }>(`/inventory/procurement/requests/${id}/cancel`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reason })
      }),

    convertRequestToPO: (id: string, payload: import('../types/index.js').ConvertRequestToPOPayload) =>
      this.request<import('../types/index.js').PurchaseOrder>(`/inventory/procurement/requests/${id}/convert-to-po`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    getPurchaseOrders: (params?: {
      status?: string;
      supplierId?: string;
      search?: string;
      page?: number;
      limit?: number;
    }) => {
      const q = new URLSearchParams();
      if (params) {
        Object.entries(params).forEach(([k, v]) => {
          if (v !== undefined && v !== null && v !== '') q.append(k, String(v));
        });
      }
      const qs = q.toString();
      return this.request<{
        data: import('../types/index.js').PurchaseOrder[];
        pagination: { total: number; page: number; limit: number; totalPages: number };
      }>(`/inventory/procurement/orders${qs ? `?${qs}` : ''}`);
    },

    getPurchaseOrderById: (id: string) =>
      this.request<import('../types/index.js').PurchaseOrder>(
        `/inventory/procurement/orders/${id}`
      ),

    createPurchaseOrder: (payload: import('../types/index.js').CreatePurchaseOrderPayload) =>
      this.request<{
        data: import('../types/index.js').PurchaseOrder;
        message: string;
      }>('/inventory/procurement/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    reviewPurchaseOrder: (id: string, payload: import('../types/index.js').ReviewPurchaseOrderPayload) =>
      this.request<{
        data: import('../types/index.js').PurchaseOrder;
        message: string;
      }>(`/inventory/procurement/orders/${id}/review`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    markPurchaseOrderSent: (id: string) =>
      this.request<{
        data: import('../types/index.js').PurchaseOrder;
        message: string;
      }>(`/inventory/procurement/orders/${id}/send`, {
        method: 'POST'
      }),

    cancelPurchaseOrder: (id: string, reason?: string) =>
      this.request<{
        data: import('../types/index.js').PurchaseOrder;
        message: string;
      }>(`/inventory/procurement/orders/${id}/cancel`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reason })
      }),

    getGoodsReceipts: (params?: {
      purchaseOrderId?: string;
      supplierId?: string;
      search?: string;
      page?: number;
      limit?: number;
    }) => {
      const q = new URLSearchParams();
      if (params) {
        Object.entries(params).forEach(([k, v]) => {
          if (v !== undefined && v !== null && v !== '') q.append(k, String(v));
        });
      }
      const qs = q.toString();
      return this.request<{
        data: import('../types/index.js').GoodsReceipt[];
        pagination: { total: number; page: number; limit: number; totalPages: number };
      }>(`/inventory/procurement/receiving${qs ? `?${qs}` : ''}`);
    },

    getGoodsReceiptById: (id: string) =>
      this.request<import('../types/index.js').GoodsReceipt>(
        `/inventory/procurement/receiving/${id}`
      ),

    receiveGoods: (poId: string, payload: import('../types/index.js').ReceiveGoodsPayload) =>
      this.request<{
        data: {
          goodsReceipt: import('../types/index.js').GoodsReceipt;
          purchaseOrder: import('../types/index.js').PurchaseOrder;
        };
        message: string;
      }>(`/inventory/procurement/orders/${poId}/receive`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    createAssetFromReceipt: (payload: import('../types/index.js').CreateAssetFromReceiptPayload) =>
      this.request<{
        data: import('../types/index.js').Asset;
        message: string;
      }>('/inventory/procurement/receiving/create-asset', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    getSupplierProcurementHistory: (supplierId: string) =>
      this.request<{
        supplier: import('../types/index.js').Supplier;
        metrics: {
          totalOrders: number;
          openOrders: number;
          completedOrders: number;
          partiallyReceivedOrders: number;
          totalOrderedQty: number;
          totalReceivedQty: number;
          fulfillmentRatePercentage: number;
          totalOrderValue: number;
        };
        recentPurchaseOrders: import('../types/index.js').PurchaseOrder[];
        recentGoodsReceipts: import('../types/index.js').GoodsReceipt[];
      }>(`/inventory/procurement/suppliers/${supplierId}/history`),

    // ==========================================
    // PART 14E: ISSUE, RETURN & ALLOCATION
    // ==========================================
    getIssueKPIs: () =>
      this.request<import('../types/index.js').IssueAllocationDashboardKPIs>('/inventory/issues/kpis'),

    getIssueRequests: (params?: {
      search?: string;
      status?: string;
      priority?: string;
      departmentId?: string;
      locationId?: string;
      requestedBy?: string;
      page?: number;
      limit?: number;
    }) => {
      const q = new URLSearchParams();
      if (params?.search) q.append('search', params.search);
      if (params?.status) q.append('status', params.status);
      if (params?.priority) q.append('priority', params.priority);
      if (params?.departmentId) q.append('departmentId', params.departmentId);
      if (params?.locationId) q.append('locationId', params.locationId);
      if (params?.requestedBy) q.append('requestedBy', params.requestedBy);
      if (params?.page) q.append('page', String(params.page));
      if (params?.limit) q.append('limit', String(params.limit));
      const qs = q.toString();
      return this.request<{
        data: import('../types/index.js').IssueRequest[];
        pagination: { total: number; page: number; limit: number; pages: number };
      }>(`/inventory/issues/requests${qs ? `?${qs}` : ''}`);
    },

    getIssueRequest: (id: string) =>
      this.request<import('../types/index.js').IssueRequest>(`/inventory/issues/requests/${id}`),

    createIssueRequest: (payload: import('../types/index.js').CreateIssueRequestPayload) =>
      this.request<{ success: boolean; data: import('../types/index.js').IssueRequest; message: string }>(
        '/inventory/issues/requests',
        {
          method: 'POST',
          body: JSON.stringify(payload)
        }
      ),

    reviewIssueRequest: (id: string, payload: import('../types/index.js').ReviewIssueRequestPayload) =>
      this.request<{ success: boolean; data: import('../types/index.js').IssueRequest; message: string }>(
        `/inventory/issues/requests/${id}/review`,
        {
          method: 'POST',
          body: JSON.stringify(payload)
        }
      ),

    getStockIssues: (params?: {
      search?: string;
      status?: string;
      departmentId?: string;
      locationId?: string;
      recipientId?: string;
      page?: number;
      limit?: number;
    }) => {
      const q = new URLSearchParams();
      if (params?.search) q.append('search', params.search);
      if (params?.status) q.append('status', params.status);
      if (params?.departmentId) q.append('departmentId', params.departmentId);
      if (params?.locationId) q.append('locationId', params.locationId);
      if (params?.recipientId) q.append('recipientId', params.recipientId);
      if (params?.page) q.append('page', String(params.page));
      if (params?.limit) q.append('limit', String(params.limit));
      const qs = q.toString();
      return this.request<{
        data: import('../types/index.js').StockIssue[];
        pagination: { total: number; page: number; limit: number; pages: number };
      }>(`/inventory/issues/dispatches${qs ? `?${qs}` : ''}`);
    },

    getStockIssue: (id: string) =>
      this.request<import('../types/index.js').StockIssue>(`/inventory/issues/dispatches/${id}`),

    executeStockIssue: (payload: import('../types/index.js').ExecuteStockIssuePayload) =>
      this.request<{
        success: boolean;
        data: import('../types/index.js').StockIssue;
        issueRequest?: import('../types/index.js').IssueRequest;
        message: string;
      }>('/inventory/issues/dispatches', {
        method: 'POST',
        body: JSON.stringify(payload)
      }),

    getInventoryReturns: (params?: {
      search?: string;
      issueId?: string;
      locationId?: string;
      page?: number;
      limit?: number;
    }) => {
      const q = new URLSearchParams();
      if (params?.search) q.append('search', params.search);
      if (params?.issueId) q.append('issueId', params.issueId);
      if (params?.locationId) q.append('locationId', params.locationId);
      if (params?.page) q.append('page', String(params.page));
      if (params?.limit) q.append('limit', String(params.limit));
      const qs = q.toString();
      return this.request<{
        data: import('../types/index.js').InventoryReturn[];
        pagination: { total: number; page: number; limit: number; pages: number };
      }>(`/inventory/returns${qs ? `?${qs}` : ''}`);
    },

    recordInventoryReturn: (payload: import('../types/index.js').RecordInventoryReturnPayload) =>
      this.request<{
        success: boolean;
        data: import('../types/index.js').InventoryReturn;
        stockIssue: import('../types/index.js').StockIssue;
        message: string;
      }>('/inventory/returns', {
        method: 'POST',
        body: JSON.stringify(payload)
      }),

    bulkAllocateAssets: (payload: import('../types/index.js').BulkAssetAllocationPayload) =>
      this.request<{
        successfulCount: number;
        results: Array<{ assetId: string; assetTag: string; success: boolean; error?: string }>;
      }>('/inventory/allocations/bulk', {
        method: 'POST',
        body: JSON.stringify(payload)
      }),

    getDepartmentAllocations: (departmentId?: string) => {
      const qs = departmentId && departmentId !== 'ALL' ? `?departmentId=${departmentId}` : '';
      return this.request<import('../types/index.js').DepartmentAllocationSummary[]>(
        `/inventory/departments${qs}`
      );
    },

    getDepartmentAllocation: (id: string) =>
      this.request<import('../types/index.js').DepartmentAllocationSummary>(`/inventory/departments/${id}`)
  };

  // Part 15A — Certificate & Document Management Foundation
  documents = {
    getMetrics: () =>
      this.request<import('../types/index.js').DocumentDashboardMetrics>('/documents/metrics'),

    getTypes: (params?: { entityType?: string; isActive?: boolean }) => {
      const q = new URLSearchParams();
      if (params?.entityType && params.entityType !== 'ALL') q.append('entityType', params.entityType);
      if (typeof params?.isActive === 'boolean') q.append('isActive', String(params.isActive));
      const qs = q.toString();
      return this.request<import('../types/index.js').DocumentTypeConfig[]>(`/documents/types${qs ? `?${qs}` : ''}`);
    },

    createType: (payload: import('../types/index.js').CreateDocumentTypePayload) =>
      this.request<import('../types/index.js').DocumentTypeConfig>('/documents/types', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    updateType: (id: string, payload: import('../types/index.js').UpdateDocumentTypePayload) =>
      this.request<import('../types/index.js').DocumentTypeConfig>(`/documents/types/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    getDocuments: (params?: import('../types/index.js').DocumentFilterParams) => {
      const q = new URLSearchParams();
      if (params) {
        Object.entries(params).forEach(([k, v]) => {
          if (v !== undefined && v !== null && v !== '') q.append(k, String(v));
        });
      }
      const qs = q.toString();
      return this.request<{
        data: import('../types/index.js').ManagedDocument[];
        pagination: { total: number; page: number; limit: number; totalPages: number };
      }>(`/documents${qs ? `?${qs}` : ''}`);
    },

    getDocumentById: (id: string) =>
      this.request<import('../types/index.js').ManagedDocument>(`/documents/${id}`),

    uploadDocument: (payload: import('../types/index.js').CreateDocumentPayload) =>
      this.request<import('../types/index.js').ManagedDocument>('/documents', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    createDocument: (payload: import('../types/index.js').CreateDocumentPayload) =>
      this.request<import('../types/index.js').ManagedDocument>('/documents', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    uploadNewVersion: (id: string, payload: import('../types/index.js').UploadDocumentVersionPayload) =>
      this.request<import('../types/index.js').ManagedDocument>(`/documents/${id}/version`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    verifyDocument: (id: string, payload: import('../types/index.js').VerifyDocumentPayload) =>
      this.request<import('../types/index.js').ManagedDocument>(`/documents/${id}/verify`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    updateMetadata: (id: string, payload: import('../types/index.js').UpdateDocumentMetadataPayload) =>
      this.request<import('../types/index.js').ManagedDocument>(`/documents/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    archiveDocument: (id: string) =>
      this.request<import('../types/index.js').ManagedDocument>(`/documents/${id}`, {
        method: 'DELETE'
      }),

    deleteDocument: (id: string) =>
      this.request<{ message: string }>(`/documents/${id}?permanent=true`, {
        method: 'DELETE'
      }),

    getCertificateTemplates: (params?: { entityType?: string; status?: string }) => {
      const q = new URLSearchParams();
      if (params?.entityType && params.entityType !== 'ALL') q.append('entityType', params.entityType);
      if (params?.status && params.status !== 'ALL') q.append('status', params.status);
      const qs = q.toString();
      return this.request<import('../types/index.js').CertificateTemplate[]>(
        `/documents/certificate-templates${qs ? `?${qs}` : ''}`
      );
    },

    getCertificateTemplateById: (id: string) =>
      this.request<import('../types/index.js').CertificateTemplate>(`/documents/certificate-templates/${id}`),

    createCertificateTemplate: (payload: import('../types/index.js').CreateCertificateTemplatePayload) =>
      this.request<import('../types/index.js').CertificateTemplate>('/documents/certificate-templates', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    updateCertificateTemplate: (id: string, payload: import('../types/index.js').UpdateCertificateTemplatePayload) =>
      this.request<import('../types/index.js').CertificateTemplate>(`/documents/certificate-templates/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    // Part 15E — Requirements, Checklist & Expiring Documents
    getRequirements: (params?: { entityType?: string; isActive?: boolean }) => {
      const q = new URLSearchParams();
      if (params?.entityType && params.entityType !== 'ALL') q.append('entityType', params.entityType);
      if (typeof params?.isActive === 'boolean') q.append('isActive', String(params.isActive));
      const qs = q.toString();
      return this.request<import('../types/index.js').DocumentRequirementConfig[]>(
        `/documents/requirements${qs ? `?${qs}` : ''}`
      );
    },

    createRequirement: (payload: import('../types/index.js').CreateDocumentRequirementPayload) =>
      this.request<import('../types/index.js').DocumentRequirementConfig>('/documents/requirements', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    updateRequirement: (id: string, payload: import('../types/index.js').UpdateDocumentRequirementPayload) =>
      this.request<import('../types/index.js').DocumentRequirementConfig>(`/documents/requirements/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    deleteRequirement: (id: string) =>
      this.request<{ message: string }>(`/documents/requirements/${id}`, {
        method: 'DELETE'
      }),

    getChecklist: (entityType: string, entityId: string) =>
      this.request<import('../types/index.js').EntityDocumentChecklistSummary>(
        `/documents/checklist/${entityType}/${entityId}`
      ),

    getExpiringDocuments: (params?: { entityType?: string; daysThreshold?: number; isExpired?: boolean }) => {
      const q = new URLSearchParams();
      if (params?.entityType && params.entityType !== 'ALL') q.append('entityType', params.entityType);
      if (params?.daysThreshold) q.append('daysThreshold', String(params.daysThreshold));
      if (typeof params?.isExpired === 'boolean') q.append('isExpired', String(params.isExpired));
      const qs = q.toString();
      return this.request<import('../types/index.js').ExpiringDocumentItem[]>(
        `/documents/expiring${qs ? `?${qs}` : ''}`
      );
    }
  };

  // ==============================================================
  // PART 15C — CERTIFICATE GENERATION & ISSUANCE API
  // ==============================================================
  certificates = {
    getMetrics: () =>
      this.request<import('../types/index.js').CertificateStatsMetrics>('/certificates/metrics'),

    getTypes: (params?: { entityType?: string; isActive?: boolean }) => {
      const q = new URLSearchParams();
      if (params?.entityType && params.entityType !== 'ALL') q.append('entityType', params.entityType);
      if (params?.isActive !== undefined) q.append('isActive', String(params.isActive));
      const qs = q.toString();
      return this.request<import('../types/index.js').CertificateTypeConfig[]>(
        `/certificates/types${qs ? `?${qs}` : ''}`
      );
    },

    getTypeById: (id: string) =>
      this.request<import('../types/index.js').CertificateTypeConfig>(`/certificates/types/${id}`),

    createType: (payload: import('../types/index.js').CreateCertificateTypePayload) =>
      this.request<import('../types/index.js').CertificateTypeConfig>('/certificates/types', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    updateType: (id: string, payload: import('../types/index.js').UpdateCertificateTypePayload) =>
      this.request<import('../types/index.js').CertificateTypeConfig>(`/certificates/types/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    preview: (payload: import('../types/index.js').PreviewCertificatePayload) =>
      this.request<{
        template: import('../types/index.js').CertificateTemplate;
        type: import('../types/index.js').CertificateTypeConfig;
        snapshot: import('../types/index.js').CertificateDataSnapshot;
        renderedTitle: string;
        renderedSubtitle: string;
        renderedBody: string;
        renderedFooter: string;
        previewCertificateNumber: string;
        issueDate: string;
      }>('/certificates/preview', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    generate: (payload: import('../types/index.js').GenerateCertificatePayload) =>
      this.request<import('../types/index.js').IssuedCertificate>('/certificates/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    issue: (id: string, payload?: import('../types/index.js').IssueCertificatePayload) =>
      this.request<import('../types/index.js').IssuedCertificate>(`/certificates/${id}/issue`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload || {})
      }),

    reissue: (id: string, payload: import('../types/index.js').ReissueCertificatePayload) =>
      this.request<import('../types/index.js').IssuedCertificate>(`/certificates/${id}/reissue`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    cancel: (id: string, reason: string) =>
      this.request<import('../types/index.js').IssuedCertificate>(`/certificates/${id}/cancel`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reason })
      }),

    revoke: (id: string, reason: string) =>
      this.request<import('../types/index.js').IssuedCertificate>(`/certificates/${id}/revoke`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reason })
      }),

    submitForVerification: (id: string, notes?: string) =>
      this.request<import('../types/index.js').IssuedCertificate>(`/certificates/${id}/submit-verification`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ notes })
      }),

    verify: (id: string, payload: import('../types/index.js').VerifyCertificatePayload) =>
      this.request<import('../types/index.js').IssuedCertificate>(`/certificates/${id}/verify`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    submitForApproval: (id: string) =>
      this.request<import('../types/index.js').IssuedCertificate>(`/certificates/${id}/submit-approval`, {
        method: 'POST'
      }),

    approve: (id: string, payload: import('../types/index.js').ApproveCertificatePayload) =>
      this.request<import('../types/index.js').IssuedCertificate>(`/certificates/${id}/approve`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }),

    getWorkflowHistory: (id: string) =>
      this.request<import('../types/index.js').CertificateWorkflowEvent[]>(`/certificates/${id}/workflow-history`),

    publicVerify: (reference: string) =>
      this.request<import('../types/index.js').PublicCertificateVerificationResult>(
        `/certificates/public/verify/${encodeURIComponent(reference)}`
      ),

    getCertificates: (params?: import('../types/index.js').CertificateFilterParams) => {
      const q = new URLSearchParams();
      if (params?.search) q.append('search', params.search);
      if (params?.certificateTypeId) q.append('certificateTypeId', params.certificateTypeId);
      if (params?.studentId) q.append('studentId', params.studentId);
      if (params?.academicSessionId) q.append('academicSessionId', params.academicSessionId);
      if (params?.status && params.status !== 'ALL') q.append('status', params.status);
      if (params?.verificationStatus && params.verificationStatus !== 'ALL') q.append('verificationStatus', params.verificationStatus);
      if (params?.approvalStatus && params.approvalStatus !== 'ALL') q.append('approvalStatus', params.approvalStatus);
      if (params?.startDate) q.append('startDate', params.startDate);
      if (params?.endDate) q.append('endDate', params.endDate);
      if (params?.page) q.append('page', String(params.page));
      if (params?.limit) q.append('limit', String(params.limit));
      if (params?.sortBy) q.append('sortBy', params.sortBy);
      if (params?.sortOrder) q.append('sortOrder', params.sortOrder);
      const qs = q.toString();
      return this.request<{
        items: import('../types/index.js').IssuedCertificate[];
        total: number;
        page: number;
        limit: number;
        totalPages: number;
      }>(`/certificates${qs ? `?${qs}` : ''}`);
    },

    getCertificateById: (id: string) =>
      this.request<import('../types/index.js').IssuedCertificate>(`/certificates/${id}`),

    downloadCertificate: (id: string) =>
      this.request<{
        id: string;
        certificateNumber: string;
        digitalVerificationReference?: string;
        studentName: string;
        fileName: string;
        fileUrl: string;
        issueDate: string;
        version: number;
      }>(`/certificates/${id}/download`),

    getMyCertificates: () =>
      this.request<import('../types/index.js').IssuedCertificate[]>('/certificates/my-certificates'),

    getGuardianCertificates: () =>
      this.request<import('../types/index.js').IssuedCertificate[]>('/certificates/guardian-certificates')
  };

  // ==============================================================
  // PART 15F — DOCUMENT & CERTIFICATE REPORTS, ANALYTICS & COMPLIANCE
  // ==============================================================
  documentReports = {
    getDocumentAnalytics: (params?: { preset?: string; startDate?: string; endDate?: string }) => {
      const q = new URLSearchParams();
      if (params?.preset) q.append('preset', params.preset);
      if (params?.startDate) q.append('startDate', params.startDate);
      if (params?.endDate) q.append('endDate', params.endDate);
      const qs = q.toString();
      return this.request<import('../types/index.js').DocumentAnalyticsDashboardData>(
        `/document-reports/analytics${qs ? `?${qs}` : ''}`
      );
    },

    getDocumentCompliance: (params?: import('../types/index.js').DocumentComplianceReportFilterParams) => {
      const q = new URLSearchParams();
      if (params?.entityType && params.entityType !== 'ALL') q.append('entityType', params.entityType);
      if (params?.academicSessionId) q.append('academicSessionId', params.academicSessionId);
      if (params?.classId) q.append('classId', params.classId);
      if (params?.department) q.append('department', params.department);
      if (params?.complianceStatus && params.complianceStatus !== 'ALL') q.append('complianceStatus', params.complianceStatus);
      if (params?.search) q.append('search', params.search);
      if (params?.page) q.append('page', String(params.page));
      if (params?.limit) q.append('limit', String(params.limit));
      if (params?.sortBy) q.append('sortBy', params.sortBy);
      if (params?.sortOrder) q.append('sortOrder', params.sortOrder);
      const qs = q.toString();
      return this.request<{
        data: import('../types/index.js').DocumentComplianceReportItem[];
        summary: import('../types/index.js').DocumentComplianceReportSummary;
        pagination: { total: number; page: number; limit: number; totalPages: number };
      }>(`/document-reports/compliance${qs ? `?${qs}` : ''}`);
    },

    getDocumentExpiry: (params?: {
      entityType?: string;
      urgency?: string;
      search?: string;
      horizonDays?: number;
      page?: number;
      limit?: number;
      sortBy?: string;
      sortOrder?: string;
    }) => {
      const q = new URLSearchParams();
      if (params?.entityType && params.entityType !== 'ALL') q.append('entityType', params.entityType);
      if (params?.urgency && params.urgency !== 'ALL') q.append('urgency', params.urgency);
      if (params?.search) q.append('search', params.search);
      if (params?.horizonDays) q.append('horizonDays', String(params.horizonDays));
      if (params?.page) q.append('page', String(params.page));
      if (params?.limit) q.append('limit', String(params.limit));
      if (params?.sortBy) q.append('sortBy', params.sortBy);
      if (params?.sortOrder) q.append('sortOrder', params.sortOrder);
      const qs = q.toString();
      return this.request<{
        data: import('../types/index.js').DocumentExpiryReportItem[];
        summary: import('../types/index.js').DocumentExpiryReportSummary;
        pagination: { total: number; page: number; limit: number; totalPages: number };
      }>(`/document-reports/expiry${qs ? `?${qs}` : ''}`);
    },

    getCertificateAnalytics: (params?: { preset?: string; startDate?: string; endDate?: string }) => {
      const q = new URLSearchParams();
      if (params?.preset) q.append('preset', params.preset);
      if (params?.startDate) q.append('startDate', params.startDate);
      if (params?.endDate) q.append('endDate', params.endDate);
      const qs = q.toString();
      return this.request<import('../types/index.js').CertificateAnalyticsDashboardData>(
        `/document-reports/certificate-analytics${qs ? `?${qs}` : ''}`
      );
    },

    getCertificateLifecycle: () =>
      this.request<import('../types/index.js').CertificateLifecycleAnalytics>(
        '/document-reports/certificate-lifecycle'
      ),

    getCertificateIssuance: (params?: {
      search?: string;
      certificateTypeId?: string;
      status?: string;
      verificationStatus?: string;
      approvalStatus?: string;
      academicSessionId?: string;
      page?: number;
      limit?: number;
      sortBy?: string;
      sortOrder?: string;
    }) => {
      const q = new URLSearchParams();
      if (params?.search) q.append('search', params.search);
      if (params?.certificateTypeId && params.certificateTypeId !== 'ALL')
        q.append('certificateTypeId', params.certificateTypeId);
      if (params?.status && params.status !== 'ALL') q.append('status', params.status);
      if (params?.verificationStatus && params.verificationStatus !== 'ALL')
        q.append('verificationStatus', params.verificationStatus);
      if (params?.approvalStatus && params.approvalStatus !== 'ALL')
        q.append('approvalStatus', params.approvalStatus);
      if (params?.academicSessionId && params.academicSessionId !== 'ALL')
        q.append('academicSessionId', params.academicSessionId);
      if (params?.page) q.append('page', String(params.page));
      if (params?.limit) q.append('limit', String(params.limit));
      if (params?.sortBy) q.append('sortBy', params.sortBy);
      if (params?.sortOrder) q.append('sortOrder', params.sortOrder);
      const qs = q.toString();
      return this.request<{
        data: import('../types/index.js').CertificateIssuanceReportItem[];
        pagination: { total: number; page: number; limit: number; totalPages: number };
      }>(`/document-reports/certificate-issuance${qs ? `?${qs}` : ''}`);
    },

    getCertificateWorkflow: (params?: {
      status?: string;
      search?: string;
      page?: number;
      limit?: number;
    }) => {
      const q = new URLSearchParams();
      if (params?.status && params.status !== 'ALL') q.append('status', params.status);
      if (params?.search) q.append('search', params.search);
      if (params?.page) q.append('page', String(params.page));
      if (params?.limit) q.append('limit', String(params.limit));
      const qs = q.toString();
      return this.request<{
        data: import('../types/index.js').CertificateWorkflowReportItem[];
        pagination: { total: number; page: number; limit: number; totalPages: number };
      }>(`/document-reports/certificate-workflow${qs ? `?${qs}` : ''}`);
    },

    getDigitalVerification: (params?: {
      search?: string;
      page?: number;
      limit?: number;
    }) => {
      const q = new URLSearchParams();
      if (params?.search) q.append('search', params.search);
      if (params?.page) q.append('page', String(params.page));
      if (params?.limit) q.append('limit', String(params.limit));
      const qs = q.toString();
      return this.request<{
        data: import('../types/index.js').DigitalVerificationReportItem[];
        pagination: { total: number; page: number; limit: number; totalPages: number };
      }>(`/document-reports/digital-verification${qs ? `?${qs}` : ''}`);
    },

    getAuditActivity: (params?: {
      action?: string;
      search?: string;
      page?: number;
      limit?: number;
    }) => {
      const q = new URLSearchParams();
      if (params?.action && params.action !== 'ALL') q.append('action', params.action);
      if (params?.search) q.append('search', params.search);
      if (params?.page) q.append('page', String(params.page));
      if (params?.limit) q.append('limit', String(params.limit));
      const qs = q.toString();
      return this.request<{
        data: import('../types/index.js').DocumentCertificateAuditItem[];
        pagination: { total: number; page: number; limit: number; totalPages: number };
      }>(`/document-reports/audit-activity${qs ? `?${qs}` : ''}`);
    },

    reconcileData: () =>
      this.request<import('../types/index.js').DocumentCertificateReconciliationReport>(
        '/document-reports/reconcile',
        { method: 'POST' }
      ),

    getExportUrl: (reportType: string, filters: Record<string, any> = {}) => {
      const q = new URLSearchParams();
      q.append('reportType', reportType);
      Object.entries(filters).forEach(([k, v]) => {
        if (v !== undefined && v !== null && v !== '' && v !== 'ALL') {
          q.append(k, String(v));
        }
      });
      return `/api/document-reports/export/csv?${q.toString()}`;
    },

    auditReportView: (reportName: string, details?: string) =>
      this.request<{ message: string }>('/document-reports/audit-view', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reportName, details })
      })
  };

  // Platform Super Admin SaaS Endpoints (Phase 1)
  platform = {
    getSchools: () => this.request<any[]>('/platform/schools'),
    getStats: () => this.request<any>('/platform/stats'),
    createSchool: (payload: any) =>
      this.request<{ school: School; provisionedAdmin?: any }>('/platform/schools', {
        method: 'POST',
        body: JSON.stringify(payload)
      }),
    getSchool: (id: string) => this.request<School>(`/platform/schools/${id}`),
    updateSchool: (id: string, payload: any) =>
      this.request<School>(`/platform/schools/${id}`, {
        method: 'PUT',
        body: JSON.stringify(payload)
      })
  };

  // Multi-Tenant School Context Endpoints (Phase 1)
  schools = {
    getMySchools: () =>
      this.request<
        Array<{
          id: string;
          name: string;
          code: string;
          status: string;
          plan: string;
          role: string;
          isDefault: boolean;
        }>
      >('/schools/my-schools'),
    getCurrent: () =>
      this.request<{ school: School; membership?: any; role: string; isPlatformAdmin: boolean }>('/schools/current'),
    switchContext: (schoolId: string) =>
      this.request<{ schoolId: string; school: School; session: AuthSession }>('/schools/switch-context', {
        method: 'POST',
        body: JSON.stringify({ schoolId })
      })
  };
}

export const api = new ApiService();

