/**
 * Inventory & Asset Management Foundation Types (Part 14A)
 * Sygmate School Management System
 */

export type ItemType = 'CONSUMABLE' | 'NON_CONSUMABLE' | 'STOCK_ITEM' | 'SERVICE';

export type InventoryItemStatus = 'ACTIVE' | 'INACTIVE' | 'DISCONTINUED';

export interface InventoryItem {
  id: string;
  schoolId: string;
  itemCode: string; // Unique SKU
  name: string;
  description?: string;
  categoryId: string;
  categoryName: string;
  subcategoryId?: string;
  subcategoryName?: string;
  unitId: string;
  unitName: string;
  unitShortCode: string;
  itemType: ItemType;
  brand?: string;
  model?: string;
  barcode?: string;
  imageUrl?: string;
  minStockLevel: number;
  reorderLevel: number;
  maxStockLevel?: number;
  status: InventoryItemStatus;
  isActive: boolean;
  locationId?: string;
  locationName?: string;
  unitPrice?: number;
  isStockable?: boolean;
  currentStock?: number;
  createdBy: string;
  createdByName?: string;
  createdAt: string;
  updatedBy?: string;
  updatedByName?: string;
  updatedAt: string;
}

export interface InventoryCategory {
  id: string;
  schoolId: string;
  name: string;
  code: string;
  description?: string;
  parentCategoryId?: string;
  parentCategoryName?: string;
  status: 'ACTIVE' | 'INACTIVE';
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface InventoryUnit {
  id: string;
  schoolId: string;
  name: string;
  shortCode: string; // e.g. PCS, BOX, PKG, DZN, KG, LTR, MTR
  description?: string;
  status: 'ACTIVE' | 'INACTIVE';
  createdAt: string;
  updatedAt: string;
}

export interface InventoryLocation {
  id: string;
  schoolId: string;
  name: string;
  code: string; // e.g. LOC-MAIN, LOC-LAB
  description?: string;
  department?: string;
  departmentId?: string;
  responsibleStaffId?: string;
  responsibleStaffName?: string;
  status: 'ACTIVE' | 'INACTIVE';
  createdAt: string;
  updatedAt: string;
}

export interface Supplier {
  id: string;
  schoolId: string;
  supplierCode: string; // e.g. SUP-2026-001
  name: string;
  contactPerson: string;
  phone: string;
  email: string;
  address: string;
  city?: string;
  taxNumber?: string;
  status: 'ACTIVE' | 'INACTIVE';
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export type AssetStatus =
  | 'ACTIVE'
  | 'AVAILABLE'
  | 'ASSIGNED'
  | 'UNDER_REPAIR'
  | 'DAMAGED'
  | 'LOST'
  | 'RETIRED'
  | 'DISPOSED';

export type AssetCondition =
  | 'NEW'
  | 'EXCELLENT'
  | 'GOOD'
  | 'FAIR'
  | 'POOR'
  | 'DAMAGED'
  | 'CRITICAL';

export type AssigneeType =
  | 'STAFF'
  | 'TEACHER'
  | 'DEPARTMENT'
  | 'LOCATION'
  | 'STUDENT';

export type AssetAssignmentStatus =
  | 'ACTIVE'
  | 'RETURNED'
  | 'TRANSFERRED';

export type AssetWarrantyStatus =
  | 'ACTIVE'
  | 'EXPIRING_SOON'
  | 'EXPIRED'
  | 'NOT_APPLICABLE';

export type AssetLifecycleEventType =
  | 'REGISTERED'
  | 'ASSIGNED'
  | 'TRANSFERRED'
  | 'RETURNED'
  | 'SENT_FOR_REPAIR'
  | 'REPAIRED'
  | 'DAMAGED'
  | 'LOST'
  | 'RECOVERED'
  | 'RETIRED'
  | 'DISPOSED'
  | 'STATUS_CHANGED'
  | 'DOCUMENT_ATTACHED'
  | 'DOCUMENT_REMOVED'
  | 'MAINTENANCE_LOGGED'
  | 'DETAILS_UPDATED';

export interface AssetAssignment {
  id: string;
  schoolId: string;
  assetId: string;
  assetTag: string;
  assetName: string;
  assigneeType: AssigneeType;
  assigneeId: string;
  assigneeName: string;
  department?: string;
  locationId?: string;
  locationName?: string;
  assignedDate: string;
  expectedReturnDate?: string;
  actualReturnDate?: string;
  conditionAtHandover: AssetCondition;
  conditionAtReturn?: AssetCondition;
  status: AssetAssignmentStatus;
  handoverNotes?: string;
  returnNotes?: string;
  assignedBy: string;
  assignedByName: string;
  receivedBy?: string;
  receivedByName?: string;
  accessories?: string[];
  createdAt: string;
  updatedAt: string;
}

export interface AssetTransfer {
  id: string;
  schoolId: string;
  assetId: string;
  assetTag: string;
  fromAssignmentId: string;
  toAssignmentId: string;
  fromAssigneeType: AssigneeType;
  fromAssigneeId: string;
  fromAssigneeName: string;
  toAssigneeType: AssigneeType;
  toAssigneeId: string;
  toAssigneeName: string;
  fromLocationId?: string;
  toLocationId?: string;
  transferDate: string;
  reason: string;
  condition: AssetCondition;
  transferredBy: string;
  transferredByName: string;
  notes?: string;
  createdAt: string;
}

export interface AssetReturn {
  id: string;
  schoolId: string;
  assetId: string;
  assignmentId: string;
  returnDate: string;
  returnCondition: AssetCondition;
  resultingStatus: AssetStatus;
  locationId: string;
  locationName: string;
  returnedByAssigneeId: string;
  returnedByAssigneeName: string;
  receivedByUserId: string;
  receivedByUserName: string;
  remarks?: string;
  createdAt: string;
}

export interface AssetTimelineEvent {
  id: string;
  schoolId: string;
  assetId: string;
  eventType: AssetLifecycleEventType;
  title: string;
  description: string;
  fromStatus?: AssetStatus;
  toStatus?: AssetStatus;
  fromAssigneeName?: string;
  toAssigneeName?: string;
  performedBy: string;
  performedByName: string;
  performedByRole?: string;
  timestamp: string;
  metadata?: Record<string, any>;
}

export interface AssetCategory {
  id: string;
  schoolId: string;
  name: string;
  code: string;
  description?: string;
  status: 'ACTIVE' | 'INACTIVE';
  createdAt: string;
  updatedAt: string;
}

export interface AssetDocument {
  id: string;
  title: string;
  fileName: string;
  fileUrl: string;
  fileType?: string;
  fileSize?: string;
  documentType?: string;
  uploadedAt: string;
  uploadedBy: string;
}

export type AssetHistory = AssetHistoryEntry;

export interface AssetHistoryEntry {
  id: string;
  assetId: string;
  action: string;
  fromStatus?: AssetStatus;
  toStatus?: AssetStatus;
  remarks: string;
  performedBy: string;
  performedByName?: string;
  timestamp: string;
}

export interface Asset {
  id: string;
  schoolId: string;
  assetTag: string; // Unique, e.g. AST-2026-0001
  name: string;
  categoryId: string;
  categoryName: string;
  brand?: string;
  model?: string;
  serialNumber?: string;
  purchaseDate: string;
  purchaseCost: number;
  supplierId?: string;
  supplierName?: string;
  warrantyStart?: string;
  warrantyEnd?: string;
  warrantyExpiryDate?: string;
  locationId: string;
  locationName: string;
  department?: string;
  status: AssetStatus;
  condition?: AssetCondition;
  currentAssigneeType?: AssigneeType;
  currentAssigneeId?: string;
  currentAssigneeName?: string;
  currentAssignmentId?: string;
  assignedDate?: string;
  expectedReturnDate?: string;
  warrantyStatus?: AssetWarrantyStatus;
  notes?: string;
  description?: string;
  imageUrl?: string;
  documents: AssetDocument[];
  history: AssetHistoryEntry[];
  createdBy: string;
  createdByName?: string;
  createdAt: string;
  updatedBy?: string;
  updatedByName?: string;
  updatedAt: string;
}

export interface InventoryDashboardStats {
  totalItems: number;
  activeItems: number;
  totalAssets: number;
  activeAssets: number;
  totalLocations: number;
  totalSuppliers: number;
  totalAssetValuation: number;
  lowStockThresholdItems: number;
  outOfStockConfiguredItems: number;
  recentItems: InventoryItem[];
  recentAssets: Asset[];
}

export interface InventoryItemFilterParams {
  search?: string;
  categoryId?: string;
  itemType?: ItemType | 'ALL';
  status?: InventoryItemStatus | 'ALL';
  locationId?: string;
  page?: number;
  limit?: number;
  sortBy?: 'name' | 'itemCode' | 'createdAt' | 'minStockLevel';
  sortOrder?: 'asc' | 'desc';
}

export interface AssetFilterParams {
  search?: string;
  categoryId?: string;
  status?: AssetStatus | 'ALL';
  locationId?: string;
  supplierId?: string;
  page?: number;
  limit?: number;
  sortBy?: 'name' | 'assetTag' | 'purchaseDate' | 'purchaseCost' | 'createdAt';
  sortOrder?: 'asc' | 'desc';
}

export interface SupplierFilterParams {
  search?: string;
  status?: 'ACTIVE' | 'INACTIVE' | 'ALL';
  page?: number;
  limit?: number;
}

export interface GlobalInventorySearchResult {
  items: InventoryItem[];
  assets: Asset[];
  suppliers: Supplier[];
  locations: InventoryLocation[];
}

export type InventoryFilterParams = InventoryItemFilterParams;

export interface CreateInventoryItemPayload {
  itemCode?: string;
  name: string;
  description?: string;
  categoryId: string;
  subcategoryId?: string;
  unitId: string;
  itemType: ItemType;
  brand?: string;
  model?: string;
  barcode?: string;
  imageUrl?: string;
  minStockLevel?: number;
  reorderLevel?: number;
  maxStockLevel?: number;
  status?: InventoryItemStatus;
  locationId?: string;
  unitPrice?: number;
}

export type UpdateInventoryItemPayload = Partial<CreateInventoryItemPayload>;

export interface CreateAssetPayload {
  assetTag?: string;
  name: string;
  categoryId: string;
  brand?: string;
  model?: string;
  serialNumber?: string;
  purchaseDate?: string;
  purchaseCost?: number;
  supplierId?: string;
  warrantyStart?: string;
  warrantyEnd?: string;
  locationId: string;
  department?: string;
  status?: AssetStatus;
  condition?: AssetCondition;
  description?: string;
  notes?: string;
  imageUrl?: string;
}

export type UpdateAssetPayload = Partial<CreateAssetPayload>;

export interface AssignAssetPayload {
  assigneeType: AssigneeType;
  assigneeId: string;
  assigneeName: string;
  department?: string;
  locationId?: string;
  locationName?: string;
  assignedDate?: string;
  expectedReturnDate?: string;
  conditionAtHandover?: AssetCondition;
  handoverNotes?: string;
  accessories?: string[];
}

export interface ReturnAssetPayload {
  returnDate?: string;
  returnCondition: AssetCondition;
  locationId: string;
  locationName?: string;
  returnNotes?: string;
}

export interface TransferAssetPayload {
  toAssigneeType: AssigneeType;
  toAssigneeId: string;
  toAssigneeName: string;
  toDepartment?: string;
  toLocationId?: string;
  toLocationName?: string;
  transferDate?: string;
  condition?: AssetCondition;
  reason: string;
  notes?: string;
}

export interface SendForRepairPayload {
  vendorOrServiceProvider?: string;
  estimatedCost?: number;
  estimatedCompletionDate?: string;
  problemDescription: string;
  notes?: string;
}

export interface CompleteRepairPayload {
  actualCost?: number;
  completionDate?: string;
  resultingCondition: AssetCondition;
  returnLocationId: string;
  repairNotes: string;
}

export interface MarkDamagedPayload {
  damageDescription: string;
  condition: AssetCondition;
  canBeRepaired?: boolean;
  notes?: string;
}

export interface MarkLostPayload {
  incidentDate?: string;
  incidentReport: string;
  reportedBy?: string;
}

export interface MarkRecoveredPayload {
  recoveryDate?: string;
  condition: AssetCondition;
  locationId: string;
  notes?: string;
}

export interface RetireAssetPayload {
  reason: string;
  effectiveDate?: string;
  notes?: string;
}

export interface DisposeAssetPayload {
  disposalMethod: 'SOLD' | 'SCRAPPED' | 'DONATED' | 'RECYCLED' | 'E_WASTE';
  disposalDate?: string;
  disposalValue?: number;
  salvageValue?: number;
  disposalReason?: string;
  recipientOrVendor?: string;
  certificateReference?: string;
  notes?: string;
}

export interface AssetLifecycleSummary {
  totalAssets: number;
  availableAssets: number;
  assignedAssets: number;
  underRepairAssets: number;
  damagedAssets: number;
  lostAssets: number;
  retiredAssets: number;
  disposedAssets: number;
  activeWarranties: number;
  expiringWarranties: number;
  expiredWarranties: number;
  totalAssetValuation: number;
}

export interface CreateSupplierPayload {
  supplierCode?: string;
  name: string;
  contactPerson: string;
  phone: string;
  email: string;
  address?: string;
  city?: string;
  taxNumber?: string;
  status?: 'ACTIVE' | 'INACTIVE';
  notes?: string;
}

export type UpdateSupplierPayload = Partial<CreateSupplierPayload>;

export interface CreateInventoryCategoryPayload {
  name: string;
  code: string;
  description?: string;
  parentCategoryId?: string;
  status?: 'ACTIVE' | 'INACTIVE';
}

export interface CreateInventoryUnitPayload {
  name: string;
  shortCode: string;
  description?: string;
  status?: 'ACTIVE' | 'INACTIVE';
}

export interface CreateInventoryLocationPayload {
  name: string;
  code: string;
  description?: string;
  department?: string;
  responsibleStaffId?: string;
  responsibleStaffName?: string;
  status?: 'ACTIVE' | 'INACTIVE';
}

export interface CreateAssetCategoryPayload {
  name: string;
  code: string;
  description?: string;
  status?: 'ACTIVE' | 'INACTIVE';
}

export interface PaginatedInventoryResponse<T> {
  data: T[];
  pagination: {
    total: number;
    page: number;
    limit: number;
    pages: number;
  };
}

// ==========================================
// PART 14B: STOCK MANAGEMENT TYPES
// ==========================================

export type StockMovementType =
  | 'OPENING_STOCK'
  | 'STOCK_IN'
  | 'STOCK_OUT'
  | 'TRANSFER_IN'
  | 'TRANSFER_OUT'
  | 'RETURN'
  | 'ADJUSTMENT_INCREASE'
  | 'ADJUSTMENT_DECREASE';

export type StockTransactionType =
  | 'OPENING_STOCK'
  | 'STOCK_IN'
  | 'STOCK_OUT'
  | 'TRANSFER'
  | 'RETURN'
  | 'ADJUSTMENT';

export type StockTransactionStatus =
  | 'COMPLETED'
  | 'PENDING_APPROVAL'
  | 'APPROVED'
  | 'REJECTED'
  | 'CANCELLED';

export type StockAdjustmentReason =
  | 'COUNT_DIFFERENCE'
  | 'DAMAGED'
  | 'LOST'
  | 'EXPIRED'
  | 'CORRECTION'
  | 'OTHER';

export type StockStatus =
  | 'IN_STOCK'
  | 'LOW_STOCK'
  | 'REORDER_REQUIRED'
  | 'OUT_OF_STOCK';

export interface ItemStockBalance {
  id: string; // Composite or UUID: schoolId:itemId:locationId
  schoolId: string;
  itemId: string;
  itemName: string;
  itemCode: string;
  itemType: ItemType;
  categoryId: string;
  categoryName: string;
  unitId: string;
  unitName: string;
  unitShortCode: string;
  locationId: string;
  locationName: string;
  locationCode: string;
  quantity: number;
  openingQuantity: number;
  totalIn: number;
  totalOut: number;
  totalReturned: number;
  totalAdjusted: number;
  unitPrice?: number;
  minStockLevel: number;
  reorderLevel: number;
  maxStockLevel?: number;
  stockStatus: StockStatus;
  lastMovementDate?: string;
  lastUpdated: string;
}

export interface StockMovement {
  id: string;
  schoolId: string;
  transactionId: string;
  transactionNumber: string;
  movementType: StockMovementType;
  itemId: string;
  itemName: string;
  itemCode: string;
  locationId: string;
  locationName: string;
  quantityIn: number;
  quantityOut: number;
  balanceAfter: number;
  unitId: string;
  unitShortCode: string;
  referenceNumber?: string;
  date: string;
  timestamp: string;
  userId: string;
  userName: string;
  notes?: string;
  sourceLocationId?: string;
  sourceLocationName?: string;
  destinationLocationId?: string;
  destinationLocationName?: string;
  supplierId?: string;
  supplierName?: string;
  department?: string;
  recipient?: string;
  unitCost?: number;
  totalCost?: number;
  adjustmentReason?: StockAdjustmentReason;
}

export interface StockTransaction {
  id: string;
  schoolId: string;
  transactionNumber: string; // STK-IN-XXXX, STK-OUT-XXXX, etc.
  transactionType: StockTransactionType;
  status: StockTransactionStatus;
  itemId: string;
  itemName: string;
  itemCode: string;
  locationId: string;
  locationName: string;
  quantity: number;
  unitId: string;
  unitShortCode: string;
  date: string;
  referenceNumber?: string;
  notes?: string;
  sourceLocationId?: string;
  sourceLocationName?: string;
  destinationLocationId?: string;
  destinationLocationName?: string;
  supplierId?: string;
  supplierName?: string;
  department?: string;
  recipient?: string;
  returnedBy?: string;
  adjustmentReason?: StockAdjustmentReason;
  previousQuantity?: number;
  adjustedQuantity?: number;
  difference?: number;
  unitCost?: number;
  totalCost?: number;
  createdBy: string;
  createdByName: string;
  createdAt: string;
}

export interface StockSummary {
  totalStockableItems: number;
  totalTrackedLocations: number;
  totalUnitsInStock: number;
  inStockCount: number;
  lowStockCount: number;
  reorderRequiredCount: number;
  outOfStockCount: number;
  totalStockValuation: number;
  locationBreakdown: {
    locationId: string;
    locationName: string;
    locationCode: string;
    totalItems: number;
    totalUnits: number;
    lowStockItems: number;
    outOfStockItems: number;
  }[];
}

export interface OpeningStockPayload {
  itemId: string;
  locationId: string;
  quantity: number;
  openingDate?: string;
  referenceNumber?: string;
  notes?: string;
  remarks?: string;
  unitCost?: number;
  batchNumber?: string;
  expiryDate?: string;
}

export interface StockInPayload {
  itemId: string;
  locationId: string;
  quantity: number;
  supplierId?: string;
  sourceType?: string;
  unitCost?: number;
  referenceNumber?: string;
  date?: string;
  transactionDate?: string;
  notes?: string;
  remarks?: string;
  batchNumber?: string;
  expiryDate?: string;
}

export interface StockOutPayload {
  itemId: string;
  locationId: string;
  quantity: number;
  department?: string;
  recipient?: string;
  issuedToName?: string;
  purpose?: string;
  referenceNumber?: string;
  date?: string;
  transactionDate?: string;
  notes?: string;
  remarks?: string;
  issuedToType?: string;
}

export interface StockTransferPayload {
  itemId: string;
  sourceLocationId: string;
  destinationLocationId: string;
  quantity: number;
  transferDate?: string;
  transactionDate?: string;
  referenceNumber?: string;
  reason?: string;
  notes?: string;
  remarks?: string;
}

export interface StockReturnPayload {
  itemId: string;
  locationId: string;
  quantity: number;
  returnedBy?: string;
  returnFromName?: string;
  department?: string;
  reason?: string;
  referenceNumber?: string;
  date?: string;
  transactionDate?: string;
  notes?: string;
  remarks?: string;
  returnFromType?: string;
  itemCondition?: string;
}

export interface StockAdjustmentPayload {
  itemId: string;
  locationId: string;
  adjustedQuantity?: number;
  countedQuantity?: number;
  reason?: StockAdjustmentReason;
  adjustmentReason?: StockAdjustmentReason;
  referenceNumber?: string;
  date?: string;
  transactionDate?: string;
  notes?: string;
  remarks?: string;
}

export interface StockBalanceFilterParams {
  search?: string;
  itemId?: string;
  categoryId?: string;
  locationId?: string;
  stockStatus?: StockStatus | 'ALL';
  itemType?: ItemType | 'ALL';
  page?: number;
  limit?: number;
  sortBy?: 'name' | 'itemCode' | 'quantity' | 'locationName';
  sortOrder?: 'asc' | 'desc';
}

export interface StockMovementFilterParams {
  search?: string;
  itemId?: string;
  locationId?: string;
  movementType?: StockMovementType | 'ALL';
  startDate?: string;
  endDate?: string;
  referenceNumber?: string;
  userId?: string;
  page?: number;
  limit?: number;
  sortBy?: 'timestamp' | 'quantityIn' | 'quantityOut' | 'balanceAfter';
  sortOrder?: 'asc' | 'desc';
}

export interface StockTransactionFilterParams {
  search?: string;
  itemId?: string;
  locationId?: string;
  transactionType?: StockTransactionType | 'ALL';
  status?: StockTransactionStatus | 'ALL';
  startDate?: string;
  endDate?: string;
  page?: number;
  limit?: number;
}

// ============================================================================
// PART 14D: PURCHASE, SUPPLIER & PROCUREMENT WORKFLOW TYPES
// ============================================================================

export type PurchaseRequestPriority = 'LOW' | 'MEDIUM' | 'HIGH' | 'URGENT';
export type PurchasePriority = PurchaseRequestPriority;

export type PurchaseRequestStatus =
  | 'DRAFT'
  | 'SUBMITTED'
  | 'UNDER_REVIEW'
  | 'APPROVED'
  | 'REJECTED'
  | 'CANCELLED'
  | 'CONVERTED_TO_PO';

export type PurchaseOrderStatus =
  | 'DRAFT'
  | 'PENDING_APPROVAL'
  | 'APPROVED'
  | 'SENT_TO_SUPPLIER'
  | 'PARTIALLY_RECEIVED'
  | 'FULLY_RECEIVED'
  | 'COMPLETED'
  | 'REJECTED'
  | 'CANCELLED'
  | 'CLOSED';

export type GoodsReceiptStatus = 'COMPLETED' | 'CANCELLED';

export interface PurchaseRequestItem {
  id: string;
  itemId: string;
  itemName: string;
  itemCode: string;
  description?: string;
  quantity: number;
  unitId: string;
  unitShortCode: string;
  estimatedUnitCost: number;
  estimatedTotal: number;
  preferredSupplierId?: string;
  preferredSupplierName?: string;
  requiredDate?: string;
  isCapitalAsset?: boolean;
  notes?: string;
}

export interface PurchaseRequest {
  id: string;
  schoolId: string;
  requestNumber: string; // e.g. PR-2026-0001
  requestDate: string;
  requiredDate?: string;
  priority: PurchaseRequestPriority;
  status: PurchaseRequestStatus;
  requestingUserId: string;
  requestingUserName: string;
  departmentId?: string;
  departmentName: string;
  targetLocationId: string;
  targetLocationName: string;
  purpose: string;
  notes?: string;
  attachments?: string[];
  items: PurchaseRequestItem[];
  totalEstimatedAmount: number;
  // Approval metadata
  reviewedBy?: string;
  reviewedByName?: string;
  reviewedAt?: string;
  reviewNotes?: string;
  rejectionReason?: string;
  // PO reference
  purchaseOrderId?: string;
  purchaseOrderNumber?: string;
  createdAt: string;
  updatedAt: string;
}

export interface PurchaseOrderItem {
  id: string;
  itemId: string;
  itemName: string;
  itemCode: string;
  description?: string;
  quantityOrdered: number;
  quantityReceived: number;
  quantityAccepted?: number;
  quantityRemaining: number;
  unitId: string;
  unitShortCode: string;
  unitPrice: number;
  discountPercentage?: number;
  discountAmount?: number;
  taxPercentage?: number;
  taxAmount?: number;
  lineTotal: number;
  isCapitalAsset?: boolean;
  expectedDeliveryDate?: string;
  notes?: string;
}

export interface PurchaseOrder {
  id: string;
  schoolId: string;
  poNumber: string; // e.g. PO-2026-0001
  poDate: string;
  supplierId: string;
  supplierName: string;
  supplierCode: string;
  purchaseRequestId?: string;
  purchaseRequestNumber?: string;
  departmentId?: string;
  departmentName: string;
  deliveryLocationId: string;
  deliveryLocationName: string;
  expectedDeliveryDate?: string;
  paymentTerms?: string;
  supplierInvoiceNumber?: string;
  supplierInvoiceDate?: string;
  financialReference?: string;
  status: PurchaseOrderStatus;
  items: PurchaseOrderItem[];
  subtotal: number;
  totalDiscount: number;
  totalTax: number;
  grandTotal: number;
  notes?: string;
  attachments?: string[];
  createdBy: string;
  createdByName: string;
  approvedBy?: string;
  approvedByName?: string;
  approvedAt?: string;
  rejectionReason?: string;
  cancellationReason?: string;
  cancelledBy?: string;
  cancelledByName?: string;
  cancelledAt?: string;
  sentAt?: string;
  completedAt?: string;
  createdAt: string;
  updatedAt: string;
}

export interface GoodsReceiptItem {
  id: string;
  poItemId: string;
  itemId: string;
  itemName: string;
  itemCode: string;
  unitId: string;
  unitShortCode: string;
  quantityOrdered: number;
  previouslyReceived: number;
  quantityReceived: number;
  quantityAccepted: number;
  quantityRejected: number;
  remainingQuantity: number;
  rejectionReason?: string;
  itemCondition: 'NEW' | 'EXCELLENT' | 'GOOD' | 'FAIR' | 'POOR' | 'DAMAGED';
  isCapitalAsset?: boolean;
  notes?: string;
  // Link to generated stock transaction
  stockTransactionId?: string;
  // Generated asset IDs if any
  createdAssetIds?: string[];
}

export interface GoodsReceipt {
  id: string;
  schoolId: string;
  receiptNumber: string; // e.g. GRN-2026-0001
  purchaseOrderId: string;
  purchaseOrderNumber: string;
  supplierId: string;
  supplierName: string;
  supplierCode: string;
  receivingLocationId: string;
  receivingLocationName: string;
  receiptDate: string;
  receivedBy: string;
  receivedByName: string;
  referenceNumber?: string; // Delivery note or bill of lading
  supplierInvoiceNumber?: string;
  status: GoodsReceiptStatus;
  items: GoodsReceiptItem[];
  totalOrderedQty: number;
  totalReceivedQty: number;
  totalAcceptedQty: number;
  totalRejectedQty: number;
  notes?: string;
  attachments?: string[];
  createdAt: string;
  updatedAt: string;
}

// Payloads
export interface CreatePurchaseRequestPayload {
  priority?: PurchaseRequestPriority;
  requiredDate?: string;
  requiredByDate?: string;
  departmentName?: string;
  departmentId?: string;
  targetLocationId?: string;
  purpose: string;
  notes?: string;
  items: Array<{
    itemId: string;
    description?: string;
    quantity: number;
    unitId?: string;
    estimatedUnitCost?: number;
    preferredSupplierId?: string;
    requiredDate?: string;
    isCapitalAsset?: boolean;
    notes?: string;
  }>;
}

export interface UpdatePurchaseRequestPayload {
  priority?: PurchaseRequestPriority;
  requiredDate?: string;
  requiredByDate?: string;
  departmentName?: string;
  departmentId?: string;
  targetLocationId?: string;
  purpose?: string;
  notes?: string;
  items?: Array<{
    itemId: string;
    description?: string;
    quantity: number;
    unitId?: string;
    estimatedUnitCost?: number;
    preferredSupplierId?: string;
    requiredDate?: string;
    isCapitalAsset?: boolean;
    notes?: string;
  }>;
}

export interface ReviewPurchaseRequestPayload {
  decision: 'APPROVE' | 'REJECT';
  reviewNotes?: string;
  rejectionReason?: string;
}

export interface ConvertRequestToPOPayload {
  supplierId: string;
  expectedDeliveryDate?: string;
  paymentTerms?: string;
  notes?: string;
  itemsOverrides?: Array<{
    itemId: string;
    unitPrice: number;
    quantityOrdered?: number;
    discountPercentage?: number;
    taxPercentage?: number;
  }>;
}

export interface CreatePurchaseOrderPayload {
  supplierId: string;
  purchaseRequestId?: string;
  departmentName?: string;
  departmentId?: string;
  deliveryLocationId?: string;
  expectedDeliveryDate?: string;
  paymentTerms?: string;
  deliveryInstructions?: string;
  shippingCost?: number;
  supplierInvoiceNumber?: string;
  financialReference?: string;
  notes?: string;
  items: Array<{
    itemId: string;
    description?: string;
    quantityOrdered: number;
    unitPrice: number;
    discountPercentage?: number;
    taxPercentage?: number;
    isCapitalAsset?: boolean;
    expectedDeliveryDate?: string;
    notes?: string;
  }>;
}

export interface UpdatePurchaseOrderPayload {
  supplierId?: string;
  deliveryLocationId?: string;
  expectedDeliveryDate?: string;
  paymentTerms?: string;
  deliveryInstructions?: string;
  shippingCost?: number;
  supplierInvoiceNumber?: string;
  financialReference?: string;
  notes?: string;
  items?: Array<{
    itemId: string;
    description?: string;
    quantityOrdered: number;
    unitPrice: number;
    discountPercentage?: number;
    taxPercentage?: number;
    isCapitalAsset?: boolean;
    expectedDeliveryDate?: string;
    notes?: string;
  }>;
}

export interface ReviewPurchaseOrderPayload {
  decision: 'APPROVE' | 'REJECT';
  reviewNotes?: string;
  rejectionReason?: string;
}

export interface ReceiveGoodsPayload {
  receivingLocationId: string;
  receiptDate?: string;
  referenceNumber?: string;
  supplierInvoiceNumber?: string;
  invoiceNumber?: string;
  notes?: string;
  remarks?: string;
  idempotencyKey?: string;
  items: Array<{
    poItemId: string;
    quantityReceived: number;
    quantityAccepted: number;
    quantityRejected?: number;
    rejectionReason?: string;
    itemCondition?: 'NEW' | 'EXCELLENT' | 'GOOD' | 'FAIR' | 'POOR' | 'DAMAGED';
    notes?: string;
    // Optional asset creation specification for capital items
    createAssets?: Array<{
      assetTag?: string;
      serialNumber?: string;
      name?: string;
      brand?: string;
      model?: string;
      categoryId: string;
      warrantyEnd?: string;
    }>;
  }>;
}

export interface CreateAssetFromReceiptPayload {
  goodsReceiptId: string;
  goodsReceiptItemId: string;
  assetTag?: string;
  serialNumber?: string;
  name: string;
  categoryId: string;
  locationId?: string;
  brand?: string;
  model?: string;
  warrantyEnd?: string;
  notes?: string;
}

export interface ProcurementDashboardSummary {
  pendingRequestsCount: number;
  pendingPoApprovalsCount: number;
  openPoCount: number;
  partiallyReceivedPoCount: number;
  completedPoCount: number;
  totalSuppliersCount: number;
  recentGoodsReceiptsCount: number;
  totalProcurementSpent: number;
}

// ============================================================================
// PART 14E: ISSUE, RETURN, ALLOCATION & DEPARTMENT WORKFLOW TYPES
// ============================================================================

export type IssueRequestPriority = 'LOW' | 'MEDIUM' | 'HIGH' | 'URGENT';

export type IssueRequestStatus =
  | 'DRAFT'
  | 'SUBMITTED'
  | 'UNDER_REVIEW'
  | 'APPROVED'
  | 'PARTIALLY_ISSUED'
  | 'FULLY_ISSUED'
  | 'COMPLETED'
  | 'REJECTED'
  | 'CANCELLED';

export type StockIssueStatus =
  | 'ISSUED'
  | 'PARTIALLY_RETURNED'
  | 'FULLY_RETURNED'
  | 'RETURNED'
  | 'COMPLETED'
  | 'CANCELLED';

export type ReturnCondition =
  | 'GOOD'
  | 'DAMAGED'
  | 'PARTIALLY_DAMAGED'
  | 'UNUSABLE';

export type InventoryReturnCondition = ReturnCondition;

export type OrganizationalDestinationType =
  | 'STAFF'
  | 'TEACHER'
  | 'DEPARTMENT'
  | 'LOCATION'
  | 'OFFICE'
  | 'ROOM'
  | 'OTHER';

export type IssueRecipientType = OrganizationalDestinationType;

export interface IssueRequestItem {
  id: string;
  issueRequestId?: string;
  itemId: string;
  itemName: string;
  itemCode: string;
  unitId: string;
  unitShortCode: string;
  requestedQuantity?: number;
  quantityRequested?: number;
  availableQuantityAtRequest?: number;
  approvedQuantity?: number;
  quantityApproved?: number;
  issuedQuantity?: number;
  quantityIssued?: number;
  remainingQuantity?: number;
  unitCost?: number;
  estimatedTotal?: number;
  notes?: string;
}

export interface IssueRequest {
  id: string;
  schoolId: string;
  requestNumber: string; // e.g. IR-2026-0001
  requestDate: string;
  requiredDate?: string;
  priority: IssueRequestPriority;
  status: IssueRequestStatus;
  requestedBy?: string; // Staff/User ID
  requestedByName?: string;
  requestedByRole?: string;
  requestingUserId?: string;
  requestingUserName?: string;
  requesterName?: string;
  departmentId?: string;
  departmentName: string;
  destinationType?: OrganizationalDestinationType;
  destinationId?: string;
  destinationName?: string;
  locationId: string; // Source store/location
  locationName: string;
  sourceLocationId?: string;
  sourceLocationName?: string;
  recipientType?: OrganizationalDestinationType;
  recipientId?: string;
  recipientName?: string;
  purpose: string;
  notes?: string;
  items: IssueRequestItem[];
  reviewedBy?: string;
  reviewedByName?: string;
  reviewedAt?: string;
  reviewNotes?: string;
  rejectionReason?: string;
  attachments?: Array<{ id: string; name: string; url: string; size?: string }>;
  totalEstimatedCost?: number;
  createdAt: string;
  updatedAt: string;
}

export interface CreateIssueRequestPayload {
  priority?: IssueRequestPriority;
  requiredDate?: string;
  departmentId?: string;
  departmentName?: string;
  requestingDepartment?: string;
  destinationType?: OrganizationalDestinationType;
  destinationId?: string;
  destinationName?: string;
  locationId?: string;
  locationName?: string;
  sourceLocationId?: string;
  sourceLocationName?: string;
  recipientType?: OrganizationalDestinationType;
  recipientId?: string;
  recipientName?: string;
  targetLocationId?: string;
  purpose?: string;
  notes?: string;
  items: Array<{
    itemId: string;
    requestedQuantity?: number;
    quantityRequested?: number;
    notes?: string;
  }>;
  attachments?: Array<{ id: string; name: string; url: string; size?: string }>;
}

export interface ReviewIssueRequestPayload {
  decision: 'APPROVE' | 'REJECT';
  reviewNotes?: string;
  rejectionReason?: string;
  items?: Array<{
    itemId: string;
    approvedQuantity?: number;
    quantityApproved?: number;
    requestedQuantity?: number;
    notes?: string;
  }>;
  itemApprovals?: Array<{
    itemId: string;
    approvedQuantity: number;
  }>;
  approvedItems?: Array<{
    itemId: string;
    approvedQuantity: number;
    notes?: string;
  }>;
}

export interface StockIssueItem {
  id: string;
  issueId?: string;
  itemId: string;
  itemName: string;
  itemCode: string;
  unitId: string;
  unitShortCode: string;
  quantityIssued: number;
  returnedQuantity?: number;
  quantityReturned?: number;
  remainingQuantity?: number;
  unitCost?: number;
  totalCost?: number;
  stockTransactionId?: string;
  stockMovementId?: string;
  notes?: string;
}

export interface StockIssue {
  id: string;
  schoolId: string;
  issueNumber: string; // e.g. ISS-2026-0001
  issueRequestId?: string;
  issueRequestNumber?: string;
  issueDate: string;
  status: StockIssueStatus;
  locationId: string; // Source store
  sourceLocationId?: string;
  locationName: string;
  sourceLocationName?: string;
  departmentId?: string;
  departmentName: string;
  recipientType: OrganizationalDestinationType;
  recipientId?: string;
  recipientName: string;
  purpose: string;
  notes?: string;
  items: StockIssueItem[];
  totalItemsCount?: number;
  totalCost?: number;
  issuedBy: string;
  issuedByName: string;
  receivedBy?: string;
  receivedByName?: string;
  attachments?: Array<{ id: string; name: string; url: string }>;
  createdAt: string;
  updatedAt: string;
}

export interface ExecuteStockIssuePayload {
  issueRequestId?: string;
  locationId?: string;
  sourceLocationId?: string;
  locationName?: string;
  departmentId?: string;
  departmentName?: string;
  recipientType?: OrganizationalDestinationType;
  recipientId?: string;
  recipientName?: string;
  purpose?: string;
  notes?: string;
  issueDate?: string;
  idempotencyKey?: string;
  items: Array<{
    itemId: string;
    quantity?: number;
    issueQuantity?: number;
    quantityToIssue?: number;
    notes?: string;
  }>;
}

export interface InventoryReturnItem {
  id: string;
  returnId?: string;
  issueItemId?: string;
  itemId: string;
  unitId?: string;
  itemName: string;
  itemCode: string;
  unitShortCode: string;
  quantityReturned: number;
  returnedQuantity?: number;
  condition: ReturnCondition;
  restockedToInventory?: boolean;
  restocked?: boolean;
  stockTransactionId?: string;
  reason?: string;
  notes?: string;
}

export interface InventoryReturn {
  id: string;
  schoolId: string;
  returnNumber: string; // e.g. RET-2026-0001
  issueId?: string;
  originalIssueId?: string;
  originalIssueNumber?: string;
  issueNumber?: string;
  returnDate: string;
  locationId?: string; // Destination store
  returnLocationId?: string;
  locationName?: string;
  returnLocationName?: string;
  departmentId?: string;
  departmentName?: string;
  returnedBy?: string;
  returnedById?: string;
  returnedByType?: string;
  returnedByName?: string;
  receivedBy?: string;
  receivedByUserId?: string;
  receivedByName?: string;
  receivedByUserName?: string;
  reason: string;
  notes?: string;
  items: InventoryReturnItem[];
  attachments?: Array<{ id: string; name: string; url: string }>;
  createdAt: string;
}

export interface RecordInventoryReturnPayload {
  issueId?: string;
  originalIssueId?: string;
  returnLocationId: string;
  departmentId?: string;
  idempotencyKey?: string;
  returnDate?: string;
  returnedBy?: string;
  returnedById?: string;
  returnedByType?: string;
  returnedByName?: string;
  departmentName?: string;
  reason: string;
  notes?: string;
  items: Array<{
    issueItemId?: string;
    itemId?: string;
    unitId?: string;
    quantity?: number;
    returnedQuantity?: number;
    condition?: ReturnCondition;
    itemCondition?: ReturnCondition;
    reason?: string;
    notes?: string;
  }>;
}

export type CreateInventoryReturnPayload = RecordInventoryReturnPayload;

export interface AssetAccessoryItem {
  name: string;
  serialNumber?: string;
  status: 'INCLUDED' | 'MISSING' | 'DAMAGED';
  notes?: string;
}

export interface BulkAssetAllocationPayload {
  assetIds: string[];
  assigneeType: AssigneeType;
  assigneeId: string;
  assigneeName: string;
  department?: string;
  locationId?: string;
  locationName?: string;
  assignedDate?: string;
  expectedReturnDate?: string;
  conditionAtHandover?: AssetCondition;
  handoverNotes?: string;
  accessories?: Array<string | AssetAccessoryItem>;
}

export interface DepartmentAllocationSummary {
  departmentId: string;
  departmentName: string;
  departmentCode?: string;
  location?: string;
  locationsCount?: number;
  totalAssetsCount?: number;
  activeAssetsCount?: number;
  assignedAssetsCount?: number;
  totalAssetValuation?: number;
  totalAssetValue?: number;
  activeCustodiansCount?: number;
  activeStaffCount?: number;
  totalIssuesCount?: number;
  recentIssuesCount?: number;
  totalIssuedInventoryVolume?: number;
  totalItemsIssued?: number;
  pendingReturnsCount?: number;
  assets?: Asset[];
  issues?: StockIssue[];
  custodians?: Array<{
    id: string;
    name: string;
    role?: string;
    assignedAssetsCount: number;
  }>;
}

export interface IssueAllocationDashboardKPIs {
  pendingIssueRequestsCount: number;
  todayIssuesCount: number;
  pendingReturnsCount: number;
  activeAssetAllocationsCount: number;
  totalDepartmentsTracked: number;
}

// ============================================================================
// PART 14F: COMPREHENSIVE INVENTORY & ASSET ANALYTICS, REPORTS & RECONCILIATION
// ============================================================================

export type DateFilterPreset =
  | 'TODAY'
  | 'YESTERDAY'
  | 'LAST_7_DAYS'
  | 'LAST_30_DAYS'
  | 'THIS_MONTH'
  | 'LAST_MONTH'
  | 'THIS_QUARTER'
  | 'THIS_YEAR'
  | 'ALL_TIME'
  | 'CUSTOM';

export interface InventoryAnalyticsFilters {
  datePreset?: DateFilterPreset;
  startDate?: string;
  endDate?: string;
  departmentId?: string;
  locationId?: string;
  categoryId?: string;
  slowMovingThresholdDays?: number;
}

export interface StockMovementChartPoint {
  date: string;
  label: string;
  stockIn: number;
  stockOut: number;
  returned: number;
  transferred: number;
  netMovement: number;
}

export interface LowStockCriticalItem {
  itemId: string;
  itemCode: string;
  itemName: string;
  categoryName: string;
  locationId: string;
  locationName: string;
  currentQuantity: number;
  minStockLevel: number;
  reorderLevel: number;
  unitShortCode: string;
  status: StockStatus;
  deficit: number;
  recommendedAction: string;
}

export interface ItemMovementPerformance {
  itemId: string;
  itemCode: string;
  itemName: string;
  categoryName: string;
  currentStock: number;
  stockInQuantity: number;
  stockOutQuantity: number;
  returnedQuantity: number;
  transferredQuantity: number;
  adjustmentQuantity: number;
  issueFrequency: number;
  lastMovementDate?: string;
  daysSinceLastMovement?: number;
  movementVelocityTag: 'HIGH_VOLUME' | 'MODERATE_VOLUME' | 'LOW_VOLUME' | 'INACTIVE';
}

export interface AssetWarrantyAlert {
  assetId: string;
  assetTag: string;
  name: string;
  categoryName: string;
  locationName?: string;
  custodianName?: string;
  warrantyExpiryDate?: string;
  daysUntilExpiry?: number;
  warrantyStatus: 'ACTIVE' | 'EXPIRING_SOON' | 'EXPIRED' | 'NO_WARRANTY';
}

export interface SupplierOperationalMetric {
  supplierId: string;
  supplierCode: string;
  name: string;
  totalOrders: number;
  openOrders: number;
  completedOrders: number;
  fulfillmentRate: number;
  totalSpend: number;
  lastOrderDate?: string;
  status: 'ACTIVE' | 'INACTIVE';
}

export interface ReconciliationAuditMetric {
  name: string;
  dashboardValue: number;
  authoritativeValue: number;
  difference: number;
  matched: boolean;
  sourceOfTruth: string;
}

export interface ReconciliationAudit {
  reconciliationTimestamp: string;
  isReconciled: boolean;
  metrics: ReconciliationAuditMetric[];
}

export interface ComprehensiveInventoryAnalytics {
  filterApplied: {
    preset: DateFilterPreset;
    startDate: string;
    endDate: string;
    departmentId?: string;
    locationId?: string;
    categoryId?: string;
  };
  inventoryKPIs: {
    totalItems: number;
    activeItems: number;
    stockableItems: number;
    nonStockItems: number;
    consumables: number;
    nonConsumables: number;
    totalLocations: number;
    totalCategories: number;
    totalStockUnits: number;
    totalStockValuation: number;
    inStockCount: number;
    lowStockCount: number;
    reorderRequiredCount: number;
    outOfStockCount: number;
    overstockCount: number;
    periodStockIn: number;
    periodStockOut: number;
    periodReturned: number;
    periodTransferred: number;
    periodAdjusted: number;
    periodNetMovement: number;
  };
  assetKPIs: {
    totalAssets: number;
    availableAssets: number;
    assignedAssets: number;
    underRepairAssets: number;
    damagedAssets: number;
    lostAssets: number;
    retiredAssets: number;
    disposedAssets: number;
    totalAssetValuation: number;
    underWarrantyCount: number;
    warrantyExpiringSoonCount: number;
    warrantyExpiredCount: number;
    noWarrantyCount: number;
    assignedToStaffCount: number;
    assignedToTeachersCount: number;
    assignedToDepartmentsCount: number;
    unassignedCount: number;
    periodRegistered: number;
    periodAssigned: number;
    periodTransferred: number;
    periodReturned: number;
    periodRepair: number;
    periodDamaged: number;
    periodLost: number;
    periodDisposed: number;
  };
  procurementKPIs: {
    totalPurchaseRequests: number;
    pendingPurchaseRequests: number;
    approvedPurchaseRequests: number;
    rejectedPurchaseRequests: number;
    convertedPurchaseRequests: number;
    totalPurchaseOrders: number;
    pendingApprovalPOs: number;
    openPOs: number;
    partiallyReceivedPOs: number;
    fullyReceivedPOs: number;
    cancelledPOs: number;
    totalGoodsReceipts: number;
    periodOrderedQuantity: number;
    periodReceivedQuantity: number;
    periodAcceptedQuantity: number;
    periodRejectedQuantity: number;
    periodProcurementSpend: number;
    pendingDeliveryQuantity: number;
    totalSuppliers?: number;
  };
  issueKPIs: {
    totalIssueRequests: number;
    pendingIssueRequests: number;
    approvedIssueRequests: number;
    completedIssueRequests: number;
    totalStockIssues: number;
    periodIssuedQuantity: number;
    periodReturnedGoodQuantity: number;
    periodReturnedDamagedQuantity: number;
    pendingReturnsCount: number;
    returnRatePercentage: number;
  };
  stockMovementTrends: StockMovementChartPoint[];
  stockByLocation: Array<{
    locationId: string;
    locationName: string;
    locationCode: string;
    department?: string;
    totalItems: number;
    totalUnits: number;
    valuation: number;
    lowStockItems: number;
    outOfStockItems: number;
    periodMovements: number;
  }>;
  lowStockCriticalItems: LowStockCriticalItem[];
  itemPerformance: ItemMovementPerformance[];
  assetStatusDistribution: Array<{ status: string; label: string; count: number; valuation: number }>;
  assetCategoryDistribution: Array<{ categoryId: string; categoryName: string; count: number; valuation: number }>;
  assetDepartmentDistribution: Array<{ departmentName: string; count: number; valuation: number }>;
  assetAgeDistribution: Array<{ bucket: string; count: number; valuation: number }>;
  warrantyAlerts: AssetWarrantyAlert[];
  supplierMetrics: SupplierOperationalMetric[];
  departmentSummaries: DepartmentAllocationSummary[];
  reconciliation: ReconciliationAudit;
}

