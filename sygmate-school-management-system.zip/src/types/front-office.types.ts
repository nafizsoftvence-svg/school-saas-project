/**
 * Front Office & Visitor Management Types (Part 13A)
 * Sygmate School Management System
 */

export type FrontOfficeEnquiryStatus =
  | 'NEW'
  | 'CONTACTED'
  | 'FOLLOW_UP_REQUIRED'
  | 'FOLLOW_UP_IN_PROGRESS'
  | 'INTERESTED'
  | 'APPLICATION_STARTED'
  | 'CONVERTED'
  | 'NOT_INTERESTED'
  | 'LOST'
  | 'CLOSED'
  | 'QUALIFIED'
  | 'FOLLOW_UP_COMPLETED';

export type FrontOfficeEnquirySource =
  | 'WALK_IN'
  | 'WEBSITE'
  | 'PHONE'
  | 'REFERRAL'
  | 'SOCIAL_MEDIA'
  | 'EMAIL'
  | 'EXPO_EVENT'
  | 'EXISTING_PARENT'
  | 'ADVERTISEMENT'
  | 'EVENT'
  | 'OTHER';

export type EnquiryPriority = 'LOW' | 'MEDIUM' | 'HIGH' | 'URGENT';

export type FollowUpContactMethod = 'Phone' | 'Email' | 'In Person' | 'Website' | 'Other';

export interface EnquiryAssignmentHistory {
  id: string;
  fromStaffId?: string;
  fromStaffName?: string;
  toStaffId: string;
  toStaffName: string;
  assignedById: string;
  assignedByName: string;
  assignedAt: string;
  notes?: string;
}

export interface EnquiryStatusHistory {
  fromStatus: string;
  toStatus: string;
  changedById: string;
  changedByName: string;
  changedAt: string;
  remarks?: string;
}

export interface EnquiryFollowUp {
  id: string;
  enquiryId: string;
  enquiryNumber: string;
  followUpDate: string; // YYYY-MM-DD
  followUpTime?: string;
  contactMethod?: FollowUpContactMethod | string; // Phone, Email, In Person, Website, Other
  contactOutcome: string; // e.g. "Called - Interested", "Campus Tour Scheduled", "No Answer", "Fees Discussed", etc.
  notes: string;
  status: FrontOfficeEnquiryStatus;
  nextFollowUpDate?: string;
  nextFollowUpTime?: string;
  assignedStaffId?: string;
  assignedStaffName?: string;
  reminderSent?: boolean;
  createdAt: string;
  createdById?: string;
  createdByName?: string;
  updatedAt?: string;
}

export interface FrontOfficeEnquiry {
  id: string;
  enquiryNumber: string;
  enquiryDate?: string;
  studentName: string;
  dateOfBirth?: string;
  gender?: 'male' | 'female' | 'other' | string;
  applyingClassId: string;
  applyingClassName: string;
  academicSessionId: string;
  academicSessionName: string;
  parentName: string;
  relationship?: string;
  phone: string;
  alternatePhone?: string;
  email?: string;
  address?: string;
  previousSchool?: string;
  source: FrontOfficeEnquirySource;
  enquiryType?: string; // "General", "Admission", "Transfer", "Scholarship", "Information"
  assignedStaffId?: string;
  assignedStaffName?: string;
  assignmentDate?: string;
  assignedById?: string;
  assignedByName?: string;
  status: FrontOfficeEnquiryStatus;
  priority?: EnquiryPriority;
  followUpDate?: string;
  followUpTime?: string;
  followUpStatus?: string;
  notes?: string;
  assignmentHistory?: EnquiryAssignmentHistory[];
  statusHistory?: EnquiryStatusHistory[];
  convertedAdmissionId?: string;
  convertedApplicationNumber?: string;
  convertedStudentId?: string;
  conversionDate?: string;
  convertedBy?: string;
  convertedById?: string;
  createdById?: string;
  createdByName?: string;
  createdAt: string;
  updatedAt: string;
  followUps?: EnquiryFollowUp[];
  followUpsCount?: number;
  latestFollowUp?: EnquiryFollowUp | null;
}

export interface EnquiryDuplicateMatch {
  type?: 'PHONE' | 'EMAIL' | 'STUDENT_NAME' | 'PARENT_NAME' | 'ADMISSION_RECORD' | string;
  matchedEntity?: 'ENQUIRY' | 'STUDENT' | 'EXISTING_STUDENT' | 'APPLICATION' | string;
  entityType?: 'ENQUIRY' | 'STUDENT' | 'EXISTING_STUDENT' | 'APPLICATION' | string;
  id: string;
  name: string;
  identifier: string;
  details?: string;
  similarityScore: number;
  status?: string;
  className?: string;
  parentName?: string;
  phone?: string;
  email?: string;
  createdAt?: string;
  matchedFields?: string[];
}

export interface EnquiryDuplicateCheckResult {
  hasDuplicates: boolean;
  matches: EnquiryDuplicateMatch[];
  checkedPhone?: string;
  checkedEmail?: string;
  checkedStudentName?: string;
}

export interface EnquiryMetricsSummary {
  totalEnquiries: number;
  newEnquiries: number;
  contactedEnquiries: number;
  followUpRequiredEnquiries: number;
  followUpInProgressEnquiries: number;
  followUpTodayEnquiries: number;
  overdueFollowUps: number;
  interestedEnquiries: number;
  applicationStartedEnquiries: number;
  convertedEnquiries: number;
  notInterestedEnquiries: number;
  lostEnquiries: number;
  closedEnquiries: number;
  conversionRate: number;
  sourceDistribution: Record<string, number>;
  priorityDistribution: Record<string, number>;
  classDistribution: Record<string, number>;
}

export interface EnquirySourceConfig {
  id: string;
  name: string;
  code: string;
  isActive: boolean;
  isDefault?: boolean;
  displayOrder: number;
}

export type VisitorType =
  | 'Parent/Guardian'
  | 'Student-related'
  | 'Vendor'
  | 'Applicant'
  | 'Government/Official'
  | 'Staff-related'
  | 'Guest'
  | 'Other';

export type VisitorStatus =
  | 'PENDING'
  | 'SCHEDULED'
  | 'CONFIRMED'
  | 'CHECKED_IN'
  | 'CHECKED_OUT'
  | 'CANCELLED'
  | 'REJECTED'
  | 'NO_SHOW';

export type VisitorEntryType = 'SCHEDULED' | 'WALK_IN';

export interface VisitorRecord {
  id: string;
  bookingId?: string; // e.g. BKG-2026-0001
  visitorPassNumber: string; // e.g. VIS-2026-0001
  visitorName: string;
  phone: string;
  email?: string;
  organization?: string;
  visitorType: VisitorType;
  entryType?: VisitorEntryType;
  purpose: string;
  personToMeet: string;
  personToMeetId?: string;
  personToMeetRole?: string;
  department: string;
  departmentId?: string;
  appointmentDate: string; // YYYY-MM-DD
  appointmentTime: string; // HH:mm
  expectedDuration?: string; // e.g. "45 mins"
  expectedDurationMinutes?: number;
  numberOfVisitors: number;
  vehicleNumber?: string;
  vehicleType?: string;
  idCardType?: string;
  idCardNumber?: string;
  idProofType?: string;
  idProofNumber?: string;
  notes?: string;
  attachmentUrl?: string;
  attachmentName?: string;
  qrCodeToken?: string;
  status: VisitorStatus;
  checkInTime?: string; // ISO server timestamp
  checkInBy?: string;
  checkInUserId?: string;
  checkOutTime?: string; // ISO server timestamp
  checkOutBy?: string;
  checkOutUserId?: string;
  durationMinutes?: number;
  badgeIssued?: boolean;
  approvedById?: string;
  approvedByName?: string;
  approvedAt?: string;
  rejectionReason?: string;
  reminderSentAt?: string;
  reminderCount?: number;
  createdById?: string;
  createdByName?: string;
  createdAt: string;
  updatedAt: string;
}

export interface TodaysFrontDeskOverview {
  date: string;
  summary: {
    expectedCount: number;
    checkedInCount: number;
    currentlyInsideCount: number;
    checkedOutCount: number;
    cancelledOrNoShowCount: number;
    totalTraffic: number;
    averageStayDurationMinutes: number;
  };
  expected: VisitorRecord[];
  checkedInToday: VisitorRecord[];
  currentlyInside: VisitorRecord[];
  checkedOutToday: VisitorRecord[];
  cancelledOrNoShow: VisitorRecord[];
}

export interface VisitorPassVerificationResult {
  valid: boolean;
  passNumber: string;
  bookingId?: string;
  visitorName: string;
  status: VisitorStatus;
  organization?: string;
  personToMeet: string;
  department: string;
  checkInTime?: string;
  checkOutTime?: string;
  appointmentDate: string;
  appointmentTime: string;
  isExpired: boolean;
  message: string;
}

export interface AdvancedVisitorReport {
  totalVisitors: number;
  averageDurationMinutes: number;
  overstayCount: number;
  statusBreakdown: Record<string, number>;
  typeBreakdown: Record<string, number>;
  departmentBreakdown: Record<string, number>;
  hourlyArrivals: Record<string, number>;
  overstayVisitors: Array<{
    id: string;
    visitorPassNumber: string;
    visitorName: string;
    personToMeet: string;
    department: string;
    checkInTime: string;
    currentDurationMins: number;
  }>;
}

export type CallDirection = 'INCOMING' | 'OUTGOING';

export type CallStatus =
  | 'COMPLETED'
  | 'MISSED'
  | 'BUSY'
  | 'NO_ANSWER'
  | 'VOICEMAIL'
  | 'FOLLOW_UP_REQUIRED'
  | 'CLOSED'
  | 'CANCELLED';

export type CallType =
  | 'Admission Inquiry'
  | 'Fee Inquiry'
  | 'Academic Progress'
  | 'General Query'
  | 'Emergency'
  | 'Complaint'
  | 'Staff Inquiry'
  | 'Parent Consultation'
  | 'Vendor / Supplier'
  | 'Other';

export interface PhoneCallLogRecord {
  id: string;
  callLogNumber: string; // e.g. CALL-2026-0001
  callNumber?: string; // Compatibility alias
  callDate: string; // YYYY-MM-DD
  callTime: string; // HH:mm
  callerName: string;
  callerPhone: string;
  phone?: string; // Compatibility alias
  callerEmail?: string;
  callerType?: string; // PARENT, STUDENT, TEACHER, etc.
  callType: CallType | string;
  direction: CallDirection;
  relatedEntityType?: 'STUDENT' | 'PARENT' | 'STAFF' | 'VISITOR' | 'VENDOR' | 'GENERAL';
  relatedEntityId?: string;
  relatedEntityName?: string;
  department?: string;
  assignedStaffId?: string;
  assignedStaffName?: string;
  purpose: string;
  summary: string;
  summaryNotes?: string; // Compatibility alias
  callDuration?: string; // e.g. "5 mins"
  durationSeconds?: number; // Numeric seconds
  followUpRequired: boolean;
  followUpDate?: string;
  followUpTime?: string;
  followUpNotes?: string;
  followUpStatus?: 'PENDING' | 'COMPLETED' | 'CANCELLED';
  followUpCompletedAt?: string;
  followUpCompletedById?: string;
  followUpCompletedByName?: string;
  followUpOutcome?: string;
  status: CallStatus;
  notes?: string;
  actionItems?: string[];
  convertedToComplaintId?: string;
  convertedToComplaintNumber?: string;
  linkedEnquiryId?: string;
  linkedEnquiryNumber?: string;
  createdById?: string;
  createdByName?: string;
  createdAt: string;
  updatedAt: string;
}

export type ComplaintPriority = 'LOW' | 'MEDIUM' | 'HIGH' | 'URGENT';

export type ComplaintStatus =
  | 'NEW'
  | 'ASSIGNED'
  | 'ACKNOWLEDGED'
  | 'IN_PROGRESS'
  | 'RESOLVED'
  | 'CLOSED'
  | 'REOPENED'
  | 'REJECTED'
  | 'CANCELLED';

export type ComplaintSlaStatus = 'ON_TRACK' | 'AT_RISK' | 'BREACHED' | 'RESOLVED_WITHIN_SLA' | 'RESOLVED_BREACHED';

export type EscalationLevel = 'LEVEL_1_HOD' | 'LEVEL_2_VP' | 'LEVEL_3_PRINCIPAL' | 'LEVEL_1' | 'LEVEL_2' | 'LEVEL_3';

export type ComplaintResolutionCategory =
  | 'REPAIRED_REPLACED'
  | 'POLICY_EXPLAINED'
  | 'APOLOGY_ISSUED'
  | 'WAIVED_REFUNDED'
  | 'COUNSELED'
  | 'PROCESS_IMPROVED'
  | 'OTHER';

export interface ComplaintHistoryEntry {
  id: string;
  complaintId: string;
  action: string;
  fromStatus?: ComplaintStatus;
  toStatus: ComplaintStatus;
  remarks: string;
  actorId?: string;
  actorName: string;
  timestamp: string;
  changedAt?: string; // Compatibility alias
  changedByName?: string; // Compatibility alias
}

export interface ComplaintAttachment {
  id: string;
  name: string;
  url: string;
  size: string;
  type?: string;
  uploadedAt?: string;
}

export type ComplainantType =
  | 'Parent'
  | 'Student'
  | 'Teacher'
  | 'Staff'
  | 'Visitor'
  | 'Neighbor/Community'
  | 'Other';

export type ComplaintCategory =
  | 'Academic'
  | 'Discipline'
  | 'Infrastructure'
  | 'Transport'
  | 'Food/Canteen'
  | 'Fee/Billing'
  | 'Staff Conduct'
  | 'Safety'
  | 'Other';

export interface ComplaintRecord {
  id: string;
  complaintNumber: string; // e.g. CMP-2026-0001
  complaintDate: string; // YYYY-MM-DD
  complainantName: string;
  complainantType: ComplainantType | string;
  phone?: string;
  complainantPhone?: string;
  email?: string;
  complainantEmail?: string;
  relatedEntityType?: 'STUDENT' | 'PARENT' | 'STAFF' | 'DEPARTMENT' | 'FACILITY' | 'OTHER';
  relatedEntityId?: string;
  relatedEntityName?: string;
  studentRollNumber?: string;
  studentClassSection?: string;
  complaintCategory: ComplaintCategory | string;
  category?: string; // Compatibility alias
  subject: string;
  description: string;
  priority: ComplaintPriority;
  assignedDepartment?: string;
  assignedStaffId?: string;
  assignedStaffName?: string;
  status: ComplaintStatus;
  
  // SLA & Deadlines
  targetResolutionDate?: string;
  slaStatus?: ComplaintSlaStatus;
  slaHoursRemaining?: number;

  // Escalation
  isEscalated?: boolean;
  escalationLevel?: 'LEVEL_1' | 'LEVEL_2' | 'LEVEL_3';
  escalationReason?: string;
  escalatedAt?: string;
  escalatedById?: string;
  escalatedByName?: string;

  // Acknowledgment
  acknowledgedAt?: string;
  acknowledgedById?: string;
  acknowledgedByName?: string;
  acknowledgmentNotes?: string;

  // Resolution & Remedies
  resolution?: string;
  resolutionDate?: string;
  resolutionCategory?: string;
  remedyActionTaken?: string;
  immediateActionTaken?: string;
  resolvedById?: string;
  resolvedByName?: string;

  // Reopening
  reopenCount?: number;
  reopenedAt?: string;
  reopenedById?: string;
  reopenedByName?: string;
  reopenReason?: string;

  // Feedback & Closure
  feedbackRating?: number; // 1 to 5
  feedbackRemarks?: string;
  closureNotes?: string;
  closedAt?: string;
  closedById?: string;
  closedByName?: string;

  // Rejection / Cancellation
  rejectionReason?: string;
  cancelledAt?: string;
  cancelledById?: string;

  // Phone Call cross-link
  originatingCallId?: string;
  originatingCallNumber?: string;

  notes?: string;
  attachments?: ComplaintAttachment[];
  history: ComplaintHistoryEntry[];
  createdById?: string;
  createdByName?: string;
  createdAt: string;
  updatedAt: string;
}

export interface ComplaintMetricsSummary {
  total: number;
  new: number;
  assigned: number;
  acknowledged: number;
  inProgress: number;
  resolved: number;
  closed: number;
  reopened: number;
  urgentCount: number;
  highCount: number;
  slaBreachedCount: number;
  slaAtRiskCount: number;
  slaAtRisk: number;
  slaBreached: number;
  resolutionRate: number;
  averageResolutionHours: number;
  byCategory: Record<string, number>;
  byDepartment: Record<string, number>;
}

export interface CallMetricsSummary {
  total: number;
  incoming: number;
  outgoing: number;
  completed: number;
  missed: number;
  callbacksPending: number;
  callbacksCompletedToday: number;
  averageDurationMinutes: number;
  convertedToComplaintCount?: number;
  byType: Record<string, number>;
}

export type DashboardDatePreset =
  | 'TODAY'
  | 'YESTERDAY'
  | 'THIS_WEEK'
  | 'LAST_7_DAYS'
  | 'THIS_MONTH'
  | 'CURRENT_MONTH'
  | 'LAST_30_DAYS'
  | 'PREVIOUS_MONTH'
  | 'THIS_ACADEMIC_YEAR'
  | 'CURRENT_SESSION'
  | 'CUSTOM';

export interface FrontOfficeDashboardStats {
  // Timeframe info
  datePreset?: DashboardDatePreset | string;
  startDate?: string;
  endDate?: string;
  sessionId?: string;

  // 1. Admission Enquiries
  totalEnquiries: number;
  newEnquiries: number;
  pendingFollowups: number;
  followupsDueToday: number;
  overdueFollowups: number;
  convertedAdmissions: number;
  lostOrClosedEnquiries: number;
  conversionRate: number; // percentage (0 - 100)

  // 2. Visitors
  todaysVisitors: number;
  expectedVisitors: number;
  checkedInVisitors: number;
  currentlyInsideVisitors: number;
  checkedOutVisitors: number;
  completedVisits: number;
  cancelledVisits: number;
  noShowVisitors: number;
  averageVisitDurationMinutes: number;

  // 3. Phone Calls
  todaysCalls: number;
  incomingCalls: number;
  outgoingCalls: number;
  missedCalls: number;
  callsFollowUpRequired: number;
  callsFollowUpDueToday: number;
  callsFollowUpOverdue: number;

  // 4. Complaints / Grievances
  totalComplaints: number;
  newComplaints: number;
  openComplaints: number;
  inProgressComplaints: number;
  resolvedComplaints: number;
  closedComplaints: number;
  overdueComplaints: number; // SLA Breached
  slaAtRiskComplaints: number;
  urgentComplaints: number;
  highComplaints: number;

  // Backward-compatibility aliases
  followUpRequiredEnquiries?: number;
  pendingEnquiries?: number;
  pendingComplaints?: number;
}

export interface FrontOfficeAnalyticsTrendPoint {
  date: string;
  label: string;
  enquiries: number;
  visitors: number;
  calls: number;
  complaints: number;
}

export interface StaffWorkloadSummary {
  staffId: string;
  staffName: string;
  department: string;
  enquiriesAssigned: number;
  enquiriesConverted: number;
  visitorsHosted: number;
  callsHandled: number;
  complaintsAssigned: number;
  complaintsResolved: number;
  totalInteractions: number;
}

export interface DepartmentDistributionItem {
  department: string;
  visitorsCount: number;
  callsCount: number;
  complaintsCount: number;
  totalVolume: number;
}

export interface FrontOfficeAnalyticsData {
  timeframe: {
    preset: string;
    startDate: string;
    endDate: string;
  };
  overview: {
    enquiries: { total: number; converted: number; pending: number; rate: number };
    visitors: { total: number; currentlyInside: number; completed: number; avgDuration: number };
    calls: { total: number; incoming: number; outgoing: number; missed: number; pendingCallback: number };
    complaints: { total: number; open: number; resolved: number; breached: number; urgent: number };
  };
  trends: FrontOfficeAnalyticsTrendPoint[];
  timeSeries?: FrontOfficeAnalyticsTrendPoint[];
  staffWorkload: StaffWorkloadSummary[];
  departmentDistribution: DepartmentDistributionItem[];
  enquiryStatusBreakdown: Record<string, number>;
  enquirySourceBreakdown: Record<string, number>;
  complaintCategoryBreakdown: Record<string, number>;
  complaintPriorityBreakdown: Record<string, number>;
  callTypeBreakdown: Record<string, number>;
}

export interface FrontOfficeGlobalSearchResult {
  enquiries: Array<{
    id: string;
    enquiryNumber: string;
    studentName: string;
    parentName: string;
    phone: string;
    status: string;
    date: string;
    applyingClassName?: string;
  }>;
  visitors: Array<{
    id: string;
    visitorPassNumber: string;
    visitorName: string;
    phone: string;
    purpose: string;
    personToMeet: string;
    status: string;
    date: string;
    department?: string;
  }>;
  calls: Array<{
    id: string;
    callLogNumber: string;
    callerName: string;
    callerPhone: string;
    callType: string;
    direction: string;
    status: string;
    date: string;
    department?: string;
  }>;
  complaints: Array<{
    id: string;
    complaintNumber: string;
    complainantName: string;
    subject: string;
    category: string;
    priority: string;
    status: string;
    date: string;
    assignedDepartment?: string;
  }>;
}

export type FrontOfficeReportType =
  // Admission Enquiry Reports
  | 'ENQUIRY_REGISTER'
  | 'ENQUIRY_STATUS'
  | 'ENQUIRY_SOURCE'
  | 'ENQUIRY_FOLLOWUP'
  | 'ENQUIRY_CONVERSION'
  // Visitor Reports
  | 'VISITOR_REGISTER'
  | 'VISITOR_DAILY'
  | 'VISITOR_EXPECTED'
  | 'VISITOR_CURRENTLY_INSIDE'
  | 'VISITOR_COMPLETED'
  | 'VISITOR_CANCELLED'
  | 'VISITOR_SUMMARY'
  // Phone Call Reports
  | 'CALL_REGISTER'
  | 'CALLS_DAILY'
  | 'CALLS_DIRECTION'
  | 'CALLS_MISSED'
  | 'CALLS_FOLLOWUP_REQUIRED'
  | 'CALLS_FOLLOWUP_DUE'
  | 'CALLS_STAFF_SUMMARY'
  | 'CALLS_TYPE_SUMMARY'
  // Complaint Reports
  | 'COMPLAINT_REGISTER'
  | 'COMPLAINT_OPEN'
  | 'COMPLAINT_RESOLVED'
  | 'COMPLAINT_CLOSED'
  | 'COMPLAINT_OVERDUE'
  | 'COMPLAINT_PRIORITY'
  | 'COMPLAINT_CATEGORY'
  | 'COMPLAINT_DEPARTMENT'
  | 'COMPLAINT_STAFF_ASSIGNMENT'
  | 'COMPLAINT_RESOLUTION_TIME'
  // Legacy Aliases
  | 'VISITORS'
  | 'ENQUIRIES'
  | 'CALLS'
  | 'COMPLAINTS'
  | 'ENQUIRY_SUMMARY'
  | 'VISITOR_CHECKIN_OUT'
  | 'PHONE_CALLS'
  | 'COMPLAINTS_SUMMARY'
  | 'COMPLAINTS_RESOLUTION'
  | 'STAFF_ASSIGNMENT';

export interface FrontOfficeReportFilter {
  reportType: FrontOfficeReportType;
  datePreset?: DashboardDatePreset | string;
  startDate?: string;
  endDate?: string;
  status?: string;
  department?: string;
  assignedStaffId?: string;
  source?: string;
  priority?: string;
  visitorType?: string;
  direction?: string;
  classId?: string;
  academicSessionId?: string;
  search?: string;
}

export interface FrontOfficeReportResult {
  reportType: FrontOfficeReportType;
  reportTitle: string;
  generatedAt: string;
  generatedBy: string;
  timeframe: {
    preset?: string;
    startDate?: string;
    endDate?: string;
  };
  totalRecords: number;
  summary: Record<string, any>;
  records: any[];
}
