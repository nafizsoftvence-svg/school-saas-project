/**
 * Sygmate School Management System
 * Core Type Definitions & Domain Models (Part 1 - Foundation & Architecture)
 */

export type UserRole = 'SUPER_ADMIN' | 'ADMIN' | 'TEACHER' | 'STUDENT' | 'GUARDIAN';

export type UserStatus =
  | 'active'
  | 'invited'
  | 'pending'
  | 'locked'
  | 'disabled'
  | 'suspended'
  | 'archived'
  | 'inactive'
  | 'ACTIVE'
  | 'INVITED'
  | 'PENDING'
  | 'LOCKED'
  | 'DISABLED'
  | 'SUSPENDED'
  | 'ARCHIVED'
  | 'INACTIVE';

export type Permission =
  // User Management
  | 'users.view'
  | 'users.create'
  | 'users.edit'
  | 'users.delete'
  // Teacher Specific Management
  | 'teacher.view'
  | 'teacher.create'
  | 'teacher.edit'
  | 'teacher.delete'
  | 'teacher.status'
  | 'teachers.view'
  | 'teachers.create'
  | 'teachers.edit'
  | 'teachers.delete'
  // Student Specific Management
  | 'student.view'
  | 'student.create'
  | 'student.edit'
  | 'student.delete'
  | 'student.status'
  | 'students.view'
  | 'students.create'
  | 'students.edit'
  | 'students.delete'
  // Guardian Specific Management
  | 'guardian.view'
  | 'guardian.create'
  | 'guardian.edit'
  | 'guardian.delete'
  | 'guardians.view'
  | 'guardians.create'
  | 'guardians.edit'
  | 'guardians.delete'
  | 'guardian.profile.view'
  | 'guardian.profile.edit'
  | 'guardian.children.view'
  | 'guardian.dashboard.view'
  | 'guardian.notifications.view'
  // Academic & Sessions
  | 'academic.view'
  | 'academic.manage'
  | 'academic_sessions.view'
  | 'academic_sessions.create'
  | 'academic_sessions.edit'
  | 'academic_sessions.activate'
  | 'academic_sessions.archive'
  | 'academic_sessions.delete'
  // Classes
  | 'classes.view'
  | 'classes.create'
  | 'classes.edit'
  | 'classes.archive'
  | 'classes.delete'
  // Sections
  | 'sections.view'
  | 'sections.create'
  | 'sections.edit'
  | 'sections.manage'
  | 'sections.archive'
  | 'sections.delete'
  // Subjects
  | 'subjects.view'
  | 'subjects.create'
  | 'subjects.edit'
  | 'subjects.assign'
  | 'subjects.manage'
  | 'subjects.archive'
  | 'subjects.delete'
  // Departments
  | 'departments.view'
  | 'departments.create'
  | 'departments.edit'
  | 'departments.archive'
  | 'departments.delete'
  // Teacher Portal Specific
  | 'teacher.classes.view'
  | 'teacher.subjects.view'
  | 'teacher.students.view'
  | 'teacher.attendance.manage'
  | 'teacher.academic.manage'
  | 'attendance.view'
  | 'attendance.manage'
  | 'attendance.edit'
  // Academic Activities (Part 3D)
  | 'homework.view'
  | 'homework.create'
  | 'homework.edit'
  | 'homework.archive'
  | 'homework.delete'
  | 'assignments.view'
  | 'assignments.create'
  | 'assignments.edit'
  | 'assignments.archive'
  | 'assignments.delete'
  | 'materials.view'
  | 'materials.create'
  | 'materials.edit'
  | 'materials.archive'
  | 'materials.delete'
  | 'announcements.view'
  | 'announcements.create'
  | 'announcements.edit'
  | 'announcements.archive'
  | 'announcements.delete'
  // Student Portal Specific
  | 'student.profile.view'
  | 'student.classes.view'
  | 'student.routine.view'
  | 'student.attendance.view'
  | 'student.examinations.view'
  | 'student.results.view'
  | 'student.progress.view'
  // System & Administration
  | 'settings.view'
  | 'settings.manage'
  | 'audit.view'
  | 'audit.export'
  | 'notifications.manage'
  // Examination Management (Part 6A-6E)
  | 'examinations.view'
  | 'examinations.create'
  | 'examinations.edit'
  | 'examinations.delete'
  | 'examinations.archive'
  | 'examinations.manage'
  | 'examinations.approve'
  | 'examinations.publish'
  // Fee Management (Part 7A)
  | 'fees.view'
  | 'fees.create'
  | 'fees.edit'
  | 'fees.delete'
  | 'fees.manage'
  | 'fees.structure.manage'
  | 'fees.types.manage'
  // Student Admission & Enrollment Management (Part 9B)
  | 'admissions.view'
  | 'admissions.create'
  | 'admissions.edit'
  | 'admissions.review'
  | 'admissions.approve'
  | 'admissions.reject'
  | 'admissions.enquiry'
  | 'admissions.enroll'
  // Student Promotion, Transfer & Status Management (Part 9E)
  | 'promotions.view'
  | 'promotions.manage'
  | 'promotions.approve'
  | 'transfers.view'
  | 'transfers.manage'
  | 'transfers.certificate'
  | 'student.status.manage'
  // Messaging & Communication Inbox (Part 11C)
  | 'messages.view'
  | 'messages.send'
  | 'messages.delete'
  | 'messages.moderate'
  // Staff & Human Resource Management Foundation (Part 12A & 12B)
  | 'staff.view'
  | 'staff.create'
  | 'staff.edit'
  | 'staff.delete'
  | 'staff.status'
  | 'staff.documents'
  | 'staff.departments'
  | 'staff.designations'
  | 'staff.attendance.view'
  | 'staff.attendance.manage'
  | 'staff.attendance.edit'
  | 'staff.schedules.view'
  | 'staff.schedules.manage'
  | 'staff.leaves.view'
  | 'staff.leaves.manage'
  | 'staff.leaves.review'
  | 'staff.leaves.policy.manage'
  | 'staff.leaves.adjust'
  | 'staff.leaves.carry_forward'
  | 'staff.leaves.balance.view'
  | 'staff.leaves.apply'
  | 'staff.leaves.reports.view'
  | 'staff.recruitment.view'
  | 'staff.recruitment.manage'
  | 'staff.recruitment.interview'
  | 'staff.recruitment.offer'
  | 'staff.recruitment.convert'
  | 'staff.onboarding.view'
  | 'staff.onboarding.manage'
  // Staff Performance Management (Part 12E)
  | 'staff.performance.view'
  | 'staff.performance.manage'
  | 'staff.performance.evaluate'
  | 'staff.performance.self'
  | 'staff.performance.override'
  | 'staff.performance.reports'
  // Staff HR Reports & Analytics (Part 12F)
  | 'staff.reports.view'
  | 'staff.reports.export'
  // Front Office & Visitor Management (Part 13A)
  | 'front_office.view'
  | 'front_office.create'
  | 'front_office.update'
  | 'front_office.delete'
  | 'front_office.manage_enquiries'
  | 'front_office.manage_visitors'
  | 'front_office.manage_calls'
  | 'front_office.manage_complaints'
  | 'front_office.manage_followups'
  | 'front_office.reports'
  | 'front_office.export'
  // Inventory & Asset Management Foundation (Part 14A & 14B)
  | 'inventory.view'
  | 'inventory.items.manage'
  | 'inventory.categories.manage'
  | 'inventory.units.manage'
  | 'inventory.locations.manage'
  | 'inventory.suppliers.manage'
  | 'assets.view'
  | 'assets.manage'
  | 'assets.status.manage'
  | 'inventory.settings.view'
  | 'inventory.stock.view'
  | 'inventory.stock.in'
  | 'inventory.stock.out'
  | 'inventory.stock.transfer'
  | 'inventory.stock.return'
  | 'inventory.stock.adjust'
  | 'inventory.stock.ledger'
  | 'inventory.stock.reports'
  // Procurement & Purchase Management (Part 14D)
  | 'procurement.requests.view'
  | 'procurement.requests.create'
  | 'procurement.requests.approve'
  | 'procurement.requests.reject'
  | 'procurement.orders.view'
  | 'procurement.orders.create'
  | 'procurement.orders.approve'
  | 'procurement.orders.reject'
  | 'procurement.orders.cancel'
  | 'procurement.receiving.view'
  | 'procurement.receiving.manage'
  | 'procurement.reports.view'
  // Issue, Return, Allocation & Department Workflow (Part 14E)
  | 'inventory.issues.view'
  | 'inventory.issues.create'
  | 'inventory.issues.approve'
  | 'inventory.issues.execute'
  | 'inventory.returns.view'
  | 'inventory.returns.create'
  | 'assets.allocation.view'
  | 'assets.allocation.manage'
  | 'assets.transfer.manage'
  | 'assets.return.manage'
  | 'assets.department.view'
  // Certificate & Document Management Foundation (Part 15A)
  | 'documents.view'
  | 'documents.upload'
  | 'documents.edit'
  | 'documents.verify'
  | 'documents.delete'
  | 'documents.archive'
  | 'documents.types.manage'
  | 'certificates.templates.view'
  | 'certificates.templates.manage'
  // Certificate Generation, Verification & Issuance (Part 15C & 15D)
  | 'certificates.view'
  | 'certificates.generate'
  | 'certificates.verify'
  | 'certificates.approve'
  | 'certificates.issue'
  | 'certificates.types.manage'
  | 'certificates.cancel'
  | 'certificates.revoke'
  | 'certificates.reissue'
  | 'certificates.download'
  | 'certificates.public_verify'
  // Staff, Teacher, Parent & School Document Management (Part 15E)
  | 'documents.requirements.manage'
  | 'teacher.documents.manage'
  | 'guardians.documents.manage'
  | 'school.documents.manage'
  // Multi-Tenant SaaS Platform Administration
  | 'platform.schools.view'
  | 'platform.schools.manage'
  | 'platform.subscriptions.manage'
  | 'platform.audit.view'
  | 'platform.system.manage';

export const ALL_PERMISSIONS: Permission[] = [
  'users.view',
  'users.create',
  'users.edit',
  'users.delete',
  'promotions.view',
  'promotions.manage',
  'promotions.approve',
  'transfers.view',
  'transfers.manage',
  'transfers.certificate',
  'student.status.manage',
  'admissions.view',
  'admissions.create',
  'admissions.edit',
  'admissions.review',
  'admissions.approve',
  'admissions.reject',
  'admissions.enquiry',
  'admissions.enroll',
  'teacher.view',
  'teacher.create',
  'teacher.edit',
  'teacher.delete',
  'teacher.status',
  'teachers.view',
  'teachers.create',
  'teachers.edit',
  'teachers.delete',
  'student.view',
  'student.create',
  'student.edit',
  'student.delete',
  'student.status',
  'students.view',
  'students.create',
  'students.edit',
  'students.delete',
  'guardian.view',
  'guardian.create',
  'guardian.edit',
  'guardian.delete',
  'guardians.view',
  'guardians.create',
  'guardians.edit',
  'guardians.delete',
  'guardian.profile.view',
  'guardian.profile.edit',
  'guardian.children.view',
  'guardian.dashboard.view',
  'guardian.notifications.view',
  'academic.view',
  'academic.manage',
  'academic_sessions.view',
  'academic_sessions.create',
  'academic_sessions.edit',
  'academic_sessions.activate',
  'academic_sessions.archive',
  'academic_sessions.delete',
  'classes.view',
  'classes.create',
  'classes.edit',
  'classes.archive',
  'classes.delete',
  'sections.view',
  'sections.create',
  'sections.edit',
  'sections.manage',
  'sections.archive',
  'sections.delete',
  'subjects.view',
  'subjects.create',
  'subjects.edit',
  'subjects.assign',
  'subjects.manage',
  'subjects.archive',
  'subjects.delete',
  'departments.view',
  'departments.create',
  'departments.edit',
  'departments.archive',
  'departments.delete',
  'teacher.classes.view',
  'teacher.subjects.view',
  'teacher.students.view',
  'teacher.attendance.manage',
  'student.profile.view',
  'student.classes.view',
  'student.routine.view',
  'student.attendance.view',
  'student.examinations.view',
  'student.results.view',
  'student.progress.view',
  'settings.view',
  'settings.manage',
  'audit.view',
  'audit.export',
  'notifications.manage',
  'examinations.view',
  'examinations.create',
  'examinations.edit',
  'examinations.delete',
  'examinations.archive',
  'examinations.manage',
  'examinations.approve',
  'examinations.publish',
  // Staff & HR Management (Part 12A, 12B & 12C)
  'staff.view',
  'staff.create',
  'staff.edit',
  'staff.delete',
  'staff.status',
  'staff.documents',
  'staff.departments',
  'staff.designations',
  'staff.attendance.view',
  'staff.attendance.manage',
  'staff.attendance.edit',
  'staff.schedules.view',
  'staff.schedules.manage',
  'staff.leaves.view',
  'staff.leaves.manage',
  'staff.leaves.review',
  'staff.leaves.policy.manage',
  'staff.leaves.adjust',
  'staff.leaves.carry_forward',
  'staff.leaves.balance.view',
  'staff.leaves.apply',
  'staff.leaves.reports.view',
  'staff.recruitment.view',
  'staff.recruitment.manage',
  'staff.recruitment.interview',
  'staff.recruitment.offer',
  'staff.recruitment.convert',
  'staff.onboarding.view',
  'staff.onboarding.manage',
  // Front Office & Visitor Management (Part 13A)
  'front_office.view',
  'front_office.create',
  'front_office.update',
  'front_office.delete',
  'front_office.manage_enquiries',
  'front_office.manage_visitors',
  'front_office.manage_calls',
  'front_office.manage_complaints',
  'front_office.manage_followups',
  'front_office.reports',
  'front_office.export',
  // Inventory & Asset Management Foundation (Part 14A)
  'inventory.view',
  'inventory.items.manage',
  'inventory.categories.manage',
  'inventory.units.manage',
  'inventory.locations.manage',
  'inventory.suppliers.manage',
  'assets.view',
  'assets.manage',
  'assets.status.manage',
  'inventory.settings.view',
  'inventory.stock.view',
  'inventory.stock.in',
  'inventory.stock.out',
  'inventory.stock.transfer',
  'inventory.stock.return',
  'inventory.stock.adjust',
  'inventory.stock.ledger',
  'inventory.stock.reports',
  // Procurement (Part 14D)
  'procurement.requests.view',
  'procurement.requests.create',
  'procurement.requests.approve',
  'procurement.requests.reject',
  'procurement.orders.view',
  'procurement.orders.create',
  'procurement.orders.approve',
  'procurement.orders.reject',
  'procurement.orders.cancel',
  'procurement.receiving.view',
  'procurement.receiving.manage',
  'procurement.reports.view',
  // Issue, Return, Allocation & Department Workflow (Part 14E)
  'inventory.issues.view',
  'inventory.issues.create',
  'inventory.issues.approve',
  'inventory.issues.execute',
  'inventory.returns.view',
  'inventory.returns.create',
  'assets.allocation.view',
  'assets.allocation.manage',
  'assets.transfer.manage',
  'assets.return.manage',
  'assets.department.view',
  // Certificate & Document Management Foundation (Part 15A)
  'documents.view',
  'documents.upload',
  'documents.edit',
  'documents.verify',
  'documents.delete',
  'documents.archive',
  'documents.types.manage',
  'certificates.templates.view',
  'certificates.templates.manage',
  // Certificate Generation, Verification & Issuance (Part 15C & 15D)
  'certificates.view',
  'certificates.generate',
  'certificates.verify',
  'certificates.approve',
  'certificates.issue',
  'certificates.types.manage',
  'certificates.cancel',
  'certificates.revoke',
  'certificates.reissue',
  'certificates.download',
  'certificates.public_verify',
  // Staff, Teacher, Parent & School Document Management (Part 15E)
  'documents.requirements.manage',
  'teacher.documents.manage',
  'guardians.documents.manage',
  'school.documents.manage',
  'platform.schools.view',
  'platform.schools.manage',
  'platform.subscriptions.manage',
  'platform.audit.view',
  'platform.system.manage'
];

export type SchoolSubscriptionPlan = 'starter' | 'growth' | 'enterprise' | 'trial';
export type SchoolSubscriptionStatus = 'active' | 'trial' | 'past_due' | 'canceled';

export interface SchoolMembership {
  id: string;
  userId: string;
  schoolId: string;
  role: UserRole;
  isDefault?: boolean;
  status: 'active' | 'inactive' | 'suspended';
  createdAt: string;
  updatedAt?: string;
}

export interface School {
  id: string;
  name: string;
  code: string;
  slug?: string;
  status: 'active' | 'suspended' | 'trial' | 'pending';
  plan: SchoolSubscriptionPlan;
  subscriptionStatus: SchoolSubscriptionStatus;
  maxStudents: number;
  maxStaff: number;
  contactEmail: string;
  contactPhone: string;
  address: string;
  city?: string;
  state?: string;
  country?: string;
  website?: string;
  settings?: SchoolSettings;
  createdAt: string;
  updatedAt?: string;
}

export interface TenantContext {
  schoolId: string;
  school: School;
  membership?: SchoolMembership;
  role: UserRole;
  isPlatformAdmin: boolean;
}

export interface User {
  id: string;
  name: string;
  firstName?: string;
  lastName?: string;
  email: string;
  username: string;
  role: UserRole;
  status: UserStatus;
  schoolId?: string;
  memberships?: SchoolMembership[];
  isPlatformAdmin?: boolean;
  avatarUrl?: string;
  phoneNumber?: string;
  createdAt: string;
  updatedAt: string;
  lastLoginAt?: string;
}

export type UserAccount = User;

export interface ParentStudentRelationship {
  id: string;
  guardianId: string;
  studentId: string;
  relationshipType: 'Father' | 'Mother' | 'Legal Guardian' | 'Foster Parent' | 'Step-Parent' | 'Grandparent' | 'Sponsor' | 'Other' | string;
  isPrimaryGuardian: boolean;
  isSecondaryGuardian: boolean;
  isEmergencyContact: boolean;
  isAuthorizedAcademic: boolean;
  isAuthorizedAttendance: boolean;
  isAuthorizedFinancial: boolean;
  isAuthorizedCommunication: boolean;
  isPickupAuthorized: boolean;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Family {
  id: string;
  familyCode: string;
  familyName: string;
  primaryContactName: string;
  primaryPhone: string;
  primaryEmail?: string;
  emergencyContactName?: string;
  emergencyContactPhone?: string;
  billingPreference?: 'Consolidated' | 'Per-Child' | 'Custom' | string;
  address: string;
  city?: string;
  state?: string;
  country?: string;
  postalCode?: string;
  guardianIds: string[];
  studentIds: string[];
  guardians?: Guardian[];
  students?: Array<{
    id: string;
    name: string;
    admissionNumber: string;
    className?: string;
    sectionName?: string;
    rollNumber?: string;
    avatarUrl?: string;
    status?: string;
    sessionName?: string;
  }>;
  status: 'active' | 'inactive' | 'archived';
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Guardian {
  id: string;
  userId?: string;
  name: string;
  firstName?: string;
  lastName?: string;
  preferredName?: string;
  gender?: 'male' | 'female' | 'other' | string;
  dateOfBirth?: string;
  avatarUrl?: string;
  relationship: 'Father' | 'Mother' | 'Guardian' | 'Legal Guardian' | 'Foster Parent' | 'Grandparent' | 'Sponsor' | 'Other' | string;
  phone: string;
  secondaryPhone?: string;
  email: string;
  whatsapp?: string;
  preferredContactMethod?: 'phone' | 'email' | 'whatsapp' | 'sms' | string;
  address: string;
  permanentAddress?: string;
  city?: string;
  state?: string;
  country?: string;
  postalCode?: string;
  occupation?: string;
  nationality?: string;
  idDocumentType?: 'National ID' | 'Passport' | 'Driving License' | 'Other' | string;
  idDocumentNumber?: string;
  emergencyContact?: string;
  isPrimaryGuardian?: boolean;
  isSecondaryGuardian?: boolean;
  familyId?: string;
  familyRole?: string;
  family?: Family;
  studentIds: string[];
  relationships?: ParentStudentRelationship[];
  students?: Array<{
    id: string;
    name: string;
    admissionNumber: string;
    className?: string;
    sectionName?: string;
    rollNumber?: string;
    avatarUrl?: string;
    status?: string;
    sessionName?: string;
    relationshipType?: string;
    isPrimary?: boolean;
    isSecondary?: boolean;
    isEmergencyContact?: boolean;
    isAuthorizedAcademic?: boolean;
    isAuthorizedAttendance?: boolean;
    isAuthorizedFinancial?: boolean;
    isAuthorizedCommunication?: boolean;
    isPickupAuthorized?: boolean;
  }>;
  studentCount?: number;
  status?: 'active' | 'inactive' | 'pending' | 'archived' | string;
  hasAccount?: boolean;
  accountStatus?: string;
  username?: string;
  userEmail?: string;
  userLastLoginAt?: string;
  isLocked?: boolean;
  isDisabled?: boolean;
  activeInvitationToken?: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface TeacherProfile {
  id: string;
  userId: string;
  employeeCode: string; // Teacher ID (e.g. EMP-T-1004)
  firstName?: string;
  lastName?: string;
  avatarUrl?: string;
  email?: string;
  phone?: string;
  contactNumber: string;
  emergencyContact?: string;
  dateOfBirth?: string;
  gender?: 'male' | 'female' | 'other' | string;
  address: string;
  departmentId?: string;
  department: string;
  departmentName?: string;
  designation: string;
  qualification: string;
  specialization?: string;
  joiningDate: string;
  employmentStatus?: 'full_time' | 'part_time' | 'contract' | 'probation' | 'visiting' | string;
  status: 'active' | 'on_leave' | 'inactive' | 'suspended' | 'ACTIVE' | string;
  accountStatus?: UserStatus;
  assignedClassIds: string[];
  assignedSubjectIds: string[];
  assignedClasses?: SchoolClass[];
  assignedSubjects?: Subject[];
  subjects?: string[];
  createdAt?: string;
  updatedAt?: string;
}

export type Teacher = TeacherProfile & {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  status: string;
  user?: {
    id: string;
    name: string;
    email: string;
    status: string;
  } | null;
};

export type StudentDocumentCategory =
  | 'IDENTIFICATION'
  | 'ACADEMIC'
  | 'MEDICAL'
  | 'LEGAL_GUARDIANSHIP'
  | 'IDENTITY_PHOTOS'
  | 'OTHER';

export type StudentDocumentVerificationStatus =
  | 'PENDING_VERIFICATION'
  | 'VERIFIED'
  | 'REJECTED'
  | 'EXPIRED';

export interface StudentDocument {
  id: string;
  studentId?: string;
  studentName?: string;
  admissionNumber?: string;
  className?: string;
  sectionName?: string;
  name: string;
  title?: string;
  type: string;
  category?: StudentDocumentCategory | string;
  documentNumber?: string;
  issuingAuthority?: string;
  issueDate?: string;
  expiryDate?: string;
  url: string;
  fileUrl?: string;
  fileName?: string;
  fileSize?: string;
  size?: string;
  verificationStatus?: StudentDocumentVerificationStatus | string;
  verifiedBy?: string;
  verifiedByName?: string;
  verifiedAt?: string;
  verificationRemarks?: string;
  rejectionReason?: string;
  uploadedAt: string;
  uploadedBy?: string;
  uploadedByRole?: string;
  isMandatory?: boolean;
}

export interface StudentProfile {
  id: string;
  userId: string;
  admissionNumber: string; // Student ID (e.g. ADM-2026-0842)
  rollNumber: string;
  firstName?: string;
  middleName?: string;
  lastName?: string;
  fullName?: string;
  avatarUrl?: string;
  dateOfBirth: string;
  gender: 'male' | 'female' | 'other' | string;
  bloodGroup?: string;
  nationality?: string;
  religion?: string;
  category?: string;
  previousSchool?: string;
  previousClass?: string;
  previousTcNumber?: string;
  previousMarksPercentage?: number;
  transferCertificateNumber?: string;
  email?: string;
  phone?: string;
  alternativePhone?: string;
  address: string;
  presentAddress?: string;
  permanentAddress?: string;
  city?: string;
  postalCode?: string;
  emergencyContact?: string;
  admissionDate?: string;
  enrollmentDate: string;
  enrollmentStatus?: 'active' | 'graduated' | 'transferred' | 'suspended' | 'inactive' | 'withdrawn' | 'archived' | string;
  status: 'active' | 'graduated' | 'transferred' | 'suspended' | 'inactive' | 'withdrawn' | 'archived' | 'ACTIVE' | string;
  accountStatus?: UserStatus;

  // Academic Relations
  academicSessionId: string;
  academicSessionName?: string;
  classId: string;
  className?: string;
  sectionId: string;
  sectionName?: string;

  // Guardian Relations
  guardianId?: string;
  guardianName: string;
  guardianRelation: string;
  guardianPhone: string;
  guardianEmail: string;
  guardianAddress?: string;
  guardianOccupation?: string;
  guardian?: Guardian;

  // Extended Parent / Family Details
  familyId?: string;
  fatherName?: string;
  fatherPhone?: string;
  fatherEmail?: string;
  fatherOccupation?: string;
  motherName?: string;
  motherPhone?: string;
  motherEmail?: string;
  motherOccupation?: string;
  secondaryGuardianId?: string;
  secondaryGuardianName?: string;
  secondaryGuardianRelation?: string;
  secondaryGuardianPhone?: string;
  secondaryGuardianEmail?: string;
  relationships?: ParentStudentRelationship[];

  // Profile Attachments
  documents?: StudentDocument[];

  createdAt?: string;
  updatedAt?: string;
}

export type Student = StudentProfile & {
  firstName: string;
  lastName: string;
  email: string;
  className: string;
  sectionName: string;
  status: string;
  user?: {
    id: string;
    name: string;
    email: string;
    status: string;
    avatarUrl?: string;
  } | null;
};

export interface StudentMasterDossier extends StudentProfile {
  firstName: string;
  lastName: string;
  fullName: string;
  email: string;
  phone: string;
  className: string;
  sectionName: string;
  academicSessionName: string;
  user?: {
    id: string;
    name: string;
    email: string;
    status: string;
    avatarUrl?: string;
  } | null;
  enrolledSubjects: Array<{
    id: string;
    name: string;
    code: string;
    type: string;
    credits: number;
    teacherName: string;
  }>;
  siblings: Array<{
    id: string;
    name: string;
    admissionNumber: string;
    className: string;
    status: string;
    avatarUrl?: string;
  }>;
  attendanceSummary: {
    totalDays: number;
    presentDays: number;
    absentDays: number;
    lateDays: number;
    halfDays: number;
    leaveDays: number;
    percentage: string;
    standing: string;
    recentRecords: Array<{
      date: string;
      status: string;
      remarks?: string;
      subjectName?: string;
    }>;
  };
  examinationSummary: {
    totalExams: number;
    cumulativeGPA: number;
    overallGrade: string;
    passedExams: number;
    failedExams: number;
    recentResults: Array<{
      examId: string;
      examName: string;
      gpa: number;
      overallGrade: string;
      overallPercentage: number;
      resultStatus: string;
      publishedDate?: string;
    }>;
  };
  feeSummary: {
    totalInvoiced: number;
    totalPaid: number;
    totalDue: number;
    status: string;
    recentFees: Array<{
      id: string;
      feeTitle: string;
      amount: number;
      paidAmount: number;
      dueAmount: number;
      status: string;
      dueDate?: string;
    }>;
  };
  documents: StudentDocument[];
  auditTrail: Array<{
    id: string;
    action: string;
    userName: string;
    userRole: string;
    details: string;
    timestamp: string;
  }>;
}

// =========================================================================
// PART 9B: STUDENT ADMISSION & ENROLLMENT MANAGEMENT TYPES
// =========================================================================

export type AdmissionEnquiryStatus =
  | 'NEW'
  | 'CONTACTED'
  | 'FOLLOW_UP_REQUIRED'
  | 'FOLLOW_UP_IN_PROGRESS'
  | 'FOLLOW_UP_COMPLETED'
  | 'INTERESTED'
  | 'APPLICATION_STARTED'
  | 'NOT_INTERESTED'
  | 'QUALIFIED'
  | 'CONVERTED'
  | 'LOST'
  | 'CLOSED';
export type AdmissionEnquirySource = 'WALK_IN' | 'WEBSITE' | 'PHONE' | 'REFERRAL' | 'SOCIAL_MEDIA' | 'EMAIL' | 'EXPO_EVENT' | 'OTHER';

export interface AdmissionEnquiry {
  id: string;
  enquiryNumber: string; // e.g. ENQ-2026-0001
  enquiryDate?: string;
  studentName: string;
  dateOfBirth?: string;
  gender?: 'male' | 'female' | 'other' | string;
  applyingClassId: string;
  applyingClassName: string;
  academicSessionId: string;
  academicSessionName: string;
  parentName: string;
  relationship?: string;
  phone: string;
  alternatePhone?: string;
  email?: string;
  address?: string;
  previousSchool?: string;
  source: AdmissionEnquirySource;
  enquiryType?: string;
  assignedStaffId?: string;
  assignedStaffName?: string;
  assignmentDate?: string;
  assignedById?: string;
  assignedByName?: string;
  assignmentHistory?: import('./front-office.types.js').EnquiryAssignmentHistory[];
  status: AdmissionEnquiryStatus;
  priority?: import('./front-office.types.js').EnquiryPriority;
  followUpDate?: string;
  followUpTime?: string;
  followUpStatus?: string;
  statusHistory?: import('./front-office.types.js').EnquiryStatusHistory[];
  notes?: string;
  convertedAdmissionId?: string;
  convertedApplicationNumber?: string;
  convertedStudentId?: string;
  conversionDate?: string;
  convertedBy?: string;
  convertedById?: string;
  createdById?: string;
  createdByName?: string;
  createdAt: string;
  updatedAt: string;
  followUps?: import('./front-office.types.js').EnquiryFollowUp[];
}

export type AdmissionApplicationStatus =
  | 'DRAFT'
  | 'SUBMITTED'
  | 'UNDER_REVIEW'
  | 'APPROVED'
  | 'REJECTED'
  | 'CANCELLED'
  | 'ADMITTED'
  | 'ENROLLED'
  | 'ACTIVE';

export interface AdmissionDocument {
  id: string;
  name: string;
  type: string;
  url: string;
  size: string;
  category: 'BIRTH_CERTIFICATE' | 'PREVIOUS_TRANSCRIPT' | 'TRANSFER_CERTIFICATE' | 'PASSPORT_PHOTO' | 'MEDICAL_RECORD' | 'OTHER';
  uploadedAt: string;
}

export interface AdmissionStatusHistory {
  fromStatus: string;
  toStatus: string;
  changedBy: string;
  changedAt: string;
  reason?: string;
}

export interface AdmissionApplication {
  id: string;
  applicationNumber: string; // e.g. APP-2026-0001
  enquiryId?: string;
  enquiryNumber?: string;

  // Student Demographics & Information
  firstName: string;
  middleName?: string;
  lastName: string;
  fullName: string;
  dateOfBirth: string;
  gender: 'male' | 'female' | 'other' | string;
  bloodGroup?: string;
  nationality: string;
  religion?: string;
  category?: string;
  email?: string;
  phone?: string;
  address: string;
  presentAddress?: string;
  permanentAddress?: string;
  city?: string;
  postalCode?: string;
  avatarUrl?: string;

  // Prior Academic Record
  previousSchoolName?: string;
  previousClass?: string;
  previousMarksPercentage?: number;
  previousSchoolBoard?: string;
  transferCertificateNumber?: string;

  // Parent / Guardian Details
  guardianMode: 'existing' | 'new';
  guardianId?: string;
  guardianName: string;
  guardianRelation: string;
  guardianPhone: string;
  guardianEmail: string;
  guardianAddress: string;
  guardianOccupation?: string;
  emergencyContact: string;
  fatherName?: string;
  fatherPhone?: string;
  fatherEmail?: string;
  fatherOccupation?: string;
  motherName?: string;
  motherPhone?: string;
  motherEmail?: string;
  motherOccupation?: string;
  secondaryGuardianName?: string;
  secondaryGuardianRelation?: string;
  secondaryGuardianPhone?: string;
  secondaryGuardianEmail?: string;

  // Academic Placement Choices
  academicSessionId: string;
  academicSessionName: string;
  classId: string;
  className: string;
  sectionId: string;
  sectionName: string;
  preferredRollNumber?: string;
  assignedRollNumber?: string;
  applicationDate: string;
  admissionDate: string;
  admissionFeeStructureId?: string;
  assignAdmissionFee: boolean;

  // Uploaded Application Documents
  documents: AdmissionDocument[];

  // Lifecycle & Review Records
  status: AdmissionApplicationStatus;
  reviewRemarks?: string;
  rejectionReason?: string;
  reviewedBy?: string;
  reviewedAt?: string;
  approvedBy?: string;
  approvedAt?: string;
  admittedStudentId?: string;
  admittedAdmissionNumber?: string;
  enrollmentId?: string;
  statusHistory: AdmissionStatusHistory[];

  createdAt: string;
  updatedAt: string;
}

export type AcademicEnrollmentStatus =
  | 'active'
  | 'transferred'
  | 'suspended'
  | 'withdrawn'
  | 'graduated'
  | 'promoted'
  | 'retained'
  | 'completed'
  | 'inactive';

export interface AcademicEnrollment {
  id: string;
  enrollmentNumber: string; // e.g. ENR-2026-0001
  studentId: string;
  studentAdmissionNumber: string;
  studentName: string;
  academicSessionId: string;
  academicSessionName: string;
  classId: string;
  className: string;
  sectionId: string;
  sectionName: string;
  rollNumber: string;
  enrollmentDate: string;
  status: AcademicEnrollmentStatus;
  admissionApplicationId?: string;
  promotionRecordId?: string;
  transferRecordId?: string;
  completionDate?: string;
  resultSummary?: {
    gpa?: number;
    overallGrade?: string;
    percentage?: number;
    passed?: boolean;
    attendancePercentage?: number;
  };
  promotedToSessionId?: string;
  promotedToClassId?: string;
  promotedToSectionId?: string;
  remarks?: string;
  createdAt: string;
  updatedAt: string;
}

export interface AdmissionNumberConfig {
  prefix: string;
  includeYear: boolean;
  sequencePadding: number;
  currentSequence: number;
  autoAssignRoll: boolean;
}

export interface DuplicateStudentMatch {
  type: 'ADMISSION_NUMBER' | 'EMAIL' | 'NAME_DOB' | 'PARENT_PHONE' | 'PREVIOUS_TC';
  matchedEntity: 'STUDENT' | 'APPLICATION';
  entityId: string;
  name: string;
  identifier: string;
  className?: string;
  details: string;
}

export interface DuplicateStudentCheckResult {
  isDuplicate: boolean;
  matches: DuplicateStudentMatch[];
}

export interface TeacherSubjectBrief {
  id: string;
  name: string;
  code: string;
  type: string;
  credits: number;
}

export interface TeacherSectionInfo {
  id: string;
  name: string;
  code?: string;
  classId: string;
  className?: string;
  roomNumber: string;
  capacity: number;
  studentCount: number;
  academicSessionName: string;
  isClassTeacher: boolean;
  status?: string;
  subjects?: TeacherSubjectBrief[];
}

export interface TeacherClassInfo {
  id: string;
  name: string;
  code: string;
  numericGrade: number;
  status?: string;
  academicSessionName: string;
  sections: TeacherSectionInfo[];
  subjects: TeacherSubjectBrief[];
  totalSections: number;
  totalStudents: number;
  description?: string;
}

export interface TeacherStudentInfo {
  id: string;
  userId: string;
  admissionNumber: string;
  rollNumber: string;
  firstName: string;
  lastName: string;
  email: string;
  avatarUrl?: string;
  classId: string;
  className: string;
  sectionId: string;
  sectionName: string;
  academicSessionId: string;
  academicSessionName: string;
  dateOfBirth: string;
  gender: string;
  bloodGroup?: string;
  address?: string;
  guardianName: string;
  guardianRelation: string;
  guardianPhone: string;
  guardianEmail: string;
  enrollmentStatus: string;
  status: string;
  enrollmentDate?: string;
  admissionDate?: string;
  createdAt?: string;
}

export interface TeacherStudentsResponse {
  students: TeacherStudentInfo[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
}

export interface SchoolSettings {
  id: string;
  name?: string;
  schoolName: string;
  code?: string;
  schoolCode: string;
  schoolType?: 'Public' | 'Private' | 'International' | 'Charter' | 'Boarding' | 'Vocational' | string;
  tagline?: string;
  logoUrl?: string;
  faviconUrl?: string;
  principalName?: string;
  principalEmail?: string;
  email?: string;
  contactEmail: string;
  supportEmail?: string;
  phone?: string;
  contactPhone: string;
  secondaryPhone?: string;
  address: string;
  city?: string;
  state?: string;
  postalCode?: string;
  country?: string;
  website?: string;
  timezone: string;
  currency: string;
  currencySymbol: string;
  dateFormat?: 'DD/MM/YYYY' | 'MM/DD/YYYY' | 'YYYY-MM-DD' | 'D MMM YYYY' | string;
  timeFormat?: '12-hour' | '24-hour';
  weekStartDay?: 'Monday' | 'Sunday' | 'Saturday';
  academicSessionId: string;
  currentTerm: string;
  affiliationNumber?: string;
  establishedYear?: number;
  foundedYear?: number;
}

export interface Department {
  id: string;
  name: string;
  code: string;
  description?: string;
  category?: 'academic' | 'non_academic' | 'administrative' | 'support' | string;
  location?: string;
  budgetCode?: string;
  headOfDepartmentId?: string;
  headOfDepartmentName?: string;
  subjectCount?: number;
  teacherCount?: number;
  staffCount?: number;
  status?: 'active' | 'inactive' | 'archived' | string;
  createdAt?: string;
  updatedAt?: string;
}

export interface AcademicSession {
  id: string;
  name?: string;
  sessionName: string; // e.g. "2026-2027"
  startDate: string;
  endDate: string;
  isActive: boolean;
  isCurrent?: boolean;
  isArchived?: boolean;
  status?: 'active' | 'upcoming' | 'completed' | 'archived' | string;
  description?: string;
  terms: string[];
  createdAt?: string;
  updatedAt?: string;
}

export interface SchoolClass {
  id: string;
  name: string; // e.g. "Grade 10", "Grade 11"
  code: string; // e.g. "G10"
  numericGrade: number;
  displayOrder?: number;
  sectionIds: string[];
  sections?: SectionWithTeacher[];
  description?: string;
  status?: 'active' | 'inactive' | 'archived' | string;
  createdAt?: string;
  updatedAt?: string;
}

export interface Section {
  id: string;
  name: string; // e.g. "Section A", "Section B"
  code?: string;
  classId: string;
  className?: string;
  roomNumber: string;
  capacity: number;
  studentCount?: number;
  classTeacherId?: string;
  classTeacherName?: string;
  description?: string;
  status?: 'active' | 'inactive' | 'archived' | string;
  createdAt?: string;
  updatedAt?: string;
}

export interface SectionWithTeacher extends Section {
  studentCount: number;
  classTeacherName?: string;
}

export interface Subject {
  id: string;
  name: string; // e.g. "Advanced Mathematics"
  code: string; // e.g. "MTH-101"
  classId?: string;
  classIds?: string[];
  className?: string;
  classNames?: string[];
  departmentId?: string;
  departmentName?: string;
  teacherId?: string;
  teacherName?: string;
  credits: number;
  type: 'core' | 'elective' | 'lab' | 'practical' | 'CORE' | 'ELECTIVE' | 'LAB' | 'PRACTICAL' | string;
  displayOrder?: number;
  description?: string;
  status?: 'active' | 'inactive' | 'archived' | string;
  createdAt?: string;
  updatedAt?: string;
}

export interface AuditLog {
  id: string;
  userId: string;
  userName?: string;
  userRole: UserRole;
  action: string;
  entity?: string;
  entityType?: string;
  entityId?: string;
  performedBy?: string;
  details: string;
  ipAddress: string;
  timestamp: string;
  metadata?: any;
}

export type AttendanceStatus = 'PRESENT' | 'ABSENT' | 'LATE' | 'HALF_DAY' | 'EXCUSED' | 'LEAVE';

export interface AttendanceCorrectionHistoryItem {
  previousStatus: AttendanceStatus;
  newStatus: AttendanceStatus;
  changedByUserId: string;
  changedByUserName: string;
  changedAt: string;
  reason: string;
}

export interface AttendanceRecord {
  id: string;
  studentId: string;
  userId: string;
  studentName?: string;
  admissionNumber?: string;
  rollNumber?: string;
  avatarUrl?: string;
  classId: string;
  className?: string;
  sectionId: string;
  sectionName?: string;
  subjectId?: string;
  subjectName?: string;
  academicSessionId: string;
  academicSessionName?: string;
  date: string; // 'YYYY-MM-DD'
  status: AttendanceStatus;
  remarks?: string;
  submissionStatus?: 'DRAFT' | 'SUBMITTED' | 'FINALIZED';
  isDraft?: boolean;
  isOverridden?: boolean;
  overrideReason?: string;
  correctionHistory?: AttendanceCorrectionHistoryItem[];
  recordedByTeacherId: string;
  recordedByTeacherName: string;
  updatedByTeacherId?: string;
  updatedByTeacherName?: string;
  createdAt: string;
  updatedAt: string;
  isDeleted?: boolean;
}

export interface AttendanceSheetStudent {
  studentId: string;
  userId: string;
  admissionNumber: string;
  rollNumber: string;
  firstName: string;
  lastName: string;
  fullName: string;
  avatarUrl?: string;
  gender: string;
  status: AttendanceStatus;
  remarks?: string;
  existingRecordId?: string;
}

export interface AttendanceSheetData {
  classId: string;
  className: string;
  sectionId: string;
  sectionName: string;
  subjectId?: string;
  subjectName?: string;
  academicSessionId: string;
  academicSessionName: string;
  date: string;
  isExisting: boolean;
  recordedByTeacherName?: string;
  lastUpdated?: string;
  students: AttendanceSheetStudent[];
  summary: {
    total: number;
    present: number;
    absent: number;
    late: number;
    halfDay?: number;
    excused: number;
    attendanceRate: number;
  };
}

export interface AttendanceFilterParams {
  classId?: string;
  sectionId?: string;
  subjectId?: string;
  studentId?: string;
  date?: string;
  startDate?: string;
  endDate?: string;
  status?: AttendanceStatus | 'ALL';
  academicSessionId?: string;
  submissionStatus?: 'ALL' | 'DRAFT' | 'SUBMITTED' | 'FINALIZED';
  search?: string;
  page?: number;
  limit?: number;
}

export interface AttendanceSummaryStats {
  totalRecords: number;
  presentCount: number;
  absentCount: number;
  lateCount: number;
  halfDayCount?: number;
  excusedCount: number;
  attendancePercentage: number;
  classBreakdown?: Array<{
    classId: string;
    className: string;
    sectionName: string;
    total: number;
    present: number;
    absent: number;
    late?: number;
    halfDay?: number;
    rate: number;
  }>;
}

export interface StudentAttendanceHistoryData {
  student: TeacherStudentInfo;
  stats: {
    totalSessions: number;
    present: number;
    absent: number;
    late: number;
    halfDay?: number;
    excused: number;
    percentage: number;
  };
  summary?: {
    totalSessions: number;
    presentCount: number;
    absentCount: number;
    lateCount: number;
    halfDayCount: number;
    excusedCount: number;
    attendancePercentage: number;
  };
  records: AttendanceRecord[];
}

export interface NotificationItem {
  id: string;
  userId?: string;
  roleTarget?: UserRole | 'ALL';
  title: string;
  message: string;
  category?: 'system' | 'academic' | 'security' | 'general' | 'fee' | 'attendance' | 'exam';
  type?: string;
  isRead: boolean;
  link?: string;
  studentId?: string;
  metadata?: any;
  createdAt: string;
}

export type Notification = NotificationItem;

export interface AuthSession {
  token: string;
  user: User;
  teacherProfile?: TeacherProfile;
  studentProfile?: StudentProfile;
  guardianProfile?: Guardian;
  permissions: Permission[];
  expiresAt: string;
  schoolContext?: {
    id: string;
    name: string;
    code: string;
    plan?: string;
    status?: string;
  };
  availableSchools?: Array<{
    id: string;
    name: string;
    code: string;
    role: UserRole;
  }>;
}

export interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  total?: number;
  stats?: any;
  message?: string;
  error?: string;
  code?: string;
  unreadCount?: number;
  pagination?: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
  [key: string]: any;
}

export interface SuperAdminDashboardData {
  metrics: {
    totalStudents: number;
    activeStudents: number;
    inactiveStudents: number;
    totalTeachers: number;
    activeTeachers: number;
    inactiveTeachers: number;
    totalClasses: number;
    totalSections: number;
    totalSubjects: number;
    currentAcademicSession: string;
    schoolName: string;
    schoolCode: string;
    schoolType?: string;
    systemHealth: string;
    recentAuditCount: number;
    isProfileComplete: boolean;
  };
  recentAuditLogs: AuditLog[];
  activeSession: AcademicSession | null;
  schoolSettings?: SchoolSettings;
}

export interface TeacherDashboardData {
  teacher: Teacher;
  metrics: {
    totalAssignedClasses: number;
    totalAssignedSections: number;
    totalAssignedSubjects: number;
    totalStudentsUnderClasses: number;
    myClassesCount: number;
    mySubjectsCount: number;
    totalStudentsTaught: number;
    todayAttendanceRate?: string;
  };
  assignedClasses: Array<{
    id: string;
    className: string;
    sectionName: string;
    roomNumber: string;
    studentCount: number;
  }>;
  assignedSubjects: Array<{
    id: string;
    name: string;
    code: string;
    type: string;
    credits: number;
    departmentName?: string;
    classNames?: string[];
  }>;
  todayClasses: Array<{
    id: string;
    subjectName: string;
    subjectCode: string;
    className: string;
    sectionName: string;
    roomNumber: string;
    timeSlot: string;
  }>;
  recentNotifications: NotificationItem[];
}

export interface StudentDashboardData {
  student: Student;
  metrics: {
    academicSession: string;
    academicSessionId?: string;
    totalSubjects: number;
    attendancePercentage: string;
    attendanceRate?: number;
    attendancePresentDays?: number;
    attendanceTotalDays?: number;
    attendanceLateDays?: number;
    attendanceAbsentDays?: number;
    hasAttendanceData: boolean;
    pendingHomeworkCount?: number;
    activeAssignmentsCount?: number;
    unreadNotificationsCount?: number;
  };
  enrolledSubjects: Array<{
    id: string;
    name: string;
    code: string;
    credits: number;
    teacherName: string;
    departmentName?: string;
    type?: string;
  }>;
  upcomingHomework?: Homework[];
  upcomingAssignments?: Assignment[];
  recentAnnouncements?: ClassAnnouncement[];
  recentNotifications?: NotificationItem[];
}

export interface DashboardStats {
  superAdmin?: SuperAdminDashboardData['metrics'];
  teacher?: TeacherDashboardData['metrics'];
  student?: StudentDashboardData['metrics'];
}

// ==========================================
// Part 3D: Academic Activities Interfaces
// ==========================================

export type ActivityStatus = 'draft' | 'published' | 'closed' | 'archived';

export interface Homework {
  id: string;
  title: string;
  description: string;
  classId: string;
  className: string;
  sectionId: string;
  sectionName: string;
  subjectId: string;
  subjectName: string;
  academicSessionId?: string;
  academicSessionName?: string;
  dueDate: string; // YYYY-MM-DD
  assignedDate: string; // YYYY-MM-DD
  attachmentUrl?: string;
  attachmentName?: string;
  attachmentSize?: string;
  attachmentType?: string;
  status: 'draft' | 'published' | 'archived';
  teacherId: string;
  teacherUserId: string;
  teacherName: string;
  createdAt: string;
  updatedAt: string;
}

export interface HomeworkFilterParams {
  classId?: string;
  sectionId?: string;
  subjectId?: string;
  status?: string;
  dueDate?: string;
  search?: string;
  page?: number;
  limit?: number;
}

export interface Assignment {
  id: string;
  title: string;
  description: string;
  subjectId: string;
  subjectName: string;
  classId: string;
  className: string;
  sectionId: string;
  sectionName: string;
  academicSessionId?: string;
  academicSessionName?: string;
  startDate: string; // YYYY-MM-DD
  dueDate: string; // YYYY-MM-DD
  totalMarks?: number;
  attachmentUrl?: string;
  attachmentName?: string;
  attachmentSize?: string;
  attachmentType?: string;
  status: 'draft' | 'published' | 'closed' | 'archived';
  teacherId: string;
  teacherUserId: string;
  teacherName: string;
  createdAt: string;
  updatedAt: string;
}

export interface AssignmentFilterParams {
  classId?: string;
  sectionId?: string;
  subjectId?: string;
  status?: string;
  startDate?: string;
  dueDate?: string;
  search?: string;
  page?: number;
  limit?: number;
}

export interface StudyMaterial {
  id: string;
  title: string;
  description: string;
  subjectId: string;
  subjectName: string;
  classId: string;
  className: string;
  sectionId: string; // 'ALL' or specific section id
  sectionName: string; // 'All Sections' or specific section name
  academicSessionId?: string;
  academicSessionName?: string;
  fileUrl: string;
  fileName: string;
  fileSize: string; // e.g. "3.2 MB"
  fileSizeBytes?: number;
  fileType: string; // 'pdf' | 'doc' | 'docx' | 'ppt' | 'pptx' | 'xls' | 'xlsx' | 'txt' | 'image' | 'video' | 'zip' | string
  uploadDate: string; // YYYY-MM-DD
  status: 'active' | 'archived' | 'draft';
  teacherId: string;
  teacherUserId: string;
  teacherName: string;
  createdAt: string;
  updatedAt: string;
}

export interface StudyMaterialFilterParams {
  classId?: string;
  sectionId?: string;
  subjectId?: string;
  status?: string;
  fileType?: string;
  search?: string;
  page?: number;
  limit?: number;
}

export type AnnouncementAudience =
  | 'SCHOOL_WIDE'
  | 'STUDENTS'
  | 'PARENTS'
  | 'TEACHERS'
  | 'CLASS'
  | 'SECTION'
  | 'CUSTOM';

export type AnnouncementPriority = 'normal' | 'important' | 'high' | 'urgent';

export type AnnouncementCategory =
  | 'general'
  | 'academic'
  | 'exam'
  | 'attendance'
  | 'fee'
  | 'holiday'
  | 'event'
  | 'admission'
  | 'emergency'
  | 'parent'
  | 'student'
  | 'teacher'
  | 'GENERAL'
  | 'ACADEMIC'
  | 'EXAMINATION'
  | 'EMERGENCY'
  | 'EVENT'
  | 'HOLIDAY'
  | 'FEE_FINANCE'
  | 'ADMINISTRATIVE'
  | 'SPORTS_COCURRICULAR';

export type AnnouncementStatus =
  | 'draft'
  | 'scheduled'
  | 'published'
  | 'expired'
  | 'archived'
  | 'cancelled';

export interface AnnouncementAttachment {
  id: string;
  fileName: string;
  fileUrl: string;
  fileSize: string;
  fileSizeBytes: number;
  fileType: string;
  uploadedAt: string;
}

export interface AnnouncementReadReceipt {
  userId: string;
  userName?: string;
  userRole?: string;
  readAt: string;
}

export interface ClassAnnouncement {
  id: string;
  schoolId?: string;
  title: string;
  message: string;
  content?: string;
  category?: AnnouncementCategory | string;
  classId: string;
  className: string;
  sectionId: string; // 'ALL' or specific section id
  sectionName: string; // 'All Sections' or specific section name
  academicSessionId?: string;
  academicSessionName?: string;
  targetAudience?: AnnouncementAudience;
  targetRoles?: UserRole[];
  targetUserIds?: string[];
  publishDate: string; // YYYY-MM-DD
  date?: string; // Aliased for date format
  publishAt?: string; // ISO string
  publishedAt?: string; // ISO string
  scheduledPublishAt?: string; // ISO string
  scheduledFor?: string;
  expiryDate?: string; // YYYY-MM-DD
  expiresAt?: string; // ISO string
  archivedAt?: string;
  cancelledAt?: string;
  priority: AnnouncementPriority;
  isPinned?: boolean;
  status: AnnouncementStatus;
  visibility?: 'ALL' | 'INTERNAL' | 'RESTRICTED';
  authorId?: string;
  authorUserId?: string;
  authorName?: string;
  authorRole?: UserRole | string;
  teacherId: string;
  teacherUserId: string;
  teacherName: string;
  attachments?: AnnouncementAttachment[];
  channels?: {
    inApp: boolean;
    email: boolean;
    sms: boolean;
    push: boolean;
  };
  readReceipts?: AnnouncementReadReceipt[];
  isRead?: boolean;
  readAt?: string;
  stats?: {
    totalRecipients: number;
    deliveredCount: number;
    readCount: number;
    unreadCount: number;
  };
  createdAt: string;
  updatedAt: string;
}

export interface AnnouncementFilterParams {
  classId?: string;
  sectionId?: string;
  category?: string;
  priority?: string;
  status?: string;
  targetAudience?: string;
  search?: string;
  page?: number;
  limit?: number;
}

// ==========================================
// Part 4B: Student Academic & Subject Types
// ==========================================

export interface StudentClassInfo {
  student: {
    id: string;
    userId: string;
    studentId: string;
    admissionNumber: string;
    rollNumber: string;
    firstName: string;
    lastName: string;
    fullName: string;
    email: string;
    avatarUrl?: string;
    enrollmentStatus: string;
    status: string;
    admissionDate?: string;
    enrollmentDate?: string;
  };
  academicSession: {
    id: string;
    sessionName: string;
    sessionCode: string;
    startDate: string;
    endDate: string;
    isCurrent: boolean;
    status: string;
  };
  schoolClass: {
    id: string;
    name: string;
    code: string;
    numericGrade: number;
    description?: string;
  };
  section: {
    id: string;
    name: string;
    code: string;
    roomNumber?: string;
    capacity: number;
    enrolledCount: number;
  };
  classTeacher?: {
    id: string;
    name: string;
    email?: string;
    departmentName?: string;
    designation?: string;
    qualification?: string;
    specialization?: string;
  } | null;
  metrics: {
    totalClassSubjects: number;
    totalClassCredits: number;
    classmatesCount: number;
  };
}

export interface StudentEnrolledSubject {
  id: string;
  name: string;
  code: string;
  type: 'core' | 'elective' | 'practical' | 'theory' | string;
  credits: number;
  description?: string;
  status: 'active' | 'inactive' | 'archived';
  displayOrder?: number;
  departmentId?: string;
  departmentName: string;
  departmentCode?: string;
  teacher?: {
    id: string;
    name: string;
    email?: string;
    designation?: string;
    departmentName?: string;
    qualification?: string;
  } | null;
  counts: {
    studyMaterials: number;
    homework: number;
    assignments: number;
  };
}

export interface StudentSubjectDetailData {
  subject: {
    id: string;
    name: string;
    code: string;
    type: string;
    credits: number;
    description?: string;
    status: string;
    departmentName: string;
    departmentCode?: string;
  };
  classInfo: {
    classId: string;
    className: string;
    sectionId: string;
    sectionName: string;
    academicSessionName: string;
  };
  teacher?: {
    id: string;
    name: string;
    email?: string;
    designation?: string;
    departmentName?: string;
    qualification?: string;
    specialization?: string;
  } | null;
  studyMaterials: StudyMaterial[];
  homework: Homework[];
  assignments: Assignment[];
}

export interface StudentAcademicInfoData {
  student: {
    id: string;
    userId: string;
    admissionNumber: string;
    rollNumber: string;
    fullName: string;
    enrollmentStatus: string;
    status: string;
    admissionDate?: string;
    enrollmentDate?: string;
  };
  academicSession: {
    id: string;
    sessionName: string;
    sessionCode: string;
    startDate: string;
    endDate: string;
    isCurrent: boolean;
  };
  schoolClass: {
    id: string;
    name: string;
    code: string;
    numericGrade: number;
  };
  section: {
    id: string;
    name: string;
    code: string;
    roomNumber?: string;
  };
  subjects: {
    id: string;
    name: string;
    code: string;
    type: string;
    credits: number;
    teacherName: string;
    departmentName: string;
    status: string;
  }[];
  summary: {
    totalSubjects: number;
    totalCredits: number;
    coreSubjectsCount: number;
    electiveSubjectsCount: number;
    practicalSubjectsCount: number;
  };
  futureRoadmap: {
    promotionStatus: string;
    promotionNotes: string;
    attendanceSummaryStatus: string;
    examinationStatus: string;
    resultsStatus: string;
    academicProgressStatus: string;
  };
}

export interface StudentSubjectFilterParams {
  search?: string;
  type?: string;
  status?: string;
}

export type LeaveStatus =
  | 'DRAFT'
  | 'SUBMITTED'
  | 'PENDING'
  | 'UNDER_REVIEW'
  | 'PARTIALLY_APPROVED'
  | 'APPROVED'
  | 'REJECTED'
  | 'CANCELLED';

export type ApplicantType = 'STUDENT' | 'TEACHER' | 'STAFF';

export interface LeaveType {
  id: string;
  name: string;
  code: string;
  description: string;
  applicableTo: 'STUDENT' | 'TEACHER' | 'STAFF' | 'BOTH' | 'ALL';
  paidType?: 'PAID' | 'UNPAID';
  isPaid?: boolean;
  maxDays?: number;
  maxDaysPerYear?: number;
  requiresAttachment: boolean;
  requiresApproval?: boolean;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface LeaveApplication {
  id: string;
  applicantType: ApplicantType;
  applicantId: string; // studentId, teacherProfileId or staffId
  userId: string;
  applicantName: string;

  // Student specific attributes
  studentId?: string;
  studentName?: string;
  admissionNumber?: string;
  rollNumber?: string;
  classId?: string;
  className?: string;
  sectionId?: string;
  sectionName?: string;

  // Teacher / Staff specific attributes
  teacherProfileId?: string;
  teacherName?: string;
  staffId?: string;
  staffName?: string;
  staffType?: string;
  designation?: string;
  designationId?: string;
  employeeCode?: string;
  departmentId?: string;
  departmentName?: string;

  academicSessionId: string;
  academicSessionName?: string;

  leaveTypeId?: string;
  leaveTypeName?: string;

  startDate: string; // 'YYYY-MM-DD'
  endDate: string; // 'YYYY-MM-DD'
  leaveDate: string; // 'YYYY-MM-DD' (backward compatible alias for startDate)
  totalDays: number;

  reason: string;
  description?: string;
  remarks?: string;

  attachmentUrl?: string;
  attachmentName?: string;
  attachmentSize?: number;
  attachmentType?: string;

  status: LeaveStatus;
  submissionDate?: string;
  submittedAt?: string;

  submittedByGuardianId?: string;
  submittedByGuardianName?: string;

  reviewedByUserId?: string;
  reviewedByName?: string;
  reviewedByRole?: string;
  reviewedAt?: string;
  adminRemarks?: string;
  rejectionReason?: string;
  isDeleted?: boolean;
  workingDays?: number;
  appliedAt?: string;
  reviewedByTeacherName?: string;
  reviewNotes?: string;
  reviewedBy?: string;
  workingDates?: string[];
  leaveTypeCode?: string;
  policyId?: string;
  policyName?: string;
  approvalHistory?: Array<{
    tier: number;
    approverId: string;
    approverName: string;
    approverRole: string;
    action: 'RECOMMEND' | 'APPROVE' | 'REJECT';
    remarks?: string;
    decisionDate: string;
  }>;
  currentApprovalTier?: number;
  totalApprovalTiers?: number;

  appliedAttendanceDates?: string[];
  previousAttendanceStates?: Record<
    string,
    {
      recordId?: string;
      previousStatus: string;
      wasAutoCreated: boolean;
    }
  >;

  createdAt: string;
  updatedAt: string;
}

export type StudentLeaveApplication = LeaveApplication;

export interface LeaveApplicationFilterParams {
  applicantType?: 'STUDENT' | 'TEACHER' | 'ALL';
  leaveTypeId?: string;
  status?: string;
  date?: string;
  startDate?: string;
  endDate?: string;
  academicSessionId?: string;
  classId?: string;
  sectionId?: string;
  search?: string;
  page?: number;
  limit?: number;
}

export interface LeaveCalculationResult {
  startDate: string;
  endDate: string;
  totalCalendarDays: number;
  totalWorkingLeaveDays: number;
  workingDates: string[];
  nonWorkingDates: {
    date: string;
    dayType: string;
    reason: string;
  }[];
}

export interface StudentAttendanceDay {
  date: string; // 'YYYY-MM-DD'
  dayOfMonth: number;
  dayOfWeek: number; // 0 = Sun, 6 = Sat
  status: AttendanceStatus | 'WEEKEND' | 'HOLIDAY' | 'FUTURE' | 'NO_RECORD';
  statusLabel: string;
  isWeekend: boolean;
  isHoliday: boolean;
  holidayName?: string;
  isToday: boolean;
  isFuture: boolean;
  record?: AttendanceRecord;
  leaveApplication?: StudentLeaveApplication;
}

export interface StudentAttendanceOverviewData {
  student: {
    id: string;
    userId: string;
    admissionNumber: string;
    rollNumber: string;
    fullName: string;
    className: string;
    sectionName: string;
    academicSessionName: string;
  };
  summary: {
    totalSchoolDays: number;
    presentCount: number;
    absentCount: number;
    lateCount: number;
    halfDayCount?: number;
    leaveCount: number;
    attendancePercentage: number;
  };
  filterMonth: string; // 'YYYY-MM'
  calendarDays: StudentAttendanceDay[];
  records: AttendanceRecord[];
  leaveApplications: StudentLeaveApplication[];
}

// ==========================================
// Part 4D: Student Academic Activities Types
// ==========================================

export type ActivityCalculatedStatus = 'active' | 'due_soon' | 'overdue' | 'upcoming';

export interface StudentHomeworkItem extends Homework {
  calculatedStatus: ActivityCalculatedStatus;
  daysRemaining: number;
  isOverdue: boolean;
  isDueSoon: boolean;
}

export interface StudentAssignmentItem extends Assignment {
  calculatedStatus: ActivityCalculatedStatus;
  daysRemaining: number;
  isOverdue: boolean;
  isDueSoon: boolean;
  submissionState?: {
    isSubmissionEnabled: boolean;
    submissionNotice: string;
    maxMarks: number;
  };
}

export interface StudentHomeworkFilterParams {
  subjectId?: string;
  status?: string; // 'ALL' | 'active' | 'due_soon' | 'overdue'
  search?: string;
  dueDate?: string;
  assignedDate?: string;
}

export interface StudentAssignmentFilterParams {
  subjectId?: string;
  status?: string; // 'ALL' | 'active' | 'due_soon' | 'overdue'
  search?: string;
  startDate?: string;
  dueDate?: string;
}

export interface StudentMaterialFilterParams {
  subjectId?: string;
  fileType?: string; // 'ALL' | 'pdf' | 'docx' | 'pptx' | 'zip' | 'image'
  search?: string;
}

export interface StudentAnnouncementFilterParams {
  priority?: string; // 'ALL' | 'urgent' | 'high' | 'important' | 'normal'
  search?: string;
}

export interface StudentActivitiesSummary {
  homework: {
    total: number;
    active: number;
    dueSoon: number;
    overdue: number;
  };
  assignments: {
    total: number;
    active: number;
    dueSoon: number;
    overdue: number;
  };
  materials: {
    total: number;
    bySubject: { subjectName: string; count: number }[];
  };
  announcements: {
    total: number;
    urgentCount: number;
    highCount: number;
  };
  upcomingDeadlines: {
    id: string;
    type: 'homework' | 'assignment';
    title: string;
    subjectName: string;
    dueDate: string;
    daysRemaining: number;
    isDueSoon: boolean;
    isOverdue: boolean;
  }[];
}

// ==========================================
// Part 4E: Examination, Results & Academic Progress Types
// ==========================================

export type ExamStatus = 'scheduled' | 'ongoing' | 'completed' | 'postponed' | 'cancelled';
export type ExaminationStatus = 'draft' | 'scheduled' | 'ongoing' | 'completed' | 'published' | 'archived';

export interface ExamSubjectConfig {
  id: string;
  examId: string;
  subjectId: string;
  subjectName: string;
  subjectCode: string;
  fullMarks: number;
  passMarks: number;
  examDurationMinutes: number;
  examDate: string; // YYYY-MM-DD
  startTime: string; // e.g. "09:00 AM"
  endTime: string; // e.g. "11:30 AM"
  roomNumber?: string;
  invigilatorTeacherId?: string;
  invigilatorName?: string;
  instructions?: string;
  orderIndex?: number;
  createdAt?: string;
  updatedAt?: string;
}

export interface Examination {
  id: string;
  name: string;
  examType: string;
  academicSessionId: string;
  academicSessionName?: string;
  classId: string;
  className?: string;
  sectionId: string; // 'ALL' or specific section id
  sectionName?: string;
  startDate: string; // YYYY-MM-DD
  endDate: string; // YYYY-MM-DD
  status: ExaminationStatus;
  description?: string;
  instructions?: string;
  isArchived: boolean;
  subjectsConfig?: ExamSubjectConfig[];
  subjectCount?: number;
  totalFullMarks?: number;
  createdAt: string;
  updatedAt: string;
}

export interface ExamFilterParams {
  academicSessionId?: string;
  classId?: string;
  sectionId?: string;
  status?: string;
  examType?: string;
  search?: string;
  includeArchived?: boolean;
}

export interface CreateExamPayload {
  name: string;
  examType: string;
  academicSessionId: string;
  classId: string;
  sectionId: string;
  startDate: string;
  endDate: string;
  status?: ExaminationStatus;
  description?: string;
  instructions?: string;
}

export interface UpdateExamPayload extends Partial<CreateExamPayload> {
  isArchived?: boolean;
}

export interface ExamSubjectConfigPayload {
  subjectId: string;
  fullMarks: number;
  passMarks: number;
  examDurationMinutes: number;
  examDate: string;
  startTime: string;
  endTime: string;
  roomNumber?: string;
  invigilatorTeacherId?: string;
  instructions?: string;
}

export interface GradingScaleItem {
  id?: string;
  grade: string;
  minPercentage: number;
  maxPercentage: number;
  gradePoint: number;
  description: string;
  isPassing: boolean;
  orderIndex?: number;
}

export interface ExamScheduleItem {
  id: string;
  examId: string;
  examName: string;
  examType: 'mid_term' | 'final' | 'unit_test' | 'quiz' | 'mock' | 'practical' | string;
  subjectId: string;
  subjectName: string;
  subjectCode: string;
  classId: string;
  className: string;
  sectionId: string; // 'ALL' or specific section id
  sectionName: string;
  academicSessionId: string;
  academicSessionName: string;
  examDate: string; // YYYY-MM-DD
  startTime: string; // e.g. "09:00 AM"
  endTime: string; // e.g. "11:30 AM"
  durationMinutes: number;
  roomNumber?: string;
  fullMarks: number;
  passMarks: number;
  instructions?: string;
  status: ExamStatus;
  invigilatorTeacherId?: string;
  invigilatorName?: string;
  createdAt: string;
  updatedAt: string;
}

export interface ExamScheduleConflict {
  type: 'CLASS_OVERLAP' | 'ROOM_OVERLAP' | 'TEACHER_OVERLAP' | 'DUPLICATE_SUBJECT' | 'INVALID_TIME' | 'INVALID_DATE' | 'MARKS_MISMATCH';
  message: string;
  conflictingScheduleId?: string;
  conflictingExamName?: string;
  conflictingSubjectName?: string;
  conflictingDetails?: string;
}

export interface ScheduleConflictCheckPayload {
  scheduleId?: string;
  examId: string;
  subjectId: string;
  classId?: string;
  sectionId?: string;
  examDate: string;
  startTime: string;
  endTime: string;
  roomNumber?: string;
  invigilatorTeacherId?: string;
  invigilatorName?: string;
  fullMarks?: number;
  passMarks?: number;
}

export interface ExamScheduleAdminFilterParams {
  academicSessionId?: string;
  examId?: string;
  classId?: string;
  sectionId?: string;
  subjectId?: string;
  teacherId?: string;
  roomNumber?: string;
  status?: string;
  date?: string;
  startDate?: string;
  endDate?: string;
  search?: string;
  page?: number;
  limit?: number;
}

export interface CreateExamSchedulePayload {
  examId: string;
  subjectId: string;
  classId?: string;
  sectionId?: string;
  academicSessionId?: string;
  examDate: string;
  startTime: string;
  endTime: string;
  durationMinutes?: number;
  roomNumber?: string;
  fullMarks?: number;
  passMarks?: number;
  invigilatorTeacherId?: string;
  invigilatorName?: string;
  instructions?: string;
  status?: ExamStatus;
}

export interface UpdateExamSchedulePayload extends Partial<CreateExamSchedulePayload> {}

// Part 6C: Teacher Marks Entry & Submission Types
// ==========================================

export type ExamMarksSubmissionStatus = 'not_started' | 'draft' | 'in_progress' | 'submitted' | 'returned' | 'approved';

export interface StudentMarkItem {
  studentId: string; // StudentProfile ID (e.g. stud-prof-1)
  userId: string; // Student User ID (e.g. usr-student-1)
  admissionNumber: string;
  rollNumber: string;
  studentName: string;
  avatarUrl?: string;
  classId: string;
  className: string;
  sectionId: string;
  sectionName: string;
  obtainedMarks: number | null;
  isAbsent?: boolean;
  isExempt?: boolean;
  remarks?: string;
  isPassed?: boolean;
  updatedAt?: string;
}

export interface ExamMarksSubmission {
  id: string;
  examId: string;
  examName: string;
  examType: string;
  academicSessionId: string;
  academicSessionName: string;
  subjectId: string;
  subjectName: string;
  subjectCode: string;
  classId: string;
  className: string;
  sectionId: string; // 'ALL' or specific section id
  sectionName: string;
  examDate: string;
  startTime?: string;
  endTime?: string;
  roomNumber?: string;
  fullMarks: number;
  passMarks: number;
  status: ExamMarksSubmissionStatus;
  teacherId: string; // TeacherProfile ID
  teacherName: string;
  teacherUserId: string;
  marks: StudentMarkItem[];
  totalStudents: number;
  enteredCount: number;
  passedCount: number;
  failedCount: number;
  absentCount: number;
  exemptCount: number;
  averageMarks: number;
  highestMarks: number;
  lowestMarks: number;
  submittedAt?: string;
  submittedBy?: string;
  returnedAt?: string;
  returnedReason?: string;
  returnedBy?: string;
  approvedAt?: string;
  approvedBy?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface TeacherAssignedExamSubject {
  examId: string;
  examName: string;
  examType: string;
  academicSessionId: string;
  academicSessionName: string;
  classId: string;
  className: string;
  sectionId: string;
  sectionName: string;
  subjectId: string;
  subjectName: string;
  subjectCode: string;
  examDate: string;
  startTime: string;
  endTime: string;
  roomNumber?: string;
  fullMarks: number;
  passMarks: number;
  submissionStatus: ExamMarksSubmissionStatus;
  submissionId?: string;
  totalStudents: number;
  enteredCount: number;
  submittedAt?: string;
  submittedBy?: string;
  returnedReason?: string;
  isAssignedDirectly: boolean;
}

export interface SaveDraftMarksPayload {
  examId: string;
  subjectId: string;
  classId: string;
  sectionId: string;
  marks: Array<{
    studentId: string;
    obtainedMarks: number | null;
    isAbsent?: boolean;
    isExempt?: boolean;
    remarks?: string;
  }>;
  notes?: string;
}

export interface SubmitMarksPayload {
  examId: string;
  subjectId: string;
  classId: string;
  sectionId: string;
  marks: Array<{
    studentId: string;
    obtainedMarks: number | null;
    isAbsent?: boolean;
    isExempt?: boolean;
    remarks?: string;
  }>;
  notes?: string;
}

export interface AdminMarksSubmissionFilterParams {
  academicSessionId?: string;
  examId?: string;
  classId?: string;
  sectionId?: string;
  subjectId?: string;
  teacherId?: string;
  status?: string;
  search?: string;
  page?: number;
  limit?: number;
}

export interface ReturnMarksPayload {
  reason: string;
}

export interface ExamScheduleFilterParams {
  academicSessionId?: string;
  examId?: string;
  subjectId?: string;
  status?: string;
  search?: string;
}

export interface ExamResultSubjectScore {
  id?: string;
  subjectId: string;
  subjectName: string;
  subjectCode: string;
  credits: number;
  fullMarks: number;
  passMarks: number;
  theoryMarks?: number;
  practicalMarks?: number;
  obtainedMarks: number;
  percentage: number;
  grade: string;
  gradePoint: number;
  status?: 'PASSED' | 'FAILED' | 'ABSENT' | 'WITHHELD' | string;
  isPassing?: boolean;
  remarks?: string;
  teacherFeedback?: string;
}

export type ResultWorkflowStatus =
  | 'DRAFT'
  | 'CALCULATED'
  | 'UNDER_REVIEW'
  | 'CORRECTION_REQUIRED'
  | 'APPROVED'
  | 'PUBLISHED'
  | 'ARCHIVED';

export interface ResultStatusHistoryItem {
  id: string;
  fromStatus: ResultWorkflowStatus;
  toStatus: ResultWorkflowStatus;
  changedByUserId: string;
  changedByUserName: string;
  changedByUserRole: string;
  timestamp: string;
  reason?: string;
  notes?: string;
}

export interface StudentExamResult {
  id: string;
  studentId: string;
  userId: string;
  studentName: string;
  admissionNumber: string;
  rollNumber: string;
  avatarUrl?: string;
  classId: string;
  className: string;
  sectionId: string;
  sectionName: string;
  academicSessionId: string;
  academicSessionName: string;
  academicYear: string;
  examId: string;
  examName: string;
  examType: string;
  term: string;
  publishDate: string;
  isPublished: boolean;
  publishedBy?: string;
  publishedByName?: string;
  publishedAt?: string;
  workflowStatus: ResultWorkflowStatus;
  isApproved?: boolean;
  approvedBy?: string;
  approvedByName?: string;
  approvedAt?: string;
  isLocked?: boolean;
  lockedReason?: string;
  correctionRequested?: boolean;
  correctionReason?: string;
  correctionRequestedBy?: string;
  correctionRequestedByName?: string;
  correctionRequestedAt?: string;
  reopenReason?: string;
  reopenedBy?: string;
  reopenedByName?: string;
  reopenedAt?: string;
  statusHistory?: ResultStatusHistoryItem[];
  subjectScores: ExamResultSubjectScore[];
  summary: {
    totalFullMarks: number;
    totalObtainedMarks: number;
    overallPercentage: number;
    gpa: number;
    overallGrade: string;
    resultStatus: 'PASSED' | 'FAILED' | 'WITHHELD' | 'DISTINCTION';
    totalSubjects: number;
    passedSubjects: number;
    failedSubjects: number;
    absentSubjects?: number;
    exemptSubjects?: number;
    isIncomplete?: boolean;
    missingSubjectCount?: number;
    classRank?: number;
    sectionRank?: number;
    overallRank?: number;
    meritPosition?: number;
    rankTie?: boolean;
    totalStudentsInClass?: number;
    totalStudentsInSection?: number;
  };
  academicProgressNotes?: string;
  createdAt: string;
  updatedAt: string;
}

// Part 6F: Report Cards, Merit/Position & Academic Reports Types
export type RankingCriteriaType = 'TOTAL_MARKS' | 'PERCENTAGE' | 'GPA' | 'WEIGHTED_GPA';
export type TieBreakerRuleType = 'STANDARD_COMPETITION' | 'DENSE' | 'ORDINAL' | 'FRACTIONAL';
export type RankingScopeType = 'SECTION' | 'CLASS' | 'GRADE' | 'OVERALL';

export interface MeritRankingConfig {
  id?: string;
  rankingCriteria: RankingCriteriaType;
  tieBreakerRule: TieBreakerRuleType;
  tieBreakerPriority: Array<'GPA' | 'TOTAL_MARKS' | 'CORE_SUBJECTS' | 'ATTENDANCE' | 'ROLL_NUMBER'>;
  rankingScope: RankingScopeType;
  includeFailedStudents: boolean;
  minimumPassingPercentage: number;
  updatedAt?: string;
  updatedBy?: string;
  updatedByName?: string;
}

export interface MeritRankItem {
  rank: number;
  displayRank: string;
  studentId: string;
  userId: string;
  studentName: string;
  admissionNumber: string;
  rollNumber: string;
  avatarUrl?: string;
  classId: string;
  className: string;
  sectionId: string;
  sectionName: string;
  academicSessionName: string;
  examId: string;
  examName: string;
  totalFullMarks: number;
  totalObtainedMarks: number;
  overallPercentage: number;
  gpa: number;
  overallGrade: string;
  resultStatus: 'PASSED' | 'FAILED' | 'DISTINCTION' | 'WITHHELD';
  isTied: boolean;
  tiedWithCount?: number;
  subjectMarks: Record<string, number>;
  attendancePercentage?: number;
}

export interface MeritListResponse {
  examId: string;
  examName: string;
  classId?: string;
  className?: string;
  sectionId?: string;
  sectionName?: string;
  academicSessionName?: string;
  rankingConfig: MeritRankingConfig;
  totalRanked: number;
  tiedCount: number;
  highestScore: number;
  lowestScore: number;
  averageScore: number;
  averageGpa: number;
  data: MeritRankItem[];
}

export interface ReportCardDetail {
  result: StudentExamResult;
  school: {
    name: string;
    logoUrl?: string;
    address: string;
    phone: string;
    email: string;
    website?: string;
    affiliationNumber?: string;
    motto?: string;
    principalName?: string;
  };
  student: {
    id: string;
    name: string;
    admissionNumber: string;
    rollNumber: string;
    className: string;
    sectionName: string;
    academicSessionName: string;
    guardianName?: string;
    dateOfBirth?: string;
    bloodGroup?: string;
    avatarUrl?: string;
  };
  gradingScale: GradingScaleItem[];
  attendance?: {
    totalWorkingDays: number;
    presentDays: number;
    absentDays: number;
    lateDays: number;
    attendancePercentage: number;
  };
  merit?: {
    classRank?: number;
    totalClassStudents?: number;
    sectionRank?: number;
    totalSectionStudents?: number;
    overallRank?: number;
    isTied?: boolean;
  };
  teacherRemarks?: string;
  principalRemarks?: string;
  issueDate: string;
  verificationHash: string;
  isOfficial: boolean;
}

export interface ClassResultSummaryData {
  examId: string;
  examName: string;
  academicSessionId: string;
  academicSessionName: string;
  classId: string;
  className: string;
  sectionId: string;
  sectionName: string;
  totalEnrolled: number;
  totalEvaluated: number;
  passedCount: number;
  failedCount: number;
  distinctionCount: number;
  withheldCount: number;
  passRate: number;
  failRate: number;
  highestMarks: number;
  highestMarksStudent?: string;
  lowestMarks: number;
  averageMarks: number;
  highestGpa: number;
  lowestGpa: number;
  averageGpa: number;
  averagePercentage: number;
  gradeDistribution: Array<{
    grade: string;
    count: number;
    percentage: number;
    isPassing: boolean;
  }>;
  subjectSummaries: Array<{
    subjectId: string;
    subjectName: string;
    subjectCode: string;
    credits: number;
    fullMarks: number;
    passMarks: number;
    evaluatedCount: number;
    passedCount: number;
    failedCount: number;
    passRate: number;
    highestMarks: number;
    lowestMarks: number;
    averageMarks: number;
    averageGpa: number;
    teacherName?: string;
  }>;
  tabulationLedger: Array<{
    studentId: string;
    studentName: string;
    admissionNumber: string;
    rollNumber: string;
    sectionName: string;
    scores: Record<string, {
      obtained: number;
      full: number;
      grade: string;
      gradePoint: number;
      isPassing: boolean;
      isAbsent?: boolean;
      isExempt?: boolean;
    }>;
    totalFullMarks: number;
    totalObtainedMarks: number;
    percentage: number;
    gpa: number;
    overallGrade: string;
    resultStatus: string;
    classRank?: number;
    sectionRank?: number;
    meritPosition?: number;
  }>;
}

export interface SubjectPerformanceItem {
  subjectId: string;
  subjectName: string;
  subjectCode: string;
  credits: number;
  fullMarks: number;
  passMarks: number;
  totalStudents: number;
  passedCount: number;
  failedCount: number;
  absentCount: number;
  exemptCount: number;
  passPercentage: number;
  highestMarks: number;
  highestMarksStudent?: string;
  lowestMarks: number;
  averageMarks: number;
  averagePercentage: number;
  averageGrade: string;
  averageGradePoint: number;
  gradeBreakdown: Record<string, number>;
  teacherName?: string;
}

export interface SubjectPerformanceReportResponse {
  examId: string;
  examName: string;
  academicSessionId: string;
  academicSessionName: string;
  classId: string;
  className: string;
  sectionId?: string;
  sectionName?: string;
  totalSubjects: number;
  overallSubjectPassRate: number;
  subjects: SubjectPerformanceItem[];
}

export interface StudentPerformanceHistoryExamItem {
  examId: string;
  examName: string;
  examType: string;
  academicSessionName: string;
  publishDate: string;
  totalFullMarks: number;
  totalObtainedMarks: number;
  overallPercentage: number;
  gpa: number;
  overallGrade: string;
  resultStatus: 'PASSED' | 'FAILED' | 'DISTINCTION' | 'WITHHELD';
  classRank?: number;
  totalStudentsInClass?: number;
  subjectScores: ExamResultSubjectScore[];
  attendanceStats?: {
    totalWorkingDays: number;
    presentDays: number;
    percentage: number;
  };
}

export interface StudentPerformanceHistoryResponse {
  student: {
    id: string;
    userId: string;
    name: string;
    admissionNumber: string;
    rollNumber: string;
    className: string;
    sectionName: string;
    academicSessionName: string;
    guardianName?: string;
    avatarUrl?: string;
    enrollmentDate?: string;
  };
  examHistory: StudentPerformanceHistoryExamItem[];
  cumulativeStats: {
    totalExamsTaken: number;
    overallCumulativeGpa: number;
    averagePercentage: number;
    highestGpa: number;
    lowestGpa: number;
    gpaTrend: 'UPWARD' | 'DOWNWARD' | 'STABLE';
    gpaDelta: number;
    passedExamsCount: number;
    failedExamsCount: number;
    attendanceAverage: number;
  };
  subjectTrends: Array<{
    subjectName: string;
    subjectCode: string;
    history: Array<{
      examName: string;
      obtainedMarks: number;
      fullMarks: number;
      percentage: number;
      grade: string;
      gradePoint: number;
    }>;
  }>;
}

// Part 6E: Result Review, Approval & Publishing Types
export interface ResultReviewFilterParams {
  academicSessionId?: string;
  examId?: string;
  classId?: string;
  sectionId?: string;
  subjectId?: string;
  workflowStatus?: string;
  resultStatus?: string;
  search?: string;
  page?: number;
  limit?: number;
}

export interface ResultReviewSummaryStats {
  total: number;
  draft: number;
  calculated: number;
  underReview: number;
  correctionRequired: number;
  approved: number;
  published: number;
  archived: number;
  passedCount: number;
  failedCount: number;
  distinctionCount: number;
  averagePercentage: number;
  averageGpa: number;
  highestGpa: number;
  lowestGpa: number;
}

export interface ResultReviewResponse {
  data: StudentExamResult[];
  total: number;
  page: number;
  limit: number;
  stats: ResultReviewSummaryStats;
  availableSessions: Array<{ id: string; name: string }>;
  availableExams: Array<{ id: string; name: string; type: string; className?: string }>;
  availableClasses: Array<{ id: string; name: string }>;
  availableSections: Array<{ id: string; name: string; classId?: string }>;
  availableSubjects: Array<{ id: string; name: string; code: string }>;
}

export interface ChangeResultStatusPayload {
  targetStatus: ResultWorkflowStatus;
  reason?: string;
  notes?: string;
}

export interface BulkChangeResultStatusPayload {
  resultIds: string[];
  targetStatus: ResultWorkflowStatus;
  reason?: string;
  notes?: string;
}

export interface ReturnCorrectionPayload {
  resultIds: string[];
  reason: string;
  notes?: string;
}

export interface BulkApproveResultsPayload {
  resultIds: string[];
  notes?: string;
}

export interface PublishResultsPayload {
  examId?: string;
  classId?: string;
  sectionId?: string;
  resultIds?: string[];
  publishDate?: string;
  notifyStudentsAndParents?: boolean;
}

export interface UnpublishReopenPayload {
  resultIds: string[];
  reason: string;
}

export interface StudentResultsFilterParams {
  academicSessionId?: string;
  examId?: string;
  academicYear?: string;
  search?: string;
}

export interface AdminResultPreviewFilterParams {
  academicSessionId?: string;
  examId?: string;
  classId?: string;
  sectionId?: string;
  status?: string;
  search?: string;
  page?: number;
  limit?: number;
}

export interface CalculateResultsPayload {
  examId: string;
  classId?: string;
  sectionId?: string;
  forceRecalculate?: boolean;
}

export interface CalculationReadinessInfo {
  examId: string;
  examName: string;
  academicSessionName: string;
  className: string;
  totalConfiguredSubjects: number;
  submittedSubjectsCount: number;
  draftSubjectsCount: number;
  unstartedSubjectsCount: number;
  isReadyForCalculation: boolean;
  totalEligibleStudents: number;
  calculatedResultsCount: number;
  pendingSubjects: Array<{
    subjectId: string;
    subjectName: string;
    subjectCode: string;
    status: 'unstarted' | 'draft' | 'submitted' | 'approved';
    teacherName?: string;
  }>;
}

export interface ResultCalculationSummaryStats {
  totalCalculated: number;
  passedCount: number;
  failedCount: number;
  distinctionCount: number;
  incompleteCount: number;
  averagePercentage: number;
  averageGpa: number;
  highestGpa: number;
  lowestGpa: number;
}

export interface SubjectPerformanceTrend {
  subjectId: string;
  subjectName: string;
  subjectCode: string;
  credits: number;
  averageMarks: number;
  highestMarks: number;
  latestGrade: string;
  latestGradePoint: number;
  trend: 'improving' | 'stable' | 'declining';
  trendDelta: number;
  examHistory: Array<{
    examId: string;
    examName: string;
    examDate: string;
    academicSessionName: string;
    obtainedMarks: number;
    fullMarks: number;
    percentage: number;
    grade: string;
    gradePoint: number;
  }>;
}

export interface ExamWiseTrendItem {
  examId: string;
  examName: string;
  academicSessionName: string;
  academicYear: string;
  publishDate: string;
  overallPercentage: number;
  gpa: number;
  overallGrade: string;
  resultStatus: string;
  totalObtainedMarks: number;
  totalFullMarks: number;
}

export interface StudentAcademicProgressOverview {
  student: {
    id: string;
    userId: string;
    admissionNumber: string;
    rollNumber: string;
    fullName: string;
    className: string;
    sectionName: string;
    academicSessionName: string;
    avatarUrl?: string;
  };
  metrics: {
    currentGPA: number;
    cumulativeGPA: number;
    totalExamsTaken: number;
    totalCreditsCompleted: number;
    highestPercentage: number;
    overallGrade: string;
    academicStanding: string;
  };
  attendanceSummary: {
    attendancePercentage: number;
    presentCount: number;
    absentCount: number;
    lateCount: number;
    totalSchoolDays: number;
    hasReliableData: boolean;
  };
  subjectPerformances: SubjectPerformanceTrend[];
  examWiseTrends: ExamWiseTrendItem[];
  gradingScale: GradingScaleItem[];
  attendancePerformanceCorrelation: {
    correlationRating: 'Strong Positive' | 'Positive' | 'Moderate' | 'Consistent';
    attendancePercentage: number;
    academicPercentage: number;
    insightText: string;
  };
  improvementHighlights: Array<{
    id: string;
    title: string;
    description: string;
    type: 'positive' | 'focus_area' | 'milestone';
  }>;
}

// -------------------------------------------------------------
// PART 5A: GUARDIAN / PARENT PORTAL TYPES
// -------------------------------------------------------------

export interface GuardianChildSummary {
  id: string; // Student profile ID (e.g. stud-prof-1)
  userId: string; // Student User ID (e.g. usr-student-1)
  admissionNumber: string;
  rollNumber: string;
  name: string;
  firstName: string;
  lastName: string;
  avatarUrl?: string;
  dateOfBirth: string;
  gender: string;
  bloodGroup?: string;
  classId: string;
  className: string;
  sectionId: string;
  sectionName: string;
  roomNumber?: string;
  academicSessionId: string;
  academicSessionName: string;
  academicYear?: string;
  enrollmentStatus: string;
  status: string;
  enrollmentDate?: string;
  classTeacherId?: string;
  classTeacherName?: string;
  classTeacherEmail?: string;
  classTeacherPhone?: string;
  totalSubjectsCount: number;
  emergencyContact?: string;
  address?: string;
}

export interface GuardianChildDossier extends GuardianChildSummary {
  enrolledSubjects: Array<{
    id: string;
    name: string;
    code: string;
    type: string;
    creditHours?: number;
    teacherName?: string;
  }>;
  academicSessionDetails?: {
    startDate?: string;
    endDate?: string;
    term?: string;
    isActive: boolean;
  };
}

export interface GuardianChildAcademicSnapshot {
  currentClass: string;
  currentSection: string;
  academicSession: string;
  totalSubjectsEnrolled: number;
  hasPublishedResults: boolean;
  publishedResultsCount: number;
  cumulativeGPA: number;
  overallGrade: string;
  overallStanding: string;
  latestResult?: {
    id: string;
    examName: string;
    examType: string;
    term: string;
    academicYear: string;
    publishDate: string;
    gpa: number;
    percentage: number;
    grade: string;
    isPassed: boolean;
    academicStanding: string;
    classRank?: number;
    totalStudentsInClass?: number;
    subjectScores: Array<{
      subjectId: string;
      subjectName: string;
      subjectCode: string;
      maxMarks: number;
      obtainedMarks: number;
      percentage: number;
      grade: string;
      status: string;
    }>;
  };
}

export interface GuardianChildAttendanceSnapshot {
  hasAttendanceData: boolean;
  totalSchoolDays: number;
  presentCount: number;
  absentCount: number;
  lateCount: number;
  leaveCount: number;
  halfDayCount: number;
  attendancePercentage: number;
  statusEvaluation: 'EXCELLENT' | 'GOOD' | 'SATISFACTORY' | 'ATTENTION_REQUIRED';
  lastMarkedDate: string | null;
  lastMarkedStatus: string | null;
}

export interface GuardianChildFeesSnapshot {
  hasFeeRecords: boolean;
  totalFees: number;
  totalPaid: number;
  totalDue: number;
  totalOverdue: number;
  totalDiscount: number;
  fullyPaidCount: number;
  partiallyPaidCount: number;
  unpaidCount: number;
  overdueCount: number;
  nextUpcomingDueDate: string | null;
  latestInvoiceNumber: string | null;
  latestPaymentStatus: 'PAID' | 'PARTIAL' | 'DUE' | 'OVERDUE' | 'NO_FEES';
}

export interface GuardianChildActivityItem {
  id: string;
  type: 'RESULT' | 'ATTENDANCE' | 'FEE' | 'NOTICE' | 'HOMEWORK' | 'ASSIGNMENT';
  title: string;
  description: string;
  timestamp: string;
  badgeLabel: string;
  badgeVariant: 'success' | 'warning' | 'danger' | 'info' | 'neutral';
  linkView?: string;
}

export interface GuardianDashboardData {
  guardian: Guardian;
  totalChildren: number;
  children: GuardianChildSummary[];
  activeChildId?: string;
  selectedChildId?: string;
  selectedChild?: GuardianChildSummary;
  academicSnapshot?: GuardianChildAcademicSnapshot;
  attendanceSnapshot?: GuardianChildAttendanceSnapshot;
  feesSnapshot?: GuardianChildFeesSnapshot;
  recentActivities?: GuardianChildActivityItem[];
  recentNotifications: NotificationItem[];
  importantAnnouncements: Array<{
    id: string;
    title: string;
    content: string;
    priority: 'low' | 'normal' | 'high' | 'urgent';
    targetType: string;
    className?: string;
    sectionName?: string;
    publishedAt: string;
    authorName: string;
  }>;
  unreadNotificationCount: number;
  quickStats: {
    totalEnrolledSubjects: number;
    activeAcademicYear: string;
    schoolName: string;
    schoolPhone?: string;
    schoolEmail?: string;
  };
}

export interface GuardianProfileUpdatePayload {
  name?: string;
  firstName?: string;
  lastName?: string;
  preferredName?: string;
  phone?: string;
  secondaryPhone?: string;
  email?: string;
  whatsapp?: string;
  preferredContactMethod?: 'phone' | 'email' | 'whatsapp' | 'sms' | string;
  address?: string;
  permanentAddress?: string;
  city?: string;
  state?: string;
  country?: string;
  postalCode?: string;
  occupation?: string;
  emergencyContact?: string;
  avatarUrl?: string;
}

export interface GuardianNotificationFilterParams {
  category?: 'system' | 'academic' | 'security' | 'general' | 'all';
  unreadOnly?: boolean;
  search?: string;
}

// -------------------------------------------------------------
// PART 5B: GUARDIAN CHILD ACADEMIC OVERVIEW TYPES
// -------------------------------------------------------------

export interface GuardianChildSubject {
  id: string;
  name: string;
  code: string;
  type: string; // core, elective, theory, practical
  credits: number;
  status: 'active' | 'inactive';
  departmentName?: string;
  teacherId?: string;
  teacherName: string;
  teacherDesignation?: string;
}

export interface GuardianChildTeacher {
  id: string;
  name: string;
  designation: string;
  departmentName: string;
  email: string;
  subjectNames: string[];
  isClassTeacher: boolean;
  className: string;
  sectionName: string;
}

export interface GuardianChildAcademicSummary {
  totalSubjects: number;
  totalCredits: number;
  attendance: {
    hasData: boolean;
    percentage: number;
    totalDays: number;
    presentDays: number;
    absentDays: number;
    lateDays: number;
  } | null;
  homework: {
    totalCount: number;
    pendingCount: number;
    nextDueItem?: {
      id: string;
      title: string;
      subjectName: string;
      dueDate: string;
    };
  } | null;
  assignments: {
    totalCount: number;
    pendingCount: number;
    nextDueItem?: {
      id: string;
      title: string;
      subjectName: string;
      dueDate: string;
    };
  } | null;
  latestResult: {
    hasData: boolean;
    examName: string;
    term: string;
    publishDate: string;
    overallPercentage: number;
    gpa: number;
    overallGrade: string;
    resultStatus: string;
    classRank?: number;
    totalStudentsInClass?: number;
  } | null;
  recentActivities: Array<{
    id: string;
    title: string;
    type: 'attendance' | 'exam' | 'announcement' | 'subject';
    date: string;
    description: string;
    badgeText?: string;
  }>;
}

export interface GuardianChildAcademicOverview {
  student: GuardianChildSummary;
  subjects: GuardianChildSubject[];
  teachers: GuardianChildTeacher[];
  summary: GuardianChildAcademicSummary;
  availableSessions: Array<{ id: string; name: string; isActive: boolean }>;
}

// -------------------------------------------------------------
// PART 5C: GUARDIAN ATTENDANCE & LEAVE TYPES
// -------------------------------------------------------------

export interface GuardianChildAttendanceDay {
  date: string; // 'YYYY-MM-DD'
  dayOfMonth: number;
  dayOfWeek: number; // 0 = Sun, 6 = Sat
  status: AttendanceStatus | 'WEEKEND' | 'HOLIDAY' | 'FUTURE' | 'NO_RECORD';
  statusLabel: string;
  isWeekend: boolean;
  isHoliday: boolean;
  holidayName?: string;
  isToday: boolean;
  isFuture: boolean;
  record?: AttendanceRecord;
  leaveApplication?: StudentLeaveApplication;
}

export interface GuardianAttendanceSummary {
  totalSchoolDays: number;
  presentCount: number;
  absentCount: number;
  lateCount: number;
  leaveCount: number;
  attendancePercentage: number;
}

export interface GuardianChildAttendanceOverviewData {
  student: GuardianChildSummary;
  summary: GuardianAttendanceSummary;
  filterMonth: string; // 'YYYY-MM'
  filterAcademicSessionId?: string;
  calendarDays: GuardianChildAttendanceDay[];
  records: AttendanceRecord[];
  leaveApplications: StudentLeaveApplication[];
  availableSessions: Array<{ id: string; name: string; isActive: boolean }>;
}

export interface GuardianLeaveSubmissionPayload {
  studentId: string;
  leaveDate: string;
  endDate?: string;
  reason: string;
  description: string;
  attachmentUrl?: string;
  attachmentName?: string;
}

// -------------------------------------------------------------
// PART 5D: GUARDIAN ACADEMIC ACTIVITIES (HOMEWORK, ASSIGNMENTS, STUDY MATERIALS, ANNOUNCEMENTS)
// -------------------------------------------------------------

export interface GuardianChildHomeworkResponse {
  student: GuardianChildSummary;
  data: StudentHomeworkItem[];
  total: number;
  stats: {
    total: number;
    active: number;
    dueSoon: number;
    overdue: number;
  };
  subjects: Array<{ id: string; name: string; code: string }>;
}

export interface GuardianChildAssignmentResponse {
  student: GuardianChildSummary;
  data: StudentAssignmentItem[];
  total: number;
  stats: {
    total: number;
    active: number;
    dueSoon: number;
    overdue: number;
  };
  subjects: Array<{ id: string; name: string; code: string }>;
}

export interface GuardianChildMaterialResponse {
  student: GuardianChildSummary;
  data: StudyMaterial[];
  total: number;
  stats: {
    total: number;
    bySubject: Array<{ subjectName: string; count: number }>;
  };
  subjects: Array<{ id: string; name: string; code: string }>;
}

export interface GuardianChildAnnouncementResponse {
  student: GuardianChildSummary;
  data: ClassAnnouncement[];
  total: number;
  stats: {
    total: number;
    urgentCount: number;
    highCount: number;
  };
}

export interface GuardianChildActivitiesSummaryResponse {
  student: GuardianChildSummary;
  summary: StudentActivitiesSummary;
}

// -------------------------------------------------------------
// PART 5E: GUARDIAN EXAMINATION, RESULTS & ACADEMIC PROGRESS TYPES
// -------------------------------------------------------------

export interface GuardianChildExaminationsResponse {
  student: GuardianChildSummary;
  data: ExamScheduleItem[];
  total: number;
  stats: {
    total: number;
    scheduled: number;
    completed: number;
    ongoing: number;
  };
  availableSessions: Array<{ id: string; name: string; isActive: boolean }>;
  availableExams: Array<{ id: string; name: string; type: string }>;
  availableSubjects: Array<{ id: string; name: string; code: string }>;
}

export interface GuardianChildResultsResponse {
  student: GuardianChildSummary;
  data: StudentExamResult[];
  total: number;
  summary: {
    latestResult: StudentExamResult | null;
    totalExamsTaken: number;
    cumulativeGPA: number;
    currentSessionGPA: number;
    overallGrade: string;
    academicStanding: string;
  };
  availableSessions: Array<{ id: string; name: string; year?: string }>;
  availableExams: Array<{ id: string; name: string; type?: string }>;
  availableYears: string[];
}

export interface GuardianChildProgressResponse {
  student: GuardianChildSummary;
  progress: StudentAcademicProgressOverview;
  overview: {
    cumulativeGPA: number;
    currentGPA: number;
    overallGrade: string;
    averagePercentage: number;
    highestPercentage: number;
    totalCreditsCompleted: number;
    totalExamsTaken: number;
    academicStanding: string;
  };
  attendanceCorrelation?: {
    correlationRating: string;
    attendancePercentage: number;
    academicAveragePercentage: number;
    narrativeInsight: string;
  };
  subjectTrends: Array<{
    subjectId: string;
    subjectName: string;
    subjectCode: string;
    credits: number;
    averageMarks: number;
    highestMarks: number;
    latestGrade: string;
    latestGradePoint: number;
    trend: 'UP' | 'DOWN' | 'STABLE' | string;
    delta: number;
  }>;
  examTrends: Array<{
    examId: string;
    examName: string;
    academicYear: string;
    term: string;
    percentage: number;
    gpa: number;
    grade: string;
    totalObtainedMarks: number;
    totalFullMarks: number;
  }>;
}

export interface GuardianChildComparisonItem {
  studentId: string;
  studentName: string;
  className: string;
  sectionName: string;
  rollNumber: string;
  admissionNumber: string;
  student: GuardianChildSummary;
  attendancePercentage: number;
  totalSchoolDays: number;
  presentDays: number;
  absentDays: number;
  lateDays: number;
  attendance: {
    percentage: number;
    presentDays: number;
    totalDays: number;
    absentDays: number;
  };
  latestResult: {
    examName: string;
    term: string;
    publishDate: string;
    overallPercentage: number;
    gpa: number;
    overallGrade: string;
    resultStatus: string;
    totalObtainedMarks: number;
    totalFullMarks: number;
    classRank?: number;
    totalStudentsInClass?: number;
  } | null;
  cumulativeGPA: number;
  totalExamsTaken: number;
  overallPercentageAverage: number;
  averagePercentage: number;
  overallGrade: string;
  totalSubjectsEnrolled: number;
  totalPendingActivities: number;
  status: string;
}

export interface GuardianChildrenComparisonResponse {
  guardian: {
    id: string;
    name: string;
    email: string;
  };
  totalChildren: number;
  children: GuardianChildComparisonItem[];
  comparison: GuardianChildComparisonItem[];
}

// ==========================================
// Phase 5F: Guardian Fees & Payment Types
// ==========================================

export type FeePaymentStatus =
  | 'DRAFT'
  | 'UNPAID'
  | 'DUE'
  | 'PARTIAL'
  | 'PARTIALLY_PAID'
  | 'PAID'
  | 'OVERDUE'
  | 'CANCELLED'
  | 'PENDING'
  | 'REFUNDED';
export type PaymentMethod =
  | 'CREDIT_CARD'
  | 'DEBIT_CARD'
  | 'NET_BANKING'
  | 'BANK_TRANSFER'
  | 'DIGITAL_WALLET'
  | 'CASH'
  | 'CHEQUE'
  | 'MOBILE_BANKING'
  | 'ONLINE_PAYMENT'
  | 'OTHER';

export interface StudentFeeRecord {
  id: string;
  feeStructureId?: string;
  feeTypeId?: string;
  feeTypeCode?: string;
  studentId: string;
  studentName: string;
  admissionNumber: string;
  rollNumber?: string;
  classId: string;
  className: string;
  sectionId: string;
  sectionName: string;
  academicSessionId: string;
  academicSessionName: string;
  term: string;
  feeType: string;
  frequency?: FeeFrequency;
  title: string;
  description: string;
  invoiceNumber: string;
  totalAmount: number;
  discountAmount: number;
  discountReason?: string;
  discountId?: string;
  scholarshipAmount?: number;
  scholarshipName?: string;
  scholarshipId?: string;
  waiverAmount?: number;
  waiverReason?: string;
  waiverId?: string;
  fineAmount?: number;
  fineReason?: string;
  fineRuleId?: string;
  netPayableAmount: number;
  paidAmount: number;
  dueAmount: number;
  dueDate: string;
  status: FeePaymentStatus;
  currency?: string;
  isMandatory?: boolean;
  feeCategory?: FeeCategory;
  appliedAdjustments?: Array<{
    type: 'DISCOUNT' | 'SCHOLARSHIP' | 'WAIVER' | 'FINE';
    id: string;
    name: string;
    amount: number;
    appliedAt: string;
    appliedBy?: string;
    notes?: string;
  }>;
  notes?: string;
  createdBy?: string;
  installments?: Array<{
    id: string;
    installmentNumber: number;
    amount: number;
    dueDate: string;
    isPaid: boolean;
    paidDate?: string;
  }>;
  createdAt: string;
  updatedAt: string;
}

export interface FeePaymentTransaction {
  id: string;
  transactionId: string;
  receiptNumber: string;
  feeRecordId: string;
  invoiceNumber?: string;
  studentId: string;
  studentName: string;
  guardianId?: string;
  guardianName?: string;
  academicSessionId: string;
  feeType: string;
  feeTitle: string;
  amountPaid: number;
  amount?: number;
  paymentMethod: PaymentMethod | string;
  paymentMethodLabel: string;
  paymentDate: string;
  paymentStatus: 'SUCCESS' | 'PENDING' | 'FAILED' | 'REFUNDED' | 'REVERSED' | 'VOIDED';
  status?: string;
  gatewayReference?: string;
  referenceNumber?: string;
  notes?: string;
  payerEmail?: string;
  payerPhone?: string;
  collectedById?: string;
  collectedByName?: string;
  collectedBy?: string;
  previousDue?: number;
  remainingDue?: number;
  isReversed?: boolean;
  reversedAt?: string;
  reversedById?: string;
  reversedByName?: string;
  reversalReason?: string;
  idempotencyKey?: string;
  createdAt: string;
}

export interface FeePaymentReceipt {
  receiptNumber: string;
  transactionId: string;
  schoolInfo: {
    name: string;
    code: string;
    address: string;
    phone: string;
    email: string;
    website?: string;
    affiliationNumber?: string;
    principalName?: string;
    currency: string;
    currencySymbol: string;
  };
  studentInfo: {
    id: string;
    name: string;
    admissionNumber: string;
    rollNumber?: string;
    className: string;
    sectionName: string;
  };
  guardianInfo?: {
    id?: string;
    name?: string;
    relation?: string;
    phone?: string;
    email?: string;
  };
  feeInfo: {
    feeRecordId: string;
    invoiceNumber?: string;
    feeType: string;
    title: string;
    academicSession: string;
    term?: string;
    totalFee: number;
    discount: number;
    scholarship?: number;
    waiver?: number;
    fine?: number;
    netPayable: number;
    previouslyPaid: number;
    amountPaidNow: number;
    remainingDue: number;
  };
  paymentDetails: {
    paymentDate: string;
    paymentMethod: string;
    paymentMethodLabel?: string;
    paymentStatus: string;
    gatewayReference?: string;
    referenceNumber?: string;
    authorizedSignatory?: string;
    collectedBy?: string;
    collectedByName?: string;
    notes?: string;
    isReversed?: boolean;
    reversedAt?: string;
    reversalReason?: string;
    reversedByName?: string;
  };
  issuedAt: string;
}

export interface GuardianFeeSummary {
  totalFees: number;
  totalPayable?: number;
  totalPaid: number;
  totalDue: number;
  totalOverdue: number;
  totalDiscount: number;
  totalWaiver?: number;
  totalScholarship?: number;
  totalFine?: number;
  fullyPaidCount: number;
  partiallyPaidCount: number;
  unpaidCount: number;
  overdueCount: number;
  nextUpcomingDueDate: string | null;
}

export interface GuardianChildFeesResponse {
  student: GuardianChildSummary;
  data: StudentFeeRecord[];
  total: number;
  summary: GuardianFeeSummary;
  availableSessions: Array<{ id: string; name: string }>;
  availableFeeTypes: string[];
}

export interface GuardianChildFeeDetailResponse {
  student: GuardianChildSummary;
  fee: StudentFeeRecord;
  transactions: FeePaymentTransaction[];
  summary: GuardianFeeSummary;
}

export interface GuardianPaymentHistoryResponse {
  student?: GuardianChildSummary;
  data: FeePaymentTransaction[];
  total: number;
  totalAmountPaid: number;
  availableChildren: GuardianChildSummary[];
  children?: GuardianChildSummary[];
  availablePaymentMethods: string[];
}

export interface GuardianFamilyFeeOverviewResponse {
  guardian: {
    id: string;
    name: string;
    email: string;
  };
  totalChildren: number;
  familySummary: GuardianFeeSummary;
  childrenSummaries: Array<{
    student: GuardianChildSummary;
    summary: GuardianFeeSummary;
    fees: StudentFeeRecord[];
    latestPayment?: FeePaymentTransaction;
  }>;
}

// ==========================================
// Part 7A: Fee Structure & Fee Type Management Types
// ==========================================

export type FeeFrequency = 'ONE_TIME' | 'MONTHLY' | 'QUARTERLY' | 'HALF_YEARLY' | 'YEARLY' | 'CUSTOM';

export type FeeStructureStatus = 'DRAFT' | 'ACTIVE' | 'INACTIVE' | 'ARCHIVED';

export type FeeCategory = 'MANDATORY' | 'OPTIONAL';

export type FeeTypeStatus = 'ACTIVE' | 'INACTIVE';

export type FeeTypeCategory =
  | 'ACADEMIC'
  | 'FACILITY'
  | 'TRANSPORT'
  | 'HOSTEL'
  | 'MISCELLANEOUS'
  | 'ADMINISTRATIVE'
  | 'EXTRACURRICULAR';

export interface FeeType {
  id: string;
  name: string;
  code: string;
  category: FeeTypeCategory;
  description?: string;
  isDefault: boolean;
  status: FeeTypeStatus;
  createdAt: string;
  updatedAt: string;
  createdBy?: string;
  updatedBy?: string;
}

export interface FeeStructure {
  id: string;
  name: string;
  feeTypeId: string;
  feeTypeName: string;
  feeTypeCode?: string;
  academicSessionId: string;
  academicSessionName: string;
  classId: string;
  className: string;
  sectionId?: string | null;
  sectionName?: string | null;
  applicableToAllSections: boolean;
  amount: number;
  currency: string;
  frequency: FeeFrequency;
  dueDate: string; // ISO string format: YYYY-MM-DD
  isMandatory: boolean;
  feeCategory: FeeCategory;
  status: FeeStructureStatus;
  description?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
  createdBy?: string;
  updatedBy?: string;
}

export interface CreateFeeTypePayload {
  name: string;
  code: string;
  category: FeeTypeCategory;
  description?: string;
  status?: FeeTypeStatus;
}

export interface UpdateFeeTypePayload {
  name?: string;
  code?: string;
  category?: FeeTypeCategory;
  description?: string;
  status?: FeeTypeStatus;
}

export interface CreateFeeStructurePayload {
  name: string;
  feeTypeId: string;
  academicSessionId: string;
  classId: string;
  sectionId?: string | null;
  applicableToAllSections?: boolean;
  amount: number;
  currency?: string;
  frequency: FeeFrequency;
  dueDate: string;
  isMandatory?: boolean;
  feeCategory?: FeeCategory;
  status?: FeeStructureStatus;
  description?: string;
  notes?: string;
}

export interface UpdateFeeStructurePayload {
  name?: string;
  feeTypeId?: string;
  academicSessionId?: string;
  classId?: string;
  sectionId?: string | null;
  applicableToAllSections?: boolean;
  amount?: number;
  currency?: string;
  frequency?: FeeFrequency;
  dueDate?: string;
  isMandatory?: boolean;
  feeCategory?: FeeCategory;
  status?: FeeStructureStatus;
  description?: string;
  notes?: string;
}

export interface FeeStructureFilterParams {
  academicSessionId?: string;
  classId?: string;
  sectionId?: string;
  feeTypeId?: string;
  status?: string;
  feeCategory?: string;
  frequency?: string;
  search?: string;
  page?: number;
  limit?: number;
}

export interface FeeStructureSummaryStats {
  totalStructures: number;
  activeStructures: number;
  draftStructures: number;
  inactiveStructures: number;
  archivedStructures: number;
  totalFeeTypes: number;
  mandatoryCount: number;
  optionalCount: number;
  totalAnnualValueEstimate: number;
}

// ==========================================
// Part 7B: Student Fee Assignment & Invoice Management Types
// ==========================================

export type FeeAssignmentType = 'INDIVIDUAL' | 'CLASS' | 'SECTION';

export interface AssignStudentFeePayload {
  assignmentType: FeeAssignmentType;
  academicSessionId: string;
  classId: string;
  sectionId?: string | null;
  studentId?: string | null;
  studentIds?: string[];
  feeStructureIds?: string[];
  autoDetermineApplicable?: boolean;
  customDueDate?: string;
  discountAmount?: number;
  discountReason?: string;
  notes?: string;
}

export interface SkippedFeeAssignmentDetail {
  studentId: string;
  studentName: string;
  admissionNumber?: string;
  feeStructureId: string;
  feeTitle: string;
  reason: string;
}

export interface AssignStudentFeeResponse {
  success: boolean;
  message: string;
  assignedCount: number;
  skippedCount: number;
  assignedRecords: StudentFeeRecord[];
  skippedDetails: SkippedFeeAssignmentDetail[];
}

export interface ApplicableFeeStructureItem {
  structure: FeeStructure;
  isAlreadyAssigned: boolean;
  assignedRecordId?: string;
  assignedInvoiceNumber?: string;
  currentStatus?: FeePaymentStatus;
}

export interface StudentFeeFilterParams {
  academicSessionId?: string;
  classId?: string;
  sectionId?: string;
  studentId?: string;
  feeTypeId?: string;
  feeStructureId?: string;
  status?: string;
  dueDateFrom?: string;
  dueDateTo?: string;
  search?: string;
  page?: number;
  limit?: number;
}

export interface StudentFeeSummaryStats {
  totalInvoices: number;
  totalAmount: number;
  totalDiscount: number;
  totalFine: number;
  totalNetPayable: number;
  totalPaid: number;
  totalDue: number;
  paidCount: number;
  unpaidCount: number;
  partialCount: number;
  overdueCount: number;
  draftCount: number;
  cancelledCount: number;
  studentsWithDuesCount: number;
}

export interface StudentFeeListResponse {
  data: StudentFeeRecord[];
  fees?: StudentFeeRecord[];
  items?: StudentFeeRecord[];
  records?: StudentFeeRecord[];
  total: number;
  summary: StudentFeeSummaryStats;
  page?: number;
  limit?: number;
  totalPages?: number;
}

export interface ApplyFeeDiscountPayload {
  discountAmount: number;
  discountReason: string;
}

export interface ApplyFeeFinePayload {
  fineAmount: number;
  fineReason?: string;
}

export interface UpdateStudentFeeStatusPayload {
  status: 'DRAFT' | 'UNPAID' | 'CANCELLED';
  reason?: string;
}

export interface InvoiceDetailResponse {
  fee: StudentFeeRecord;
  student: {
    id: string;
    userId: string;
    admissionNumber: string;
    rollNumber: string;
    name: string;
    email?: string;
    avatarUrl?: string;
    classId: string;
    className: string;
    sectionId: string;
    sectionName: string;
    academicSessionId: string;
    academicSessionName: string;
    guardianName?: string;
    guardianEmail?: string;
    guardianPhone?: string;
    guardianRelation?: string;
    guardianAddress?: string;
  };
  schoolInfo: {
    schoolName: string;
    schoolCode: string;
    affiliationNumber?: string;
    address?: string;
    contactEmail?: string;
    contactPhone?: string;
    currency: string;
    currencySymbol: string;
  };
  transactions: FeePaymentTransaction[];
  discountsApplied?: any[];
  scholarshipsApplied?: any[];
  waiversApplied?: any[];
  finesApplied?: any[];
  breakdown: {
    originalAmount: number;
    discountAmount: number;
    scholarshipAmount?: number;
    waiverAmount?: number;
    fineAmount: number;
    netPayableAmount: number;
    totalPaid: number;
    remainingDue: number;
    status: FeePaymentStatus;
    isOverdue: boolean;
    daysOverdue: number;
    discountsApplied?: Array<{ name: string; amount: number; reason?: string }>;
    scholarshipsApplied?: Array<{ name: string; amount: number }>;
    waiversApplied?: Array<{ reason: string; amount: number; approvedBy?: string }>;
    finesApplied?: Array<{ reason?: string; amount: number; ruleName?: string }>;
  };
}

// ==========================================
// Part 7C: Fee Collection & Payment Management Types
// ==========================================

export interface PaymentMethodConfig {
  id: string;
  code: string;
  name: string;
  description?: string;
  isActive: boolean;
  requiresReference: boolean;
  displayOrder: number;
}

export interface CollectFeePaymentPayload {
  feeRecordId: string;
  amount: number;
  paymentDate: string;
  paymentMethod: PaymentMethod | string;
  referenceNumber?: string;
  notes?: string;
  cardholderName?: string;
  idempotencyKey?: string;
}

export interface CollectFeePaymentResponse {
  success: boolean;
  message: string;
  data: {
    transaction: FeePaymentTransaction;
    feeRecord: StudentFeeRecord;
    receiptNumber: string;
  };
}

export interface ReverseFeePaymentPayload {
  reason: string;
}

export interface ReverseFeePaymentResponse {
  success: boolean;
  message: string;
  data: {
    transaction: FeePaymentTransaction;
    feeRecord: StudentFeeRecord;
  };
}

export interface FeePaymentFilterParams {
  search?: string;
  studentId?: string;
  feeRecordId?: string;
  classId?: string;
  paymentMethod?: string;
  status?: string;
  startDate?: string;
  endDate?: string;
  page?: number;
  limit?: number;
}

export interface FeePaymentListResponse {
  transactions: FeePaymentTransaction[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
  summary: {
    totalCollected: number;
    totalTransactions: number;
    reversedCount: number;
    reversedAmount: number;
  };
}

export interface FeeCollectionSummaryStats {
  totalCollectedToday: number;
  totalCollectedMonth: number;
  totalCollectedAllTime: number;
  totalTransactions: number;
  reversedTransactionsCount: number;
  reversedAmount: number;
  activeInvoicesWithDue: number;
  totalDueOutstanding: number;
}

// ==========================================
// Part 7D: Discounts, Fines, Waivers & Scholarships Types
// ==========================================

export type DiscountType = 'FIXED' | 'PERCENTAGE';
export type DiscountScope = 'ALL' | 'STUDENT' | 'CLASS' | 'SECTION' | 'FEE_TYPE';
export type DiscountStatus = 'ACTIVE' | 'INACTIVE' | 'EXPIRED';
export type AdjustmentApprovalStatus = 'PENDING' | 'APPROVED' | 'REJECTED' | 'CANCELLED';

export interface FeeDiscountRule {
  id: string;
  code: string;
  name: string;
  ruleName?: string;
  discountType: DiscountType;
  value: number; // fixed dollar amount or percentage 1-100
  scope: DiscountScope;
  studentId?: string;
  studentName?: string;
  admissionNumber?: string;
  classId?: string;
  className?: string;
  sectionId?: string;
  sectionName?: string;
  feeTypeId?: string;
  feeTypeName?: string;
  applicableFeeType?: string; // 'ALL' or specific fee type title
  academicSessionId: string;
  academicSessionName?: string;
  startDate: string;
  endDate: string;
  status: DiscountStatus;
  approvalStatus: AdjustmentApprovalStatus;
  approvedById?: string;
  approvedByName?: string;
  approvedAt?: string;
  rejectionReason?: string;
  description?: string;
  appliedCount: number;
  totalDiscountGiven: number;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface CreateDiscountRulePayload {
  name: string;
  ruleName?: string;
  code?: string;
  discountType: DiscountType;
  value: number;
  scope: DiscountScope;
  studentId?: string;
  classId?: string;
  sectionId?: string;
  feeTypeId?: string;
  applicableFeeType?: string;
  academicSessionId: string;
  startDate: string;
  endDate: string;
  description?: string;
  status?: DiscountStatus;
}

export interface UpdateDiscountRulePayload {
  name?: string;
  ruleName?: string;
  discountType?: DiscountType;
  value?: number;
  scope?: DiscountScope;
  studentId?: string;
  classId?: string;
  sectionId?: string;
  feeTypeId?: string;
  applicableFeeType?: string;
  academicSessionId?: string;
  startDate?: string;
  endDate?: string;
  description?: string;
  status?: DiscountStatus;
}

export interface ApplyDiscountBatchPayload {
  academicSessionId?: string;
  classId?: string;
  sectionId?: string;
  feeTypeId?: string;
  targetStudentFeeIds?: string[];
}

export interface ApplyDiscountBatchResponse {
  success: boolean;
  message: string;
  data?: {
    appliedCount: number;
    updatedCount?: number;
    totalAmountDiscounted: number;
    totalAmountApplied?: number;
    affectedInvoices: Array<{
      feeRecordId: string;
      invoiceNumber: string;
      studentName: string;
      discountAmount: number;
      newNetPayable: number;
    }>;
  };
  appliedCount?: number;
  updatedCount?: number;
  totalAmountDiscounted?: number;
  totalAmountApplied?: number;
  affectedInvoices?: Array<{
    feeRecordId: string;
    invoiceNumber: string;
    studentName: string;
    discountAmount: number;
    newNetPayable: number;
  }>;
}

// ------------------------------------------
// Waivers
// ------------------------------------------

export type WaiverType = 'FULL' | 'PARTIAL_FIXED' | 'PARTIAL_PERCENTAGE';

export interface FeeWaiver {
  id: string;
  waiverNumber: string;
  studentId: string;
  studentName: string;
  admissionNumber: string;
  classId: string;
  className: string;
  sectionId?: string;
  sectionName?: string;
  feeRecordId: string;
  invoiceNumber: string;
  feeTitle: string;
  feeType: string;
  academicSessionId: string;
  academicSessionName?: string;
  waiverType: WaiverType;
  value: number; // percentage or fixed amount
  amount: number; // evaluated dollar amount
  originalFeeAmount: number;
  reason: string;
  status: AdjustmentApprovalStatus;
  requestedById: string;
  requestedByName: string;
  approvedById?: string;
  approvedByName?: string;
  approvedAt?: string;
  rejectionReason?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface CreateWaiverPayload {
  studentId: string;
  feeRecordId: string;
  waiverType: WaiverType;
  value: number;
  reason: string;
  notes?: string;
  autoApprove?: boolean;
}

export interface ApproveWaiverPayload {
  reason?: string;
  notes?: string;
}

export interface RejectWaiverPayload {
  reason?: string;
  rejectionReason?: string;
}

// ------------------------------------------
// Scholarships
// ------------------------------------------

export type ScholarshipType = 'FIXED' | 'PERCENTAGE' | 'FULL_TUITION' | 'MERIT' | 'NEED_BASED' | 'SPORTS' | 'SPECIAL_TALENT' | 'GOVERNMENT_ENDOWMENT';
export type ScholarshipStatus = 'PENDING' | 'APPROVED' | 'ACTIVE' | 'INACTIVE' | 'REJECTED' | 'CANCELLED' | 'EXPIRED';

export interface FeeScholarship {
  id: string;
  code: string;
  name: string;
  scholarshipName?: string;
  studentId: string;
  studentName: string;
  admissionNumber: string;
  classId: string;
  className: string;
  academicSessionId: string;
  academicSessionName?: string;
  scholarshipType: ScholarshipType;
  coverageType?: 'PERCENTAGE' | 'FIXED' | 'FULL';
  value: number;
  amount: number; // computed estimated dollar amount
  applicableFeeType: string; // 'ALL' or specific fee type title, e.g. 'Tuition Fee'
  applicableFeeTypeId?: string;
  startDate: string;
  endDate: string;
  status: ScholarshipStatus;
  approvedById?: string;
  approvedByName?: string;
  approvedAt?: string;
  rejectionReason?: string;
  notes?: string;
  sponsorName?: string;
  disbursedAmount?: number;
  appliedCount: number;
  totalDisbursed: number;
  createdAt: string;
  updatedAt: string;
}

export interface CreateScholarshipPayload {
  name?: string;
  scholarshipName?: string;
  code?: string;
  studentId: string;
  academicSessionId: string;
  scholarshipType: ScholarshipType;
  coverageType?: 'PERCENTAGE' | 'FIXED' | 'FULL';
  value: number;
  applicableFeeType?: string;
  applicableFeeTypeId?: string;
  startDate: string;
  endDate: string;
  sponsorName?: string;
  description?: string;
  notes?: string;
  autoApprove?: boolean;
  status?: ScholarshipStatus;
}

export interface UpdateScholarshipPayload {
  name?: string;
  scholarshipName?: string;
  studentId?: string;
  academicSessionId?: string;
  scholarshipType?: ScholarshipType;
  coverageType?: 'PERCENTAGE' | 'FIXED' | 'FULL';
  value?: number;
  applicableFeeType?: string;
  applicableFeeTypeId?: string;
  startDate?: string;
  endDate?: string;
  sponsorName?: string;
  description?: string;
  notes?: string;
  status?: ScholarshipStatus;
}

// ------------------------------------------
// Fines & Fine Policies
// ------------------------------------------

export type FineType = 'FIXED' | 'PERCENTAGE' | 'DAILY_FIXED' | 'MANUAL' | 'LATE_PAYMENT' | 'LIBRARY_OVERDUE' | 'PROPERTY_DAMAGE' | 'DISCIPLINARY' | 'MANUAL_ADJUSTMENT';

export interface FeeFineRule {
  id: string;
  code: string;
  name: string;
  ruleName?: string;
  fineType: FineType;
  amount: number; // fixed amount or percentage rate or daily fixed rate
  gracePeriodDays: number;
  maxFineAmount?: number;
  maxFineLimit?: number;
  applicableFeeType: string; // 'ALL' or specific fee type title
  applicableFeeTypeId?: string;
  academicSessionId: string;
  academicSessionName?: string;
  startDate: string;
  endDate?: string;
  status: 'ACTIVE' | 'INACTIVE';
  description?: string;
  autoApply: boolean;
  appliedCount: number;
  totalFinesAssessed: number;
  createdAt: string;
  updatedAt: string;
}

export interface CreateFineRulePayload {
  name?: string;
  ruleName?: string;
  code?: string;
  fineType: FineType;
  amount: number;
  gracePeriodDays: number;
  maxFineAmount?: number;
  maxFineLimit?: number;
  applicableFeeType?: string;
  applicableFeeTypeId?: string;
  academicSessionId?: string;
  startDate?: string;
  endDate?: string;
  description?: string;
  autoApply?: boolean;
  status?: 'ACTIVE' | 'INACTIVE';
}

export interface UpdateFineRulePayload {
  name?: string;
  ruleName?: string;
  fineType?: FineType;
  amount?: number;
  gracePeriodDays?: number;
  maxFineAmount?: number;
  maxFineLimit?: number;
  applicableFeeType?: string;
  applicableFeeTypeId?: string;
  academicSessionId?: string;
  startDate?: string;
  endDate?: string;
  description?: string;
  autoApply?: boolean;
  status?: 'ACTIVE' | 'INACTIVE';
}

export interface AppliedFineRecord {
  id: string;
  feeRecordId: string;
  invoiceNumber: string;
  studentId: string;
  studentName: string;
  admissionNumber?: string;
  className?: string;
  fineRuleId?: string;
  fineRuleName?: string;
  fineType: FineType;
  fineAmount?: number;
  amount?: number;
  calculatedDate?: string;
  dueDate?: string;
  daysOverdue?: number;
  gracePeriodDays?: number;
  reason: string;
  status: 'APPLIED' | 'WAIVED' | 'CANCELLED';
  waivedReason?: string;
  waiveReason?: string;
  waiverReason?: string;
  waivedById?: string;
  waivedByName?: string;
  waivedAt?: string;
  appliedById?: string;
  appliedByName?: string;
  createdAt: string;
}

export interface ApplyManualFinePayload {
  feeRecordId: string;
  studentId?: string;
  fineAmount?: number;
  amount?: number;
  fineReason?: string;
  reason?: string;
  fineType?: FineType | string;
}

export interface WaiveFinePayload {
  reason?: string;
  waiveReason?: string;
  waiverReason?: string;
}

export interface AssessLateFinesPayload {
  academicSessionId?: string;
  fineRuleId?: string;
  classId?: string;
  assessmentDate?: string;
  asOfDate?: string;
  dryRun?: boolean;
}

export interface AssessLateFinesResponse {
  success: boolean;
  message: string;
  data?: {
    evaluatedCount: number;
    totalFineAssessed: number;
    ruleApplied: {
      ruleName: string;
      gracePeriodDays: number;
      fineType: string;
      amount: number;
    };
    assessedFines: Array<{
      id: string;
      feeRecordId: string;
      invoiceNumber: string;
      studentName: string;
      className: string;
      daysOverdue: number;
      amount: number;
      newDueAmount: number;
    }>;
  };
  assessedCount?: number;
  newFinesAppliedCount?: number;
  totalFineAmountApplied?: number;
  skippedCount?: number;
  appliedDetails?: Array<{
    feeRecordId: string;
    invoiceNumber: string;
    studentName: string;
    daysOverdue: number;
    gracePeriod: number;
    fineAmount: number;
    ruleName: string;
  }>;
}

// ------------------------------------------
// Adjustment Audit Trail & Summaries
// ------------------------------------------

export interface FeeAdjustmentAudit {
  id: string;
  adjustmentType: 'DISCOUNT' | 'WAIVER' | 'SCHOLARSHIP' | 'FINE';
  action: 'CREATED' | 'UPDATED' | 'APPLIED' | 'APPROVED' | 'REJECTED' | 'WAIVED' | 'CANCELLED';
  referenceId: string;
  referenceName: string;
  feeRecordId?: string;
  invoiceNumber?: string;
  studentId?: string;
  studentName?: string;
  amount?: number;
  previousAmount?: number;
  newAmount?: number;
  performedById: string;
  performedByName: string;
  performedByRole: string;
  reason?: string;
  details: string;
  timestamp: string;
}

export interface FeeAdjustmentSummaryStats {
  discounts: {
    activeRulesCount: number;
    totalDisbursed: number;
    totalApplications: number;
  };
  waivers: {
    approvedCount: number;
    pendingCount: number;
    rejectedCount: number;
    totalAmountWaived: number;
  };
  scholarships: {
    activeCount: number;
    totalDisbursed: number;
    uniqueRecipients: number;
  };
  fines: {
    activeRulesCount: number;
    activeFinesCount: number;
    totalFinesAssessed: number;
    totalFinesWaived: number;
  };
  totalActiveDiscounts?: number;
  totalDiscountAmountGiven?: number;
  totalActiveScholarships?: number;
  totalScholarshipsDisbursed?: number;
  totalPendingWaivers?: number;
  totalApprovedWaiversCount?: number;
  totalWaiverAmountGranted?: number;
  totalActiveFineRules?: number;
  totalFinesAssessedAmount?: number;
  totalFinesWaivedAmount?: number;
  pendingApprovalsCount?: number;
}

// ------------------------------------------
// Part 7E: Fee Due, Overdue & Fee Tracking Types
// ------------------------------------------

export type DueAgingBracket =
  | 'NOT_DUE'
  | 'DUE_SOON'
  | '1_15_DAYS'
  | '16_30_DAYS'
  | '31_60_DAYS'
  | '60_PLUS_DAYS';

export type DueStatusFilter = 'ALL' | 'DUE' | 'OVERDUE' | 'DUE_SOON' | 'PARTIAL' | 'PAID';

export interface FeeDueAgingSummary {
  notDueYet: { count: number; amount: number };
  dueSoon: { count: number; amount: number };
  overdue1to15: { count: number; amount: number };
  overdue16to30: { count: number; amount: number };
  overdue31to60: { count: number; amount: number };
  overdue60Plus: { count: number; amount: number };
}

export interface ClassWiseDueSummary {
  classId: string;
  className: string;
  totalStudents: number;
  totalStudentsWithDue: number;
  totalReceivable: number;
  totalCollected: number;
  totalDue: number;
  totalOverdue: number;
  defaulterRate: number; // percentage
  collectionRate: number; // percentage
}

export interface FeeTypeDueSummary {
  feeTypeId?: string;
  feeTypeName: string;
  feeTypeCode?: string;
  category?: string;
  totalInvoicesCount: number;
  totalInvoiced: number;
  totalCollected: number;
  totalDue: number;
  totalOverdue: number;
  collectionRate: number;
}

export interface FeeDueDashboardStats {
  totalReceivable: number;
  totalCollected: number;
  totalDue: number;
  totalOverdue: number;
  studentsWithDueCount: number;
  overdueInvoicesCount: number;
  totalActiveInvoices: number;
  paidInvoicesCount: number;
  partialInvoicesCount: number;
  dueSoonInvoicesCount: number;
  collectionEfficiencyRate: number;
  agingBreakdown: FeeDueAgingSummary;
  classWiseBreakdown: ClassWiseDueSummary[];
  feeTypeBreakdown: FeeTypeDueSummary[];
}

export interface FeeDueStudentItem {
  feeRecordId: string;
  invoiceNumber: string;
  studentId: string;
  studentName: string;
  admissionNumber: string;
  rollNumber?: string;
  classId: string;
  className: string;
  sectionId?: string;
  sectionName?: string;
  feeType: string;
  feeTitle: string;
  academicSessionId?: string;
  academicSessionName?: string;
  term?: string;
  totalAmount: number;
  discountAmount: number;
  scholarshipAmount: number;
  waiverAmount: number;
  fineAmount: number;
  netPayableAmount: number;
  paidAmount: number;
  dueAmount: number;
  dueDate: string;
  daysOverdue: number;
  isDueSoon: boolean;
  status: 'PAID' | 'PARTIAL' | 'DUE' | 'DUE_SOON' | 'OVERDUE' | 'CANCELLED';
  agingBracket: DueAgingBracket;
  guardianName?: string;
  guardianPhone?: string;
  guardianEmail?: string;
  guardianRelation?: string;
  lastReminderSentAt?: string;
  remindersCount?: number;
  createdAt: string;
}

export interface FeeDueFilterParams {
  academicSessionId?: string;
  classId?: string;
  sectionId?: string;
  feeTypeId?: string;
  status?: string;
  agingBracket?: string;
  minDueAmount?: number;
  maxDueAmount?: number;
  dueDateFrom?: string;
  dueDateTo?: string;
  search?: string;
  sortBy?: 'daysOverdue' | 'dueAmount' | 'dueDate' | 'studentName' | 'className' | 'netPayableAmount';
  sortOrder?: 'asc' | 'desc';
  page?: number;
  limit?: number;
}

export interface FeeDueStudentListResponse {
  data: FeeDueStudentItem[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
  summary: {
    totalReceivable: number;
    totalCollected: number;
    totalDue: number;
    totalOverdue: number;
    studentsWithDueCount: number;
    overdueInvoicesCount: number;
    dueSoonCount: number;
  };
}

export type ReminderChannel = 'IN_APP_NOTIFICATION' | 'SMS_PREVIEW' | 'EMAIL_PREVIEW' | 'SYSTEM_LOG';
export type ReminderType =
  | 'DUE_SOON'
  | 'OVERDUE_FIRST_NOTICE'
  | 'OVERDUE_SECOND_NOTICE'
  | 'FINAL_DEMAND'
  | 'GENERAL_REMINDER'
  | 'CUSTOM';

export interface FeeReminderLog {
  id: string;
  feeRecordId: string;
  invoiceNumber: string;
  studentId: string;
  studentName: string;
  admissionNumber?: string;
  className?: string;
  guardianId?: string;
  guardianName?: string;
  recipientContact?: string;
  channel: ReminderChannel;
  reminderType: ReminderType;
  title: string;
  message: string;
  dueAmountAtSend: number;
  dueDate: string;
  daysOverdueAtSend: number;
  sentAt: string;
  sentById: string;
  sentByName: string;
  sentByRole: string;
  status: 'DELIVERED' | 'SENT' | 'QUEUED';
  notes?: string;
}

export interface SendFeeReminderPayload {
  feeRecordIds: string[];
  channel: ReminderChannel;
  reminderType: ReminderType;
  customTitle?: string;
  customMessage?: string;
  notes?: string;
}

export interface SendFeeReminderResponse {
  success: boolean;
  message: string;
  sentCount: number;
  logs: FeeReminderLog[];
}

// ==========================================
// Part 7F: Financial Reports, Receipts & Statements Types
// ==========================================

export interface FinancialReportDashboardStats {
  totalFeesGenerated: number;
  totalNetPayable: number;
  totalCollected: number;
  totalOutstanding: number;
  totalOverdue: number;
  totalDiscounts: number;
  totalScholarshipsWaivers: number;
  totalScholarships: number;
  totalWaivers: number;
  totalFines: number;
  totalReversedAmount: number;
  collectionRate: number;
  kpis?: {
    totalFeesGenerated: number;
    totalNetPayable: number;
    totalCollected: number;
    totalOutstanding: number;
    totalOverdue: number;
    totalDiscounts: number;
    totalScholarshipsAndWaivers: number;
    totalFines: number;
    collectionEfficiencyRate: number;
  };
  reversals?: {
    count: number;
    volume: number;
  };
  invoicesCount: {
    total: number;
    paid: number;
    unpaid: number;
    partiallyPaid: number;
    overdue: number;
    cancelled: number;
  };
  transactionsCount: {
    total: number;
    successful: number;
    reversed: number;
  };
  monthlyTrends: {
    month: string;
    generated: number;
    invoiced?: number;
    collected: number;
    due: number;
  }[];
  categoryBreakdown: {
    category: string;
    generated: number;
    invoicedAmount?: number;
    collected: number;
    collectedAmount?: number;
    due: number;
    count: number;
  }[];
}

export interface CollectionReportFilterParams {
  startDate?: string;
  endDate?: string;
  academicSessionId?: string;
  classId?: string;
  sectionId?: string;
  feeTypeId?: string;
  paymentMethod?: string;
  collectedBy?: string;
  status?: string;
  search?: string;
  page?: number;
  limit?: number;
}

export interface CollectionReportTransactionItem {
  id: string;
  transactionId: string;
  receiptNumber: string;
  feeRecordId: string;
  invoiceNumber: string;
  studentId: string;
  studentName: string;
  admissionNumber?: string;
  studentAdmissionNumber?: string;
  rollNumber?: string;
  classId?: string;
  className: string;
  sectionId?: string;
  sectionName?: string;
  feeType: string;
  feeTitle: string;
  amountPaid: number;
  paymentMethod: string;
  paymentMethodLabel?: string;
  gatewayReference?: string;
  referenceNumber?: string;
  paymentDate: string;
  paymentStatus: 'SUCCESS' | 'REVERSED' | 'PENDING' | 'FAILED';
  collectedBy?: string;
  collectedByName?: string;
  reversalReason?: string;
  reversedAt?: string;
  payerEmail?: string;
  payerPhone?: string;
  notes?: string;
}

export interface CollectionReportResponse {
  data: CollectionReportTransactionItem[];
  transactions?: CollectionReportTransactionItem[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
  summary: {
    totalTransactions: number;
    grossCollected: number;
    reversedCount?: number;
    reversedTransactions?: number;
    reversedAmount?: number;
    reversedVolume?: number;
    netCollected: number;
  };
  paymentMethodBreakdown: {
    method: string;
    label: string;
    count: number;
    amount: number;
    percentage: number;
  }[];
  dailyCollection: {
    date: string;
    amount: number;
    transactionsCount: number;
  }[];
}

export interface FeeSummaryReportItem {
  id?: string;
  name?: string;
  code?: string;
  category?: string;
  assignedStudentsCount?: number;
  totalInvoiced?: number;
  totalDiscounts?: number;
  totalScholarships?: number;
  totalWaivers?: number;
  totalFines?: number;
  netPayable?: number;
  totalCollected: number;
  totalDue: number;
  collectionRate: number;

  feeTypeId?: string;
  feeTypeName?: string;
  feeCategory?: string;
  assignedCount?: number;
  totalOriginalAmount?: number;
  totalDiscount?: number;
  totalScholarship?: number;
  totalWaiver?: number;
  totalFine?: number;
  netPayableAmount?: number;
}

export interface FeeSummaryReportResponse {
  data: FeeSummaryReportItem[];
  feeTypes?: FeeSummaryReportItem[];
  summary: {
    totalStudents?: number;
    totalAssignedCount?: number;
    totalInvoiced?: number;
    totalOriginal?: number;
    totalDiscount?: number;
    totalDiscounts?: number;
    totalScholarship?: number;
    totalScholarships?: number;
    totalWaiver?: number;
    totalWaivers?: number;
    totalFine?: number;
    totalFines?: number;
    netPayable?: number;
    totalNetPayable?: number;
    totalCollected: number;
    totalDue: number;
    overallCollectionRate: number;
  };
}

export interface StudentStatementEntry {
  id: string;
  date: string;
  type:
    | 'INVOICE_GENERATED'
    | 'DISCOUNT_APPLIED'
    | 'SCHOLARSHIP_APPLIED'
    | 'WAIVER_APPLIED'
    | 'FINE_APPLIED'
    | 'PAYMENT_RECEIVED'
    | 'PAYMENT_REVERSED'
    | 'INVOICE_CANCELLED';
  referenceNo: string;
  description: string;
  feeType?: string;
  feeTitle?: string;
  debit: number;
  credit: number;
  runningBalance: number;
  metadata?: Record<string, any>;
}

export interface StudentAccountStatement {
  student: {
    id: string;
    name: string;
    admissionNumber: string;
    rollNumber?: string;
    className: string;
    sectionName?: string;
    academicSessionName: string;
    guardianName?: string;
    guardianPhone?: string;
    guardianEmail?: string;
    address?: string;
  };
  period: {
    startDate?: string;
    endDate?: string;
    sessionName: string;
    generatedAt: string;
  };
  summary: {
    totalBilled: number;
    totalDiscounts: number;
    totalScholarships: number;
    totalWaivers: number;
    totalFines: number;
    netPayable: number;
    totalPaid: number;
    currentDue: number;
    status: 'CLEARED' | 'PARTIAL_DUE' | 'DUE' | 'OVERDUE';
    invoicesCount: number;
    paymentsCount: number;
  };
  entries: StudentStatementEntry[];
}

export interface PaymentMethodReportResponse {
  summary: {
    totalTransactions: number;
    totalVolume: number;
    reversedTransactions: number;
    reversedVolume: number;
    netVolume: number;
  };
  methods: {
    methodCode: string;
    methodName: string;
    transactionCount: number;
    grossVolume: number;
    reversedVolume: number;
    netVolume: number;
    sharePercentage: number;
    averageTransactionValue: number;
    requiresReference: boolean;
  }[];
}

// Convenience Type Aliases
export type ClassItem = SchoolClass;
export type SectionItem = Section;
export type FeeTypeItem = FeeType;
export type AcademicSessionItem = AcademicSession;
export type StudentItem = StudentProfile;

// ==========================================
// PART 8A — ATTENDANCE SETTINGS & ACADEMIC CALENDAR
// ==========================================

export type DayOfWeekName = 'MONDAY' | 'TUESDAY' | 'WEDNESDAY' | 'THURSDAY' | 'FRIDAY' | 'SATURDAY' | 'SUNDAY';

export interface AttendanceStatusConfig {
  id: string;
  code: string; // 'PRESENT' | 'ABSENT' | 'LATE' | 'HALF_DAY' | 'LEAVE' | 'EXCUSED' | custom
  name: string;
  color: string;
  weight: number; // 1.0 (Present), 0.5 (Half day/Late), 0.0 (Absent)
  isLate: boolean;
  isExcused: boolean;
  isActive: boolean;
  description: string;
}

export interface StudentAttendanceRules {
  enabled: boolean;
  mode: 'ONCE_DAILY' | 'SUBJECT_WISE' | 'PERIOD_WISE';
  allowTeacherEdit: boolean;
  teacherEditGracePeriodHours: number;
  requireAdminApprovalForCorrection: boolean;
  autoNotifyParentsOnAbsent: boolean;
  cutoffTime: string; // e.g. "09:30"
  lateThresholdMinutes: number; // e.g. 15
  halfDayThresholdMinutes: number; // e.g. 120
  countLateAs: 'PRESENT' | 'LATE' | 'HALF_DAY' | 'PENALTY';
  consecutiveLateToAbsentThreshold: number; // e.g. 3 late = 1 absent penalty
  minimumAttendancePercentage?: number;
}

export interface TeacherAttendanceRules {
  enabled: boolean;
  mode: 'MANUAL_ENTRY' | 'BIOMETRIC_DEVICE' | 'SELF_CHECKIN';
  checkInStartTime: string; // e.g. "07:30"
  cutoffTime: string; // e.g. "08:30"
  lateThresholdMinutes: number; // e.g. 15
  halfDayThresholdMinutes: number; // e.g. 180
  requireGeofence: boolean;
}

export interface HolidayRulesConfig {
  autoMarkHolidayInAttendance: boolean;
  allowAttendanceOverrideOnHoliday: boolean;
  allowOvertimeOnHoliday: boolean;
}

export interface LeaveRulesConfig {
  requireAdvanceApplication: boolean;
  maxCasualLeavesPerYear: number;
  maxMedicalLeavesPerYear: number;
  autoApproveWithinDays: number;
}

export interface AttendanceSettings {
  id: string;
  studentAttendance: StudentAttendanceRules;
  teacherAttendance: TeacherAttendanceRules;
  workingDays: DayOfWeekName[];
  weekendDays: DayOfWeekName[];
  holidayRules: HolidayRulesConfig;
  leaveRules: LeaveRulesConfig;
  attendanceStatuses: AttendanceStatusConfig[];
  notifications?: AttendanceNotificationSettings;
  academicSessionId?: string;
  schoolId?: string;
  updatedAt: string;
  updatedBy: string;
  updatedByName?: string;
}

export type HolidayType = 'NATIONAL' | 'RELIGIOUS' | 'ACADEMIC_BREAK' | 'GOVERNMENT' | 'SPECIAL' | 'INSTITUTIONAL';

export interface HolidayRecord {
  id: string;
  holidayName: string;
  startDate: string; // 'YYYY-MM-DD'
  endDate: string;   // 'YYYY-MM-DD'
  holidayType: HolidayType;
  description: string;
  status: 'ACTIVE' | 'ARCHIVED';
  academicSessionId: string;
  academicSessionName?: string;
  createdAt: string;
  updatedAt: string;
}

export interface SpecialWorkingDayRecord {
  id: string;
  date: string; // 'YYYY-MM-DD'
  reason: string;
  overridesDayType: 'WEEKEND' | 'HOLIDAY';
  academicSessionId: string;
  academicSessionName?: string;
  status: 'ACTIVE' | 'ARCHIVED';
  createdAt: string;
  updatedAt: string;
}

export type CalendarEventType = 'ACADEMIC' | 'EXAM' | 'SPORTS' | 'CULTURAL' | 'MEETING' | 'HOLIDAY' | 'OTHER';

export interface SchoolCalendarEvent {
  id: string;
  title: string;
  startDate: string; // 'YYYY-MM-DD'
  endDate: string;   // 'YYYY-MM-DD'
  eventType: CalendarEventType;
  description: string;
  targetAudience: 'ALL' | 'STUDENTS' | 'TEACHERS' | 'PARENTS' | 'STAFF';
  academicSessionId: string;
  academicSessionName?: string;
  color?: string;
  createdAt: string;
  updatedAt: string;
}

export interface CalendarDayDetails {
  date: string; // 'YYYY-MM-DD'
  dayOfWeek: number; // 0 (Sun) - 6 (Sat)
  dayName: string; // e.g. 'Sunday', 'Monday'
  dayType: 'WORKING_DAY' | 'WEEKEND' | 'HOLIDAY' | 'SPECIAL_WORKING_DAY';
  isWorkingDay: boolean;
  holidays: HolidayRecord[];
  specialWorkingDays: SpecialWorkingDayRecord[];
  events: SchoolCalendarEvent[];
  exams?: any[];
}

export interface AcademicCalendarMonthViewResponse {
  academicSessionId: string;
  academicSessionName: string;
  year: number;
  month: number; // 1-12
  monthName: string;
  totalDays: number;
  totalWorkingDays: number;
  totalWeekends: number;
  totalHolidays: number;
  totalSpecialWorkingDays: number;
  totalEvents: number;
  days: CalendarDayDetails[];
  holidays: HolidayRecord[];
  specialWorkingDays: SpecialWorkingDayRecord[];
  events: SchoolCalendarEvent[];
  weekendDays: DayOfWeekName[];
}

// ==========================================
// PART 8B — TEACHER ATTENDANCE MANAGEMENT
// ==========================================

export type TeacherAttendanceStatus = 'PRESENT' | 'ABSENT' | 'LATE' | 'HALF_DAY' | 'LEAVE' | 'EXCUSED';

export interface TeacherAttendanceCorrectionHistoryItem {
  id: string;
  fromStatus: TeacherAttendanceStatus;
  toStatus: TeacherAttendanceStatus;
  fromCheckInTime?: string;
  toCheckInTime?: string;
  fromCheckOutTime?: string;
  toCheckOutTime?: string;
  reason: string;
  correctedByUserId: string;
  correctedByUserName: string;
  correctedAt: string;
}

export interface TeacherAttendanceRecord {
  id: string;
  teacherProfileId: string;
  userId: string;
  teacherName: string;
  employeeCode: string;
  departmentId?: string;
  departmentName?: string;
  avatarUrl?: string;
  academicSessionId: string;
  academicSessionName?: string;
  date: string; // 'YYYY-MM-DD'
  status: TeacherAttendanceStatus;
  checkInTime?: string; // 'HH:MM'
  checkOutTime?: string; // 'HH:MM'
  remarks?: string;
  isOverridden?: boolean;
  overrideReason?: string;
  history?: TeacherAttendanceCorrectionHistoryItem[];
  createdBy: string;
  createdByName?: string;
  updatedBy: string;
  updatedByName?: string;
  createdAt: string;
  updatedAt: string;
  isDeleted?: boolean;
  deletedAt?: string;
  deletedBy?: string;
}

export interface TeacherAttendanceSummaryStats {
  totalRecords: number;
  presentCount: number;
  absentCount: number;
  lateCount: number;
  halfDayCount: number;
  leaveCount: number;
  excusedCount: number;
  attendanceRate: number; // percentage (0-100)
}

export interface TeacherDailyAttendanceRosterItem {
  teacherProfileId: string;
  userId: string;
  teacherName: string;
  employeeCode: string;
  departmentId?: string;
  departmentName?: string;
  avatarUrl?: string;
  status?: TeacherAttendanceStatus;
  recordId?: string;
  checkInTime?: string;
  checkOutTime?: string;
  remarks?: string;
  isOverridden?: boolean;
  overrideReason?: string;
  history?: TeacherAttendanceCorrectionHistoryItem[];
  updatedAt?: string;
  updatedByName?: string;
}

export interface TeacherDailyAttendanceResponse {
  date: string;
  academicSessionId: string;
  academicSessionName: string;
  dayType: 'WORKING_DAY' | 'WEEKEND' | 'HOLIDAY' | 'SPECIAL_WORKING_DAY';
  isWorkingDay: boolean;
  dayReason: string;
  canMarkAttendance: boolean;
  stats: {
    totalTeachers: number;
    markedTeachers: number;
    presentCount: number;
    absentCount: number;
    lateCount: number;
    halfDayCount: number;
    leaveCount: number;
    excusedCount: number;
    unmarkedCount: number;
    attendanceRate: number;
  };
  roster: TeacherDailyAttendanceRosterItem[];
}

export interface TeacherMonthlyMatrixDay {
  date: string;
  dayOfMonth: number;
  dayOfWeek: number;
  dayName: string;
  dayType: 'WORKING_DAY' | 'WEEKEND' | 'HOLIDAY' | 'SPECIAL_WORKING_DAY';
  isWorkingDay: boolean;
  reason?: string;
}

export interface TeacherMonthlyMatrixRow {
  teacherProfileId: string;
  userId: string;
  teacherName: string;
  employeeCode: string;
  departmentName: string;
  avatarUrl?: string;
  attendanceByDate: Record<string, {
    status: TeacherAttendanceStatus;
    recordId?: string;
    checkInTime?: string;
    checkOutTime?: string;
    remarks?: string;
    isOverridden?: boolean;
  }>;
  summary: {
    totalApplicableWorkingDays: number;
    present: number;
    absent: number;
    late: number;
    halfDay: number;
    leave: number;
    excused: number;
    rate: number;
  };
}

export interface TeacherMonthlyAttendanceResponse {
  academicSessionId: string;
  academicSessionName: string;
  year: number;
  month: number;
  monthName: string;
  days: TeacherMonthlyMatrixDay[];
  teachers: TeacherMonthlyMatrixRow[];
  totalWorkingDays: number;
  overallSummary: {
    totalTeachers: number;
    averageAttendanceRate: number;
    totalPresent: number;
    totalAbsent: number;
    totalLate: number;
    totalHalfDay: number;
    totalLeave: number;
    totalExcused: number;
  };
}

export interface TeacherMyAttendanceDay {
  date: string;
  dayOfMonth: number;
  dayOfWeek: number;
  dayName: string;
  dayType: 'WORKING_DAY' | 'WEEKEND' | 'HOLIDAY' | 'SPECIAL_WORKING_DAY';
  isWorkingDay: boolean;
  reason?: string;
  status?: TeacherAttendanceStatus;
  checkInTime?: string;
  checkOutTime?: string;
  remarks?: string;
  recordId?: string;
  isOverridden?: boolean;
}

export interface TeacherMyAttendanceResponse {
  teacher: {
    teacherProfileId: string;
    userId: string;
    name: string;
    employeeCode: string;
    designation: string;
    departmentName: string;
    avatarUrl?: string;
  };
  academicSessionId: string;
  academicSessionName: string;
  year: number;
  month: number;
  monthName: string;
  summary: {
    totalWorkingDays: number;
    present: number;
    absent: number;
    late: number;
    halfDay: number;
    leave: number;
    excused: number;
    attendanceRate: number;
  };
  stats?: {
    totalWorkingDays: number;
    presentCount: number;
    absentCount: number;
    lateCount: number;
    halfDayCount: number;
    leaveCount: number;
    excusedCount: number;
    attendanceRate: number;
  };
  days?: TeacherMyAttendanceDay[];
  calendarDays: TeacherMyAttendanceDay[];
  historyRecords: TeacherAttendanceRecord[];
}

// =========================================================================
// PART 8E: ATTENDANCE REPORTS & ANALYTICS TYPES
// =========================================================================

export interface AttendanceReportFilterParams {
  academicSessionId?: string;
  date?: string;
  startDate?: string;
  endDate?: string;
  month?: string; // 'YYYY-MM'
  classId?: string;
  sectionId?: string;
  studentId?: string;
  teacherId?: string;
  departmentId?: string;
  status?: AttendanceStatus | 'ALL';
  leaveTypeId?: string;
  gender?: string;
  search?: string;
  belowThresholdOnly?: boolean;
  page?: number;
  limit?: number;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
}

export interface AttendanceReportPagination {
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}

export interface AttendanceReportDashboardData {
  summary?: {
    attendancePercentage: number;
    totalStudents: number;
    totalPresent: number;
    totalAbsent: number;
    totalLate: number;
    totalHalfDay: number;
    totalLeaves: number;
    totalExcused: number;
    totalRecords: number;
    defaultersCount: number;
  };
  studentStats: {
    totalEnrolled: number;
    present: number;
    absent: number;
    late: number;
    halfDay: number;
    excused: number;
    onLeave: number;
    averageAttendancePercentage: number;
    belowThresholdCount: number;
    thresholdPercentage: number;
  };
  classComparisons?: Array<{
    classId: string;
    className: string;
    attendancePercentage: number;
    totalStudents: number;
    totalRecords: number;
    present?: number;
    absent?: number;
  }>;
  statusBreakdown?: {
    present: number;
    absent: number;
    leave: number;
    late: number;
    halfDay: number;
  };
  teacherStats: {
    totalTeachers: number;
    present: number;
    absent: number;
    late: number;
    onLeave: number;
    halfDay: number;
    averageAttendancePercentage: number;
  };
  dailyTrends: Array<{
    date: string;
    dayName: string;
    present: number;
    absent: number;
    late: number;
    halfDay: number;
    leave: number;
    percentage: number;
    attendancePercentage?: number;
    total?: number;
  }>;
  monthlyTrends: Array<{
    month: string;
    monthName: string;
    present: number;
    absent: number;
    late: number;
    halfDay: number;
    leave: number;
    percentage: number;
  }>;
  classPercentages: Array<{
    classId: string;
    className: string;
    sectionId?: string;
    sectionName?: string;
    percentage: number;
    present: number;
    absent: number;
    total: number;
  }>;
  leaveDistribution: Array<{
    leaveTypeId: string;
    leaveTypeName: string;
    count: number;
    totalDays: number;
  }>;
  studentsBelowThreshold: Array<{
    studentId: string;
    studentName: string;
    rollNumber?: string;
    admissionNumber?: string;
    className: string;
    sectionName: string;
    percentage: number;
    present: number;
    absent: number;
    totalWorkingDays: number;
  }>;
}

export interface StudentWiseAttendanceReportItem {
  studentId: string;
  studentName: string;
  admissionNumber: string;
  rollNumber: string;
  gender?: string;
  classId: string;
  className: string;
  sectionId: string;
  sectionName: string;
  academicSessionId: string;
  academicSessionName?: string;
  totalWorkingDays: number;
  presentDays: number;
  absentDays: number;
  lateDays: number;
  halfDays: number;
  excusedDays: number;
  approvedLeaveDays: number;
  attendancePercentage: number;
  isBelowThreshold: boolean;
}

export interface ClassSectionAttendanceReportItem {
  classId: string;
  className: string;
  sectionId: string;
  sectionName: string;
  classTeacherName?: string;
  totalStudents: number;
  present: number;
  absent: number;
  late: number;
  halfDay: number;
  excused: number;
  leave: number;
  totalRecords: number;
  averageAttendancePercentage: number;
  attendancePercentage?: number;
}

export interface TeacherAttendanceReportItem {
  teacherProfileId: string;
  teacherName: string;
  employeeCode: string;
  departmentId?: string;
  departmentName: string;
  designation?: string;
  totalWorkingDays: number;
  present: number;
  absent: number;
  late: number;
  halfDay: number;
  leave: number;
  excused: number;
  attendancePercentage: number;
}

export interface AttendanceDetailedRecordReportItem {
  id: string;
  date: string;
  studentId: string;
  studentName: string;
  admissionNumber: string;
  rollNumber: string;
  classId: string;
  className: string;
  sectionId: string;
  sectionName: string;
  status: AttendanceStatus;
  remarks?: string;
  recordedByTeacherName: string;
  updatedByTeacherName?: string;
  isOverridden?: boolean;
  overrideReason?: string;
  correctionHistoryCount?: number;
}

export interface LeaveReportItem {
  id: string;
  applicantType: ApplicantType;
  applicantId: string;
  applicantName: string;
  details?: string;
  leaveTypeId: string;
  leaveTypeName: string;
  startDate: string;
  endDate: string;
  totalDays: number;
  workingDays: number;
  reason: string;
  status: LeaveStatus;
  appliedAt: string;
  reviewedBy?: string;
  reviewedAt?: string;
  reviewNotes?: string;
}

// =========================================================================
// PART 8F — ATTENDANCE NOTIFICATION & ALERT SYSTEM TYPES
// =========================================================================

export type AttendanceNotificationEventType =
  | 'STUDENT_ABSENT'
  | 'STUDENT_LATE'
  | 'STUDENT_HALF_DAY'
  | 'LEAVE_SUBMITTED'
  | 'LEAVE_APPROVED'
  | 'LEAVE_REJECTED'
  | 'LEAVE_CANCELLED'
  | 'ATTENDANCE_CORRECTION';

export type AttendanceNotificationChannel = 'IN_APP' | 'EMAIL' | 'SMS' | 'PUSH';

export type AttendanceNotificationStatus =
  | 'PENDING'
  | 'PROCESSING'
  | 'SENT'
  | 'QUEUED'
  | 'SUPPRESSED'
  | 'FAILED'
  | 'RETRYING'
  | 'CANCELLED';

export interface AttendanceNotificationChannelToggles {
  inApp: boolean;
  email: boolean;
  sms: boolean;
  push: boolean;
}

export interface AttendanceNotificationRecipientsConfig {
  guardian: boolean;
  student: boolean;
  staff: boolean;
}

export interface AttendanceAlertEventConfig {
  enabled: boolean;
  channels: AttendanceNotificationChannelToggles;
  recipients: AttendanceNotificationRecipientsConfig;
}

export interface AttendanceProviderStatusInfo {
  active: boolean;
  status: 'ACTIVE' | 'SANDBOX_READY' | 'NOT_CONFIGURED' | 'DISABLED';
  providerName: string;
  description: string;
  isExternalReady: boolean;
}

export interface AttendanceNotificationSettings {
  id: string;
  studentAbsentAlert: AttendanceAlertEventConfig;
  studentLateAlert: AttendanceAlertEventConfig;
  studentHalfDayAlert: AttendanceAlertEventConfig;
  leaveSubmittedAlert: AttendanceAlertEventConfig;
  leaveApprovedAlert: AttendanceAlertEventConfig;
  leaveRejectedAlert: AttendanceAlertEventConfig;
  leaveCancelledAlert: AttendanceAlertEventConfig;
  attendanceCorrectionAlert: AttendanceAlertEventConfig;
  preventDuplicates: boolean;
  deduplicationWindowMinutes: number;
  maxRetries: number;
  retryDelayMinutes: number;
  batchSize: number;
  providerStatus: {
    inApp: AttendanceProviderStatusInfo;
    email: AttendanceProviderStatusInfo;
    sms: AttendanceProviderStatusInfo;
    push: AttendanceProviderStatusInfo;
  };
  updatedAt: string;
  updatedBy: string;
  updatedByName?: string;
}

export interface AttendanceNotificationTemplate {
  id: string;
  eventType: AttendanceNotificationEventType;
  name: string;
  description: string;
  titleTemplate: string;
  bodyTemplate: string;
  allowedVariables: string[];
  updatedAt: string;
  updatedBy: string;
}

export interface AttendanceNotificationLog {
  id: string;
  dedupKey: string;
  eventType: AttendanceNotificationEventType;
  channel: AttendanceNotificationChannel;
  recipientId: string;
  recipientUserId?: string;
  recipientName: string;
  recipientRole: 'GUARDIAN' | 'STUDENT' | 'TEACHER' | 'SUPER_ADMIN';
  recipientContact?: string;
  title: string;
  message: string;
  relatedStudentId?: string;
  relatedStudentName?: string;
  relatedTeacherId?: string;
  relatedTeacherName?: string;
  attendanceRecordId?: string;
  leaveApplicationId?: string;
  date: string;
  status: AttendanceNotificationStatus;
  retryCount: number;
  maxRetries: number;
  failureReason?: string;
  metadata?: Record<string, any>;
  createdAt: string;
  sentAt?: string;
  deliveredAt?: string;
}

export interface AttendanceNotificationStats {
  totalLogged: number;
  sentCount: number;
  failedCount: number;
  pendingCount: number;
  inAppCount: number;
  emailCount: number;
  smsCount: number;
  pushCount: number;
  byEventType: Record<string, number>;
}

export interface AttendanceNotificationFilterParams {
  startDate?: string;
  endDate?: string;
  eventType?: string;
  channel?: string;
  status?: string;
  studentId?: string;
  teacherId?: string;
  search?: string;
  page?: number;
  limit?: number;
}

// =========================================================================
// PART 9D: STUDENT DOCUMENTS & ID CARD MANAGEMENT TYPES
// =========================================================================

export type StudentIDCardStatus =
  | 'NOT_ISSUED'
  | 'GENERATED'
  | 'PRINTED'
  | 'ISSUED'
  | 'BLOCKED_LOST';

export type StudentIDCardTemplateLayout =
  | 'modern-vertical'
  | 'classic-horizontal'
  | 'minimalist-academic'
  | 'smart-card';

export interface StudentIDCardReissueRecord {
  reissueDate: string;
  reason: string;
  reissuedBy: string;
  reissuedByName?: string;
  previousCardNumber: string;
}

export interface StudentIDCard {
  id: string;
  studentId: string;
  studentName?: string;
  admissionNumber: string;
  cardNumber: string; // e.g. IDC-2026-00842
  templateId: StudentIDCardTemplateLayout | string;
  status: StudentIDCardStatus;
  academicSessionId: string;
  academicSessionName: string;
  classId?: string;
  className?: string;
  sectionId?: string;
  sectionName?: string;
  rollNumber?: string;
  bloodGroup?: string;
  emergencyContact?: string;
  avatarUrl?: string;
  issueDate: string;
  expiryDate: string;
  issuedBy: string;
  issuedByName: string;
  reissueCount: number;
  reissueHistory?: StudentIDCardReissueRecord[];
  qrCodeData: string;
  barcodeData: string;
  digitalSignatureUrl?: string;
  customNotes?: string;
  blockedReason?: string;
  blockedAt?: string;
  blockedBy?: string;
  createdAt: string;
  updatedAt: string;
}

export interface StudentIDCardTemplate {
  id: string;
  name: string;
  orientation: 'portrait' | 'landscape';
  themeColor: string;
  secondaryColor: string;
  layout: StudentIDCardTemplateLayout;
  showQrCode: boolean;
  showBarcode: boolean;
  showEmergencyContact: boolean;
  showBloodGroup: boolean;
  showAddress: boolean;
  showPrincipalSignature: boolean;
  schoolLogoUrl?: string;
  schoolName: string;
  schoolCode: string;
  affiliationText?: string;
  termsAndConditions: string;
  isDefault?: boolean;
}

export interface StudentIDCardStats {
  totalStudents: number;
  totalCardsIssued: number;
  totalCardsPrinted: number;
  totalCardsGenerated: number;
  totalCardsBlocked: number;
  pendingIssuance: number;
}

export interface StudentDocumentStats {
  totalDocuments: number;
  verifiedCount: number;
  pendingCount: number;
  rejectedCount: number;
  mandatoryComplianceRate: number;
  categoryBreakdown: Record<string, number>;
}

export interface StudentDocumentVerificationPayload {
  verificationStatus: 'VERIFIED' | 'REJECTED';
  remarks?: string;
  rejectionReason?: string;
}

export interface BulkIDCardGeneratePayload {
  academicSessionId?: string;
  classId?: string;
  sectionId?: string;
  studentIds?: string[];
  templateId?: string;
  expiryDate?: string;
}

// ==========================================
// PART 9E: STUDENT PROMOTION, TRANSFER & STATUS MANAGEMENT
// ==========================================

export type PromotionType =
  | 'REGULAR_PROMOTION'
  | 'DOUBLE_PROMOTION'
  | 'CONDITIONAL_PROMOTION'
  | 'RETAINED_REPEAT'
  | 'GRADUATED';

export type PromotionAction = 'PROMOTE' | 'RETAIN' | 'GRADUATE' | 'EXCLUDE';

export type PromotionDecisionStatus =
  | 'ELIGIBLE'
  | 'WARNING_FEES'
  | 'WARNING_ATTENDANCE'
  | 'FAILED_ACADEMIC'
  | 'ROLL_CONFLICT'
  | 'SECTION_FULL'
  | 'MANUAL_OVERRIDE';

export interface StudentAcademicStandingSummary {
  cumulativeGPA: number;
  overallGrade: string;
  totalExams: number;
  passedExams: number;
  failedExams: number;
  passedAllCore: boolean;
  overallPercentage: number;
  attendancePercentage: number;
  attendanceStanding: string;
  totalDueFees: number;
  hasOutstandingFees: boolean;
}

export interface StudentPromotionRecord {
  id: string;
  batchId?: string;
  studentId: string;
  studentName: string;
  admissionNumber: string;
  fromSessionId: string;
  fromSessionName: string;
  fromClassId: string;
  fromClassName: string;
  fromSectionId: string;
  fromSectionName: string;
  fromRollNumber: string;
  toSessionId: string;
  toSessionName: string;
  toClassId: string;
  toClassName: string;
  toSectionId: string;
  toSectionName: string;
  toRollNumber: string;
  promotionType: PromotionType;
  action: PromotionAction;
  academicStanding: {
    gpa?: number;
    percentage?: number;
    passedExams?: number;
    failedExams?: number;
    attendancePercentage?: number;
    standingGrade?: string;
    passedAllCore?: boolean;
  };
  feeStatus: {
    hasOutstandingDues: boolean;
    totalDue: number;
    overrideApproved: boolean;
    overrideReason?: string;
  };
  status: 'COMPLETED' | 'REVERTED';
  promotedBy: string;
  promotedByName: string;
  promotedAt: string;
  remarks?: string;
  previousEnrollmentId?: string;
  newEnrollmentId?: string;
}

export interface BulkPromotionPreviewStudent {
  studentId: string;
  studentName: string;
  admissionNumber: string;
  currentRollNumber: string;
  currentClassId: string;
  currentClassName: string;
  currentSectionId: string;
  currentSectionName: string;
  suggestedClassId: string;
  suggestedClassName: string;
  suggestedSectionId: string;
  suggestedSectionName: string;
  suggestedRollNumber: string;
  gpa: number;
  percentage: number;
  attendanceRate: number;
  passedAllCore: boolean;
  failedSubjectsCount: number;
  totalDue: number;
  decision: PromotionAction;
  promotionType: PromotionType;
  eligibilityStatus: PromotionDecisionStatus;
  validationErrors: string[];
  validationWarnings: string[];
  customRemarks?: string;
  feeOverrideApproved?: boolean;
  feeOverrideReason?: string;
}

export interface BulkPromotionBatch {
  id: string;
  title: string;
  sourceSessionId: string;
  sourceSessionName: string;
  sourceClassId: string;
  sourceClassName: string;
  sourceSectionId?: string;
  sourceSectionName?: string;
  targetSessionId: string;
  targetSessionName: string;
  targetClassId: string;
  targetClassName: string;
  targetSectionId?: string;
  targetSectionName?: string;
  totalStudents: number;
  promotedCount: number;
  retainedCount: number;
  graduatedCount: number;
  excludedCount: number;
  executedBy: string;
  executedByName: string;
  executedAt: string;
  records: StudentPromotionRecord[];
}

export type TransferType = 'INTERNAL_SECTION' | 'INTERNAL_CLASS' | 'EXTERNAL_SCHOOL';

export interface TransferRecord {
  id: string;
  studentId: string;
  studentName: string;
  admissionNumber: string;
  transferType: TransferType;
  effectiveDate: string;
  reason: string;
  fromSessionId: string;
  fromSessionName: string;
  fromClassId: string;
  fromClassName: string;
  fromSectionId: string;
  fromSectionName: string;
  fromRollNumber: string;
  toClassId?: string;
  toClassName?: string;
  toSectionId?: string;
  toSectionName?: string;
  toRollNumber?: string;
  targetSchoolName?: string;
  tcNumber?: string;
  tcIssueDate?: string;
  conductCertificate?: string;
  clearanceDetails?: {
    libraryCleared: boolean;
    libraryRemarks?: string;
    feesCleared: boolean;
    duesAmount?: number;
    labSportsCleared: boolean;
    allCleared: boolean;
    overriddenBy?: string;
  };
  status: 'COMPLETED' | 'CANCELLED';
  approvedBy: string;
  approvedByName: string;
  createdAt: string;
  updatedAt: string;
  previousEnrollmentId?: string;
  newEnrollmentId?: string;
}

export interface TransferCertificate {
  id: string;
  tcNumber: string; // e.g. TC-2026-0042
  studentId: string;
  studentName: string;
  admissionNumber: string;
  fatherName: string;
  motherName: string;
  dateOfBirth: string;
  nationality: string;
  academicSessionId: string;
  academicSessionName: string;
  classLeft: string;
  sectionLeft: string;
  dateOfLeaving: string;
  reasonForLeaving: string;
  generalConduct: 'EXCELLENT' | 'VERY_GOOD' | 'GOOD' | 'SATISFACTORY';
  totalAttendanceDays: number;
  attendedDays: number;
  feeDuesPaidUpto: string;
  hasClearedAllDues: boolean;
  issueDate: string;
  issuedBy: string;
  issuedByName: string;
  verifiedBy: string;
  status: 'ACTIVE' | 'CANCELLED';
  qrCodeData: string;
  remarks?: string;
  createdAt: string;
}

export type StudentStatusType =
  | 'active'
  | 'inactive'
  | 'suspended'
  | 'withdrawn'
  | 'transferred'
  | 'graduated'
  | 'retained'
  | 'expelled';

export interface StudentStatusHistoryEntry {
  id: string;
  studentId: string;
  admissionNumber: string;
  studentName: string;
  fromStatus: StudentStatusType;
  toStatus: StudentStatusType;
  effectiveDate: string;
  endDate?: string;
  reason: string;
  remarks?: string;
  documentUrl?: string;
  suspensionTerms?: string;
  changedBy: string;
  changedByName: string;
  changedAt: string;
}

export interface PromotionTransferStats {
  totalEnrollments: number;
  activeEnrollments: number;
  promotedThisYear: number;
  transferredCount: number;
  graduatedCount: number;
  suspendedCount: number;
  withdrawnCount: number;
  retainedCount: number;
  tcIssuedCount: number;
}

// ==========================================
// PART 9F: STUDENT REPORTS, SEARCH, BULK OPERATIONS & DATA EXPORT
// ==========================================

export interface StudentReportFilterParams {
  search?: string;
  q?: string;
  academicSessionId?: string;
  classId?: string;
  sectionId?: string;
  status?: string;
  enrollmentStatus?: string;
  gender?: string;
  bloodGroup?: string;
  admissionDateFrom?: string;
  admissionDateTo?: string;
  enrollmentDateFrom?: string;
  enrollmentDateTo?: string;
  documentStatus?: string;
  idCardStatus?: string;
  page?: number;
  limit?: number;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
}

export interface StudentReportItem {
  id: string;
  userId: string;
  admissionNumber: string;
  rollNumber: string;
  firstName: string;
  middleName?: string;
  lastName: string;
  fullName: string;
  avatarUrl?: string;
  email?: string;
  phone?: string;
  gender: string;
  bloodGroup: string;
  dateOfBirth: string;
  address: string;
  admissionDate: string;
  enrollmentDate: string;
  status: string;
  enrollmentStatus: string;
  academicSessionId: string;
  academicSessionName: string;
  classId: string;
  className: string;
  sectionId: string;
  sectionName: string;
  guardianId?: string;
  guardianName: string;
  guardianRelation: string;
  guardianPhone: string;
  guardianEmail: string;
  documentStatus: 'complete' | 'incomplete' | 'pending_verification' | 'verified';
  documentCount: number;
  verifiedDocumentCount: number;
  idCardStatus: 'issued' | 'active' | 'not_issued' | 'blocked' | 'expired';
  idCardNumber?: string;
  totalEnrollmentsCount: number;
}

export interface StudentReportsSummaryData {
  totalStudents: number;
  activeStudents: number;
  inactiveStudents: number;
  suspendedStudents: number;
  withdrawnStudents: number;
  transferredStudents: number;
  graduatedStudents: number;
  genderDistribution: {
    male: number;
    female: number;
    other: number;
  };
  documentCompliance: {
    verifiedCount: number;
    pendingCount: number;
    incompleteCount: number;
    percentVerified: number;
  };
  idCardIssuance: {
    issuedCount: number;
    pendingCount: number;
    percentIssued: number;
  };
  classBreakdown: Array<{
    classId: string;
    className: string;
    studentCount: number;
    activeCount: number;
  }>;
}

export interface ClassWiseReportItem {
  classId: string;
  className: string;
  gradeLevel: number;
  totalStudents: number;
  activeStudents: number;
  maleCount: number;
  femaleCount: number;
  sections: Array<{
    sectionId: string;
    sectionName: string;
    capacity: number;
    studentCount: number;
    activeCount: number;
    students: StudentReportItem[];
  }>;
}

export interface StatusReportData {
  all: Array<StudentReportItem & {
    lastStatusChangeDate: string;
    lastStatusReason: string;
    changedBy: string;
    previousStatus: string;
  }>;
  grouped: {
    active: StudentReportItem[];
    inactive: StudentReportItem[];
    suspended: StudentReportItem[];
    withdrawn: StudentReportItem[];
    transferred: StudentReportItem[];
    graduated: StudentReportItem[];
  };
  counts: {
    active: number;
    inactive: number;
    suspended: number;
    withdrawn: number;
    transferred: number;
    graduated: number;
    total: number;
  };
}

export interface AcademicAssignmentReportItem {
  enrollmentId: string;
  studentId: string;
  studentName: string;
  admissionNumber: string;
  rollNumber: string;
  academicSessionId: string;
  academicSessionName: string;
  classId: string;
  className: string;
  sectionId: string;
  sectionName: string;
  enrollmentDate: string;
  status: string;
  isCurrentAssignment: boolean;
}

export interface BulkStudentActionPayload {
  action: 'STATUS_UPDATE' | 'SECTION_REASSIGN' | 'GENERATE_ID_CARDS' | 'ARCHIVE';
  studentIds: string[];
  targetStatus?: string;
  targetClassId?: string;
  targetSectionId?: string;
  reason: string;
  dryRun?: boolean;
}

export interface BulkStudentActionResult {
  success: boolean;
  message: string;
  affectedCount: number;
  failures: Array<{ studentId: string; reason: string }>;
}

// =========================================================================
// PART 10B: PARENT/GUARDIAN AUTHENTICATION, ACCOUNT & PORTAL FOUNDATION
// =========================================================================

export type ParentAccountLifecycleStatus =
  | 'pending'
  | 'invited'
  | 'active'
  | 'locked'
  | 'disabled'
  | 'suspended'
  | 'archived';

export interface ParentInvitation {
  id: string;
  guardianId: string;
  guardianName?: string;
  userId?: string;
  email: string;
  token: string;
  status: 'pending' | 'accepted' | 'expired' | 'revoked';
  expiresAt: string;
  createdAt: string;
  acceptedAt?: string;
  invitedBy: string;
  invitedByName?: string;
}

export interface PasswordResetToken {
  id: string;
  userId: string;
  email: string;
  token: string;
  status: 'pending' | 'used' | 'expired' | 'revoked';
  expiresAt: string;
  createdAt: string;
  usedAt?: string;
}

export interface GuardianAccountInfo {
  guardianId: string;
  guardianName: string;
  guardianEmail: string;
  guardianPhone: string;
  hasAccount: boolean;
  userId?: string;
  username?: string;
  userEmail?: string;
  accountStatus: UserStatus | 'unprovisioned';
  createdAt?: string;
  lastLoginAt?: string;
  failedLoginAttempts?: number;
  isLocked: boolean;
  isDisabled: boolean;
  invitations: ParentInvitation[];
  activeInvitation?: ParentInvitation | null;
  passwordResetTokens: PasswordResetToken[];
  linkedStudentsCount: number;
}

export interface GuardianContextData {
  guardian: Guardian;
  user?: {
    id: string;
    name: string;
    email: string;
    username: string;
    role: UserRole;
    status: UserStatus;
  };
  children: Array<GuardianChildSummary & {
    relationshipType?: string;
    isPrimary?: boolean;
    isAuthorizedAcademic?: boolean;
    isAuthorizedAttendance?: boolean;
    isAuthorizedFinancial?: boolean;
    isAuthorizedCommunication?: boolean;
    isPickupAuthorized?: boolean;
  }>;
  selectedChildId: string | null;
  selectedChild: GuardianChildSummary | null;
  activeSessionName?: string;
  unreadNoticesCount?: number;
  permissions?: {
    canViewAcademic: boolean;
    canViewAttendance: boolean;
    canViewFinancial: boolean;
    canViewCommunication: boolean;
    isPickupAuthorized: boolean;
  };
  unreadNotificationsCount?: number;
}

export interface ParentActivationPayload {
  token: string;
  password: string;
  confirmPassword: string;
  username?: string;
}

export interface ParentPasswordChangePayload {
  currentPassword: string;
  newPassword: string;
  confirmPassword: string;
}

export interface ParentResetPasswordPayload {
  token: string;
  newPassword: string;
  confirmPassword: string;
}

// Re-export Communication Types (Part 11A)
export * from './communication.types.js';

// Re-export Staff & HR Types (Part 12A)
export * from './staff.types.js';

// Re-export Staff Recruitment & Onboarding Types (Part 12D)
export * from './staff-recruitment.types.js';

// Re-export Staff Performance Management Types (Part 12E)
export * from './staff-performance.types.js';

// Re-export Staff HR Reports & Analytics Types (Part 12F)
export * from './staff-reports.types.js';

// Re-export Front Office & Visitor Management Types (Part 13A)
export * from './front-office.types.js';

// Re-export Inventory & Asset Management Types (Part 14A)
export * from './inventory.types.js';

// Re-export Certificate & Document Management Types (Part 15A)
export * from './document.types.js';

