/**
 * Sygmate School Management System
 * Staff Recruitment & Onboarding Management (Part 12D)
 * Type Definitions & Domain Models
 */

import { StaffType, StaffEmploymentType, EmploymentStatus } from './staff.types.js';
import { UserRole } from './index.js';

// ==========================================
// 1. JOB OPENINGS
// ==========================================

export type JobOpeningStatus =
  | 'DRAFT'
  | 'PUBLISHED'
  | 'APPLICATIONS_OPEN'
  | 'APPLICATIONS_CLOSED'
  | 'ON_HOLD'
  | 'FILLED'
  | 'CANCELLED'
  | 'ARCHIVED';

export interface JobOpening {
  id: string;
  title: string;
  code: string;
  departmentId: string;
  departmentName: string;
  designationId?: string;
  designationTitle: string;
  staffType: StaffType;
  employmentType: StaffEmploymentType;
  vacancies: number;
  filledVacancies: number;
  jobDescription: string;
  responsibilities: string[];
  qualifications: string[];
  experienceYears: number;
  requiredSkills: string[];
  salaryRange?: string; // Display only, no payroll engine
  workLocation: string;
  applicationStartDate: string; // YYYY-MM-DD
  applicationClosingDate: string; // YYYY-MM-DD
  status: JobOpeningStatus;
  createdBy: string;
  createdByName?: string;
  createdAt: string;
  updatedAt: string;
  notes?: string;
  applicationCount?: number;
}

export interface CreateJobOpeningPayload {
  title: string;
  code?: string;
  departmentId: string;
  designationId?: string;
  designationTitle?: string;
  staffType: StaffType;
  employmentType: StaffEmploymentType;
  vacancies: number;
  jobDescription: string;
  responsibilities: string[];
  qualifications: string[];
  experienceYears: number;
  requiredSkills: string[];
  salaryRange?: string;
  workLocation: string;
  applicationStartDate: string;
  applicationClosingDate: string;
  notes?: string;
}

export interface UpdateJobOpeningPayload extends Partial<CreateJobOpeningPayload> {
  status?: JobOpeningStatus;
}

// ==========================================
// 2. CANDIDATES & APPLICANTS
// ==========================================

export type CandidateSource =
  | 'DIRECT_APPLICATION'
  | 'SCHOOL_WEBSITE'
  | 'REFERRAL'
  | 'JOB_BOARD'
  | 'CAMPUS_RECRUITMENT'
  | 'INTERNAL'
  | 'AGENCY'
  | 'OTHER';

export type RecruitmentStage =
  | 'APPLIED'
  | 'SCREENING'
  | 'SHORTLISTED'
  | 'INTERVIEW'
  | 'SELECTED'
  | 'OFFER'
  | 'ACCEPTED'
  | 'ONBOARDING'
  | 'HIRED'
  | 'REJECTED'
  | 'WITHDRAWN'
  | 'ON_HOLD'
  | 'CANCELLED';

export type CandidateStatus =
  | 'ACTIVE'
  | 'CONVERTED_TO_STAFF'
  | 'REJECTED'
  | 'WITHDRAWN'
  | 'ARCHIVED';

export interface CandidateReference {
  name: string;
  designation: string;
  organization: string;
  email?: string;
  phone?: string;
  relationship: string;
}

export interface CandidateProfile {
  id: string;
  candidateNumber: string;
  // Personal
  fullName: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  photoUrl?: string;
  address?: string;
  city?: string;
  state?: string;
  country?: string;
  dateOfBirth?: string;
  gender?: 'male' | 'female' | 'other';
  emergencyContactName?: string;
  emergencyContactPhone?: string;

  // Professional
  currentOccupation?: string;
  highestQualification: string;
  institution?: string;
  yearsOfExperience: number;
  previousEmployment?: string;
  skills: string[];
  certifications: string[];
  specialization?: string;
  references?: CandidateReference[];

  // Recruitment
  appliedPositionTitle?: string;
  appliedDepartmentId?: string;
  appliedDepartmentName?: string;
  source: CandidateSource;
  currentStage: RecruitmentStage;
  status: CandidateStatus;
  assignedRecruiterId?: string;
  assignedRecruiterName?: string;
  notes?: string;
  staffProfileId?: string; // Set when converted to staff
  employeeCode?: string; // Set when converted to staff
  createdAt: string;
  updatedAt: string;
}

export interface CreateCandidatePayload {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  photoUrl?: string;
  address?: string;
  city?: string;
  state?: string;
  country?: string;
  dateOfBirth?: string;
  gender?: 'male' | 'female' | 'other';
  emergencyContactName?: string;
  emergencyContactPhone?: string;
  currentOccupation?: string;
  highestQualification: string;
  institution?: string;
  yearsOfExperience: number;
  previousEmployment?: string;
  skills: string[];
  certifications?: string[];
  specialization?: string;
  references?: CandidateReference[];
  source?: CandidateSource;
  notes?: string;
  // Optional direct application
  applyForJobOpeningId?: string;
  coverLetter?: string;
  resumeUrl?: string;
}

export interface UpdateCandidatePayload extends Partial<CreateCandidatePayload> {
  currentStage?: RecruitmentStage;
  status?: CandidateStatus;
}

// ==========================================
// 3. APPLICATIONS
// ==========================================

export type ApplicationStatus =
  | 'SUBMITTED'
  | 'UNDER_REVIEW'
  | 'SHORTLISTED'
  | 'INTERVIEWING'
  | 'SELECTED'
  | 'OFFERED'
  | 'ACCEPTED'
  | 'ONBOARDING'
  | 'HIRED'
  | 'REJECTED'
  | 'WITHDRAWN'
  | 'CANCELLED';

export interface StageHistoryEntry {
  stage: RecruitmentStage;
  changedBy: string;
  changedByName: string;
  timestamp: string;
  notes?: string;
}

export interface SupportingDocument {
  id: string;
  name: string;
  fileUrl: string;
  fileType?: string;
  fileSize?: string;
  uploadedAt: string;
}

export interface JobApplication {
  id: string;
  applicationNumber: string;
  candidateId: string;
  candidateName: string;
  candidateEmail: string;
  candidatePhone?: string;
  candidateQualification?: string;
  candidateExperienceYears?: number;
  jobOpeningId: string;
  jobTitle: string;
  departmentId: string;
  departmentName: string;
  applicationDate: string; // YYYY-MM-DD
  stage: RecruitmentStage;
  status: ApplicationStatus;
  resumeUrl?: string;
  resumeFileName?: string;
  coverLetter?: string;
  supportingDocuments?: SupportingDocument[];
  source: CandidateSource;
  assignedRecruiterId?: string;
  assignedRecruiterName?: string;
  screeningNotes?: string;
  screeningDecision?: 'PENDING' | 'SHORTLISTED' | 'REJECTED' | 'HOLD';
  screenedBy?: string;
  screenedByName?: string;
  screenedAt?: string;
  rejectionReason?: string;
  stageHistory: StageHistoryEntry[];
  internalNotes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface CreateJobApplicationPayload {
  candidateId: string;
  jobOpeningId: string;
  coverLetter?: string;
  resumeUrl?: string;
  resumeFileName?: string;
  source?: CandidateSource;
  supportingDocuments?: SupportingDocument[];
  internalNotes?: string;
}

export interface ScreenApplicationPayload {
  decision: 'SHORTLISTED' | 'REJECTED' | 'HOLD';
  notes: string;
  rejectionReason?: string;
}

export interface TransitionApplicationStagePayload {
  newStage: RecruitmentStage;
  notes?: string;
  rejectionReason?: string;
}

// ==========================================
// 4. INTERVIEWS & EVALUATIONS
// ==========================================

export type InterviewType =
  | 'IN_PERSON'
  | 'ONLINE_VIDEO'
  | 'PHONE'
  | 'PRACTICAL_DEMO';

export type InterviewStatus =
  | 'SCHEDULED'
  | 'CONFIRMED'
  | 'COMPLETED'
  | 'RESCHEDULED'
  | 'CANCELLED'
  | 'NO_SHOW';

export type EvaluationRecommendation =
  | 'STRONG_HIRE'
  | 'HIRE'
  | 'MAYBE'
  | 'DO_NOT_HIRE';

export interface InterviewPanelMember {
  userId: string;
  staffId?: string;
  name: string;
  role: string;
  email: string;
}

export interface InterviewEvaluation {
  id: string;
  interviewerId: string;
  interviewerName: string;
  interviewerRole: string;
  submittedAt: string;
  technicalSkillsScore: number; // 1-5
  communicationScore: number; // 1-5
  subjectKnowledgeScore: number; // 1-5
  teachingDemonstrationScore?: number; // 1-5 (optional for non-teaching)
  experienceScore: number; // 1-5
  problemSolvingScore: number; // 1-5
  professionalismScore: number; // 1-5
  overallScore: number; // 1-5 computed
  recommendation: EvaluationRecommendation;
  strengthsNotes: string;
  weaknessesNotes: string;
  generalComments: string;
}

export interface JobInterview {
  id: string;
  interviewNumber: string;
  applicationId: string;
  candidateId: string;
  candidateName: string;
  candidateEmail: string;
  jobOpeningId: string;
  jobTitle: string;
  interviewRound: number;
  roundName: string;
  interviewType: InterviewType;
  interviewDate: string; // YYYY-MM-DD
  startTime: string; // HH:mm
  endTime: string; // HH:mm
  location: string;
  meetingLink?: string;
  panelMembers: InterviewPanelMember[];
  status: InterviewStatus;
  statusReason?: string;
  rescheduledFrom?: {
    date: string;
    startTime: string;
    endTime: string;
  };
  evaluations: InterviewEvaluation[];
  overallRecommendation?: EvaluationRecommendation;
  averageScore?: number;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface ScheduleInterviewPayload {
  applicationId: string;
  interviewRound: number;
  roundName: string;
  interviewType: InterviewType;
  interviewDate: string; // YYYY-MM-DD
  startTime: string; // HH:mm
  endTime: string; // HH:mm
  location: string;
  meetingLink?: string;
  panelUserIds: string[];
  notes?: string;
}

export interface SubmitEvaluationPayload {
  technicalSkillsScore: number;
  communicationScore: number;
  subjectKnowledgeScore: number;
  teachingDemonstrationScore?: number;
  experienceScore: number;
  problemSolvingScore: number;
  professionalismScore: number;
  recommendation: EvaluationRecommendation;
  strengthsNotes: string;
  weaknessesNotes: string;
  generalComments: string;
}

export interface RescheduleInterviewPayload {
  newDate: string;
  newStartTime: string;
  newEndTime: string;
  reason: string;
  location?: string;
  meetingLink?: string;
}

// ==========================================
// 5. OFFERS & APPROVALS
// ==========================================

export type OfferStatus =
  | 'DRAFT'
  | 'PENDING_APPROVAL'
  | 'APPROVED'
  | 'SENT'
  | 'ACCEPTED'
  | 'REJECTED'
  | 'EXPIRED'
  | 'WITHDRAWN';

export interface OfferApprovalEntry {
  approverId: string;
  approverName: string;
  approverRole: string;
  decision: 'APPROVED' | 'REJECTED';
  remarks?: string;
  decisionDate: string;
}

export interface JobOffer {
  id: string;
  offerNumber: string;
  applicationId: string;
  candidateId: string;
  candidateName: string;
  candidateEmail: string;
  jobOpeningId: string;
  positionTitle: string;
  departmentId: string;
  departmentName: string;
  designationId?: string;
  designationTitle: string;
  staffType: StaffType;
  employmentType: StaffEmploymentType;
  proposedJoiningDate: string; // YYYY-MM-DD
  offeredSalary: string; // Compensation display text, no payroll engine
  basicSalary?: number;
  offerExpiryDate: string; // YYYY-MM-DD
  probationPeriodMonths: number;
  termsAndConditions: string;
  workScheduleId?: string;
  workScheduleName?: string;
  supervisorName?: string;
  status: OfferStatus;
  approvals: OfferApprovalEntry[];
  approvedBy?: string;
  approvedByName?: string;
  approvedAt?: string;
  sentAt?: string;
  sentBy?: string;
  acceptedAt?: string;
  rejectedAt?: string;
  rejectionReason?: string;
  withdrawnAt?: string;
  withdrawalReason?: string;
  generatedLetterContent?: string;
  createdAt: string;
  updatedAt: string;
}

export interface CreateJobOfferPayload {
  applicationId: string;
  designationId?: string;
  designationTitle?: string;
  proposedJoiningDate: string;
  offeredSalary: string;
  offerExpiryDate: string;
  probationPeriodMonths?: number;
  termsAndConditions: string;
  workScheduleId?: string;
  supervisorName?: string;
  notes?: string;
}

export interface ReviewOfferPayload {
  decision: 'APPROVED' | 'REJECTED';
  remarks?: string;
}

export interface CandidateOfferResponsePayload {
  response: 'ACCEPTED' | 'REJECTED';
  reason?: string;
}

// ==========================================
// 6. CANDIDATE -> STAFF CONVERSION
// ==========================================

export interface ConvertCandidateToStaffPayload {
  candidateId: string;
  applicationId?: string;
  offerId?: string;
  departmentId: string;
  designationId?: string;
  designationTitle?: string;
  staffType: StaffType;
  employmentType: StaffEmploymentType;
  employmentStatus?: EmploymentStatus;
  joiningDate: string; // YYYY-MM-DD
  employeeCode?: string; // Auto-generated if not provided
  workScheduleId?: string;
  // Account provisioning
  createAccount?: boolean;
  username?: string;
  password?: string;
  accountRole?: UserRole;
  // Onboarding template
  onboardingTemplateId?: string;
}

export interface CandidateConversionResult {
  candidateId: string;
  staffId: string;
  employeeCode: string;
  staffName: string;
  departmentName: string;
  designation: string;
  hasAccount: boolean;
  username?: string;
  onboardingId?: string;
}

// ==========================================
// 7. ONBOARDING & CHECKLISTS
// ==========================================

export type OnboardingTaskCategory =
  | 'DOCUMENTATION'
  | 'CREDENTIALS'
  | 'SYSTEM_ACCESS'
  | 'WORK_SETUP'
  | 'ORIENTATION'
  | 'COMPLIANCE'
  | 'FACILITY';

export type OnboardingTaskStatus =
  | 'PENDING'
  | 'IN_PROGRESS'
  | 'COMPLETED'
  | 'WAIVED';

export interface OnboardingTask {
  id: string;
  title: string;
  description?: string;
  category: OnboardingTaskCategory;
  isMandatory: boolean;
  status: OnboardingTaskStatus;
  dueDate?: string;
  assignedToId?: string;
  assignedToName?: string;
  completedAt?: string;
  completedBy?: string;
  completedByName?: string;
  notes?: string;
  order: number;
}

export interface OnboardingRecord {
  id: string;
  staffId: string;
  employeeCode: string;
  staffName: string;
  staffType: StaffType;
  departmentId: string;
  departmentName: string;
  designation: string;
  joiningDate: string;
  candidateId?: string;
  applicationId?: string;
  templateId?: string;
  templateName?: string;
  status: 'NOT_STARTED' | 'IN_PROGRESS' | 'COMPLETED' | 'BLOCKED';
  totalTasks: number;
  completedTasks: number;
  progressPercentage: number;
  startDate: string;
  targetCompletionDate: string;
  completedAt?: string;
  tasks: OnboardingTask[];
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface OnboardingTemplate {
  id: string;
  name: string;
  staffType: StaffType | 'ALL';
  description: string;
  tasks: Array<{
    title: string;
    description?: string;
    category: OnboardingTaskCategory;
    isMandatory: boolean;
    daysFromJoiningDue: number;
  }>;
  isDefault: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface CreateOnboardingTaskPayload {
  title: string;
  description?: string;
  category: OnboardingTaskCategory;
  isMandatory: boolean;
  dueDate?: string;
  assignedToId?: string;
  notes?: string;
}

export interface UpdateOnboardingTaskPayload {
  title?: string;
  description?: string;
  category?: OnboardingTaskCategory;
  isMandatory?: boolean;
  status?: OnboardingTaskStatus;
  dueDate?: string;
  assignedToId?: string;
  notes?: string;
}

// ==========================================
// 8. DASHBOARD & METRICS
// ==========================================

export interface RecruitmentDashboardMetrics {
  openJobOpenings: number;
  totalApplications: number;
  candidatesUnderScreening: number;
  shortlistedCandidates: number;
  upcomingInterviews: number;
  selectedCandidates: number;
  pendingOffers: number;
  acceptedOffers: number;
  activeOnboarding: number;
  completedOnboarding: number;
  conversionRate: number; // Percentage
  departmentDistribution: Array<{
    departmentId: string;
    departmentName: string;
    openingsCount: number;
    applicationsCount: number;
    hiredCount: number;
  }>;
  stageDistribution: Array<{
    stage: RecruitmentStage;
    count: number;
  }>;
}

// Filter queries
export interface RecruitmentFilterQuery {
  search?: string;
  departmentId?: string;
  staffType?: string;
  status?: string;
  page?: number;
  limit?: number;
}
