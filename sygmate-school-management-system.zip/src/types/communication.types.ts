import { UserRole } from './index.js';

export type NotificationChannel = 'IN_APP' | 'EMAIL' | 'SMS' | 'PUSH';

export type CommunicationDeliveryStatus =
  | 'PENDING'
  | 'PROCESSING'
  | 'SENT'
  | 'DELIVERED'
  | 'FAILED'
  | 'RETRYING'
  | 'CANCELLED';

export type CommunicationCategory =
  | 'system'
  | 'academic'
  | 'security'
  | 'general'
  | 'fee'
  | 'attendance'
  | 'exam'
  | 'admission';

export type CommunicationEventType =
  // Student lifecycle
  | 'STUDENT_ADMISSION'
  | 'STUDENT_ENROLLMENT'
  | 'STUDENT_PROMOTION'
  | 'STUDENT_TRANSFER'
  | 'STUDENT_STATUS_CHANGE'
  // Attendance & Leaves
  | 'STUDENT_ABSENT'
  | 'STUDENT_LATE'
  | 'STUDENT_HALF_DAY'
  | 'LEAVE_SUBMITTED'
  | 'LEAVE_APPROVED'
  | 'LEAVE_REJECTED'
  | 'LEAVE_CANCELLED'
  | 'ATTENDANCE_CORRECTION'
  // Examination & Academics
  | 'EXAM_SCHEDULED'
  | 'EXAM_RESULT_PUBLISHED'
  | 'EXAM_RESULT_UPDATED'
  // Fees & Finance
  | 'FEE_INVOICE_GENERATED'
  | 'FEE_DUE_REMINDER'
  | 'FEE_OVERDUE_ALERT'
  | 'PAYMENT_SUCCESSFUL'
  | 'PAYMENT_FAILED'
  | 'PAYMENT_RECEIPT_GENERATED'
  // Account & General
  | 'PARENT_ACCOUNT_INVITATION'
  | 'ACCOUNT_ACTIVATED'
  | 'PASSWORD_RESET_REQUESTED'
  | 'SCHOOL_ANNOUNCEMENT'
  | 'MESSAGE_RECEIVED'
  | 'SYSTEM_ALERT';

export interface NotificationChannelToggles {
  inApp: boolean;
  email: boolean;
  sms: boolean;
  push: boolean;
}

export interface CommunicationTemplate {
  id: string;
  eventType: CommunicationEventType;
  name: string;
  description: string;
  category: CommunicationCategory;
  channels: NotificationChannelToggles;
  titleTemplate: string;
  bodyTemplate: string;
  emailSubjectTemplate?: string;
  emailHtmlTemplate?: string;
  smsTemplate?: string;
  allowedVariables: string[];
  isActive: boolean;
  isMandatory: boolean; // Mandatory notifications cannot be disabled by user preferences
  updatedAt: string;
  updatedBy: string;
  updatedByName?: string;
}

export interface CommunicationLog {
  id: string;
  dedupKey: string;
  idempotencyKey?: string;
  eventType: CommunicationEventType;
  channel: NotificationChannel;
  recipientId: string;
  recipientUserId?: string;
  recipientName: string;
  recipientRole: UserRole | string;
  recipientContact?: string;
  title: string;
  message: string;
  emailSubject?: string;
  status: CommunicationDeliveryStatus;
  failureReason?: string;
  providerReference?: string;
  relatedStudentId?: string;
  relatedStudentName?: string;
  relatedEntityId?: string;
  relatedEntityType?: string;
  entityId?: string;
  entityType?: string;
  retryCount: number;
  maxRetries: number;
  metadata?: Record<string, any>;
  createdAt: string;
  sentAt?: string;
  deliveredAt?: string;
}

export interface EmailProviderConfig {
  enabled: boolean;
  provider: 'SMTP' | 'SENDGRID' | 'AWS_SES' | 'MAILGUN';
  host?: string;
  port?: number;
  secure?: boolean;
  senderName: string;
  senderEmail: string;
  username?: string;
  password?: string;
  passwordMasked?: string;
  hasSecret: boolean;
  status: 'ACTIVE' | 'NOT_CONFIGURED' | 'DISABLED';
  description?: string;
}

export interface SmsProviderConfig {
  enabled: boolean;
  provider: 'TWILIO' | 'AWS_SNS' | 'MESSAGEBIRD';
  senderId: string;
  accountSid?: string;
  authToken?: string;
  authTokenMasked?: string;
  hasSecret: boolean;
  status: 'ACTIVE' | 'NOT_CONFIGURED' | 'DISABLED';
  description?: string;
}

export interface PushProviderConfig {
  enabled: boolean;
  provider: 'FCM' | 'APNS' | 'WEB_PUSH';
  serverKey?: string;
  serverKeyMasked?: string;
  hasSecret: boolean;
  status: 'ACTIVE' | 'NOT_CONFIGURED' | 'DISABLED';
  description?: string;
}

export interface InAppProviderConfig {
  enabled: boolean;
  retentionDays: number;
  status: 'ACTIVE' | 'DISABLED';
  description?: string;
}

export interface GeneralCommunicationConfig {
  preventDuplicates: boolean;
  deduplicationWindowMinutes: number;
  maxRetries: number;
  retryDelayMinutes: number;
  allowUserChannelPreferences: boolean;
}

export interface CommunicationSettings {
  id: string;
  inApp: InAppProviderConfig;
  email: EmailProviderConfig;
  sms: SmsProviderConfig;
  push: PushProviderConfig;
  general: GeneralCommunicationConfig;
  updatedAt: string;
  updatedBy: string;
  updatedByName?: string;
}

export interface UserNotificationPreference {
  userId: string;
  userRole: UserRole | string;
  channels: {
    inApp: boolean;
    email: boolean;
    sms: boolean;
    push: boolean;
  };
  categories: {
    attendance: boolean;
    academic: boolean;
    exam: boolean;
    fee: boolean;
    general: boolean;
    security: boolean;
  };
  updatedAt: string;
}

export interface CommunicationStats {
  totalLogged: number;
  sentCount: number;
  deliveredCount: number;
  failedCount: number;
  pendingCount: number;
  byChannel: {
    inApp: number;
    email: number;
    sms: number;
    push: number;
  };
  byCategory: Record<string, number>;
  deliveryRate: number;
}

export interface CommunicationFilterParams {
  eventType?: string;
  channel?: string;
  status?: string;
  recipientRole?: string;
  search?: string;
  startDate?: string;
  endDate?: string;
  page?: number;
  limit?: number;
}

export type {
  AnnouncementAudience,
  AnnouncementCategory,
  AnnouncementStatus,
  AnnouncementAttachment,
  AnnouncementReadReceipt,
  ClassAnnouncement,
  ClassAnnouncement as SchoolAnnouncement,
  AnnouncementFilterParams
} from './index.js';

// =========================================================================
// PART 11C: PARENT-TEACHER & INTERNAL MESSAGING / INBOX TYPES
// =========================================================================

export type ConversationCategory =
  | 'parent_teacher'
  | 'staff_internal'
  | 'general'
  | 'academic'
  | 'administrative'
  | 'student_teacher';

export interface MessageAttachment {
  id: string;
  name: string;
  size: string; // e.g. "1.2 MB"
  sizeBytes?: number;
  type: string; // e.g. "application/pdf"
  url: string; // data URL or relative URI
}

export interface MessageItem {
  id: string;
  conversationId: string;
  senderId: string;
  senderName: string;
  senderRole: UserRole | string;
  senderAvatarUrl?: string;
  body: string;
  attachments?: MessageAttachment[];
  status: 'sent' | 'delivered' | 'read';
  createdAt: string;
  isEdited?: boolean;
  editedAt?: string;
}

export interface ConversationParticipant {
  userId: string;
  name: string;
  role: UserRole;
  email?: string;
  avatarUrl?: string;
  isArchived?: boolean;
  isStarred?: boolean;
  isDeleted?: boolean;
  lastReadMessageId?: string;
  lastReadAt?: string;
}

export interface Conversation {
  id: string;
  subject: string;
  category: ConversationCategory;
  participants: ConversationParticipant[];
  participantIds: string[];

  // Child / Academic context
  studentId?: string;
  studentName?: string;
  classId?: string;
  className?: string;
  sectionId?: string;
  sectionName?: string;
  academicSessionId?: string;
  academicSessionName?: string;

  // Last message overview
  lastMessageAt: string;
  lastMessagePreview: string;
  lastMessageId?: string;
  lastSenderId?: string;
  lastSenderName?: string;

  // Draft state
  isDraft?: boolean;
  draftBody?: string;
  draftRecipientId?: string;

  // Moderation / Reports
  status: 'active' | 'archived' | 'closed';
  isReported?: boolean;
  reportReason?: string;
  reportedBy?: string;
  reportedAt?: string;

  // Creation & Audit
  createdBy: string;
  createdByName: string;
  createdByRole: UserRole | string;
  createdAt: string;
  updatedAt: string;

  // Client-specific computed states (for current user)
  unreadCount?: number;
  isArchivedForMe?: boolean;
  isStarredForMe?: boolean;
  otherParticipant?: ConversationParticipant;
}

export interface ConversationFilterParams {
  folder?: 'inbox' | 'sent' | 'drafts' | 'archived' | 'starred' | 'reported';
  category?: string;
  search?: string;
  studentId?: string;
  unreadOnly?: boolean;
  page?: number;
  limit?: number;
}

export interface EligibleRecipient {
  userId: string;
  name: string;
  role: UserRole | string;
  email?: string;
  avatarUrl?: string;
  designation?: string;
  relationshipContext?: string;
  studentId?: string;
  studentName?: string;
  className?: string;
  sectionName?: string;
}

export interface MessageReport {
  id: string;
  conversationId: string;
  messageId?: string;
  reporterUserId: string;
  reporterName: string;
  reporterRole: string;
  reason: 'inappropriate_content' | 'harassment' | 'spam' | 'wrong_recipient' | 'other';
  details?: string;
  status: 'pending' | 'reviewed' | 'dismissed' | 'action_taken';
  resolutionNotes?: string;
  createdAt: string;
  resolvedAt?: string;
  resolvedBy?: string;
}

// =========================================================================
// PART 11D: BULK COMMUNICATION & TARGETED CAMPAIGN MANAGEMENT TYPES
// =========================================================================

export type BulkCampaignPriority = 'LOW' | 'NORMAL' | 'HIGH' | 'URGENT';

export type BulkCampaignStatus =
  | 'DRAFT'
  | 'SCHEDULED'
  | 'PROCESSING'
  | 'COMPLETED'
  | 'PARTIALLY_FAILED'
  | 'FAILED'
  | 'CANCELLED'
  | 'ARCHIVED';

export type BulkCampaignAudienceType =
  | 'SCHOOL_WIDE'
  | 'ROLE_BASED'
  | 'ACADEMIC_COHORT'
  | 'RECIPIENT_LIST'
  | 'RELATIONSHIP_BASED';

export type BulkCampaignScheduleType = 'IMMEDIATE' | 'SCHEDULED';

export type BulkCampaignRelationshipType =
  | 'PARENTS_OF_CLASS'
  | 'PARENTS_OF_SECTION'
  | 'TEACHERS_OF_CLASS'
  | 'TEACHERS_OF_SUBJECT';

export interface BulkCampaignAttachment {
  id: string;
  name: string;
  size: string; // e.g. "1.5 MB"
  sizeBytes?: number;
  type: string; // e.g. "application/pdf"
  url: string; // data URL or relative URI
}

export interface BulkCampaignChannelStats {
  inApp: { sent: number; failed: number; read: number };
  email: { sent: number; delivered: number; failed: number };
  sms: { sent: number; delivered: number; failed: number };
  push: { sent: number; delivered: number; failed: number };
}

export interface BulkCampaign {
  id: string;
  name: string; // Campaign identifier / name
  internalDescription?: string;
  title: string; // Message Title
  body: string; // Sanitized Message Content
  category: CommunicationCategory;
  priority: BulkCampaignPriority;

  // Audience targeting
  audienceType: BulkCampaignAudienceType;
  academicSessionId?: string;
  academicSessionName?: string;
  classId?: string;
  className?: string;
  sectionId?: string;
  sectionName?: string;
  targetRoles: (UserRole | string)[]; // e.g. ['GUARDIAN', 'STUDENT']
  selectedRecipientIds?: string[]; // specific user IDs if targeted recipient list
  relationshipType?: BulkCampaignRelationshipType;
  subjectId?: string;
  subjectName?: string;

  // Template reuse
  templateId?: string;
  templateName?: string;

  // Delivery configuration
  channels: NotificationChannel[];
  attachments: BulkCampaignAttachment[];

  // Scheduling & Lifecycle
  scheduleType: BulkCampaignScheduleType;
  scheduledAt?: string; // ISO string for future dispatch
  expiresAt?: string; // Optional expiry
  status: BulkCampaignStatus;
  statusReason?: string;

  // Delivery summary & stats
  totalRecipientsCount: number;
  queuedCount: number;
  sentCount: number;
  deliveredCount: number;
  failedCount: number;
  readCount: number;
  duplicateCount: number;
  channelStats: BulkCampaignChannelStats;

  // Concurrency & Idempotency
  idempotencyKey?: string;

  // Audit
  createdBy: string;
  createdByName: string;
  createdByRole: UserRole | string;
  createdAt: string;
  updatedAt: string;
  processedAt?: string;
  completedAt?: string;
  cancelledAt?: string;
  cancelledBy?: string;
}

export interface BulkCampaignRecipient {
  id: string;
  campaignId: string;
  recipientId: string; // User ID or Entity ID
  userId?: string;
  recipientName: string;
  recipientRole: UserRole | string;
  contact?: string; // Email or Phone (sanitized for preview)
  studentId?: string;
  studentName?: string;
  channels: NotificationChannel[];
  status: 'QUEUED' | 'SENT' | 'DELIVERED' | 'FAILED' | 'SKIPPED_DUPLICATE';
  deliveredChannels?: NotificationChannel[];
  failedChannels?: NotificationChannel[];
  failureReasons?: Record<string, string>;
  isRead?: boolean;
  readAt?: string;
  sentAt?: string;
  deliveredAt?: string;
  dedupKey: string;
}

export interface BulkCampaignFilterParams {
  search?: string;
  status?: string;
  category?: string;
  audienceType?: string;
  startDate?: string;
  endDate?: string;
  page?: number;
  limit?: number;
}

export interface RecipientPreviewResult {
  totalCount: number;
  duplicatesRemoved: number;
  ineligibleExcluded: number;
  channelsSelected: NotificationChannel[];
  audienceType: BulkCampaignAudienceType;
  classId?: string;
  className?: string;
  sectionId?: string;
  sectionName?: string;
  sampleRecipients: Array<{
    id: string;
    name: string;
    role: string;
    contactMasked?: string;
    studentName?: string;
  }>;
  roleBreakdown: Record<string, number>;
}

export interface BulkCampaignStats {
  totalCampaigns: number;
  draftCount: number;
  scheduledCount: number;
  processingCount: number;
  completedCount: number;
  failedCount: number;
  cancelledCount: number;
  totalRecipientsReached: number;
  totalDelivered: number;
  overallDeliveryRate: number;
  byCategory: Record<string, number>;
  byAudience: Record<string, number>;
}

// =========================================================================
// PART 11E: COMMUNICATION ANALYTICS, DELIVERY REPORTS & AUDIT TYPES
// =========================================================================

export type CommunicationDatePreset =
  | 'TODAY'
  | 'YESTERDAY'
  | 'LAST_7_DAYS'
  | 'LAST_30_DAYS'
  | 'CURRENT_MONTH'
  | 'PREVIOUS_MONTH'
  | 'CUSTOM';

export interface CommunicationAnalyticsFilterParams {
  datePreset?: CommunicationDatePreset;
  startDate?: string;
  endDate?: string;
  academicSessionId?: string;
  classId?: string;
  sectionId?: string;
  recipientRole?: string;
  category?: string;
  channel?: NotificationChannel | 'ALL';
  status?: CommunicationDeliveryStatus | 'ALL';
}

export interface CommunicationSummaryMetrics {
  totalNotifications: number;
  totalAnnouncements: number;
  totalInternalMessages: number;
  totalBulkCampaigns: number;
  totalRecipients: number;
  successfulDeliveries: number;
  failedDeliveries: number;
  pendingDeliveries: number;
  readNotifications: number;
  unreadNotifications: number;
  scheduledCommunications: number;
  failedCampaigns: number;
  overallDeliveryRate: number;
}

export interface ChannelAnalyticsItem {
  channel: NotificationChannel;
  sent: number;
  delivered: number;
  failed: number;
  pending: number;
  read: number | null; // Tracked verified for IN_APP; null for Email/SMS/Push
  deliveryRate: number;
  providerVerified: boolean;
  statusNote?: string;
}

export interface DeliveryPerformanceMetrics {
  avgQueueWaitMs: number;
  avgDeliveryProcessingMs: number;
  deliveryFailureRate: number;
  systemProcessingPerformance: string;
  providerDeliveryPerformance: string;
}

export type FailureCategory =
  | 'INVALID_RECIPIENT'
  | 'PROVIDER_UNCONFIGURED'
  | 'PROVIDER_ERROR'
  | 'RATE_LIMIT'
  | 'TIMEOUT'
  | 'ATTACHMENT_FAILURE'
  | 'OTHER';

export interface FailureAnalysisItem {
  category: FailureCategory;
  label: string;
  count: number;
  percentage: number;
  recentExamples: Array<{
    id: string;
    recipientName: string;
    channel: string;
    reason: string;
    timestamp: string;
  }>;
}

export interface CommunicationTrendPoint {
  date: string;
  label: string;
  total: number;
  delivered: number;
  failed: number;
  inApp: number;
  email: number;
  sms: number;
  push: number;
}

export interface QueueJobStatusSummary {
  pendingJobs: number;
  processingJobs: number;
  completedJobs: number;
  failedJobs: number;
  retryingJobs: number;
  workerActive: boolean;
  lastHeartbeat: string;
}

export interface ScheduledCommunicationItem {
  id: string;
  type: 'CAMPAIGN' | 'ANNOUNCEMENT' | 'NOTIFICATION';
  title: string;
  audience: string;
  scheduledAt: string;
  status: string;
  createdBy: string;
  createdByName: string;
  canCancel: boolean;
}

export interface ProviderHealthItem {
  channel: NotificationChannel;
  providerName: string;
  status: 'ACTIVE' | 'NOT_CONFIGURED' | 'DISABLED';
  isSandbox: boolean;
  hasCredentials: boolean;
  senderIdentifier: string;
  lastTested?: string;
}

export interface MessagingAnalyticsSummary {
  totalConversations: number;
  totalMessages: number;
  activeConversations: number;
  unreadMessagesCount: number;
  byCategory: Record<string, number>;
  bySenderRole: Record<string, number>;
  parentTeacherVolume: number;
  staffInternalVolume: number;
}

export interface AnnouncementAnalyticsSummary {
  totalAnnouncements: number;
  publishedCount: number;
  scheduledCount: number;
  activeCount: number;
  expiredCount: number;
  archivedCount: number;
  totalReadReceipts: number;
  estimatedUnreadCount: number;
  averageReadRate: number;
}

export interface CommunicationAnalyticsOverview {
  filtersApplied: CommunicationAnalyticsFilterParams;
  summary: CommunicationSummaryMetrics;
  channelAnalytics: Record<NotificationChannel, ChannelAnalyticsItem>;
  performance: DeliveryPerformanceMetrics;
  failureAnalysis: FailureAnalysisItem[];
  trends: CommunicationTrendPoint[];
  queueStatus: QueueJobStatusSummary;
  scheduledItems: ScheduledCommunicationItem[];
  providerHealth: ProviderHealthItem[];
  messaging: MessagingAnalyticsSummary;
  announcements: AnnouncementAnalyticsSummary;
}

export interface DeliveryReportQuery {
  page?: number;
  limit?: number;
  search?: string;
  channel?: string;
  status?: string;
  recipientRole?: string;
  category?: string;
  eventType?: string;
  startDate?: string;
  endDate?: string;
  sortBy?: 'createdAt' | 'sentAt' | 'recipientName' | 'status';
  sortOrder?: 'asc' | 'desc';
}

export interface DeliveryReportItem {
  id: string;
  title: string;
  eventType: string;
  recipientName: string;
  recipientRole: string;
  recipientContactMasked: string;
  channel: NotificationChannel;
  createdAt: string;
  sentAt?: string;
  deliveredAt?: string;
  status: CommunicationDeliveryStatus;
  retryCount: number;
  maxRetries: number;
  failureReason?: string;
  failureCategory?: FailureCategory;
  canRetry: boolean;
}

export interface DeliveryReportResponse {
  data: DeliveryReportItem[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
  stats: {
    totalDelivered: number;
    totalFailed: number;
    totalPending: number;
  };
}

export type ExportReportType =
  | 'summary'
  | 'delivery'
  | 'campaigns'
  | 'announcements'
  | 'failures';

export type ExportFormat = 'csv' | 'json';




