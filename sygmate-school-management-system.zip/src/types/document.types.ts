/**
 * Part 15A — Certificate & Document Management Foundation Types
 * Sygmate School Management System
 */

export type DocumentEntityType =
  | 'STUDENT'
  | 'TEACHER'
  | 'STAFF'
  | 'GUARDIAN'
  | 'SCHOOL'
  | 'DEPARTMENT'
  | 'OTHER';

export type DocumentCategory =
  | 'IDENTIFICATION'
  | 'ACADEMIC'
  | 'EMPLOYMENT'
  | 'LEGAL'
  | 'MEDICAL'
  | 'FINANCIAL'
  | 'INSTITUTIONAL'
  | 'OTHER';

export type DocumentStatus =
  | 'DRAFT'
  | 'UPLOADED'
  | 'PENDING_REVIEW'
  | 'VERIFIED'
  | 'REJECTED'
  | 'EXPIRED'
  | 'ARCHIVED'
  | 'CANCELLED';

export type DocumentVerificationStatus =
  | 'PENDING_REVIEW'
  | 'VERIFIED'
  | 'REJECTED'
  | 'NOT_REQUIRED'
  | 'EXPIRED';

export interface DocumentTypeConfig {
  id: string;
  schoolId: string;
  name: string;
  code: string;
  category: DocumentCategory | string;
  applicableEntityType: DocumentEntityType | 'ALL';
  description: string;
  isRequired: boolean;
  hasExpiry: boolean;
  defaultExpiryMonths?: number;
  allowedExtensions: string[];
  maxSizeBytes: number;
  isActive: boolean;
  createdBy: string;
  updatedBy?: string;
  createdAt: string;
  updatedAt: string;
}

export interface DocumentVersionRecord {
  version: number;
  fileName: string;
  fileUrl: string;
  fileType: string;
  fileSize: string;
  fileSizeBytes: number;
  uploadedBy: string;
  uploadedByName: string;
  uploadedAt: string;
  changeNotes?: string;
}

export interface ManagedDocument {
  id: string;
  schoolId: string;
  documentTypeId: string;
  documentTypeName: string;
  category: DocumentCategory | string;
  entityType: DocumentEntityType;
  entityId: string;
  entityName?: string;
  entityCode?: string;
  documentTitle: string;
  description?: string;
  referenceNumber?: string;
  issueDate?: string;
  expiryDate?: string;
  status: DocumentStatus;
  verificationStatus: DocumentVerificationStatus;
  verifiedBy?: string;
  verifiedByName?: string;
  verifiedAt?: string;
  verificationRemarks?: string;
  rejectionReason?: string;
  fileUrl: string;
  fileName: string;
  fileType: string;
  fileSize: string;
  fileSizeBytes: number;
  storageKey?: string;
  version: number;
  versionHistory: DocumentVersionRecord[];
  notes?: string;
  tags?: string[];
  isConfidential?: boolean;
  createdBy: string;
  createdByName?: string;
  updatedBy: string;
  updatedByName?: string;
  createdAt: string;
  updatedAt: string;
}

export type CertificateTemplateOrientation = 'PORTRAIT' | 'LANDSCAPE';
export type CertificateTemplateLayoutDesign = 'CLASSIC_BORDER' | 'MODERN_MINIMAL' | 'ELEGANT_GOLD' | 'ROYAL_CREST';
export type CertificateTemplateCategory = 'ACADEMIC' | 'ACHIEVEMENT' | 'CONDUCT' | 'LEAVING' | 'EMPLOYMENT' | 'PARTICIPATION';

export interface CertificateSignatory {
  title: string;
  name: string;
  signatureImageUrl?: string;
  required: boolean;
}

export interface CertificateTemplate {
  id: string;
  schoolId: string;
  name: string;
  code: string;
  entityType: 'STUDENT' | 'TEACHER' | 'STAFF';
  category: CertificateTemplateCategory;
  description: string;
  orientation: CertificateTemplateOrientation;
  dimensions: {
    width: number;
    height: number;
    unit: 'mm' | 'in' | 'px';
  };
  layoutDesign: CertificateTemplateLayoutDesign;
  headerText: string;
  title: string;
  subtitle?: string;
  bodyTemplate: string;
  footerText?: string;
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  logoUrl?: string;
  watermarkUrl?: string;
  signatories: CertificateSignatory[];
  qrCodeEnabled: boolean;
  qrVerificationUrlPattern?: string;
  status: 'DRAFT' | 'ACTIVE' | 'ARCHIVED';
  version: number;
  createdBy: string;
  updatedBy: string;
  createdAt: string;
  updatedAt: string;
}

// DTOs & Payloads
export interface CreateDocumentPayload {
  documentTypeId: string;
  entityType: DocumentEntityType;
  entityId: string;
  entityName?: string;
  documentTitle: string;
  description?: string;
  referenceNumber?: string;
  issueDate?: string;
  expiryDate?: string;
  fileName: string;
  fileData?: string; // base64 / blob data URL
  fileUrl?: string;
  fileType: string;
  fileSizeBytes?: number;
  fileSize?: string | number;
  notes?: string;
  tags?: string[];
  isConfidential?: boolean;
}

export interface UploadDocumentVersionPayload {
  fileName: string;
  fileData?: string;
  fileUrl?: string;
  fileType: string;
  fileSizeBytes?: number;
  fileSize?: string | number;
  changeNotes?: string;
}

export interface VerifyDocumentPayload {
  verificationStatus: 'VERIFIED' | 'REJECTED';
  verificationRemarks?: string;
  rejectionReason?: string;
}

export interface UpdateDocumentMetadataPayload {
  documentTitle?: string;
  description?: string;
  referenceNumber?: string;
  issueDate?: string;
  expiryDate?: string;
  notes?: string;
  tags?: string[];
  isConfidential?: boolean;
}

export interface CreateDocumentTypePayload {
  name: string;
  code?: string;
  category: DocumentCategory | string;
  applicableEntityType: DocumentEntityType | 'ALL';
  description: string;
  isRequired?: boolean;
  hasExpiry?: boolean;
  defaultExpiryMonths?: number;
  allowedExtensions?: string[];
  maxSizeBytes?: number;
}

export interface UpdateDocumentTypePayload {
  name?: string;
  category?: DocumentCategory | string;
  applicableEntityType?: DocumentEntityType | 'ALL';
  description?: string;
  isRequired?: boolean;
  hasExpiry?: boolean;
  defaultExpiryMonths?: number;
  allowedExtensions?: string[];
  maxSizeBytes?: number;
  isActive?: boolean;
}

export interface CreateCertificateTemplatePayload {
  name: string;
  code?: string;
  entityType: 'STUDENT' | 'TEACHER' | 'STAFF';
  category: CertificateTemplateCategory;
  description: string;
  orientation?: CertificateTemplateOrientation;
  dimensions?: { width: number; height: number; unit: 'mm' | 'in' | 'px' };
  layoutDesign?: CertificateTemplateLayoutDesign;
  headerText: string;
  title: string;
  subtitle?: string;
  bodyTemplate: string;
  footerText?: string;
  primaryColor?: string;
  secondaryColor?: string;
  accentColor?: string;
  logoUrl?: string;
  watermarkUrl?: string;
  signatories?: CertificateSignatory[];
  qrCodeEnabled?: boolean;
}

export interface UpdateCertificateTemplatePayload {
  name?: string;
  description?: string;
  orientation?: CertificateTemplateOrientation;
  dimensions?: { width: number; height: number; unit: 'mm' | 'in' | 'px' };
  layoutDesign?: CertificateTemplateLayoutDesign;
  headerText?: string;
  title?: string;
  subtitle?: string;
  bodyTemplate?: string;
  footerText?: string;
  primaryColor?: string;
  secondaryColor?: string;
  accentColor?: string;
  logoUrl?: string;
  watermarkUrl?: string;
  signatories?: CertificateSignatory[];
  qrCodeEnabled?: boolean;
  status?: 'DRAFT' | 'ACTIVE' | 'ARCHIVED';
}

export interface DocumentFilterParams {
  search?: string;
  entityType?: DocumentEntityType | 'ALL';
  entityId?: string;
  category?: string;
  documentTypeId?: string;
  status?: DocumentStatus | 'ALL';
  verificationStatus?: DocumentVerificationStatus | 'ALL';
  expiringWithinDays?: number;
  isExpired?: boolean;
  startDate?: string;
  endDate?: string;
  page?: number;
  limit?: number;
  sortBy?: 'createdAt' | 'updatedAt' | 'title' | 'expiryDate';
  sortOrder?: 'asc' | 'desc';
}

export interface DocumentDashboardMetrics {
  totalDocuments: number;
  activeDocuments: number;
  pendingReview: number;
  verified: number;
  rejected: number;
  expired: number;
  expiringSoon: number; // Expiring in next 30 days
  entityBreakdown: {
    student: number;
    teacher: number;
    staff: number;
    guardian: number;
    school: number;
    department: number;
  };
  categoryBreakdown: Record<string, number>;
  monthlyUploadTrends: Array<{
    month: string;
    count: number;
  }>;
}

// ==============================================================
// PART 15C — CERTIFICATE GENERATION & ISSUANCE TYPES
// ==============================================================

export type CertificateLifecycleStatus =
  | 'DRAFT'
  | 'GENERATED'
  | 'PENDING_VERIFICATION'
  | 'VERIFIED'
  | 'VERIFICATION_REJECTED'
  | 'PENDING_APPROVAL'
  | 'APPROVED'
  | 'APPROVAL_REJECTED'
  | 'ISSUED'
  | 'CANCELLED'
  | 'REVOKED';

export type CertificateVerificationStatus = 'PENDING' | 'VERIFIED' | 'REJECTED';
export type CertificateApprovalStatus = 'PENDING' | 'APPROVED' | 'REJECTED';

export type CertificateWorkflowAction =
  | 'GENERATED'
  | 'SUBMITTED_FOR_VERIFICATION'
  | 'VERIFIED'
  | 'VERIFICATION_REJECTED'
  | 'SUBMITTED_FOR_APPROVAL'
  | 'APPROVED'
  | 'APPROVAL_REJECTED'
  | 'ISSUED'
  | 'REISSUED'
  | 'CANCELLED'
  | 'REVOKED'
  | 'PUBLIC_VERIFIED';

export interface CertificateWorkflowEvent {
  id: string;
  certificateId: string;
  action: CertificateWorkflowAction;
  actorId: string;
  actorName: string;
  actorRole: string;
  timestamp: string;
  previousStatus: CertificateLifecycleStatus;
  newStatus: CertificateLifecycleStatus;
  notes?: string;
  reason?: string;
  metadata?: Record<string, any>;
}

export interface CertificateTypeConfig {
  id: string;
  schoolId: string;
  name: string;
  code: string;
  description: string;
  applicableEntityType: DocumentEntityType | 'ALL';
  defaultTemplateId?: string;
  requiredFields: string[];
  numberingPrefix: string;
  numberingFormat: string; // e.g. '{PREFIX}/{YYYY}/{SEQ:6}'
  nextSequenceNumber: number;
  isActive: boolean;
  createdBy: string;
  updatedBy?: string;
  createdAt: string;
  updatedAt: string;
}

export interface CertificateDataSnapshot {
  student: {
    id: string;
    fullName: string;
    admissionNumber: string;
    rollNumber?: string;
    className: string;
    sectionName: string;
    academicSession: string;
    academicSessionId?: string;
    dob?: string;
    gender?: string;
    admissionDate?: string;
    guardianName?: string;
    address?: string;
  };
  school: {
    id: string;
    name: string;
    address: string;
    contact: string;
    email: string;
    website?: string;
    logoUrl?: string;
  };
  variables: Record<string, string>;
  customFields?: Record<string, string>;
}

export interface IssuedCertificate {
  id: string;
  schoolId: string;
  certificateTypeId: string;
  certificateTypeCode: string;
  certificateTypeName: string;
  certificateNumber: string;
  studentId: string;
  studentName: string;
  admissionNumber: string;
  className?: string;
  sectionName?: string;
  academicSessionId: string;
  academicSessionName: string;
  templateId: string;
  templateSnapshot: CertificateTemplate;
  dataSnapshot: CertificateDataSnapshot;
  renderedTitle: string;
  renderedSubtitle?: string;
  renderedBody: string;
  renderedFooter?: string;
  issueDate: string;
  status: CertificateLifecycleStatus;
  documentId?: string; // Foreign key to ManagedDocument in vault
  fileUrl?: string;
  fileName?: string;
  issuedBy?: string;
  issuedByName?: string;
  issuedAt?: string;
  cancellationReason?: string;
  cancelledBy?: string;
  cancelledByName?: string;
  cancelledAt?: string;
  revocationReason?: string;
  revokedBy?: string;
  revokedByName?: string;
  revokedAt?: string;
  reissueReason?: string;
  reissuedFromCertificateId?: string;
  reissuedToCertificateId?: string;
  version: number;
  remarks?: string;
  notes?: string;
  qrVerificationCode: string;
  // Part 15D — Verification, Approval & Digital Certificate Workflow
  verificationStatus?: CertificateVerificationStatus;
  verifiedBy?: string;
  verifiedByName?: string;
  verifiedAt?: string;
  verificationNotes?: string;
  verificationRejectionReason?: string;

  approvalStatus?: CertificateApprovalStatus;
  approvedBy?: string;
  approvedByName?: string;
  approvedAt?: string;
  approvalNotes?: string;
  approvalRejectionReason?: string;

  digitalVerificationReference: string; // Opaque non-sensitive public token (e.g. SEC-VER-xxx)
  verificationUrl?: string;
  qrCodeDataUrl?: string;
  workflowHistory?: CertificateWorkflowEvent[];

  createdAt: string;
  updatedAt: string;
}

export interface CreateCertificateTypePayload {
  name: string;
  code?: string;
  description: string;
  applicableEntityType?: DocumentEntityType | 'ALL';
  defaultTemplateId?: string;
  requiredFields?: string[];
  numberingPrefix?: string;
  numberingFormat?: string;
  nextSequenceNumber?: number;
}

export interface UpdateCertificateTypePayload {
  name?: string;
  description?: string;
  applicableEntityType?: DocumentEntityType | 'ALL';
  defaultTemplateId?: string;
  requiredFields?: string[];
  numberingPrefix?: string;
  numberingFormat?: string;
  nextSequenceNumber?: number;
  isActive?: boolean;
}

export interface PreviewCertificatePayload {
  certificateTypeId: string;
  studentId: string;
  templateId?: string;
  academicSessionId?: string;
  issueDate?: string;
  remarks?: string;
  customFields?: Record<string, string>;
}

export interface GenerateCertificatePayload {
  certificateTypeId: string;
  studentId: string;
  templateId?: string;
  academicSessionId?: string;
  issueDate?: string;
  remarks?: string;
  customFields?: Record<string, string>;
  asDraft?: boolean;
  notes?: string;
}

export interface IssueCertificatePayload {
  issueDate?: string;
  remarks?: string;
  notes?: string;
}

export interface ReissueCertificatePayload {
  reissueReason: string;
  templateId?: string;
  remarks?: string;
  customFields?: Record<string, string>;
}

export interface CancelCertificatePayload {
  reason: string;
}

export interface RevokeCertificatePayload {
  reason: string;
}

export interface SubmitForVerificationPayload {
  notes?: string;
}

export interface VerifyCertificatePayload {
  decision: 'VERIFY' | 'REJECT';
  notes?: string;
  rejectionReason?: string;
}

export interface ApproveCertificatePayload {
  decision: 'APPROVE' | 'REJECT';
  notes?: string;
  rejectionReason?: string;
}

export interface PublicCertificateVerificationResult {
  status: 'VALID' | 'REVOKED' | 'CANCELLED' | 'NOT_FOUND' | 'RATE_LIMITED';
  isAuthentic: boolean;
  message: string;
  certificate?: {
    certificateNumber: string;
    certificateTypeName: string;
    issueDate: string;
    schoolName: string;
    schoolAddress?: string;
    maskedStudentName: string;
    admissionNumberMasked?: string;
    className?: string;
    academicSessionName: string;
    verificationReference: string;
    status: CertificateLifecycleStatus;
    qrVerificationCode: string;
    revokedAt?: string;
    revocationReason?: string;
    cancelledAt?: string;
    cancellationReason?: string;
    verificationTimestamp: string;
  };
}

export interface CertificateFilterParams {
  search?: string;
  certificateTypeId?: string;
  studentId?: string;
  academicSessionId?: string;
  status?: CertificateLifecycleStatus | 'ALL';
  verificationStatus?: CertificateVerificationStatus | 'ALL';
  approvalStatus?: CertificateApprovalStatus | 'ALL';
  startDate?: string;
  endDate?: string;
  page?: number;
  limit?: number;
  sortBy?: 'createdAt' | 'issueDate' | 'certificateNumber' | 'studentName';
  sortOrder?: 'asc' | 'desc';
}

export interface CertificateStatsMetrics {
  totalCertificates: number;
  drafts: number;
  generated: number;
  pendingVerification: number;
  verified: number;
  pendingApproval: number;
  approved: number;
  issued: number;
  cancelled: number;
  revoked: number;
  rejected: number;
  byType: Record<string, number>;
  monthlyTrends: Array<{
    month: string;
    count: number;
  }>;
}

// ==============================================================
// PART 15E — STAFF, TEACHER, PARENT & SCHOOL DOCUMENT MANAGEMENT
// ==============================================================

export interface DocumentRequirementConfig {
  id: string;
  schoolId: string;
  entityType: DocumentEntityType;
  documentTypeId: string;
  documentTypeName: string;
  documentTypeCode?: string;
  isRequired: boolean;
  applicableRole?: string; // 'ALL' or specific role/designation (e.g. 'TEACHER', 'HR', 'ACCOUNTANT')
  applicableCategory?: string;
  academicSessionId?: string;
  description?: string;
  isActive: boolean;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface CreateDocumentRequirementPayload {
  entityType: DocumentEntityType;
  documentTypeId: string;
  isRequired: boolean;
  applicableRole?: string;
  applicableCategory?: string;
  academicSessionId?: string;
  description?: string;
  isActive?: boolean;
}

export interface UpdateDocumentRequirementPayload {
  isRequired?: boolean;
  applicableRole?: string;
  applicableCategory?: string;
  academicSessionId?: string;
  description?: string;
  isActive?: boolean;
}

export interface EntityDocumentChecklistItem {
  requirementId?: string;
  documentTypeId: string;
  documentTypeName: string;
  category: string;
  isRequired: boolean;
  status: 'MISSING' | 'SUBMITTED' | 'PENDING_REVIEW' | 'VERIFIED' | 'REJECTED' | 'EXPIRING_SOON' | 'EXPIRED';
  document?: ManagedDocument;
  daysRemaining?: number;
  isExpiringSoon?: boolean;
  isExpired?: boolean;
}

export interface EntityDocumentChecklistSummary {
  entityId: string;
  entityName: string;
  entityCode?: string;
  entityType: DocumentEntityType;
  totalRequired: number;
  totalOptional: number;
  submitted: number;
  pendingReview: number;
  verified: number;
  rejected: number;
  missing: number;
  expiringSoon: number;
  expired: number;
  compliancePercentage: number;
  items: EntityDocumentChecklistItem[];
}

export interface ExpiringDocumentItem {
  document: ManagedDocument;
  daysRemaining: number;
  isExpired: boolean;
  isExpiringSoon: boolean;
}

// ==============================================================
// PART 15F — DOCUMENT & CERTIFICATE REPORTS, ANALYTICS & COMPLIANCE
// ==============================================================

export type DocumentReportDateRangePreset =
  | 'TODAY'
  | 'LAST_7_DAYS'
  | 'THIS_MONTH'
  | 'LAST_30_DAYS'
  | 'THIS_QUARTER'
  | 'THIS_YEAR'
  | 'CUSTOM';

export interface DocumentAnalyticsDashboardData {
  // Current-State KPIs
  currentState: {
    totalDocuments: number;
    studentDocuments: number;
    teacherDocuments: number;
    staffDocuments: number;
    guardianDocuments: number;
    schoolDocuments: number;
    pendingVerification: number;
    verified: number;
    rejected: number;
    missingRequiredDocuments: number;
    expiredDocuments: number;
    expiringSoon: number;
    archivedDocuments: number;
  };
  // Historical Metrics over selected period
  periodMetrics: {
    preset: DocumentReportDateRangePreset;
    startDate: string;
    endDate: string;
    documentsUploaded: number;
    documentsVerified: number;
    documentsRejected: number;
    documentsExpired: number;
  };
  // Trend timelines & breakdowns
  timeline: Array<{
    date: string;
    uploaded: number;
    verified: number;
    rejected: number;
    expired: number;
  }>;
  categoryBreakdown: Array<{
    category: string;
    count: number;
    percentage: number;
  }>;
  entityBreakdown: Array<{
    entityType: DocumentEntityType;
    count: number;
    percentage: number;
  }>;
  verificationBreakdown: Array<{
    status: string;
    count: number;
  }>;
}

export interface DocumentComplianceReportItem {
  entityId: string;
  entityName: string;
  entityCode?: string;
  entityType: DocumentEntityType;
  subGroup?: string; // Class/Section, Department, Designation, Relation
  totalApplicableRequired: number;
  totalOptional: number;
  submittedCount: number;
  verifiedCount: number;
  pendingReviewCount: number;
  rejectedCount: number;
  missingCount: number;
  expiredCount: number;
  compliancePercentage: number;
  complianceStatus: 'FULLY_COMPLIANT' | 'PARTIALLY_COMPLIANT' | 'NON_COMPLIANT';
  items: EntityDocumentChecklistItem[];
}

export interface DocumentComplianceReportSummary {
  totalEntities: number;
  averageComplianceRate: number;
  fullyCompliantCount: number;
  partiallyCompliantCount: number;
  nonCompliantCount: number;
  byEntityType: Record<string, { total: number; avgCompliance: number; fullyCompliant: number }>;
}

export interface DocumentComplianceReportFilterParams {
  entityType?: DocumentEntityType | 'ALL';
  academicSessionId?: string;
  classId?: string;
  department?: string;
  complianceStatus?: 'ALL' | 'FULLY_COMPLIANT' | 'PARTIALLY_COMPLIANT' | 'NON_COMPLIANT';
  search?: string;
  page?: number;
  limit?: number;
  sortBy?: 'entityName' | 'compliancePercentage' | 'missingCount' | 'verifiedCount';
  sortOrder?: 'asc' | 'desc';
}

export interface DocumentExpiryReportItem {
  documentId: string;
  documentTitle: string;
  fileName: string;
  fileType: string;
  entityType: DocumentEntityType;
  entityId: string;
  entityName: string;
  category: string;
  documentTypeName: string;
  issueDate?: string;
  expiryDate: string;
  daysRemaining: number;
  expiryStatus: 'ALREADY_EXPIRED' | 'EXPIRING_TODAY' | 'EXPIRING_SOON' | 'EXPIRING_HORIZON' | 'VALID';
  urgency: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  verificationStatus: string;
}

export interface DocumentExpiryReportSummary {
  totalMonitored: number;
  alreadyExpired: number;
  expiringToday: number;
  expiringIn7Days: number;
  expiringIn30Days: number;
  expiringIn60Days: number;
  valid: number;
}

export interface CertificateAnalyticsDashboardData {
  // Current-State KPIs
  currentState: {
    totalCertificates: number;
    draft: number;
    generated: number;
    pendingVerification: number;
    verified: number;
    pendingApproval: number;
    approved: number;
    issued: number;
    cancelled: number;
    revoked: number;
  };
  // Historical period metrics
  periodMetrics: {
    preset: DocumentReportDateRangePreset;
    startDate: string;
    endDate: string;
    generatedCount: number;
    verifiedCount: number;
    approvedCount: number;
    issuedCount: number;
    revokedCount: number;
    cancelledCount: number;
  };
  // Timeline trends
  timeline: Array<{
    date: string;
    generated: number;
    verified: number;
    approved: number;
    issued: number;
  }>;
  byType: Array<{
    typeId: string;
    typeName: string;
    typeCode: string;
    count: number;
    percentage: number;
  }>;
  bySession: Array<{
    sessionId: string;
    sessionName: string;
    count: number;
  }>;
}

export interface CertificateLifecycleAnalytics {
  funnel: {
    generatedCount: number;
    verifiedCount: number;
    approvedCount: number;
    issuedCount: number;
  };
  dropoffRates: {
    verificationDropoffPct: number;
    approvalDropoffPct: number;
  };
  exceptions: {
    verificationRejectedCount: number;
    approvalRejectedCount: number;
    revokedCount: number;
    cancelledCount: number;
  };
  durations: {
    avgGenerationToVerificationHours: number;
    avgVerificationToApprovalHours: number;
    avgApprovalToIssuanceHours: number;
    avgTotalCycleDays: number;
    sampleCount: number;
  };
}

export interface CertificateIssuanceReportItem {
  id: string;
  certificateNumber: string;
  certificateTypeName: string;
  certificateTypeCode: string;
  studentId: string;
  studentName: string;
  admissionNumber: string;
  className?: string;
  sectionName?: string;
  academicSessionName: string;
  issueDate: string;
  status: CertificateLifecycleStatus;
  templateName: string;
  verificationStatus?: CertificateVerificationStatus;
  verifiedByName?: string;
  verifiedAt?: string;
  approvalStatus?: CertificateApprovalStatus;
  approvedByName?: string;
  approvedAt?: string;
  issuedByName?: string;
  issuedAt?: string;
  digitalVerificationReference: string;
  version: number;
  isRevoked: boolean;
  isCancelled: boolean;
}

export interface CertificateWorkflowReportItem {
  certificateId: string;
  certificateNumber: string;
  certificateTypeName: string;
  studentName: string;
  currentStatus: CertificateLifecycleStatus;
  verificationStatus?: CertificateVerificationStatus;
  verifiedByName?: string;
  verifiedAt?: string;
  verificationRejectionReason?: string;
  approvalStatus?: CertificateApprovalStatus;
  approvedByName?: string;
  approvedAt?: string;
  approvalRejectionReason?: string;
  cancelledAt?: string;
  cancelledByName?: string;
  cancellationReason?: string;
  revokedAt?: string;
  revokedByName?: string;
  revocationReason?: string;
  workflowHistory: CertificateWorkflowEvent[];
}

export interface DigitalVerificationReportItem {
  certificateNumber: string;
  certificateTypeName: string;
  digitalVerificationReference: string;
  status: CertificateLifecycleStatus;
  issueDate: string;
  maskedStudentName: string;
  academicSessionName: string;
  isAuthentic: boolean;
  revokedAt?: string;
  cancelledAt?: string;
}

export interface DocumentCertificateAuditItem {
  id: string;
  timestamp: string;
  userName: string;
  userRole: string;
  action: string;
  entityType: string;
  entityId?: string;
  details: string;
  ipAddress: string;
}

export interface DocumentCertificateReconciliationReport {
  timestamp: string;
  isReconciled: boolean;
  documents: {
    totalRecords: number;
    dashboardTotal: number;
    activeTotal: number;
    archivedTotal: number;
    variance: number;
  };
  certificates: {
    totalRecords: number;
    dashboardTotal: number;
    issuedCount: number;
    verifiedCount: number;
    approvedCount: number;
    variance: number;
  };
  expiries: {
    expiredRecords: number;
    dashboardExpired: number;
    variance: number;
  };
  compliance: {
    evaluatedEntities: number;
    averageCalculatedCompliance: number;
  };
}
