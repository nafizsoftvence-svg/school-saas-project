/**
 * Sygmate School Management System
 * Staff & Human Resource Management Foundation (Part 12A)
 * Type Definitions & Domain Models
 */

import { UserRole, UserStatus } from './index.js';

export type StaffType =
  | 'teaching'
  | 'administrative'
  | 'support'
  | 'management'
  | 'operational';

export type StaffEmploymentType =
  | 'full_time'
  | 'part_time'
  | 'contract'
  | 'probation'
  | 'visiting'
  | 'temporary';

export type StaffEmploymentStatus =
  | 'active'
  | 'on_leave'
  | 'probation'
  | 'suspended'
  | 'resigned'
  | 'retired'
  | 'terminated';

export type EmploymentStatus = StaffEmploymentStatus;
export type EmploymentType = StaffEmploymentType;
export type Gender = 'male' | 'female' | 'other';

export type DesignationLevel =
  | 'entry'
  | 'mid'
  | 'senior'
  | 'lead'
  | 'executive';

export interface Designation {
  id: string;
  title: string;
  code: string;
  departmentId?: string;
  departmentName?: string;
  staffType: StaffType | string;
  description?: string;
  level?: DesignationLevel | string;
  status: 'active' | 'inactive' | 'archived' | string;
  staffCount?: number;
  createdAt: string;
  updatedAt: string;
}

export type StaffDocumentCategory =
  | 'ID_PROOF'
  | 'RESUME_CV'
  | 'ACADEMIC_CERTIFICATE'
  | 'EXPERIENCE_LETTER'
  | 'CONTRACT'
  | 'POLICE_CLEARANCE'
  | 'MEDICAL_REPORT'
  | 'OTHER';

export type StaffDocumentVerificationStatus =
  | 'PENDING_VERIFICATION'
  | 'VERIFIED'
  | 'REJECTED'
  | 'EXPIRED';

export interface StaffDocument {
  id: string;
  staffId: string;
  name: string;
  title: string;
  category: StaffDocumentCategory | string;
  documentNumber?: string;
  issuingAuthority?: string;
  issueDate?: string;
  expiryDate?: string;
  fileUrl: string;
  fileSize?: string;
  fileType?: string;
  verificationStatus: StaffDocumentVerificationStatus | string;
  verifiedBy?: string;
  verifiedAt?: string;
  verificationRemarks?: string;
  uploadedAt: string;
}

export interface StaffStatusHistoryEntry {
  id: string;
  staffId: string;
  previousStatus: string;
  newStatus: string;
  reason: string;
  effectiveDate: string;
  changedBy: string;
  changedByName?: string;
  notes?: string;
  timestamp: string;
}

export interface StaffProfile {
  id: string;
  userId?: string;
  teacherProfileId?: string;
  employeeCode: string; // e.g. EMP-ADM-1001, EMP-T-1004
  firstName: string;
  lastName: string;
  displayName?: string;
  fullName?: string;
  avatarUrl?: string;
  gender: 'male' | 'female' | 'other' | string;
  dateOfBirth?: string;
  maritalStatus?: 'single' | 'married' | 'divorced' | 'widowed' | string;
  nationality?: string;
  bloodGroup?: string;
  nationalIdNumber?: string;
  passportNumber?: string;

  // Contact Info
  email: string;
  phone: string;
  emergencyContactName?: string;
  emergencyContactPhone?: string;
  emergencyContactRelation?: string;
  currentAddress: string;
  permanentAddress?: string;
  city?: string;
  state?: string;
  postalCode?: string;
  country?: string;

  // Professional & Organizational Structure
  staffType: StaffType | string;
  departmentId: string;
  departmentName: string;
  designationId?: string;
  designation: string;
  employmentType: StaffEmploymentType | string;
  employmentStatus: StaffEmploymentStatus | string;
  joiningDate: string;
  confirmationDate?: string;
  contractEndDate?: string;
  qualification: string;
  specialization?: string;
  yearsOfExperience?: number;
  workShift?: 'morning' | 'evening' | 'general' | 'rotational' | string;
  workLocation?: string;

  // Status Change Metadata
  statusChangeReason?: string;
  statusEffectiveDate?: string;

  // Embedded collections
  documents?: StaffDocument[];
  statusHistory?: StaffStatusHistoryEntry[];

  // Linked User Account Metadata
  hasAccount?: boolean;
  accountRole?: UserRole | string;
  accountStatus?: UserStatus | string;
  username?: string;
  lastLoginAt?: string;

  createdAt: string;
  updatedAt: string;
}

export interface StaffDirectoryQuery {
  search?: string;
  staffType?: string;
  departmentId?: string;
  designationId?: string;
  employmentStatus?: string;
  employmentType?: string;
  gender?: string;
  page?: number;
  limit?: number;
  sortBy?: 'name' | 'employeeCode' | 'joiningDate' | 'department' | 'designation' | 'status';
  sortOrder?: 'asc' | 'desc';
}

export interface StaffDirectorySummary {
  totalStaff: number;
  teachingStaff: number;
  administrativeStaff: number;
  supportStaff: number;
  managementStaff: number;
  operationalStaff: number;
  activeStaff: number;
  onLeaveStaff: number;
  probationStaff: number;
  inactiveStaff: number;
}

export interface StaffDirectoryResponse {
  items: StaffProfile[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
  summary: StaffDirectorySummary;
}

export interface StaffStatsResponse {
  summary: StaffDirectorySummary;
  byDepartment: Array<{
    departmentId: string;
    departmentName: string;
    count: number;
  }>;
  byStaffType: Array<{
    type: string;
    count: number;
  }>;
  byEmploymentStatus: Array<{
    status: string;
    count: number;
  }>;
  byGender: Array<{
    gender: string;
    count: number;
  }>;
  recentJoiners: StaffProfile[];
}

export interface CreateStaffPayload {
  employeeCode?: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  avatarUrl?: string;
  gender: 'male' | 'female' | 'other' | string;
  dateOfBirth?: string;
  maritalStatus?: 'single' | 'married' | 'divorced' | 'widowed' | string;
  nationality?: string;
  bloodGroup?: string;
  nationalIdNumber?: string;
  passportNumber?: string;
  emergencyContactName?: string;
  emergencyContactPhone?: string;
  emergencyContactRelation?: string;
  currentAddress: string;
  permanentAddress?: string;
  city?: string;
  state?: string;
  postalCode?: string;
  country?: string;
  staffType: StaffType | string;
  departmentId: string;
  designationId?: string;
  designation?: string;
  employmentType?: StaffEmploymentType | string;
  employmentStatus?: StaffEmploymentStatus | string;
  joiningDate?: string;
  confirmationDate?: string;
  contractEndDate?: string;
  qualification: string;
  specialization?: string;
  yearsOfExperience?: number;
  workShift?: string;
  workLocation?: string;

  // Optional account creation on staff creation
  createAccount?: boolean;
  username?: string;
  password?: string;
  accountRole?: UserRole;
}

export interface UpdateStaffPayload extends Partial<CreateStaffPayload> {}

export interface ChangeStaffStatusPayload {
  newStatus: StaffEmploymentStatus | string;
  reason: string;
  effectiveDate: string;
  notes?: string;
  deactivateAccount?: boolean;
}

export interface UploadStaffDocumentPayload {
  title: string;
  name: string;
  category: StaffDocumentCategory | string;
  documentNumber?: string;
  issuingAuthority?: string;
  issueDate?: string;
  expiryDate?: string;
  fileUrl: string;
  fileSize?: string;
  fileType?: string;
}

export interface VerifyStaffDocumentPayload {
  verificationStatus: StaffDocumentVerificationStatus | string;
  verificationRemarks?: string;
}

export interface CreateDesignationPayload {
  title: string;
  code: string;
  departmentId?: string;
  staffType: StaffType | string;
  description?: string;
  level?: DesignationLevel | string;
  status?: 'active' | 'inactive' | 'archived';
}

export interface UpdateDesignationPayload extends Partial<CreateDesignationPayload> {}

// =========================================================================
// PART 12B — STAFF ATTENDANCE, WORK SCHEDULE & LEAVE INTEGRATION MODELS
// =========================================================================

export type StaffAttendanceStatus =
  | 'PRESENT'
  | 'ABSENT'
  | 'LATE'
  | 'HALF_DAY'
  | 'LEAVE'
  | 'EXCUSED';

export interface StaffAttendanceCorrectionHistoryItem {
  id: string;
  fromStatus: StaffAttendanceStatus;
  toStatus: StaffAttendanceStatus;
  fromCheckInTime?: string;
  toCheckInTime?: string;
  fromCheckOutTime?: string;
  toCheckOutTime?: string;
  reason: string;
  correctedByUserId: string;
  correctedByUserName: string;
  correctedAt: string;
}

export interface StaffAttendanceRecord {
  id: string;
  staffId: string;
  teacherProfileId?: string;
  userId?: string;
  staffName: string;
  employeeCode: string;
  staffType: StaffType | string;
  departmentId?: string;
  departmentName?: string;
  designationId?: string;
  designation?: string;
  avatarUrl?: string;
  academicSessionId: string;
  academicSessionName?: string;
  date: string; // 'YYYY-MM-DD'
  status: StaffAttendanceStatus;
  checkInTime?: string; // 'HH:MM'
  checkOutTime?: string; // 'HH:MM'
  remarks?: string;
  isOverridden?: boolean;
  overrideReason?: string;
  history?: StaffAttendanceCorrectionHistoryItem[];
  createdBy: string;
  createdByName?: string;
  updatedBy: string;
  updatedByName?: string;
  createdAt: string;
  updatedAt: string;
  isDeleted?: boolean;
  deletedAt?: string;
  deletedBy?: string;
}

export type StaffWorkScheduleScope =
  | 'INDIVIDUAL'
  | 'DESIGNATION'
  | 'DEPARTMENT'
  | 'STAFF_TYPE'
  | 'SCHOOL_DEFAULT';

export type DayOfWeekName =
  | 'SUNDAY'
  | 'MONDAY'
  | 'TUESDAY'
  | 'WEDNESDAY'
  | 'THURSDAY'
  | 'FRIDAY'
  | 'SATURDAY';

export interface StaffScheduleDayConfig {
  dayOfWeek: number; // 0=Sunday, 1=Monday ... 6=Saturday
  dayName: DayOfWeekName;
  isWorkingDay: boolean;
  startTime?: string; // e.g. '08:00'
  endTime?: string; // e.g. '16:00'
  breakStartTime?: string; // e.g. '12:00'
  breakEndTime?: string; // e.g. '13:00'
  breakMinutes?: number; // e.g. 60
}

export interface StaffWorkSchedule {
  id: string;
  name: string;
  scope: StaffWorkScheduleScope;
  priority: number; // 1: INDIVIDUAL, 2: DESIGNATION, 3: DEPARTMENT, 4: STAFF_TYPE, 5: SCHOOL_DEFAULT
  staffId?: string;
  staffName?: string;
  employeeCode?: string;
  designationId?: string;
  designationName?: string;
  departmentId?: string;
  departmentName?: string;
  staffType?: StaffType | string;
  days: StaffScheduleDayConfig[];
  effectiveFrom: string; // 'YYYY-MM-DD'
  effectiveTo?: string; // 'YYYY-MM-DD'
  isActive: boolean;
  notes?: string;
  createdAt: string;
  updatedAt: string;
  createdBy: string;
  createdByName?: string;
}

export interface StaffEffectiveSchedule {
  staffId: string;
  staffName: string;
  employeeCode: string;
  staffType: string;
  departmentName: string;
  date: string;
  dayOfWeek: number;
  dayName: DayOfWeekName;
  isWorkingDay: boolean;
  isCalendarWorkingDay: boolean;
  dayType: 'WORKING_DAY' | 'WEEKEND' | 'HOLIDAY' | 'SPECIAL_WORKING_DAY';
  dayReason?: string;
  startTime: string;
  endTime: string;
  breakStartTime?: string;
  breakEndTime?: string;
  breakMinutes: number;
  scheduleId: string;
  scheduleName: string;
  scheduleScope: StaffWorkScheduleScope;
  priority: number;
}

export interface StaffDailyRosterItem {
  staffId: string;
  teacherProfileId?: string;
  userId?: string;
  staffName: string;
  employeeCode: string;
  staffType: StaffType | string;
  departmentId?: string;
  departmentName?: string;
  designation?: string;
  avatarUrl?: string;
  status?: StaffAttendanceStatus;
  recordId?: string;
  checkInTime?: string;
  checkOutTime?: string;
  remarks?: string;
  isOverridden?: boolean;
  overrideReason?: string;
  history?: StaffAttendanceCorrectionHistoryItem[];
  effectiveSchedule?: StaffEffectiveSchedule;
  updatedAt?: string;
  updatedByName?: string;
}

export interface StaffDailyAttendanceResponse {
  date: string;
  academicSessionId: string;
  academicSessionName: string;
  dayType: string;
  isWorkingDay: boolean;
  dayReason: string;
  canMarkAttendance: boolean;
  stats: {
    totalStaff: number;
    markedStaff: number;
    presentCount: number;
    absentCount: number;
    lateCount: number;
    halfDayCount: number;
    leaveCount: number;
    excusedCount: number;
    unmarkedCount: number;
    attendanceRate: number;
  };
  roster: StaffDailyRosterItem[];
}

export interface StaffMonthlyMatrixDay {
  date: string;
  dayOfMonth: number;
  dayOfWeek: number;
  dayName: string;
  dayType: string;
  isWorkingDay: boolean;
  reason?: string;
}

export interface StaffMonthlyMatrixRow {
  staffId: string;
  teacherProfileId?: string;
  staffName: string;
  employeeCode: string;
  staffType: StaffType | string;
  departmentName: string;
  designation: string;
  attendanceByDate: Record<
    string,
    {
      status: StaffAttendanceStatus;
      recordId?: string;
      checkInTime?: string;
      checkOutTime?: string;
      remarks?: string;
      isOverridden?: boolean;
    }
  >;
  summary: {
    totalApplicableWorkingDays: number;
    present: number;
    absent: number;
    late: number;
    halfDay: number;
    leave: number;
    excused: number;
    unmarked: number;
    rate: number;
  };
}

export interface StaffMonthlyAttendanceResponse {
  academicSessionId: string;
  academicSessionName: string;
  year: number;
  month: number;
  monthName: string;
  days: StaffMonthlyMatrixDay[];
  staff: StaffMonthlyMatrixRow[];
  overallSummary: {
    totalStaff: number;
    averageAttendanceRate: number;
    totalPresent: number;
    totalAbsent: number;
    totalLate: number;
    totalHalfDay: number;
    totalLeave: number;
    totalExcused: number;
  };
  totalWorkingDays: number;
}

export interface StaffAttendanceStatsResponse {
  totalStaff: number;
  todayMarked: number;
  todayPresent: number;
  todayAbsent: number;
  todayLate: number;
  todayLeave: number;
  todayRate: number;
  monthlyAverageRate: number;
  totalActiveSchedules: number;
  pendingLeavesCount: number;
  byDepartment: Array<{
    departmentId: string;
    departmentName: string;
    totalStaff: number;
    presentCount: number;
    attendanceRate: number;
  }>;
  byStaffType: Array<{
    staffType: string;
    totalStaff: number;
    presentCount: number;
    attendanceRate: number;
  }>;
}

export interface StaffAttendanceHistoryItem {
  id: string;
  date: string;
  status: StaffAttendanceStatus;
  checkInTime?: string;
  checkOutTime?: string;
  remarks?: string;
  isOverridden?: boolean;
  overrideReason?: string;
  history?: StaffAttendanceCorrectionHistoryItem[];
  createdByName?: string;
  updatedByName?: string;
  updatedAt: string;
}

export interface MarkStaffAttendancePayload {
  staffId: string;
  date: string;
  status: StaffAttendanceStatus;
  checkInTime?: string;
  checkOutTime?: string;
  remarks?: string;
  academicSessionId?: string;
  allowOverride?: boolean;
  overrideReason?: string;
}

export interface BulkMarkStaffAttendancePayload {
  date: string;
  academicSessionId?: string;
  records: Array<{
    staffId: string;
    status: StaffAttendanceStatus;
    checkInTime?: string;
    checkOutTime?: string;
    remarks?: string;
  }>;
  allowOverride?: boolean;
  overrideReason?: string;
}

export interface CorrectStaffAttendancePayload {
  status?: StaffAttendanceStatus;
  checkInTime?: string;
  checkOutTime?: string;
  remarks?: string;
  reason: string;
}

export interface CreateStaffSchedulePayload {
  name: string;
  scope: StaffWorkScheduleScope;
  staffId?: string;
  designationId?: string;
  departmentId?: string;
  staffType?: StaffType | string;
  days: StaffScheduleDayConfig[];
  effectiveFrom: string;
  effectiveTo?: string;
  notes?: string;
  isActive?: boolean;
}

export interface UpdateStaffSchedulePayload extends Partial<CreateStaffSchedulePayload> {}

export interface StaffLeaveApplicationPayload {
  staffId?: string;
  leaveTypeId: string;
  startDate: string;
  endDate?: string;
  reason: string;
  description?: string;
  remarks?: string;
  attachmentUrl?: string;
  attachmentName?: string;
  attachmentSize?: number;
  attachmentType?: string;
  status?: 'DRAFT' | 'SUBMITTED';
  allowBalanceOverride?: boolean;
  overrideReason?: string;
}

export interface ReviewStaffLeavePayload {
  status: 'APPROVED' | 'REJECTED' | 'UNDER_REVIEW' | 'PARTIALLY_APPROVED' | 'CANCELLED';
  adminRemarks?: string;
  rejectionReason?: string;
  allowBalanceOverride?: boolean;
  overrideReason?: string;
}

// =========================================================================
// PART 12C — STAFF LEAVE POLICY, BALANCE & APPROVAL WORKFLOW TYPES
// =========================================================================

export type StaffCategoryScope =
  | 'ALL'
  | 'teaching'
  | 'TEACHING'
  | 'administrative'
  | 'ADMINISTRATIVE'
  | 'support'
  | 'SUPPORT'
  | 'management'
  | 'MANAGEMENT'
  | 'operational'
  | 'NON_TEACHING';

export type ApprovalHierarchyType = 'SINGLE' | 'TWO_TIER' | 'THREE_TIER';

export interface StaffLeavePolicy {
  id: string;
  name: string;
  code: string;
  leaveTypeId: string;
  leaveTypeName: string;
  applicableStaffCategory: StaffCategoryScope;
  applicableDepartmentId?: string; // or 'ALL'
  applicableDepartmentName?: string;
  applicableDesignationId?: string; // or 'ALL'
  applicableDesignationName?: string;
  academicSessionId: string;
  entitlementDays: number;
  paidType: 'PAID' | 'UNPAID';
  carryForwardAllowed: boolean;
  maxCarryForwardDays: number;
  carryForwardExpiryMonths?: number;
  minNoticeDays: number;
  maxConsecutiveDays: number;
  requiresAttachment: boolean;
  attachmentMandatoryAboveDays?: number;
  requiresApproval: boolean;
  approvalHierarchy: ApprovalHierarchyType;
  allowNegativeBalance: boolean;
  reservePendingBalance: boolean;
  isActive: boolean;
  priority: number; // 1: Designation, 2: Department, 3: Staff Category, 4: School Default
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface CreateStaffLeavePolicyPayload {
  name: string;
  code: string;
  leaveTypeId: string;
  applicableStaffCategory?: StaffCategoryScope;
  applicableDepartmentId?: string;
  applicableDesignationId?: string;
  academicSessionId?: string;
  entitlementDays: number;
  paidType?: 'PAID' | 'UNPAID';
  carryForwardAllowed?: boolean;
  maxCarryForwardDays?: number;
  carryForwardExpiryMonths?: number;
  minNoticeDays?: number;
  maxConsecutiveDays?: number;
  requiresAttachment?: boolean;
  attachmentMandatoryAboveDays?: number;
  requiresApproval?: boolean;
  approvalHierarchy?: ApprovalHierarchyType;
  allowNegativeBalance?: boolean;
  reservePendingBalance?: boolean;
  isActive?: boolean;
  priority?: number;
  notes?: string;
}

export interface UpdateStaffLeavePolicyPayload extends Partial<CreateStaffLeavePolicyPayload> {}

export interface StaffLeaveEntitlement {
  id: string;
  staffId: string;
  staffName: string;
  employeeCode?: string;
  departmentId?: string;
  departmentName?: string;
  staffType?: string;
  leaveTypeId: string;
  leaveTypeName: string;
  policyId: string;
  policyName: string;
  academicSessionId: string;
  entitlementDays: number;
  carryForwardDays: number;
  effectiveFrom: string;
  effectiveTo: string;
  allocationType: 'POLICY_DEFAULT' | 'CUSTOM_OVERRIDE';
  allocatedBy: string;
  allocatedByName: string;
  allocatedAt: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export type StaffLeaveTransactionType =
  | 'ENTITLEMENT'
  | 'CARRY_FORWARD'
  | 'LEAVE_DEDUCTION'
  | 'LEAVE_REVERSAL'
  | 'ADJUSTMENT_ADD'
  | 'ADJUSTMENT_DEDUCT'
  | 'EXPIRED';

export interface StaffLeaveTransaction {
  id: string;
  staffId: string;
  staffName: string;
  employeeCode?: string;
  departmentId?: string;
  leaveTypeId: string;
  leaveTypeName: string;
  academicSessionId: string;
  transactionType: StaffLeaveTransactionType;
  amount: number; // positive for additions/reversals, negative for deductions/expired
  balanceBefore: number;
  balanceAfter: number;
  referenceId?: string; // leaveApplicationId or adjustmentId
  referenceType?: 'LEAVE_APPLICATION' | 'POLICY' | 'ADJUSTMENT' | 'CARRY_FORWARD_JOB' | 'EXPIRATION_JOB';
  reason: string;
  performedBy: string;
  performedByName: string;
  createdAt: string;
}

export interface StaffLeaveBalance {
  id: string;
  staffId: string;
  staffName: string;
  employeeCode: string;
  departmentId?: string;
  departmentName?: string;
  staffType: string;
  leaveTypeId: string;
  leaveTypeName: string;
  leaveTypeCode: string;
  paidType: 'PAID' | 'UNPAID';
  policyId?: string;
  policyName?: string;
  academicSessionId: string;
  entitlementDays: number;
  carryForwardDays: number;
  adjustmentsDays: number;
  usedDays: number;
  pendingDays: number;
  remainingDays: number; // entitlement + carryForward + adjustments - used - expired
  availableDays: number; // remaining - pending (if policy reserves pending)
  expiredDays: number;
  lastTransactionAt?: string;
  lastCalculatedAt: string;
}

export interface StaffLeaveApprovalHistoryItem {
  tier: number;
  approverRole: 'DEPARTMENT_HEAD' | 'REPORTING_MANAGER' | 'HR_ADMIN' | 'SUPER_ADMIN';
  approverUserId: string;
  approverName: string;
  action: 'SUBMISSION' | 'TIER_APPROVE' | 'FINAL_APPROVE' | 'REJECT' | 'CANCEL' | 'OVERRIDE';
  decisionDate: string;
  remarks?: string;
  rejectionReason?: string;
  previousStatus: string;
  newStatus: string;
}

export interface AdjustStaffLeaveBalancePayload {
  staffId: string;
  leaveTypeId: string;
  adjustmentType: 'ADD' | 'DEDUCT';
  days: number;
  reason: string;
  academicSessionId?: string;
}

export interface CarryForwardProcessPayload {
  fromSessionId: string;
  toSessionId: string;
  staffCategory?: StaffCategoryScope;
  leaveTypeId?: string;
  staffId?: string;
}

export interface CarryForwardResult {
  processedCount: number;
  totalDaysCarried: number;
  skippedCount: number;
  details: Array<{
    staffId: string;
    staffName: string;
    leaveTypeName: string;
    remainingDays: number;
    daysCarried: number;
    reason?: string;
  }>;
}

export interface StaffLeaveBalancesQuery {
  departmentId?: string;
  staffType?: string;
  leaveTypeId?: string;
  academicSessionId?: string;
  search?: string;
  page?: number;
  limit?: number;
}

export interface StaffLeaveBalancesResponse {
  items: StaffLeaveBalance[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
  summary: {
    totalStaff: number;
    totalEntitlementDays: number;
    totalCarryForwardDays: number;
    totalAdjustmentsDays: number;
    totalUsedDays: number;
    totalPendingDays: number;
    totalRemainingDays: number;
    averageUtilizationRate: number;
  };
}

export interface StaffLeaveLedgerQuery {
  staffId?: string;
  leaveTypeId?: string;
  academicSessionId?: string;
  transactionType?: StaffLeaveTransactionType;
  startDate?: string;
  endDate?: string;
  search?: string;
  page?: number;
  limit?: number;
}

export interface StaffLeaveLedgerResponse {
  items: StaffLeaveTransaction[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
}

export interface StaffLeaveReportsSummary {
  balanceReport: {
    totalEntitlement: number;
    totalUsed: number;
    totalPending: number;
    totalRemaining: number;
    totalCarryForward: number;
    utilizationRate: number;
  };
  usageByDepartment: Array<{
    departmentId: string;
    departmentName: string;
    totalDays: number;
    totalApplications: number;
  }>;
  usageByLeaveType: Array<{
    leaveTypeId: string;
    leaveTypeName: string;
    leaveTypeCode: string;
    totalDays: number;
    applicationCount: number;
  }>;
  approvalStats: {
    totalSubmitted: number;
    approved: number;
    partiallyApproved: number;
    rejected: number;
    cancelled: number;
    pending: number;
  };
}


