/**
 * Sygmate School Management System
 * Staff Performance Management (Part 12E)
 * TypeScript Type Definitions
 */

import { StaffCategoryScope } from './staff.types.js';

export type ReviewCycleStatus =
  | 'DRAFT'
  | 'OPEN'
  | 'ACTIVE'
  | 'IN_PROGRESS'
  | 'UNDER_EVALUATION'
  | 'PENDING_APPROVAL'
  | 'COMPLETED'
  | 'CLOSED'
  | 'ARCHIVED';

export type ReviewType =
  | 'ANNUAL'
  | 'HALF_YEARLY'
  | 'QUARTERLY'
  | 'PROBATION'
  | 'SPECIAL';

export type ReviewFrequency =
  | 'ANNUAL'
  | 'HALF_YEARLY'
  | 'QUARTERLY'
  | 'MONTHLY'
  | 'CUSTOM';

export type ScoringModelType =
  | 'FIVE_STAR'
  | 'TEN_POINT'
  | 'PERCENTAGE'
  | 'WEIGHTED_100';

export type RatingBand =
  | 'EXCEPTIONAL'
  | 'EXCEEDS_EXPECTATIONS'
  | 'MEETS_EXPECTATIONS'
  | 'NEEDS_IMPROVEMENT'
  | 'UNSATISFACTORY';

export type ReviewWorkflowStatus =
  | 'DRAFT'
  | 'SELF_ASSESSMENT'
  | 'SUPERVISOR_REVIEW'
  | 'HR_REVIEW'
  | 'FINALIZED'
  | 'ACKNOWLEDGED'
  | 'CLOSED'
  | 'RETURNED_FOR_CORRECTION'
  | 'REOPENED'
  | 'CANCELLED';

export type ReviewStage = ReviewWorkflowStatus;

export type CriterionCategory =
  | 'PEDAGOGY'
  | 'TEACHING_PEDAGOGY'
  | 'CLASSROOM_MANAGEMENT'
  | 'PROFESSIONALISM'
  | 'PROFESSIONAL_CONDUCT'
  | 'INSTITUTIONAL_DUTIES'
  | 'WORK_QUALITY'
  | 'LEADERSHIP'
  | 'LEADERSHIP_INITIATIVE'
  | 'COMMUNICATION'
  | 'TEAMWORK_COMMUNICATION'
  | 'PRODUCTIVITY'
  | 'ATTENDANCE_PUNCTUALITY'
  | 'PUNCTUALITY_ATTENDANCE'
  | 'STUDENT_OUTCOMES'
  | 'RESEARCH_DEVELOPMENT';

export type PerformanceCriterionCategory = CriterionCategory;

export type GoalCategory =
  | 'ACADEMIC'
  | 'ADMINISTRATIVE'
  | 'PROFESSIONAL_DEVELOPMENT'
  | 'STUDENT_OUTCOMES'
  | 'INNOVATION'
  | 'INSTITUTIONAL_CONTRIBUTION';

export type GoalStatus =
  | 'DRAFT'
  | 'ACTIVE'
  | 'IN_PROGRESS'
  | 'ACHIEVED'
  | 'PARTIALLY_ACHIEVED'
  | 'NOT_ACHIEVED'
  | 'DEFERRED'
  | 'CANCELLED';

export type PIPStatus =
  | 'DRAFT'
  | 'ACTIVE'
  | 'UNDER_REVIEW'
  | 'IMPROVED'
  | 'RESOLVED'
  | 'EXTENDED'
  | 'COMPLETED'
  | 'FAILED'
  | 'UNSUCCESSFUL'
  | 'CLOSED';

export type PIPOutcome =
  | 'PENDING'
  | 'IMPROVED_SATISFACTORY'
  | 'EXTENSION_GRANTED'
  | 'UNSATISFACTORY_TERMINATION_RECOMMENDED'
  | 'SUCCESSFUL'
  | 'UNSUCCESSFUL'
  | 'EXTENDED';

export type FeedbackType =
  | 'FORMAL_APPRAISAL'
  | 'PEER_FEEDBACK'
  | 'PEER_REVIEW'
  | 'SUPERVISOR_NOTE'
  | 'COACHING_NOTE'
  | 'COMMENDATION'
  | '360_FEEDBACK'
  | 'AREAS_TO_DEVELOP';

// ----------------------------------------------------
// 1. Performance Review Cycle
// ----------------------------------------------------

export interface PerformanceReviewCycle {
  id: string;
  name: string;
  code: string;
  description: string;
  academicSessionId: string;
  academicSessionName?: string;
  reviewPeriod: string;
  startDate: string; // YYYY-MM-DD
  endDate: string; // YYYY-MM-DD
  selfAssessmentDeadline?: string;
  supervisorReviewDeadline?: string;
  reviewType: ReviewType;
  frequency: ReviewFrequency;
  applicableStaffCategories: StaffCategoryScope[];
  applicableDepartmentIds: string[]; // empty = all
  applicableDesignationIds: string[]; // empty = all
  status: ReviewCycleStatus;
  scoringModel: ScoringModelType;
  allowSelfAssessment: boolean;
  requireHODReview: boolean;
  requireHRFinalApproval: boolean;
  totalEligibleStaff: number;
  completedReviewsCount: number;
  createdBy: string;
  createdByName: string;
  createdAt: string;
  updatedAt: string;
}

export interface CreateReviewCyclePayload {
  name: string;
  code: string;
  description: string;
  academicSessionId: string;
  reviewPeriod: string;
  startDate: string;
  endDate: string;
  selfAssessmentDeadline?: string;
  supervisorReviewDeadline?: string;
  reviewType: ReviewType;
  frequency: ReviewFrequency;
  applicableStaffCategories: StaffCategoryScope[];
  applicableDepartmentIds?: string[];
  applicableDesignationIds?: string[];
  scoringModel?: ScoringModelType;
  allowSelfAssessment?: boolean;
  requireHODReview?: boolean;
  requireHRFinalApproval?: boolean;
}

export interface UpdateReviewCyclePayload extends Partial<CreateReviewCyclePayload> {
  status?: ReviewCycleStatus;
}

// ----------------------------------------------------
// 2. Performance Criteria & KPIs
// ----------------------------------------------------

export interface PerformanceCriterion {
  id: string;
  name: string;
  code: string;
  description: string;
  category: CriterionCategory;
  weight: number; // e.g. 10 points
  maxScore: number; // e.g. 5
  scoringRubric?: Array<{
    score: number;
    label: string;
    description: string;
  }>;
  applicableStaffType: StaffCategoryScope;
  applicableDepartmentId?: string;
  applicableDesignationId?: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface CreatePerformanceCriterionPayload {
  name: string;
  code: string;
  description: string;
  category: CriterionCategory;
  weight: number;
  maxScore?: number;
  applicableStaffType: StaffCategoryScope;
  applicableDepartmentId?: string;
  applicableDesignationId?: string;
  scoringRubric?: Array<{
    score: number;
    label: string;
    description: string;
  }>;
}

export interface UpdatePerformanceCriterionPayload extends Partial<CreatePerformanceCriterionPayload> {
  isActive?: boolean;
}

// ----------------------------------------------------
// 3. Performance Goals & Progress
// ----------------------------------------------------

export interface GoalMilestone {
  id: string;
  title: string;
  dueDate: string;
  isCompleted: boolean;
  completedAt?: string;
}

export interface GoalProgressNote {
  id: string;
  note: string;
  updatedPercentage: number;
  authorId: string;
  authorName: string;
  createdAt: string;
}

export interface PerformanceGoal {
  id: string;
  staffId: string;
  staffName: string;
  staffEmployeeCode: string;
  departmentId: string;
  departmentName: string;
  reviewCycleId: string;
  reviewCycleName: string;
  title: string;
  description: string;
  category: GoalCategory;
  target: string;
  measurementMethod: string;
  weight: number; // e.g. 20
  startDate: string;
  dueDate: string;
  progressPercentage: number; // 0 - 100
  status: GoalStatus;
  reviewerId?: string;
  reviewerName?: string;
  milestones?: GoalMilestone[];
  progressNotes?: GoalProgressNote[];
  evidenceFiles?: Array<{
    id: string;
    name: string;
    url: string;
    sizeBytes: number;
    uploadedAt: string;
  }>;
  lastUpdatedDate: string;
  updatedBy: string;
  createdAt: string;
}

export interface CreatePerformanceGoalPayload {
  staffId: string;
  reviewCycleId: string;
  title: string;
  description: string;
  category: GoalCategory;
  target: string;
  measurementMethod: string;
  weight?: number;
  startDate: string;
  dueDate: string;
  reviewerId?: string;
  milestones?: Array<{ title: string; dueDate: string }>;
}

export interface UpdatePerformanceGoalPayload extends Partial<CreatePerformanceGoalPayload> {
  status?: GoalStatus;
}

export interface UpdateGoalProgressPayload {
  progressPercentage: number;
  status?: GoalStatus;
  note?: string;
  completedMilestoneIds?: string[];
}

// ----------------------------------------------------
// 4. Staff Performance Reviews
// ----------------------------------------------------

export interface ReviewCriterionScore {
  criterionId: string;
  criterionCode: string;
  criterionName: string;
  category: string;
  weight: number;
  maxScore: number;
  score: number; // e.g. 1 to 5
  comments?: string;
}

export interface ReviewGoalAssessment {
  goalId: string;
  goalTitle: string;
  weight: number;
  progressPercentage: number;
  achievedScore: number; // 1 to 5
  comments?: string;
}

export interface ReviewSelfAssessment {
  achievementSummary: string;
  goalProgressSummary: string;
  strengths: string;
  challenges: string;
  trainingNeeds: string;
  comments: string;
  selfRating: number; // 1 to 5
  submittedAt: string;
}

export interface ReviewSupervisorEvaluation {
  criteriaScores: ReviewCriterionScore[];
  goalAssessments: ReviewGoalAssessment[];
  strengths: string;
  areasForImprovement: string;
  developmentRecommendations: string;
  recommendedTraining: string[];
  calculatedScore: number; // 0-100 or weighted score
  supervisorRating: number; // 1 to 5
  generalComments: string;
  submittedAt: string;
}

export interface ReviewHREvaluation {
  hrComments: string;
  hrScoreOverride?: number;
  overrideReason?: string;
  overrideBy?: string;
  overrideByName?: string;
  overrideAt?: string;
  finalCalculatedScore: number;
  finalRatingBand: RatingBand;
  pipRecommended: boolean;
  reviewedAt: string;
}

export interface ReviewEmployeeAcknowledgement {
  isAcknowledged: boolean;
  acknowledgedAt?: string;
  comments?: string;
}

export interface ReviewSupportingData {
  attendancePercentage: number;
  lateArrivalsCount: number;
  approvedLeavesCount: number;
  workloadSummary: string;
  marksSubmissionComplianceRate?: number;
  documentsComplianceStatus: string;
}

export interface ReviewWorkflowHistoryEntry {
  stage: string;
  action: string;
  actorId: string;
  actorName: string;
  timestamp: string;
  comments?: string;
}

export interface StaffPerformanceReview {
  id: string;
  reviewCycleId: string;
  reviewCycleName: string;
  staffId: string;
  staffName: string;
  staffEmployeeCode: string;
  departmentId: string;
  departmentName: string;
  designationTitle: string;
  staffType: 'TEACHING' | 'NON_TEACHING' | 'ADMINISTRATIVE' | 'SUPPORT';
  reviewerId: string;
  reviewerName: string;
  hrReviewerId?: string;
  hrReviewerName?: string;
  reviewPeriod: string;
  academicSessionId: string;
  status: ReviewWorkflowStatus;
  currentStage: string;
  history: ReviewWorkflowHistoryEntry[];
  selfAssessment?: ReviewSelfAssessment;
  supervisorReview?: ReviewSupervisorEvaluation;
  hrReview?: ReviewHREvaluation;
  acknowledgement?: ReviewEmployeeAcknowledgement;
  supportingData?: ReviewSupportingData;
  createdAt: string;
  updatedAt: string;
}

export interface CreatePerformanceReviewPayload {
  reviewCycleId: string;
  staffId: string;
  reviewerId?: string;
}

export interface SubmitSelfAssessmentPayload {
  achievementSummary: string;
  goalProgressSummary: string;
  strengths: string;
  challenges: string;
  trainingNeeds: string;
  comments: string;
  selfRating: number;
}

export interface SubmitSupervisorReviewPayload {
  criteriaScores: Array<{
    criterionId: string;
    score: number;
    comments?: string;
  }>;
  goalAssessments?: Array<{
    goalId: string;
    achievedScore: number;
    comments?: string;
  }>;
  strengths: string;
  areasForImprovement: string;
  developmentRecommendations: string;
  recommendedTraining: string[];
  supervisorRating: number;
  generalComments: string;
}

export interface SubmitHRReviewPayload {
  hrComments: string;
  finalRatingBand?: RatingBand;
  pipRecommended?: boolean;
}

export interface OverrideRatingPayload {
  overrideScore: number;
  overrideRatingBand: RatingBand;
  reason: string;
}

export interface AcknowledgeReviewPayload {
  comments?: string;
}

export interface TransitionReviewWorkflowPayload {
  targetStatus: ReviewWorkflowStatus;
  comments?: string;
}

// ----------------------------------------------------
// 5. Performance Feedback
// ----------------------------------------------------

export interface PerformanceFeedbackItem {
  id: string;
  reviewId?: string;
  staffId: string;
  staffName: string;
  authorName?: string;
  authorRole?: string;
  isAnonymous?: boolean;
  rating?: number;
  comments?: string;
  givenBy?: string;
  givenByName?: string;
  givenByRole?: string;
  feedbackType: FeedbackType;
  strengths?: string;
  improvementAreas?: string;
  areasForImprovement?: string;
  recommendations?: string;
  trainingNeeds?: string;
  careerDevelopmentSuggestions?: string;
  generalComments?: string;
  isAcknowledged?: boolean;
  acknowledgedAt?: string;
  acknowledgementNote?: string;
  createdAt: string;
}

export type PerformanceFeedback = PerformanceFeedbackItem;

export interface CreatePerformanceFeedbackPayload {
  staffId: string;
  reviewId?: string;
  authorName?: string;
  authorRole?: string;
  isAnonymous?: boolean;
  rating?: number;
  comments?: string;
  feedbackType: FeedbackType;
  strengths?: string;
  improvementAreas?: string;
  areasForImprovement?: string;
  recommendations?: string;
  trainingNeeds?: string;
  careerDevelopmentSuggestions?: string;
  generalComments?: string;
}

// ----------------------------------------------------
// 6. Performance Improvement Plan (PIP)
// ----------------------------------------------------

export interface PIPRequiredAction {
  id: string;
  description: string;
  deadline: string;
  status: 'PENDING' | 'IN_PROGRESS' | 'COMPLETED' | 'UNMET';
  isCompleted?: boolean;
  verificationNotes?: string;
}

export interface PIPProgressNote {
  id: string;
  note: string;
  loggedAt: string;
  loggedBy: string;
  loggedByName: string;
}

export interface PerformanceImprovementPlan {
  id: string;
  staffId: string;
  staffName: string;
  staffEmployeeCode: string;
  departmentId: string;
  departmentName: string;
  designationTitle: string;
  reviewId?: string;
  reason: string;
  improvementAreas: string[];
  requiredActions: PIPRequiredAction[];
  targetDate: string;
  reviewDate: string;
  assignedSupervisorId: string;
  assignedSupervisorName: string;
  progressNotes: PIPProgressNote[];
  outcome: PIPOutcome;
  status: PIPStatus;
  createdBy: string;
  createdByName: string;
  createdAt: string;
  updatedAt: string;
  closedAt?: string;
}

export interface CreatePIPPayload {
  staffId: string;
  reviewId?: string;
  reason: string;
  improvementAreas: string[];
  requiredActions: Array<{
    description: string;
    deadline: string;
  }>;
  targetDate: string;
  reviewDate: string;
  assignedSupervisorId: string;
}

export interface UpdatePIPPayload {
  status?: PIPStatus;
  outcome?: PIPOutcome;
  reviewDate?: string;
  targetDate?: string;
}

export interface AddPIPProgressNotePayload {
  note: string;
}

export interface UpdatePIPActionPayload {
  status?: 'PENDING' | 'IN_PROGRESS' | 'COMPLETED' | 'UNMET';
  isCompleted?: boolean;
  verificationNotes?: string;
}

export interface ClosePIPPayload {
  outcome: PIPOutcome;
  finalNotes: string;
}

// ----------------------------------------------------
// 7. Performance Dashboard & Query Types
// ----------------------------------------------------

export interface PerformanceDashboardMetrics {
  activeReviewCycles: number;
  activeCyclesCount?: number;
  reviewsInProgress: number;
  pendingSupervisorReviews: number;
  pendingHRReviews: number;
  completedReviews: number;
  staffAwaitingAcknowledgement: number;
  averageRating: number;
  ratingDistribution: Record<string, number>;
  ratingBandDistribution?: Record<string, number>;
  goalsCompleted: number;
  goalsAtRisk: number;
  totalGoals: number;
  activeImprovementPlans: number;
  activePIPsCount?: number;
}

export interface PerformanceFilterQuery {
  search?: string;
  staffId?: string;
  departmentId?: string;
  designationId?: string;
  staffType?: string;
  reviewCycleId?: string;
  academicSessionId?: string;
  status?: string;
  ratingBand?: string;
  reviewerId?: string;
  page?: number;
  limit?: number;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
}

export interface PerformanceReportSummary {
  reviewCycle: PerformanceReviewCycle;
  totalStaff: number;
  totalReviews: number;
  completionRate: number;
  averageScore: number;
  ratingDistribution: Record<RatingBand, number>;
  departmentBreakdown: Array<{
    departmentId: string;
    departmentName: string;
    totalStaff: number;
    reviewedCount: number;
    averageScore: number;
    ratingBands: Record<RatingBand, number>;
  }>;
}
