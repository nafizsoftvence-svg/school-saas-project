/**
 * Sygmate School Management System
 * Part 12F — HR Reports & Analytics Types
 */

import { StaffCategoryScope } from './staff.types.js';
import { RatingBand, ReviewStage } from './staff-performance.types.js';

export interface HRReportFilterQuery {
  academicSessionId?: string;
  departmentId?: string;
  designationId?: string;
  staffType?: string; // 'teaching' | 'non_teaching' | 'administrative' | 'support' | 'ALL'
  employmentStatus?: string;
  startDate?: string;
  endDate?: string;
  staffId?: string;
  leaveTypeId?: string;
  jobOpeningId?: string;
  reviewCycleId?: string;
  search?: string;
}

export interface HRDashboardKPIs {
  totalStaff: number;
  activeStaff: number;
  inactiveStaff: number;
  teachingStaff: number;
  administrativeStaff: number;
  supportStaff: number;
  otherStaff: number;
  staffOnLeave: number;
  probationStaff: number;
  suspendedStaff: number;
  resignedStaff: number;
  terminatedStaff: number;
  retiredStaff: number;
  newHiresCurrentSession: number;
  openJobPositions: number;
  activeCandidates: number;
  pendingInterviews: number;
  pendingOnboarding: number;
  activePerformanceReviews: number;
  pendingPerformanceReviews: number;
  leaveApplicationsPending: number;
  todayAttendanceRate: number;
}

export interface DepartmentHeadcountItem {
  departmentId: string;
  departmentName: string;
  departmentCode: string;
  totalStaff: number;
  activeStaff: number;
  inactiveStaff: number;
  teachingStaff: number;
  nonTeachingStaff: number;
  onLeaveStaff: number;
  probationStaff: number;
  maleStaff: number;
  femaleStaff: number;
}

export interface DesignationHeadcountItem {
  designationId: string;
  title: string;
  code: string;
  departmentId?: string;
  departmentName?: string;
  staffCount: number;
  activeCount: number;
  inactiveCount: number;
}

export interface CategoryHeadcountItem {
  category: string;
  displayName: string;
  count: number;
  activeCount: number;
  percentage: number;
}

export interface EmploymentStatusCountItem {
  status: string;
  displayName: string;
  count: number;
  percentage: number;
}

export interface StaffHeadcountReport {
  summary: {
    totalStaff: number;
    activeStaff: number;
    inactiveStaff: number;
    teachingStaff: number;
    administrativeStaff: number;
    supportStaff: number;
    otherStaff: number;
  };
  departments: DepartmentHeadcountItem[];
  designations: DesignationHeadcountItem[];
  categories: CategoryHeadcountItem[];
  employmentStatuses: EmploymentStatusCountItem[];
}

export interface AttendanceStatusDistributionItem {
  status: string;
  label: string;
  count: number;
  percentage: number;
}

export interface DepartmentAttendanceSummaryItem {
  departmentId: string;
  departmentName: string;
  totalScheduled: number;
  presentCount: number;
  lateCount: number;
  halfDayCount: number;
  absentCount: number;
  leaveCount: number;
  attendancePercentage: number;
}

export interface StaffAttendanceReport {
  dateRange: {
    startDate: string;
    endDate: string;
  };
  totalWorkingDays: number;
  overallAttendanceRate: number;
  totalRecords: number;
  statusDistribution: AttendanceStatusDistributionItem[];
  departmentSummaries: DepartmentAttendanceSummaryItem[];
  lateArrivalSummary: {
    totalLateCount: number;
    mostFrequentLateStaff: Array<{ staffId: string; staffName: string; employeeCode: string; count: number; departmentName: string }>;
  };
  absenceSummary: {
    totalAbsenceCount: number;
    unexcusedAbsenceCount: number;
    mostFrequentAbsentStaff: Array<{ staffId: string; staffName: string; employeeCode: string; count: number; departmentName: string }>;
  };
  halfDaySummary: {
    totalHalfDays: number;
  };
  leaveVsAttendanceSummary: {
    totalWorkDaysCount: number;
    totalPresentDaysCount: number;
    totalLeaveDaysCount: number;
    totalAbsentDaysCount: number;
    leaveToWorkRatio: number;
  };
}

export interface LeaveStatusBreakdownItem {
  status: string;
  label: string;
  count: number;
  totalDays: number;
}

export interface LeaveTypeBreakdownItem {
  leaveTypeId: string;
  leaveTypeName: string;
  code: string;
  totalApplications: number;
  approvedDays: number;
  pendingDays: number;
  rejectedDays: number;
}

export interface DepartmentLeaveBreakdownItem {
  departmentId: string;
  departmentName: string;
  totalApplications: number;
  approvedDays: number;
  pendingDays: number;
}

export interface StaffLeaveReport {
  summary: {
    totalApplications: number;
    approvedApplications: number;
    rejectedApplications: number;
    pendingApplications: number;
    cancelledApplications: number;
    totalApprovedDays: number;
    totalPendingDays: number;
  };
  statusBreakdown: LeaveStatusBreakdownItem[];
  typeBreakdown: LeaveTypeBreakdownItem[];
  departmentBreakdown: DepartmentLeaveBreakdownItem[];
  monthlyTrend: Array<{ month: string; applications: number; approvedDays: number }>;
}

export interface LeaveBalanceUtilizationItem {
  staffId: string;
  staffName: string;
  employeeCode: string;
  departmentName: string;
  designationTitle: string;
  leaveTypeName: string;
  leaveTypeCode: string;
  entitledDays: number;
  carriedForwardDays: number;
  adjustedDays: number;
  totalAllocatedDays: number;
  usedDays: number;
  pendingDays: number;
  remainingDays: number;
  utilizationPercentage: number;
}

export interface LeaveBalanceUtilizationReport {
  overallUtilizationPercentage: number;
  totalEntitledDays: number;
  totalUsedDays: number;
  totalPendingDays: number;
  totalRemainingDays: number;
  departmentUtilization: Array<{ departmentId: string; departmentName: string; allocatedDays: number; usedDays: number; utilizationRate: number }>;
  typeUtilization: Array<{ leaveTypeId: string; leaveTypeName: string; allocatedDays: number; usedDays: number; utilizationRate: number }>;
  staffBalances: LeaveBalanceUtilizationItem[];
}

export interface RecruitmentFunnelStage {
  stage: string;
  label: string;
  count: number;
  conversionRateFromPrevious: number;
  conversionRateFromTotal: number;
}

export interface RecruitmentFunnelReport {
  summary: {
    totalPositions: number;
    publishedPositions: number;
    closedPositions: number;
    totalCandidates: number;
    totalApplications: number;
    hiredCandidates: number;
  };
  funnelStages: RecruitmentFunnelStage[];
  positionMetrics: Array<{
    jobOpeningId: string;
    title: string;
    departmentName: string;
    status: string;
    openingsCount: number;
    applicationsCount: number;
    interviewsCount: number;
    offersCount: number;
    hiredCount: number;
    timeToHireDays?: number;
  }>;
}

export interface RecruitmentPerformanceReport {
  hasEnoughData: boolean;
  applicationsPerPosition: number;
  shortlistRate: number; // %
  interviewRate: number; // %
  offerRate: number; // %
  offerAcceptanceRate: number; // %
  hiringConversionRate: number; // %
  averageProcessingTimeDays: number; // average days from application to offer/hire
}

export interface OnboardingReport {
  summary: {
    totalOnboarding: number;
    pendingOnboarding: number;
    inProgressOnboarding: number;
    completedOnboarding: number;
    delayedOnboarding: number;
    cancelledOnboarding: number;
  };
  tasksSummary: {
    totalTasks: number;
    completedTasks: number;
    pendingTasks: number;
    overdueTasks: number;
    overallCompletionRate: number;
  };
  departmentBreakdown: Array<{
    departmentId: string;
    departmentName: string;
    totalOnboarding: number;
    completedCount: number;
    inProgressCount: number;
    completionPercentage: number;
  }>;
  recentOnboardingList: Array<{
    id: string;
    staffId: string;
    staffName: string;
    employeeCode: string;
    departmentName: string;
    designationTitle: string;
    startDate: string;
    targetCompletionDate: string;
    status: string;
    completedTasksCount: number;
    totalTasksCount: number;
    progressPercentage: number;
  }>;
}

export interface PerformanceCompletionReport {
  summary: {
    totalCycles: number;
    activeCycleName?: string;
    totalReviews: number;
    completedReviews: number;
    inProgressReviews: number;
    completionRate: number;
    selfAssessmentCompletedCount: number;
    selfAssessmentCompletionRate: number;
    supervisorReviewCompletedCount: number;
    supervisorReviewCompletionRate: number;
    hrReviewCompletedCount: number;
    hrReviewCompletionRate: number;
    acknowledgementCount: number;
    acknowledgementRate: number;
  };
  ratingDistribution: Array<{
    band: RatingBand;
    label: string;
    count: number;
    percentage: number;
  }>;
  departmentPerformance: Array<{
    departmentId: string;
    departmentName: string;
    reviewsCount: number;
    completedCount: number;
    averageScore: number;
    ratingBand: RatingBand;
  }>;
}

export interface GoalAchievementReport {
  summary: {
    totalGoals: number;
    achievedGoals: number;
    partiallyAchievedGoals: number;
    inProgressGoals: number;
    notAchievedGoals: number;
    cancelledGoals: number;
    goalAchievementRate: number; // %
  };
  departmentGoals: Array<{
    departmentId: string;
    departmentName: string;
    totalGoals: number;
    achievedCount: number;
    achievementRate: number;
  }>;
}

export interface StaffTurnoverReport {
  hasHistoricalData: boolean;
  statusDistribution: Array<{
    status: string;
    label: string;
    count: number;
    percentage: number;
  }>;
  movementMetrics: {
    newHiresCount: number;
    probationCount: number;
    resignationsCount: number;
    terminationsCount: number;
    retirementsCount: number;
    netStaffChange: number;
    turnoverRate?: number; // % if historical baseline exists
  };
  monthlyMovement: Array<{
    month: string;
    joined: number;
    exited: number;
    net: number;
  }>;
  statusTransitionsHistory: Array<{
    id: string;
    staffId: string;
    staffName: string;
    employeeCode: string;
    previousStatus: string;
    newStatus: string;
    effectiveDate: string;
    reason: string;
    changedByUserName: string;
  }>;
}

export interface CrossSessionHRReportItem {
  sessionId: string;
  sessionName: string;
  isCurrent: boolean;
  totalStaff: number;
  newHires: number;
  staffDepartures: number;
  attendanceRate: number;
  leaveUtilizationRate: number;
  recruitmentApplications: number;
  hiredCount: number;
  onboardingCompletionRate: number;
  performanceCompletionRate: number;
}

export interface CrossSessionHRReport {
  sessions: CrossSessionHRReportItem[];
}

export interface HRDrilldownRecord {
  id: string;
  code: string;
  name: string;
  category: string;
  department: string;
  designation: string;
  status: string;
  date?: string;
  details?: string;
  secondaryInfo?: string;
}

export interface HRDrilldownResponse {
  metricKey: string;
  metricLabel: string;
  totalCount: number;
  records: HRDrilldownRecord[];
}

export interface HRExportAuditPayload {
  reportType: string;
  format: 'CSV' | 'EXCEL' | 'PDF' | 'PRINT';
  filtersApplied: Record<string, any>;
  recordCount: number;
}
