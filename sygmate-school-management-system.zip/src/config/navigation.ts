import {
  LayoutDashboard,
  Calendar,
  Settings,
  Users,
  ShieldAlert,
  BookOpen,
  GraduationCap,
  Clock,
  UserCircle,
  LogOut,
  Layers,
  Sparkles,
  Building,
  CheckSquare,
  BookCheck,
  FileSpreadsheet,
  FolderGit2,
  Megaphone,
  CalendarDays,
  Award,
  TrendingUp,
  Bell,
  CreditCard,
  Receipt,
  FileText,
  BarChart3,
  Coins,
  Percent,
  AlertCircle,
  UserCheck,
  CalendarCheck,
  ArrowRightLeft,
  UserPlus,
  Mail,
  Briefcase,
  Building2,
  Package,
  FolderLock,
  ShieldCheck,
  Boxes,
  Truck,
  ShoppingBag,
  Send,
  Flag,
  Sun,
  PieChart,
  DollarSign,
  AlertTriangle,
  HelpCircle,
  Shield,
  Phone,
  Globe
} from 'lucide-react';
import { UserRole } from '../types/index.js';

export interface NavSubItem {
  id: string; // The subtab key
  label: string;
  icon?: any;
}

export interface NavItem {
  id: string; // The view identifier
  label: string;
  icon: any;
  defaultSubTab?: string;
  children?: NavSubItem[];
}

/**
 * Super Admin Navigation Model
 * Contains Main Tabs and their authoritative nested subtabs
 */
export const superAdminNav: NavItem[] = [
  { id: 'admin-dashboard', label: 'Architecture Overview', icon: LayoutDashboard },
  { id: 'platform-schools', label: 'Platform Schools & Tenants', icon: Globe },

  {
    id: 'admin-front-office',
    label: 'Front Office & Visitors',
    icon: Building2,
    defaultSubTab: 'overview',
    children: [
      { id: 'overview', label: 'Command Center', icon: Sparkles },
      { id: 'visitors', label: 'Visitor Register', icon: Shield },
      { id: 'enquiries', label: 'Admission Enquiries', icon: HelpCircle },
      { id: 'calls', label: 'Phone Call Logs', icon: Phone },
      { id: 'complaints', label: 'Grievance Desk', icon: AlertCircle },
      { id: 'reports', label: 'Official Ledgers', icon: FileText }
    ]
  },

  {
    id: 'admin-inventory',
    label: 'Inventory & Assets',
    icon: Package,
    defaultSubTab: 'overview',
    children: [
      { id: 'overview', label: 'Command Center', icon: Sparkles },
      { id: 'items', label: 'Item Catalog', icon: Package },
      { id: 'stock', label: 'Stock Control', icon: Boxes },
      { id: 'issues', label: 'Issue & Return', icon: ArrowRightLeft },
      { id: 'assets', label: 'Asset Register', icon: ShieldCheck },
      { id: 'departments', label: 'Department Allocation', icon: Building },
      { id: 'procurement', label: 'Procurement & Orders', icon: ShoppingBag },
      { id: 'suppliers', label: 'Vendors & Suppliers', icon: Truck },
      { id: 'reports', label: 'Reports & Analytics', icon: BarChart3 },
      { id: 'setup', label: 'Foundation Setup', icon: Layers }
    ]
  },

  {
    id: 'admin-teacher-attendance',
    label: 'Teacher Attendance',
    icon: UserCheck,
    defaultSubTab: 'daily',
    children: [
      { id: 'daily', label: 'Daily Roster & Marking', icon: CalendarCheck },
      { id: 'monthly', label: 'Monthly Matrix View', icon: CalendarDays },
      { id: 'history', label: 'Attendance History & Logs', icon: Clock },
      { id: 'leave_management', label: 'Leave Applications & Policies', icon: FileText }
    ]
  },

  {
    id: 'admin-staff',
    label: 'Staff Attendance & HR',
    icon: CalendarCheck,
    defaultSubTab: 'directory',
    children: [
      { id: 'directory', label: 'Staff Directory', icon: Users },
      { id: 'recruitment', label: 'Recruitment & Hiring', icon: UserPlus },
      { id: 'onboarding', label: 'Staff Onboarding', icon: Sparkles },
      { id: 'attendance', label: 'Staff Attendance', icon: CalendarCheck },
      { id: 'schedules', label: 'Work Schedules', icon: Clock },
      { id: 'leaves', label: 'Staff Leaves', icon: FileText },
      { id: 'performance', label: 'Performance & Appraisals', icon: TrendingUp },
      { id: 'departments', label: 'Departments & Units', icon: Building2 },
      { id: 'designations', label: 'Job Titles & Designations', icon: Briefcase },
      { id: 'analytics', label: 'HR Demographics & Analytics', icon: BarChart3 }
    ]
  },

  {
    id: 'admin-student-attendance',
    label: 'Student Attendance',
    icon: CheckSquare,
    defaultSubTab: 'mark',
    children: [
      { id: 'mark', label: 'Take Attendance', icon: CheckSquare },
      { id: 'history', label: 'Attendance History', icon: Clock },
      { id: 'analytics', label: 'Cohort Analytics', icon: BarChart3 },
      { id: 'student_leaves', label: 'Student Leave Requests', icon: FileText }
    ]
  },

  {
    id: 'admin-attendance-reports',
    label: 'Reports & Analytics',
    icon: BarChart3,
    defaultSubTab: 'DASHBOARD',
    children: [
      { id: 'DASHBOARD', label: 'Executive Analytics', icon: BarChart3 },
      { id: 'DAILY', label: 'Daily Register Report', icon: CalendarDays },
      { id: 'STUDENTS', label: 'Student-wise Report', icon: Users },
      { id: 'CLASSES', label: 'Class & Section Breakdown', icon: Layers },
      { id: 'DEFAULTERS', label: 'Defaulters (<75%)', icon: AlertCircle },
      { id: 'TEACHERS', label: 'Faculty Attendance', icon: UserCheck },
      { id: 'LEAVES', label: 'Leave Impact Analytics', icon: TrendingUp },
      { id: 'RAW_LOGS', label: 'Raw Audit Logs', icon: Clock }
    ]
  },

  {
    id: 'admin-academic-calendar',
    label: 'Academic Calendar',
    icon: CalendarDays,
    defaultSubTab: 'calendar',
    children: [
      { id: 'calendar', label: 'Interactive Calendar Grid', icon: CalendarDays },
      { id: 'holidays', label: 'Holidays Roster', icon: Flag },
      { id: 'special-days', label: 'Special Working Days', icon: Sun },
      { id: 'events', label: 'School Calendar Events', icon: Sparkles }
    ]
  },

  {
    id: 'admin-attendance-settings',
    label: 'Attendance Settings',
    icon: CheckSquare,
    defaultSubTab: 'schedule',
    children: [
      { id: 'schedule', label: 'Working & Weekend Days', icon: Calendar },
      { id: 'student', label: 'Student Attendance Rules', icon: Users },
      { id: 'teacher', label: 'Teacher Attendance Rules', icon: UserCheck },
      { id: 'statuses', label: 'Attendance Statuses', icon: CheckSquare },
      { id: 'rules', label: 'Holidays & Leave Policies', icon: Shield },
      { id: 'notifications', label: 'Alert Policies & Channels', icon: Bell },
      { id: 'templates', label: 'Notification Templates', icon: FileText },
      { id: 'notification-logs', label: 'Alert History & Queue', icon: Clock }
    ]
  },

  {
    id: 'admin-financial-reports',
    label: 'Financial Reports',
    icon: BarChart3,
    defaultSubTab: 'DASHBOARD',
    children: [
      { id: 'DASHBOARD', label: 'Financial Overview', icon: PieChart },
      { id: 'COLLECTIONS', label: 'Collection Report', icon: DollarSign },
      { id: 'DUE_OVERDUE', label: 'Due & Overdue Report', icon: AlertTriangle },
      { id: 'FEE_SUMMARY', label: 'Fee Head Summary', icon: Layers },
      { id: 'PAYMENT_METHODS', label: 'Payment Channels', icon: CreditCard },
      { id: 'RECEIPTS', label: 'Receipts Archive', icon: Receipt },
      { id: 'STATEMENTS', label: 'Student Statement Generator', icon: FileText }
    ]
  },

  {
    id: 'admin-fee-collection',
    label: 'Fee Collection',
    icon: Receipt,
    defaultSubTab: 'TERMINAL',
    children: [
      { id: 'TERMINAL', label: 'Fee Collection Terminal', icon: Receipt },
      { id: 'TRANSACTIONS', label: 'Payment Transactions Ledger', icon: FileSpreadsheet },
      { id: 'METHODS', label: 'Payment Methods', icon: CreditCard }
    ]
  },

  { id: 'admin-student-fees', label: 'Student Fees', icon: CreditCard },

  {
    id: 'admin-due-management',
    label: 'Due Management',
    icon: AlertCircle,
    defaultSubTab: 'students',
    children: [
      { id: 'students', label: 'Student-Wise Due Ledger', icon: Users },
      { id: 'classes', label: 'Class-Wise Breakdown', icon: Layers },
      { id: 'feetypes', label: 'Fee Type Breakdown', icon: Coins },
      { id: 'reminders', label: 'Reminder Audit Logs', icon: Clock }
    ]
  },

  {
    id: 'admin-fee-adjustments',
    label: 'Discounts & Waivers',
    icon: Percent,
    defaultSubTab: 'DISCOUNTS',
    children: [
      { id: 'DISCOUNTS', label: 'Discounts Hub', icon: Percent },
      { id: 'WAIVERS', label: 'Fee Waivers Desk', icon: AlertTriangle },
      { id: 'SCHOLARSHIPS', label: 'Scholarships & Grants', icon: Award },
      { id: 'FINES', label: 'Late Fines & Penalties', icon: Clock },
      { id: 'AUDIT_TRAIL', label: 'Adjustment Audit Log', icon: FileSpreadsheet }
    ]
  },

  {
    id: 'admin-fee-structures',
    label: 'Fee Structures',
    icon: Coins,
    defaultSubTab: 'structures',
    children: [
      { id: 'structures', label: 'Fee Structures', icon: FileSpreadsheet },
      { id: 'types', label: 'Fee Types Configuration', icon: Coins },
      { id: 'analytics', label: 'Finance Analytics', icon: BarChart3 }
    ]
  },

  {
    id: 'admin-examinations',
    label: 'Examination Management',
    icon: CalendarDays,
    defaultSubTab: 'overview',
    children: [
      { id: 'overview', label: 'Examinations & Cycles', icon: CalendarDays },
      { id: 'schedules', label: 'Master Schedules & Conflict Engine', icon: Clock },
      { id: 'marks', label: 'Marks Submissions & Review', icon: FileSpreadsheet },
      { id: 'grading', label: 'Grading System', icon: Award },
      { id: 'calculation', label: 'Grade & Result Calculation', icon: TrendingUp },
      { id: 'review', label: 'Result Review & Publishing', icon: ShieldCheck },
      { id: 'report-cards', label: 'Report Cards & Transcripts', icon: FileText },
      { id: 'merit', label: 'Merit & Position Ranking', icon: Award },
      { id: 'reports', label: 'Academic Reports & Analytics', icon: BarChart3 }
    ]
  },

  {
    id: 'admin-academic',
    label: 'Academic Structure',
    icon: Calendar,
    defaultSubTab: 'classes',
    children: [
      { id: 'classes', label: 'Classes & Grades', icon: GraduationCap },
      { id: 'sections', label: 'Classroom Sections', icon: Layers },
      { id: 'sessions', label: 'Academic Sessions', icon: Calendar },
      { id: 'subjects', label: 'Curriculum Subjects', icon: BookOpen },
      { id: 'departments', label: 'Departments', icon: Building2 }
    ]
  },

  {
    id: 'admin-admissions',
    label: 'Admissions & Enrollment',
    icon: UserPlus,
    defaultSubTab: 'applications',
    children: [
      { id: 'applications', label: 'Admission Applications', icon: FileText },
      { id: 'enquiries', label: 'Front Office Enquiries', icon: HelpCircle },
      { id: 'enrollments', label: 'Academic Student Enrollments', icon: GraduationCap },
      { id: 'settings', label: 'Admission Settings & Numbering', icon: Settings }
    ]
  },

  {
    id: 'admin-promotions-transfers',
    label: 'Promotion & Transfers',
    icon: ArrowRightLeft,
    defaultSubTab: 'promotions',
    children: [
      { id: 'promotions', label: 'Promotion Engine & Records', icon: ArrowRightLeft },
      { id: 'transfers', label: 'Transfers & Transfer Certificates (TC)', icon: FileText },
      { id: 'status', label: 'Status Lifecycle Manager', icon: ShieldCheck },
      { id: 'enrollments', label: 'Academic Enrollments Roster', icon: Users },
      { id: 'batches', label: 'Batch History & Rollbacks', icon: Clock }
    ]
  },

  {
    id: 'admin-student-reports',
    label: 'Student Reports & Search',
    icon: FileSpreadsheet,
    defaultSubTab: 'directory',
    children: [
      { id: 'directory', label: 'Roster & Directory', icon: Users },
      { id: 'reports', label: 'Analytical Reports', icon: BarChart3 }
    ]
  },

  {
    id: 'admin-users',
    label: 'User Directory',
    icon: Users,
    defaultSubTab: 'teachers',
    children: [
      { id: 'teachers', label: 'Faculty & Teachers', icon: UserCheck },
      { id: 'students', label: 'Enrolled Students', icon: GraduationCap },
      { id: 'guardians', label: 'Parents & Guardians', icon: Users },
      { id: 'admins', label: 'System Administrators', icon: ShieldAlert }
    ]
  },

  {
    id: 'admin-documents',
    label: 'Certificates & Documents',
    icon: FolderLock,
    defaultSubTab: 'certificates',
    children: [
      { id: 'certificates', label: 'Issued Certificates', icon: Award },
      { id: 'cert-types', label: 'Certificate Types', icon: FileText },
      { id: 'templates', label: 'Certificate Templates', icon: Sparkles },
      { id: 'all', label: 'All Vault Docs', icon: FolderLock },
      { id: 'students', label: 'Student Docs', icon: GraduationCap },
      { id: 'staff', label: 'Staff & Teachers', icon: Briefcase },
      { id: 'guardians', label: 'Guardian Docs', icon: Users },
      { id: 'school', label: 'School & Institutional', icon: Building2 },
      { id: 'requirements', label: 'Doc Requirements', icon: CheckSquare },
      { id: 'expiring', label: 'Expiring & Overdue', icon: AlertTriangle },
      { id: 'types', label: 'Doc Types', icon: Layers },
      { id: 'reports', label: 'Reports & Analytics', icon: BarChart3 }
    ]
  },

  { id: 'verify-certificate', label: 'Verify Credential (QR)', icon: ShieldCheck },

  {
    id: 'admin-id-cards',
    label: 'ID Cards & Badges',
    icon: CreditCard,
    defaultSubTab: 'id-cards',
    children: [
      { id: 'id-cards', label: 'ID Card Command Center', icon: CreditCard },
      { id: 'documents', label: 'Document Verification Queue', icon: FolderLock },
      { id: 'compliance', label: 'Mandatory Compliance Audit', icon: ShieldCheck },
      { id: 'templates', label: 'Template Studio & Layouts', icon: Sparkles }
    ]
  },

  { id: 'admin-inbox', label: 'Messaging & Inbox', icon: Mail },

  {
    id: 'admin-communication',
    label: 'Communication & Alerts',
    icon: Bell,
    defaultSubTab: 'overview',
    children: [
      { id: 'overview', label: 'Overview & Status', icon: Sparkles },
      { id: 'inbox', label: 'Messages & Inbox', icon: Mail },
      { id: 'announcements', label: 'Announcements & Circulars', icon: Megaphone },
      { id: 'campaigns', label: 'Bulk Campaigns', icon: Send },
      { id: 'analytics', label: 'Analytics & Delivery Reports', icon: BarChart3 },
      { id: 'channels', label: 'Gateways & Providers', icon: Layers },
      { id: 'templates', label: 'Notification Templates', icon: FileText },
      { id: 'logs', label: 'Delivery Logs', icon: Clock },
      { id: 'policy', label: 'Mandatory Policies', icon: ShieldAlert }
    ]
  },

  { id: 'admin-rbac', label: 'Role Permissions', icon: ShieldAlert },
  { id: 'admin-audit', label: 'Audit Trail Logs', icon: Clock },

  {
    id: 'admin-settings',
    label: 'School Settings',
    icon: Settings,
    defaultSubTab: 'profile',
    children: [
      { id: 'profile', label: 'School Profile', icon: Building2 },
      { id: 'contact', label: 'Contact & Location', icon: Building },
      { id: 'regional', label: 'Regional & Localization', icon: Calendar },
      { id: 'branding', label: 'Branding & Theme', icon: Sparkles }
    ]
  },

  { id: 'admin-ui-components', label: 'UI Component Library', icon: Sparkles }
];

/**
 * Teacher Navigation Model
 */
export const teacherNav: NavItem[] = [
  { id: 'teacher-dashboard', label: 'Teacher Dashboard', icon: LayoutDashboard },
  { id: 'teacher-inbox', label: 'Messages & Parent Chat', icon: Mail },

  {
    id: 'teacher-my-attendance',
    label: 'My Attendance',
    icon: CalendarCheck,
    defaultSubTab: 'attendance',
    children: [
      { id: 'attendance', label: 'My Attendance & Clock In', icon: CalendarCheck },
      { id: 'leaves', label: 'Leave Applications & Quotas', icon: FileText }
    ]
  },

  {
    id: 'teacher-attendance',
    label: 'Student Attendance',
    icon: CheckSquare,
    defaultSubTab: 'mark',
    children: [
      { id: 'mark', label: 'Take Attendance', icon: CheckSquare },
      { id: 'history', label: 'Attendance History', icon: Clock },
      { id: 'analytics', label: 'Cohort Analytics', icon: BarChart3 },
      { id: 'student_leaves', label: 'Student Leave Requests', icon: FileText }
    ]
  },

  { id: 'teacher-examinations', label: 'Examinations / Marks', icon: CalendarDays },

  {
    id: 'teacher-classes',
    label: 'My Classes & Sections',
    icon: GraduationCap,
    defaultSubTab: 'classes',
    children: [
      { id: 'classes', label: 'My Classes', icon: GraduationCap },
      { id: 'sections', label: 'My Sections', icon: Layers }
    ]
  },

  { id: 'teacher-students', label: 'My Students', icon: Users },

  {
    id: 'admin-student-reports',
    label: 'Student Directory & Reports',
    icon: FileSpreadsheet,
    defaultSubTab: 'directory',
    children: [
      { id: 'directory', label: 'Roster & Directory', icon: Users },
      { id: 'reports', label: 'Analytical Reports', icon: BarChart3 }
    ]
  },

  { id: 'teacher-homework', label: 'Homework', icon: BookCheck },
  { id: 'teacher-assignments', label: 'Assignments', icon: FileSpreadsheet },
  { id: 'teacher-materials', label: 'Study Materials', icon: FolderGit2 },
  { id: 'teacher-announcements', label: 'Announcements', icon: Megaphone },
  { id: 'teacher-subjects', label: 'My Subjects', icon: BookOpen },

  {
    id: 'admin-documents',
    label: 'Document Vault',
    icon: FolderLock,
    defaultSubTab: 'certificates',
    children: [
      { id: 'certificates', label: 'Issued Certificates', icon: Award },
      { id: 'cert-types', label: 'Certificate Types', icon: FileText },
      { id: 'templates', label: 'Certificate Templates', icon: Sparkles },
      { id: 'all', label: 'All Vault Docs', icon: FolderLock },
      { id: 'students', label: 'Student Docs', icon: GraduationCap },
      { id: 'staff', label: 'Staff & Teachers', icon: Briefcase },
      { id: 'requirements', label: 'Doc Requirements', icon: CheckSquare },
      { id: 'expiring', label: 'Expiring & Overdue', icon: AlertTriangle }
    ]
  },

  { id: 'verify-certificate', label: 'Verify Credential (QR)', icon: ShieldCheck },
  { id: 'teacher-profile', label: 'Teacher Profile', icon: UserCircle }
];

/**
 * Student Navigation Model
 */
export const studentNav: NavItem[] = [
  { id: 'student-dashboard', label: 'Student Dashboard', icon: LayoutDashboard },
  { id: 'student-inbox', label: 'Teacher Messages', icon: Mail },
  { id: 'student-fees', label: 'Fees & Invoices', icon: CreditCard },
  { id: 'student-class', label: 'My Class', icon: GraduationCap },

  { id: 'student-subjects', label: 'My Subjects', icon: BookOpen },

  { id: 'student-homework', label: 'Homework', icon: BookCheck },
  { id: 'student-assignments', label: 'Assignments', icon: FileSpreadsheet },
  { id: 'student-materials', label: 'Study Materials', icon: FolderGit2 },
  { id: 'student-announcements', label: 'Announcements', icon: Megaphone },
  { id: 'student-examinations', label: 'Examinations', icon: CalendarDays },
  { id: 'student-results', label: 'Results & Marks', icon: Award },
  { id: 'student-progress', label: 'Academic Progress', icon: TrendingUp },

  {
    id: 'student-attendance',
    label: 'Attendance & Leave',
    icon: CheckSquare,
    defaultSubTab: 'calendar',
    children: [
      { id: 'calendar', label: 'Monthly Calendar', icon: CalendarDays },
      { id: 'records', label: 'Attendance Records Log', icon: FileText },
      { id: 'leaves', label: 'My Leave Applications', icon: ShieldCheck }
    ]
  },

  { id: 'student-academic-info', label: 'Academic Information', icon: Layers },
  { id: 'student-routine', label: 'Class Timetable', icon: Clock },
  { id: 'student-id-card', label: 'Digital ID Pass', icon: CreditCard },
  { id: 'student-certificates', label: 'My Certificates', icon: Award },
  { id: 'student-profile', label: 'Student Bio & Profile', icon: UserCircle }
];

/**
 * Guardian / Parent Navigation Model
 */
export const guardianNav: NavItem[] = [
  { id: 'guardian-dashboard', label: 'Guardian Dashboard', icon: LayoutDashboard },
  { id: 'guardian-inbox', label: 'Teacher Messaging & Inbox', icon: Mail },
  { id: 'guardian-id-cards', label: 'Child ID Badges', icon: CreditCard },
  { id: 'guardian-certificates', label: 'Child Certificates', icon: Award },
  { id: 'guardian-fees', label: 'Fees & Invoices', icon: CreditCard },
  { id: 'guardian-payments', label: 'Payment History', icon: Receipt },

  {
    id: 'guardian-academic-overview',
    label: 'Academic Overview',
    icon: BookOpen,
    defaultSubTab: 'subjects',
    children: [
      { id: 'subjects', label: 'My Subjects', icon: BookOpen },
      { id: 'teachers', label: 'Assigned Teachers & Faculty', icon: Users },
      { id: 'summary', label: 'Academic Summary & Activities', icon: TrendingUp }
    ]
  },

  { id: 'guardian-examinations', label: 'Examinations', icon: CalendarDays },
  { id: 'guardian-results', label: 'Results & Marks', icon: Award },
  { id: 'guardian-progress', label: 'Academic Progress', icon: TrendingUp },
  { id: 'guardian-homework', label: 'Child Homework', icon: BookCheck },
  { id: 'guardian-assignments', label: 'Child Assignments', icon: FileSpreadsheet },
  { id: 'guardian-materials', label: 'Study Materials', icon: FolderGit2 },
  { id: 'guardian-announcements', label: 'Class Announcements', icon: Megaphone },

  {
    id: 'guardian-attendance',
    label: 'Attendance & Leave',
    icon: CheckSquare,
    defaultSubTab: 'calendar',
    children: [
      { id: 'calendar', label: 'Attendance Calendar', icon: CalendarDays },
      { id: 'records', label: 'Detailed Logs', icon: FileText },
      { id: 'leave-status', label: 'Leave Requests', icon: Send }
    ]
  },

  { id: 'guardian-children', label: 'Linked Children', icon: GraduationCap },
  { id: 'guardian-notifications', label: 'School Notices', icon: Bell },
  { id: 'guardian-profile', label: 'Guardian Profile', icon: UserCircle }
];

export const schoolAdminNav: NavItem[] = superAdminNav.filter((item) => item.id !== 'platform-schools');

export const getNavItemsForRole = (role?: UserRole): NavItem[] => {
  switch (role) {
    case 'SUPER_ADMIN':
      return superAdminNav;
    case 'ADMIN':
      return schoolAdminNav;
    case 'TEACHER':
      return teacherNav;
    case 'GUARDIAN':
      return guardianNav;
    case 'STUDENT':
    default:
      return studentNav;
  }
};

export const findNavItem = (role: UserRole | undefined, viewId: string): NavItem | undefined => {
  const items = getNavItemsForRole(role);
  return items.find((item) => item.id === viewId);
};
