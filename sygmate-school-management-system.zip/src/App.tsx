import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext.js';
import { ToastProvider } from './context/ToastContext.js';
import { SettingsProvider } from './context/SettingsContext.js';
import { ThemeProvider } from './context/ThemeContext.js';
import { PortalLayout } from './components/layout/PortalLayout.js';
import { LoginPage } from './pages/auth/LoginPage.js';
import { ParentActivationPage } from './pages/auth/ParentActivationPage.js';
import { ForgotPasswordPage } from './pages/auth/ForgotPasswordPage.js';
import { ResetPasswordPage } from './pages/auth/ResetPasswordPage.js';
import { AdminDashboard } from './pages/admin/AdminDashboard.js';
import { AdminExaminationsPage } from './pages/admin/AdminExaminationsPage.js';
import { AcademicStructurePage } from './pages/admin/AcademicStructurePage.js';
import { UserDirectoryPage } from './pages/admin/UserDirectoryPage.js';
import { AuditTrailPage } from './pages/admin/AuditTrailPage.js';
import { SchoolSettingsPage } from './pages/admin/SchoolSettingsPage.js';
import { PlatformSchoolsPage } from './pages/admin/PlatformSchoolsPage.js';
import { AdminUIComponentsPage } from './pages/admin/AdminUIComponentsPage.js';
import { AttendanceSettingsPage } from './pages/admin/attendance/AttendanceSettingsPage.js';
import { TeacherAttendanceManagementPage } from './pages/admin/attendance/TeacherAttendanceManagementPage.js';
import { AdminAttendanceReportsPage } from './pages/admin/attendance/AdminAttendanceReportsPage.js';
import { AcademicCalendarPage } from './pages/admin/calendar/AcademicCalendarPage.js';
import { RbacPermissionsPage } from './pages/admin/RbacPermissionsPage.js';
import { AdminFeeStructurePage } from './pages/admin/AdminFeeStructurePage.js';
import { AdminStudentFeesPage } from './pages/admin/AdminStudentFeesPage.js';
import { AdminFeeCollectionPage } from './pages/admin/AdminFeeCollectionPage.js';
import { AdminFeeAdjustmentsPage } from './pages/admin/AdminFeeAdjustmentsPage.js';
import { AdminDueManagementPage } from './pages/admin/AdminDueManagementPage.js';
import { AdminFinancialReportsPage } from './pages/admin/AdminFinancialReportsPage.js';
import { AdminFrontOfficePage } from './pages/admin/AdminFrontOfficePage.js';
import { AdminInventoryPage } from './pages/admin/AdminInventoryPage.js';
import { AdminIDCardAndDocumentsPage } from './pages/admin/AdminIDCardAndDocumentsPage.js';
import { AdminDocumentsPage } from './pages/admin/AdminDocumentsPage.js';
import { AdminAdmissionsPage } from './pages/admin/AdminAdmissionsPage.js';
import { AdminStudentPromotionTransferPage } from './pages/admin/AdminStudentPromotionTransferPage.js';
import { AdminStudentReportsPage } from './pages/admin/AdminStudentReportsPage.js';
import { StaffManagementPage } from './pages/admin/staff/StaffManagementPage.js';
import { CommunicationManagementPage } from './pages/admin/communication/CommunicationManagementPage.js';
import { InboxPage } from './components/inbox/InboxPage.js';
import { StudentDigitalIDCardPage } from './pages/student/StudentDigitalIDCardPage.js';
import { StudentCertificatesPage } from './pages/student/StudentCertificatesPage.js';
import { GuardianChildIDCardsPage } from './pages/guardian/GuardianChildIDCardsPage.js';
import { GuardianCertificatesPage } from './pages/guardian/GuardianCertificatesPage.js';
import { PublicCertificateVerificationPage } from './pages/public/PublicCertificateVerificationPage.js';
import { TeacherDashboard } from './pages/teacher/TeacherDashboard.js';
import { TeacherExaminationsPage } from './pages/teacher/TeacherExaminationsPage.js';
import { TeacherClassesPage } from './pages/teacher/TeacherClassesPage.js';
import { TeacherStudentsPage } from './pages/teacher/TeacherStudentsPage.js';
import { TeacherAttendancePage } from './pages/teacher/TeacherAttendancePage.js';
import { TeacherMyAttendancePage } from './pages/teacher/TeacherMyAttendancePage.js';
import { TeacherSubjectsPage } from './pages/teacher/TeacherSubjectsPage.js';
import { TeacherProfilePage } from './pages/teacher/TeacherProfilePage.js';
import { TeacherHomeworkPage } from './pages/teacher/TeacherHomeworkPage.js';
import { TeacherAssignmentsPage } from './pages/teacher/TeacherAssignmentsPage.js';
import { TeacherMaterialsPage } from './pages/teacher/TeacherMaterialsPage.js';
import { TeacherAnnouncementsPage } from './pages/teacher/TeacherAnnouncementsPage.js';
import { StudentDashboard } from './pages/student/StudentDashboard.js';
import { StudentFeesPage } from './pages/student/StudentFeesPage.js';
import { StudentClassPage } from './pages/student/StudentClassPage.js';
import { StudentSubjectsPage } from './pages/student/StudentSubjectsPage.js';
import { StudentAttendancePage } from './pages/student/StudentAttendancePage.js';
import { StudentAcademicInfoPage } from './pages/student/StudentAcademicInfoPage.js';
import { StudentRoutinePage } from './pages/student/StudentRoutinePage.js';
import { StudentProfilePage } from './pages/student/StudentProfilePage.js';
import { StudentHomeworkPage } from './pages/student/StudentHomeworkPage.js';
import { StudentAssignmentsPage } from './pages/student/StudentAssignmentsPage.js';
import { StudentMaterialsPage } from './pages/student/StudentMaterialsPage.js';
import { StudentAnnouncementsPage } from './pages/student/StudentAnnouncementsPage.js';
import { StudentExaminationsPage } from './pages/student/StudentExaminationsPage.js';
import { StudentResultsPage } from './pages/student/StudentResultsPage.js';
import { StudentProgressPage } from './pages/student/StudentProgressPage.js';
import { GuardianExaminationsPage } from './pages/guardian/GuardianExaminationsPage.js';
import { GuardianResultsPage } from './pages/guardian/GuardianResultsPage.js';
import { GuardianProgressPage } from './pages/guardian/GuardianProgressPage.js';
import { GuardianDashboardPage } from './pages/guardian/GuardianDashboardPage.js';
import { GuardianFeesPage } from './pages/guardian/GuardianFeesPage.js';
import { GuardianPaymentHistoryPage } from './pages/guardian/GuardianPaymentHistoryPage.js';
import { GuardianChildAcademicOverviewPage } from './pages/guardian/GuardianChildAcademicOverviewPage.js';
import { GuardianAttendancePage } from './pages/guardian/GuardianAttendancePage.js';
import { GuardianHomeworkPage } from './pages/guardian/GuardianHomeworkPage.js';
import { GuardianAssignmentsPage } from './pages/guardian/GuardianAssignmentsPage.js';
import { GuardianMaterialsPage } from './pages/guardian/GuardianMaterialsPage.js';
import { GuardianAnnouncementsPage } from './pages/guardian/GuardianAnnouncementsPage.js';
import { GuardianChildrenPage } from './pages/guardian/GuardianChildrenPage.js';
import { GuardianNotificationsPage } from './pages/guardian/GuardianNotificationsPage.js';
import { GuardianProfilePage } from './pages/guardian/GuardianProfilePage.js';
import { ProfilePage } from './pages/common/ProfilePage.js';
import { RoleRoute } from './components/auth/RoleRoute.js';
import { LoadingSpinner } from './components/ui/LoadingSpinner.js';
import { getNavItemsForRole } from './config/navigation.js';
import { BreadcrumbItem } from './components/layout/Breadcrumb.js';

const MainAppContent: React.FC = () => {
  const { isAuthenticated, isInitializing, role } = useAuth();
  const [currentView, setCurrentView] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      const search = new URLSearchParams(window.location.search);
      const v = search.get('view');
      if (v && !['login', 'activate', 'forgot-password', 'reset-password', 'verify-certificate'].includes(v)) {
        return v;
      }
      try {
        const saved = sessionStorage.getItem('sygmate_current_view');
        if (saved) return saved;
      } catch (e) {}
    }
    return 'default';
  });

  const [currentSubTab, setCurrentSubTab] = useState<string | undefined>(() => {
    if (typeof window !== 'undefined') {
      const search = new URLSearchParams(window.location.search);
      const st = search.get('subTab') || search.get('subtab');
      if (st) return st;
      try {
        const saved = sessionStorage.getItem('sygmate_current_subtab');
        if (saved) return saved;
      } catch (e) {}
    }
    return undefined;
  });

  const [authView, setAuthView] = useState<'login' | 'activate' | 'forgot-password' | 'reset-password' | 'verify-certificate'>('login');
  const [activationToken, setActivationToken] = useState<string>('');
  const [resetToken, setResetToken] = useState<string>('');
  const [loginPrefill, setLoginPrefill] = useState<string>('');

  const handleNavigate = (view: string, subTab?: string) => {
    setCurrentView(view);
    setCurrentSubTab(subTab);

    if (typeof window !== 'undefined') {
      try {
        const url = new URL(window.location.href);
        if (view && view !== 'default') {
          url.searchParams.set('view', view);
        } else {
          url.searchParams.delete('view');
        }

        if (subTab) {
          url.searchParams.set('subTab', subTab);
        } else {
          url.searchParams.delete('subTab');
        }

        window.history.replaceState({}, '', url.toString());
        sessionStorage.setItem('sygmate_current_view', view);
        if (subTab) {
          sessionStorage.setItem('sygmate_current_subtab', subTab);
        } else {
          sessionStorage.removeItem('sygmate_current_subtab');
        }
      } catch (e) {}
    }
  };

  // Sync state on popstate (browser back/forward)
  React.useEffect(() => {
    const handlePopState = () => {
      if (typeof window !== 'undefined') {
        const search = new URLSearchParams(window.location.search);
        const v = search.get('view');
        const st = search.get('subTab') || search.get('subtab');
        if (v) {
          setCurrentView(v);
          setCurrentSubTab(st || undefined);
        }
      }
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  // Check URL parameters for direct activation / reset links or deep views
  React.useEffect(() => {
    if (typeof window !== 'undefined') {
      const search = new URLSearchParams(window.location.search);
      const urlToken = search.get('token') || search.get('invitationToken');
      const urlReset = search.get('resetToken');
      const viewParam = search.get('view');
      const subTabParam = search.get('subTab') || search.get('subtab');
      const pathname = window.location.pathname;

      if (pathname === '/verify-certificate' || viewParam === 'verify-certificate' || search.has('ref')) {
        setAuthView('verify-certificate');
      } else if (urlReset || pathname === '/reset-password' || viewParam === 'reset-password') {
        setAuthView('reset-password');
        if (urlReset) setResetToken(urlReset);
        else if (urlToken) setResetToken(urlToken);
      } else if (urlToken || pathname === '/activate' || viewParam === 'activate') {
        setAuthView('activate');
        if (urlToken) setActivationToken(urlToken);
      } else if (pathname === '/forgot-password' || viewParam === 'forgot-password') {
        setAuthView('forgot-password');
      } else if (viewParam && !['login', 'activate', 'forgot-password', 'reset-password'].includes(viewParam)) {
        setCurrentView(viewParam);
        if (subTabParam) {
          setCurrentSubTab(subTabParam);
        }
      }
    }
  }, []);

  if (isInitializing) {
    return (
      <div
        className="min-h-screen flex items-center justify-center bg-slate-950 text-white"
        style={{ background: 'radial-gradient(circle at top right, #1e293b, #0f172a)' }}
      >
        <LoadingSpinner size="lg" message="Initializing Sygmate School OS..." />
      </div>
    );
  }

  if (!isAuthenticated) {
    if (authView === 'activate') {
      return (
        <ParentActivationPage
          initialToken={activationToken}
          onNavigateToLogin={() => setAuthView('login')}
          onActivationSuccess={(targetView) => {
            setCurrentView(targetView || 'guardian-dashboard');
          }}
        />
      );
    }

    if (authView === 'forgot-password') {
      return (
        <ForgotPasswordPage
          onNavigateToLogin={() => setAuthView('login')}
          onNavigateToReset={(tok) => {
            setResetToken(tok);
            setAuthView('reset-password');
          }}
        />
      );
    }

    if (authView === 'reset-password') {
      return (
        <ResetPasswordPage
          initialToken={resetToken}
          onNavigateToLogin={(username) => {
            if (username) setLoginPrefill(username);
            setAuthView('login');
          }}
        />
      );
    }

    if (authView === 'verify-certificate') {
      return (
        <PublicCertificateVerificationPage
          onNavigateToLogin={() => setAuthView('login')}
        />
      );
    }

    return (
      <LoginPage
        initialUsername={loginPrefill}
        onNavigateToActivate={(tok) => {
          if (tok) setActivationToken(tok);
          setAuthView('activate');
        }}
        onNavigateToForgotPassword={() => setAuthView('forgot-password')}
        onNavigateToVerifyCertificate={() => setAuthView('verify-certificate')}
      />
    );
  }

  // Resolve default view per role
  const normalizedRole = (role as string) === 'ADMIN' ? 'SUPER_ADMIN' : role;
  const roleNavItems = role ? getNavItemsForRole(role) : [];

  const defaultRoleDashboard =
    normalizedRole === 'SUPER_ADMIN'
      ? 'admin-dashboard'
      : role === 'TEACHER'
      ? 'teacher-dashboard'
      : role === 'GUARDIAN'
      ? 'guardian-dashboard'
      : 'student-dashboard';

  const isViewValidForRole = (v: string): boolean => {
    if (!v || v === 'default') return false;
    if (['profile', 'verify-certificate'].includes(v)) return true;
    if (normalizedRole === 'SUPER_ADMIN' && v === 'admin-inbox') return true;
    if (role === 'TEACHER' && v === 'teacher-inbox') return true;
    if (role === 'GUARDIAN' && v === 'guardian-inbox') return true;
    if (role === 'STUDENT' && v === 'student-inbox') return true;
    return roleNavItems.some(
      (item) => item.id === v || item.children?.some((c) => c.id === v)
    );
  };

  const resolvedView =
    currentView === 'default' || !isViewValidForRole(currentView)
      ? defaultRoleDashboard
      : currentView;

  // Determine active navigation configuration and effective subtab
  const currentNavItem = roleNavItems.find((item) => item.id === resolvedView);
  const isValidSubTab = currentNavItem?.children?.some((child) => child.id === currentSubTab);
  const effectiveSubTab = isValidSubTab
    ? currentSubTab
    : currentNavItem?.defaultSubTab || currentNavItem?.children?.[0]?.id;

  const renderCurrentView = () => {
    switch (resolvedView) {
      // Platform Super Admin SaaS Views
      case 'platform-schools':
        return (
          <RoleRoute allowedRoles={['SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <PlatformSchoolsPage onNavigate={handleNavigate} />
          </RoleRoute>
        );

      // School Admin Views
      case 'admin-dashboard':
        return (
          <RoleRoute allowedRoles={['SUPER_ADMIN', 'ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <AdminDashboard onNavigate={handleNavigate} />
          </RoleRoute>
        );
      case 'admin-teacher-attendance':
        return (
          <RoleRoute allowedRoles={['SUPER_ADMIN', 'ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <TeacherAttendanceManagementPage
              activeTab={effectiveSubTab as any}
              onTabChange={(t) => setCurrentSubTab(t)}
              hideTabBar={true}
            />
          </RoleRoute>
        );
      case 'admin-attendance-reports':
      case 'attendance-reports':
        return (
          <RoleRoute allowedRoles={['SUPER_ADMIN', 'ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <AdminAttendanceReportsPage
              activeTab={effectiveSubTab as any}
              onTabChange={(t) => setCurrentSubTab(t)}
              hideTabBar={true}
              onNavigate={handleNavigate}
            />
          </RoleRoute>
        );
      case 'admin-academic-calendar':
        return (
          <RoleRoute allowedRoles={['SUPER_ADMIN', 'ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <AcademicCalendarPage
              activeTab={effectiveSubTab as any}
              onTabChange={(t) => setCurrentSubTab(t)}
              hideTabBar={true}
            />
          </RoleRoute>
        );
      case 'admin-attendance-settings':
        return (
          <RoleRoute allowedRoles={['SUPER_ADMIN', 'ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <AttendanceSettingsPage
              activeTab={effectiveSubTab as any}
              onTabChange={(t) => setCurrentSubTab(t)}
              hideTabBar={true}
            />
          </RoleRoute>
        );
      case 'admin-examinations':
        return (
          <RoleRoute allowedRoles={['SUPER_ADMIN', 'ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <AdminExaminationsPage
              initialTab="overview"
              activeTab={effectiveSubTab as any}
              onTabChange={(t) => setCurrentSubTab(t)}
              hideTabBar={true}
            />
          </RoleRoute>
        );
      case 'admin-report-cards':
        return (
          <RoleRoute allowedRoles={['SUPER_ADMIN', 'ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <AdminExaminationsPage initialTab="report-cards" activeTab="report-cards" hideTabBar={true} />
          </RoleRoute>
        );
      case 'admin-merit-list':
        return (
          <RoleRoute allowedRoles={['SUPER_ADMIN', 'ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <AdminExaminationsPage initialTab="merit" activeTab="merit" hideTabBar={true} />
          </RoleRoute>
        );
      case 'admin-academic-reports':
        return (
          <RoleRoute allowedRoles={['SUPER_ADMIN', 'ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <AdminExaminationsPage initialTab="reports" activeTab="reports" hideTabBar={true} />
          </RoleRoute>
        );
      case 'admin-financial-reports':
        return (
          <RoleRoute allowedRoles={['SUPER_ADMIN', 'ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <AdminFinancialReportsPage
              activeTab={effectiveSubTab as any}
              onTabChange={(t) => setCurrentSubTab(t)}
              hideTabBar={true}
            />
          </RoleRoute>
        );
      case 'admin-fee-collection':
        return (
          <RoleRoute allowedRoles={['SUPER_ADMIN', 'ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <AdminFeeCollectionPage
              activeTab={effectiveSubTab as any}
              onTabChange={(t) => setCurrentSubTab(t)}
              hideTabBar={true}
            />
          </RoleRoute>
        );
      case 'admin-student-fees':
        return (
          <RoleRoute allowedRoles={['SUPER_ADMIN', 'ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <AdminStudentFeesPage />
          </RoleRoute>
        );
      case 'admin-fee-adjustments':
        return (
          <RoleRoute allowedRoles={['SUPER_ADMIN', 'ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <AdminFeeAdjustmentsPage
              activeTab={effectiveSubTab as any}
              onTabChange={(t) => setCurrentSubTab(t)}
              hideTabBar={true}
            />
          </RoleRoute>
        );
      case 'admin-due-management':
        return (
          <RoleRoute allowedRoles={['SUPER_ADMIN', 'ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <AdminDueManagementPage
              activeTab={effectiveSubTab as any}
              onTabChange={(t) => setCurrentSubTab(t)}
              hideTabBar={true}
            />
          </RoleRoute>
        );
      case 'admin-fee-structures':
        return (
          <RoleRoute allowedRoles={['SUPER_ADMIN', 'ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <AdminFeeStructurePage
              activeTab={effectiveSubTab as any}
              onTabChange={(t) => setCurrentSubTab(t)}
              hideTabBar={true}
            />
          </RoleRoute>
        );
      case 'admin-academic':
        return (
          <RoleRoute allowedRoles={['SUPER_ADMIN', 'ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <AcademicStructurePage
              activeTab={effectiveSubTab as any}
              onTabChange={(t) => setCurrentSubTab(t)}
              hideTabBar={true}
            />
          </RoleRoute>
        );
      case 'admin-front-office':
      case 'front-office':
      case 'visitors':
      case 'visitor-management':
        return (
          <RoleRoute allowedRoles={['SUPER_ADMIN', 'ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <AdminFrontOfficePage
              activeTab={effectiveSubTab as any}
              onTabChange={(t) => setCurrentSubTab(t)}
              hideTabBar={true}
            />
          </RoleRoute>
        );
      case 'admin-inventory':
      case 'inventory':
      case 'assets':
      case 'inventory-assets':
        return (
          <RoleRoute allowedRoles={['SUPER_ADMIN', 'ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <AdminInventoryPage
              activeTab={effectiveSubTab as any}
              onTabChange={(t) => setCurrentSubTab(t)}
              hideTabBar={true}
            />
          </RoleRoute>
        );
      case 'admin-admissions':
      case 'admissions':
        return (
          <RoleRoute allowedRoles={['SUPER_ADMIN', 'ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <AdminAdmissionsPage
              activeTab={effectiveSubTab as any}
              onTabChange={(t) => setCurrentSubTab(t)}
              hideTabBar={true}
            />
          </RoleRoute>
        );
      case 'admin-promotions-transfers':
        return (
          <RoleRoute allowedRoles={['SUPER_ADMIN', 'ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <AdminStudentPromotionTransferPage
              activeTab={effectiveSubTab as any}
              onTabChange={(t) => setCurrentSubTab(t)}
              hideTabBar={true}
            />
          </RoleRoute>
        );
      case 'admin-student-reports':
      case 'student-reports':
        return (
          <RoleRoute allowedRoles={['SUPER_ADMIN', 'TEACHER']} onBackToPortal={() => handleNavigate('default')}>
            <AdminStudentReportsPage
              activeTab={effectiveSubTab as any}
              onTabChange={(t) => setCurrentSubTab(t)}
              hideTabBar={true}
            />
          </RoleRoute>
        );
      case 'admin-users':
        return (
          <RoleRoute allowedRoles={['SUPER_ADMIN', 'ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <UserDirectoryPage
              onNavigate={handleNavigate}
              activeTab={effectiveSubTab as any}
              onTabChange={(t) => setCurrentSubTab(t)}
              hideTabBar={true}
            />
          </RoleRoute>
        );
      case 'admin-staff':
      case 'staff':
      case 'staff-directory':
      case 'staff-management':
      case 'hr-management':
        return (
          <RoleRoute allowedRoles={['SUPER_ADMIN', 'ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <StaffManagementPage
              activeTab={effectiveSubTab as any}
              onTabChange={(t) => setCurrentSubTab(t)}
              hideTabBar={true}
            />
          </RoleRoute>
        );
      case 'admin-staff-attendance':
        return (
          <RoleRoute allowedRoles={['SUPER_ADMIN', 'ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <StaffManagementPage initialTab="attendance" activeTab="attendance" hideTabBar={true} />
          </RoleRoute>
        );
      case 'admin-staff-schedules':
        return (
          <RoleRoute allowedRoles={['SUPER_ADMIN', 'ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <StaffManagementPage initialTab="schedules" activeTab="schedules" hideTabBar={true} />
          </RoleRoute>
        );
      case 'admin-staff-leaves':
        return (
          <RoleRoute allowedRoles={['SUPER_ADMIN', 'ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <StaffManagementPage initialTab="leaves" activeTab="leaves" hideTabBar={true} />
          </RoleRoute>
        );
      case 'admin-audit':
        return (
          <RoleRoute allowedRoles={['SUPER_ADMIN', 'ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <AuditTrailPage />
          </RoleRoute>
        );
      case 'admin-settings':
        return (
          <RoleRoute allowedRoles={['SUPER_ADMIN', 'ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <SchoolSettingsPage
              activeTab={effectiveSubTab as any}
              onTabChange={(t) => setCurrentSubTab(t)}
              hideTabBar={true}
            />
          </RoleRoute>
        );
      case 'admin-ui-components':
      case 'ui-components':
        return (
          <RoleRoute allowedRoles={['SUPER_ADMIN', 'TEACHER', 'STUDENT']} onBackToPortal={() => handleNavigate('default')}>
            <AdminUIComponentsPage />
          </RoleRoute>
        );
      case 'admin-rbac':
        return (
          <RoleRoute allowedRoles={['SUPER_ADMIN', 'ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <RbacPermissionsPage />
          </RoleRoute>
        );
      case 'admin-id-cards':
        return (
          <RoleRoute allowedRoles={['SUPER_ADMIN', 'ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <AdminIDCardAndDocumentsPage
              onNavigate={handleNavigate}
              activeTab={effectiveSubTab as any}
              onTabChange={(t) => setCurrentSubTab(t)}
              hideTabBar={true}
            />
          </RoleRoute>
        );
      case 'admin-documents':
      case 'documents':
      case 'certificates':
        return (
          <RoleRoute allowedRoles={['SUPER_ADMIN', 'TEACHER']} onBackToPortal={() => handleNavigate('default')}>
            <AdminDocumentsPage
              onNavigate={handleNavigate}
              activeTab={effectiveSubTab as any}
              onTabChange={(t) => setCurrentSubTab(t)}
              hideTabBar={true}
            />
          </RoleRoute>
        );
      case 'admin-announcements':
      case 'announcements':
        return (
          <RoleRoute allowedRoles={['SUPER_ADMIN', 'ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <CommunicationManagementPage initialTab="announcements" activeTab="announcements" hideTabBar={true} />
          </RoleRoute>
        );
      case 'admin-campaigns':
      case 'campaigns':
      case 'bulk-campaigns':
        return (
          <RoleRoute allowedRoles={['SUPER_ADMIN', 'ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <CommunicationManagementPage initialTab="campaigns" activeTab="campaigns" hideTabBar={true} />
          </RoleRoute>
        );
      case 'admin-inbox':
      case 'inbox':
      case 'messages':
        return (
          <RoleRoute allowedRoles={['SUPER_ADMIN', 'ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <InboxPage onNavigate={handleNavigate} />
          </RoleRoute>
        );
      case 'admin-communication':
      case 'communication':
      case 'notifications-management':
        return (
          <RoleRoute allowedRoles={['SUPER_ADMIN', 'ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <CommunicationManagementPage
              activeTab={effectiveSubTab as any}
              onTabChange={(t) => setCurrentSubTab(t)}
              hideTabBar={true}
            />
          </RoleRoute>
        );

      // Teacher Views
      case 'teacher-dashboard':
        return (
          <RoleRoute allowedRoles={['TEACHER', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <TeacherDashboard onNavigate={handleNavigate} />
          </RoleRoute>
        );
      case 'teacher-examinations':
      case 'teacher-marks-entry':
        return (
          <RoleRoute allowedRoles={['TEACHER', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <TeacherExaminationsPage />
          </RoleRoute>
        );
      case 'teacher-classes':
        return (
          <RoleRoute allowedRoles={['TEACHER', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <TeacherClassesPage
              onNavigate={handleNavigate}
              activeTab={effectiveSubTab as any}
              onTabChange={(t) => setCurrentSubTab(t)}
              hideTabBar={true}
            />
          </RoleRoute>
        );
      case 'teacher-students':
        return (
          <RoleRoute allowedRoles={['TEACHER', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <TeacherStudentsPage />
          </RoleRoute>
        );
      case 'teacher-my-attendance':
        return (
          <RoleRoute allowedRoles={['TEACHER', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <TeacherMyAttendancePage
              onNavigate={handleNavigate}
              activeTab={effectiveSubTab as any}
              onTabChange={(t) => setCurrentSubTab(t)}
              hideTabBar={true}
            />
          </RoleRoute>
        );
      case 'admin-student-attendance':
      case 'teacher-attendance':
        return (
          <RoleRoute allowedRoles={['TEACHER', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <TeacherAttendancePage
              onNavigate={handleNavigate}
              activeTab={effectiveSubTab as any}
              onTabChange={(t) => setCurrentSubTab(t)}
              hideTabBar={true}
            />
          </RoleRoute>
        );
      case 'teacher-homework':
        return (
          <RoleRoute allowedRoles={['TEACHER', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <TeacherHomeworkPage onNavigate={handleNavigate} />
          </RoleRoute>
        );
      case 'teacher-assignments':
        return (
          <RoleRoute allowedRoles={['TEACHER', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <TeacherAssignmentsPage onNavigate={handleNavigate} />
          </RoleRoute>
        );
      case 'teacher-materials':
        return (
          <RoleRoute allowedRoles={['TEACHER', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <TeacherMaterialsPage onNavigate={handleNavigate} />
          </RoleRoute>
        );
      case 'teacher-announcements':
        return (
          <RoleRoute allowedRoles={['TEACHER', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <TeacherAnnouncementsPage onNavigate={handleNavigate} />
          </RoleRoute>
        );
      case 'teacher-inbox':
      case 'teacher-messages':
        return (
          <RoleRoute allowedRoles={['TEACHER', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <InboxPage onNavigate={handleNavigate} />
          </RoleRoute>
        );
      case 'teacher-subjects':
        return (
          <RoleRoute allowedRoles={['TEACHER', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <TeacherSubjectsPage />
          </RoleRoute>
        );
      case 'teacher-profile':
        return (
          <RoleRoute allowedRoles={['TEACHER', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <TeacherProfilePage onNavigate={handleNavigate} />
          </RoleRoute>
        );

      // Student Views
      case 'student-dashboard':
        return (
          <RoleRoute allowedRoles={['STUDENT', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <StudentDashboard onNavigate={handleNavigate} />
          </RoleRoute>
        );
      case 'student-fees':
        return (
          <RoleRoute allowedRoles={['STUDENT', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <StudentFeesPage />
          </RoleRoute>
        );
      case 'student-class':
        return (
          <RoleRoute allowedRoles={['STUDENT', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <StudentClassPage onNavigate={handleNavigate} />
          </RoleRoute>
        );
      case 'student-subjects':
        return (
          <RoleRoute allowedRoles={['STUDENT', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <StudentSubjectsPage />
          </RoleRoute>
        );
      case 'student-homework':
        return (
          <RoleRoute allowedRoles={['STUDENT', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <StudentHomeworkPage onNavigate={handleNavigate} />
          </RoleRoute>
        );
      case 'student-assignments':
        return (
          <RoleRoute allowedRoles={['STUDENT', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <StudentAssignmentsPage onNavigate={handleNavigate} />
          </RoleRoute>
        );
      case 'student-materials':
        return (
          <RoleRoute allowedRoles={['STUDENT', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <StudentMaterialsPage onNavigate={handleNavigate} />
          </RoleRoute>
        );
      case 'student-announcements':
        return (
          <RoleRoute allowedRoles={['STUDENT', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <StudentAnnouncementsPage onNavigate={handleNavigate} />
          </RoleRoute>
        );
      case 'student-examinations':
        return (
          <RoleRoute allowedRoles={['STUDENT', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <StudentExaminationsPage onNavigate={handleNavigate} />
          </RoleRoute>
        );
      case 'student-results':
        return (
          <RoleRoute allowedRoles={['STUDENT', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <StudentResultsPage onNavigate={handleNavigate} />
          </RoleRoute>
        );
      case 'student-progress':
        return (
          <RoleRoute allowedRoles={['STUDENT', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <StudentProgressPage onNavigate={handleNavigate} />
          </RoleRoute>
        );
      case 'student-attendance':
        return (
          <RoleRoute allowedRoles={['STUDENT', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <StudentAttendancePage
              onNavigate={handleNavigate}
              activeTab={effectiveSubTab as any}
              onTabChange={(t) => setCurrentSubTab(t)}
              hideTabBar={true}
            />
          </RoleRoute>
        );
      case 'student-academic-info':
        return (
          <RoleRoute allowedRoles={['STUDENT', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <StudentAcademicInfoPage onNavigate={handleNavigate} />
          </RoleRoute>
        );
      case 'student-routine':
        return (
          <RoleRoute allowedRoles={['STUDENT', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <StudentRoutinePage />
          </RoleRoute>
        );
      case 'student-id-card':
        return (
          <RoleRoute allowedRoles={['STUDENT', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <StudentDigitalIDCardPage />
          </RoleRoute>
        );
      case 'student-certificates':
        return (
          <RoleRoute allowedRoles={['STUDENT', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <StudentCertificatesPage onNavigate={handleNavigate} />
          </RoleRoute>
        );
      case 'student-profile':
        return (
          <RoleRoute allowedRoles={['STUDENT', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <StudentProfilePage />
          </RoleRoute>
        );
      case 'student-inbox':
      case 'student-messages':
        return (
          <RoleRoute allowedRoles={['STUDENT', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <InboxPage onNavigate={handleNavigate} />
          </RoleRoute>
        );

      case 'verify-certificate':
        return (
          <PublicCertificateVerificationPage
            onNavigateToLogin={() => handleNavigate('default')}
          />
        );

      // Guardian Views
      case 'guardian-dashboard':
        return (
          <RoleRoute allowedRoles={['GUARDIAN', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <GuardianDashboardPage onNavigate={handleNavigate} />
          </RoleRoute>
        );
      case 'guardian-id-cards':
        return (
          <RoleRoute allowedRoles={['GUARDIAN', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <GuardianChildIDCardsPage />
          </RoleRoute>
        );
      case 'guardian-certificates':
        return (
          <RoleRoute allowedRoles={['GUARDIAN', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <GuardianCertificatesPage onNavigate={handleNavigate} />
          </RoleRoute>
        );
      case 'guardian-fees':
        return (
          <RoleRoute allowedRoles={['GUARDIAN', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <GuardianFeesPage onNavigate={handleNavigate} />
          </RoleRoute>
        );
      case 'guardian-payments':
        return (
          <RoleRoute allowedRoles={['GUARDIAN', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <GuardianPaymentHistoryPage onNavigate={handleNavigate} />
          </RoleRoute>
        );
      case 'guardian-academic-overview':
        return (
          <RoleRoute allowedRoles={['GUARDIAN', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <GuardianChildAcademicOverviewPage
              onNavigate={handleNavigate}
              activeTab={effectiveSubTab as any}
              onTabChange={(t) => setCurrentSubTab(t)}
              hideTabBar={true}
            />
          </RoleRoute>
        );
      case 'guardian-examinations':
        return (
          <RoleRoute allowedRoles={['GUARDIAN', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <GuardianExaminationsPage onNavigate={handleNavigate} />
          </RoleRoute>
        );
      case 'guardian-results':
        return (
          <RoleRoute allowedRoles={['GUARDIAN', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <GuardianResultsPage onNavigate={handleNavigate} />
          </RoleRoute>
        );
      case 'guardian-progress':
        return (
          <RoleRoute allowedRoles={['GUARDIAN', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <GuardianProgressPage onNavigate={handleNavigate} />
          </RoleRoute>
        );
      case 'guardian-attendance':
      case 'guardian-leaves':
        return (
          <RoleRoute allowedRoles={['GUARDIAN', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <GuardianAttendancePage
              onNavigate={handleNavigate}
              initialTab={resolvedView === 'guardian-leaves' ? 'leave-status' : 'calendar'}
              activeTab={effectiveSubTab as any}
              onTabChange={(t) => setCurrentSubTab(t)}
              hideTabBar={true}
            />
          </RoleRoute>
        );
      case 'guardian-homework':
        return (
          <RoleRoute allowedRoles={['GUARDIAN', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <GuardianHomeworkPage onNavigate={handleNavigate} />
          </RoleRoute>
        );
      case 'guardian-assignments':
        return (
          <RoleRoute allowedRoles={['GUARDIAN', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <GuardianAssignmentsPage onNavigate={handleNavigate} />
          </RoleRoute>
        );
      case 'guardian-materials':
        return (
          <RoleRoute allowedRoles={['GUARDIAN', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <GuardianMaterialsPage onNavigate={handleNavigate} />
          </RoleRoute>
        );
      case 'guardian-announcements':
        return (
          <RoleRoute allowedRoles={['GUARDIAN', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <GuardianAnnouncementsPage onNavigate={handleNavigate} />
          </RoleRoute>
        );
      case 'guardian-inbox':
      case 'guardian-messages':
        return (
          <RoleRoute allowedRoles={['GUARDIAN', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <InboxPage onNavigate={handleNavigate} />
          </RoleRoute>
        );
      case 'guardian-children':
        return (
          <RoleRoute allowedRoles={['GUARDIAN', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <GuardianChildrenPage onNavigate={handleNavigate} />
          </RoleRoute>
        );
      case 'guardian-notifications':
        return (
          <RoleRoute allowedRoles={['GUARDIAN', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <GuardianNotificationsPage />
          </RoleRoute>
        );
      case 'guardian-profile':
        return (
          <RoleRoute allowedRoles={['GUARDIAN', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
            <GuardianProfilePage />
          </RoleRoute>
        );

      // Common Views
      case 'profile':
        if (role === 'TEACHER') {
          return (
            <RoleRoute allowedRoles={['TEACHER', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
              <TeacherProfilePage onNavigate={handleNavigate} />
            </RoleRoute>
          );
        }
        if (role === 'STUDENT') {
          return (
            <RoleRoute allowedRoles={['STUDENT', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
              <StudentProfilePage />
            </RoleRoute>
          );
        }
        if (role === 'GUARDIAN') {
          return (
            <RoleRoute allowedRoles={['GUARDIAN', 'SUPER_ADMIN']} onBackToPortal={() => handleNavigate('default')}>
              <GuardianProfilePage />
            </RoleRoute>
          );
        }
        return <ProfilePage />;

      default:
        return (
          <div className="p-8 text-center text-slate-400">
            <h3 className="text-lg font-semibold text-white">View not found</h3>
            <button
              onClick={() => handleNavigate('default')}
              className="mt-4 px-4 py-2 bg-indigo-600 rounded-xl text-white text-xs font-semibold cursor-pointer"
            >
              Return to Portal Home
            </button>
          </div>
        );
    }
  };

  const getBreadcrumbs = () => {
    const dashboardView =
      role === 'SUPER_ADMIN'
        ? 'admin-dashboard'
        : role === 'TEACHER'
        ? 'teacher-dashboard'
        : role === 'GUARDIAN'
        ? 'guardian-dashboard'
        : 'student-dashboard';

    if (resolvedView === dashboardView) {
      return [{ label: 'Overview' }, { label: currentNavItem?.label || 'Dashboard', active: true }];
    }

    const crumbs: BreadcrumbItem[] = [
      { label: 'Overview', onClick: () => handleNavigate(dashboardView) }
    ];

    if (currentNavItem) {
      if (currentNavItem.children && currentNavItem.children.length > 0) {
        const activeChild = currentNavItem.children.find((c) => c.id === effectiveSubTab);
        crumbs.push({
          label: currentNavItem.label,
          onClick: () => handleNavigate(currentNavItem.id, currentNavItem.defaultSubTab || currentNavItem.children?.[0]?.id)
        });
        if (activeChild) {
          crumbs.push({
            label: activeChild.label,
            active: true
          });
        }
      } else {
        crumbs.push({
          label: currentNavItem.label,
          active: true
        });
      }
      return crumbs;
    }

    return [{ label: 'Overview', onClick: () => handleNavigate(dashboardView) }, { label: 'Portal', active: true }];
  };

  return (
    <PortalLayout
      currentView={resolvedView}
      currentSubTab={effectiveSubTab}
      onNavigate={handleNavigate}
      breadcrumbs={getBreadcrumbs()}
    >
      {renderCurrentView()}
    </PortalLayout>
  );
};

export function App() {
  return (
    <ThemeProvider>
      <ToastProvider>
        <AuthProvider>
          <SettingsProvider>
            <MainAppContent />
          </SettingsProvider>
        </AuthProvider>
      </ToastProvider>
    </ThemeProvider>
  );
}

export default App;
