import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { User, UserRole, Permission, AuthSession } from '../types/index.js';
import { api } from '../services/api.js';
import { useToast } from './ToastContext.js';

interface AuthContextType {
  user: User | null;
  role: UserRole | null;
  session: AuthSession | null;
  token: string | null;
  isAuthenticated: boolean;
  isInitializing: boolean;
  activeSchool: {
    id: string;
    name: string;
    code: string;
    plan?: string;
    status?: string;
  } | null;
  userSchools: Array<{
    id: string;
    name: string;
    code: string;
    role: UserRole;
  }>;
  isPlatformAdmin: boolean;
  login: (
    identifier: string,
    password: string
  ) => Promise<{
    success: boolean;
    redirectTo?: string;
    error?: string;
    code?: string;
    invitationToken?: string;
  }>;
  switchDemoRole: (role: UserRole) => Promise<{ success: boolean; redirectTo?: string; error?: string }>;
  switchActiveSchool: (schoolId: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
  hasPermission: (permission: Permission) => boolean;
  refreshSession: () => Promise<void>;
  setSessionFromLogin: (session: AuthSession) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const TOKEN_KEY = 'sygmate_auth_token';

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [session, setSession] = useState<AuthSession | null>(null);
  const [isInitializing, setIsInitializing] = useState(true);
  const { success: toastSuccess, error: toastError, info: toastInfo } = useToast();

  const user = session?.user || null;
  const role = user?.role || null;
  const token = session?.token || null;
  const isAuthenticated = !!session && !!user;
  const activeSchool = session?.schoolContext || null;
  const userSchools = session?.availableSchools || [];
  const isPlatformAdmin = user?.role === 'SUPER_ADMIN' || user?.isPlatformAdmin === true;

  const setSessionFromLogin = useCallback((newSession: AuthSession) => {
    localStorage.setItem(TOKEN_KEY, newSession.token);
    localStorage.setItem('token', newSession.token);
    localStorage.setItem('sygmate_token', newSession.token);
    if (newSession.schoolContext?.id) {
      localStorage.setItem('sygmate_active_school_id', newSession.schoolContext.id);
    }
    setSession(newSession);
  }, []);

  // Check token on boot
  const refreshSession = useCallback(async () => {
    const savedToken = localStorage.getItem(TOKEN_KEY) || localStorage.getItem('token') || localStorage.getItem('sygmate_token');
    if (!savedToken) {
      setSession(null);
      setIsInitializing(false);
      return;
    }

    try {
      const response = await api.auth.getMe();
      if (response.success && response.data) {
        localStorage.setItem(TOKEN_KEY, savedToken);
        localStorage.setItem('token', savedToken);
        localStorage.setItem('sygmate_token', savedToken);
        setSession(response.data);
      } else {
        localStorage.removeItem(TOKEN_KEY);
        localStorage.removeItem('token');
        localStorage.removeItem('sygmate_token');
        setSession(null);
      }
    } catch {
      localStorage.removeItem(TOKEN_KEY);
      localStorage.removeItem('token');
      localStorage.removeItem('sygmate_token');
      setSession(null);
    } finally {
      setIsInitializing(false);
    }
  }, []);

  useEffect(() => {
    refreshSession();
  }, [refreshSession]);

  const login = async (identifier: string, password: string) => {
    try {
      const response = await api.auth.login({ identifier, password });
      if (response.success && response.data) {
        const { session: newSession, redirectTo } = response.data;
        localStorage.setItem(TOKEN_KEY, newSession.token);
        localStorage.setItem('token', newSession.token);
        localStorage.setItem('sygmate_token', newSession.token);
        setSession(newSession);
        toastSuccess(`Signed in successfully`, `Logged in as ${newSession.user.name} (${newSession.user.role})`);
        return { success: true, redirectTo };
      } else {
        toastError('Authentication Failed', response.error || 'Invalid credentials.');
        return {
          success: false,
          error: response.error,
          code: (response as any).code,
          invitationToken: (response as any).invitationToken
        };
      }
    } catch (err: any) {
      toastError('Login Error', 'Failed to connect to authentication service.');
      return { success: false, error: 'Network error during login' };
    }
  };

  const switchDemoRole = async (targetRole: UserRole) => {
    try {
      const response = await api.auth.switchDemo(targetRole);
      if (response.success && response.data) {
        const { session: newSession, redirectTo } = response.data;
        localStorage.setItem(TOKEN_KEY, newSession.token);
        localStorage.setItem('token', newSession.token);
        localStorage.setItem('sygmate_token', newSession.token);
        setSession(newSession);
        toastInfo(`Switched Portal Context`, `Active role changed to ${targetRole} (${newSession.user.name})`);
        return { success: true, redirectTo };
      } else {
        toastError('Role Switch Failed', response.error);
        return { success: false, error: response.error };
      }
    } catch (err) {
      toastError('Error', 'Could not switch demo role.');
      return { success: false, error: 'Network error' };
    }
  };

  const logout = async () => {
    try {
      await api.auth.logout();
    } catch {
      // ignore network failure on logout
    } finally {
      localStorage.removeItem(TOKEN_KEY);
      localStorage.removeItem('token');
      localStorage.removeItem('sygmate_token');
      try {
        sessionStorage.removeItem('sygmate_current_view');
        sessionStorage.removeItem('sygmate_current_subtab');
      } catch (e) {}
      setSession(null);
      toastInfo('Signed Out', 'You have been safely logged out of Sygmate.');
    }
  };

  const hasPermission = useCallback(
    (permission: Permission): boolean => {
      if (!session || !session.permissions) return false;
      return session.permissions.includes(permission);
    },
    [session]
  );

  const switchActiveSchool = async (schoolId: string) => {
    try {
      const response = await api.auth.switchSchool(schoolId);
      if (response.success && response.data) {
        localStorage.setItem('sygmate_active_school_id', schoolId);
        if (response.data.session) {
          setSession(response.data.session);
        } else {
          await refreshSession();
        }
        toastSuccess('Tenant Switched', `Active school is now ${response.data.school?.name || schoolId}`);
        return { success: true };
      } else {
        toastError('School Switch Failed', response.error || 'Access denied.');
        return { success: false, error: response.error };
      }
    } catch (err: any) {
      toastError('Network Error', 'Could not switch active school.');
      return { success: false, error: err.message };
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        role,
        session,
        token,
        isAuthenticated,
        isInitializing,
        activeSchool,
        userSchools,
        isPlatformAdmin,
        login,
        switchDemoRole,
        switchActiveSchool,
        logout,
        hasPermission,
        refreshSession,
        setSessionFromLogin
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
