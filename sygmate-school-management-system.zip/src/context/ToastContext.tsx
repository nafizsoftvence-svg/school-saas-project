import React, { createContext, useContext, useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CheckCircle2, AlertTriangle, AlertCircle, Info, X } from 'lucide-react';

export type ToastType = 'success' | 'error' | 'warning' | 'info';

export interface Toast {
  id: string;
  title: string;
  message?: string;
  type: ToastType;
  duration?: number;
}

interface ToastContextType {
  showToast: (title: string, message?: string, type?: ToastType, duration?: number) => void;
  addToast: (titleOrMessage: string, typeOrMessage?: ToastType | string, type?: ToastType) => void;
  success: (title: string, message?: string) => void;
  error: (title: string, message?: string) => void;
  warning: (title: string, message?: string) => void;
  info: (title: string, message?: string) => void;
}

const ToastContext = createContext<ToastContextType | undefined>(undefined);

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const removeToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const showToast = useCallback(
    (title: string, message?: string, type: ToastType = 'info', duration: number = 4000) => {
      const id = `toast-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
      const newToast: Toast = { id, title, message, type, duration };

      setToasts((prev) => [...prev, newToast]);

      if (duration > 0) {
        setTimeout(() => {
          removeToast(id);
        }, duration);
      }
    },
    [removeToast]
  );

  const addToast = useCallback(
    (titleOrMessage: string, typeOrMessage?: ToastType | string, type?: ToastType) => {
      const knownTypes = ['success', 'error', 'warning', 'info'];
      if (type) {
        showToast(titleOrMessage, typeOrMessage as string, type);
      } else if (typeOrMessage && knownTypes.includes(typeOrMessage)) {
        showToast(titleOrMessage, undefined, typeOrMessage as ToastType);
      } else if (typeOrMessage) {
        showToast(titleOrMessage, typeOrMessage as string, 'info');
      } else {
        showToast(titleOrMessage, undefined, 'info');
      }
    },
    [showToast]
  );

  const success = useCallback((title: string, message?: string) => showToast(title, message, 'success'), [showToast]);
  const error = useCallback((title: string, message?: string) => showToast(title, message, 'error', 5000), [showToast]);
  const warning = useCallback((title: string, message?: string) => showToast(title, message, 'warning'), [showToast]);
  const info = useCallback((title: string, message?: string) => showToast(title, message, 'info'), [showToast]);

  return (
    <ToastContext.Provider value={{ showToast, addToast, success, error, warning, info }}>
      {children}
      {/* Toast Render Area */}
      <div
        id="toast-container"
        className="fixed bottom-4 right-4 z-50 flex flex-col gap-2 max-w-md w-full pointer-events-none px-4 sm:px-0"
      >
        <AnimatePresence>
          {(toasts || []).map((toast) => {
            const icons = {
              success: <CheckCircle2 className="w-5 h-5 text-emerald-600 flex-shrink-0" />,
              error: <AlertCircle className="w-5 h-5 text-rose-600 flex-shrink-0" />,
              warning: <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0" />,
              info: <Info className="w-5 h-5 text-blue-600 flex-shrink-0" />
            };

            const borderColors = {
              success: 'border-emerald-200 bg-emerald-50/95 text-emerald-950',
              error: 'border-rose-200 bg-rose-50/95 text-rose-950',
              warning: 'border-amber-200 bg-amber-50/95 text-amber-950',
              info: 'border-blue-200 bg-blue-50/95 text-blue-950'
            };

            return (
              <motion.div
                key={toast.id}
                id={`toast-${toast.id}`}
                initial={{ opacity: 0, y: 20, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 10, scale: 0.95 }}
                transition={{ duration: 0.2 }}
                className={`pointer-events-auto flex items-start gap-3 p-4 rounded-xl border shadow-lg backdrop-blur-sm ${borderColors[toast.type]}`}
              >
                {icons[toast.type]}
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold leading-tight">{toast.title}</p>
                  {toast.message && <p className="text-xs opacity-90 mt-1 leading-relaxed">{toast.message}</p>}
                </div>
                <button
                  id={`close-toast-${toast.id}`}
                  onClick={() => removeToast(toast.id)}
                  className="text-gray-400 hover:text-gray-700 transition-colors p-0.5 rounded"
                >
                  <X className="w-4 h-4" />
                </button>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>
    </ToastContext.Provider>
  );
}

export function useToast() {
  const context = useContext(ToastContext);
  if (!context) {
    throw new Error('useToast must be used within a ToastProvider');
  }
  return context;
}
