import React, { createContext, useContext, useEffect } from 'react';

export interface NordicThemeMeta {
  id?: string;
  name: string;
  tagline: string;
  primaryColor: string;
  primaryClass: string;
  badgeClass: string;
  borderClass: string;
  previewColor?: string;
}

export const NORDIC_THEME: NordicThemeMeta = {
  id: 'nordic',
  name: 'Nordic Crisp Light',
  tagline: 'Clean Scandinavian aesthetic with high-contrast slate typography and arctic fjord accents',
  primaryColor: '#0369a1',
  primaryClass: 'bg-sky-700 hover:bg-sky-800 text-white shadow-xs',
  badgeClass: 'bg-sky-50 text-sky-800 border-sky-200',
  borderClass: 'border-slate-200',
  previewColor: '#0369a1'
};

export type ThemeMode = 'light';
export type AccentColor = 'nordic';

interface ThemeContextType {
  themeName: string;
  themeMode: 'light';
  setThemeMode: (mode: any) => void;
  accentColor: string;
  setAccentColor: (accent: any) => void;
  allAccents: NordicThemeMeta[];
  activeAccent: NordicThemeMeta;
  isDark: boolean;
  toggleTheme: () => void;
  themeMeta: NordicThemeMeta;
}

const ThemeContext = createContext<ThemeContextType>({
  themeName: 'Nordic Crisp Light',
  themeMode: 'light',
  setThemeMode: () => {},
  accentColor: 'nordic',
  setAccentColor: () => {},
  allAccents: [NORDIC_THEME],
  activeAccent: NORDIC_THEME,
  isDark: false,
  toggleTheme: () => {},
  themeMeta: NORDIC_THEME
});

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  useEffect(() => {
    if (typeof document === 'undefined') return;
    const root = document.documentElement;

    // Strictly enforce Nordic Crisp Light across the entire application
    root.classList.remove('dark');
    root.classList.add('light');
    root.style.colorScheme = 'light';
    root.setAttribute('data-theme', 'nordic-light');

    // Clean up any stale dark mode flags from storage
    try {
      localStorage.setItem('sygmate_theme', 'nordic-light');
      localStorage.removeItem('sygmate_theme_mode');
    } catch {
      // ignore
    }
  }, []);

  return (
    <ThemeContext.Provider
      value={{
        themeName: 'Nordic Crisp Light',
        themeMode: 'light',
        setThemeMode: () => {},
        accentColor: 'nordic',
        setAccentColor: () => {},
        allAccents: [NORDIC_THEME],
        activeAccent: NORDIC_THEME,
        isDark: false,
        toggleTheme: () => {},
        themeMeta: NORDIC_THEME
      }}
    >
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = () => useContext(ThemeContext);
