import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { SchoolSettings, AcademicSession } from '../types/index.js';
import { api } from '../services/api.js';
import { useToast } from './ToastContext.js';

interface SettingsContextType {
  settings: SchoolSettings | null;
  activeSession: AcademicSession | null;
  isLoading: boolean;
  refreshSettings: () => Promise<void>;
  updateSettings: (updates: Partial<SchoolSettings>) => Promise<{ success: boolean; data?: SchoolSettings; error?: string }>;
  formatCurrency: (amount: number) => string;
  formatDate: (date: string | Date) => string;
}

const SettingsContext = createContext<SettingsContextType | undefined>(undefined);

export const SettingsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [settings, setSettings] = useState<SchoolSettings | null>(null);
  const [activeSession, setActiveSession] = useState<AcademicSession | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const { addToast } = useToast();

  const refreshSettings = useCallback(async () => {
    try {
      setIsLoading(true);
      const res = await api.getSchoolSettings();
      if (res.success && res.data) {
        // Handle if res.data is SchoolSettings or an object containing settings
        const loadedSettings: SchoolSettings = (res.data as any).settings || res.data;
        setSettings(loadedSettings);
        if ((res as any).activeSession) {
          setActiveSession((res as any).activeSession);
        }
      }
    } catch (err) {
      console.error('Failed to load global school settings:', err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshSettings();
  }, [refreshSettings]);

  const updateSettings = async (updates: Partial<SchoolSettings>) => {
    try {
      const res = await api.updateSchoolSettings(updates);
      if (res.success && res.data) {
        setSettings(res.data);
        addToast('Institutional settings updated and logged.', 'success');
        return { success: true, data: res.data };
      } else {
        const errMsg = res.error || 'Failed to update school settings.';
        addToast(errMsg, 'error');
        return { success: false, error: errMsg };
      }
    } catch (err: any) {
      const errMsg = err?.message || 'Network communication failure during settings update.';
      addToast(errMsg, 'error');
      return { success: false, error: errMsg };
    }
  };

  const formatCurrency = useCallback(
    (amount: number): string => {
      const symbol = settings?.currencySymbol || '$';
      const formattedNum = Number(amount || 0).toLocaleString(undefined, {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
      });
      return `${symbol}${formattedNum}`;
    },
    [settings?.currencySymbol]
  );

  const formatDate = useCallback(
    (dateInput: string | Date): string => {
      if (!dateInput) return '';
      const d = typeof dateInput === 'string' ? new Date(dateInput) : dateInput;
      if (isNaN(d.getTime())) return String(dateInput);

      const fmt = settings?.dateFormat || 'DD/MM/YYYY';
      const day = String(d.getDate()).padStart(2, '0');
      const month = String(d.getMonth() + 1).padStart(2, '0');
      const year = d.getFullYear();
      const monthShort = d.toLocaleString('en-US', { month: 'short' });

      if (fmt === 'MM/DD/YYYY') return `${month}/${day}/${year}`;
      if (fmt === 'YYYY-MM-DD') return `${year}-${month}-${day}`;
      if (fmt === 'D MMM YYYY') return `${d.getDate()} ${monthShort} ${year}`;
      return `${day}/${month}/${year}`;
    },
    [settings?.dateFormat]
  );

  return (
    <SettingsContext.Provider
      value={{
        settings,
        activeSession,
        isLoading,
        refreshSettings,
        updateSettings,
        formatCurrency,
        formatDate
      }}
    >
      {children}
    </SettingsContext.Provider>
  );
};

export const useSettings = (): SettingsContextType => {
  const context = useContext(SettingsContext);
  if (!context) {
    throw new Error('useSettings must be used within a SettingsProvider');
  }
  return context;
};
