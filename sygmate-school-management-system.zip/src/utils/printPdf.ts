/**
 * Sygmate School Management System — Centralized Print & PDF Engine
 * Comprehensive utility for generating, downloading, and printing PDF documents
 * Supports vector table PDF generation, high-res DOM element capture, and iframe-safe printing.
 */

import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas-pro';

export interface TablePdfColumn {
  header: string;
  dataKey?: string;
  widthRatio?: number;
}

export interface TablePdfConfig {
  title: string;
  subtitle?: string;
  schoolName?: string;
  filterSummary?: string;
  columns: (TablePdfColumn | string)[];
  data: any[];
  filename?: string;
  orientation?: 'portrait' | 'landscape';
}

export interface ElementPdfOptions {
  orientation?: 'portrait' | 'landscape';
  title?: string;
  scale?: number;
  backgroundColor?: string;
}

/**
 * Generates a clean, professional, publication-quality vector PDF table report
 * Complete with school letterhead, active metadata filters, formatted columns, alternating row striping, and page numbers.
 */
export async function downloadTablePdf(config: TablePdfConfig): Promise<void> {
  const {
    title,
    subtitle,
    schoolName = 'SYGMATE INTERNATIONAL ACADEMY',
    filterSummary,
    columns,
    data,
    filename,
    orientation = columns.length > 5 ? 'landscape' : 'portrait'
  } = config;

  const doc = new jsPDF({
    orientation,
    unit: 'mm',
    format: 'a4'
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const marginLeft = 14;
  const marginRight = 14;
  const marginTop = 16;
  const marginBottom = 18;
  const usableWidth = pageWidth - marginLeft - marginRight;

  // Normalized columns
  const normalizedCols: { header: string; key?: string; width: number }[] = [];
  const totalCols = columns.length;
  const defaultColWidth = usableWidth / totalCols;

  columns.forEach((col) => {
    if (typeof col === 'string') {
      normalizedCols.push({ header: col, width: defaultColWidth });
    } else {
      normalizedCols.push({
        header: col.header,
        key: col.dataKey,
        width: col.widthRatio ? usableWidth * col.widthRatio : defaultColWidth
      });
    }
  });

  // Normalize column widths to sum up to exactly usableWidth
  const sumWidths = normalizedCols.reduce((acc, c) => acc + c.width, 0);
  if (sumWidths > 0) {
    normalizedCols.forEach((c) => {
      c.width = (c.width / sumWidths) * usableWidth;
    });
  }

  let currentY = marginTop;

  const drawHeader = (isFirstPage: boolean) => {
    if (isFirstPage) {
      // Top Institutional Accent Bar
      doc.setFillColor(22, 38, 59); // Deep Navy (#16263B)
      doc.rect(0, 0, pageWidth, 5, 'F');

      // School Name
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(14);
      doc.setTextColor(22, 38, 59);
      doc.text(schoolName.toUpperCase(), marginLeft, currentY + 3);

      // Subtitle / Accreditation
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8);
      doc.setTextColor(100, 116, 139);
      doc.text('OFFICIAL INSTITUTIONAL RECORD & AUTHORITATIVE REPORT', marginLeft, currentY + 8);

      currentY += 12;

      // Report Title
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(13);
      doc.setTextColor(15, 23, 42);
      doc.text(title.replace(/_/g, ' '), marginLeft, currentY + 3);

      currentY += 8;

      // Metadata summary line
      const timestamp = new Date().toLocaleString();
      const metaText = `Generated: ${timestamp}  |  Total Records: ${data.length}${
        filterSummary ? `  |  Scope: ${filterSummary}` : ''
      }`;

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8);
      doc.setTextColor(100, 116, 139);
      doc.text(metaText, marginLeft, currentY + 1);

      if (subtitle) {
        currentY += 5;
        doc.text(subtitle, marginLeft, currentY + 1);
      }

      currentY += 6;

      // Divider line
      doc.setDrawColor(226, 232, 240);
      doc.setLineWidth(0.5);
      doc.line(marginLeft, currentY, pageWidth - marginRight, currentY);

      currentY += 5;
    } else {
      // Continuation Header on Subsequent Pages
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(9);
      doc.setTextColor(71, 85, 105);
      doc.text(`${title.replace(/_/g, ' ')} (Continued)`, marginLeft, currentY);
      currentY += 5;
    }

    // Table Header Row
    const headerHeight = 8;
    doc.setFillColor(29, 100, 201); // Indigo / Brand Blue (#1D64C9)
    doc.rect(marginLeft, currentY, usableWidth, headerHeight, 'F');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(255, 255, 255);

    let cellX = marginLeft;
    normalizedCols.forEach((col) => {
      const maxTextWidth = col.width - 3;
      let text = col.header;
      while (doc.getTextWidth(text) > maxTextWidth && text.length > 3) {
        text = text.substring(0, text.length - 2) + '…';
      }
      doc.text(text, cellX + 2, currentY + 5.2);
      cellX += col.width;
    });

    currentY += headerHeight;
  };

  // Draw Page 1 header
  drawHeader(true);

  // Table Body Rows
  const rowHeight = 7;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);

  data.forEach((row, rowIndex) => {
    // Check if new page is needed
    if (currentY + rowHeight > pageHeight - marginBottom) {
      doc.addPage();
      currentY = marginTop;
      drawHeader(false);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(7.5);
    }

    // Row Background (Zebra Striping)
    if (rowIndex % 2 === 0) {
      doc.setFillColor(255, 255, 255);
    } else {
      doc.setFillColor(248, 250, 252); // slate-50
    }
    doc.rect(marginLeft, currentY, usableWidth, rowHeight, 'F');

    // Row Bottom Border
    doc.setDrawColor(241, 245, 249); // slate-100
    doc.setLineWidth(0.2);
    doc.line(marginLeft, currentY + rowHeight, pageWidth - marginRight, currentY + rowHeight);

    // Row Content Cells
    let cellX = marginLeft;
    doc.setTextColor(30, 41, 59);

    normalizedCols.forEach((col, colIdx) => {
      let cellVal = '';
      if (Array.isArray(row)) {
        cellVal = row[colIdx] !== undefined && row[colIdx] !== null ? String(row[colIdx]) : '';
      } else if (typeof row === 'object' && row !== null) {
        const key = col.key || col.header;
        cellVal = row[key] !== undefined && row[key] !== null ? String(row[key]) : '';
      }

      // Truncate text if exceeds column width
      const maxTextWidth = col.width - 4;
      let text = cellVal.replace(/\n/g, ' ').trim();
      while (doc.getTextWidth(text) > maxTextWidth && text.length > 3) {
        text = text.substring(0, text.length - 2) + '…';
      }

      doc.text(text, cellX + 2, currentY + 4.8);
      cellX += col.width;
    });

    currentY += rowHeight;
  });

  // Footer on all pages
  const totalPages = doc.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7);
    doc.setTextColor(148, 163, 184);

    // Left Footer
    doc.text('CONFIDENTIAL — PROPRIETARY INSTITUTIONAL ARCHIVE', marginLeft, pageHeight - 8);

    // Right Footer: Page X of Y
    const pageNumText = `Page ${i} of ${totalPages}`;
    doc.text(pageNumText, pageWidth - marginRight - doc.getTextWidth(pageNumText), pageHeight - 8);

    // Footer divider line
    doc.setDrawColor(226, 232, 240);
    doc.setLineWidth(0.3);
    doc.line(marginLeft, pageHeight - 12, pageWidth - marginRight, pageHeight - 12);
  }

  // Generate filename and trigger download
  const dateStr = new Date().toISOString().split('T')[0];
  const cleanFilename =
    filename || `${title.toLowerCase().replace(/[^a-z0-9]/g, '_')}_${dateStr}.pdf`;

  doc.save(cleanFilename);
}

/**
 * Captures any DOM element (e.g. Certificate, Invoice, ID Card, Visitor Pass, Report Card)
 * and exports it as a crystal-clear, high-resolution PDF file.
 */
export async function downloadElementPdf(
  elementOrId: HTMLElement | string,
  filename?: string,
  options?: ElementPdfOptions
): Promise<void> {
  const element =
    typeof elementOrId === 'string' ? document.getElementById(elementOrId) : elementOrId;

  if (!element) {
    console.error(`[printPdf] Element not found for download: ${elementOrId}`);
    // If element is not found, fallback to standard clean print
    window.print();
    return;
  }

  const {
    orientation = element.offsetWidth > element.offsetHeight ? 'landscape' : 'portrait',
    scale = 2,
    backgroundColor = '#ffffff'
  } = options || {};

  try {
    const canvas = await html2canvas(element, {
      scale,
      useCORS: true,
      logging: false,
      backgroundColor,
      windowWidth: element.scrollWidth,
      windowHeight: element.scrollHeight
    });

    const imgData = canvas.toDataURL('image/jpeg', 0.95);

    const doc = new jsPDF({
      orientation,
      unit: 'mm',
      format: 'a4'
    });

    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    const margin = 10;
    const printableWidth = pageWidth - margin * 2;
    const printableHeight = pageHeight - margin * 2;

    const imgWidth = canvas.width;
    const imgHeight = canvas.height;
    const ratio = imgWidth / imgHeight;

    let targetWidth = printableWidth;
    let targetHeight = targetWidth / ratio;

    if (targetHeight > printableHeight) {
      targetHeight = printableHeight;
      targetWidth = targetHeight * ratio;
    }

    const posX = margin + (printableWidth - targetWidth) / 2;
    const posY = margin + (printableHeight - targetHeight) / 2;

    doc.addImage(imgData, 'JPEG', posX, posY, targetWidth, targetHeight);

    const dateStr = new Date().toISOString().split('T')[0];
    const targetFilename =
      filename || `sygmate_document_${dateStr}.pdf`;

    doc.save(targetFilename);
  } catch (err) {
    console.error('[printPdf] Failed to generate PDF from element:', err);
    // Graceful fallback to browser print dialog
    try {
      window.print();
    } catch {
      // ignore
    }
  }
}

/**
 * Safely triggers the browser print dialog.
 * If running inside a sandboxed iframe or if window.print() is blocked/throws an exception,
 * it catches the error and executes the provided fallback (e.g. downloadElementPdf or downloadTablePdf).
 */
export async function triggerSafePrint(options?: {
  elementOrId?: HTMLElement | string;
  fallbackTitle?: string;
  fallbackConfig?: TablePdfConfig;
}): Promise<void> {
  const { elementOrId, fallbackConfig, fallbackTitle = 'Document' } = options || {};

  try {
    // Attempt standard browser print dialog
    window.print();
  } catch (printErr) {
    console.warn('[printPdf] window.print() was blocked or failed:', printErr);

    // If window.print failed and we have an element, download as PDF
    if (elementOrId) {
      await downloadElementPdf(
        elementOrId,
        `${fallbackTitle.toLowerCase().replace(/[^a-z0-9]/g, '_')}.pdf`
      );
    } else if (fallbackConfig) {
      await downloadTablePdf(fallbackConfig);
    }
  }
}

/**
 * All-in-one helper for "Print / PDF" buttons:
 * Generates and downloads the real PDF document to the user's computer,
 * AND safely invokes the print dialog/preview.
 */
export async function executePrintAndPdf(options: {
  tableConfig?: TablePdfConfig;
  elementOrId?: HTMLElement | string;
  filename?: string;
  onNotice?: (msg: string) => void;
}): Promise<void> {
  const { tableConfig, elementOrId, filename, onNotice } = options;

  try {
    if (tableConfig) {
      await downloadTablePdf(tableConfig);
    } else if (elementOrId) {
      await downloadElementPdf(elementOrId, filename);
    }

    if (onNotice) {
      onNotice('PDF generated and downloaded. Opening print preview...');
    }

    // Safely trigger print dialog as well
    setTimeout(() => {
      try {
        window.print();
      } catch (e) {
        console.warn('[printPdf] Print dialog skipped or restricted by environment.');
      }
    }, 300);
  } catch (err: any) {
    console.error('[printPdf] Export failed:', err);
    // Fallback to window.print if PDF generation hit any issue
    try {
      window.print();
    } catch {
      // ignore
    }
  }
}
