import { Router, Response } from 'express';
import { database } from '../db/database.js';
import {
  AuthenticatedRequest,
  requireAuth,
  requireRole,
  requirePermission
} from '../security/auth.js';
import { hasPermission } from '../security/rbac.js';
import { logAudit } from '../security/audit.js';
import {
  FeeType,
  FeeStructure,
  FeeFrequency,
  FeeStructureStatus,
  FeeCategory,
  FeeTypeStatus,
  FeeTypeCategory,
  CreateFeeTypePayload,
  UpdateFeeTypePayload,
  CreateFeeStructurePayload,
  UpdateFeeStructurePayload,
  FeeStructureFilterParams,
  FeeStructureSummaryStats,
  StudentFeeRecord,
  FeePaymentStatus,
  AssignStudentFeePayload,
  AssignStudentFeeResponse,
  ApplicableFeeStructureItem,
  StudentFeeFilterParams,
  StudentFeeSummaryStats,
  ApplyFeeDiscountPayload,
  ApplyFeeFinePayload,
  UpdateStudentFeeStatusPayload,
  InvoiceDetailResponse,
  FeePaymentTransaction,
  FeePaymentReceipt,
  CollectFeePaymentPayload,
  CollectFeePaymentResponse,
  ReverseFeePaymentPayload,
  ReverseFeePaymentResponse,
  FeePaymentFilterParams,
  FeePaymentListResponse,
  FeeCollectionSummaryStats,
  PaymentMethod,
  PaymentMethodConfig,
  FeeDiscountRule,
  CreateDiscountRulePayload,
  UpdateDiscountRulePayload,
  ApplyDiscountBatchPayload,
  ApplyDiscountBatchResponse,
  FeeWaiver,
  CreateWaiverPayload,
  ApproveWaiverPayload,
  RejectWaiverPayload,
  FeeScholarship,
  CreateScholarshipPayload,
  UpdateScholarshipPayload,
  FeeFineRule,
  CreateFineRulePayload,
  UpdateFineRulePayload,
  AppliedFineRecord,
  ApplyManualFinePayload,
  WaiveFinePayload,
  AssessLateFinesPayload,
  AssessLateFinesResponse,
  FeeAdjustmentAudit,
  FeeAdjustmentSummaryStats
} from '../../src/types/index.js';
import { feeAdjustmentsRouter } from './fees-adjustments.routes.js';
import { feeDueRouter } from './fees-due.routes.js';
import { feesReportsRouter } from './fees-reports.routes.js';

export const feesRouter = Router();

// All routes require authentication
feesRouter.use(requireAuth);

// Mount Part 7D Discounts, Waivers, Scholarships & Fines sub-router
feesRouter.use('/', feeAdjustmentsRouter);

// Mount Part 7E Fee Due, Overdue & Fee Tracking sub-router
feesRouter.use('/', feeDueRouter);

// Mount Part 7F Financial Reports, Receipts & Statements sub-router
feesRouter.use('/', feesReportsRouter);

// Helper: check valid date string YYYY-MM-DD
function isValidDateString(dateStr: string): boolean {
  if (!dateStr || typeof dateStr !== 'string') return false;
  const regex = /^\d{4}-\d{2}-\d{2}$/;
  if (!regex.test(dateStr)) return false;
  const d = new Date(dateStr);
  return !isNaN(d.getTime());
}

// Valid status transitions for Fee Structure
const VALID_FEE_STRUCTURE_TRANSITIONS: Record<FeeStructureStatus, FeeStructureStatus[]> = {
  DRAFT: ['ACTIVE', 'ARCHIVED'],
  ACTIVE: ['INACTIVE', 'ARCHIVED'],
  INACTIVE: ['ACTIVE', 'ARCHIVED'],
  ARCHIVED: ['DRAFT', 'INACTIVE']
};

const VALID_FREQUENCIES: FeeFrequency[] = [
  'ONE_TIME',
  'MONTHLY',
  'QUARTERLY',
  'HALF_YEARLY',
  'YEARLY',
  'CUSTOM'
];

const VALID_FEE_CATEGORIES: FeeCategory[] = ['MANDATORY', 'OPTIONAL'];

const VALID_TYPE_CATEGORIES: FeeTypeCategory[] = [
  'ACADEMIC',
  'FACILITY',
  'TRANSPORT',
  'HOSTEL',
  'MISCELLANEOUS',
  'ADMINISTRATIVE',
  'EXTRACURRICULAR'
];

// ============================================================================
// FEE TYPES ENDPOINTS
// ============================================================================

/**
 * GET /api/fees/types
 * List all configured fee types
 */
feesRouter.get('/types', (req: AuthenticatedRequest, res: Response) => {
  try {
    const { status, category, search } = req.query as {
      status?: string;
      category?: string;
      search?: string;
    };

    let types = [...(database.feeTypes || [])];

    if (status && status !== 'ALL') {
      types = types.filter((t) => t.status === status);
    }

    if (category && category !== 'ALL') {
      types = types.filter((t) => t.category === category);
    }

    if (search && search.trim()) {
      const q = search.trim().toLowerCase();
      types = types.filter(
        (t) =>
          t.name.toLowerCase().includes(q) ||
          t.code.toLowerCase().includes(q) ||
          (t.description && t.description.toLowerCase().includes(q))
      );
    }

    // Sort default types first, then alphabetically
    types.sort((a, b) => {
      if (a.isDefault && !b.isDefault) return -1;
      if (!a.isDefault && b.isDefault) return 1;
      return a.name.localeCompare(b.name);
    });

    res.json({
      success: true,
      data: types,
      total: types.length
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to retrieve fee types',
      code: 'SERVER_ERROR'
    });
  }
});

/**
 * GET /api/fees/types/:id
 * Get single fee type detail
 */
feesRouter.get('/types/:id', (req: AuthenticatedRequest, res: Response) => {
  try {
    const type = (database.feeTypes || []).find((t) => t.id === req.params.id);
    if (!type) {
      res.status(404).json({
        success: false,
        error: `Fee type with ID '${req.params.id}' not found`,
        code: 'NOT_FOUND'
      });
      return;
    }

    const linkedStructuresCount = (database.feeStructures || []).filter(
      (fs) => fs.feeTypeId === type.id && fs.status !== 'ARCHIVED'
    ).length;

    res.json({
      success: true,
      data: {
        ...type,
        linkedStructuresCount
      }
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to retrieve fee type',
      code: 'SERVER_ERROR'
    });
  }
});

/**
 * POST /api/fees/types
 * Create a new custom fee type (Super Admin / fees.types.manage)
 */
feesRouter.post(
  '/types',
  requirePermission('fees.types.manage'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const payload: CreateFeeTypePayload = req.body;

      if (!payload.name || typeof payload.name !== 'string' || payload.name.trim().length < 2) {
        res.status(400).json({
          success: false,
          error: 'Fee type name is required and must be at least 2 characters.',
          code: 'VALIDATION_ERROR'
        });
        return;
      }

      if (!payload.code || typeof payload.code !== 'string' || payload.code.trim().length < 2) {
        res.status(400).json({
          success: false,
          error: 'Fee type code is required and must be at least 2 characters (e.g. LAB_FEE).',
          code: 'VALIDATION_ERROR'
        });
        return;
      }

      const trimmedName = payload.name.trim();
      const formattedCode = payload.code
        .trim()
        .toUpperCase()
        .replace(/[^A-Z0-9_]/g, '_');

      if (!VALID_TYPE_CATEGORIES.includes(payload.category)) {
        res.status(400).json({
          success: false,
          error: `Invalid category. Must be one of: ${VALID_TYPE_CATEGORIES.join(', ')}`,
          code: 'VALIDATION_ERROR'
        });
        return;
      }

      // Check for duplicate name or code
      const duplicateName = (database.feeTypes || []).find(
        (t) => t.name.toLowerCase() === trimmedName.toLowerCase()
      );
      if (duplicateName) {
        res.status(400).json({
          success: false,
          error: `A fee type with the name '${trimmedName}' already exists.`,
          code: 'DUPLICATE_FEE_TYPE'
        });
        return;
      }

      const duplicateCode = (database.feeTypes || []).find(
        (t) => t.code.toUpperCase() === formattedCode
      );
      if (duplicateCode) {
        res.status(400).json({
          success: false,
          error: `A fee type with the code '${formattedCode}' already exists.`,
          code: 'DUPLICATE_FEE_CODE'
        });
        return;
      }

      const now = new Date().toISOString();
      const newFeeType: FeeType = {
        id: `feetype-custom-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        name: trimmedName,
        code: formattedCode,
        category: payload.category,
        description: payload.description?.trim() || '',
        isDefault: false,
        status: payload.status === 'INACTIVE' ? 'INACTIVE' : 'ACTIVE',
        createdAt: now,
        updatedAt: now,
        createdBy: req.user?.id,
        updatedBy: req.user?.id
      };

      if (!database.feeTypes) {
        database.feeTypes = [];
      }
      database.feeTypes.push(newFeeType);

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'CREATE',
        entity: 'FEE_TYPE',
        entityId: newFeeType.id,
        details: `Created new fee type '${newFeeType.name}' (${newFeeType.code}) in category '${newFeeType.category}'.`,
        metadata: { feeType: newFeeType }
      });

      res.status(201).json({
        success: true,
        message: `Fee type '${newFeeType.name}' created successfully.`,
        data: newFeeType
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to create fee type',
        code: 'SERVER_ERROR'
      });
    }
  }
);

/**
 * PUT /api/fees/types/:id
 * Update an existing fee type
 */
feesRouter.put(
  '/types/:id',
  requirePermission('fees.types.manage'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const typeIndex = (database.feeTypes || []).findIndex((t) => t.id === req.params.id);
      if (typeIndex === -1) {
        res.status(404).json({
          success: false,
          error: `Fee type with ID '${req.params.id}' not found`,
          code: 'NOT_FOUND'
        });
        return;
      }

      const existing = database.feeTypes[typeIndex];
      const payload: UpdateFeeTypePayload = req.body;

      if (payload.name !== undefined) {
        if (typeof payload.name !== 'string' || payload.name.trim().length < 2) {
          res.status(400).json({
            success: false,
            error: 'Fee type name must be at least 2 characters.',
            code: 'VALIDATION_ERROR'
          });
          return;
        }

        const duplicate = (database.feeTypes || []).find(
          (t) => t.id !== existing.id && t.name.toLowerCase() === payload.name!.trim().toLowerCase()
        );
        if (duplicate) {
          res.status(400).json({
            success: false,
            error: `Another fee type with name '${payload.name.trim()}' already exists.`,
            code: 'DUPLICATE_FEE_TYPE'
          });
          return;
        }
      }

      if (payload.code !== undefined && !existing.isDefault) {
        const formattedCode = payload.code.trim().toUpperCase().replace(/[^A-Z0-9_]/g, '_');
        const duplicateCode = (database.feeTypes || []).find(
          (t) => t.id !== existing.id && t.code.toUpperCase() === formattedCode
        );
        if (duplicateCode) {
          res.status(400).json({
            success: false,
            error: `Another fee type with code '${formattedCode}' already exists.`,
            code: 'DUPLICATE_FEE_CODE'
          });
          return;
        }
      }

      if (payload.category !== undefined && !VALID_TYPE_CATEGORIES.includes(payload.category)) {
        res.status(400).json({
          success: false,
          error: `Invalid category. Must be one of: ${VALID_TYPE_CATEGORIES.join(', ')}`,
          code: 'VALIDATION_ERROR'
        });
        return;
      }

      const updated: FeeType = {
        ...existing,
        name: payload.name !== undefined ? payload.name.trim() : existing.name,
        code:
          payload.code !== undefined && !existing.isDefault
            ? payload.code.trim().toUpperCase().replace(/[^A-Z0-9_]/g, '_')
            : existing.code,
        category: payload.category !== undefined ? payload.category : existing.category,
        description: payload.description !== undefined ? payload.description.trim() : existing.description,
        status: payload.status !== undefined ? payload.status : existing.status,
        updatedAt: new Date().toISOString(),
        updatedBy: req.user?.id
      };

      database.feeTypes[typeIndex] = updated;

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'UPDATE',
        entity: 'FEE_TYPE',
        entityId: updated.id,
        details: `Updated fee type '${updated.name}' (${updated.code}).`,
        metadata: { previous: existing, updated }
      });

      res.json({
        success: true,
        message: `Fee type '${updated.name}' updated successfully.`,
        data: updated
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to update fee type',
        code: 'SERVER_ERROR'
      });
    }
  }
);

/**
 * PATCH /api/fees/types/:id/status
 * Toggle fee type status (ACTIVE / INACTIVE)
 */
feesRouter.patch(
  '/types/:id/status',
  requirePermission('fees.types.manage'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const { status } = req.body as { status: FeeTypeStatus };
      if (!['ACTIVE', 'INACTIVE'].includes(status)) {
        res.status(400).json({
          success: false,
          error: "Status must be 'ACTIVE' or 'INACTIVE'.",
          code: 'VALIDATION_ERROR'
        });
        return;
      }

      const typeIndex = (database.feeTypes || []).findIndex((t) => t.id === req.params.id);
      if (typeIndex === -1) {
        res.status(404).json({
          success: false,
          error: `Fee type with ID '${req.params.id}' not found`,
          code: 'NOT_FOUND'
        });
        return;
      }

      const existing = database.feeTypes[typeIndex];

      const activeStructuresCount = (database.feeStructures || []).filter(
        (fs) => fs.feeTypeId === existing.id && fs.status === 'ACTIVE'
      ).length;

      const updated: FeeType = {
        ...existing,
        status,
        updatedAt: new Date().toISOString(),
        updatedBy: req.user?.id
      };

      database.feeTypes[typeIndex] = updated;

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'UPDATE',
        entity: 'FEE_TYPE',
        entityId: updated.id,
        details: `Changed fee type '${updated.name}' status from ${existing.status} to ${status}.${
          status === 'INACTIVE' && activeStructuresCount > 0
            ? ` Note: ${activeStructuresCount} active fee structures currently reference this type.`
            : ''
        }`,
        metadata: { previousStatus: existing.status, newStatus: status, activeStructuresCount }
      });

      res.json({
        success: true,
        message: `Fee type '${updated.name}' status set to ${status}.`,
        data: updated,
        activeStructuresCount
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to update fee type status',
        code: 'SERVER_ERROR'
      });
    }
  }
);

/**
 * DELETE /api/fees/types/:id
 * Delete custom fee type (Super Admin only, default fee types cannot be deleted)
 */
feesRouter.delete(
  '/types/:id',
  requirePermission('fees.types.manage'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const typeIndex = (database.feeTypes || []).findIndex((t) => t.id === req.params.id);
      if (typeIndex === -1) {
        res.status(404).json({
          success: false,
          error: `Fee type with ID '${req.params.id}' not found`,
          code: 'NOT_FOUND'
        });
        return;
      }

      const targetType = database.feeTypes[typeIndex];

      if (targetType.isDefault) {
        res.status(400).json({
          success: false,
          error: `Cannot delete system default fee type '${targetType.name}'. You can set its status to INACTIVE instead.`,
          code: 'SYSTEM_TYPE_PROTECTED'
        });
        return;
      }

      const linkedStructures = (database.feeStructures || []).filter(
        (fs) => fs.feeTypeId === targetType.id
      );

      if (linkedStructures.length > 0) {
        res.status(400).json({
          success: false,
          error: `Cannot delete fee type '${targetType.name}' because ${linkedStructures.length} fee structure(s) are linked to it. Please reassign or remove those structures first.`,
          code: 'FEE_TYPE_IN_USE'
        });
        return;
      }

      database.feeTypes.splice(typeIndex, 1);

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'DELETE',
        entity: 'FEE_TYPE',
        entityId: targetType.id,
        details: `Deleted custom fee type '${targetType.name}' (${targetType.code}).`,
        metadata: { deletedType: targetType }
      });

      res.json({
        success: true,
        message: `Custom fee type '${targetType.name}' deleted successfully.`
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to delete fee type',
        code: 'SERVER_ERROR'
      });
    }
  }
);

// ============================================================================
// FEE STRUCTURES ENDPOINTS
// ============================================================================

/**
 * GET /api/fees/structures/stats
 * Aggregate overview statistics for fee structures
 */
feesRouter.get('/structures/stats', (req: AuthenticatedRequest, res: Response) => {
  try {
    const structures = database.feeStructures || [];
    const types = database.feeTypes || [];

    const stats: FeeStructureSummaryStats = {
      totalStructures: structures.length,
      activeStructures: structures.filter((s) => s.status === 'ACTIVE').length,
      draftStructures: structures.filter((s) => s.status === 'DRAFT').length,
      inactiveStructures: structures.filter((s) => s.status === 'INACTIVE').length,
      archivedStructures: structures.filter((s) => s.status === 'ARCHIVED').length,
      totalFeeTypes: types.length,
      mandatoryCount: structures.filter((s) => s.isMandatory || s.feeCategory === 'MANDATORY').length,
      optionalCount: structures.filter((s) => !s.isMandatory || s.feeCategory === 'OPTIONAL').length,
      totalAnnualValueEstimate: structures
        .filter((s) => s.status === 'ACTIVE')
        .reduce((sum, s) => {
          let multiplier = 1;
          if (s.frequency === 'MONTHLY') multiplier = 10;
          else if (s.frequency === 'QUARTERLY') multiplier = 4;
          else if (s.frequency === 'HALF_YEARLY') multiplier = 2;
          else if (s.frequency === 'YEARLY' || s.frequency === 'ONE_TIME' || s.frequency === 'CUSTOM') multiplier = 1;
          return sum + s.amount * multiplier;
        }, 0)
    };

    res.json({
      success: true,
      data: stats
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to calculate fee structure stats',
      code: 'SERVER_ERROR'
    });
  }
});

/**
 * GET /api/fees/structures
 * List fee structures with multi-field filtering, search, and pagination
 */
feesRouter.get('/structures', (req: AuthenticatedRequest, res: Response) => {
  try {
    const {
      academicSessionId,
      classId,
      sectionId,
      feeTypeId,
      status,
      feeCategory,
      frequency,
      search,
      page = '1',
      limit = '50'
    } = req.query as Record<string, string>;

    let list = [...(database.feeStructures || [])];

    if (academicSessionId && academicSessionId !== 'ALL') {
      list = list.filter((s) => s.academicSessionId === academicSessionId);
    }

    if (classId && classId !== 'ALL') {
      list = list.filter((s) => s.classId === classId);
    }

    if (sectionId && sectionId !== 'ALL') {
      if (sectionId === 'ALL_SECTIONS') {
        list = list.filter((s) => s.applicableToAllSections || !s.sectionId);
      } else {
        list = list.filter((s) => s.sectionId === sectionId || s.applicableToAllSections);
      }
    }

    if (feeTypeId && feeTypeId !== 'ALL') {
      list = list.filter((s) => s.feeTypeId === feeTypeId);
    }

    if (status && status !== 'ALL') {
      list = list.filter((s) => s.status === status);
    }

    if (feeCategory && feeCategory !== 'ALL') {
      list = list.filter(
        (s) =>
          s.feeCategory === feeCategory ||
          (feeCategory === 'MANDATORY' && s.isMandatory) ||
          (feeCategory === 'OPTIONAL' && !s.isMandatory)
      );
    }

    if (frequency && frequency !== 'ALL') {
      list = list.filter((s) => s.frequency === frequency);
    }

    if (search && search.trim()) {
      const q = search.trim().toLowerCase();
      list = list.filter(
        (s) =>
          s.name.toLowerCase().includes(q) ||
          s.feeTypeName.toLowerCase().includes(q) ||
          s.className.toLowerCase().includes(q) ||
          (s.sectionName && s.sectionName.toLowerCase().includes(q)) ||
          s.academicSessionName.toLowerCase().includes(q) ||
          (s.description && s.description.toLowerCase().includes(q))
      );
    }

    // Default sorting: Active & Draft first, then by class display order / name, then newest
    list.sort((a, b) => {
      const statusOrder: Record<FeeStructureStatus, number> = {
        ACTIVE: 1,
        DRAFT: 2,
        INACTIVE: 3,
        ARCHIVED: 4
      };
      if (statusOrder[a.status] !== statusOrder[b.status]) {
        return statusOrder[a.status] - statusOrder[b.status];
      }
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });

    const pageNum = Math.max(1, parseInt(page, 10) || 1);
    const limitNum = Math.max(1, Math.min(200, parseInt(limit, 10) || 50));
    const total = list.length;
    const startIndex = (pageNum - 1) * limitNum;
    const paginatedData = list.slice(startIndex, startIndex + limitNum);

    res.json({
      success: true,
      data: paginatedData,
      total,
      page: pageNum,
      limit: limitNum,
      totalPages: Math.ceil(total / limitNum)
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to fetch fee structures',
      code: 'SERVER_ERROR'
    });
  }
});

/**
 * GET /api/fees/structures/:id
 * Get single fee structure details
 */
feesRouter.get('/structures/:id', (req: AuthenticatedRequest, res: Response) => {
  try {
    const structure = (database.feeStructures || []).find((s) => s.id === req.params.id);
    if (!structure) {
      res.status(404).json({
        success: false,
        error: `Fee structure with ID '${req.params.id}' not found`,
        code: 'NOT_FOUND'
      });
      return;
    }

    const feeType = (database.feeTypes || []).find((t) => t.id === structure.feeTypeId);
    const academicSession = (database.academicSessions || []).find((s) => s.id === structure.academicSessionId);
    const schoolClass = (database.classes || []).find((c) => c.id === structure.classId);
    const section = structure.sectionId
      ? (database.sections || []).find((sec) => sec.id === structure.sectionId)
      : null;

    res.json({
      success: true,
      data: {
        ...structure,
        feeTypeDetails: feeType || null,
        academicSessionDetails: academicSession || null,
        classDetails: schoolClass || null,
        sectionDetails: section || null
      }
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to retrieve fee structure',
      code: 'SERVER_ERROR'
    });
  }
});

/**
 * POST /api/fees/structures
 * Create a new fee structure (Super Admin / fees.structure.manage)
 */
feesRouter.post(
  '/structures',
  requirePermission('fees.structure.manage'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const payload: CreateFeeStructurePayload = req.body;

      // 1. Validate Fee Name
      if (!payload.name || typeof payload.name !== 'string' || payload.name.trim().length < 3) {
        res.status(400).json({
          success: false,
          error: 'Fee structure name is required and must be at least 3 characters.',
          code: 'VALIDATION_ERROR'
        });
        return;
      }
      const trimmedName = payload.name.trim();

      // 2. Validate Amount
      if (
        payload.amount === undefined ||
        payload.amount === null ||
        typeof payload.amount !== 'number' ||
        isNaN(payload.amount) ||
        payload.amount < 0
      ) {
        res.status(400).json({
          success: false,
          error: 'Fee amount must be a valid non-negative number (0 or greater).',
          code: 'INVALID_AMOUNT'
        });
        return;
      }

      // 3. Validate Due Date
      if (!payload.dueDate || !isValidDateString(payload.dueDate)) {
        res.status(400).json({
          success: false,
          error: 'Due date is required and must be a valid date in YYYY-MM-DD format.',
          code: 'INVALID_DUE_DATE'
        });
        return;
      }

      // 4. Validate Frequency
      if (!payload.frequency || !VALID_FREQUENCIES.includes(payload.frequency)) {
        res.status(400).json({
          success: false,
          error: `Frequency is required and must be one of: ${VALID_FREQUENCIES.join(', ')}`,
          code: 'INVALID_FREQUENCY'
        });
        return;
      }

      // 5. Validate Academic Session
      const session = (database.academicSessions || []).find(
        (s) => s.id === payload.academicSessionId
      );
      if (!session) {
        res.status(400).json({
          success: false,
          error: `Academic Session '${payload.academicSessionId}' does not exist.`,
          code: 'INVALID_ACADEMIC_SESSION'
        });
        return;
      }

      // 6. Validate Class
      const schoolClass = (database.classes || []).find((c) => c.id === payload.classId);
      if (!schoolClass) {
        res.status(400).json({
          success: false,
          error: `Class '${payload.classId}' does not exist.`,
          code: 'INVALID_CLASS'
        });
        return;
      }

      // 7. Validate Section where applicable
      let sectionName: string | null = null;
      let sectionId: string | null = null;
      const applicableToAllSections = payload.applicableToAllSections !== false && !payload.sectionId;

      if (!applicableToAllSections && payload.sectionId) {
        const sec = (database.sections || []).find((s) => s.id === payload.sectionId);
        if (!sec) {
          res.status(400).json({
            success: false,
            error: `Section '${payload.sectionId}' does not exist.`,
            code: 'INVALID_SECTION'
          });
          return;
        }

        // Verify section belongs to class
        if (schoolClass.sectionIds && !schoolClass.sectionIds.includes(sec.id)) {
          res.status(400).json({
            success: false,
            error: `Section '${sec.name}' (${sec.id}) does not belong to Class '${schoolClass.name}'.`,
            code: 'SECTION_CLASS_MISMATCH'
          });
          return;
        }

        sectionId = sec.id;
        sectionName = sec.name;
      }

      // 8. Validate Fee Type
      const feeType = (database.feeTypes || []).find((t) => t.id === payload.feeTypeId);
      if (!feeType) {
        res.status(400).json({
          success: false,
          error: `Fee Type '${payload.feeTypeId}' does not exist.`,
          code: 'INVALID_FEE_TYPE'
        });
        return;
      }

      if (feeType.status === 'INACTIVE') {
        res.status(400).json({
          success: false,
          error: `Fee Type '${feeType.name}' is currently INACTIVE. Please activate the fee type first.`,
          code: 'FEE_TYPE_INACTIVE'
        });
        return;
      }

      // 9. Prevent Duplicate Fee Structures
      const duplicate = (database.feeStructures || []).find((s) => {
        if (s.status === 'ARCHIVED') return false;
        const sameSession = s.academicSessionId === session.id;
        const sameClass = s.classId === schoolClass.id;
        const sameSection =
          (applicableToAllSections && s.applicableToAllSections) ||
          (!applicableToAllSections && !s.applicableToAllSections && s.sectionId === sectionId);
        const sameType = s.feeTypeId === feeType.id;
        const sameName = s.name.toLowerCase().trim() === trimmedName.toLowerCase();
        return sameSession && sameClass && sameSection && sameType && sameName;
      });

      if (duplicate) {
        res.status(400).json({
          success: false,
          error: `A fee structure '${trimmedName}' already exists for ${schoolClass.name} in ${session.sessionName} with Fee Type '${feeType.name}'.`,
          code: 'DUPLICATE_FEE_STRUCTURE'
        });
        return;
      }

      // 10. Fee Category & Mandatory determination
      const isMandatory =
        payload.isMandatory !== undefined
          ? !!payload.isMandatory
          : payload.feeCategory === 'OPTIONAL'
          ? false
          : true;
      const feeCategory: FeeCategory = isMandatory ? 'MANDATORY' : 'OPTIONAL';

      // 11. Initial Status
      const initialStatus: FeeStructureStatus =
        payload.status && ['DRAFT', 'ACTIVE'].includes(payload.status)
          ? payload.status
          : 'ACTIVE';

      const now = new Date().toISOString();
      const newStructure: FeeStructure = {
        id: `feestruct-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        name: trimmedName,
        feeTypeId: feeType.id,
        feeTypeName: feeType.name,
        feeTypeCode: feeType.code,
        academicSessionId: session.id,
        academicSessionName: session.sessionName,
        classId: schoolClass.id,
        className: schoolClass.name,
        sectionId: sectionId,
        sectionName: sectionName,
        applicableToAllSections,
        amount: payload.amount,
        currency: payload.currency || database.schoolSettings?.currency || 'USD',
        frequency: payload.frequency,
        dueDate: payload.dueDate,
        isMandatory,
        feeCategory,
        status: initialStatus,
        description: payload.description?.trim() || '',
        notes: payload.notes?.trim() || '',
        createdAt: now,
        updatedAt: now,
        createdBy: req.user?.id,
        updatedBy: req.user?.id
      };

      if (!database.feeStructures) {
        database.feeStructures = [];
      }
      database.feeStructures.push(newStructure);

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'CREATE',
        entity: 'FEE_STRUCTURE',
        entityId: newStructure.id,
        details: `Created ${newStructure.feeCategory} fee structure '${newStructure.name}' for ${newStructure.className} (${newStructure.amount} ${newStructure.currency}, Frequency: ${newStructure.frequency}).`,
        metadata: { feeStructure: newStructure }
      });

      res.status(201).json({
        success: true,
        message: `Fee structure '${newStructure.name}' created successfully.`,
        data: newStructure
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to create fee structure',
        code: 'SERVER_ERROR'
      });
    }
  }
);

/**
 * PUT /api/fees/structures/:id
 * Update an existing fee structure
 */
feesRouter.put(
  '/structures/:id',
  requirePermission('fees.structure.manage'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const structIndex = (database.feeStructures || []).findIndex(
        (s) => s.id === req.params.id
      );
      if (structIndex === -1) {
        res.status(404).json({
          success: false,
          error: `Fee structure with ID '${req.params.id}' not found`,
          code: 'NOT_FOUND'
        });
        return;
      }

      const existing = database.feeStructures[structIndex];

      if (existing.status === 'ARCHIVED') {
        res.status(400).json({
          success: false,
          error: 'Archived fee structures cannot be edited. Please restore the structure first.',
          code: 'ARCHIVED_IMMUTABLE'
        });
        return;
      }

      const payload: UpdateFeeStructurePayload = req.body;

      // Validate Name if provided
      let name = existing.name;
      if (payload.name !== undefined) {
        if (typeof payload.name !== 'string' || payload.name.trim().length < 3) {
          res.status(400).json({
            success: false,
            error: 'Fee structure name must be at least 3 characters.',
            code: 'VALIDATION_ERROR'
          });
          return;
        }
        name = payload.name.trim();
      }

      // Validate Amount if provided
      let amount = existing.amount;
      if (payload.amount !== undefined) {
        if (
          typeof payload.amount !== 'number' ||
          isNaN(payload.amount) ||
          payload.amount < 0
        ) {
          res.status(400).json({
            success: false,
            error: 'Fee amount must be a valid non-negative number (0 or greater).',
            code: 'INVALID_AMOUNT'
          });
          return;
        }
        amount = payload.amount;
      }

      // Validate Due Date if provided
      let dueDate = existing.dueDate;
      if (payload.dueDate !== undefined) {
        if (!isValidDateString(payload.dueDate)) {
          res.status(400).json({
            success: false,
            error: 'Due date must be a valid date in YYYY-MM-DD format.',
            code: 'INVALID_DUE_DATE'
          });
          return;
        }
        dueDate = payload.dueDate;
      }

      // Validate Frequency if provided
      let frequency = existing.frequency;
      if (payload.frequency !== undefined) {
        if (!VALID_FREQUENCIES.includes(payload.frequency)) {
          res.status(400).json({
            success: false,
            error: `Frequency must be one of: ${VALID_FREQUENCIES.join(', ')}`,
            code: 'INVALID_FREQUENCY'
          });
          return;
        }
        frequency = payload.frequency;
      }

      // Validate Session if provided
      let academicSessionId = existing.academicSessionId;
      let academicSessionName = existing.academicSessionName;
      if (payload.academicSessionId !== undefined) {
        const sess = (database.academicSessions || []).find((s) => s.id === payload.academicSessionId);
        if (!sess) {
          res.status(400).json({
            success: false,
            error: `Academic Session '${payload.academicSessionId}' does not exist.`,
            code: 'INVALID_ACADEMIC_SESSION'
          });
          return;
        }
        academicSessionId = sess.id;
        academicSessionName = sess.sessionName;
      }

      // Validate Class & Section if provided
      let classId = existing.classId;
      let className = existing.className;
      let sectionId = existing.sectionId;
      let sectionName = existing.sectionName;
      let applicableToAllSections = existing.applicableToAllSections;

      if (payload.classId !== undefined) {
        const cls = (database.classes || []).find((c) => c.id === payload.classId);
        if (!cls) {
          res.status(400).json({
            success: false,
            error: `Class '${payload.classId}' does not exist.`,
            code: 'INVALID_CLASS'
          });
          return;
        }
        classId = cls.id;
        className = cls.name;
      }

      if (payload.applicableToAllSections !== undefined || payload.sectionId !== undefined) {
        applicableToAllSections = payload.applicableToAllSections !== false && !payload.sectionId;
        if (applicableToAllSections) {
          sectionId = null;
          sectionName = null;
        } else if (payload.sectionId) {
          const sec = (database.sections || []).find((s) => s.id === payload.sectionId);
          if (!sec) {
            res.status(400).json({
              success: false,
              error: `Section '${payload.sectionId}' does not exist.`,
              code: 'INVALID_SECTION'
            });
            return;
          }
          const currentClass = (database.classes || []).find((c) => c.id === classId);
          if (currentClass?.sectionIds && !currentClass.sectionIds.includes(sec.id)) {
            res.status(400).json({
              success: false,
              error: `Section '${sec.name}' does not belong to Class '${className}'.`,
              code: 'SECTION_CLASS_MISMATCH'
            });
            return;
          }
          sectionId = sec.id;
          sectionName = sec.name;
        }
      }

      // Validate Fee Type if provided
      let feeTypeId = existing.feeTypeId;
      let feeTypeName = existing.feeTypeName;
      let feeTypeCode = existing.feeTypeCode;
      if (payload.feeTypeId !== undefined) {
        const ft = (database.feeTypes || []).find((t) => t.id === payload.feeTypeId);
        if (!ft) {
          res.status(400).json({
            success: false,
            error: `Fee Type '${payload.feeTypeId}' does not exist.`,
            code: 'INVALID_FEE_TYPE'
          });
          return;
        }
        if (ft.status === 'INACTIVE' && ft.id !== existing.feeTypeId) {
          res.status(400).json({
            success: false,
            error: `Fee Type '${ft.name}' is INACTIVE.`,
            code: 'FEE_TYPE_INACTIVE'
          });
          return;
        }
        feeTypeId = ft.id;
        feeTypeName = ft.name;
        feeTypeCode = ft.code;
      }

      // Duplicate Check excluding current record
      const duplicate = (database.feeStructures || []).find((s) => {
        if (s.id === existing.id || s.status === 'ARCHIVED') return false;
        const sameSession = s.academicSessionId === academicSessionId;
        const sameClass = s.classId === classId;
        const sameSection =
          (applicableToAllSections && s.applicableToAllSections) ||
          (!applicableToAllSections && !s.applicableToAllSections && s.sectionId === sectionId);
        const sameType = s.feeTypeId === feeTypeId;
        const sameName = s.name.toLowerCase().trim() === name.toLowerCase();
        return sameSession && sameClass && sameSection && sameType && sameName;
      });

      if (duplicate) {
        res.status(400).json({
          success: false,
          error: `Another fee structure '${name}' already exists with identical session, class, and fee type.`,
          code: 'DUPLICATE_FEE_STRUCTURE'
        });
        return;
      }

      // Mandatory / Optional handling
      let isMandatory = existing.isMandatory;
      let feeCategory = existing.feeCategory;
      if (payload.isMandatory !== undefined) {
        isMandatory = !!payload.isMandatory;
        feeCategory = isMandatory ? 'MANDATORY' : 'OPTIONAL';
      } else if (payload.feeCategory !== undefined) {
        feeCategory = payload.feeCategory;
        isMandatory = feeCategory === 'MANDATORY';
      }

      // Status transition validation if status is changing
      let status: FeeStructureStatus = existing.status;
      if (payload.status !== undefined && payload.status !== existing.status) {
        const allowedTransitions = VALID_FEE_STRUCTURE_TRANSITIONS[existing.status] || [];
        if (!allowedTransitions.includes(payload.status)) {
          res.status(400).json({
            success: false,
            error: `Invalid status transition from '${existing.status}' to '${payload.status}'. Allowed transitions: ${allowedTransitions.join(', ') || 'None'}`,
            code: 'INVALID_STATUS_TRANSITION'
          });
          return;
        }
        status = payload.status;
      }

      const updated: FeeStructure = {
        ...existing,
        name,
        feeTypeId,
        feeTypeName,
        feeTypeCode,
        academicSessionId,
        academicSessionName,
        classId,
        className,
        sectionId,
        sectionName,
        applicableToAllSections,
        amount,
        currency: payload.currency || existing.currency,
        frequency,
        dueDate,
        isMandatory,
        feeCategory,
        status,
        description: payload.description !== undefined ? payload.description.trim() : existing.description,
        notes: payload.notes !== undefined ? payload.notes.trim() : existing.notes,
        updatedAt: new Date().toISOString(),
        updatedBy: req.user?.id
      };

      database.feeStructures[structIndex] = updated;

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'UPDATE',
        entity: 'FEE_STRUCTURE',
        entityId: updated.id,
        details: `Updated fee structure '${updated.name}' (Amount: ${updated.amount} ${updated.currency}, Status: ${updated.status}).`,
        metadata: { previous: existing, updated }
      });

      res.json({
        success: true,
        message: `Fee structure '${updated.name}' updated successfully.`,
        data: updated
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to update fee structure',
        code: 'SERVER_ERROR'
      });
    }
  }
);

/**
 * PATCH /api/fees/structures/:id/status
 * State machine transition for fee structure status (DRAFT -> ACTIVE -> INACTIVE -> ARCHIVED)
 */
feesRouter.patch(
  '/structures/:id/status',
  requirePermission('fees.structure.manage'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const { status } = req.body as { status: FeeStructureStatus };
      if (!['DRAFT', 'ACTIVE', 'INACTIVE', 'ARCHIVED'].includes(status)) {
        res.status(400).json({
          success: false,
          error: "Status must be 'DRAFT', 'ACTIVE', 'INACTIVE', or 'ARCHIVED'.",
          code: 'VALIDATION_ERROR'
        });
        return;
      }

      const structIndex = (database.feeStructures || []).findIndex(
        (s) => s.id === req.params.id
      );
      if (structIndex === -1) {
        res.status(404).json({
          success: false,
          error: `Fee structure with ID '${req.params.id}' not found`,
          code: 'NOT_FOUND'
        });
        return;
      }

      const existing = database.feeStructures[structIndex];

      if (existing.status === status) {
        res.json({
          success: true,
          message: `Fee structure is already in ${status} status.`,
          data: existing
        });
        return;
      }

      const allowedTransitions = VALID_FEE_STRUCTURE_TRANSITIONS[existing.status] || [];
      if (!allowedTransitions.includes(status)) {
        res.status(400).json({
          success: false,
          error: `Cannot transition fee structure from '${existing.status}' to '${status}'. Allowed transitions: ${allowedTransitions.join(', ') || 'None'}`,
          code: 'INVALID_STATUS_TRANSITION'
        });
        return;
      }

      // If activating, verify that the underlying fee type is ACTIVE
      if (status === 'ACTIVE') {
        const feeType = (database.feeTypes || []).find((t) => t.id === existing.feeTypeId);
        if (feeType && feeType.status === 'INACTIVE') {
          res.status(400).json({
            success: false,
            error: `Cannot activate fee structure because fee type '${feeType.name}' is INACTIVE. Please activate the fee type first.`,
            code: 'FEE_TYPE_INACTIVE'
          });
          return;
        }
      }

      const updated: FeeStructure = {
        ...existing,
        status,
        updatedAt: new Date().toISOString(),
        updatedBy: req.user?.id
      };

      database.feeStructures[structIndex] = updated;

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'UPDATE',
        entity: 'FEE_STRUCTURE',
        entityId: updated.id,
        details: `Transitioned fee structure '${updated.name}' status from ${existing.status} to ${status}.`,
        metadata: { previousStatus: existing.status, newStatus: status }
      });

      res.json({
        success: true,
        message: `Fee structure status transitioned to ${status}.`,
        data: updated
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to update fee structure status',
        code: 'SERVER_ERROR'
      });
    }
  }
);

/**
 * DELETE /api/fees/structures/:id
 * Delete a fee structure (Allowed for DRAFT or ARCHIVED structures only)
 */
feesRouter.delete(
  '/structures/:id',
  requirePermission('fees.structure.manage'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const structIndex = (database.feeStructures || []).findIndex(
        (s) => s.id === req.params.id
      );
      if (structIndex === -1) {
        res.status(404).json({
          success: false,
          error: `Fee structure with ID '${req.params.id}' not found`,
          code: 'NOT_FOUND'
        });
        return;
      }

      const target = database.feeStructures[structIndex];

      // Prevent hard deleting ACTIVE or INACTIVE fee structures directly
      if (target.status === 'ACTIVE' || target.status === 'INACTIVE') {
        res.status(400).json({
          success: false,
          error: `Cannot directly delete an ${target.status} fee structure. Please archive the fee structure first.`,
          code: 'ARCHIVE_REQUIRED_BEFORE_DELETE'
        });
        return;
      }

      database.feeStructures.splice(structIndex, 1);

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'DELETE',
        entity: 'FEE_STRUCTURE',
        entityId: target.id,
        details: `Deleted ${target.status} fee structure '${target.name}'.`,
        metadata: { deletedStructure: target }
      });

      res.json({
        success: true,
        message: `Fee structure '${target.name}' deleted successfully.`
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to delete fee structure',
        code: 'SERVER_ERROR'
      });
    }
  }
);

/**
 * POST /api/fees/structures/batch-status
 * Batch status update for fee structures
 */
feesRouter.post(
  '/structures/batch-status',
  requirePermission('fees.structure.manage'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const { ids, status } = req.body as { ids: string[]; status: FeeStructureStatus };

      if (!Array.isArray(ids) || ids.length === 0) {
        res.status(400).json({
          success: false,
          error: 'An array of fee structure IDs is required.',
          code: 'VALIDATION_ERROR'
        });
        return;
      }

      if (!['DRAFT', 'ACTIVE', 'INACTIVE', 'ARCHIVED'].includes(status)) {
        res.status(400).json({
          success: false,
          error: "Status must be 'DRAFT', 'ACTIVE', 'INACTIVE', or 'ARCHIVED'.",
          code: 'VALIDATION_ERROR'
        });
        return;
      }

      const results = {
        updated: [] as string[],
        skipped: [] as { id: string; reason: string }[]
      };

      for (const id of ids) {
        const structIndex = (database.feeStructures || []).findIndex((s) => s.id === id);
        if (structIndex === -1) {
          results.skipped.push({ id, reason: 'Not found' });
          continue;
        }

        const existing = database.feeStructures[structIndex];
        if (existing.status === status) {
          continue;
        }

        const allowedTransitions = VALID_FEE_STRUCTURE_TRANSITIONS[existing.status] || [];
        if (!allowedTransitions.includes(status)) {
          results.skipped.push({
            id,
            reason: `Illegal transition from ${existing.status} to ${status}`
          });
          continue;
        }

        database.feeStructures[structIndex] = {
          ...existing,
          status,
          updatedAt: new Date().toISOString(),
          updatedBy: req.user?.id
        };
        results.updated.push(id);
      }

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'UPDATE',
        entity: 'FEE_STRUCTURE',
        details: `Batch status update to ${status} for ${results.updated.length} fee structure(s).`,
        metadata: { results }
      });

      res.json({
        success: true,
        message: `Successfully updated ${results.updated.length} fee structures to ${status}.`,
        data: results
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to batch update fee structure status',
        code: 'SERVER_ERROR'
      });
    }
  }
);

// ============================================================================
// PART 7B: STUDENT FEE ASSIGNMENT & INVOICE MANAGEMENT ENDPOINTS
// ============================================================================

/**
 * Helper: Generate unique invoice number with collision prevention
 */
function generateUniqueInvoiceNumber(): string {
  const year = new Date().getFullYear();
  let invoiceNumber = '';
  let isUnique = false;
  let attempts = 0;
  while (!isUnique && attempts < 1000) {
    attempts++;
    const rand = Math.floor(10000 + Math.random() * 90000);
    invoiceNumber = `INV-${year}-${rand}`;
    const exists = (database.feeRecords || []).some((r) => r.invoiceNumber === invoiceNumber);
    if (!exists) {
      isUnique = true;
    }
  }
  if (!isUnique) {
    invoiceNumber = `INV-${year}-${Date.now().toString().slice(-6)}`;
  }
  return invoiceNumber;
}

/**
 * Helper: Synchronize and normalize fee record calculations & status
 * Calculation order:
 * Original Fee Amount
 * − Discount Amount
 * − Scholarship Amount
 * − Waiver Amount
 * + Valid Late Fine Amount
 * = Net Payable Amount (min 0)
 * − Paid Amount
 * = Remaining Due Amount (min 0)
 */
function normalizeFeeCalculations(record: StudentFeeRecord): StudentFeeRecord {
  const totalAmount = Math.max(0, Number(record.totalAmount) || 0);
  const discountAmount = Math.max(0, Number(record.discountAmount) || 0);
  const scholarshipAmount = Math.max(0, Number(record.scholarshipAmount) || 0);
  const waiverAmount = Math.max(0, Number(record.waiverAmount) || 0);
  const fineAmount = Math.max(0, Number(record.fineAmount) || 0);
  const paidAmount = Math.max(0, Number(record.paidAmount) || 0);

  const totalDeductions = discountAmount + scholarshipAmount + waiverAmount;
  const grossNet = totalAmount - totalDeductions + fineAmount;
  const netPayableAmount = Math.max(0, Math.round(grossNet * 100) / 100);
  const dueAmount = Math.max(0, Math.round((netPayableAmount - paidAmount) * 100) / 100);

  let status: FeePaymentStatus = record.status;
  if (record.status !== 'CANCELLED' && record.status !== 'DRAFT') {
    if (dueAmount === 0 && (paidAmount > 0 || netPayableAmount === 0)) {
      status = 'PAID';
    } else if (paidAmount > 0 && dueAmount > 0) {
      status = 'PARTIAL';
    } else {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const dueDate = new Date(record.dueDate);
      if (!isNaN(dueDate.getTime()) && dueDate < today && dueAmount > 0) {
        status = 'OVERDUE';
      } else {
        status = 'DUE';
      }
    }
  }

  return {
    ...record,
    totalAmount,
    discountAmount,
    scholarshipAmount,
    waiverAmount,
    fineAmount,
    netPayableAmount,
    paidAmount,
    dueAmount,
    status
  };
}

/**
 * GET /api/fees/student-fees
 * Filterable, searchable, and paginated list of all student fee records with summary stats
 */
feesRouter.get('/student-fees', (req: AuthenticatedRequest, res: Response) => {
  try {
    const {
      academicSessionId,
      classId,
      sectionId,
      studentId,
      feeTypeId,
      feeStructureId,
      status,
      dueDateFrom,
      dueDateTo,
      search,
      page = '1',
      limit = '15'
    } = req.query as {
      academicSessionId?: string;
      classId?: string;
      sectionId?: string;
      studentId?: string;
      feeTypeId?: string;
      feeStructureId?: string;
      status?: string;
      dueDateFrom?: string;
      dueDateTo?: string;
      search?: string;
      page?: string;
      limit?: string;
    };

    if (!database.feeRecords) {
      database.feeRecords = [];
    }

    // Recalculate dynamic statuses & balances on real database records
    database.feeRecords = database.feeRecords.map(normalizeFeeCalculations);

    let records = [...database.feeRecords];

    const user = req.user!;
    if (user.role === 'STUDENT') {
      const studentProfile = (database.studentProfiles || []).find((s) => s.userId === user.id);
      if (!studentProfile) {
        records = [];
      } else {
        records = records.filter((r) => r.studentId === studentProfile.id);
      }
    } else if (user.role === 'GUARDIAN') {
      const guardian = (database.guardians || []).find((g) => g.userId === user.id);
      if (!guardian || !guardian.studentIds || guardian.studentIds.length === 0) {
        records = [];
      } else {
        records = records.filter((r) => guardian.studentIds.includes(r.studentId));
        if (studentId && studentId !== 'ALL' && !guardian.studentIds.includes(studentId)) {
          res.status(403).json({
            success: false,
            error: 'Access Denied: You are not authorized to view fee records for this student.',
            code: 'FORBIDDEN'
          });
          return;
        }
      }
    } else if (user.role !== 'SUPER_ADMIN') {
      if (!hasPermission(user.role, 'fees.view')) {
        res.status(403).json({
          success: false,
          error: 'Access Denied: Unauthorized to access financial records.',
          code: 'FORBIDDEN'
        });
        return;
      }
    }

    // Filter by Academic Session
    if (academicSessionId && academicSessionId !== 'ALL') {
      records = records.filter((r) => r.academicSessionId === academicSessionId);
    }

    // Filter by Class
    if (classId && classId !== 'ALL') {
      records = records.filter((r) => r.classId === classId);
    }

    // Filter by Section
    if (sectionId && sectionId !== 'ALL') {
      records = records.filter((r) => r.sectionId === sectionId);
    }

    // Filter by Student
    if (studentId && studentId !== 'ALL') {
      records = records.filter((r) => r.studentId === studentId);
    }

    // Filter by Fee Type
    if (feeTypeId && feeTypeId !== 'ALL') {
      records = records.filter((r) => {
        if (r.feeTypeId && r.feeTypeId === feeTypeId) return true;
        const ft = (database.feeTypes || []).find((t) => t.id === feeTypeId);
        return ft && r.feeType.toLowerCase() === ft.name.toLowerCase();
      });
    }

    // Filter by Fee Structure
    if (feeStructureId && feeStructureId !== 'ALL') {
      records = records.filter((r) => r.feeStructureId === feeStructureId);
    }

    // Filter by Status
    if (status && status !== 'ALL') {
      if (status === 'UNPAID' || status === 'DUE') {
        records = records.filter((r) => r.status === 'UNPAID' || r.status === 'DUE');
      } else if (status === 'PARTIAL' || status === 'PARTIALLY_PAID') {
        records = records.filter((r) => r.status === 'PARTIAL' || r.status === 'PARTIALLY_PAID');
      } else {
        records = records.filter((r) => r.status === status);
      }
    }

    // Filter by Due Date Range
    if (dueDateFrom) {
      records = records.filter((r) => r.dueDate >= dueDateFrom);
    }
    if (dueDateTo) {
      records = records.filter((r) => r.dueDate <= dueDateTo);
    }

    // Search query
    if (search && search.trim()) {
      const q = search.trim().toLowerCase();
      records = records.filter(
        (r) =>
          r.studentName.toLowerCase().includes(q) ||
          r.admissionNumber.toLowerCase().includes(q) ||
          r.invoiceNumber.toLowerCase().includes(q) ||
          r.title.toLowerCase().includes(q) ||
          r.feeType.toLowerCase().includes(q) ||
          r.className.toLowerCase().includes(q) ||
          (r.sectionName && r.sectionName.toLowerCase().includes(q))
      );
    }

    // Sort by createdAt desc / dueDate desc
    records.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    // Calculate aggregated statistics on matched records
    const studentsWithDues = new Set<string>();
    let totalAmount = 0;
    let totalDiscount = 0;
    let totalFine = 0;
    let totalNetPayable = 0;
    let totalPaid = 0;
    let totalDue = 0;
    let paidCount = 0;
    let unpaidCount = 0;
    let partialCount = 0;
    let overdueCount = 0;
    let draftCount = 0;
    let cancelledCount = 0;

    for (const r of records) {
      totalAmount += r.totalAmount || 0;
      totalDiscount += r.discountAmount || 0;
      totalFine += r.fineAmount || 0;
      totalNetPayable += r.netPayableAmount || 0;
      totalPaid += r.paidAmount || 0;
      totalDue += r.dueAmount || 0;

      if (r.dueAmount > 0 && r.status !== 'CANCELLED') {
        studentsWithDues.add(r.studentId);
      }

      if (r.status === 'PAID') paidCount++;
      else if (r.status === 'UNPAID' || r.status === 'DUE') unpaidCount++;
      else if (r.status === 'PARTIAL' || r.status === 'PARTIALLY_PAID') partialCount++;
      else if (r.status === 'OVERDUE') overdueCount++;
      else if (r.status === 'DRAFT') draftCount++;
      else if (r.status === 'CANCELLED') cancelledCount++;
    }

    const summary: StudentFeeSummaryStats = {
      totalInvoices: records.length,
      totalAmount,
      totalDiscount,
      totalFine,
      totalNetPayable,
      totalPaid,
      totalDue,
      paidCount,
      unpaidCount,
      partialCount,
      overdueCount,
      draftCount,
      cancelledCount,
      studentsWithDuesCount: studentsWithDues.size
    };

    // Pagination
    const pageNum = Math.max(1, parseInt(page, 10) || 1);
    const limitNum = Math.max(1, Math.min(100, parseInt(limit, 10) || 15));
    const total = records.length;
    const totalPages = Math.ceil(total / limitNum);
    const startIndex = (pageNum - 1) * limitNum;
    const paginatedData = records.slice(startIndex, startIndex + limitNum);

    res.json({
      success: true,
      data: paginatedData,
      total,
      summary,
      page: pageNum,
      limit: limitNum,
      totalPages
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to fetch student fees',
      code: 'SERVER_ERROR'
    });
  }
});

/**
 * GET /api/fees/student-fees/stats
 * Global student fees and invoice statistics
 */
feesRouter.get('/student-fees/stats', (req: AuthenticatedRequest, res: Response) => {
  try {
    const allRecords = (database.feeRecords || []).map(normalizeFeeCalculations);
    database.feeRecords = allRecords;

    const studentsWithDues = new Set<string>();
    let totalAmount = 0;
    let totalDiscount = 0;
    let totalFine = 0;
    let totalNetPayable = 0;
    let totalPaid = 0;
    let totalDue = 0;
    let paidCount = 0;
    let unpaidCount = 0;
    let partialCount = 0;
    let overdueCount = 0;
    let draftCount = 0;
    let cancelledCount = 0;

    for (const r of allRecords) {
      totalAmount += r.totalAmount || 0;
      totalDiscount += r.discountAmount || 0;
      totalFine += r.fineAmount || 0;
      totalNetPayable += r.netPayableAmount || 0;
      totalPaid += r.paidAmount || 0;
      totalDue += r.dueAmount || 0;

      if (r.dueAmount > 0 && r.status !== 'CANCELLED') {
        studentsWithDues.add(r.studentId);
      }

      if (r.status === 'PAID') paidCount++;
      else if (r.status === 'UNPAID' || r.status === 'DUE') unpaidCount++;
      else if (r.status === 'PARTIAL' || r.status === 'PARTIALLY_PAID') partialCount++;
      else if (r.status === 'OVERDUE') overdueCount++;
      else if (r.status === 'DRAFT') draftCount++;
      else if (r.status === 'CANCELLED') cancelledCount++;
    }

    const stats: StudentFeeSummaryStats = {
      totalInvoices: allRecords.length,
      totalAmount,
      totalDiscount,
      totalFine,
      totalNetPayable,
      totalPaid,
      totalDue,
      paidCount,
      unpaidCount,
      partialCount,
      overdueCount,
      draftCount,
      cancelledCount,
      studentsWithDuesCount: studentsWithDues.size
    };

    res.json({ success: true, data: stats });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to fetch student fee statistics',
      code: 'SERVER_ERROR'
    });
  }
});

/**
 * GET /api/fees/applicable-structures
 * Preview active applicable fee structures for a given session, class, section, and student
 */
feesRouter.get('/applicable-structures', (req: AuthenticatedRequest, res: Response) => {
  try {
    const { academicSessionId, classId, sectionId, studentId } = req.query as {
      academicSessionId?: string;
      classId?: string;
      sectionId?: string;
      studentId?: string;
    };

    if (!academicSessionId || !classId) {
      res.status(400).json({
        success: false,
        error: 'academicSessionId and classId are required to query applicable fee structures.',
        code: 'VALIDATION_ERROR'
      });
      return;
    }

    // Fetch active fee structures for this session and class
    const structures = (database.feeStructures || []).filter(
      (s) =>
        s.status === 'ACTIVE' &&
        s.academicSessionId === academicSessionId &&
        s.classId === classId &&
        (s.applicableToAllSections || !sectionId || s.sectionId === null || s.sectionId === sectionId)
    );

    // If a specific student is provided, check which structures are already assigned
    const applicableItems: ApplicableFeeStructureItem[] = structures.map((structure) => {
      let isAlreadyAssigned = false;
      let assignedRecordId: string | undefined;
      let assignedInvoiceNumber: string | undefined;
      let currentStatus: FeePaymentStatus | undefined;

      if (studentId) {
        const existingRecord = (database.feeRecords || []).find(
          (r) =>
            r.studentId === studentId &&
            r.academicSessionId === academicSessionId &&
            r.status !== 'CANCELLED' &&
            (r.feeStructureId === structure.id ||
              (r.feeType.toLowerCase() === structure.name.toLowerCase() ||
                r.title.toLowerCase() === structure.name.toLowerCase()))
        );

        if (existingRecord) {
          isAlreadyAssigned = true;
          assignedRecordId = existingRecord.id;
          assignedInvoiceNumber = existingRecord.invoiceNumber;
          currentStatus = existingRecord.status;
        }
      }

      return {
        structure,
        isAlreadyAssigned,
        assignedRecordId,
        assignedInvoiceNumber,
        currentStatus
      };
    });

    res.json({ success: true, data: applicableItems });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to fetch applicable fee structures',
      code: 'SERVER_ERROR'
    });
  }
});

/**
 * POST /api/fees/assign
 * Bulk or individual student fee assignment with automatic fee structure determination and duplicate prevention
 */
feesRouter.post(
  '/assign',
  requirePermission('fees.create'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const payload = req.body as AssignStudentFeePayload;
      const {
        assignmentType,
        academicSessionId,
        classId,
        sectionId,
        studentId,
        studentIds,
        feeStructureIds,
        autoDetermineApplicable = true,
        customDueDate,
        discountAmount,
        discountReason,
        notes
      } = payload;

      if (!assignmentType || !['INDIVIDUAL', 'CLASS', 'SECTION'].includes(assignmentType)) {
        res.status(400).json({
          success: false,
          error: "assignmentType must be 'INDIVIDUAL', 'CLASS', or 'SECTION'.",
          code: 'VALIDATION_ERROR'
        });
        return;
      }

      if (!academicSessionId || !classId) {
        res.status(400).json({
          success: false,
          error: 'academicSessionId and classId are required.',
          code: 'VALIDATION_ERROR'
        });
        return;
      }

      // Verify Academic Session
      const session = (database.academicSessions || []).find((s) => s.id === academicSessionId);
      if (!session) {
        res.status(404).json({
          success: false,
          error: 'Academic Session not found.',
          code: 'NOT_FOUND'
        });
        return;
      }

      // Verify Class
      const cls = (database.classes || []).find((c) => c.id === classId);
      if (!cls) {
        res.status(404).json({
          success: false,
          error: 'Class not found.',
          code: 'NOT_FOUND'
        });
        return;
      }

      // Verify Section if SECTION assignment
      let sec = null;
      if (assignmentType === 'SECTION' || sectionId) {
        sec = (database.sections || []).find((s) => s.id === sectionId);
        if (assignmentType === 'SECTION' && !sec) {
          res.status(400).json({
            success: false,
            error: 'Valid sectionId is required for SECTION assignment.',
            code: 'VALIDATION_ERROR'
          });
          return;
        }
      }

      // 1. Resolve target students
      let targetStudents: Array<any> = [];
      if (assignmentType === 'INDIVIDUAL') {
        const idsToProcess = studentIds && studentIds.length > 0 ? studentIds : studentId ? [studentId] : [];
        if (idsToProcess.length === 0) {
          res.status(400).json({
            success: false,
            error: 'studentId or studentIds is required for INDIVIDUAL assignment.',
            code: 'VALIDATION_ERROR'
          });
          return;
        }

        for (const sId of idsToProcess) {
          const studentProf = (database.studentProfiles || []).find(
            (p) => p.id === sId || p.userId === sId
          );
          if (studentProf) {
            const user = (database.users || []).find((u) => u.id === studentProf.userId);
            targetStudents.push({
              profile: studentProf,
              user,
              name: user?.name || `${studentProf.firstName || ''} ${studentProf.lastName || ''}`.trim() || 'Student',
              admissionNumber: studentProf.admissionNumber || `ADM-${studentProf.id.slice(-4)}`
            });
          }
        }

        if (targetStudents.length === 0) {
          res.status(404).json({
            success: false,
            error: 'No valid student profiles found for the provided ID(s).',
            code: 'STUDENTS_NOT_FOUND'
          });
          return;
        }
      } else if (assignmentType === 'SECTION') {
        const profiles = (database.studentProfiles || []).filter(
          (p) => p.classId === classId && p.sectionId === sectionId && p.status !== 'SUSPENDED' && p.status !== 'INACTIVE'
        );
        for (const p of profiles) {
          const user = (database.users || []).find((u) => u.id === p.userId);
          targetStudents.push({
            profile: p,
            user,
            name: user?.name || `${p.firstName || ''} ${p.lastName || ''}`.trim() || 'Student',
            admissionNumber: p.admissionNumber || `ADM-${p.id.slice(-4)}`
          });
        }
      } else if (assignmentType === 'CLASS') {
        const profiles = (database.studentProfiles || []).filter(
          (p) => p.classId === classId && p.status !== 'SUSPENDED' && p.status !== 'INACTIVE'
        );
        for (const p of profiles) {
          const user = (database.users || []).find((u) => u.id === p.userId);
          targetStudents.push({
            profile: p,
            user,
            name: user?.name || `${p.firstName || ''} ${p.lastName || ''}`.trim() || 'Student',
            admissionNumber: p.admissionNumber || `ADM-${p.id.slice(-4)}`
          });
        }
      }

      if (targetStudents.length === 0) {
        res.status(400).json({
          success: false,
          error: `No active enrolled students found in ${assignmentType === 'SECTION' ? 'Section ' + (sec?.name || sectionId) : 'Class ' + cls.name}.`,
          code: 'NO_STUDENTS_FOUND'
        });
        return;
      }

      // 2. Resolve target fee structures
      let structuresToAssign: FeeStructure[] = [];
      if (feeStructureIds && feeStructureIds.length > 0) {
        structuresToAssign = (database.feeStructures || []).filter(
          (s) => feeStructureIds.includes(s.id) && s.status === 'ACTIVE'
        );
      } else if (autoDetermineApplicable) {
        // Automatically determine all active fee structures for this academic session and class
        structuresToAssign = (database.feeStructures || []).filter(
          (s) =>
            s.status === 'ACTIVE' &&
            s.academicSessionId === academicSessionId &&
            s.classId === classId
        );
      }

      if (structuresToAssign.length === 0) {
        res.status(400).json({
          success: false,
          error: 'No active fee structures found to assign for this session and class.',
          code: 'NO_FEE_STRUCTURES_FOUND'
        });
        return;
      }

      if (!database.feeRecords) {
        database.feeRecords = [];
      }

      // 3. Process assignments & detect duplicates
      const assignedRecords: StudentFeeRecord[] = [];
      const skippedDetails: Array<{
        studentId: string;
        studentName: string;
        admissionNumber?: string;
        feeStructureId: string;
        feeTitle: string;
        reason: string;
      }> = [];

      const now = new Date().toISOString();

      for (const student of targetStudents) {
        const studentSectionId = student.profile.sectionId;
        const studentSection =
          (database.sections || []).find((s) => s.id === studentSectionId) || sec;

        for (const structure of structuresToAssign) {
          // Check if structure is applicable to this student's section
          if (
            !structure.applicableToAllSections &&
            structure.sectionId &&
            structure.sectionId !== studentSectionId
          ) {
            continue; // Not applicable for this student's section
          }

          // Check for duplicate assignment
          const isDuplicate = database.feeRecords.some((existing) => {
            if (existing.studentId !== student.profile.id) return false;
            if (existing.academicSessionId !== academicSessionId) return false;
            if (existing.status === 'CANCELLED') return false;

            // Direct fee structure ID match
            if (existing.feeStructureId && existing.feeStructureId === structure.id) {
              return true;
            }

            // Fallback match: feeTypeId or name + term matching
            if (
              existing.feeTypeId &&
              existing.feeTypeId === structure.feeTypeId &&
              existing.title.toLowerCase() === structure.name.toLowerCase()
            ) {
              return true;
            }

            if (existing.title.toLowerCase() === structure.name.toLowerCase()) {
              return true;
            }

            return false;
          });

          if (isDuplicate) {
            skippedDetails.push({
              studentId: student.profile.id,
              studentName: student.name,
              admissionNumber: student.admissionNumber,
              feeStructureId: structure.id,
              feeTitle: structure.name,
              reason: 'Fee structure is already assigned to student for this academic session.'
            });
            continue;
          }

          // Generate unique invoice number
          const invoiceNumber = generateUniqueInvoiceNumber();

          // Financial calculations
          const totalAmount = structure.amount;
          const assignedDiscount =
            assignmentType === 'INDIVIDUAL' && typeof discountAmount === 'number'
              ? Math.max(0, Math.min(discountAmount, totalAmount))
              : 0;
          const netPayableAmount = Math.max(0, totalAmount - assignedDiscount);
          const dueAmount = netPayableAmount;
          const paidAmount = 0;
          const effectiveDueDate = customDueDate || structure.dueDate;

          // Fee type info
          const feeTypeObj = (database.feeTypes || []).find((t) => t.id === structure.feeTypeId);
          const feeTypeName = feeTypeObj?.name || structure.name;

          const newFeeRecord: StudentFeeRecord = {
            id: `fee-rec-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
            feeStructureId: structure.id,
            feeTypeId: structure.feeTypeId,
            feeTypeCode: feeTypeObj?.code,
            studentId: student.profile.id,
            studentName: student.name,
            admissionNumber: student.admissionNumber,
            rollNumber: student.profile.rollNumber || '01',
            classId: cls.id,
            className: cls.name,
            sectionId: studentSection?.id || '',
            sectionName: studentSection?.name || 'General',
            academicSessionId: session.id,
            academicSessionName: session.name,
            term: session.name,
            feeType: feeTypeName,
            frequency: structure.frequency,
            title: structure.name,
            description: structure.description || `${structure.name} for ${cls.name}`,
            invoiceNumber,
            totalAmount,
            discountAmount: assignedDiscount,
            discountReason: assignedDiscount > 0 ? discountReason || 'Admin Assigned Discount' : undefined,
            fineAmount: 0,
            netPayableAmount,
            paidAmount,
            dueAmount,
            dueDate: effectiveDueDate,
            status: netPayableAmount === 0 ? 'PAID' : 'DUE',
            currency: structure.currency || 'USD',
            isMandatory: structure.isMandatory,
            feeCategory: structure.feeCategory,
            notes: notes || undefined,
            createdBy: req.user?.id,
            createdAt: now,
            updatedAt: now
          };

          database.feeRecords.push(newFeeRecord);
          assignedRecords.push(newFeeRecord);
        }
      }

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'CREATE',
        entity: 'FEE_ASSIGNMENT',
        details: `Assigned fees (${assignmentType}): ${assignedRecords.length} invoices generated, ${skippedDetails.length} skipped duplicates.`,
        metadata: {
          assignmentType,
          classId,
          sectionId,
          assignedCount: assignedRecords.length,
          skippedCount: skippedDetails.length
        }
      });

      const responseData: AssignStudentFeeResponse = {
        success: true,
        message: `Successfully generated ${assignedRecords.length} fee invoice(s). ${skippedDetails.length > 0 ? `${skippedDetails.length} existing assignments skipped.` : ''}`,
        assignedCount: assignedRecords.length,
        skippedCount: skippedDetails.length,
        assignedRecords,
        skippedDetails
      };

      res.status(201).json(responseData);
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to assign fees',
        code: 'SERVER_ERROR'
      });
    }
  }
);

/**
 * GET /api/fees/student-fees/:id
 * Single student fee / invoice details with linked transactions and audit
 */
feesRouter.get('/student-fees/:id', (req: AuthenticatedRequest, res: Response) => {
  try {
    const { id } = req.params;

    const rawRecord = (database.feeRecords || []).find((r) => r.id === id || r.invoiceNumber === id);
    if (!rawRecord) {
      res.status(404).json({
        success: false,
        error: 'Student fee record not found.',
        code: 'NOT_FOUND'
      });
      return;
    }

    const fee = normalizeFeeCalculations(rawRecord);

    // Student and Guardian Info
    const studentProfile = (database.studentProfiles || []).find((s) => s.id === fee.studentId);
    const studentUser = studentProfile
      ? (database.users || []).find((u) => u.id === studentProfile.userId)
      : null;

    // Find linked guardian if any
    let guardian = null;
    if (studentProfile) {
      guardian = (database.guardians || []).find(
        (g) => g.studentIds && g.studentIds.includes(studentProfile.id)
      );
    }

    const studentInfo = {
      id: fee.studentId,
      userId: studentProfile?.userId || '',
      admissionNumber: fee.admissionNumber,
      rollNumber: fee.rollNumber || studentProfile?.rollNumber || '01',
      name: fee.studentName,
      email: studentUser?.email,
      avatarUrl: studentUser?.avatarUrl,
      classId: fee.classId,
      className: fee.className,
      sectionId: fee.sectionId,
      sectionName: fee.sectionName,
      academicSessionId: fee.academicSessionId,
      academicSessionName: fee.academicSessionName,
      guardianName: guardian?.name,
      guardianEmail: guardian?.email,
      guardianPhone: guardian?.phone,
      guardianRelation: guardian?.relation,
      guardianAddress: guardian?.address
    };

    // Linked Transactions
    const transactions = (database.feeTransactions || []).filter(
      (t) => t.feeRecordId === fee.id || t.receiptNumber === fee.invoiceNumber
    );

    // School Info
    const schoolSettings = database.schoolSettings || {
      name: 'Sygmate International Academy',
      code: 'SIA-HQ-01',
      affiliationNumber: 'CBSE-INTL-2026-9901',
      address: '742 Evergreen Academic Way, Sector 4, Silicon Valley Campus',
      phone: '+1 (800) 555-0199',
      email: 'finance@sygmate-academy.edu',
      currency: 'USD',
      currencySymbol: '$'
    };

    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const dueDateObj = new Date(fee.dueDate);
    const isOverdue = !isNaN(dueDateObj.getTime()) && dueDateObj < today && fee.dueAmount > 0;
    const daysOverdue = isOverdue
      ? Math.floor((today.getTime() - dueDateObj.getTime()) / (1000 * 60 * 60 * 24))
      : 0;

    const waiversApplied = (database.feeWaivers || []).filter(
      (w) => w.feeRecordId === fee.id || w.invoiceNumber === fee.invoiceNumber
    );
    const finesApplied = (database.feeAppliedFines || []).filter(
      (f) => f.feeRecordId === fee.id || f.invoiceNumber === fee.invoiceNumber
    );
    const scholarshipsApplied = (database.feeScholarships || []).filter(
      (s) => s.studentId === fee.studentId && s.status === 'ACTIVE'
    );
    const discountsApplied = (database.feeDiscounts || []).filter(
      (d) =>
        d.status === 'ACTIVE' &&
        (d.scope === 'ALL' ||
          (d.scope === 'STUDENT' && d.studentId === fee.studentId) ||
          (d.scope === 'CLASS' && d.classId === fee.classId) ||
          (d.scope === 'FEE_TYPE' && d.applicableFeeType === fee.feeType))
    );

    const detail: InvoiceDetailResponse = {
      fee,
      student: studentInfo,
      schoolInfo: {
        schoolName: schoolSettings.name || 'Sygmate International Academy',
        schoolCode: schoolSettings.code || 'SIA-HQ-01',
        affiliationNumber: schoolSettings.affiliationNumber,
        address: schoolSettings.address,
        contactEmail: schoolSettings.email,
        contactPhone: schoolSettings.phone,
        currency: fee.currency || schoolSettings.currency || 'USD',
        currencySymbol: '$'
      },
      transactions,
      breakdown: {
        originalAmount: fee.totalAmount,
        discountAmount: fee.discountAmount || 0,
        scholarshipAmount: fee.scholarshipAmount || 0,
        waiverAmount: fee.waiverAmount || 0,
        fineAmount: fee.fineAmount || 0,
        netPayableAmount: fee.netPayableAmount,
        totalPaid: fee.paidAmount,
        remainingDue: fee.dueAmount,
        status: fee.status,
        isOverdue,
        daysOverdue
      },
      discountsApplied,
      scholarshipsApplied,
      waiversApplied,
      finesApplied
    };

    res.json({ success: true, data: detail });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to fetch invoice details',
      code: 'SERVER_ERROR'
    });
  }
});

/**
 * POST /api/fees/student-fees/:id/discount
 * Apply or adjust authorized discount on a student fee record
 */
feesRouter.post(
  '/student-fees/:id/discount',
  requirePermission('fees.edit'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const { id } = req.params;
      const { discountAmount, discountReason } = req.body as ApplyFeeDiscountPayload;

      if (typeof discountAmount !== 'number' || discountAmount < 0) {
        res.status(400).json({
          success: false,
          error: 'Discount amount must be a positive number or zero.',
          code: 'VALIDATION_ERROR'
        });
        return;
      }

      if (!discountReason || !discountReason.trim()) {
        res.status(400).json({
          success: false,
          error: 'A reason or description for the discount is required.',
          code: 'VALIDATION_ERROR'
        });
        return;
      }

      const index = (database.feeRecords || []).findIndex((r) => r.id === id);
      if (index === -1) {
        res.status(404).json({
          success: false,
          error: 'Student fee record not found.',
          code: 'NOT_FOUND'
        });
        return;
      }

      const fee = database.feeRecords[index];
      const maxAllowedDiscount = fee.totalAmount + (fee.fineAmount || 0);

      if (discountAmount > maxAllowedDiscount) {
        res.status(400).json({
          success: false,
          error: `Discount amount (${discountAmount}) cannot exceed the gross amount (${maxAllowedDiscount}).`,
          code: 'INVALID_DISCOUNT_AMOUNT'
        });
        return;
      }

      // Recalculate
      const updatedRecord: StudentFeeRecord = {
        ...fee,
        discountAmount,
        discountReason: discountReason.trim(),
        updatedAt: new Date().toISOString()
      };

      const normalized = normalizeFeeCalculations(updatedRecord);
      database.feeRecords[index] = normalized;

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'UPDATE',
        entity: 'FEE_DISCOUNT',
        details: `Applied discount of $${discountAmount} to invoice ${normalized.invoiceNumber} for ${normalized.studentName}. Reason: ${discountReason}`,
        metadata: {
          feeRecordId: fee.id,
          invoiceNumber: fee.invoiceNumber,
          oldDiscount: fee.discountAmount,
          newDiscount: discountAmount,
          netPayable: normalized.netPayableAmount,
          remainingDue: normalized.dueAmount
        }
      });

      res.json({
        success: true,
        message: `Successfully applied discount to invoice ${normalized.invoiceNumber}.`,
        data: normalized
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to apply discount',
        code: 'SERVER_ERROR'
      });
    }
  }
);

/**
 * POST /api/fees/student-fees/:id/fine
 * Apply or adjust fine amount on a student fee record
 */
feesRouter.post(
  '/student-fees/:id/fine',
  requirePermission('fees.edit'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const { id } = req.params;
      const { fineAmount, fineReason } = req.body as ApplyFeeFinePayload;

      if (typeof fineAmount !== 'number' || fineAmount < 0) {
        res.status(400).json({
          success: false,
          error: 'Fine amount must be a positive number or zero.',
          code: 'VALIDATION_ERROR'
        });
        return;
      }

      const index = (database.feeRecords || []).findIndex((r) => r.id === id);
      if (index === -1) {
        res.status(404).json({
          success: false,
          error: 'Student fee record not found.',
          code: 'NOT_FOUND'
        });
        return;
      }

      const fee = database.feeRecords[index];

      const updatedRecord: StudentFeeRecord = {
        ...fee,
        fineAmount,
        fineReason: fineReason?.trim() || undefined,
        updatedAt: new Date().toISOString()
      };

      const normalized = normalizeFeeCalculations(updatedRecord);
      database.feeRecords[index] = normalized;

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'UPDATE',
        entity: 'FEE_FINE',
        details: `Adjusted fine of $${fineAmount} on invoice ${normalized.invoiceNumber} for ${normalized.studentName}.`,
        metadata: {
          feeRecordId: fee.id,
          invoiceNumber: fee.invoiceNumber,
          oldFine: fee.fineAmount,
          newFine: fineAmount,
          netPayable: normalized.netPayableAmount,
          remainingDue: normalized.dueAmount
        }
      });

      res.json({
        success: true,
        message: `Successfully updated fine on invoice ${normalized.invoiceNumber}.`,
        data: normalized
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to apply fine',
        code: 'SERVER_ERROR'
      });
    }
  }
);

/**
 * PATCH /api/fees/student-fees/:id/status
 * Transition invoice status (DRAFT -> UNPAID, or CANCELLED)
 */
feesRouter.patch(
  '/student-fees/:id/status',
  requirePermission('fees.edit'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const { id } = req.params;
      const { status, reason } = req.body as UpdateStudentFeeStatusPayload;

      if (!status || !['DRAFT', 'UNPAID', 'CANCELLED'].includes(status)) {
        res.status(400).json({
          success: false,
          error: "Status must be 'DRAFT', 'UNPAID', or 'CANCELLED'.",
          code: 'VALIDATION_ERROR'
        });
        return;
      }

      const index = (database.feeRecords || []).findIndex((r) => r.id === id);
      if (index === -1) {
        res.status(404).json({
          success: false,
          error: 'Student fee record not found.',
          code: 'NOT_FOUND'
        });
        return;
      }

      const fee = database.feeRecords[index];

      // Safety check: Cannot cancel an invoice that already has collected funds without refund
      if (status === 'CANCELLED' && fee.paidAmount > 0) {
        res.status(400).json({
          success: false,
          error: `Cannot cancel invoice ${fee.invoiceNumber} because it already has a paid balance of $${fee.paidAmount}.`,
          code: 'CANNOT_CANCEL_PAID_INVOICE'
        });
        return;
      }

      database.feeRecords[index] = {
        ...fee,
        status,
        updatedAt: new Date().toISOString()
      };

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'UPDATE',
        entity: 'FEE_STATUS',
        details: `Changed status of invoice ${fee.invoiceNumber} to ${status}. Reason: ${reason || 'Admin status change'}`,
        metadata: { feeRecordId: fee.id, previousStatus: fee.status, newStatus: status, reason }
      });

      res.json({
        success: true,
        message: `Invoice status updated to ${status}.`,
        data: database.feeRecords[index]
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to update fee status',
        code: 'SERVER_ERROR'
      });
    }
  }
);

/**
 * DELETE /api/fees/student-fees/:id
 * Delete a student fee invoice if unpaid and in draft or cancelled state
 */
feesRouter.delete(
  '/student-fees/:id',
  requirePermission('fees.delete'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const { id } = req.params;

      const index = (database.feeRecords || []).findIndex((r) => r.id === id);
      if (index === -1) {
        res.status(404).json({
          success: false,
          error: 'Student fee record not found.',
          code: 'NOT_FOUND'
        });
        return;
      }

      const fee = database.feeRecords[index];

      if (fee.paidAmount > 0) {
        res.status(400).json({
          success: false,
          error: `Cannot delete invoice ${fee.invoiceNumber} because payments have been recorded.`,
          code: 'PAID_RECORD_PROTECTED'
        });
        return;
      }

      database.feeRecords.splice(index, 1);

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'DELETE',
        entity: 'FEE_RECORD',
        details: `Deleted fee invoice ${fee.invoiceNumber} for ${fee.studentName}.`,
        metadata: { fee }
      });

      res.json({
        success: true,
        message: `Invoice ${fee.invoiceNumber} has been successfully deleted.`
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to delete fee record',
        code: 'SERVER_ERROR'
      });
    }
  }
);

/**
 * GET /api/fees/invoices/:invoiceNumber
 * Universal invoice lookup by invoice number with RBAC ownership enforcement
 */
feesRouter.get('/invoices/:invoiceNumber', (req: AuthenticatedRequest, res: Response) => {
  try {
    const { invoiceNumber } = req.params;
    const user = req.user!;

    const rawRecord = (database.feeRecords || []).find(
      (r) => r.invoiceNumber.toLowerCase() === invoiceNumber.toLowerCase()
    );

    if (!rawRecord) {
      res.status(404).json({
        success: false,
        error: `Invoice ${invoiceNumber} was not found.`,
        code: 'INVOICE_NOT_FOUND'
      });
      return;
    }

    const fee = normalizeFeeCalculations(rawRecord);

    // Enforce Authorization:
    // Super Admin: allowed
    // Guardian: allowed only if fee belongs to one of their linked children
    // Student: allowed only if fee belongs to their student profile
    if (user.role === 'GUARDIAN') {
      const guardian = (database.guardians || []).find((g) => g.userId === user.id);
      if (!guardian || !guardian.studentIds || !guardian.studentIds.includes(fee.studentId)) {
        res.status(403).json({
          success: false,
          error: 'Access denied: You can only view invoices for your linked children.',
          code: 'FORBIDDEN'
        });
        return;
      }
    } else if (user.role === 'STUDENT') {
      const studentProfile = (database.studentProfiles || []).find((s) => s.userId === user.id);
      if (!studentProfile || studentProfile.id !== fee.studentId) {
        res.status(403).json({
          success: false,
          error: 'Access denied: You can only view your own student invoices.',
          code: 'FORBIDDEN'
        });
        return;
      }
    }

    // Student and Guardian Info
    const studentProfile = (database.studentProfiles || []).find((s) => s.id === fee.studentId);
    const studentUser = studentProfile
      ? (database.users || []).find((u) => u.id === studentProfile.userId)
      : null;

    let guardian = null;
    if (studentProfile) {
      guardian = (database.guardians || []).find(
        (g) => g.studentIds && g.studentIds.includes(studentProfile.id)
      );
    }

    const studentInfo = {
      id: fee.studentId,
      userId: studentProfile?.userId || '',
      admissionNumber: fee.admissionNumber,
      rollNumber: fee.rollNumber || studentProfile?.rollNumber || '01',
      name: fee.studentName,
      email: studentUser?.email,
      avatarUrl: studentUser?.avatarUrl,
      classId: fee.classId,
      className: fee.className,
      sectionId: fee.sectionId,
      sectionName: fee.sectionName,
      academicSessionId: fee.academicSessionId,
      academicSessionName: fee.academicSessionName,
      guardianName: guardian?.name,
      guardianEmail: guardian?.email,
      guardianPhone: guardian?.phone,
      guardianRelation: guardian?.relation,
      guardianAddress: guardian?.address
    };

    const transactions = (database.feeTransactions || []).filter(
      (t) => t.feeRecordId === fee.id || t.receiptNumber === fee.invoiceNumber
    );

    const schoolSettings = database.schoolSettings || {
      name: 'Sygmate International Academy',
      code: 'SIA-HQ-01',
      affiliationNumber: 'CBSE-INTL-2026-9901',
      address: '742 Evergreen Academic Way, Sector 4, Silicon Valley Campus',
      phone: '+1 (800) 555-0199',
      email: 'finance@sygmate-academy.edu',
      currency: 'USD',
      currencySymbol: '$'
    };

    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const dueDateObj = new Date(fee.dueDate);
    const isOverdue = !isNaN(dueDateObj.getTime()) && dueDateObj < today && fee.dueAmount > 0;
    const daysOverdue = isOverdue
      ? Math.floor((today.getTime() - dueDateObj.getTime()) / (1000 * 60 * 60 * 24))
      : 0;

    const waiversApplied = (database.feeWaivers || []).filter(
      (w) => w.feeRecordId === fee.id || w.invoiceNumber === fee.invoiceNumber
    );
    const finesApplied = (database.feeAppliedFines || []).filter(
      (f) => f.feeRecordId === fee.id || f.invoiceNumber === fee.invoiceNumber
    );
    const scholarshipsApplied = (database.feeScholarships || []).filter(
      (s) => s.studentId === fee.studentId && s.status === 'ACTIVE'
    );
    const discountsApplied = (database.feeDiscounts || []).filter(
      (d) =>
        d.status === 'ACTIVE' &&
        (d.scope === 'ALL' ||
          (d.scope === 'STUDENT' && d.studentId === fee.studentId) ||
          (d.scope === 'CLASS' && d.classId === fee.classId) ||
          (d.scope === 'FEE_TYPE' && d.applicableFeeType === fee.feeType))
    );

    const detail: InvoiceDetailResponse = {
      fee,
      student: studentInfo,
      schoolInfo: {
        schoolName: schoolSettings.name || 'Sygmate International Academy',
        schoolCode: schoolSettings.code || 'SIA-HQ-01',
        affiliationNumber: schoolSettings.affiliationNumber,
        address: schoolSettings.address,
        contactEmail: schoolSettings.email,
        contactPhone: schoolSettings.phone,
        currency: fee.currency || schoolSettings.currency || 'USD',
        currencySymbol: '$'
      },
      transactions,
      breakdown: {
        originalAmount: fee.totalAmount,
        discountAmount: fee.discountAmount || 0,
        scholarshipAmount: fee.scholarshipAmount || 0,
        waiverAmount: fee.waiverAmount || 0,
        fineAmount: fee.fineAmount || 0,
        netPayableAmount: fee.netPayableAmount,
        totalPaid: fee.paidAmount,
        remainingDue: fee.dueAmount,
        status: fee.status,
        isOverdue,
        daysOverdue
      },
      discountsApplied,
      scholarshipsApplied,
      waiversApplied,
      finesApplied
    };

    res.json({ success: true, data: detail });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to fetch invoice',
      code: 'SERVER_ERROR'
    });
  }
});

// ============================================================================
// PART 7C: FEE COLLECTION & PAYMENT MANAGEMENT ENDPOINTS
// ============================================================================

/**
 * Helper: Generate unique transaction ID
 */
function generateUniqueTransactionId(): string {
  const year = new Date().getFullYear();
  let txnId = '';
  let isUnique = false;
  let attempts = 0;
  while (!isUnique && attempts < 1000) {
    attempts++;
    const rand = Math.floor(10000 + Math.random() * 90000);
    txnId = `TXN-${year}-${rand}`;
    const exists = (database.feeTransactions || []).some((t) => t.transactionId === txnId);
    if (!exists) isUnique = true;
  }
  if (!isUnique) {
    txnId = `TXN-${year}-${Date.now().toString().slice(-6)}`;
  }
  return txnId;
}

/**
 * Helper: Generate unique receipt number
 */
function generateUniqueReceiptNumber(): string {
  const year = new Date().getFullYear();
  let receiptNumber = '';
  let isUnique = false;
  let attempts = 0;
  while (!isUnique && attempts < 1000) {
    attempts++;
    const count = (database.feeTransactions?.length || 0) + 100 + attempts;
    const padded = String(count).padStart(5, '0');
    receiptNumber = `REC-${year}-${padded}`;
    const exists = (database.feeTransactions || []).some((t) => t.receiptNumber === receiptNumber);
    if (!exists) isUnique = true;
  }
  if (!isUnique) {
    receiptNumber = `REC-${year}-${Date.now().toString().slice(-6)}`;
  }
  return receiptNumber;
}

/**
 * Helper: Format payment method display label
 */
function formatPaymentMethodLabel(method: string, reference?: string): string {
  let label = method;
  switch (method) {
    case 'CASH':
      label = 'Cash Payment (Counter)';
      break;
    case 'BANK_TRANSFER':
      label = reference ? `Bank Transfer (Ref: ${reference})` : 'Direct Bank Transfer / Wire';
      break;
    case 'CREDIT_CARD':
      label = reference ? `Credit Card POS (Ref: ${reference})` : 'Credit Card (POS Terminal)';
      break;
    case 'DEBIT_CARD':
      label = reference ? `Debit Card POS (Ref: ${reference})` : 'Debit Card (POS Terminal)';
      break;
    case 'CHEQUE':
      label = reference ? `Cheque / Draft (No: ${reference})` : 'Bank Cheque / Draft';
      break;
    case 'MOBILE_BANKING':
    case 'DIGITAL_WALLET':
      label = reference ? `Mobile Wallet (${reference})` : 'Digital Wallet / Mobile Banking';
      break;
    case 'ONLINE_PAYMENT':
    case 'NET_BANKING':
      label = reference ? `Online Gateway (${reference})` : 'Online Portal Payment Gateway';
      break;
    case 'OTHER':
      label = reference ? `Other Settlement (${reference})` : 'Administrative Settlement / Other';
      break;
    default:
      label = method;
  }
  return label;
}

/**
 * GET /api/fees/payment-methods
 * Returns all configured payment methods
 */
feesRouter.get('/payment-methods', (req: AuthenticatedRequest, res: Response): void => {
  try {
    const methods = database.paymentMethods || [];
    res.json({
      success: true,
      data: methods.sort((a, b) => a.displayOrder - b.displayOrder)
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to fetch payment methods',
      code: 'SERVER_ERROR'
    });
  }
});

/**
 * POST /api/fees/payment-methods/:id/toggle
 * Toggle active status of a payment method (Super Admin)
 */
feesRouter.post(
  '/payment-methods/:id/toggle',
  requireRole('SUPER_ADMIN'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const { id } = req.params;
      const method = (database.paymentMethods || []).find((m) => m.id === id || m.code === id);
      if (!method) {
        res.status(404).json({ success: false, error: 'Payment method not found', code: 'NOT_FOUND' });
        return;
      }
      method.isActive = !method.isActive;

      logAudit({
        userId: req.user!.id,
        userRole: req.user!.role,
        action: 'UPDATE_PAYMENT_METHOD',
        entityType: 'PaymentMethodConfig',
        entityId: method.id,
        details: `Toggled payment method ${method.name} (${method.code}) to ${method.isActive ? 'ACTIVE' : 'INACTIVE'}`,
        ipAddress: req.ip || '127.0.0.1'
      });

      res.json({
        success: true,
        message: `Payment method ${method.name} is now ${method.isActive ? 'Active' : 'Inactive'}.`,
        data: method
      });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message, code: 'SERVER_ERROR' });
    }
  }
);

/**
 * POST /api/fees/collect
 * Collect fee payment against an existing student invoice with full/partial payment support.
 * Enforces server-side amount validation, idempotency, audit trail, and state updates.
 */
feesRouter.post(
  '/collect',
  requireRole('SUPER_ADMIN'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const {
        feeRecordId,
        amount,
        paymentDate,
        paymentMethod,
        referenceNumber,
        notes,
        cardholderName,
        idempotencyKey
      }: CollectFeePaymentPayload = req.body;

      if (!feeRecordId) {
        res.status(400).json({
          success: false,
          error: 'Fee record / invoice ID is required.',
          code: 'MISSING_FEE_RECORD_ID'
        });
        return;
      }

      const fee = (database.feeRecords || []).find((f) => f.id === feeRecordId || f.invoiceNumber === feeRecordId);
      if (!fee) {
        res.status(404).json({
          success: false,
          error: 'Valid student invoice / fee record not found.',
          code: 'FEE_RECORD_NOT_FOUND'
        });
        return;
      }

      if (fee.status === 'CANCELLED') {
        res.status(400).json({
          success: false,
          error: 'Cannot collect payment for a cancelled invoice.',
          code: 'INVOICE_CANCELLED'
        });
        return;
      }

      if (fee.status === 'DRAFT') {
        res.status(400).json({
          success: false,
          error: 'Cannot collect payment on a draft invoice. Please publish the invoice first.',
          code: 'INVOICE_DRAFT'
        });
        return;
      }

      const parsedAmount = typeof amount === 'string' ? parseFloat(amount) : Number(amount);
      if (isNaN(parsedAmount) || parsedAmount <= 0) {
        res.status(400).json({
          success: false,
          error: 'Payment amount must be a positive numeric value greater than zero.',
          code: 'INVALID_AMOUNT'
        });
        return;
      }

      // Idempotency token check
      if (idempotencyKey) {
        const existingTxn = (database.feeTransactions || []).find(
          (t) => t.idempotencyKey === idempotencyKey
        );
        if (existingTxn) {
          res.json({
            success: true,
            message: 'Payment already processed with this transaction token.',
            data: {
              transaction: existingTxn,
              feeRecord: fee,
              receiptNumber: existingTxn.receiptNumber
            }
          });
          return;
        }
      }

      // Server-side balance calculation (sum all active non-reversed payments)
      const activeTransactions = (database.feeTransactions || []).filter(
        (t) => t.feeRecordId === fee.id && t.paymentStatus === 'SUCCESS' && !t.isReversed
      );
      const totalAlreadyPaid = activeTransactions.reduce(
        (sum, t) => sum + (Number(t.amountPaid) || 0),
        0
      );

      const totalAmount = Number(fee.totalAmount) || 0;
      const discountAmount = Number(fee.discountAmount) || 0;
      const fineAmount = Number(fee.fineAmount) || 0;
      const netPayable = Math.max(0, parseFloat((totalAmount - discountAmount + fineAmount).toFixed(2)));
      const remainingDue = Math.max(0, parseFloat((netPayable - totalAlreadyPaid).toFixed(2)));

      if (remainingDue <= 0) {
        res.status(400).json({
          success: false,
          error: 'This invoice is already fully paid. No outstanding balance remains.',
          code: 'INVOICE_ALREADY_PAID'
        });
        return;
      }

      if (parsedAmount > remainingDue + 0.01) {
        res.status(400).json({
          success: false,
          error: `Payment amount ($${parsedAmount.toFixed(2)}) exceeds remaining outstanding balance ($${remainingDue.toFixed(2)}).`,
          code: 'EXCESSIVE_PAYMENT_AMOUNT'
        });
        return;
      }

      // Resolve student and guardian details
      const studentProfile = database.studentProfiles.find((s) => s.id === fee.studentId);
      const guardian = database.guardians.find((g) => g.studentIds.includes(fee.studentId));

      const validMethod = (paymentMethod || 'CASH').toUpperCase();
      const methodLabel = formatPaymentMethodLabel(
        validMethod,
        cardholderName ? `${cardholderName} - ${referenceNumber || ''}` : referenceNumber
      );

      const timestamp = paymentDate && isValidDateString(paymentDate)
        ? `${paymentDate}T${new Date().toISOString().substring(11)}`
        : new Date().toISOString();

      const transactionId = generateUniqueTransactionId();
      const receiptNumber = generateUniqueReceiptNumber();
      const gatewayRef = referenceNumber || `ref_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;

      const newTransaction: FeePaymentTransaction = {
        id: `txn-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`,
        transactionId,
        receiptNumber,
        feeRecordId: fee.id,
        invoiceNumber: fee.invoiceNumber,
        studentId: fee.studentId,
        studentName: fee.studentName,
        guardianId: guardian?.id || '',
        guardianName: guardian?.name || '',
        academicSessionId: fee.academicSessionId,
        feeType: fee.feeType,
        feeTitle: fee.title,
        amountPaid: parsedAmount,
        amount: parsedAmount,
        paymentMethod: validMethod as PaymentMethod,
        paymentMethodLabel: methodLabel,
        paymentDate: timestamp,
        paymentStatus: 'SUCCESS',
        status: 'SUCCESS',
        gatewayReference: gatewayRef,
        referenceNumber: referenceNumber || undefined,
        notes: notes || `Payment collected at finance counter by ${req.user!.name}`,
        payerEmail: guardian?.email || studentProfile?.email,
        payerPhone: guardian?.phone || studentProfile?.phone,
        collectedById: req.user!.id,
        collectedByName: req.user!.name,
        collectedBy: req.user!.name,
        previousDue: remainingDue,
        remainingDue: Math.max(0, parseFloat((remainingDue - parsedAmount).toFixed(2))),
        isReversed: false,
        idempotencyKey: idempotencyKey || undefined,
        createdAt: new Date().toISOString()
      };

      // Push transaction to store
      if (!database.feeTransactions) database.feeTransactions = [];
      database.feeTransactions.unshift(newTransaction);

      // Update invoice financial state
      fee.paidAmount = parseFloat((totalAlreadyPaid + parsedAmount).toFixed(2));
      fee.netPayableAmount = netPayable;
      fee.dueAmount = Math.max(0, parseFloat((netPayable - fee.paidAmount).toFixed(2)));
      fee.status = fee.dueAmount <= 0 ? 'PAID' : 'PARTIAL';
      fee.updatedAt = new Date().toISOString();

      // Update installments if applicable
      if (fee.installments && fee.installments.length > 0) {
        let remainingToAllocate = parsedAmount;
        for (const inst of fee.installments) {
          if (!inst.isPaid && remainingToAllocate >= inst.amount) {
            inst.isPaid = true;
            inst.paidDate = timestamp;
            remainingToAllocate -= inst.amount;
          }
        }
      }

      // Audit Log
      logAudit({
        userId: req.user!.id,
        userRole: req.user!.role,
        action: 'COLLECT_FEE_PAYMENT',
        entityType: 'FeePaymentTransaction',
        entityId: newTransaction.id,
        details: `Collected payment of $${parsedAmount.toFixed(2)} via ${methodLabel} for student ${fee.studentName} (Invoice: ${fee.invoiceNumber}, Receipt: ${receiptNumber}, Remaining Due: $${fee.dueAmount.toFixed(2)}).`,
        ipAddress: req.ip || '127.0.0.1'
      });

      // Notification for guardian if available
      if (guardian) {
        database.notifications.unshift({
          id: `notif-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
          userId: guardian.userId,
          title: 'Fee Payment Received',
          message: `Payment of $${parsedAmount.toFixed(2)} received for "${fee.title}" (${fee.studentName}). Receipt #${receiptNumber}. Outstanding balance: $${fee.dueAmount.toFixed(2)}.`,
          type: 'success',
          category: 'fee',
          isRead: false,
          createdAt: new Date().toISOString(),
          link: '/guardian/fees'
        });
      }

      // Notification for student
      if (studentProfile?.userId) {
        database.notifications.unshift({
          id: `notif-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
          userId: studentProfile.userId,
          title: 'Fee Payment Recorded',
          message: `Fee payment of $${parsedAmount.toFixed(2)} recorded for "${fee.title}". Receipt #${receiptNumber}.`,
          type: 'success',
          category: 'fee',
          isRead: false,
          createdAt: new Date().toISOString(),
          link: '/student/fees'
        });
      }

      res.json({
        success: true,
        message: `Payment of $${parsedAmount.toFixed(2)} recorded successfully. Official receipt #${receiptNumber} generated.`,
        data: {
          transaction: newTransaction,
          feeRecord: fee,
          receiptNumber: newTransaction.receiptNumber
        }
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to collect payment',
        code: 'SERVER_ERROR'
      });
    }
  }
);

/**
 * GET /api/fees/payments
 * Filterable, searchable, and paginated payment transaction ledger with summary
 */
feesRouter.get('/payments', (req: AuthenticatedRequest, res: Response): void => {
  try {
    const search = req.query.search as string | undefined;
    const studentId = req.query.studentId as string | undefined;
    const feeRecordId = req.query.feeRecordId as string | undefined;
    const classId = req.query.classId as string | undefined;
    const paymentMethod = req.query.paymentMethod as string | undefined;
    const status = req.query.status as string | undefined;
    const startDate = req.query.startDate as string | undefined;
    const endDate = req.query.endDate as string | undefined;
    const page = req.query.page as string | number | undefined;
    const limit = req.query.limit as string | number | undefined;

    let txns = [...(database.feeTransactions || [])];

    const user = req.user!;
    if (user.role === 'STUDENT') {
      const studentProfile = (database.studentProfiles || []).find((s) => s.userId === user.id);
      if (!studentProfile) {
        txns = [];
      } else {
        txns = txns.filter((t) => t.studentId === studentProfile.id);
      }
    } else if (user.role === 'GUARDIAN') {
      const guardian = (database.guardians || []).find((g) => g.userId === user.id);
      if (!guardian || !guardian.studentIds || guardian.studentIds.length === 0) {
        txns = [];
      } else {
        txns = txns.filter((t) => guardian.studentIds.includes(t.studentId));
        if (studentId && studentId !== 'ALL' && !guardian.studentIds.includes(studentId)) {
          res.status(403).json({
            success: false,
            error: 'Access Denied: You are not authorized to view payments for this student.',
            code: 'FORBIDDEN'
          });
          return;
        }
      }
    } else if (user.role !== 'SUPER_ADMIN') {
      if (!hasPermission(user.role, 'fees.view')) {
        res.status(403).json({
          success: false,
          error: 'Access Denied: Unauthorized to access payment records.',
          code: 'FORBIDDEN'
        });
        return;
      }
    }

    // Filter by studentId
    if (studentId && studentId !== 'ALL') {
      txns = txns.filter((t) => t.studentId === studentId);
    }

    // Filter by feeRecordId
    if (feeRecordId && feeRecordId !== 'ALL') {
      txns = txns.filter((t) => t.feeRecordId === feeRecordId);
    }

    // Filter by payment method
    if (paymentMethod && paymentMethod !== 'ALL') {
      txns = txns.filter(
        (t) => t.paymentMethod === paymentMethod || t.paymentMethod?.toLowerCase() === paymentMethod.toLowerCase()
      );
    }

    // Filter by status (ALL, SUCCESS, REVERSED)
    if (status && status !== 'ALL') {
      if (status === 'REVERSED') {
        txns = txns.filter((t) => t.isReversed || t.paymentStatus === 'REVERSED');
      } else if (status === 'SUCCESS') {
        txns = txns.filter((t) => !t.isReversed && (t.paymentStatus === 'SUCCESS' || t.status === 'SUCCESS'));
      } else {
        txns = txns.filter((t) => t.paymentStatus === status || t.status === status);
      }
    }

    // Filter by date range
    if (startDate) {
      const start = new Date(startDate);
      start.setHours(0, 0, 0, 0);
      txns = txns.filter((t) => new Date(t.paymentDate || t.createdAt) >= start);
    }
    if (endDate) {
      const end = new Date(endDate);
      end.setHours(23, 59, 59, 999);
      txns = txns.filter((t) => new Date(t.paymentDate || t.createdAt) <= end);
    }

    // Search query
    if (search && search.trim()) {
      const q = search.trim().toLowerCase();
      txns = txns.filter(
        (t) =>
          (t.receiptNumber && t.receiptNumber.toLowerCase().includes(q)) ||
          (t.transactionId && t.transactionId.toLowerCase().includes(q)) ||
          (t.studentName && t.studentName.toLowerCase().includes(q)) ||
          (t.feeTitle && t.feeTitle.toLowerCase().includes(q)) ||
          (t.invoiceNumber && t.invoiceNumber.toLowerCase().includes(q)) ||
          (t.referenceNumber && t.referenceNumber.toLowerCase().includes(q)) ||
          (t.notes && t.notes.toLowerCase().includes(q)) ||
          (t.collectedByName && t.collectedByName.toLowerCase().includes(q))
      );
    }

    // Calculate Summary Stats
    const totalTransactions = txns.length;
    let totalCollected = 0;
    let reversedCount = 0;
    let reversedAmount = 0;

    for (const t of txns) {
      const amt = Number(t.amountPaid || t.amount) || 0;
      if (t.isReversed || t.paymentStatus === 'REVERSED') {
        reversedCount++;
        reversedAmount += amt;
      } else if (t.paymentStatus === 'SUCCESS' || t.status === 'SUCCESS' || !t.paymentStatus) {
        totalCollected += amt;
      }
    }

    // Pagination
    const pageNum = Math.max(1, parseInt(page as any, 10) || 1);
    const pageSize = Math.max(1, Math.min(100, parseInt(limit as any, 10) || 15));
    const totalPages = Math.ceil(totalTransactions / pageSize) || 1;
    const paginatedTransactions = txns.slice((pageNum - 1) * pageSize, pageNum * pageSize);

    const responseData: FeePaymentListResponse = {
      transactions: paginatedTransactions,
      total: totalTransactions,
      page: pageNum,
      limit: pageSize,
      totalPages,
      summary: {
        totalCollected: parseFloat(totalCollected.toFixed(2)),
        totalTransactions,
        reversedCount,
        reversedAmount: parseFloat(reversedAmount.toFixed(2))
      }
    };

    res.json({ success: true, data: responseData });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to fetch payments ledger',
      code: 'SERVER_ERROR'
    });
  }
});

/**
 * GET /api/fees/payments/stats
 * Summary statistics for the fee collection dashboard
 */
feesRouter.get('/payments/stats', (req: AuthenticatedRequest, res: Response): void => {
  try {
    const allTxns = database.feeTransactions || [];
    const allFees = database.feeRecords || [];

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const firstDayOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);

    let totalCollectedToday = 0;
    let totalCollectedMonth = 0;
    let totalCollectedAllTime = 0;
    let reversedTransactionsCount = 0;
    let reversedAmount = 0;

    for (const t of allTxns) {
      const amt = Number(t.amountPaid || t.amount) || 0;
      const tDate = new Date(t.paymentDate || t.createdAt);

      if (t.isReversed || t.paymentStatus === 'REVERSED') {
        reversedTransactionsCount++;
        reversedAmount += amt;
      } else if (t.paymentStatus === 'SUCCESS' || t.status === 'SUCCESS' || !t.paymentStatus) {
        totalCollectedAllTime += amt;
        if (tDate >= today) {
          totalCollectedToday += amt;
        }
        if (tDate >= firstDayOfMonth) {
          totalCollectedMonth += amt;
        }
      }
    }

    let activeInvoicesWithDue = 0;
    let totalDueOutstanding = 0;

    for (const f of allFees) {
      if (f.status !== 'CANCELLED' && f.status !== 'DRAFT') {
        const due = Number(f.dueAmount) || 0;
        if (due > 0) {
          activeInvoicesWithDue++;
          totalDueOutstanding += due;
        }
      }
    }

    const stats: FeeCollectionSummaryStats = {
      totalCollectedToday: parseFloat(totalCollectedToday.toFixed(2)),
      totalCollectedMonth: parseFloat(totalCollectedMonth.toFixed(2)),
      totalCollectedAllTime: parseFloat(totalCollectedAllTime.toFixed(2)),
      totalTransactions: allTxns.length,
      reversedTransactionsCount,
      reversedAmount: parseFloat(reversedAmount.toFixed(2)),
      activeInvoicesWithDue,
      totalDueOutstanding: parseFloat(totalDueOutstanding.toFixed(2))
    };

    res.json({ success: true, data: stats });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to fetch collection stats',
      code: 'SERVER_ERROR'
    });
  }
});

/**
 * GET /api/fees/payments/:id/receipt
 * Universal official receipt generator for a transaction ID or Receipt Number
 */
feesRouter.get('/payments/:id/receipt', (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { id } = req.params;
    const transaction = (database.feeTransactions || []).find(
      (t) => t.id === id || t.transactionId === id || t.receiptNumber === id
    );

    if (!transaction) {
      res.status(404).json({
        success: false,
        error: 'Payment transaction record not found.',
        code: 'TRANSACTION_NOT_FOUND'
      });
      return;
    }

    // Role-based security check
    if (req.user?.role === 'GUARDIAN') {
      const guardian = database.guardians.find((g) => g.userId === req.user!.id);
      if (!guardian || !guardian.studentIds.includes(transaction.studentId)) {
        res.status(403).json({
          success: false,
          error: 'Access Denied: You are not authorized to view receipts for this student.',
          code: 'UNAUTHORIZED_RECEIPT_ACCESS'
        });
        return;
      }
    } else if (req.user?.role === 'STUDENT') {
      const studentProfile = database.studentProfiles.find((s) => s.userId === req.user!.id);
      if (!studentProfile || studentProfile.id !== transaction.studentId) {
        res.status(403).json({
          success: false,
          error: 'Access Denied: You cannot view receipts for other students.',
          code: 'UNAUTHORIZED_RECEIPT_ACCESS'
        });
        return;
      }
    }

    const fee = (database.feeRecords || []).find((f) => f.id === transaction.feeRecordId);
    const student = database.studentProfiles.find((s) => s.id === transaction.studentId);
    const guardian = database.guardians.find((g) => g.studentIds.includes(transaction.studentId));
    const school = database.schoolSettings || {
      name: 'Sygmate International Academy',
      code: 'SIA-HQ-01',
      address: '742 Evergreen Academic Way, Silicon Valley Campus',
      phone: '+1 (800) 555-0199',
      email: 'finance@sygmate-academy.edu',
      currency: 'USD',
      currencySymbol: '$'
    };

    const studentClass = database.classes.find((c) => c.id === student?.classId);
    const studentSection = database.sections.find((s) => s.id === student?.sectionId);

    const totalFee = fee ? fee.totalAmount : transaction.amountPaid;
    const discount = fee ? fee.discountAmount : 0;
    const fine = fee ? (fee.fineAmount || 0) : 0;
    const netPayable = fee ? fee.netPayableAmount : transaction.amountPaid;
    const previouslyPaid = transaction.previousDue !== undefined && fee
      ? Math.max(0, netPayable - transaction.previousDue)
      : Math.max(0, (fee?.paidAmount || 0) - transaction.amountPaid);
    const remainingDue = transaction.remainingDue !== undefined
      ? transaction.remainingDue
      : (fee?.dueAmount || 0);

    const receipt: FeePaymentReceipt = {
      receiptNumber: transaction.receiptNumber,
      transactionId: transaction.transactionId,
      schoolInfo: {
        name: (school as any).name || (school as any).schoolName || 'Sygmate International Academy',
        code: (school as any).code || (school as any).schoolCode || 'SIA-HQ-01',
        address: (school as any).address || '742 Evergreen Academic Way, Silicon Valley Campus',
        phone: (school as any).phone || (school as any).contactPhone || '+1 (800) 555-0199',
        email: (school as any).email || (school as any).contactEmail || 'finance@sygmate-academy.edu',
        website: (school as any).website || 'https://sygmate-school.edu',
        affiliationNumber: (school as any).affiliationNumber || 'CBSE-INTL-2026-9901',
        principalName: (school as any).principalName || 'Dr. Evelyn Montgomery',
        currency: (school as any).currency || 'USD',
        currencySymbol: (school as any).currencySymbol || '$'
      },
      studentInfo: {
        id: student?.id || transaction.studentId,
        name: student?.firstName
          ? `${student.firstName} ${student.lastName || ''}`.trim()
          : transaction.studentName,
        admissionNumber: student?.admissionNumber || 'ADM-2026-0000',
        rollNumber: student?.rollNumber || '01',
        className: studentClass?.name || fee?.className || 'Grade 10',
        sectionName: studentSection?.name || fee?.sectionName || 'Section A'
      },
      guardianInfo: guardian
        ? {
            id: guardian.id,
            name: guardian.name,
            relation: (guardian as any).relation || (guardian as any).relationship || 'Parent',
            phone: guardian.phone,
            email: guardian.email
          }
        : undefined,
      feeInfo: {
        feeRecordId: transaction.feeRecordId,
        invoiceNumber: fee?.invoiceNumber || transaction.invoiceNumber || 'INV-2026-0000',
        feeType: transaction.feeType,
        title: transaction.feeTitle,
        academicSession: fee?.academicSessionName || '2026-2027 Academic Year',
        term: fee?.term || 'ANNUAL',
        totalFee,
        discount,
        fine,
        netPayable,
        previouslyPaid,
        amountPaidNow: transaction.amountPaid,
        remainingDue
      },
      paymentDetails: {
        paymentDate: transaction.paymentDate || transaction.createdAt,
        paymentMethod: transaction.paymentMethod,
        paymentMethodLabel: transaction.paymentMethodLabel,
        paymentStatus: transaction.isReversed ? 'REVERSED' : transaction.paymentStatus,
        gatewayReference: transaction.gatewayReference,
        referenceNumber: transaction.referenceNumber,
        authorizedSignatory: 'Accounts & Bursar Department',
        collectedBy: transaction.collectedByName || transaction.collectedBy || 'Finance Office',
        notes: transaction.notes,
        isReversed: transaction.isReversed || transaction.paymentStatus === 'REVERSED',
        reversedAt: transaction.reversedAt,
        reversalReason: transaction.reversalReason,
        reversedByName: transaction.reversedByName
      },
      issuedAt: transaction.createdAt
    };

    logAudit({
      userId: req.user!.id,
      userRole: req.user!.role,
      action: 'VIEW_FEE_RECEIPT',
      entityType: 'FeePaymentReceipt',
      entityId: transaction.id,
      details: `Generated payment receipt #${transaction.receiptNumber} (${transaction.transactionId}) for student ${transaction.studentName}.`,
      ipAddress: req.ip || '127.0.0.1'
    });

    res.json({ success: true, data: receipt });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to generate receipt',
      code: 'SERVER_ERROR'
    });
  }
});

/**
 * POST /api/fees/payments/:id/reverse
 * Reverse / void an incorrect fee payment.
 * Preserves financial audit history and safely recalculates the invoice balance.
 */
feesRouter.post(
  '/payments/:id/reverse',
  requireRole('SUPER_ADMIN'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const { id } = req.params;
      const { reason }: ReverseFeePaymentPayload = req.body;

      if (!reason || typeof reason !== 'string' || reason.trim().length < 3) {
        res.status(400).json({
          success: false,
          error: 'A valid mandatory reason (minimum 3 characters) is required to reverse a payment.',
          code: 'MISSING_REVERSAL_REASON'
        });
        return;
      }

      const transaction = (database.feeTransactions || []).find(
        (t) => t.id === id || t.transactionId === id || t.receiptNumber === id
      );

      if (!transaction) {
        res.status(404).json({
          success: false,
          error: 'Payment transaction record not found.',
          code: 'TRANSACTION_NOT_FOUND'
        });
        return;
      }

      if (transaction.isReversed || transaction.paymentStatus === 'REVERSED') {
        res.status(400).json({
          success: false,
          error: `Payment transaction #${transaction.receiptNumber} has already been voided/reversed on ${new Date(transaction.reversedAt || '').toLocaleDateString()}.`,
          code: 'TRANSACTION_ALREADY_REVERSED'
        });
        return;
      }

      const timestamp = new Date().toISOString();

      // Mark transaction as reversed
      transaction.isReversed = true;
      transaction.paymentStatus = 'REVERSED';
      transaction.status = 'REVERSED';
      transaction.reversedAt = timestamp;
      transaction.reversedById = req.user!.id;
      transaction.reversedByName = req.user!.name;
      transaction.reversalReason = reason.trim();

      // Recalculate linked student fee invoice balance safely
      const fee = (database.feeRecords || []).find((f) => f.id === transaction.feeRecordId);
      if (fee) {
        const remainingActiveTxns = (database.feeTransactions || []).filter(
          (t) => t.feeRecordId === fee.id && t.paymentStatus === 'SUCCESS' && !t.isReversed
        );
        const validPaidSum = remainingActiveTxns.reduce(
          (sum, t) => sum + (Number(t.amountPaid) || 0),
          0
        );

        fee.paidAmount = parseFloat(validPaidSum.toFixed(2));
        const totalAmount = Number(fee.totalAmount) || 0;
        const discountAmount = Number(fee.discountAmount) || 0;
        const fineAmount = Number(fee.fineAmount) || 0;
        fee.netPayableAmount = Math.max(0, parseFloat((totalAmount - discountAmount + fineAmount).toFixed(2)));
        fee.dueAmount = Math.max(0, parseFloat((fee.netPayableAmount - fee.paidAmount).toFixed(2)));

        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const dueDate = new Date(fee.dueDate);
        const isOverdue = !isNaN(dueDate.getTime()) && dueDate < today;

        if (fee.status !== 'CANCELLED' && fee.status !== 'DRAFT') {
          if (fee.dueAmount <= 0 && (fee.paidAmount > 0 || fee.netPayableAmount === 0)) {
            fee.status = 'PAID';
          } else if (fee.paidAmount > 0 && fee.dueAmount > 0) {
            fee.status = 'PARTIAL';
          } else if (isOverdue && fee.dueAmount > 0) {
            fee.status = 'OVERDUE';
          } else {
            fee.status = 'DUE';
          }
        }
        fee.updatedAt = timestamp;
      }

      // Audit Log
      logAudit({
        userId: req.user!.id,
        userRole: req.user!.role,
        action: 'REVERSE_FEE_PAYMENT',
        entityType: 'FeePaymentTransaction',
        entityId: transaction.id,
        details: `Reversed/voided payment of $${transaction.amountPaid.toFixed(2)} (Receipt: ${transaction.receiptNumber}, Txn: ${transaction.transactionId}) for student ${transaction.studentName}. Reason: "${reason.trim()}". New outstanding balance: $${fee ? fee.dueAmount.toFixed(2) : 'N/A'}.`,
        ipAddress: req.ip || '127.0.0.1'
      });

      // Notify guardian if exists
      const guardian = database.guardians.find((g) => g.studentIds.includes(transaction.studentId));
      if (guardian) {
        database.notifications.unshift({
          id: `notif-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
          userId: guardian.userId,
          title: 'Payment Voided / Adjusted',
          message: `Payment receipt #${transaction.receiptNumber} ($${transaction.amountPaid.toFixed(2)}) for "${transaction.feeTitle}" was reversed. Reason: ${reason.trim()}. Outstanding balance is now $${fee?.dueAmount.toFixed(2)}.`,
          type: 'warning',
          category: 'fee',
          isRead: false,
          createdAt: timestamp,
          link: '/guardian/fees'
        });
      }

      res.json({
        success: true,
        message: `Payment transaction #${transaction.receiptNumber} has been successfully voided. Invoice balance recalculated.`,
        data: {
          transaction,
          feeRecord: fee
        }
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to reverse payment',
        code: 'SERVER_ERROR'
      });
    }
  }
);


