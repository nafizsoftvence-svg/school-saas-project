/**
 * Sygmate School Management System
 * Staff Performance Management (Part 12E)
 * API Router: /api/staff/performance
 */

import { Router, Response } from 'express';
import { requireAuth, requirePermission, AuthenticatedRequest } from '../security/auth.js';
import { staffPerformanceService } from '../services/staff-performance.service.js';
import {
  CreateReviewCyclePayload,
  UpdateReviewCyclePayload,
  CreatePerformanceCriterionPayload,
  UpdatePerformanceCriterionPayload,
  CreatePerformanceGoalPayload,
  UpdatePerformanceGoalPayload,
  UpdateGoalProgressPayload,
  CreatePerformanceReviewPayload,
  SubmitSelfAssessmentPayload,
  SubmitSupervisorReviewPayload,
  SubmitHRReviewPayload,
  OverrideRatingPayload,
  AcknowledgeReviewPayload,
  TransitionReviewWorkflowPayload,
  CreatePerformanceFeedbackPayload,
  CreatePIPPayload,
  UpdatePIPPayload,
  AddPIPProgressNotePayload,
  UpdatePIPActionPayload,
  ClosePIPPayload
} from '../../src/types/index.js';

export const staffPerformanceRouter = Router();

// ==========================================
// 1. DASHBOARD & METRICS
// ==========================================

/**
 * GET /api/staff/performance/metrics
 * Performance overview KPIs, counts, distributions
 */
staffPerformanceRouter.get(
  '/metrics',
  requireAuth,
  requirePermission('staff.performance.view'),
  (_req: AuthenticatedRequest, res: Response): void => {
    try {
      const metrics = staffPerformanceService.getDashboardMetrics();
      res.json({ success: true, data: metrics });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  }
);

// ==========================================
// 2. REVIEW CYCLES
// ==========================================

staffPerformanceRouter.get(
  '/cycles',
  requireAuth,
  requirePermission('staff.performance.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const result = staffPerformanceService.listReviewCycles(req.query as any);
      res.json({ success: true, data: result });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  }
);

staffPerformanceRouter.get(
  '/cycles/:id',
  requireAuth,
  requirePermission('staff.performance.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const cycle = staffPerformanceService.getReviewCycleById(req.params.id);
      if (!cycle) {
        res.status(404).json({ success: false, message: 'Review cycle not found.' });
        return;
      }
      res.json({ success: true, data: cycle });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  }
);

staffPerformanceRouter.post(
  '/cycles',
  requireAuth,
  requirePermission('staff.performance.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const payload = req.body as CreateReviewCyclePayload;
      if (!payload.name || !payload.code || !payload.startDate || !payload.endDate) {
        res.status(400).json({
          success: false,
          message: 'Missing required cycle attributes: name, code, startDate, endDate.'
        });
        return;
      }
      const created = staffPerformanceService.createReviewCycle(payload, req.user);
      res.status(201).json({ success: true, data: created });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  }
);

staffPerformanceRouter.put(
  '/cycles/:id',
  requireAuth,
  requirePermission('staff.performance.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const updated = staffPerformanceService.updateReviewCycle(
        req.params.id,
        req.body as UpdateReviewCyclePayload,
        req.user
      );
      res.json({ success: true, data: updated });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  }
);

staffPerformanceRouter.post(
  '/cycles/:id/status',
  requireAuth,
  requirePermission('staff.performance.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const { status } = req.body;
      if (!status) {
        res.status(400).json({ success: false, message: 'Target status is required.' });
        return;
      }
      const updated = staffPerformanceService.transitionReviewCycleStatus(
        req.params.id,
        status,
        req.user
      );
      res.json({ success: true, data: updated });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  }
);

staffPerformanceRouter.post(
  '/cycles/:id/generate-reviews',
  requireAuth,
  requirePermission('staff.performance.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const result = staffPerformanceService.generateReviewsForCycle(req.params.id, req.user);
      res.json({
        success: true,
        message: `Successfully initiated ${result.generatedCount} review dossiers.`,
        data: result
      });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  }
);

// ==========================================
// 3. PERFORMANCE CRITERIA & KPIS
// ==========================================

staffPerformanceRouter.get(
  '/criteria',
  requireAuth,
  requirePermission('staff.performance.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const criteria = staffPerformanceService.listCriteria(req.query as any);
      res.json({ success: true, data: criteria });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  }
);

staffPerformanceRouter.get(
  '/criteria/:id',
  requireAuth,
  requirePermission('staff.performance.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const item = staffPerformanceService.getCriterionById(req.params.id);
      if (!item) {
        res.status(404).json({ success: false, message: 'Criterion not found.' });
        return;
      }
      res.json({ success: true, data: item });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  }
);

staffPerformanceRouter.post(
  '/criteria',
  requireAuth,
  requirePermission('staff.performance.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const payload = req.body as CreatePerformanceCriterionPayload;
      if (!payload.name || !payload.code || !payload.category || payload.weight === undefined) {
        res.status(400).json({
          success: false,
          message: 'Missing required criterion attributes: name, code, category, weight.'
        });
        return;
      }
      const created = staffPerformanceService.createCriterion(payload, req.user);
      res.status(201).json({ success: true, data: created });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  }
);

staffPerformanceRouter.put(
  '/criteria/:id',
  requireAuth,
  requirePermission('staff.performance.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const updated = staffPerformanceService.updateCriterion(
        req.params.id,
        req.body as UpdatePerformanceCriterionPayload,
        req.user
      );
      res.json({ success: true, data: updated });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  }
);

staffPerformanceRouter.post(
  '/criteria/:id/toggle',
  requireAuth,
  requirePermission('staff.performance.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const updated = staffPerformanceService.toggleCriterionActive(req.params.id, req.user);
      res.json({ success: true, data: updated });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  }
);

// ==========================================
// 4. PERFORMANCE GOALS & PROGRESS
// ==========================================

staffPerformanceRouter.get(
  '/goals',
  requireAuth,
  requirePermission('staff.performance.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const goals = staffPerformanceService.listGoals(req.query as any);
      res.json({ success: true, data: goals });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  }
);

staffPerformanceRouter.get(
  '/goals/:id',
  requireAuth,
  requirePermission('staff.performance.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const goal = staffPerformanceService.getGoalById(req.params.id);
      if (!goal) {
        res.status(404).json({ success: false, message: 'Performance goal not found.' });
        return;
      }
      res.json({ success: true, data: goal });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  }
);

staffPerformanceRouter.post(
  '/goals',
  requireAuth,
  requirePermission('staff.performance.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const payload = req.body as CreatePerformanceGoalPayload;
      if (!payload.staffId || !payload.reviewCycleId || !payload.title || !payload.target) {
        res.status(400).json({
          success: false,
          message: 'Missing required goal attributes: staffId, reviewCycleId, title, target.'
        });
        return;
      }
      const created = staffPerformanceService.createGoal(payload, req.user);
      res.status(201).json({ success: true, data: created });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  }
);

staffPerformanceRouter.put(
  '/goals/:id',
  requireAuth,
  requirePermission('staff.performance.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const updated = staffPerformanceService.updateGoal(
        req.params.id,
        req.body as UpdatePerformanceGoalPayload,
        req.user
      );
      res.json({ success: true, data: updated });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  }
);

staffPerformanceRouter.put(
  '/goals/:id/progress',
  requireAuth,
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const updated = staffPerformanceService.updateGoalProgress(
        req.params.id,
        req.body as UpdateGoalProgressPayload,
        req.user
      );
      res.json({ success: true, data: updated });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  }
);

// ==========================================
// 5. STAFF PERFORMANCE REVIEWS (WORKFLOW)
// ==========================================

staffPerformanceRouter.get(
  '/reviews',
  requireAuth,
  requirePermission('staff.performance.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const result = staffPerformanceService.listReviews(req.query as any, req.user);
      res.json({ success: true, data: result });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  }
);

staffPerformanceRouter.get(
  '/reviews/my-review',
  requireAuth,
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      if (!req.user) {
        res.status(401).json({ success: false, message: 'Authentication required.' });
        return;
      }
      const review = staffPerformanceService.getMyActiveReview(req.user);
      res.json({ success: true, data: review });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  }
);

staffPerformanceRouter.get(
  '/reviews/:id',
  requireAuth,
  requirePermission('staff.performance.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const review = staffPerformanceService.getReviewById(req.params.id, req.user);
      res.json({ success: true, data: review });
    } catch (err: any) {
      res.status(err.message.includes('Access denied') ? 403 : 404).json({
        success: false,
        message: err.message
      });
    }
  }
);

staffPerformanceRouter.post(
  '/reviews',
  requireAuth,
  requirePermission('staff.performance.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const payload = req.body as CreatePerformanceReviewPayload;
      if (!payload.reviewCycleId || !payload.staffId) {
        res.status(400).json({
          success: false,
          message: 'Missing required review fields: reviewCycleId, staffId.'
        });
        return;
      }
      const created = staffPerformanceService.createReview(payload, req.user);
      res.status(201).json({ success: true, data: created });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  }
);

staffPerformanceRouter.post(
  '/reviews/:id/self-assessment',
  requireAuth,
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const payload = req.body as SubmitSelfAssessmentPayload;
      if (!payload.achievementSummary || payload.selfRating === undefined) {
        res.status(400).json({
          success: false,
          message: 'Missing self-assessment details: achievementSummary and selfRating (1-5).'
        });
        return;
      }
      const updated = staffPerformanceService.submitSelfAssessment(
        req.params.id,
        payload,
        req.user
      );
      res.json({
        success: true,
        message: 'Self-assessment submitted successfully.',
        data: updated
      });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  }
);

staffPerformanceRouter.post(
  '/reviews/:id/supervisor-review',
  requireAuth,
  requirePermission('staff.performance.evaluate'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const payload = req.body as SubmitSupervisorReviewPayload;
      if (!payload.criteriaScores || payload.criteriaScores.length === 0) {
        res.status(400).json({
          success: false,
          message: 'At least one criterion score is required for supervisor evaluation.'
        });
        return;
      }
      const updated = staffPerformanceService.submitSupervisorReview(
        req.params.id,
        payload,
        req.user
      );
      res.json({
        success: true,
        message: 'Supervisor scores and comments submitted successfully.',
        data: updated
      });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  }
);

staffPerformanceRouter.post(
  '/reviews/:id/hr-review',
  requireAuth,
  requirePermission('staff.performance.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const payload = req.body as SubmitHRReviewPayload;
      const updated = staffPerformanceService.submitHRReview(req.params.id, payload, req.user);
      res.json({
        success: true,
        message: 'HR review finalized successfully.',
        data: updated
      });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  }
);

staffPerformanceRouter.post(
  '/reviews/:id/override',
  requireAuth,
  requirePermission('staff.performance.override'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const payload = req.body as OverrideRatingPayload;
      if (payload.overrideScore === undefined || !payload.overrideRatingBand || !payload.reason) {
        res.status(400).json({
          success: false,
          message: 'Override requires overrideScore, overrideRatingBand, and mandatory justification reason.'
        });
        return;
      }
      const updated = staffPerformanceService.overrideReviewRating(
        req.params.id,
        payload,
        req.user
      );
      res.json({
        success: true,
        message: 'Rating overridden and audited successfully.',
        data: updated
      });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  }
);

staffPerformanceRouter.post(
  '/reviews/:id/acknowledge',
  requireAuth,
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const payload = req.body as AcknowledgeReviewPayload;
      const updated = staffPerformanceService.acknowledgeReview(
        req.params.id,
        payload,
        req.user
      );
      res.json({
        success: true,
        message: 'Performance review signed off and acknowledged.',
        data: updated
      });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  }
);

staffPerformanceRouter.post(
  '/reviews/:id/transition',
  requireAuth,
  requirePermission('staff.performance.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const payload = req.body as TransitionReviewWorkflowPayload;
      if (!payload.targetStatus) {
        res.status(400).json({ success: false, message: 'Target status is required.' });
        return;
      }
      const updated = staffPerformanceService.transitionReviewWorkflow(
        req.params.id,
        payload,
        req.user
      );
      res.json({ success: true, data: updated });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  }
);

// ==========================================
// 6. PERFORMANCE FEEDBACK
// ==========================================

staffPerformanceRouter.get(
  '/feedback',
  requireAuth,
  requirePermission('staff.performance.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const items = staffPerformanceService.listFeedback(
        req.query.staffId as string,
        req.query.reviewId as string
      );
      res.json({ success: true, data: items });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  }
);

staffPerformanceRouter.post(
  '/feedback',
  requireAuth,
  requirePermission('staff.performance.evaluate'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const payload = req.body as CreatePerformanceFeedbackPayload;
      if (!payload.staffId || !payload.feedbackType || !payload.strengths) {
        res.status(400).json({
          success: false,
          message: 'Missing feedback fields: staffId, feedbackType, strengths.'
        });
        return;
      }
      const created = staffPerformanceService.createFeedback(payload, req.user);
      res.status(201).json({ success: true, data: created });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  }
);

staffPerformanceRouter.post(
  '/feedback/:id/acknowledge',
  requireAuth,
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const updated = staffPerformanceService.acknowledgeFeedback(
        req.params.id,
        req.body.note,
        req.user
      );
      res.json({ success: true, data: updated });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  }
);

// ==========================================
// 7. PERFORMANCE IMPROVEMENT PLANS (PIP)
// ==========================================

staffPerformanceRouter.get(
  '/pips',
  requireAuth,
  requirePermission('staff.performance.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const pips = staffPerformanceService.listPIPs(req.query as any);
      res.json({ success: true, data: pips });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  }
);

staffPerformanceRouter.get(
  '/pips/:id',
  requireAuth,
  requirePermission('staff.performance.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const pip = staffPerformanceService.getPIPById(req.params.id);
      if (!pip) {
        res.status(404).json({ success: false, message: 'PIP not found.' });
        return;
      }
      res.json({ success: true, data: pip });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  }
);

staffPerformanceRouter.post(
  '/pips',
  requireAuth,
  requirePermission('staff.performance.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const payload = req.body as CreatePIPPayload;
      if (!payload.staffId || !payload.reason || !payload.targetDate || !payload.assignedSupervisorId) {
        res.status(400).json({
          success: false,
          message: 'Missing required PIP fields: staffId, reason, targetDate, assignedSupervisorId.'
        });
        return;
      }
      const created = staffPerformanceService.createPIP(payload, req.user);
      res.status(201).json({ success: true, data: created });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  }
);

staffPerformanceRouter.put(
  '/pips/:id',
  requireAuth,
  requirePermission('staff.performance.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const updated = staffPerformanceService.updatePIP(
        req.params.id,
        req.body as UpdatePIPPayload,
        req.user
      );
      res.json({ success: true, data: updated });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  }
);

staffPerformanceRouter.post(
  '/pips/:id/notes',
  requireAuth,
  requirePermission('staff.performance.evaluate'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const updated = staffPerformanceService.addPIPProgressNote(
        req.params.id,
        req.body as AddPIPProgressNotePayload,
        req.user
      );
      res.json({ success: true, data: updated });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  }
);

staffPerformanceRouter.put(
  '/pips/:id/actions/:actionId',
  requireAuth,
  requirePermission('staff.performance.evaluate'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const updated = staffPerformanceService.updatePIPAction(
        req.params.id,
        req.params.actionId,
        req.body as UpdatePIPActionPayload,
        req.user
      );
      res.json({ success: true, data: updated });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  }
);

staffPerformanceRouter.post(
  '/pips/:id/close',
  requireAuth,
  requirePermission('staff.performance.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const payload = req.body as ClosePIPPayload;
      if (!payload.outcome) {
        res.status(400).json({ success: false, message: 'Resolution outcome is required.' });
        return;
      }
      const updated = staffPerformanceService.closePIP(req.params.id, payload, req.user);
      res.json({
        success: true,
        message: `PIP closed with outcome: ${payload.outcome}`,
        data: updated
      });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  }
);

// ==========================================
// 8. REPORTS & ANALYTICS
// ==========================================

staffPerformanceRouter.get(
  '/reports/summary',
  requireAuth,
  requirePermission('staff.performance.reports'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const cycleId = req.query.cycleId as string;
      if (!cycleId) {
        res.status(400).json({ success: false, message: 'cycleId query parameter is required.' });
        return;
      }
      const summary = staffPerformanceService.getPerformanceReportSummary(cycleId);
      res.json({ success: true, data: summary });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  }
);
