import { Router, Response } from 'express';
import { database } from '../db/database.js';
import { requireAuth, AuthenticatedRequest } from '../security/auth.js';
import {
  SuperAdminDashboardData,
  TeacherDashboardData,
  StudentDashboardData
} from '../../src/types/index.js';

export const dashboardRouter = Router();

/**
 * GET /api/dashboard/admin
 */
dashboardRouter.get('/admin', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const activeSession = database.academicSessions.find((s) => s.isActive) || null;
    
    // Students
    const allStudents = database.studentProfiles;
    const totalStudents = allStudents.length;
    const activeStudents = allStudents.filter((s) => s.status.toLowerCase() === 'active').length;
    const inactiveStudents = totalStudents - activeStudents;

    // Teachers
    const allTeachers = database.teacherProfiles;
    const totalTeachers = allTeachers.length;
    const activeTeachers = allTeachers.filter((t) => t.status.toLowerCase() === 'active').length;
    const inactiveTeachers = totalTeachers - activeTeachers;

    // Academic Structure
    const totalClasses = database.classes.length;
    const totalSections = database.sections.length;
    const totalSubjects = database.subjects.length;

    // School Profile Check
    const settings = database.schoolSettings;
    const hasCoreInfo = Boolean(
      settings &&
      settings.schoolName &&
      settings.schoolCode &&
      settings.contactEmail &&
      settings.contactPhone &&
      settings.address
    );

    const data: SuperAdminDashboardData = {
      metrics: {
        totalStudents,
        activeStudents,
        inactiveStudents,
        totalTeachers,
        activeTeachers,
        inactiveTeachers,
        totalClasses,
        totalSections,
        totalSubjects,
        currentAcademicSession: activeSession ? activeSession.sessionName : 'No active academic session',
        schoolName: settings?.schoolName || 'Sygmate Academy',
        schoolCode: settings?.schoolCode || 'SIA-2026',
        schoolType: settings?.schoolType || 'International',
        systemHealth: '100%',
        recentAuditCount: database.auditLogs.length,
        isProfileComplete: hasCoreInfo
      },
      recentAuditLogs: [...database.auditLogs].reverse().slice(0, 10),
      activeSession: activeSession,
      schoolSettings: settings
    };

    res.json({ success: true, data });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * GET /api/dashboard/teacher
 */
dashboardRouter.get('/teacher', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    const teacherProfile =
      database.teacherProfiles.find((t) => t.userId === user.id) ||
      (user.role === 'SUPER_ADMIN' ? database.teacherProfiles[0] : null);
    if (!teacherProfile) {
      res.status(404).json({ success: false, error: 'Teacher profile not found.' });
      return;
    }
    const teacherUser = database.users.find((u) => u.id === teacherProfile.userId) || user;

    const assignedClassIds = teacherProfile.assignedClassIds || [];
    const assignedSubjectIds = teacherProfile.assignedSubjectIds || [];

    // Real Assigned Classes with Real Student Counts and Sections
    const assignedClasses = database.classes
      .filter((c) => assignedClassIds.includes(c.id))
      .map((cls) => {
        const matchingSections = database.sections.filter((s) => s.classId === cls.id);
        const primarySec = matchingSections.find((s) => s.classTeacherId === teacherProfile.id) || matchingSections[0];
        const studentCount = database.studentProfiles.filter((st) => st.classId === cls.id).length;
        return {
          id: cls.id,
          className: cls.name,
          sectionName: primarySec ? primarySec.name : 'All Sections',
          roomNumber: primarySec ? primarySec.roomNumber : 'Building Main',
          studentCount: studentCount
        };
      });

    // Real Assigned Sections (Unique sections assigned or belonging to assigned classes)
    const assignedSections = database.sections.filter(
      (s) => assignedClassIds.includes(s.classId) || s.classTeacherId === teacherProfile.id
    );

    // Real Assigned Subjects
    const teacherSubjects = database.subjects.filter(
      (s) => s.teacherId === teacherProfile.id || assignedSubjectIds.includes(s.id)
    ).map((sub) => {
      const dept = database.departments.find((d) => d.id === sub.departmentId);
      const classesForSub = database.classes.filter(
        (c) => sub.classId === c.id || sub.classIds?.includes(c.id)
      ).map((c) => c.name);

      return {
        id: sub.id,
        name: sub.name,
        code: sub.code,
        type: sub.type,
        credits: sub.credits,
        departmentName: dept?.name || 'Academic Faculty',
        classNames: classesForSub
      };
    });

    // Real Total Enrolled Students under assigned classes
    const totalStudentsUnderClasses = database.studentProfiles.filter((st) =>
      assignedClassIds.includes(st.classId)
    ).length;

    // Real Notifications for Teacher
    const recentNotifications = database.notifications
      .filter((n) => n.userId === user.id || n.roleTarget === 'ALL' || n.roleTarget === 'TEACHER')
      .slice(-5)
      .reverse();

    // Today's classes schedule (Empty array if no timetable slots scheduled yet)
    const todayClasses: Array<{
      id: string;
      subjectName: string;
      subjectCode: string;
      className: string;
      sectionName: string;
      roomNumber: string;
      timeSlot: string;
    }> = [];

    const nameParts = (teacherUser.name || `${teacherProfile.firstName || ''} ${teacherProfile.lastName || ''}`.trim()).split(' ');
    const firstName = teacherProfile.firstName || nameParts[0] || 'Teacher';
    const lastName = teacherProfile.lastName || nameParts.slice(1).join(' ') || 'Faculty';

    const data: TeacherDashboardData = {
      teacher: {
        ...teacherProfile,
        firstName,
        lastName,
        email: teacherProfile.email || teacherUser.email,
        phone: teacherProfile.contactNumber || teacherProfile.phone || teacherUser.phoneNumber || '',
        avatarUrl: teacherProfile.avatarUrl || teacherUser.avatarUrl,
        status: teacherProfile.status
      },
      metrics: {
        totalAssignedClasses: assignedClassIds.length,
        totalAssignedSections: assignedSections.length,
        totalAssignedSubjects: teacherSubjects.length,
        totalStudentsUnderClasses: totalStudentsUnderClasses,
        myClassesCount: assignedClassIds.length,
        mySubjectsCount: teacherSubjects.length,
        totalStudentsTaught: totalStudentsUnderClasses
      },
      assignedClasses,
      assignedSubjects: teacherSubjects,
      todayClasses,
      recentNotifications
    };

    res.json({ success: true, data });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * GET /api/dashboard/student
 */
dashboardRouter.get('/student', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    let studentProfile = database.studentProfiles.find((s) => s.userId === user.id);

    // If super admin or teacher is previewing without a direct student userId, allow query param or fallback
    if (!studentProfile) {
      if (user.role === 'SUPER_ADMIN' || user.role === 'TEACHER') {
        const queryStudentId = req.query.studentId as string;
        if (queryStudentId) {
          studentProfile = database.studentProfiles.find((s) => s.id === queryStudentId || s.userId === queryStudentId);
        }
        if (!studentProfile) {
          studentProfile = database.studentProfiles[0];
        }
      }
    }

    if (!studentProfile) {
      res.status(404).json({ success: false, error: 'Student profile record not found.' });
      return;
    }

    const studentUser = database.users.find((u) => u.id === studentProfile.userId) || user;
    const studentClass = database.classes.find((c) => c.id === studentProfile.classId) || database.classes[0];
    const studentSection = database.sections.find((s) => s.id === studentProfile.sectionId) || database.sections[0];
    const activeSession =
      database.academicSessions.find((s) => s.id === studentProfile.academicSessionId) ||
      database.academicSessions.find((s) => s.isActive) ||
      database.academicSessions[0];

    // Real Enrolled Subjects for this Class
    const enrolledSubjects = database.subjects
      .filter((s) => s.classId === studentClass.id || s.classIds?.includes(studentClass.id))
      .map((subj) => {
        let teacherName = 'Assigned Faculty';
        if (subj.teacherId) {
          const tProf = database.teacherProfiles.find((t) => t.id === subj.teacherId);
          if (tProf) {
            const tUser = database.users.find((u) => u.id === tProf.userId);
            teacherName = tUser?.name || `${tProf.firstName || ''} ${tProf.lastName || ''}`.trim() || 'Assigned Faculty';
          }
        }
        const dept = database.departments.find((d) => d.id === subj.departmentId);
        return {
          id: subj.id,
          name: subj.name,
          code: subj.code,
          credits: subj.credits,
          teacherName,
          departmentName: dept?.name || 'Department of Academics',
          type: subj.type
        };
      });

    // Real Attendance Calculation from database
    const studentAttendanceRecords = (database.attendanceRecords || []).filter(
      (a) => a.studentId === studentProfile.id || a.userId === studentProfile.userId
    );
    const totalDays = studentAttendanceRecords.length;
    const presentDays = studentAttendanceRecords.filter((a) => a.status === 'PRESENT').length;
    const lateDays = studentAttendanceRecords.filter((a) => a.status === 'LATE').length;
    const absentDays = studentAttendanceRecords.filter((a) => a.status === 'ABSENT').length;

    let attendancePercentage = 'No records yet';
    let attendanceRate = 0;
    const hasAttendanceData = totalDays > 0;

    if (hasAttendanceData) {
      // Calculate effective attendance rate (Present = 100%, Late = 75% or 50%, Absent = 0%)
      const calculatedRate = ((presentDays + lateDays * 0.75) / totalDays) * 100;
      attendanceRate = Math.min(100, Math.max(0, Number(calculatedRate.toFixed(1))));
      attendancePercentage = `${attendanceRate}%`;
    }

    // Real Upcoming Homework for student's class & section
    if (!database.homework) database.homework = [];
    const upcomingHomework = database.homework
      .filter(
        (h) =>
          h.classId === studentProfile.classId &&
          (!h.sectionId || h.sectionId === 'ALL' || h.sectionId === 'all' || h.sectionId === studentProfile.sectionId) &&
          h.status === 'published'
      )
      .sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime());

    // Real Upcoming Assignments for student's class & section
    if (!database.assignments) database.assignments = [];
    const upcomingAssignments = database.assignments
      .filter(
        (a) =>
          a.classId === studentProfile.classId &&
          (!a.sectionId || a.sectionId === 'ALL' || a.sectionId === 'all' || a.sectionId === studentProfile.sectionId) &&
          a.status === 'published'
      )
      .sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime());

    // Real Announcements for student's class
    if (!database.classAnnouncements) database.classAnnouncements = [];
    const recentAnnouncements = database.classAnnouncements
      .filter(
        (a) =>
          (a.classId === studentProfile.classId || a.classId === 'ALL' || !a.classId) &&
          (!a.sectionId || a.sectionId === 'ALL' || a.sectionId === 'all' || a.sectionId === studentProfile.sectionId) &&
          a.status === 'published'
      )
      .sort((a, b) => new Date(b.publishDate || b.createdAt).getTime() - new Date(a.publishDate || a.createdAt).getTime())
      .slice(0, 5);

    // Real Notifications for student
    if (!database.notifications) database.notifications = [];
    const recentNotifications = database.notifications
      .filter((n) => n.userId === user.id || n.roleTarget === 'ALL' || n.roleTarget === 'STUDENT')
      .slice(-10)
      .reverse();

    const unreadNotificationsCount = recentNotifications.filter((n) => !n.isRead).length;

    const nameParts = (studentUser.name || `${studentProfile.firstName || ''} ${studentProfile.lastName || ''}`.trim()).split(' ');
    const firstName = studentProfile.firstName || nameParts[0] || 'Student';
    const lastName = studentProfile.lastName || nameParts.slice(1).join(' ') || '';

    const data: StudentDashboardData = {
      student: {
        ...studentProfile,
        firstName,
        lastName,
        email: studentProfile.email || studentUser.email,
        phone: studentProfile.phone || studentUser.phoneNumber || '',
        avatarUrl: studentProfile.avatarUrl || studentUser.avatarUrl,
        className: studentClass.name,
        sectionName: studentSection.name,
        academicSessionName: activeSession?.sessionName || '2026-2027 Academic Year',
        status: studentProfile.status
      },
      metrics: {
        academicSession: activeSession?.sessionName || '2026-2027',
        academicSessionId: activeSession?.id,
        totalSubjects: enrolledSubjects.length,
        attendancePercentage,
        attendanceRate,
        attendancePresentDays: presentDays,
        attendanceTotalDays: totalDays,
        attendanceLateDays: lateDays,
        attendanceAbsentDays: absentDays,
        hasAttendanceData,
        pendingHomeworkCount: upcomingHomework.length,
        activeAssignmentsCount: upcomingAssignments.length,
        unreadNotificationsCount
      },
      enrolledSubjects,
      upcomingHomework,
      upcomingAssignments,
      recentAnnouncements,
      recentNotifications
    };

    res.json({ success: true, data });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});
