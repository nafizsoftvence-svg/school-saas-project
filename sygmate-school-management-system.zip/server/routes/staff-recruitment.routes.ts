/**
 * Sygmate School Management System
 * Staff Recruitment & Onboarding Management (Part 12D)
 * API Routes: /api/staff/recruitment and /api/staff/onboarding
 */

import { Router, Response } from 'express';
import { requireAuth, requirePermission, AuthenticatedRequest } from '../security/auth.js';
import { staffRecruitmentService } from '../services/staff-recruitment.service.js';
import {
  CreateJobOpeningPayload,
  UpdateJobOpeningPayload,
  CreateCandidatePayload,
  UpdateCandidatePayload,
  CreateJobApplicationPayload,
  ScreenApplicationPayload,
  TransitionApplicationStagePayload,
  ScheduleInterviewPayload,
  SubmitEvaluationPayload,
  RescheduleInterviewPayload,
  CreateJobOfferPayload,
  ReviewOfferPayload,
  CandidateOfferResponsePayload,
  ConvertCandidateToStaffPayload,
  CreateOnboardingTaskPayload,
  UpdateOnboardingTaskPayload
} from '../../src/types/index.js';

export const staffRecruitmentRouter = Router();
export const staffOnboardingRouter = Router();

// ==========================================
// RECRUITMENT ROUTES
// ==========================================

/**
 * GET /api/staff/recruitment/metrics
 * Comprehensive Recruitment Metrics & Dashboard Data
 */
staffRecruitmentRouter.get(
  '/metrics',
  requireAuth,
  requirePermission('staff.recruitment.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const metrics = staffRecruitmentService.getDashboardMetrics();
      res.json({ success: true, data: metrics });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  }
);

// ------------------------------------------
// 1. Job Openings
// ------------------------------------------

staffRecruitmentRouter.get(
  '/jobs',
  requireAuth,
  requirePermission('staff.recruitment.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const query = {
        search: req.query.search as string,
        departmentId: req.query.departmentId as string,
        staffType: req.query.staffType as string,
        status: req.query.status as string,
        page: req.query.page ? parseInt(req.query.page as string, 10) : 1,
        limit: req.query.limit ? parseInt(req.query.limit as string, 10) : 50
      };
      const result = staffRecruitmentService.listJobOpenings(query);
      res.json({ success: true, ...result });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  }
);

staffRecruitmentRouter.get(
  '/jobs/:id',
  requireAuth,
  requirePermission('staff.recruitment.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const job = staffRecruitmentService.getJobOpeningById(req.params.id);
      if (!job) {
        return res.status(404).json({ success: false, message: 'Job opening not found.' });
      }
      res.json({ success: true, data: job });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  }
);

staffRecruitmentRouter.post(
  '/jobs',
  requireAuth,
  requirePermission('staff.recruitment.manage'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const payload: CreateJobOpeningPayload = req.body;
      const job = staffRecruitmentService.createJobOpening(payload, req.user);
      res.status(201).json({ success: true, data: job, message: 'Job opening created successfully.' });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  }
);

staffRecruitmentRouter.put(
  '/jobs/:id',
  requireAuth,
  requirePermission('staff.recruitment.manage'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const payload: UpdateJobOpeningPayload = req.body;
      const job = staffRecruitmentService.updateJobOpening(req.params.id, payload, req.user);
      res.json({ success: true, data: job, message: 'Job opening updated successfully.' });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  }
);

staffRecruitmentRouter.delete(
  '/jobs/:id',
  requireAuth,
  requirePermission('staff.recruitment.manage'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      staffRecruitmentService.deleteJobOpening(req.params.id, req.user);
      res.json({ success: true, message: 'Job opening removed or archived successfully.' });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  }
);

// ------------------------------------------
// 2. Candidates
// ------------------------------------------

staffRecruitmentRouter.get(
  '/candidates',
  requireAuth,
  requirePermission('staff.recruitment.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const query = {
        search: req.query.search as string,
        departmentId: req.query.departmentId as string,
        status: req.query.status as string,
        page: req.query.page ? parseInt(req.query.page as string, 10) : 1,
        limit: req.query.limit ? parseInt(req.query.limit as string, 10) : 50
      };
      const result = staffRecruitmentService.listCandidates(query);
      res.json({ success: true, ...result });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  }
);

staffRecruitmentRouter.get(
  '/candidates/:id',
  requireAuth,
  requirePermission('staff.recruitment.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const candidate = staffRecruitmentService.getCandidateById(req.params.id);
      if (!candidate) {
        return res.status(404).json({ success: false, message: 'Candidate not found.' });
      }
      res.json({ success: true, data: candidate });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  }
);

staffRecruitmentRouter.post(
  '/candidates',
  requireAuth,
  requirePermission('staff.recruitment.manage'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const payload: CreateCandidatePayload = req.body;
      const candidate = staffRecruitmentService.createCandidate(payload, req.user);
      res.status(201).json({ success: true, data: candidate, message: 'Candidate created successfully.' });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  }
);

staffRecruitmentRouter.put(
  '/candidates/:id',
  requireAuth,
  requirePermission('staff.recruitment.manage'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const payload: UpdateCandidatePayload = req.body;
      const candidate = staffRecruitmentService.updateCandidate(req.params.id, payload, req.user);
      res.json({ success: true, data: candidate, message: 'Candidate details updated successfully.' });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  }
);

// ------------------------------------------
// 3. Applications
// ------------------------------------------

staffRecruitmentRouter.get(
  '/applications',
  requireAuth,
  requirePermission('staff.recruitment.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const query = {
        candidateId: req.query.candidateId as string,
        jobOpeningId: req.query.jobOpeningId as string,
        departmentId: req.query.departmentId as string,
        stage: req.query.stage as string,
        search: req.query.search as string,
        page: req.query.page ? parseInt(req.query.page as string, 10) : 1,
        limit: req.query.limit ? parseInt(req.query.limit as string, 10) : 50
      };
      const result = staffRecruitmentService.listApplications(query);
      res.json({ success: true, ...result });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  }
);

staffRecruitmentRouter.get(
  '/applications/:id',
  requireAuth,
  requirePermission('staff.recruitment.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const app = staffRecruitmentService.getApplicationById(req.params.id);
      if (!app) {
        return res.status(404).json({ success: false, message: 'Job application not found.' });
      }
      res.json({ success: true, data: app });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  }
);

staffRecruitmentRouter.post(
  '/applications',
  requireAuth,
  requirePermission('staff.recruitment.manage'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const payload: CreateJobApplicationPayload = req.body;
      const app = staffRecruitmentService.createApplication(payload, req.user);
      res.status(201).json({ success: true, data: app, message: 'Application submitted successfully.' });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  }
);

staffRecruitmentRouter.post(
  '/applications/:id/screen',
  requireAuth,
  requirePermission('staff.recruitment.manage'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const payload: ScreenApplicationPayload = req.body;
      const app = staffRecruitmentService.screenApplication(req.params.id, payload, req.user);
      res.json({ success: true, data: app, message: 'Application screening completed.' });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  }
);

staffRecruitmentRouter.post(
  '/applications/:id/stage',
  requireAuth,
  requirePermission('staff.recruitment.manage'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const payload: TransitionApplicationStagePayload = req.body;
      const app = staffRecruitmentService.transitionApplicationStage(req.params.id, payload, req.user);
      res.json({ success: true, data: app, message: `Application moved to ${payload.newStage}.` });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  }
);

staffRecruitmentRouter.post(
  '/applications/:id/select',
  requireAuth,
  requirePermission('staff.recruitment.manage'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const app = staffRecruitmentService.selectCandidate(req.params.id, req.user);
      res.json({ success: true, data: app, message: 'Candidate marked as selected for position.' });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  }
);

// ------------------------------------------
// 4. Interviews & Evaluations
// ------------------------------------------

staffRecruitmentRouter.get(
  '/interviews',
  requireAuth,
  requirePermission('staff.recruitment.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const query = {
        applicationId: req.query.applicationId as string,
        candidateId: req.query.candidateId as string,
        jobOpeningId: req.query.jobOpeningId as string,
        status: req.query.status as string,
        date: req.query.date as string
      };
      const items = staffRecruitmentService.listInterviews(query);
      res.json({ success: true, data: items, total: items.length });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  }
);

staffRecruitmentRouter.get(
  '/interviews/:id',
  requireAuth,
  requirePermission('staff.recruitment.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const interview = staffRecruitmentService.getInterviewById(req.params.id);
      if (!interview) {
        return res.status(404).json({ success: false, message: 'Interview record not found.' });
      }
      res.json({ success: true, data: interview });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  }
);

staffRecruitmentRouter.post(
  '/interviews',
  requireAuth,
  requirePermission('staff.recruitment.interview'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const payload: ScheduleInterviewPayload = req.body;
      const interview = staffRecruitmentService.scheduleInterview(payload, req.user);
      res.status(201).json({ success: true, data: interview, message: 'Interview scheduled successfully.' });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  }
);

staffRecruitmentRouter.post(
  '/interviews/:id/evaluations',
  requireAuth,
  requirePermission('staff.recruitment.interview'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const payload: SubmitEvaluationPayload = req.body;
      const interview = staffRecruitmentService.submitInterviewEvaluation(req.params.id, payload, req.user);
      res.json({ success: true, data: interview, message: 'Interview evaluation submitted.' });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  }
);

staffRecruitmentRouter.post(
  '/interviews/:id/reschedule',
  requireAuth,
  requirePermission('staff.recruitment.interview'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const payload: RescheduleInterviewPayload = req.body;
      const interview = staffRecruitmentService.rescheduleInterview(req.params.id, payload, req.user);
      res.json({ success: true, data: interview, message: 'Interview rescheduled.' });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  }
);

// ------------------------------------------
// 5. Offers & Approvals
// ------------------------------------------

staffRecruitmentRouter.get(
  '/offers',
  requireAuth,
  requirePermission('staff.recruitment.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const query = {
        applicationId: req.query.applicationId as string,
        candidateId: req.query.candidateId as string,
        jobOpeningId: req.query.jobOpeningId as string,
        status: req.query.status as string
      };
      const items = staffRecruitmentService.listOffers(query);
      res.json({ success: true, data: items, total: items.length });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  }
);

staffRecruitmentRouter.get(
  '/offers/:id',
  requireAuth,
  requirePermission('staff.recruitment.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const offer = staffRecruitmentService.getOfferById(req.params.id);
      if (!offer) {
        return res.status(404).json({ success: false, message: 'Offer record not found.' });
      }
      res.json({ success: true, data: offer });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  }
);

staffRecruitmentRouter.post(
  '/offers',
  requireAuth,
  requirePermission('staff.recruitment.offer'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const payload: CreateJobOfferPayload = req.body;
      const offer = staffRecruitmentService.createOffer(payload, req.user);
      res.status(201).json({ success: true, data: offer, message: 'Appointment offer created.' });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  }
);

staffRecruitmentRouter.post(
  '/offers/:id/review',
  requireAuth,
  requirePermission('staff.recruitment.offer'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const payload: ReviewOfferPayload = req.body;
      const offer = staffRecruitmentService.reviewOffer(req.params.id, payload, req.user);
      res.json({ success: true, data: offer, message: `Offer ${payload.decision.toLowerCase()} successfully.` });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  }
);

staffRecruitmentRouter.post(
  '/offers/:id/send',
  requireAuth,
  requirePermission('staff.recruitment.offer'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const offer = staffRecruitmentService.sendOffer(req.params.id, req.user);
      res.json({ success: true, data: offer, message: 'Offer formally dispatched to candidate.' });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  }
);

staffRecruitmentRouter.post(
  '/offers/:id/respond',
  requireAuth,
  requirePermission('staff.recruitment.offer'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const payload: CandidateOfferResponsePayload = req.body;
      const offer = staffRecruitmentService.recordCandidateOfferResponse(req.params.id, payload, req.user);
      res.json({ success: true, data: offer, message: `Offer response recorded as ${payload.response}.` });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  }
);

// ------------------------------------------
// 6. Candidate -> Staff Conversion
// ------------------------------------------

staffRecruitmentRouter.post(
  '/candidates/:id/convert-to-staff',
  requireAuth,
  requirePermission('staff.recruitment.convert'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const payload: ConvertCandidateToStaffPayload = {
        ...req.body,
        candidateId: req.params.id
      };
      const result = staffRecruitmentService.convertCandidateToStaff(payload, req.user);
      res.status(201).json({
        success: true,
        data: result,
        message: `Candidate successfully converted to active staff member (${result.employeeCode}).`
      });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  }
);

// ==========================================
// ONBOARDING ROUTES
// ==========================================

staffOnboardingRouter.get(
  '/',
  requireAuth,
  requirePermission('staff.onboarding.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const query = {
        status: req.query.status as string,
        departmentId: req.query.departmentId as string,
        staffType: req.query.staffType as string,
        search: req.query.search as string
      };
      const items = staffRecruitmentService.listOnboardingRecords(query);
      res.json({ success: true, data: items, total: items.length });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  }
);

staffOnboardingRouter.get(
  '/templates',
  requireAuth,
  requirePermission('staff.onboarding.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const templates = staffRecruitmentService.listOnboardingTemplates();
      res.json({ success: true, data: templates });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  }
);

staffOnboardingRouter.get(
  '/templates/:id',
  requireAuth,
  requirePermission('staff.onboarding.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const template = staffRecruitmentService.getOnboardingTemplateById(req.params.id);
      if (!template) {
        return res.status(404).json({ success: false, message: 'Onboarding template not found.' });
      }
      res.json({ success: true, data: template });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  }
);

staffOnboardingRouter.get(
  '/staff/:staffId',
  requireAuth,
  requirePermission('staff.onboarding.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const record = staffRecruitmentService.getOnboardingRecordByStaffId(req.params.staffId);
      if (!record) {
        return res.status(404).json({ success: false, message: 'Onboarding record not found for this staff member.' });
      }
      res.json({ success: true, data: record });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  }
);

staffOnboardingRouter.get(
  '/:id',
  requireAuth,
  requirePermission('staff.onboarding.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const record = staffRecruitmentService.getOnboardingRecordById(req.params.id);
      if (!record) {
        return res.status(404).json({ success: false, message: 'Onboarding record not found.' });
      }
      res.json({ success: true, data: record });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  }
);

staffOnboardingRouter.post(
  '/initialize',
  requireAuth,
  requirePermission('staff.onboarding.manage'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const { staffId, templateId } = req.body;
      if (!staffId || !templateId) {
        return res.status(400).json({ success: false, message: 'Staff ID and Template ID are required.' });
      }
      const record = staffRecruitmentService.initializeOnboarding(staffId, templateId, req.user);
      res.status(201).json({ success: true, data: record, message: 'Onboarding initialized successfully.' });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  }
);

staffOnboardingRouter.post(
  '/:id/tasks',
  requireAuth,
  requirePermission('staff.onboarding.manage'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const payload: CreateOnboardingTaskPayload = req.body;
      const record = staffRecruitmentService.addOnboardingTask(req.params.id, payload, req.user);
      res.status(201).json({ success: true, data: record, message: 'Task added to onboarding checklist.' });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  }
);

staffOnboardingRouter.put(
  '/:id/tasks/:taskId',
  requireAuth,
  requirePermission('staff.onboarding.manage'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const payload: UpdateOnboardingTaskPayload = req.body;
      const record = staffRecruitmentService.updateOnboardingTask(
        req.params.id,
        req.params.taskId,
        payload,
        req.user
      );
      res.json({ success: true, data: record, message: 'Task status updated successfully.' });
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  }
);
