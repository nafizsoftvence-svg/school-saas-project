/**
 * Part 15C & 15D — Certificate Generation, Issuance, Verification & Approval Routes
 * Sygmate School Management System
 */

import { Router, Response } from 'express';
import { AuthenticatedRequest, requireAuth, requirePermission } from '../security/auth.js';
import { CertificateService } from '../services/certificate.service.js';

export const certificateRouter = Router();

// ==============================================================
// PUBLIC CERTIFICATE VERIFICATION (NO AUTH REQUIRED)
// ==============================================================

/**
 * GET /api/certificates/public/verify/:reference
 * Public, privacy-safe verification of issued certificates
 */
certificateRouter.get(
  '/public/verify/:reference',
  (req, res): void => {
    try {
      const clientIp = (req.headers['x-forwarded-for'] as string)?.split(',')[0] || req.socket.remoteAddress || '127.0.0.1';
      const reference = req.params.reference;
      const result = CertificateService.publicVerifyCertificate(reference, clientIp);

      if (result.status === 'RATE_LIMITED') {
        res.status(429).json({
          success: false,
          ...result
        });
        return;
      }

      res.json({
        success: true,
        ...result
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        status: 'NOT_FOUND',
        isAuthentic: false,
        message: 'An error occurred while verifying the certificate reference.'
      });
    }
  }
);

/**
 * POST /api/certificates/public/verify
 * Public verification query endpoint for search forms
 */
certificateRouter.post(
  '/public/verify',
  (req, res): void => {
    try {
      const clientIp = (req.headers['x-forwarded-for'] as string)?.split(',')[0] || req.socket.remoteAddress || '127.0.0.1';
      const { reference } = req.body || {};
      const result = CertificateService.publicVerifyCertificate(reference || '', clientIp);

      if (result.status === 'RATE_LIMITED') {
        res.status(429).json({
          success: false,
          ...result
        });
        return;
      }

      res.json({
        success: true,
        ...result
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        status: 'NOT_FOUND',
        isAuthentic: false,
        message: 'An error occurred while verifying the certificate reference.'
      });
    }
  }
);

// ==============================================================
// METRICS & STATS
// ==============================================================

/**
 * GET /api/certificates/metrics
 */
certificateRouter.get(
  '/metrics',
  requireAuth,
  requirePermission('certificates.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = (req.user as any)?.schoolId || 'school-main';
      const metrics = CertificateService.getCertificateMetrics(schoolId, req.user!);
      res.json({
        success: true,
        data: metrics
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to retrieve certificate metrics.'
      });
    }
  }
);

// ==============================================================
// CERTIFICATE TYPES CONFIGURATION
// ==============================================================

/**
 * GET /api/certificates/types
 */
certificateRouter.get(
  '/types',
  requireAuth,
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = (req.user as any)?.schoolId || 'school-main';
      const { entityType, isActive } = req.query as Record<string, string>;
      const types = CertificateService.listCertificateTypes(
        schoolId,
        entityType as any,
        isActive !== undefined ? isActive === 'true' : undefined
      );
      res.json({
        success: true,
        data: types
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to list certificate types.'
      });
    }
  }
);

/**
 * GET /api/certificates/types/:id
 */
certificateRouter.get(
  '/types/:id',
  requireAuth,
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = (req.user as any)?.schoolId || 'school-main';
      const type = CertificateService.getCertificateTypeById(schoolId, req.params.id);
      res.json({
        success: true,
        data: type
      });
    } catch (error: any) {
      res.status(404).json({
        success: false,
        error: error.message || 'Certificate type not found.'
      });
    }
  }
);

/**
 * POST /api/certificates/types
 */
certificateRouter.post(
  '/types',
  requireAuth,
  requirePermission('certificates.types.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = (req.user as any)?.schoolId || 'school-main';
      const created = CertificateService.createCertificateType(schoolId, req.body, req.user!);
      res.status(201).json({
        success: true,
        message: `Certificate type "${created.name}" created successfully.`,
        data: created
      });
    } catch (error: any) {
      res.status(400).json({
        success: false,
        error: error.message || 'Failed to create certificate type.'
      });
    }
  }
);

/**
 * PUT /api/certificates/types/:id
 */
certificateRouter.put(
  '/types/:id',
  requireAuth,
  requirePermission('certificates.types.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = (req.user as any)?.schoolId || 'school-main';
      const updated = CertificateService.updateCertificateType(schoolId, req.params.id, req.body, req.user!);
      res.json({
        success: true,
        message: `Certificate type "${updated.name}" updated successfully.`,
        data: updated
      });
    } catch (error: any) {
      res.status(400).json({
        success: false,
        error: error.message || 'Failed to update certificate type.'
      });
    }
  }
);

// ==============================================================
// PREVIEW & GENERATE
// ==============================================================

/**
 * POST /api/certificates/preview
 */
certificateRouter.post(
  '/preview',
  requireAuth,
  requirePermission('certificates.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = (req.user as any)?.schoolId || 'school-main';
      const preview = CertificateService.previewCertificate(schoolId, req.body, req.user!);
      res.json({
        success: true,
        data: preview
      });
    } catch (error: any) {
      res.status(400).json({
        success: false,
        error: error.message || 'Failed to generate certificate preview.'
      });
    }
  }
);

/**
 * POST /api/certificates/generate
 */
certificateRouter.post(
  '/generate',
  requireAuth,
  requirePermission('certificates.generate'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = (req.user as any)?.schoolId || 'school-main';
      const cert = CertificateService.generateCertificate(schoolId, req.body, req.user!);
      res.status(201).json({
        success: true,
        message: `Certificate "${cert.certificateNumber}" successfully generated for ${cert.studentName}.`,
        data: cert
      });
    } catch (error: any) {
      res.status(400).json({
        success: false,
        error: error.message || 'Failed to generate certificate.'
      });
    }
  }
);

// ==============================================================
// PART 15D: VERIFICATION & APPROVAL WORKFLOW
// ==============================================================

/**
 * POST /api/certificates/:id/submit-verification
 * Submit a generated or draft certificate for formal verification
 */
certificateRouter.post(
  '/:id/submit-verification',
  requireAuth,
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = (req.user as any)?.schoolId || 'school-main';
      const updated = CertificateService.submitForVerification(schoolId, req.params.id, req.body || {}, req.user!);
      res.json({
        success: true,
        message: `Certificate "${updated.certificateNumber}" submitted for verification.`,
        data: updated
      });
    } catch (error: any) {
      res.status(400).json({
        success: false,
        error: error.message || 'Failed to submit certificate for verification.'
      });
    }
  }
);

/**
 * POST /api/certificates/:id/verify
 * Reviewer decision: VERIFY or REJECT
 */
certificateRouter.post(
  '/:id/verify',
  requireAuth,
  requirePermission('certificates.verify'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = (req.user as any)?.schoolId || 'school-main';
      const updated = CertificateService.verifyCertificate(schoolId, req.params.id, req.body, req.user!);
      const actionText = updated.verificationStatus === 'VERIFIED' ? 'verified and queued for approval' : 'rejected';
      res.json({
        success: true,
        message: `Certificate "${updated.certificateNumber}" ${actionText}.`,
        data: updated
      });
    } catch (error: any) {
      res.status(400).json({
        success: false,
        error: error.message || 'Failed to verify certificate.'
      });
    }
  }
);

/**
 * POST /api/certificates/:id/submit-approval
 * Submit verified certificate for administrative approval
 */
certificateRouter.post(
  '/:id/submit-approval',
  requireAuth,
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = (req.user as any)?.schoolId || 'school-main';
      const updated = CertificateService.submitForApproval(schoolId, req.params.id, req.user!);
      res.json({
        success: true,
        message: `Certificate "${updated.certificateNumber}" submitted for approval.`,
        data: updated
      });
    } catch (error: any) {
      res.status(400).json({
        success: false,
        error: error.message || 'Failed to submit certificate for approval.'
      });
    }
  }
);

/**
 * POST /api/certificates/:id/approve
 * Approver decision: APPROVE or REJECT
 */
certificateRouter.post(
  '/:id/approve',
  requireAuth,
  requirePermission('certificates.approve'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = (req.user as any)?.schoolId || 'school-main';
      const updated = CertificateService.approveCertificate(schoolId, req.params.id, req.body, req.user!);
      const actionText = updated.approvalStatus === 'APPROVED' ? 'approved for official issuance' : 'rejected';
      res.json({
        success: true,
        message: `Certificate "${updated.certificateNumber}" ${actionText}.`,
        data: updated
      });
    } catch (error: any) {
      res.status(400).json({
        success: false,
        error: error.message || 'Failed to approve certificate.'
      });
    }
  }
);

/**
 * GET /api/certificates/:id/workflow-history
 * Get complete audit trail & workflow events for this certificate
 */
certificateRouter.get(
  '/:id/workflow-history',
  requireAuth,
  requirePermission('certificates.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = (req.user as any)?.schoolId || 'school-main';
      const history = CertificateService.getCertificateWorkflowHistory(schoolId, req.params.id, req.user!);
      res.json({
        success: true,
        data: history
      });
    } catch (error: any) {
      res.status(404).json({
        success: false,
        error: error.message || 'Failed to retrieve workflow history.'
      });
    }
  }
);

// ==============================================================
// CERTIFICATE ISSUANCE & LIFECYCLE
// ==============================================================

/**
 * POST /api/certificates/:id/issue
 * Officially issues certificate, locks modifications, notifies student/guardian
 */
certificateRouter.post(
  '/:id/issue',
  requireAuth,
  requirePermission('certificates.issue'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = (req.user as any)?.schoolId || 'school-main';
      const issued = CertificateService.issueCertificate(schoolId, req.params.id, req.body || {}, req.user!);
      res.json({
        success: true,
        message: `Certificate "${issued.certificateNumber}" officially issued.`,
        data: issued
      });
    } catch (error: any) {
      res.status(400).json({
        success: false,
        error: error.message || 'Failed to issue certificate.'
      });
    }
  }
);

/**
 * POST /api/certificates/:id/reissue
 * Safe controlled reissue preserving original certificate record
 */
certificateRouter.post(
  '/:id/reissue',
  requireAuth,
  requirePermission('certificates.reissue'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = (req.user as any)?.schoolId || 'school-main';
      const reissued = CertificateService.reissueCertificate(schoolId, req.params.id, req.body, req.user!);
      res.json({
        success: true,
        message: `New certificate version "${reissued.certificateNumber}" issued successfully.`,
        data: reissued
      });
    } catch (error: any) {
      res.status(400).json({
        success: false,
        error: error.message || 'Failed to reissue certificate.'
      });
    }
  }
);

/**
 * POST /api/certificates/:id/cancel
 * Cancel unissued or draft certificate
 */
certificateRouter.post(
  '/:id/cancel',
  requireAuth,
  requirePermission('certificates.cancel'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = (req.user as any)?.schoolId || 'school-main';
      const { reason } = req.body;
      const cancelled = CertificateService.cancelCertificate(schoolId, req.params.id, reason, req.user!);
      res.json({
        success: true,
        message: `Certificate "${cancelled.certificateNumber}" cancelled.`,
        data: cancelled
      });
    } catch (error: any) {
      res.status(400).json({
        success: false,
        error: error.message || 'Failed to cancel certificate.'
      });
    }
  }
);

/**
 * POST /api/certificates/:id/revoke
 * Officially revokes an issued certificate
 */
certificateRouter.post(
  '/:id/revoke',
  requireAuth,
  requirePermission('certificates.revoke'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = (req.user as any)?.schoolId || 'school-main';
      const { reason } = req.body;
      const revoked = CertificateService.revokeCertificate(schoolId, req.params.id, reason, req.user!);
      res.json({
        success: true,
        message: `Certificate "${revoked.certificateNumber}" revoked.`,
        data: revoked
      });
    } catch (error: any) {
      res.status(400).json({
        success: false,
        error: error.message || 'Failed to revoke certificate.'
      });
    }
  }
);

// ==============================================================
// SEARCH, LIST & PORTALS
// ==============================================================

/**
 * GET /api/certificates
 * List certificates with server-side filters & pagination
 */
certificateRouter.get(
  '/',
  requireAuth,
  requirePermission('certificates.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = (req.user as any)?.schoolId || 'school-main';
      const result = CertificateService.listIssuedCertificates(
        schoolId,
        {
          search: req.query.search as string,
          certificateTypeId: req.query.certificateTypeId as string,
          studentId: req.query.studentId as string,
          academicSessionId: req.query.academicSessionId as string,
          status: req.query.status as any,
          verificationStatus: req.query.verificationStatus as any,
          approvalStatus: req.query.approvalStatus as any,
          startDate: req.query.startDate as string,
          endDate: req.query.endDate as string,
          page: req.query.page ? parseInt(req.query.page as string, 10) : 1,
          limit: req.query.limit ? parseInt(req.query.limit as string, 10) : 20,
          sortBy: req.query.sortBy as any,
          sortOrder: req.query.sortOrder as any
        },
        req.user!
      );
      res.json({
        success: true,
        ...result
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to list certificates.'
      });
    }
  }
);

/**
 * GET /api/certificates/my-certificates
 * Student portal endpoint to fetch authenticated student's issued certificates
 */
certificateRouter.get(
  '/my-certificates',
  requireAuth,
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = (req.user as any)?.schoolId || 'school-main';
      const result = CertificateService.listIssuedCertificates(
        schoolId,
        { status: 'ISSUED', limit: 100 },
        req.user!
      );
      res.json({
        success: true,
        data: result.items
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to retrieve your student certificates.'
      });
    }
  }
);

/**
 * GET /api/certificates/guardian-certificates
 * Guardian portal endpoint to fetch linked children's issued certificates
 */
certificateRouter.get(
  '/guardian-certificates',
  requireAuth,
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = (req.user as any)?.schoolId || 'school-main';
      const result = CertificateService.listIssuedCertificates(
        schoolId,
        { status: 'ISSUED', limit: 100 },
        req.user!
      );
      res.json({
        success: true,
        data: result.items
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to retrieve child certificates.'
      });
    }
  }
);

/**
 * GET /api/certificates/:id
 */
certificateRouter.get(
  '/:id',
  requireAuth,
  requirePermission('certificates.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = (req.user as any)?.schoolId || 'school-main';
      const cert = CertificateService.getIssuedCertificateById(schoolId, req.params.id, req.user!);
      res.json({
        success: true,
        data: cert
      });
    } catch (error: any) {
      const status = error.message.includes('Access denied') ? 403 : 404;
      res.status(status).json({
        success: false,
        error: error.message || 'Certificate not found.'
      });
    }
  }
);

/**
 * GET /api/certificates/:id/download
 * Secure permission-checked download payload
 */
certificateRouter.get(
  '/:id/download',
  requireAuth,
  requirePermission('certificates.download'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = (req.user as any)?.schoolId || 'school-main';
      const cert = CertificateService.getIssuedCertificateById(schoolId, req.params.id, req.user!);
      res.json({
        success: true,
        data: {
          id: cert.id,
          certificateNumber: cert.certificateNumber,
          digitalVerificationReference: cert.digitalVerificationReference,
          studentName: cert.studentName,
          fileName: cert.fileName,
          fileUrl: cert.fileUrl,
          issueDate: cert.issueDate,
          version: cert.version
        }
      });
    } catch (error: any) {
      const status = error.message.includes('Access denied') ? 403 : 404;
      res.status(status).json({
        success: false,
        error: error.message || 'Access denied.'
      });
    }
  }
);
