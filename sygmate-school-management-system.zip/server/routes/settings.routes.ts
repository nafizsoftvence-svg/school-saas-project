import { Router, Response } from 'express';
import { database } from '../db/database.js';
import { requireAuth, requireRole, AuthenticatedRequest } from '../security/auth.js';
import { logAudit } from '../security/audit.js';

export const settingsRouter = Router();

// Get School Settings
settingsRouter.get('/', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  const activeSession = database.academicSessions.find((s) => s.isActive) || null;
  res.json({
    success: true,
    data: database.schoolSettings,
    activeSession
  });
});

// Update School Settings (Super Admin only)
settingsRouter.put('/', requireAuth, requireRole('SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  const updates = req.body;

  if (!updates || typeof updates !== 'object') {
    res.status(400).json({ success: false, error: 'Invalid settings payload provided.' });
    return;
  }

  // Field Validations
  if (updates.schoolName !== undefined && !updates.schoolName.trim()) {
    res.status(400).json({ success: false, error: 'School Name cannot be blank.' });
    return;
  }

  if (updates.schoolCode !== undefined && !updates.schoolCode.trim()) {
    res.status(400).json({ success: false, error: 'School Code cannot be blank.' });
    return;
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (updates.contactEmail && !emailRegex.test(updates.contactEmail)) {
    res.status(400).json({ success: false, error: 'Please provide a valid administrative contact email address.' });
    return;
  }
  if (updates.supportEmail && !emailRegex.test(updates.supportEmail)) {
    res.status(400).json({ success: false, error: 'Please provide a valid support email address.' });
    return;
  }

  if (updates.establishedYear !== undefined) {
    const yr = Number(updates.establishedYear);
    if (isNaN(yr) || yr < 1800 || yr > new Date().getFullYear() + 1) {
      res.status(400).json({ success: false, error: `Established year must be between 1800 and ${new Date().getFullYear() + 1}.` });
      return;
    }
  }

  // Alias sync for backwards compatibility
  if (updates.schoolName) updates.name = updates.schoolName;
  if (updates.name && !updates.schoolName) updates.schoolName = updates.name;
  if (updates.schoolCode) updates.code = updates.schoolCode;
  if (updates.code && !updates.schoolCode) updates.schoolCode = updates.code;
  if (updates.contactEmail) updates.email = updates.contactEmail;
  if (updates.email && !updates.contactEmail) updates.contactEmail = updates.email;
  if (updates.contactPhone) updates.phone = updates.contactPhone;
  if (updates.phone && !updates.contactPhone) updates.contactPhone = updates.phone;

  database.schoolSettings = {
    ...database.schoolSettings,
    ...updates
  };

  const changedFields = Object.keys(updates).filter(k => k !== 'name' && k !== 'code' && k !== 'email' && k !== 'phone');

  logAudit({
    userId: req.user!.id,
    userName: req.user!.name,
    userRole: req.user!.role,
    action: 'SETTINGS_UPDATE',
    entity: 'SETTINGS',
    details: `Updated institutional configuration: ${changedFields.join(', ')}`,
    ipAddress: req.ip || '127.0.0.1'
  });

  res.json({
    success: true,
    data: database.schoolSettings,
    message: 'Institutional configuration updated and verified.'
  });
});
