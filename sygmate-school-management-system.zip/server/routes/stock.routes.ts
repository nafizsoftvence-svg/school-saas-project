/**
 * Inventory Stock Management Routes (Part 14B)
 * Sygmate School Management System
 */

import { Router, Response } from 'express';
import { requireAuth, requirePermission, AuthenticatedRequest } from '../security/auth.js';
import { StockService } from '../services/stock.service.js';
import { database } from '../db/database.js';

export const stockRouter = Router();

/**
 * Resolves authoritative schoolId from session / database settings.
 * Never trust user-provided schoolId in params or payload.
 */
function resolveSchoolId(req: AuthenticatedRequest): string {
  if (req?.tenant?.schoolId) return req.tenant.schoolId;
  if (req?.user?.schoolId) return req.user.schoolId;
  return database.schoolSettings?.id || 'school-main';
}

/**
 * GET /api/inventory/stock/summary
 * Stock overview KPIs and location breakdown
 */
stockRouter.get(
  '/summary',
  requireAuth,
  requirePermission('inventory.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = resolveSchoolId(req);
      const summary = StockService.getStockSummary(schoolId);
      res.json({ success: true, data: summary });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to fetch stock summary' });
    }
  }
);

/**
 * GET /api/inventory/stock
 * Get stock balances with filters, searching, and pagination
 */
stockRouter.get(
  '/',
  requireAuth,
  requirePermission('inventory.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = resolveSchoolId(req);
      const result = StockService.getStockBalances(schoolId, {
        search: req.query.search as string,
        categoryId: req.query.categoryId as string,
        locationId: req.query.locationId as string,
        stockStatus: req.query.stockStatus as any,
        itemType: req.query.itemType as any,
        page: req.query.page ? parseInt(req.query.page as string, 10) : 1,
        limit: req.query.limit ? parseInt(req.query.limit as string, 10) : 20,
        sortBy: req.query.sortBy as any,
        sortOrder: req.query.sortOrder as any
      });
      res.json({ success: true, ...result });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to fetch stock balances' });
    }
  }
);

/**
 * GET /api/inventory/stock/items/:itemId
 * Get stock balances for a specific item across all locations with recent movements
 */
stockRouter.get(
  '/items/:itemId',
  requireAuth,
  requirePermission('inventory.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = resolveSchoolId(req);
      const detail = StockService.getItemStockDetail(schoolId, req.params.itemId);
      res.json({ success: true, data: detail });
    } catch (error: any) {
      const status = error.message?.includes('not found') ? 404 : 500;
      res.status(status).json({ success: false, error: error.message || 'Failed to fetch item stock' });
    }
  }
);

/**
 * POST /api/inventory/stock/opening
 * Record opening stock for an item at a location
 */
stockRouter.post(
  '/opening',
  requireAuth,
  requirePermission('inventory.items.manage'),
  async (req: AuthenticatedRequest, res: Response): Promise<void> => {
    try {
      const schoolId = resolveSchoolId(req);
      const user = {
        id: req.user?.id || 'usr-admin-1',
        name: req.user?.name || 'Administrator',
        role: req.user?.role || 'SUPER_ADMIN'
      };

      const result = await StockService.recordOpeningStock(schoolId, req.body, user);
      res.status(201).json({
        success: true,
        message: 'Opening stock recorded successfully.',
        data: result
      });
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message || 'Failed to record opening stock' });
    }
  }
);

/**
 * POST /api/inventory/stock/in
 * Record stock in (receipt of items into location)
 */
stockRouter.post(
  '/in',
  requireAuth,
  requirePermission('inventory.stock.in'),
  async (req: AuthenticatedRequest, res: Response): Promise<void> => {
    try {
      const schoolId = resolveSchoolId(req);
      const user = {
        id: req.user?.id || 'usr-admin-1',
        name: req.user?.name || 'Administrator',
        role: req.user?.role || 'SUPER_ADMIN'
      };

      const result = await StockService.recordStockIn(schoolId, req.body, user);
      res.status(201).json({
        success: true,
        message: 'Stock received and balance updated successfully.',
        data: result
      });
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message || 'Failed to record stock in' });
    }
  }
);

/**
 * POST /api/inventory/stock/out
 * Record stock out (issuance of items; strictly validates currentStock >= requested)
 */
stockRouter.post(
  '/out',
  requireAuth,
  requirePermission('inventory.stock.out'),
  async (req: AuthenticatedRequest, res: Response): Promise<void> => {
    try {
      const schoolId = resolveSchoolId(req);
      const user = {
        id: req.user?.id || 'usr-admin-1',
        name: req.user?.name || 'Administrator',
        role: req.user?.role || 'SUPER_ADMIN'
      };

      const result = await StockService.recordStockOut(schoolId, req.body, user);
      res.status(201).json({
        success: true,
        message: 'Stock issued and balance updated successfully.',
        data: result
      });
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message || 'Failed to issue stock' });
    }
  }
);

/**
 * POST /api/inventory/stock/transfer
 * Execute atomic stock transfer between two locations
 */
stockRouter.post(
  '/transfer',
  requireAuth,
  requirePermission('inventory.stock.transfer'),
  async (req: AuthenticatedRequest, res: Response): Promise<void> => {
    try {
      const schoolId = resolveSchoolId(req);
      const user = {
        id: req.user?.id || 'usr-admin-1',
        name: req.user?.name || 'Administrator',
        role: req.user?.role || 'SUPER_ADMIN'
      };

      const result = await StockService.recordStockTransfer(schoolId, req.body, user);
      res.status(201).json({
        success: true,
        message: 'Stock transfer completed successfully across locations.',
        data: result
      });
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message || 'Failed to transfer stock' });
    }
  }
);

/**
 * POST /api/inventory/stock/return
 * Record return of items back to store
 */
stockRouter.post(
  '/return',
  requireAuth,
  requirePermission('inventory.stock.return'),
  async (req: AuthenticatedRequest, res: Response): Promise<void> => {
    try {
      const schoolId = resolveSchoolId(req);
      const user = {
        id: req.user?.id || 'usr-admin-1',
        name: req.user?.name || 'Administrator',
        role: req.user?.role || 'SUPER_ADMIN'
      };

      const result = await StockService.recordStockReturn(schoolId, req.body, user);
      res.status(201).json({
        success: true,
        message: 'Stock return accepted and balance updated.',
        data: result
      });
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message || 'Failed to record stock return' });
    }
  }
);

/**
 * POST /api/inventory/stock/adjust
 * Record physical count stock adjustment / reconciliation
 */
stockRouter.post(
  '/adjust',
  requireAuth,
  requirePermission('inventory.stock.adjust'),
  async (req: AuthenticatedRequest, res: Response): Promise<void> => {
    try {
      const schoolId = resolveSchoolId(req);
      const user = {
        id: req.user?.id || 'usr-admin-1',
        name: req.user?.name || 'Administrator',
        role: req.user?.role || 'SUPER_ADMIN'
      };

      const result = await StockService.recordStockAdjustment(schoolId, req.body, user);
      res.status(201).json({
        success: true,
        message: 'Stock adjustment applied and ledger movement created.',
        data: result
      });
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message || 'Failed to adjust stock' });
    }
  }
);

/**
 * GET /api/inventory/stock/ledger
 * Auditable stock ledger with movements, filters, and pagination
 */
stockRouter.get(
  '/ledger',
  requireAuth,
  requirePermission('inventory.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = resolveSchoolId(req);
      const result = StockService.getStockMovements(schoolId, {
        search: req.query.search as string,
        itemId: req.query.itemId as string,
        locationId: req.query.locationId as string,
        movementType: req.query.movementType as any,
        startDate: req.query.startDate as string,
        endDate: req.query.endDate as string,
        page: req.query.page ? parseInt(req.query.page as string, 10) : 1,
        limit: req.query.limit ? parseInt(req.query.limit as string, 10) : 25
      });
      res.json({ success: true, ...result });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to fetch stock ledger' });
    }
  }
);

/**
 * GET /api/inventory/stock/transactions
 * List stock transactions with filters and pagination
 */
stockRouter.get(
  '/transactions',
  requireAuth,
  requirePermission('inventory.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = resolveSchoolId(req);
      const result = StockService.getStockTransactions(schoolId, {
        search: req.query.search as string,
        itemId: req.query.itemId as string,
        locationId: req.query.locationId as string,
        transactionType: req.query.transactionType as any,
        status: req.query.status as any,
        startDate: req.query.startDate as string,
        endDate: req.query.endDate as string,
        page: req.query.page ? parseInt(req.query.page as string, 10) : 1,
        limit: req.query.limit ? parseInt(req.query.limit as string, 10) : 20
      });
      res.json({ success: true, ...result });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to fetch stock transactions' });
    }
  }
);

/**
 * GET /api/inventory/stock/transactions/:id
 * Get single transaction details with linked double-entry movements
 */
stockRouter.get(
  '/transactions/:id',
  requireAuth,
  requirePermission('inventory.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = resolveSchoolId(req);
      const result = StockService.getStockTransactionById(schoolId, req.params.id);
      res.json({ success: true, data: result });
    } catch (error: any) {
      const status = error.message?.includes('not found') ? 404 : 500;
      res.status(status).json({ success: false, error: error.message || 'Failed to fetch transaction' });
    }
  }
);
