/**
 * Front Office & Visitor Management Routes (Part 13A)
 * Sygmate School Management System
 */

import crypto from 'crypto';
import { Router, Response } from 'express';
import { database } from '../db/database.js';
import { AuthenticatedRequest, requireAuth, requirePermission } from '../security/auth.js';
import { logAudit } from '../security/audit.js';
import { CommunicationService } from '../services/communication.service.js';
import {
  AdmissionEnquiry,
  AdmissionApplication,
  EnquiryFollowUp,
  VisitorRecord,
  VisitorStatus,
  PhoneCallLogRecord,
  CallMetricsSummary,
  ComplaintRecord,
  ComplaintStatus,
  ComplaintPriority,
  ComplaintSlaStatus,
  EscalationLevel,
  ComplaintResolutionCategory,
  ComplaintHistoryEntry,
  ComplaintMetricsSummary,
  FrontOfficeDashboardStats,
  FrontOfficeGlobalSearchResult,
  EnquiryPriority,
  EnquiryDuplicateMatch,
  EnquiryDuplicateCheckResult,
  EnquiryMetricsSummary,
  EnquirySourceConfig,
  FrontOfficeAnalyticsData,
  FrontOfficeAnalyticsTrendPoint,
  StaffWorkloadSummary,
  DepartmentDistributionItem
} from '../../src/types/index.js';
import { INITIAL_ENQUIRY_SOURCES } from '../db/front-office-seed.js';

export const frontOfficeRouter = Router();

// Enforce authentication across all Front Office endpoints
frontOfficeRouter.use(requireAuth);

/**
 * Defensive check to ensure database arrays are initialized
 */
function ensureFrontOfficeCollections() {
  if (!database.admissionEnquiries) database.admissionEnquiries = [];
  if (!database.admissionApplications) database.admissionApplications = [];
  if (!database.enquiryFollowups) database.enquiryFollowups = [];
  if (!database.visitors) database.visitors = [];
  if (!database.phoneCallLogs) database.phoneCallLogs = [];
  if (!database.complaints) database.complaints = [];
  if (!database.enquirySources || database.enquirySources.length === 0) {
    database.enquirySources = [...INITIAL_ENQUIRY_SOURCES];
  }

  const today = new Date();
  const todayStr = today.toISOString().split('T')[0];
  const yesterday = new Date(today.getTime() - 86400000).toISOString().split('T')[0];
  const tomorrow = new Date(today.getTime() + 86400000).toISOString().split('T')[0];

  // Guarantee seed admission enquiries if empty
  if (database.admissionEnquiries.length === 0) {
    database.admissionEnquiries = [
      {
        id: 'enq-2026-001',
        enquiryNumber: 'ENQ-2026-0001',
        enquiryDate: todayStr,
        studentName: 'Julian Sterling',
        dateOfBirth: '2011-05-14',
        gender: 'male',
        applyingClassId: 'class-g9',
        applyingClassName: 'Grade 9',
        academicSessionId: 'session-2026-2027',
        academicSessionName: '2026-2027 Academic Year',
        parentName: 'Victoria Sterling',
        relationship: 'Mother',
        phone: '+1 (617) 555-0143',
        alternatePhone: '+1 (617) 555-0144',
        email: 'victoria.sterling@example.com',
        address: '120 Beacon St, Boston, MA',
        previousSchool: 'Oakridge Middle Academy',
        source: 'WALK_IN',
        enquiryType: 'Admission',
        assignedStaffId: 'usr-admin-1',
        assignedStaffName: 'Dr. Arthur Sterling',
        status: 'NEW',
        priority: 'HIGH',
        followUpDate: todayStr,
        followUpTime: '14:00',
        followUpStatus: 'Scheduled',
        notes: 'Inquired about the STEM robotics honors program and transportation bus routes.',
        assignmentHistory: [
          {
            id: 'asgh-001',
            toStaffId: 'usr-admin-1',
            toStaffName: 'Dr. Arthur Sterling',
            assignedById: 'usr-admin-1',
            assignedByName: 'Dr. Arthur Sterling',
            assignedAt: `${todayStr}T09:00:00.000Z`,
            notes: 'Initial walk-in assignment'
          }
        ],
        statusHistory: [
          {
            fromStatus: 'NONE',
            toStatus: 'NEW',
            changedById: 'usr-admin-1',
            changedByName: 'Dr. Arthur Sterling',
            changedAt: `${todayStr}T09:00:00.000Z`,
            remarks: 'Walk-in enquiry logged at reception.'
          }
        ],
        createdById: 'usr-admin-1',
        createdByName: 'Dr. Arthur Sterling',
        createdAt: `${todayStr}T09:00:00.000Z`,
        updatedAt: `${todayStr}T09:00:00.000Z`
      },
      {
        id: 'enq-2026-002',
        enquiryNumber: 'ENQ-2026-0002',
        enquiryDate: yesterday,
        studentName: 'Chloe Lin',
        dateOfBirth: '2010-08-22',
        gender: 'female',
        applyingClassId: 'class-g10',
        applyingClassName: 'Grade 10',
        academicSessionId: 'session-2026-2027',
        academicSessionName: '2026-2027 Academic Year',
        parentName: 'David Lin',
        relationship: 'Father',
        phone: '+1 (617) 555-0288',
        alternatePhone: '',
        email: 'david.lin@example.com',
        address: '45 Harvard St, Cambridge, MA',
        previousSchool: 'Metro Cambridge Day School',
        source: 'WEBSITE',
        enquiryType: 'Admission',
        assignedStaffId: 'usr-admin-1',
        assignedStaffName: 'Dr. Arthur Sterling',
        status: 'INTERESTED',
        priority: 'URGENT',
        followUpDate: tomorrow,
        followUpTime: '11:00',
        followUpStatus: 'Scheduled',
        notes: 'Requested laboratory tour and syllabus overview for honors physics.',
        assignmentHistory: [],
        statusHistory: [
          {
            fromStatus: 'NEW',
            toStatus: 'CONTACTED',
            changedById: 'usr-admin-1',
            changedByName: 'Dr. Arthur Sterling',
            changedAt: `${yesterday}T14:30:00.000Z`,
            remarks: 'Initial call made to father.'
          },
          {
            fromStatus: 'CONTACTED',
            toStatus: 'INTERESTED',
            changedById: 'usr-admin-1',
            changedByName: 'Dr. Arthur Sterling',
            changedAt: `${yesterday}T15:00:00.000Z`,
            remarks: 'Parent expressed strong interest; tour scheduled.'
          }
        ],
        createdById: 'usr-admin-1',
        createdByName: 'Dr. Arthur Sterling',
        createdAt: `${yesterday}T10:00:00.000Z`,
        updatedAt: `${yesterday}T15:00:00.000Z`
      },
      {
        id: 'enq-2026-003',
        enquiryNumber: 'ENQ-2026-0003',
        enquiryDate: '2026-09-02',
        studentName: 'Ethan Walker',
        dateOfBirth: '2009-11-03',
        gender: 'male',
        applyingClassId: 'class-g11',
        applyingClassName: 'Grade 11',
        academicSessionId: 'session-2026-2027',
        academicSessionName: '2026-2027 Academic Year',
        parentName: 'Sarah Walker',
        relationship: 'Mother',
        phone: '+1 (617) 555-0372',
        alternatePhone: '',
        email: 'sarah.walker@example.com',
        address: '88 River Rd, Somerville, MA',
        previousSchool: 'Somerville Community High',
        source: 'PHONE',
        enquiryType: 'Admission',
        assignedStaffId: 'usr-admin-1',
        assignedStaffName: 'Dr. Arthur Sterling',
        status: 'FOLLOW_UP_REQUIRED',
        priority: 'MEDIUM',
        followUpDate: todayStr,
        followUpTime: '10:00',
        followUpStatus: 'Scheduled',
        notes: 'Sent fee breakdown and athletic scholarship brochure. Callback requested.',
        assignmentHistory: [],
        statusHistory: [
          {
            fromStatus: 'NEW',
            toStatus: 'FOLLOW_UP_REQUIRED',
            changedById: 'usr-admin-1',
            changedByName: 'Dr. Arthur Sterling',
            changedAt: '2026-09-02T11:00:00.000Z',
            remarks: 'Prospectus delivered via email.'
          }
        ],
        createdById: 'usr-admin-1',
        createdByName: 'Dr. Arthur Sterling',
        createdAt: '2026-09-02T10:00:00.000Z',
        updatedAt: '2026-09-02T11:00:00.000Z'
      },
      {
        id: 'enq-2026-004',
        enquiryNumber: 'ENQ-2026-0004',
        enquiryDate: '2026-09-05',
        studentName: 'Amara Patel',
        dateOfBirth: '2011-01-19',
        gender: 'female',
        applyingClassId: 'class-g9',
        applyingClassName: 'Grade 9',
        academicSessionId: 'session-2026-2027',
        academicSessionName: '2026-2027 Academic Year',
        parentName: 'Rajesh Patel',
        relationship: 'Father',
        phone: '+1 (617) 555-0491',
        alternatePhone: '+1 (617) 555-0492',
        email: 'rajesh.patel@example.com',
        address: '210 Kendall Square, Cambridge, MA',
        previousSchool: 'North Cambridge Elementary',
        source: 'REFERRAL',
        enquiryType: 'Admission',
        assignedStaffId: 'usr-teacher-1',
        assignedStaffName: 'Prof. Sarah Jenkins',
        status: 'APPLICATION_STARTED',
        priority: 'HIGH',
        followUpDate: tomorrow,
        followUpTime: '16:00',
        followUpStatus: 'Scheduled',
        notes: 'Online application started by parent. Awaiting medical documents.',
        assignmentHistory: [
          {
            id: 'asgh-002',
            fromStaffId: 'usr-admin-1',
            fromStaffName: 'Dr. Arthur Sterling',
            toStaffId: 'usr-teacher-1',
            toStaffName: 'Prof. Sarah Jenkins',
            assignedById: 'usr-admin-1',
            assignedByName: 'Dr. Arthur Sterling',
            assignedAt: '2026-09-06T09:30:00.000Z',
            notes: 'Reassigned to academic counselor'
          }
        ],
        statusHistory: [
          {
            fromStatus: 'INTERESTED',
            toStatus: 'APPLICATION_STARTED',
            changedById: 'usr-teacher-1',
            changedByName: 'Prof. Sarah Jenkins',
            changedAt: '2026-09-08T14:00:00.000Z',
            remarks: 'Application portal link opened.'
          }
        ],
        createdById: 'usr-admin-1',
        createdByName: 'Dr. Arthur Sterling',
        createdAt: '2026-09-05T08:30:00.000Z',
        updatedAt: '2026-09-08T14:00:00.000Z'
      },
      {
        id: 'enq-2026-005',
        enquiryNumber: 'ENQ-2026-0005',
        enquiryDate: '2026-08-20',
        studentName: 'Leo Montgomery',
        dateOfBirth: '2010-03-12',
        gender: 'male',
        applyingClassId: 'class-g10',
        applyingClassName: 'Grade 10',
        academicSessionId: 'session-2026-2027',
        academicSessionName: '2026-2027 Academic Year',
        parentName: 'Claire Montgomery',
        relationship: 'Mother',
        phone: '+1 (617) 555-0556',
        alternatePhone: '',
        email: 'claire.montgomery@example.com',
        address: '15 Maple Terrace, Boston, MA',
        previousSchool: 'Boston Public Latin',
        source: 'SOCIAL_MEDIA',
        enquiryType: 'Admission',
        assignedStaffId: 'usr-admin-1',
        assignedStaffName: 'Dr. Arthur Sterling',
        status: 'LOST',
        priority: 'LOW',
        notes: 'Family relocated to California due to job transfer.',
        assignmentHistory: [],
        statusHistory: [
          {
            fromStatus: 'FOLLOW_UP_REQUIRED',
            toStatus: 'LOST',
            changedById: 'usr-admin-1',
            changedByName: 'Dr. Arthur Sterling',
            changedAt: '2026-08-25T16:00:00.000Z',
            remarks: 'Parent confirmed interstate move.'
          }
        ],
        createdById: 'usr-admin-1',
        createdByName: 'Dr. Arthur Sterling',
        createdAt: '2026-08-20T11:00:00.000Z',
        updatedAt: '2026-08-25T16:00:00.000Z'
      }
    ];
  }

  // Defensive enrichment for all existing admission enquiries
  database.admissionEnquiries.forEach(e => {
    if (!e.priority) e.priority = 'MEDIUM';
    if (!e.enquiryDate) e.enquiryDate = e.createdAt ? e.createdAt.split('T')[0] : todayStr;
    if (!e.alternatePhone) e.alternatePhone = '';
    if (!e.previousSchool) e.previousSchool = '';
    if (!e.assignmentHistory) e.assignmentHistory = [];
    if (!e.statusHistory || e.statusHistory.length === 0) {
      e.statusHistory = [
        {
          fromStatus: 'NONE',
          toStatus: e.status || 'NEW',
          changedById: e.createdById || 'usr-admin-1',
          changedByName: e.createdByName || 'Administrator',
          changedAt: e.createdAt || new Date().toISOString(),
          remarks: 'Initial enquiry record logged'
        }
      ];
    }
  });

  // Guarantee enhanced fields for visitor records
  database.visitors.forEach((v, idx) => {
    if (!v.bookingId) {
      v.bookingId = `BK-${v.appointmentDate.replace(/-/g, '')}-${String(idx + 1).padStart(3, '0')}`;
    }
    if (!v.qrCodeToken) {
      v.qrCodeToken = `QR-${Math.random().toString(36).substring(2, 10).toUpperCase()}`;
    }
    if (!v.entryType) {
      v.entryType = idx % 2 === 0 ? 'SCHEDULED' : 'WALK_IN';
    }
    if (!v.vehicleType) {
      v.vehicleType = v.vehicleNumber ? 'Car' : 'None';
    }
    // If seed records have past or future appointment dates, align the first 4 to today's date
    if (idx < 4 && v.appointmentDate !== todayStr) {
      v.appointmentDate = todayStr;
      if (v.checkInTime) {
        v.checkInTime = `${todayStr}T${v.checkInTime.split('T')[1] || '09:00:00.000Z'}`;
      }
      if (v.checkOutTime) {
        v.checkOutTime = `${todayStr}T${v.checkOutTime.split('T')[1] || '10:00:00.000Z'}`;
      }
    }
  });
}

/**
 * Sequential number generators with collision protection
 */
function generateEnquiryNumber(): string {
  ensureFrontOfficeCollections();
  const year = new Date().getFullYear();
  const count = database.admissionEnquiries.length + 1;
  return `ENQ-${year}-${String(count).padStart(4, '0')}`;
}

function generateVisitorPassNumber(): string {
  ensureFrontOfficeCollections();
  const year = new Date().getFullYear();
  const count = database.visitors.length + 1;
  return `VIS-${year}-${String(count).padStart(4, '0')}`;
}

function generateBookingId(): string {
  ensureFrontOfficeCollections();
  const year = new Date().getFullYear();
  const count = database.visitors.length + 1;
  return `BKG-${year}-${String(count).padStart(4, '0')}`;
}

function generateQrCodeToken(): string {
  return `VQR-${Date.now().toString(36)}-${crypto.randomBytes(6).toString('hex')}`;
}

function generateCallLogNumber(): string {
  ensureFrontOfficeCollections();
  const year = new Date().getFullYear();
  const count = database.phoneCallLogs.length + 1;
  return `CALL-${year}-${String(count).padStart(4, '0')}`;
}

function generateComplaintNumber(): string {
  ensureFrontOfficeCollections();
  const year = new Date().getFullYear();
  const count = database.complaints.length + 1;
  return `CMP-${year}-${String(count).padStart(4, '0')}`;
}

function generateApplicationNumber(): string {
  ensureFrontOfficeCollections();
  const year = new Date().getFullYear();
  const count = database.admissionApplications.length + 1;
  return `APP-${year}-${String(count).padStart(4, '0')}`;
}

// Helper: Compute date range from dashboard presets
export function getDateRangeFromPreset(
  preset?: string,
  customStart?: string,
  customEnd?: string,
  sessionId?: string
): { startDate: string; endDate: string } {
  const now = new Date();
  const todayStr = now.toISOString().split('T')[0];

  switch (preset) {
    case 'YESTERDAY': {
      const y = new Date(now.getTime() - 86400000);
      const yStr = y.toISOString().split('T')[0];
      return { startDate: yStr, endDate: yStr };
    }
    case 'LAST_7_DAYS': {
      const start = new Date(now.getTime() - 7 * 86400000).toISOString().split('T')[0];
      return { startDate: start, endDate: todayStr };
    }
    case 'LAST_30_DAYS': {
      const start = new Date(now.getTime() - 30 * 86400000).toISOString().split('T')[0];
      return { startDate: start, endDate: todayStr };
    }
    case 'CURRENT_MONTH': {
      const start = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split('T')[0];
      return { startDate: start, endDate: todayStr };
    }
    case 'PREVIOUS_MONTH': {
      const start = new Date(now.getFullYear(), now.getMonth() - 1, 1).toISOString().split('T')[0];
      const end = new Date(now.getFullYear(), now.getMonth(), 0).toISOString().split('T')[0];
      return { startDate: start, endDate: end };
    }
    case 'CURRENT_SESSION': {
      const session = sessionId
        ? database.academicSessions?.find(s => s.id === sessionId)
        : database.academicSessions?.find(s => s.isCurrent || s.status === 'ACTIVE') || database.academicSessions?.[0];
      if (session && session.startDate && session.endDate) {
        return { startDate: session.startDate, endDate: session.endDate };
      }
      const y = now.getFullYear();
      return { startDate: `${y}-01-01`, endDate: `${y}-12-31` };
    }
    case 'CUSTOM': {
      const s = customStart || todayStr;
      const e = customEnd || todayStr;
      return s <= e ? { startDate: s, endDate: e } : { startDate: e, endDate: s };
    }
    case 'TODAY':
    default:
      return { startDate: todayStr, endDate: todayStr };
  }
}

// =========================================================================
// 1. DASHBOARD & OPERATIONAL STATS & ANALYTICS
// =========================================================================

/**
 * GET /api/front-office/dashboard/stats
 * Computes authoritative front office operational statistics from database
 */
frontOfficeRouter.get(
  '/dashboard/stats',
  requirePermission('front_office.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const todayStr = new Date().toISOString().split('T')[0];
      const { datePreset, startDate, endDate, academicSessionId } = req.query;

      const { startDate: sDate, endDate: eDate } = getDateRangeFromPreset(
        String(datePreset || 'TODAY'),
        String(startDate || ''),
        String(endDate || ''),
        String(academicSessionId || '')
      );

      // Filtered sets by period
      let periodEnquiries = database.admissionEnquiries.filter(e => {
        const d = e.enquiryDate || e.createdAt.split('T')[0];
        return d >= sDate && d <= eDate;
      });
      if (academicSessionId && academicSessionId !== 'ALL') {
        periodEnquiries = periodEnquiries.filter(e => e.academicSessionId === academicSessionId);
      }

      const periodVisitors = database.visitors.filter(v => v.appointmentDate >= sDate && v.appointmentDate <= eDate);
      const periodCalls = database.phoneCallLogs.filter(c => c.callDate >= sDate && c.callDate <= eDate);
      const periodComplaints = database.complaints.filter(c => c.complaintDate >= sDate && c.complaintDate <= eDate);

      // 1. Admission Enquiries
      const totalEnquiries = periodEnquiries.length;
      const newEnquiries = periodEnquiries.filter(e => e.status === 'NEW').length;
      const pendingFollowups = database.admissionEnquiries.filter(
        e =>
          (e.status === 'FOLLOW_UP_REQUIRED' || (e.followUpDate && e.followUpStatus !== 'COMPLETED' && e.followUpStatus !== 'CANCELLED')) &&
          e.status !== 'CONVERTED' &&
          e.status !== 'CLOSED' &&
          e.status !== 'LOST'
      ).length;
      const followupsDueToday = database.admissionEnquiries.filter(
        e =>
          e.followUpDate === todayStr &&
          e.followUpStatus !== 'COMPLETED' &&
          e.followUpStatus !== 'CANCELLED' &&
          e.status !== 'CONVERTED' &&
          e.status !== 'CLOSED'
      ).length;
      const overdueFollowups = database.admissionEnquiries.filter(
        e =>
          e.followUpDate &&
          e.followUpDate < todayStr &&
          e.followUpStatus !== 'COMPLETED' &&
          e.followUpStatus !== 'CANCELLED' &&
          e.status !== 'CONVERTED' &&
          e.status !== 'CLOSED'
      ).length;
      const convertedAdmissions = periodEnquiries.filter(e => e.status === 'CONVERTED').length;
      const lostOrClosedEnquiries = periodEnquiries.filter(
        e => e.status === 'CLOSED' || e.status === 'NOT_INTERESTED' || e.status === 'FOLLOW_UP_COMPLETED'
      ).length;
      const conversionRate = totalEnquiries > 0 ? Math.round((convertedAdmissions / totalEnquiries) * 100) : 0;

      // 2. Visitors
      const todaysVisitors = periodVisitors.length;
      const expectedVisitors = periodVisitors.filter(
        v => v.status === 'SCHEDULED' || v.status === 'CONFIRMED' || v.status === 'PENDING'
      ).length;
      const checkedInVisitors = database.visitors.filter(v => v.status === 'CHECKED_IN').length;
      const currentlyInsideVisitors = checkedInVisitors;
      const checkedOutVisitors = periodVisitors.filter(v => v.status === 'CHECKED_OUT').length;
      const completedVisits = checkedOutVisitors;
      const cancelledVisits = periodVisitors.filter(v => v.status === 'CANCELLED' || v.status === 'REJECTED').length;
      const noShowVisitors = periodVisitors.filter(v => v.status === 'NO_SHOW').length;

      let totalStayMinutes = 0;
      let stayCount = 0;
      periodVisitors.filter(v => v.status === 'CHECKED_OUT').forEach(v => {
        if (v.durationMinutes) {
          totalStayMinutes += v.durationMinutes;
          stayCount++;
        } else if (v.checkInTime && v.checkOutTime) {
          const diff = Math.round((new Date(v.checkOutTime).getTime() - new Date(v.checkInTime).getTime()) / 60000);
          if (diff > 0) {
            totalStayMinutes += diff;
            stayCount++;
          }
        }
      });
      const averageVisitDurationMinutes = stayCount > 0 ? Math.round(totalStayMinutes / stayCount) : 0;

      // 3. Phone Calls
      const todaysCalls = periodCalls.length;
      const incomingCalls = periodCalls.filter(c => c.direction === 'INCOMING').length;
      const outgoingCalls = periodCalls.filter(c => c.direction === 'OUTGOING').length;
      const missedCalls = periodCalls.filter(c => c.status === 'MISSED').length;
      const callsFollowUpRequired = database.phoneCallLogs.filter(
        c =>
          (c.followUpRequired || c.status === 'FOLLOW_UP_REQUIRED') &&
          c.followUpStatus !== 'COMPLETED' &&
          c.followUpStatus !== 'CANCELLED' &&
          c.status !== 'CLOSED'
      ).length;
      const callsFollowUpDueToday = database.phoneCallLogs.filter(
        c =>
          (c.followUpRequired || c.status === 'FOLLOW_UP_REQUIRED') &&
          c.followUpDate === todayStr &&
          c.followUpStatus !== 'COMPLETED' &&
          c.followUpStatus !== 'CANCELLED'
      ).length;
      const callsFollowUpOverdue = database.phoneCallLogs.filter(
        c =>
          (c.followUpRequired || c.status === 'FOLLOW_UP_REQUIRED') &&
          c.followUpDate &&
          c.followUpDate < todayStr &&
          c.followUpStatus !== 'COMPLETED' &&
          c.followUpStatus !== 'CANCELLED'
      ).length;

      // 4. Complaints
      const totalComplaints = periodComplaints.length;
      const newComplaints = database.complaints.filter(c => c.status === 'NEW').length;
      const openComplaints = database.complaints.filter(
        c => c.status === 'NEW' || c.status === 'ASSIGNED' || c.status === 'ACKNOWLEDGED' || c.status === 'IN_PROGRESS' || c.status === 'REOPENED'
      ).length;
      const inProgressComplaints = database.complaints.filter(c => c.status === 'IN_PROGRESS').length;
      const resolvedComplaints = periodComplaints.filter(c => c.status === 'RESOLVED').length;
      const closedComplaints = periodComplaints.filter(c => c.status === 'CLOSED').length;

      const overdueComplaints = database.complaints.filter(
        c => c.status !== 'RESOLVED' && c.status !== 'CLOSED' && computeComplaintSla(c).slaStatus === 'BREACHED'
      ).length;
      const slaAtRiskComplaints = database.complaints.filter(
        c => c.status !== 'RESOLVED' && c.status !== 'CLOSED' && computeComplaintSla(c).slaStatus === 'AT_RISK'
      ).length;
      const urgentComplaints = database.complaints.filter(
        c => (c.priority === 'URGENT') && c.status !== 'RESOLVED' && c.status !== 'CLOSED'
      ).length;
      const highComplaints = database.complaints.filter(
        c => (c.priority === 'HIGH') && c.status !== 'RESOLVED' && c.status !== 'CLOSED'
      ).length;

      const stats: FrontOfficeDashboardStats = {
        datePreset: (datePreset as any) || 'TODAY',
        startDate: sDate,
        endDate: eDate,
        sessionId: String(academicSessionId || ''),
        totalEnquiries,
        newEnquiries,
        pendingFollowups,
        followupsDueToday,
        overdueFollowups,
        convertedAdmissions,
        lostOrClosedEnquiries,
        conversionRate,
        todaysVisitors,
        expectedVisitors,
        checkedInVisitors,
        currentlyInsideVisitors,
        checkedOutVisitors,
        completedVisits,
        cancelledVisits,
        noShowVisitors,
        averageVisitDurationMinutes,
        todaysCalls,
        incomingCalls,
        outgoingCalls,
        missedCalls,
        callsFollowUpRequired,
        callsFollowUpDueToday,
        callsFollowUpOverdue,
        totalComplaints,
        newComplaints,
        openComplaints,
        inProgressComplaints,
        resolvedComplaints,
        closedComplaints,
        overdueComplaints,
        slaAtRiskComplaints,
        urgentComplaints,
        highComplaints,
        // Legacy aliases
        followUpRequiredEnquiries: pendingFollowups,
        pendingEnquiries: totalEnquiries - convertedAdmissions - lostOrClosedEnquiries,
        pendingComplaints: openComplaints
      };

      res.json({ success: true, data: stats });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * GET /api/front-office/dashboard/analytics
 * Comprehensive cross-front-office workload, time-series trends, staff workload, and department distribution
 */
frontOfficeRouter.get(
  '/dashboard/analytics',
  requirePermission('front_office.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const todayStr = new Date().toISOString().split('T')[0];
      const { datePreset, startDate, endDate, academicSessionId } = req.query;

      const { startDate: sDate, endDate: eDate } = getDateRangeFromPreset(
        String(datePreset || 'LAST_7_DAYS'),
        String(startDate || ''),
        String(endDate || ''),
        String(academicSessionId || '')
      );

      // Period datasets
      let periodEnquiries = database.admissionEnquiries.filter(e => {
        const d = e.enquiryDate || e.createdAt.split('T')[0];
        return d >= sDate && d <= eDate;
      });
      if (academicSessionId && academicSessionId !== 'ALL') {
        periodEnquiries = periodEnquiries.filter(e => e.academicSessionId === academicSessionId);
      }

      const periodVisitors = database.visitors.filter(v => v.appointmentDate >= sDate && v.appointmentDate <= eDate);
      const periodCalls = database.phoneCallLogs.filter(c => c.callDate >= sDate && c.callDate <= eDate);
      const periodComplaints = database.complaints.filter(c => c.complaintDate >= sDate && c.complaintDate <= eDate);

      // Build day-by-day trends
      const daysCount = Math.max(1, Math.min(31, Math.round((new Date(eDate).getTime() - new Date(sDate).getTime()) / 86400000) + 1));
      const trendMap: Record<string, FrontOfficeAnalyticsTrendPoint> = {};

      for (let i = 0; i < daysCount; i++) {
        const curr = new Date(new Date(sDate).getTime() + i * 86400000);
        const iso = curr.toISOString().split('T')[0];
        const label = curr.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
        trendMap[iso] = {
          date: iso,
          label,
          enquiries: 0,
          visitors: 0,
          calls: 0,
          complaints: 0
        };
      }

      periodEnquiries.forEach(e => {
        const d = e.enquiryDate || e.createdAt.split('T')[0];
        if (trendMap[d]) trendMap[d].enquiries++;
      });
      periodVisitors.forEach(v => {
        const d = v.appointmentDate;
        if (trendMap[d]) trendMap[d].visitors++;
      });
      periodCalls.forEach(c => {
        const d = c.callDate;
        if (trendMap[d]) trendMap[d].calls++;
      });
      periodComplaints.forEach(c => {
        const d = c.complaintDate;
        if (trendMap[d]) trendMap[d].complaints++;
      });

      const trends = Object.values(trendMap).sort((a, b) => a.date.localeCompare(b.date));

      // Staff workload matrix
      const staffMap: Record<string, StaffWorkloadSummary> = {};
      const staffList = (database.users || []).filter(u => u.role === 'TEACHER' || u.role === 'SUPER_ADMIN' || (u.role as string) === 'ADMIN');

      staffList.forEach(s => {
        staffMap[s.id] = {
          staffId: s.id,
          staffName: s.name,
          department: (s as any).department || 'Administration',
          enquiriesAssigned: 0,
          enquiriesConverted: 0,
          visitorsHosted: 0,
          callsHandled: 0,
          complaintsAssigned: 0,
          complaintsResolved: 0,
          totalInteractions: 0
        };
      });

      periodEnquiries.forEach(e => {
        if (e.assignedStaffId && staffMap[e.assignedStaffId]) {
          staffMap[e.assignedStaffId].enquiriesAssigned++;
          if (e.status === 'CONVERTED') staffMap[e.assignedStaffId].enquiriesConverted++;
        }
      });
      periodVisitors.forEach(v => {
        if (v.personToMeetId && staffMap[v.personToMeetId]) {
          staffMap[v.personToMeetId].visitorsHosted++;
        } else {
          // match by name
          const match = Object.values(staffMap).find(s => s.staffName.toLowerCase() === v.personToMeet.toLowerCase());
          if (match) match.visitorsHosted++;
        }
      });
      periodCalls.forEach(c => {
        if (c.assignedStaffId && staffMap[c.assignedStaffId]) {
          staffMap[c.assignedStaffId].callsHandled++;
        } else if (c.createdById && staffMap[c.createdById]) {
          staffMap[c.createdById].callsHandled++;
        }
      });
      periodComplaints.forEach(c => {
        if (c.assignedStaffId && staffMap[c.assignedStaffId]) {
          staffMap[c.assignedStaffId].complaintsAssigned++;
          if (c.status === 'RESOLVED' || c.status === 'CLOSED') {
            staffMap[c.assignedStaffId].complaintsResolved++;
          }
        }
      });

      Object.values(staffMap).forEach(s => {
        s.totalInteractions = s.enquiriesAssigned + s.visitorsHosted + s.callsHandled + s.complaintsAssigned;
      });

      const staffWorkload = Object.values(staffMap)
        .filter(s => s.totalInteractions > 0 || s.staffName.includes('Admin') || s.staffName.includes('Sterling'))
        .sort((a, b) => b.totalInteractions - a.totalInteractions);

      // Department distribution
      const deptMap: Record<string, DepartmentDistributionItem> = {
        Administration: { department: 'Administration', visitorsCount: 0, callsCount: 0, complaintsCount: 0, totalVolume: 0 },
        Admissions: { department: 'Admissions', visitorsCount: 0, callsCount: 0, complaintsCount: 0, totalVolume: 0 },
        Academics: { department: 'Academics', visitorsCount: 0, callsCount: 0, complaintsCount: 0, totalVolume: 0 },
        Accounts: { department: 'Accounts / Finance', visitorsCount: 0, callsCount: 0, complaintsCount: 0, totalVolume: 0 },
        Transport: { department: 'Transport', visitorsCount: 0, callsCount: 0, complaintsCount: 0, totalVolume: 0 },
        Security: { department: 'Security & Campus', visitorsCount: 0, callsCount: 0, complaintsCount: 0, totalVolume: 0 }
      };

      periodVisitors.forEach(v => {
        const d = v.department || 'Administration';
        if (!deptMap[d]) deptMap[d] = { department: d, visitorsCount: 0, callsCount: 0, complaintsCount: 0, totalVolume: 0 };
        deptMap[d].visitorsCount++;
      });
      periodCalls.forEach(c => {
        const d = c.department || 'Administration';
        if (!deptMap[d]) deptMap[d] = { department: d, visitorsCount: 0, callsCount: 0, complaintsCount: 0, totalVolume: 0 };
        deptMap[d].callsCount++;
      });
      periodComplaints.forEach(c => {
        const d = c.assignedDepartment || 'Administration';
        if (!deptMap[d]) deptMap[d] = { department: d, visitorsCount: 0, callsCount: 0, complaintsCount: 0, totalVolume: 0 };
        deptMap[d].complaintsCount++;
      });

      Object.values(deptMap).forEach(d => {
        d.totalVolume = d.visitorsCount + d.callsCount + d.complaintsCount;
      });

      const departmentDistribution = Object.values(deptMap)
        .filter(d => d.totalVolume > 0 || ['Administration', 'Admissions', 'Academics'].includes(d.department))
        .sort((a, b) => b.totalVolume - a.totalVolume);

      // Category breakdowns
      const enquiryStatusBreakdown: Record<string, number> = {};
      const enquirySourceBreakdown: Record<string, number> = {};
      periodEnquiries.forEach(e => {
        enquiryStatusBreakdown[e.status] = (enquiryStatusBreakdown[e.status] || 0) + 1;
        enquirySourceBreakdown[e.source] = (enquirySourceBreakdown[e.source] || 0) + 1;
      });

      const complaintCategoryBreakdown: Record<string, number> = {};
      const complaintPriorityBreakdown: Record<string, number> = {};
      periodComplaints.forEach(c => {
        const cat = c.complaintCategory || c.category || 'Other';
        complaintCategoryBreakdown[cat] = (complaintCategoryBreakdown[cat] || 0) + 1;
        complaintPriorityBreakdown[c.priority] = (complaintPriorityBreakdown[c.priority] || 0) + 1;
      });

      const callTypeBreakdown: Record<string, number> = {};
      periodCalls.forEach(c => {
        const t = c.callType || 'General Query';
        callTypeBreakdown[t] = (callTypeBreakdown[t] || 0) + 1;
      });

      // Overall numbers
      const convertedEnq = periodEnquiries.filter(e => e.status === 'CONVERTED').length;
      const insideVisitors = database.visitors.filter(v => v.status === 'CHECKED_IN').length;
      const completedVis = periodVisitors.filter(v => v.status === 'CHECKED_OUT').length;
      const missedC = periodCalls.filter(c => c.status === 'MISSED').length;
      const pendingCb = database.phoneCallLogs.filter(
        c => (c.followUpRequired || c.status === 'FOLLOW_UP_REQUIRED') && c.followUpStatus !== 'COMPLETED'
      ).length;
      const openCmp = database.complaints.filter(
        c => c.status === 'NEW' || c.status === 'ASSIGNED' || c.status === 'IN_PROGRESS'
      ).length;
      const resCmp = periodComplaints.filter(c => c.status === 'RESOLVED').length;
      const breachedCmp = database.complaints.filter(
        c => c.status !== 'RESOLVED' && c.status !== 'CLOSED' && computeComplaintSla(c).slaStatus === 'BREACHED'
      ).length;
      const urgCmp = database.complaints.filter(
        c => c.priority === 'URGENT' && c.status !== 'RESOLVED' && c.status !== 'CLOSED'
      ).length;

      let totalDuration = 0;
      let durationCount = 0;
      periodVisitors.filter(v => v.status === 'CHECKED_OUT').forEach(v => {
        if (v.durationMinutes) {
          totalDuration += v.durationMinutes;
          durationCount++;
        }
      });
      const avgDuration = durationCount > 0 ? Math.round(totalDuration / durationCount) : 0;

      const analyticsData: FrontOfficeAnalyticsData = {
        timeframe: {
          preset: String(datePreset || 'LAST_7_DAYS'),
          startDate: sDate,
          endDate: eDate
        },
        overview: {
          enquiries: {
            total: periodEnquiries.length,
            converted: convertedEnq,
            pending: periodEnquiries.length - convertedEnq,
            rate: periodEnquiries.length > 0 ? Math.round((convertedEnq / periodEnquiries.length) * 100) : 0
          },
          visitors: {
            total: periodVisitors.length,
            currentlyInside: insideVisitors,
            completed: completedVis,
            avgDuration
          },
          calls: {
            total: periodCalls.length,
            incoming: periodCalls.filter(c => c.direction === 'INCOMING').length,
            outgoing: periodCalls.filter(c => c.direction === 'OUTGOING').length,
            missed: missedC,
            pendingCallback: pendingCb
          },
          complaints: {
            total: periodComplaints.length,
            open: openCmp,
            resolved: resCmp,
            breached: breachedCmp,
            urgent: urgCmp
          }
        },
        trends,
        timeSeries: trends,
        staffWorkload,
        departmentDistribution,
        enquiryStatusBreakdown,
        enquirySourceBreakdown,
        complaintCategoryBreakdown,
        complaintPriorityBreakdown,
        callTypeBreakdown
      };

      res.json({ success: true, data: analyticsData });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * GET /api/front-office/dashboard/overview
 * Returns dashboard summary including recent activities, visitors today, and pending tasks
 */
frontOfficeRouter.get(
  '/dashboard/overview',
  requirePermission('front_office.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const todayStr = new Date().toISOString().split('T')[0];

      // Recent/Today's visitors
      const visitorsToday = database.visitors
        .filter(v => v.appointmentDate === todayStr || v.status === 'CHECKED_IN')
        .sort((a, b) => (a.appointmentTime || '').localeCompare(b.appointmentTime || ''));

      // Pending followups
      const pendingFollowups = database.admissionEnquiries
        .filter(e => e.status === 'FOLLOW_UP_REQUIRED' || (e.followUpDate && e.followUpDate <= todayStr && e.status !== 'CONVERTED' && e.status !== 'CLOSED'))
        .slice(0, 5);

      // Urgent complaints
      const urgentComplaints = database.complaints
        .filter(c => (c.priority === 'URGENT' || c.priority === 'HIGH') && c.status !== 'RESOLVED' && c.status !== 'CLOSED')
        .slice(0, 5);

      // Recent Calls
      const recentCalls = [...database.phoneCallLogs]
        .sort((a, b) => new Date(`${b.callDate}T${b.callTime || '00:00'}`).getTime() - new Date(`${a.callDate}T${a.callTime || '00:00'}`).getTime())
        .slice(0, 5);

      res.json({
        success: true,
        data: {
          visitorsToday,
          pendingFollowups,
          urgentComplaints,
          recentCalls
        }
      });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

// =========================================================================
// 2. ADMISSION ENQUIRY ENDPOINTS & WORKFLOW (PART 13C ENHANCED)
// =========================================================================

/**
 * GET /api/front-office/enquiry-sources
 * Get all configured admission enquiry sources
 */
frontOfficeRouter.get(
  '/enquiry-sources',
  requirePermission('front_office.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const sources = [...database.enquirySources].sort((a, b) => a.displayOrder - b.displayOrder);
      res.json({ success: true, data: sources });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * POST /api/front-office/enquiry-sources
 * Add custom enquiry source
 */
frontOfficeRouter.post(
  '/enquiry-sources',
  requirePermission('front_office.manage_enquiries'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const { name, code } = req.body;
      if (!name || !name.trim()) {
        res.status(400).json({ success: false, error: 'Source name is required.' });
        return;
      }
      const safeCode = code ? String(code).trim().toUpperCase().replace(/\s+/g, '_') : String(name).trim().toUpperCase().replace(/\s+/g, '_');
      const existing = database.enquirySources.find(s => s.code === safeCode);
      if (existing) {
        res.status(400).json({ success: false, error: 'A source with this code already exists.' });
        return;
      }

      const newSource: EnquirySourceConfig = {
        id: `src-${Date.now()}`,
        name: String(name).trim(),
        code: safeCode,
        isActive: true,
        isDefault: false,
        displayOrder: database.enquirySources.length + 1
      };

      database.enquirySources.push(newSource);

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'CREATE',
        entity: 'EnquirySource',
        entityId: newSource.id,
        details: `Created custom admission enquiry source "${newSource.name}" (${newSource.code}).`
      });

      res.status(201).json({ success: true, data: newSource });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * PATCH /api/front-office/enquiry-sources/:id
 * Toggle status or rename enquiry source
 */
frontOfficeRouter.patch(
  '/enquiry-sources/:id',
  requirePermission('front_office.manage_enquiries'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const source = database.enquirySources.find(s => s.id === req.params.id);
      if (!source) {
        res.status(404).json({ success: false, error: 'Enquiry source not found.' });
        return;
      }

      if (req.body.name) source.name = String(req.body.name).trim();
      if (req.body.isActive !== undefined) source.isActive = Boolean(req.body.isActive);
      if (req.body.displayOrder !== undefined) source.displayOrder = Number(req.body.displayOrder);

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'UPDATE',
        entity: 'EnquirySource',
        entityId: source.id,
        details: `Updated enquiry source ${source.name} (Active: ${source.isActive}).`
      });

      res.json({ success: true, data: source });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * GET /api/front-office/enquiries/check-duplicates
 * Server-side duplicate detection across enquiries, existing students, and applications
 */
frontOfficeRouter.get(
  '/enquiries/check-duplicates',
  requirePermission('front_office.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const phone = req.query.phone ? String(req.query.phone).trim() : '';
      const email = req.query.email ? String(req.query.email).trim().toLowerCase() : '';
      const studentName = req.query.studentName ? String(req.query.studentName).trim().toLowerCase() : '';
      const parentName = req.query.parentName ? String(req.query.parentName).trim().toLowerCase() : '';
      const excludeId = req.query.excludeId ? String(req.query.excludeId) : '';

      const cleanPhone = (p: string) => p.replace(/\D/g, '');
      const reqPhoneClean = cleanPhone(phone);

      const matches: EnquiryDuplicateMatch[] = [];

      // 1. Check existing admission enquiries
      for (const enq of database.admissionEnquiries) {
        if (excludeId && enq.id === excludeId) continue;

        const matchedFields: string[] = [];
        let score = 0;

        // Check phone (full or last 7-10 digits match)
        if (reqPhoneClean && reqPhoneClean.length >= 7) {
          const enqPhoneClean = cleanPhone(enq.phone);
          const enqAltClean = cleanPhone(enq.alternatePhone || '');
          if (
            (enqPhoneClean && (enqPhoneClean.endsWith(reqPhoneClean) || reqPhoneClean.endsWith(enqPhoneClean))) ||
            (enqAltClean && (enqAltClean.endsWith(reqPhoneClean) || reqPhoneClean.endsWith(enqAltClean)))
          ) {
            matchedFields.push('Phone Number');
            score += 50;
          }
        }

        // Check email
        if (email && enq.email && enq.email.toLowerCase() === email) {
          matchedFields.push('Email Address');
          score += 40;
        }

        // Check student name
        if (studentName && enq.studentName.toLowerCase() === studentName) {
          matchedFields.push('Student Exact Name');
          score += 30;
        } else if (
          studentName &&
          studentName.length > 3 &&
          (enq.studentName.toLowerCase().includes(studentName) || studentName.includes(enq.studentName.toLowerCase()))
        ) {
          matchedFields.push('Student Similar Name');
          score += 15;
        }

        // Check parent name
        if (parentName && enq.parentName.toLowerCase() === parentName) {
          matchedFields.push('Parent Name');
          score += 20;
        }

        if (matchedFields.length > 0) {
          matches.push({
            id: enq.id,
            entityType: 'ENQUIRY',
            identifier: enq.enquiryNumber,
            name: enq.studentName,
            parentName: enq.parentName,
            phone: enq.phone,
            email: enq.email,
            status: enq.status,
            createdAt: enq.createdAt,
            matchedFields,
            similarityScore: Math.min(100, score)
          });
        }
      }

      // 2. Check existing students
      if (database.studentProfiles) {
        for (const st of database.studentProfiles) {
          const matchedFields: string[] = [];
          let score = 0;

          if (reqPhoneClean && reqPhoneClean.length >= 7) {
            const stPhoneClean = cleanPhone(st.phone || '');
            const stEmerClean = cleanPhone((st as any).emergencyContactNumber || (st as any).emergencyContact || '');
            if (
              (stPhoneClean && (stPhoneClean.endsWith(reqPhoneClean) || reqPhoneClean.endsWith(stPhoneClean))) ||
              (stEmerClean && (stEmerClean.endsWith(reqPhoneClean) || reqPhoneClean.endsWith(stEmerClean)))
            ) {
              matchedFields.push('Student/Emergency Phone');
              score += 50;
            }
          }

          if (email && st.email && st.email.toLowerCase() === email) {
            matchedFields.push('Student Email');
            score += 40;
          }

          const stFullName = `${st.firstName || ''} ${st.lastName || ''}`.trim().toLowerCase();
          if (studentName && stFullName && (stFullName === studentName || stFullName.includes(studentName))) {
            matchedFields.push('Enrolled Student Name');
            score += 35;
          }

          if (matchedFields.length > 0) {
            matches.push({
              id: st.id,
              entityType: 'EXISTING_STUDENT',
              identifier: st.admissionNumber || st.id,
              name: `${st.firstName || ''} ${st.lastName || ''}`.trim(),
              phone: st.phone || '',
              email: st.email || '',
              status: st.status || 'Active',
              createdAt: st.createdAt || '',
              matchedFields,
              similarityScore: Math.min(100, score)
            });
          }
        }
      }

      // 3. Check existing applications
      if (database.admissionApplications) {
        for (const app of database.admissionApplications) {
          const matchedFields: string[] = [];
          let score = 0;

          if (reqPhoneClean && reqPhoneClean.length >= 7) {
            const appPhoneClean = cleanPhone(app.phone || '');
            const appGuardClean = cleanPhone(app.guardianPhone || '');
            if (
              (appPhoneClean && (appPhoneClean.endsWith(reqPhoneClean) || reqPhoneClean.endsWith(appPhoneClean))) ||
              (appGuardClean && (appGuardClean.endsWith(reqPhoneClean) || reqPhoneClean.endsWith(appGuardClean)))
            ) {
              matchedFields.push('Application Phone');
              score += 50;
            }
          }

          if (email && ((app.email && app.email.toLowerCase() === email) || (app.guardianEmail && app.guardianEmail.toLowerCase() === email))) {
            matchedFields.push('Application Email');
            score += 40;
          }

          if (studentName && app.fullName && app.fullName.toLowerCase() === studentName) {
            matchedFields.push('Applicant Name');
            score += 30;
          }

          if (matchedFields.length > 0) {
            matches.push({
              id: app.id,
              entityType: 'APPLICATION',
              identifier: app.applicationNumber,
              name: app.fullName,
              parentName: app.guardianName,
              phone: app.phone,
              email: app.email,
              status: app.status,
              createdAt: app.createdAt,
              matchedFields,
              similarityScore: Math.min(100, score)
            });
          }
        }
      }

      matches.sort((a, b) => b.similarityScore - a.similarityScore);

      const result: EnquiryDuplicateCheckResult = {
        hasDuplicates: matches.length > 0,
        matches,
        checkedPhone: phone,
        checkedEmail: email,
        checkedStudentName: studentName
      };

      res.json({ success: true, data: result });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * GET /api/front-office/enquiries/metrics/summary
 * Aggregate analytics & conversion metrics for admission enquiries
 */
frontOfficeRouter.get(
  '/enquiries/metrics/summary',
  requirePermission('front_office.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const todayStr = new Date().toISOString().split('T')[0];
      const enquiries = database.admissionEnquiries;

      const totalEnquiries = enquiries.length;
      const newEnquiries = enquiries.filter(e => e.status === 'NEW').length;
      const contactedEnquiries = enquiries.filter(e => e.status === 'CONTACTED').length;
      const followUpRequiredEnquiries = enquiries.filter(e => e.status === 'FOLLOW_UP_REQUIRED').length;
      const followUpInProgressEnquiries = enquiries.filter(e => e.status === 'FOLLOW_UP_IN_PROGRESS').length;
      const followUpTodayEnquiries = enquiries.filter(
        e => e.followUpDate === todayStr && e.status !== 'CONVERTED' && e.status !== 'CLOSED' && e.status !== 'LOST'
      ).length;
      const overdueFollowUps = enquiries.filter(
        e => e.followUpDate && e.followUpDate < todayStr && e.status !== 'CONVERTED' && e.status !== 'CLOSED' && e.status !== 'LOST'
      ).length;
      const interestedEnquiries = enquiries.filter(e => e.status === 'INTERESTED').length;
      const applicationStartedEnquiries = enquiries.filter(e => e.status === 'APPLICATION_STARTED').length;
      const convertedEnquiries = enquiries.filter(e => e.status === 'CONVERTED').length;
      const notInterestedEnquiries = enquiries.filter(e => e.status === 'NOT_INTERESTED').length;
      const lostEnquiries = enquiries.filter(e => e.status === 'LOST').length;
      const closedEnquiries = enquiries.filter(e => e.status === 'CLOSED').length;

      const conversionRate = totalEnquiries > 0 ? Math.round((convertedEnquiries / totalEnquiries) * 100) : 0;

      const sourceDistribution: Record<string, number> = {};
      const priorityDistribution: Record<string, number> = {};
      const classDistribution: Record<string, number> = {};

      enquiries.forEach(e => {
        const src = e.source || 'OTHER';
        sourceDistribution[src] = (sourceDistribution[src] || 0) + 1;

        const pri = e.priority || 'MEDIUM';
        priorityDistribution[pri] = (priorityDistribution[pri] || 0) + 1;

        const cls = e.applyingClassName || 'Unassigned';
        classDistribution[cls] = (classDistribution[cls] || 0) + 1;
      });

      const metrics: EnquiryMetricsSummary = {
        totalEnquiries,
        newEnquiries,
        contactedEnquiries,
        followUpRequiredEnquiries,
        followUpInProgressEnquiries,
        followUpTodayEnquiries,
        overdueFollowUps,
        interestedEnquiries,
        applicationStartedEnquiries,
        convertedEnquiries,
        notInterestedEnquiries,
        lostEnquiries,
        closedEnquiries,
        conversionRate,
        sourceDistribution,
        priorityDistribution,
        classDistribution
      };

      res.json({ success: true, data: metrics });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * GET /api/front-office/enquiries/export
 * Export filtered enquiries as CSV or structured JSON
 */
frontOfficeRouter.get(
  '/enquiries/export',
  requirePermission('front_office.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const { status, classId, priority, source, search, format = 'csv' } = req.query;

      let list = [...database.admissionEnquiries];

      if (status && status !== 'ALL') {
        list = list.filter(e => e.status === status);
      }
      if (priority && priority !== 'ALL') {
        list = list.filter(e => e.priority === priority);
      }
      if (classId && classId !== 'ALL') {
        list = list.filter(e => e.applyingClassId === classId);
      }
      if (source && source !== 'ALL') {
        list = list.filter(e => e.source === source);
      }
      if (search) {
        const q = String(search).toLowerCase().trim();
        list = list.filter(
          e =>
            e.studentName.toLowerCase().includes(q) ||
            e.parentName.toLowerCase().includes(q) ||
            e.enquiryNumber.toLowerCase().includes(q) ||
            e.phone.toLowerCase().includes(q) ||
            (e.email && e.email.toLowerCase().includes(q))
        );
      }

      list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'EXPORT',
        entity: 'AdmissionEnquiry',
        entityId: 'ALL',
        details: `Exported ${list.length} admission enquiries in ${String(format).toUpperCase()} format.`
      });

      if (format === 'json') {
        res.setHeader('Content-Type', 'application/json');
        res.setHeader('Content-Disposition', `attachment; filename="admission-enquiries-${new Date().toISOString().split('T')[0]}.json"`);
        res.send(JSON.stringify(list, null, 2));
        return;
      }

      // Default CSV format
      const headers = [
        'Enquiry Number',
        'Date',
        'Student Name',
        'Applying Class',
        'Parent Name',
        'Phone',
        'Alternate Phone',
        'Email',
        'Source',
        'Priority',
        'Status',
        'Assigned Staff',
        'Next Follow-Up Date',
        'Follow-Up Time',
        'Previous School',
        'Notes'
      ];

      const rows = list.map(e => [
        `"${e.enquiryNumber}"`,
        `"${e.enquiryDate || e.createdAt.split('T')[0]}"`,
        `"${e.studentName.replace(/"/g, '""')}"`,
        `"${e.applyingClassName || ''}"`,
        `"${e.parentName.replace(/"/g, '""')}"`,
        `"${e.phone}"`,
        `"${e.alternatePhone || ''}"`,
        `"${e.email || ''}"`,
        `"${e.source || ''}"`,
        `"${e.priority || 'MEDIUM'}"`,
        `"${e.status}"`,
        `"${e.assignedStaffName || ''}"`,
        `"${e.followUpDate || ''}"`,
        `"${e.followUpTime || ''}"`,
        `"${(e.previousSchool || '').replace(/"/g, '""')}"`,
        `"${(e.notes || '').replace(/"/g, '""')}"`
      ]);

      const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');

      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', `attachment; filename="admission-enquiries-${new Date().toISOString().split('T')[0]}.csv"`);
      res.send(csvContent);
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * GET /api/front-office/enquiries
 * Filtered enquiry listing with pagination, priority, and follow-up filters
 */
frontOfficeRouter.get(
  '/enquiries',
  requirePermission('front_office.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const {
        status,
        priority,
        followUpFilter,
        classId,
        sessionId,
        source,
        enquiryType,
        assignedStaffId,
        search,
        startDate,
        endDate,
        limit = 50,
        page = 1
      } = req.query;

      const todayStr = new Date().toISOString().split('T')[0];
      let list = [...database.admissionEnquiries];

      if (status && status !== 'ALL') {
        list = list.filter(e => e.status === status);
      }
      if (priority && priority !== 'ALL') {
        list = list.filter(e => e.priority === priority);
      }
      if (classId && classId !== 'ALL') {
        list = list.filter(e => e.applyingClassId === classId);
      }
      if (sessionId && sessionId !== 'ALL') {
        list = list.filter(e => e.academicSessionId === sessionId);
      }
      if (source && source !== 'ALL') {
        list = list.filter(e => e.source === source);
      }
      if (enquiryType && enquiryType !== 'ALL') {
        list = list.filter(e => e.enquiryType === enquiryType);
      }
      if (assignedStaffId && assignedStaffId !== 'ALL') {
        list = list.filter(e => e.assignedStaffId === assignedStaffId);
      }
      if (followUpFilter && followUpFilter !== 'ALL') {
        if (followUpFilter === 'TODAY') {
          list = list.filter(e => e.followUpDate === todayStr && e.status !== 'CONVERTED' && e.status !== 'CLOSED' && e.status !== 'LOST');
        } else if (followUpFilter === 'OVERDUE') {
          list = list.filter(e => e.followUpDate && e.followUpDate < todayStr && e.status !== 'CONVERTED' && e.status !== 'CLOSED' && e.status !== 'LOST');
        } else if (followUpFilter === 'UPCOMING') {
          list = list.filter(e => e.followUpDate && e.followUpDate > todayStr && e.status !== 'CONVERTED' && e.status !== 'CLOSED' && e.status !== 'LOST');
        } else if (followUpFilter === 'NONE') {
          list = list.filter(e => !e.followUpDate);
        }
      }
      if (startDate) {
        list = list.filter(e => (e.enquiryDate || e.createdAt.split('T')[0]) >= String(startDate));
      }
      if (endDate) {
        list = list.filter(e => (e.enquiryDate || e.createdAt.split('T')[0]) <= String(endDate));
      }
      if (search) {
        const q = String(search).toLowerCase().trim();
        list = list.filter(
          e =>
            e.studentName.toLowerCase().includes(q) ||
            e.parentName.toLowerCase().includes(q) ||
            e.enquiryNumber.toLowerCase().includes(q) ||
            e.phone.toLowerCase().includes(q) ||
            (e.email && e.email.toLowerCase().includes(q))
        );
      }

      list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

      const total = list.length;
      const startIndex = (Number(page) - 1) * Number(limit);
      const paginated = list.slice(startIndex, startIndex + Number(limit));

      // Attach follow-ups count or latest follow-up
      const enriched = paginated.map(enq => {
        const fols = database.enquiryFollowups.filter(f => f.enquiryId === enq.id);
        return {
          ...enq,
          followUpsCount: fols.length,
          latestFollowUp: fols.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())[0] || null
        };
      });

      res.json({
        success: true,
        data: enriched,
        pagination: {
          total,
          page: Number(page),
          limit: Number(limit),
          totalPages: Math.ceil(total / Number(limit))
        }
      });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * GET /api/front-office/enquiries/:id
 */
frontOfficeRouter.get(
  '/enquiries/:id',
  requirePermission('front_office.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const enquiry = database.admissionEnquiries.find(e => e.id === req.params.id);
      if (!enquiry) {
        res.status(404).json({ success: false, error: 'Admission enquiry not found.' });
        return;
      }

      const followUps = database.enquiryFollowups
        .filter(f => f.enquiryId === enquiry.id)
        .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

      res.json({
        success: true,
        data: {
          ...enquiry,
          followUps
        }
      });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * POST /api/front-office/enquiries
 * Create admission enquiry with lifecycle initialization, duplicate detection awareness & audit
 */
frontOfficeRouter.post(
  '/enquiries',
  requirePermission('front_office.manage_enquiries'),
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const {
        studentName,
        dateOfBirth,
        gender,
        applyingClassId,
        academicSessionId,
        parentName,
        relationship,
        phone,
        alternatePhone,
        email,
        address,
        previousSchool,
        source,
        enquiryType,
        priority,
        assignedStaffId,
        followUpDate,
        followUpTime,
        notes
      } = req.body;

      if (!studentName || !parentName || !phone || !applyingClassId) {
        res.status(400).json({
          success: false,
          error: 'Student Name, Parent Name, Phone, and Applying Class are mandatory.'
        });
        return;
      }

      const targetClass = database.classes.find(c => c.id === applyingClassId);
      const targetSession = academicSessionId
        ? database.academicSessions.find(s => s.id === academicSessionId)
        : database.academicSessions.find(s => s.status === 'active') || database.academicSessions[0];

      let assignedStaffName = '';
      if (assignedStaffId) {
        const staff = database.users.find(u => u.id === assignedStaffId);
        assignedStaffName = staff ? staff.name : '';
      }

      const todayStr = new Date().toISOString().split('T')[0];
      const nowIso = new Date().toISOString();
      const validPriority: EnquiryPriority = ['LOW', 'MEDIUM', 'HIGH', 'URGENT'].includes(priority) ? priority : 'MEDIUM';

      const newEnquiry: AdmissionEnquiry = {
        id: `enq-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        enquiryNumber: generateEnquiryNumber(),
        enquiryDate: todayStr,
        studentName: String(studentName).trim(),
        dateOfBirth: dateOfBirth || '',
        gender: gender || 'male',
        applyingClassId,
        applyingClassName: targetClass ? targetClass.name : 'Class',
        academicSessionId: targetSession ? targetSession.id : '',
        academicSessionName: targetSession ? targetSession.name : '',
        parentName: String(parentName).trim(),
        relationship: relationship || 'Parent',
        phone: String(phone).trim(),
        alternatePhone: alternatePhone ? String(alternatePhone).trim() : '',
        email: String(email || '').trim(),
        address: String(address || '').trim(),
        previousSchool: previousSchool ? String(previousSchool).trim() : '',
        source: source || 'WALK_IN',
        enquiryType: enquiryType || 'Admission',
        priority: validPriority,
        assignedStaffId: assignedStaffId || req.user!.id,
        assignedStaffName: assignedStaffName || req.user!.name,
        status: 'NEW',
        followUpDate: followUpDate || '',
        followUpTime: followUpTime || '10:00',
        followUpStatus: followUpDate ? 'Scheduled' : 'None',
        notes: notes || '',
        assignmentHistory: assignedStaffId ? [
          {
            id: `asgh-${Date.now()}`,
            toStaffId: assignedStaffId,
            toStaffName: assignedStaffName,
            assignedById: req.user!.id,
            assignedByName: req.user!.name,
            assignedAt: nowIso,
            notes: 'Initial assignment upon enquiry creation'
          }
        ] : [],
        statusHistory: [
          {
            fromStatus: 'NONE',
            toStatus: 'NEW',
            changedById: req.user!.id,
            changedByName: req.user!.name,
            changedAt: nowIso,
            remarks: 'Enquiry record created and intake logged'
          }
        ],
        createdById: req.user!.id,
        createdByName: req.user!.name,
        createdAt: nowIso,
        updatedAt: nowIso
      };

      database.admissionEnquiries.push(newEnquiry);

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'CREATE',
        entity: 'AdmissionEnquiry',
        entityId: newEnquiry.id,
        details: `Logged front office admission enquiry ${newEnquiry.enquiryNumber} for student ${newEnquiry.studentName} (Priority: ${newEnquiry.priority}).`
      });

      // Staff assignment notification
      if (newEnquiry.assignedStaffId && newEnquiry.assignedStaffId !== req.user!.id) {
        try {
          await CommunicationService.dispatch({
            eventType: 'SYSTEM_ALERT',
            entityId: newEnquiry.id,
            entityType: 'AdmissionEnquiry',
            userId: newEnquiry.assignedStaffId,
            customTitle: `New Admission Enquiry Assigned: ${newEnquiry.enquiryNumber}`,
            customMessage: `You have been assigned to handle enquiry ${newEnquiry.enquiryNumber} for prospective student ${newEnquiry.studentName} (Parent: ${newEnquiry.parentName}, Phone: ${newEnquiry.phone}). Priority: ${newEnquiry.priority}.`,
            actorUser: { id: req.user!.id, name: req.user!.name, role: req.user!.role }
          });
        } catch (notifErr) {
          console.warn('[Notification Notice]:', notifErr);
        }
      }

      res.status(201).json({ success: true, data: newEnquiry });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * PUT /api/front-office/enquiries/:id
 */
frontOfficeRouter.put(
  '/enquiries/:id',
  requirePermission('front_office.manage_enquiries'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const enquiry = database.admissionEnquiries.find(e => e.id === req.params.id);
      if (!enquiry) {
        res.status(404).json({ success: false, error: 'Admission enquiry not found.' });
        return;
      }

      const updates = req.body;
      const nowIso = new Date().toISOString();

      if (updates.studentName) enquiry.studentName = String(updates.studentName).trim();
      if (updates.parentName) enquiry.parentName = String(updates.parentName).trim();
      if (updates.phone) enquiry.phone = String(updates.phone).trim();
      if (updates.alternatePhone !== undefined) enquiry.alternatePhone = String(updates.alternatePhone).trim();
      if (updates.previousSchool !== undefined) enquiry.previousSchool = String(updates.previousSchool).trim();
      if (updates.email !== undefined) enquiry.email = String(updates.email).trim();
      if (updates.address !== undefined) enquiry.address = String(updates.address).trim();
      if (updates.source) enquiry.source = updates.source;
      if (updates.enquiryType) enquiry.enquiryType = updates.enquiryType;
      if (updates.priority && ['LOW', 'MEDIUM', 'HIGH', 'URGENT'].includes(updates.priority)) {
        enquiry.priority = updates.priority;
      }
      if (updates.followUpDate !== undefined) enquiry.followUpDate = updates.followUpDate;
      if (updates.followUpTime !== undefined) enquiry.followUpTime = updates.followUpTime;
      if (updates.followUpStatus !== undefined) enquiry.followUpStatus = updates.followUpStatus;
      if (updates.notes !== undefined) enquiry.notes = updates.notes;
      if (updates.dateOfBirth !== undefined) enquiry.dateOfBirth = updates.dateOfBirth;
      if (updates.gender !== undefined) enquiry.gender = updates.gender;
      if (updates.relationship !== undefined) enquiry.relationship = updates.relationship;

      // Status change tracking
      if (updates.status && updates.status !== enquiry.status) {
        const oldStatus = enquiry.status;
        enquiry.status = updates.status;
        if (!enquiry.statusHistory) enquiry.statusHistory = [];
        enquiry.statusHistory.push({
          fromStatus: oldStatus,
          toStatus: updates.status,
          changedById: req.user!.id,
          changedByName: req.user!.name,
          changedAt: nowIso,
          remarks: updates.statusRemarks || `Status updated to ${updates.status}`
        });
      }

      // Staff reassignment tracking
      if (updates.assignedStaffId && updates.assignedStaffId !== enquiry.assignedStaffId) {
        const staff = database.users.find(u => u.id === updates.assignedStaffId);
        if (staff) {
          const oldStaffId = enquiry.assignedStaffId;
          const oldStaffName = enquiry.assignedStaffName;
          enquiry.assignedStaffId = staff.id;
          enquiry.assignedStaffName = staff.name;
          if (!enquiry.assignmentHistory) enquiry.assignmentHistory = [];
          enquiry.assignmentHistory.push({
            id: `asgh-${Date.now()}`,
            fromStaffId: oldStaffId,
            fromStaffName: oldStaffName,
            toStaffId: staff.id,
            toStaffName: staff.name,
            assignedById: req.user!.id,
            assignedByName: req.user!.name,
            assignedAt: nowIso,
            notes: updates.assignmentNotes || 'Reassigned via edit enquiry'
          });
        }
      }

      if (updates.applyingClassId) {
        const cls = database.classes.find(c => c.id === updates.applyingClassId);
        if (cls) {
          enquiry.applyingClassId = cls.id;
          enquiry.applyingClassName = cls.name;
        }
      }

      enquiry.updatedAt = nowIso;

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'UPDATE',
        entity: 'AdmissionEnquiry',
        entityId: enquiry.id,
        details: `Updated enquiry ${enquiry.enquiryNumber} (status: ${enquiry.status}, priority: ${enquiry.priority}).`
      });

      res.json({ success: true, data: enquiry });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * POST /api/front-office/enquiries/:id/status
 * Explicit status transition with remarks and audit history
 */
frontOfficeRouter.post(
  '/enquiries/:id/status',
  requirePermission('front_office.manage_enquiries'),
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const enquiry = database.admissionEnquiries.find(e => e.id === req.params.id);
      if (!enquiry) {
        res.status(404).json({ success: false, error: 'Admission enquiry not found.' });
        return;
      }

      const { status, remarks } = req.body;
      if (!status) {
        res.status(400).json({ success: false, error: 'Status is required.' });
        return;
      }

      const oldStatus = enquiry.status;
      enquiry.status = status;
      const nowIso = new Date().toISOString();

      if (!enquiry.statusHistory) enquiry.statusHistory = [];
      enquiry.statusHistory.push({
        fromStatus: oldStatus,
        toStatus: status,
        changedById: req.user!.id,
        changedByName: req.user!.name,
        changedAt: nowIso,
        remarks: remarks || `Status changed from ${oldStatus} to ${status}`
      });

      enquiry.updatedAt = nowIso;

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'UPDATE',
        entity: 'AdmissionEnquiry',
        entityId: enquiry.id,
        details: `Changed status of enquiry ${enquiry.enquiryNumber} from ${oldStatus} to ${status}. Remarks: ${remarks || 'None'}.`
      });

      res.json({ success: true, data: enquiry });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * POST /api/front-office/enquiries/:id/priority
 * Update enquiry priority
 */
frontOfficeRouter.post(
  '/enquiries/:id/priority',
  requirePermission('front_office.manage_enquiries'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const enquiry = database.admissionEnquiries.find(e => e.id === req.params.id);
      if (!enquiry) {
        res.status(404).json({ success: false, error: 'Admission enquiry not found.' });
        return;
      }

      const { priority } = req.body;
      if (!['LOW', 'MEDIUM', 'HIGH', 'URGENT'].includes(priority)) {
        res.status(400).json({ success: false, error: 'Invalid priority level.' });
        return;
      }

      const oldPriority = enquiry.priority || 'MEDIUM';
      enquiry.priority = priority;
      enquiry.updatedAt = new Date().toISOString();

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'UPDATE',
        entity: 'AdmissionEnquiry',
        entityId: enquiry.id,
        details: `Updated priority of enquiry ${enquiry.enquiryNumber} from ${oldPriority} to ${priority}.`
      });

      res.json({ success: true, data: enquiry });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * POST /api/front-office/enquiries/:id/assign
 * Assign or reassign enquiry to staff member
 */
frontOfficeRouter.post(
  '/enquiries/:id/assign',
  requirePermission('front_office.manage_enquiries'),
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const enquiry = database.admissionEnquiries.find(e => e.id === req.params.id);
      if (!enquiry) {
        res.status(404).json({ success: false, error: 'Admission enquiry not found.' });
        return;
      }

      const { assignedStaffId, notes } = req.body;
      if (!assignedStaffId) {
        res.status(400).json({ success: false, error: 'Assigned staff ID is required.' });
        return;
      }

      const targetStaff = database.users.find(u => u.id === assignedStaffId);
      if (!targetStaff) {
        res.status(404).json({ success: false, error: 'Designated staff user not found.' });
        return;
      }

      const oldStaffId = enquiry.assignedStaffId;
      const oldStaffName = enquiry.assignedStaffName;
      const nowIso = new Date().toISOString();

      enquiry.assignedStaffId = targetStaff.id;
      enquiry.assignedStaffName = targetStaff.name;
      enquiry.assignmentDate = nowIso;
      enquiry.assignedById = req.user!.id;
      enquiry.assignedByName = req.user!.name;

      if (!enquiry.assignmentHistory) enquiry.assignmentHistory = [];
      enquiry.assignmentHistory.push({
        id: `asgh-${Date.now()}`,
        fromStaffId: oldStaffId,
        fromStaffName: oldStaffName,
        toStaffId: targetStaff.id,
        toStaffName: targetStaff.name,
        assignedById: req.user!.id,
        assignedByName: req.user!.name,
        assignedAt: nowIso,
        notes: notes || 'Assigned via front office assignment tool'
      });

      enquiry.updatedAt = nowIso;

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'UPDATE',
        entity: 'AdmissionEnquiry',
        entityId: enquiry.id,
        details: `Assigned enquiry ${enquiry.enquiryNumber} to staff ${targetStaff.name}. Notes: ${notes || 'None'}.`
      });

      // Dispatch alert to new assigned staff
      try {
        await CommunicationService.dispatch({
          eventType: 'SYSTEM_ALERT',
          entityId: enquiry.id,
          entityType: 'AdmissionEnquiry',
          userId: targetStaff.id,
          customTitle: `Admission Enquiry Assigned: ${enquiry.enquiryNumber}`,
          customMessage: `You have been assigned to handle enquiry ${enquiry.enquiryNumber} for student ${enquiry.studentName} (Class: ${enquiry.applyingClassName}, Priority: ${enquiry.priority || 'MEDIUM'}).`,
          actorUser: { id: req.user!.id, name: req.user!.name, role: req.user!.role }
        });
      } catch (notifErr) {
        console.warn('[Notification Notice]:', notifErr);
      }

      res.json({ success: true, data: enquiry });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * POST /api/front-office/enquiries/:id/send-reminder
 * Send follow-up reminder notification to assigned staff
 */
frontOfficeRouter.post(
  '/enquiries/:id/send-reminder',
  requirePermission('front_office.manage_followups'),
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const enquiry = database.admissionEnquiries.find(e => e.id === req.params.id);
      if (!enquiry) {
        res.status(404).json({ success: false, error: 'Admission enquiry not found.' });
        return;
      }

      const recipientId = enquiry.assignedStaffId || req.user!.id;

      await CommunicationService.dispatch({
        eventType: 'SYSTEM_ALERT',
        entityId: enquiry.id,
        entityType: 'AdmissionEnquiry',
        userId: recipientId,
        customTitle: `Admission Follow-Up Reminder: ${enquiry.enquiryNumber}`,
        customMessage: `Follow-up reminder for prospective student ${enquiry.studentName} (Parent: ${enquiry.parentName}, Phone: ${enquiry.phone}). Next follow-up is scheduled for ${enquiry.followUpDate || 'Today'} at ${enquiry.followUpTime || '10:00'}.`,
        actorUser: { id: req.user!.id, name: req.user!.name, role: req.user!.role }
      });

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'UPDATE',
        entity: 'AdmissionEnquiry',
        entityId: enquiry.id,
        details: `Sent follow-up reminder for enquiry ${enquiry.enquiryNumber} to staff ID ${recipientId}.`
      });

      res.json({ success: true, message: 'Follow-up reminder notification dispatched successfully.' });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * DELETE /api/front-office/enquiries/:id
 */
frontOfficeRouter.delete(
  '/enquiries/:id',
  requirePermission('front_office.delete'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const idx = database.admissionEnquiries.findIndex(e => e.id === req.params.id);
      if (idx === -1) {
        res.status(404).json({ success: false, error: 'Admission enquiry not found.' });
        return;
      }

      const [removed] = database.admissionEnquiries.splice(idx, 1);

      // Clean up linked follow-ups
      database.enquiryFollowups = database.enquiryFollowups.filter(f => f.enquiryId !== removed.id);

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'DELETE',
        entity: 'AdmissionEnquiry',
        entityId: removed.id,
        details: `Deleted admission enquiry ${removed.enquiryNumber}.`
      });

      res.json({ success: true, message: 'Enquiry deleted successfully.' });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * POST /api/front-office/enquiries/:id/follow-ups
 * Add structured follow-up record to enquiry with contact method & status history synchronization
 */
frontOfficeRouter.post(
  '/enquiries/:id/follow-ups',
  requirePermission('front_office.manage_followups'),
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const enquiry = database.admissionEnquiries.find(e => e.id === req.params.id);
      if (!enquiry) {
        res.status(404).json({ success: false, error: 'Enquiry not found.' });
        return;
      }

      const { followUpDate, followUpTime, contactOutcome, contactMethod, notes, nextStatus, sendReminder } = req.body;

      if (!contactOutcome) {
        res.status(400).json({ success: false, error: 'Contact outcome is required.' });
        return;
      }

      const nowIso = new Date().toISOString();
      const validContactMethod = ['Phone', 'Email', 'In Person', 'Website', 'Other'].includes(contactMethod) ? contactMethod : 'Phone';

      const newFollowUp: EnquiryFollowUp = {
        id: `enq-fol-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        enquiryId: enquiry.id,
        enquiryNumber: enquiry.enquiryNumber,
        followUpDate: followUpDate || new Date().toISOString().split('T')[0],
        followUpTime: followUpTime || '10:00',
        contactMethod: validContactMethod,
        contactOutcome: String(contactOutcome).trim(),
        notes: String(notes || '').trim(),
        status: nextStatus || enquiry.status,
        assignedStaffId: req.user!.id,
        assignedStaffName: req.user!.name,
        reminderSent: Boolean(sendReminder),
        createdAt: nowIso,
        createdById: req.user!.id,
        createdByName: req.user!.name
      };

      database.enquiryFollowups.push(newFollowUp);

      // Update enquiry state & status history
      const oldStatus = enquiry.status;
      if (nextStatus && nextStatus !== oldStatus) {
        enquiry.status = nextStatus;
        if (!enquiry.statusHistory) enquiry.statusHistory = [];
        enquiry.statusHistory.push({
          fromStatus: oldStatus,
          toStatus: nextStatus,
          changedById: req.user!.id,
          changedByName: req.user!.name,
          changedAt: nowIso,
          remarks: `Status updated via follow-up record (${validContactMethod} - ${contactOutcome})`
        });
      }

      if (followUpDate) {
        enquiry.followUpDate = followUpDate;
        enquiry.followUpTime = followUpTime || enquiry.followUpTime || '10:00';
        enquiry.followUpStatus = 'Scheduled';
      }
      enquiry.updatedAt = nowIso;

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'CREATE',
        entity: 'EnquiryFollowUp',
        entityId: newFollowUp.id,
        details: `Recorded follow-up for enquiry ${enquiry.enquiryNumber} via ${validContactMethod} (Outcome: ${newFollowUp.contactOutcome}).`
      });

      // Notification reminder if requested
      if (sendReminder && enquiry.assignedStaffId) {
        try {
          await CommunicationService.dispatch({
            eventType: 'SYSTEM_ALERT',
            entityId: enquiry.id,
            entityType: 'AdmissionEnquiry',
            userId: enquiry.assignedStaffId,
            customTitle: `Follow-up Recorded: ${enquiry.enquiryNumber}`,
            customMessage: `Follow-up logged for ${enquiry.studentName}. Method: ${validContactMethod}. Outcome: ${newFollowUp.contactOutcome}. Next follow-up: ${enquiry.followUpDate || 'None'}.`,
            actorUser: { id: req.user!.id, name: req.user!.name, role: req.user!.role }
          });
        } catch (notifErr) {
          console.warn('[Notification Error]:', notifErr);
        }
      }

      res.status(201).json({ success: true, data: newFollowUp, enquiry });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * GET /api/front-office/enquiries/:id/follow-ups
 */
frontOfficeRouter.get(
  '/enquiries/:id/follow-ups',
  requirePermission('front_office.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const followUps = database.enquiryFollowups
        .filter(f => f.enquiryId === req.params.id)
        .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

      res.json({ success: true, data: followUps });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * POST /api/front-office/enquiries/:id/convert
 * Convert enquiry to pre-filled Admission Application with full trace and status history
 */
frontOfficeRouter.post(
  '/enquiries/:id/convert',
  requirePermission('front_office.manage_enquiries'),
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const enquiry = database.admissionEnquiries.find(e => e.id === req.params.id);
      if (!enquiry) {
        res.status(404).json({ success: false, error: 'Admission enquiry not found.' });
        return;
      }

      if (enquiry.status === 'CONVERTED' || enquiry.convertedAdmissionId) {
        res.status(400).json({
          success: false,
          error: 'This enquiry has already been converted into an admission application.'
        });
        return;
      }

      const targetClass = database.classes.find(c => c.id === enquiry.applyingClassId) || database.classes[0];
      const targetSection = database.sections.find(s => s.classId === targetClass.id) || database.sections[0];
      const targetSession = enquiry.academicSessionId
        ? database.academicSessions.find(s => s.id === enquiry.academicSessionId)
        : database.academicSessions.find(s => s.status === 'active') || database.academicSessions[0];

      const nameParts = enquiry.studentName.trim().split(' ');
      const firstName = nameParts[0] || 'Applicant';
      const lastName = nameParts.length > 1 ? nameParts.slice(1).join(' ') : 'Student';
      const nowIso = new Date().toISOString();

      const newApplication: AdmissionApplication = {
        id: `adm-app-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        applicationNumber: generateApplicationNumber(),
        enquiryId: enquiry.id,
        enquiryNumber: enquiry.enquiryNumber,
        firstName,
        lastName,
        fullName: enquiry.studentName,
        dateOfBirth: enquiry.dateOfBirth || '',
        gender: enquiry.gender || 'male',
        nationality: 'United States',
        email: enquiry.email || '',
        phone: enquiry.phone || '',
        address: enquiry.address || '',
        guardianMode: 'new',
        guardianName: enquiry.parentName,
        guardianRelation: enquiry.relationship || 'Parent',
        guardianPhone: enquiry.phone,
        guardianEmail: enquiry.email || '',
        guardianAddress: enquiry.address || '',
        emergencyContact: enquiry.phone,
        academicSessionId: targetSession.id,
        academicSessionName: targetSession.name,
        classId: targetClass.id,
        className: targetClass.name,
        sectionId: targetSection ? targetSection.id : '',
        sectionName: targetSection ? targetSection.name : '',
        applicationDate: new Date().toISOString().split('T')[0],
        admissionDate: new Date().toISOString().split('T')[0],
        assignAdmissionFee: true,
        documents: [],
        status: 'DRAFT',
        statusHistory: [
          {
            fromStatus: 'ENQUIRY',
            toStatus: 'DRAFT',
            changedBy: req.user!.name,
            changedAt: nowIso,
            reason: `Converted from front office enquiry ${enquiry.enquiryNumber}`
          }
        ],
        createdAt: nowIso,
        updatedAt: nowIso
      };

      database.admissionApplications.push(newApplication);

      // Update enquiry status & history
      const oldStatus = enquiry.status;
      enquiry.status = 'CONVERTED';
      enquiry.convertedAdmissionId = newApplication.id;
      enquiry.convertedApplicationNumber = newApplication.applicationNumber;
      enquiry.conversionDate = nowIso;
      enquiry.convertedBy = req.user!.name;
      enquiry.convertedById = req.user!.id;
      enquiry.updatedAt = nowIso;

      if (!enquiry.statusHistory) enquiry.statusHistory = [];
      enquiry.statusHistory.push({
        fromStatus: oldStatus,
        toStatus: 'CONVERTED',
        changedById: req.user!.id,
        changedByName: req.user!.name,
        changedAt: nowIso,
        remarks: `Converted into admission application ${newApplication.applicationNumber}`
      });

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'CONVERT',
        entity: 'AdmissionEnquiry',
        entityId: enquiry.id,
        details: `Converted enquiry ${enquiry.enquiryNumber} to admission application ${newApplication.applicationNumber}.`
      });

      // Dispatch alert
      try {
        await CommunicationService.dispatch({
          eventType: 'SYSTEM_ALERT',
          entityId: newApplication.id,
          entityType: 'AdmissionApplication',
          userId: req.user!.id,
          customTitle: `Enquiry Converted: ${enquiry.enquiryNumber}`,
          customMessage: `Admission enquiry ${enquiry.enquiryNumber} (${enquiry.studentName}) has been converted to admission application ${newApplication.applicationNumber}.`,
          actorUser: { id: req.user!.id, name: req.user!.name, role: req.user!.role }
        });
      } catch (notifErr) {
        console.warn('[Notification Error]:', notifErr);
      }

      res.status(201).json({
        success: true,
        data: {
          enquiry,
          application: newApplication
        }
      });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

// =========================================================================
// 3. VISITOR MANAGEMENT & VISITOR PASS
// =========================================================================

/**
 * GET /api/front-office/visitors/today
 * "Today's Front Desk View" categorized summary
 */
frontOfficeRouter.get(
  '/visitors/today',
  requirePermission('front_office.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const todayStr = new Date().toISOString().split('T')[0];

      // Categories:
      // 1. Expected: scheduled, confirmed, or pending for today that haven't checked in yet
      const expected = database.visitors.filter(
        v => v.appointmentDate === todayStr && ['SCHEDULED', 'CONFIRMED', 'PENDING'].includes(v.status)
      );

      // 2. Checked In Today: all who checked in today
      const checkedInToday = database.visitors.filter(
        v => (v.checkInTime && v.checkInTime.startsWith(todayStr)) || (v.status === 'CHECKED_IN' && v.appointmentDate === todayStr)
      );

      // 3. Currently Inside: active visitors right now
      const currentlyInside = database.visitors.filter(v => v.status === 'CHECKED_IN');

      // 4. Checked Out Today: completed visits today
      const checkedOutToday = database.visitors.filter(
        v => v.status === 'CHECKED_OUT' && v.checkOutTime && v.checkOutTime.startsWith(todayStr)
      );

      // 5. Cancelled or No-Show for today
      const cancelledOrNoShow = database.visitors.filter(
        v => ['CANCELLED', 'NO_SHOW', 'REJECTED'].includes(v.status) && v.appointmentDate === todayStr
      );

      // Calculate average stay duration
      let totalDurationMinutes = 0;
      let durationCount = 0;
      checkedOutToday.forEach(v => {
        if (v.durationMinutes) {
          totalDurationMinutes += v.durationMinutes;
          durationCount++;
        } else if (v.checkInTime && v.checkOutTime) {
          const diff = Math.round(
            (new Date(v.checkOutTime).getTime() - new Date(v.checkInTime).getTime()) / 60000
          );
          if (diff > 0) {
            totalDurationMinutes += diff;
            durationCount++;
          }
        }
      });
      const averageStayDurationMinutes = durationCount > 0 ? Math.round(totalDurationMinutes / durationCount) : 0;

      res.json({
        success: true,
        data: {
          date: todayStr,
          summary: {
            expectedCount: expected.length,
            checkedInCount: checkedInToday.length,
            currentlyInsideCount: currentlyInside.length,
            checkedOutCount: checkedOutToday.length,
            cancelledOrNoShowCount: cancelledOrNoShow.length,
            totalTraffic: checkedInToday.length + expected.length,
            averageStayDurationMinutes
          },
          expected,
          checkedInToday,
          currentlyInside,
          checkedOutToday,
          cancelledOrNoShow
        }
      });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * GET /api/front-office/visitors/reports/advanced
 * Advanced Front Office Visitor Analytics & Register
 */
frontOfficeRouter.get(
  '/visitors/reports/advanced',
  requirePermission('front_office.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const { date, startDate, endDate, department, visitorType, status } = req.query;

      let list = [...database.visitors];

      if (date) {
        list = list.filter(v => v.appointmentDate === String(date));
      } else {
        if (startDate) {
          list = list.filter(v => v.appointmentDate >= String(startDate));
        }
        if (endDate) {
          list = list.filter(v => v.appointmentDate <= String(endDate));
        }
      }

      if (department && department !== 'ALL') {
        list = list.filter(v => v.department === department);
      }
      if (visitorType && visitorType !== 'ALL') {
        list = list.filter(v => v.visitorType === visitorType);
      }
      if (status && status !== 'ALL') {
        list = list.filter(v => v.status === status);
      }

      const departmentCounts: Record<string, number> = {};
      const typeCounts: Record<string, number> = {};
      const statusCounts: Record<string, number> = {};
      const hourlyDistribution: Record<string, number> = {};

      let totalDuration = 0;
      let completedVisits = 0;

      list.forEach(v => {
        departmentCounts[v.department] = (departmentCounts[v.department] || 0) + 1;
        typeCounts[v.visitorType] = (typeCounts[v.visitorType] || 0) + 1;
        statusCounts[v.status] = (statusCounts[v.status] || 0) + 1;

        if (v.checkInTime) {
          const hour = new Date(v.checkInTime).getHours();
          const hourKey = `${String(hour).padStart(2, '0')}:00`;
          hourlyDistribution[hourKey] = (hourlyDistribution[hourKey] || 0) + 1;
        }

        if (v.durationMinutes) {
          totalDuration += v.durationMinutes;
          completedVisits++;
        }
      });

      const avgDuration = completedVisits > 0 ? Math.round(totalDuration / completedVisits) : 0;

      const now = Date.now();
      const overstayVisitors = database.visitors
        .filter(v => v.status === 'CHECKED_IN')
        .map(v => {
          const inMs = v.checkInTime ? new Date(v.checkInTime).getTime() : now;
          const currentDurationMins = Math.round((now - inMs) / 60000);
          return {
            ...v,
            currentDurationMins,
            isOverstay: currentDurationMins > 90
          };
        })
        .filter(v => v.isOverstay);

      res.json({
        success: true,
        data: {
          totalVisitors: list.length,
          averageDurationMinutes: avgDuration,
          overstayCount: overstayVisitors.length,
          overstayVisitors,
          departmentBreakdown: departmentCounts,
          visitorTypeBreakdown: typeCounts,
          statusBreakdown: statusCounts,
          hourlyDistribution,
          records: list
        }
      });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * POST /api/front-office/visitors/verify-pass
 * Secure QR code or visitor pass number lookup and verification
 */
frontOfficeRouter.post(
  '/visitors/verify-pass',
  requirePermission('front_office.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const { token } = req.body;
      if (!token || typeof token !== 'string') {
        res.status(400).json({ success: false, error: 'Pass token or number is required.' });
        return;
      }

      const q = token.trim().toUpperCase();
      const visitor = database.visitors.find(
        v =>
          v.visitorPassNumber.toUpperCase() === q ||
          (v.bookingId && v.bookingId.toUpperCase() === q) ||
          (v.qrCodeToken && v.qrCodeToken.toUpperCase() === q)
      );

      if (!visitor) {
        res.status(404).json({
          success: false,
          data: {
            valid: false,
            message: 'No matching visitor record found for this badge / code.'
          }
        });
        return;
      }

      const todayStr = new Date().toISOString().split('T')[0];
      const isExpired =
        visitor.appointmentDate < todayStr ||
        visitor.status === 'CHECKED_OUT' ||
        visitor.status === 'CANCELLED' ||
        visitor.status === 'REJECTED';

      res.json({
        success: true,
        data: {
          valid: !isExpired,
          passNumber: visitor.visitorPassNumber,
          bookingId: visitor.bookingId,
          visitorName: visitor.visitorName,
          status: visitor.status,
          organization: visitor.organization,
          personToMeet: visitor.personToMeet,
          department: visitor.department,
          checkInTime: visitor.checkInTime,
          checkOutTime: visitor.checkOutTime,
          appointmentDate: visitor.appointmentDate,
          appointmentTime: visitor.appointmentTime,
          isExpired,
          message: isExpired
            ? `Pass expired or visit completed (Status: ${visitor.status})`
            : `Valid pass for ${visitor.visitorName} (Status: ${visitor.status})`
        }
      });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * GET /api/front-office/visitors
 * Filtered visitor listing with pagination
 */
frontOfficeRouter.get(
  '/visitors',
  requirePermission('front_office.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const {
        status,
        date,
        dateRange,
        visitorType,
        entryType,
        department,
        personToMeet,
        search,
        limit = 50,
        page = 1
      } = req.query;

      let list = [...database.visitors];
      const todayStr = new Date().toISOString().split('T')[0];

      if (status && status !== 'ALL') {
        list = list.filter(v => v.status === status);
      }
      if (visitorType && visitorType !== 'ALL') {
        list = list.filter(v => v.visitorType === visitorType);
      }
      if (entryType && entryType !== 'ALL') {
        list = list.filter(v => v.entryType === entryType);
      }
      if (department && department !== 'ALL') {
        list = list.filter(v => v.department === department);
      }
      if (personToMeet) {
        list = list.filter(v => v.personToMeet.toLowerCase().includes(String(personToMeet).toLowerCase()));
      }
      if (date) {
        list = list.filter(v => v.appointmentDate === String(date));
      } else if (dateRange) {
        if (dateRange === 'TODAY') {
          list = list.filter(v => v.appointmentDate === todayStr || v.status === 'CHECKED_IN');
        } else if (dateRange === 'THIS_WEEK') {
          const now = new Date();
          const firstDay = new Date(now.setDate(now.getDate() - now.getDay())).toISOString().split('T')[0];
          list = list.filter(v => v.appointmentDate >= firstDay);
        }
      }

      if (search) {
        const q = String(search).toLowerCase().trim();
        list = list.filter(
          v =>
            v.visitorName.toLowerCase().includes(q) ||
            v.visitorPassNumber.toLowerCase().includes(q) ||
            (v.bookingId && v.bookingId.toLowerCase().includes(q)) ||
            v.phone.toLowerCase().includes(q) ||
            (v.organization && v.organization.toLowerCase().includes(q)) ||
            v.purpose.toLowerCase().includes(q) ||
            v.personToMeet.toLowerCase().includes(q)
        );
      }

      list.sort((a, b) => {
        // Priority to checked in visitors, then by appointment date & time
        if (a.status === 'CHECKED_IN' && b.status !== 'CHECKED_IN') return -1;
        if (b.status === 'CHECKED_IN' && a.status !== 'CHECKED_IN') return 1;
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      });

      const total = list.length;
      const startIndex = (Number(page) - 1) * Number(limit);
      const paginated = list.slice(startIndex, startIndex + Number(limit));

      res.json({
        success: true,
        data: paginated,
        pagination: {
          total,
          page: Number(page),
          limit: Number(limit),
          totalPages: Math.ceil(total / Number(limit))
        }
      });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * GET /api/front-office/visitors/history
 * Retrieve past visitor records with filtering
 */
frontOfficeRouter.get(
  '/visitors/history',
  requirePermission('front_office.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const { phone, search, visitorType, status, startDate, endDate, limit = 50, page = 1 } = req.query;

      let list = database.visitors.filter(
        v => v.status === 'CHECKED_OUT' || v.status === 'CANCELLED' || v.status === 'NO_SHOW'
      );

      if (phone) {
        const rawPhone = String(phone).replace(/\D/g, '');
        list = list.filter(v => v.phone.replace(/\D/g, '').includes(rawPhone));
      }

      if (visitorType && visitorType !== 'ALL') {
        list = list.filter(v => v.visitorType === visitorType);
      }

      if (status && status !== 'ALL') {
        list = list.filter(v => v.status === status);
      }

      if (startDate) {
        list = list.filter(v => v.appointmentDate >= String(startDate));
      }

      if (endDate) {
        list = list.filter(v => v.appointmentDate <= String(endDate));
      }

      if (search) {
        const q = String(search).toLowerCase().trim();
        list = list.filter(
          v =>
            v.visitorName.toLowerCase().includes(q) ||
            v.visitorPassNumber.toLowerCase().includes(q) ||
            (v.bookingId && v.bookingId.toLowerCase().includes(q)) ||
            (v.organization && v.organization.toLowerCase().includes(q)) ||
            v.personToMeet.toLowerCase().includes(q)
        );
      }

      list.sort((a, b) => new Date(b.appointmentDate).getTime() - new Date(a.appointmentDate).getTime());

      const total = list.length;
      const startIndex = (Number(page) - 1) * Number(limit);
      const paginated = list.slice(startIndex, startIndex + Number(limit));

      res.json({
        success: true,
        data: paginated,
        pagination: {
          total,
          page: Number(page),
          limit: Number(limit),
          totalPages: Math.ceil(total / Number(limit))
        }
      });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * GET /api/front-office/visitors/history/phone/:phone
 * Retrieve past visits by contact phone (preserved for backward compatibility)
 */
frontOfficeRouter.get(
  '/visitors/history/phone/:phone',
  requirePermission('front_office.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const rawPhone = String(req.params.phone).replace(/\D/g, '');
      const history = database.visitors.filter(v => v.phone.replace(/\D/g, '').includes(rawPhone));
      res.json({ success: true, data: history });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * GET /api/front-office/visitors/:id
 */
frontOfficeRouter.get(
  '/visitors/:id',
  requirePermission('front_office.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const visitor = database.visitors.find(v => v.id === req.params.id);
      if (!visitor) {
        res.status(404).json({ success: false, error: 'Visitor record not found.' });
        return;
      }
      res.json({ success: true, data: visitor });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * POST /api/front-office/visitors
 * Enhanced visitor booking / walk-in registration
 */
frontOfficeRouter.post(
  '/visitors',
  requirePermission('front_office.manage_visitors'),
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const {
        visitorName,
        phone,
        email,
        organization,
        visitorType,
        entryType,
        purpose,
        personToMeet,
        personToMeetId,
        personToMeetRole,
        department,
        departmentId,
        appointmentDate,
        appointmentTime,
        expectedDuration,
        expectedDurationMinutes,
        numberOfVisitors,
        vehicleNumber,
        vehicleType,
        idCardType,
        idCardNumber,
        idProofType,
        idProofNumber,
        notes,
        attachmentUrl,
        attachmentName,
        autoCheckIn
      } = req.body;

      if (!visitorName || !phone || !purpose || !personToMeet) {
        res.status(400).json({
          success: false,
          error: 'Visitor Name, Phone Number, Purpose, and Person to Meet are mandatory.'
        });
        return;
      }

      const todayStr = new Date().toISOString().split('T')[0];
      const decidedEntryType = entryType || (autoCheckIn ? 'WALK_IN' : 'SCHEDULED');
      const initialStatus: VisitorStatus = autoCheckIn ? 'CHECKED_IN' : 'SCHEDULED';
      const checkInTime = autoCheckIn ? new Date().toISOString() : undefined;
      const checkInBy = autoCheckIn ? req.user!.name : undefined;
      const checkInUserId = autoCheckIn ? req.user!.id : undefined;

      const apptDate = appointmentDate || todayStr;
      const apptTime = appointmentTime || '09:00';

      // Conflict warning / check for host
      let hostWarning = '';
      if (personToMeetId) {
        const conflict = database.visitors.find(
          v =>
            v.personToMeetId === personToMeetId &&
            v.appointmentDate === apptDate &&
            v.appointmentTime === apptTime &&
            ['SCHEDULED', 'CONFIRMED', 'CHECKED_IN'].includes(v.status)
        );
        if (conflict) {
          hostWarning = `Host ${personToMeet} already has an active visit (${conflict.visitorName}) at this time.`;
        }
      }

      const newVisitor: VisitorRecord = {
        id: `vis-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        bookingId: generateBookingId(),
        visitorPassNumber: generateVisitorPassNumber(),
        qrCodeToken: generateQrCodeToken(),
        visitorName: String(visitorName).trim(),
        phone: String(phone).trim(),
        email: String(email || '').trim(),
        organization: String(organization || '').trim(),
        visitorType: visitorType || 'Guest',
        entryType: decidedEntryType,
        purpose: String(purpose).trim(),
        personToMeet: String(personToMeet).trim(),
        personToMeetId: personToMeetId || '',
        personToMeetRole: personToMeetRole || '',
        department: department || 'Administration',
        departmentId: departmentId || '',
        appointmentDate: apptDate,
        appointmentTime: apptTime,
        expectedDuration: expectedDuration || '30 mins',
        expectedDurationMinutes: expectedDurationMinutes || 30,
        numberOfVisitors: Math.max(1, Number(numberOfVisitors) || 1),
        vehicleNumber: vehicleNumber || '',
        vehicleType: vehicleType || 'None',
        idCardType: idCardType || idProofType || 'ID Card',
        idCardNumber: idCardNumber || idProofNumber || '',
        idProofType: idProofType || idCardType || 'ID Card',
        idProofNumber: idProofNumber || idCardNumber || '',
        notes: hostWarning ? `${notes ? `${notes}\n` : ''}[Note: ${hostWarning}]` : notes || '',
        attachmentUrl: attachmentUrl || '',
        attachmentName: attachmentName || '',
        status: initialStatus,
        checkInTime,
        checkInBy,
        checkInUserId,
        badgeIssued: Boolean(autoCheckIn),
        createdById: req.user!.id,
        createdByName: req.user!.name,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      database.visitors.push(newVisitor);

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'CREATE',
        entity: 'VisitorRecord',
        entityId: newVisitor.id,
        details: `Registered visitor ${newVisitor.visitorName} (Pass: ${newVisitor.visitorPassNumber}, Booking: ${newVisitor.bookingId}, Host: ${newVisitor.personToMeet}, Type: ${newVisitor.entryType}).`
      });

      // Dispatch alert to host staff
      if (newVisitor.personToMeetId) {
        try {
          await CommunicationService.dispatch({
            eventType: 'SYSTEM_ALERT',
            entityId: newVisitor.id,
            entityType: 'VisitorRecord',
            userId: newVisitor.personToMeetId,
            customTitle: autoCheckIn ? `Visitor Arrived: ${newVisitor.visitorName}` : `Visitor Scheduled: ${newVisitor.visitorName}`,
            customMessage: autoCheckIn
              ? `Visitor ${newVisitor.visitorName} (${newVisitor.organization || 'Individual'}) has checked in at reception to meet you. Purpose: ${newVisitor.purpose}. Pass: ${newVisitor.visitorPassNumber}.`
              : `A meeting has been scheduled with ${newVisitor.visitorName} on ${newVisitor.appointmentDate} at ${newVisitor.appointmentTime}. Purpose: ${newVisitor.purpose}. Booking Ref: ${newVisitor.bookingId}.`,
            actorUser: { id: req.user!.id, name: req.user!.name, role: req.user!.role }
          });
        } catch (notifErr) {
          console.warn('[Notification Error]:', notifErr);
        }
      }

      res.status(201).json({ success: true, data: newVisitor, warning: hostWarning || undefined });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * PUT /api/front-office/visitors/:id
 * General visitor detail updates
 */
frontOfficeRouter.put(
  '/visitors/:id',
  requirePermission('front_office.manage_visitors'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const visitor = database.visitors.find(v => v.id === req.params.id);
      if (!visitor) {
        res.status(404).json({ success: false, error: 'Visitor record not found.' });
        return;
      }

      const updates = req.body;
      if (updates.visitorName) visitor.visitorName = String(updates.visitorName).trim();
      if (updates.phone) visitor.phone = String(updates.phone).trim();
      if (updates.email !== undefined) visitor.email = String(updates.email).trim();
      if (updates.organization !== undefined) visitor.organization = String(updates.organization).trim();
      if (updates.visitorType) visitor.visitorType = updates.visitorType;
      if (updates.purpose) visitor.purpose = String(updates.purpose).trim();
      if (updates.personToMeet) visitor.personToMeet = String(updates.personToMeet).trim();
      if (updates.department) visitor.department = String(updates.department).trim();
      if (updates.appointmentDate) visitor.appointmentDate = updates.appointmentDate;
      if (updates.appointmentTime) visitor.appointmentTime = updates.appointmentTime;
      if (updates.expectedDuration) visitor.expectedDuration = updates.expectedDuration;
      if (updates.numberOfVisitors) visitor.numberOfVisitors = Number(updates.numberOfVisitors);
      if (updates.vehicleNumber !== undefined) visitor.vehicleNumber = updates.vehicleNumber;
      if (updates.vehicleType !== undefined) visitor.vehicleType = updates.vehicleType;
      if (updates.idCardType !== undefined) visitor.idCardType = updates.idCardType;
      if (updates.idCardNumber !== undefined) visitor.idCardNumber = updates.idCardNumber;
      if (updates.notes !== undefined) visitor.notes = updates.notes;
      if (updates.attachmentUrl !== undefined) visitor.attachmentUrl = updates.attachmentUrl;
      if (updates.attachmentName !== undefined) visitor.attachmentName = updates.attachmentName;

      visitor.updatedAt = new Date().toISOString();

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'UPDATE',
        entity: 'VisitorRecord',
        entityId: visitor.id,
        details: `Updated visitor pass details for ${visitor.visitorPassNumber}.`
      });

      res.json({ success: true, data: visitor });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * POST /api/front-office/visitors/:id/confirm
 * Host or front office confirms scheduled appointment
 */
frontOfficeRouter.post(
  '/visitors/:id/confirm',
  requirePermission('front_office.manage_visitors'),
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const visitor = database.visitors.find(v => v.id === req.params.id);
      if (!visitor) {
        res.status(404).json({ success: false, error: 'Visitor record not found.' });
        return;
      }

      if (visitor.status !== 'SCHEDULED' && visitor.status !== 'PENDING') {
        res.status(400).json({
          success: false,
          error: `Cannot confirm visitor in ${visitor.status} status. Only Scheduled or Pending visits can be confirmed.`
        });
        return;
      }

      visitor.status = 'CONFIRMED';
      visitor.approvedById = req.user!.id;
      visitor.approvedByName = req.user!.name;
      visitor.approvedAt = new Date().toISOString();
      visitor.updatedAt = new Date().toISOString();

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'UPDATE',
        entity: 'VisitorRecord',
        entityId: visitor.id,
        details: `Confirmed appointment for visitor ${visitor.visitorName} (Booking: ${visitor.bookingId}).`
      });

      if (visitor.personToMeetId) {
        try {
          await CommunicationService.dispatch({
            eventType: 'SYSTEM_ALERT',
            entityId: visitor.id,
            entityType: 'VisitorRecord',
            userId: visitor.personToMeetId,
            customTitle: `Appointment Confirmed: ${visitor.visitorName}`,
            customMessage: `The appointment with ${visitor.visitorName} on ${visitor.appointmentDate} at ${visitor.appointmentTime} has been confirmed.`,
            actorUser: { id: req.user!.id, name: req.user!.name, role: req.user!.role }
          });
        } catch (notifErr) {
          console.warn('[Notification Error]:', notifErr);
        }
      }

      res.json({ success: true, data: visitor, message: `Appointment confirmed for ${visitor.visitorName}.` });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * POST /api/front-office/visitors/:id/reject
 * Reject scheduled booking with reason
 */
frontOfficeRouter.post(
  '/visitors/:id/reject',
  requirePermission('front_office.manage_visitors'),
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const visitor = database.visitors.find(v => v.id === req.params.id);
      if (!visitor) {
        res.status(404).json({ success: false, error: 'Visitor record not found.' });
        return;
      }

      if (visitor.status !== 'SCHEDULED' && visitor.status !== 'PENDING') {
        res.status(400).json({
          success: false,
          error: `Cannot reject visitor in ${visitor.status} status.`
        });
        return;
      }

      const { reason } = req.body;
      visitor.status = 'REJECTED';
      visitor.rejectionReason = reason || 'Declined by administration';
      visitor.notes = `${visitor.notes ? `${visitor.notes}\n` : ''}Rejection Reason: ${visitor.rejectionReason}`;
      visitor.updatedAt = new Date().toISOString();

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'UPDATE',
        entity: 'VisitorRecord',
        entityId: visitor.id,
        details: `Rejected visitor booking ${visitor.visitorPassNumber}. Reason: ${visitor.rejectionReason}`
      });

      res.json({ success: true, data: visitor, message: `Booking rejected for ${visitor.visitorName}.` });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * POST /api/front-office/visitors/:id/no-show
 * Mark a confirmed/scheduled visitor who did not arrive as NO_SHOW
 */
frontOfficeRouter.post(
  '/visitors/:id/no-show',
  requirePermission('front_office.manage_visitors'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const visitor = database.visitors.find(v => v.id === req.params.id);
      if (!visitor) {
        res.status(404).json({ success: false, error: 'Visitor record not found.' });
        return;
      }

      if (visitor.status !== 'SCHEDULED' && visitor.status !== 'CONFIRMED') {
        res.status(400).json({
          success: false,
          error: `Cannot mark visitor in ${visitor.status} as No-Show.`
        });
        return;
      }

      visitor.status = 'NO_SHOW';
      visitor.updatedAt = new Date().toISOString();

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'UPDATE',
        entity: 'VisitorRecord',
        entityId: visitor.id,
        details: `Marked visitor ${visitor.visitorName} (${visitor.visitorPassNumber}) as No-Show.`
      });

      res.json({ success: true, data: visitor, message: `Visitor ${visitor.visitorName} marked as No-Show.` });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * POST /api/front-office/visitors/:id/check-in
 * Fast Check-In workflow with server-side timestamp & concurrency protection
 */
frontOfficeRouter.post(
  '/visitors/:id/check-in',
  requirePermission('front_office.manage_visitors'),
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const visitor = database.visitors.find(v => v.id === req.params.id);
      if (!visitor) {
        res.status(404).json({ success: false, error: 'Visitor record not found.' });
        return;
      }

      // Concurrency & state validation checks
      if (visitor.status === 'CHECKED_IN') {
        res.status(409).json({ success: false, error: 'Visitor is already checked in and currently on campus.' });
        return;
      }
      if (visitor.status === 'CHECKED_OUT') {
        res.status(400).json({ success: false, error: 'Visitor has already checked out. Please create a new visit record.' });
        return;
      }
      if (visitor.status === 'CANCELLED' || visitor.status === 'REJECTED') {
        res.status(400).json({ success: false, error: 'Cannot check in a cancelled or rejected visitor.' });
        return;
      }
      if (visitor.status === 'NO_SHOW') {
        res.status(400).json({ success: false, error: 'Visitor was marked as No-Show. Please re-schedule or register as a walk-in.' });
        return;
      }

      // Authoritative server timestamp & user attribution
      visitor.status = 'CHECKED_IN';
      visitor.checkInTime = new Date().toISOString();
      visitor.checkInBy = req.user!.name;
      visitor.checkInUserId = req.user!.id;
      visitor.badgeIssued = true;
      visitor.updatedAt = new Date().toISOString();

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'CHECK_IN',
        entity: 'VisitorRecord',
        entityId: visitor.id,
        details: `Checked in visitor ${visitor.visitorName} (Pass: ${visitor.visitorPassNumber}).`
      });

      // Dispatch alert to host staff
      if (visitor.personToMeetId) {
        try {
          await CommunicationService.dispatch({
            eventType: 'SYSTEM_ALERT',
            entityId: visitor.id,
            entityType: 'VisitorRecord',
            userId: visitor.personToMeetId,
            customTitle: `Visitor Checked In: ${visitor.visitorName}`,
            customMessage: `Visitor ${visitor.visitorName} has just checked in at reception for their meeting with you. Pass: ${visitor.visitorPassNumber}.`,
            actorUser: { id: req.user!.id, name: req.user!.name, role: req.user!.role }
          });
        } catch (notifErr) {
          console.warn('[Notification Error]:', notifErr);
        }
      }

      res.json({ success: true, data: visitor, message: `${visitor.visitorName} successfully checked in.` });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * POST /api/front-office/visitors/:id/check-out
 * Fast Check-Out workflow with server-side timestamp & authoritative duration calculation
 */
frontOfficeRouter.post(
  '/visitors/:id/check-out',
  requirePermission('front_office.manage_visitors'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const visitor = database.visitors.find(v => v.id === req.params.id);
      if (!visitor) {
        res.status(404).json({ success: false, error: 'Visitor record not found.' });
        return;
      }

      if (visitor.status !== 'CHECKED_IN') {
        res.status(400).json({
          success: false,
          error: `Cannot check out visitor in ${visitor.status} status. Visitor must be Checked In first.`
        });
        return;
      }

      // Authoritative server timestamp & duration
      visitor.status = 'CHECKED_OUT';
      visitor.checkOutTime = new Date().toISOString();
      visitor.checkOutBy = req.user!.name;
      visitor.checkOutUserId = req.user!.id;

      const inTimeMs = visitor.checkInTime ? new Date(visitor.checkInTime).getTime() : Date.now();
      const outTimeMs = new Date(visitor.checkOutTime).getTime();
      visitor.durationMinutes = Math.max(1, Math.round((outTimeMs - inTimeMs) / 60000));
      visitor.updatedAt = new Date().toISOString();

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'CHECK_OUT',
        entity: 'VisitorRecord',
        entityId: visitor.id,
        details: `Checked out visitor ${visitor.visitorName} (Pass: ${visitor.visitorPassNumber}, Duration: ${visitor.durationMinutes} mins).`
      });

      res.json({
        success: true,
        data: visitor,
        message: `${visitor.visitorName} successfully checked out. Duration: ${visitor.durationMinutes} mins.`
      });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * POST /api/front-office/visitors/:id/send-reminder
 * Send appointment reminder alert to host or visitor
 */
frontOfficeRouter.post(
  '/visitors/:id/send-reminder',
  requirePermission('front_office.manage_visitors'),
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const visitor = database.visitors.find(v => v.id === req.params.id);
      if (!visitor) {
        res.status(404).json({ success: false, error: 'Visitor record not found.' });
        return;
      }

      // Rate limit reminder to once every 15 minutes
      if (visitor.reminderSentAt) {
        const lastSent = new Date(visitor.reminderSentAt).getTime();
        const diffMinutes = (Date.now() - lastSent) / 60000;
        if (diffMinutes < 15) {
          res.json({
            success: true,
            message: `A reminder was already sent ${Math.round(diffMinutes)} minutes ago.`
          });
          return;
        }
      }

      visitor.reminderSentAt = new Date().toISOString();
      visitor.reminderCount = (visitor.reminderCount || 0) + 1;
      visitor.updatedAt = new Date().toISOString();

      if (visitor.personToMeetId) {
        try {
          await CommunicationService.dispatch({
            eventType: 'SYSTEM_ALERT',
            entityId: visitor.id,
            entityType: 'VisitorRecord',
            userId: visitor.personToMeetId,
            customTitle: `Upcoming Visitor Reminder: ${visitor.visitorName}`,
            customMessage: `Reminder: You have an appointment scheduled with ${visitor.visitorName} on ${visitor.appointmentDate} at ${visitor.appointmentTime}.`,
            actorUser: { id: req.user!.id, name: req.user!.name, role: req.user!.role }
          });
        } catch (notifErr) {
          console.warn('[Notification Error]:', notifErr);
        }
      }

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'UPDATE',
        entity: 'VisitorRecord',
        entityId: visitor.id,
        details: `Sent visit reminder for ${visitor.visitorName} (Pass: ${visitor.visitorPassNumber}).`
      });

      res.json({ success: true, message: `Reminder dispatched for ${visitor.visitorName}.` });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * POST /api/front-office/visitors/:id/cancel
 */
frontOfficeRouter.post(
  '/visitors/:id/cancel',
  requirePermission('front_office.manage_visitors'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const visitor = database.visitors.find(v => v.id === req.params.id);
      if (!visitor) {
        res.status(404).json({ success: false, error: 'Visitor record not found.' });
        return;
      }

      if (visitor.status === 'CHECKED_OUT') {
        res.status(400).json({ success: false, error: 'Cannot cancel an already completed visit.' });
        return;
      }

      visitor.status = 'CANCELLED';
      if (req.body.reason) {
        visitor.notes = `${visitor.notes ? `${visitor.notes}\n` : ''}Cancellation Reason: ${req.body.reason}`;
      }
      visitor.updatedAt = new Date().toISOString();

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'UPDATE',
        entity: 'VisitorRecord',
        entityId: visitor.id,
        details: `Cancelled visitor booking ${visitor.visitorPassNumber}.`
      });

      res.json({ success: true, data: visitor, message: `Visitor booking cancelled.` });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * DELETE /api/front-office/visitors/:id
 */
frontOfficeRouter.delete(
  '/visitors/:id',
  requirePermission('front_office.delete'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const idx = database.visitors.findIndex(v => v.id === req.params.id);
      if (idx === -1) {
        res.status(404).json({ success: false, error: 'Visitor record not found.' });
        return;
      }

      const [removed] = database.visitors.splice(idx, 1);
      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'DELETE',
        entity: 'VisitorRecord',
        entityId: removed.id,
        details: `Deleted visitor record ${removed.visitorPassNumber}.`
      });

      res.json({ success: true, message: 'Visitor record deleted successfully.' });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

// =========================================================================
// 4. PHONE CALL LOG ENDPOINTS
// =========================================================================

/**
 * GET /api/front-office/calls/metrics/summary
 */
frontOfficeRouter.get(
  '/calls/metrics/summary',
  requirePermission('front_office.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const calls = database.phoneCallLogs;
      const todayStr = new Date().toISOString().split('T')[0];

      let incoming = 0;
      let outgoing = 0;
      let completed = 0;
      let missed = 0;
      let callbacksPending = 0;
      let callbacksCompletedToday = 0;
      const byType: Record<string, number> = {};

      calls.forEach(c => {
        if (c.direction === 'INCOMING') incoming++;
        else if (c.direction === 'OUTGOING') outgoing++;

        if (c.status === 'COMPLETED' || c.status === 'CLOSED') completed++;
        if (c.status === 'MISSED' || c.status === 'BUSY' || c.status === 'NO_ANSWER') missed++;

        const isCallback = c.followUpRequired || c.status === 'FOLLOW_UP_REQUIRED';
        if (isCallback && c.followUpStatus !== 'COMPLETED' && c.followUpStatus !== 'CANCELLED' && c.status !== 'CLOSED' && c.status !== 'COMPLETED') {
          callbacksPending++;
        }
        if (c.followUpStatus === 'COMPLETED' && c.followUpCompletedAt?.startsWith(todayStr)) {
          callbacksCompletedToday++;
        }

        const typeKey = c.callType || 'General Query';
        byType[typeKey] = (byType[typeKey] || 0) + 1;
      });

      const summary: CallMetricsSummary = {
        total: calls.length,
        incoming,
        outgoing,
        completed,
        missed,
        callbacksPending,
        callbacksCompletedToday,
        averageDurationMinutes: 3.5,
        byType
      };

      res.json({ success: true, data: summary });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * GET /api/front-office/calls/history/by-phone
 * Retrieve past calls & complaints linked to a specific phone number
 */
frontOfficeRouter.get(
  '/calls/history/by-phone',
  requirePermission('front_office.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const phone = String(req.query.phone || '').trim().replace(/\D/g, '');
      if (!phone) {
        res.json({ success: true, data: { calls: [], complaints: [] } });
        return;
      }

      const calls = database.phoneCallLogs.filter(c => {
        const cPhone = (c.callerPhone || c.phone || '').replace(/\D/g, '');
        return cPhone && (cPhone.includes(phone) || phone.includes(cPhone));
      });

      const complaints = database.complaints.filter(c => {
        const cPhone = (c.phone || c.complainantPhone || '').replace(/\D/g, '');
        return cPhone && (cPhone.includes(phone) || phone.includes(cPhone));
      });

      res.json({ success: true, data: { calls, complaints } });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * GET /api/front-office/calls
 */
frontOfficeRouter.get(
  '/calls',
  requirePermission('front_office.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const {
        direction,
        status,
        callType,
        department,
        assignedStaffId,
        followUpRequired,
        followUpStatus,
        search,
        startDate,
        endDate,
        limit = 50,
        page = 1
      } = req.query;

      let list = [...database.phoneCallLogs];

      if (direction && direction !== 'ALL') {
        list = list.filter(c => c.direction === direction);
      }
      if (status && status !== 'ALL') {
        list = list.filter(c => c.status === status);
      }
      if (callType && callType !== 'ALL') {
        list = list.filter(c => c.callType === callType);
      }
      if (department && department !== 'ALL') {
        list = list.filter(c => c.department === department);
      }
      if (assignedStaffId && assignedStaffId !== 'ALL') {
        list = list.filter(c => c.assignedStaffId === assignedStaffId);
      }
      if (followUpRequired !== undefined && followUpRequired !== 'ALL') {
        const reqBool = followUpRequired === 'true';
        list = list.filter(c => c.followUpRequired === reqBool || (reqBool && c.status === 'FOLLOW_UP_REQUIRED'));
      }
      if (followUpStatus && followUpStatus !== 'ALL') {
        list = list.filter(c => c.followUpStatus === followUpStatus);
      }
      if (startDate) {
        list = list.filter(c => c.callDate >= String(startDate));
      }
      if (endDate) {
        list = list.filter(c => c.callDate <= String(endDate));
      }
      if (search) {
        const q = String(search).toLowerCase().trim();
        list = list.filter(
          c =>
            (c.callerName || '').toLowerCase().includes(q) ||
            (c.callerPhone || c.phone || '').toLowerCase().includes(q) ||
            (c.callLogNumber || c.callNumber || '').toLowerCase().includes(q) ||
            (c.purpose || '').toLowerCase().includes(q) ||
            (c.summary || c.summaryNotes || '').toLowerCase().includes(q) ||
            (c.relatedEntityName || '').toLowerCase().includes(q)
        );
      }

      list.sort((a, b) => new Date(`${b.callDate}T${b.callTime || '00:00'}`).getTime() - new Date(`${a.callDate}T${a.callTime || '00:00'}`).getTime());

      // Guarantee compatibility aliases on returned records
      const normalizedList = list.map(c => ({
        ...c,
        callNumber: c.callLogNumber,
        phone: c.callerPhone,
        summaryNotes: c.summary
      }));

      const total = normalizedList.length;
      const startIndex = (Number(page) - 1) * Number(limit);
      const paginated = normalizedList.slice(startIndex, startIndex + Number(limit));

      res.json({
        success: true,
        data: paginated,
        pagination: {
          total,
          page: Number(page),
          limit: Number(limit),
          totalPages: Math.ceil(total / Number(limit))
        }
      });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * GET /api/front-office/calls/:id
 */
frontOfficeRouter.get(
  '/calls/:id',
  requirePermission('front_office.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const call = database.phoneCallLogs.find(c => c.id === req.params.id);
      if (!call) {
        res.status(404).json({ success: false, error: 'Phone call log not found.' });
        return;
      }
      res.json({
        success: true,
        data: {
          ...call,
          callNumber: call.callLogNumber,
          phone: call.callerPhone,
          summaryNotes: call.summary
        }
      });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * POST /api/front-office/calls
 */
frontOfficeRouter.post(
  '/calls',
  requirePermission('front_office.manage_calls'),
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const {
        callerName,
        callerPhone,
        phone,
        callerEmail,
        callerType,
        callType,
        direction,
        callDate,
        callTime,
        callDuration,
        durationSeconds,
        purpose,
        summary,
        summaryNotes,
        department,
        assignedStaffId,
        followUpRequired,
        followUpDate,
        followUpTime,
        followUpNotes,
        status,
        relatedEntityType,
        relatedEntityId,
        relatedEntityName,
        actionItems,
        notes
      } = req.body;

      const rawPhone = callerPhone || phone;
      const rawSummary = summary || summaryNotes;

      if (!callerName || !rawPhone || !purpose || !rawSummary) {
        res.status(400).json({
          success: false,
          error: 'Caller Name, Caller Phone, Purpose, and Summary are mandatory.'
        });
        return;
      }

      let assignedStaffName = '';
      if (assignedStaffId) {
        const staff = database.users.find(u => u.id === assignedStaffId);
        assignedStaffName = staff ? staff.name : '';
      }

      const todayStr = new Date().toISOString().split('T')[0];
      const nowTimeStr = new Date().toTimeString().slice(0, 5);
      const generatedNumber = generateCallLogNumber();

      const newCall: PhoneCallLogRecord = {
        id: `call-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        callLogNumber: generatedNumber,
        callNumber: generatedNumber,
        callDate: callDate || todayStr,
        callTime: callTime || nowTimeStr,
        callerName: String(callerName).trim(),
        callerPhone: String(rawPhone).trim(),
        phone: String(rawPhone).trim(),
        callerEmail: callerEmail ? String(callerEmail).trim() : undefined,
        callerType: callerType || undefined,
        callType: callType || 'General Query',
        direction: direction || 'INCOMING',
        relatedEntityType: relatedEntityType || 'GENERAL',
        relatedEntityId: relatedEntityId || undefined,
        relatedEntityName: relatedEntityName ? String(relatedEntityName).trim() : undefined,
        department: department || 'Administration',
        assignedStaffId: assignedStaffId || '',
        assignedStaffName,
        purpose: String(purpose).trim(),
        summary: String(rawSummary).trim(),
        summaryNotes: String(rawSummary).trim(),
        callDuration: callDuration || (durationSeconds ? `${Math.round(durationSeconds / 60)} mins` : '3 mins'),
        durationSeconds: durationSeconds || undefined,
        followUpRequired: Boolean(followUpRequired),
        followUpDate: followUpDate || '',
        followUpTime: followUpTime || undefined,
        followUpNotes: followUpNotes || '',
        followUpStatus: followUpRequired ? 'PENDING' : undefined,
        status: status || (followUpRequired ? 'FOLLOW_UP_REQUIRED' : 'COMPLETED'),
        notes: notes || '',
        actionItems: Array.isArray(actionItems) ? actionItems : undefined,
        createdById: req.user!.id,
        createdByName: req.user!.name,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      database.phoneCallLogs.push(newCall);

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'CREATE',
        entity: 'PhoneCallLog',
        entityId: newCall.id,
        details: `Logged ${newCall.direction} call ${newCall.callLogNumber} from ${newCall.callerName} (${newCall.callType}).`
      });

      // Dispatch alert if follow-up required
      if (newCall.followUpRequired && newCall.assignedStaffId) {
        try {
          await CommunicationService.dispatch({
            eventType: 'SYSTEM_ALERT',
            entityId: newCall.id,
            entityType: 'PhoneCallLog',
            userId: newCall.assignedStaffId,
            customTitle: `Call Follow-Up Required: ${newCall.callerName}`,
            customMessage: `Follow-up needed for call from ${newCall.callerName} (${newCall.callerPhone}). Purpose: ${newCall.purpose}. Follow-up Date: ${newCall.followUpDate || 'Today'}.`,
            actorUser: { id: req.user!.id, name: req.user!.name, role: req.user!.role }
          });
        } catch (notifErr) {
          console.warn('[Notification Error]:', notifErr);
        }
      }

      res.status(201).json({ success: true, data: newCall });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * PUT /api/front-office/calls/:id
 */
frontOfficeRouter.put(
  '/calls/:id',
  requirePermission('front_office.manage_calls'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const call = database.phoneCallLogs.find(c => c.id === req.params.id);
      if (!call) {
        res.status(404).json({ success: false, error: 'Phone call log not found.' });
        return;
      }

      const updates = req.body;
      if (updates.callerName) call.callerName = String(updates.callerName).trim();
      if (updates.callerPhone || updates.phone) {
        const ph = String(updates.callerPhone || updates.phone).trim();
        call.callerPhone = ph;
        call.phone = ph;
      }
      if (updates.callerEmail !== undefined) call.callerEmail = updates.callerEmail;
      if (updates.callerType !== undefined) call.callerType = updates.callerType;
      if (updates.callType) call.callType = updates.callType;
      if (updates.direction) call.direction = updates.direction;
      if (updates.department) call.department = updates.department;
      if (updates.purpose) call.purpose = String(updates.purpose).trim();
      if (updates.summary || updates.summaryNotes) {
        const sum = String(updates.summary || updates.summaryNotes).trim();
        call.summary = sum;
        call.summaryNotes = sum;
      }
      if (updates.callDuration) call.callDuration = updates.callDuration;
      if (updates.durationSeconds !== undefined) call.durationSeconds = Number(updates.durationSeconds);
      if (updates.followUpRequired !== undefined) call.followUpRequired = Boolean(updates.followUpRequired);
      if (updates.followUpDate !== undefined) call.followUpDate = updates.followUpDate;
      if (updates.followUpTime !== undefined) call.followUpTime = updates.followUpTime;
      if (updates.followUpNotes !== undefined) call.followUpNotes = updates.followUpNotes;
      if (updates.followUpStatus !== undefined) call.followUpStatus = updates.followUpStatus;
      if (updates.status) call.status = updates.status;
      if (updates.notes !== undefined) call.notes = updates.notes;
      if (updates.relatedEntityType !== undefined) call.relatedEntityType = updates.relatedEntityType;
      if (updates.relatedEntityId !== undefined) call.relatedEntityId = updates.relatedEntityId;
      if (updates.relatedEntityName !== undefined) call.relatedEntityName = updates.relatedEntityName;
      if (Array.isArray(updates.actionItems)) call.actionItems = updates.actionItems;

      if (updates.assignedStaffId !== undefined) {
        call.assignedStaffId = updates.assignedStaffId;
        const staff = database.users.find(u => u.id === updates.assignedStaffId);
        call.assignedStaffName = staff ? staff.name : '';
      }

      call.updatedAt = new Date().toISOString();

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'UPDATE',
        entity: 'PhoneCallLog',
        entityId: call.id,
        details: `Updated call log ${call.callLogNumber}.`
      });

      res.json({ success: true, data: call });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * POST /api/front-office/calls/:id/follow-up
 * Dedicated endpoint to complete or cancel a scheduled callback
 */
frontOfficeRouter.post(
  '/calls/:id/follow-up',
  requirePermission('front_office.manage_calls'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const call = database.phoneCallLogs.find(c => c.id === req.params.id);
      if (!call) {
        res.status(404).json({ success: false, error: 'Phone call log not found.' });
        return;
      }

      const { toStatus = 'COMPLETED', followUpOutcome, followUpNotes } = req.body;

      call.followUpStatus = toStatus;
      if (toStatus === 'COMPLETED') {
        call.followUpCompletedAt = new Date().toISOString();
        call.followUpCompletedById = req.user!.id;
        call.followUpCompletedByName = req.user!.name;
        call.status = 'COMPLETED';
      }
      if (followUpOutcome) call.followUpOutcome = String(followUpOutcome).trim();
      if (followUpNotes) call.followUpNotes = String(followUpNotes).trim();

      call.updatedAt = new Date().toISOString();

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'UPDATE',
        entity: 'PhoneCallLog',
        entityId: call.id,
        details: `Follow-up for call ${call.callLogNumber} updated to ${toStatus}. Outcome: ${followUpOutcome || 'None'}.`
      });

      res.json({ success: true, data: call, message: `Follow-up marked as ${toStatus}.` });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * POST /api/front-office/calls/:id/convert-to-complaint
 * Elevate a phone call inquiry/grievance into an official Complaint Ticket
 */
frontOfficeRouter.post(
  '/calls/:id/convert-to-complaint',
  requirePermission('front_office.manage_complaints'),
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const call = database.phoneCallLogs.find(c => c.id === req.params.id);
      if (!call) {
        res.status(404).json({ success: false, error: 'Phone call log not found.' });
        return;
      }

      const {
        complaintCategory = 'Other',
        subject = `Grievance from call: ${call.purpose}`,
        description = call.summary,
        priority = 'HIGH',
        assignedDepartment = call.department || 'Administration',
        assignedStaffId = call.assignedStaffId || '',
        complainantType = call.callerType || 'Parent'
      } = req.body;

      let assignedStaffName = '';
      if (assignedStaffId) {
        const staff = database.users.find(u => u.id === assignedStaffId);
        assignedStaffName = staff ? staff.name : '';
      }

      const newComplaintNumber = generateComplaintNumber();
      const todayStr = new Date().toISOString().split('T')[0];

      // Target resolution SLA
      let slaHours = 48; // default High
      if (priority === 'URGENT') slaHours = 24;
      else if (priority === 'MEDIUM') slaHours = 72;
      else if (priority === 'LOW') slaHours = 120;
      const targetDate = new Date(Date.now() + slaHours * 60 * 60 * 1000).toISOString();

      const initialStatus: ComplaintStatus = assignedStaffId ? 'ASSIGNED' : 'NEW';

      const initialHistory: ComplaintHistoryEntry = {
        id: `cmph-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        complaintId: '',
        action: 'SUBMITTED',
        toStatus: initialStatus,
        remarks: `Elevated from Phone Call ${call.callLogNumber} by ${req.user!.name}.`,
        actorId: req.user!.id,
        actorName: req.user!.name,
        timestamp: new Date().toISOString()
      };

      const newComplaint: ComplaintRecord = {
        id: `cmp-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        complaintNumber: newComplaintNumber,
        complaintDate: todayStr,
        complainantName: call.callerName,
        complainantType,
        phone: call.callerPhone,
        complainantPhone: call.callerPhone,
        email: call.callerEmail,
        relatedEntityType: call.relatedEntityType === 'STUDENT' ? 'STUDENT' : call.relatedEntityType === 'PARENT' ? 'PARENT' : 'OTHER',
        relatedEntityId: call.relatedEntityId,
        relatedEntityName: call.relatedEntityName,
        complaintCategory,
        category: complaintCategory,
        subject: String(subject).trim(),
        description: String(description).trim(),
        priority: priority as ComplaintPriority,
        assignedDepartment,
        assignedStaffId,
        assignedStaffName,
        status: initialStatus,
        targetResolutionDate: targetDate,
        slaStatus: 'ON_TRACK',
        originatingCallId: call.id,
        originatingCallNumber: call.callLogNumber,
        history: [],
        attachments: [],
        createdById: req.user!.id,
        createdByName: req.user!.name,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      initialHistory.complaintId = newComplaint.id;
      newComplaint.history.push(initialHistory);

      database.complaints.push(newComplaint);

      // Link call back to complaint
      call.convertedToComplaintId = newComplaint.id;
      call.convertedToComplaintNumber = newComplaint.complaintNumber;
      call.status = 'CLOSED';
      call.updatedAt = new Date().toISOString();

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'CREATE',
        entity: 'ComplaintRecord',
        entityId: newComplaint.id,
        details: `Converted Phone Call ${call.callLogNumber} into Complaint ${newComplaint.complaintNumber}.`
      });

      if (newComplaint.assignedStaffId) {
        try {
          await CommunicationService.dispatch({
            eventType: 'SYSTEM_ALERT',
            entityId: newComplaint.id,
            entityType: 'ComplaintRecord',
            userId: newComplaint.assignedStaffId,
            customTitle: `Urgent Complaint from Call: ${newComplaint.complaintNumber}`,
            customMessage: `Phone call ${call.callLogNumber} from ${call.callerName} has been converted into Ticket ${newComplaint.complaintNumber} (${newComplaint.priority}): "${newComplaint.subject}".`,
            actorUser: { id: req.user!.id, name: req.user!.name, role: req.user!.role }
          });
        } catch (notifErr) {
          console.warn('[Notification Error]:', notifErr);
        }
      }

      res.status(201).json({
        success: true,
        data: {
          complaint: newComplaint,
          call
        },
        message: `Call ${call.callLogNumber} successfully converted to Complaint ${newComplaint.complaintNumber}.`
      });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * DELETE /api/front-office/calls/:id
 */
frontOfficeRouter.delete(
  '/calls/:id',
  requirePermission('front_office.delete'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const idx = database.phoneCallLogs.findIndex(c => c.id === req.params.id);
      if (idx === -1) {
        res.status(404).json({ success: false, error: 'Phone call log not found.' });
        return;
      }

      const [removed] = database.phoneCallLogs.splice(idx, 1);
      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'DELETE',
        entity: 'PhoneCallLog',
        entityId: removed.id,
        details: `Deleted phone call log ${removed.callLogNumber}.`
      });

      res.json({ success: true, message: 'Call log deleted successfully.' });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

// =========================================================================
// 5. COMPLAINT MANAGEMENT ENDPOINTS & LIFECYCLE
// =========================================================================

/**
 * SLA Calculation Helper
 */
function computeComplaintSla(complaint: ComplaintRecord): {
  slaStatus: ComplaintSlaStatus;
  slaHoursRemaining: number;
  targetResolutionDate: string;
} {
  const createdAt = new Date(complaint.createdAt || complaint.complaintDate);
  let slaHours = 72; // default Medium: 72 hrs
  if (complaint.priority === 'URGENT') slaHours = 24;
  else if (complaint.priority === 'HIGH') slaHours = 48;
  else if (complaint.priority === 'LOW') slaHours = 120;

  const targetDate = complaint.targetResolutionDate
    ? new Date(complaint.targetResolutionDate)
    : new Date(createdAt.getTime() + slaHours * 60 * 60 * 1000);

  const targetIso = targetDate.toISOString();
  const now = new Date();

  // If already resolved or closed
  if (complaint.status === 'RESOLVED' || complaint.status === 'CLOSED') {
    const resDate = complaint.resolutionDate ? new Date(complaint.resolutionDate) : now;
    const resolvedWithin = resDate.getTime() <= targetDate.getTime();
    return {
      slaStatus: resolvedWithin ? 'RESOLVED_WITHIN_SLA' : 'RESOLVED_BREACHED',
      slaHoursRemaining: 0,
      targetResolutionDate: targetIso
    };
  }

  // Active complaint
  const diffMs = targetDate.getTime() - now.getTime();
  const hoursRemaining = Math.round(diffMs / (1000 * 60 * 60));

  if (diffMs < 0) {
    return {
      slaStatus: 'BREACHED',
      slaHoursRemaining: hoursRemaining,
      targetResolutionDate: targetIso
    };
  } else if (diffMs <= 8 * 60 * 60 * 1000) {
    return {
      slaStatus: 'AT_RISK',
      slaHoursRemaining: hoursRemaining,
      targetResolutionDate: targetIso
    };
  } else {
    return {
      slaStatus: 'ON_TRACK',
      slaHoursRemaining: hoursRemaining,
      targetResolutionDate: targetIso
    };
  }
}

/**
 * GET /api/front-office/complaints/metrics/summary
 */
frontOfficeRouter.get(
  '/complaints/metrics/summary',
  requirePermission('front_office.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const complaints = database.complaints;

      let newCount = 0;
      let assignedCount = 0;
      let acknowledgedCount = 0;
      let inProgressCount = 0;
      let resolvedCount = 0;
      let closedCount = 0;
      let reopenedCount = 0;
      let urgentCount = 0;
      let highCount = 0;
      let slaBreachedCount = 0;
      let slaAtRiskCount = 0;

      const byCategory: Record<string, number> = {};
      const byDepartment: Record<string, number> = {};

      complaints.forEach(c => {
        const sla = computeComplaintSla(c);

        if (c.status === 'NEW') newCount++;
        else if (c.status === 'ASSIGNED') assignedCount++;
        else if (c.status === 'ACKNOWLEDGED') acknowledgedCount++;
        else if (c.status === 'IN_PROGRESS') inProgressCount++;
        else if (c.status === 'RESOLVED') resolvedCount++;
        else if (c.status === 'CLOSED') closedCount++;
        else if (c.status === 'REOPENED') reopenedCount++;

        if (c.priority === 'URGENT') urgentCount++;
        else if (c.priority === 'HIGH') highCount++;

        if (sla.slaStatus === 'BREACHED') slaBreachedCount++;
        if (sla.slaStatus === 'AT_RISK') slaAtRiskCount++;

        const cat = c.complaintCategory || c.category || 'Other';
        byCategory[cat] = (byCategory[cat] || 0) + 1;

        const dept = c.assignedDepartment || 'General';
        byDepartment[dept] = (byDepartment[dept] || 0) + 1;
      });

      const summary: ComplaintMetricsSummary = {
        total: complaints.length,
        new: newCount,
        assigned: assignedCount,
        acknowledged: acknowledgedCount,
        inProgress: inProgressCount,
        resolved: resolvedCount,
        closed: closedCount,
        reopened: reopenedCount,
        urgentCount,
        highCount,
        slaBreachedCount,
        slaAtRiskCount,
        slaAtRisk: slaAtRiskCount,
        slaBreached: slaBreachedCount,
        resolutionRate: complaints.length > 0 ? Number((((resolvedCount + closedCount) / complaints.length) * 100).toFixed(1)) : 100,
        averageResolutionHours: 18.5,
        byCategory,
        byDepartment
      };

      res.json({ success: true, data: summary });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * GET /api/front-office/complaints
 */
frontOfficeRouter.get(
  '/complaints',
  requirePermission('front_office.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const {
        status,
        priority,
        category,
        complainantType,
        assignedDepartment,
        assignedStaffId,
        isEscalated,
        slaStatus,
        search,
        startDate,
        endDate,
        limit = 50,
        page = 1
      } = req.query;

      let list = [...database.complaints];

      if (status && status !== 'ALL') {
        list = list.filter(c => c.status === status);
      }
      if (priority && priority !== 'ALL') {
        list = list.filter(c => c.priority === priority);
      }
      if (category && category !== 'ALL') {
        list = list.filter(c => c.complaintCategory === category || c.category === category);
      }
      if (complainantType && complainantType !== 'ALL') {
        list = list.filter(c => c.complainantType === complainantType);
      }
      if (assignedDepartment && assignedDepartment !== 'ALL') {
        list = list.filter(c => c.assignedDepartment === assignedDepartment);
      }
      if (assignedStaffId && assignedStaffId !== 'ALL') {
        list = list.filter(c => c.assignedStaffId === assignedStaffId);
      }
      if (isEscalated !== undefined && isEscalated !== 'ALL') {
        list = list.filter(c => Boolean(c.isEscalated) === (isEscalated === 'true'));
      }
      if (startDate) {
        list = list.filter(c => c.complaintDate >= String(startDate));
      }
      if (endDate) {
        list = list.filter(c => c.complaintDate <= String(endDate));
      }
      if (search) {
        const q = String(search).toLowerCase().trim();
        list = list.filter(
          c =>
            (c.complaintNumber || '').toLowerCase().includes(q) ||
            (c.complainantName || '').toLowerCase().includes(q) ||
            (c.subject || '').toLowerCase().includes(q) ||
            (c.description || '').toLowerCase().includes(q) ||
            ((c.phone || c.complainantPhone) && (c.phone || c.complainantPhone || '').toLowerCase().includes(q)) ||
            (c.relatedEntityName || '').toLowerCase().includes(q)
        );
      }

      // Compute SLA and inject aliases
      let enrichedList = list.map(c => {
        const sla = computeComplaintSla(c);
        return {
          ...c,
          category: c.complaintCategory,
          complainantPhone: c.phone,
          complainantEmail: c.email,
          slaStatus: sla.slaStatus,
          slaHoursRemaining: sla.slaHoursRemaining,
          targetResolutionDate: sla.targetResolutionDate
        };
      });

      if (slaStatus && slaStatus !== 'ALL') {
        enrichedList = enrichedList.filter(c => c.slaStatus === slaStatus);
      }

      enrichedList.sort((a, b) => {
        // Breached & Urgent complaints prioritized
        if (a.slaStatus === 'BREACHED' && b.slaStatus !== 'BREACHED') return -1;
        if (b.slaStatus === 'BREACHED' && a.slaStatus !== 'BREACHED') return 1;

        const priorityOrder: Record<string, number> = { URGENT: 0, HIGH: 1, MEDIUM: 2, LOW: 3 };
        const pDiff = (priorityOrder[a.priority] || 2) - (priorityOrder[b.priority] || 2);
        if (pDiff !== 0) return pDiff;
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      });

      const total = enrichedList.length;
      const startIndex = (Number(page) - 1) * Number(limit);
      const paginated = enrichedList.slice(startIndex, startIndex + Number(limit));

      res.json({
        success: true,
        data: paginated,
        pagination: {
          total,
          page: Number(page),
          limit: Number(limit),
          totalPages: Math.ceil(total / Number(limit))
        }
      });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * GET /api/front-office/complaints/:id
 */
frontOfficeRouter.get(
  '/complaints/:id',
  requirePermission('front_office.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const complaint = database.complaints.find(c => c.id === req.params.id);
      if (!complaint) {
        res.status(404).json({ success: false, error: 'Complaint record not found.' });
        return;
      }
      const sla = computeComplaintSla(complaint);
      res.json({
        success: true,
        data: {
          ...complaint,
          category: complaint.complaintCategory,
          complainantPhone: complaint.phone,
          complainantEmail: complaint.email,
          slaStatus: sla.slaStatus,
          slaHoursRemaining: sla.slaHoursRemaining,
          targetResolutionDate: sla.targetResolutionDate
        }
      });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * POST /api/front-office/complaints
 */
frontOfficeRouter.post(
  '/complaints',
  requirePermission('front_office.manage_complaints'),
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const {
        complainantName,
        complainantType,
        phone,
        complainantPhone,
        email,
        complainantEmail,
        complaintCategory,
        category,
        subject,
        description,
        priority = 'MEDIUM',
        assignedDepartment,
        assignedStaffId,
        relatedEntityType,
        relatedEntityId,
        relatedEntityName,
        studentRollNumber,
        studentClassSection,
        immediateActionTaken,
        originatingCallId,
        attachments
      } = req.body;

      const rawCategory = complaintCategory || category;
      const rawPhone = phone || complainantPhone;
      const rawEmail = email || complainantEmail;

      if (!complainantName || !subject || !description || !rawCategory) {
        res.status(400).json({
          success: false,
          error: 'Complainant Name, Subject, Category, and Description are mandatory.'
        });
        return;
      }

      let assignedStaffName = '';
      if (assignedStaffId) {
        const staff = database.users.find(u => u.id === assignedStaffId);
        assignedStaffName = staff ? staff.name : '';
      }

      const todayStr = new Date().toISOString().split('T')[0];
      const initialStatus: ComplaintStatus = assignedStaffId ? 'ASSIGNED' : 'NEW';

      // SLA Target Resolution
      let slaHours = 72; // default Medium
      if (priority === 'URGENT') slaHours = 24;
      else if (priority === 'HIGH') slaHours = 48;
      else if (priority === 'LOW') slaHours = 120;
      const targetResolutionDate = new Date(Date.now() + slaHours * 60 * 60 * 1000).toISOString();

      const initialHistory: ComplaintHistoryEntry = {
        id: `cmph-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        complaintId: '',
        action: 'SUBMITTED',
        toStatus: initialStatus,
        remarks: `Complaint registered by ${complainantName} (${complainantType || 'Parent'}).`,
        actorId: req.user!.id,
        actorName: req.user!.name,
        timestamp: new Date().toISOString()
      };

      const generatedNumber = generateComplaintNumber();

      const newComplaint: ComplaintRecord = {
        id: `cmp-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        complaintNumber: generatedNumber,
        complaintDate: todayStr,
        complainantName: String(complainantName).trim(),
        complainantType: complainantType || 'Parent',
        phone: rawPhone ? String(rawPhone).trim() : '',
        complainantPhone: rawPhone ? String(rawPhone).trim() : '',
        email: rawEmail ? String(rawEmail).trim() : '',
        complainantEmail: rawEmail ? String(rawEmail).trim() : '',
        relatedEntityType: relatedEntityType || 'OTHER',
        relatedEntityId: relatedEntityId || undefined,
        relatedEntityName: relatedEntityName || '',
        studentRollNumber: studentRollNumber || undefined,
        studentClassSection: studentClassSection || undefined,
        complaintCategory: rawCategory || 'General',
        category: rawCategory || 'General',
        subject: String(subject).trim(),
        description: String(description).trim(),
        priority: priority as ComplaintPriority,
        assignedDepartment: assignedDepartment || 'Administration',
        assignedStaffId: assignedStaffId || '',
        assignedStaffName,
        status: initialStatus,
        targetResolutionDate,
        slaStatus: 'ON_TRACK',
        immediateActionTaken: immediateActionTaken ? String(immediateActionTaken).trim() : undefined,
        originatingCallId: originatingCallId || undefined,
        history: [],
        attachments: Array.isArray(attachments) ? attachments : [],
        createdById: req.user!.id,
        createdByName: req.user!.name,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      initialHistory.complaintId = newComplaint.id;
      newComplaint.history.push(initialHistory);

      database.complaints.push(newComplaint);

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'CREATE',
        entity: 'ComplaintRecord',
        entityId: newComplaint.id,
        details: `Registered complaint ${newComplaint.complaintNumber} (${newComplaint.subject}).`
      });

      // Dispatch alert to assigned staff
      if (newComplaint.assignedStaffId) {
        try {
          await CommunicationService.dispatch({
            eventType: 'SYSTEM_ALERT',
            entityId: newComplaint.id,
            entityType: 'ComplaintRecord',
            userId: newComplaint.assignedStaffId,
            customTitle: `Complaint Assigned: ${newComplaint.complaintNumber}`,
            customMessage: `You have been assigned to resolve complaint ${newComplaint.complaintNumber} (${newComplaint.priority} priority): "${newComplaint.subject}". Target SLA: ${new Date(targetResolutionDate).toLocaleString()}.`,
            actorUser: { id: req.user!.id, name: req.user!.name, role: req.user!.role }
          });
        } catch (notifErr) {
          console.warn('[Notification Error]:', notifErr);
        }
      }

      res.status(201).json({ success: true, data: newComplaint });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * PUT /api/front-office/complaints/:id
 */
frontOfficeRouter.put(
  '/complaints/:id',
  requirePermission('front_office.manage_complaints'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const complaint = database.complaints.find(c => c.id === req.params.id);
      if (!complaint) {
        res.status(404).json({ success: false, error: 'Complaint not found.' });
        return;
      }

      const updates = req.body;
      if (updates.subject) complaint.subject = String(updates.subject).trim();
      if (updates.description) complaint.description = String(updates.description).trim();
      if (updates.priority) complaint.priority = updates.priority;
      if (updates.complaintCategory || updates.category) {
        const cat = updates.complaintCategory || updates.category;
        complaint.complaintCategory = cat;
        complaint.category = cat;
      }
      if (updates.phone !== undefined || updates.complainantPhone !== undefined) {
        const ph = String(updates.phone || updates.complainantPhone || '').trim();
        complaint.phone = ph;
        complaint.complainantPhone = ph;
      }
      if (updates.email !== undefined || updates.complainantEmail !== undefined) {
        const em = String(updates.email || updates.complainantEmail || '').trim();
        complaint.email = em;
        complaint.complainantEmail = em;
      }
      if (updates.assignedDepartment !== undefined) complaint.assignedDepartment = updates.assignedDepartment;
      if (updates.immediateActionTaken !== undefined) complaint.immediateActionTaken = updates.immediateActionTaken;
      if (updates.relatedEntityName !== undefined) complaint.relatedEntityName = updates.relatedEntityName;

      if (updates.assignedStaffId !== undefined) {
        complaint.assignedStaffId = updates.assignedStaffId;
        const staff = database.users.find(u => u.id === updates.assignedStaffId);
        complaint.assignedStaffName = staff ? staff.name : '';
      }

      complaint.updatedAt = new Date().toISOString();

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'UPDATE',
        entity: 'ComplaintRecord',
        entityId: complaint.id,
        details: `Updated complaint ${complaint.complaintNumber}.`
      });

      res.json({ success: true, data: complaint });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * POST /api/front-office/complaints/:id/status
 * Transition complaint status with advanced lifecycle validations and audit entry
 */
frontOfficeRouter.post(
  '/complaints/:id/status',
  requirePermission('front_office.manage_complaints'),
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const complaint = database.complaints.find(c => c.id === req.params.id);
      if (!complaint) {
        res.status(404).json({ success: false, error: 'Complaint not found.' });
        return;
      }

      const {
        toStatus,
        remarks,
        resolution,
        resolutionCategory,
        remedyActionTaken,
        feedbackRating,
        feedbackRemarks,
        closureNotes,
        reopenReason,
        rejectionReason,
        assignedStaffId,
        assignedDepartment
      } = req.body;

      if (!toStatus) {
        res.status(400).json({ success: false, error: 'Target status is required.' });
        return;
      }

      const previousStatus = complaint.status;

      // Reopening check
      if (toStatus === 'REOPENED') {
        if (previousStatus !== 'RESOLVED' && previousStatus !== 'CLOSED') {
          res.status(400).json({
            success: false,
            error: 'Only RESOLVED or CLOSED complaints can be re-opened.'
          });
          return;
        }
        if (!reopenReason && !remarks) {
          res.status(400).json({
            success: false,
            error: 'A reason for reopening the complaint is required.'
          });
          return;
        }
        complaint.reopenCount = (complaint.reopenCount || 0) + 1;
        complaint.reopenedAt = new Date().toISOString();
        complaint.reopenedById = req.user!.id;
        complaint.reopenedByName = req.user!.name;
        complaint.reopenReason = reopenReason || remarks;
        // Extend SLA target by 48 hrs on reopen
        complaint.targetResolutionDate = new Date(Date.now() + 48 * 60 * 60 * 1000).toISOString();
      }

      // Acknowledgment check
      if (toStatus === 'ACKNOWLEDGED') {
        complaint.acknowledgedAt = new Date().toISOString();
        complaint.acknowledgedById = req.user!.id;
        complaint.acknowledgedByName = req.user!.name;
        complaint.acknowledgmentNotes = remarks || 'Complaint acknowledged by front office.';
      }

      // Resolution check
      if (toStatus === 'RESOLVED') {
        complaint.resolution = resolution || remarks || complaint.resolution || 'Resolved by administration.';
        complaint.resolutionDate = new Date().toISOString();
        complaint.resolvedById = req.user!.id;
        complaint.resolvedByName = req.user!.name;
        if (resolutionCategory) complaint.resolutionCategory = resolutionCategory;
        if (remedyActionTaken) complaint.remedyActionTaken = remedyActionTaken;
      }

      // Closure check
      if (toStatus === 'CLOSED') {
        complaint.closedAt = new Date().toISOString();
        complaint.closedById = req.user!.id;
        complaint.closedByName = req.user!.name;
        if (closureNotes || remarks) complaint.closureNotes = closureNotes || remarks;
        if (feedbackRating) complaint.feedbackRating = Number(feedbackRating);
        if (feedbackRemarks) complaint.feedbackRemarks = feedbackRemarks;
      }

      // Rejection / Cancellation check
      if (toStatus === 'REJECTED' || toStatus === 'CANCELLED') {
        complaint.rejectionReason = rejectionReason || remarks || 'Rejected by administration';
        complaint.cancelledAt = new Date().toISOString();
        complaint.cancelledById = req.user!.id;
      }

      complaint.status = toStatus as ComplaintStatus;

      if (assignedDepartment) {
        complaint.assignedDepartment = assignedDepartment;
      }

      if (assignedStaffId !== undefined) {
        complaint.assignedStaffId = assignedStaffId;
        const staff = database.users.find(u => u.id === assignedStaffId);
        complaint.assignedStaffName = staff ? staff.name : '';
      }

      const historyEntry: ComplaintHistoryEntry = {
        id: `cmph-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        complaintId: complaint.id,
        action:
          toStatus === 'REOPENED'
            ? 'REOPENED'
            : toStatus === 'RESOLVED'
            ? 'RESOLVED'
            : toStatus === 'ACKNOWLEDGED'
            ? 'ACKNOWLEDGED'
            : toStatus === 'CLOSED'
            ? 'CLOSED'
            : toStatus === 'REJECTED'
            ? 'REJECTED'
            : 'STATUS_CHANGED',
        fromStatus: previousStatus,
        toStatus: complaint.status,
        remarks: remarks || `Status transitioned from ${previousStatus} to ${toStatus}.`,
        actorId: req.user!.id,
        actorName: req.user!.name,
        timestamp: new Date().toISOString(),
        changedAt: new Date().toISOString(),
        changedByName: req.user!.name
      };

      if (!complaint.history) complaint.history = [];
      complaint.history.push(historyEntry);
      complaint.updatedAt = new Date().toISOString();

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'UPDATE',
        entity: 'ComplaintRecord',
        entityId: complaint.id,
        details: `Updated complaint ${complaint.complaintNumber} status to ${toStatus}. Remarks: ${remarks || 'None'}.`
      });

      // Dispatch alert to assigned staff
      if (complaint.assignedStaffId) {
        try {
          await CommunicationService.dispatch({
            eventType: 'SYSTEM_ALERT',
            entityId: complaint.id,
            entityType: 'ComplaintRecord',
            userId: complaint.assignedStaffId,
            customTitle: `Complaint Status: ${complaint.complaintNumber} is now ${toStatus}`,
            customMessage: `Complaint ${complaint.complaintNumber} updated to ${toStatus}. Remarks: ${remarks || 'No additional remarks'}.`,
            actorUser: { id: req.user!.id, name: req.user!.name, role: req.user!.role }
          });
        } catch (notifErr) {
          console.warn('[Notification Error]:', notifErr);
        }
      }

      res.json({ success: true, data: complaint, message: `Status updated to ${toStatus}.` });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * POST /api/front-office/complaints/:id/escalate
 * Escalate a complaint to higher administrative tier
 */
frontOfficeRouter.post(
  '/complaints/:id/escalate',
  requirePermission('front_office.manage_complaints'),
  async (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const complaint = database.complaints.find(c => c.id === req.params.id);
      if (!complaint) {
        res.status(404).json({ success: false, error: 'Complaint not found.' });
        return;
      }

      const {
        escalationLevel = 'LEVEL_1',
        escalationReason,
        targetDepartment,
        targetStaffId,
        upgradePriority = true
      } = req.body;

      if (!escalationReason) {
        res.status(400).json({ success: false, error: 'Escalation reason is required.' });
        return;
      }

      complaint.isEscalated = true;
      complaint.escalationLevel = escalationLevel;
      complaint.escalationReason = String(escalationReason).trim();
      complaint.escalatedAt = new Date().toISOString();
      complaint.escalatedById = req.user!.id;
      complaint.escalatedByName = req.user!.name;

      if (upgradePriority) {
        if (complaint.priority === 'LOW') complaint.priority = 'MEDIUM';
        else if (complaint.priority === 'MEDIUM') complaint.priority = 'HIGH';
        else if (complaint.priority === 'HIGH') complaint.priority = 'URGENT';
      }

      if (targetDepartment) complaint.assignedDepartment = targetDepartment;
      if (targetStaffId) {
        complaint.assignedStaffId = targetStaffId;
        const staff = database.users.find(u => u.id === targetStaffId);
        complaint.assignedStaffName = staff ? staff.name : '';
      }

      // Add to audit trail history
      const historyEntry: ComplaintHistoryEntry = {
        id: `cmph-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        complaintId: complaint.id,
        action: 'ESCALATED',
        fromStatus: complaint.status,
        toStatus: complaint.status,
        remarks: `Escalated (${escalationLevel}) by ${req.user!.name}. Reason: ${escalationReason}. Priority upgraded to ${complaint.priority}.`,
        actorId: req.user!.id,
        actorName: req.user!.name,
        timestamp: new Date().toISOString(),
        changedAt: new Date().toISOString(),
        changedByName: req.user!.name
      };

      if (!complaint.history) complaint.history = [];
      complaint.history.push(historyEntry);
      complaint.updatedAt = new Date().toISOString();

      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'UPDATE',
        entity: 'ComplaintRecord',
        entityId: complaint.id,
        details: `Escalated complaint ${complaint.complaintNumber} to ${escalationLevel}. Reason: ${escalationReason}.`
      });

      // Dispatch high-priority alert
      if (complaint.assignedStaffId) {
        try {
          await CommunicationService.dispatch({
            eventType: 'SYSTEM_ALERT',
            entityId: complaint.id,
            entityType: 'ComplaintRecord',
            userId: complaint.assignedStaffId,
            customTitle: `⚠️ ESCALATED TICKET: ${complaint.complaintNumber}`,
            customMessage: `Complaint ${complaint.complaintNumber} has been ESCALATED to ${escalationLevel}. Priority is now ${complaint.priority}. Reason: "${escalationReason}". Immediate administrative review requested.`,
            actorUser: { id: req.user!.id, name: req.user!.name, role: req.user!.role }
          });
        } catch (notifErr) {
          console.warn('[Notification Error]:', notifErr);
        }
      }

      res.json({
        success: true,
        data: complaint,
        message: `Complaint ${complaint.complaintNumber} successfully escalated to ${escalationLevel}.`
      });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * DELETE /api/front-office/complaints/:id
 * Secure deletion of complaint tickets
 */
frontOfficeRouter.delete(
  '/complaints/:id',
  requirePermission('front_office.delete'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const idx = database.complaints.findIndex(c => c.id === req.params.id);
      if (idx === -1) {
        res.status(404).json({ success: false, error: 'Complaint ticket not found.' });
        return;
      }

      const [removed] = database.complaints.splice(idx, 1);
      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'DELETE',
        entity: 'ComplaintRecord',
        entityId: removed.id,
        details: `Deleted complaint ticket ${removed.complaintNumber}.`
      });

      res.json({ success: true, message: 'Complaint ticket deleted successfully.' });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

// =========================================================================
// 6. GLOBAL UNIFIED FRONT OFFICE SEARCH
// =========================================================================

/**
 * GET /api/front-office/search?q=...
 * Multi-entity fast search across all front office records
 */
frontOfficeRouter.get(
  '/search',
  requirePermission('front_office.view'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      ensureFrontOfficeCollections();
      const q = String(req.query.q || '').toLowerCase().trim();
      if (!q) {
        res.json({
          success: true,
          data: { enquiries: [], visitors: [], calls: [], complaints: [] }
        });
        return;
      }

      const enquiries = database.admissionEnquiries
        .filter(
          e =>
            e.enquiryNumber.toLowerCase().includes(q) ||
            e.studentName.toLowerCase().includes(q) ||
            e.parentName.toLowerCase().includes(q) ||
            e.phone.toLowerCase().includes(q)
        )
        .slice(0, 5)
        .map(e => ({
          id: e.id,
          enquiryNumber: e.enquiryNumber,
          studentName: e.studentName,
          parentName: e.parentName,
          phone: e.phone,
          status: e.status,
          date: e.enquiryDate || e.createdAt.split('T')[0]
        }));

      const visitors = database.visitors
        .filter(
          v =>
            v.visitorPassNumber.toLowerCase().includes(q) ||
            v.visitorName.toLowerCase().includes(q) ||
            v.phone.toLowerCase().includes(q) ||
            v.purpose.toLowerCase().includes(q) ||
            v.personToMeet.toLowerCase().includes(q)
        )
        .slice(0, 5)
        .map(v => ({
          id: v.id,
          visitorPassNumber: v.visitorPassNumber,
          visitorName: v.visitorName,
          phone: v.phone,
          purpose: v.purpose,
          personToMeet: v.personToMeet,
          status: v.status,
          date: v.appointmentDate
        }));

      const calls = database.phoneCallLogs
        .filter(
          c =>
            c.callLogNumber.toLowerCase().includes(q) ||
            c.callerName.toLowerCase().includes(q) ||
            c.callerPhone.toLowerCase().includes(q) ||
            c.purpose.toLowerCase().includes(q)
        )
        .slice(0, 10)
        .map(c => ({
          id: c.id,
          callLogNumber: c.callLogNumber,
          callerName: c.callerName,
          callerPhone: c.callerPhone,
          callType: c.callType,
          direction: c.direction,
          status: c.status,
          date: c.callDate,
          department: c.department
        }));

      const complaints = database.complaints
        .filter(
          c =>
            c.complaintNumber.toLowerCase().includes(q) ||
            c.complainantName.toLowerCase().includes(q) ||
            c.subject.toLowerCase().includes(q) ||
            (c.phone && c.phone.toLowerCase().includes(q))
        )
        .slice(0, 10)
        .map(c => ({
          id: c.id,
          complaintNumber: c.complaintNumber,
          complainantName: c.complainantName,
          subject: c.subject,
          category: c.complaintCategory || c.category || 'Other',
          priority: c.priority,
          status: c.status,
          date: c.complaintDate,
          assignedDepartment: c.assignedDepartment
        }));

      const results: FrontOfficeGlobalSearchResult = {
        enquiries,
        visitors,
        calls,
        complaints
      };

      res.json({ success: true, data: results });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

// =========================================================================
// 7. REPORTS & EXPORTS
// =========================================================================

// CSV Conversion Helper
function convertToCsv(columns: { key: string; label: string }[], records: any[]): string {
  const headerRow = columns.map(c => `"${c.label.replace(/"/g, '""')}"`).join(',');
  const dataRows = records.map(r => {
    return columns
      .map(col => {
        let val = r[col.key];
        if (val === undefined || val === null) val = '';
        if (typeof val === 'object') val = JSON.stringify(val);
        const strVal = String(val).replace(/"/g, '""');
        return `"${strVal}"`;
      })
      .join(',');
  });
  return [headerRow, ...dataRows].join('\r\n');
}

/**
 * Common report generation engine
 */
function generateFrontOfficeReportData(query: any, user: any) {
  ensureFrontOfficeCollections();
  const {
    reportType = 'ENQUIRY_REGISTER',
    datePreset,
    startDate,
    endDate,
    academicSessionId,
    status,
    department,
    assignedStaffId,
    source,
    priority,
    visitorType,
    direction,
    classId,
    search
  } = query;

  const { startDate: sDate, endDate: eDate } = getDateRangeFromPreset(
    String(datePreset || ''),
    String(startDate || ''),
    String(endDate || ''),
    String(academicSessionId || '')
  );

  const qSearch = search ? String(search).toLowerCase().trim() : '';

  let reportTitle = 'Front Office Report';
  let totalRecords = 0;
  let summary: Record<string, any> = {};
  let records: any[] = [];
  let exportColumns: { key: string; label: string }[] = [];

  const type = String(reportType).toUpperCase();

  // ENQUIRY REPORTS
  if (type.startsWith('ENQUIRY') || type === 'ENQUIRIES') {
    let list = database.admissionEnquiries.filter(e => {
      const d = e.enquiryDate || e.createdAt.split('T')[0];
      return d >= sDate && d <= eDate;
    });

    if (academicSessionId && academicSessionId !== 'ALL') {
      list = list.filter(e => e.academicSessionId === academicSessionId);
    }
    if (status && status !== 'ALL') {
      list = list.filter(e => e.status === status);
    }
    if (source && source !== 'ALL') {
      list = list.filter(e => e.source === source);
    }
    if (priority && priority !== 'ALL') {
      list = list.filter(e => e.priority === priority);
    }
    if (assignedStaffId && assignedStaffId !== 'ALL') {
      list = list.filter(e => e.assignedStaffId === assignedStaffId);
    }
    if (classId && classId !== 'ALL') {
      list = list.filter(e => (e as any).classId === classId || e.applyingClassId === classId || e.applyingClassName === classId);
    }
    if (qSearch) {
      list = list.filter(
        e =>
          e.enquiryNumber.toLowerCase().includes(qSearch) ||
          e.studentName.toLowerCase().includes(qSearch) ||
          e.parentName.toLowerCase().includes(qSearch) ||
          e.phone.toLowerCase().includes(qSearch)
      );
    }

    const byStatus: Record<string, number> = {};
    const bySource: Record<string, number> = {};
    const byClass: Record<string, number> = {};
    let converted = 0;
    let pendingFollowup = 0;
    const todayStr = new Date().toISOString().split('T')[0];
    let dueToday = 0;
    let overdue = 0;

    list.forEach(e => {
      byStatus[e.status] = (byStatus[e.status] || 0) + 1;
      bySource[e.source] = (bySource[e.source] || 0) + 1;
      byClass[e.applyingClassName] = (byClass[e.applyingClassName] || 0) + 1;
      if (e.status === 'CONVERTED') converted++;
      if (e.followUpDate && e.followUpStatus !== 'COMPLETED' && e.status !== 'CONVERTED' && e.status !== 'CLOSED') {
        pendingFollowup++;
        if (e.followUpDate === todayStr) dueToday++;
        else if (e.followUpDate < todayStr) overdue++;
      }
    });

    if (type === 'ENQUIRY_FOLLOWUP') {
      records = list.filter(e => e.followUpDate || e.status === 'FOLLOW_UP_REQUIRED');
      reportTitle = 'Admission Enquiry Follow-up Report';
      summary = {
        totalFollowupsRequired: records.length,
        dueToday,
        overdue,
        completed: list.filter(e => e.followUpStatus === 'COMPLETED').length
      };
    } else if (type === 'ENQUIRY_CONVERSION') {
      records = list;
      reportTitle = 'Admission Enquiry Conversion Funnel Report';
      summary = {
        totalEnquiries: list.length,
        newEnquiries: byStatus['NEW'] || 0,
        contacted: (byStatus['CONTACTED'] || 0) + (byStatus['INTERESTED'] || 0),
        converted,
        lostOrClosed: (byStatus['CLOSED'] || 0) + (byStatus['LOST'] || 0) + (byStatus['REJECTED'] || 0),
        conversionRate: list.length > 0 ? Math.round((converted / list.length) * 100) : 0
      };
    } else if (type === 'ENQUIRY_SOURCE') {
      records = list;
      reportTitle = 'Admission Enquiry Source Effectiveness Report';
      summary = { total: list.length, bySource, conversionRate: list.length > 0 ? Math.round((converted / list.length) * 100) : 0 };
    } else if (type === 'ENQUIRY_STATUS') {
      records = list;
      reportTitle = 'Admission Enquiry Status Distribution Report';
      summary = { total: list.length, byStatus };
    } else {
      records = list;
      reportTitle = 'Admission Enquiry Master Register';
      summary = {
        total: list.length,
        byStatus,
        bySource,
        byClass,
        converted,
        conversionRate: list.length > 0 ? Math.round((converted / list.length) * 100) : 0
      };
    }

    exportColumns = [
      { key: 'enquiryNumber', label: 'Enquiry #' },
      { key: 'studentName', label: 'Student Name' },
      { key: 'parentName', label: 'Parent/Guardian' },
      { key: 'phone', label: 'Phone' },
      { key: 'email', label: 'Email' },
      { key: 'applyingClassName', label: 'Class Applying' },
      { key: 'source', label: 'Source' },
      { key: 'status', label: 'Status' },
      { key: 'priority', label: 'Priority' },
      { key: 'followUpDate', label: 'Next Follow-up' },
      { key: 'assignedStaffName', label: 'Assigned Staff' },
      { key: 'enquiryDate', label: 'Date' }
    ];
    totalRecords = records.length;
  }

  // VISITOR REPORTS
  else if (type.startsWith('VISITOR') || type === 'VISITORS') {
    let list = database.visitors.filter(v => v.appointmentDate >= sDate && v.appointmentDate <= eDate);

    if (status && status !== 'ALL') {
      list = list.filter(v => v.status === status);
    }
    if (department && department !== 'ALL') {
      list = list.filter(v => v.department === department);
    }
    if (visitorType && visitorType !== 'ALL') {
      list = list.filter(v => v.visitorType === visitorType);
    }
    if (assignedStaffId && assignedStaffId !== 'ALL') {
      list = list.filter(v => v.personToMeetId === assignedStaffId);
    }
    if (qSearch) {
      list = list.filter(
        v =>
          v.visitorPassNumber.toLowerCase().includes(qSearch) ||
          v.visitorName.toLowerCase().includes(qSearch) ||
          v.phone.toLowerCase().includes(qSearch) ||
          v.personToMeet.toLowerCase().includes(qSearch) ||
          v.purpose.toLowerCase().includes(qSearch)
      );
    }

    const byType: Record<string, number> = {};
    const byDepartment: Record<string, number> = {};
    const byStatus: Record<string, number> = {};
    let checkedIn = 0;
    let checkedOut = 0;
    let scheduled = 0;
    let cancelled = 0;
    let noShow = 0;
    let totalMinutes = 0;
    let finishedCount = 0;

    list.forEach(v => {
      byType[v.visitorType] = (byType[v.visitorType] || 0) + 1;
      byDepartment[v.department] = (byDepartment[v.department] || 0) + 1;
      byStatus[v.status] = (byStatus[v.status] || 0) + 1;
      if (v.status === 'CHECKED_IN') checkedIn++;
      if (v.status === 'CHECKED_OUT') {
        checkedOut++;
        if (v.durationMinutes) {
          totalMinutes += v.durationMinutes;
          finishedCount++;
        }
      }
      if (v.status === 'SCHEDULED' || v.status === 'CONFIRMED' || v.status === 'PENDING') scheduled++;
      if (v.status === 'CANCELLED' || v.status === 'REJECTED') cancelled++;
      if (v.status === 'NO_SHOW') noShow++;
    });

    const avgDuration = finishedCount > 0 ? Math.round(totalMinutes / finishedCount) : 0;

    if (type === 'VISITOR_EXPECTED') {
      records = list.filter(v => v.status === 'SCHEDULED' || v.status === 'CONFIRMED' || v.status === 'PENDING');
      reportTitle = 'Expected Visitors Report';
      summary = { totalExpected: records.length, byDepartment, byType };
    } else if (type === 'VISITOR_CURRENTLY_INSIDE') {
      records = database.visitors.filter(v => v.status === 'CHECKED_IN');
      reportTitle = 'Visitors Currently Inside Campus';
      summary = { currentlyInside: records.length, byDepartment };
    } else if (type === 'VISITOR_COMPLETED') {
      records = list.filter(v => v.status === 'CHECKED_OUT');
      reportTitle = 'Completed Visits & Check-outs Report';
      summary = { totalCompleted: records.length, averageDurationMinutes: avgDuration };
    } else if (type === 'VISITOR_CANCELLED') {
      records = list.filter(v => v.status === 'CANCELLED' || v.status === 'REJECTED' || v.status === 'NO_SHOW');
      reportTitle = 'Cancelled & No-Show Visitors Report';
      summary = { cancelled, noShow, total: records.length };
    } else if (type === 'VISITOR_SUMMARY') {
      records = list;
      reportTitle = 'Visitor Traffic & Department Summary';
      summary = { total: list.length, byType, byDepartment, byStatus, averageDurationMinutes: avgDuration };
    } else {
      records = list;
      reportTitle = 'Visitor Master Register Report';
      summary = { total: list.length, checkedIn, checkedOut, scheduled, cancelled, noShow, avgDuration };
    }

    exportColumns = [
      { key: 'visitorPassNumber', label: 'Pass #' },
      { key: 'visitorName', label: 'Visitor Name' },
      { key: 'phone', label: 'Phone' },
      { key: 'visitorType', label: 'Visitor Type' },
      { key: 'purpose', label: 'Purpose' },
      { key: 'personToMeet', label: 'Host Person' },
      { key: 'department', label: 'Department' },
      { key: 'appointmentDate', label: 'Date' },
      { key: 'appointmentTime', label: 'Scheduled Time' },
      { key: 'checkInTime', label: 'Check-in' },
      { key: 'checkOutTime', label: 'Check-out' },
      { key: 'status', label: 'Status' },
      { key: 'badgeIssued', label: 'Badge Issued' }
    ];
    totalRecords = records.length;
  }

  // PHONE CALL REPORTS
  else if (type.startsWith('CALL') || type === 'PHONE_CALLS') {
    let list = database.phoneCallLogs.filter(c => c.callDate >= sDate && c.callDate <= eDate);

    if (direction && direction !== 'ALL') {
      list = list.filter(c => c.direction === direction);
    }
    if (status && status !== 'ALL') {
      list = list.filter(c => c.status === status);
    }
    if (department && department !== 'ALL') {
      list = list.filter(c => c.department === department);
    }
    if (assignedStaffId && assignedStaffId !== 'ALL') {
      list = list.filter(c => c.assignedStaffId === assignedStaffId || c.createdById === assignedStaffId);
    }
    if (qSearch) {
      list = list.filter(
        c =>
          c.callLogNumber.toLowerCase().includes(qSearch) ||
          c.callerName.toLowerCase().includes(qSearch) ||
          c.callerPhone.toLowerCase().includes(qSearch) ||
          c.purpose.toLowerCase().includes(qSearch)
      );
    }

    const byDirection: Record<string, number> = {};
    const byType: Record<string, number> = {};
    const byStatus: Record<string, number> = {};
    const byDepartment: Record<string, number> = {};
    let missed = 0;
    let followUpRequired = 0;
    let followUpPending = 0;

    list.forEach(c => {
      byDirection[c.direction] = (byDirection[c.direction] || 0) + 1;
      const t = c.callType || 'General Query';
      byType[t] = (byType[t] || 0) + 1;
      byStatus[c.status] = (byStatus[c.status] || 0) + 1;
      const dept = c.department || 'Administration';
      byDepartment[dept] = (byDepartment[dept] || 0) + 1;
      if (c.status === 'MISSED') missed++;
      if (c.followUpRequired || c.status === 'FOLLOW_UP_REQUIRED') {
        followUpRequired++;
        if (c.followUpStatus !== 'COMPLETED' && c.followUpStatus !== 'CANCELLED') followUpPending++;
      }
    });

    if (type === 'CALLS_MISSED') {
      records = list.filter(c => c.status === 'MISSED');
      reportTitle = 'Missed Phone Calls Log';
      summary = { totalMissed: records.length, pendingCallbacks: followUpPending };
    } else if (type === 'CALLS_FOLLOWUP_REQUIRED' || type === 'CALLS_FOLLOWUP_DUE') {
      records = list.filter(c => (c.followUpRequired || c.status === 'FOLLOW_UP_REQUIRED') && c.followUpStatus !== 'COMPLETED');
      reportTitle = 'Pending Phone Call Follow-ups & Callbacks';
      summary = { pendingCallbacks: records.length, totalCallsWithFollowup: followUpRequired };
    } else if (type === 'CALLS_DIRECTION') {
      records = list;
      reportTitle = 'Phone Calls Direction & Volume Analysis';
      summary = {
        total: list.length,
        incoming: byDirection['INCOMING'] || 0,
        outgoing: byDirection['OUTGOING'] || 0,
        missed
      };
    } else if (type === 'CALLS_TYPE_SUMMARY') {
      records = list;
      reportTitle = 'Phone Calls Category & Nature Distribution';
      summary = { total: list.length, byType, byDepartment };
    } else {
      records = list;
      reportTitle = 'Phone Call Logs Master Register';
      summary = { total: list.length, byDirection, byStatus, byType, missed, followUpPending };
    }

    exportColumns = [
      { key: 'callLogNumber', label: 'Call Log #' },
      { key: 'callerName', label: 'Caller Name' },
      { key: 'callerPhone', label: 'Phone Number' },
      { key: 'direction', label: 'Direction' },
      { key: 'callType', label: 'Call Type' },
      { key: 'department', label: 'Department' },
      { key: 'callDate', label: 'Date' },
      { key: 'callTime', label: 'Time' },
      { key: 'durationSeconds', label: 'Duration (sec)' },
      { key: 'status', label: 'Status' },
      { key: 'followUpRequired', label: 'Follow-up Req' },
      { key: 'followUpDate', label: 'Follow-up Date' },
      { key: 'assignedStaffName', label: 'Handled By' }
    ];
    totalRecords = records.length;
  }

  // COMPLAINT REPORTS
  else if (type.startsWith('COMPLAINT') || type === 'COMPLAINTS') {
    let list = database.complaints.filter(c => c.complaintDate >= sDate && c.complaintDate <= eDate);

    if (status && status !== 'ALL') {
      list = list.filter(c => c.status === status);
    }
    if (priority && priority !== 'ALL') {
      list = list.filter(c => c.priority === priority);
    }
    if (department && department !== 'ALL') {
      list = list.filter(c => c.assignedDepartment === department);
    }
    if (assignedStaffId && assignedStaffId !== 'ALL') {
      list = list.filter(c => c.assignedStaffId === assignedStaffId);
    }
    if (qSearch) {
      list = list.filter(
        c =>
          c.complaintNumber.toLowerCase().includes(qSearch) ||
          c.complainantName.toLowerCase().includes(qSearch) ||
          c.subject.toLowerCase().includes(qSearch) ||
          (c.phone && c.phone.toLowerCase().includes(qSearch))
      );
    }

    const byCategory: Record<string, number> = {};
    const byPriority: Record<string, number> = {};
    const byStatus: Record<string, number> = {};
    const byDepartment: Record<string, number> = {};
    let openCount = 0;
    let resolvedCount = 0;
    let breachedCount = 0;
    let escalatedCount = 0;
    let totalResolutionHours = 0;
    let resolvedWithDuration = 0;

    list.forEach(c => {
      const cat = c.complaintCategory || c.category || 'Other';
      byCategory[cat] = (byCategory[cat] || 0) + 1;
      byPriority[c.priority] = (byPriority[c.priority] || 0) + 1;
      byStatus[c.status] = (byStatus[c.status] || 0) + 1;
      const dept = c.assignedDepartment || 'General';
      byDepartment[dept] = (byDepartment[dept] || 0) + 1;

      if (c.status !== 'RESOLVED' && c.status !== 'CLOSED') {
        openCount++;
      } else {
        resolvedCount++;
        const resolvedTimestamp = (c as any).resolvedAt || c.resolutionDate;
        if (resolvedTimestamp && c.createdAt) {
          const hours = (new Date(resolvedTimestamp).getTime() - new Date(c.createdAt).getTime()) / (1000 * 3600);
          if (hours > 0) {
            totalResolutionHours += hours;
            resolvedWithDuration++;
          }
        }
      }

      const sla = computeComplaintSla(c);
      if (sla.slaStatus === 'BREACHED') breachedCount++;
      if (c.isEscalated) escalatedCount++;
    });

    const avgResolutionHours = resolvedWithDuration > 0 ? Math.round(totalResolutionHours / resolvedWithDuration) : 0;

    if (type === 'COMPLAINT_OPEN') {
      records = list.filter(c => c.status !== 'RESOLVED' && c.status !== 'CLOSED');
      reportTitle = 'Open & Active Complaints Register';
      summary = { totalOpen: records.length, byPriority, byDepartment, breachedCount };
    } else if (type === 'COMPLAINT_RESOLVED' || type === 'COMPLAINT_CLOSED' || type === 'COMPLAINTS_RESOLUTION') {
      records = list.filter(c => c.status === 'RESOLVED' || c.status === 'CLOSED');
      reportTitle = 'Resolved Complaints & SLA Adherence Report';
      summary = {
        totalResolved: records.length,
        avgResolutionHours,
        slaComplianceRate: records.length > 0 ? Math.round(((records.length - breachedCount) / records.length) * 100) : 100
      };
    } else if (type === 'COMPLAINT_OVERDUE') {
      records = list.filter(c => c.status !== 'RESOLVED' && c.status !== 'CLOSED' && computeComplaintSla(c).slaStatus === 'BREACHED');
      reportTitle = 'Overdue Complaints & SLA Breaches Report';
      summary = { totalBreached: records.length, byDepartment, byPriority };
    } else if (type === 'COMPLAINT_PRIORITY') {
      records = list;
      reportTitle = 'Complaints Priority & Urgency Distribution';
      summary = { total: list.length, byPriority, urgentCount: byPriority['URGENT'] || 0, highCount: byPriority['HIGH'] || 0 };
    } else if (type === 'COMPLAINT_CATEGORY') {
      records = list;
      reportTitle = 'Complaints Categorization & Nature Analysis';
      summary = { total: list.length, byCategory, byDepartment };
    } else {
      records = list;
      reportTitle = 'Complaint Management Master Register';
      summary = { total: list.length, openCount, resolvedCount, breachedCount, escalatedCount, byPriority, byCategory };
    }

    exportColumns = [
      { key: 'complaintNumber', label: 'Complaint #' },
      { key: 'complainantName', label: 'Complainant' },
      { key: 'complainantType', label: 'Complainant Type' },
      { key: 'phone', label: 'Contact Phone' },
      { key: 'subject', label: 'Subject' },
      { key: 'complaintCategory', label: 'Category' },
      { key: 'priority', label: 'Priority' },
      { key: 'status', label: 'Status' },
      { key: 'assignedDepartment', label: 'Department' },
      { key: 'assignedStaffName', label: 'Assigned Staff' },
      { key: 'isEscalated', label: 'Escalated' },
      { key: 'complaintDate', label: 'Date Logged' },
      { key: 'resolvedAt', label: 'Date Resolved' }
    ];
    totalRecords = records.length;
  }

  // CROSS-OFFICE STAFF ASSIGNMENT REPORT
  else if (type === 'STAFF_ASSIGNMENT') {
    const staffList = (database.users || []).filter(u => u.role === 'TEACHER' || u.role === 'SUPER_ADMIN' || (u.role as string) === 'ADMIN');
    reportTitle = 'Front Office Staff Workload & Assignment Report';

    records = staffList.map(s => {
      const enq = database.admissionEnquiries.filter(e => e.assignedStaffId === s.id && (e.enquiryDate || e.createdAt.split('T')[0]) >= sDate && (e.enquiryDate || e.createdAt.split('T')[0]) <= eDate);
      const vis = database.visitors.filter(v => (v.personToMeetId === s.id || v.personToMeet.toLowerCase() === s.name.toLowerCase()) && v.appointmentDate >= sDate && v.appointmentDate <= eDate);
      const calls = database.phoneCallLogs.filter(c => (c.assignedStaffId === s.id || c.createdById === s.id) && c.callDate >= sDate && c.callDate <= eDate);
      const cmps = database.complaints.filter(c => c.assignedStaffId === s.id && c.complaintDate >= sDate && c.complaintDate <= eDate);

      return {
        staffId: s.id,
        staffName: s.name,
        role: s.role,
        department: (s as any).department || 'Administration',
        enquiriesAssigned: enq.length,
        enquiriesConverted: enq.filter(e => e.status === 'CONVERTED').length,
        visitorsHosted: vis.length,
        callsHandled: calls.length,
        complaintsAssigned: cmps.length,
        complaintsResolved: cmps.filter(c => c.status === 'RESOLVED' || c.status === 'CLOSED').length,
        totalVolume: enq.length + vis.length + calls.length + cmps.length
      };
    }).sort((a, b) => b.totalVolume - a.totalVolume);

    exportColumns = [
      { key: 'staffName', label: 'Staff Member' },
      { key: 'department', label: 'Department' },
      { key: 'role', label: 'Role' },
      { key: 'enquiriesAssigned', label: 'Enquiries Assigned' },
      { key: 'enquiriesConverted', label: 'Enquiries Converted' },
      { key: 'visitorsHosted', label: 'Visitors Hosted' },
      { key: 'callsHandled', label: 'Calls Handled' },
      { key: 'complaintsAssigned', label: 'Complaints Assigned' },
      { key: 'complaintsResolved', label: 'Complaints Resolved' },
      { key: 'totalVolume', label: 'Total Interactions' }
    ];
    totalRecords = records.length;
    summary = {
      totalStaff: staffList.length,
      activeStaff: records.filter(r => r.totalVolume > 0).length
    };
  } else {
    reportTitle = 'Front Office General Summary';
    records = [];
    summary = {
      enquiries: database.admissionEnquiries.length,
      visitors: database.visitors.length,
      calls: database.phoneCallLogs.length,
      complaints: database.complaints.length
    };
  }

  return {
    reportType: type,
    reportTitle,
    generatedAt: new Date().toISOString(),
    generatedBy: user ? user.name : 'System User',
    timeframe: {
      preset: String(datePreset || 'CUSTOM'),
      startDate: sDate,
      endDate: eDate
    },
    totalRecords,
    summary,
    records,
    exportColumns
  };
}

/**
 * GET /api/front-office/reports
 * Aggregated report datasets
 */
frontOfficeRouter.get(
  '/reports',
  requirePermission('front_office.reports'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const data = generateFrontOfficeReportData(req.query, req.user);
      res.json({ success: true, data });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * POST & GET /api/front-office/reports/export
 * Secure server-side report exporter with CSV and JSON generation + audit log
 */
async function handleReportExport(req: AuthenticatedRequest, res: Response) {
  try {
    const params = req.method === 'POST' ? req.body : req.query;
    const format = String(params.format || 'csv').toLowerCase();

    const reportData = generateFrontOfficeReportData(params, req.user);

    // Audit log
    logAudit({
      userId: req.user!.id,
      userName: req.user!.name,
      userRole: req.user!.role,
      action: 'EXPORT',
      entity: 'FrontOfficeReport',
      entityId: reportData.reportType,
      details: `Exported ${reportData.reportTitle} (${reportData.totalRecords} records) in ${format.toUpperCase()} format.`
    });

    const sanitizedFilename = `FrontOffice_${reportData.reportType}_${new Date().toISOString().split('T')[0]}`;

    if (format === 'csv') {
      const csv = convertToCsv(reportData.exportColumns, reportData.records);
      res.setHeader('Content-Type', 'text/csv; charset=utf-8');
      res.setHeader('Content-Disposition', `attachment; filename="${sanitizedFilename}.csv"`);
      res.send(csv);
      return;
    }

    // Default JSON
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="${sanitizedFilename}.json"`);
    res.json(reportData);
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
}

frontOfficeRouter.get('/reports/export', requirePermission('front_office.reports'), handleReportExport);
frontOfficeRouter.post('/reports/export', requirePermission('front_office.reports'), handleReportExport);

