import { Router, Response } from 'express';
import { database } from '../db/database.js';
import { AuthenticatedRequest, requireAuth, requirePermission } from '../security/auth.js';
import { logAudit } from '../security/audit.js';
import {
  StudentDocument,
  StudentProfile,
  StudentIDCard,
  StudentIDCardTemplate,
  StudentIDCardStats,
  StudentDocumentStats,
  StudentDocumentVerificationPayload,
  BulkIDCardGeneratePayload,
  StudentDocumentCategory,
  StudentDocumentVerificationStatus
} from '../../src/types/index.js';

export const documentsIdCardsRouter = Router();

// Helper to ensure collections are defined
function ensureCollections() {
  if (!database.studentIdCards) database.studentIdCards = [];
  if (!database.studentIdCardTemplates) database.studentIdCardTemplates = [];
}

/**
 * Helper to determine which student records a user is authorized to inspect or modify
 */
function getAuthorizedStudentIdsForUser(user: any): Set<string> | null {
  if (!user || user.role === 'SUPER_ADMIN') {
    return null; // Full institutional administrative access
  }
  if (user.role === 'STUDENT') {
    const student = database.studentProfiles.find(s => s.userId === user.id);
    return new Set(student ? [student.id] : []);
  }
  if (user.role === 'GUARDIAN') {
    const guardian = database.guardians.find(g => g.userId === user.id);
    return new Set(guardian?.studentIds || []);
  }
  if (user.role === 'TEACHER') {
    const teacherProfile = database.teacherProfiles.find(t => t.userId === user.id);
    const assignedClassIds = teacherProfile?.assignedClassIds || [];
    const classTeacherSectionClassIds = database.sections
      .filter(s => s.classTeacherId === teacherProfile?.id)
      .map(s => s.classId);
    const allClasses = new Set([...assignedClassIds, ...classTeacherSectionClassIds]);
    const teacherStudentIds = database.studentProfiles
      .filter(s => allClasses.has(s.classId))
      .map(s => s.id);
    return new Set(teacherStudentIds);
  }
  return new Set();
}

// -------------------------------------------------------------
// DOCUMENT REPOSITORY & VERIFICATION WORKFLOW ENDPOINTS
// -------------------------------------------------------------

/**
 * GET /api/documents-idcards/documents
 * Central repository view across all student documents with search & filter
 */
documentsIdCardsRouter.get(
  '/documents',
  requireAuth,
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      ensureCollections();
      const {
        search,
        studentId,
        classId,
        sectionId,
        category,
        verificationStatus,
        page = '1',
        limit = '15'
      } = req.query as Record<string, string>;

      // Aggregate all documents from student profiles
      let allDocs: StudentDocument[] = [];
      const authorizedScope = getAuthorizedStudentIdsForUser(req.user);

      for (const student of database.studentProfiles) {
        if (!student.documents || student.documents.length === 0) continue;
        if (authorizedScope !== null && !authorizedScope.has(student.id)) continue;

        const cls = database.classes.find(c => c.id === student.classId);
        const sec = database.sections.find(s => s.id === student.sectionId);

        for (const doc of student.documents) {
          allDocs.push({
            ...doc,
            studentId: student.id,
            studentName: student.fullName || `${student.firstName || ''} ${student.lastName || ''}`.trim() || 'Student',
            admissionNumber: student.admissionNumber,
            className: student.className || cls?.name || 'Class',
            sectionName: student.sectionName || sec?.name || 'Section'
          });
        }
      }

      // Filter by Student ID
      if (studentId) {
        allDocs = allDocs.filter(d => d.studentId === studentId);
      }

      // Filter by Class ID
      if (classId) {
        const matchingStudentIds = database.studentProfiles
          .filter(s => s.classId === classId)
          .map(s => s.id);
        allDocs = allDocs.filter(d => matchingStudentIds.includes(d.studentId || ''));
      }

      // Filter by Section ID
      if (sectionId) {
        const matchingStudentIds = database.studentProfiles
          .filter(s => s.sectionId === sectionId)
          .map(s => s.id);
        allDocs = allDocs.filter(d => matchingStudentIds.includes(d.studentId || ''));
      }

      // Filter by Category
      if (category && category !== 'ALL') {
        allDocs = allDocs.filter(d => (d.category || 'OTHER').toUpperCase() === category.toUpperCase());
      }

      // Filter by Verification Status
      if (verificationStatus && verificationStatus !== 'ALL') {
        allDocs = allDocs.filter(d => (d.verificationStatus || 'PENDING_VERIFICATION').toUpperCase() === verificationStatus.toUpperCase());
      }

      // Filter by Search Query (title, document name, student name, admission #)
      if (search && search.trim()) {
        const q = search.trim().toLowerCase();
        allDocs = allDocs.filter(d =>
          (d.name && d.name.toLowerCase().includes(q)) ||
          (d.title && d.title.toLowerCase().includes(q)) ||
          (d.studentName && d.studentName.toLowerCase().includes(q)) ||
          (d.admissionNumber && d.admissionNumber.toLowerCase().includes(q)) ||
          (d.documentNumber && d.documentNumber.toLowerCase().includes(q))
        );
      }

      // Sort newest first
      allDocs.sort((a, b) => new Date(b.uploadedAt || 0).getTime() - new Date(a.uploadedAt || 0).getTime());

      // Pagination
      const pageNum = Math.max(1, parseInt(page, 10) || 1);
      const limitNum = Math.max(1, parseInt(limit, 10) || 15);
      const total = allDocs.length;
      const totalPages = Math.ceil(total / limitNum);
      const paginated = allDocs.slice((pageNum - 1) * limitNum, pageNum * limitNum);

      res.json({
        success: true,
        data: paginated,
        total,
        page: pageNum,
        limit: limitNum,
        totalPages
      });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to retrieve documents' });
    }
  }
);

/**
 * GET /api/documents-idcards/documents/stats
 * Statistical metrics on document verification & categories
 */
documentsIdCardsRouter.get(
  '/documents/stats',
  requireAuth,
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      ensureCollections();
      let totalDocuments = 0;
      let verifiedCount = 0;
      let pendingCount = 0;
      let rejectedCount = 0;
      const categoryBreakdown: Record<string, number> = {
        IDENTIFICATION: 0,
        ACADEMIC: 0,
        MEDICAL: 0,
        LEGAL_GUARDIANSHIP: 0,
        IDENTITY_PHOTOS: 0,
        OTHER: 0
      };

      // Mandatory compliance tracking
      let studentsWithMandatoryComplete = 0;
      const totalStudents = database.studentProfiles.length;

      for (const student of database.studentProfiles) {
        const docs = student.documents || [];
        let hasIdentification = false;
        let hasAcademic = false;

        for (const doc of docs) {
          totalDocuments++;
          const status = (doc.verificationStatus || 'PENDING_VERIFICATION').toUpperCase();
          if (status === 'VERIFIED') verifiedCount++;
          else if (status === 'REJECTED') rejectedCount++;
          else pendingCount++;

          const cat = (doc.category || 'OTHER').toUpperCase();
          categoryBreakdown[cat] = (categoryBreakdown[cat] || 0) + 1;

          if (cat === 'IDENTIFICATION' && status === 'VERIFIED') hasIdentification = true;
          if (cat === 'ACADEMIC' && status === 'VERIFIED') hasAcademic = true;
        }

        if (hasIdentification && hasAcademic) {
          studentsWithMandatoryComplete++;
        }
      }

      const mandatoryComplianceRate = totalStudents > 0
        ? Math.round((studentsWithMandatoryComplete / totalStudents) * 100)
        : 100;

      const stats: StudentDocumentStats = {
        totalDocuments,
        verifiedCount,
        pendingCount,
        rejectedCount,
        mandatoryComplianceRate,
        categoryBreakdown
      };

      res.json({
        success: true,
        data: stats
      });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to retrieve document statistics' });
    }
  }
);

/**
 * GET /api/documents-idcards/compliance-checklist
 * Class-wise and student-wise compliance audit for mandatory documentation
 */
documentsIdCardsRouter.get(
  '/compliance-checklist',
  requireAuth,
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      ensureCollections();
      if (req.user?.role === 'STUDENT' || req.user?.role === 'GUARDIAN') {
        res.status(403).json({ success: false, error: 'Access denied: Institutional compliance checklist is restricted to staff.' });
        return;
      }

      const { classId } = req.query as { classId?: string };

      let students = database.studentProfiles;
      const authorizedScope = getAuthorizedStudentIdsForUser(req.user);
      if (authorizedScope !== null) {
        students = students.filter(s => authorizedScope.has(s.id));
      }

      if (classId) {
        students = students.filter(s => s.classId === classId);
      }

      const checklist = students.map(student => {
        const docs = student.documents || [];
        const hasBirthCert = docs.some(d =>
          (d.category === 'IDENTIFICATION' || d.title?.toLowerCase().includes('birth')) &&
          d.verificationStatus === 'VERIFIED'
        );
        const hasTransferCert = docs.some(d =>
          (d.category === 'ACADEMIC' || d.title?.toLowerCase().includes('transfer') || d.title?.toLowerCase().includes('transcript')) &&
          d.verificationStatus === 'VERIFIED'
        );
        const hasMedical = docs.some(d =>
          (d.category === 'MEDICAL' || d.title?.toLowerCase().includes('immunization') || d.title?.toLowerCase().includes('medical')) &&
          d.verificationStatus === 'VERIFIED'
        );
        const hasPhoto = !!student.avatarUrl || docs.some(d => d.category === 'IDENTITY_PHOTOS');

        const missingRequirements: string[] = [];
        if (!hasBirthCert) missingRequirements.push('Government Birth Certificate / ID');
        if (!hasTransferCert) missingRequirements.push('Previous Transfer Certificate / Prior Transcript');
        if (!hasMedical) missingRequirements.push('Medical Clearance / Immunization Record');
        if (!hasPhoto) missingRequirements.push('Official Passport Photograph');

        let status: 'COMPLETE' | 'PARTIALLY_COMPLETE' | 'CRITICAL_MISSING' = 'COMPLETE';
        if (missingRequirements.length >= 3) {
          status = 'CRITICAL_MISSING';
        } else if (missingRequirements.length > 0) {
          status = 'PARTIALLY_COMPLETE';
        }

        const cls = database.classes.find(c => c.id === student.classId);
        const sec = database.sections.find(s => s.id === student.sectionId);

        return {
          studentId: student.id,
          studentName: student.fullName || `${student.firstName || ''} ${student.lastName || ''}`.trim(),
          admissionNumber: student.admissionNumber,
          rollNumber: student.rollNumber,
          classId: student.classId,
          className: student.className || cls?.name || 'Class',
          sectionName: student.sectionName || sec?.name || 'Section',
          totalDocuments: docs.length,
          verifiedDocuments: docs.filter(d => d.verificationStatus === 'VERIFIED').length,
          pendingDocuments: docs.filter(d => !d.verificationStatus || d.verificationStatus === 'PENDING_VERIFICATION').length,
          rejectedDocuments: docs.filter(d => d.verificationStatus === 'REJECTED').length,
          hasBirthCert,
          hasTransferCert,
          hasMedical,
          hasPhoto,
          missingRequirements,
          complianceStatus: status
        };
      });

      res.json({
        success: true,
        data: checklist,
        summary: {
          totalAudited: checklist.length,
          completeCount: checklist.filter(c => c.complianceStatus === 'COMPLETE').length,
          partialCount: checklist.filter(c => c.complianceStatus === 'PARTIALLY_COMPLETE').length,
          criticalMissingCount: checklist.filter(c => c.complianceStatus === 'CRITICAL_MISSING').length
        }
      });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to audit document compliance' });
    }
  }
);

/**
 * GET /api/documents-idcards/students/:studentId/documents
 * Retrieve all documents attached to a student profile
 */
documentsIdCardsRouter.get(
  '/students/:studentId/documents',
  requireAuth,
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      ensureCollections();
      const { studentId } = req.params;

      const student = database.studentProfiles.find(s => s.id === studentId || s.userId === studentId);
      if (!student) {
        res.status(404).json({ success: false, error: 'Student profile not found' });
        return;
      }

      // Check view authorization
      const authorizedScope = getAuthorizedStudentIdsForUser(req.user);
      if (authorizedScope !== null && !authorizedScope.has(student.id)) {
        res.status(403).json({ success: false, error: 'Access denied: You are not authorized to view documents for this student.' });
        return;
      }

      res.json({
        success: true,
        data: student.documents || []
      });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to retrieve student documents' });
    }
  }
);

/**
 * POST /api/documents-idcards/students/:studentId/documents
 * Upload / attach a new document to a student profile
 */
documentsIdCardsRouter.post(
  '/students/:studentId/documents',
  requireAuth,
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      ensureCollections();
      const { studentId } = req.params;
      const {
        title,
        name,
        category = 'OTHER',
        documentNumber,
        issuingAuthority,
        issueDate,
        expiryDate,
        fileUrl,
        fileName,
        fileType = 'application/pdf',
        fileSize = '245 KB',
        isMandatory = false
      } = req.body;

      const student = database.studentProfiles.find(s => s.id === studentId || s.userId === studentId);
      if (!student) {
        res.status(404).json({ success: false, error: 'Student profile not found' });
        return;
      }

      // Check upload authorization
      const authorizedScope = getAuthorizedStudentIdsForUser(req.user);
      if (authorizedScope !== null && !authorizedScope.has(student.id)) {
        res.status(403).json({ success: false, error: 'Access denied: You are not authorized to upload documents for this student.' });
        return;
      }

      if (!title && !name) {
        res.status(400).json({ success: false, error: 'Document title or name is required' });
        return;
      }

      const docTitle = title || name;
      const newDoc: StudentDocument = {
        id: `doc-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        studentId: student.id,
        name: docTitle,
        title: docTitle,
        type: fileType,
        category: category as StudentDocumentCategory,
        documentNumber: documentNumber || undefined,
        issuingAuthority: issuingAuthority || undefined,
        issueDate: issueDate || undefined,
        expiryDate: expiryDate || undefined,
        url: fileUrl || `https://storage.sygmate.edu/student-docs/${student.admissionNumber}_${Date.now()}.pdf`,
        fileUrl: fileUrl || `https://storage.sygmate.edu/student-docs/${student.admissionNumber}_${Date.now()}.pdf`,
        fileName: fileName || `${docTitle.toLowerCase().replace(/\s+/g, '_')}.pdf`,
        fileSize: fileSize,
        size: fileSize,
        verificationStatus: 'PENDING_VERIFICATION',
        uploadedAt: new Date().toISOString(),
        uploadedBy: req.user?.id || 'usr-admin-1',
        uploadedByRole: req.user?.role || 'SUPER_ADMIN',
        isMandatory: !!isMandatory
      };

      if (!student.documents) {
        student.documents = [];
      }
      student.documents.push(newDoc);
      student.updatedAt = new Date().toISOString();

      logAudit({
        userId: req.user?.id || 'system',
        userName: req.user?.name || 'Administrator',
        userRole: (req.user?.role as any) || 'SUPER_ADMIN',
        action: 'STUDENT_DOCUMENT_UPLOADED',
        entity: 'STUDENT_DOCUMENT',
        entityId: newDoc.id,
        details: `Uploaded '${newDoc.title}' (${newDoc.category}) for student ${student.admissionNumber}.`,
        ipAddress: req.ip
      });

      res.status(201).json({
        success: true,
        message: 'Document uploaded successfully and queued for verification',
        data: newDoc
      });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to upload document' });
    }
  }
);

/**
 * PUT /api/documents-idcards/documents/:docId/verify
 * Verification action: Approve or reject student document with remarks
 */
documentsIdCardsRouter.put(
  '/documents/:docId/verify',
  requireAuth,
  requirePermission('students.edit'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      ensureCollections();
      const { docId } = req.params;
      const { verificationStatus, remarks, rejectionReason }: StudentDocumentVerificationPayload = req.body;

      if (!['VERIFIED', 'REJECTED'].includes(verificationStatus)) {
        res.status(400).json({ success: false, error: 'Status must be either VERIFIED or REJECTED' });
        return;
      }

      if (verificationStatus === 'REJECTED' && !rejectionReason && !remarks) {
        res.status(400).json({ success: false, error: 'A rejection reason or remark is required when rejecting a document' });
        return;
      }

      // Find student and document
      let targetStudent: StudentProfile | undefined;
      let targetDoc: StudentDocument | undefined;

      for (const student of database.studentProfiles) {
        const found = (student.documents || []).find(d => d.id === docId);
        if (found) {
          targetStudent = student;
          targetDoc = found;
          break;
        }
      }

      if (!targetStudent || !targetDoc) {
        res.status(404).json({ success: false, error: 'Document not found' });
        return;
      }

      targetDoc.verificationStatus = verificationStatus;
      targetDoc.verifiedBy = req.user?.id;
      targetDoc.verifiedByName = req.user?.name || 'Authorized Verifier';
      targetDoc.verifiedAt = new Date().toISOString();
      targetDoc.verificationRemarks = remarks || undefined;
      targetDoc.rejectionReason = rejectionReason || (verificationStatus === 'REJECTED' ? remarks : undefined);

      targetStudent.updatedAt = new Date().toISOString();

      logAudit({
        userId: req.user?.id || 'system',
        userName: req.user?.name || 'Administrator',
        userRole: (req.user?.role as any) || 'SUPER_ADMIN',
        action: verificationStatus === 'VERIFIED' ? 'STUDENT_DOCUMENT_VERIFIED' : 'STUDENT_DOCUMENT_REJECTED',
        entity: 'STUDENT_DOCUMENT',
        entityId: targetDoc.id,
        details: `Document '${targetDoc.name}' for ${targetStudent.admissionNumber} marked as ${verificationStatus}. ${remarks ? `Remarks: ${remarks}` : ''}`,
        ipAddress: req.ip
      });

      res.json({
        success: true,
        message: `Document has been ${verificationStatus.toLowerCase()} successfully`,
        data: targetDoc
      });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to verify document' });
    }
  }
);

/**
 * DELETE /api/documents-idcards/students/:studentId/documents/:docId
 * Delete a document from a student profile
 */
documentsIdCardsRouter.delete(
  '/students/:studentId/documents/:docId',
  requireAuth,
  requirePermission('students.edit'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      ensureCollections();
      const { studentId, docId } = req.params;

      const student = database.studentProfiles.find(s => s.id === studentId || s.userId === studentId);
      if (!student) {
        res.status(404).json({ success: false, error: 'Student profile not found' });
        return;
      }

      const docIndex = (student.documents || []).findIndex(d => d.id === docId);
      if (docIndex === -1) {
        res.status(404).json({ success: false, error: 'Document not found' });
        return;
      }

      const deleted = student.documents!.splice(docIndex, 1)[0];
      student.updatedAt = new Date().toISOString();

      logAudit({
        userId: req.user?.id || 'system',
        userName: req.user?.name || 'Administrator',
        userRole: (req.user?.role as any) || 'SUPER_ADMIN',
        action: 'STUDENT_DOCUMENT_DELETED',
        entity: 'STUDENT_DOCUMENT',
        entityId: docId,
        details: `Deleted document '${deleted.title || deleted.name}' from student ${student.admissionNumber}.`,
        ipAddress: req.ip
      });

      res.json({
        success: true,
        message: 'Document deleted successfully',
        data: deleted
      });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to delete document' });
    }
  }
);

// -------------------------------------------------------------
// STUDENT ID CARD MANAGEMENT & GENERATION ENDPOINTS
// -------------------------------------------------------------

/**
 * GET /api/documents-idcards/id-cards
 * List generated ID cards with filters & pagination
 */
documentsIdCardsRouter.get(
  '/id-cards',
  requireAuth,
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      ensureCollections();
      const {
        search,
        classId,
        sectionId,
        status,
        templateId,
        page = '1',
        limit = '15'
      } = req.query as Record<string, string>;

      let list = [...database.studentIdCards];
      const authorizedScope = getAuthorizedStudentIdsForUser(req.user);
      if (authorizedScope !== null) {
        list = list.filter(c => authorizedScope.has(c.studentId));
      }

      // Filter by Class
      if (classId) {
        list = list.filter(c => c.classId === classId);
      }

      // Filter by Section
      if (sectionId) {
        list = list.filter(c => c.sectionId === sectionId);
      }

      // Filter by Card Status
      if (status && status !== 'ALL') {
        list = list.filter(c => c.status === status);
      }

      // Filter by Template
      if (templateId && templateId !== 'ALL') {
        list = list.filter(c => c.templateId === templateId);
      }

      // Search (student name, card number, admission number, roll number)
      if (search && search.trim()) {
        const q = search.trim().toLowerCase();
        list = list.filter(c =>
          (c.studentName && c.studentName.toLowerCase().includes(q)) ||
          (c.cardNumber && c.cardNumber.toLowerCase().includes(q)) ||
          (c.admissionNumber && c.admissionNumber.toLowerCase().includes(q)) ||
          (c.rollNumber && c.rollNumber.toLowerCase().includes(q))
        );
      }

      // Sort by newest creation/update
      list.sort((a, b) => new Date(b.updatedAt || b.createdAt).getTime() - new Date(a.updatedAt || a.createdAt).getTime());

      // Pagination
      const pageNum = Math.max(1, parseInt(page, 10) || 1);
      const limitNum = Math.max(1, parseInt(limit, 10) || 15);
      const total = list.length;
      const totalPages = Math.ceil(total / limitNum);
      const paginated = list.slice((pageNum - 1) * limitNum, pageNum * limitNum);

      res.json({
        success: true,
        data: paginated,
        total,
        page: pageNum,
        limit: limitNum,
        totalPages
      });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to list ID cards' });
    }
  }
);

/**
 * GET /api/documents-idcards/id-cards/stats
 * Summary KPI cards for ID card issuance lifecycle
 */
documentsIdCardsRouter.get(
  '/id-cards/stats',
  requireAuth,
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      ensureCollections();
      const totalStudents = database.studentProfiles.length;
      const totalCardsGenerated = database.studentIdCards.length;
      const totalCardsIssued = database.studentIdCards.filter(c => c.status === 'ISSUED').length;
      const totalCardsPrinted = database.studentIdCards.filter(c => c.status === 'PRINTED').length;
      const totalCardsBlocked = database.studentIdCards.filter(c => c.status === 'BLOCKED_LOST').length;

      // Students who do NOT have an active or printed card
      const issuedStudentIds = new Set(
        database.studentIdCards
          .filter(c => ['ISSUED', 'PRINTED', 'GENERATED'].includes(c.status))
          .map(c => c.studentId)
      );
      const pendingIssuance = database.studentProfiles.filter(s => !issuedStudentIds.has(s.id)).length;

      const stats: StudentIDCardStats = {
        totalStudents,
        totalCardsIssued,
        totalCardsPrinted,
        totalCardsGenerated,
        totalCardsBlocked,
        pendingIssuance
      };

      res.json({
        success: true,
        data: stats
      });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to retrieve ID card statistics' });
    }
  }
);

/**
 * GET /api/documents-idcards/students/:studentId/id-card
 * Get or build live preview for an individual student
 */
documentsIdCardsRouter.get(
  '/students/:studentId/id-card',
  requireAuth,
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      ensureCollections();
      const { studentId } = req.params;
      const student = database.studentProfiles.find(s => s.id === studentId || s.userId === studentId);

      if (!student) {
        res.status(404).json({ success: false, error: 'Student not found' });
        return;
      }

      let card = database.studentIdCards.find(c => c.studentId === student.id);

      const cls = database.classes.find(c => c.id === student.classId);
      const sec = database.sections.find(s => s.id === student.sectionId);
      const session = database.academicSessions.find(a => a.id === student.academicSessionId) || database.academicSessions[0];

      // If card doesn't exist yet, return a preview representation
      if (!card) {
        const cleanAdm = student.admissionNumber.replace(/[^0-9]/g, '').slice(-5) || '001';
        card = {
          id: `idc-preview-${student.id}`,
          studentId: student.id,
          studentName: student.fullName || `${student.firstName || ''} ${student.lastName || ''}`.trim(),
          admissionNumber: student.admissionNumber,
          cardNumber: `IDC-2026-${cleanAdm}`,
          templateId: 'modern-vertical',
          status: 'NOT_ISSUED',
          academicSessionId: student.academicSessionId || session?.id || 'session-2026-2027',
          academicSessionName: student.academicSessionName || session?.name || '2026-2027 Academic Year',
          classId: student.classId,
          className: student.className || cls?.name || 'Class',
          sectionId: student.sectionId,
          sectionName: student.sectionName || sec?.name || 'Section',
          rollNumber: student.rollNumber,
          bloodGroup: student.bloodGroup || 'O+',
          emergencyContact: student.emergencyContact || student.guardianPhone || '+1 (555) 019-8811',
          avatarUrl: student.avatarUrl || 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&q=80&w=256',
          issueDate: new Date().toISOString().split('T')[0],
          expiryDate: '2027-06-30',
          issuedBy: req.user?.id || 'usr-admin-1',
          issuedByName: req.user?.name || 'Administrator',
          reissueCount: 0,
          qrCodeData: `SYG:STU:${student.admissionNumber}:IDC-2026-${cleanAdm}:ACTIVE`,
          barcodeData: `2026${cleanAdm}001`,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        };
      }

      res.json({
        success: true,
        data: card
      });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to fetch student ID card' });
    }
  }
);

/**
 * POST /api/documents-idcards/generate-single
 * Generate, update, or reissue ID card for a single student
 */
documentsIdCardsRouter.post(
  '/generate-single',
  requireAuth,
  requirePermission('students.edit'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      ensureCollections();
      const {
        studentId,
        templateId = 'modern-vertical',
        expiryDate,
        customNotes,
        autoIssue = false
      } = req.body;

      const student = database.studentProfiles.find(s => s.id === studentId);
      if (!student) {
        res.status(404).json({ success: false, error: 'Student not found' });
        return;
      }

      const cls = database.classes.find(c => c.id === student.classId);
      const sec = database.sections.find(s => s.id === student.sectionId);
      const session = database.academicSessions.find(a => a.id === student.academicSessionId) || database.academicSessions[0];

      let card = database.studentIdCards.find(c => c.studentId === student.id);
      const cleanAdm = student.admissionNumber.replace(/[^0-9]/g, '').slice(-5) || '001';
      const cardNumber = `IDC-2026-${cleanAdm}`;

      if (card) {
        card.templateId = templateId;
        card.status = autoIssue ? 'ISSUED' : (card.status === 'NOT_ISSUED' ? 'GENERATED' : card.status);
        if (expiryDate) card.expiryDate = expiryDate;
        if (customNotes !== undefined) card.customNotes = customNotes;
        card.updatedAt = new Date().toISOString();
      } else {
        card = {
          id: `idc-rec-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
          studentId: student.id,
          studentName: student.fullName || `${student.firstName || ''} ${student.lastName || ''}`.trim(),
          admissionNumber: student.admissionNumber,
          cardNumber,
          templateId,
          status: autoIssue ? 'ISSUED' : 'GENERATED',
          academicSessionId: student.academicSessionId || session?.id || 'session-2026-2027',
          academicSessionName: student.academicSessionName || session?.name || '2026-2027 Academic Year',
          classId: student.classId,
          className: student.className || cls?.name || 'Class',
          sectionId: student.sectionId,
          sectionName: student.sectionName || sec?.name || 'Section',
          rollNumber: student.rollNumber,
          bloodGroup: student.bloodGroup || 'O+',
          emergencyContact: student.emergencyContact || student.guardianPhone || '+1 (555) 019-8811',
          avatarUrl: student.avatarUrl || 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&q=80&w=256',
          issueDate: new Date().toISOString().split('T')[0],
          expiryDate: expiryDate || '2027-06-30',
          issuedBy: req.user?.id || 'usr-admin-1',
          issuedByName: req.user?.name || 'Administrator',
          reissueCount: 0,
          qrCodeData: `SYG:STU:${student.admissionNumber}:${cardNumber}:ACTIVE`,
          barcodeData: `2026${cleanAdm}001`,
          customNotes: customNotes || undefined,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        };
        database.studentIdCards.push(card);
      }

      logAudit({
        userId: req.user?.id || 'system',
        userName: req.user?.name || 'Administrator',
        userRole: (req.user?.role as any) || 'SUPER_ADMIN',
        action: 'STUDENT_ID_CARD_GENERATED',
        entity: 'STUDENT_ID_CARD',
        entityId: card.id,
        details: `Generated ID card (${card.cardNumber}) for student ${student.admissionNumber} using template ${templateId}.`,
        ipAddress: req.ip
      });

      res.status(201).json({
        success: true,
        message: 'Student ID card generated successfully',
        data: card
      });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to generate ID card' });
    }
  }
);

/**
 * POST /api/documents-idcards/generate-bulk
 * Bulk generate ID cards for an entire Class, Section, or selected students
 */
documentsIdCardsRouter.post(
  '/generate-bulk',
  requireAuth,
  requirePermission('students.edit'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      ensureCollections();
      const {
        classId,
        sectionId,
        studentIds,
        templateId = 'modern-vertical',
        expiryDate = '2027-06-30'
      }: BulkIDCardGeneratePayload = req.body;

      let targetStudents = database.studentProfiles;

      if (studentIds && studentIds.length > 0) {
        targetStudents = targetStudents.filter(s => studentIds.includes(s.id));
      } else if (sectionId) {
        targetStudents = targetStudents.filter(s => s.sectionId === sectionId);
      } else if (classId) {
        targetStudents = targetStudents.filter(s => s.classId === classId);
      }

      if (targetStudents.length === 0) {
        res.status(400).json({ success: false, error: 'No matching students found for bulk generation criteria' });
        return;
      }

      let generatedCount = 0;
      let updatedCount = 0;
      const affectedCards: StudentIDCard[] = [];

      for (const student of targetStudents) {
        const cls = database.classes.find(c => c.id === student.classId);
        const sec = database.sections.find(s => s.id === student.sectionId);
        const session = database.academicSessions.find(a => a.id === student.academicSessionId) || database.academicSessions[0];

        let card = database.studentIdCards.find(c => c.studentId === student.id);
        const cleanAdm = student.admissionNumber.replace(/[^0-9]/g, '').slice(-5) || '001';
        const cardNumber = `IDC-2026-${cleanAdm}`;

        if (card) {
          // Do not overwrite blocked cards
          if (card.status === 'BLOCKED_LOST') continue;

          card.templateId = templateId;
          card.expiryDate = expiryDate;
          if (card.status === 'NOT_ISSUED') card.status = 'GENERATED';
          card.updatedAt = new Date().toISOString();
          updatedCount++;
          affectedCards.push(card);
        } else {
          card = {
            id: `idc-rec-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
            studentId: student.id,
            studentName: student.fullName || `${student.firstName || ''} ${student.lastName || ''}`.trim(),
            admissionNumber: student.admissionNumber,
            cardNumber,
            templateId,
            status: 'GENERATED',
            academicSessionId: student.academicSessionId || session?.id || 'session-2026-2027',
            academicSessionName: student.academicSessionName || session?.name || '2026-2027 Academic Year',
            classId: student.classId,
            className: student.className || cls?.name || 'Class',
            sectionId: student.sectionId,
            sectionName: student.sectionName || sec?.name || 'Section',
            rollNumber: student.rollNumber,
            bloodGroup: student.bloodGroup || 'O+',
            emergencyContact: student.emergencyContact || student.guardianPhone || '+1 (555) 019-8811',
            avatarUrl: student.avatarUrl || 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&q=80&w=256',
            issueDate: new Date().toISOString().split('T')[0],
            expiryDate,
            issuedBy: req.user?.id || 'usr-admin-1',
            issuedByName: req.user?.name || 'Administrator',
            reissueCount: 0,
            qrCodeData: `SYG:STU:${student.admissionNumber}:${cardNumber}:ACTIVE`,
            barcodeData: `2026${cleanAdm}001`,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
          };
          database.studentIdCards.push(card);
          generatedCount++;
          affectedCards.push(card);
        }
      }

      logAudit({
        userId: req.user?.id || 'system',
        userName: req.user?.name || 'Administrator',
        userRole: (req.user?.role as any) || 'SUPER_ADMIN',
        action: 'STUDENT_ID_CARDS_BULK_GENERATED',
        entity: 'STUDENT_ID_CARD',
        details: `Bulk generated ${generatedCount} new cards and updated ${updatedCount} existing cards with template ${templateId}.`,
        ipAddress: req.ip
      });

      res.json({
        success: true,
        message: `Successfully processed ${affectedCards.length} ID cards (${generatedCount} created, ${updatedCount} updated)`,
        data: {
          totalProcessed: affectedCards.length,
          generatedCount,
          updatedCount,
          cards: affectedCards
        }
      });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to process bulk ID card generation' });
    }
  }
);

/**
 * POST /api/documents-idcards/id-cards/:id/issue
 * Mark card status as ISSUED or PRINTED
 */
documentsIdCardsRouter.post(
  '/id-cards/:id/issue',
  requireAuth,
  requirePermission('students.edit'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      ensureCollections();
      const { id } = req.params;
      const { status = 'ISSUED' } = req.body;

      const card = database.studentIdCards.find(c => c.id === id);
      if (!card) {
        res.status(404).json({ success: false, error: 'ID card record not found' });
        return;
      }

      if (!['ISSUED', 'PRINTED'].includes(status)) {
        res.status(400).json({ success: false, error: 'Status must be ISSUED or PRINTED' });
        return;
      }

      card.status = status;
      card.updatedAt = new Date().toISOString();

      logAudit({
        userId: req.user?.id || 'system',
        userName: req.user?.name || 'Administrator',
        userRole: (req.user?.role as any) || 'SUPER_ADMIN',
        action: `STUDENT_ID_CARD_${status}`,
        entity: 'STUDENT_ID_CARD',
        entityId: card.id,
        details: `Student ID card ${card.cardNumber} marked as ${status}.`,
        ipAddress: req.ip
      });

      res.json({
        success: true,
        message: `ID card status updated to ${status}`,
        data: card
      });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to update card status' });
    }
  }
);

/**
 * POST /api/documents-idcards/id-cards/:id/reissue
 * Reissue card due to loss, damage, or details update
 */
documentsIdCardsRouter.post(
  '/id-cards/:id/reissue',
  requireAuth,
  requirePermission('students.edit'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      ensureCollections();
      const { id } = req.params;
      const { reason, markIssued = true } = req.body;

      if (!reason || !reason.trim()) {
        res.status(400).json({ success: false, error: 'A specific reissue reason is required' });
        return;
      }

      const card = database.studentIdCards.find(c => c.id === id);
      if (!card) {
        res.status(404).json({ success: false, error: 'ID card record not found' });
        return;
      }

      const prevCardNumber = card.cardNumber;
      card.reissueCount = (card.reissueCount || 0) + 1;

      if (!card.reissueHistory) {
        card.reissueHistory = [];
      }
      card.reissueHistory.push({
        reissueDate: new Date().toISOString(),
        reason: reason.trim(),
        reissuedBy: req.user?.id || 'usr-admin-1',
        reissuedByName: req.user?.name || 'Administrator',
        previousCardNumber: prevCardNumber
      });

      // Generate new card serial number with -R suffix
      const baseClean = prevCardNumber.split('-R')[0];
      card.cardNumber = `${baseClean}-R${card.reissueCount}`;
      card.status = markIssued ? 'ISSUED' : 'GENERATED';
      card.issueDate = new Date().toISOString().split('T')[0];
      card.blockedReason = undefined;
      card.blockedAt = undefined;
      card.blockedBy = undefined;
      card.qrCodeData = `SYG:STU:${card.admissionNumber}:${card.cardNumber}:ACTIVE`;
      card.updatedAt = new Date().toISOString();

      logAudit({
        userId: req.user?.id || 'system',
        userName: req.user?.name || 'Administrator',
        userRole: (req.user?.role as any) || 'SUPER_ADMIN',
        action: 'STUDENT_ID_CARD_REISSUED',
        entity: 'STUDENT_ID_CARD',
        entityId: card.id,
        details: `Reissued card for ${card.admissionNumber} (${prevCardNumber} -> ${card.cardNumber}). Reason: ${reason}`,
        ipAddress: req.ip
      });

      res.json({
        success: true,
        message: `ID card reissued successfully. New card number: ${card.cardNumber}`,
        data: card
      });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to reissue card' });
    }
  }
);

/**
 * POST /api/documents-idcards/id-cards/:id/block
 * Block / Invalidate lost or compromised ID card
 */
documentsIdCardsRouter.post(
  '/id-cards/:id/block',
  requireAuth,
  requirePermission('students.edit'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      ensureCollections();
      const { id } = req.params;
      const { reason } = req.body;

      if (!reason || !reason.trim()) {
        res.status(400).json({ success: false, error: 'Reason for blocking card is required' });
        return;
      }

      const card = database.studentIdCards.find(c => c.id === id);
      if (!card) {
        res.status(404).json({ success: false, error: 'ID card record not found' });
        return;
      }

      card.status = 'BLOCKED_LOST';
      card.blockedReason = reason.trim();
      card.blockedAt = new Date().toISOString();
      card.blockedBy = req.user?.id;
      card.qrCodeData = `SYG:STU:${card.admissionNumber}:${card.cardNumber}:BLOCKED`;
      card.updatedAt = new Date().toISOString();

      logAudit({
        userId: req.user?.id || 'system',
        userName: req.user?.name || 'Administrator',
        userRole: (req.user?.role as any) || 'SUPER_ADMIN',
        action: 'STUDENT_ID_CARD_BLOCKED',
        entity: 'STUDENT_ID_CARD',
        entityId: card.id,
        details: `Blocked ID card ${card.cardNumber} for ${card.admissionNumber}. Reason: ${reason}`,
        ipAddress: req.ip
      });

      res.json({
        success: true,
        message: 'ID card has been blocked and marked as invalid in campus scanners',
        data: card
      });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to block card' });
    }
  }
);

/**
 * GET /api/documents-idcards/templates
 * Retrieve customizable card templates
 */
documentsIdCardsRouter.get(
  '/templates',
  requireAuth,
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      ensureCollections();
      res.json({
        success: true,
        data: database.studentIdCardTemplates
      });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to retrieve templates' });
    }
  }
);

/**
 * PUT /api/documents-idcards/templates/:id
 * Update template preferences
 */
documentsIdCardsRouter.put(
  '/templates/:id',
  requireAuth,
  requirePermission('settings.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      ensureCollections();
      const { id } = req.params;
      const tIndex = database.studentIdCardTemplates.findIndex(t => t.id === id);

      if (tIndex === -1) {
        res.status(404).json({ success: false, error: 'Template not found' });
        return;
      }

      database.studentIdCardTemplates[tIndex] = {
        ...database.studentIdCardTemplates[tIndex],
        ...req.body,
        id
      };

      logAudit({
        userId: req.user?.id || 'system',
        userName: req.user?.name || 'Administrator',
        userRole: (req.user?.role as any) || 'SUPER_ADMIN',
        action: 'ID_CARD_TEMPLATE_UPDATED',
        entity: 'SETTINGS',
        entityId: id,
        details: `Updated ID card template configuration for '${database.studentIdCardTemplates[tIndex].name}'.`,
        ipAddress: req.ip
      });

      res.json({
        success: true,
        message: 'Template settings updated successfully',
        data: database.studentIdCardTemplates[tIndex]
      });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to update template' });
    }
  }
);

/**
 * GET /api/documents-idcards/verify-card/:tokenOrAdmissionNo
 * Public / Gatekeeper digital scan verification endpoint
 */
documentsIdCardsRouter.get(
  '/verify-card/:tokenOrAdmissionNo',
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      ensureCollections();
      const { tokenOrAdmissionNo } = req.params;
      const clean = (tokenOrAdmissionNo || '').trim().toLowerCase();

      // Check against card number, admission number, or qrCodeData token
      const card = database.studentIdCards.find(c =>
        c.cardNumber.toLowerCase() === clean ||
        c.admissionNumber.toLowerCase() === clean ||
        c.qrCodeData.toLowerCase().includes(clean)
      );

      if (!card) {
        // Fallback: check student profile
        const student = database.studentProfiles.find(s =>
          s.admissionNumber.toLowerCase() === clean
        );
        if (!student) {
          res.status(404).json({
            success: false,
            valid: false,
            verificationStatus: 'NOT_FOUND',
            message: 'No student or registered institutional badge found matching this token'
          });
          return;
        }

        res.json({
          success: true,
          valid: false,
          verificationStatus: 'CARD_NOT_ISSUED',
          message: 'Student record exists but no physical ID card has been issued yet',
          student: {
            name: student.fullName || `${student.firstName} ${student.lastName}`,
            admissionNumber: student.admissionNumber,
            className: student.className,
            status: student.status
          }
        });
        return;
      }

      const student = database.studentProfiles.find(s => s.id === card.studentId);
      const isExpired = new Date(card.expiryDate) < new Date();
      const isBlocked = card.status === 'BLOCKED_LOST';
      const isValid = card.status === 'ISSUED' && !isExpired && !isBlocked;

      let gateStatus: 'VALID_ACCESS' | 'BLOCKED_CARD' | 'EXPIRED_CARD' | 'UNISSUED_CARD' = 'VALID_ACCESS';
      if (isBlocked) gateStatus = 'BLOCKED_CARD';
      else if (isExpired) gateStatus = 'EXPIRED_CARD';
      else if (card.status !== 'ISSUED') gateStatus = 'UNISSUED_CARD';

      res.json({
        success: true,
        valid: isValid,
        verificationStatus: gateStatus,
        message: isValid
          ? 'Identity badge successfully verified. Campus access granted.'
          : (isBlocked
              ? `SECURITY ALERT: This card has been reported LOST or BLOCKED (${card.blockedReason || 'Unauthorized'}). Detain or report card.`
              : (isExpired ? 'Card has expired. Please renew at Registrar Office.' : `Card is not active (Status: ${card.status})`)),
        card: {
          cardNumber: card.cardNumber,
          status: card.status,
          issueDate: card.issueDate,
          expiryDate: card.expiryDate,
          blockedReason: card.blockedReason,
          reissueCount: card.reissueCount
        },
        student: {
          id: card.studentId,
          name: card.studentName || student?.fullName,
          admissionNumber: card.admissionNumber,
          rollNumber: card.rollNumber,
          className: card.className,
          sectionName: card.sectionName,
          bloodGroup: card.bloodGroup,
          emergencyContact: card.emergencyContact,
          avatarUrl: card.avatarUrl || student?.avatarUrl,
          enrollmentStatus: student?.enrollmentStatus || 'active'
        }
      });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Verification failed' });
    }
  }
);
