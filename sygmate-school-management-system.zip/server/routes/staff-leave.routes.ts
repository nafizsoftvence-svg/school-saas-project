/**
 * Sygmate School Management System
 * Staff Leave Policy, Balance Engine & Approval Workflow Router (Part 12C)
 * API Router: /api/staff/leaves
 */

import { Router, Response } from 'express';
import { requireAuth, requirePermission, AuthenticatedRequest } from '../security/auth.js';
import { staffLeaveService } from '../services/staff-leave.service.js';
import { database } from '../db/database.js';
import {
  StaffLeaveBalancesQuery,
  StaffLeaveLedgerQuery,
  CreateStaffLeavePolicyPayload,
  UpdateStaffLeavePolicyPayload,
  StaffLeaveApplicationPayload,
  ReviewStaffLeavePayload,
  AdjustStaffLeaveBalancePayload,
  CarryForwardProcessPayload
} from '../../src/types/index.js';

export const staffLeaveRouter = Router();

// =========================================================================
// 1. LEAVE POLICIES MANAGEMENT
// =========================================================================

/**
 * GET /api/staff/leaves/policies
 * List all leave policies for an academic session
 */
staffLeaveRouter.get(
  '/policies',
  requireAuth,
  requirePermission('staff.leaves.policy.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const sessionId = req.query.academicSessionId as string;
      const policies = staffLeaveService.getPolicies(sessionId);
      res.json({
        success: true,
        data: policies
      });
    } catch (err: any) {
      res.status(500).json({
        success: false,
        error: err.message || 'Failed to retrieve leave policies.',
        code: 'LEAVE_POLICY_QUERY_ERROR'
      });
    }
  }
);

/**
 * POST /api/staff/leaves/policies
 * Create a new staff leave policy
 */
staffLeaveRouter.post(
  '/policies',
  requireAuth,
  requirePermission('staff.leaves.policy.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const payload = req.body as CreateStaffLeavePolicyPayload;
      const policy = staffLeaveService.createPolicy(payload, req.user!);
      res.status(201).json({
        success: true,
        data: policy,
        message: `Leave policy '${policy.name}' created successfully.`
      });
    } catch (err: any) {
      res.status(400).json({
        success: false,
        error: err.message || 'Failed to create leave policy.',
        code: 'LEAVE_POLICY_CREATE_ERROR'
      });
    }
  }
);

/**
 * PUT /api/staff/leaves/policies/:id
 * Update an existing staff leave policy
 */
staffLeaveRouter.put(
  '/policies/:id',
  requireAuth,
  requirePermission('staff.leaves.policy.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const payload = req.body as UpdateStaffLeavePolicyPayload;
      const updated = staffLeaveService.updatePolicy(req.params.id, payload, req.user!);
      res.json({
        success: true,
        data: updated,
        message: `Leave policy '${updated.name}' updated successfully.`
      });
    } catch (err: any) {
      res.status(400).json({
        success: false,
        error: err.message || 'Failed to update leave policy.',
        code: 'LEAVE_POLICY_UPDATE_ERROR'
      });
    }
  }
);

/**
 * DELETE /api/staff/leaves/policies/:id
 * Delete a staff leave policy
 */
staffLeaveRouter.delete(
  '/policies/:id',
  requireAuth,
  requirePermission('staff.leaves.policy.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      staffLeaveService.deletePolicy(req.params.id, req.user!);
      res.json({
        success: true,
        message: 'Leave policy deleted successfully.'
      });
    } catch (err: any) {
      res.status(400).json({
        success: false,
        error: err.message || 'Failed to delete leave policy.',
        code: 'LEAVE_POLICY_DELETE_ERROR'
      });
    }
  }
);

// =========================================================================
// 2. AUTHORITATIVE LEAVE BALANCES
// =========================================================================

/**
 * GET /api/staff/leaves/balances
 * Query all staff leave balances with filters, search, and summary metrics
 */
staffLeaveRouter.get(
  '/balances',
  requireAuth,
  requirePermission('staff.leaves.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const query: StaffLeaveBalancesQuery = {
        academicSessionId: req.query.academicSessionId as string,
        departmentId: req.query.departmentId as string,
        staffType: req.query.staffType as string,
        leaveTypeId: req.query.leaveTypeId as string,
        search: req.query.search as string,
        page: req.query.page ? Number(req.query.page) : 1,
        limit: req.query.limit ? Number(req.query.limit) : 25
      };

      const result = staffLeaveService.getAllStaffBalances(query);
      res.json({
        success: true,
        data: result
      });
    } catch (err: any) {
      res.status(500).json({
        success: false,
        error: err.message || 'Failed to retrieve staff leave balances.',
        code: 'LEAVE_BALANCES_QUERY_ERROR'
      });
    }
  }
);

/**
 * GET /api/staff/leaves/my-balances
 * Balances for the currently authenticated staff or teacher
 */
staffLeaveRouter.get(
  '/my-balances',
  requireAuth,
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const sessionId = req.query.academicSessionId as string;
      const balances = staffLeaveService.getStaffBalancesForUser(req.user!.id, sessionId);
      res.json({
        success: true,
        data: balances
      });
    } catch (err: any) {
      res.status(500).json({
        success: false,
        error: err.message || 'Failed to retrieve personal leave balances.',
        code: 'MY_BALANCES_QUERY_ERROR'
      });
    }
  }
);

/**
 * GET /api/staff/leaves/staff/:staffId/balances
 * Balances for a specific staff member
 */
staffLeaveRouter.get(
  '/staff/:staffId/balances',
  requireAuth,
  requirePermission('staff.leaves.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const sessionId = req.query.academicSessionId as string;
      const balances = staffLeaveService.getStaffLeaveBalancesForStaff(req.params.staffId, sessionId);
      res.json({
        success: true,
        data: balances
      });
    } catch (err: any) {
      res.status(500).json({
        success: false,
        error: err.message || 'Failed to retrieve staff leave balances.',
        code: 'STAFF_BALANCES_ERROR'
      });
    }
  }
);

// =========================================================================
// 3. PRE-SUBMISSION VALIDATION & WORKING DAYS CALCULATION
// =========================================================================

/**
 * POST /api/staff/leaves/validate
 * Calculate working days excluding holidays/weekends and validate policies/balance
 */
staffLeaveRouter.post(
  '/validate',
  requireAuth,
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const { staffId, leaveTypeId, startDate, endDate, attachmentUrl, allowBalanceOverride } = req.body;
      if (!startDate || !leaveTypeId) {
        res.status(400).json({
          success: false,
          error: 'Start Date and Leave Type are required for validation.',
          code: 'VALIDATION_PARAMS_MISSING'
        });
        return;
      }

      let resolvedStaffId = staffId;
      if (!resolvedStaffId) {
        const staff = (database.staffProfiles || []).find((s) => s.userId === req.user!.id);
        resolvedStaffId = staff?.id;
      }

      if (!resolvedStaffId) {
        res.status(400).json({
          success: false,
          error: 'Could not resolve target staff profile for validation.',
          code: 'STAFF_NOT_RESOLVED'
        });
        return;
      }

      const validation = staffLeaveService.validateLeaveApplication(
        resolvedStaffId,
        leaveTypeId,
        startDate,
        endDate || startDate,
        attachmentUrl,
        allowBalanceOverride
      );

      res.json({
        success: true,
        data: validation
      });
    } catch (err: any) {
      res.status(400).json({
        success: false,
        error: err.message || 'Leave validation failed.',
        code: 'LEAVE_VALIDATION_ERROR'
      });
    }
  }
);

// =========================================================================
// 4. TRANSACTION LEDGER & ADMINISTRATIVE ADJUSTMENTS
// =========================================================================

/**
 * GET /api/staff/leaves/ledger
 * Query authoritative transaction ledger
 */
staffLeaveRouter.get(
  '/ledger',
  requireAuth,
  requirePermission('staff.leaves.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const query: StaffLeaveLedgerQuery = {
        academicSessionId: req.query.academicSessionId as string,
        staffId: req.query.staffId as string,
        leaveTypeId: req.query.leaveTypeId as string,
        transactionType: req.query.transactionType as any,
        startDate: req.query.startDate as string,
        endDate: req.query.endDate as string,
        search: req.query.search as string,
        page: req.query.page ? Number(req.query.page) : 1,
        limit: req.query.limit ? Number(req.query.limit) : 25
      };

      const result = staffLeaveService.getLedger(query);
      res.json({
        success: true,
        data: result
      });
    } catch (err: any) {
      res.status(500).json({
        success: false,
        error: err.message || 'Failed to retrieve leave ledger.',
        code: 'LEDGER_QUERY_ERROR'
      });
    }
  }
);

/**
 * POST /api/staff/leaves/adjust
 * Execute an administrative leave balance adjustment
 */
staffLeaveRouter.post(
  '/adjust',
  requireAuth,
  requirePermission('staff.leaves.adjust'),
  async (req: AuthenticatedRequest, res: Response): Promise<void> => {
    try {
      const payload = req.body as AdjustStaffLeaveBalancePayload;
      const transaction = await staffLeaveService.adjustStaffBalance(payload, req.user!);
      res.status(201).json({
        success: true,
        data: transaction,
        message: `Leave balance adjustment recorded successfully. Reference: ${transaction.id}`
      });
    } catch (err: any) {
      res.status(400).json({
        success: false,
        error: err.message || 'Failed to record leave adjustment.',
        code: 'ADJUSTMENT_ERROR'
      });
    }
  }
);

/**
 * POST /api/staff/leaves/carry-forward
 * Execute automated session carry-forward calculation
 */
staffLeaveRouter.post(
  '/carry-forward',
  requireAuth,
  requirePermission('staff.leaves.carry_forward'),
  async (req: AuthenticatedRequest, res: Response): Promise<void> => {
    try {
      const payload = req.body as CarryForwardProcessPayload;
      const result = await staffLeaveService.runCarryForward(payload, req.user!);
      res.json({
        success: true,
        data: result,
        message: `Carry-forward processed: ${result.processedCount} records updated (${result.totalDaysCarried} total days carried), ${result.skippedCount} skipped.`
      });
    } catch (err: any) {
      res.status(400).json({
        success: false,
        error: err.message || 'Carry-forward processing failed.',
        code: 'CARRY_FORWARD_ERROR'
      });
    }
  }
);

// =========================================================================
// 5. LEAVE APPLICATIONS & APPROVAL WORKFLOW
// =========================================================================

/**
 * GET /api/staff/leaves
 * Query leave applications with role-based scoping and filters
 */
staffLeaveRouter.get(
  '/',
  requireAuth,
  requirePermission('staff.leaves.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const user = req.user!;
      const isSuperAdmin = user.role === 'SUPER_ADMIN';
      const staffProfile = (database.staffProfiles || []).find((s) => s.userId === user.id);

      let applications = (database.leaveApplications || []).filter(
        (l) => l.applicantType === 'STAFF' || l.applicantType === 'TEACHER'
      );

      // Enrich with staff directory data if missing
      applications = applications.map((app) => {
        const staff = (database.staffProfiles || []).find(
          (s) => s.id === app.staffId || s.id === app.applicantId || s.teacherProfileId === app.applicantId || s.userId === app.userId
        );
        const dept = staff?.departmentId
          ? (database.departments || []).find((d) => d.id === staff.departmentId)
          : undefined;

        return {
          ...app,
          staffId: app.staffId || staff?.id || app.applicantId,
          staffName: app.staffName || staff?.fullName || app.applicantName,
          applicantName: app.applicantName || staff?.fullName || 'Staff Member',
          employeeCode: app.employeeCode || staff?.employeeCode || 'N/A',
          departmentId: app.departmentId || staff?.departmentId,
          departmentName: app.departmentName || dept?.name || staff?.departmentName || 'General',
          staffType: app.staffType || staff?.staffType || (app.applicantType === 'TEACHER' ? 'teaching' : 'administrative')
        };
      });

      // Role-based scoping: regular employees only see their own requests unless admin or approver
      if (!isSuperAdmin && !(user as any).permissions?.includes('staff.leaves.review')) {
        applications = applications.filter(
          (l) => l.userId === user.id || (staffProfile && l.staffId === staffProfile.id)
        );
      }

      // Filter by status
      if (req.query.status && req.query.status !== 'ALL') {
        const targetStatus = (req.query.status as string).toUpperCase();
        applications = applications.filter((l) => l.status === targetStatus);
      }

      // Filter by department
      if (req.query.departmentId && req.query.departmentId !== 'ALL') {
        applications = applications.filter((l) => l.departmentId === req.query.departmentId);
      }

      // Filter by staff type
      if (req.query.staffType && req.query.staffType !== 'ALL') {
        applications = applications.filter((l) => l.staffType === req.query.staffType);
      }

      // Search
      if (req.query.search) {
        const q = (req.query.search as string).toLowerCase().trim();
        applications = applications.filter(
          (l) =>
            l.applicantName.toLowerCase().includes(q) ||
            (l.employeeCode || '').toLowerCase().includes(q) ||
            (l.leaveTypeName || '').toLowerCase().includes(q) ||
            (l.reason || '').toLowerCase().includes(q)
        );
      }

      // Sort descending by applied date
      applications.sort((a, b) => (b.createdAt || b.startDate).localeCompare(a.createdAt || a.startDate));

      res.json({
        success: true,
        data: applications
      });
    } catch (err: any) {
      res.status(500).json({
        success: false,
        error: err.message || 'Failed to retrieve staff leave applications.',
        code: 'STAFF_LEAVE_QUERY_ERROR'
      });
    }
  }
);

/**
 * POST /api/staff/leaves
 * Submit a staff leave application with policy validation
 */
staffLeaveRouter.post(
  '/',
  requireAuth,
  requirePermission('staff.leaves.view'),
  async (req: AuthenticatedRequest, res: Response): Promise<void> => {
    try {
      const payload = req.body as StaffLeaveApplicationPayload;
      const leave = await staffLeaveService.applyStaffLeave(payload, req.user!);
      res.status(201).json({
        success: true,
        data: leave,
        message: 'Leave application submitted successfully for review.'
      });
    } catch (err: any) {
      res.status(400).json({
        success: false,
        error: err.message || 'Failed to submit staff leave application.',
        code: 'STAFF_LEAVE_SUBMIT_ERROR'
      });
    }
  }
);

/**
 * PUT /api/staff/leaves/:id/review
 * Multi-tier review, self-approval check, ledger deduction, and attendance sync
 */
staffLeaveRouter.put(
  '/:id/review',
  requireAuth,
  requirePermission('staff.leaves.review'),
  async (req: AuthenticatedRequest, res: Response): Promise<void> => {
    try {
      const payload = req.body as ReviewStaffLeavePayload;
      const updated = await staffLeaveService.reviewStaffLeave(req.params.id, payload, req.user!);
      res.json({
        success: true,
        data: updated,
        message: `Leave application successfully updated to status '${updated.status}'.`
      });
    } catch (err: any) {
      res.status(400).json({
        success: false,
        error: err.message || 'Failed to review leave application.',
        code: 'STAFF_LEAVE_REVIEW_ERROR'
      });
    }
  }
);

/**
 * POST /api/staff/leaves/:id/cancel
 * Cancel an approved or pending leave application with ledger reversal
 */
staffLeaveRouter.post(
  '/:id/cancel',
  requireAuth,
  async (req: AuthenticatedRequest, res: Response): Promise<void> => {
    try {
      const reason = req.body.reason || 'Staff leave cancellation requested.';
      const cancelled = await staffLeaveService.cancelStaffLeave(req.params.id, reason, req.user!);
      res.json({
        success: true,
        data: cancelled,
        message: 'Leave application cancelled and balances/attendance reversed successfully.'
      });
    } catch (err: any) {
      res.status(400).json({
        success: false,
        error: err.message || 'Failed to cancel leave application.',
        code: 'STAFF_LEAVE_CANCEL_ERROR'
      });
    }
  }
);

// =========================================================================
// 6. REPORTS & EXPORTS
// =========================================================================

/**
 * GET /api/staff/leaves/reports/summary
 * Leave analytics, departmental breakdown, and approval stats
 */
staffLeaveRouter.get(
  '/reports/summary',
  requireAuth,
  requirePermission('staff.leaves.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const sessionId = req.query.academicSessionId as string;
      const summary = staffLeaveService.getStaffLeaveReportsSummary(sessionId);
      res.json({
        success: true,
        data: summary
      });
    } catch (err: any) {
      res.status(500).json({
        success: false,
        error: err.message || 'Failed to generate leave reports summary.',
        code: 'LEAVE_REPORTS_ERROR'
      });
    }
  }
);

/**
 * GET /api/staff/leaves/export/balances
 * Export staff leave balances as CSV
 */
staffLeaveRouter.get(
  '/export/balances',
  requireAuth,
  requirePermission('staff.leaves.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const query: StaffLeaveBalancesQuery = {
        academicSessionId: req.query.academicSessionId as string,
        departmentId: req.query.departmentId as string,
        staffType: req.query.staffType as string,
        leaveTypeId: req.query.leaveTypeId as string,
        search: req.query.search as string
      };

      const csv = staffLeaveService.exportStaffLeaveBalancesCSV(query);
      const filename = `staff-leave-balances-${new Date().toISOString().split('T')[0]}.csv`;

      res.setHeader('Content-Type', 'text/csv; charset=utf-8');
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      res.send(csv);
    } catch (err: any) {
      res.status(500).json({
        success: false,
        error: err.message || 'Failed to export balances.',
        code: 'EXPORT_ERROR'
      });
    }
  }
);
