/**
 * Sygmate School Management System
 * Staff & Human Resource Management Foundation (Part 12A)
 * API Router: /api/staff
 */

import { Router, Response } from 'express';
import { requireAuth, requirePermission, AuthenticatedRequest } from '../security/auth.js';
import { staffService } from '../services/staff.service.ts';
import {
  CreateStaffPayload,
  UpdateStaffPayload,
  ChangeStaffStatusPayload,
  UploadStaffDocumentPayload,
  VerifyStaffDocumentPayload,
  CreateDesignationPayload,
  UpdateDesignationPayload,
  StaffDirectoryQuery
} from '../../src/types/index.js';
import {
  staffAttendanceRouter,
  staffScheduleRouter
} from './staff-attendance.routes.js';
import { staffLeaveRouter } from './staff-leave.routes.js';
import {
  staffRecruitmentRouter,
  staffOnboardingRouter
} from './staff-recruitment.routes.js';
import { staffPerformanceRouter } from './staff-performance.routes.js';
import { staffReportsRouter } from './staff-reports.routes.js';

export const staffRouter = Router();

// Sub-routers for Staff Attendance, Work Schedules, Leaves, Recruitment, Onboarding, Performance & Reports (Parts 12B-12F)
staffRouter.use('/attendance', staffAttendanceRouter);
staffRouter.use('/schedules', staffScheduleRouter);
staffRouter.use('/leaves', staffLeaveRouter);
staffRouter.use('/recruitment', staffRecruitmentRouter);
staffRouter.use('/onboarding', staffOnboardingRouter);
staffRouter.use('/performance', staffPerformanceRouter);
staffRouter.use('/reports', staffReportsRouter);

/**
 * GET /api/staff
 * Staff Directory Query with server-side filters, search, sorting & pagination
 */
staffRouter.get(
  '/',
  requireAuth,
  requirePermission('staff.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const query: StaffDirectoryQuery = {
        search: req.query.search as string,
        staffType: req.query.staffType as string,
        departmentId: req.query.departmentId as string,
        designationId: req.query.designationId as string,
        employmentStatus: req.query.employmentStatus as string,
        employmentType: req.query.employmentType as string,
        gender: req.query.gender as string,
        page: req.query.page ? Number(req.query.page) : 1,
        limit: req.query.limit ? Number(req.query.limit) : 10,
        sortBy: req.query.sortBy as any,
        sortOrder: req.query.sortOrder as any
      };

      const result = staffService.getStaffDirectory(query);
      res.json({
        success: true,
        data: result
      });
    } catch (err: any) {
      console.error('[Staff Directory API Error]:', err);
      res.status(500).json({
        success: false,
        error: err.message || 'Failed to retrieve staff directory.',
        code: 'STAFF_QUERY_ERROR'
      });
    }
  }
);

/**
 * GET /api/staff/stats
 * Aggregate HR statistics, demographics & recent joiners
 */
staffRouter.get(
  '/stats',
  requireAuth,
  requirePermission('staff.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const stats = staffService.getStaffStats();
      res.json({
        success: true,
        data: stats
      });
    } catch (err: any) {
      console.error('[Staff Stats API Error]:', err);
      res.status(500).json({
        success: false,
        error: err.message || 'Failed to calculate staff statistics.',
        code: 'STAFF_STATS_ERROR'
      });
    }
  }
);

/**
 * GET /api/staff/export
 * Export filtered directory to CSV format
 */
staffRouter.get(
  '/export',
  requireAuth,
  requirePermission('staff.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const query: StaffDirectoryQuery = {
        search: req.query.search as string,
        staffType: req.query.staffType as string,
        departmentId: req.query.departmentId as string,
        designationId: req.query.designationId as string,
        employmentStatus: req.query.employmentStatus as string,
        employmentType: req.query.employmentType as string,
        gender: req.query.gender as string
      };

      const csv = staffService.exportStaffToCsv(query);
      const filename = `Staff_Directory_${new Date().toISOString().split('T')[0]}.csv`;

      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      res.status(200).send(csv);
    } catch (err: any) {
      console.error('[Staff Export CSV Error]:', err);
      res.status(500).json({
        success: false,
        error: err.message || 'Failed to export staff directory.',
        code: 'STAFF_EXPORT_ERROR'
      });
    }
  }
);

/**
 * GET /api/staff/code/next
 * Get the next auto-generated employee code preview
 */
staffRouter.get(
  '/code/next',
  requireAuth,
  requirePermission('staff.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const staffType = (req.query.staffType as string) || 'teaching';
      const code = staffService.generateNextEmployeeCode(staffType);
      res.json({
        success: true,
        data: { employeeCode: code, staffType }
      });
    } catch (err: any) {
      res.status(500).json({
        success: false,
        error: err.message || 'Failed to generate code.',
        code: 'CODE_GEN_ERROR'
      });
    }
  }
);

/**
 * GET /api/staff/meta/departments
 * List departments enriched with real-time staff counts
 */
staffRouter.get(
  '/meta/departments',
  requireAuth,
  requirePermission('staff.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const depts = staffService.getDepartmentsWithStats();
      res.json({
        success: true,
        data: depts
      });
    } catch (err: any) {
      res.status(500).json({
        success: false,
        error: err.message || 'Failed to list departments.',
        code: 'DEPT_LIST_ERROR'
      });
    }
  }
);

/**
 * POST /api/staff/meta/departments
 * Create a new department
 */
staffRouter.post(
  '/meta/departments',
  requireAuth,
  requirePermission('staff.departments'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const dept = staffService.createDepartment(req.body, req.user);
      res.status(201).json({
        success: true,
        data: dept,
        message: `Department '${dept.name}' created successfully.`
      });
    } catch (err: any) {
      res.status(400).json({
        success: false,
        error: err.message || 'Failed to create department.',
        code: 'DEPT_CREATE_ERROR'
      });
    }
  }
);

/**
 * PUT /api/staff/meta/departments/:id
 * Update department metadata
 */
staffRouter.put(
  '/meta/departments/:id',
  requireAuth,
  requirePermission('staff.departments'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const dept = staffService.updateDepartment(req.params.id, req.body, req.user);
      res.json({
        success: true,
        data: dept,
        message: `Department '${dept.name}' updated successfully.`
      });
    } catch (err: any) {
      res.status(400).json({
        success: false,
        error: err.message || 'Failed to update department.',
        code: 'DEPT_UPDATE_ERROR'
      });
    }
  }
);

/**
 * DELETE /api/staff/meta/departments/:id
 * Delete or archive department (guarded against active staff dependencies)
 */
staffRouter.delete(
  '/meta/departments/:id',
  requireAuth,
  requirePermission('staff.departments'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      staffService.deleteDepartment(req.params.id, req.user);
      res.json({
        success: true,
        message: 'Department deleted successfully.'
      });
    } catch (err: any) {
      res.status(400).json({
        success: false,
        error: err.message || 'Failed to delete department.',
        code: 'DEPT_DELETE_ERROR'
      });
    }
  }
);

/**
 * GET /api/staff/meta/designations
 * List designations with optional department and type filters
 */
staffRouter.get(
  '/meta/designations',
  requireAuth,
  requirePermission('staff.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const departmentId = req.query.departmentId as string;
      const staffType = req.query.staffType as string;
      const designations = staffService.getDesignations(departmentId, staffType);
      res.json({
        success: true,
        data: designations
      });
    } catch (err: any) {
      res.status(500).json({
        success: false,
        error: err.message || 'Failed to retrieve designations.',
        code: 'DES_LIST_ERROR'
      });
    }
  }
);

/**
 * POST /api/staff/meta/designations
 * Create a new designation
 */
staffRouter.post(
  '/meta/designations',
  requireAuth,
  requirePermission('staff.designations'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const des = staffService.createDesignation(req.body as CreateDesignationPayload, req.user);
      res.status(201).json({
        success: true,
        data: des,
        message: `Designation '${des.title}' created successfully.`
      });
    } catch (err: any) {
      res.status(400).json({
        success: false,
        error: err.message || 'Failed to create designation.',
        code: 'DES_CREATE_ERROR'
      });
    }
  }
);

/**
 * PUT /api/staff/meta/designations/:id
 * Update designation
 */
staffRouter.put(
  '/meta/designations/:id',
  requireAuth,
  requirePermission('staff.designations'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const des = staffService.updateDesignation(req.params.id, req.body as UpdateDesignationPayload, req.user);
      res.json({
        success: true,
        data: des,
        message: `Designation '${des.title}' updated successfully.`
      });
    } catch (err: any) {
      res.status(400).json({
        success: false,
        error: err.message || 'Failed to update designation.',
        code: 'DES_UPDATE_ERROR'
      });
    }
  }
);

/**
 * DELETE /api/staff/meta/designations/:id
 * Delete designation
 */
staffRouter.delete(
  '/meta/designations/:id',
  requireAuth,
  requirePermission('staff.designations'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      staffService.deleteDesignation(req.params.id, req.user);
      res.json({
        success: true,
        message: 'Designation deleted successfully.'
      });
    } catch (err: any) {
      res.status(400).json({
        success: false,
        error: err.message || 'Failed to delete designation.',
        code: 'DES_DELETE_ERROR'
      });
    }
  }
);

/**
 * GET /api/staff/:id
 * Get single staff dossier
 */
staffRouter.get(
  '/:id',
  requireAuth,
  requirePermission('staff.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const staff = staffService.getStaffById(req.params.id);
      if (!staff) {
        res.status(404).json({
          success: false,
          error: `Staff profile '${req.params.id}' was not found.`,
          code: 'STAFF_NOT_FOUND'
        });
        return;
      }
      res.json({
        success: true,
        data: staff
      });
    } catch (err: any) {
      res.status(500).json({
        success: false,
        error: err.message || 'Failed to retrieve staff dossier.',
        code: 'STAFF_FETCH_ERROR'
      });
    }
  }
);

/**
 * POST /api/staff
 * Create a new staff profile
 */
staffRouter.post(
  '/',
  requireAuth,
  requirePermission('staff.create'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const newStaff = staffService.createStaff(req.body as CreateStaffPayload, req.user);
      res.status(201).json({
        success: true,
        data: newStaff,
        message: `Staff member ${newStaff.firstName} ${newStaff.lastName} (${newStaff.employeeCode}) created successfully.`
      });
    } catch (err: any) {
      res.status(400).json({
        success: false,
        error: err.message || 'Failed to create staff profile.',
        code: 'STAFF_CREATE_ERROR'
      });
    }
  }
);

/**
 * PUT /api/staff/:id
 * Update staff profile
 */
staffRouter.put(
  '/:id',
  requireAuth,
  requirePermission('staff.edit'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const updated = staffService.updateStaff(req.params.id, req.body as UpdateStaffPayload, req.user);
      res.json({
        success: true,
        data: updated,
        message: `Staff profile for ${updated.displayName} (${updated.employeeCode}) updated successfully.`
      });
    } catch (err: any) {
      res.status(400).json({
        success: false,
        error: err.message || 'Failed to update staff profile.',
        code: 'STAFF_UPDATE_ERROR'
      });
    }
  }
);

/**
 * PATCH /api/staff/:id/status
 * Transition employment status with mandatory governance audit trail
 */
staffRouter.patch(
  '/:id/status',
  requireAuth,
  requirePermission('staff.status'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const updated = staffService.changeStaffStatus(
        req.params.id,
        req.body as ChangeStaffStatusPayload,
        req.user
      );
      res.json({
        success: true,
        data: updated,
        message: `Employment status transitioned to '${updated.employmentStatus}'.`
      });
    } catch (err: any) {
      res.status(400).json({
        success: false,
        error: err.message || 'Failed to change staff status.',
        code: 'STATUS_CHANGE_ERROR'
      });
    }
  }
);

/**
 * POST /api/staff/:id/documents
 * Attach and upload staff credential document
 */
staffRouter.post(
  '/:id/documents',
  requireAuth,
  requirePermission('staff.documents'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const doc = staffService.uploadStaffDocument(
        req.params.id,
        req.body as UploadStaffDocumentPayload,
        req.user
      );
      res.status(201).json({
        success: true,
        data: doc,
        message: `Document '${doc.title}' uploaded successfully.`
      });
    } catch (err: any) {
      res.status(400).json({
        success: false,
        error: err.message || 'Failed to upload staff document.',
        code: 'DOC_UPLOAD_ERROR'
      });
    }
  }
);

/**
 * DELETE /api/staff/:id/documents/:docId
 * Delete staff credential document
 */
staffRouter.delete(
  '/:id/documents/:docId',
  requireAuth,
  requirePermission('staff.documents'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      staffService.deleteStaffDocument(req.params.id, req.params.docId, req.user);
      res.json({
        success: true,
        message: 'Document deleted successfully.'
      });
    } catch (err: any) {
      res.status(400).json({
        success: false,
        error: err.message || 'Failed to delete document.',
        code: 'DOC_DELETE_ERROR'
      });
    }
  }
);

/**
 * PATCH /api/staff/:id/documents/:docId/verify
 * Verify or reject staff document
 */
staffRouter.patch(
  '/:id/documents/:docId/verify',
  requireAuth,
  requirePermission('staff.documents'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const doc = staffService.verifyStaffDocument(
        req.params.id,
        req.params.docId,
        req.body as VerifyStaffDocumentPayload,
        req.user
      );
      res.json({
        success: true,
        data: doc,
        message: `Document verification status updated to '${doc.verificationStatus}'.`
      });
    } catch (err: any) {
      res.status(400).json({
        success: false,
        error: err.message || 'Failed to update document verification.',
        code: 'DOC_VERIFY_ERROR'
      });
    }
  }
);

/**
 * POST /api/staff/:id/link-account
 * Link user account or create login credentials for staff
 */
staffRouter.post(
  '/:id/link-account',
  requireAuth,
  requirePermission('staff.edit'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const updated = staffService.linkStaffAccount(req.params.id, req.body, req.user);
      res.json({
        success: true,
        data: updated,
        message: `Account linked to staff profile ${updated.displayName}.`
      });
    } catch (err: any) {
      res.status(400).json({
        success: false,
        error: err.message || 'Failed to link account.',
        code: 'ACCOUNT_LINK_ERROR'
      });
    }
  }
);

/**
 * POST /api/staff/:id/unlink-account
 * Unlink user account from staff profile
 */
staffRouter.post(
  '/:id/unlink-account',
  requireAuth,
  requirePermission('staff.edit'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const updated = staffService.unlinkStaffAccount(req.params.id, req.user);
      res.json({
        success: true,
        data: updated,
        message: `Account unlinked from staff profile ${updated.displayName}.`
      });
    } catch (err: any) {
      res.status(400).json({
        success: false,
        error: err.message || 'Failed to unlink account.',
        code: 'ACCOUNT_UNLINK_ERROR'
      });
    }
  }
);
