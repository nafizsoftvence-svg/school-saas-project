import { Router, Response } from 'express';
import { database } from '../db/database.js';
import {
  AuthenticatedRequest,
  requireAuth,
  requireRole,
  requirePermission
} from '../security/auth.js';
import { logAudit } from '../security/audit.js';
import {
  FinancialReportDashboardStats,
  CollectionReportFilterParams,
  CollectionReportTransactionItem,
  CollectionReportResponse,
  FeeSummaryReportItem,
  FeeSummaryReportResponse,
  StudentStatementEntry,
  StudentAccountStatement,
  PaymentMethodReportResponse,
  FeePaymentReceipt
} from '../../src/types/index.js';

export const feesReportsRouter = Router();

// Ensure authenticated
feesReportsRouter.use(requireAuth);

/**
 * Helper: Find student by ID or UserID
 */
function findStudent(identifier: string) {
  return database.studentProfiles.find(
    (s) => s.id === identifier || s.userId === identifier
  );
}

/**
 * Helper: Normalize date string
 */
function normalizeDate(dStr?: string): Date | null {
  if (!dStr) return null;
  const d = new Date(dStr);
  return isNaN(d.getTime()) ? null : d;
}

// =========================================================================
// 1. FINANCIAL REPORT DASHBOARD STATS
// GET /api/fees/reports/dashboard
// =========================================================================
feesReportsRouter.get(
  '/reports/dashboard',
  requireRole('SUPER_ADMIN'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const { academicSessionId, classId } = req.query;

      // Filter fee records
      let records = database.feeRecords.filter((f) => f.status !== 'CANCELLED');
      if (academicSessionId && academicSessionId !== 'ALL') {
        records = records.filter((f) => f.academicSessionId === academicSessionId);
      }
      if (classId && classId !== 'ALL') {
        records = records.filter((f) => f.classId === classId);
      }

      // Filter transactions linked to these records or session
      let transactions = database.feeTransactions;
      if (academicSessionId && academicSessionId !== 'ALL') {
        transactions = transactions.filter((t) => t.academicSessionId === academicSessionId);
      }
      if (classId && classId !== 'ALL') {
        const studentIdsInClass = new Set(
          database.studentProfiles.filter((s) => s.classId === classId).map((s) => s.id)
        );
        transactions = transactions.filter((t) => studentIdsInClass.has(t.studentId));
      }

      const totalFeesGenerated = records.reduce((acc, f) => acc + (f.totalAmount || 0), 0);
      const totalDiscounts = records.reduce((acc, f) => acc + (f.discountAmount || 0), 0);
      const totalScholarships = records.reduce((acc, f) => acc + (f.scholarshipAmount || 0), 0);
      const totalWaivers = records.reduce((acc, f) => acc + (f.waiverAmount || 0), 0);
      const totalFines = records.reduce((acc, f) => acc + (f.fineAmount || 0), 0);
      const totalNetPayable = records.reduce((acc, f) => acc + (f.netPayableAmount || 0), 0);

      const successfulTxns = transactions.filter((t) => t.paymentStatus === 'SUCCESS');
      const reversedTxns = transactions.filter((t) => t.paymentStatus === 'REVERSED');

      const totalCollected = successfulTxns.reduce((acc, t) => acc + (t.amountPaid || 0), 0);
      const totalReversedAmount = reversedTxns.reduce((acc, t) => acc + (t.amountPaid || 0), 0);
      const totalOutstanding = records.reduce((acc, f) => acc + (f.dueAmount || 0), 0);

      // Overdue records
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const overdueRecords = records.filter((f) => {
        if (f.dueAmount <= 0) return false;
        const d = new Date(f.dueDate);
        return !isNaN(d.getTime()) && d < today;
      });
      const totalOverdue = overdueRecords.reduce((acc, f) => acc + (f.dueAmount || 0), 0);

      const allSessionRecords = database.feeRecords.filter(
        (f) => !academicSessionId || academicSessionId === 'ALL' || f.academicSessionId === academicSessionId
      );

      const invoicesCount = {
        total: allSessionRecords.length,
        paid: allSessionRecords.filter((f) => f.status === 'PAID').length,
        unpaid: allSessionRecords.filter((f) => f.status === 'UNPAID' || f.status === 'DRAFT').length,
        partiallyPaid: allSessionRecords.filter((f) => f.status === 'PARTIAL').length,
        overdue: allSessionRecords.filter((f) => f.status === 'OVERDUE').length,
        cancelled: allSessionRecords.filter((f) => f.status === 'CANCELLED').length
      };

      const transactionsCount = {
        total: transactions.length,
        successful: successfulTxns.length,
        reversed: reversedTxns.length
      };

      const collectionRate =
        totalNetPayable > 0 ? Number(((totalCollected / totalNetPayable) * 100).toFixed(2)) : 0;

      // Category breakdown
      const categoryMap = new Map<string, { generated: number; collected: number; due: number; count: number }>();
      records.forEach((rec) => {
        const typeObj = database.feeTypes.find((t) => t.name === rec.feeType || t.id === rec.feeTypeId);
        const cat = typeObj?.category || 'ACADEMIC';
        const curr = categoryMap.get(cat) || { generated: 0, collected: 0, due: 0, count: 0 };
        curr.generated += rec.netPayableAmount || 0;
        curr.collected += rec.paidAmount || 0;
        curr.due += rec.dueAmount || 0;
        curr.count += 1;
        categoryMap.set(cat, curr);
      });

      const categoryBreakdown = Array.from(categoryMap.entries()).map(([category, stats]) => ({
        category,
        generated: stats.generated,
        invoicedAmount: stats.generated,
        collected: stats.collected,
        collectedAmount: stats.collected,
        due: stats.due,
        count: stats.count
      }));

      // Monthly trends (last 6 months or based on records)
      const monthlyMap = new Map<string, { generated: number; collected: number; due: number }>();
      const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

      records.forEach((rec) => {
        const d = new Date(rec.createdAt);
        if (!isNaN(d.getTime())) {
          const key = `${monthNames[d.getMonth()]} ${d.getFullYear()}`;
          const curr = monthlyMap.get(key) || { generated: 0, collected: 0, due: 0 };
          curr.generated += rec.netPayableAmount || 0;
          curr.due += rec.dueAmount || 0;
          monthlyMap.set(key, curr);
        }
      });

      successfulTxns.forEach((tx) => {
        const d = new Date(tx.paymentDate);
        if (!isNaN(d.getTime())) {
          const key = `${monthNames[d.getMonth()]} ${d.getFullYear()}`;
          const curr = monthlyMap.get(key) || { generated: 0, collected: 0, due: 0 };
          curr.collected += tx.amountPaid || 0;
          monthlyMap.set(key, curr);
        }
      });

      const monthlyTrends = Array.from(monthlyMap.entries()).map(([month, val]) => ({
        month,
        generated: Math.round(val.generated),
        invoiced: Math.round(val.generated),
        collected: Math.round(val.collected),
        due: Math.round(val.due)
      }));

      const responseData: FinancialReportDashboardStats = {
        totalFeesGenerated,
        totalNetPayable,
        totalCollected,
        totalOutstanding,
        totalOverdue,
        totalDiscounts,
        totalScholarshipsWaivers: totalScholarships + totalWaivers,
        totalScholarships,
        totalWaivers,
        totalFines,
        totalReversedAmount,
        collectionRate,
        kpis: {
          totalFeesGenerated,
          totalNetPayable,
          totalCollected,
          totalOutstanding,
          totalOverdue,
          totalDiscounts,
          totalScholarshipsAndWaivers: totalScholarships + totalWaivers,
          totalFines,
          collectionEfficiencyRate: collectionRate
        },
        reversals: {
          count: reversedTxns.length,
          volume: totalReversedAmount
        },
        invoicesCount,
        transactionsCount,
        monthlyTrends: monthlyTrends.length > 0 ? monthlyTrends : [
          { month: 'Aug 2026', generated: totalNetPayable, invoiced: totalNetPayable, collected: totalCollected, due: totalOutstanding }
        ],
        categoryBreakdown
      };

      res.json({
        success: true,
        data: responseData
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to fetch financial report stats',
        code: 'SERVER_ERROR'
      });
    }
  }
);

// =========================================================================
// 2. COLLECTION REPORT WITH FILTERS
// GET /api/fees/reports/collections
// =========================================================================
feesReportsRouter.get(
  '/reports/collections',
  requireRole('SUPER_ADMIN'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const {
        startDate,
        endDate,
        academicSessionId,
        classId,
        sectionId,
        feeTypeId,
        paymentMethod,
        collectedBy,
        status,
        search,
        page = '1',
        limit = '25'
      } = req.query as Record<string, string>;

      const pageNum = Math.max(1, parseInt(page, 10) || 1);
      const limitNum = Math.max(1, Math.min(200, parseInt(limit, 10) || 25));

      let txns = [...database.feeTransactions];

      // 1. Session filter
      if (academicSessionId && academicSessionId !== 'ALL') {
        txns = txns.filter((t) => t.academicSessionId === academicSessionId);
      }

      // 2. Payment Method filter
      if (paymentMethod && paymentMethod !== 'ALL') {
        txns = txns.filter((t) => t.paymentMethod === paymentMethod);
      }

      // 3. Status filter (SUCCESS, REVERSED, ALL)
      if (status && status !== 'ALL') {
        txns = txns.filter((t) => t.paymentStatus === status);
      }

      // 4. Date range filter
      if (startDate) {
        const start = new Date(startDate);
        start.setHours(0, 0, 0, 0);
        txns = txns.filter((t) => new Date(t.paymentDate) >= start);
      }
      if (endDate) {
        const end = new Date(endDate);
        end.setHours(23, 59, 59, 999);
        txns = txns.filter((t) => new Date(t.paymentDate) <= end);
      }

      // 5. Collector filter
      if (collectedBy && collectedBy !== 'ALL') {
        txns = txns.filter((t) => t.collectedById === collectedBy || t.collectedByName === collectedBy);
      }

      // 6. Fee Type filter
      if (feeTypeId && feeTypeId !== 'ALL') {
        const feeTypeObj = database.feeTypes.find((ft) => ft.id === feeTypeId || ft.name === feeTypeId);
        const targetName = feeTypeObj ? feeTypeObj.name : feeTypeId;
        txns = txns.filter((t) => t.feeType === targetName);
      }

      // 7. Student / Class / Section join & filters
      const enrichedItems: CollectionReportTransactionItem[] = txns.map((t) => {
        const student = database.studentProfiles.find((s) => s.id === t.studentId || s.userId === t.studentId);
        const feeRecord = database.feeRecords.find((f) => f.id === t.feeRecordId);
        const methodObj = database.paymentMethods.find((pm) => pm.code === t.paymentMethod);

        return {
          id: t.id,
          transactionId: t.transactionId,
          receiptNumber: t.receiptNumber,
          feeRecordId: t.feeRecordId,
          invoiceNumber: feeRecord?.invoiceNumber || 'INV-NA',
          studentId: t.studentId,
          studentName: t.studentName || (student ? `${student.firstName} ${student.lastName}` : 'Unknown Student'),
          admissionNumber: student?.admissionNumber || 'N/A',
          rollNumber: student?.rollNumber || 'N/A',
          classId: student?.classId || feeRecord?.classId,
          className: student?.className || feeRecord?.className || 'N/A',
          sectionId: student?.sectionId || feeRecord?.sectionId,
          sectionName: student?.sectionName || feeRecord?.sectionName || 'N/A',
          feeType: t.feeType,
          feeTitle: t.feeTitle,
          amountPaid: t.amountPaid,
          paymentMethod: t.paymentMethod,
          paymentMethodLabel: t.paymentMethodLabel || methodObj?.name || t.paymentMethod,
          gatewayReference: t.gatewayReference,
          paymentDate: t.paymentDate,
          paymentStatus: t.paymentStatus as any,
          collectedBy: t.collectedByName,
          reversalReason: t.reversalReason,
          reversedAt: t.reversedAt,
          payerEmail: t.payerEmail,
          payerPhone: t.payerPhone,
          notes: t.notes
        };
      });

      // Filter by Class / Section
      let filtered = enrichedItems;
      if (classId && classId !== 'ALL') {
        filtered = filtered.filter((item) => item.classId === classId);
      }
      if (sectionId && sectionId !== 'ALL') {
        filtered = filtered.filter((item) => item.sectionId === sectionId);
      }

      // Search filter
      if (search && search.trim()) {
        const query = search.trim().toLowerCase();
        filtered = filtered.filter(
          (item) =>
            item.receiptNumber.toLowerCase().includes(query) ||
            item.transactionId.toLowerCase().includes(query) ||
            item.studentName.toLowerCase().includes(query) ||
            (item.admissionNumber && item.admissionNumber.toLowerCase().includes(query)) ||
            (item.invoiceNumber && item.invoiceNumber.toLowerCase().includes(query)) ||
            item.feeTitle.toLowerCase().includes(query) ||
            (item.gatewayReference && item.gatewayReference.toLowerCase().includes(query))
        );
      }

      // Sort by paymentDate descending
      filtered.sort((a, b) => new Date(b.paymentDate).getTime() - new Date(a.paymentDate).getTime());

      // Calculate summaries
      const totalTransactions = filtered.length;
      const successfulItems = filtered.filter((i) => i.paymentStatus === 'SUCCESS');
      const reversedItems = filtered.filter((i) => i.paymentStatus === 'REVERSED');

      const grossCollected = successfulItems.reduce((acc, i) => acc + i.amountPaid, 0);
      const reversedCount = reversedItems.length;
      const reversedAmount = reversedItems.reduce((acc, i) => acc + i.amountPaid, 0);
      const netCollected = grossCollected;

      // Payment method breakdown
      const methodMap = new Map<string, { label: string; count: number; amount: number }>();
      successfulItems.forEach((item) => {
        const key = item.paymentMethod;
        const curr = methodMap.get(key) || { label: item.paymentMethodLabel || key, count: 0, amount: 0 };
        curr.count += 1;
        curr.amount += item.amountPaid;
        methodMap.set(key, curr);
      });

      const paymentMethodBreakdown = Array.from(methodMap.entries()).map(([method, data]) => ({
        method,
        label: data.label,
        count: data.count,
        amount: data.amount,
        percentage: grossCollected > 0 ? Number(((data.amount / grossCollected) * 100).toFixed(1)) : 0
      }));

      // Daily collection breakdown
      const dailyMap = new Map<string, { amount: number; count: number }>();
      successfulItems.forEach((item) => {
        const dateKey = item.paymentDate.split('T')[0];
        const curr = dailyMap.get(dateKey) || { amount: 0, count: 0 };
        curr.amount += item.amountPaid;
        curr.count += 1;
        dailyMap.set(dateKey, curr);
      });

      const dailyCollection = Array.from(dailyMap.entries())
        .sort((a, b) => a[0].localeCompare(b[0]))
        .map(([date, data]) => ({
          date,
          amount: data.amount,
          transactionsCount: data.count
        }));

      // Pagination
      const totalPages = Math.ceil(totalTransactions / limitNum) || 1;
      const paginatedData = filtered.slice((pageNum - 1) * limitNum, pageNum * limitNum);

      const response: CollectionReportResponse = {
        data: paginatedData,
        transactions: paginatedData,
        total: totalTransactions,
        page: pageNum,
        limit: limitNum,
        totalPages,
        summary: {
          totalTransactions,
          grossCollected,
          reversedCount,
          reversedTransactions: reversedCount,
          reversedAmount,
          reversedVolume: reversedAmount,
          netCollected
        },
        paymentMethodBreakdown,
        dailyCollection
      };

      res.json({
        success: true,
        data: response
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to generate collection report',
        code: 'SERVER_ERROR'
      });
    }
  }
);

// =========================================================================
// 3. FEE SUMMARY REPORT (BY FEE TYPE & HEAD)
// GET /api/fees/reports/fee-summary
// =========================================================================
feesReportsRouter.get(
  '/reports/fee-summary',
  requireRole('SUPER_ADMIN'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const { academicSessionId, classId, sectionId } = req.query;

      let records = database.feeRecords.filter((f) => f.status !== 'CANCELLED');
      if (academicSessionId && academicSessionId !== 'ALL') {
        records = records.filter((f) => f.academicSessionId === academicSessionId);
      }
      if (classId && classId !== 'ALL') {
        records = records.filter((f) => f.classId === classId);
      }
      if (sectionId && sectionId !== 'ALL') {
        records = records.filter((f) => f.sectionId === sectionId);
      }

      // Group by Fee Type
      const summaryMap = new Map<
        string,
        {
          feeTypeName: string;
          feeCategory: string;
          assignedCount: number;
          totalOriginal: number;
          totalDiscount: number;
          totalScholarship: number;
          totalWaiver: number;
          totalFine: number;
          netPayable: number;
          totalCollected: number;
          totalDue: number;
        }
      >();

      // Seed all fee types
      database.feeTypes.forEach((ft) => {
        summaryMap.set(ft.name, {
          feeTypeName: ft.name,
          feeCategory: ft.category,
          assignedCount: 0,
          totalOriginal: 0,
          totalDiscount: 0,
          totalScholarship: 0,
          totalWaiver: 0,
          totalFine: 0,
          netPayable: 0,
          totalCollected: 0,
          totalDue: 0
        });
      });

      records.forEach((rec) => {
        const key = rec.feeType;
        const curr = summaryMap.get(key) || {
          feeTypeName: rec.feeType,
          feeCategory: 'ACADEMIC',
          assignedCount: 0,
          totalOriginal: 0,
          totalDiscount: 0,
          totalScholarship: 0,
          totalWaiver: 0,
          totalFine: 0,
          netPayable: 0,
          totalCollected: 0,
          totalDue: 0
        };

        curr.assignedCount += 1;
        curr.totalOriginal += rec.totalAmount || 0;
        curr.totalDiscount += rec.discountAmount || 0;
        curr.totalScholarship += rec.scholarshipAmount || 0;
        curr.totalWaiver += rec.waiverAmount || 0;
        curr.totalFine += rec.fineAmount || 0;
        curr.netPayable += rec.netPayableAmount || 0;
        curr.totalCollected += rec.paidAmount || 0;
        curr.totalDue += rec.dueAmount || 0;

        summaryMap.set(key, curr);
      });

      const reportItems: FeeSummaryReportItem[] = Array.from(summaryMap.entries())
        .map(([typeName, stats]) => {
          const typeObj = database.feeTypes.find((t) => t.name === typeName);
          const rate =
            stats.netPayable > 0
              ? Number(((stats.totalCollected / stats.netPayable) * 100).toFixed(1))
              : stats.assignedCount > 0 && stats.netPayable === 0
              ? 100
              : 0;

          const feeTypeId = typeObj?.id || `ft-${typeName.toLowerCase().replace(/\s+/g, '-')}`;
          return {
            id: feeTypeId,
            feeTypeId,
            name: typeName,
            feeTypeName: typeName,
            code: typeObj?.code || typeName.substring(0, 4).toUpperCase(),
            category: stats.feeCategory,
            feeCategory: stats.feeCategory,
            assignedStudentsCount: stats.assignedCount,
            assignedCount: stats.assignedCount,
            totalOriginalAmount: stats.totalOriginal,
            totalInvoiced: stats.totalOriginal,
            totalDiscounts: stats.totalDiscount,
            totalDiscount: stats.totalDiscount,
            totalScholarships: stats.totalScholarship,
            totalScholarship: stats.totalScholarship,
            totalWaivers: stats.totalWaiver,
            totalWaiver: stats.totalWaiver,
            totalFines: stats.totalFine,
            totalFine: stats.totalFine,
            netPayable: stats.netPayable,
            netPayableAmount: stats.netPayable,
            totalCollected: stats.totalCollected,
            totalDue: stats.totalDue,
            collectionRate: rate
          };
        })
        .filter((item) => item.assignedCount > 0 || (academicSessionId === 'ALL' && item.totalOriginalAmount > 0));

      const overallSummary = {
        totalStudents: reportItems.reduce((acc, i) => acc + i.assignedStudentsCount, 0),
        totalAssignedCount: reportItems.reduce((acc, i) => acc + i.assignedCount, 0),
        totalInvoiced: reportItems.reduce((acc, i) => acc + i.totalInvoiced, 0),
        totalOriginal: reportItems.reduce((acc, i) => acc + i.totalOriginalAmount, 0),
        totalDiscounts: reportItems.reduce((acc, i) => acc + i.totalDiscounts, 0),
        totalDiscount: reportItems.reduce((acc, i) => acc + i.totalDiscount, 0),
        totalScholarships: reportItems.reduce((acc, i) => acc + i.totalScholarships, 0),
        totalScholarship: reportItems.reduce((acc, i) => acc + i.totalScholarship, 0),
        totalWaivers: reportItems.reduce((acc, i) => acc + i.totalWaivers, 0),
        totalWaiver: reportItems.reduce((acc, i) => acc + i.totalWaiver, 0),
        totalFines: reportItems.reduce((acc, i) => acc + i.totalFines, 0),
        totalFine: reportItems.reduce((acc, i) => acc + i.totalFine, 0),
        totalNetPayable: reportItems.reduce((acc, i) => acc + i.netPayable, 0),
        netPayable: reportItems.reduce((acc, i) => acc + i.netPayableAmount, 0),
        totalCollected: reportItems.reduce((acc, i) => acc + i.totalCollected, 0),
        totalDue: reportItems.reduce((acc, i) => acc + i.totalDue, 0),
        overallCollectionRate: 0
      };

      overallSummary.overallCollectionRate =
        overallSummary.netPayable > 0
          ? Number(((overallSummary.totalCollected / overallSummary.netPayable) * 100).toFixed(1))
          : 0;

      const response: FeeSummaryReportResponse = {
        data: reportItems,
        feeTypes: reportItems,
        summary: overallSummary
      };

      res.json({
        success: true,
        data: response
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to generate fee summary report',
        code: 'SERVER_ERROR'
      });
    }
  }
);

// =========================================================================
// 4. PAYMENT METHOD REPORT
// GET /api/fees/reports/payment-methods
// =========================================================================
feesReportsRouter.get(
  '/reports/payment-methods',
  requireRole('SUPER_ADMIN'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const { academicSessionId, startDate, endDate } = req.query;

      let txns = [...database.feeTransactions];
      if (academicSessionId && academicSessionId !== 'ALL') {
        txns = txns.filter((t) => t.academicSessionId === academicSessionId);
      }
      if (startDate) {
        const start = new Date(startDate as string);
        start.setHours(0, 0, 0, 0);
        txns = txns.filter((t) => new Date(t.paymentDate) >= start);
      }
      if (endDate) {
        const end = new Date(endDate as string);
        end.setHours(23, 59, 59, 999);
        txns = txns.filter((t) => new Date(t.paymentDate) <= end);
      }

      const totalTransactions = txns.length;
      const successfulTxns = txns.filter((t) => t.paymentStatus === 'SUCCESS');
      const reversedTxns = txns.filter((t) => t.paymentStatus === 'REVERSED');

      const totalVolume = successfulTxns.reduce((acc, t) => acc + t.amountPaid, 0);
      const reversedVolume = reversedTxns.reduce((acc, t) => acc + t.amountPaid, 0);
      const netVolume = totalVolume;

      const methodStatsMap = new Map<
        string,
        {
          code: string;
          name: string;
          transactionCount: number;
          grossVolume: number;
          reversedVolume: number;
          requiresReference: boolean;
        }
      >();

      // Initialize with configured payment methods
      database.paymentMethods.forEach((pm) => {
        methodStatsMap.set(pm.code, {
          code: pm.code,
          name: pm.name,
          transactionCount: 0,
          grossVolume: 0,
          reversedVolume: 0,
          requiresReference: pm.requiresReference
        });
      });

      txns.forEach((t) => {
        const key = t.paymentMethod;
        const pmObj = database.paymentMethods.find((p) => p.code === key);
        const curr = methodStatsMap.get(key) || {
          code: key,
          name: pmObj?.name || t.paymentMethodLabel || key,
          transactionCount: 0,
          grossVolume: 0,
          reversedVolume: 0,
          requiresReference: false
        };

        curr.transactionCount += 1;
        if (t.paymentStatus === 'SUCCESS') {
          curr.grossVolume += t.amountPaid;
        } else if (t.paymentStatus === 'REVERSED') {
          curr.reversedVolume += t.amountPaid;
        }
        methodStatsMap.set(key, curr);
      });

      const methods = Array.from(methodStatsMap.values()).map((m) => {
        const net = m.grossVolume;
        const share = totalVolume > 0 ? Number(((m.grossVolume / totalVolume) * 100).toFixed(1)) : 0;
        const successfulCount = m.transactionCount;
        const avg = successfulCount > 0 && m.grossVolume > 0 ? Math.round(m.grossVolume / successfulCount) : 0;

        return {
          methodCode: m.code,
          methodName: m.name,
          transactionCount: m.transactionCount,
          grossVolume: m.grossVolume,
          reversedVolume: m.reversedVolume,
          netVolume: net,
          sharePercentage: share,
          averageTransactionValue: avg,
          requiresReference: m.requiresReference
        };
      });

      const response: PaymentMethodReportResponse = {
        summary: {
          totalTransactions,
          totalVolume,
          reversedTransactions: reversedTxns.length,
          reversedVolume,
          netVolume
        },
        methods
      };

      res.json({
        success: true,
        data: response
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to generate payment methods report',
        code: 'SERVER_ERROR'
      });
    }
  }
);

// =========================================================================
// 5. STUDENT ACCOUNT STATEMENT / FINANCIAL LEDGER
// GET /api/fees/reports/statements/students/:studentId
// =========================================================================
feesReportsRouter.get(
  '/reports/statements/students/:studentId',
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const { studentId } = req.params;
      const { academicSessionId, startDate, endDate } = req.query;

      const student = findStudent(studentId);
      if (!student) {
        return res.status(404).json({
          success: false,
          error: 'Student record not found',
          code: 'NOT_FOUND'
        });
      }

      // Security check:
      // Super Admin can access all.
      // Student can only access their own.
      // Guardian can only access their linked children.
      const user = req.user!;
      if (user.role === 'STUDENT') {
        if (student.userId !== user.id && student.id !== user.id) {
          return res.status(403).json({
            success: false,
            error: 'You are only authorized to view your own financial statement.',
            code: 'FORBIDDEN'
          });
        }
      } else if (user.role === 'GUARDIAN') {
        const guardian = database.guardians.find((g) => g.userId === user.id || g.id === user.id);
        if (!guardian || !guardian.studentIds.includes(student.id)) {
          return res.status(403).json({
            success: false,
            error: 'You are only authorized to view statements for your linked children.',
            code: 'FORBIDDEN'
          });
        }
      } else if (user.role !== 'SUPER_ADMIN') {
        return res.status(403).json({
          success: false,
          error: 'Unauthorized access to student financial statement.',
          code: 'FORBIDDEN'
        });
      }

      // Fetch linked student fees
      let feeRecords = database.feeRecords.filter(
        (f) => (f.studentId === student.id || f.studentId === student.userId) && f.status !== 'CANCELLED'
      );
      if (academicSessionId && academicSessionId !== 'ALL') {
        feeRecords = feeRecords.filter((f) => f.academicSessionId === academicSessionId);
      }

      // Fetch linked payment transactions
      let transactions = database.feeTransactions.filter(
        (t) => t.studentId === student.id || t.studentId === student.userId
      );
      if (academicSessionId && academicSessionId !== 'ALL') {
        transactions = transactions.filter((t) => t.academicSessionId === academicSessionId);
      }

      // Build chronological ledger entries
      const rawEntries: Array<{
        id: string;
        date: string;
        type: StudentStatementEntry['type'];
        referenceNo: string;
        description: string;
        feeType?: string;
        feeTitle?: string;
        debit: number;
        credit: number;
        metadata?: Record<string, any>;
      }> = [];

      // 1. Fee Invoices & In-Invoice Adjustments
      feeRecords.forEach((fee) => {
        // Base invoice charge
        rawEntries.push({
          id: `entry-inv-${fee.id}`,
          date: fee.createdAt || fee.dueDate,
          type: 'INVOICE_GENERATED',
          referenceNo: fee.invoiceNumber,
          description: `Fee Assessment: ${fee.title}`,
          feeType: fee.feeType,
          feeTitle: fee.title,
          debit: fee.totalAmount,
          credit: 0,
          metadata: { feeRecordId: fee.id, dueDate: fee.dueDate }
        });

        // Discount applied
        if (fee.discountAmount > 0) {
          rawEntries.push({
            id: `entry-disc-${fee.id}`,
            date: fee.createdAt,
            type: 'DISCOUNT_APPLIED',
            referenceNo: fee.invoiceNumber,
            description: `Discount Concession: ${fee.discountReason || 'Authorized Fee Discount'}`,
            feeType: fee.feeType,
            feeTitle: fee.title,
            debit: 0,
            credit: fee.discountAmount,
            metadata: { feeRecordId: fee.id }
          });
        }

        // Scholarship applied
        if (fee.scholarshipAmount && fee.scholarshipAmount > 0) {
          rawEntries.push({
            id: `entry-sch-${fee.id}`,
            date: fee.createdAt,
            type: 'SCHOLARSHIP_APPLIED',
            referenceNo: fee.invoiceNumber,
            description: `Scholarship Credit: ${fee.scholarshipName || 'Merit/Need Scholarship'}`,
            feeType: fee.feeType,
            feeTitle: fee.title,
            debit: 0,
            credit: fee.scholarshipAmount,
            metadata: { feeRecordId: fee.id }
          });
        }

        // Waiver applied
        if (fee.waiverAmount && fee.waiverAmount > 0) {
          rawEntries.push({
            id: `entry-waiv-${fee.id}`,
            date: fee.createdAt,
            type: 'WAIVER_APPLIED',
            referenceNo: fee.invoiceNumber,
            description: `Special Fee Waiver: ${fee.waiverReason || 'Administrative Relief'}`,
            feeType: fee.feeType,
            feeTitle: fee.title,
            debit: 0,
            credit: fee.waiverAmount,
            metadata: { feeRecordId: fee.id }
          });
        }

        // Fine applied
        if (fee.fineAmount && fee.fineAmount > 0) {
          rawEntries.push({
            id: `entry-fine-${fee.id}`,
            date: fee.updatedAt || fee.createdAt,
            type: 'FINE_APPLIED',
            referenceNo: fee.invoiceNumber,
            description: `Late Assessment Fine: ${fee.fineReason || 'Overdue Late Fee Penalty'}`,
            feeType: fee.feeType,
            feeTitle: fee.title,
            debit: fee.fineAmount,
            credit: 0,
            metadata: { feeRecordId: fee.id }
          });
        }
      });

      // 2. Transactions
      transactions.forEach((tx) => {
        const feeRecord = feeRecords.find((f) => f.id === tx.feeRecordId);
        rawEntries.push({
          id: `entry-tx-${tx.id}`,
          date: tx.paymentDate,
          type: 'PAYMENT_RECEIVED',
          referenceNo: tx.receiptNumber,
          description: `Payment Settled: ${tx.paymentMethodLabel || tx.paymentMethod} (Txn: ${tx.transactionId})`,
          feeType: tx.feeType,
          feeTitle: tx.feeTitle,
          debit: 0,
          credit: tx.amountPaid,
          metadata: { transactionId: tx.transactionId, gatewayReference: tx.gatewayReference, status: tx.paymentStatus }
        });

        if (tx.paymentStatus === 'REVERSED') {
          rawEntries.push({
            id: `entry-rev-${tx.id}`,
            date: tx.reversedAt || tx.paymentDate,
            type: 'PAYMENT_REVERSED',
            referenceNo: `VOID-${tx.receiptNumber}`,
            description: `Payment Voided / Reversed: "${tx.reversalReason || 'Administrative correction'}"`,
            feeType: tx.feeType,
            feeTitle: tx.feeTitle,
            debit: tx.amountPaid,
            credit: 0,
            metadata: { transactionId: tx.transactionId, reason: tx.reversalReason }
          });
        }
      });

      // Sort entries chronologically ascending
      rawEntries.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

      // Filter by custom date range if supplied
      let filteredEntries = rawEntries;
      if (startDate) {
        const start = new Date(startDate as string);
        start.setHours(0, 0, 0, 0);
        filteredEntries = filteredEntries.filter((e) => new Date(e.date) >= start);
      }
      if (endDate) {
        const end = new Date(endDate as string);
        end.setHours(23, 59, 59, 999);
        filteredEntries = filteredEntries.filter((e) => new Date(e.date) <= end);
      }

      // Calculate running balances
      let currentRunningBalance = 0;
      const statementEntries: StudentStatementEntry[] = filteredEntries.map((item) => {
        currentRunningBalance += item.debit - item.credit;
        return {
          ...item,
          runningBalance: Math.round(currentRunningBalance * 100) / 100
        };
      });

      // Find guardian info
      const guardian = database.guardians.find((g) => g.studentIds.includes(student.id));

      const totalBilled = feeRecords.reduce((acc, f) => acc + f.totalAmount, 0);
      const totalDiscounts = feeRecords.reduce((acc, f) => acc + (f.discountAmount || 0), 0);
      const totalScholarships = feeRecords.reduce((acc, f) => acc + (f.scholarshipAmount || 0), 0);
      const totalWaivers = feeRecords.reduce((acc, f) => acc + (f.waiverAmount || 0), 0);
      const totalFines = feeRecords.reduce((acc, f) => acc + (f.fineAmount || 0), 0);
      const netPayable = feeRecords.reduce((acc, f) => acc + f.netPayableAmount, 0);

      const successfulTxns = transactions.filter((t) => t.paymentStatus === 'SUCCESS');
      const totalPaid = successfulTxns.reduce((acc, t) => acc + t.amountPaid, 0);
      const currentDue = feeRecords.reduce((acc, f) => acc + f.dueAmount, 0);

      let statementStatus: StudentAccountStatement['summary']['status'] = 'CLEARED';
      const isOverdue = feeRecords.some((f) => f.status === 'OVERDUE');
      if (isOverdue) {
        statementStatus = 'OVERDUE';
      } else if (currentDue > 0 && totalPaid > 0) {
        statementStatus = 'PARTIAL_DUE';
      } else if (currentDue > 0) {
        statementStatus = 'DUE';
      }

      const statement: StudentAccountStatement = {
        student: {
          id: student.id,
          name: `${student.firstName} ${student.lastName}`,
          admissionNumber: student.admissionNumber,
          rollNumber: student.rollNumber,
          className: student.className,
          sectionName: student.sectionName,
          academicSessionName: student.academicSessionName || '2026-2027 Academic Year',
          guardianName: guardian ? `${guardian.firstName} ${guardian.lastName}` : 'Carlos Rivera',
          guardianPhone: guardian?.phone || '+1 (555) 019-8811',
          guardianEmail: guardian?.email || 'carlos.rivera@example.com',
          address: student.address || '742 Evergreen Terrace, Springfield'
        },
        period: {
          startDate: (startDate as string) || '2026-08-01',
          endDate: (endDate as string) || '2027-06-30',
          sessionName: student.academicSessionName || '2026-2027 Academic Year',
          generatedAt: new Date().toISOString()
        },
        summary: {
          totalBilled,
          totalDiscounts,
          totalScholarships,
          totalWaivers,
          totalFines,
          netPayable,
          totalPaid,
          currentDue,
          status: statementStatus,
          invoicesCount: feeRecords.length,
          paymentsCount: successfulTxns.length
        },
        entries: statementEntries
      };

      // Log audit
      logAudit({
        userId: user.id,
        userRole: user.role,
        action: 'VIEW_STUDENT_FINANCIAL_STATEMENT',
        entityType: 'StudentAccountStatement',
        entityId: student.id,
        details: `Generated financial ledger statement for student ${student.firstName} ${student.lastName} (ADM: ${student.admissionNumber}). Total Billed: $${totalBilled}, Paid: $${totalPaid}, Balance Due: $${currentDue}.`,
        ipAddress: req.ip || '127.0.0.1'
      });

      res.json({
        success: true,
        data: statement
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to generate student statement',
        code: 'SERVER_ERROR'
      });
    }
  }
);

// =========================================================================
// 6. PAYMENT RECEIPTS ARCHIVE & VERIFICATION
// GET /api/fees/reports/receipts
// =========================================================================
feesReportsRouter.get(
  '/reports/receipts',
  requireRole('SUPER_ADMIN'),
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const { search, studentId, classId, paymentMethod, status, startDate, endDate, page = '1', limit = '20' } =
        req.query as Record<string, string>;

      const pageNum = Math.max(1, parseInt(page, 10) || 1);
      const limitNum = Math.max(1, Math.min(100, parseInt(limit, 10) || 20));

      let txns = [...database.feeTransactions];

      if (studentId && studentId !== 'ALL') {
        txns = txns.filter((t) => t.studentId === studentId);
      }
      if (paymentMethod && paymentMethod !== 'ALL') {
        txns = txns.filter((t) => t.paymentMethod === paymentMethod);
      }
      if (status && status !== 'ALL') {
        txns = txns.filter((t) => t.paymentStatus === status);
      }
      if (startDate) {
        const start = new Date(startDate);
        start.setHours(0, 0, 0, 0);
        txns = txns.filter((t) => new Date(t.paymentDate) >= start);
      }
      if (endDate) {
        const end = new Date(endDate);
        end.setHours(23, 59, 59, 999);
        txns = txns.filter((t) => new Date(t.paymentDate) <= end);
      }

      // Build full receipt objects
      const fullReceipts: FeePaymentReceipt[] = txns.map((t) => {
        const student = database.studentProfiles.find((s) => s.id === t.studentId || s.userId === t.studentId);
        const feeRecord = database.feeRecords.find((f) => f.id === t.feeRecordId);
        const methodObj = database.paymentMethods.find((pm) => pm.code === t.paymentMethod);
        const isReversed = t.paymentStatus === 'REVERSED';

        return {
          receiptNumber: t.receiptNumber,
          transactionId: t.transactionId,
          issuedAt: t.paymentDate,
          schoolInfo: {
            name: database.schoolSettings.schoolName || 'Sygmate International Academy',
            code: database.schoolSettings.schoolCode || 'SYGMATE',
            address: database.schoolSettings.address || '450 Innovation Parkway, Silicon Valley, CA',
            phone: database.schoolSettings.phone || '+1 (555) 890-4321',
            email: database.schoolSettings.email || 'bursar@sygmateschools.edu',
            website: database.schoolSettings.website || 'https://sygmate.school.internal',
            currency: 'USD',
            currencySymbol: '$'
          },
          studentInfo: {
            id: t.studentId,
            name: t.studentName || (student ? `${student.firstName} ${student.lastName}` : 'Student'),
            admissionNumber: student?.admissionNumber || 'N/A',
            rollNumber: student?.rollNumber || 'N/A',
            className: student?.className || feeRecord?.className || 'Grade 10',
            sectionName: student?.sectionName || feeRecord?.sectionName || 'Section A'
          },
          guardianInfo: {
            name: t.guardianName || 'Carlos Rivera',
            relation: 'Father / Guardian',
            email: t.payerEmail || 'carlos.rivera@example.com',
            phone: t.payerPhone || '+1 (555) 019-8811'
          },
          feeInfo: {
            feeRecordId: t.feeRecordId,
            invoiceNumber: feeRecord?.invoiceNumber || 'INV-NA',
            feeType: t.feeType,
            title: t.feeTitle,
            academicSession: t.academicSessionId || '2026-2027 Academic Year',
            totalFee: feeRecord?.totalAmount || t.amountPaid,
            discount: feeRecord?.discountAmount || 0,
            fine: feeRecord?.fineAmount || 0,
            netPayable: feeRecord?.netPayableAmount || t.amountPaid,
            previouslyPaid: Math.max(0, (feeRecord?.paidAmount || t.amountPaid) - t.amountPaid),
            amountPaidNow: t.amountPaid,
            remainingDue: feeRecord?.dueAmount || 0
          },
          paymentDetails: {
            paymentDate: t.paymentDate,
            paymentMethod: t.paymentMethod,
            paymentMethodLabel: t.paymentMethodLabel || methodObj?.name || t.paymentMethod,
            paymentStatus: t.paymentStatus,
            gatewayReference: t.gatewayReference,
            referenceNumber: t.gatewayReference || t.referenceNumber,
            collectedBy: t.collectedByName || 'School Finance Counter / POS',
            notes: t.notes,
            isReversed,
            reversedAt: t.reversedAt,
            reversalReason: t.reversalReason,
            reversedByName: t.reversedByName || 'Admin Bursar'
          }
        };
      });

      // Filter by class if specified
      let filtered = fullReceipts;
      if (classId && classId !== 'ALL') {
        const studentIdsInClass = new Set(
          database.studentProfiles.filter((s) => s.classId === classId).map((s) => s.id)
        );
        filtered = filtered.filter((r) => studentIdsInClass.has(r.studentInfo.id));
      }

      // Search filter
      if (search && search.trim()) {
        const query = search.trim().toLowerCase();
        filtered = filtered.filter(
          (r) =>
            r.receiptNumber.toLowerCase().includes(query) ||
            r.transactionId.toLowerCase().includes(query) ||
            r.studentInfo.name.toLowerCase().includes(query) ||
            r.studentInfo.admissionNumber.toLowerCase().includes(query) ||
            (r.feeInfo.invoiceNumber && r.feeInfo.invoiceNumber.toLowerCase().includes(query)) ||
            (r.paymentDetails.gatewayReference && r.paymentDetails.gatewayReference.toLowerCase().includes(query))
        );
      }

      // Sort newest first
      filtered.sort((a, b) => new Date(b.issuedAt).getTime() - new Date(a.issuedAt).getTime());

      const total = filtered.length;
      const totalPages = Math.ceil(total / limitNum) || 1;
      const paginated = filtered.slice((pageNum - 1) * limitNum, pageNum * limitNum);

      res.json({
        success: true,
        data: paginated,
        total,
        page: pageNum,
        limit: limitNum,
        totalPages
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to retrieve receipts',
        code: 'SERVER_ERROR'
      });
    }
  }
);

// =========================================================================
// 7. GET SINGLE RECEIPT BY RECEIPT NUMBER OR TRANSACTION ID
// GET /api/fees/reports/receipts/:receiptOrTxnId
// =========================================================================
feesReportsRouter.get(
  '/reports/receipts/:receiptOrTxnId',
  (req: AuthenticatedRequest, res: Response) => {
    try {
      const { receiptOrTxnId } = req.params;

      const t = database.feeTransactions.find(
        (tx) =>
          tx.receiptNumber.toLowerCase() === receiptOrTxnId.toLowerCase() ||
          tx.transactionId.toLowerCase() === receiptOrTxnId.toLowerCase() ||
          tx.id.toLowerCase() === receiptOrTxnId.toLowerCase()
      );

      if (!t) {
        return res.status(404).json({
          success: false,
          error: `Receipt or transaction "${receiptOrTxnId}" not found`,
          code: 'NOT_FOUND'
        });
      }

      const student = database.studentProfiles.find((s) => s.id === t.studentId || s.userId === t.studentId);
      const feeRecord = database.feeRecords.find((f) => f.id === t.feeRecordId);
      const methodObj = database.paymentMethods.find((pm) => pm.code === t.paymentMethod);

      // Access control
      const user = req.user!;
      if (user.role === 'STUDENT') {
        if (student && student.userId !== user.id && student.id !== user.id) {
          return res.status(403).json({
            success: false,
            error: 'You are only authorized to view your own payment receipts.',
            code: 'FORBIDDEN'
          });
        }
      } else if (user.role === 'GUARDIAN') {
        const guardian = database.guardians.find((g) => g.userId === user.id || g.id === user.id);
        if (!guardian || !student || !guardian.studentIds.includes(student.id)) {
          return res.status(403).json({
            success: false,
            error: 'You are only authorized to view receipts for your linked children.',
            code: 'FORBIDDEN'
          });
        }
      } else if (user.role !== 'SUPER_ADMIN') {
        return res.status(403).json({
          success: false,
          error: 'Unauthorized receipt access.',
          code: 'FORBIDDEN'
        });
      }

      const isReversed = t.paymentStatus === 'REVERSED';

      const receipt: FeePaymentReceipt = {
        receiptNumber: t.receiptNumber,
        transactionId: t.transactionId,
        issuedAt: t.paymentDate,
        schoolInfo: {
          name: database.schoolSettings.schoolName || 'Sygmate International Academy',
          code: database.schoolSettings.schoolCode || 'SYGMATE',
          address: database.schoolSettings.address || '450 Innovation Parkway, Silicon Valley, CA',
          phone: database.schoolSettings.phone || '+1 (555) 890-4321',
          email: database.schoolSettings.email || 'bursar@sygmateschools.edu',
          website: database.schoolSettings.website || 'https://sygmate.school.internal',
          currency: 'USD',
          currencySymbol: '$'
        },
        studentInfo: {
          id: t.studentId,
          name: t.studentName || (student ? `${student.firstName} ${student.lastName}` : 'Student'),
          admissionNumber: student?.admissionNumber || 'N/A',
          rollNumber: student?.rollNumber || 'N/A',
          className: student?.className || feeRecord?.className || 'Grade 10',
          sectionName: student?.sectionName || feeRecord?.sectionName || 'Section A'
        },
        guardianInfo: {
          name: t.guardianName || 'Carlos Rivera',
          relation: 'Father / Guardian',
          email: t.payerEmail || 'carlos.rivera@example.com',
          phone: t.payerPhone || '+1 (555) 019-8811'
        },
        feeInfo: {
          feeRecordId: t.feeRecordId,
          invoiceNumber: feeRecord?.invoiceNumber || 'INV-NA',
          feeType: t.feeType,
          title: t.feeTitle,
          academicSession: t.academicSessionId || '2026-2027 Academic Year',
          totalFee: feeRecord?.totalAmount || t.amountPaid,
          discount: feeRecord?.discountAmount || 0,
          fine: feeRecord?.fineAmount || 0,
          netPayable: feeRecord?.netPayableAmount || t.amountPaid,
          previouslyPaid: Math.max(0, (feeRecord?.paidAmount || t.amountPaid) - t.amountPaid),
          amountPaidNow: t.amountPaid,
          remainingDue: feeRecord?.dueAmount || 0
        },
        paymentDetails: {
          paymentDate: t.paymentDate,
          paymentMethod: t.paymentMethod,
          paymentMethodLabel: t.paymentMethodLabel || methodObj?.name || t.paymentMethod,
          paymentStatus: t.paymentStatus,
          gatewayReference: t.gatewayReference,
          referenceNumber: t.gatewayReference || t.referenceNumber,
          collectedBy: t.collectedByName || 'School Finance Counter / POS',
          notes: t.notes,
          isReversed,
          reversedAt: t.reversedAt,
          reversalReason: t.reversalReason,
          reversedByName: t.reversedByName || 'Admin Bursar'
        }
      };

      res.json({
        success: true,
        data: receipt
      });
    } catch (error: any) {
      res.status(500).json({
        success: false,
        error: error.message || 'Failed to load receipt detail',
        code: 'SERVER_ERROR'
      });
    }
  }
);
