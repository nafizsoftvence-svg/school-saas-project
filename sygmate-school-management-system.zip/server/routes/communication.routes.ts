import { Router, Response } from 'express';
import { requireAuth, AuthenticatedRequest } from '../security/auth.js';
import { hasPermission } from '../security/rbac.js';
import { logAudit } from '../security/audit.js';
import { CommunicationService, renderTemplate } from '../services/communication.service.js';
import { AnnouncementService, sanitizeAnnouncementContent } from '../services/announcement.service.js';
import { MessagingService } from '../services/messaging.service.js';
import { BulkCampaignService } from '../services/bulk-campaign.service.js';
import { CommunicationAnalyticsService } from '../services/communication-analytics.service.js';
import { database } from '../db/database.js';
import {
  CommunicationEventType,
  NotificationChannel,
  UserRole,
  AnnouncementAudience,
  AnnouncementCategory,
  AnnouncementStatus
} from '../../src/types/index.js';

export const communicationRouter = Router();

// Helper to check admin authorization
function requireAdmin(req: AuthenticatedRequest, res: Response, next: () => void): void {
  const user = req.user;
  if (!user) {
    res.status(401).json({ success: false, error: 'Authentication required.' });
    return;
  }

  const isAdmin =
    user.role === 'SUPER_ADMIN' ||
    hasPermission(user.role, 'settings.manage') ||
    hasPermission(user.role, 'settings.view') ||
    hasPermission(user.role, 'notifications.manage');

  if (!isAdmin) {
    res.status(403).json({ success: false, error: 'Access denied. Administrative privileges required.' });
    return;
  }

  next();
}

// =========================================================================
// PROVIDER SETTINGS & CONFIGURATION
// =========================================================================

/**
 * GET /api/communication/settings
 * Admin only: Returns communication settings with secrets masked.
 */
communicationRouter.get('/settings', requireAuth, requireAdmin, (req: AuthenticatedRequest, res: Response): void => {
  const settings = CommunicationService.getSanitizedSettings();
  res.json({ success: true, data: settings });
});

/**
 * PUT /api/communication/settings
 * Admin only: Updates provider configuration and global rules.
 */
communicationRouter.put('/settings', requireAuth, requireAdmin, (req: AuthenticatedRequest, res: Response): void => {
  const user = req.user!;
  const body = req.body;

  // Validation
  if (body.general) {
    if (body.general.deduplicationWindowMinutes !== undefined && body.general.deduplicationWindowMinutes < 1) {
      res.status(400).json({ success: false, error: 'Deduplication window must be at least 1 minute.' });
      return;
    }
    if (body.general.maxRetries !== undefined && (body.general.maxRetries < 0 || body.general.maxRetries > 10)) {
      res.status(400).json({ success: false, error: 'Max retries must be between 0 and 10.' });
      return;
    }
  }

  if (body.email?.senderEmail && !body.email.senderEmail.includes('@')) {
    res.status(400).json({ success: false, error: 'Sender email must be a valid email address.' });
    return;
  }

  const updated = CommunicationService.updateSettings(body, {
    id: user.id,
    name: user.name
  });

  logAudit({
    userId: user.id,
    userName: user.name,
    userRole: user.role,
    action: 'UPDATE',
    entity: 'COMMUNICATION_SETTINGS',
    entityType: 'COMMUNICATION_SETTINGS',
    entityId: updated.id,
    details: 'Updated institutional communication channel and provider configuration.'
  });

  res.json({
    success: true,
    message: 'Communication settings updated successfully.',
    data: CommunicationService.getSanitizedSettings()
  });
});

/**
 * POST /api/communication/providers/test
 * Admin only: Dispatches a real test payload to evaluate provider status.
 */
communicationRouter.post('/providers/test', requireAuth, requireAdmin, async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  const user = req.user!;
  const { channel, recipientContact } = req.body;

  if (!channel || !['IN_APP', 'EMAIL', 'SMS', 'PUSH'].includes(channel)) {
    res.status(400).json({ success: false, error: 'A valid channel (IN_APP, EMAIL, SMS, PUSH) is required.' });
    return;
  }

  const target = recipientContact || user.email || 'system.admin@sygmate-school.edu';

  const result = await CommunicationService.testChannel(channel as NotificationChannel, target, {
    id: user.id,
    name: user.name,
    role: user.role
  });

  logAudit({
    userId: user.id,
    userName: user.name,
    userRole: user.role,
    action: 'TEST',
    entity: 'COMMUNICATION_PROVIDER',
    entityType: 'COMMUNICATION_PROVIDER',
    details: `Executed provider connectivity test for channel "${channel}". Result: ${result.status}.`
  });

  res.json(result);
});

// =========================================================================
// TEMPLATE MANAGEMENT
// =========================================================================

/**
 * GET /api/communication/templates
 * Admin only: Returns all registered templates with optional filtering.
 */
communicationRouter.get('/templates', requireAuth, requireAdmin, (req: AuthenticatedRequest, res: Response): void => {
  const { category, eventType, isActive, search } = req.query;
  let templates = CommunicationService.getTemplates();

  if (category) {
    templates = templates.filter((t) => t.category === category);
  }
  if (eventType) {
    templates = templates.filter((t) => t.eventType === eventType);
  }
  if (isActive !== undefined) {
    const activeBool = isActive === 'true';
    templates = templates.filter((t) => t.isActive === activeBool);
  }
  if (search) {
    const s = String(search).toLowerCase();
    templates = templates.filter(
      (t) =>
        t.name.toLowerCase().includes(s) ||
        t.eventType.toLowerCase().includes(s) ||
        t.description.toLowerCase().includes(s)
    );
  }

  res.json({
    success: true,
    data: templates
  });
});

/**
 * GET /api/communication/templates/:id
 * Admin only: Returns a single template.
 */
communicationRouter.get('/templates/:id', requireAuth, requireAdmin, (req: AuthenticatedRequest, res: Response): void => {
  const { id } = req.params;
  const template = CommunicationService.getTemplateById(id);

  if (!template) {
    res.status(404).json({ success: false, error: `Template with ID "${id}" was not found.` });
    return;
  }

  res.json({ success: true, data: template });
});

/**
 * POST /api/communication/templates
 * Admin only: Creates a new custom notification template.
 */
communicationRouter.post('/templates', requireAuth, requireAdmin, (req: AuthenticatedRequest, res: Response): void => {
  const user = req.user!;
  const { eventType, name, description, category, channels, titleTemplate, bodyTemplate, emailSubjectTemplate, emailHtmlTemplate, smsTemplate, allowedVariables, isActive, isMandatory } = req.body;

  if (!eventType || !name || !titleTemplate || !bodyTemplate) {
    res.status(400).json({ success: false, error: 'eventType, name, titleTemplate, and bodyTemplate are required fields.' });
    return;
  }

  const created = CommunicationService.createTemplate({
    eventType,
    name,
    description: description || '',
    category: category || 'general',
    channels: channels || { inApp: true, email: false, sms: false, push: false },
    titleTemplate,
    bodyTemplate,
    emailSubjectTemplate,
    emailHtmlTemplate,
    smsTemplate,
    allowedVariables: Array.isArray(allowedVariables) ? allowedVariables : [],
    isActive: isActive !== false,
    isMandatory: isMandatory === true
  }, {
    id: user.id,
    name: user.name
  });

  logAudit({
    userId: user.id,
    userName: user.name,
    userRole: user.role,
    action: 'CREATE',
    entity: 'COMMUNICATION_TEMPLATE',
    entityType: 'COMMUNICATION_TEMPLATE',
    entityId: created.id,
    details: `Created new notification template "${created.name}" for event "${created.eventType}".`
  });

  res.status(201).json({
    success: true,
    message: 'Template created successfully.',
    data: created
  });
});

/**
 * PUT /api/communication/templates/:id
 * Admin only: Updates an existing template.
 */
communicationRouter.put('/templates/:id', requireAuth, requireAdmin, (req: AuthenticatedRequest, res: Response): void => {
  const user = req.user!;
  const { id } = req.params;
  const updates = req.body;

  const result = CommunicationService.updateTemplate(id, updates, {
    id: user.id,
    name: user.name
  });

  if (!result.success) {
    res.status(404).json({ success: false, error: result.error });
    return;
  }

  logAudit({
    userId: user.id,
    userName: user.name,
    userRole: user.role,
    action: 'UPDATE',
    entity: 'COMMUNICATION_TEMPLATE',
    entityType: 'COMMUNICATION_TEMPLATE',
    entityId: id,
    details: `Updated notification template "${result.template?.name}".`
  });

  res.json({
    success: true,
    message: 'Template updated successfully.',
    data: result.template
  });
});

/**
 * POST /api/communication/templates/:id/toggle
 * Admin only: Toggles active status of a template.
 */
communicationRouter.post('/templates/:id/toggle', requireAuth, requireAdmin, (req: AuthenticatedRequest, res: Response): void => {
  const user = req.user!;
  const { id } = req.params;
  const tpl = CommunicationService.getTemplateById(id);

  if (!tpl) {
    res.status(404).json({ success: false, error: 'Template not found.' });
    return;
  }

  const newStatus = !tpl.isActive;
  CommunicationService.updateTemplate(id, { isActive: newStatus }, {
    id: user.id,
    name: user.name
  });

  logAudit({
    userId: user.id,
    userName: user.name,
    userRole: user.role,
    action: 'UPDATE',
    entity: 'COMMUNICATION_TEMPLATE',
    entityType: 'COMMUNICATION_TEMPLATE',
    entityId: id,
    details: `Toggled template "${tpl.name}" active status to ${newStatus}.`
  });

  res.json({
    success: true,
    message: `Template "${tpl.name}" is now ${newStatus ? 'active' : 'inactive'}.`,
    isActive: newStatus
  });
});

/**
 * POST /api/communication/templates/preview
 * Admin only: Previews rendered title, in-app body, email HTML, and SMS text with test variables.
 */
communicationRouter.post('/templates/preview', requireAuth, requireAdmin, (req: AuthenticatedRequest, res: Response): void => {
  const { templateId, titleTemplate, bodyTemplate, emailSubjectTemplate, emailHtmlTemplate, smsTemplate, variables } = req.body;

  let title = titleTemplate || '';
  let body = bodyTemplate || '';
  let emailSubject = emailSubjectTemplate || '';
  let emailHtml = emailHtmlTemplate || '';
  let sms = smsTemplate || '';

  if (templateId) {
    const tpl = CommunicationService.getTemplateById(templateId);
    if (tpl) {
      title = title || tpl.titleTemplate;
      body = body || tpl.bodyTemplate;
      emailSubject = emailSubject || tpl.emailSubjectTemplate || tpl.titleTemplate;
      emailHtml = emailHtml || tpl.emailHtmlTemplate || `<p>${tpl.bodyTemplate}</p>`;
      sms = sms || tpl.smsTemplate || tpl.bodyTemplate;
    }
  }

  const sampleVars = {
    student_name: 'Alex Rivera',
    student_id: 'ADM-2026-0042',
    parent_name: 'Carlos Rivera',
    class_name: 'Grade 10',
    section_name: 'Section A',
    school_name: 'Sygmate International Academy',
    date: new Date().toISOString().split('T')[0],
    amount: '1,250.00',
    balance_due: '1,250.00',
    currency: '$',
    invoice_number: 'INV-2026-001',
    due_date: '2026-09-15',
    receipt_number: 'REC-2026-089',
    exam_name: 'Mid-Term Examination 2026',
    overall_grade: 'A',
    gpa: '3.85',
    leave_type: 'Medical Leave',
    leave_start_date: '2026-09-20',
    leave_end_date: '2026-09-22',
    remarks: 'Approved by medical advisory.',
    reason: 'Fever and seasonal flu.',
    user_name: 'Carlos Rivera',
    ...(variables || {})
  };

  const renderedTitle = renderTemplate(title, sampleVars);
  const renderedBody = renderTemplate(body, sampleVars);
  const renderedEmailSubject = renderTemplate(emailSubject, sampleVars);
  const renderedEmailHtml = renderTemplate(emailHtml, sampleVars);
  const renderedSms = renderTemplate(sms, sampleVars);

  res.json({
    success: true,
    preview: {
      title: renderedTitle,
      body: renderedBody,
      emailSubject: renderedEmailSubject,
      emailHtml: renderedEmailHtml,
      sms: renderedSms,
      variablesUsed: sampleVars
    }
  });
});

/**
 * POST /api/communication/templates/reset
 * Admin only: Resets templates to system defaults.
 */
communicationRouter.post('/templates/reset', requireAuth, requireAdmin, (req: AuthenticatedRequest, res: Response): void => {
  const user = req.user!;
  const reset = CommunicationService.resetTemplates({
    id: user.id,
    name: user.name
  });

  logAudit({
    userId: user.id,
    userName: user.name,
    userRole: user.role,
    action: 'RESET',
    entity: 'COMMUNICATION_TEMPLATE',
    entityType: 'COMMUNICATION_TEMPLATE',
    details: 'Reset all notification templates to system baseline definitions.'
  });

  res.json({
    success: true,
    message: 'Templates successfully reset to system default library.',
    data: reset
  });
});

// =========================================================================
// COMMUNICATION LOGS & METRICS
// =========================================================================

/**
 * GET /api/communication/logs
 * Admin only: Returns paginated communication delivery logs with filters.
 */
communicationRouter.get('/logs', requireAuth, requireAdmin, (req: AuthenticatedRequest, res: Response): void => {
  const { eventType, channel, status, recipientRole, search, startDate, endDate, page = '1', limit = '20' } = req.query;

  let logs = CommunicationService.getLogs();

  if (eventType) {
    logs = logs.filter((l) => l.eventType === eventType);
  }
  if (channel) {
    logs = logs.filter((l) => l.channel === channel);
  }
  if (status) {
    logs = logs.filter((l) => l.status === status);
  }
  if (recipientRole) {
    logs = logs.filter((l) => l.recipientRole === recipientRole);
  }
  if (startDate) {
    logs = logs.filter((l) => new Date(l.createdAt) >= new Date(String(startDate)));
  }
  if (endDate) {
    logs = logs.filter((l) => new Date(l.createdAt) <= new Date(String(endDate)));
  }
  if (search) {
    const s = String(search).toLowerCase();
    logs = logs.filter(
      (l) =>
        l.recipientName.toLowerCase().includes(s) ||
        (l.recipientContact && l.recipientContact.toLowerCase().includes(s)) ||
        l.title.toLowerCase().includes(s) ||
        l.message.toLowerCase().includes(s) ||
        (l.relatedStudentName && l.relatedStudentName.toLowerCase().includes(s)) ||
        l.dedupKey.toLowerCase().includes(s)
    );
  }

  // Sort newest first
  logs.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  const pageNum = Math.max(1, parseInt(String(page), 10) || 1);
  const limitNum = Math.max(1, Math.min(100, parseInt(String(limit), 10) || 20));
  const total = logs.length;
  const startIndex = (pageNum - 1) * limitNum;
  const paginated = logs.slice(startIndex, startIndex + limitNum);

  res.json({
    success: true,
    total,
    page: pageNum,
    totalPages: Math.ceil(total / limitNum),
    data: paginated
  });
});

/**
 * GET /api/communication/logs/:id
 * Admin only: Returns details of a specific communication log.
 */
communicationRouter.get('/logs/:id', requireAuth, requireAdmin, (req: AuthenticatedRequest, res: Response): void => {
  const { id } = req.params;
  const logs = CommunicationService.getLogs();
  const log = logs.find((l) => l.id === id);

  if (!log) {
    res.status(404).json({ success: false, error: 'Communication log not found.' });
    return;
  }

  res.json({ success: true, data: log });
});

/**
 * POST /api/communication/logs/:id/retry
 * Admin only: Retries delivery of a failed communication log.
 */
communicationRouter.post('/logs/:id/retry', requireAuth, requireAdmin, async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  const user = req.user!;
  const { id } = req.params;

  const result = await CommunicationService.retryLog(id, {
    id: user.id,
    name: user.name,
    role: user.role
  });

  if (!result.success) {
    res.status(400).json({ success: false, error: result.error });
    return;
  }

  res.json({
    success: true,
    message: 'Delivery retry attempted.',
    data: result.log
  });
});

/**
 * GET /api/communication/stats
 * Admin only: Returns system-wide communication statistics.
 */
communicationRouter.get('/stats', requireAuth, requireAdmin, (_req: AuthenticatedRequest, res: Response): void => {
  const stats = CommunicationService.getStats();
  res.json({ success: true, data: stats });
});

// =========================================================================
// USER NOTIFICATION PREFERENCES
// =========================================================================

/**
 * GET /api/communication/preferences
 * Any authenticated user: Returns their personal notification preferences.
 */
communicationRouter.get('/preferences', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  const user = req.user!;
  const preferences = CommunicationService.getUserPreferences(user.id, user.role);
  res.json({ success: true, data: preferences });
});

/**
 * PUT /api/communication/preferences
 * Any authenticated user: Updates their personal notification preferences.
 */
communicationRouter.put('/preferences', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  const user = req.user!;
  const { channels, categories } = req.body;

  const updated = CommunicationService.updateUserPreferences(user.id, {
    channels,
    categories
  }, user.role);

  res.json({
    success: true,
    message: 'Notification preferences updated successfully.',
    data: updated
  });
});

/**
 * GET /api/communication/preferences/:userId
 * Admin only: Inspects a target user's notification preferences.
 */
communicationRouter.get('/preferences/:userId', requireAuth, requireAdmin, (req: AuthenticatedRequest, res: Response): void => {
  const { userId } = req.params;
  const preferences = CommunicationService.getUserPreferences(userId);
  res.json({ success: true, data: preferences });
});

/**
 * PUT /api/communication/preferences/:userId
 * Admin only: Updates a target user's notification preferences.
 */
communicationRouter.put('/preferences/:userId', requireAuth, requireAdmin, (req: AuthenticatedRequest, res: Response): void => {
  const user = req.user!;
  const { userId } = req.params;
  const { channels, categories } = req.body;

  const updated = CommunicationService.updateUserPreferences(userId, {
    channels,
    categories
  });

  logAudit({
    userId: user.id,
    userName: user.name,
    userRole: user.role,
    action: 'UPDATE',
    entity: 'USER_PREFERENCES',
    entityType: 'USER_PREFERENCES',
    entityId: userId,
    details: `Updated notification preferences for user ${userId}.`
  });

  res.json({
    success: true,
    message: `Preferences for user ${userId} updated.`,
    data: updated
  });
});

// =========================================================================
// MANUAL / AD-HOC NOTIFICATION DISPATCH
// =========================================================================

/**
 * POST /api/communication/dispatch
 * Admin only: Manually dispatches an institutional notification or event.
 */
communicationRouter.post('/dispatch', requireAuth, requireAdmin, async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  const user = req.user!;
  const {
    eventType,
    entityId,
    entityType,
    studentId,
    guardianId,
    teacherId,
    userId,
    classId,
    sectionId,
    targetRole,
    customTitle,
    customMessage,
    variables,
    idempotencyKey
  } = req.body;

  if (!eventType) {
    res.status(400).json({ success: false, error: 'eventType is required.' });
    return;
  }

  const result = await CommunicationService.dispatch({
    eventType: eventType as CommunicationEventType,
    entityId: entityId || `adhoc-${Date.now()}`,
    entityType: entityType || 'ADHOC_BROADCAST',
    studentId,
    guardianId,
    teacherId,
    userId,
    classId,
    sectionId,
    targetRole: targetRole as UserRole | 'ALL',
    customTitle,
    customMessage,
    variables,
    idempotencyKey,
    actorUser: { id: user.id, name: user.name, role: user.role }
  });

  logAudit({
    userId: user.id,
    userName: user.name,
    userRole: user.role,
    action: 'DISPATCH',
    entity: 'COMMUNICATION',
    entityType: 'COMMUNICATION',
    details: `Dispatched communication event "${eventType}" (Sent: ${result.sentCount}, Failed: ${result.failedCount}, Duplicates: ${result.duplicateCount}).`
  });

  res.json({
    success: true,
    message: `Dispatched ${result.sentCount} message(s). ${result.failedCount > 0 ? `${result.failedCount} external delivery withheld/unconfigured.` : ''}`,
    data: result
  });
});

// =========================================================================
// PART 11B: SCHOOL ANNOUNCEMENT & NOTICE MANAGEMENT ENDPOINTS
// =========================================================================

const ALLOWED_ATTACHMENT_EXTENSIONS = [
  'pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx',
  'txt', 'csv', 'jpg', 'jpeg', 'png', 'gif', 'webp', 'zip'
];
const MAX_ATTACHMENT_BYTES = 15 * 1024 * 1024; // 15MB

function formatAttachmentSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

/**
 * Helper to build user authorization context for announcement queries
 */
function resolveAnnouncementUserContext(user: any) {
  let studentProfileId: string | undefined;
  let classId: string | undefined;
  let sectionId: string | undefined;
  let guardianId: string | undefined;
  let childIds: string[] | undefined;
  let teacherId: string | undefined;
  let assignedClassIds: string[] | undefined;

  if (user.role === 'STUDENT') {
    const sp = (database.studentProfiles || []).find((s) => s.userId === user.id);
    if (sp) {
      studentProfileId = sp.id;
      classId = sp.classId;
      sectionId = sp.sectionId;
    }
  } else if (user.role === 'GUARDIAN') {
    const g = (database.guardians || []).find((guard) => guard.userId === user.id || guard.email === user.email);
    if (g) {
      guardianId = g.id;
      childIds = g.studentIds || [];
      const firstChild = (database.studentProfiles || []).find((s) => childIds?.includes(s.id));
      if (firstChild) {
        classId = firstChild.classId;
        sectionId = firstChild.sectionId;
      }
    }
  } else if (user.role === 'TEACHER') {
    const t = (database.teacherProfiles || []).find((tp) => tp.userId === user.id || tp.email === user.email);
    if (t) {
      teacherId = t.id;
      const classIdSet = new Set<string>(t.assignedClassIds || []);
      (database.sections || []).forEach((sec) => {
        if (sec.classTeacherId === t.id && sec.classId) {
          classIdSet.add(sec.classId);
        }
      });
      (database.subjects || []).forEach((subj) => {
        if (subj.teacherId === t.id) {
          if (subj.classId) classIdSet.add(subj.classId);
          if (subj.classIds) subj.classIds.forEach((cid) => classIdSet.add(cid));
        }
      });
      assignedClassIds = Array.from(classIdSet);
    }
  }

  return {
    userId: user.id,
    role: user.role,
    studentProfileId,
    classId,
    sectionId,
    guardianId,
    childIds,
    teacherId,
    assignedClassIds
  };
}

/**
 * GET /api/communication/announcements
 * Returns filtered list of announcements scoped to user's permissions and cohort.
 */
communicationRouter.get('/announcements', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    const userContext = resolveAnnouncementUserContext(user);
    const {
      classId,
      sectionId,
      category,
      priority,
      status,
      targetAudience,
      search,
      page = '1',
      limit = '50'
    } = req.query as any;

    const result = AnnouncementService.getAnnouncements(
      {
        classId,
        sectionId,
        category,
        priority,
        status,
        targetAudience,
        search,
        page: parseInt(page, 10) || 1,
        limit: parseInt(limit, 10) || 50
      },
      userContext
    );

    const pageNum = Math.max(1, parseInt(page, 10) || 1);
    const limitNum = Math.max(1, Math.min(100, parseInt(limit, 10) || 50));
    const total = result.total;
    const paginated = result.data.slice((pageNum - 1) * limitNum, pageNum * limitNum);

    res.json({
      success: true,
      data: paginated,
      stats: result.stats,
      pagination: {
        page: pageNum,
        limit: limitNum,
        total,
        totalPages: Math.ceil(total / limitNum) || 1
      }
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message || 'Failed to fetch announcements.' });
  }
});

/**
 * GET /api/communication/announcements/stats
 * Aggregated metrics on active, scheduled, expired, and draft notices.
 */
communicationRouter.get('/announcements/stats', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const stats = AnnouncementService.getAggregatedStats();
    res.json({ success: true, data: stats });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message || 'Failed to fetch announcement metrics.' });
  }
});

/**
 * POST /api/communication/announcements/upload-attachment
 * Secure upload validation for announcement documents & media (max 15MB).
 */
communicationRouter.post('/announcements/upload-attachment', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { fileName, fileSizeBytes, fileData } = req.body as {
      fileName: string;
      fileSizeBytes: number;
      fileData?: string;
      fileType?: string;
    };

    if (!fileName || !fileName.trim()) {
      res.status(400).json({ success: false, error: 'File name is required.' });
      return;
    }

    const ext = fileName.split('.').pop()?.toLowerCase() || '';
    if (!ALLOWED_ATTACHMENT_EXTENSIONS.includes(ext)) {
      res.status(400).json({
        success: false,
        error: `Unsupported file extension .${ext}. Allowed formats: ${ALLOWED_ATTACHMENT_EXTENSIONS.join(', ')}`
      });
      return;
    }

    const size = Number(fileSizeBytes) || 0;
    if (size > MAX_ATTACHMENT_BYTES) {
      res.status(400).json({
        success: false,
        error: `File exceeds maximum allowed limit of 15MB (${formatAttachmentSize(size)} uploaded).`
      });
      return;
    }

    const sanitizedName = fileName.replace(/[^a-zA-Z0-9._-]/g, '_');
    const safeUrl = fileData && fileData.startsWith('data:')
      ? fileData
      : `https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?auto=format&fit=crop&q=80&w=800`;

    const attachment = {
      id: `att-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      fileName: sanitizedName,
      fileUrl: safeUrl,
      fileSize: formatAttachmentSize(size > 0 ? size : 1024 * 256),
      fileSizeBytes: size > 0 ? size : 1024 * 256,
      fileType: ext,
      uploadedAt: new Date().toISOString()
    };

    res.json({
      success: true,
      message: 'Attachment validated and staged successfully.',
      data: attachment
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message || 'Failed to process attachment.' });
  }
});

/**
 * POST /api/communication/announcements/preview
 * Generates an estimated audience recipient count and sanitized preview payload.
 */
communicationRouter.post('/announcements/preview', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { title, message, targetAudience, classId, sectionId, targetRoles } = req.body;

    const sanitizedTitle = (title || '').trim();
    const sanitizedBody = sanitizeAnnouncementContent(message || '');

    const dummyAnn: any = {
      targetAudience: targetAudience || 'SCHOOL_WIDE',
      classId: classId || 'ALL',
      sectionId: sectionId || 'ALL',
      targetRoles: targetRoles || []
    };

    const eligibleCount = AnnouncementService.calculateEligibleRecipients(dummyAnn);

    res.json({
      success: true,
      data: {
        title: sanitizedTitle,
        content: sanitizedBody,
        estimatedRecipients: eligibleCount,
        targetAudience: dummyAnn.targetAudience
      }
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message || 'Failed to generate preview.' });
  }
});

/**
 * GET /api/communication/announcements/:id
 * Single announcement details with read stats and linked delivery audit logs.
 */
communicationRouter.get('/announcements/:id', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    const { id } = req.params;
    const userContext = resolveAnnouncementUserContext(user);

    const ann = AnnouncementService.getAnnouncementById(id, userContext);
    if (!ann) {
      res.status(404).json({ success: false, error: 'Announcement not found or access unauthorized.' });
      return;
    }

    // Include linked communication logs for admins
    const isAdmin = user.role === 'SUPER_ADMIN' || (user.role as string) === 'ADMIN';
    let deliveryLogs = undefined;
    if (isAdmin) {
      deliveryLogs = CommunicationService.getLogs().filter(
        (l) => l.relatedEntityId === ann.id || l.entityId === ann.id
      );
    }

    res.json({
      success: true,
      data: ann,
      deliveryLogs
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message || 'Failed to fetch announcement details.' });
  }
});

/**
 * POST /api/communication/announcements
 * Creates announcement with optional immediate publish or future schedule.
 */
communicationRouter.post('/announcements', requireAuth, async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  try {
    const user = req.user!;
    const isAdmin =
      user.role === 'SUPER_ADMIN' ||
      (user.role as string) === 'ADMIN' ||
      hasPermission(user.role, 'announcements.create');

    if (!isAdmin && user.role !== 'TEACHER') {
      res.status(403).json({ success: false, error: 'Access denied: You are not authorized to create announcements.' });
      return;
    }

    const {
      title,
      message,
      category = 'general',
      priority = 'normal',
      targetAudience = 'SCHOOL_WIDE',
      targetRoles = [],
      targetUserIds = [],
      classId = 'ALL',
      sectionId = 'ALL',
      publishDate,
      scheduledPublishAt,
      expiryDate,
      expiresAt,
      isPinned = false,
      status = 'published',
      visibility = 'ALL',
      attachments = [],
      channels = { inApp: true, email: true, sms: false, push: true }
    } = req.body;

    if (!title || !title.trim()) {
      res.status(400).json({ success: false, error: 'Announcement title is required.' });
      return;
    }

    if (!message || !message.trim()) {
      res.status(400).json({ success: false, error: 'Announcement message body is required.' });
      return;
    }

    // Teacher cohort restriction check
    if (user.role === 'TEACHER' && !isAdmin) {
      if (targetAudience === 'SCHOOL_WIDE') {
        res.status(403).json({ success: false, error: 'Teachers can only post announcements for their assigned classes.' });
        return;
      }
      if (classId === 'ALL' || !classId) {
        res.status(400).json({ success: false, error: 'Please select a specific class for your announcement.' });
        return;
      }
      const context = resolveAnnouncementUserContext(user);
      if (context.assignedClassIds && !context.assignedClassIds.includes(classId)) {
        res.status(403).json({ success: false, error: 'You are not assigned to post announcements for this class.' });
        return;
      }
    }

    const created = await AnnouncementService.createAnnouncement(
      {
        title,
        message,
        category,
        priority,
        targetAudience: targetAudience as AnnouncementAudience,
        targetRoles,
        targetUserIds,
        classId,
        sectionId,
        publishDate,
        scheduledPublishAt,
        expiryDate,
        expiresAt,
        isPinned,
        status: status as AnnouncementStatus,
        visibility,
        attachments,
        channels
      },
      {
        id: user.id,
        name: user.name,
        role: user.role
      }
    );

    res.status(201).json({
      success: true,
      message: created.status === 'scheduled'
        ? 'Announcement scheduled successfully.'
        : created.status === 'draft'
          ? 'Draft saved successfully.'
          : 'Announcement published successfully.',
      data: created
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message || 'Failed to create announcement.' });
  }
});

/**
 * PUT /api/communication/announcements/:id
 * Updates an announcement
 */
communicationRouter.put('/announcements/:id', requireAuth, async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  try {
    const user = req.user!;
    const { id } = req.params;

    const result = await AnnouncementService.updateAnnouncement(id, req.body, {
      id: user.id,
      name: user.name,
      role: user.role
    });

    if (!result.success) {
      res.status(result.error?.includes('Unauthorized') ? 403 : 404).json(result);
      return;
    }

    res.json({
      success: true,
      message: 'Announcement updated successfully.',
      data: result.data
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message || 'Failed to update announcement.' });
  }
});

/**
 * POST /api/communication/announcements/:id/publish
 * Publishes an existing draft or scheduled announcement immediately
 */
communicationRouter.post('/announcements/:id/publish', requireAuth, async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  try {
    const user = req.user!;
    const { id } = req.params;

    const result = await AnnouncementService.publishAnnouncement(id, {
      id: user.id,
      name: user.name,
      role: user.role
    });

    if (!result.success) {
      res.status(404).json(result);
      return;
    }

    res.json({
      success: true,
      message: 'Announcement published immediately.',
      data: result.data
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message || 'Failed to publish announcement.' });
  }
});

/**
 * POST /api/communication/announcements/:id/cancel-schedule
 * Cancels a scheduled announcement
 */
communicationRouter.post('/announcements/:id/cancel-schedule', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    const { id } = req.params;

    const result = AnnouncementService.cancelSchedule(id, {
      id: user.id,
      name: user.name,
      role: user.role
    });

    if (!result.success) {
      res.status(400).json(result);
      return;
    }

    res.json({
      success: true,
      message: 'Scheduled announcement has been cancelled.',
      data: result.data
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message || 'Failed to cancel announcement schedule.' });
  }
});

/**
 * POST /api/communication/announcements/:id/archive
 * Archives an announcement
 */
communicationRouter.post('/announcements/:id/archive', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    const { id } = req.params;

    const result = AnnouncementService.archiveAnnouncement(id, {
      id: user.id,
      name: user.name,
      role: user.role
    });

    if (!result.success) {
      res.status(404).json(result);
      return;
    }

    res.json({
      success: true,
      message: 'Announcement archived successfully.',
      data: result.data
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message || 'Failed to archive announcement.' });
  }
});

/**
 * POST /api/communication/announcements/:id/unarchive
 * Restores an archived announcement
 */
communicationRouter.post('/announcements/:id/unarchive', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    const { id } = req.params;

    const result = AnnouncementService.unarchiveAnnouncement(id, {
      id: user.id,
      name: user.name,
      role: user.role
    });

    if (!result.success) {
      res.status(404).json(result);
      return;
    }

    res.json({
      success: true,
      message: 'Announcement unarchived successfully.',
      data: result.data
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message || 'Failed to unarchive announcement.' });
  }
});

/**
 * POST /api/communication/announcements/:id/pin
 * Toggles pinned status
 */
communicationRouter.post('/announcements/:id/pin', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    const { id } = req.params;

    const result = AnnouncementService.togglePin(id, {
      id: user.id,
      name: user.name,
      role: user.role
    });

    if (!result.success) {
      res.status(404).json(result);
      return;
    }

    res.json({
      success: true,
      message: `Announcement ${result.isPinned ? 'pinned to top' : 'unpinned'}.`,
      isPinned: result.isPinned
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message || 'Failed to toggle pinned status.' });
  }
});

/**
 * DELETE /api/communication/announcements/:id
 * Deletes an announcement
 */
communicationRouter.delete('/announcements/:id', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    const { id } = req.params;

    const result = AnnouncementService.deleteAnnouncement(id, {
      id: user.id,
      name: user.name,
      role: user.role
    });

    if (!result.success) {
      res.status(result.error?.includes('Unauthorized') ? 403 : 404).json(result);
      return;
    }

    res.json({
      success: true,
      message: 'Announcement deleted successfully.'
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message || 'Failed to delete announcement.' });
  }
});

/**
 * POST /api/communication/announcements/:id/read
 * Marks announcement as read for the authenticated user (isolated per-user read receipt).
 */
communicationRouter.post('/announcements/:id/read', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    const { id } = req.params;

    const result = AnnouncementService.markAsRead(id, {
      id: user.id,
      name: user.name,
      role: user.role
    });

    if (!result.success) {
      res.status(404).json(result);
      return;
    }

    res.json({
      success: true,
      message: 'Marked as read.'
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message || 'Failed to record read status.' });
  }
});

// =========================================================================
// PART 11C: PARENT-TEACHER & INTERNAL MESSAGING / INBOX ENDPOINTS
// =========================================================================

/**
 * GET /api/communication/inbox/conversations
 * List conversation threads for current user with folder filtering, search, and pagination.
 */
communicationRouter.get('/inbox/conversations', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    const {
      folder = 'inbox',
      category,
      search,
      studentId,
      unreadOnly,
      page = 1,
      limit = 20
    } = req.query;

    const result = MessagingService.listConversations(
      {
        id: user.id,
        name: user.name,
        role: user.role,
        email: user.email,
        avatarUrl: user.avatarUrl
      },
      {
        folder: folder as any,
        category: category as any,
        search: search as string,
        studentId: studentId as string,
        unreadOnly: unreadOnly === 'true',
        page: parseInt(page as string, 10) || 1,
        limit: parseInt(limit as string, 10) || 20
      }
    );

    res.json({
      success: true,
      ...result
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message || 'Failed to load conversations.' });
  }
});

/**
 * GET /api/communication/inbox/conversations/:id
 * Retrieve single conversation thread and all messages with strict IDOR verification.
 */
communicationRouter.get('/inbox/conversations/:id', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    const { id } = req.params;

    const result = MessagingService.getConversationById(id, {
      id: user.id,
      name: user.name,
      role: user.role,
      email: user.email,
      avatarUrl: user.avatarUrl
    });

    res.json({
      success: true,
      data: result.conversation,
      messages: result.messages
    });
  } catch (error: any) {
    const status = error.message?.includes('Forbidden') ? 403 : error.message?.includes('not found') ? 404 : 500;
    res.status(status).json({ success: false, error: error.message || 'Failed to retrieve conversation.' });
  }
});

/**
 * POST /api/communication/inbox/conversations
 * Create a new conversation and send initial message (or save as draft).
 * Enforces server-side relationship authorization.
 */
communicationRouter.post('/inbox/conversations', requireAuth, async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  try {
    const user = req.user!;
    const { recipientId, studentId, subject, message, category, attachments, isDraft } = req.body;

    const result = await MessagingService.createConversation(
      {
        id: user.id,
        name: user.name,
        role: user.role,
        email: user.email,
        avatarUrl: user.avatarUrl
      },
      {
        recipientId,
        studentId,
        subject,
        message,
        category,
        attachments,
        isDraft
      }
    );

    res.status(201).json({
      success: true,
      message: isDraft ? 'Draft saved successfully.' : 'Message sent successfully.',
      data: result.conversation,
      messageItem: result.message
    });
  } catch (error: any) {
    const status = error.message?.includes('Unauthorized') || error.message?.includes('Forbidden') ? 403 : 400;
    res.status(status).json({ success: false, error: error.message || 'Failed to send message.' });
  }
});

/**
 * POST /api/communication/inbox/conversations/:id/reply
 * Post a reply into an active conversation. Enforces participant authorization and anti-duplicate defense.
 */
communicationRouter.post('/inbox/conversations/:id/reply', requireAuth, async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  try {
    const user = req.user!;
    const { id } = req.params;
    const { message, attachments, idempotencyKey } = req.body;

    const result = await MessagingService.reply(
      id,
      {
        id: user.id,
        name: user.name,
        role: user.role,
        email: user.email,
        avatarUrl: user.avatarUrl
      },
      {
        message,
        attachments,
        idempotencyKey
      }
    );

    res.status(201).json({
      success: true,
      message: 'Reply sent successfully.',
      data: result.message,
      conversation: result.conversation
    });
  } catch (error: any) {
    const status = error.message?.includes('Forbidden') ? 403 : error.message?.includes('not found') ? 404 : 400;
    res.status(status).json({ success: false, error: error.message || 'Failed to post reply.' });
  }
});

/**
 * POST /api/communication/inbox/conversations/:id/read
 * Mark conversation as read for the authenticated user.
 */
communicationRouter.post('/inbox/conversations/:id/read', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    const { id } = req.params;

    const success = MessagingService.markAsRead(id, user.id);
    if (!success) {
      res.status(404).json({ success: false, error: 'Conversation or participant record not found.' });
      return;
    }

    res.json({ success: true, message: 'Conversation marked as read.' });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message || 'Failed to update read status.' });
  }
});

/**
 * POST /api/communication/inbox/conversations/:id/unread
 * Mark conversation as unread for the authenticated user.
 */
communicationRouter.post('/inbox/conversations/:id/unread', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    const { id } = req.params;

    const success = MessagingService.markAsUnread(id, user.id);
    if (!success) {
      res.status(404).json({ success: false, error: 'Conversation or participant record not found.' });
      return;
    }

    res.json({ success: true, message: 'Conversation marked as unread.' });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message || 'Failed to mark as unread.' });
  }
});

/**
 * POST /api/communication/inbox/conversations/:id/archive
 * Toggle archive state of conversation for authenticated user.
 */
communicationRouter.post('/inbox/conversations/:id/archive', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    const { id } = req.params;

    const isArchived = MessagingService.toggleArchive(id, user.id);
    res.json({
      success: true,
      message: isArchived ? 'Conversation archived.' : 'Conversation unarchived.',
      isArchived
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message || 'Failed to toggle archive status.' });
  }
});

/**
 * POST /api/communication/inbox/conversations/:id/star
 * Toggle star state of conversation for authenticated user.
 */
communicationRouter.post('/inbox/conversations/:id/star', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    const { id } = req.params;

    const isStarred = MessagingService.toggleStar(id, user.id);
    res.json({
      success: true,
      message: isStarred ? 'Conversation starred.' : 'Conversation unstarred.',
      isStarred
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message || 'Failed to toggle star.' });
  }
});

/**
 * POST /api/communication/inbox/conversations/:id/report
 * Report inappropriate message or conversation to administrative moderation.
 */
communicationRouter.post('/inbox/conversations/:id/report', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    const { id } = req.params;
    const { reason, details } = req.body;

    if (!reason) {
      res.status(400).json({ success: false, error: 'Reason for report is required.' });
      return;
    }

    const report = MessagingService.reportConversation(
      id,
      {
        id: user.id,
        name: user.name,
        role: user.role,
        email: user.email,
        avatarUrl: user.avatarUrl
      },
      reason,
      details
    );

    res.json({
      success: true,
      message: 'Conversation reported to administration for review.',
      data: report
    });
  } catch (error: any) {
    const status = error.message?.includes('Forbidden') ? 403 : error.message?.includes('not found') ? 404 : 500;
    res.status(status).json({ success: false, error: error.message || 'Failed to report conversation.' });
  }
});

/**
 * DELETE /api/communication/inbox/conversations/:id/draft
 * Delete a draft conversation.
 */
communicationRouter.delete('/inbox/conversations/:id/draft', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    const { id } = req.params;

    const draftIndex = database.conversations.findIndex(
      (c) => c.id === id && c.isDraft && c.createdBy === user.id
    );

    if (draftIndex === -1) {
      res.status(404).json({ success: false, error: 'Draft not found or you are not authorized to delete it.' });
      return;
    }

    database.conversations.splice(draftIndex, 1);
    res.json({ success: true, message: 'Draft discarded.' });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message || 'Failed to discard draft.' });
  }
});

/**
 * GET /api/communication/inbox/eligible-recipients
 * List all permitted recipients strictly filtered by server-side relationship policies.
 */
communicationRouter.get('/inbox/eligible-recipients', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    const { studentId } = req.query;

    const recipients = MessagingService.getEligibleRecipients(
      {
        id: user.id,
        name: user.name,
        role: user.role,
        email: user.email,
        avatarUrl: user.avatarUrl
      },
      studentId as string | undefined
    );

    res.json({
      success: true,
      data: recipients
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message || 'Failed to fetch eligible recipients.' });
  }
});

/**
 * GET /api/communication/inbox/unread-count
 * Returns total unread conversation count for current user's notification badge.
 */
communicationRouter.get('/inbox/unread-count', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    const count = MessagingService.getUnreadCount(user.id);
    res.json({ success: true, unreadCount: count });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message || 'Failed to fetch unread count.' });
  }
});

/**
 * GET /api/communication/inbox/reports
 * Admin only: View flagged/reported messages for institutional moderation.
 */
communicationRouter.get('/inbox/reports', requireAuth, requireAdmin, (_req: AuthenticatedRequest, res: Response): void => {
  try {
    const reports = MessagingService.getReports();
    res.json({ success: true, data: reports });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message || 'Failed to fetch moderation reports.' });
  }
});

/**
 * POST /api/communication/inbox/reports/:id/resolve
 * Admin only: Resolve a flagged message report.
 */
communicationRouter.post('/inbox/reports/:id/resolve', requireAuth, requireAdmin, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    const { id } = req.params;
    const { status, resolutionNotes } = req.body;

    if (!status || !['reviewed', 'dismissed', 'action_taken'].includes(status)) {
      res.status(400).json({ success: false, error: 'Valid resolution status is required.' });
      return;
    }

    const resolved = MessagingService.resolveReport(
      id,
      {
        id: user.id,
        name: user.name,
        role: user.role,
        email: user.email,
        avatarUrl: user.avatarUrl
      },
      status,
      resolutionNotes
    );

    res.json({ success: true, message: 'Report resolved.', data: resolved });
  } catch (error: any) {
    const statusCode = error.message?.includes('not found') ? 404 : 500;
    res.status(statusCode).json({ success: false, error: error.message || 'Failed to resolve report.' });
  }
});

// =========================================================================
// PART 11D: BULK COMMUNICATION & TARGETED MESSAGE CAMPAIGN ROUTES
// =========================================================================

/**
 * GET /api/communication/campaigns
 * Admin only: List bulk communication campaigns with filters, search, and pagination.
 */
communicationRouter.get('/campaigns', requireAuth, requireAdmin, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { search, status, category, audienceType, startDate, endDate, page, limit } = req.query;
    const result = BulkCampaignService.getCampaigns({
      search: search as string,
      status: status as string,
      category: category as string,
      audienceType: audienceType as string,
      startDate: startDate as string,
      endDate: endDate as string,
      page: page ? Number(page) : 1,
      limit: limit ? Number(limit) : 10
    });

    res.json({ success: true, ...result });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Failed to fetch campaigns.' });
  }
});

/**
 * GET /api/communication/campaigns/stats
 * Admin only: Get aggregate statistics for campaigns.
 */
communicationRouter.get('/campaigns/stats', requireAuth, requireAdmin, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const stats = BulkCampaignService.getCampaignStats();
    res.json({ success: true, data: stats });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Failed to fetch campaign stats.' });
  }
});

/**
 * POST /api/communication/campaigns/preview-recipients
 * Admin only: Authoritatively resolve audience without sending or writing delivery logs.
 */
communicationRouter.post('/campaigns/preview-recipients', requireAuth, requireAdmin, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const {
      audienceType,
      academicSessionId,
      classId,
      sectionId,
      targetRoles,
      selectedRecipientIds,
      relationshipType,
      subjectId,
      channels
    } = req.body;

    if (!audienceType) {
      res.status(400).json({ success: false, error: 'Audience type is required for preview calculation.' });
      return;
    }

    const preview = BulkCampaignService.previewRecipients({
      audienceType,
      academicSessionId,
      classId,
      sectionId,
      targetRoles,
      selectedRecipientIds,
      relationshipType,
      subjectId,
      channels
    });

    res.json({ success: true, data: preview });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Failed to generate recipient preview.' });
  }
});

/**
 * GET /api/communication/campaigns/:id
 * Admin only: Get campaign details and recipient summary.
 */
communicationRouter.get('/campaigns/:id', requireAuth, requireAdmin, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { id } = req.params;
    const result = BulkCampaignService.getCampaignById(id);
    if (!result) {
      res.status(404).json({ success: false, error: 'Campaign not found.' });
      return;
    }

    res.json({ success: true, data: result.campaign, recipients: result.recipients });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Failed to fetch campaign details.' });
  }
});

/**
 * GET /api/communication/campaigns/:id/recipients
 * Admin only: Paginated recipient delivery logs for a campaign.
 */
communicationRouter.get('/campaigns/:id/recipients', requireAuth, requireAdmin, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { id } = req.params;
    const { page = '1', limit = '20', search, status } = req.query;

    const allRecipients = database.bulkCampaignRecipients?.filter((r) => r.campaignId === id) || [];
    let filtered = [...allRecipients];

    if (search) {
      const q = (search as string).toLowerCase().trim();
      filtered = filtered.filter(
        (r) =>
          r.recipientName.toLowerCase().includes(q) ||
          (r.contact && r.contact.toLowerCase().includes(q)) ||
          (r.studentName && r.studentName.toLowerCase().includes(q))
      );
    }

    if (status && status !== 'all') {
      filtered = filtered.filter((r) => r.status === status);
    }

    const total = filtered.length;
    const p = Math.max(1, Number(page));
    const l = Math.min(100, Math.max(1, Number(limit)));
    const totalPages = Math.ceil(total / l) || 1;
    const startIndex = (p - 1) * l;
    const paginated = filtered.slice(startIndex, startIndex + l);

    res.json({
      success: true,
      data: paginated,
      total,
      pagination: {
        page: p,
        limit: l,
        totalPages
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message || 'Failed to fetch campaign recipients.' });
  }
});

/**
 * POST /api/communication/campaigns
 * Admin only: Create a new campaign (in DRAFT, SCHEDULED, or IMMEDIATE).
 */
communicationRouter.post('/campaigns', requireAuth, requireAdmin, async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  try {
    const user = req.user!;
    const campaign = await BulkCampaignService.createCampaign(req.body, {
      id: user.id,
      name: user.name,
      role: user.role
    });

    res.status(201).json({
      success: true,
      message:
        campaign.status === 'SCHEDULED'
          ? 'Campaign successfully scheduled for dispatch.'
          : campaign.scheduleType === 'IMMEDIATE' && campaign.status === 'PROCESSING'
          ? 'Campaign created and queued for immediate delivery.'
          : 'Campaign draft created successfully.',
      data: campaign
    });
  } catch (err: any) {
    res.status(400).json({ success: false, error: err.message || 'Failed to create campaign.' });
  }
});

/**
 * PUT /api/communication/campaigns/:id
 * Admin only: Update a draft campaign.
 */
communicationRouter.put('/campaigns/:id', requireAuth, requireAdmin, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    const { id } = req.params;
    const updated = BulkCampaignService.updateCampaign(id, req.body, {
      id: user.id,
      name: user.name,
      role: user.role
    });

    res.json({ success: true, message: 'Campaign draft updated successfully.', data: updated });
  } catch (err: any) {
    const statusCode = err.message?.includes('not found') ? 404 : 400;
    res.status(statusCode).json({ success: false, error: err.message || 'Failed to update campaign.' });
  }
});

/**
 * POST /api/communication/campaigns/:id/send
 * Admin only: Immediately dispatch a campaign.
 */
communicationRouter.post('/campaigns/:id/send', requireAuth, requireAdmin, async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  try {
    const user = req.user!;
    const { id } = req.params;
    const sent = await BulkCampaignService.sendCampaignNow(id, {
      id: user.id,
      name: user.name,
      role: user.role
    });

    res.json({
      success: true,
      message: 'Campaign has been placed in processing queue and dispatch has commenced.',
      data: sent
    });
  } catch (err: any) {
    const statusCode = err.message?.includes('not found') ? 404 : 400;
    res.status(statusCode).json({ success: false, error: err.message || 'Failed to dispatch campaign.' });
  }
});

/**
 * POST /api/communication/campaigns/:id/schedule
 * Admin only: Schedule a campaign for a future date/time.
 */
communicationRouter.post('/campaigns/:id/schedule', requireAuth, requireAdmin, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    const { id } = req.params;
    const { scheduledAt } = req.body;

    if (!scheduledAt) {
      res.status(400).json({ success: false, error: 'Scheduled date/time is required.' });
      return;
    }

    const scheduled = BulkCampaignService.scheduleCampaign(id, scheduledAt, {
      id: user.id,
      name: user.name,
      role: user.role
    });

    res.json({
      success: true,
      message: `Campaign scheduled for dispatch at ${scheduled.scheduledAt}.`,
      data: scheduled
    });
  } catch (err: any) {
    const statusCode = err.message?.includes('not found') ? 404 : 400;
    res.status(statusCode).json({ success: false, error: err.message || 'Failed to schedule campaign.' });
  }
});

/**
 * POST /api/communication/campaigns/:id/cancel
 * Admin only: Cancel a scheduled or processing campaign.
 */
communicationRouter.post('/campaigns/:id/cancel', requireAuth, requireAdmin, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    const { id } = req.params;
    const { reason } = req.body;

    const cancelled = BulkCampaignService.cancelCampaign(id, reason, {
      id: user.id,
      name: user.name,
      role: user.role
    });

    res.json({
      success: true,
      message: 'Campaign has been cancelled.',
      data: cancelled
    });
  } catch (err: any) {
    const statusCode = err.message?.includes('not found') ? 404 : 400;
    res.status(statusCode).json({ success: false, error: err.message || 'Failed to cancel campaign.' });
  }
});

/**
 * POST /api/communication/campaigns/:id/archive
 * Admin only: Archive a completed or cancelled campaign.
 */
communicationRouter.post('/campaigns/:id/archive', requireAuth, requireAdmin, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    const { id } = req.params;

    const archived = BulkCampaignService.archiveCampaign(id, {
      id: user.id,
      name: user.name,
      role: user.role
    });

    res.json({
      success: true,
      message: 'Campaign has been moved to archive.',
      data: archived
    });
  } catch (err: any) {
    const statusCode = err.message?.includes('not found') ? 404 : 400;
    res.status(statusCode).json({ success: false, error: err.message || 'Failed to archive campaign.' });
  }
});

// =========================================================================
// PART 11E: COMMUNICATION ANALYTICS, DELIVERY REPORTS & SCHEDULER AUDIT
// =========================================================================

/**
 * GET /api/communication/analytics/overview
 * Admin only: Multi-channel aggregate communication metrics and operational overview.
 */
communicationRouter.get(
  '/analytics/overview',
  requireAuth,
  requireAdmin,
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const filters = {
        datePreset: req.query.datePreset as any,
        startDate: req.query.startDate as string,
        endDate: req.query.endDate as string,
        academicSessionId: req.query.academicSessionId as string,
        classId: req.query.classId as string,
        sectionId: req.query.sectionId as string,
        recipientRole: req.query.recipientRole as string,
        category: req.query.category as string,
        channel: req.query.channel as any,
        status: req.query.status as any
      };

      const overview = CommunicationAnalyticsService.getAnalyticsOverview(filters);
      res.json({
        success: true,
        data: overview
      });
    } catch (err: any) {
      res.status(500).json({
        success: false,
        error: err.message || 'Failed to retrieve communication analytics overview.'
      });
    }
  }
);

/**
 * GET /api/communication/analytics/delivery-reports
 * Admin only: Paginated delivery ledger with privacy masking and search filters.
 */
communicationRouter.get(
  '/analytics/delivery-reports',
  requireAuth,
  requireAdmin,
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const query = {
        page: req.query.page ? Number(req.query.page) : 1,
        limit: req.query.limit ? Number(req.query.limit) : 20,
        search: req.query.search as string,
        channel: req.query.channel as string,
        status: req.query.status as string,
        recipientRole: req.query.recipientRole as string,
        eventType: req.query.eventType as string,
        startDate: req.query.startDate as string,
        endDate: req.query.endDate as string,
        sortBy: req.query.sortBy as any,
        sortOrder: req.query.sortOrder as any
      };

      const report = CommunicationAnalyticsService.getDeliveryReport(query);
      res.json({
        success: true,
        data: report.data,
        total: report.total,
        page: report.page,
        limit: report.limit,
        totalPages: report.totalPages,
        stats: report.stats
      });
    } catch (err: any) {
      res.status(500).json({
        success: false,
        error: err.message || 'Failed to retrieve delivery reports.'
      });
    }
  }
);

/**
 * GET /api/communication/analytics/export
 * Admin only: Secure export of sanitized communication reports in CSV or JSON.
 */
communicationRouter.get(
  '/analytics/export',
  requireAuth,
  requireAdmin,
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const user = req.user!;
      const type = (req.query.type as any) || 'delivery';
      const format = (req.query.format as any) || 'csv';

      const filters = {
        datePreset: req.query.datePreset as any,
        startDate: req.query.startDate as string,
        endDate: req.query.endDate as string,
        channel: req.query.channel as string,
        status: req.query.status as string,
        recipientRole: req.query.recipientRole as string,
        search: req.query.search as string
      };

      const result = CommunicationAnalyticsService.exportReport(type, format, filters, {
        id: user.id,
        name: user.name,
        role: user.role
      });

      res.setHeader('Content-Type', result.mimeType);
      res.setHeader('Content-Disposition', `attachment; filename="${result.filename}"`);
      res.status(200).send(result.content);
    } catch (err: any) {
      res.status(500).json({
        success: false,
        error: err.message || 'Failed to export communication report.'
      });
    }
  }
);

/**
 * POST /api/communication/analytics/cancel-scheduled
 * Admin only: Cancel a scheduled announcement or bulk campaign.
 */
communicationRouter.post(
  '/analytics/cancel-scheduled',
  requireAuth,
  requireAdmin,
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const user = req.user!;
      const { id, type } = req.body;

      if (!id || !type) {
        res.status(400).json({ success: false, error: 'Communication ID and type are required.' });
        return;
      }

      if (type !== 'CAMPAIGN' && type !== 'ANNOUNCEMENT') {
        res.status(400).json({ success: false, error: 'Invalid communication type. Expected CAMPAIGN or ANNOUNCEMENT.' });
        return;
      }

      const result = CommunicationAnalyticsService.cancelScheduledCommunication(id, type, {
        id: user.id,
        name: user.name,
        role: user.role
      });

      res.json({
        success: true,
        message: result.message
      });
    } catch (err: any) {
      res.status(400).json({
        success: false,
        error: err.message || 'Failed to cancel scheduled communication.'
      });
    }
  }
);



