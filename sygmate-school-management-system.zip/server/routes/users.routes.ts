import { Router, Response } from 'express';
import { database, StoredUser } from '../db/database.js';
import {
  requireAuth,
  requirePermission,
  AuthenticatedRequest,
  hashPassword,
  hasPermission,
  invalidateUserSessions,
  generateSecureToken,
  validatePasswordStrength
} from '../security/auth.js';
import { logAudit } from '../security/audit.js';
import {
  TeacherProfile,
  StudentProfile,
  Guardian,
  ParentStudentRelationship,
  Family,
  User,
  SchoolClass,
  Section,
  Subject,
  Department,
  ParentInvitation,
  PasswordResetToken,
  GuardianAccountInfo
} from '../../src/types/index.js';

const SEED_SALT = 'e5f2a1b8c9d0e7f4a3b2c1d0e9f8a7b6';

export const usersRouter = Router();

// Helper to sanitize user object
function sanitizeUser(user: any) {
  if (!user) return null;
  const { passwordHash, passwordSalt, ...rest } = user;
  return rest;
}

// =========================================================================
// 1. TEACHER MANAGEMENT
// =========================================================================

/**
 * GET /api/users/teachers
 * Retrieve list of teachers with filtering and search
 */
usersRouter.get('/teachers', requireAuth, requirePermission('teachers.view'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { search, departmentId, status } = req.query as {
      search?: string;
      departmentId?: string;
      status?: string;
    };

    let list = database.teacherProfiles.map((profile) => {
      const user = database.users.find((u) => u.id === profile.userId);
      const assignedClasses = database.classes.filter((c) => profile.assignedClassIds?.includes(c.id));
      const assignedSubjects = database.subjects.filter((s) => profile.assignedSubjectIds?.includes(s.id));
      const dept = database.departments.find((d) => d.id === profile.departmentId || d.name.toLowerCase() === profile.department?.toLowerCase());
      
      const nameParts = (user?.name || profile.firstName ? `${profile.firstName || ''} ${profile.lastName || ''}`.trim() : 'Faculty Member').split(' ');
      const firstName = profile.firstName || nameParts[0] || 'Faculty';
      const lastName = profile.lastName || nameParts.slice(1).join(' ') || 'Member';

      return {
        ...profile,
        firstName,
        lastName,
        email: profile.email || user?.email || 'faculty@sygmate.edu',
        phone: profile.phone || profile.contactNumber || user?.phoneNumber || '',
        contactNumber: profile.contactNumber || profile.phone || user?.phoneNumber || '',
        departmentId: dept?.id || profile.departmentId || '',
        department: dept?.name || profile.department || 'Academic Department',
        departmentName: dept?.name || profile.department || 'Academic Department',
        user: sanitizeUser(user),
        assignedClasses,
        assignedSubjects,
        subjects: assignedSubjects.map((s) => s.name)
      };
    });

    // Apply Search Filter
    if (search && search.trim()) {
      const q = search.toLowerCase().trim();
      list = list.filter((t) =>
        t.firstName.toLowerCase().includes(q) ||
        t.lastName.toLowerCase().includes(q) ||
        `${t.firstName} ${t.lastName}`.toLowerCase().includes(q) ||
        t.employeeCode.toLowerCase().includes(q) ||
        t.email.toLowerCase().includes(q) ||
        t.designation.toLowerCase().includes(q) ||
        t.department.toLowerCase().includes(q)
      );
    }

    // Apply Department Filter
    if (departmentId && departmentId !== 'ALL') {
      list = list.filter((t) => t.departmentId === departmentId);
    }

    // Apply Status Filter
    if (status && status !== 'ALL') {
      list = list.filter((t) => t.status.toLowerCase() === status.toLowerCase());
    }

    // Sort by employee code or name
    list.sort((a, b) => a.employeeCode.localeCompare(b.employeeCode));

    res.json({
      success: true,
      data: list
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * GET /api/users/teachers/:id
 * Retrieve single teacher dossier
 */
usersRouter.get('/teachers/:id', requireAuth, requirePermission('teachers.view'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { id } = req.params;
    const profile = database.teacherProfiles.find((t) => t.id === id || t.userId === id);
    if (!profile) {
      res.status(404).json({ success: false, error: 'Teacher profile not found.' });
      return;
    }

    const user = database.users.find((u) => u.id === profile.userId);
    const assignedClasses = database.classes.filter((c) => profile.assignedClassIds?.includes(c.id));
    const assignedSubjects = database.subjects.filter((s) => profile.assignedSubjectIds?.includes(s.id));
    const dept = database.departments.find((d) => d.id === profile.departmentId || d.name.toLowerCase() === profile.department?.toLowerCase());

    const nameParts = (user?.name || `${profile.firstName || ''} ${profile.lastName || ''}`.trim()).split(' ');
    const firstName = profile.firstName || nameParts[0] || 'Faculty';
    const lastName = profile.lastName || nameParts.slice(1).join(' ') || 'Member';

    res.json({
      success: true,
      data: {
        ...profile,
        firstName,
        lastName,
        email: profile.email || user?.email || 'faculty@sygmate.edu',
        phone: profile.phone || profile.contactNumber || user?.phoneNumber || '',
        contactNumber: profile.contactNumber || profile.phone || '',
        departmentId: dept?.id || profile.departmentId || '',
        department: dept?.name || profile.department || 'Academic Department',
        departmentName: dept?.name || profile.department || 'Academic Department',
        user: sanitizeUser(user),
        assignedClasses,
        assignedSubjects,
        subjects: assignedSubjects.map((s) => s.name)
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * POST /api/users/teachers
 * Create a new Teacher and associated user account
 */
usersRouter.post('/teachers', requireAuth, requirePermission('teachers.create'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const {
      firstName,
      lastName,
      employeeCode,
      email,
      phone,
      contactNumber,
      emergencyContact,
      dateOfBirth,
      gender,
      address,
      departmentId,
      designation,
      qualification,
      specialization,
      joiningDate,
      employmentStatus,
      status,
      assignedClassIds,
      assignedSubjectIds,
      initialPassword
    } = req.body;

    // Required Field Validations
    if (!firstName || !firstName.trim()) {
      res.status(400).json({ success: false, error: 'First name is required.' });
      return;
    }
    if (!lastName || !lastName.trim()) {
      res.status(400).json({ success: false, error: 'Last name is required.' });
      return;
    }
    if (!employeeCode || !employeeCode.trim()) {
      res.status(400).json({ success: false, error: 'Teacher ID / Employee Code is required.' });
      return;
    }
    if (!email || !email.trim()) {
      res.status(400).json({ success: false, error: 'Email address is required.' });
      return;
    }
    if (!designation || !designation.trim()) {
      res.status(400).json({ success: false, error: 'Designation is required.' });
      return;
    }

    const trimmedCode = employeeCode.trim();
    const trimmedEmail = email.trim().toLowerCase();

    // Check Unique Employee Code
    const codeExists = database.teacherProfiles.some(
      (t) => t.employeeCode.toLowerCase() === trimmedCode.toLowerCase()
    );
    if (codeExists) {
      res.status(400).json({ success: false, error: `Teacher ID "${trimmedCode}" is already assigned to another faculty member.` });
      return;
    }

    // Check Unique Email across system users
    const emailExists = database.users.some(
      (u) => u.email.toLowerCase() === trimmedEmail
    );
    if (emailExists) {
      res.status(400).json({ success: false, error: `Email address "${trimmedEmail}" is already in use by an existing account.` });
      return;
    }

    // Validate Department if provided
    let deptName = 'General Faculty';
    let validDeptId = departmentId;
    if (departmentId) {
      const dept = database.departments.find((d) => d.id === departmentId);
      if (dept) {
        deptName = dept.name;
        validDeptId = dept.id;
      }
    }

    // Validate Classes
    const validClassIds = Array.isArray(assignedClassIds)
      ? assignedClassIds.filter((cid: string) => database.classes.some((c) => c.id === cid))
      : [];

    // Validate Subjects
    const validSubjectIds = Array.isArray(assignedSubjectIds)
      ? assignedSubjectIds.filter((sid: string) => database.subjects.some((s) => s.id === sid))
      : [];

    // Create User Account
    const userId = `usr-teacher-${Date.now()}`;
    const teacherProfId = `teacher-prof-${Date.now()}`;
    const fullName = `${firstName.trim()} ${lastName.trim()}`;
    const username = (firstName.charAt(0) + lastName).toLowerCase().replace(/[^a-z0-9]/g, '');

    const pwd = initialPassword && initialPassword.trim() ? initialPassword.trim() : 'Teacher@123';
    const hashData = hashPassword(pwd, SEED_SALT);

    const newUser = {
      id: userId,
      name: fullName,
      firstName: firstName.trim(),
      lastName: lastName.trim(),
      email: trimmedEmail,
      username: `${username}${Math.floor(100 + Math.random() * 900)}`,
      role: 'TEACHER' as const,
      status: (status?.toLowerCase() === 'inactive' || status?.toLowerCase() === 'suspended' ? 'suspended' : 'active') as 'active' | 'suspended',
      phoneNumber: phone || contactNumber || '',
      passwordHash: hashData.hash,
      passwordSalt: hashData.salt,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    database.users.push(newUser);

    // Create Teacher Profile
    const newTeacherProfile: TeacherProfile = {
      id: teacherProfId,
      userId: userId,
      employeeCode: trimmedCode,
      firstName: firstName.trim(),
      lastName: lastName.trim(),
      email: trimmedEmail,
      phone: phone || contactNumber || '',
      contactNumber: contactNumber || phone || '',
      emergencyContact: emergencyContact || '',
      dateOfBirth: dateOfBirth || '',
      gender: gender || 'other',
      address: address || '',
      departmentId: validDeptId,
      department: deptName,
      departmentName: deptName,
      designation: designation.trim(),
      qualification: qualification ? qualification.trim() : 'B.Ed. / Bachelor Degree',
      specialization: specialization ? specialization.trim() : '',
      joiningDate: joiningDate || new Date().toISOString().split('T')[0],
      employmentStatus: employmentStatus || 'full_time',
      status: status || 'active',
      assignedClassIds: validClassIds,
      assignedSubjectIds: validSubjectIds,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    database.teacherProfiles.push(newTeacherProfile);

    // Audit Trail
    logAudit({
      userId: req.user!.id,
      userName: req.user!.name,
      userRole: req.user!.role,
      action: 'CREATE',
      entity: 'TEACHER',
      entityType: 'TEACHER',
      entityId: teacherProfId,
      details: `Created new teacher profile for ${fullName} (${trimmedCode}) in ${deptName}.`,
      ipAddress: req.ip
    });

    res.status(201).json({
      success: true,
      message: `Teacher profile for ${fullName} created successfully.`,
      data: {
        ...newTeacherProfile,
        user: sanitizeUser(newUser),
        assignedClasses: database.classes.filter((c) => validClassIds.includes(c.id)),
        assignedSubjects: database.subjects.filter((s) => validSubjectIds.includes(s.id))
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * PUT /api/users/teachers/:id
 * Update Teacher details and synchronize user account
 */
usersRouter.put('/teachers/:id', requireAuth, requirePermission('teachers.edit'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { id } = req.params;
    const index = database.teacherProfiles.findIndex((t) => t.id === id || t.userId === id);
    if (index === -1) {
      res.status(404).json({ success: false, error: 'Teacher profile not found.' });
      return;
    }

    const existingProfile = database.teacherProfiles[index];
    const userIndex = database.users.findIndex((u) => u.id === existingProfile.userId);

    const {
      firstName,
      lastName,
      employeeCode,
      email,
      phone,
      contactNumber,
      emergencyContact,
      dateOfBirth,
      gender,
      address,
      departmentId,
      designation,
      qualification,
      specialization,
      joiningDate,
      employmentStatus,
      status,
      assignedClassIds,
      assignedSubjectIds
    } = req.body;

    // Check unique employee code if updated
    if (employeeCode && employeeCode.trim().toLowerCase() !== existingProfile.employeeCode.toLowerCase()) {
      const codeExists = database.teacherProfiles.some(
        (t) => t.id !== existingProfile.id && t.employeeCode.toLowerCase() === employeeCode.trim().toLowerCase()
      );
      if (codeExists) {
        res.status(400).json({ success: false, error: `Teacher ID "${employeeCode.trim()}" is already assigned to another faculty member.` });
        return;
      }
    }

    // Check unique email if updated
    if (email && email.trim().toLowerCase() !== existingProfile.email?.toLowerCase()) {
      const emailExists = database.users.some(
        (u) => u.id !== existingProfile.userId && u.email.toLowerCase() === email.trim().toLowerCase()
      );
      if (emailExists) {
        res.status(400).json({ success: false, error: `Email address "${email.trim()}" is already in use.` });
        return;
      }
    }

    // Validate Department
    let deptName = existingProfile.department;
    let validDeptId = existingProfile.departmentId;
    if (departmentId) {
      const dept = database.departments.find((d) => d.id === departmentId);
      if (dept) {
        deptName = dept.name;
        validDeptId = dept.id;
      }
    }

    // Update Profile
    const updatedProfile: TeacherProfile = {
      ...existingProfile,
      employeeCode: employeeCode ? employeeCode.trim() : existingProfile.employeeCode,
      firstName: firstName !== undefined ? firstName.trim() : existingProfile.firstName,
      lastName: lastName !== undefined ? lastName.trim() : existingProfile.lastName,
      email: email ? email.trim().toLowerCase() : existingProfile.email,
      phone: phone || contactNumber || existingProfile.phone,
      contactNumber: contactNumber || phone || existingProfile.contactNumber,
      emergencyContact: emergencyContact !== undefined ? emergencyContact : existingProfile.emergencyContact,
      dateOfBirth: dateOfBirth !== undefined ? dateOfBirth : existingProfile.dateOfBirth,
      gender: gender !== undefined ? gender : existingProfile.gender,
      address: address !== undefined ? address : existingProfile.address,
      departmentId: validDeptId,
      department: deptName,
      departmentName: deptName,
      designation: designation !== undefined ? designation.trim() : existingProfile.designation,
      qualification: qualification !== undefined ? qualification.trim() : existingProfile.qualification,
      specialization: specialization !== undefined ? specialization.trim() : existingProfile.specialization,
      joiningDate: joiningDate !== undefined ? joiningDate : existingProfile.joiningDate,
      employmentStatus: employmentStatus !== undefined ? employmentStatus : existingProfile.employmentStatus,
      status: status !== undefined ? status : existingProfile.status,
      assignedClassIds: Array.isArray(assignedClassIds) ? assignedClassIds : existingProfile.assignedClassIds,
      assignedSubjectIds: Array.isArray(assignedSubjectIds) ? assignedSubjectIds : existingProfile.assignedSubjectIds,
      updatedAt: new Date().toISOString()
    };

    database.teacherProfiles[index] = updatedProfile;

    // Update Linked User
    if (userIndex !== -1) {
      const existingUser = database.users[userIndex];
      const newFullName = `${updatedProfile.firstName || ''} ${updatedProfile.lastName || ''}`.trim() || existingUser.name;
      database.users[userIndex] = {
        ...existingUser,
        name: newFullName,
        firstName: updatedProfile.firstName,
        lastName: updatedProfile.lastName,
        email: updatedProfile.email || existingUser.email,
        phoneNumber: updatedProfile.contactNumber || existingUser.phoneNumber,
        status: updatedProfile.status.toLowerCase() === 'inactive' || updatedProfile.status.toLowerCase() === 'suspended' ? 'suspended' : 'active',
        updatedAt: new Date().toISOString()
      };
    }

    logAudit({
      userId: req.user!.id,
      userName: req.user!.name,
      userRole: req.user!.role,
      action: 'UPDATE',
      entity: 'TEACHER',
      entityType: 'TEACHER',
      entityId: existingProfile.id,
      details: `Updated teacher profile for ${updatedProfile.firstName} ${updatedProfile.lastName} (${updatedProfile.employeeCode}).`,
      ipAddress: req.ip
    });

    res.json({
      success: true,
      message: 'Teacher profile updated successfully.',
      data: updatedProfile
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * PATCH /api/users/teachers/:id/status
 * Toggle Teacher Active / Inactive / On Leave / Suspended status
 */
usersRouter.patch('/teachers/:id/status', requireAuth, requirePermission('teachers.edit'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    if (!status) {
      res.status(400).json({ success: false, error: 'Status value is required.' });
      return;
    }

    const index = database.teacherProfiles.findIndex((t) => t.id === id || t.userId === id);
    if (index === -1) {
      res.status(404).json({ success: false, error: 'Teacher profile not found.' });
      return;
    }

    const teacher = database.teacherProfiles[index];
    teacher.status = status;
    teacher.updatedAt = new Date().toISOString();

    const userIndex = database.users.findIndex((u) => u.id === teacher.userId);
    if (userIndex !== -1) {
      database.users[userIndex].status = status.toLowerCase() === 'active' ? 'active' : 'suspended';
      database.users[userIndex].updatedAt = new Date().toISOString();
    }

    logAudit({
      userId: req.user!.id,
      userName: req.user!.name,
      userRole: req.user!.role,
      action: 'UPDATE',
      entity: 'TEACHER',
      entityType: 'TEACHER',
      entityId: teacher.id,
      details: `Changed teacher status for ${teacher.employeeCode} to "${status}".`,
      ipAddress: req.ip
    });

    res.json({
      success: true,
      message: `Teacher status updated to ${status}.`,
      data: teacher
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * DELETE /api/users/teachers/:id
 * Safely delete teacher or warn if active dependencies exist
 */
usersRouter.delete('/teachers/:id', requireAuth, requirePermission('teachers.delete'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { id } = req.params;
    const index = database.teacherProfiles.findIndex((t) => t.id === id || t.userId === id);
    if (index === -1) {
      res.status(404).json({ success: false, error: 'Teacher profile not found.' });
      return;
    }

    const teacher = database.teacherProfiles[index];

    // Check if teacher is assigned as Class Teacher in any Section
    const activeSection = database.sections.find((s) => s.classTeacherId === teacher.id);
    if (activeSection) {
      res.status(400).json({
        success: false,
        error: `Cannot delete teacher. ${teacher.employeeCode} is currently designated as Class Teacher for section "${activeSection.name}". Please reassign the class teacher first.`
      });
      return;
    }

    // Check if teacher is head of any Department
    const activeDept = database.departments.find((d) => d.headOfDepartmentId === teacher.id);
    if (activeDept) {
      res.status(400).json({
        success: false,
        error: `Cannot delete teacher. ${teacher.employeeCode} is currently designated as Head of "${activeDept.name}". Please reassign the department head first.`
      });
      return;
    }

    // Delete Teacher Profile
    database.teacherProfiles.splice(index, 1);

    // Delete Linked User Account
    const userIndex = database.users.findIndex((u) => u.id === teacher.userId);
    if (userIndex !== -1) {
      database.users.splice(userIndex, 1);
    }

    logAudit({
      userId: req.user!.id,
      userName: req.user!.name,
      userRole: req.user!.role,
      action: 'DELETE',
      entity: 'TEACHER',
      entityType: 'TEACHER',
      entityId: teacher.id,
      details: `Deleted teacher profile ${teacher.employeeCode} (${teacher.firstName} ${teacher.lastName}).`,
      ipAddress: req.ip
    });

    res.json({
      success: true,
      message: `Teacher ${teacher.employeeCode} deleted successfully.`
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// =========================================================================
// 2. STUDENT MANAGEMENT
// =========================================================================

/**
 * GET /api/users/students
 * Retrieve list of students with comprehensive search, filters, sorting, and pagination
 */
usersRouter.get('/students', requireAuth, requirePermission('students.view'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const {
      search,
      academicSessionId,
      classId,
      sectionId,
      status,
      gender,
      page,
      limit,
      sortBy = 'admissionNumber',
      sortOrder = 'asc'
    } = req.query as {
      search?: string;
      academicSessionId?: string;
      classId?: string;
      sectionId?: string;
      status?: string;
      gender?: string;
      page?: string;
      limit?: string;
      sortBy?: string;
      sortOrder?: 'asc' | 'desc';
    };

    let list = database.studentProfiles.map((profile) => {
      const user = database.users.find((u) => u.id === profile.userId);
      const cls = database.classes.find((c) => c.id === profile.classId);
      const sec = database.sections.find((s) => s.id === profile.sectionId);
      const sess = database.academicSessions.find((s) => s.id === profile.academicSessionId);
      const guardian = database.guardians.find((g) => g.id === profile.guardianId || g.studentIds?.includes(profile.id));

      const nameParts = (user?.name || (profile.firstName ? `${profile.firstName || ''} ${profile.lastName || ''}`.trim() : 'Student Member')).split(' ');
      const firstName = profile.firstName || nameParts[0] || 'Student';
      const lastName = profile.lastName || nameParts.slice(1).join(' ') || 'Scholar';
      const middleName = profile.middleName || '';
      const fullName = profile.fullName || `${firstName} ${middleName ? middleName + ' ' : ''}${lastName}`.trim();

      return {
        ...profile,
        firstName,
        middleName,
        lastName,
        fullName,
        avatarUrl: profile.avatarUrl || user?.avatarUrl || '',
        email: profile.email || user?.email || 'student@sygmate.edu',
        phone: profile.phone || user?.phoneNumber || '',
        alternativePhone: profile.alternativePhone || '',
        address: profile.address || profile.presentAddress || '',
        presentAddress: profile.presentAddress || profile.address || '',
        permanentAddress: profile.permanentAddress || profile.address || '',
        city: profile.city || 'Boston',
        postalCode: profile.postalCode || '02115',
        nationality: profile.nationality || 'United States',
        emergencyContact: profile.emergencyContact || profile.guardianPhone || '',
        className: cls?.name || 'Class / Grade',
        sectionName: sec?.name || 'Section',
        academicSessionName: sess?.sessionName || 'Academic Term',
        guardianId: guardian?.id || profile.guardianId,
        guardianName: guardian?.name || profile.guardianName || 'Guardian',
        guardianRelation: guardian?.relationship || profile.guardianRelation || 'Guardian',
        guardianPhone: guardian?.phone || profile.guardianPhone || '',
        guardianEmail: guardian?.email || profile.guardianEmail || '',
        guardianAddress: guardian?.address || profile.guardianAddress || profile.address,
        guardianOccupation: guardian?.occupation || profile.guardianOccupation || '',
        user: sanitizeUser(user)
      };
    });

    // Apply Search Filter (multi-attribute: name, admission, roll, email, phone, guardian)
    if (search && search.trim()) {
      const q = search.toLowerCase().trim();
      list = list.filter((s) =>
        s.firstName.toLowerCase().includes(q) ||
        s.lastName.toLowerCase().includes(q) ||
        (s.middleName && s.middleName.toLowerCase().includes(q)) ||
        s.fullName.toLowerCase().includes(q) ||
        s.admissionNumber.toLowerCase().includes(q) ||
        (s.rollNumber && s.rollNumber.toLowerCase().includes(q)) ||
        s.email.toLowerCase().includes(q) ||
        (s.phone && s.phone.toLowerCase().includes(q)) ||
        (s.guardianName && s.guardianName.toLowerCase().includes(q)) ||
        (s.guardianPhone && s.guardianPhone.toLowerCase().includes(q)) ||
        (s.city && s.city.toLowerCase().includes(q))
      );
    }

    // Apply Academic Session Filter
    if (academicSessionId && academicSessionId !== 'ALL') {
      list = list.filter((s) => s.academicSessionId === academicSessionId);
    }

    // Apply Class Filter
    if (classId && classId !== 'ALL') {
      list = list.filter((s) => s.classId === classId);
    }

    // Apply Section Filter
    if (sectionId && sectionId !== 'ALL') {
      list = list.filter((s) => s.sectionId === sectionId);
    }

    // Apply Status Filter
    if (status && status !== 'ALL') {
      list = list.filter((s) => s.status.toLowerCase() === status.toLowerCase());
    }

    // Apply Gender Filter
    if (gender && gender !== 'ALL') {
      list = list.filter((s) => s.gender?.toLowerCase() === gender.toLowerCase());
    }

    // Sorting
    list.sort((a: any, b: any) => {
      let fieldA = a[sortBy] ?? '';
      let fieldB = b[sortBy] ?? '';

      if (sortBy === 'name') {
        fieldA = a.fullName || `${a.firstName} ${a.lastName}`;
        fieldB = b.fullName || `${b.firstName} ${b.lastName}`;
      }

      if (typeof fieldA === 'string') {
        const cmp = fieldA.localeCompare(fieldB);
        return sortOrder === 'desc' ? -cmp : cmp;
      }
      return sortOrder === 'desc' ? fieldB - fieldA : fieldA - fieldB;
    });

    const total = list.length;
    let paginatedData = list;
    let pageNum = 1;
    let limitNum = total;

    if (page || limit) {
      pageNum = Math.max(1, parseInt(page || '1', 10) || 1);
      limitNum = Math.max(1, parseInt(limit || '10', 10) || 10);
      const startIndex = (pageNum - 1) * limitNum;
      paginatedData = list.slice(startIndex, startIndex + limitNum);
    }

    const totalPages = Math.ceil(total / limitNum) || 1;

    res.json({
      success: true,
      data: paginatedData,
      pagination: {
        total,
        page: pageNum,
        limit: limitNum,
        totalPages
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * GET /api/users/students/:id
 * Retrieve rich Central Student Master Profile Dossier with authoritative cross-module summaries
 */
usersRouter.get('/students/:id', requireAuth, requirePermission('students.view'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { id } = req.params;
    const profile = database.studentProfiles.find((s) => s.id === id || s.userId === id);
    if (!profile) {
      res.status(404).json({ success: false, error: 'Student record not found.' });
      return;
    }

    const user = database.users.find((u) => u.id === profile.userId);
    const cls = database.classes.find((c) => c.id === profile.classId);
    const sec = database.sections.find((s) => s.id === profile.sectionId);
    const sess = database.academicSessions.find((s) => s.id === profile.academicSessionId);
    const guardian = database.guardians.find((g) => g.id === profile.guardianId || g.studentIds?.includes(profile.id));

    // 1. Enrolled Subjects for this student's class
    const enrolledSubjects = database.subjects
      .filter((sub) => sub.classId === profile.classId || sub.classIds?.includes(profile.classId))
      .map((sub) => {
        const teacher = database.teacherProfiles.find((t) => t.id === sub.teacherId || (sub as any).teacherIds?.includes(t.id));
        const teacherUser = teacher ? database.users.find((u) => u.id === teacher.userId) : null;
        return {
          id: sub.id,
          name: sub.name,
          code: sub.code,
          type: sub.type,
          credits: sub.credits,
          teacherName: teacherUser ? teacherUser.name : (teacher?.firstName ? `${teacher.firstName} ${teacher.lastName}` : 'Academic Faculty')
        };
      });

    // 2. Siblings / other children sharing the same primary guardian
    const siblingStudents = guardian
      ? database.studentProfiles
          .filter((st) => st.id !== profile.id && (guardian.studentIds?.includes(st.id) || st.guardianId === guardian.id))
          .map((st) => {
            const stUser = database.users.find((u) => u.id === st.userId);
            const stClass = database.classes.find((c) => c.id === st.classId);
            return {
              id: st.id,
              name: stUser?.name || `${st.firstName || ''} ${st.lastName || ''}`.trim() || 'Student',
              admissionNumber: st.admissionNumber,
              className: stClass?.name || 'Class',
              status: st.status || 'active',
              avatarUrl: st.avatarUrl || stUser?.avatarUrl || ''
            };
          })
      : [];

    // 3. REAL Cross-Module Attendance Summary from database.attendanceRecords
    const studentAttendanceRecords = database.attendanceRecords.filter(
      (rec) => rec.studentId === profile.id || rec.userId === profile.userId || (rec as any).studentId === profile.userId
    );

    const totalDays = studentAttendanceRecords.length;
    const presentDays = studentAttendanceRecords.filter((r) => r.status === 'PRESENT').length;
    const absentDays = studentAttendanceRecords.filter((r) => r.status === 'ABSENT').length;
    const lateDays = studentAttendanceRecords.filter((r) => r.status === 'LATE').length;
    const halfDays = studentAttendanceRecords.filter((r) => r.status === 'HALF_DAY').length;
    const leaveDays = studentAttendanceRecords.filter((r) => r.status === 'LEAVE' || (r.status as any) === 'EXCUSED').length;

    let percentage = '100.0%';
    let standing = 'Excellent';
    if (totalDays > 0) {
      const calculatedRatio = ((presentDays + (lateDays * 0.5) + (halfDays * 0.5)) / totalDays) * 100;
      percentage = `${calculatedRatio.toFixed(1)}%`;
      if (calculatedRatio >= 90) standing = 'Excellent';
      else if (calculatedRatio >= 80) standing = 'Good';
      else if (calculatedRatio >= 75) standing = 'Satisfactory';
      else standing = 'Needs Improvement';
    }

    const recentAttendance = [...studentAttendanceRecords]
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
      .slice(0, 10)
      .map((r) => ({
        date: r.date,
        status: r.status,
        remarks: r.remarks || (r.isOverridden ? `Overridden: ${r.overrideReason}` : undefined),
        subjectName: r.subjectName
      }));

    const attendanceSummary = {
      totalDays,
      presentDays,
      absentDays,
      lateDays,
      halfDays,
      leaveDays,
      percentage,
      standing,
      recentRecords: recentAttendance
    };

    // 4. REAL Cross-Module Examination & GPA Summary from database.examResults
    const studentExamResults = database.examResults.filter(
      (resItem) => resItem.studentId === profile.id || (resItem as any).studentId === profile.userId
    );

    const totalExams = studentExamResults.length;
    const passedExams = studentExamResults.filter((r) => r.summary?.resultStatus === 'PASSED').length;
    const failedExams = studentExamResults.filter((r) => r.summary?.resultStatus === 'FAILED').length;

    let cumulativeGPA = 0;
    if (totalExams > 0) {
      const gpaSum = studentExamResults.reduce((acc, curr) => acc + (curr.summary?.gpa || 0), 0);
      cumulativeGPA = Math.round((gpaSum / totalExams) * 100) / 100;
    }

    let overallGrade = 'A';
    if (cumulativeGPA >= 3.8) overallGrade = 'A+';
    else if (cumulativeGPA >= 3.5) overallGrade = 'A';
    else if (cumulativeGPA >= 3.0) overallGrade = 'B';
    else if (cumulativeGPA >= 2.5) overallGrade = 'C';
    else if (cumulativeGPA > 0) overallGrade = 'D';

    const recentResults = [...studentExamResults]
      .sort((a, b) => new Date((b as any).publishedAt || b.createdAt || 0).getTime() - new Date((a as any).publishedAt || a.createdAt || 0).getTime())
      .slice(0, 10)
      .map((r) => ({
        examId: r.examId,
        examName: r.examName,
        gpa: r.summary?.gpa || 0,
        overallGrade: r.summary?.overallGrade || 'N/A',
        overallPercentage: r.summary?.overallPercentage || 0,
        resultStatus: r.summary?.resultStatus || 'PASSED',
        publishedDate: (r as any).publishedAt || '2026-08-15'
      }));

    const examinationSummary = {
      totalExams,
      cumulativeGPA,
      overallGrade,
      passedExams,
      failedExams,
      recentResults
    };

    // 5. REAL Cross-Module Fee & Account Summary from database.feeRecords
    const studentFeeRecords = database.feeRecords.filter(
      (feeItem) => feeItem.studentId === profile.id || (feeItem as any).studentId === profile.userId
    );

    const totalInvoiced = studentFeeRecords.reduce((acc, curr) => acc + (curr.netPayableAmount ?? curr.totalAmount ?? 0), 0);
    const totalPaid = studentFeeRecords.reduce((acc, curr) => acc + (curr.paidAmount || 0), 0);
    const totalDue = studentFeeRecords.reduce((acc, curr) => acc + (curr.dueAmount || 0), 0);

    let feeAccountStanding = 'CLEARED';
    if (totalDue > 0) {
      feeAccountStanding = totalPaid > 0 ? 'PARTIAL' : 'OUTSTANDING';
    }

    const recentFees = [...studentFeeRecords]
      .slice(0, 10)
      .map((f) => ({
        id: f.id,
        feeTitle: f.title || f.feeType,
        amount: f.netPayableAmount ?? f.totalAmount ?? 0,
        paidAmount: f.paidAmount,
        dueAmount: f.dueAmount,
        status: f.status,
        dueDate: f.dueDate
      }));

    const feeSummary = {
      totalInvoiced,
      totalPaid,
      totalDue,
      status: feeAccountStanding,
      recentFees
    };

    // 6. Documents & Attachments
    const documents = profile.documents && profile.documents.length > 0
      ? profile.documents
      : [
          {
            id: `doc-init-1-${profile.id}`,
            name: 'Birth Certificate Verification.pdf',
            type: 'application/pdf',
            url: '#',
            size: '1.2 MB',
            uploadedAt: profile.enrollmentDate || '2026-08-01'
          },
          {
            id: `doc-init-2-${profile.id}`,
            name: 'Immunization & Health History Form.pdf',
            type: 'application/pdf',
            url: '#',
            size: '850 KB',
            uploadedAt: profile.enrollmentDate || '2026-08-01'
          },
          {
            id: `doc-init-3-${profile.id}`,
            name: 'Official Academic Transcript (Previous Grade).pdf',
            type: 'application/pdf',
            url: '#',
            size: '2.4 MB',
            uploadedAt: profile.admissionDate || '2026-07-20'
          }
        ];

    // 7. Audit Trail relevant to this student
    const auditTrail = database.auditLogs
      .filter(
        (log) =>
          log.entityId === profile.id ||
          log.entityId === profile.userId ||
          (log.details && log.details.includes(profile.admissionNumber))
      )
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
      .slice(0, 15)
      .map((l) => ({
        id: l.id,
        action: l.action,
        userName: l.userName,
        userRole: l.userRole,
        details: l.details,
        timestamp: l.timestamp
      }));

    const nameParts = (user?.name || `${profile.firstName || ''} ${profile.lastName || ''}`.trim()).split(' ');
    const firstName = profile.firstName || nameParts[0] || 'Student';
    const lastName = profile.lastName || nameParts.slice(1).join(' ') || 'Scholar';
    const middleName = profile.middleName || '';
    const fullName = profile.fullName || `${firstName} ${middleName ? middleName + ' ' : ''}${lastName}`.trim();

    res.json({
      success: true,
      data: {
        ...profile,
        firstName,
        middleName,
        lastName,
        fullName,
        avatarUrl: profile.avatarUrl || user?.avatarUrl || '',
        email: profile.email || user?.email || 'student@sygmate.edu',
        phone: profile.phone || user?.phoneNumber || '',
        alternativePhone: profile.alternativePhone || '',
        address: profile.address || profile.presentAddress || '',
        presentAddress: profile.presentAddress || profile.address || '',
        permanentAddress: profile.permanentAddress || profile.address || '',
        city: profile.city || 'Boston',
        postalCode: profile.postalCode || '02115',
        nationality: profile.nationality || 'United States',
        emergencyContact: profile.emergencyContact || profile.guardianPhone || '',
        className: cls?.name || 'Class / Grade',
        sectionName: sec?.name || 'Section',
        academicSessionName: sess?.sessionName || 'Academic Term',
        guardian: guardian ? { ...guardian, siblingStudents } : null,
        guardianName: guardian?.name || profile.guardianName || 'Guardian',
        guardianRelation: guardian?.relationship || profile.guardianRelation || 'Guardian',
        guardianPhone: guardian?.phone || profile.guardianPhone || '',
        guardianEmail: guardian?.email || profile.guardianEmail || '',
        guardianAddress: guardian?.address || profile.guardianAddress || profile.address,
        guardianOccupation: guardian?.occupation || profile.guardianOccupation || '',
        fatherName: profile.fatherName || (profile.guardianRelation === 'Father' ? profile.guardianName : ''),
        fatherPhone: profile.fatherPhone || (profile.guardianRelation === 'Father' ? profile.guardianPhone : ''),
        fatherEmail: profile.fatherEmail || (profile.guardianRelation === 'Father' ? profile.guardianEmail : ''),
        fatherOccupation: profile.fatherOccupation || (profile.guardianRelation === 'Father' ? profile.guardianOccupation : ''),
        motherName: profile.motherName || (profile.guardianRelation === 'Mother' ? profile.guardianName : ''),
        motherPhone: profile.motherPhone || (profile.guardianRelation === 'Mother' ? profile.guardianPhone : ''),
        motherEmail: profile.motherEmail || (profile.guardianRelation === 'Mother' ? profile.guardianEmail : ''),
        motherOccupation: profile.motherOccupation || (profile.guardianRelation === 'Mother' ? profile.guardianOccupation : ''),
        secondaryGuardianName: profile.secondaryGuardianName || '',
        secondaryGuardianRelation: profile.secondaryGuardianRelation || '',
        secondaryGuardianPhone: profile.secondaryGuardianPhone || '',
        secondaryGuardianEmail: profile.secondaryGuardianEmail || '',
        user: sanitizeUser(user),
        enrolledSubjects,
        siblings: siblingStudents,
        attendanceSummary,
        examinationSummary,
        feeSummary,
        documents,
        auditTrail
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * POST /api/users/students
 * Create new student with robust duplicate prevention, validation, guardian linkage, and user account creation
 */
usersRouter.post('/students', requireAuth, requirePermission('students.create'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const {
      firstName,
      middleName,
      lastName,
      admissionNumber,
      rollNumber,
      email,
      phone,
      alternativePhone,
      dateOfBirth,
      gender,
      bloodGroup,
      nationality,
      address,
      presentAddress,
      permanentAddress,
      city,
      postalCode,
      emergencyContact,
      academicSessionId,
      classId,
      sectionId,
      admissionDate,
      enrollmentDate,
      enrollmentStatus,
      status,
      avatarUrl,
      // Guardian Info
      guardianId,
      guardianName,
      guardianRelation,
      guardianPhone,
      guardianEmail,
      guardianAddress,
      guardianOccupation,
      // Extended Family
      fatherName,
      fatherPhone,
      fatherEmail,
      fatherOccupation,
      motherName,
      motherPhone,
      motherEmail,
      motherOccupation,
      secondaryGuardianName,
      secondaryGuardianRelation,
      secondaryGuardianPhone,
      secondaryGuardianEmail,
      initialPassword
    } = req.body;

    // Required Field Validations
    if (!firstName || !firstName.trim()) {
      res.status(400).json({ success: false, error: 'First name is required.' });
      return;
    }
    if (!lastName || !lastName.trim()) {
      res.status(400).json({ success: false, error: 'Last name is required.' });
      return;
    }
    if (!admissionNumber || !admissionNumber.trim()) {
      res.status(400).json({ success: false, error: 'Student ID / Admission Number is required.' });
      return;
    }
    if (!academicSessionId) {
      res.status(400).json({ success: false, error: 'Academic Session is required.' });
      return;
    }
    if (!classId) {
      res.status(400).json({ success: false, error: 'Enrolled Class is required.' });
      return;
    }
    if (!sectionId) {
      res.status(400).json({ success: false, error: 'Enrolled Section is required.' });
      return;
    }

    const trimmedAdmission = admissionNumber.trim();
    const cleanAdmission = trimmedAdmission.toLowerCase();

    // 1. Strict Duplicate Student Check (Admission Number / Student ID)
    const admExists = database.studentProfiles.some(
      (s) => s.admissionNumber.toLowerCase() === cleanAdmission
    );
    if (admExists) {
      res.status(400).json({
        success: false,
        error: `Duplicate Student Error: Student ID / Admission Number "${trimmedAdmission}" is already registered.`
      });
      return;
    }

    // 2. Email Validation & Duplicate Check
    const trimmedEmail = email && email.trim()
      ? email.trim().toLowerCase()
      : `student.${trimmedAdmission.toLowerCase().replace(/[^a-z0-9]/g, '')}@sygmate.edu`;

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(trimmedEmail)) {
      res.status(400).json({ success: false, error: 'Invalid email address format.' });
      return;
    }

    const emailInUse = database.users.some((u) => u.email.toLowerCase() === trimmedEmail);
    if (emailInUse) {
      res.status(400).json({
        success: false,
        error: `Email address "${trimmedEmail}" is already associated with another user account.`
      });
      return;
    }

    // 3. Validate Academic Session
    const session = database.academicSessions.find((s) => s.id === academicSessionId);
    if (!session) {
      res.status(400).json({ success: false, error: 'Selected Academic Session does not exist.' });
      return;
    }

    // 4. Validate Class
    const cls = database.classes.find((c) => c.id === classId);
    if (!cls) {
      res.status(400).json({ success: false, error: 'Selected Class does not exist.' });
      return;
    }

    // 5. Validate Section and ensure it belongs to the selected Class
    const sec = database.sections.find((s) => s.id === sectionId);
    if (!sec) {
      res.status(400).json({ success: false, error: 'Selected Section does not exist.' });
      return;
    }
    if (sec.classId !== classId) {
      res.status(400).json({
        success: false,
        error: `Selected Section "${sec.name}" does not belong to Class "${cls.name}".`
      });
      return;
    }

    const studentProfId = `stud-prof-${Date.now()}`;
    const userId = `usr-student-${Date.now()}`;
    const cleanMiddle = middleName ? middleName.trim() : '';
    const fullName = `${firstName.trim()} ${cleanMiddle ? cleanMiddle + ' ' : ''}${lastName.trim()}`.trim();
    const username = (firstName.charAt(0) + lastName).toLowerCase().replace(/[^a-z0-9]/g, '');

    // 6. Handle Guardian Linking or Creation
    let resolvedGuardianId = guardianId;
    let resolvedGuardianName = guardianName || 'Guardian';
    let resolvedGuardianRelation = guardianRelation || 'Guardian';
    let resolvedGuardianPhone = guardianPhone || '';
    let resolvedGuardianEmail = guardianEmail || '';
    let resolvedGuardianAddress = guardianAddress || address || presentAddress || '';
    let resolvedGuardianOccupation = guardianOccupation || '';

    if (guardianId && guardianId !== 'NEW') {
      const existingGuardian = database.guardians.find((g) => g.id === guardianId);
      if (existingGuardian) {
        resolvedGuardianId = existingGuardian.id;
        resolvedGuardianName = existingGuardian.name;
        resolvedGuardianRelation = existingGuardian.relationship;
        resolvedGuardianPhone = existingGuardian.phone;
        resolvedGuardianEmail = existingGuardian.email;
        resolvedGuardianAddress = existingGuardian.address;
        resolvedGuardianOccupation = existingGuardian.occupation || '';
        if (!existingGuardian.studentIds.includes(studentProfId)) {
          existingGuardian.studentIds.push(studentProfId);
        }
      }
    } else if (guardianName && guardianName.trim()) {
      // Create new Guardian Record
      const newGuardianId = `guard-${Date.now()}`;
      const newGuardian: Guardian = {
        id: newGuardianId,
        name: guardianName.trim(),
        relationship: guardianRelation || 'Guardian',
        phone: guardianPhone || phone || '',
        email: guardianEmail || '',
        address: guardianAddress || address || presentAddress || '',
        occupation: guardianOccupation || '',
        studentIds: [studentProfId],
        status: 'active',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      database.guardians.push(newGuardian);
      resolvedGuardianId = newGuardianId;
      resolvedGuardianName = newGuardian.name;
      resolvedGuardianRelation = newGuardian.relationship;
      resolvedGuardianPhone = newGuardian.phone;
      resolvedGuardianEmail = newGuardian.email;
      resolvedGuardianAddress = newGuardian.address;
      resolvedGuardianOccupation = newGuardian.occupation;
    }

    // 7. Create User Account
    const pwd = initialPassword && initialPassword.trim() ? initialPassword.trim() : 'Student@123';
    const hashData = hashPassword(pwd, SEED_SALT);

    const newUser = {
      id: userId,
      name: fullName,
      firstName: firstName.trim(),
      lastName: lastName.trim(),
      email: trimmedEmail,
      username: `${username}${Math.floor(1000 + Math.random() * 9000)}`,
      role: 'STUDENT' as const,
      status: (status?.toLowerCase() === 'inactive' || status?.toLowerCase() === 'suspended' ? 'suspended' : 'active') as 'active' | 'suspended',
      phoneNumber: phone || '',
      avatarUrl: avatarUrl || '',
      passwordHash: hashData.hash,
      passwordSalt: hashData.salt,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    database.users.push(newUser);

    // 8. Create Central Student Profile
    const newStudentProfile: StudentProfile = {
      id: studentProfId,
      userId: userId,
      admissionNumber: trimmedAdmission,
      rollNumber: rollNumber ? rollNumber.trim() : `R-${Math.floor(10 + Math.random() * 90)}`,
      firstName: firstName.trim(),
      middleName: cleanMiddle,
      lastName: lastName.trim(),
      fullName: fullName,
      avatarUrl: avatarUrl || '',
      email: trimmedEmail,
      phone: phone || '',
      alternativePhone: alternativePhone || '',
      dateOfBirth: dateOfBirth || '2010-01-01',
      gender: gender || 'male',
      bloodGroup: bloodGroup || 'O+',
      nationality: nationality || 'United States',
      address: address || presentAddress || '',
      presentAddress: presentAddress || address || '',
      permanentAddress: permanentAddress || address || '',
      city: city || 'Boston',
      postalCode: postalCode || '02115',
      emergencyContact: emergencyContact || resolvedGuardianPhone || '',
      admissionDate: admissionDate || new Date().toISOString().split('T')[0],
      enrollmentDate: enrollmentDate || new Date().toISOString().split('T')[0],
      enrollmentStatus: enrollmentStatus || 'active',
      status: status || 'active',
      academicSessionId: academicSessionId,
      academicSessionName: session.sessionName,
      classId: classId,
      className: cls.name,
      sectionId: sectionId,
      sectionName: sec.name,
      guardianId: resolvedGuardianId,
      guardianName: resolvedGuardianName,
      guardianRelation: resolvedGuardianRelation,
      guardianPhone: resolvedGuardianPhone,
      guardianEmail: resolvedGuardianEmail,
      guardianAddress: resolvedGuardianAddress,
      guardianOccupation: resolvedGuardianOccupation,
      fatherName: fatherName || (resolvedGuardianRelation === 'Father' ? resolvedGuardianName : ''),
      fatherPhone: fatherPhone || (resolvedGuardianRelation === 'Father' ? resolvedGuardianPhone : ''),
      fatherEmail: fatherEmail || (resolvedGuardianRelation === 'Father' ? resolvedGuardianEmail : ''),
      fatherOccupation: fatherOccupation || (resolvedGuardianRelation === 'Father' ? resolvedGuardianOccupation : ''),
      motherName: motherName || (resolvedGuardianRelation === 'Mother' ? resolvedGuardianName : ''),
      motherPhone: motherPhone || (resolvedGuardianRelation === 'Mother' ? resolvedGuardianPhone : ''),
      motherEmail: motherEmail || (resolvedGuardianRelation === 'Mother' ? resolvedGuardianEmail : ''),
      motherOccupation: motherOccupation || (resolvedGuardianRelation === 'Mother' ? resolvedGuardianOccupation : ''),
      secondaryGuardianName: secondaryGuardianName || '',
      secondaryGuardianRelation: secondaryGuardianRelation || '',
      secondaryGuardianPhone: secondaryGuardianPhone || '',
      secondaryGuardianEmail: secondaryGuardianEmail || '',
      documents: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    database.studentProfiles.push(newStudentProfile);

    // 9. Audit Logging
    logAudit({
      userId: req.user!.id,
      userName: req.user!.name,
      userRole: req.user!.role,
      action: 'CREATE',
      entity: 'STUDENT',
      entityType: 'STUDENT',
      entityId: studentProfId,
      details: `Enrolled student ${fullName} (${trimmedAdmission}) into Class ${cls.name} - ${sec.name} for academic session ${session.sessionName}.`,
      ipAddress: req.ip
    });

    res.status(201).json({
      success: true,
      message: `Student ${fullName} enrolled successfully.`,
      data: {
        ...newStudentProfile,
        user: sanitizeUser(newUser)
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * PUT /api/users/students/:id
 * Update Student details, academic placement, and guardian linkage with server-side validation & duplicate protection
 */
usersRouter.put('/students/:id', requireAuth, requirePermission('students.edit'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { id } = req.params;
    const index = database.studentProfiles.findIndex((s) => s.id === id || s.userId === id);
    if (index === -1) {
      res.status(404).json({ success: false, error: 'Student record not found.' });
      return;
    }

    const existing = database.studentProfiles[index];
    const userIndex = database.users.findIndex((u) => u.id === existing.userId);

    const {
      firstName,
      middleName,
      lastName,
      admissionNumber,
      rollNumber,
      email,
      phone,
      alternativePhone,
      dateOfBirth,
      gender,
      bloodGroup,
      nationality,
      address,
      presentAddress,
      permanentAddress,
      city,
      postalCode,
      emergencyContact,
      academicSessionId,
      classId,
      sectionId,
      admissionDate,
      enrollmentDate,
      enrollmentStatus,
      status,
      avatarUrl,
      guardianId,
      guardianName,
      guardianRelation,
      guardianPhone,
      guardianEmail,
      guardianAddress,
      guardianOccupation,
      fatherName,
      fatherPhone,
      fatherEmail,
      fatherOccupation,
      motherName,
      motherPhone,
      motherEmail,
      motherOccupation,
      secondaryGuardianName,
      secondaryGuardianRelation,
      secondaryGuardianPhone,
      secondaryGuardianEmail
    } = req.body;

    // Check unique admission number if modified
    if (admissionNumber && admissionNumber.trim().toLowerCase() !== existing.admissionNumber.toLowerCase()) {
      const trimmedAdm = admissionNumber.trim();
      const exists = database.studentProfiles.some(
        (s) => s.id !== existing.id && s.admissionNumber.toLowerCase() === trimmedAdm.toLowerCase()
      );
      if (exists) {
        res.status(400).json({
          success: false,
          error: `Duplicate Student Error: Admission Number "${trimmedAdm}" is already registered to another student.`
        });
        return;
      }
    }

    // Check unique email if modified
    if (email && email.trim().toLowerCase() !== (existing.email || '').toLowerCase()) {
      const trimmedEmail = email.trim().toLowerCase();
      const emailExists = database.users.some(
        (u) => u.id !== existing.userId && u.email.toLowerCase() === trimmedEmail
      );
      if (emailExists) {
        res.status(400).json({
          success: false,
          error: `Email address "${trimmedEmail}" is already in use by another account.`
        });
        return;
      }
    }

    // Validate Academic Placement if changed
    let validSessionId = existing.academicSessionId;
    let validSessionName = existing.academicSessionName;
    if (academicSessionId) {
      const sess = database.academicSessions.find((s) => s.id === academicSessionId);
      if (sess) {
        validSessionId = sess.id;
        validSessionName = sess.sessionName;
      }
    }

    let validClassId = existing.classId;
    let validClassName = existing.className;
    if (classId) {
      const cls = database.classes.find((c) => c.id === classId);
      if (cls) {
        validClassId = cls.id;
        validClassName = cls.name;
      }
    }

    let validSectionId = existing.sectionId;
    let validSectionName = existing.sectionName;
    if (sectionId) {
      const sec = database.sections.find((s) => s.id === sectionId);
      if (sec) {
        // Validate section belongs to class
        if (sec.classId !== validClassId) {
          res.status(400).json({
            success: false,
            error: `Section "${sec.name}" does not belong to the selected class.`
          });
          return;
        }
        validSectionId = sec.id;
        validSectionName = sec.name;
      }
    }

    // Update Guardian Link
    let resolvedGuardianId = guardianId !== undefined ? guardianId : existing.guardianId;
    if (guardianId && guardianId !== existing.guardianId) {
      // Remove from old guardian
      if (existing.guardianId) {
        const oldG = database.guardians.find((g) => g.id === existing.guardianId);
        if (oldG) {
          oldG.studentIds = oldG.studentIds.filter((sid) => sid !== existing.id);
        }
      }
      // Add to new guardian
      const newG = database.guardians.find((g) => g.id === guardianId);
      if (newG && !newG.studentIds.includes(existing.id)) {
        newG.studentIds.push(existing.id);
      }
    }

    const updatedFirstName = firstName !== undefined ? firstName.trim() : existing.firstName;
    const updatedMiddleName = middleName !== undefined ? middleName.trim() : (existing.middleName || '');
    const updatedLastName = lastName !== undefined ? lastName.trim() : existing.lastName;
    const updatedFullName = `${updatedFirstName || ''} ${updatedMiddleName ? updatedMiddleName + ' ' : ''}${updatedLastName || ''}`.trim();

    const updatedProfile: StudentProfile = {
      ...existing,
      admissionNumber: admissionNumber ? admissionNumber.trim() : existing.admissionNumber,
      rollNumber: rollNumber !== undefined ? rollNumber.trim() : existing.rollNumber,
      firstName: updatedFirstName,
      middleName: updatedMiddleName,
      lastName: updatedLastName,
      fullName: updatedFullName,
      email: email ? email.trim().toLowerCase() : existing.email,
      phone: phone !== undefined ? phone : existing.phone,
      alternativePhone: alternativePhone !== undefined ? alternativePhone : existing.alternativePhone,
      dateOfBirth: dateOfBirth !== undefined ? dateOfBirth : existing.dateOfBirth,
      gender: gender !== undefined ? gender : existing.gender,
      bloodGroup: bloodGroup !== undefined ? bloodGroup : existing.bloodGroup,
      nationality: nationality !== undefined ? nationality : (existing.nationality || 'United States'),
      address: address !== undefined ? address : existing.address,
      presentAddress: presentAddress !== undefined ? presentAddress : (existing.presentAddress || existing.address),
      permanentAddress: permanentAddress !== undefined ? permanentAddress : (existing.permanentAddress || existing.address),
      city: city !== undefined ? city : (existing.city || 'Boston'),
      postalCode: postalCode !== undefined ? postalCode : (existing.postalCode || '02115'),
      emergencyContact: emergencyContact !== undefined ? emergencyContact : existing.emergencyContact,
      academicSessionId: validSessionId,
      academicSessionName: validSessionName,
      classId: validClassId,
      className: validClassName,
      sectionId: validSectionId,
      sectionName: validSectionName,
      admissionDate: admissionDate !== undefined ? admissionDate : existing.admissionDate,
      enrollmentDate: enrollmentDate !== undefined ? enrollmentDate : existing.enrollmentDate,
      enrollmentStatus: enrollmentStatus !== undefined ? enrollmentStatus : existing.enrollmentStatus,
      status: status !== undefined ? status : existing.status,
      avatarUrl: avatarUrl !== undefined ? avatarUrl : existing.avatarUrl,
      guardianId: resolvedGuardianId,
      guardianName: guardianName !== undefined ? guardianName : existing.guardianName,
      guardianRelation: guardianRelation !== undefined ? guardianRelation : existing.guardianRelation,
      guardianPhone: guardianPhone !== undefined ? guardianPhone : existing.guardianPhone,
      guardianEmail: guardianEmail !== undefined ? guardianEmail : existing.guardianEmail,
      guardianAddress: guardianAddress !== undefined ? guardianAddress : existing.guardianAddress,
      guardianOccupation: guardianOccupation !== undefined ? guardianOccupation : existing.guardianOccupation,
      fatherName: fatherName !== undefined ? fatherName : existing.fatherName,
      fatherPhone: fatherPhone !== undefined ? fatherPhone : existing.fatherPhone,
      fatherEmail: fatherEmail !== undefined ? fatherEmail : existing.fatherEmail,
      fatherOccupation: fatherOccupation !== undefined ? fatherOccupation : existing.fatherOccupation,
      motherName: motherName !== undefined ? motherName : existing.motherName,
      motherPhone: motherPhone !== undefined ? motherPhone : existing.motherPhone,
      motherEmail: motherEmail !== undefined ? motherEmail : existing.motherEmail,
      motherOccupation: motherOccupation !== undefined ? motherOccupation : existing.motherOccupation,
      secondaryGuardianName: secondaryGuardianName !== undefined ? secondaryGuardianName : existing.secondaryGuardianName,
      secondaryGuardianRelation: secondaryGuardianRelation !== undefined ? secondaryGuardianRelation : existing.secondaryGuardianRelation,
      secondaryGuardianPhone: secondaryGuardianPhone !== undefined ? secondaryGuardianPhone : existing.secondaryGuardianPhone,
      secondaryGuardianEmail: secondaryGuardianEmail !== undefined ? secondaryGuardianEmail : existing.secondaryGuardianEmail,
      updatedAt: new Date().toISOString()
    };

    database.studentProfiles[index] = updatedProfile;

    // Update Linked User Account
    if (userIndex !== -1) {
      const existingUser = database.users[userIndex];
      database.users[userIndex] = {
        ...existingUser,
        name: updatedFullName || existingUser.name,
        firstName: updatedProfile.firstName,
        lastName: updatedProfile.lastName,
        email: updatedProfile.email || existingUser.email,
        phoneNumber: updatedProfile.phone || existingUser.phoneNumber,
        avatarUrl: updatedProfile.avatarUrl !== undefined ? updatedProfile.avatarUrl : existingUser.avatarUrl,
        status: updatedProfile.status.toLowerCase() === 'inactive' || updatedProfile.status.toLowerCase() === 'suspended' ? 'suspended' : 'active',
        updatedAt: new Date().toISOString()
      };
    }

    logAudit({
      userId: req.user!.id,
      userName: req.user!.name,
      userRole: req.user!.role,
      action: 'UPDATE',
      entity: 'STUDENT',
      entityType: 'STUDENT',
      entityId: existing.id,
      details: `Updated student record for ${updatedFullName} (${updatedProfile.admissionNumber}).`,
      ipAddress: req.ip
    });

    res.json({
      success: true,
      message: 'Student record updated successfully.',
      data: updatedProfile
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * PATCH /api/users/students/:id/status
 * Toggle student status (active, graduated, transferred, suspended, inactive, withdrawn, archived)
 */
usersRouter.patch('/students/:id/status', requireAuth, requirePermission('students.edit'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    if (!status) {
      res.status(400).json({ success: false, error: 'Status value is required.' });
      return;
    }

    const validStatuses = ['active', 'inactive', 'suspended', 'transferred', 'graduated', 'withdrawn', 'archived'];
    if (!validStatuses.includes(status.toLowerCase())) {
      res.status(400).json({
        success: false,
        error: `Invalid status "${status}". Allowed statuses: ${validStatuses.join(', ')}.`
      });
      return;
    }

    const index = database.studentProfiles.findIndex((s) => s.id === id || s.userId === id);
    if (index === -1) {
      res.status(404).json({ success: false, error: 'Student record not found.' });
      return;
    }

    const student = database.studentProfiles[index];
    student.status = status.toLowerCase();
    student.updatedAt = new Date().toISOString();

    const userIndex = database.users.findIndex((u) => u.id === student.userId);
    if (userIndex !== -1) {
      database.users[userIndex].status = student.status === 'active' ? 'active' : 'suspended';
      database.users[userIndex].updatedAt = new Date().toISOString();
    }

    logAudit({
      userId: req.user!.id,
      userName: req.user!.name,
      userRole: req.user!.role,
      action: 'UPDATE',
      entity: 'STUDENT',
      entityType: 'STUDENT',
      entityId: student.id,
      details: `Changed student status for ${student.admissionNumber} to "${status}".`,
      ipAddress: req.ip
    });

    res.json({
      success: true,
      message: `Student status updated to ${status}.`,
      data: student
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * POST /api/users/students/:id/photo
 * Secure upload / replacement of student profile photo
 */
usersRouter.post('/students/:id/photo', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { id } = req.params;
    const { avatarUrl } = req.body;

    const user = req.user!;
    const student = database.studentProfiles.find((s) => s.id === id || s.userId === id);
    if (!student) {
      res.status(404).json({ success: false, error: 'Student record not found.' });
      return;
    }

    // Security check: Must be Super Admin, Admin with edit rights, or the student themselves
    const isSelf = user.role === 'STUDENT' && (student.userId === user.id || student.id === user.id);
    const hasAdminRights = user.role === 'SUPER_ADMIN' || hasPermission(user.role, 'students.edit');

    if (!isSelf && !hasAdminRights) {
      res.status(403).json({
        success: false,
        error: 'Forbidden: You are not authorized to update this student photo.'
      });
      return;
    }

    if (!avatarUrl || typeof avatarUrl !== 'string') {
      res.status(400).json({ success: false, error: 'Photo data is required.' });
      return;
    }

    // Validate MIME format
    const validImageMimeRegex = /^data:image\/(jpeg|jpg|png|webp);base64,/i;
    if (!validImageMimeRegex.test(avatarUrl) && !avatarUrl.startsWith('http://') && !avatarUrl.startsWith('https://')) {
      res.status(400).json({
        success: false,
        error: 'Invalid image format. Supported types: JPEG, JPG, PNG, WEBP.'
      });
      return;
    }

    // Max 5MB file payload check (approx 6.8 million base64 characters)
    if (avatarUrl.length > 7 * 1024 * 1024) {
      res.status(400).json({
        success: false,
        error: 'Image file size exceeds the 5MB institutional limit.'
      });
      return;
    }

    student.avatarUrl = avatarUrl;
    student.updatedAt = new Date().toISOString();

    const userIndex = database.users.findIndex((u) => u.id === student.userId);
    if (userIndex !== -1) {
      database.users[userIndex].avatarUrl = avatarUrl;
      database.users[userIndex].updatedAt = new Date().toISOString();
    }

    logAudit({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action: 'UPDATE',
      entity: 'STUDENT_PHOTO',
      entityType: 'STUDENT',
      entityId: student.id,
      details: `Updated student photo for ${student.admissionNumber} (${student.firstName} ${student.lastName}).`,
      ipAddress: req.ip
    });

    res.json({
      success: true,
      message: 'Student photo updated successfully.',
      data: {
        id: student.id,
        avatarUrl: student.avatarUrl
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * DELETE /api/users/students/:id/photo
 * Remove student profile photo
 */
usersRouter.delete('/students/:id/photo', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { id } = req.params;
    const user = req.user!;
    const student = database.studentProfiles.find((s) => s.id === id || s.userId === id);
    if (!student) {
      res.status(404).json({ success: false, error: 'Student record not found.' });
      return;
    }

    const isSelf = user.role === 'STUDENT' && (student.userId === user.id || student.id === user.id);
    const hasAdminRights = user.role === 'SUPER_ADMIN' || hasPermission(user.role, 'students.edit');

    if (!isSelf && !hasAdminRights) {
      res.status(403).json({ success: false, error: 'Forbidden: You cannot remove this photo.' });
      return;
    }

    student.avatarUrl = '';
    student.updatedAt = new Date().toISOString();

    const userIndex = database.users.findIndex((u) => u.id === student.userId);
    if (userIndex !== -1) {
      database.users[userIndex].avatarUrl = '';
      database.users[userIndex].updatedAt = new Date().toISOString();
    }

    logAudit({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action: 'DELETE',
      entity: 'STUDENT_PHOTO',
      entityType: 'STUDENT',
      entityId: student.id,
      details: `Removed profile photo for student ${student.admissionNumber}.`,
      ipAddress: req.ip
    });

    res.json({
      success: true,
      message: 'Student photo removed successfully.'
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * POST /api/users/students/:id/documents
 * Attach student profile document
 */
usersRouter.post('/students/:id/documents', requireAuth, requirePermission('students.edit'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { id } = req.params;
    const { name, type, url, size } = req.body;

    const student = database.studentProfiles.find((s) => s.id === id || s.userId === id);
    if (!student) {
      res.status(404).json({ success: false, error: 'Student record not found.' });
      return;
    }

    if (!name || !name.trim()) {
      res.status(400).json({ success: false, error: 'Document name is required.' });
      return;
    }

    const newDoc = {
      id: `doc-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      name: name.trim(),
      type: type || 'application/pdf',
      url: url || '#',
      size: size || '1.0 MB',
      uploadedAt: new Date().toISOString().split('T')[0]
    };

    if (!student.documents) {
      student.documents = [];
    }

    student.documents.push(newDoc);
    student.updatedAt = new Date().toISOString();

    logAudit({
      userId: req.user!.id,
      userName: req.user!.name,
      userRole: req.user!.role,
      action: 'CREATE',
      entity: 'STUDENT_DOCUMENT',
      entityType: 'STUDENT',
      entityId: student.id,
      details: `Attached document "${newDoc.name}" to student ${student.admissionNumber}.`,
      ipAddress: req.ip
    });

    res.status(201).json({
      success: true,
      message: 'Document attached successfully.',
      data: newDoc
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * DELETE /api/users/students/:id/documents/:docId
 * Remove student profile document
 */
usersRouter.delete('/students/:id/documents/:docId', requireAuth, requirePermission('students.edit'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { id, docId } = req.params;
    const student = database.studentProfiles.find((s) => s.id === id || s.userId === id);
    if (!student) {
      res.status(404).json({ success: false, error: 'Student record not found.' });
      return;
    }

    if (!student.documents) {
      res.status(404).json({ success: false, error: 'Document not found.' });
      return;
    }

    const docIndex = student.documents.findIndex((d) => d.id === docId);
    if (docIndex === -1) {
      res.status(404).json({ success: false, error: 'Document not found.' });
      return;
    }

    const removed = student.documents.splice(docIndex, 1)[0];
    student.updatedAt = new Date().toISOString();

    logAudit({
      userId: req.user!.id,
      userName: req.user!.name,
      userRole: req.user!.role,
      action: 'DELETE',
      entity: 'STUDENT_DOCUMENT',
      entityType: 'STUDENT',
      entityId: student.id,
      details: `Removed document "${removed.name}" from student ${student.admissionNumber}.`,
      ipAddress: req.ip
    });

    res.json({
      success: true,
      message: 'Document removed successfully.'
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * DELETE /api/users/students/:id
 * Delete student record and unlink from guardian
 */
usersRouter.delete('/students/:id', requireAuth, requirePermission('students.delete'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { id } = req.params;
    const index = database.studentProfiles.findIndex((s) => s.id === id || s.userId === id);
    if (index === -1) {
      res.status(404).json({ success: false, error: 'Student record not found.' });
      return;
    }

    const student = database.studentProfiles[index];

    // Unlink from guardian's studentIds
    if (student.guardianId) {
      const guardian = database.guardians.find((g) => g.id === student.guardianId);
      if (guardian) {
        guardian.studentIds = guardian.studentIds.filter((sid) => sid !== student.id);
      }
    }

    // Delete Student Profile
    database.studentProfiles.splice(index, 1);

    // Delete Linked User Account
    const userIndex = database.users.findIndex((u) => u.id === student.userId);
    if (userIndex !== -1) {
      database.users.splice(userIndex, 1);
    }

    logAudit({
      userId: req.user!.id,
      userName: req.user!.name,
      userRole: req.user!.role,
      action: 'DELETE',
      entity: 'STUDENT',
      entityType: 'STUDENT',
      entityId: student.id,
      details: `Deleted student record ${student.admissionNumber} (${student.firstName} ${student.lastName}).`,
      ipAddress: req.ip
    });

    res.json({
      success: true,
      message: `Student ${student.admissionNumber} deleted successfully.`
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// =========================================================================
// 3. GUARDIAN & FAMILY HOUSEHOLD MANAGEMENT (PART 10A)
// =========================================================================

function normalizePhoneDigits(phone?: string): string {
  if (!phone) return '';
  return phone.replace(/\D/g, '');
}

function enrichGuardian(g: Guardian): Guardian {
  const rels = database.parentStudentRelationships.filter((r) => r.guardianId === g.id);
  
  // Combine all student IDs associated with this guardian
  const studentIdSet = new Set<string>([
    ...(g.studentIds || []),
    ...rels.map((r) => r.studentId),
    ...database.studentProfiles.filter((s) => s.guardianId === g.id || s.secondaryGuardianId === g.id).map((s) => s.id)
  ]);

  const populatedStudents = Array.from(studentIdSet).map((sid) => {
    const st = database.studentProfiles.find((s) => s.id === sid);
    if (!st) return null;
    const u = database.users.find((usr) => usr.id === st.userId);
    const cls = database.classes.find((c) => c.id === st.classId);
    const sec = database.sections.find((s) => s.id === st.sectionId);
    const sess = database.academicSessions.find((s) => s.id === st.academicSessionId);
    const rel = rels.find((r) => r.studentId === sid);

    const isPrimary = rel ? rel.isPrimaryGuardian : st.guardianId === g.id;
    const isSecondary = rel ? rel.isSecondaryGuardian : st.secondaryGuardianId === g.id;

    return {
      id: st.id,
      name: u?.name || `${st.firstName || ''} ${st.lastName || ''}`.trim() || 'Student',
      admissionNumber: st.admissionNumber,
      rollNumber: st.rollNumber,
      className: cls?.name || 'Class',
      sectionName: sec?.name || 'A',
      avatarUrl: st.avatarUrl || u?.avatarUrl || '',
      status: st.status || 'active',
      sessionName: sess?.sessionName || 'Academic Session',
      relationshipType: rel?.relationshipType || g.relationship || 'Parent',
      isPrimary,
      isSecondary,
      isEmergencyContact: rel ? rel.isEmergencyContact : true,
      isAuthorizedAcademic: rel ? rel.isAuthorizedAcademic : true,
      isAuthorizedAttendance: rel ? rel.isAuthorizedAttendance : true,
      isAuthorizedFinancial: rel ? rel.isAuthorizedFinancial : isPrimary,
      isAuthorizedCommunication: rel ? rel.isAuthorizedCommunication : true,
      isPickupAuthorized: rel ? rel.isPickupAuthorized : true
    };
  }).filter(Boolean) as any[];

  const family = g.familyId ? database.families.find((f) => f.id === g.familyId) : undefined;

  const linkedUser = g.userId
    ? database.users.find((u) => u.id === g.userId)
    : database.users.find((u) => u.email.toLowerCase() === (g.email || '').toLowerCase());

  const activeInvitation = database.parentInvitations?.find(
    (inv) => inv.guardianId === g.id && inv.status === 'pending' && new Date(inv.expiresAt) > new Date()
  );

  let accountStatus: string = 'unprovisioned';
  if (linkedUser) {
    accountStatus = linkedUser.status;
  } else if (activeInvitation) {
    accountStatus = 'invited';
  }

  return {
    ...g,
    studentIds: Array.from(studentIdSet),
    students: populatedStudents,
    studentCount: populatedStudents.length,
    relationships: rels,
    family,
    hasAccount: !!linkedUser,
    accountStatus,
    username: linkedUser?.username,
    userEmail: linkedUser?.email,
    userLastLoginAt: linkedUser?.lastLoginAt,
    isLocked: linkedUser?.status === 'locked',
    isDisabled: linkedUser?.status === 'disabled' || linkedUser?.status === 'suspended',
    activeInvitationToken: activeInvitation?.token
  };
}

/**
 * POST /api/users/guardians/check-duplicate
 * Real-time duplicate detection by normalized phone, email, and full name
 */
usersRouter.post('/guardians/check-duplicate', requireAuth, requirePermission('guardians.view'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { phone, email, name, excludeId } = req.body;
    const inputPhoneDigits = normalizePhoneDigits(phone);
    const inputEmail = (email || '').trim().toLowerCase();
    const inputName = (name || '').trim().toLowerCase();

    const matches: any[] = [];

    for (const g of database.guardians) {
      if (excludeId && g.id === excludeId) continue;

      let matchedBy = '';
      const existingPhoneDigits = normalizePhoneDigits(g.phone);
      const existingEmail = (g.email || '').trim().toLowerCase();
      const existingName = (g.name || '').trim().toLowerCase();

      if (inputPhoneDigits && existingPhoneDigits && inputPhoneDigits === existingPhoneDigits) {
        matchedBy = 'Phone number match';
      } else if (inputEmail && existingEmail && inputEmail === existingEmail) {
        matchedBy = 'Email address match';
      } else if (inputName && existingName && inputName === existingName) {
        matchedBy = 'Exact full name match';
      }

      if (matchedBy) {
        const enriched = enrichGuardian(g);
        matches.push({
          id: g.id,
          name: g.name,
          relationship: g.relationship,
          phone: g.phone,
          email: g.email,
          address: g.address,
          matchedBy,
          studentCount: enriched.studentCount || 0,
          studentNames: enriched.students?.map((s) => s.name) || []
        });
      }
    }

    res.json({
      success: true,
      hasDuplicate: matches.length > 0,
      duplicates: matches
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * GET /api/users/guardians
 * List all guardians with search, filters, pagination, and enriched children
 */
usersRouter.get('/guardians', requireAuth, requirePermission('guardians.view'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { search, status, relationship, academicSessionId, familyId, page, limit } = req.query as {
      search?: string;
      status?: string;
      relationship?: string;
      academicSessionId?: string;
      familyId?: string;
      page?: string;
      limit?: string;
    };

    let list = database.guardians.map(enrichGuardian);

    // Search filter
    if (search && search.trim()) {
      const q = search.toLowerCase().trim();
      list = list.filter((g) =>
        g.name.toLowerCase().includes(q) ||
        (g.firstName && g.firstName.toLowerCase().includes(q)) ||
        (g.lastName && g.lastName.toLowerCase().includes(q)) ||
        (g.preferredName && g.preferredName.toLowerCase().includes(q)) ||
        g.phone.toLowerCase().includes(q) ||
        (g.secondaryPhone && g.secondaryPhone.toLowerCase().includes(q)) ||
        g.email.toLowerCase().includes(q) ||
        (g.occupation && g.occupation.toLowerCase().includes(q)) ||
        (g.address && g.address.toLowerCase().includes(q)) ||
        (g.city && g.city.toLowerCase().includes(q)) ||
        (g.family?.familyName && g.family.familyName.toLowerCase().includes(q)) ||
        (g.students && g.students.some((st: any) =>
          st.name.toLowerCase().includes(q) ||
          st.admissionNumber.toLowerCase().includes(q) ||
          (st.rollNumber && st.rollNumber.toLowerCase().includes(q))
        ))
      );
    }

    // Relationship filter
    if (relationship && relationship !== 'ALL') {
      list = list.filter((g) => (g.relationship || '').toLowerCase() === relationship.toLowerCase());
    }

    // Status filter
    if (status && status !== 'ALL') {
      list = list.filter((g) => (g.status || 'active').toLowerCase() === status.toLowerCase());
    }

    // Family filter
    if (familyId && familyId !== 'ALL') {
      list = list.filter((g) => g.familyId === familyId);
    }

    // Academic session filter (students enrolled in this session)
    if (academicSessionId && academicSessionId !== 'ALL') {
      list = list.filter((g) => {
        const studentIdsInSession = database.studentProfiles
          .filter((s) => s.academicSessionId === academicSessionId)
          .map((s) => s.id);
        return g.studentIds.some((sid) => studentIdsInSession.includes(sid));
      });
    }

    list.sort((a, b) => a.name.localeCompare(b.name));

    // Handle Pagination if requested
    if (page && limit) {
      const pageNum = Math.max(1, parseInt(page, 10) || 1);
      const limitNum = Math.max(1, parseInt(limit, 10) || 10);
      const total = list.length;
      const totalPages = Math.ceil(total / limitNum);
      const paginated = list.slice((pageNum - 1) * limitNum, pageNum * limitNum);

      res.json({
        success: true,
        data: paginated,
        pagination: {
          page: pageNum,
          limit: limitNum,
          total,
          totalPages
        }
      });
      return;
    }

    res.json({
      success: true,
      data: list
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * GET /api/users/guardians/:id
 * Retrieve single guardian details with enriched linked children, relationships, and family
 */
usersRouter.get('/guardians/:id', requireAuth, requirePermission('guardians.view'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { id } = req.params;
    const guardian = database.guardians.find((g) => g.id === id);
    if (!guardian) {
      res.status(404).json({ success: false, error: 'Guardian record not found.' });
      return;
    }

    res.json({
      success: true,
      data: enrichGuardian(guardian)
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * POST /api/users/guardians
 * Create new Guardian profile with duplicate check, user account creation, and relationship bindings
 */
usersRouter.post('/guardians', requireAuth, requirePermission('guardians.create'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const {
      name,
      firstName,
      lastName,
      preferredName,
      gender,
      dateOfBirth,
      relationship,
      phone,
      secondaryPhone,
      email,
      whatsapp,
      preferredContactMethod,
      address,
      permanentAddress,
      city,
      state,
      country,
      postalCode,
      occupation,
      nationality,
      idDocumentType,
      idDocumentNumber,
      emergencyContact,
      familyId,
      familyRole,
      studentIds,
      relationships,
      status,
      forceConfirm
    } = req.body;

    if (!name || !name.trim()) {
      res.status(400).json({ success: false, error: 'Guardian full name is required.' });
      return;
    }
    if (!relationship || !relationship.trim()) {
      res.status(400).json({ success: false, error: 'Relationship type is required.' });
      return;
    }
    if (!phone || !phone.trim()) {
      res.status(400).json({ success: false, error: 'Primary phone number is required.' });
      return;
    }

    // Validate email format if provided
    const cleanEmail = email ? email.trim().toLowerCase() : '';
    if (cleanEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
      res.status(400).json({ success: false, error: 'Please provide a valid email address.' });
      return;
    }

    // Duplicate detection check
    const inputPhoneDigits = normalizePhoneDigits(phone);
    if (!forceConfirm) {
      const duplicateMatches: any[] = [];
      for (const g of database.guardians) {
        const existPhoneDigits = normalizePhoneDigits(g.phone);
        const existEmail = (g.email || '').trim().toLowerCase();
        if (inputPhoneDigits && existPhoneDigits && inputPhoneDigits === existPhoneDigits) {
          duplicateMatches.push({ id: g.id, name: g.name, matchedBy: 'Phone number match', phone: g.phone, email: g.email });
        } else if (cleanEmail && existEmail && cleanEmail === existEmail) {
          duplicateMatches.push({ id: g.id, name: g.name, matchedBy: 'Email address match', phone: g.phone, email: g.email });
        }
      }

      if (duplicateMatches.length > 0) {
        res.status(409).json({
          success: false,
          duplicateDetected: true,
          error: `Potential duplicate guardian found (${duplicateMatches[0].matchedBy}: ${duplicateMatches[0].name}). Set forceConfirm=true to proceed.`,
          duplicates: duplicateMatches
        });
        return;
      }
    }

    const guardianId = `guard-${Date.now()}`;
    const nameParts = name.trim().split(' ');
    const computedFirstName = firstName?.trim() || nameParts[0] || 'Guardian';
    const computedLastName = lastName?.trim() || nameParts.slice(1).join(' ') || '';

    // Create user login account for guardian if email is provided
    let createdUserId: string | undefined = undefined;
    if (cleanEmail) {
      const existingUser = database.users.find((u) => u.email.toLowerCase() === cleanEmail);
      if (!existingUser) {
        const newSalt = 'e5f2a1b8c9d0e7f4a3b2c1d0e9f8a7b6';
        const newPasswordHash = hashPassword('Guardian@123', newSalt).hash;
        const newUserObj: any = {
          id: `usr-guardian-${Date.now()}`,
          name: name.trim(),
          email: cleanEmail,
          username: cleanEmail.split('@')[0],
          role: 'GUARDIAN',
          status: 'active',
          phoneNumber: phone.trim(),
          passwordHash: newPasswordHash,
          passwordSalt: newSalt,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        };
        database.users.push(newUserObj);
        createdUserId = newUserObj.id;
      } else {
        createdUserId = existingUser.id;
      }
    }

    const validStudentIds = Array.isArray(studentIds)
      ? studentIds.filter((sid: string) => database.studentProfiles.some((s) => s.id === sid))
      : [];

    const newGuardian: Guardian = {
      id: guardianId,
      userId: createdUserId,
      name: name.trim(),
      firstName: computedFirstName,
      lastName: computedLastName,
      preferredName: preferredName ? preferredName.trim() : computedFirstName,
      gender: gender || 'other',
      dateOfBirth: dateOfBirth || '',
      relationship: relationship.trim(),
      phone: phone.trim(),
      secondaryPhone: secondaryPhone ? secondaryPhone.trim() : '',
      email: cleanEmail,
      whatsapp: whatsapp ? whatsapp.trim() : '',
      preferredContactMethod: preferredContactMethod || 'phone',
      address: address ? address.trim() : '',
      permanentAddress: permanentAddress ? permanentAddress.trim() : (address ? address.trim() : ''),
      city: city ? city.trim() : '',
      state: state ? state.trim() : '',
      country: country ? country.trim() : 'USA',
      postalCode: postalCode ? postalCode.trim() : '',
      occupation: occupation ? occupation.trim() : '',
      nationality: nationality ? nationality.trim() : 'American',
      idDocumentType: idDocumentType || '',
      idDocumentNumber: idDocumentNumber ? idDocumentNumber.trim() : '',
      emergencyContact: emergencyContact ? emergencyContact.trim() : phone.trim(),
      familyId: familyId || '',
      familyRole: familyRole || relationship.trim(),
      studentIds: validStudentIds,
      status: status || 'active',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    database.guardians.push(newGuardian);

    // Setup Parent-Student Relationships
    const relationshipsPayload: any[] = Array.isArray(relationships) ? relationships : [];
    for (const sid of validStudentIds) {
      const relConfig = relationshipsPayload.find((r) => r.studentId === sid);
      const isPrimary = relConfig?.isPrimaryGuardian !== undefined ? relConfig.isPrimaryGuardian : true;
      const isSecondary = relConfig?.isSecondaryGuardian !== undefined ? relConfig.isSecondaryGuardian : !isPrimary;

      // If primary guardian, demote any existing primary guardian for this student
      if (isPrimary) {
        database.parentStudentRelationships
          .filter((r) => r.studentId === sid && r.guardianId !== guardianId)
          .forEach((r) => {
            if (r.isPrimaryGuardian) {
              r.isPrimaryGuardian = false;
              r.isSecondaryGuardian = true;
              r.updatedAt = new Date().toISOString();
            }
          });
      }

      const newRel: ParentStudentRelationship = {
        id: `rel-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
        guardianId,
        studentId: sid,
        relationshipType: relConfig?.relationshipType || newGuardian.relationship,
        isPrimaryGuardian: isPrimary,
        isSecondaryGuardian: isSecondary,
        isEmergencyContact: relConfig?.isEmergencyContact !== undefined ? relConfig.isEmergencyContact : true,
        isAuthorizedAcademic: relConfig?.isAuthorizedAcademic !== undefined ? relConfig.isAuthorizedAcademic : true,
        isAuthorizedAttendance: relConfig?.isAuthorizedAttendance !== undefined ? relConfig.isAuthorizedAttendance : true,
        isAuthorizedFinancial: relConfig?.isAuthorizedFinancial !== undefined ? relConfig.isAuthorizedFinancial : isPrimary,
        isAuthorizedCommunication: relConfig?.isAuthorizedCommunication !== undefined ? relConfig.isAuthorizedCommunication : true,
        isPickupAuthorized: relConfig?.isPickupAuthorized !== undefined ? relConfig.isPickupAuthorized : true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      database.parentStudentRelationships.push(newRel);

      // Synchronize to StudentProfile
      const student = database.studentProfiles.find((s) => s.id === sid);
      if (student) {
        if (isPrimary) {
          student.guardianId = guardianId;
          student.guardianName = newGuardian.name;
          student.guardianRelation = newGuardian.relationship;
          student.guardianPhone = newGuardian.phone;
          student.guardianEmail = newGuardian.email;
          student.guardianAddress = newGuardian.address;
          student.guardianOccupation = newGuardian.occupation;
        } else if (isSecondary) {
          student.secondaryGuardianId = guardianId;
          student.secondaryGuardianName = newGuardian.name;
          student.secondaryGuardianRelation = newGuardian.relationship;
          student.secondaryGuardianPhone = newGuardian.phone;
          student.secondaryGuardianEmail = newGuardian.email;
        }
        if (newGuardian.familyId) {
          student.familyId = newGuardian.familyId;
        }
      }
    }

    // Attach to Family Household if familyId provided
    if (newGuardian.familyId) {
      const family = database.families.find((f) => f.id === newGuardian.familyId);
      if (family) {
        if (!family.guardianIds.includes(guardianId)) {
          family.guardianIds.push(guardianId);
        }
        for (const sid of validStudentIds) {
          if (!family.studentIds.includes(sid)) {
            family.studentIds.push(sid);
          }
        }
        family.updatedAt = new Date().toISOString();
      }
    }

    logAudit({
      userId: req.user!.id,
      userName: req.user!.name,
      userRole: req.user!.role,
      action: 'CREATE',
      entity: 'GUARDIAN',
      entityType: 'GUARDIAN',
      entityId: guardianId,
      details: `Registered new guardian profile for ${newGuardian.name} linked to ${validStudentIds.length} student(s).`,
      ipAddress: req.ip
    });

    res.status(201).json({
      success: true,
      message: `Guardian profile for ${newGuardian.name} created successfully.`,
      data: enrichGuardian(newGuardian)
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * PUT /api/users/guardians/:id
 * Update Guardian details, re-validate, synchronize changes to linked students & user accounts
 */
usersRouter.put('/guardians/:id', requireAuth, requirePermission('guardians.edit'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { id } = req.params;
    const index = database.guardians.findIndex((g) => g.id === id);
    if (index === -1) {
      res.status(404).json({ success: false, error: 'Guardian record not found.' });
      return;
    }

    const existing = database.guardians[index];
    const {
      name,
      firstName,
      lastName,
      preferredName,
      gender,
      dateOfBirth,
      relationship,
      phone,
      secondaryPhone,
      email,
      whatsapp,
      preferredContactMethod,
      address,
      permanentAddress,
      city,
      state,
      country,
      postalCode,
      occupation,
      nationality,
      idDocumentType,
      idDocumentNumber,
      emergencyContact,
      familyId,
      familyRole,
      studentIds,
      status
    } = req.body;

    // Validate email format if modified
    const cleanEmail = email !== undefined ? email.trim().toLowerCase() : existing.email;
    if (cleanEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
      res.status(400).json({ success: false, error: 'Please provide a valid email address.' });
      return;
    }

    // Check duplicate phone/email against OTHER guardians
    const newPhoneDigits = phone !== undefined ? normalizePhoneDigits(phone) : normalizePhoneDigits(existing.phone);
    for (const g of database.guardians) {
      if (g.id === id) continue;
      const existPhoneDigits = normalizePhoneDigits(g.phone);
      const existEmail = (g.email || '').trim().toLowerCase();

      if (newPhoneDigits && existPhoneDigits && newPhoneDigits === existPhoneDigits) {
        res.status(409).json({
          success: false,
          error: `Phone number is already associated with another guardian (${g.name}).`
        });
        return;
      }
      if (cleanEmail && existEmail && cleanEmail === existEmail) {
        res.status(409).json({
          success: false,
          error: `Email address is already associated with another guardian (${g.name}).`
        });
        return;
      }
    }

    const validStudentIds = Array.isArray(studentIds)
      ? studentIds.filter((sid: string) => database.studentProfiles.some((s) => s.id === sid))
      : existing.studentIds;

    const updatedGuardian: Guardian = {
      ...existing,
      name: name !== undefined ? name.trim() : existing.name,
      firstName: firstName !== undefined ? firstName.trim() : existing.firstName,
      lastName: lastName !== undefined ? lastName.trim() : existing.lastName,
      preferredName: preferredName !== undefined ? preferredName.trim() : existing.preferredName,
      gender: gender !== undefined ? gender : existing.gender,
      dateOfBirth: dateOfBirth !== undefined ? dateOfBirth : existing.dateOfBirth,
      relationship: relationship !== undefined ? relationship.trim() : existing.relationship,
      phone: phone !== undefined ? phone.trim() : existing.phone,
      secondaryPhone: secondaryPhone !== undefined ? secondaryPhone.trim() : existing.secondaryPhone,
      email: cleanEmail,
      whatsapp: whatsapp !== undefined ? whatsapp.trim() : existing.whatsapp,
      preferredContactMethod: preferredContactMethod !== undefined ? preferredContactMethod : existing.preferredContactMethod,
      address: address !== undefined ? address.trim() : existing.address,
      permanentAddress: permanentAddress !== undefined ? permanentAddress.trim() : existing.permanentAddress,
      city: city !== undefined ? city.trim() : existing.city,
      state: state !== undefined ? state.trim() : existing.state,
      country: country !== undefined ? country.trim() : existing.country,
      postalCode: postalCode !== undefined ? postalCode.trim() : existing.postalCode,
      occupation: occupation !== undefined ? occupation.trim() : existing.occupation,
      nationality: nationality !== undefined ? nationality.trim() : existing.nationality,
      idDocumentType: idDocumentType !== undefined ? idDocumentType : existing.idDocumentType,
      idDocumentNumber: idDocumentNumber !== undefined ? idDocumentNumber.trim() : existing.idDocumentNumber,
      emergencyContact: emergencyContact !== undefined ? emergencyContact.trim() : existing.emergencyContact,
      familyId: familyId !== undefined ? familyId : existing.familyId,
      familyRole: familyRole !== undefined ? familyRole : existing.familyRole,
      studentIds: validStudentIds,
      status: status !== undefined ? status : existing.status,
      updatedAt: new Date().toISOString()
    };

    database.guardians[index] = updatedGuardian;

    // Synchronize to linked StudentProfiles
    for (const sid of validStudentIds) {
      const st = database.studentProfiles.find((s) => s.id === sid);
      if (st) {
        if (st.guardianId === updatedGuardian.id) {
          st.guardianName = updatedGuardian.name;
          st.guardianRelation = updatedGuardian.relationship;
          st.guardianPhone = updatedGuardian.phone;
          st.guardianEmail = updatedGuardian.email;
          st.guardianAddress = updatedGuardian.address;
          st.guardianOccupation = updatedGuardian.occupation;
        } else if (st.secondaryGuardianId === updatedGuardian.id) {
          st.secondaryGuardianName = updatedGuardian.name;
          st.secondaryGuardianRelation = updatedGuardian.relationship;
          st.secondaryGuardianPhone = updatedGuardian.phone;
          st.secondaryGuardianEmail = updatedGuardian.email;
        }
      }
    }

    // Synchronize user login account
    if (updatedGuardian.userId) {
      const u = database.users.find((usr) => usr.id === updatedGuardian.userId);
      if (u) {
        u.name = updatedGuardian.name;
        u.phoneNumber = updatedGuardian.phone;
        u.email = updatedGuardian.email;
        u.updatedAt = new Date().toISOString();
      }
    }

    logAudit({
      userId: req.user!.id,
      userName: req.user!.name,
      userRole: req.user!.role,
      action: 'UPDATE',
      entity: 'GUARDIAN',
      entityType: 'GUARDIAN',
      entityId: existing.id,
      details: `Updated guardian profile for ${updatedGuardian.name}.`,
      ipAddress: req.ip
    });

    res.json({
      success: true,
      message: 'Guardian record updated successfully.',
      data: enrichGuardian(updatedGuardian)
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * POST /api/users/guardians/:id/link-student
 * Link or unlink student with primary/secondary designations and permissions
 */
usersRouter.post('/guardians/:id/link-student', requireAuth, requirePermission('guardians.edit'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { id } = req.params;
    const {
      studentId,
      action,
      relationshipType,
      isPrimaryGuardian = true,
      isSecondaryGuardian = false,
      isEmergencyContact = true,
      isAuthorizedAcademic = true,
      isAuthorizedAttendance = true,
      isAuthorizedFinancial = true,
      isAuthorizedCommunication = true,
      isPickupAuthorized = true
    } = req.body;

    if (!studentId) {
      res.status(400).json({ success: false, error: 'Student ID is required.' });
      return;
    }

    const guardian = database.guardians.find((g) => g.id === id);
    if (!guardian) {
      res.status(404).json({ success: false, error: 'Guardian not found.' });
      return;
    }

    const student = database.studentProfiles.find((s) => s.id === studentId);
    if (!student) {
      res.status(404).json({ success: false, error: 'Student record not found.' });
      return;
    }

    if (action === 'unlink') {
      guardian.studentIds = guardian.studentIds.filter((sid) => sid !== studentId);
      
      // Remove relationship record
      const relIdx = database.parentStudentRelationships.findIndex(
        (r) => r.guardianId === guardian.id && r.studentId === studentId
      );
      if (relIdx !== -1) {
        database.parentStudentRelationships.splice(relIdx, 1);
      }

      if (student.guardianId === guardian.id) {
        student.guardianId = undefined;
        // Promote secondary guardian if available
        const remainingPrimary = database.parentStudentRelationships.find(
          (r) => r.studentId === studentId && (r.isPrimaryGuardian || r.isSecondaryGuardian)
        );
        if (remainingPrimary) {
          const promoGuard = database.guardians.find((g) => g.id === remainingPrimary.guardianId);
          if (promoGuard) {
            remainingPrimary.isPrimaryGuardian = true;
            remainingPrimary.isSecondaryGuardian = false;
            student.guardianId = promoGuard.id;
            student.guardianName = promoGuard.name;
            student.guardianRelation = promoGuard.relationship;
            student.guardianPhone = promoGuard.phone;
            student.guardianEmail = promoGuard.email;
          }
        }
      } else if (student.secondaryGuardianId === guardian.id) {
        student.secondaryGuardianId = undefined;
        student.secondaryGuardianName = undefined;
        student.secondaryGuardianPhone = undefined;
        student.secondaryGuardianEmail = undefined;
      }
    } else {
      // Link action
      if (!guardian.studentIds.includes(studentId)) {
        guardian.studentIds.push(studentId);
      }

      // If marked primary, ensure other guardians for this student are demoted to secondary
      if (isPrimaryGuardian) {
        database.parentStudentRelationships
          .filter((r) => r.studentId === studentId && r.guardianId !== guardian.id)
          .forEach((r) => {
            if (r.isPrimaryGuardian) {
              r.isPrimaryGuardian = false;
              r.isSecondaryGuardian = true;
              r.updatedAt = new Date().toISOString();
            }
          });
      }

      const existingRelIndex = database.parentStudentRelationships.findIndex(
        (r) => r.guardianId === guardian.id && r.studentId === studentId
      );

      const relData: ParentStudentRelationship = {
        id: existingRelIndex !== -1 ? database.parentStudentRelationships[existingRelIndex].id : `rel-${Date.now()}`,
        guardianId: guardian.id,
        studentId,
        relationshipType: relationshipType || guardian.relationship,
        isPrimaryGuardian: isPrimaryGuardian,
        isSecondaryGuardian: !isPrimaryGuardian && isSecondaryGuardian,
        isEmergencyContact,
        isAuthorizedAcademic,
        isAuthorizedAttendance,
        isAuthorizedFinancial,
        isAuthorizedCommunication,
        isPickupAuthorized,
        createdAt: existingRelIndex !== -1 ? database.parentStudentRelationships[existingRelIndex].createdAt : new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      if (existingRelIndex !== -1) {
        database.parentStudentRelationships[existingRelIndex] = relData;
      } else {
        database.parentStudentRelationships.push(relData);
      }

      if (isPrimaryGuardian) {
        student.guardianId = guardian.id;
        student.guardianName = guardian.name;
        student.guardianRelation = guardian.relationship;
        student.guardianPhone = guardian.phone;
        student.guardianEmail = guardian.email;
        student.guardianAddress = guardian.address;
        student.guardianOccupation = guardian.occupation;
      } else if (isSecondaryGuardian) {
        student.secondaryGuardianId = guardian.id;
        student.secondaryGuardianName = guardian.name;
        student.secondaryGuardianRelation = guardian.relationship;
        student.secondaryGuardianPhone = guardian.phone;
        student.secondaryGuardianEmail = guardian.email;
      }
    }

    guardian.updatedAt = new Date().toISOString();

    logAudit({
      userId: req.user!.id,
      userName: req.user!.name,
      userRole: req.user!.role,
      action: 'UPDATE',
      entity: 'GUARDIAN',
      entityType: 'GUARDIAN',
      entityId: guardian.id,
      details: `${action === 'unlink' ? 'Unlinked' : 'Linked'} student ${student.admissionNumber} (${student.firstName || student.id}) to guardian ${guardian.name}.`,
      ipAddress: req.ip
    });

    res.json({
      success: true,
      message: `Student successfully ${action === 'unlink' ? 'unlinked from' : 'linked to'} guardian.`,
      data: enrichGuardian(guardian)
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * DELETE /api/users/guardians/:id
 * Delete guardian, safely unlink associated students, delete relationships and user accounts
 */
usersRouter.delete('/guardians/:id', requireAuth, requirePermission('guardians.delete'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { id } = req.params;
    const index = database.guardians.findIndex((g) => g.id === id);
    if (index === -1) {
      res.status(404).json({ success: false, error: 'Guardian record not found.' });
      return;
    }

    const guardian = database.guardians[index];

    // Safely unlink all students
    database.studentProfiles.forEach((st) => {
      if (st.guardianId === guardian.id) {
        st.guardianId = undefined;
      }
      if (st.secondaryGuardianId === guardian.id) {
        st.secondaryGuardianId = undefined;
      }
    });

    // Remove all relationships
    database.parentStudentRelationships = database.parentStudentRelationships.filter(
      (r) => r.guardianId !== guardian.id
    );

    // Remove from family if member
    if (guardian.familyId) {
      const fam = database.families.find((f) => f.id === guardian.familyId);
      if (fam) {
        fam.guardianIds = fam.guardianIds.filter((gid) => gid !== guardian.id);
      }
    }

    // Delete user account if linked
    if (guardian.userId) {
      const userIndex = database.users.findIndex((u) => u.id === guardian.userId);
      if (userIndex !== -1) {
        database.users.splice(userIndex, 1);
      }
    }

    database.guardians.splice(index, 1);

    logAudit({
      userId: req.user!.id,
      userName: req.user!.name,
      userRole: req.user!.role,
      action: 'DELETE',
      entity: 'GUARDIAN',
      entityType: 'GUARDIAN',
      entityId: guardian.id,
      details: `Deleted guardian profile ${guardian.name}.`,
      ipAddress: req.ip
    });

    res.json({
      success: true,
      message: `Guardian ${guardian.name} deleted successfully.`
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * GET /api/users/guardians/:id/account
 * Retrieve security and account credentials info for a guardian
 */
usersRouter.get('/guardians/:id/account', requireAuth, requirePermission('guardians.view'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { id } = req.params;
    const guardian = database.guardians.find((g) => g.id === id);
    if (!guardian) {
      res.status(404).json({ success: false, error: 'Guardian record not found.' });
      return;
    }

    const linkedUser = guardian.userId
      ? database.users.find((u) => u.id === guardian.userId)
      : database.users.find((u) => u.email.toLowerCase() === guardian.email.toLowerCase());

    const invitations = (database.parentInvitations || []).filter((inv) => inv.guardianId === id);
    const activeInvitation = invitations.find((inv) => inv.status === 'pending' && new Date(inv.expiresAt) > new Date()) || null;
    const resetTokens = (database.passwordResetTokens || []).filter((t) => linkedUser && t.userId === linkedUser.id);

    const accountInfo: GuardianAccountInfo = {
      guardianId: guardian.id,
      guardianName: guardian.name,
      guardianEmail: guardian.email,
      guardianPhone: guardian.phone,
      hasAccount: !!linkedUser,
      userId: linkedUser?.id,
      username: linkedUser?.username,
      userEmail: linkedUser?.email,
      accountStatus: linkedUser ? linkedUser.status : (activeInvitation ? 'invited' : 'unprovisioned'),
      createdAt: linkedUser?.createdAt,
      lastLoginAt: linkedUser?.lastLoginAt,
      isLocked: linkedUser?.status === 'locked',
      isDisabled: linkedUser?.status === 'disabled' || linkedUser?.status === 'suspended',
      invitations,
      activeInvitation,
      passwordResetTokens: resetTokens,
      linkedStudentsCount: (guardian.studentIds || []).length
    };

    res.json({
      success: true,
      data: accountInfo
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * POST /api/users/guardians/:id/invite
 * Create / issue secure time-limited invitation token (48h expiry) for parent account activation
 */
usersRouter.post('/guardians/:id/invite', requireAuth, requirePermission('guardians.edit'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { id } = req.params;
    const guardian = database.guardians.find((g) => g.id === id);
    if (!guardian) {
      res.status(404).json({ success: false, error: 'Guardian record not found.' });
      return;
    }

    if (!guardian.email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(guardian.email)) {
      res.status(400).json({ success: false, error: 'Guardian must have a valid email address to receive an invitation.' });
      return;
    }

    // Resolve or pre-create user record in 'invited' state
    let user = guardian.userId
      ? database.users.find((u) => u.id === guardian.userId)
      : database.users.find((u) => u.email.toLowerCase() === guardian.email.toLowerCase());

    if (!user) {
      const generatedUsername = guardian.email.split('@')[0].toLowerCase().replace(/[^a-z0-9]/g, '');
      const hashedTemp = hashPassword(generateSecureToken(16));
      const newUser: StoredUser = {
        id: `usr-guardian-${Date.now()}`,
        name: guardian.name,
        email: guardian.email,
        username: generatedUsername,
        role: 'GUARDIAN',
        status: 'invited',
        phoneNumber: guardian.phone,
        passwordHash: hashedTemp.hash,
        passwordSalt: hashedTemp.salt,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      database.users.push(newUser);
      guardian.userId = newUser.id;
      user = newUser;
    } else if (user.status === 'pending' || user.status === 'invited') {
      user.status = 'invited';
      user.updatedAt = new Date().toISOString();
    }

    // Invalidate existing pending invitations
    (database.parentInvitations || [])
      .filter((inv) => inv.guardianId === id && inv.status === 'pending')
      .forEach((inv) => {
        inv.status = 'revoked';
      });

    // Generate secure 48h invitation token
    const token = generateSecureToken(32);
    const invitation: ParentInvitation = {
      id: `inv-${Date.now()}`,
      guardianId: guardian.id,
      guardianName: guardian.name,
      userId: user.id,
      email: guardian.email,
      token,
      status: 'pending',
      expiresAt: new Date(Date.now() + 48 * 60 * 60 * 1000).toISOString(),
      createdAt: new Date().toISOString(),
      invitedBy: req.user!.id,
      invitedByName: req.user!.name
    };

    if (!database.parentInvitations) {
      database.parentInvitations = [];
    }
    database.parentInvitations.push(invitation);

    logAudit({
      userId: req.user!.id,
      userName: req.user!.name,
      userRole: req.user!.role,
      action: 'CREATE',
      entity: 'USER',
      entityId: user.id,
      details: `Generated portal invitation for guardian ${guardian.name} (${guardian.email}).`,
      ipAddress: req.ip
    });

    res.json({
      success: true,
      message: `Invitation successfully created for ${guardian.name}.`,
      data: {
        invitation,
        activationUrl: `/activate?token=${token}`
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * POST /api/users/guardians/:id/resend-invite
 * Revoke older invitations and issue fresh one
 */
usersRouter.post('/guardians/:id/resend-invite', requireAuth, requirePermission('guardians.edit'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { id } = req.params;
    const guardian = database.guardians.find((g) => g.id === id);
    if (!guardian) {
      res.status(404).json({ success: false, error: 'Guardian not found.' });
      return;
    }

    // Revoke prior
    (database.parentInvitations || [])
      .filter((inv) => inv.guardianId === id && inv.status === 'pending')
      .forEach((inv) => {
        inv.status = 'revoked';
      });

    const token = generateSecureToken(32);
    const invitation: ParentInvitation = {
      id: `inv-${Date.now()}`,
      guardianId: guardian.id,
      guardianName: guardian.name,
      userId: guardian.userId,
      email: guardian.email,
      token,
      status: 'pending',
      expiresAt: new Date(Date.now() + 48 * 60 * 60 * 1000).toISOString(),
      createdAt: new Date().toISOString(),
      invitedBy: req.user!.id,
      invitedByName: req.user!.name
    };

    if (!database.parentInvitations) {
      database.parentInvitations = [];
    }
    database.parentInvitations.push(invitation);

    logAudit({
      userId: req.user!.id,
      userName: req.user!.name,
      userRole: req.user!.role,
      action: 'UPDATE',
      entity: 'USER',
      details: `Resent portal invitation for guardian ${guardian.name}.`,
      ipAddress: req.ip
    });

    res.json({
      success: true,
      message: `Fresh invitation sent to ${guardian.email}.`,
      data: {
        invitation,
        activationUrl: `/activate?token=${token}`
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * POST /api/users/guardians/:id/toggle-account-status
 * Enable, disable, lock, or suspend parent account without deleting guardian history
 */
usersRouter.post('/guardians/:id/toggle-account-status', requireAuth, requirePermission('guardians.edit'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { id } = req.params;
    const { status, reason } = req.body;
    const allowedStatuses = ['active', 'disabled', 'locked', 'suspended'];
    if (!status || !allowedStatuses.includes(status)) {
      res.status(400).json({ success: false, error: `Invalid status. Must be one of: ${allowedStatuses.join(', ')}.` });
      return;
    }

    const guardian = database.guardians.find((g) => g.id === id);
    if (!guardian) {
      res.status(404).json({ success: false, error: 'Guardian not found.' });
      return;
    }

    const user = guardian.userId
      ? database.users.find((u) => u.id === guardian.userId)
      : database.users.find((u) => u.email.toLowerCase() === guardian.email.toLowerCase());

    if (!user) {
      res.status(400).json({ success: false, error: 'Guardian has no linked user account. Please invite them first to create an account.' });
      return;
    }

    const previousStatus = user.status;
    user.status = status;
    user.updatedAt = new Date().toISOString();

    // If disabled, locked, or suspended, immediately evict all active sessions
    if (status !== 'active') {
      const revokedSessions = invalidateUserSessions(user.id);
      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'UPDATE',
        entity: 'USER',
        entityId: user.id,
        details: `Revoked ${revokedSessions} active session(s) due to account status change to '${status}'.`,
        ipAddress: req.ip
      });
    }

    logAudit({
      userId: req.user!.id,
      userName: req.user!.name,
      userRole: req.user!.role,
      action: 'UPDATE',
      entity: 'USER',
      entityId: user.id,
      details: `Changed guardian account status from '${previousStatus}' to '${status}'. Reason: ${reason || 'Administrative action'}.`,
      ipAddress: req.ip
    });

    res.json({
      success: true,
      message: `Account status for ${guardian.name} successfully set to ${status}.`,
      data: {
        userId: user.id,
        status: user.status
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * POST /api/users/guardians/:id/reset-access
 * Issue immediate one-time password reset token on behalf of parent
 */
usersRouter.post('/guardians/:id/reset-access', requireAuth, requirePermission('guardians.edit'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { id } = req.params;
    const guardian = database.guardians.find((g) => g.id === id);
    if (!guardian) {
      res.status(404).json({ success: false, error: 'Guardian not found.' });
      return;
    }

    const user = guardian.userId
      ? database.users.find((u) => u.id === guardian.userId)
      : database.users.find((u) => u.email.toLowerCase() === guardian.email.toLowerCase());

    if (!user) {
      res.status(400).json({ success: false, error: 'Guardian does not have a user account yet. Please send an invitation.' });
      return;
    }

    // Invalidate old pending tokens
    (database.passwordResetTokens || [])
      .filter((t) => t.userId === user.id && t.status === 'pending')
      .forEach((t) => {
        t.status = 'revoked';
      });

    const token = generateSecureToken(24);
    const resetRecord: PasswordResetToken = {
      id: `prt-${Date.now()}`,
      userId: user.id,
      email: user.email,
      token,
      status: 'pending',
      expiresAt: new Date(Date.now() + 60 * 60 * 1000).toISOString(),
      createdAt: new Date().toISOString()
    };

    if (!database.passwordResetTokens) {
      database.passwordResetTokens = [];
    }
    database.passwordResetTokens.push(resetRecord);

    logAudit({
      userId: req.user!.id,
      userName: req.user!.name,
      userRole: req.user!.role,
      action: 'UPDATE',
      entity: 'USER',
      entityId: user.id,
      details: `Administrator generated password reset token for guardian ${guardian.name}.`,
      ipAddress: req.ip
    });

    res.json({
      success: true,
      message: `Password reset link generated for ${guardian.name}.`,
      data: {
        resetToken: token,
        resetUrl: `/reset-password?token=${token}`
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * GET /api/users/guardians/:id/relationships
 * Get all parent-student relationships for a specific guardian
 */
usersRouter.get('/guardians/:id/relationships', requireAuth, requirePermission('guardians.view'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { id } = req.params;
    const rels = database.parentStudentRelationships.filter((r) => r.guardianId === id);
    const enrichedRels = rels.map((r) => {
      const student = database.studentProfiles.find((s) => s.id === r.studentId);
      const user = student ? database.users.find((u) => u.id === student.userId) : undefined;
      const cls = student ? database.classes.find((c) => c.id === student.classId) : undefined;
      return {
        ...r,
        studentName: user?.name || `${student?.firstName || ''} ${student?.lastName || ''}`.trim() || 'Student',
        admissionNumber: student?.admissionNumber || '',
        className: cls?.name || 'Class'
      };
    });

    res.json({
      success: true,
      data: enrichedRels
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * POST /api/users/guardians/:id/relationships
 * Configure or update a parent-student relationship with granular authorizations
 */
usersRouter.post('/guardians/:id/relationships', requireAuth, requirePermission('guardians.edit'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { id } = req.params;
    const {
      studentId,
      relationshipType,
      isPrimaryGuardian,
      isSecondaryGuardian,
      isEmergencyContact,
      isAuthorizedAcademic,
      isAuthorizedAttendance,
      isAuthorizedFinancial,
      isAuthorizedCommunication,
      isPickupAuthorized,
      notes
    } = req.body;

    if (!studentId) {
      res.status(400).json({ success: false, error: 'Student ID is required.' });
      return;
    }

    const guardian = database.guardians.find((g) => g.id === id);
    if (!guardian) {
      res.status(404).json({ success: false, error: 'Guardian not found.' });
      return;
    }

    const student = database.studentProfiles.find((s) => s.id === studentId);
    if (!student) {
      res.status(404).json({ success: false, error: 'Student not found.' });
      return;
    }

    // Ensure student is in guardian's studentIds
    if (!guardian.studentIds.includes(studentId)) {
      guardian.studentIds.push(studentId);
    }

    // If setting as primary, demote any other primary guardians for this student
    if (isPrimaryGuardian) {
      database.parentStudentRelationships
        .filter((r) => r.studentId === studentId && r.guardianId !== id)
        .forEach((r) => {
          if (r.isPrimaryGuardian) {
            r.isPrimaryGuardian = false;
            r.isSecondaryGuardian = true;
            r.updatedAt = new Date().toISOString();
          }
        });

      student.guardianId = guardian.id;
      student.guardianName = guardian.name;
      student.guardianRelation = relationshipType || guardian.relationship;
      student.guardianPhone = guardian.phone;
      student.guardianEmail = guardian.email;
    } else if (isSecondaryGuardian) {
      student.secondaryGuardianId = guardian.id;
      student.secondaryGuardianName = guardian.name;
      student.secondaryGuardianRelation = relationshipType || guardian.relationship;
      student.secondaryGuardianPhone = guardian.phone;
      student.secondaryGuardianEmail = guardian.email;
    }

    const existingIndex = database.parentStudentRelationships.findIndex(
      (r) => r.guardianId === id && r.studentId === studentId
    );

    const relRecord: ParentStudentRelationship = {
      id: existingIndex !== -1 ? database.parentStudentRelationships[existingIndex].id : `rel-${Date.now()}`,
      guardianId: id,
      studentId,
      relationshipType: relationshipType || guardian.relationship,
      isPrimaryGuardian: !!isPrimaryGuardian,
      isSecondaryGuardian: !!isSecondaryGuardian,
      isEmergencyContact: isEmergencyContact !== undefined ? isEmergencyContact : true,
      isAuthorizedAcademic: isAuthorizedAcademic !== undefined ? isAuthorizedAcademic : true,
      isAuthorizedAttendance: isAuthorizedAttendance !== undefined ? isAuthorizedAttendance : true,
      isAuthorizedFinancial: isAuthorizedFinancial !== undefined ? isAuthorizedFinancial : !!isPrimaryGuardian,
      isAuthorizedCommunication: isAuthorizedCommunication !== undefined ? isAuthorizedCommunication : true,
      isPickupAuthorized: isPickupAuthorized !== undefined ? isPickupAuthorized : true,
      notes: notes || '',
      createdAt: existingIndex !== -1 ? database.parentStudentRelationships[existingIndex].createdAt : new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    if (existingIndex !== -1) {
      database.parentStudentRelationships[existingIndex] = relRecord;
    } else {
      database.parentStudentRelationships.push(relRecord);
    }

    res.json({
      success: true,
      message: 'Parent-Student relationship authorizations saved.',
      data: relRecord
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// =========================================================================
// 3B. FAMILY HOUSEHOLD MANAGEMENT
// =========================================================================

function enrichFamily(fam: Family): Family {
  const memberGuardians = database.guardians
    .filter((g) => fam.guardianIds?.includes(g.id) || g.familyId === fam.id)
    .map(enrichGuardian);

  const memberStudents = (fam.studentIds || []).map((sid) => {
    const st = database.studentProfiles.find((s) => s.id === sid);
    if (!st) return null;
    const u = database.users.find((usr) => usr.id === st.userId);
    const cls = database.classes.find((c) => c.id === st.classId);
    const sec = database.sections.find((s) => s.id === st.sectionId);
    return {
      id: st.id,
      name: u?.name || `${st.firstName || ''} ${st.lastName || ''}`.trim() || 'Student',
      admissionNumber: st.admissionNumber,
      rollNumber: st.rollNumber,
      className: cls?.name || 'Class',
      sectionName: sec?.name || 'A',
      avatarUrl: st.avatarUrl || u?.avatarUrl || '',
      status: st.status || 'active'
    };
  }).filter(Boolean) as any[];

  return {
    ...fam,
    guardians: memberGuardians,
    students: memberStudents
  };
}

/**
 * GET /api/users/families
 * List all family households with member guardians and sibling students
 */
usersRouter.get('/families', requireAuth, requirePermission('guardians.view'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { search, status, page, limit } = req.query as {
      search?: string;
      status?: string;
      page?: string;
      limit?: string;
    };

    let list = database.families.map(enrichFamily);

    if (search && search.trim()) {
      const q = search.toLowerCase().trim();
      list = list.filter((f) =>
        f.familyName.toLowerCase().includes(q) ||
        f.familyCode.toLowerCase().includes(q) ||
        f.primaryContactName.toLowerCase().includes(q) ||
        f.primaryPhone.toLowerCase().includes(q) ||
        (f.primaryEmail && f.primaryEmail.toLowerCase().includes(q)) ||
        (f.guardians && f.guardians.some((g) => g.name.toLowerCase().includes(q))) ||
        (f.students && f.students.some((s) => s.name.toLowerCase().includes(q)))
      );
    }

    if (status && status !== 'ALL') {
      list = list.filter((f) => f.status === status);
    }

    list.sort((a, b) => a.familyName.localeCompare(b.familyName));

    if (page && limit) {
      const pageNum = Math.max(1, parseInt(page, 10) || 1);
      const limitNum = Math.max(1, parseInt(limit, 10) || 10);
      const total = list.length;
      const paginated = list.slice((pageNum - 1) * limitNum, pageNum * limitNum);
      res.json({
        success: true,
        data: paginated,
        pagination: { page: pageNum, limit: limitNum, total, totalPages: Math.ceil(total / limitNum) }
      });
      return;
    }

    res.json({
      success: true,
      data: list
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * GET /api/users/families/:id
 * Retrieve single family household with full member details
 */
usersRouter.get('/families/:id', requireAuth, requirePermission('guardians.view'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { id } = req.params;
    const fam = database.families.find((f) => f.id === id);
    if (!fam) {
      res.status(404).json({ success: false, error: 'Family household record not found.' });
      return;
    }

    res.json({
      success: true,
      data: enrichFamily(fam)
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * POST /api/users/families
 * Create new Family Household
 */
usersRouter.post('/families', requireAuth, requirePermission('guardians.create'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const {
      familyName,
      primaryContactName,
      primaryPhone,
      primaryEmail,
      address,
      city,
      state,
      country,
      postalCode,
      guardianIds,
      studentIds,
      notes
    } = req.body;

    if (!familyName || !familyName.trim()) {
      res.status(400).json({ success: false, error: 'Family household name is required.' });
      return;
    }
    if (!primaryContactName || !primaryContactName.trim()) {
      res.status(400).json({ success: false, error: 'Primary contact name is required.' });
      return;
    }
    if (!primaryPhone || !primaryPhone.trim()) {
      res.status(400).json({ success: false, error: 'Primary contact phone is required.' });
      return;
    }

    const familyId = `fam-${Date.now()}`;
    const familyCount = database.families.length + 1;
    const familyCode = `FAM-2026-${String(familyCount).padStart(3, '0')}`;

    const validGuardianIds = Array.isArray(guardianIds)
      ? guardianIds.filter((gid: string) => database.guardians.some((g) => g.id === gid))
      : [];

    const validStudentIds = Array.isArray(studentIds)
      ? studentIds.filter((sid: string) => database.studentProfiles.some((s) => s.id === sid))
      : [];

    const newFamily: Family = {
      id: familyId,
      familyCode,
      familyName: familyName.trim(),
      primaryContactName: primaryContactName.trim(),
      primaryPhone: primaryPhone.trim(),
      primaryEmail: primaryEmail ? primaryEmail.trim().toLowerCase() : '',
      address: address ? address.trim() : '',
      city: city ? city.trim() : '',
      state: state ? state.trim() : '',
      country: country ? country.trim() : 'USA',
      postalCode: postalCode ? postalCode.trim() : '',
      guardianIds: validGuardianIds,
      studentIds: validStudentIds,
      status: 'active',
      notes: notes || '',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    database.families.push(newFamily);

    // Update familyId on linked guardians
    for (const gid of validGuardianIds) {
      const g = database.guardians.find((guard) => guard.id === gid);
      if (g) {
        g.familyId = familyId;
      }
    }

    // Update familyId on linked students
    for (const sid of validStudentIds) {
      const s = database.studentProfiles.find((st) => st.id === sid);
      if (s) {
        s.familyId = familyId;
      }
    }

    logAudit({
      userId: req.user!.id,
      userName: req.user!.name,
      userRole: req.user!.role,
      action: 'CREATE',
      entity: 'GUARDIAN',
      entityType: 'FAMILY',
      entityId: familyId,
      details: `Created new family household ${newFamily.familyName} (${newFamily.familyCode}).`,
      ipAddress: req.ip
    });

    res.status(201).json({
      success: true,
      message: `Family household ${newFamily.familyName} created successfully.`,
      data: enrichFamily(newFamily)
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * PUT /api/users/families/:id
 * Update Family Household details
 */
usersRouter.put('/families/:id', requireAuth, requirePermission('guardians.edit'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { id } = req.params;
    const fam = database.families.find((f) => f.id === id);
    if (!fam) {
      res.status(404).json({ success: false, error: 'Family household record not found.' });
      return;
    }

    const {
      familyName,
      primaryContactName,
      primaryPhone,
      primaryEmail,
      address,
      city,
      state,
      country,
      postalCode,
      status,
      notes
    } = req.body;

    if (familyName !== undefined) fam.familyName = familyName.trim();
    if (primaryContactName !== undefined) fam.primaryContactName = primaryContactName.trim();
    if (primaryPhone !== undefined) fam.primaryPhone = primaryPhone.trim();
    if (primaryEmail !== undefined) fam.primaryEmail = primaryEmail.trim().toLowerCase();
    if (address !== undefined) fam.address = address.trim();
    if (city !== undefined) fam.city = city.trim();
    if (state !== undefined) fam.state = state.trim();
    if (country !== undefined) fam.country = country.trim();
    if (postalCode !== undefined) fam.postalCode = postalCode.trim();
    if (status !== undefined) fam.status = status;
    if (notes !== undefined) fam.notes = notes;
    fam.updatedAt = new Date().toISOString();

    logAudit({
      userId: req.user!.id,
      userName: req.user!.name,
      userRole: req.user!.role,
      action: 'UPDATE',
      entity: 'GUARDIAN',
      entityType: 'FAMILY',
      entityId: fam.id,
      details: `Updated family household ${fam.familyName}.`,
      ipAddress: req.ip
    });

    res.json({
      success: true,
      message: 'Family household updated successfully.',
      data: enrichFamily(fam)
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * DELETE /api/users/families/:id
 * Remove Family Household and unlink member references
 */
usersRouter.delete('/families/:id', requireAuth, requirePermission('guardians.delete'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { id } = req.params;
    const index = database.families.findIndex((f) => f.id === id);
    if (index === -1) {
      res.status(404).json({ success: false, error: 'Family household record not found.' });
      return;
    }

    const fam = database.families[index];

    // Unlink familyId from guardians
    database.guardians.forEach((g) => {
      if (g.familyId === fam.id) {
        g.familyId = undefined;
      }
    });

    // Unlink familyId from students
    database.studentProfiles.forEach((s) => {
      if (s.familyId === fam.id) {
        s.familyId = undefined;
      }
    });

    database.families.splice(index, 1);

    logAudit({
      userId: req.user!.id,
      userName: req.user!.name,
      userRole: req.user!.role,
      action: 'DELETE',
      entity: 'GUARDIAN',
      entityType: 'FAMILY',
      entityId: fam.id,
      details: `Deleted family household ${fam.familyName}.`,
      ipAddress: req.ip
    });

    res.json({
      success: true,
      message: `Family household ${fam.familyName} deleted successfully.`
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * POST /api/users/families/:id/add-guardian
 * Add a guardian to an existing family
 */
usersRouter.post('/families/:id/add-guardian', requireAuth, requirePermission('guardians.edit'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { id } = req.params;
    const { guardianId } = req.body;

    const fam = database.families.find((f) => f.id === id);
    if (!fam) {
      res.status(404).json({ success: false, error: 'Family household not found.' });
      return;
    }

    const guardian = database.guardians.find((g) => g.id === guardianId);
    if (!guardian) {
      res.status(404).json({ success: false, error: 'Guardian not found.' });
      return;
    }

    if (!fam.guardianIds.includes(guardianId)) {
      fam.guardianIds.push(guardianId);
    }
    guardian.familyId = fam.id;
    fam.updatedAt = new Date().toISOString();

    res.json({
      success: true,
      message: `Guardian ${guardian.name} added to family ${fam.familyName}.`,
      data: enrichFamily(fam)
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * POST /api/users/families/:id/add-student
 * Add a student to an existing family
 */
usersRouter.post('/families/:id/add-student', requireAuth, requirePermission('guardians.edit'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { id } = req.params;
    const { studentId } = req.body;

    const fam = database.families.find((f) => f.id === id);
    if (!fam) {
      res.status(404).json({ success: false, error: 'Family household not found.' });
      return;
    }

    const student = database.studentProfiles.find((s) => s.id === studentId);
    if (!student) {
      res.status(404).json({ success: false, error: 'Student not found.' });
      return;
    }

    if (!fam.studentIds.includes(studentId)) {
      fam.studentIds.push(studentId);
    }
    student.familyId = fam.id;
    fam.updatedAt = new Date().toISOString();

    res.json({
      success: true,
      message: `Student ${student.admissionNumber} added to family ${fam.familyName}.`,
      data: enrichFamily(fam)
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * POST /api/users/families/:id/remove-member
 * Remove a guardian or student member from family
 */
usersRouter.post('/families/:id/remove-member', requireAuth, requirePermission('guardians.edit'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { id } = req.params;
    const { memberType, memberId } = req.body;

    const fam = database.families.find((f) => f.id === id);
    if (!fam) {
      res.status(404).json({ success: false, error: 'Family household not found.' });
      return;
    }

    if (memberType === 'guardian') {
      fam.guardianIds = fam.guardianIds.filter((gid) => gid !== memberId);
      const guardian = database.guardians.find((g) => g.id === memberId);
      if (guardian && guardian.familyId === fam.id) {
        guardian.familyId = undefined;
      }
    } else if (memberType === 'student') {
      fam.studentIds = fam.studentIds.filter((sid) => sid !== memberId);
      const student = database.studentProfiles.find((s) => s.id === memberId);
      if (student && student.familyId === fam.id) {
        student.familyId = undefined;
      }
    }

    fam.updatedAt = new Date().toISOString();

    res.json({
      success: true,
      message: `Member removed from family ${fam.familyName}.`,
      data: enrichFamily(fam)
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * GET /api/users/guardians-integrity-check
 * Run comprehensive parent & family data integrity check with auto-heal option
 */
usersRouter.get('/guardians-integrity-check', requireAuth, requirePermission('guardians.view'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const autoHeal = req.query.autoHeal === 'true';
    const issues: string[] = [];
    let healedCount = 0;

    // 1. Orphan Guardian IDs in Student Profiles
    database.studentProfiles.forEach((st) => {
      if (st.guardianId && !database.guardians.some((g) => g.id === st.guardianId)) {
        issues.push(`Student ${st.admissionNumber} references non-existent guardian ID "${st.guardianId}"`);
        if (autoHeal) {
          st.guardianId = undefined;
          healedCount++;
        }
      }
    });

    // 2. Orphan Student IDs in Guardians
    database.guardians.forEach((g) => {
      const valid = g.studentIds.filter((sid) => database.studentProfiles.some((s) => s.id === sid));
      if (valid.length !== g.studentIds.length) {
        const orphanCount = g.studentIds.length - valid.length;
        issues.push(`Guardian ${g.name} (${g.id}) has ${orphanCount} orphan student ID(s)`);
        if (autoHeal) {
          g.studentIds = valid;
          healedCount++;
        }
      }
    });

    // 3. Ensure Bidirectional ParentStudentRelationship consistency
    database.guardians.forEach((g) => {
      g.studentIds.forEach((sid) => {
        const hasRel = database.parentStudentRelationships.some(
          (r) => r.guardianId === g.id && r.studentId === sid
        );
        if (!hasRel) {
          issues.push(`Missing relationship record for Guardian ${g.name} -> Student ${sid}`);
          if (autoHeal) {
            database.parentStudentRelationships.push({
              id: `rel-auto-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
              guardianId: g.id,
              studentId: sid,
              relationshipType: g.relationship || 'Parent',
              isPrimaryGuardian: true,
              isSecondaryGuardian: false,
              isEmergencyContact: true,
              isAuthorizedAcademic: true,
              isAuthorizedAttendance: true,
              isAuthorizedFinancial: true,
              isAuthorizedCommunication: true,
              isPickupAuthorized: true,
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString()
            });
            healedCount++;
          }
        }
      });
    });

    // 4. Duplicate Primary Guardians for any student
    const studentPrimaryMap: Record<string, string[]> = {};
    database.parentStudentRelationships.forEach((r) => {
      if (r.isPrimaryGuardian) {
        if (!studentPrimaryMap[r.studentId]) studentPrimaryMap[r.studentId] = [];
        studentPrimaryMap[r.studentId].push(r.guardianId);
      }
    });

    Object.entries(studentPrimaryMap).forEach(([studentId, guardIds]) => {
      if (guardIds.length > 1) {
        issues.push(`Student ${studentId} has ${guardIds.length} primary guardians (${guardIds.join(', ')})`);
        if (autoHeal) {
          // Keep the first one primary, demote the rest
          for (let i = 1; i < guardIds.length; i++) {
            const rel = database.parentStudentRelationships.find(
              (r) => r.studentId === studentId && r.guardianId === guardIds[i]
            );
            if (rel) {
              rel.isPrimaryGuardian = false;
              rel.isSecondaryGuardian = true;
              healedCount++;
            }
          }
        }
      }
    });

    res.json({
      success: true,
      healthy: issues.length === 0,
      totalIssues: issues.length,
      issues,
      autoHealed: autoHeal,
      healedCount
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// =========================================================================
// 4. GENERAL DIRECTORY & PROFILE ENDPOINTS
// =========================================================================

/**
 * GET /api/users/directory
 * Unified directory overview and statistics
 */
usersRouter.get('/directory', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const totalTeachers = database.teacherProfiles.length;
    const activeTeachers = database.teacherProfiles.filter((t) => t.status.toLowerCase() === 'active').length;

    const totalStudents = database.studentProfiles.length;
    const activeStudents = database.studentProfiles.filter((s) => s.status.toLowerCase() === 'active').length;

    const totalGuardians = database.guardians.length;
    const multiChildGuardians = database.guardians.filter((g) => g.studentIds && g.studentIds.length > 1).length;

    const totalAdmins = database.users.filter((u) => u.role === 'SUPER_ADMIN').length;

    res.json({
      success: true,
      data: {
        metrics: {
          totalTeachers,
          activeTeachers,
          totalStudents,
          activeStudents,
          totalGuardians,
          multiChildGuardians,
          totalAdmins
        }
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * Helper: Safely resolve Teacher Profile with strict multi-tenant isolation
 */
function resolveTeacherProfile(req: AuthenticatedRequest) {
  const user = req.user!;
  if (!user) return null;
  if (user.role === 'SUPER_ADMIN') {
    // If admin requested a specific teacher via query, resolve that, else fallback to first profile for preview
    const requestedTeacherId = req.query.teacherId as string;
    if (requestedTeacherId) {
      return (
        database.teacherProfiles.find((t) => t.id === requestedTeacherId || t.userId === requestedTeacherId) ||
        database.teacherProfiles[0]
      );
    }
    return database.teacherProfiles[0] || null;
  }
  // For TEACHER role, strictly match user's own userId
  return database.teacherProfiles.find((t) => t.userId === user.id) || null;
}

/**
 * GET /api/users/teachers/my-classes
 * Return teacher's assigned classes with sections, assigned subjects, and student counts
 */
usersRouter.get('/teachers/my-classes', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const teacherProfile = resolveTeacherProfile(req);
    if (!teacherProfile) {
      res.status(404).json({ success: false, error: 'Teacher profile not found for the authenticated user.' });
      return;
    }

    const assignedClassIds = teacherProfile.assignedClassIds || [];
    const activeSession = database.academicSessions.find((s) => s.isActive) || database.academicSessions[0];

    const classesList = database.classes
      .filter((c) => assignedClassIds.includes(c.id))
      .map((cls) => {
        // Teacher's assigned subjects for this class
        const classSubjects = database.subjects
          .filter(
            (s) =>
              (s.teacherId === teacherProfile.id || teacherProfile.assignedSubjectIds?.includes(s.id)) &&
              (s.classId === cls.id || s.classIds?.includes(cls.id))
          )
          .map((s) => ({
            id: s.id,
            name: s.name,
            code: s.code,
            type: s.type,
            credits: s.credits
          }));

        const sections = database.sections
          .filter((s) => s.classId === cls.id)
          .map((sec) => {
            const studentCount = database.studentProfiles.filter((st) => st.sectionId === sec.id).length;
            const isClassTeacher = sec.classTeacherId === teacherProfile.id;
            return {
              ...sec,
              academicSessionName: activeSession?.sessionName || '2026-2027 Academic Year',
              studentCount,
              isClassTeacher,
              subjects: classSubjects
            };
          });

        const totalStudents = database.studentProfiles.filter((st) => st.classId === cls.id).length;

        return {
          ...cls,
          academicSessionName: activeSession?.sessionName || '2026-2027 Academic Year',
          subjects: classSubjects,
          sections,
          totalSections: sections.length,
          totalStudents
        };
      });

    res.json({
      success: true,
      data: classesList
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * GET /api/users/teachers/my-classes/:classId/sections
 * Return assigned sections for a specific class with strict authorization
 */
usersRouter.get('/teachers/my-classes/:classId/sections', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { classId } = req.params;
    const teacherProfile = resolveTeacherProfile(req);
    if (!teacherProfile) {
      res.status(404).json({ success: false, error: 'Teacher profile not found.' });
      return;
    }

    const assignedClassIds = teacherProfile.assignedClassIds || [];
    if (!assignedClassIds.includes(classId)) {
      res.status(403).json({
        success: false,
        error: 'Access denied. You are not authorized to view sections for this class.',
        code: 'FORBIDDEN_CLASS_ACCESS'
      });
      return;
    }

    const targetClass = database.classes.find((c) => c.id === classId);
    if (!targetClass) {
      res.status(404).json({ success: false, error: 'Class not found.' });
      return;
    }

    const activeSession = database.academicSessions.find((s) => s.isActive) || database.academicSessions[0];
    
    // Teacher's assigned subjects for this class
    const classSubjects = database.subjects
      .filter(
        (s) =>
          (s.teacherId === teacherProfile.id || teacherProfile.assignedSubjectIds?.includes(s.id)) &&
          (s.classId === classId || s.classIds?.includes(classId))
      )
      .map((s) => ({
        id: s.id,
        name: s.name,
        code: s.code,
        type: s.type,
        credits: s.credits
      }));

    const sections = database.sections
      .filter((s) => s.classId === classId)
      .map((sec) => {
        const studentCount = database.studentProfiles.filter((st) => st.sectionId === sec.id).length;
        const isClassTeacher = sec.classTeacherId === teacherProfile.id;
        return {
          ...sec,
          className: targetClass.name,
          academicSessionName: activeSession?.sessionName || '2026-2027 Academic Year',
          studentCount,
          isClassTeacher,
          subjects: classSubjects
        };
      });

    res.json({
      success: true,
      data: sections
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * GET /api/users/teachers/my-subjects
 * Return teacher's assigned subjects with curriculum and classes
 */
usersRouter.get('/teachers/my-subjects', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const teacherProfile = resolveTeacherProfile(req);
    if (!teacherProfile) {
      res.status(404).json({ success: false, error: 'Teacher profile not found.' });
      return;
    }

    const assignedSubjectIds = teacherProfile.assignedSubjectIds || [];
    const teacherSubjects = database.subjects.filter(
      (s) => s.teacherId === teacherProfile.id || assignedSubjectIds.includes(s.id)
    ).map((sub) => {
      const dept = database.departments.find((d) => d.id === sub.departmentId);
      const classesForSub = database.classes
        .filter((c) => sub.classId === c.id || sub.classIds?.includes(c.id))
        .map((c) => c.name);

      return {
        ...sub,
        departmentName: dept?.name || 'Academic Department',
        classNames: classesForSub
      };
    });

    res.json({
      success: true,
      data: teacherSubjects
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * GET /api/users/teachers/my-students
 * Teacher-scoped student directory with search, filtering, pagination, and strict permission enforcement
 */
usersRouter.get('/teachers/my-students', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const teacherProfile = resolveTeacherProfile(req);
    if (!teacherProfile) {
      res.status(404).json({ success: false, error: 'Teacher profile not found.' });
      return;
    }
    
    const assignedClassIds = teacherProfile.assignedClassIds || [];
    const { classId, sectionId, status, search, page = '1', limit = '10' } = req.query as {
      classId?: string;
      sectionId?: string;
      status?: string;
      search?: string;
      page?: string;
      limit?: string;
    };

    // STRICT SECURITY: If teacher specifies classId, it MUST be in assignedClassIds
    if (classId && classId !== 'ALL') {
      if (!assignedClassIds.includes(classId)) {
        res.status(403).json({
          success: false,
          error: 'Access denied. You are not authorized to access students from this class.',
          code: 'FORBIDDEN_CLASS_ACCESS'
        });
        return;
      }
    }

    // STRICT SECURITY: If teacher specifies sectionId, that section MUST belong to an assigned class
    if (sectionId && sectionId !== 'ALL') {
      const section = database.sections.find((s) => s.id === sectionId);
      if (!section || !assignedClassIds.includes(section.classId)) {
        res.status(403).json({
          success: false,
          error: 'Access denied. You are not authorized to access students from this section.',
          code: 'FORBIDDEN_SECTION_ACCESS'
        });
        return;
      }
    }

    const activeSession = database.academicSessions.find((s) => s.isActive) || database.academicSessions[0];

    // Filter students strictly within teacher's assigned classes
    let matched = database.studentProfiles.filter((s) => {
      // 1. Authorized class membership (MANDATORY)
      if (!assignedClassIds.includes(s.classId)) return false;

      // 2. Specific Class Filter
      if (classId && classId !== 'ALL' && s.classId !== classId) return false;

      // 3. Specific Section Filter
      if (sectionId && sectionId !== 'ALL' && s.sectionId !== sectionId) return false;

      // 4. Status Filter
      if (status && status !== 'ALL') {
        const studentStatus = (s.status || s.enrollmentStatus || 'active').toLowerCase();
        if (studentStatus !== status.toLowerCase()) return false;
      }

      // 5. Search Filter
      if (search && search.trim()) {
        const q = search.toLowerCase().trim();
        const u = database.users.find((usr) => usr.id === s.userId);
        const fullName = `${s.firstName || ''} ${s.lastName || ''} ${u?.name || ''}`.toLowerCase();
        const adm = (s.admissionNumber || '').toLowerCase();
        const roll = (s.rollNumber || '').toLowerCase();
        const email = (s.email || u?.email || '').toLowerCase();
        const id = (s.id || '').toLowerCase();

        const match =
          fullName.includes(q) ||
          adm.includes(q) ||
          roll.includes(q) ||
          email.includes(q) ||
          id.includes(q);

        if (!match) return false;
      }

      return true;
    });

    // Populate relation data
    const enrichedStudents = matched.map((profile) => {
      const u = database.users.find((usr) => usr.id === profile.userId);
      const cls = database.classes.find((c) => c.id === profile.classId);
      const sec = database.sections.find((s) => s.id === profile.sectionId);
      const nameParts = (u?.name || `${profile.firstName || ''} ${profile.lastName || ''}`.trim() || 'Student Name').split(' ');

      return {
        id: profile.id,
        userId: profile.userId,
        admissionNumber: profile.admissionNumber,
        rollNumber: profile.rollNumber,
        firstName: profile.firstName || nameParts[0],
        lastName: profile.lastName || nameParts.slice(1).join(' ') || 'Student',
        email: profile.email || u?.email || 'student@sygmate.edu',
        avatarUrl: u?.avatarUrl || profile.avatarUrl,
        classId: profile.classId,
        className: cls?.name || 'Class',
        sectionId: profile.sectionId,
        sectionName: sec?.name || 'Section',
        academicSessionId: profile.academicSessionId || activeSession?.id,
        academicSessionName: activeSession?.sessionName || '2026-2027 Academic Year',
        dateOfBirth: profile.dateOfBirth,
        gender: profile.gender,
        bloodGroup: profile.bloodGroup,
        address: profile.address,
        guardianName: profile.guardianName || 'Guardian on File',
        guardianRelation: profile.guardianRelation || 'Parent / Guardian',
        guardianPhone: profile.guardianPhone || 'N/A',
        guardianEmail: profile.guardianEmail || 'N/A',
        enrollmentStatus: profile.enrollmentStatus || 'active',
        status: profile.status || 'active',
        createdAt: profile.createdAt || '2026-02-01T08:00:00.000Z'
      };
    });

    // Sort by class numeric grade, then section, then roll number
    enrichedStudents.sort((a, b) => {
      const clsA = a.className || '';
      const clsB = b.className || '';
      if (clsA !== clsB) return clsA.localeCompare(clsB);
      return (a.rollNumber || '').localeCompare(b.rollNumber || '');
    });

    // Pagination
    const pageNum = Math.max(1, parseInt(page, 10) || 1);
    const limitNum = Math.max(1, parseInt(limit, 10) || 10);
    const total = enrichedStudents.length;
    const totalPages = Math.ceil(total / limitNum) || 1;
    const startIndex = (pageNum - 1) * limitNum;
    const paginatedList = enrichedStudents.slice(startIndex, startIndex + limitNum);

    res.json({
      success: true,
      data: paginatedList,
      pagination: {
        page: pageNum,
        limit: limitNum,
        total,
        totalPages
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * GET /api/users/teachers/my-students/:studentId
 * View individual student's basic profile with strict authorization checking
 */
usersRouter.get('/teachers/my-students/:studentId', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { studentId } = req.params;
    const teacherProfile = resolveTeacherProfile(req);
    if (!teacherProfile) {
      res.status(404).json({ success: false, error: 'Teacher profile not found.' });
      return;
    }

    const assignedClassIds = teacherProfile.assignedClassIds || [];

    // Find student
    const student = database.studentProfiles.find(
      (s) => s.id === studentId || s.userId === studentId || s.admissionNumber === studentId
    );

    if (!student) {
      res.status(404).json({ success: false, error: 'Student record not found.' });
      return;
    }

    // STRICT SECURITY: Check if this student belongs to one of the teacher's assigned classes
    if (!assignedClassIds.includes(student.classId)) {
      res.status(403).json({
        success: false,
        error: 'Access denied. You do not have authorization to view this student because they are not enrolled in your assigned classes.',
        code: 'FORBIDDEN_STUDENT_ACCESS'
      });
      return;
    }

    const u = database.users.find((usr) => usr.id === student.userId);
    const cls = database.classes.find((c) => c.id === student.classId);
    const sec = database.sections.find((s) => s.id === student.sectionId);
    const activeSession = database.academicSessions.find((s) => s.isActive) || database.academicSessions[0];
    const nameParts = (u?.name || `${student.firstName || ''} ${student.lastName || ''}`.trim() || 'Student Name').split(' ');

    const safeStudentProfile = {
      id: student.id,
      userId: student.userId,
      admissionNumber: student.admissionNumber,
      rollNumber: student.rollNumber,
      firstName: student.firstName || nameParts[0],
      lastName: student.lastName || nameParts.slice(1).join(' ') || 'Student',
      email: student.email || u?.email || 'student@sygmate.edu',
      avatarUrl: u?.avatarUrl || student.avatarUrl,
      classId: student.classId,
      className: cls?.name || 'Class',
      sectionId: student.sectionId,
      sectionName: sec?.name || 'Section',
      academicSessionId: student.academicSessionId || activeSession?.id,
      academicSessionName: activeSession?.sessionName || '2026-2027 Academic Year',
      dateOfBirth: student.dateOfBirth,
      gender: student.gender,
      bloodGroup: student.bloodGroup,
      address: student.address,
      guardianName: student.guardianName || 'Guardian on File',
      guardianRelation: student.guardianRelation || 'Parent / Guardian',
      guardianPhone: student.guardianPhone || 'N/A',
      guardianEmail: student.guardianEmail || 'N/A',
      enrollmentStatus: student.enrollmentStatus || 'active',
      status: student.status || 'active',
      enrollmentDate: student.enrollmentDate,
      admissionDate: student.admissionDate
    };

    res.json({
      success: true,
      data: safeStudentProfile
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * GET /api/users/me/profile
 * Get current authenticated user's profile with populated relation objects
 */
usersRouter.get('/me/profile', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    let roleProfile: any = null;

    if (user.role === 'TEACHER') {
      const profile = database.teacherProfiles.find((t) => t.userId === user.id);
      if (profile) {
        const assignedClasses = database.classes.filter((c) => profile.assignedClassIds?.includes(c.id));
        const assignedSubjects = database.subjects.filter((s) => profile.assignedSubjectIds?.includes(s.id) || s.teacherId === profile.id);
        const dept = database.departments.find((d) => d.id === profile.departmentId);

        const nameParts = (user.name || `${profile.firstName || ''} ${profile.lastName || ''}`.trim()).split(' ');
        const firstName = profile.firstName || nameParts[0] || 'Faculty';
        const lastName = profile.lastName || nameParts.slice(1).join(' ') || 'Member';

        roleProfile = {
          ...profile,
          firstName,
          lastName,
          email: profile.email || user.email,
          phone: profile.contactNumber || profile.phone || user.phoneNumber || '',
          contactNumber: profile.contactNumber || profile.phone || user.phoneNumber || '',
          departmentName: dept?.name || profile.department || 'Academic Faculty',
          avatarUrl: profile.avatarUrl || user.avatarUrl,
          assignedClasses,
          assignedSubjects,
          subjects: assignedSubjects.map((s) => s.name)
        };
      }
    } else if (user.role === 'STUDENT') {
      const profile = database.studentProfiles.find((s) => s.userId === user.id || s.id === user.id);
      if (profile) {
        const cls = database.classes.find((c) => c.id === profile.classId);
        const sec = database.sections.find((s) => s.id === profile.sectionId);
        const sess = database.academicSessions.find((s) => s.id === profile.academicSessionId);
        const guardian = database.guardians.find((g) => g.id === profile.guardianId || g.studentIds?.includes(profile.id));

        const nameParts = (user.name || `${profile.firstName || ''} ${profile.lastName || ''}`.trim()).split(' ');
        const firstName = profile.firstName || nameParts[0] || 'Student';
        const lastName = profile.lastName || nameParts.slice(1).join(' ') || '';
        const middleName = profile.middleName || '';
        const fullName = profile.fullName || `${firstName} ${middleName ? middleName + ' ' : ''}${lastName}`.trim();

        // Cross-module Attendance Summary
        const studentAttendanceRecords = database.attendanceRecords.filter(
          (rec) => rec.studentId === profile.id || rec.userId === profile.userId
        );
        const totalDays = studentAttendanceRecords.length;
        const presentDays = studentAttendanceRecords.filter((r) => r.status === 'PRESENT').length;
        const absentDays = studentAttendanceRecords.filter((r) => r.status === 'ABSENT').length;
        const lateDays = studentAttendanceRecords.filter((r) => r.status === 'LATE').length;
        const halfDays = studentAttendanceRecords.filter((r) => r.status === 'HALF_DAY').length;
        const leaveDays = studentAttendanceRecords.filter((r) => r.status === 'LEAVE' || (r.status as any) === 'EXCUSED').length;
        const percentage = totalDays > 0
          ? `${(((presentDays + lateDays * 0.5 + halfDays * 0.5) / totalDays) * 100).toFixed(1)}%`
          : '100.0%';

        // Cross-module Examination Summary
        const studentExamResults = database.examResults.filter(
          (resItem) => resItem.studentId === profile.id || (resItem as any).studentId === profile.userId
        );
        const totalExams = studentExamResults.length;
        let cumulativeGPA = 0;
        if (totalExams > 0) {
          const gpaSum = studentExamResults.reduce((acc, curr) => acc + (curr.summary?.gpa || 0), 0);
          cumulativeGPA = Math.round((gpaSum / totalExams) * 100) / 100;
        }

        // Cross-module Fee Summary
        const studentFeeRecords = database.feeRecords.filter(
          (feeItem) => feeItem.studentId === profile.id || (feeItem as any).studentId === profile.userId
        );
        const totalInvoiced = studentFeeRecords.reduce((acc, curr) => acc + (curr.netPayableAmount ?? curr.totalAmount ?? 0), 0);
        const totalPaid = studentFeeRecords.reduce((acc, curr) => acc + (curr.paidAmount || 0), 0);
        const totalDue = studentFeeRecords.reduce((acc, curr) => acc + (curr.dueAmount || 0), 0);

        roleProfile = {
          ...profile,
          firstName,
          middleName,
          lastName,
          fullName,
          email: profile.email || user.email,
          phone: profile.phone || user.phoneNumber || '',
          phoneNumber: profile.phone || user.phoneNumber || '',
          alternativePhone: profile.alternativePhone || '',
          nationality: profile.nationality || 'United States',
          presentAddress: profile.presentAddress || profile.address || '',
          permanentAddress: profile.permanentAddress || profile.address || '',
          city: profile.city || 'Boston',
          postalCode: profile.postalCode || '02115',
          className: cls?.name || 'Grade 10',
          sectionName: sec?.name || 'Section A',
          academicSessionName: sess?.sessionName || '2026-2027 Academic Year',
          guardianId: guardian?.id || profile.guardianId,
          guardianName: guardian?.name || profile.guardianName || 'Guardian',
          guardianRelation: guardian?.relationship || profile.guardianRelation || 'Parent',
          guardianPhone: guardian?.phone || profile.guardianPhone || '',
          guardianEmail: guardian?.email || profile.guardianEmail || '',
          guardianAddress: guardian?.address || profile.guardianAddress || profile.address || '',
          guardianOccupation: guardian?.occupation || profile.guardianOccupation || '',
          emergencyContact: profile.emergencyContact || guardian?.emergencyContact || guardian?.phone || profile.guardianPhone || '',
          avatarUrl: profile.avatarUrl || user.avatarUrl || '',
          attendanceSummary: {
            totalDays,
            presentDays,
            absentDays,
            lateDays,
            halfDays,
            leaveDays,
            percentage
          },
          examinationSummary: {
            totalExams,
            cumulativeGPA
          },
          feeSummary: {
            totalInvoiced,
            totalPaid,
            totalDue,
            status: totalDue <= 0 ? 'CLEARED' : 'OUTSTANDING'
          }
        };
      }
    }

    res.json({
      success: true,
      data: {
        user: sanitizeUser(user),
        profile: roleProfile
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * PUT /api/users/me/profile
 * Teacher / Student self-service profile update with strict authorization
 * Only non-admin fields (phone, alternative phone, email, emergency contact, present address, avatarUrl) are allowed to be updated.
 */
usersRouter.put('/me/profile', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    const { phone, phoneNumber, contactNumber, alternativePhone, email, emergencyContact, address, presentAddress, avatarUrl } = req.body;

    const resolvedPhone = (phone || phoneNumber || contactNumber || '').trim();
    const resolvedEmail = (email || '').trim().toLowerCase();
    const resolvedEmergency = (emergencyContact || '').trim();
    const resolvedAddress = (presentAddress || address || '').trim();

    if (user.role === 'TEACHER') {
      const teacherIndex = database.teacherProfiles.findIndex((t) => t.userId === user.id);
      if (teacherIndex === -1) {
        res.status(404).json({ success: false, error: 'Teacher profile not found.' });
        return;
      }

      const existingProfile = database.teacherProfiles[teacherIndex];

      // Update Teacher Profile (strictly only allowed fields)
      if (resolvedPhone) {
        existingProfile.phone = resolvedPhone;
        existingProfile.contactNumber = resolvedPhone;
      }
      if (emergencyContact !== undefined) existingProfile.emergencyContact = resolvedEmergency;
      if (address !== undefined || presentAddress !== undefined) existingProfile.address = resolvedAddress;
      if (avatarUrl !== undefined) existingProfile.avatarUrl = avatarUrl;
      existingProfile.updatedAt = new Date().toISOString();

      // Update User account
      const userIndex = database.users.findIndex((u) => u.id === user.id);
      if (userIndex !== -1) {
        if (resolvedPhone) database.users[userIndex].phoneNumber = resolvedPhone;
        if (avatarUrl !== undefined) database.users[userIndex].avatarUrl = avatarUrl;
        database.users[userIndex].updatedAt = new Date().toISOString();
      }

      logAudit({
        userId: user.id,
        userName: user.name,
        userRole: user.role,
        action: 'UPDATE',
        entity: 'TEACHER_PROFILE',
        entityType: 'TEACHER',
        entityId: existingProfile.id,
        details: `Teacher ${user.name} updated self-service profile details and contact information.`,
        ipAddress: req.ip
      });

      const dept = database.departments.find((d) => d.id === existingProfile.departmentId);
      const assignedClasses = database.classes.filter((c) => existingProfile.assignedClassIds?.includes(c.id));
      const assignedSubjects = database.subjects.filter((s) => existingProfile.assignedSubjectIds?.includes(s.id) || s.teacherId === existingProfile.id);

      res.json({
        success: true,
        message: 'Your profile has been successfully updated.',
        data: {
          user: sanitizeUser(database.users[userIndex] || user),
          profile: {
            ...existingProfile,
            departmentName: dept?.name || existingProfile.department,
            assignedClasses,
            assignedSubjects
          }
        }
      });
      return;
    }

    if (user.role === 'STUDENT') {
      const studentIndex = database.studentProfiles.findIndex((s) => s.userId === user.id || s.id === user.id);
      if (studentIndex === -1) {
        res.status(404).json({ success: false, error: 'Student profile not found.' });
        return;
      }

      const existingStudent = database.studentProfiles[studentIndex];
      const userIndex = database.users.findIndex((u) => u.id === user.id);

      // Validate email format and uniqueness if modified
      if (resolvedEmail && resolvedEmail !== (user.email || '').toLowerCase()) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(resolvedEmail)) {
          res.status(400).json({ success: false, error: 'Please provide a valid email address.' });
          return;
        }
        const emailExists = database.users.some((u) => u.id !== user.id && u.email.toLowerCase() === resolvedEmail);
        if (emailExists) {
          res.status(400).json({ success: false, error: 'Email address is already in use by another account.' });
          return;
        }
        existingStudent.email = resolvedEmail;
        if (userIndex !== -1) {
          database.users[userIndex].email = resolvedEmail;
        }
      }

      if (phone !== undefined || phoneNumber !== undefined) {
        existingStudent.phone = resolvedPhone;
        if (userIndex !== -1) {
          database.users[userIndex].phoneNumber = resolvedPhone;
        }
      }

      if (alternativePhone !== undefined) {
        existingStudent.alternativePhone = alternativePhone.trim();
      }

      if (emergencyContact !== undefined) {
        existingStudent.emergencyContact = resolvedEmergency;
      }

      if (address !== undefined || presentAddress !== undefined) {
        existingStudent.address = resolvedAddress;
        existingStudent.presentAddress = resolvedAddress;
      }

      if (avatarUrl !== undefined) {
        // Validate avatarUrl format and size if non-empty
        if (avatarUrl && typeof avatarUrl === 'string' && avatarUrl.startsWith('data:image/')) {
          const validImageMimeRegex = /^data:image\/(jpeg|jpg|png|webp);base64,/i;
          if (!validImageMimeRegex.test(avatarUrl)) {
            res.status(400).json({
              success: false,
              error: 'Invalid image format. Supported formats: JPG, PNG, WEBP.'
            });
            return;
          }
          if (avatarUrl.length > 7 * 1024 * 1024) {
            res.status(400).json({
              success: false,
              error: 'Profile photo exceeds 5MB limit.'
            });
            return;
          }
        }
        existingStudent.avatarUrl = avatarUrl;
        if (userIndex !== -1) {
          database.users[userIndex].avatarUrl = avatarUrl;
        }
      }

      existingStudent.updatedAt = new Date().toISOString();
      if (userIndex !== -1) {
        database.users[userIndex].updatedAt = new Date().toISOString();
      }

      logAudit({
        userId: user.id,
        userName: user.name,
        userRole: user.role,
        action: 'UPDATE',
        entity: 'STUDENT_PROFILE',
        entityType: 'STUDENT',
        entityId: existingStudent.id,
        details: `Student ${user.name} updated self-service profile details (contact, address, photo).`,
        ipAddress: req.ip
      });

      const cls = database.classes.find((c) => c.id === existingStudent.classId);
      const sec = database.sections.find((s) => s.id === existingStudent.sectionId);
      const sess = database.academicSessions.find((s) => s.id === existingStudent.academicSessionId);
      const guardian = database.guardians.find((g) => g.id === existingStudent.guardianId || g.studentIds?.includes(existingStudent.id));

      const updatedUser = database.users[userIndex] || user;
      const nameParts = (updatedUser.name || `${existingStudent.firstName || ''} ${existingStudent.lastName || ''}`.trim()).split(' ');

      const populatedProfile = {
        ...existingStudent,
        firstName: existingStudent.firstName || nameParts[0] || 'Student',
        lastName: existingStudent.lastName || nameParts.slice(1).join(' ') || '',
        email: existingStudent.email || updatedUser.email,
        phone: existingStudent.phone || updatedUser.phoneNumber || '',
        phoneNumber: existingStudent.phone || updatedUser.phoneNumber || '',
        className: cls?.name || 'Class',
        sectionName: sec?.name || 'Section',
        academicSessionName: sess?.sessionName || 'Academic Session',
        guardianId: guardian?.id || existingStudent.guardianId,
        guardianName: guardian?.name || existingStudent.guardianName || 'Guardian',
        guardianRelation: guardian?.relationship || existingStudent.guardianRelation || 'Parent',
        guardianPhone: guardian?.phone || existingStudent.guardianPhone || '',
        guardianEmail: guardian?.email || existingStudent.guardianEmail || '',
        guardianAddress: guardian?.address || existingStudent.guardianAddress || existingStudent.address || '',
        guardianOccupation: guardian?.occupation || existingStudent.guardianOccupation || '',
        emergencyContact: existingStudent.emergencyContact || guardian?.emergencyContact || guardian?.phone || existingStudent.guardianPhone || '',
        avatarUrl: existingStudent.avatarUrl || updatedUser.avatarUrl || ''
      };

      res.json({
        success: true,
        message: 'Your profile has been successfully updated.',
        data: {
          user: sanitizeUser(updatedUser),
          profile: populatedProfile
        }
      });
      return;
    }

    res.status(400).json({ success: false, error: 'Profile self-service update not applicable for this role.' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});
