import { Router, Response } from 'express';
import { database } from '../db/database.js';
import { requireAuth, requirePermission, AuthenticatedRequest } from '../security/auth.js';
import { logAudit } from '../security/audit.js';
import {
  Homework,
  Assignment,
  StudyMaterial,
  ClassAnnouncement
} from '../../src/types/index.js';
import { AnnouncementService } from '../services/announcement.service.js';

export const teacherActivitiesRouter = Router();

/**
 * Helper: Resolve Teacher Profile and Authorization Context
 */
function getTeacherAuthContext(req: AuthenticatedRequest) {
  const user = req.user!;
  if (user.role === 'SUPER_ADMIN') {
    return {
      isAdmin: true,
      teacherProfile: null,
      teacherId: 'super-admin',
      teacherName: user.name,
      teacherUserId: user.id,
      assignedClassIds: database.classes.map((c) => c.id),
      assignedSubjectIds: database.subjects.map((s) => s.id)
    };
  }

  const teacherProfile = database.teacherProfiles.find((t) => t.userId === user.id);
  const assignedClassIds = new Set<string>(teacherProfile?.assignedClassIds || []);
  const assignedSubjectIds = new Set<string>(teacherProfile?.assignedSubjectIds || []);

  // Also include classes where teacher is assigned as class teacher on sections
  database.sections.forEach((sec) => {
    if (sec.classTeacherId === teacherProfile?.id && sec.classId) {
      assignedClassIds.add(sec.classId);
    }
  });

  // Also include subjects where subject.teacherId === teacherProfile.id
  database.subjects.forEach((subj) => {
    if (subj.teacherId === teacherProfile?.id) {
      assignedSubjectIds.add(subj.id);
      if (subj.classId) assignedClassIds.add(subj.classId);
      if (subj.classIds) subj.classIds.forEach((cid) => assignedClassIds.add(cid));
    }
  });

  return {
    isAdmin: false,
    teacherProfile,
    teacherId: teacherProfile?.id || '',
    teacherName: user.name,
    teacherUserId: user.id,
    assignedClassIds: Array.from(assignedClassIds),
    assignedSubjectIds: Array.from(assignedSubjectIds)
  };
}

/**
 * File Validation Config & Helper
 */
const ALLOWED_EXTENSIONS = ['pdf', 'doc', 'docx', 'ppt', 'pptx', 'xls', 'xlsx', 'txt', 'png', 'jpg', 'jpeg', 'zip'];
const MAX_FILE_SIZE_BYTES = 15 * 1024 * 1024; // 15MB

function formatBytes(bytes: number, decimals = 1): string {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

// =========================================================================
// 0. SECURE FILE VALIDATION & SIMULATED UPLOAD ENDPOINT
// =========================================================================
teacherActivitiesRouter.post('/upload-file', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { fileName, fileSizeBytes, fileData, fileType } = req.body as {
      fileName: string;
      fileSizeBytes: number;
      fileData?: string;
      fileType?: string;
    };

    if (!fileName || !fileName.trim()) {
      res.status(400).json({ success: false, error: 'File name is required.' });
      return;
    }

    const ext = fileName.split('.').pop()?.toLowerCase() || '';
    if (!ALLOWED_EXTENSIONS.includes(ext)) {
      res.status(400).json({
        success: false,
        error: `Unsupported file type .${ext}. Allowed formats: ${ALLOWED_EXTENSIONS.join(', ')}`
      });
      return;
    }

    const size = Number(fileSizeBytes) || 0;
    if (size > MAX_FILE_SIZE_BYTES) {
      res.status(400).json({
        success: false,
        error: `File exceeds maximum allowed size of 15MB (Attempted: ${formatBytes(size)}).`
      });
      return;
    }

    // Sanitize filename
    const sanitizedName = fileName.replace(/[^a-zA-Z0-9._-]/g, '_');
    const safeUrl = fileData && fileData.startsWith('data:')
      ? fileData
      : `https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?auto=format&fit=crop&q=80&w=800`;

    res.json({
      success: true,
      data: {
        fileUrl: safeUrl,
        fileName: sanitizedName,
        fileSize: formatBytes(size > 0 ? size : 1024 * 512),
        fileSizeBytes: size > 0 ? size : 1024 * 512,
        fileType: ext
      }
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message || 'File upload processing failed.' });
  }
});

// =========================================================================
// SUMMARY METRICS FOR TEACHER DASHBOARD
// =========================================================================
teacherActivitiesRouter.get('/summary', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { isAdmin, teacherId, assignedClassIds } = getTeacherAuthContext(req);

    if (!database.homework) database.homework = [];
    if (!database.assignments) database.assignments = [];
    if (!database.studyMaterials) database.studyMaterials = [];
    if (!database.classAnnouncements) database.classAnnouncements = [];

    const hw = isAdmin
      ? database.homework
      : database.homework.filter((h) => h.teacherId === teacherId || assignedClassIds.includes(h.classId));

    const asg = isAdmin
      ? database.assignments
      : database.assignments.filter((a) => a.teacherId === teacherId || assignedClassIds.includes(a.classId));

    const mat = isAdmin
      ? database.studyMaterials
      : database.studyMaterials.filter((m) => m.teacherId === teacherId || assignedClassIds.includes(m.classId));

    const ann = isAdmin
      ? database.classAnnouncements
      : database.classAnnouncements.filter((a) => a.teacherId === teacherId || assignedClassIds.includes(a.classId));

    res.json({
      success: true,
      data: {
        totalHomework: hw.length,
        publishedHomework: hw.filter((h) => h.status === 'published').length,
        draftHomework: hw.filter((h) => h.status === 'draft').length,
        totalAssignments: asg.length,
        activeAssignments: asg.filter((a) => a.status === 'published').length,
        closedAssignments: asg.filter((a) => a.status === 'closed' || a.status === 'archived').length,
        totalMaterials: mat.length,
        activeMaterials: mat.filter((m) => m.status === 'active').length,
        totalAnnouncements: ann.length,
        highPriorityAnnouncements: ann.filter((a) => a.priority === 'high' || a.priority === 'urgent').length
      }
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// =========================================================================
// 1. HOMEWORK CRUD
// =========================================================================

// List Homework with Search & Filters
teacherActivitiesRouter.get('/homework', requireAuth, requirePermission('homework.view'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { isAdmin, teacherId, assignedClassIds } = getTeacherAuthContext(req);
    const { classId, sectionId, subjectId, status, dueDate, search, page = '1', limit = '50' } = req.query as Record<string, string>;

    if (!database.homework) database.homework = [];
    let list = database.homework;

    // SECURITY: Scope to authorized classes or teacher ownership
    if (!isAdmin) {
      list = list.filter((h) => h.teacherId === teacherId || assignedClassIds.includes(h.classId));
    }

    // Apply Filters
    if (classId && classId !== 'ALL') {
      list = list.filter((h) => h.classId === classId);
    }
    if (sectionId && sectionId !== 'ALL') {
      list = list.filter((h) => h.sectionId === sectionId || h.sectionId === 'ALL');
    }
    if (subjectId && subjectId !== 'ALL') {
      list = list.filter((h) => h.subjectId === subjectId);
    }
    if (status && status !== 'ALL') {
      list = list.filter((h) => h.status === status);
    }
    if (dueDate) {
      list = list.filter((h) => h.dueDate === dueDate);
    }
    if (search && search.trim()) {
      const q = search.toLowerCase().trim();
      list = list.filter(
        (h) =>
          h.title.toLowerCase().includes(q) ||
          h.description.toLowerCase().includes(q) ||
          h.subjectName.toLowerCase().includes(q) ||
          h.className.toLowerCase().includes(q) ||
          h.sectionName.toLowerCase().includes(q)
      );
    }

    // Sort by Due Date descending, then created date
    list.sort((a, b) => new Date(b.dueDate).getTime() - new Date(a.dueDate).getTime());

    const pageNum = Math.max(1, parseInt(page, 10) || 1);
    const limitNum = Math.max(1, parseInt(limit, 10) || 50);
    const total = list.length;
    const totalPages = Math.ceil(total / limitNum) || 1;
    const paginated = list.slice((pageNum - 1) * limitNum, pageNum * limitNum);

    res.json({
      success: true,
      data: paginated,
      pagination: {
        page: pageNum,
        limit: limitNum,
        total,
        totalPages
      }
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Get Homework by ID
teacherActivitiesRouter.get('/homework/:id', requireAuth, requirePermission('homework.view'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { id } = req.params;
    const { isAdmin, teacherId, assignedClassIds } = getTeacherAuthContext(req);

    if (!database.homework) database.homework = [];
    const item = database.homework.find((h) => h.id === id);

    if (!item) {
      res.status(404).json({ success: false, error: 'Homework record not found.' });
      return;
    }

    // Security check
    if (!isAdmin && item.teacherId !== teacherId && !assignedClassIds.includes(item.classId)) {
      res.status(403).json({ success: false, error: 'Access denied: You are not authorized to view this homework.' });
      return;
    }

    res.json({ success: true, data: item });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Create Homework
teacherActivitiesRouter.post('/homework', requireAuth, requirePermission('homework.create'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { isAdmin, teacherId, teacherName, teacherUserId, assignedClassIds, assignedSubjectIds } = getTeacherAuthContext(req);
    const {
      title,
      description,
      classId,
      sectionId,
      subjectId,
      dueDate,
      assignedDate,
      attachmentUrl,
      attachmentName,
      attachmentSize,
      attachmentType,
      status = 'published'
    } = req.body;

    if (!title || !title.trim()) {
      res.status(400).json({ success: false, error: 'Homework title is required.' });
      return;
    }
    if (!classId) {
      res.status(400).json({ success: false, error: 'Target Class is required.' });
      return;
    }
    if (!sectionId) {
      res.status(400).json({ success: false, error: 'Target Section is required.' });
      return;
    }
    if (!subjectId) {
      res.status(400).json({ success: false, error: 'Target Subject is required.' });
      return;
    }
    if (!dueDate) {
      res.status(400).json({ success: false, error: 'Due date is required.' });
      return;
    }

    // SECURITY: Validate Teacher Class Assignment
    if (!isAdmin && !assignedClassIds.includes(classId)) {
      res.status(403).json({
        success: false,
        error: 'Authorization violation: You are not assigned to create homework for this class.'
      });
      return;
    }

    // SECURITY: Validate Subject Assignment (if teacher is assigned to specific subjects)
    if (!isAdmin && assignedSubjectIds.length > 0 && !assignedSubjectIds.includes(subjectId)) {
      res.status(403).json({
        success: false,
        error: 'Authorization violation: You are not assigned to teach this subject.'
      });
      return;
    }

    // Resolve Names
    const cls = database.classes.find((c) => c.id === classId);
    const sec = database.sections.find((s) => s.id === sectionId);
    const subj = database.subjects.find((s) => s.id === subjectId);
    const activeSession = database.academicSessions.find((s) => s.isActive) || database.academicSessions[0];

    const newHomework: Homework = {
      id: `hw-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      title: title.trim(),
      description: (description || '').trim(),
      classId,
      className: cls?.name || 'Class',
      sectionId,
      sectionName: sec?.name || 'Section',
      subjectId,
      subjectName: subj?.name || 'Subject',
      academicSessionId: activeSession?.id,
      academicSessionName: activeSession?.sessionName,
      dueDate,
      assignedDate: assignedDate || new Date().toISOString().split('T')[0],
      attachmentUrl: attachmentUrl || undefined,
      attachmentName: attachmentName || undefined,
      attachmentSize: attachmentSize || undefined,
      attachmentType: attachmentType || undefined,
      status: status || 'published',
      teacherId: teacherId || 'teacher-prof-1',
      teacherUserId,
      teacherName,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    if (!database.homework) database.homework = [];
    database.homework.unshift(newHomework);

    logAudit({
      userId: req.user!.id,
      userRole: req.user!.role,
      action: 'HOMEWORK_CREATE',
      entity: 'Homework',
      entityType: 'Homework',
      entityId: newHomework.id,
      details: `Created homework '${newHomework.title}' for ${newHomework.className} (${newHomework.sectionName}) - ${newHomework.subjectName}`,
      ipAddress: req.ip || '127.0.0.1'
    });

    res.status(201).json({
      success: true,
      data: newHomework,
      message: 'Homework created and assigned successfully.'
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Update Homework
teacherActivitiesRouter.put('/homework/:id', requireAuth, requirePermission('homework.edit'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { id } = req.params;
    const { isAdmin, teacherId, assignedClassIds } = getTeacherAuthContext(req);

    if (!database.homework) database.homework = [];
    const index = database.homework.findIndex((h) => h.id === id);

    if (index === -1) {
      res.status(404).json({ success: false, error: 'Homework not found.' });
      return;
    }

    const current = database.homework[index];

    // SECURITY: Only author or Super Admin can edit
    if (!isAdmin && current.teacherId !== teacherId && !assignedClassIds.includes(current.classId)) {
      res.status(403).json({ success: false, error: 'Authorization error: You do not have permission to modify this homework.' });
      return;
    }

    const {
      title,
      description,
      classId,
      sectionId,
      subjectId,
      dueDate,
      assignedDate,
      attachmentUrl,
      attachmentName,
      attachmentSize,
      attachmentType,
      status
    } = req.body;

    if (classId && classId !== current.classId && !isAdmin && !assignedClassIds.includes(classId)) {
      res.status(403).json({ success: false, error: 'Cannot reassign homework to an unauthorized class.' });
      return;
    }

    const cls = classId ? database.classes.find((c) => c.id === classId) : null;
    const sec = sectionId ? database.sections.find((s) => s.id === sectionId) : null;
    const subj = subjectId ? database.subjects.find((s) => s.id === subjectId) : null;

    const updated: Homework = {
      ...current,
      title: title !== undefined ? title.trim() : current.title,
      description: description !== undefined ? description.trim() : current.description,
      classId: classId || current.classId,
      className: cls?.name || current.className,
      sectionId: sectionId || current.sectionId,
      sectionName: sec?.name || current.sectionName,
      subjectId: subjectId || current.subjectId,
      subjectName: subj?.name || current.subjectName,
      dueDate: dueDate || current.dueDate,
      assignedDate: assignedDate || current.assignedDate,
      attachmentUrl: attachmentUrl !== undefined ? attachmentUrl : current.attachmentUrl,
      attachmentName: attachmentName !== undefined ? attachmentName : current.attachmentName,
      attachmentSize: attachmentSize !== undefined ? attachmentSize : current.attachmentSize,
      attachmentType: attachmentType !== undefined ? attachmentType : current.attachmentType,
      status: status || current.status,
      updatedAt: new Date().toISOString()
    };

    database.homework[index] = updated;

    logAudit({
      userId: req.user!.id,
      userRole: req.user!.role,
      action: 'HOMEWORK_UPDATE',
      entity: 'Homework',
      entityType: 'Homework',
      entityId: id,
      details: `Updated homework '${updated.title}' (${updated.className})`,
      ipAddress: req.ip || '127.0.0.1'
    });

    res.json({
      success: true,
      data: updated,
      message: 'Homework updated successfully.'
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Delete or Archive Homework
teacherActivitiesRouter.delete('/homework/:id', requireAuth, requirePermission('homework.delete'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { id } = req.params;
    const { isAdmin, teacherId, assignedClassIds } = getTeacherAuthContext(req);

    if (!database.homework) database.homework = [];
    const index = database.homework.findIndex((h) => h.id === id);

    if (index === -1) {
      res.status(404).json({ success: false, error: 'Homework not found.' });
      return;
    }

    const current = database.homework[index];
    if (!isAdmin && current.teacherId !== teacherId && !assignedClassIds.includes(current.classId)) {
      res.status(403).json({ success: false, error: 'Access denied: You cannot delete this homework.' });
      return;
    }

    database.homework.splice(index, 1);

    logAudit({
      userId: req.user!.id,
      userRole: req.user!.role,
      action: 'HOMEWORK_DELETE',
      entity: 'Homework',
      entityType: 'Homework',
      entityId: id,
      details: `Deleted homework '${current.title}' (${current.className})`,
      ipAddress: req.ip || '127.0.0.1'
    });

    res.json({ success: true, message: `Homework '${current.title}' deleted successfully.` });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// =========================================================================
// 2. ASSIGNMENTS CRUD
// =========================================================================

// List Assignments
teacherActivitiesRouter.get('/assignments', requireAuth, requirePermission('assignments.view'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { isAdmin, teacherId, assignedClassIds } = getTeacherAuthContext(req);
    const { classId, sectionId, subjectId, status, startDate, dueDate, search, page = '1', limit = '50' } = req.query as Record<string, string>;

    if (!database.assignments) database.assignments = [];
    let list = database.assignments;

    // SECURITY: Scope to authorized classes or author
    if (!isAdmin) {
      list = list.filter((a) => a.teacherId === teacherId || assignedClassIds.includes(a.classId));
    }

    // Apply Filters
    if (classId && classId !== 'ALL') {
      list = list.filter((a) => a.classId === classId);
    }
    if (sectionId && sectionId !== 'ALL') {
      list = list.filter((a) => a.sectionId === sectionId || a.sectionId === 'ALL');
    }
    if (subjectId && subjectId !== 'ALL') {
      list = list.filter((a) => a.subjectId === subjectId);
    }
    if (status && status !== 'ALL') {
      list = list.filter((a) => a.status === status);
    }
    if (startDate) {
      list = list.filter((a) => a.startDate >= startDate);
    }
    if (dueDate) {
      list = list.filter((a) => a.dueDate <= dueDate);
    }
    if (search && search.trim()) {
      const q = search.toLowerCase().trim();
      list = list.filter(
        (a) =>
          a.title.toLowerCase().includes(q) ||
          a.description.toLowerCase().includes(q) ||
          a.subjectName.toLowerCase().includes(q) ||
          a.className.toLowerCase().includes(q) ||
          a.sectionName.toLowerCase().includes(q)
      );
    }

    // Sort by Due Date descending
    list.sort((a, b) => new Date(b.dueDate).getTime() - new Date(a.dueDate).getTime());

    const pageNum = Math.max(1, parseInt(page, 10) || 1);
    const limitNum = Math.max(1, parseInt(limit, 10) || 50);
    const total = list.length;
    const totalPages = Math.ceil(total / limitNum) || 1;
    const paginated = list.slice((pageNum - 1) * limitNum, pageNum * limitNum);

    res.json({
      success: true,
      data: paginated,
      pagination: {
        page: pageNum,
        limit: limitNum,
        total,
        totalPages
      }
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Get Assignment by ID
teacherActivitiesRouter.get('/assignments/:id', requireAuth, requirePermission('assignments.view'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { id } = req.params;
    const { isAdmin, teacherId, assignedClassIds } = getTeacherAuthContext(req);

    if (!database.assignments) database.assignments = [];
    const item = database.assignments.find((a) => a.id === id);

    if (!item) {
      res.status(404).json({ success: false, error: 'Assignment not found.' });
      return;
    }

    if (!isAdmin && item.teacherId !== teacherId && !assignedClassIds.includes(item.classId)) {
      res.status(403).json({ success: false, error: 'Access denied: You are not authorized to view this assignment.' });
      return;
    }

    res.json({ success: true, data: item });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Create Assignment
teacherActivitiesRouter.post('/assignments', requireAuth, requirePermission('assignments.create'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { isAdmin, teacherId, teacherName, teacherUserId, assignedClassIds, assignedSubjectIds } = getTeacherAuthContext(req);
    const {
      title,
      description,
      subjectId,
      classId,
      sectionId,
      startDate,
      dueDate,
      totalMarks,
      attachmentUrl,
      attachmentName,
      attachmentSize,
      attachmentType,
      status = 'published'
    } = req.body;

    if (!title || !title.trim()) {
      res.status(400).json({ success: false, error: 'Assignment title is required.' });
      return;
    }
    if (!classId) {
      res.status(400).json({ success: false, error: 'Target Class is required.' });
      return;
    }
    if (!sectionId) {
      res.status(400).json({ success: false, error: 'Target Section is required.' });
      return;
    }
    if (!subjectId) {
      res.status(400).json({ success: false, error: 'Target Subject is required.' });
      return;
    }
    if (!dueDate) {
      res.status(400).json({ success: false, error: 'Due date is required.' });
      return;
    }

    // SECURITY: Validate Teacher Class Assignment
    if (!isAdmin && !assignedClassIds.includes(classId)) {
      res.status(403).json({
        success: false,
        error: 'Authorization violation: You are not assigned to create assignments for this class.'
      });
      return;
    }

    if (!isAdmin && assignedSubjectIds.length > 0 && !assignedSubjectIds.includes(subjectId)) {
      res.status(403).json({
        success: false,
        error: 'Authorization violation: You are not assigned to teach this subject.'
      });
      return;
    }

    const cls = database.classes.find((c) => c.id === classId);
    const sec = database.sections.find((s) => s.id === sectionId);
    const subj = database.subjects.find((s) => s.id === subjectId);
    const activeSession = database.academicSessions.find((s) => s.isActive) || database.academicSessions[0];

    const newAssignment: Assignment = {
      id: `assign-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      title: title.trim(),
      description: (description || '').trim(),
      subjectId,
      subjectName: subj?.name || 'Subject',
      classId,
      className: cls?.name || 'Class',
      sectionId,
      sectionName: sec?.name || 'Section',
      academicSessionId: activeSession?.id,
      academicSessionName: activeSession?.sessionName,
      startDate: startDate || new Date().toISOString().split('T')[0],
      dueDate,
      totalMarks: Number(totalMarks) || 100,
      attachmentUrl: attachmentUrl || undefined,
      attachmentName: attachmentName || undefined,
      attachmentSize: attachmentSize || undefined,
      attachmentType: attachmentType || undefined,
      status: status || 'published',
      teacherId: teacherId || 'teacher-prof-1',
      teacherUserId,
      teacherName,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    if (!database.assignments) database.assignments = [];
    database.assignments.unshift(newAssignment);

    logAudit({
      userId: req.user!.id,
      userRole: req.user!.role,
      action: 'ASSIGNMENT_CREATE',
      entity: 'Assignment',
      entityType: 'Assignment',
      entityId: newAssignment.id,
      details: `Created assignment '${newAssignment.title}' for ${newAssignment.className} (${newAssignment.sectionName}) - ${newAssignment.subjectName}`,
      ipAddress: req.ip || '127.0.0.1'
    });

    res.status(201).json({
      success: true,
      data: newAssignment,
      message: 'Assignment created successfully.'
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Update Assignment
teacherActivitiesRouter.put('/assignments/:id', requireAuth, requirePermission('assignments.edit'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { id } = req.params;
    const { isAdmin, teacherId, assignedClassIds } = getTeacherAuthContext(req);

    if (!database.assignments) database.assignments = [];
    const index = database.assignments.findIndex((a) => a.id === id);

    if (index === -1) {
      res.status(404).json({ success: false, error: 'Assignment not found.' });
      return;
    }

    const current = database.assignments[index];
    if (!isAdmin && current.teacherId !== teacherId && !assignedClassIds.includes(current.classId)) {
      res.status(403).json({ success: false, error: 'Authorization error: You do not have permission to modify this assignment.' });
      return;
    }

    const {
      title,
      description,
      subjectId,
      classId,
      sectionId,
      startDate,
      dueDate,
      totalMarks,
      attachmentUrl,
      attachmentName,
      attachmentSize,
      attachmentType,
      status
    } = req.body;

    if (classId && classId !== current.classId && !isAdmin && !assignedClassIds.includes(classId)) {
      res.status(403).json({ success: false, error: 'Cannot reassign assignment to an unauthorized class.' });
      return;
    }

    const cls = classId ? database.classes.find((c) => c.id === classId) : null;
    const sec = sectionId ? database.sections.find((s) => s.id === sectionId) : null;
    const subj = subjectId ? database.subjects.find((s) => s.id === subjectId) : null;

    const updated: Assignment = {
      ...current,
      title: title !== undefined ? title.trim() : current.title,
      description: description !== undefined ? description.trim() : current.description,
      subjectId: subjectId || current.subjectId,
      subjectName: subj?.name || current.subjectName,
      classId: classId || current.classId,
      className: cls?.name || current.className,
      sectionId: sectionId || current.sectionId,
      sectionName: sec?.name || current.sectionName,
      startDate: startDate || current.startDate,
      dueDate: dueDate || current.dueDate,
      totalMarks: totalMarks !== undefined ? Number(totalMarks) : current.totalMarks,
      attachmentUrl: attachmentUrl !== undefined ? attachmentUrl : current.attachmentUrl,
      attachmentName: attachmentName !== undefined ? attachmentName : current.attachmentName,
      attachmentSize: attachmentSize !== undefined ? attachmentSize : current.attachmentSize,
      attachmentType: attachmentType !== undefined ? attachmentType : current.attachmentType,
      status: status || current.status,
      updatedAt: new Date().toISOString()
    };

    database.assignments[index] = updated;

    logAudit({
      userId: req.user!.id,
      userRole: req.user!.role,
      action: 'ASSIGNMENT_UPDATE',
      entity: 'Assignment',
      entityType: 'Assignment',
      entityId: id,
      details: `Updated assignment '${updated.title}' (${updated.className})`,
      ipAddress: req.ip || '127.0.0.1'
    });

    res.json({
      success: true,
      data: updated,
      message: 'Assignment updated successfully.'
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Delete Assignment
teacherActivitiesRouter.delete('/assignments/:id', requireAuth, requirePermission('assignments.delete'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { id } = req.params;
    const { isAdmin, teacherId, assignedClassIds } = getTeacherAuthContext(req);

    if (!database.assignments) database.assignments = [];
    const index = database.assignments.findIndex((a) => a.id === id);

    if (index === -1) {
      res.status(404).json({ success: false, error: 'Assignment not found.' });
      return;
    }

    const current = database.assignments[index];
    if (!isAdmin && current.teacherId !== teacherId && !assignedClassIds.includes(current.classId)) {
      res.status(403).json({ success: false, error: 'Access denied: You cannot delete this assignment.' });
      return;
    }

    database.assignments.splice(index, 1);

    logAudit({
      userId: req.user!.id,
      userRole: req.user!.role,
      action: 'ASSIGNMENT_DELETE',
      entity: 'Assignment',
      entityType: 'Assignment',
      entityId: id,
      details: `Deleted assignment '${current.title}' (${current.className})`,
      ipAddress: req.ip || '127.0.0.1'
    });

    res.json({ success: true, message: `Assignment '${current.title}' deleted successfully.` });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// =========================================================================
// 3. STUDY MATERIALS CRUD
// =========================================================================

// List Study Materials
teacherActivitiesRouter.get('/materials', requireAuth, requirePermission('materials.view'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { isAdmin, teacherId, assignedClassIds } = getTeacherAuthContext(req);
    const { classId, sectionId, subjectId, fileType, status, search, page = '1', limit = '50' } = req.query as Record<string, string>;

    if (!database.studyMaterials) database.studyMaterials = [];
    let list = database.studyMaterials;

    if (!isAdmin) {
      list = list.filter((m) => m.teacherId === teacherId || assignedClassIds.includes(m.classId));
    }

    if (classId && classId !== 'ALL') {
      list = list.filter((m) => m.classId === classId);
    }
    if (sectionId && sectionId !== 'ALL') {
      list = list.filter((m) => m.sectionId === sectionId || m.sectionId === 'ALL');
    }
    if (subjectId && subjectId !== 'ALL') {
      list = list.filter((m) => m.subjectId === subjectId);
    }
    if (fileType && fileType !== 'ALL') {
      list = list.filter((m) => m.fileType.toLowerCase() === fileType.toLowerCase());
    }
    if (status && status !== 'ALL') {
      list = list.filter((m) => m.status === status);
    }
    if (search && search.trim()) {
      const q = search.toLowerCase().trim();
      list = list.filter(
        (m) =>
          m.title.toLowerCase().includes(q) ||
          m.description.toLowerCase().includes(q) ||
          m.fileName.toLowerCase().includes(q) ||
          m.subjectName.toLowerCase().includes(q) ||
          m.className.toLowerCase().includes(q)
      );
    }

    list.sort((a, b) => new Date(b.uploadDate).getTime() - new Date(a.uploadDate).getTime());

    const pageNum = Math.max(1, parseInt(page, 10) || 1);
    const limitNum = Math.max(1, parseInt(limit, 10) || 50);
    const total = list.length;
    const totalPages = Math.ceil(total / limitNum) || 1;
    const paginated = list.slice((pageNum - 1) * limitNum, pageNum * limitNum);

    res.json({
      success: true,
      data: paginated,
      pagination: {
        page: pageNum,
        limit: limitNum,
        total,
        totalPages
      }
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Create Study Material
teacherActivitiesRouter.post('/materials', requireAuth, requirePermission('materials.create'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { isAdmin, teacherId, teacherName, teacherUserId, assignedClassIds, assignedSubjectIds } = getTeacherAuthContext(req);
    const {
      title,
      description,
      subjectId,
      classId,
      sectionId = 'ALL',
      fileUrl,
      fileName,
      fileSize,
      fileSizeBytes,
      fileType,
      status = 'active'
    } = req.body;

    if (!title || !title.trim()) {
      res.status(400).json({ success: false, error: 'Material title is required.' });
      return;
    }
    if (!classId) {
      res.status(400).json({ success: false, error: 'Target Class is required.' });
      return;
    }
    if (!subjectId) {
      res.status(400).json({ success: false, error: 'Subject is required.' });
      return;
    }
    if (!fileName) {
      res.status(400).json({ success: false, error: 'File attachment is required for study materials.' });
      return;
    }

    if (!isAdmin && !assignedClassIds.includes(classId)) {
      res.status(403).json({
        success: false,
        error: 'Authorization violation: You are not assigned to share materials with this class.'
      });
      return;
    }

    if (!isAdmin && assignedSubjectIds.length > 0 && !assignedSubjectIds.includes(subjectId)) {
      res.status(403).json({
        success: false,
        error: 'Authorization violation: You are not assigned to teach this subject.'
      });
      return;
    }

    const cls = database.classes.find((c) => c.id === classId);
    const sec = sectionId !== 'ALL' ? database.sections.find((s) => s.id === sectionId) : null;
    const subj = database.subjects.find((s) => s.id === subjectId);
    const activeSession = database.academicSessions.find((s) => s.isActive) || database.academicSessions[0];

    const detectedExt = fileName.split('.').pop()?.toLowerCase() || 'pdf';

    const newMaterial: StudyMaterial = {
      id: `mat-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      title: title.trim(),
      description: (description || '').trim(),
      subjectId,
      subjectName: subj?.name || 'Subject',
      classId,
      className: cls?.name || 'Class',
      sectionId: sectionId || 'ALL',
      sectionName: sec?.name || 'All Sections',
      academicSessionId: activeSession?.id,
      academicSessionName: activeSession?.sessionName,
      fileUrl: fileUrl || 'https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?auto=format&fit=crop&q=80&w=800',
      fileName: fileName.trim(),
      fileSize: fileSize || '2.0 MB',
      fileSizeBytes: fileSizeBytes || 2097152,
      fileType: fileType || detectedExt,
      uploadDate: new Date().toISOString().split('T')[0],
      status: status || 'active',
      teacherId: teacherId || 'teacher-prof-1',
      teacherUserId,
      teacherName,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    if (!database.studyMaterials) database.studyMaterials = [];
    database.studyMaterials.unshift(newMaterial);

    logAudit({
      userId: req.user!.id,
      userRole: req.user!.role,
      action: 'MATERIAL_UPLOAD',
      entity: 'StudyMaterial',
      entityType: 'StudyMaterial',
      entityId: newMaterial.id,
      details: `Uploaded study material '${newMaterial.title}' (${newMaterial.fileName}) for ${newMaterial.className}`,
      ipAddress: req.ip || '127.0.0.1'
    });

    res.status(201).json({
      success: true,
      data: newMaterial,
      message: 'Study material uploaded successfully.'
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Update Study Material
teacherActivitiesRouter.put('/materials/:id', requireAuth, requirePermission('materials.edit'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { id } = req.params;
    const { isAdmin, teacherId, assignedClassIds } = getTeacherAuthContext(req);

    if (!database.studyMaterials) database.studyMaterials = [];
    const index = database.studyMaterials.findIndex((m) => m.id === id);

    if (index === -1) {
      res.status(404).json({ success: false, error: 'Study material not found.' });
      return;
    }

    const current = database.studyMaterials[index];
    if (!isAdmin && current.teacherId !== teacherId && !assignedClassIds.includes(current.classId)) {
      res.status(403).json({ success: false, error: 'Authorization error: You do not have permission to modify this material.' });
      return;
    }

    const {
      title,
      description,
      subjectId,
      classId,
      sectionId,
      fileUrl,
      fileName,
      fileSize,
      fileSizeBytes,
      fileType,
      status
    } = req.body;

    if (classId && classId !== current.classId && !isAdmin && !assignedClassIds.includes(classId)) {
      res.status(403).json({ success: false, error: 'Cannot reassign material to an unauthorized class.' });
      return;
    }

    const cls = classId ? database.classes.find((c) => c.id === classId) : null;
    const sec = sectionId && sectionId !== 'ALL' ? database.sections.find((s) => s.id === sectionId) : null;
    const subj = subjectId ? database.subjects.find((s) => s.id === subjectId) : null;

    const updated: StudyMaterial = {
      ...current,
      title: title !== undefined ? title.trim() : current.title,
      description: description !== undefined ? description.trim() : current.description,
      subjectId: subjectId || current.subjectId,
      subjectName: subj?.name || current.subjectName,
      classId: classId || current.classId,
      className: cls?.name || current.className,
      sectionId: sectionId !== undefined ? sectionId : current.sectionId,
      sectionName: sectionId === 'ALL' ? 'All Sections' : (sec?.name || current.sectionName),
      fileUrl: fileUrl || current.fileUrl,
      fileName: fileName || current.fileName,
      fileSize: fileSize || current.fileSize,
      fileSizeBytes: fileSizeBytes || current.fileSizeBytes,
      fileType: fileType || current.fileType,
      status: status || current.status,
      updatedAt: new Date().toISOString()
    };

    database.studyMaterials[index] = updated;

    logAudit({
      userId: req.user!.id,
      userRole: req.user!.role,
      action: 'MATERIAL_UPDATE',
      entity: 'StudyMaterial',
      entityType: 'StudyMaterial',
      entityId: id,
      details: `Updated study material '${updated.title}' (${updated.className})`,
      ipAddress: req.ip || '127.0.0.1'
    });

    res.json({
      success: true,
      data: updated,
      message: 'Study material updated successfully.'
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Delete Study Material
teacherActivitiesRouter.delete('/materials/:id', requireAuth, requirePermission('materials.delete'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { id } = req.params;
    const { isAdmin, teacherId, assignedClassIds } = getTeacherAuthContext(req);

    if (!database.studyMaterials) database.studyMaterials = [];
    const index = database.studyMaterials.findIndex((m) => m.id === id);

    if (index === -1) {
      res.status(404).json({ success: false, error: 'Study material not found.' });
      return;
    }

    const current = database.studyMaterials[index];
    if (!isAdmin && current.teacherId !== teacherId && !assignedClassIds.includes(current.classId)) {
      res.status(403).json({ success: false, error: 'Access denied: You cannot delete this material.' });
      return;
    }

    database.studyMaterials.splice(index, 1);

    logAudit({
      userId: req.user!.id,
      userRole: req.user!.role,
      action: 'MATERIAL_DELETE',
      entity: 'StudyMaterial',
      entityType: 'StudyMaterial',
      entityId: id,
      details: `Deleted study material '${current.title}' (${current.className})`,
      ipAddress: req.ip || '127.0.0.1'
    });

    res.json({ success: true, message: `Study material '${current.title}' deleted successfully.` });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// =========================================================================
// 4. CLASS ANNOUNCEMENTS CRUD
// =========================================================================

// List Announcements (Delegated to AnnouncementService)
teacherActivitiesRouter.get('/announcements', requireAuth, requirePermission('announcements.view'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    const { isAdmin, teacherId, assignedClassIds } = getTeacherAuthContext(req);
    const { classId, sectionId, priority, status, search, page = '1', limit = '50' } = req.query as Record<string, string>;

    const result = AnnouncementService.getAnnouncements(
      {
        classId,
        sectionId,
        priority,
        status,
        search,
        page: parseInt(page, 10) || 1,
        limit: parseInt(limit, 10) || 50
      },
      {
        userId: user.id,
        role: user.role,
        teacherId,
        assignedClassIds
      }
    );

    const pageNum = Math.max(1, parseInt(page, 10) || 1);
    const limitNum = Math.max(1, parseInt(limit, 10) || 50);
    const total = result.total;
    const paginated = result.data.slice((pageNum - 1) * limitNum, pageNum * limitNum);

    res.json({
      success: true,
      data: paginated,
      stats: result.stats,
      pagination: {
        page: pageNum,
        limit: limitNum,
        total,
        totalPages: Math.ceil(total / limitNum) || 1
      }
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Create Announcement (Delegated to AnnouncementService)
teacherActivitiesRouter.post('/announcements', requireAuth, requirePermission('announcements.create'), async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  try {
    const user = req.user!;
    const { isAdmin, assignedClassIds } = getTeacherAuthContext(req);
    const {
      title,
      message,
      category = 'general',
      classId,
      sectionId = 'ALL',
      publishDate,
      expiryDate,
      priority = 'normal',
      status = 'published',
      attachments = [],
      isPinned = false
    } = req.body;

    if (!title || !title.trim()) {
      res.status(400).json({ success: false, error: 'Announcement title is required.' });
      return;
    }
    if (!message || !message.trim()) {
      res.status(400).json({ success: false, error: 'Announcement message body is required.' });
      return;
    }
    if (!classId) {
      res.status(400).json({ success: false, error: 'Target Class is required.' });
      return;
    }

    if (!isAdmin && !assignedClassIds.includes(classId)) {
      res.status(403).json({
        success: false,
        error: 'Authorization violation: You are not assigned to post announcements for this class.'
      });
      return;
    }

    const created = await AnnouncementService.createAnnouncement(
      {
        title,
        message,
        category,
        priority,
        targetAudience: 'CLASS',
        classId,
        sectionId: sectionId || 'ALL',
        publishDate,
        expiryDate,
        isPinned,
        status,
        attachments
      },
      {
        id: user.id,
        name: user.name,
        role: user.role
      }
    );

    res.status(201).json({
      success: true,
      data: created,
      message: 'Announcement posted successfully.'
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Update Announcement (Delegated to AnnouncementService)
teacherActivitiesRouter.put('/announcements/:id', requireAuth, requirePermission('announcements.edit'), async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  try {
    const user = req.user!;
    const { id } = req.params;

    const result = await AnnouncementService.updateAnnouncement(id, req.body, {
      id: user.id,
      name: user.name,
      role: user.role
    });

    if (!result.success) {
      res.status(result.error?.includes('Unauthorized') ? 403 : 404).json(result);
      return;
    }

    res.json({
      success: true,
      data: result.data,
      message: 'Announcement updated successfully.'
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Delete Announcement (Delegated to AnnouncementService)
teacherActivitiesRouter.delete('/announcements/:id', requireAuth, requirePermission('announcements.delete'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    const { id } = req.params;

    const result = AnnouncementService.deleteAnnouncement(id, {
      id: user.id,
      name: user.name,
      role: user.role
    });

    if (!result.success) {
      res.status(result.error?.includes('Unauthorized') ? 403 : 404).json(result);
      return;
    }

    res.json({ success: true, message: 'Announcement deleted successfully.' });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});
