import { Router, Response } from 'express';
import { database } from '../db/database.js';
import { requireAuth, requireRole, AuthenticatedRequest } from '../security/auth.js';
import { getAuditLogs } from '../security/audit.js';

export const auditRouter = Router();

// Only Super Admin can view full audit trail
auditRouter.get('/', requireAuth, requireRole('SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  const limit = req.query.limit ? parseInt(req.query.limit as string, 10) : 50;
  const logs = getAuditLogs(limit);

  res.json({
    success: true,
    data: logs,
    total: database.auditLogs.length
  });
});
