import { Router, Response } from 'express';
import { database } from '../db/database.js';
import { requireAuth, requireRole, AuthenticatedRequest } from '../security/auth.js';
import { logAudit } from '../security/audit.js';
import { getDateWorkingStatus } from './attendance.routes.js';
import { AttendanceNotificationService } from '../services/attendance-notifications.service.js';
import { AnnouncementService } from '../services/announcement.service.js';
import {
  Guardian,
  GuardianChildSummary,
  GuardianChildDossier,
  GuardianDashboardData,
  GuardianProfileUpdatePayload,
  NotificationItem,
  GuardianChildSubject,
  GuardianChildTeacher,
  GuardianChildAcademicSummary,
  GuardianChildAcademicOverview,
  GuardianChildAttendanceDay,
  GuardianAttendanceSummary,
  GuardianChildAttendanceOverviewData,
  StudentLeaveApplication,
  LeaveApplication,
  AttendanceStatus,
  AttendanceRecord,
  StudentHomeworkItem,
  StudentAssignmentItem,
  StudyMaterial,
  ClassAnnouncement,
  StudentActivitiesSummary,
  ActivityCalculatedStatus,
  GuardianChildHomeworkResponse,
  GuardianChildAssignmentResponse,
  GuardianChildMaterialResponse,
  GuardianChildAnnouncementResponse,
  GuardianChildActivitiesSummaryResponse,
  ExamScheduleItem,
  ExamScheduleFilterParams,
  StudentExamResult,
  StudentResultsFilterParams,
  StudentAcademicProgressOverview,
  SubjectPerformanceTrend,
  ExamWiseTrendItem,
  GradingScaleItem,
  GuardianChildExaminationsResponse,
  GuardianChildResultsResponse,
  GuardianChildProgressResponse,
  GuardianChildrenComparisonResponse,
  GuardianChildComparisonItem,
  StudentFeeRecord,
  FeePaymentTransaction,
  FeePaymentReceipt,
  GuardianFeeSummary,
  GuardianChildFeesResponse,
  GuardianChildFeeDetailResponse,
  GuardianPaymentHistoryResponse,
  GuardianFamilyFeeOverviewResponse,
  PaymentMethod,
  GuardianContextData,
  GuardianChildAcademicSnapshot,
  GuardianChildAttendanceSnapshot,
  GuardianChildFeesSnapshot,
  GuardianChildActivityItem
} from '../../src/types/index.js';

export const guardianRouter = Router();

const CURRENT_SYSTEM_DATE = '2026-08-16';

function calculateActivityDates(
  dueDateStr: string,
  assignedOrStartDateStr?: string
): {
  status: ActivityCalculatedStatus;
  daysRemaining: number;
  isOverdue: boolean;
  isDueSoon: boolean;
} {
  const today = new Date(CURRENT_SYSTEM_DATE);
  today.setHours(0, 0, 0, 0);

  const due = new Date(dueDateStr);
  due.setHours(0, 0, 0, 0);

  const diffTime = due.getTime() - today.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

  const isOverdue = diffDays < 0;
  const isDueSoon = diffDays >= 0 && diffDays <= 3;

  let status: ActivityCalculatedStatus = 'active';
  if (isOverdue) {
    status = 'overdue';
  } else if (isDueSoon) {
    status = 'due_soon';
  } else if (assignedOrStartDateStr && new Date(assignedOrStartDateStr) > today) {
    status = 'upcoming';
  }

  return {
    status,
    daysRemaining: diffDays,
    isOverdue,
    isDueSoon
  };
}

// Apply Authentication to all guardian routes
guardianRouter.use(requireAuth);

/**
 * Helper to resolve the active Guardian record for the authenticated user.
 * Guardians can only access their own profile. Super Admins inspecting the portal
 * will default to the primary multi-child demo guardian (Carlos Rivera).
 */
function resolveAuthenticatedGuardian(req: AuthenticatedRequest): Guardian | null {
  const user = req.user;
  if (!user) return null;

  if (user.role === 'GUARDIAN') {
    const guardian = database.guardians.find(
      (g) => g.userId === user.id || g.email.toLowerCase() === user.email.toLowerCase()
    );
    return guardian || null;
  }

  // Super Admin bypass / demo inspection context
  if (user.role === 'SUPER_ADMIN') {
    // Return primary multi-child guardian or first available guardian
    return database.guardians[0] || null;
  }

  return null;
}

/**
 * Helper to build a comprehensive GuardianChildSummary from a student profile
 */
function buildChildSummary(studentProfileId: string): GuardianChildSummary | null {
  const student = database.studentProfiles.find((s) => s.id === studentProfileId);
  if (!student) return null;

  const user = database.users.find((u) => u.id === student.userId);
  const schoolClass = database.classes.find((c) => c.id === student.classId);
  const section = database.sections.find((sec) => sec.id === student.sectionId);
  const session = database.academicSessions.find((sess) => sess.id === student.academicSessionId);

  // Find class teacher
  let classTeacherName = 'Prof. Sarah Jenkins';
  let classTeacherEmail = 'teacher.sarah@sygmate.edu';
  let classTeacherPhone = '+1 (555) 012-7890';
  let classTeacherId = 'teacher-prof-1';

  if (section?.classTeacherId) {
    const teacherProf = database.teacherProfiles.find((tp) => tp.id === section.classTeacherId);
    if (teacherProf) {
      const teacherUser = database.users.find((u) => u.id === teacherProf.userId);
      classTeacherId = teacherProf.id;
      classTeacherName = teacherProf.firstName && teacherProf.lastName
        ? `${teacherProf.firstName} ${teacherProf.lastName}`
        : teacherUser?.name || teacherProf.designation;
      classTeacherEmail = teacherProf.email || teacherUser?.email || classTeacherEmail;
      classTeacherPhone = teacherProf.phone || teacherProf.contactNumber || teacherUser?.phoneNumber || classTeacherPhone;
    }
  }

  // Calculate enrolled subjects count
  const classSubjects = database.subjects.filter(
    (subj) => subj.classId === student.classId || (subj.classIds && subj.classIds.includes(student.classId))
  );

  return {
    id: student.id,
    userId: student.userId,
    admissionNumber: student.admissionNumber,
    rollNumber: student.rollNumber,
    name: student.firstName && student.lastName ? `${student.firstName} ${student.lastName}` : user?.name || 'Student Scholar',
    firstName: student.firstName || user?.name?.split(' ')[0] || '',
    lastName: student.lastName || user?.name?.split(' ').slice(1).join(' ') || '',
    avatarUrl: student.avatarUrl || user?.avatarUrl,
    dateOfBirth: student.dateOfBirth,
    gender: student.gender,
    bloodGroup: student.bloodGroup || 'O+',
    classId: student.classId,
    className: schoolClass?.name || 'Class',
    sectionId: student.sectionId,
    sectionName: section?.name || 'Section A',
    roomNumber: section?.roomNumber || 'Room 302',
    academicSessionId: student.academicSessionId,
    academicSessionName: session?.sessionName || '2026-2027 Academic Year',
    academicYear: '2026-2027',
    enrollmentStatus: student.enrollmentStatus || 'Active',
    status: student.status || 'active',
    enrollmentDate: student.enrollmentDate || '2026-08-01',
    classTeacherId,
    classTeacherName,
    classTeacherEmail,
    classTeacherPhone,
    totalSubjectsCount: classSubjects.length || 6,
    emergencyContact: (student as any).emergencyContact || student.guardianPhone || user?.phoneNumber,
    address: student.address || (user as any)?.address || 'Campus Residence'
  };
}

/**
 * Helper to get all linked children for a guardian with relationship-level authorization flags
 */
function getAllLinkedChildren(guardian: Guardian): Array<GuardianChildSummary & {
  relationshipType: string;
  isPrimary: boolean;
  isAuthorizedAcademic: boolean;
  isAuthorizedAttendance: boolean;
  isAuthorizedFinancial: boolean;
  isAuthorizedCommunication: boolean;
  isPickupAuthorized: boolean;
}> {
  const studentIdSet = new Set<string>();
  (guardian.studentIds || []).forEach((id) => studentIdSet.add(id));
  database.studentProfiles.forEach((st) => {
    if (st.guardianId === guardian.id || st.secondaryGuardianId === guardian.id) {
      studentIdSet.add(st.id);
    }
  });
  database.parentStudentRelationships.forEach((rel) => {
    if (rel.guardianId === guardian.id) {
      studentIdSet.add(rel.studentId);
    }
  });

  const children: Array<GuardianChildSummary & {
    relationshipType: string;
    isPrimary: boolean;
    isAuthorizedAcademic: boolean;
    isAuthorizedAttendance: boolean;
    isAuthorizedFinancial: boolean;
    isAuthorizedCommunication: boolean;
    isPickupAuthorized: boolean;
  }> = [];

  for (const studentId of Array.from(studentIdSet)) {
    const summary = buildChildSummary(studentId);
    if (!summary) continue;

    const rel = database.parentStudentRelationships.find(
      (r) => r.guardianId === guardian.id && r.studentId === studentId
    );

    const isPrimary = rel?.isPrimaryGuardian ?? (guardian.isPrimaryGuardian || false);

    children.push({
      ...summary,
      relationshipType: rel?.relationshipType || guardian.relationship || 'Guardian',
      isPrimary,
      isAuthorizedAcademic: rel?.isAuthorizedAcademic ?? true,
      isAuthorizedAttendance: rel?.isAuthorizedAttendance ?? true,
      isAuthorizedFinancial: rel?.isAuthorizedFinancial ?? isPrimary,
      isAuthorizedCommunication: rel?.isAuthorizedCommunication ?? true,
      isPickupAuthorized: rel?.isPickupAuthorized ?? true
    });
  }

  return children;
}

/**
 * Verifies if a studentId belongs to an authorized child of the guardian
 * Checks guardian.studentIds, studentProfiles, and parentStudentRelationships.
 */
function isAuthorizedStudentForGuardian(guardian: Guardian, studentId: string): boolean {
  if (!guardian || !studentId) return false;
  if (guardian.studentIds && guardian.studentIds.includes(studentId)) return true;
  const inProfile = database.studentProfiles.some(
    (st) => st.id === studentId && (st.guardianId === guardian.id || st.secondaryGuardianId === guardian.id)
  );
  if (inProfile) return true;
  return database.parentStudentRelationships.some(
    (r) => r.guardianId === guardian.id && r.studentId === studentId
  );
}

/**
 * Returns all student IDs linked to a guardian across all models
 */
function getGuardianLinkedStudentIds(guardian: Guardian): string[] {
  const ids = new Set<string>(guardian.studentIds || []);
  database.studentProfiles.forEach((st) => {
    if (st.guardianId === guardian.id || st.secondaryGuardianId === guardian.id) {
      ids.add(st.id);
    }
  });
  database.parentStudentRelationships.forEach((rel) => {
    if (rel.guardianId === guardian.id) {
      ids.add(rel.studentId);
    }
  });
  return Array.from(ids);
}

/**
 * Builds the Academic Snapshot for a specific child.
 * Strictly filters database.examResults where isPublished === true and workflowStatus === 'PUBLISHED'.
 * Never leaks draft, unapproved results, or internal teacher notes.
 */
function buildAcademicSnapshot(studentId: string, studentSummary: GuardianChildSummary): GuardianChildAcademicSnapshot {
  const publishedResults = (database.examResults || []).filter(
    (r) =>
      (r.studentId === studentId || r.userId === studentSummary.userId) &&
      r.isPublished === true &&
      r.workflowStatus === 'PUBLISHED'
  );

  publishedResults.sort(
    (a, b) => new Date(b.publishDate || b.createdAt).getTime() - new Date(a.publishDate || a.createdAt).getTime()
  );

  const totalExams = publishedResults.length;
  let cumulativeGPA = 0;
  let totalGPA = 0;

  publishedResults.forEach((r) => {
    totalGPA += Number(r.summary?.gpa) || 0;
  });

  if (totalExams > 0) {
    cumulativeGPA = Math.round((totalGPA / totalExams) * 100) / 100;
  }

  let overallGrade = 'N/A';
  let overallStanding = 'In Good Standing';

  if (cumulativeGPA >= 3.8) {
    overallGrade = 'A+';
    overallStanding = 'Academic High Distinction';
  } else if (cumulativeGPA >= 3.5) {
    overallGrade = 'A';
    overallStanding = 'Academic Honors';
  } else if (cumulativeGPA >= 3.0) {
    overallGrade = 'B+';
    overallStanding = 'Satisfactory Standing';
  } else if (cumulativeGPA >= 2.0) {
    overallGrade = 'C';
    overallStanding = 'Average Progress';
  } else if (totalExams > 0) {
    overallGrade = 'D';
    overallStanding = 'Academic Review Required';
  }

  const latest = publishedResults[0];
  let latestResult: GuardianChildAcademicSnapshot['latestResult'] = undefined;

  if (latest) {
    const publicSubjectScores = (latest.subjectScores || []).map((s) => ({
      subjectId: s.subjectId,
      subjectName: s.subjectName,
      subjectCode: s.subjectCode,
      maxMarks: s.fullMarks || 100,
      obtainedMarks: s.obtainedMarks,
      percentage: s.percentage,
      grade: s.grade,
      status: s.status
    }));

    latestResult = {
      id: latest.id,
      examName: latest.examName,
      examType: latest.examType,
      term: latest.term,
      academicYear: latest.academicYear,
      publishDate: latest.publishDate,
      gpa: Number(latest.summary?.gpa) || 0,
      percentage: Number(latest.summary?.overallPercentage) || 0,
      grade: latest.summary?.overallGrade || 'N/A',
      isPassed: (latest.summary?.failedSubjects || 0) === 0,
      academicStanding: latest.summary?.resultStatus || 'SATISFACTORY',
      classRank: latest.summary?.classRank,
      totalStudentsInClass: latest.summary?.totalStudentsInClass,
      subjectScores: publicSubjectScores
    };
  }

  return {
    currentClass: studentSummary.className,
    currentSection: studentSummary.sectionName,
    academicSession: studentSummary.academicSessionName,
    totalSubjectsEnrolled: studentSummary.totalSubjectsCount,
    hasPublishedResults: totalExams > 0,
    publishedResultsCount: totalExams,
    cumulativeGPA,
    overallGrade,
    overallStanding,
    latestResult
  };
}

/**
 * Builds the Attendance Snapshot for a specific child using institutional attendance records.
 */
function buildAttendanceSnapshot(studentId: string, studentSummary: GuardianChildSummary): GuardianChildAttendanceSnapshot {
  const records = (database.attendanceRecords || []).filter(
    (r) => r.studentId === studentId || r.userId === studentSummary.userId
  );

  const totalSchoolDays = records.length;
  let presentCount = 0;
  let absentCount = 0;
  let lateCount = 0;
  let leaveCount = 0;
  let halfDayCount = 0;

  records.forEach((r) => {
    switch (r.status) {
      case 'PRESENT':
        presentCount++;
        break;
      case 'ABSENT':
        absentCount++;
        break;
      case 'LATE':
        lateCount++;
        break;
      case 'LEAVE':
      case 'EXCUSED':
        leaveCount++;
        break;
      case 'HALF_DAY':
        halfDayCount++;
        break;
      default:
        presentCount++;
    }
  });

  const attendancePercentage =
    totalSchoolDays > 0
      ? Math.round(((presentCount + lateCount + halfDayCount * 0.5) / totalSchoolDays) * 1000) / 10
      : 100;

  let statusEvaluation: GuardianChildAttendanceSnapshot['statusEvaluation'] = 'EXCELLENT';
  if (attendancePercentage >= 90) {
    statusEvaluation = 'EXCELLENT';
  } else if (attendancePercentage >= 80) {
    statusEvaluation = 'GOOD';
  } else if (attendancePercentage >= 75) {
    statusEvaluation = 'SATISFACTORY';
  } else {
    statusEvaluation = 'ATTENTION_REQUIRED';
  }

  const sortedRecords = [...records].sort(
    (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
  );
  const lastRecord = sortedRecords[0];

  return {
    hasAttendanceData: totalSchoolDays > 0,
    totalSchoolDays,
    presentCount,
    absentCount,
    lateCount,
    leaveCount,
    halfDayCount,
    attendancePercentage,
    statusEvaluation,
    lastMarkedDate: lastRecord?.date || null,
    lastMarkedStatus: lastRecord?.status || null
  };
}

/**
 * Builds the Fees Snapshot for a specific child using database fee records.
 */
function buildFeesSnapshot(studentId: string): GuardianChildFeesSnapshot {
  const childFees = (database.feeRecords || []).filter((f) => f.studentId === studentId);
  const hasFeeRecords = childFees.length > 0;
  const summary = calculateFeeSummary(childFees);

  let latestPaymentStatus: GuardianChildFeesSnapshot['latestPaymentStatus'] = 'NO_FEES';
  if (hasFeeRecords) {
    if (summary.totalDue <= 0) {
      latestPaymentStatus = 'PAID';
    } else if (summary.totalOverdue > 0) {
      latestPaymentStatus = 'OVERDUE';
    } else if (summary.totalPaid > 0) {
      latestPaymentStatus = 'PARTIAL';
    } else {
      latestPaymentStatus = 'DUE';
    }
  }

  const sortedFees = [...childFees].sort(
    (a, b) => new Date(b.dueDate).getTime() - new Date(a.dueDate).getTime()
  );
  const latestFee = sortedFees[0];

  return {
    hasFeeRecords,
    totalFees: summary.totalFees,
    totalPaid: summary.totalPaid,
    totalDue: summary.totalDue,
    totalOverdue: summary.totalOverdue,
    totalDiscount: summary.totalDiscount,
    fullyPaidCount: summary.fullyPaidCount,
    partiallyPaidCount: summary.partiallyPaidCount,
    unpaidCount: summary.unpaidCount,
    overdueCount: summary.overdueCount,
    nextUpcomingDueDate: summary.nextUpcomingDueDate,
    latestInvoiceNumber: latestFee?.invoiceNumber || null,
    latestPaymentStatus
  };
}

/**
 * Builds Recent Activities for the dashboard focusing on the selected child.
 */
function buildRecentActivities(
  studentId: string,
  studentSummary: GuardianChildSummary,
  guardian: Guardian
): GuardianChildActivityItem[] {
  const activities: GuardianChildActivityItem[] = [];

  // 1. Published Results
  const publishedResults = (database.examResults || []).filter(
    (r) =>
      (r.studentId === studentId || r.userId === studentSummary.userId) &&
      r.isPublished === true &&
      r.workflowStatus === 'PUBLISHED'
  );
  publishedResults.slice(0, 2).forEach((r) => {
    activities.push({
      id: `act-res-${r.id}`,
      type: 'RESULT',
      title: `Result Published: ${r.examName}`,
      description: `Grade: ${r.summary?.overallGrade || 'A'} • GPA: ${Number(r.summary?.gpa || 0).toFixed(2)} (${r.summary?.overallPercentage || 0}%)`,
      timestamp: r.publishDate || r.createdAt,
      badgeLabel: 'Exam Result',
      badgeVariant: 'success',
      linkView: 'guardian-results'
    });
  });

  // 2. Attendance notices/records
  const attendanceRecords = (database.attendanceRecords || [])
    .filter((r) => r.studentId === studentId || r.userId === studentSummary.userId)
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  attendanceRecords.slice(0, 3).forEach((a) => {
    const isAbs = a.status === 'ABSENT';
    const isLate = a.status === 'LATE';
    activities.push({
      id: `act-att-${a.id}`,
      type: 'ATTENDANCE',
      title: isAbs
        ? `Absence Recorded for ${studentSummary.name}`
        : isLate
        ? `Late Arrival Recorded for ${studentSummary.name}`
        : `Attendance Logged: Present`,
      description: `Daily roll call verified for ${studentSummary.className} on ${a.date}`,
      timestamp: `${a.date}T08:30:00.000Z`,
      badgeLabel: a.status,
      badgeVariant: isAbs ? 'danger' : isLate ? 'warning' : 'success',
      linkView: 'guardian-attendance'
    });
  });

  // 3. Fee records & receipts
  const childFees = (database.feeRecords || [])
    .filter((f) => f.studentId === studentId)
    .sort((a, b) => new Date(b.createdAt || b.dueDate).getTime() - new Date(a.createdAt || a.dueDate).getTime());

  childFees.slice(0, 2).forEach((f) => {
    activities.push({
      id: `act-fee-${f.id}`,
      type: 'FEE',
      title: `Fee Invoice: ${f.title || f.feeType}`,
      description: `Invoice ${f.invoiceNumber} • $${f.totalAmount.toFixed(2)} • Due ${f.dueDate}`,
      timestamp: f.createdAt || `${f.dueDate}T09:00:00.000Z`,
      badgeLabel: f.status,
      badgeVariant: f.status === 'PAID' ? 'success' : f.status === 'OVERDUE' ? 'danger' : 'info',
      linkView: 'guardian-fees'
    });
  });

  // 4. Relevant class announcements
  const announcements = (database.classAnnouncements || []).filter(
    (a) =>
      a.status === 'published' &&
      (!a.classId || a.classId === 'ALL' || a.classId === studentSummary.classId) &&
      (!a.sectionId || a.sectionId === 'ALL' || a.sectionId === studentSummary.sectionId)
  );
  announcements.slice(0, 2).forEach((a) => {
    activities.push({
      id: `act-not-${a.id}`,
      type: 'NOTICE',
      title: a.title,
      description: a.message?.slice(0, 100) + (a.message?.length > 100 ? '...' : ''),
      timestamp: a.publishDate || a.createdAt,
      badgeLabel: a.priority === 'urgent' ? 'Urgent' : 'Notice',
      badgeVariant: a.priority === 'urgent' ? 'danger' : 'neutral',
      linkView: 'guardian-announcements'
    });
  });

  activities.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

  return activities.slice(0, 8);
}

/**
 * GET /api/guardian/context
 * Comprehensive parent session context endpoint: returns guardian profile,
 * all linked children with granular permissions, active child, and notification count.
 * Enforces strict IDOR checks on requested childId.
 */
guardianRouter.get('/context', requireRole('GUARDIAN', 'SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const guardian = resolveAuthenticatedGuardian(req);
    if (!guardian) {
      res.status(404).json({
        success: false,
        error: 'Guardian account profile not found.',
        code: 'GUARDIAN_NOT_FOUND'
      });
      return;
    }

    const allChildren = getAllLinkedChildren(guardian);
    const { childId } = req.query as { childId?: string };

    let selectedChild = null;
    if (childId) {
      selectedChild = allChildren.find((c) => c.id === childId);
      if (!selectedChild) {
        // IDOR violation detected
        res.status(403).json({
          success: false,
          error: 'Access forbidden: Requested student is not linked to your parent account.',
          code: 'FORBIDDEN_IDOR_VIOLATION'
        });
        return;
      }
    } else {
      selectedChild = allChildren[0] || null;
    }

    const user = req.user!;
    const unreadNotificationsCount = database.notifications.filter(
      (n) => (n.userId === user.id || n.roleTarget === 'ALL' || n.roleTarget === 'GUARDIAN') && !n.isRead
    ).length;

    const contextData: GuardianContextData = {
      guardian,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        username: user.username,
        role: user.role,
        status: user.status
      },
      children: allChildren,
      selectedChildId: selectedChild ? selectedChild.id : null,
      selectedChild,
      permissions: {
        canViewAcademic: selectedChild ? selectedChild.isAuthorizedAcademic : false,
        canViewAttendance: selectedChild ? selectedChild.isAuthorizedAttendance : false,
        canViewFinancial: selectedChild ? selectedChild.isAuthorizedFinancial : false,
        canViewCommunication: selectedChild ? selectedChild.isAuthorizedCommunication : false,
        isPickupAuthorized: selectedChild ? selectedChild.isPickupAuthorized : false
      },
      unreadNotificationsCount
    };

    res.json({
      success: true,
      data: contextData
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * POST /api/guardian/switch-child
 * Safely switch active child in portal context with strict IDOR verification
 */
guardianRouter.post('/switch-child', requireRole('GUARDIAN', 'SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const guardian = resolveAuthenticatedGuardian(req);
    if (!guardian) {
      res.status(404).json({ success: false, error: 'Guardian not found.' });
      return;
    }

    const { studentId } = req.body;
    if (!studentId) {
      res.status(400).json({ success: false, error: 'studentId is required.' });
      return;
    }

    const allChildren = getAllLinkedChildren(guardian);
    const targetChild = allChildren.find((c) => c.id === studentId);

    if (!targetChild) {
      logAudit({
        userId: req.user!.id,
        userName: req.user!.name,
        userRole: req.user!.role,
        action: 'READ',
        entity: 'STUDENT',
        entityId: studentId,
        details: `IDOR attempt blocked: Parent attempted to switch to unauthorized student ${studentId}.`,
        ipAddress: req.ip
      });

      res.status(403).json({
        success: false,
        error: 'Access forbidden: You do not have permission to access records for this student.',
        code: 'FORBIDDEN_IDOR_VIOLATION'
      });
      return;
    }

    logAudit({
      userId: req.user!.id,
      userName: req.user!.name,
      userRole: req.user!.role,
      action: 'READ',
      entity: 'STUDENT',
      entityId: studentId,
      details: `Parent switched active portal focus to ${targetChild.name} (${targetChild.admissionNumber}).`,
      ipAddress: req.ip
    });

    res.json({
      success: true,
      message: `Switched active child to ${targetChild.name}.`,
      data: {
        selectedChildId: targetChild.id,
        selectedChild: targetChild,
        permissions: {
          canViewAcademic: targetChild.isAuthorizedAcademic,
          canViewAttendance: targetChild.isAuthorizedAttendance,
          canViewFinancial: targetChild.isAuthorizedFinancial,
          canViewCommunication: targetChild.isAuthorizedCommunication,
          isPickupAuthorized: targetChild.isPickupAuthorized
        }
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * GET /api/guardian/dashboard
 * Authenticated dashboard for guardian showing profile summary, all linked children,
 * recent targeted notifications, academic updates, and quick actions.
 */
guardianRouter.get('/dashboard', requireRole('GUARDIAN', 'SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const guardian = resolveAuthenticatedGuardian(req);
    if (!guardian) {
      res.status(404).json({
        success: false,
        error: 'Guardian account profile not found.',
        code: 'GUARDIAN_NOT_FOUND'
      });
      return;
    }

    // Resolve all linked children across guardian profiles and relationships
    const children: GuardianChildSummary[] = getAllLinkedChildren(guardian);

    // IDOR Protection: If childId query parameter is provided, verify it belongs to this guardian
    const requestedChildId = req.query.childId as string | undefined;
    if (requestedChildId && !isAuthorizedStudentForGuardian(guardian, requestedChildId)) {
      logAudit({
        userId: req.user?.id || 'unknown',
        userName: req.user?.name || guardian.name,
        userRole: req.user?.role || 'GUARDIAN',
        action: 'UNAUTHORIZED_ATTEMPT',
        entity: 'STUDENT',
        details: `IDOR Security Violation: Guardian '${guardian.name}' unauthorized attempt to access dashboard snapshot for unlinked student '${requestedChildId}'.`,
        ipAddress: req.ip
      });

      res.status(403).json({
        success: false,
        error: 'Access denied: You do not have authorization to view records for this student.',
        code: 'FORBIDDEN_STUDENT_ACCESS'
      });
      return;
    }

    // Determine active / selected child
    const selectedChildId = requestedChildId || children[0]?.id;
    const selectedChild = children.find((c) => c.id === selectedChildId) || children[0];

    // Compute child-specific snapshots if a child exists
    let academicSnapshot: GuardianChildAcademicSnapshot | undefined = undefined;
    let attendanceSnapshot: GuardianChildAttendanceSnapshot | undefined = undefined;
    let feesSnapshot: GuardianChildFeesSnapshot | undefined = undefined;
    let recentActivities: GuardianChildActivityItem[] = [];

    if (selectedChild) {
      academicSnapshot = buildAcademicSnapshot(selectedChild.id, selectedChild);
      attendanceSnapshot = buildAttendanceSnapshot(selectedChild.id, selectedChild);
      feesSnapshot = buildFeesSnapshot(selectedChild.id);
      recentActivities = buildRecentActivities(selectedChild.id, selectedChild, guardian);
    }

    // Get notifications for this guardian
    const recentNotifications = database.notifications
      .filter((n) => n.userId === req.user?.id || n.roleTarget === 'ALL' || n.roleTarget === 'GUARDIAN')
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    const unreadNotificationCount = recentNotifications.filter((n) => !n.isRead).length;

    // Get relevant announcements (Class-specific for linked children or school-wide)
    const childClassIds = new Set(children.map((c) => c.classId));
    const rawAnnouncements = database.classAnnouncements || [];
    const importantAnnouncements = rawAnnouncements
      .filter((a) => a.status === 'published' && (!a.classId || a.classId === 'ALL' || childClassIds.has(a.classId)))
      .sort((a, b) => new Date(b.publishDate || b.createdAt).getTime() - new Date(a.publishDate || a.createdAt).getTime())
      .slice(0, 5)
      .map((a) => {
        const cls = database.classes.find((c) => c.id === a.classId);
        const sec = database.sections.find((s) => s.id === a.sectionId);
        return {
          id: a.id,
          title: a.title,
          content: a.message,
          priority: (a.priority === 'important' ? 'high' : a.priority || 'normal') as 'low' | 'normal' | 'high' | 'urgent',
          targetType: a.classId === 'ALL' ? 'ALL' : 'CLASS',
          className: cls?.name || a.className,
          sectionName: sec?.name || a.sectionName,
          publishedAt: a.publishDate || a.createdAt,
          authorName: a.teacherName || 'Academic Administration'
        };
      });

    const settings = database.schoolSettings;
    const activeSession = database.academicSessions.find((s) => s.isActive);

    const totalEnrolledSubjects = children.reduce((acc, c) => acc + c.totalSubjectsCount, 0);

    const dashboardData: GuardianDashboardData = {
      guardian,
      totalChildren: children.length,
      children,
      activeChildId: selectedChildId,
      selectedChildId,
      selectedChild,
      academicSnapshot,
      attendanceSnapshot,
      feesSnapshot,
      recentActivities,
      recentNotifications: recentNotifications.slice(0, 5),
      importantAnnouncements,
      unreadNotificationCount,
      quickStats: {
        totalEnrolledSubjects,
        activeAcademicYear: activeSession?.sessionName || '2026-2027 Academic Year',
        schoolName: settings?.schoolName || 'Sygmate International Academy',
        schoolPhone: settings?.contactPhone || settings?.phone || '+1 (555) 012-3456',
        schoolEmail: settings?.contactEmail || 'administration@sygmate.edu'
      }
    };

    res.json({
      success: true,
      data: dashboardData
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to retrieve guardian dashboard data.',
      code: 'SERVER_ERROR'
    });
  }
});

/**
 * GET /api/guardian/children
 * List all verified children linked to the authenticated guardian
 */
guardianRouter.get('/children', requireRole('GUARDIAN', 'SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const guardian = resolveAuthenticatedGuardian(req);
    if (!guardian) {
      res.status(404).json({
        success: false,
        error: 'Guardian profile not found.',
        code: 'GUARDIAN_NOT_FOUND'
      });
      return;
    }

    const children: GuardianChildSummary[] = getAllLinkedChildren(guardian);

    res.json({
      success: true,
      data: children
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve linked children.',
      code: 'SERVER_ERROR'
    });
  }
});

/**
 * GET /api/guardian/children/:studentId/dashboard-snapshot
 * Returns standalone dashboard snapshot for a specific child.
 * Strictly verifies child belongs to authenticated guardian (IDOR protection).
 */
guardianRouter.get('/children/:studentId/dashboard-snapshot', requireRole('GUARDIAN', 'SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { studentId } = req.params;
    const guardian = resolveAuthenticatedGuardian(req);
    if (!guardian) {
      res.status(404).json({
        success: false,
        error: 'Guardian profile not found.',
        code: 'GUARDIAN_NOT_FOUND'
      });
      return;
    }

    // STRICT IDOR CHECK
    if (!isAuthorizedStudentForGuardian(guardian, studentId)) {
      logAudit({
        userId: req.user?.id || 'unknown',
        userName: req.user?.name || guardian.name,
        userRole: req.user?.role || 'GUARDIAN',
        action: 'UNAUTHORIZED_ATTEMPT',
        entity: 'STUDENT',
        details: `IDOR Security Violation: Guardian '${guardian.name}' unauthorized attempt to fetch dashboard snapshot for student '${studentId}'.`,
        ipAddress: req.ip
      });

      res.status(403).json({
        success: false,
        error: 'Access denied: You do not have authorization to view records for this student.',
        code: 'FORBIDDEN_STUDENT_ACCESS'
      });
      return;
    }

    const studentSummary = buildChildSummary(studentId);
    if (!studentSummary) {
      res.status(404).json({
        success: false,
        error: 'Student record not found.',
        code: 'STUDENT_NOT_FOUND'
      });
      return;
    }

    const rel = database.parentStudentRelationships.find(
      (r) => r.guardianId === guardian.id && r.studentId === studentId
    );

    const academicSnapshot = buildAcademicSnapshot(studentId, studentSummary);
    const attendanceSnapshot = buildAttendanceSnapshot(studentId, studentSummary);
    const feesSnapshot = buildFeesSnapshot(studentId);
    const recentActivities = buildRecentActivities(studentId, studentSummary, guardian);

    res.json({
      success: true,
      data: {
        studentSummary,
        academicSnapshot,
        attendanceSnapshot,
        feesSnapshot,
        recentActivities,
        permissions: {
          isPrimary: rel?.isPrimaryGuardian ?? true,
          isAuthorizedAcademic: rel?.isAuthorizedAcademic ?? true,
          isAuthorizedAttendance: rel?.isAuthorizedAttendance ?? true,
          isAuthorizedFinancial: rel?.isAuthorizedFinancial ?? true,
          isAuthorizedCommunication: rel?.isAuthorizedCommunication ?? true,
          isPickupAuthorized: rel?.isPickupAuthorized ?? true
        }
      }
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to retrieve child dashboard snapshot.',
      code: 'SERVER_ERROR'
    });
  }
});

/**
 * GET /api/guardian/children/:studentId
 * Get detailed academic dossier for a specific child.
 * CRITICAL SECURITY: Verifies that the requested studentId is in the authenticated guardian's studentIds.
 */
guardianRouter.get('/children/:studentId', requireRole('GUARDIAN', 'SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { studentId } = req.params;
    const guardian = resolveAuthenticatedGuardian(req);

    if (!guardian) {
      res.status(404).json({
        success: false,
        error: 'Guardian profile not found.',
        code: 'GUARDIAN_NOT_FOUND'
      });
      return;
    }

    // STRICT SECURITY VERIFICATION: ID Manipulation Protection
    if (!isAuthorizedStudentForGuardian(guardian, studentId)) {
      logAudit({
        userId: req.user?.id || 'unknown',
        userName: req.user?.name || guardian.name,
        userRole: req.user?.role || 'GUARDIAN',
        action: 'UNAUTHORIZED_ATTEMPT',
        entity: 'STUDENT',
        details: `Access denied: Guardian '${guardian.name}' attempted to access unlinked student '${studentId}'.`,
        ipAddress: req.ip
      });

      res.status(403).json({
        success: false,
        error: 'Access denied: You are not authorized to view this scholar profile. You can only access your own linked children.',
        code: 'FORBIDDEN_STUDENT_ACCESS'
      });
      return;
    }

    const summary = buildChildSummary(studentId);
    if (!summary) {
      res.status(404).json({
        success: false,
        error: 'Student record not found.',
        code: 'STUDENT_NOT_FOUND'
      });
      return;
    }

    // Get enrolled subjects for the child's class
    const classSubjects = database.subjects
      .filter((subj) => subj.classId === summary.classId || (subj.classIds && subj.classIds.includes(summary.classId)))
      .map((s) => {
        const teacher = database.teacherProfiles.find((t) => t.id === s.teacherId);
        const teacherUser = teacher ? database.users.find((u) => u.id === teacher.userId) : null;
        return {
          id: s.id,
          name: s.name,
          code: s.code,
          type: s.type || 'theory',
          creditHours: s.credits || 3,
          teacherName: teacher?.firstName && teacher?.lastName ? `${teacher.firstName} ${teacher.lastName}` : teacherUser?.name || 'Faculty Member'
        };
      });

    const session = database.academicSessions.find((sess) => sess.id === summary.academicSessionId);

    const dossier: GuardianChildDossier = {
      ...summary,
      enrolledSubjects: classSubjects,
      academicSessionDetails: {
        startDate: session?.startDate,
        endDate: session?.endDate,
        term: 'Fall Semester 2026',
        isActive: !!session?.isActive
      }
    };

    res.json({
      success: true,
      data: dossier
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve child scholar dossier.',
      code: 'SERVER_ERROR'
    });
  }
});

/**
 * GET /api/guardian/children/:studentId/academic-overview
 * Comprehensive academic overview for a specific linked child.
 * CRITICAL SECURITY: Verifies that the requested studentId is in the authenticated guardian's studentIds.
 * Supports query filters: search, type, sessionId.
 */
guardianRouter.get('/children/:studentId/academic-overview', requireRole('GUARDIAN', 'SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { studentId } = req.params;
    const { search, type, sessionId } = req.query as {
      search?: string;
      type?: string;
      sessionId?: string;
    };

    const guardian = resolveAuthenticatedGuardian(req);
    if (!guardian) {
      res.status(404).json({
        success: false,
        error: 'Guardian profile not found.',
        code: 'GUARDIAN_NOT_FOUND'
      });
      return;
    }

    // STRICT SECURITY AUTHORIZATION: Prevent unauthorized access across guardians
    if (!isAuthorizedStudentForGuardian(guardian, studentId)) {
      logAudit({
        userId: req.user?.id || 'unknown',
        userName: req.user?.name || guardian.name,
        userRole: req.user?.role || 'GUARDIAN',
        action: 'UNAUTHORIZED_ATTEMPT',
        entity: 'STUDENT',
        details: `Security Violation: Guardian '${guardian.name}' unauthorized attempt to view academic overview of unlinked student '${studentId}'.`,
        ipAddress: req.ip
      });

      res.status(403).json({
        success: false,
        error: 'Access denied: You are not authorized to view academic information for this scholar. Guardians can only access records of their verified linked children.',
        code: 'FORBIDDEN_STUDENT_ACCESS'
      });
      return;
    }

    const studentSummary = buildChildSummary(studentId);
    if (!studentSummary) {
      res.status(404).json({
        success: false,
        error: 'Student record not found.',
        code: 'STUDENT_NOT_FOUND'
      });
      return;
    }

    const studentProfile = database.studentProfiles.find((s) => s.id === studentId);
    const effectiveSessionId = sessionId || studentSummary.academicSessionId;

    // 1. Resolve Subjects for child's class
    let rawSubjects = database.subjects.filter(
      (subj) => subj.classId === studentSummary.classId || (subj.classIds && subj.classIds.includes(studentSummary.classId))
    );

    // Apply search filter if provided
    if (search && search.trim()) {
      const q = search.trim().toLowerCase();
      rawSubjects = rawSubjects.filter(
        (s) => s.name.toLowerCase().includes(q) || s.code.toLowerCase().includes(q)
      );
    }

    // Apply type filter if provided (core, elective, theory, practical)
    if (type && type !== 'all') {
      rawSubjects = rawSubjects.filter(
        (s) => (s.type || 'theory').toLowerCase() === type.toLowerCase()
      );
    }

    const childSubjects: GuardianChildSubject[] = rawSubjects.map((s) => {
      const teacher = database.teacherProfiles.find((t) => t.id === s.teacherId);
      const teacherUser = teacher ? database.users.find((u) => u.id === teacher.userId) : null;
      const dept = database.departments.find((d) => d.id === s.departmentId);

      const teacherName = teacher?.firstName && teacher?.lastName
        ? `${teacher.firstName} ${teacher.lastName}`
        : teacherUser?.name || 'Faculty Instructor';

      return {
        id: s.id,
        name: s.name,
        code: s.code,
        type: s.type || 'theory',
        credits: s.credits || 3,
        status: (s.status === 'inactive' ? 'inactive' : 'active') as 'active' | 'inactive',
        departmentName: dept?.name || 'Academic Faculty',
        teacherId: teacher?.id,
        teacherName,
        teacherDesignation: teacher?.designation || 'Lecturer'
      };
    });

    // 2. Resolve Teachers associated with this child
    // Deduplicate distinct teachers from subjects and homeroom/class teacher
    const teachersMap = new Map<string, GuardianChildTeacher>();

    // Add class teacher
    if (studentSummary.classTeacherId) {
      const ctProf = database.teacherProfiles.find((tp) => tp.id === studentSummary.classTeacherId);
      if (ctProf) {
        const ctUser = database.users.find((u) => u.id === ctProf.userId);
        const dept = database.departments.find((d) => d.id === ctProf.departmentId);
        const name = ctProf.firstName && ctProf.lastName ? `${ctProf.firstName} ${ctProf.lastName}` : ctUser?.name || 'Faculty Member';
        teachersMap.set(ctProf.id, {
          id: ctProf.id,
          name,
          designation: ctProf.designation || 'Head of Class / Homeroom Faculty',
          departmentName: dept?.name || 'Academic Faculty',
          email: ctProf.email || ctUser?.email || 'faculty@sygmate.edu',
          subjectNames: [],
          isClassTeacher: true,
          className: studentSummary.className,
          sectionName: studentSummary.sectionName
        });
      }
    }

    // Add subject teachers
    for (const subj of childSubjects) {
      if (subj.teacherId) {
        const teacherProf = database.teacherProfiles.find((tp) => tp.id === subj.teacherId);
        if (teacherProf) {
          const teacherUser = database.users.find((u) => u.id === teacherProf.userId);
          const dept = database.departments.find((d) => d.id === teacherProf.departmentId);
          const name = teacherProf.firstName && teacherProf.lastName ? `${teacherProf.firstName} ${teacherProf.lastName}` : teacherUser?.name || subj.teacherName;

          if (teachersMap.has(teacherProf.id)) {
            const existing = teachersMap.get(teacherProf.id)!;
            if (!existing.subjectNames.includes(subj.name)) {
              existing.subjectNames.push(subj.name);
            }
          } else {
            teachersMap.set(teacherProf.id, {
              id: teacherProf.id,
              name,
              designation: teacherProf.designation || 'Subject Instructor',
              departmentName: dept?.name || 'Academic Faculty',
              email: teacherProf.email || teacherUser?.email || 'faculty@sygmate.edu',
              subjectNames: [subj.name],
              isClassTeacher: teacherProf.id === studentSummary.classTeacherId,
              className: studentSummary.className,
              sectionName: studentSummary.sectionName
            });
          }
        }
      }
    }

    const childTeachers = Array.from(teachersMap.values());

    // 3. Assemble Academic Summary from Real Database Data
    // Attendance Stats
    const studentAttendance = (database.attendanceRecords || []).filter(
      (att) => att.studentId === studentSummary.id || att.userId === studentSummary.userId
    );

    let attendanceSummaryData: GuardianChildAcademicSummary['attendance'] = null;
    if (studentAttendance.length > 0) {
      const totalDays = studentAttendance.length;
      const presentDays = studentAttendance.filter((a) => a.status === 'PRESENT').length;
      const absentDays = studentAttendance.filter((a) => a.status === 'ABSENT').length;
      const lateDays = studentAttendance.filter((a) => a.status === 'LATE').length;
      const excusedDays = studentAttendance.filter((a) => a.status === 'EXCUSED' || a.status === 'LEAVE').length;
      const percentage = Math.round(((presentDays + excusedDays + lateDays * 0.8) / totalDays) * 1000) / 10;

      attendanceSummaryData = {
        hasData: true,
        percentage: Math.min(100, percentage),
        totalDays,
        presentDays,
        absentDays,
        lateDays
      };
    } else {
      attendanceSummaryData = {
        hasData: false,
        percentage: 0,
        totalDays: 0,
        presentDays: 0,
        absentDays: 0,
        lateDays: 0
      };
    }

    // Homework Stats
    const classHomework = (database.homework || []).filter(
      (hw) => hw.classId === studentSummary.classId && (hw.sectionId === 'ALL' || hw.sectionId === studentSummary.sectionId)
    );
    const sortedHw = [...classHomework].sort(
      (a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime()
    );
    const nextHw = sortedHw[0];

    const homeworkSummary: GuardianChildAcademicSummary['homework'] = classHomework.length > 0 ? {
      totalCount: classHomework.length,
      pendingCount: classHomework.filter((h) => h.status === 'published').length,
      nextDueItem: nextHw ? {
        id: nextHw.id,
        title: nextHw.title,
        subjectName: nextHw.subjectName || 'Coursework',
        dueDate: nextHw.dueDate
      } : undefined
    } : null;

    // Assignments Stats
    const classAssignments = (database.assignments || []).filter(
      (asg) => asg.classId === studentSummary.classId && (asg.sectionId === 'ALL' || asg.sectionId === studentSummary.sectionId)
    );
    const sortedAsg = [...classAssignments].sort(
      (a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime()
    );
    const nextAsg = sortedAsg[0];

    const assignmentsSummary: GuardianChildAcademicSummary['assignments'] = classAssignments.length > 0 ? {
      totalCount: classAssignments.length,
      pendingCount: classAssignments.filter((a) => a.status === 'published').length,
      nextDueItem: nextAsg ? {
        id: nextAsg.id,
        title: nextAsg.title,
        subjectName: nextAsg.subjectName || 'Assignment',
        dueDate: nextAsg.dueDate
      } : undefined
    } : null;

    // Latest Exam Result
    const studentResults = (database.examResults || []).filter(
      (resItem) => resItem.studentId === studentSummary.id || resItem.userId === studentSummary.userId
    );
    sortedResultsDesc: studentResults.sort(
      (a, b) => new Date(b.publishDate || b.createdAt).getTime() - new Date(a.publishDate || a.createdAt).getTime()
    );

    const latestExam = studentResults[0];
    let latestResultSummary: GuardianChildAcademicSummary['latestResult'] = null;
    if (latestExam) {
      latestResultSummary = {
        hasData: true,
        examName: latestExam.examName,
        term: latestExam.term || 'Fall Semester 2026',
        publishDate: latestExam.publishDate || latestExam.createdAt,
        overallPercentage: latestExam.summary?.overallPercentage || 0,
        gpa: latestExam.summary?.gpa || 0,
        overallGrade: latestExam.summary?.overallGrade || 'A',
        resultStatus: latestExam.summary?.resultStatus || 'PASSED',
        classRank: latestExam.summary?.classRank,
        totalStudentsInClass: latestExam.summary?.totalStudentsInClass
      };
    }

    // Recent Activities compiled from Announcements, Attendance, and Exam publications
    const recentActivities: GuardianChildAcademicSummary['recentActivities'] = [];

    // Recent announcements
    const relevantAnnouncements = (database.classAnnouncements || [])
      .filter((a) => a.status === 'published' && (!a.classId || a.classId === 'ALL' || a.classId === studentSummary.classId))
      .slice(0, 3);
    for (const ann of relevantAnnouncements) {
      recentActivities.push({
        id: `act-ann-${ann.id}`,
        title: ann.title,
        type: 'announcement',
        date: ann.publishDate || ann.createdAt,
        description: ann.message,
        badgeText: 'School Notice'
      });
    }

    // Latest Attendance activity
    if (studentAttendance.length > 0) {
      const latestAtt = studentAttendance[studentAttendance.length - 1];
      recentActivities.push({
        id: `act-att-${latestAtt.id}`,
        title: `Attendance Log: ${latestAtt.status}`,
        type: 'attendance',
        date: latestAtt.date,
        description: `Marked as ${latestAtt.status} for ${latestAtt.subjectName || studentSummary.className} by ${latestAtt.recordedByTeacherName}.`,
        badgeText: latestAtt.status
      });
    }

    // Latest Exam activity
    if (latestExam) {
      recentActivities.push({
        id: `act-res-${latestExam.id}`,
        title: `Exam Score Published: ${latestExam.examName}`,
        type: 'exam',
        date: latestExam.publishDate || latestExam.createdAt,
        description: `Achieved ${latestExam.summary?.overallPercentage}% (${latestExam.summary?.overallGrade}) with GPA ${latestExam.summary?.gpa}.`,
        badgeText: latestExam.summary?.resultStatus || 'Graded'
      });
    }

    recentActivities.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

    const totalCredits = childSubjects.reduce((acc, s) => acc + (s.credits || 0), 0);

    const availableSessions = (database.academicSessions || []).map((s) => ({
      id: s.id,
      name: s.sessionName,
      isActive: !!s.isActive
    }));

    const overview: GuardianChildAcademicOverview = {
      student: studentSummary,
      subjects: childSubjects,
      teachers: childTeachers,
      summary: {
        totalSubjects: childSubjects.length,
        totalCredits,
        attendance: attendanceSummaryData,
        homework: homeworkSummary,
        assignments: assignmentsSummary,
        latestResult: latestResultSummary,
        recentActivities: recentActivities.slice(0, 6)
      },
      availableSessions
    };

    res.json({
      success: true,
      data: overview
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to retrieve child academic overview.',
      code: 'SERVER_ERROR'
    });
  }
});

// =========================================================================
// PART 5C: GUARDIAN ATTENDANCE & LEAVE MANAGEMENT ENDPOINTS
// =========================================================================

/**
 * GET /api/guardian/children/:studentId/attendance
 * Retrieve comprehensive attendance records, metrics, and calendar for a verified linked child.
 * CRITICAL SECURITY: Validates that the requested studentId is in the authenticated guardian's studentIds.
 */
guardianRouter.get('/children/:studentId/attendance', requireRole('GUARDIAN', 'SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { studentId } = req.params;
    const { month, academicSessionId, startDate, endDate } = req.query as {
      month?: string; // 'YYYY-MM'
      academicSessionId?: string;
      startDate?: string;
      endDate?: string;
    };

    const guardian = resolveAuthenticatedGuardian(req);
    if (!guardian) {
      res.status(404).json({
        success: false,
        error: 'Guardian profile not found.',
        code: 'GUARDIAN_NOT_FOUND'
      });
      return;
    }

    // STRICT SECURITY VERIFICATION: Guardian-Student Authorization check
    if (!isAuthorizedStudentForGuardian(guardian, studentId)) {
      logAudit({
        userId: req.user?.id || 'unknown',
        userName: req.user?.name || guardian.name,
        userRole: req.user?.role || 'GUARDIAN',
        action: 'UNAUTHORIZED_ATTEMPT',
        entity: 'STUDENT_ATTENDANCE',
        details: `Security Violation: Guardian '${guardian.name}' unauthorized attempt to view attendance of unlinked student '${studentId}'.`,
        ipAddress: req.ip
      });

      res.status(403).json({
        success: false,
        error: 'Access denied: You are not authorized to view attendance data for this scholar. You can only inspect records of your verified linked children.',
        code: 'FORBIDDEN_STUDENT_ACCESS'
      });
      return;
    }

    const studentSummary = buildChildSummary(studentId);
    if (!studentSummary) {
      res.status(404).json({
        success: false,
        error: 'Student scholar record not found.',
        code: 'STUDENT_NOT_FOUND'
      });
      return;
    }

    const studentProfile = database.studentProfiles.find((s) => s.id === studentId);
    if (!studentProfile) {
      res.status(404).json({
        success: false,
        error: 'Student profile record not found.',
        code: 'STUDENT_PROFILE_NOT_FOUND'
      });
      return;
    }

    // Determine target month (default to current year-month e.g., '2026-08')
    const currentIsoDate = '2026-08-15';
    const targetMonth = month && /^\d{4}-\d{2}$/.test(month) ? month : currentIsoDate.substring(0, 7);
    const [yearStr, monthStr] = targetMonth.split('-');
    const year = parseInt(yearStr, 10);
    const monthIndex = parseInt(monthStr, 10) - 1; // 0-indexed month

    // Get number of days in this month
    const daysInMonth = new Date(year, monthIndex + 1, 0).getDate();

    // Fetch all attendance records for this student
    const studentAttendanceRecords = (database.attendanceRecords || []).filter(
      (r) => r.studentId === studentProfile.id || r.userId === studentProfile.userId
    );

    // Fetch leave applications for this student
    if (!database.leaveApplications) database.leaveApplications = [];
    const studentLeaveApplications = database.leaveApplications.filter(
      (l) => l.studentId === studentProfile.id || l.userId === studentProfile.userId
    );

    // Filter records for summary computation (either session or date range)
    const sessionRecords = studentAttendanceRecords.filter((r) => {
      if (startDate && r.date < startDate) return false;
      if (endDate && r.date > endDate) return false;
      if (academicSessionId && academicSessionId !== 'ALL' && r.academicSessionId !== academicSessionId) return false;
      return true;
    });

    const totalSchoolDays = sessionRecords.length;
    const presentCount = sessionRecords.filter((r) => r.status === 'PRESENT').length;
    const absentCount = sessionRecords.filter((r) => r.status === 'ABSENT').length;
    const lateCount = sessionRecords.filter((r) => r.status === 'LATE').length;
    const halfDayCount = sessionRecords.filter((r) => r.status === 'HALF_DAY').length;
    const leaveCount = sessionRecords.filter((r) => r.status === 'EXCUSED' || (r.status as string) === 'LEAVE').length;

    // Standard institutional percentage calculation: (present + late + halfDay * 0.5) / totalSchoolDays
    const attendancePercentage =
      totalSchoolDays > 0
        ? Math.round(((presentCount + lateCount + (halfDayCount * 0.5)) / totalSchoolDays) * 1000) / 10
        : 100;

    // Build calendar days array for the targeted month
    const calendarDays: GuardianChildAttendanceDay[] = [];
    const targetSessionId = academicSessionId || studentSummary.academicSessionId || database.schoolSettings.academicSessionId;
    for (let day = 1; day <= daysInMonth; day++) {
      const dayPad = String(day).padStart(2, '0');
      const dateStr = `${targetMonth}-${dayPad}`;
      const dateObj = new Date(year, monthIndex, day);
      const dayOfWeek = dateObj.getDay(); // 0 = Sun, 6 = Sat
      
      const dayWorkingStatus = getDateWorkingStatus(dateStr, targetSessionId);
      const isWeekend = dayWorkingStatus.dayType === 'WEEKEND';
      const isHoliday = dayWorkingStatus.dayType === 'HOLIDAY';
      const isToday = dateStr === currentIsoDate;
      const isFuture = dateStr > currentIsoDate;

      // Find record for this date
      const record = studentAttendanceRecords.find((r) => r.date === dateStr);
      const leaveApp = studentLeaveApplications.find(
        (l) => l.leaveDate === dateStr || (l.endDate && dateStr >= l.leaveDate && dateStr <= l.endDate)
      );

      let status: AttendanceStatus | 'WEEKEND' | 'HOLIDAY' | 'FUTURE' | 'NO_RECORD' = 'NO_RECORD';
      let statusLabel = 'No Session';

      if (isHoliday) {
        status = 'HOLIDAY';
        statusLabel = dayWorkingStatus.reason || 'Holiday';
      } else if (isWeekend) {
        status = 'WEEKEND';
        statusLabel = 'Weekend';
      } else if (record) {
        status = record.status;
        statusLabel =
          record.status === 'PRESENT'
            ? 'Present'
            : record.status === 'ABSENT'
            ? 'Absent'
            : record.status === 'LATE'
            ? 'Late'
            : 'Leave / Excused';
      } else if (leaveApp && leaveApp.status === 'APPROVED') {
        status = 'EXCUSED';
        statusLabel = 'Approved Leave';
      } else if (isFuture) {
        status = 'FUTURE';
        statusLabel = 'Upcoming';
      } else {
        status = 'NO_RECORD';
        statusLabel = 'No Record';
      }

      calendarDays.push({
        date: dateStr,
        dayOfMonth: day,
        dayOfWeek,
        status,
        statusLabel,
        isWeekend,
        isHoliday,
        isToday,
        isFuture,
        record,
        leaveApplication: leaveApp
      });
    }

    const availableSessions = (database.academicSessions || []).map((s) => ({
      id: s.id,
      name: s.sessionName,
      isActive: !!s.isActive
    }));

    const responseData: GuardianChildAttendanceOverviewData = {
      student: studentSummary,
      summary: {
        totalSchoolDays,
        presentCount,
        absentCount,
        lateCount,
        leaveCount,
        attendancePercentage
      },
      filterMonth: targetMonth,
      filterAcademicSessionId: academicSessionId || studentSummary.academicSessionId,
      calendarDays,
      records: sessionRecords.sort((a, b) => b.date.localeCompare(a.date)),
      leaveApplications: studentLeaveApplications.sort((a, b) => b.createdAt.localeCompare(a.createdAt)),
      availableSessions
    };

    res.json({
      success: true,
      data: responseData
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to retrieve child attendance data.',
      code: 'SERVER_ERROR'
    });
  }
});

/**
 * GET /api/guardian/children/:studentId/leave-applications
 * Retrieve all leave applications submitted for a specific linked child.
 * CRITICAL SECURITY: Validates that the requested studentId is in the authenticated guardian's studentIds.
 */
guardianRouter.get('/children/:studentId/leave-applications', requireRole('GUARDIAN', 'SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { studentId } = req.params;
    const { status } = req.query as { status?: string };

    const guardian = resolveAuthenticatedGuardian(req);
    if (!guardian) {
      res.status(404).json({
        success: false,
        error: 'Guardian profile not found.',
        code: 'GUARDIAN_NOT_FOUND'
      });
      return;
    }

    if (!isAuthorizedStudentForGuardian(guardian, studentId)) {
      res.status(403).json({
        success: false,
        error: 'Access denied: You are not authorized to view leave applications for this scholar.',
        code: 'FORBIDDEN_STUDENT_ACCESS'
      });
      return;
    }

    if (!database.leaveApplications) database.leaveApplications = [];

    const studentProfile = database.studentProfiles.find((s) => s.id === studentId);
    if (!studentProfile) {
      res.status(404).json({
        success: false,
        error: 'Student record not found.',
        code: 'STUDENT_NOT_FOUND'
      });
      return;
    }

    let applications = database.leaveApplications.filter(
      (l) => l.studentId === studentProfile.id || l.userId === studentProfile.userId
    );

    if (status && status !== 'ALL') {
      applications = applications.filter((l) => l.status === status.toUpperCase());
    }

    applications.sort((a, b) => b.createdAt.localeCompare(a.createdAt));

    res.json({
      success: true,
      data: applications
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to retrieve child leave applications.',
      code: 'SERVER_ERROR'
    });
  }
});

/**
 * POST /api/guardian/children/:studentId/leave-applications
 * Submit a new leave application on behalf of a verified linked child.
 * Validates input, prevents duplicate requests for the same date, and integrates with Admin/Teacher approval workflow.
 */
guardianRouter.post('/children/:studentId/leave-applications', requireRole('GUARDIAN', 'SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { studentId } = req.params;
    const { leaveDate, endDate, reason, description, attachmentUrl, attachmentName } = req.body as {
      leaveDate: string;
      endDate?: string;
      reason: string;
      description: string;
      attachmentUrl?: string;
      attachmentName?: string;
    };

    const guardian = resolveAuthenticatedGuardian(req);
    if (!guardian) {
      res.status(404).json({
        success: false,
        error: 'Guardian profile not found.',
        code: 'GUARDIAN_NOT_FOUND'
      });
      return;
    }

    // STRICT SECURITY AUTHORIZATION
    if (!isAuthorizedStudentForGuardian(guardian, studentId)) {
      logAudit({
        userId: req.user?.id || 'unknown',
        userName: req.user?.name || guardian.name,
        userRole: req.user?.role || 'GUARDIAN',
        action: 'UNAUTHORIZED_ATTEMPT',
        entity: 'LEAVE_APPLICATION',
        details: `Security Violation: Guardian '${guardian.name}' attempted to submit leave for unlinked student '${studentId}'.`,
        ipAddress: req.ip
      });

      res.status(403).json({
        success: false,
        error: 'Access denied: You cannot submit leave applications for scholars who are not linked to your family account.',
        code: 'FORBIDDEN_STUDENT_ACCESS'
      });
      return;
    }

    const studentProfile = database.studentProfiles.find((s) => s.id === studentId);
    if (!studentProfile) {
      res.status(404).json({
        success: false,
        error: 'Student record not found.',
        code: 'STUDENT_NOT_FOUND'
      });
      return;
    }

    const studentUser = database.users.find((u) => u.id === studentProfile.userId);
    const studentClass = database.classes.find((c) => c.id === studentProfile.classId);
    const studentSection = database.sections.find((s) => s.id === studentProfile.sectionId);

    // Validation
    if (!leaveDate || !leaveDate.trim()) {
      res.status(400).json({ success: false, error: 'Leave date is required.' });
      return;
    }
    if (!reason || !reason.trim()) {
      res.status(400).json({ success: false, error: 'Reason for leave is required.' });
      return;
    }
    if (!description || !description.trim()) {
      res.status(400).json({ success: false, error: 'Detailed description is required.' });
      return;
    }

    // Date validations and totalDays calculation
    const startStr = leaveDate.trim();
    const endStr = endDate ? endDate.trim() : startStr;

    if (endStr < startStr) {
      res.status(400).json({ success: false, error: 'End date cannot be earlier than start date.' });
      return;
    }

    let calculatedTotalDays = 1;
    const startTime = new Date(startStr).getTime();
    const endTime = new Date(endStr).getTime();
    if (!isNaN(startTime) && !isNaN(endTime) && endTime >= startTime) {
      calculatedTotalDays = Math.max(1, Math.round((endTime - startTime) / (1000 * 60 * 60 * 24)) + 1);
    }

    if (!database.leaveApplications) database.leaveApplications = [];

    // DUPLICATE & OVERLAP CHECK: Verify no active/approved application exists for this student overlapping the requested dates
    const existingApp = database.leaveApplications.find((l) => {
      if (l.studentId !== studentProfile.id && l.userId !== studentProfile.userId) return false;
      if (l.status === 'REJECTED' || l.status === 'CANCELLED') return false;
      const lStart = l.startDate || l.leaveDate;
      const lEnd = l.endDate || l.leaveDate;
      return startStr <= lEnd && endStr >= lStart;
    });

    if (existingApp) {
      res.status(400).json({
        success: false,
        error: `A leave application overlapping these dates (${existingApp.startDate || existingApp.leaveDate} to ${existingApp.endDate || existingApp.leaveDate}) has already been submitted (Status: ${existingApp.status}).`
      });
      return;
    }

    const now = new Date().toISOString();
    const studentFullName = studentUser?.name || `${studentProfile.firstName || ''} ${studentProfile.lastName || ''}`.trim() || 'Student Scholar';

    const newApplication: LeaveApplication = {
      id: `leave-app-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      applicantType: 'STUDENT',
      applicantId: studentProfile.id,
      applicantName: studentFullName,
      studentId: studentProfile.id,
      userId: studentProfile.userId,
      studentName: studentFullName,
      admissionNumber: studentProfile.admissionNumber,
      rollNumber: studentProfile.rollNumber,
      classId: studentProfile.classId,
      className: studentClass?.name || 'Class',
      sectionId: studentProfile.sectionId,
      sectionName: studentSection?.name || 'Section',
      academicSessionId: studentProfile.academicSessionId || 'session-2026-2027',
      startDate: startStr,
      endDate: endStr,
      leaveDate: startStr,
      totalDays: calculatedTotalDays,
      reason: reason.trim(),
      description: description.trim(),
      attachmentUrl: attachmentUrl || undefined,
      attachmentName: attachmentName || (attachmentUrl ? 'Medical_or_Leave_Document.pdf' : undefined),
      status: 'PENDING',
      submissionDate: now.substring(0, 10),
      submittedByGuardianId: guardian.id,
      submittedByGuardianName: guardian.name,
      createdAt: now,
      updatedAt: now
    };

    database.leaveApplications.push(newApplication);

    // IN-APP NOTIFICATION FOR ADMIN / CLASS TEACHER
    if (!database.notifications) database.notifications = [];
    database.notifications.push({
      id: `notif-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      userId: 'usr-admin-1',
      roleTarget: 'SUPER_ADMIN',
      title: `Guardian Leave Application: ${studentFullName}`,
      message: `Guardian ${guardian.name} submitted a leave request for ${studentFullName} (${studentClass?.name || 'Grade 10'}) on ${leaveDate}. Reason: ${reason}.`,
      category: 'academic',
      isRead: false,
      createdAt: now
    });

    // Centralized Attendance Notification & Alert System (Part 8F)
    AttendanceNotificationService.dispatchEvent({
      eventType: 'LEAVE_SUBMITTED',
      date: leaveDate.trim(),
      studentId: studentProfile.id,
      leaveApplicationId: newApplication.id,
      leaveType: 'General Leave',
      leaveStartDate: leaveDate.trim(),
      leaveEndDate: (endDate || leaveDate).trim(),
      reason: reason.trim(),
      actorUser: { id: req.user?.id || guardian.userId, name: guardian.name, role: 'GUARDIAN' }
    });

    // AUDIT LOG
    logAudit({
      userId: req.user?.id || guardian.userId,
      userName: req.user?.name || guardian.name,
      userRole: req.user?.role || 'GUARDIAN',
      action: 'CREATE',
      entity: 'LEAVE_APPLICATION',
      entityType: 'LEAVE_APPLICATION',
      entityId: newApplication.id,
      details: `Guardian '${guardian.name}' submitted leave application for student '${studentFullName}' on ${leaveDate}. Reason: ${reason}.`,
      ipAddress: req.ip,
      metadata: {
        studentId: studentProfile.id,
        leaveDate,
        reason
      }
    });

    res.status(201).json({
      success: true,
      message: `Leave application for ${studentFullName} on ${leaveDate} submitted successfully and queued for administrative review.`,
      data: newApplication
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to submit leave application on behalf of child.',
      code: 'SERVER_ERROR'
    });
  }
});

/**
 * DELETE /api/guardian/children/:studentId/leave-applications/:leaveId
 * Cancel a pending leave application submitted for a linked child.
 */
guardianRouter.delete('/children/:studentId/leave-applications/:leaveId', requireRole('GUARDIAN', 'SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { studentId, leaveId } = req.params;

    const guardian = resolveAuthenticatedGuardian(req);
    if (!guardian) {
      res.status(404).json({
        success: false,
        error: 'Guardian profile not found.',
        code: 'GUARDIAN_NOT_FOUND'
      });
      return;
    }

    if (!isAuthorizedStudentForGuardian(guardian, studentId)) {
      res.status(403).json({
        success: false,
        error: 'Access denied: You cannot cancel leave applications for this scholar.',
        code: 'FORBIDDEN_STUDENT_ACCESS'
      });
      return;
    }

    if (!database.leaveApplications) database.leaveApplications = [];
    const index = database.leaveApplications.findIndex(
      (l) => l.id === leaveId && (l.studentId === studentId || l.userId === studentId)
    );

    if (index === -1) {
      res.status(404).json({
        success: false,
        error: 'Leave application not found.'
      });
      return;
    }

    const application = database.leaveApplications[index];
    if (application.status !== 'PENDING') {
      res.status(400).json({
        success: false,
        error: `Cannot cancel leave application that is already ${application.status.toLowerCase()}.`
      });
      return;
    }

    database.leaveApplications.splice(index, 1);

    // AUDIT LOG
    logAudit({
      userId: req.user?.id || guardian.userId,
      userName: req.user?.name || guardian.name,
      userRole: req.user?.role || 'GUARDIAN',
      action: 'DELETE',
      entity: 'LEAVE_APPLICATION',
      entityType: 'LEAVE_APPLICATION',
      entityId: leaveId,
      details: `Guardian '${guardian.name}' retracted pending leave application for student '${application.studentName}' on ${application.leaveDate}.`,
      ipAddress: req.ip
    });

    res.json({
      success: true,
      message: 'Leave application retracted successfully.'
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to cancel leave application.',
      code: 'SERVER_ERROR'
    });
  }
});



/**
 * GET /api/guardian/profile
 * Get authenticated guardian profile details, enriched with family household and scholar relationship details
 */
guardianRouter.get('/profile', requireRole('GUARDIAN', 'SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const guardian = resolveAuthenticatedGuardian(req);
    if (!guardian) {
      res.status(404).json({
        success: false,
        error: 'Guardian profile not found.',
        code: 'GUARDIAN_NOT_FOUND'
      });
      return;
    }

    const rels = database.parentStudentRelationships?.filter((r) => r.guardianId === guardian.id) || [];
    const family = guardian.familyId ? database.families?.find((f) => f.id === guardian.familyId) : undefined;
    const coGuardians = family
      ? database.guardians?.filter((g) => family.guardianIds?.includes(g.id) && g.id !== guardian.id)
      : [];

    const enrichedGuardian = {
      ...guardian,
      relationships: rels,
      family,
      coGuardians: coGuardians.map((cg) => ({
        id: cg.id,
        name: cg.name,
        relationship: cg.relationship,
        phone: cg.phone,
        email: cg.email,
        familyRole: cg.familyRole
      }))
    };

    res.json({
      success: true,
      data: enrichedGuardian
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve guardian profile.',
      code: 'SERVER_ERROR'
    });
  }
});

/**
 * PUT /api/guardian/profile
 * Update authorized personal contact fields for the authenticated guardian.
 * SECURITY: Only allows personal contact fields; prevents administrative attribute tampering.
 */
guardianRouter.put('/profile', requireRole('GUARDIAN', 'SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const guardian = resolveAuthenticatedGuardian(req);
    if (!guardian) {
      res.status(404).json({
        success: false,
        error: 'Guardian profile not found.',
        code: 'GUARDIAN_NOT_FOUND'
      });
      return;
    }

    const payload = req.body as GuardianProfileUpdatePayload;

    // Validate email format if provided
    if (payload.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(payload.email)) {
      res.status(400).json({
        success: false,
        error: 'Please provide a valid email address.',
        code: 'VALIDATION_ERROR'
      });
      return;
    }

    // Strictly update permitted personal fields ONLY
    if (payload.name !== undefined) guardian.name = payload.name.trim();
    if (payload.firstName !== undefined) guardian.firstName = payload.firstName.trim();
    if (payload.lastName !== undefined) guardian.lastName = payload.lastName.trim();
    if (payload.preferredName !== undefined) guardian.preferredName = payload.preferredName.trim();
    if (payload.phone !== undefined) guardian.phone = payload.phone.trim();
    if (payload.secondaryPhone !== undefined) guardian.secondaryPhone = payload.secondaryPhone.trim();
    if (payload.whatsapp !== undefined) guardian.whatsapp = payload.whatsapp.trim();
    if (payload.preferredContactMethod !== undefined) guardian.preferredContactMethod = payload.preferredContactMethod;
    if (payload.email !== undefined) guardian.email = payload.email.trim();
    if (payload.address !== undefined) guardian.address = payload.address.trim();
    if (payload.permanentAddress !== undefined) guardian.permanentAddress = payload.permanentAddress.trim();
    if (payload.city !== undefined) guardian.city = payload.city.trim();
    if (payload.state !== undefined) guardian.state = payload.state.trim();
    if (payload.country !== undefined) guardian.country = payload.country.trim();
    if (payload.postalCode !== undefined) guardian.postalCode = payload.postalCode.trim();
    if (payload.occupation !== undefined) guardian.occupation = payload.occupation.trim();
    if (payload.emergencyContact !== undefined) guardian.emergencyContact = payload.emergencyContact.trim();
    if (payload.avatarUrl !== undefined) guardian.avatarUrl = payload.avatarUrl.trim();
    guardian.updatedAt = new Date().toISOString();

    // Synchronize corresponding User record if present
    if (guardian.userId) {
      const user = database.users.find((u) => u.id === guardian.userId);
      if (user) {
        if (payload.name) user.name = payload.name.trim();
        if (payload.phone) user.phoneNumber = payload.phone.trim();
        if (payload.email) user.email = payload.email.trim();
        if (payload.avatarUrl) user.avatarUrl = payload.avatarUrl.trim();
        user.updatedAt = new Date().toISOString();
      }
    }

    logAudit({
      userId: req.user?.id || guardian.id,
      userName: guardian.name,
      userRole: req.user?.role || 'GUARDIAN',
      action: 'UPDATE',
      entity: 'USER',
      entityId: guardian.id,
      details: `Guardian personal contact profile updated for ${guardian.name}.`,
      ipAddress: req.ip
    });

    res.json({
      success: true,
      data: guardian,
      message: 'Your guardian profile details have been updated successfully.'
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: 'Failed to update guardian profile.',
      code: 'SERVER_ERROR'
    });
  }
});

/**
 * GET /api/guardian/notifications
 * Retrieve notification feed for guardian with optional filtering
 */
guardianRouter.get('/notifications', requireRole('GUARDIAN', 'SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { category, unreadOnly, search } = req.query as {
      category?: string;
      unreadOnly?: string;
      search?: string;
    };

    let notifications = database.notifications.filter(
      (n) => n.userId === req.user?.id || n.roleTarget === 'ALL' || n.roleTarget === 'GUARDIAN'
    );

    if (category && category !== 'all') {
      notifications = notifications.filter((n) => n.category === category);
    }

    if (unreadOnly === 'true') {
      notifications = notifications.filter((n) => !n.isRead);
    }

    if (search) {
      const term = search.toLowerCase();
      notifications = notifications.filter(
        (n) => n.title.toLowerCase().includes(term) || n.message.toLowerCase().includes(term)
      );
    }

    notifications.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    const unreadCount = database.notifications.filter(
      (n) => (n.userId === req.user?.id || n.roleTarget === 'ALL' || n.roleTarget === 'GUARDIAN') && !n.isRead
    ).length;

    res.json({
      success: true,
      unreadCount,
      data: notifications
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: 'Failed to retrieve guardian notifications.',
      code: 'SERVER_ERROR'
    });
  }
});

/**
 * PATCH /api/guardian/notifications/:id/read
 * Mark single notification as read
 */
guardianRouter.patch('/notifications/:id/read', requireRole('GUARDIAN', 'SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { id } = req.params;
    const notif = database.notifications.find((n) => n.id === id);
    if (notif) {
      notif.isRead = true;
    }

    res.json({
      success: true,
      message: 'Notification marked as read.'
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: 'Failed to update notification status.',
      code: 'SERVER_ERROR'
    });
  }
});

/**
 * POST /api/guardian/notifications/mark-all-read
 * Mark all notifications as read for the authenticated guardian
 */
guardianRouter.post('/notifications/mark-all-read', requireRole('GUARDIAN', 'SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    database.notifications.forEach((n) => {
      if (n.userId === req.user?.id || n.roleTarget === 'ALL' || n.roleTarget === 'GUARDIAN') {
        n.isRead = true;
      }
    });

    res.json({
      success: true,
      message: 'All notifications marked as read.'
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: 'Failed to mark all notifications as read.',
      code: 'SERVER_ERROR'
    });
  }
});

// =========================================================================
// PART 5D: GUARDIAN CHILD ACADEMIC ACTIVITIES ENDPOINTS
// =========================================================================

/**
 * Helper to retrieve distinct enrolled subjects for a child's class/section
 */
function getChildEnrolledSubjects(classId: string, sectionId?: string) {
  const subjectList = (database.subjects || []).filter(
    (s) => !s.classId || s.classId === classId
  );
  return subjectList.map((s) => ({
    id: s.id,
    name: s.name,
    code: s.code
  }));
}

/**
 * GET /api/guardian/children/:studentId/homework
 * Fetches homework assigned to the linked child's class, section & subject.
 * STRICT SECURITY: Validates that studentId belongs to the authenticated guardian.
 */
guardianRouter.get('/children/:studentId/homework', requireRole('GUARDIAN', 'SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { studentId } = req.params;
    const { subjectId, status, search, dueDate, assignedDate } = req.query as {
      subjectId?: string;
      status?: string;
      search?: string;
      dueDate?: string;
      assignedDate?: string;
    };

    const guardian = resolveAuthenticatedGuardian(req);
    if (!guardian) {
      res.status(404).json({ success: false, error: 'Guardian profile not found.', code: 'GUARDIAN_NOT_FOUND' });
      return;
    }

    if (!isAuthorizedStudentForGuardian(guardian, studentId)) {
      logAudit({
        userId: req.user?.id || guardian.userId,
        userName: guardian.name,
        userRole: 'GUARDIAN',
        action: 'UNAUTHORIZED_ATTEMPT',
        entity: 'HOMEWORK',
        details: `Security Alert: Guardian '${guardian.name}' attempted to access homework for unlinked child '${studentId}'.`,
        ipAddress: req.ip
      });
      res.status(403).json({
        success: false,
        error: 'Access denied: You are not authorized to view academic activities for this scholar.',
        code: 'FORBIDDEN_STUDENT_ACCESS'
      });
      return;
    }

    const studentSummary = buildChildSummary(studentId);
    if (!studentSummary) {
      res.status(404).json({ success: false, error: 'Student record not found.', code: 'STUDENT_NOT_FOUND' });
      return;
    }

    if (!database.homework) database.homework = [];

    // Filter published homework assigned to the child's class and section
    const rawList = database.homework.filter((h) => {
      if (h.classId !== studentSummary.classId) return false;
      if (h.sectionId && h.sectionId !== 'ALL' && h.sectionId !== 'all' && h.sectionId !== studentSummary.sectionId) {
        return false;
      }
      if (h.status !== 'published') return false;
      return true;
    });

    // Map with calculated dynamic statuses
    let mappedItems: StudentHomeworkItem[] = rawList.map((h) => {
      const calc = calculateActivityDates(h.dueDate, h.assignedDate);
      return {
        ...h,
        calculatedStatus: calc.status,
        daysRemaining: calc.daysRemaining,
        isOverdue: calc.isOverdue,
        isDueSoon: calc.isDueSoon
      };
    });

    // Compute stats across all published homework for this child
    const stats = {
      total: mappedItems.length,
      active: mappedItems.filter((h) => h.calculatedStatus === 'active' || h.calculatedStatus === 'upcoming').length,
      dueSoon: mappedItems.filter((h) => h.isDueSoon && !h.isOverdue).length,
      overdue: mappedItems.filter((h) => h.isOverdue).length
    };

    // Apply Filters
    if (subjectId && subjectId !== 'ALL' && subjectId !== 'all') {
      mappedItems = mappedItems.filter((h) => h.subjectId === subjectId);
    }

    if (status && status !== 'ALL' && status !== 'all') {
      const st = status.toLowerCase();
      mappedItems = mappedItems.filter((h) => h.calculatedStatus === st || h.status === st);
    }

    if (dueDate) {
      mappedItems = mappedItems.filter((h) => h.dueDate === dueDate);
    }
    if (assignedDate) {
      mappedItems = mappedItems.filter((h) => h.assignedDate === assignedDate);
    }

    if (search && search.trim()) {
      const q = search.trim().toLowerCase();
      mappedItems = mappedItems.filter(
        (h) =>
          h.title.toLowerCase().includes(q) ||
          h.description.toLowerCase().includes(q) ||
          h.subjectName.toLowerCase().includes(q) ||
          h.teacherName.toLowerCase().includes(q) ||
          (h.attachmentName && h.attachmentName.toLowerCase().includes(q))
      );
    }

    // Sort: Due soonest first, then newest assigned
    mappedItems.sort((a, b) => {
      if (a.isOverdue && !b.isOverdue) return 1;
      if (!a.isOverdue && b.isOverdue) return -1;
      return a.dueDate.localeCompare(b.dueDate) || b.assignedDate.localeCompare(a.assignedDate);
    });

    const subjects = getChildEnrolledSubjects(studentSummary.classId, studentSummary.sectionId);

    const response: GuardianChildHomeworkResponse = {
      student: studentSummary,
      data: mappedItems,
      total: mappedItems.length,
      stats,
      subjects
    };

    res.json({ success: true, data: response });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message, code: 'SERVER_ERROR' });
  }
});

/**
 * GET /api/guardian/children/:studentId/homework/:id
 * Single homework detail for the child
 */
guardianRouter.get('/children/:studentId/homework/:id', requireRole('GUARDIAN', 'SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { studentId, id } = req.params;
    const guardian = resolveAuthenticatedGuardian(req);
    if (!guardian) {
      res.status(404).json({ success: false, error: 'Guardian profile not found.' });
      return;
    }

    if (!isAuthorizedStudentForGuardian(guardian, studentId)) {
      res.status(403).json({ success: false, error: 'Unauthorized access to student homework.' });
      return;
    }

    const studentSummary = buildChildSummary(studentId);
    if (!studentSummary) {
      res.status(404).json({ success: false, error: 'Student record not found.' });
      return;
    }

    const item = (database.homework || []).find((h) => h.id === id);
    if (!item || item.status !== 'published') {
      res.status(404).json({ success: false, error: 'Homework not found or unavailable.', code: 'NOT_FOUND' });
      return;
    }

    const isAuthorized =
      item.classId === studentSummary.classId &&
      (!item.sectionId || item.sectionId === 'ALL' || item.sectionId === 'all' || item.sectionId === studentSummary.sectionId);

    if (!isAuthorized) {
      res.status(403).json({
        success: false,
        error: 'Unauthorized: This homework belongs to another class or section.',
        code: 'FORBIDDEN_COHORT_ACCESS'
      });
      return;
    }

    const calc = calculateActivityDates(item.dueDate, item.assignedDate);
    const data: StudentHomeworkItem = {
      ...item,
      calculatedStatus: calc.status,
      daysRemaining: calc.daysRemaining,
      isOverdue: calc.isOverdue,
      isDueSoon: calc.isDueSoon
    };

    res.json({ success: true, data });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * GET /api/guardian/children/:studentId/assignments
 * Fetches assignments for the linked child
 */
guardianRouter.get('/children/:studentId/assignments', requireRole('GUARDIAN', 'SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { studentId } = req.params;
    const { subjectId, status, search, startDate, dueDate } = req.query as {
      subjectId?: string;
      status?: string;
      search?: string;
      startDate?: string;
      dueDate?: string;
    };

    const guardian = resolveAuthenticatedGuardian(req);
    if (!guardian) {
      res.status(404).json({ success: false, error: 'Guardian profile not found.' });
      return;
    }

    if (!isAuthorizedStudentForGuardian(guardian, studentId)) {
      res.status(403).json({ success: false, error: 'Unauthorized access to student assignments.' });
      return;
    }

    const studentSummary = buildChildSummary(studentId);
    if (!studentSummary) {
      res.status(404).json({ success: false, error: 'Student record not found.' });
      return;
    }

    if (!database.assignments) database.assignments = [];

    const rawList = database.assignments.filter((a) => {
      if (a.classId !== studentSummary.classId) return false;
      if (a.sectionId && a.sectionId !== 'ALL' && a.sectionId !== 'all' && a.sectionId !== studentSummary.sectionId) {
        return false;
      }
      if (a.status !== 'published') return false;
      return true;
    });

    let mappedItems: StudentAssignmentItem[] = rawList.map((a) => {
      const calc = calculateActivityDates(a.dueDate, a.startDate);
      return {
        ...a,
        calculatedStatus: calc.status,
        daysRemaining: calc.daysRemaining,
        isOverdue: calc.isOverdue,
        isDueSoon: calc.isDueSoon,
        submissionState: {
          isSubmissionEnabled: false,
          submissionNotice: 'Submissions window is open for scholars. Parents can inspect instructions and submission statuses.',
          maxMarks: a.totalMarks || 100
        }
      };
    });

    const stats = {
      total: mappedItems.length,
      active: mappedItems.filter((a) => a.calculatedStatus === 'active' || a.calculatedStatus === 'upcoming').length,
      dueSoon: mappedItems.filter((a) => a.isDueSoon && !a.isOverdue).length,
      overdue: mappedItems.filter((a) => a.isOverdue).length
    };

    if (subjectId && subjectId !== 'ALL' && subjectId !== 'all') {
      mappedItems = mappedItems.filter((a) => a.subjectId === subjectId);
    }

    if (status && status !== 'ALL' && status !== 'all') {
      const st = status.toLowerCase();
      mappedItems = mappedItems.filter((a) => a.calculatedStatus === st || a.status === st);
    }

    if (startDate) {
      mappedItems = mappedItems.filter((a) => a.startDate === startDate);
    }
    if (dueDate) {
      mappedItems = mappedItems.filter((a) => a.dueDate === dueDate);
    }

    if (search && search.trim()) {
      const q = search.trim().toLowerCase();
      mappedItems = mappedItems.filter(
        (a) =>
          a.title.toLowerCase().includes(q) ||
          a.description.toLowerCase().includes(q) ||
          a.subjectName.toLowerCase().includes(q) ||
          a.teacherName.toLowerCase().includes(q) ||
          (a.attachmentName && a.attachmentName.toLowerCase().includes(q))
      );
    }

    mappedItems.sort((a, b) => {
      if (a.isOverdue && !b.isOverdue) return 1;
      if (!a.isOverdue && b.isOverdue) return -1;
      return a.dueDate.localeCompare(b.dueDate) || b.startDate.localeCompare(a.startDate);
    });

    const subjects = getChildEnrolledSubjects(studentSummary.classId, studentSummary.sectionId);

    const response: GuardianChildAssignmentResponse = {
      student: studentSummary,
      data: mappedItems,
      total: mappedItems.length,
      stats,
      subjects
    };

    res.json({ success: true, data: response });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message, code: 'SERVER_ERROR' });
  }
});

/**
 * GET /api/guardian/children/:studentId/assignments/:id
 * Single assignment detail for the child
 */
guardianRouter.get('/children/:studentId/assignments/:id', requireRole('GUARDIAN', 'SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { studentId, id } = req.params;
    const guardian = resolveAuthenticatedGuardian(req);
    if (!guardian) {
      res.status(404).json({ success: false, error: 'Guardian profile not found.' });
      return;
    }

    if (!isAuthorizedStudentForGuardian(guardian, studentId)) {
      res.status(403).json({ success: false, error: 'Unauthorized access to student assignments.' });
      return;
    }

    const studentSummary = buildChildSummary(studentId);
    if (!studentSummary) {
      res.status(404).json({ success: false, error: 'Student record not found.' });
      return;
    }

    const item = (database.assignments || []).find((a) => a.id === id);
    if (!item || item.status !== 'published') {
      res.status(404).json({ success: false, error: 'Assignment not found or unavailable.', code: 'NOT_FOUND' });
      return;
    }

    const isAuthorized =
      item.classId === studentSummary.classId &&
      (!item.sectionId || item.sectionId === 'ALL' || item.sectionId === 'all' || item.sectionId === studentSummary.sectionId);

    if (!isAuthorized) {
      res.status(403).json({
        success: false,
        error: 'Unauthorized: This assignment belongs to another class or section.',
        code: 'FORBIDDEN_COHORT_ACCESS'
      });
      return;
    }

    const calc = calculateActivityDates(item.dueDate, item.startDate);
    const data: StudentAssignmentItem = {
      ...item,
      calculatedStatus: calc.status,
      daysRemaining: calc.daysRemaining,
      isOverdue: calc.isOverdue,
      isDueSoon: calc.isDueSoon,
      submissionState: {
        isSubmissionEnabled: false,
        submissionNotice: 'Submissions window is open for scholars. Parents can inspect instructions and submission statuses.',
        maxMarks: item.totalMarks || 100
      }
    };

    res.json({ success: true, data });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * GET /api/guardian/children/:studentId/study-materials
 * Fetches study materials shared for the child's class, section, subject
 */
guardianRouter.get('/children/:studentId/study-materials', requireRole('GUARDIAN', 'SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { studentId } = req.params;
    const { subjectId, fileType, search } = req.query as {
      subjectId?: string;
      fileType?: string;
      search?: string;
    };

    const guardian = resolveAuthenticatedGuardian(req);
    if (!guardian) {
      res.status(404).json({ success: false, error: 'Guardian profile not found.' });
      return;
    }

    if (!isAuthorizedStudentForGuardian(guardian, studentId)) {
      res.status(403).json({ success: false, error: 'Unauthorized access to student study materials.' });
      return;
    }

    const studentSummary = buildChildSummary(studentId);
    if (!studentSummary) {
      res.status(404).json({ success: false, error: 'Student record not found.' });
      return;
    }

    if (!database.studyMaterials) database.studyMaterials = [];

    let filtered = database.studyMaterials.filter((m) => {
      if (m.classId !== studentSummary.classId) return false;
      if (m.sectionId && m.sectionId !== 'ALL' && m.sectionId !== 'all' && m.sectionId !== studentSummary.sectionId) {
        return false;
      }
      if (m.status !== 'active') return false;
      return true;
    });

    // Group materials by subject for stats
    const subjectMap = new Map<string, number>();
    filtered.forEach((m) => {
      const count = subjectMap.get(m.subjectName) || 0;
      subjectMap.set(m.subjectName, count + 1);
    });
    const materialsBySubject = Array.from(subjectMap.entries()).map(([subjectName, count]) => ({
      subjectName,
      count
    }));

    const stats = {
      total: filtered.length,
      bySubject: materialsBySubject
    };

    if (subjectId && subjectId !== 'ALL' && subjectId !== 'all') {
      filtered = filtered.filter((m) => m.subjectId === subjectId);
    }

    if (fileType && fileType !== 'ALL' && fileType !== 'all') {
      const ft = fileType.toLowerCase();
      filtered = filtered.filter((m) => m.fileType?.toLowerCase() === ft);
    }

    if (search && search.trim()) {
      const q = search.trim().toLowerCase();
      filtered = filtered.filter(
        (m) =>
          m.title.toLowerCase().includes(q) ||
          m.description.toLowerCase().includes(q) ||
          m.subjectName.toLowerCase().includes(q) ||
          m.teacherName.toLowerCase().includes(q) ||
          m.fileName.toLowerCase().includes(q)
      );
    }

    filtered.sort((a, b) => b.uploadDate.localeCompare(a.uploadDate) || b.createdAt.localeCompare(a.createdAt));

    const subjects = getChildEnrolledSubjects(studentSummary.classId, studentSummary.sectionId);

    const response: GuardianChildMaterialResponse = {
      student: studentSummary,
      data: filtered,
      total: filtered.length,
      stats,
      subjects
    };

    res.json({ success: true, data: response });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message, code: 'SERVER_ERROR' });
  }
});

/**
 * GET /api/guardian/children/:studentId/study-materials/:id
 * Single study material detail
 */
guardianRouter.get('/children/:studentId/study-materials/:id', requireRole('GUARDIAN', 'SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { studentId, id } = req.params;
    const guardian = resolveAuthenticatedGuardian(req);
    if (!guardian) {
      res.status(404).json({ success: false, error: 'Guardian profile not found.' });
      return;
    }

    if (!isAuthorizedStudentForGuardian(guardian, studentId)) {
      res.status(403).json({ success: false, error: 'Unauthorized access.' });
      return;
    }

    const studentSummary = buildChildSummary(studentId);
    if (!studentSummary) {
      res.status(404).json({ success: false, error: 'Student record not found.' });
      return;
    }

    const item = (database.studyMaterials || []).find((m) => m.id === id);
    if (!item || item.status !== 'active') {
      res.status(404).json({ success: false, error: 'Study material not found or archived.', code: 'NOT_FOUND' });
      return;
    }

    const isAuthorized =
      item.classId === studentSummary.classId &&
      (!item.sectionId || item.sectionId === 'ALL' || item.sectionId === 'all' || item.sectionId === studentSummary.sectionId);

    if (!isAuthorized) {
      res.status(403).json({
        success: false,
        error: 'Unauthorized: This study material belongs to another class or section.',
        code: 'FORBIDDEN_COHORT_ACCESS'
      });
      return;
    }

    res.json({ success: true, data: item });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * GET /api/guardian/children/:studentId/announcements
 * Fetches announcements relevant to the child's class and section
 */
guardianRouter.get('/children/:studentId/announcements', requireRole('GUARDIAN', 'SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { studentId } = req.params;
    const { priority, search } = req.query as {
      priority?: string;
      search?: string;
    };

    const guardian = resolveAuthenticatedGuardian(req);
    if (!guardian) {
      res.status(404).json({ success: false, error: 'Guardian profile not found.' });
      return;
    }

    if (!isAuthorizedStudentForGuardian(guardian, studentId)) {
      res.status(403).json({ success: false, error: 'Unauthorized access to student notices.' });
      return;
    }

    const studentSummary = buildChildSummary(studentId);
    if (!studentSummary) {
      res.status(404).json({ success: false, error: 'Student record not found.' });
      return;
    }

    if (!database.classAnnouncements) database.classAnnouncements = [];

    const now = new Date();
    const todayStr = now.toISOString().split('T')[0];

    let filtered = database.classAnnouncements.filter((a) => {
      if (a.status !== 'published') return false;
      if (a.expiresAt && new Date(a.expiresAt) <= now) return false;
      if (a.expiryDate && a.expiryDate < todayStr) return false;

      const aud = a.targetAudience || (a.classId === 'ALL' ? 'SCHOOL_WIDE' : 'CLASS');
      if (aud === 'SCHOOL_WIDE' || aud === 'PARENTS') return true;
      if (aud === 'CUSTOM' && a.targetRoles?.includes('GUARDIAN')) return true;

      if (a.classId === studentSummary.classId || a.classId === 'ALL' || a.classId === 'all') {
        if (!a.sectionId || a.sectionId === 'ALL' || a.sectionId === 'all' || a.sectionId === studentSummary.sectionId) {
          return true;
        }
      }
      return false;
    });

    const stats = {
      total: filtered.length,
      urgentCount: filtered.filter((a) => a.priority === 'urgent').length,
      highCount: filtered.filter((a) => a.priority === 'high').length
    };

    if (priority && priority !== 'ALL' && priority !== 'all') {
      const pr = priority.toLowerCase();
      filtered = filtered.filter((a) => a.priority.toLowerCase() === pr);
    }

    if (search && search.trim()) {
      const q = search.trim().toLowerCase();
      filtered = filtered.filter(
        (a) =>
          a.title.toLowerCase().includes(q) ||
          a.message.toLowerCase().includes(q) ||
          a.teacherName.toLowerCase().includes(q) ||
          a.className.toLowerCase().includes(q) ||
          (a.category && a.category.toLowerCase().includes(q))
      );
    }

    filtered.sort((a, b) => {
      if (a.isPinned && !b.isPinned) return -1;
      if (!a.isPinned && b.isPinned) return 1;
      const dateA = a.publishDate || a.createdAt;
      const dateB = b.publishDate || b.createdAt;
      return dateB.localeCompare(dateA) || b.createdAt.localeCompare(a.createdAt);
    });

    // Decorate with guardian's user read receipts
    const decorated = filtered.map((a) => ({
      ...a,
      isRead: !!(a.readReceipts && a.readReceipts.some((r) => r.userId === req.user?.id)),
      readAt: a.readReceipts?.find((r) => r.userId === req.user?.id)?.readAt
    }));

    const response = {
      student: studentSummary,
      data: decorated,
      total: decorated.length,
      stats
    };

    res.json({ success: true, data: response });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message, code: 'SERVER_ERROR' });
  }
});

/**
 * GET /api/guardian/children/:studentId/announcements/:id
 * Single announcement detail
 */
guardianRouter.get('/children/:studentId/announcements/:id', requireRole('GUARDIAN', 'SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { studentId, id } = req.params;
    const guardian = resolveAuthenticatedGuardian(req);
    if (!guardian) {
      res.status(404).json({ success: false, error: 'Guardian profile not found.' });
      return;
    }

    if (!isAuthorizedStudentForGuardian(guardian, studentId)) {
      res.status(403).json({ success: false, error: 'Unauthorized access.' });
      return;
    }

    const studentSummary = buildChildSummary(studentId);
    if (!studentSummary) {
      res.status(404).json({ success: false, error: 'Student record not found.' });
      return;
    }

    const item = (database.classAnnouncements || []).find((a) => a.id === id);
    if (!item || item.status !== 'published') {
      res.status(404).json({ success: false, error: 'Announcement not found or archived.', code: 'NOT_FOUND' });
      return;
    }

    const aud = item.targetAudience || (item.classId === 'ALL' ? 'SCHOOL_WIDE' : 'CLASS');
    const isAuthorized =
      aud === 'SCHOOL_WIDE' ||
      aud === 'PARENTS' ||
      (aud === 'CUSTOM' && item.targetRoles?.includes('GUARDIAN')) ||
      item.classId === 'ALL' ||
      (item.classId === studentSummary.classId &&
        (!item.sectionId || item.sectionId === 'ALL' || item.sectionId === 'all' || item.sectionId === studentSummary.sectionId));

    if (!isAuthorized) {
      res.status(403).json({
        success: false,
        error: 'Unauthorized: This announcement belongs to another class or section.',
        code: 'FORBIDDEN_COHORT_ACCESS'
      });
      return;
    }

    // Auto mark as read for guardian
    if (!item.readReceipts) item.readReceipts = [];
    if (req.user?.id && !item.readReceipts.some((r) => r.userId === req.user?.id)) {
      item.readReceipts.push({
        userId: req.user.id,
        userName: req.user.name,
        userRole: req.user.role,
        readAt: new Date().toISOString()
      });
    }

    const isRead = !!(item.readReceipts && item.readReceipts.some((r) => r.userId === req.user?.id));

    res.json({
      success: true,
      data: {
        ...item,
        isRead,
        readAt: item.readReceipts?.find((r) => r.userId === req.user?.id)?.readAt
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * POST /api/guardian/children/:studentId/announcements/:id/read
 * Mark an announcement as read by the authenticated guardian
 */
guardianRouter.post('/children/:studentId/announcements/:id/read', requireRole('GUARDIAN', 'SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { studentId, id } = req.params;
    const guardian = resolveAuthenticatedGuardian(req);
    if (!guardian) {
      res.status(404).json({ success: false, error: 'Guardian profile not found.' });
      return;
    }

    if (!isAuthorizedStudentForGuardian(guardian, studentId)) {
      res.status(403).json({ success: false, error: 'Unauthorized access to student notices.' });
      return;
    }

    if (!req.user) {
      res.status(401).json({ success: false, error: 'Authentication required.' });
      return;
    }

    const updated = AnnouncementService.markAsRead(id, req.user);
    if (!updated) {
      res.status(404).json({ success: false, error: 'Announcement not found.' });
      return;
    }

    res.json({ success: true, message: 'Announcement marked as read.', data: updated });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * GET /api/guardian/children/:studentId/activities-summary
 * Aggregated academic activities summary for the selected child
 */
guardianRouter.get('/children/:studentId/activities-summary', requireRole('GUARDIAN', 'SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { studentId } = req.params;
    const guardian = resolveAuthenticatedGuardian(req);
    if (!guardian) {
      res.status(404).json({ success: false, error: 'Guardian profile not found.' });
      return;
    }

    if (!isAuthorizedStudentForGuardian(guardian, studentId)) {
      res.status(403).json({ success: false, error: 'Unauthorized access to student activities summary.' });
      return;
    }

    const studentSummary = buildChildSummary(studentId);
    if (!studentSummary) {
      res.status(404).json({ success: false, error: 'Student record not found.' });
      return;
    }

    const hwList = (database.homework || []).filter(
      (h) =>
        h.classId === studentSummary.classId &&
        (!h.sectionId || h.sectionId === 'ALL' || h.sectionId === 'all' || h.sectionId === studentSummary.sectionId) &&
        h.status === 'published'
    );

    const asgList = (database.assignments || []).filter(
      (a) =>
        a.classId === studentSummary.classId &&
        (!a.sectionId || a.sectionId === 'ALL' || a.sectionId === 'all' || a.sectionId === studentSummary.sectionId) &&
        a.status === 'published'
    );

    const matList = (database.studyMaterials || []).filter(
      (m) =>
        m.classId === studentSummary.classId &&
        (!m.sectionId || m.sectionId === 'ALL' || m.sectionId === 'all' || m.sectionId === studentSummary.sectionId) &&
        m.status === 'active'
    );

    const annList = (database.classAnnouncements || []).filter(
      (a) =>
        (a.classId === studentSummary.classId || a.classId === 'ALL') &&
        (!a.sectionId || a.sectionId === 'ALL' || a.sectionId === 'all' || a.sectionId === studentSummary.sectionId) &&
        a.status === 'published'
    );

    let hwActive = 0, hwDueSoon = 0, hwOverdue = 0;
    const upcomingDeadlines: StudentActivitiesSummary['upcomingDeadlines'] = [];

    hwList.forEach((h) => {
      const calc = calculateActivityDates(h.dueDate, h.assignedDate);
      if (calc.isOverdue) hwOverdue++;
      else if (calc.isDueSoon) hwDueSoon++;
      else hwActive++;

      upcomingDeadlines.push({
        id: h.id,
        type: 'homework',
        title: h.title,
        subjectName: h.subjectName,
        dueDate: h.dueDate,
        daysRemaining: calc.daysRemaining,
        isDueSoon: calc.isDueSoon,
        isOverdue: calc.isOverdue
      });
    });

    let asgActive = 0, asgDueSoon = 0, asgOverdue = 0;
    asgList.forEach((a) => {
      const calc = calculateActivityDates(a.dueDate, a.startDate);
      if (calc.isOverdue) asgOverdue++;
      else if (calc.isDueSoon) asgDueSoon++;
      else asgActive++;

      upcomingDeadlines.push({
        id: a.id,
        type: 'assignment',
        title: a.title,
        subjectName: a.subjectName,
        dueDate: a.dueDate,
        daysRemaining: calc.daysRemaining,
        isDueSoon: calc.isDueSoon,
        isOverdue: calc.isOverdue
      });
    });

    upcomingDeadlines.sort((a, b) => {
      if (a.isOverdue && !b.isOverdue) return 1;
      if (!a.isOverdue && b.isOverdue) return -1;
      return a.dueDate.localeCompare(b.dueDate);
    });

    const subjectMap = new Map<string, number>();
    matList.forEach((m) => {
      const count = subjectMap.get(m.subjectName) || 0;
      subjectMap.set(m.subjectName, count + 1);
    });
    const materialsBySubject = Array.from(subjectMap.entries()).map(([subjectName, count]) => ({
      subjectName,
      count
    }));

    const summary: StudentActivitiesSummary = {
      homework: {
        total: hwList.length,
        active: hwActive,
        dueSoon: hwDueSoon,
        overdue: hwOverdue
      },
      assignments: {
        total: asgList.length,
        active: asgActive,
        dueSoon: asgDueSoon,
        overdue: asgOverdue
      },
      materials: {
        total: matList.length,
        bySubject: materialsBySubject
      },
      announcements: {
        total: annList.length,
        urgentCount: annList.filter((a) => a.priority === 'urgent').length,
        highCount: annList.filter((a) => a.priority === 'high').length
      },
      upcomingDeadlines: upcomingDeadlines.slice(0, 5)
    };

    const response: GuardianChildActivitiesSummaryResponse = {
      student: studentSummary,
      summary
    };

    res.json({ success: true, data: response });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message, code: 'SERVER_ERROR' });
  }
});

// =========================================================================
// PART 5E: GUARDIAN EXAMINATIONS, RESULTS & ACADEMIC PROGRESS ENDPOINTS
// =========================================================================

/**
 * Helper to calculate grade and grade point from percentage against institutional scale
 */
function calculateGradeFromScale(percentage: number, scale: GradingScaleItem[] = []): { grade: string; gradePoint: number; isPassing: boolean; description: string } {
  const activeScale = scale.length > 0 ? scale : database.gradingScale || [];
  const matched = activeScale.find(
    (g) => percentage >= g.minPercentage && percentage <= g.maxPercentage
  );

  if (matched) {
    return {
      grade: matched.grade,
      gradePoint: matched.gradePoint,
      isPassing: matched.isPassing,
      description: matched.description
    };
  }

  if (percentage >= 90) return { grade: 'A+', gradePoint: 4.0, isPassing: true, description: 'Outstanding' };
  if (percentage >= 80) return { grade: 'A', gradePoint: 3.7, isPassing: true, description: 'Excellent' };
  if (percentage >= 75) return { grade: 'B+', gradePoint: 3.3, isPassing: true, description: 'Very Good' };
  if (percentage >= 70) return { grade: 'B', gradePoint: 3.0, isPassing: true, description: 'Good' };
  if (percentage >= 60) return { grade: 'C+', gradePoint: 2.3, isPassing: true, description: 'Average' };
  if (percentage >= 50) return { grade: 'C', gradePoint: 2.0, isPassing: true, description: 'Satisfactory' };
  if (percentage >= 40) return { grade: 'D', gradePoint: 1.0, isPassing: true, description: 'Pass' };
  return { grade: 'F', gradePoint: 0.0, isPassing: false, description: 'Fail' };
}

/**
 * GET /api/guardian/children/:studentId/examinations
 * Returns exam schedule strictly scoped to the selected child's class and section
 */
guardianRouter.get('/children/:studentId/examinations', requireRole('GUARDIAN', 'SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { studentId } = req.params;
    const guardian = resolveAuthenticatedGuardian(req);
    if (!guardian) {
      res.status(404).json({ success: false, error: 'Guardian profile not found.' });
      return;
    }

    // Security Check: Guardian must have this student linked
    if (!isAuthorizedStudentForGuardian(guardian, studentId)) {
      logAudit({
        userId: req.user!.id,
        userRole: req.user!.role,
        action: 'UNAUTHORIZED_GUARDIAN_EXAM_ACCESS_ATTEMPT',
        entityType: 'ExamSchedule',
        entityId: studentId,
        details: `Security Alert: Guardian ${guardian.name} (${guardian.id}) attempted unauthorized access to exam schedule of unlinked student ${studentId}.`,
        ipAddress: req.ip || '127.0.0.1'
      });

      res.status(403).json({
        success: false,
        error: 'Unauthorized: You are only permitted to view examination schedules for your linked children.',
        code: 'FORBIDDEN_STUDENT_ACCESS'
      });
      return;
    }

    const studentSummary = buildChildSummary(studentId);
    if (!studentSummary) {
      res.status(404).json({ success: false, error: 'Student record not found.' });
      return;
    }

    const {
      academicSessionId,
      examId,
      subjectId,
      status,
      search
    } = req.query as ExamScheduleFilterParams;

    const allSchedules = database.examSchedules || [];

    // Cohort isolation: Only show exams matching the child's class and section (or ALL)
    let filtered = allSchedules.filter((item) => {
      const classMatch = item.classId === studentSummary.classId;
      const sectionMatch =
        !item.sectionId ||
        item.sectionId === 'ALL' ||
        item.sectionId === 'all' ||
        item.sectionId === studentSummary.sectionId;

      return classMatch && sectionMatch;
    });

    // Session filter
    if (academicSessionId && academicSessionId !== 'ALL') {
      filtered = filtered.filter((item) => item.academicSessionId === academicSessionId);
    } else if (req.query.academicSessionId === undefined) {
      // Default to child's active session or current active session if not explicitly requested
      const targetSessionId = studentSummary.academicSessionId || 'session-2026-2027';
      filtered = filtered.filter(
        (item) => item.academicSessionId === targetSessionId || item.academicSessionId === 'session-2026-2027'
      );
    }

    // Exam ID filter
    if (examId && examId !== 'ALL') {
      filtered = filtered.filter((item) => item.examId === examId);
    }

    // Subject filter
    if (subjectId && subjectId !== 'ALL') {
      filtered = filtered.filter((item) => item.subjectId === subjectId);
    }

    // Status filter
    if (status && status !== 'ALL') {
      filtered = filtered.filter((item) => item.status === status);
    }

    // Search filter
    if (search && search.trim()) {
      const q = search.toLowerCase().trim();
      filtered = filtered.filter(
        (item) =>
          item.examName.toLowerCase().includes(q) ||
          item.subjectName.toLowerCase().includes(q) ||
          item.subjectCode.toLowerCase().includes(q) ||
          (item.roomNumber && item.roomNumber.toLowerCase().includes(q)) ||
          (item.instructions && item.instructions.toLowerCase().includes(q))
      );
    }

    // Sort by exam date ascending, then start time
    filtered.sort((a, b) => {
      const dateCmp = a.examDate.localeCompare(b.examDate);
      if (dateCmp !== 0) return dateCmp;
      return a.startTime.localeCompare(b.startTime);
    });

    // Compute stats
    const stats = {
      total: filtered.length,
      scheduled: filtered.filter((s) => s.status === 'scheduled').length,
      ongoing: filtered.filter((s) => s.status === 'ongoing').length,
      completed: filtered.filter((s) => s.status === 'completed').length
    };

    // Extract available filter sessions and exams
    const availableSessions = (database.academicSessions || []).map((s) => ({
      id: s.id,
      name: s.sessionName,
      isActive: s.isActive ?? false
    }));

    const availableExamsMap = new Map<string, { id: string; name: string; type: string }>();
    allSchedules.forEach((s) => {
      if (!availableExamsMap.has(s.examId)) {
        availableExamsMap.set(s.examId, { id: s.examId, name: s.examName, type: s.examType });
      }
    });
    const availableExams = Array.from(availableExamsMap.values());

    const subjectsInCohort = database.subjects.filter(
      (s) => s.classId === studentSummary.classId || s.classIds?.includes(studentSummary.classId)
    );
    const availableSubjects = subjectsInCohort.map((s) => ({
      id: s.id,
      name: s.name,
      code: s.code
    }));

    logAudit({
      userId: req.user!.id,
      userRole: req.user!.role,
      action: 'VIEW_CHILD_EXAM_SCHEDULE',
      entityType: 'ExamSchedule',
      entityId: studentId,
      details: `Guardian ${guardian.name} viewed exam schedule for child ${studentSummary.name} (${filtered.length} exams matched).`,
      ipAddress: req.ip || '127.0.0.1'
    });

    const response: GuardianChildExaminationsResponse = {
      student: studentSummary,
      data: filtered,
      total: filtered.length,
      stats,
      availableSessions,
      availableExams,
      availableSubjects
    };

    res.json({ success: true, data: response });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message, code: 'SERVER_ERROR' });
  }
});

/**
 * GET /api/guardian/children/:studentId/examinations/:examScheduleId
 * Single exam schedule details with verification
 */
guardianRouter.get('/children/:studentId/examinations/:examScheduleId', requireRole('GUARDIAN', 'SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { studentId, examScheduleId } = req.params;
    const guardian = resolveAuthenticatedGuardian(req);
    if (!guardian) {
      res.status(404).json({ success: false, error: 'Guardian profile not found.' });
      return;
    }

    if (!isAuthorizedStudentForGuardian(guardian, studentId)) {
      res.status(403).json({ success: false, error: 'Unauthorized child access.' });
      return;
    }

    const studentSummary = buildChildSummary(studentId);
    if (!studentSummary) {
      res.status(404).json({ success: false, error: 'Student record not found.' });
      return;
    }

    const item = (database.examSchedules || []).find((s) => s.id === examScheduleId);
    if (!item) {
      res.status(404).json({ success: false, error: 'Exam schedule entry not found.', code: 'NOT_FOUND' });
      return;
    }

    const isAuthorized =
      item.classId === studentSummary.classId &&
      (!item.sectionId || item.sectionId === 'ALL' || item.sectionId === 'all' || item.sectionId === studentSummary.sectionId);

    if (!isAuthorized) {
      res.status(403).json({
        success: false,
        error: 'Unauthorized: This exam does not pertain to the student’s class cohort.',
        code: 'FORBIDDEN_COHORT_ACCESS'
      });
      return;
    }

    res.json({ success: true, student: studentSummary, data: item });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * GET /api/guardian/children/:studentId/results
 * Returns real published examination results for the selected child with history & filters
 */
guardianRouter.get('/children/:studentId/results', requireRole('GUARDIAN', 'SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { studentId } = req.params;
    const guardian = resolveAuthenticatedGuardian(req);
    if (!guardian) {
      res.status(404).json({ success: false, error: 'Guardian profile not found.' });
      return;
    }

    // Security check: Guardian must have student linked
    if (!isAuthorizedStudentForGuardian(guardian, studentId)) {
      logAudit({
        userId: req.user!.id,
        userRole: req.user!.role,
        action: 'UNAUTHORIZED_GUARDIAN_RESULT_ACCESS_ATTEMPT',
        entityType: 'StudentExamResult',
        entityId: studentId,
        details: `Security Alert: Guardian ${guardian.name} (${guardian.id}) attempted unauthorized access to exam results of unlinked student ${studentId}.`,
        ipAddress: req.ip || '127.0.0.1'
      });

      res.status(403).json({
        success: false,
        error: 'Unauthorized: You are only permitted to view examination results for your linked children.',
        code: 'FORBIDDEN_STUDENT_ACCESS'
      });
      return;
    }

    const studentSummary = buildChildSummary(studentId);
    if (!studentSummary) {
      res.status(404).json({ success: false, error: 'Student record not found.' });
      return;
    }

    const {
      academicSessionId,
      examId,
      academicYear,
      search
    } = req.query as StudentResultsFilterParams;

    const allResults = database.examResults || [];

    // Security: Only return published results belonging to this student
    let filtered = allResults.filter(
      (r) =>
        (r.studentId === studentId || r.userId === studentSummary.userId) &&
        r.isPublished &&
        r.workflowStatus === 'PUBLISHED'
    );

    // Session filter
    if (academicSessionId && academicSessionId !== 'ALL') {
      filtered = filtered.filter((r) => r.academicSessionId === academicSessionId);
    }

    // Academic Year filter
    if (academicYear && academicYear !== 'ALL') {
      filtered = filtered.filter((r) => r.academicYear === academicYear);
    }

    // Exam filter
    if (examId && examId !== 'ALL') {
      filtered = filtered.filter((r) => r.examId === examId);
    }

    // Search query
    if (search && search.trim()) {
      const q = search.toLowerCase().trim();
      filtered = filtered.filter(
        (r) =>
          r.examName.toLowerCase().includes(q) ||
          r.term.toLowerCase().includes(q) ||
          r.academicYear.toLowerCase().includes(q) ||
          r.subjectScores.some(
            (s) =>
              s.subjectName.toLowerCase().includes(q) ||
              s.subjectCode.toLowerCase().includes(q) ||
              s.grade.toLowerCase().includes(q)
          )
      );
    }

    // Sort descending by publishDate
    filtered.sort((a, b) => b.publishDate.localeCompare(a.publishDate));

    // Summary calculation
    const allChildResults = allResults
      .filter(
        (r) =>
          (r.studentId === studentId || r.userId === studentSummary.userId) &&
          r.isPublished &&
          r.workflowStatus === 'PUBLISHED'
      )
      .sort((a, b) => b.publishDate.localeCompare(a.publishDate));

    const latestResult = allChildResults.length > 0 ? allChildResults[0] : null;
    const totalExamsTaken = allChildResults.length;
    const totalGpaSum = allChildResults.reduce((acc, curr) => acc + curr.summary.gpa, 0);
    const cumulativeGPA =
      totalExamsTaken > 0 ? parseFloat((totalGpaSum / totalExamsTaken).toFixed(2)) : 0;
    const currentSessionGPA = latestResult ? latestResult.summary.gpa : 0;

    let overallGrade = 'N/A';
    let academicStanding = 'Good Standing';
    if (cumulativeGPA > 0) {
      const gradeInfo = calculateGradeFromScale((cumulativeGPA / 4.0) * 100);
      overallGrade = gradeInfo.grade;
      if (cumulativeGPA >= 3.8) academicStanding = 'High Honors / Distinction';
      else if (cumulativeGPA >= 3.5) academicStanding = 'Honors Standing';
      else if (cumulativeGPA >= 3.0) academicStanding = 'Satisfactory Progress';
      else academicStanding = 'Academic Review';
    }

    // Available sessions & exams for dropdown filters
    const availableSessions = Array.from(
      new Set(
        allChildResults.map((r) => JSON.stringify({ id: r.academicSessionId, name: r.academicSessionName, year: r.academicYear }))
      )
    ).map((s) => JSON.parse(s));

    const availableExams = Array.from(
      new Set(
        allChildResults.map((r) => JSON.stringify({ id: r.examId, name: r.examName, type: r.examType }))
      )
    ).map((e) => JSON.parse(e));

    const availableYears = Array.from(
      new Set(allChildResults.map((r) => r.academicYear))
    );

    logAudit({
      userId: req.user!.id,
      userRole: req.user!.role,
      action: 'VIEW_CHILD_EXAM_RESULTS',
      entityType: 'StudentExamResult',
      entityId: studentId,
      details: `Guardian ${guardian.name} viewed examination results for child ${studentSummary.name} (${filtered.length} results returned).`,
      ipAddress: req.ip || '127.0.0.1'
    });

    const response: GuardianChildResultsResponse = {
      student: studentSummary,
      data: filtered,
      total: filtered.length,
      summary: {
        latestResult,
        totalExamsTaken,
        cumulativeGPA,
        currentSessionGPA,
        overallGrade,
        academicStanding
      },
      availableSessions,
      availableExams,
      availableYears
    };

    res.json({ success: true, data: response });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message, code: 'SERVER_ERROR' });
  }
});

/**
 * GET /api/guardian/children/:studentId/results/:resultId
 * Returns single detailed exam result report card with subject score breakdown
 */
guardianRouter.get('/children/:studentId/results/:resultId', requireRole('GUARDIAN', 'SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { studentId, resultId } = req.params;
    const guardian = resolveAuthenticatedGuardian(req);
    if (!guardian) {
      res.status(404).json({ success: false, error: 'Guardian profile not found.' });
      return;
    }

    if (!isAuthorizedStudentForGuardian(guardian, studentId)) {
      res.status(403).json({ success: false, error: 'Unauthorized child access.' });
      return;
    }

    const studentSummary = buildChildSummary(studentId);
    if (!studentSummary) {
      res.status(404).json({ success: false, error: 'Student record not found.' });
      return;
    }

    const result = (database.examResults || []).find((r) => r.id === resultId);
    if (!result) {
      res.status(404).json({ success: false, error: 'Exam result report not found.', code: 'NOT_FOUND' });
      return;
    }

    // Strict Security Ownership Verification
    const isOwner =
      result.studentId === studentId ||
      result.userId === studentSummary.userId ||
      req.user!.role === 'SUPER_ADMIN';

    if (!isOwner) {
      logAudit({
        userId: req.user!.id,
        userRole: req.user!.role,
        action: 'UNAUTHORIZED_RESULT_VIEW_ATTEMPT',
        entityType: 'StudentExamResult',
        entityId: resultId,
        details: `Security Violation: Guardian ${guardian.name} attempted to view result ${resultId} belonging to another student ${result.studentName} (${result.studentId}). Access denied.`,
        ipAddress: req.ip || '127.0.0.1'
      });

      res.status(403).json({
        success: false,
        error: 'Access Denied: You do not have permission to view confidential examination results belonging to another student.',
        code: 'FORBIDDEN_RESULT_ACCESS'
      });
      return;
    }

    if ((!result.isPublished || result.workflowStatus !== 'PUBLISHED') && req.user!.role !== 'SUPER_ADMIN') {
      res.status(403).json({
        success: false,
        error: 'Access Denied: This examination result is currently pending institutional review and has not yet been published.',
        code: 'RESULT_NOT_PUBLISHED'
      });
      return;
    }

    res.json({ success: true, student: studentSummary, data: result });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * GET /api/guardian/children/:studentId/results/:resultId/report-card
 * Full institutional report card payload (reusing official Part 6F schema)
 * Strictly published-only, authenticated parent IDOR protection
 */
guardianRouter.get(
  '/children/:studentId/results/:resultId/report-card',
  requireRole('GUARDIAN', 'SUPER_ADMIN'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const { studentId, resultId } = req.params;
      const guardian = resolveAuthenticatedGuardian(req);
      if (!guardian) {
        res.status(404).json({ success: false, error: 'Guardian profile not found.' });
        return;
      }

      if (!isAuthorizedStudentForGuardian(guardian, studentId)) {
        logAudit({
          userId: req.user!.id,
          userRole: req.user!.role,
          action: 'UNAUTHORIZED_REPORT_CARD_ACCESS_ATTEMPT',
          entityType: 'ReportCard',
          entityId: resultId,
          details: `Security Violation: Guardian ${guardian.name} (${guardian.id}) attempted to view report card for unauthorized student ${studentId}.`,
          ipAddress: req.ip || '127.0.0.1'
        });

        res.status(403).json({
          success: false,
          error: 'Access Denied: You do not have permission to view confidential report cards for this student.',
          code: 'FORBIDDEN_REPORT_CARD_ACCESS'
        });
        return;
      }

      const result = (database.examResults || []).find((r) => r.id === resultId);
      if (!result) {
        res.status(404).json({ success: false, error: 'Examination result record not found.' });
        return;
      }

      const studentSummary = buildChildSummary(studentId);
      if (!studentSummary) {
        res.status(404).json({ success: false, error: 'Student record not found in guardian portfolio.' });
        return;
      }

      // Ensure result belongs to the requested student
      if (result.studentId !== studentId && result.userId !== studentSummary.userId) {
        logAudit({
          userId: req.user!.id,
          userRole: req.user!.role,
          action: 'UNAUTHORIZED_RESULT_VIEW_ATTEMPT',
          entityType: 'ReportCard',
          entityId: resultId,
          details: `Security Violation: Guardian ${guardian.name} attempted to view report card ${resultId} belonging to another student ${result.studentName} (${result.studentId}). Access denied.`,
          ipAddress: req.ip || '127.0.0.1'
        });

        res.status(403).json({
          success: false,
          error: 'Access Denied: You do not have permission to view confidential examination results belonging to another student.',
          code: 'FORBIDDEN_RESULT_ACCESS'
        });
        return;
      }

      // Strictly published results only
      if ((!result.isPublished || result.workflowStatus !== 'PUBLISHED') && req.user!.role !== 'SUPER_ADMIN') {
        res.status(403).json({
          success: false,
          error: 'Access Denied: This examination result is currently pending institutional review and has not yet been published.',
          code: 'RESULT_NOT_PUBLISHED'
        });
        return;
      }

      // Resolve student profile
      const studentProfile = (database.studentProfiles || []).find(
        (s) => s.id === result.studentId || s.userId === result.userId
      );

      // Resolve Attendance stats
      const attendanceRecords = (database.attendanceRecords || []).filter(
        (a) => a.studentId === result.studentId
      );
      const totalWorkingDays = attendanceRecords.length > 0 ? attendanceRecords.length : 90;
      const presentDays = attendanceRecords.length > 0
        ? attendanceRecords.filter((a) => a.status === 'PRESENT').length
        : 86;
      const absentDays = attendanceRecords.length > 0
        ? attendanceRecords.filter((a) => a.status === 'ABSENT').length
        : 3;
      const lateDays = attendanceRecords.length > 0
        ? attendanceRecords.filter((a) => a.status === 'LATE').length
        : 1;
      const attendancePercentage = Number(((presentDays / totalWorkingDays) * 100).toFixed(1));

      // Resolve School Settings
      const school = database.schoolSettings || {
        schoolName: 'Sygmate International Academy',
        name: 'Sygmate International Academy',
        address: '450 Innovation Parkway, Suite 100, Cambridge, MA 02142',
        phone: '+1 (800) 555-0199',
        email: 'academics@sygmate.edu',
        website: 'https://sygmate-school.edu',
        affiliationNumber: 'MA-EDU-88291',
        motto: 'Excellence in Academic Mastery & Ethical Leadership',
        principalName: 'Dr. Evelyn Montgomery'
      };

      const gradingScale = (database.gradingScale && database.gradingScale.length > 0)
        ? database.gradingScale
        : [
            { id: '1', grade: 'A+', minPercentage: 90, maxPercentage: 100, gradePoint: 4.0, description: 'Outstanding', isPassing: true },
            { id: '2', grade: 'A', minPercentage: 80, maxPercentage: 89.99, gradePoint: 3.75, description: 'Excellent', isPassing: true },
            { id: '3', grade: 'B+', minPercentage: 70, maxPercentage: 79.99, gradePoint: 3.5, description: 'Very Good', isPassing: true },
            { id: '4', grade: 'B', minPercentage: 60, maxPercentage: 69.99, gradePoint: 3.0, description: 'Good', isPassing: true },
            { id: '5', grade: 'C', minPercentage: 50, maxPercentage: 59.99, gradePoint: 2.0, description: 'Average', isPassing: true },
            { id: '6', grade: 'D', minPercentage: 40, maxPercentage: 49.99, gradePoint: 1.0, description: 'Pass', isPassing: true },
            { id: '7', grade: 'F', minPercentage: 0, maxPercentage: 39.99, gradePoint: 0.0, description: 'Fail', isPassing: false }
          ];

      const classResults = (database.examResults || []).filter(
        (r) => r.examId === result.examId && r.classId === result.classId
      );
      const sectionResults = (database.examResults || []).filter(
        (r) => r.examId === result.examId && r.sectionId === result.sectionId
      );

      const reportCard = {
        result,
        school: {
          name: (school as any).name || (school as any).schoolName || 'Sygmate International Academy',
          address: (school as any).address || '450 Innovation Parkway, Suite 100, Cambridge, MA 02142',
          phone: (school as any).phone || (school as any).contactPhone || '+1 (800) 555-0199',
          email: (school as any).email || (school as any).contactEmail || 'academics@sygmate.edu',
          website: (school as any).website || 'https://sygmate-school.edu',
          logoUrl: (school as any).logoUrl,
          affiliationNumber: (school as any).affiliationNumber || 'MA-EDU-88291',
          motto: (school as any).motto || (school as any).tagline || 'Excellence in Academic Mastery & Ethical Leadership',
          principalName: (school as any).principalName || 'Dr. Evelyn Montgomery'
        },
        student: {
          id: result.studentId,
          name: result.studentName,
          admissionNumber: result.admissionNumber,
          rollNumber: result.rollNumber,
          className: result.className,
          sectionName: result.sectionName,
          academicSessionName: result.academicSessionName,
          guardianName: guardian.name,
          dateOfBirth: studentProfile?.dateOfBirth,
          bloodGroup: studentProfile?.bloodGroup,
          avatarUrl: studentProfile?.avatarUrl
        },
        gradingScale,
        attendance: {
          totalWorkingDays,
          presentDays,
          absentDays,
          lateDays,
          attendancePercentage
        },
        merit: {
          classRank: result.summary.classRank,
          totalClassStudents: result.summary.totalStudentsInClass || classResults.length || 28,
          sectionRank: result.summary.sectionRank,
          totalSectionStudents: result.summary.totalStudentsInSection || sectionResults.length || 28,
          overallRank: result.summary.overallRank,
          isTied: result.summary.rankTie || false
        },
        teacherRemarks:
          result.academicProgressNotes ||
          (result.summary.gpa >= 3.8
            ? 'Exceptional academic discipline, critical inquiry, and analytical synthesis across all examination components.'
            : result.summary.gpa >= 3.0
            ? 'Commendable performance and steady conceptual comprehension. Continues to show notable academic capability.'
            : 'Satisfactory effort demonstrated. Targeted focus on core foundational coursework recommended for the upcoming term.'),
        principalRemarks:
          result.summary.resultStatus === 'DISTINCTION' || result.summary.resultStatus === 'PASSED'
            ? 'The scholar has fulfilled the rigorous assessment criteria established by the Academic Council and is certified in good academic standing.'
            : 'Academic standing is currently under review by the Academic Standards Committee.',
        issueDate: result.publishDate || new Date().toISOString().split('T')[0],
        verificationHash: `SIG-REP-${result.id.toUpperCase()}-${result.studentId.slice(-4).toUpperCase()}`,
        isOfficial: true
      };

      logAudit({
        userId: req.user!.id,
        userRole: req.user!.role,
        action: 'VIEW_CHILD_REPORT_CARD',
        entityType: 'ReportCard',
        entityId: resultId,
        details: `Guardian ${guardian.name} viewed official institutional report card for student ${studentSummary.name} (Exam: ${result.examName}).`,
        ipAddress: req.ip || '127.0.0.1'
      });

      res.json({ success: true, data: reportCard });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  }
);

/**
 * GET /api/guardian/children/:studentId/progress
 * Comprehensive academic progress overview with subject trends, exam trends, attendance correlation
 */
guardianRouter.get('/children/:studentId/progress', requireRole('GUARDIAN', 'SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { studentId } = req.params;
    const guardian = resolveAuthenticatedGuardian(req);
    if (!guardian) {
      res.status(404).json({ success: false, error: 'Guardian profile not found.' });
      return;
    }

    if (!isAuthorizedStudentForGuardian(guardian, studentId)) {
      logAudit({
        userId: req.user!.id,
        userRole: req.user!.role,
        action: 'UNAUTHORIZED_GUARDIAN_PROGRESS_ACCESS_ATTEMPT',
        entityType: 'AcademicProgress',
        entityId: studentId,
        details: `Security Alert: Guardian ${guardian.name} attempted unauthorized access to academic progress of unlinked student ${studentId}.`,
        ipAddress: req.ip || '127.0.0.1'
      });

      res.status(403).json({
        success: false,
        error: 'Unauthorized access to student academic progress.',
        code: 'FORBIDDEN_STUDENT_ACCESS'
      });
      return;
    }

    const studentSummary = buildChildSummary(studentId);
    if (!studentSummary) {
      res.status(404).json({ success: false, error: 'Student record not found.' });
      return;
    }

    const myResults = (database.examResults || [])
      .filter(
        (r) =>
          (r.studentId === studentId || r.userId === studentSummary.userId) &&
          r.isPublished &&
          r.workflowStatus === 'PUBLISHED'
      )
      .sort((a, b) => a.publishDate.localeCompare(b.publishDate)); // Chronological for trend calculation

    // 1. Attendance Metrics
    const attendanceRecords = (database.attendanceRecords || []).filter(
      (r) => r.studentId === studentId || r.userId === studentSummary.userId
    );

    const totalAttendanceDays = attendanceRecords.length;
    const presentCount = attendanceRecords.filter((r) => r.status === 'PRESENT').length;
    const absentCount = attendanceRecords.filter((r) => r.status === 'ABSENT').length;
    const lateCount = attendanceRecords.filter((r) => r.status === 'LATE').length;
    const halfDayCount = attendanceRecords.filter((r) => r.status === 'HALF_DAY').length;
    const attendancePercentage =
      totalAttendanceDays > 0
        ? Math.round(((presentCount + lateCount + (halfDayCount * 0.5)) / totalAttendanceDays) * 1000) / 10
        : 95.0;

    // 2. Subject Performance Trends
    const subjectMap = new Map<
      string,
      {
        subjectId: string;
        subjectName: string;
        subjectCode: string;
        credits: number;
        scores: Array<{
          examId: string;
          examName: string;
          examDate: string;
          academicSessionName: string;
          obtainedMarks: number;
          fullMarks: number;
          percentage: number;
          grade: string;
          gradePoint: number;
        }>;
      }
    >();

    myResults.forEach((resItem) => {
      resItem.subjectScores.forEach((score) => {
        const key = score.subjectCode || score.subjectName;
        if (!subjectMap.has(key)) {
          subjectMap.set(key, {
            subjectId: score.subjectId,
            subjectName: score.subjectName,
            subjectCode: score.subjectCode,
            credits: score.credits || 3,
            scores: []
          });
        }

        const entry = subjectMap.get(key)!;
        entry.scores.push({
          examId: resItem.examId,
          examName: resItem.examName,
          examDate: resItem.publishDate,
          academicSessionName: resItem.academicSessionName,
          obtainedMarks: score.obtainedMarks,
          fullMarks: score.fullMarks,
          percentage: score.percentage,
          grade: score.grade,
          gradePoint: score.gradePoint
        });
      });
    });

    const subjectPerformances: SubjectPerformanceTrend[] = Array.from(subjectMap.values()).map((item) => {
      const totalMarks = item.scores.reduce((acc, curr) => acc + curr.percentage, 0);
      const averageMarks = parseFloat((totalMarks / item.scores.length).toFixed(1));
      const highestMarks = Math.max(...item.scores.map((s) => s.obtainedMarks));
      const latestScore = item.scores[item.scores.length - 1];

      let trend: 'improving' | 'stable' | 'declining' = 'stable';
      let trendDelta = 0;

      if (item.scores.length >= 2) {
        const prevScore = item.scores[item.scores.length - 2];
        trendDelta = parseFloat((latestScore.percentage - prevScore.percentage).toFixed(1));
        if (trendDelta > 1.5) trend = 'improving';
        else if (trendDelta < -1.5) trend = 'declining';
        else trend = 'stable';
      }

      return {
        subjectId: item.subjectId,
        subjectName: item.subjectName,
        subjectCode: item.subjectCode,
        credits: item.credits,
        averageMarks,
        highestMarks,
        latestGrade: latestScore ? latestScore.grade : 'A',
        latestGradePoint: latestScore ? latestScore.gradePoint : 4.0,
        trend,
        trendDelta,
        examHistory: item.scores
      };
    });

    // 3. Exam-Wise Trends
    const examWiseTrends: ExamWiseTrendItem[] = myResults.map((r) => ({
      examId: r.examId,
      examName: r.examName,
      academicSessionName: r.academicSessionName,
      academicYear: r.academicYear,
      publishDate: r.publishDate,
      overallPercentage: r.summary.overallPercentage,
      gpa: r.summary.gpa,
      overallGrade: r.summary.overallGrade,
      resultStatus: r.summary.resultStatus,
      totalObtainedMarks: r.summary.totalObtainedMarks,
      totalFullMarks: r.summary.totalFullMarks
    }));

    // 4. Cumulative Metrics
    const totalExamsTaken = myResults.length;
    const currentGPA = myResults.length > 0 ? myResults[myResults.length - 1].summary.gpa : 0;
    const cumulativeGPA =
      myResults.length > 0
        ? parseFloat((myResults.reduce((acc, curr) => acc + curr.summary.gpa, 0) / myResults.length).toFixed(2))
        : 0;
    const highestPercentage =
      myResults.length > 0 ? Math.max(...myResults.map((r) => r.summary.overallPercentage)) : 0;
    const totalCreditsCompleted = subjectPerformances.reduce((acc, curr) => acc + curr.credits, 0);
    const overallGradeInfo = calculateGradeFromScale((cumulativeGPA / 4.0) * 100);

    // 5. Attendance vs Performance Correlation
    const academicPercentage =
      myResults.length > 0
        ? parseFloat(
            (myResults.reduce((acc, curr) => acc + curr.summary.overallPercentage, 0) / myResults.length).toFixed(1)
          )
        : 90.0;

    let correlationRating: 'Strong Positive' | 'Positive' | 'Moderate' | 'Consistent' = 'Strong Positive';
    let insightText = '';

    if (attendancePercentage >= 90 && academicPercentage >= 85) {
      correlationRating = 'Strong Positive';
      insightText = `High attendance (${attendancePercentage}%) directly correlates with honors academic results (${academicPercentage}% average). Consistent classroom attendance supports superior topic retention.`;
    } else if (attendancePercentage >= 80 && academicPercentage >= 75) {
      correlationRating = 'Positive';
      insightText = `Good attendance (${attendancePercentage}%) aligns well with positive academic standing (${academicPercentage}% average).`;
    } else if (attendancePercentage < 75) {
      correlationRating = 'Moderate';
      insightText = `Attendance is at ${attendancePercentage}%. Increasing attendance will strengthen retention and examination outcomes.`;
    } else {
      correlationRating = 'Consistent';
      insightText = `Steady attendance patterns sustain balanced academic progress across all terms.`;
    }

    // 6. Improvement Highlights
    const improvementHighlights: StudentAcademicProgressOverview['improvementHighlights'] = [];

    const improvingSubjects = subjectPerformances.filter((s) => s.trend === 'improving');
    improvingSubjects.forEach((s) => {
      improvementHighlights.push({
        id: `hl-imp-${s.subjectCode}`,
        title: `${s.subjectName} Score Surged by +${s.trendDelta}%`,
        description: `Attained Grade ${s.latestGrade} (${s.latestGradePoint} GP) in the latest assessment, showing strong mastery growth.`,
        type: 'positive'
      });
    });

    if (cumulativeGPA >= 3.8) {
      improvementHighlights.push({
        id: 'hl-honor-roll',
        title: 'High Honors Academic Distinction',
        description: `Maintained a cumulative GPA of ${cumulativeGPA} out of 4.00, placing in the top tier of the class cohort.`,
        type: 'milestone'
      });
    }

    if (attendancePercentage >= 95) {
      improvementHighlights.push({
        id: 'hl-attendance-star',
        title: 'Exemplary Attendance & Punctuality',
        description: `Maintained an attendance rate of ${attendancePercentage}% with zero unexcused absences.`,
        type: 'milestone'
      });
    }

    let academicStanding = 'Good Standing';
    if (cumulativeGPA >= 3.8) academicStanding = 'High Honors / Dean’s List';
    else if (cumulativeGPA >= 3.5) academicStanding = 'Honors Standing';
    else if (cumulativeGPA >= 3.0) academicStanding = 'Satisfactory Academic Progress';
    else academicStanding = 'Academic Review';

    const progressOverview: StudentAcademicProgressOverview = {
      student: {
        id: studentSummary.id,
        userId: studentSummary.userId,
        admissionNumber: studentSummary.admissionNumber,
        rollNumber: studentSummary.rollNumber,
        fullName: studentSummary.name,
        className: studentSummary.className,
        sectionName: studentSummary.sectionName,
        academicSessionName: studentSummary.academicSessionName,
        avatarUrl: studentSummary.avatarUrl
      },
      metrics: {
        currentGPA,
        cumulativeGPA,
        totalExamsTaken,
        totalCreditsCompleted,
        highestPercentage,
        overallGrade: overallGradeInfo.grade,
        academicStanding
      },
      attendanceSummary: {
        attendancePercentage,
        presentCount,
        absentCount,
        lateCount,
        totalSchoolDays: totalAttendanceDays > 0 ? totalAttendanceDays : 20,
        hasReliableData: true
      },
      subjectPerformances,
      examWiseTrends,
      gradingScale: database.gradingScale || [],
      attendancePerformanceCorrelation: {
        correlationRating,
        attendancePercentage,
        academicPercentage,
        insightText
      },
      improvementHighlights
    };

    logAudit({
      userId: req.user!.id,
      userRole: req.user!.role,
      action: 'VIEW_CHILD_ACADEMIC_PROGRESS',
      entityType: 'AcademicProgress',
      entityId: studentId,
      details: `Guardian ${guardian.name} inspected comprehensive academic progress for child ${studentSummary.name}.`,
      ipAddress: req.ip || '127.0.0.1'
    });

    const response: GuardianChildProgressResponse = {
      student: studentSummary,
      progress: progressOverview,
      overview: {
        cumulativeGPA,
        currentGPA,
        overallGrade: overallGradeInfo.grade,
        averagePercentage: academicPercentage,
        highestPercentage,
        totalCreditsCompleted,
        totalExamsTaken,
        academicStanding
      },
      attendanceCorrelation: {
        correlationRating,
        attendancePercentage,
        academicAveragePercentage: academicPercentage,
        narrativeInsight: insightText
      },
      subjectTrends: subjectPerformances.map((s) => ({
        subjectId: s.subjectId,
        subjectName: s.subjectName,
        subjectCode: s.subjectCode,
        credits: s.credits,
        averageMarks: s.averageMarks,
        highestMarks: s.highestMarks,
        latestGrade: s.latestGrade,
        latestGradePoint: s.latestGradePoint,
        trend: s.trend === 'improving' ? 'UP' : s.trend === 'declining' ? 'DOWN' : 'STABLE',
        delta: s.trendDelta
      })),
      examTrends: myResults.map((r) => ({
        examId: r.examId,
        examName: r.examName,
        academicYear: r.academicYear,
        term: r.term,
        percentage: r.summary.overallPercentage,
        gpa: r.summary.gpa,
        grade: r.summary.overallGrade,
        totalObtainedMarks: r.summary.totalObtainedMarks,
        totalFullMarks: r.summary.totalFullMarks
      }))
    };

    res.json({ success: true, data: response });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message, code: 'SERVER_ERROR' });
  }
});

/**
 * GET /api/guardian/children-comparison
 * Provides a comparative overview of all children linked to the authenticated guardian
 * Strictly isolated to the guardian's linked children only
 */
guardianRouter.get('/children-comparison', requireRole('GUARDIAN', 'SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const guardian = resolveAuthenticatedGuardian(req);
    if (!guardian) {
      res.status(404).json({ success: false, error: 'Guardian profile not found.' });
      return;
    }

    const comparisonItems: GuardianChildComparisonItem[] = [];

    guardian.studentIds.forEach((childId) => {
      const studentSummary = buildChildSummary(childId);
      if (!studentSummary) return;

      // 1. Attendance for this child
      const attendanceRecords = (database.attendanceRecords || []).filter(
        (r) => r.studentId === childId || r.userId === studentSummary.userId
      );
      const totalSchoolDays = attendanceRecords.length;
      const presentDays = attendanceRecords.filter((r) => r.status === 'PRESENT').length;
      const absentDays = attendanceRecords.filter((r) => r.status === 'ABSENT').length;
      const lateDays = attendanceRecords.filter((r) => r.status === 'LATE').length;
      const halfDays = attendanceRecords.filter((r) => r.status === 'HALF_DAY').length;
      const attendancePercentage =
        totalSchoolDays > 0
          ? Math.round(((presentDays + lateDays + (halfDays * 0.5)) / totalSchoolDays) * 1000) / 10
          : 95.0;

      // 2. Results for this child
      const childResults = (database.examResults || [])
        .filter((r) => (r.studentId === childId || r.userId === studentSummary.userId) && r.isPublished)
        .sort((a, b) => b.publishDate.localeCompare(a.publishDate));

      const totalExamsTaken = childResults.length;
      const totalGpaSum = childResults.reduce((acc, curr) => acc + curr.summary.gpa, 0);
      const cumulativeGPA =
        totalExamsTaken > 0 ? parseFloat((totalGpaSum / totalExamsTaken).toFixed(2)) : 0;
      const overallPercentageAverage =
        totalExamsTaken > 0
          ? parseFloat((childResults.reduce((acc, curr) => acc + curr.summary.overallPercentage, 0) / totalExamsTaken).toFixed(1))
          : 0;

      const latest = childResults.length > 0 ? childResults[0] : null;
      const latestResult = latest
        ? {
            examName: latest.examName,
            term: latest.term,
            publishDate: latest.publishDate,
            overallPercentage: latest.summary.overallPercentage,
            gpa: latest.summary.gpa,
            overallGrade: latest.summary.overallGrade,
            resultStatus: latest.summary.resultStatus,
            totalObtainedMarks: latest.summary.totalObtainedMarks,
            totalFullMarks: latest.summary.totalFullMarks,
            classRank: latest.summary.classRank,
            totalStudentsInClass: latest.summary.totalStudentsInClass
          }
        : null;

      // 3. Pending Activities
      const pendingHw = (database.homework || []).filter(
        (h) =>
          h.classId === studentSummary.classId &&
          (!h.sectionId || h.sectionId === 'ALL' || h.sectionId === 'all' || h.sectionId === studentSummary.sectionId) &&
          h.status === 'published'
      ).length;

      const pendingAsg = (database.assignments || []).filter(
        (a) =>
          a.classId === studentSummary.classId &&
          (!a.sectionId || a.sectionId === 'ALL' || a.sectionId === 'all' || a.sectionId === studentSummary.sectionId) &&
          a.status === 'published'
      ).length;

      comparisonItems.push({
        studentId: studentSummary.id,
        studentName: studentSummary.name,
        className: studentSummary.className,
        sectionName: studentSummary.sectionName,
        rollNumber: studentSummary.rollNumber,
        admissionNumber: studentSummary.admissionNumber,
        student: studentSummary,
        attendancePercentage,
        totalSchoolDays: totalSchoolDays > 0 ? totalSchoolDays : 20,
        presentDays,
        absentDays,
        lateDays,
        attendance: {
          percentage: attendancePercentage,
          presentDays,
          totalDays: totalSchoolDays > 0 ? totalSchoolDays : 20,
          absentDays
        },
        latestResult,
        cumulativeGPA,
        totalExamsTaken,
        overallPercentageAverage,
        averagePercentage: overallPercentageAverage,
        overallGrade: latestResult?.overallGrade || 'N/A',
        totalSubjectsEnrolled: studentSummary.totalSubjectsCount,
        totalPendingActivities: pendingHw + pendingAsg,
        status: studentSummary.status
      });
    });

    logAudit({
      userId: req.user!.id,
      userRole: req.user!.role,
      action: 'VIEW_CHILDREN_COMPARISON',
      entityType: 'GuardianChildrenComparison',
      entityId: guardian.id,
      details: `Guardian ${guardian.name} generated side-by-side academic comparison for ${comparisonItems.length} linked children.`,
      ipAddress: req.ip || '127.0.0.1'
    });

    const response: GuardianChildrenComparisonResponse = {
      guardian: {
        id: guardian.id,
        name: guardian.name,
        email: guardian.email
      },
      totalChildren: comparisonItems.length,
      children: comparisonItems,
      comparison: comparisonItems
    };

    res.json({ success: true, data: response });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message, code: 'SERVER_ERROR' });
  }
});

// ==========================================
// Phase 5F: Fee & Payment Management Routes
// ==========================================

function calculateFeeSummary(fees: StudentFeeRecord[]): GuardianFeeSummary {
  const today = new Date(CURRENT_SYSTEM_DATE);
  today.setHours(0, 0, 0, 0);

  let totalFees = 0;
  let totalPayable = 0;
  let totalPaid = 0;
  let totalDue = 0;
  let totalOverdue = 0;
  let totalDiscount = 0;
  let totalScholarship = 0;
  let totalWaiver = 0;
  let totalFine = 0;
  let fullyPaidCount = 0;
  let partiallyPaidCount = 0;
  let unpaidCount = 0;
  let overdueCount = 0;
  let nextUpcomingDueDate: string | null = null;
  let earliestDueTime = Infinity;

  fees.forEach((raw) => {
    const totalAmount = Number(raw.totalAmount) || 0;
    const discountAmount = Number(raw.discountAmount) || 0;
    const scholarshipAmount = Number(raw.scholarshipAmount) || 0;
    const waiverAmount = Number(raw.waiverAmount) || 0;
    const fineAmount = Number(raw.fineAmount) || 0;
    const paidAmount = Number(raw.paidAmount) || 0;
    const totalDeductions = discountAmount + scholarshipAmount + waiverAmount;
    const grossNet = totalAmount - totalDeductions + fineAmount;
    const netPayableAmount = Math.max(0, Math.round(grossNet * 100) / 100);
    const dueAmount = Math.max(0, Math.round((netPayableAmount - paidAmount) * 100) / 100);

    totalFees += totalAmount;
    totalDiscount += discountAmount;
    totalScholarship += scholarshipAmount;
    totalWaiver += waiverAmount;
    totalFine += fineAmount;
    totalPayable += netPayableAmount;
    totalPaid += paidAmount;
    totalDue += dueAmount;

    const dueDate = new Date(raw.dueDate);
    dueDate.setHours(0, 0, 0, 0);
    const isPastDue = dueDate < today && dueAmount > 0;

    if (raw.status === 'PAID' || dueAmount <= 0) {
      fullyPaidCount++;
    } else if (raw.status === 'PARTIAL' || (paidAmount > 0 && dueAmount > 0)) {
      partiallyPaidCount++;
      if (isPastDue || raw.status === 'OVERDUE') {
        overdueCount++;
        totalOverdue += dueAmount;
      }
    } else {
      unpaidCount++;
      if (isPastDue || raw.status === 'OVERDUE') {
        overdueCount++;
        totalOverdue += dueAmount;
      }
    }

    if (dueAmount > 0 && dueDate >= today) {
      if (dueDate.getTime() < earliestDueTime) {
        earliestDueTime = dueDate.getTime();
        nextUpcomingDueDate = raw.dueDate;
      }
    }
  });

  return {
    totalFees: Math.round(totalFees * 100) / 100,
    totalPayable: Math.round(totalPayable * 100) / 100,
    totalPaid: Math.round(totalPaid * 100) / 100,
    totalDue: Math.round(totalDue * 100) / 100,
    totalOverdue: Math.round(totalOverdue * 100) / 100,
    totalDiscount: Math.round(totalDiscount * 100) / 100,
    totalScholarship: Math.round(totalScholarship * 100) / 100,
    totalWaiver: Math.round(totalWaiver * 100) / 100,
    totalFine: Math.round(totalFine * 100) / 100,
    fullyPaidCount,
    partiallyPaidCount,
    unpaidCount,
    overdueCount,
    nextUpcomingDueDate
  };
}

/**
 * GET /api/guardian/fees
 * Retrieve fee records and financial overview for a specific linked child.
 * Strictly verifies child belongs to authenticated guardian.
 */
guardianRouter.get('/fees', requireRole('GUARDIAN', 'SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const guardian = resolveAuthenticatedGuardian(req);
    if (!guardian) {
      res.status(404).json({ success: false, error: 'Guardian account profile not found.', code: 'GUARDIAN_NOT_FOUND' });
      return;
    }

    if (!guardian.studentIds || guardian.studentIds.length === 0) {
      res.status(404).json({ success: false, error: 'No student wards currently linked to your guardian profile.', code: 'NO_LINKED_STUDENTS' });
      return;
    }

    // Resolve target child
    const requestedStudentId = (req.query.studentId as string) || guardian.studentIds[0];
    if (!isAuthorizedStudentForGuardian(guardian, requestedStudentId)) {
      res.status(403).json({
        success: false,
        error: 'Access Denied: You do not have authorization to view financial records for this student.',
        code: 'UNAUTHORIZED_STUDENT_ACCESS'
      });
      return;
    }

    const studentSummary = buildChildSummary(requestedStudentId);
    if (!studentSummary) {
      res.status(404).json({ success: false, error: 'Student scholar profile not found.', code: 'STUDENT_NOT_FOUND' });
      return;
    }

    // Fetch all fees for this child
    const allChildFees = (database.feeRecords || []).filter((f) => f.studentId === requestedStudentId);
    const summary = calculateFeeSummary(allChildFees);

    // Apply query filters
    let filtered = [...allChildFees];

    if (req.query.status) {
      const statusFilter = (req.query.status as string).toUpperCase();
      if (statusFilter === 'PAID') {
        filtered = filtered.filter((f) => f.status === 'PAID' || f.dueAmount <= 0);
      } else if (statusFilter === 'PARTIAL') {
        filtered = filtered.filter((f) => f.status === 'PARTIAL' && f.dueAmount > 0);
      } else if (statusFilter === 'DUE') {
        filtered = filtered.filter((f) => f.status === 'DUE' && f.dueAmount > 0);
      } else if (statusFilter === 'OVERDUE') {
        const today = new Date(CURRENT_SYSTEM_DATE);
        today.setHours(0, 0, 0, 0);
        filtered = filtered.filter((f) => f.status === 'OVERDUE' || (new Date(f.dueDate) < today && f.dueAmount > 0));
      } else if (statusFilter === 'OUTSTANDING') {
        filtered = filtered.filter((f) => f.dueAmount > 0);
      }
    }

    if (req.query.sessionId) {
      filtered = filtered.filter((f) => f.academicSessionId === req.query.sessionId);
    }

    if (req.query.feeType) {
      filtered = filtered.filter((f) => f.feeType.toLowerCase() === (req.query.feeType as string).toLowerCase());
    }

    if (req.query.term) {
      filtered = filtered.filter((f) => f.term.toLowerCase() === (req.query.term as string).toLowerCase());
    }

    if (req.query.search) {
      const q = (req.query.search as string).toLowerCase().trim();
      filtered = filtered.filter(
        (f) =>
          f.title.toLowerCase().includes(q) ||
          f.feeType.toLowerCase().includes(q) ||
          f.invoiceNumber.toLowerCase().includes(q) ||
          f.description.toLowerCase().includes(q)
      );
    }

    // Sort by due date (soonest due first for outstanding, then recent)
    filtered.sort((a, b) => new Date(b.dueDate).getTime() - new Date(a.dueDate).getTime());

    // Extract available sessions & fee types
    const availableSessions = Array.from(
      new Set(allChildFees.map((f) => JSON.stringify({ id: f.academicSessionId, name: f.academicSessionName })))
    ).map((s) => JSON.parse(s));

    const availableFeeTypes = Array.from(new Set(allChildFees.map((f) => f.feeType)));

    logAudit({
      userId: req.user!.id,
      userRole: req.user!.role,
      action: 'VIEW_STUDENT_FEES',
      entityType: 'FeeRecord',
      entityId: requestedStudentId,
      details: `Guardian ${guardian.name} viewed fee ledger (${filtered.length} items) for student ${studentSummary.name} (${studentSummary.admissionNumber}).`,
      ipAddress: req.ip || '127.0.0.1'
    });

    const response: GuardianChildFeesResponse = {
      student: studentSummary,
      data: filtered,
      total: filtered.length,
      summary,
      availableSessions,
      availableFeeTypes
    };

    res.json({ success: true, data: response });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message, code: 'SERVER_ERROR' });
  }
});

/**
 * GET /api/guardian/fees/family-overview
 * Aggregate financial summary and status breakdown across all linked children for the guardian.
 */
guardianRouter.get('/fees/family-overview', requireRole('GUARDIAN', 'SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const guardian = resolveAuthenticatedGuardian(req);
    if (!guardian) {
      res.status(404).json({ success: false, error: 'Guardian account profile not found.', code: 'GUARDIAN_NOT_FOUND' });
      return;
    }

    const linkedStudentIds = getGuardianLinkedStudentIds(guardian);
    const allLinkedFees = (database.feeRecords || []).filter((f) => linkedStudentIds.includes(f.studentId));
    const familySummary = calculateFeeSummary(allLinkedFees);

    const childrenSummaries = linkedStudentIds.map((studentId) => {
      const studentSummary = buildChildSummary(studentId)!;
      const childFees = allLinkedFees.filter((f) => f.studentId === studentId);
      const childSummary = calculateFeeSummary(childFees);
      const latestPayment = (database.feeTransactions || [])
        .filter((t) => t.studentId === studentId && t.paymentStatus === 'SUCCESS')
        .sort((a, b) => new Date(b.paymentDate).getTime() - new Date(a.paymentDate).getTime())[0];

      return {
        student: studentSummary,
        summary: childSummary,
        fees: childFees,
        latestPayment
      };
    });

    logAudit({
      userId: req.user!.id,
      userRole: req.user!.role,
      action: 'VIEW_FAMILY_FEE_OVERVIEW',
      entityType: 'GuardianFamilyFeeOverview',
      entityId: guardian.id,
      details: `Guardian ${guardian.name} viewed consolidated family fee overview for ${guardian.studentIds.length} children.`,
      ipAddress: req.ip || '127.0.0.1'
    });

    const response: GuardianFamilyFeeOverviewResponse = {
      guardian: {
        id: guardian.id,
        name: guardian.name,
        email: guardian.email
      },
      totalChildren: guardian.studentIds.length,
      familySummary,
      childrenSummaries
    };

    res.json({ success: true, data: response });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message, code: 'SERVER_ERROR' });
  }
});

/**
 * GET /api/guardian/fees/:feeId
 * Retrieve deep breakdown of an individual fee invoice including linked payment history.
 * Strictly verifies the fee belongs to one of the guardian's linked children.
 */
guardianRouter.get('/fees/:feeId', requireRole('GUARDIAN', 'SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const guardian = resolveAuthenticatedGuardian(req);
    if (!guardian) {
      res.status(404).json({ success: false, error: 'Guardian account profile not found.', code: 'GUARDIAN_NOT_FOUND' });
      return;
    }

    const { feeId } = req.params;
    const fee = (database.feeRecords || []).find((f) => f.id === feeId);
    if (!fee) {
      res.status(404).json({ success: false, error: 'Fee invoice record not found.', code: 'FEE_NOT_FOUND' });
      return;
    }

    // Security check: fee must belong to guardian's ward
    if (!isAuthorizedStudentForGuardian(guardian, fee.studentId)) {
      res.status(403).json({
        success: false,
        error: 'Access Denied: You are not authorized to view this fee record.',
        code: 'UNAUTHORIZED_FEE_ACCESS'
      });
      return;
    }

    const studentSummary = buildChildSummary(fee.studentId);
    if (!studentSummary) {
      res.status(404).json({ success: false, error: 'Student scholar profile not found.', code: 'STUDENT_NOT_FOUND' });
      return;
    }

    const transactions = (database.feeTransactions || [])
      .filter((t) => t.feeRecordId === fee.id)
      .sort((a, b) => new Date(b.paymentDate).getTime() - new Date(a.paymentDate).getTime());

    const allChildFees = (database.feeRecords || []).filter((f) => f.studentId === fee.studentId);
    const summary = calculateFeeSummary(allChildFees);

    logAudit({
      userId: req.user!.id,
      userRole: req.user!.role,
      action: 'VIEW_FEE_DETAIL',
      entityType: 'FeeRecord',
      entityId: fee.id,
      details: `Guardian ${guardian.name} viewed detailed fee ledger for invoice ${fee.invoiceNumber} (${fee.title}).`,
      ipAddress: req.ip || '127.0.0.1'
    });

    const response: GuardianChildFeeDetailResponse = {
      student: studentSummary,
      fee,
      transactions,
      summary
    };

    res.json({ success: true, data: response });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message, code: 'SERVER_ERROR' });
  }
});

/**
 * GET /api/guardian/payments
 * Retrieve complete payment and transaction history across one or all linked children.
 */
guardianRouter.get('/payments', requireRole('GUARDIAN', 'SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const guardian = resolveAuthenticatedGuardian(req);
    if (!guardian) {
      res.status(404).json({ success: false, error: 'Guardian account profile not found.', code: 'GUARDIAN_NOT_FOUND' });
      return;
    }

    const requestedStudentId = req.query.studentId as string;
    if (requestedStudentId && !isAuthorizedStudentForGuardian(guardian, requestedStudentId)) {
      res.status(403).json({
        success: false,
        error: 'Access Denied: You do not have authorization to view payments for this student.',
        code: 'UNAUTHORIZED_STUDENT_ACCESS'
      });
      return;
    }

    let transactions = (database.feeTransactions || []).filter((t) => {
      if (requestedStudentId) {
        return t.studentId === requestedStudentId;
      }
      return isAuthorizedStudentForGuardian(guardian, t.studentId);
    });

    // Filters
    if (req.query.paymentMethod) {
      transactions = transactions.filter((t) => t.paymentMethod === req.query.paymentMethod);
    }

    if (req.query.status) {
      transactions = transactions.filter((t) => t.paymentStatus.toUpperCase() === (req.query.status as string).toUpperCase());
    }

    if (req.query.startDate) {
      const start = new Date(req.query.startDate as string);
      transactions = transactions.filter((t) => new Date(t.paymentDate) >= start);
    }

    if (req.query.endDate) {
      const end = new Date(req.query.endDate as string);
      end.setHours(23, 59, 59, 999);
      transactions = transactions.filter((t) => new Date(t.paymentDate) <= end);
    }

    if (req.query.search) {
      const q = (req.query.search as string).toLowerCase().trim();
      transactions = transactions.filter(
        (t) =>
          t.transactionId.toLowerCase().includes(q) ||
          t.receiptNumber.toLowerCase().includes(q) ||
          t.feeTitle.toLowerCase().includes(q) ||
          t.feeType.toLowerCase().includes(q) ||
          t.studentName.toLowerCase().includes(q)
      );
    }

    // Sort newest first
    transactions.sort((a, b) => new Date(b.paymentDate).getTime() - new Date(a.paymentDate).getTime());

    const totalAmountPaid = transactions
      .filter((t) => t.paymentStatus === 'SUCCESS')
      .reduce((sum, t) => sum + t.amountPaid, 0);

    const availableChildren = guardian.studentIds
      .map((id) => buildChildSummary(id))
      .filter((c): c is GuardianChildSummary => c !== null);

    const availablePaymentMethods = Array.from(new Set(database.feeTransactions.map((t) => t.paymentMethod)));

    const targetStudent = requestedStudentId ? buildChildSummary(requestedStudentId) || undefined : undefined;

    logAudit({
      userId: req.user!.id,
      userRole: req.user!.role,
      action: 'VIEW_PAYMENT_HISTORY',
      entityType: 'FeePaymentTransaction',
      entityId: requestedStudentId || guardian.id,
      details: `Guardian ${guardian.name} inspected payment transaction history (${transactions.length} records).`,
      ipAddress: req.ip || '127.0.0.1'
    });

    const response: GuardianPaymentHistoryResponse = {
      student: targetStudent,
      data: transactions,
      total: transactions.length,
      totalAmountPaid,
      availableChildren,
      children: availableChildren,
      availablePaymentMethods
    };

    res.json({ success: true, data: response });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message, code: 'SERVER_ERROR' });
  }
});

/**
 * POST /api/guardian/fees/pay
 * Secure payment initiation and server-side settlement for an outstanding fee invoice.
 * Verifies authorization, guards against duplicate idempotency keys, and updates state safely.
 */
guardianRouter.post('/fees/pay', requireRole('GUARDIAN', 'SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const guardian = resolveAuthenticatedGuardian(req);
    if (!guardian) {
      res.status(404).json({ success: false, error: 'Guardian account profile not found.', code: 'GUARDIAN_NOT_FOUND' });
      return;
    }

    const { feeId, amount, paymentMethod, cardholderName, notes, idempotencyKey } = req.body;

    if (!feeId) {
      res.status(400).json({ success: false, error: 'Fee invoice ID is required.', code: 'MISSING_FEE_ID' });
      return;
    }

    const fee = (database.feeRecords || []).find((f) => f.id === feeId);
    if (!fee) {
      res.status(404).json({ success: false, error: 'Fee invoice record not found.', code: 'FEE_NOT_FOUND' });
      return;
    }

    // Security check: Guardian must own this child
    if (!isAuthorizedStudentForGuardian(guardian, fee.studentId)) {
      res.status(403).json({
        success: false,
        error: 'Access Denied: You are not authorized to make payments for this student.',
        code: 'UNAUTHORIZED_FEE_PAYMENT'
      });
      return;
    }

    const parsedAmount = typeof amount === 'string' ? parseFloat(amount) : Number(amount);
    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      res.status(400).json({
        success: false,
        error: 'Invalid payment amount. Amount must be a positive number greater than 0.',
        code: 'INVALID_AMOUNT'
      });
      return;
    }

    // Idempotency check to prevent accidental double-submission (checked before balance due validation)
    if (idempotencyKey) {
      const existingTxn = (database.feeTransactions || []).find(
        (t) => t.idempotencyKey === idempotencyKey && t.guardianId === guardian.id
      );
      if (existingTxn) {
        res.json({
          success: true,
          message: 'Payment already processed with this transaction token.',
          data: {
            transaction: existingTxn,
            feeRecord: fee,
            isDuplicate: true
          }
        });
        return;
      }
    }

    if (parsedAmount > fee.dueAmount + 0.01) {
      res.status(400).json({
        success: false,
        error: `Payment amount (${parsedAmount.toFixed(2)}) exceeds the current remaining balance due (${fee.dueAmount.toFixed(2)}).`,
        code: 'EXCESSIVE_AMOUNT'
      });
      return;
    }

    const validMethods: PaymentMethod[] = [
      'CREDIT_CARD',
      'DEBIT_CARD',
      'NET_BANKING',
      'BANK_TRANSFER',
      'DIGITAL_WALLET',
      'CASH',
      'CHEQUE'
    ];
    const selectedMethod: PaymentMethod = validMethods.includes(paymentMethod) ? paymentMethod : 'CREDIT_CARD';

    // Format human-readable method label
    let methodLabel = 'Credit Card (Online Gateway)';
    if (selectedMethod === 'CREDIT_CARD') {
      methodLabel = 'Credit Card (Online Gateway)';
    } else if (selectedMethod === 'DEBIT_CARD') {
      methodLabel = 'Debit Card (Online Gateway)';
    } else if (selectedMethod === 'NET_BANKING') {
      methodLabel = 'ACH / Direct Net Banking';
    } else if (selectedMethod === 'BANK_TRANSFER') {
      methodLabel = 'Direct Wire Transfer';
    } else if (selectedMethod === 'DIGITAL_WALLET') {
      methodLabel = 'Digital Wallet (Apple/Google Pay)';
    }

    const timestamp = new Date().toISOString();
    const txnRandomNumber = Math.floor(10000 + Math.random() * 90000);
    const transactionId = `TXN-2026-${txnRandomNumber}`;
    const receiptNumber = `REC-2026-${String((database.feeTransactions?.length || 0) + 101).padStart(5, '0')}`;
    const gatewayRef = `ch_sim_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;

    // Create the transaction
    const newTransaction: FeePaymentTransaction = {
      id: `txn-${Date.now()}-${txnRandomNumber}`,
      transactionId,
      receiptNumber,
      feeRecordId: fee.id,
      studentId: fee.studentId,
      studentName: fee.studentName,
      guardianId: guardian.id,
      guardianName: guardian.name,
      academicSessionId: fee.academicSessionId,
      feeType: fee.feeType,
      feeTitle: fee.title,
      amountPaid: parsedAmount,
      paymentMethod: selectedMethod,
      paymentMethodLabel: cardholderName ? `${methodLabel} - ${cardholderName}` : methodLabel,
      paymentDate: timestamp,
      paymentStatus: 'SUCCESS',
      gatewayReference: gatewayRef,
      notes: notes || `Online portal fee settlement by ${guardian.name}`,
      payerEmail: guardian.email,
      payerPhone: guardian.phone,
      idempotencyKey: idempotencyKey || undefined,
      createdAt: timestamp
    };

    // Update fee record state
    fee.paidAmount = parseFloat((fee.paidAmount + parsedAmount).toFixed(2));
    fee.dueAmount = Math.max(0, parseFloat((fee.netPayableAmount - fee.paidAmount).toFixed(2)));
    fee.status = fee.dueAmount <= 0 ? 'PAID' : 'PARTIAL';
    fee.updatedAt = timestamp;

    // Update installments if applicable
    if (fee.installments && fee.installments.length > 0) {
      let remainingPayment = parsedAmount;
      for (const inst of fee.installments) {
        if (!inst.isPaid && remainingPayment >= inst.amount) {
          inst.isPaid = true;
          inst.paidDate = timestamp;
          remainingPayment -= inst.amount;
        }
      }
    }

    // Append to transactions
    database.feeTransactions.unshift(newTransaction);

    // Create an in-app notification for the guardian
    const notification: NotificationItem = {
      id: `notif-${Date.now()}`,
      userId: guardian.userId,
      title: 'Fee Payment Receipt Generated',
      message: `Your payment of ${parsedAmount.toFixed(2)} for "${fee.title}" (${fee.studentName}) was successfully processed. Receipt #${receiptNumber}.`,
      type: 'success',
      category: 'fee',
      isRead: false,
      createdAt: timestamp,
      link: '/guardian/fees'
    };
    database.notifications.unshift(notification);

    // Audit log
    logAudit({
      userId: req.user!.id,
      userRole: req.user!.role,
      action: 'MAKE_FEE_PAYMENT',
      entityType: 'FeePaymentTransaction',
      entityId: newTransaction.id,
      details: `Guardian ${guardian.name} processed ${parsedAmount.toFixed(2)} payment for invoice ${fee.invoiceNumber} (Txn: ${transactionId}, Receipt: ${receiptNumber}).`,
      ipAddress: req.ip || '127.0.0.1'
    });

    res.json({
      success: true,
      message: `Payment of ${parsedAmount.toFixed(2)} successfully verified and settled. Receipt #${receiptNumber} generated.`,
      data: {
        transaction: newTransaction,
        feeRecord: fee,
        receiptNumber: newTransaction.receiptNumber
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message, code: 'SERVER_ERROR' });
  }
});

/**
 * GET /api/guardian/payments/:transactionId/receipt
 * Generate official structured payment receipt printable by guardian.
 * Strictly verifies the transaction belongs to the guardian's linked child.
 */
guardianRouter.get('/payments/:transactionId/receipt', requireRole('GUARDIAN', 'SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const guardian = resolveAuthenticatedGuardian(req);
    if (!guardian) {
      res.status(404).json({ success: false, error: 'Guardian account profile not found.', code: 'GUARDIAN_NOT_FOUND' });
      return;
    }

    const { transactionId } = req.params;
    const transaction = (database.feeTransactions || []).find(
      (t) =>
        t.transactionId === transactionId ||
        t.id === transactionId ||
        t.receiptNumber === transactionId ||
        t.feeRecordId === transactionId
    );

    if (!transaction) {
      res.status(404).json({ success: false, error: 'Payment transaction receipt record not found.', code: 'TRANSACTION_NOT_FOUND' });
      return;
    }

    // Security check: Guardian must be linked to student of this transaction
    if (!isAuthorizedStudentForGuardian(guardian, transaction.studentId)) {
      res.status(403).json({
        success: false,
        error: 'Access Denied: You are not authorized to view receipts for this transaction.',
        code: 'UNAUTHORIZED_RECEIPT_ACCESS'
      });
      return;
    }

    const fee = (database.feeRecords || []).find((f) => f.id === transaction.feeRecordId);
    const student = database.studentProfiles.find((s) => s.id === transaction.studentId);
    const studentSummary = buildChildSummary(transaction.studentId);
    const school = database.schoolSettings;

    const receipt: FeePaymentReceipt = {
      receiptNumber: transaction.receiptNumber,
      transactionId: transaction.transactionId,
      schoolInfo: {
        name: school.name || school.schoolName || 'Sygmate International Academy',
        code: school.code || school.schoolCode || 'SIA-2026',
        address: `${school.address}, ${school.city}, ${school.state} ${school.postalCode}, ${school.country}`,
        phone: school.phone || school.contactPhone || '+1 (800) 555-0199',
        email: school.email || school.contactEmail || 'administration@sygmate.edu',
        website: school.website || 'https://sygmate-school.edu',
        affiliationNumber: school.affiliationNumber || 'MA-EDU-88291',
        principalName: school.principalName || 'Dr. Evelyn Montgomery',
        currency: school.currency || 'USD',
        currencySymbol: school.currencySymbol || '$'
      },
      studentInfo: {
        id: student?.id || transaction.studentId,
        name: studentSummary?.name || transaction.studentName,
        admissionNumber: studentSummary?.admissionNumber || student?.admissionNumber || 'ADM-2026-0000',
        rollNumber: studentSummary?.rollNumber || student?.rollNumber || 'N/A',
        className: studentSummary?.className || 'Grade 10',
        sectionName: studentSummary?.sectionName || 'Section A'
      },
      guardianInfo: {
        id: guardian.id,
        name: guardian.name,
        relation: guardian.relationship || 'Guardian',
        phone: guardian.phone,
        email: guardian.email
      },
      feeInfo: {
        feeRecordId: fee?.id || transaction.feeRecordId,
        invoiceNumber: fee?.invoiceNumber,
        feeType: fee?.feeType || transaction.feeType,
        title: fee?.title || transaction.feeTitle,
        academicSession: fee?.academicSessionName || '2026-2027 Academic Year',
        term: fee?.term || 'Fall Semester 2026',
        totalFee: fee?.totalAmount || transaction.amountPaid,
        discount: (fee?.discountAmount || 0) + (fee?.scholarshipAmount || 0) + (fee?.waiverAmount || 0),
        fine: fee?.fineAmount || 0,
        netPayable: fee?.netPayableAmount || transaction.amountPaid,
        previouslyPaid: Math.max(0, (fee?.paidAmount || transaction.amountPaid) - transaction.amountPaid),
        amountPaidNow: transaction.amountPaid,
        remainingDue: fee?.dueAmount || 0
      },
      paymentDetails: {
        paymentDate: transaction.paymentDate,
        paymentMethod: transaction.paymentMethodLabel || transaction.paymentMethod,
        paymentStatus: transaction.paymentStatus,
        gatewayReference: transaction.gatewayReference || 'GW-VERIFIED-SETTLED',
        authorizedSignatory: 'Office of Financial Comptroller & Bursar'
      },
      issuedAt: new Date().toISOString()
    };

    logAudit({
      userId: req.user!.id,
      userRole: req.user!.role,
      action: 'DOWNLOAD_PAYMENT_RECEIPT',
      entityType: 'FeePaymentReceipt',
      entityId: transaction.receiptNumber,
      details: `Guardian ${guardian.name} downloaded official payment receipt ${transaction.receiptNumber} for transaction ${transaction.transactionId}.`,
      ipAddress: req.ip || '127.0.0.1'
    });

    res.json({ success: true, data: receipt });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message, code: 'SERVER_ERROR' });
  }
});


