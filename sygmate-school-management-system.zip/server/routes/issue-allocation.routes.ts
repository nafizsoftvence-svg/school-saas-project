/**
 * Issue, Return, Allocation & Department Workflow Routes (Part 14E)
 * Sygmate School Management System
 */

import { Router, Response } from 'express';
import { requireAuth, requirePermission, AuthenticatedRequest } from '../security/auth.js';
import { IssueAllocationService } from '../services/issue-allocation.service.js';
import { database } from '../db/database.js';

export const issueAllocationRouter = Router();

/**
 * Resolves authoritative schoolId from session / database settings.
 * Never trust user-provided schoolId in params or payload.
 */
function resolveSchoolId(req: AuthenticatedRequest): string {
  if (req?.tenant?.schoolId) return req.tenant.schoolId;
  if (req?.user?.schoolId) return req.user.schoolId;
  return database.schoolSettings?.id || 'school-main';
}

// ============================================================================
// DASHBOARD KPIS
// ============================================================================

/**
 * GET /api/inventory/issues/kpis
 */
issueAllocationRouter.get(
  '/issues/kpis',
  requireAuth,
  requirePermission('inventory.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = resolveSchoolId(req);
      const kpis = IssueAllocationService.getDashboardKPIs(schoolId);
      res.json({ success: true, data: kpis });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to fetch issue KPIs' });
    }
  }
);

// ============================================================================
// 1. ISSUE REQUESTS ENDPOINTS
// ============================================================================

/**
 * GET /api/inventory/issues/requests
 * List issue requests with search, filtering, and pagination
 */
issueAllocationRouter.get(
  '/issues/requests',
  requireAuth,
  requirePermission('inventory.issues.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = resolveSchoolId(req);
      const result = IssueAllocationService.getIssueRequests(schoolId, {
        search: req.query.search as string,
        status: req.query.status as string,
        priority: req.query.priority as string,
        departmentId: req.query.departmentId as string,
        locationId: req.query.locationId as string,
        requestedBy: req.query.requestedBy as string,
        page: req.query.page ? parseInt(req.query.page as string, 10) : 1,
        limit: req.query.limit ? parseInt(req.query.limit as string, 10) : 20
      });
      res.json({ success: true, ...result });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to fetch issue requests' });
    }
  }
);

/**
 * GET /api/inventory/issues/requests/:id
 * Retrieve single issue request with live stock availability
 */
issueAllocationRouter.get(
  '/issues/requests/:id',
  requireAuth,
  requirePermission('inventory.issues.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = resolveSchoolId(req);
      const request = IssueAllocationService.getIssueRequestById(schoolId, req.params.id);
      res.json({ success: true, data: request });
    } catch (error: any) {
      const status = error.message?.includes('not found') ? 404 : 500;
      res.status(status).json({ success: false, error: error.message || 'Failed to fetch issue request' });
    }
  }
);

/**
 * POST /api/inventory/issues/requests
 * Create new issue request
 */
issueAllocationRouter.post(
  '/issues/requests',
  requireAuth,
  requirePermission('inventory.issues.create'),
  async (req: AuthenticatedRequest, res: Response): Promise<void> => {
    try {
      const schoolId = resolveSchoolId(req);
      const result = await IssueAllocationService.createIssueRequest(schoolId, req.body, req.user);
      res.status(201).json({
        success: true,
        data: result,
        message: `Issue request ${result.requestNumber} submitted successfully.`
      });
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message || 'Failed to create issue request' });
    }
  }
);

/**
 * POST /api/inventory/issues/requests/:id/review
 * Review / Approve / Reject issue request
 */
issueAllocationRouter.post(
  '/issues/requests/:id/review',
  requireAuth,
  requirePermission('inventory.issues.approve'),
  async (req: AuthenticatedRequest, res: Response): Promise<void> => {
    try {
      const schoolId = resolveSchoolId(req);
      const result = await IssueAllocationService.reviewIssueRequest(schoolId, req.params.id, req.body, req.user);
      res.json({
        success: true,
        data: result,
        message: `Issue request ${result.requestNumber} reviewed: status is now ${result.status}.`
      });
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message || 'Failed to review issue request' });
    }
  }
);

// ============================================================================
// 2. STOCK ISSUES / DISPATCHES ENDPOINTS
// ============================================================================

/**
 * GET /api/inventory/issues/dispatches
 * List stock issues
 */
issueAllocationRouter.get(
  '/issues/dispatches',
  requireAuth,
  requirePermission('inventory.issues.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = resolveSchoolId(req);
      const result = IssueAllocationService.getStockIssues(schoolId, {
        search: req.query.search as string,
        status: req.query.status as string,
        departmentId: req.query.departmentId as string,
        locationId: req.query.locationId as string,
        recipientId: req.query.recipientId as string,
        page: req.query.page ? parseInt(req.query.page as string, 10) : 1,
        limit: req.query.limit ? parseInt(req.query.limit as string, 10) : 20
      });
      res.json({ success: true, ...result });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to fetch stock issues' });
    }
  }
);

/**
 * GET /api/inventory/issues/dispatches/:id
 * Retrieve single stock issue
 */
issueAllocationRouter.get(
  '/issues/dispatches/:id',
  requireAuth,
  requirePermission('inventory.issues.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = resolveSchoolId(req);
      const issue = IssueAllocationService.getStockIssueById(schoolId, req.params.id);
      res.json({ success: true, data: issue });
    } catch (error: any) {
      const status = error.message?.includes('not found') ? 404 : 500;
      res.status(status).json({ success: false, error: error.message || 'Failed to fetch stock issue' });
    }
  }
);

/**
 * POST /api/inventory/issues/dispatches
 * Execute Stock Issue (Authoritative deduction via StockService)
 */
issueAllocationRouter.post(
  '/issues/dispatches',
  requireAuth,
  requirePermission('inventory.issues.execute'),
  async (req: AuthenticatedRequest, res: Response): Promise<void> => {
    try {
      const schoolId = resolveSchoolId(req);
      const result = await IssueAllocationService.executeStockIssue(schoolId, req.body, req.user);
      res.status(201).json({
        success: true,
        data: result.stockIssue,
        issueRequest: result.issueRequest,
        message: `Stock issue ${result.stockIssue.issueNumber} executed successfully.`
      });
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message || 'Failed to execute stock issue' });
    }
  }
);

// ============================================================================
// 3. INVENTORY RETURN ENDPOINTS
// ============================================================================

/**
 * GET /api/inventory/returns
 * List inventory returns
 */
issueAllocationRouter.get(
  '/returns',
  requireAuth,
  requirePermission('inventory.returns.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = resolveSchoolId(req);
      const result = IssueAllocationService.getInventoryReturns(schoolId, {
        search: req.query.search as string,
        issueId: req.query.issueId as string,
        locationId: req.query.locationId as string,
        page: req.query.page ? parseInt(req.query.page as string, 10) : 1,
        limit: req.query.limit ? parseInt(req.query.limit as string, 10) : 20
      });
      res.json({ success: true, ...result });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to fetch returns' });
    }
  }
);

/**
 * POST /api/inventory/returns
 * Record inventory return
 */
issueAllocationRouter.post(
  '/returns',
  requireAuth,
  requirePermission('inventory.returns.create'),
  async (req: AuthenticatedRequest, res: Response): Promise<void> => {
    try {
      const schoolId = resolveSchoolId(req);
      const result = await IssueAllocationService.recordInventoryReturn(schoolId, req.body, req.user);
      res.status(201).json({
        success: true,
        data: result.inventoryReturn,
        stockIssue: result.stockIssue,
        message: `Inventory return ${result.inventoryReturn.returnNumber} processed successfully.`
      });
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message || 'Failed to process inventory return' });
    }
  }
);

// ============================================================================
// 4. BULK ASSET ALLOCATION ENDPOINTS
// ============================================================================

/**
 * POST /api/inventory/allocations/bulk
 * Bulk allocate assets
 */
issueAllocationRouter.post(
  '/allocations/bulk',
  requireAuth,
  requirePermission('assets.allocation.manage'),
  async (req: AuthenticatedRequest, res: Response): Promise<void> => {
    try {
      const schoolId = resolveSchoolId(req);
      const result = await IssueAllocationService.bulkAllocateAssets(schoolId, req.body, req.user);
      res.status(201).json({
        success: true,
        data: result,
        message: `Successfully allocated ${result.successfulCount} assets.`
      });
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message || 'Failed to bulk allocate assets' });
    }
  }
);

// ============================================================================
// 5. DEPARTMENT ALLOCATIONS ENDPOINTS
// ============================================================================

/**
 * GET /api/inventory/departments
 * Summaries of assets, stock issues, and custodians across departments
 */
issueAllocationRouter.get(
  '/departments',
  requireAuth,
  requirePermission('assets.department.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = resolveSchoolId(req);
      const summaries = IssueAllocationService.getDepartmentAllocations(schoolId, req.query.departmentId as string);
      res.json({ success: true, data: summaries });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to fetch department allocations' });
    }
  }
);

/**
 * GET /api/inventory/departments/:id
 * Single department asset & issue details
 */
issueAllocationRouter.get(
  '/departments/:id',
  requireAuth,
  requirePermission('assets.department.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = resolveSchoolId(req);
      const summaries = IssueAllocationService.getDepartmentAllocations(schoolId, req.params.id);
      if (!summaries || summaries.length === 0) {
        res.status(404).json({ success: false, error: 'Department not found' });
        return;
      }
      res.json({ success: true, data: summaries[0] });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to fetch department allocation' });
    }
  }
);
