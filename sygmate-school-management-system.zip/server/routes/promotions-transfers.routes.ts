import { Router, Response } from 'express';
import { database } from '../db/database.js';
import { requireAuth, AuthenticatedRequest } from '../security/auth.js';
import { logAudit } from '../security/audit.js';
import {
  AcademicEnrollment,
  StudentPromotionRecord,
  BulkPromotionBatch,
  BulkPromotionPreviewStudent,
  TransferRecord,
  TransferCertificate,
  StudentStatusHistoryEntry,
  StudentAcademicStandingSummary,
  PromotionTransferStats,
  PromotionType,
  PromotionAction,
  PromotionDecisionStatus,
  StudentStatusType
} from '../../src/types/index.js';

export const promotionsTransfersRouter = Router();

// ============================================================================
// HELPER UTILITIES
// ============================================================================

function recordAuditLog(
  req: AuthenticatedRequest,
  action: string,
  details: string,
  metadata?: any,
  entityId?: string
) {
  logAudit({
    userId: req.user?.id || 'usr-admin-1',
    userName: req.user?.name || 'System Administrator',
    userRole: req.user?.role || 'SUPER_ADMIN',
    action,
    entity: 'StudentAcademicLifecycle',
    entityType: 'PROMOTION_TRANSFER',
    entityId,
    details,
    ipAddress: (req.ip as string) || '127.0.0.1',
    metadata
  });
}

/**
 * Generate sequential TC Number (e.g. TC-2026-0042)
 */
function generateNextTCNumber(): string {
  const currentYear = new Date().getFullYear();
  const existingTCs = database.transferCertificates || [];
  const maxSeq = existingTCs.reduce((max, tc) => {
    const parts = tc.tcNumber.split('-');
    if (parts.length >= 3) {
      const seq = parseInt(parts[2], 10);
      return !isNaN(seq) && seq > max ? seq : max;
    }
    return max;
  }, 0);

  const nextSeq = maxSeq + 1;
  return `TC-${currentYear}-${String(nextSeq).padStart(4, '0')}`;
}

/**
 * Calculate academic, attendance, and financial standing for a student
 */
function calculateStudentStanding(studentId: string, sessionId?: string): StudentAcademicStandingSummary {
  const student = database.studentProfiles.find((s) => s.id === studentId);
  const targetSessionId = sessionId || student?.academicSessionId || database.academicSessions.find((s) => s.isActive)?.id;

  // 1. Exam marks & GPA
  const studentResults = database.examResults.filter(
    (r) => r.studentId === studentId && (!targetSessionId || r.academicSessionId === targetSessionId)
  );

  let cumulativeGPA = 3.5;
  let overallPercentage = 85.0;
  let totalExams = studentResults.length;
  let passedExams = 0;
  let failedExams = 0;
  let passedAllCore = true;

  if (studentResults.length > 0) {
    const totalGpa = studentResults.reduce((acc, curr) => acc + (curr.summary?.gpa || 0), 0);
    cumulativeGPA = parseFloat((totalGpa / studentResults.length).toFixed(2));

    const totalPct = studentResults.reduce((acc, curr) => acc + (curr.summary?.overallPercentage || 0), 0);
    overallPercentage = parseFloat((totalPct / studentResults.length).toFixed(1));

    passedExams = studentResults.filter((r) => r.summary?.resultStatus === 'PASSED' || r.summary?.resultStatus === 'DISTINCTION').length;
    failedExams = studentResults.filter((r) => r.summary?.resultStatus === 'FAILED').length;
    passedAllCore = failedExams === 0;
  } else {
    // Default fallback based on student's overall profile data if results not entered yet
    cumulativeGPA = 3.6;
    overallPercentage = 88.0;
    totalExams = 6;
    passedExams = 6;
    failedExams = 0;
    passedAllCore = true;
  }

  let overallGrade = 'A';
  if (cumulativeGPA >= 3.8) overallGrade = 'A+';
  else if (cumulativeGPA >= 3.5) overallGrade = 'A';
  else if (cumulativeGPA >= 3.0) overallGrade = 'B+';
  else if (cumulativeGPA >= 2.5) overallGrade = 'B';
  else if (cumulativeGPA >= 2.0) overallGrade = 'C';
  else overallGrade = 'F';

  // 2. Attendance Standing
  const studentAttendance = database.attendanceRecords.filter(
    (a) => a.studentId === studentId
  );
  let attendancePercentage = 94.5;
  if (studentAttendance.length > 0) {
    const presentCount = studentAttendance.filter((a) => a.status === 'PRESENT' || a.status === 'LATE').length;
    attendancePercentage = parseFloat(((presentCount / studentAttendance.length) * 100).toFixed(1));
  }

  const attendanceStanding = attendancePercentage >= 85 ? 'EXCELLENT' : attendancePercentage >= 75 ? 'SATISFACTORY' : 'ATTENDANCE_WARNING';

  // 3. Fee dues
  const studentFees = database.feeRecords.filter(
    (f) => f.studentId === studentId && f.status !== 'PAID'
  );
  const totalDueFees = studentFees.reduce((acc, curr) => acc + (curr.dueAmount || 0), 0);
  const hasOutstandingFees = totalDueFees > 0;

  return {
    cumulativeGPA,
    overallGrade,
    totalExams,
    passedExams,
    failedExams,
    passedAllCore,
    overallPercentage,
    attendancePercentage,
    attendanceStanding,
    totalDueFees,
    hasOutstandingFees
  };
}

/**
 * Suggest next roll number for target class and section
 */
function suggestNextRollNumber(targetClassId: string, targetSectionId: string, targetSessionId: string): string {
  const targetClass = database.classes.find((c) => c.id === targetClassId);
  const targetSection = database.sections.find((s) => s.id === targetSectionId);

  const prefix = targetClass?.name ? targetClass.name.replace(/\s+/g, '').toUpperCase().slice(0, 3) : 'G10';
  const secLetter = targetSection?.name ? targetSection.name.replace(/Section\s*/i, '').trim().toUpperCase() : 'A';

  // Look for existing enrollments or student profiles in target section
  const existingEnrollments = database.academicEnrollments.filter(
    (e) => e.classId === targetClassId && e.sectionId === targetSectionId && e.academicSessionId === targetSessionId && e.status === 'active'
  );

  let highestNum = 0;
  for (const enr of existingEnrollments) {
    const match = enr.rollNumber?.match(/(\d+)$/);
    if (match) {
      const num = parseInt(match[1], 10);
      if (!isNaN(num) && num > highestNum) highestNum = num;
    }
  }

  return `${prefix}-${secLetter}-${String(highestNum + 1).padStart(2, '0')}`;
}

// ============================================================================
// 1. STATS & OVERVIEW
// ============================================================================

promotionsTransfersRouter.get('/stats', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const enrollments = database.academicEnrollments || [];
    const promotions = database.studentPromotionRecords || [];
    const transfers = database.studentTransferRecords || [];
    const tcs = database.transferCertificates || [];
    const students = database.studentProfiles || [];

    const stats: PromotionTransferStats = {
      totalEnrollments: enrollments.length,
      activeEnrollments: enrollments.filter((e) => e.status === 'active').length,
      promotedThisYear: promotions.filter((p) => p.status === 'COMPLETED').length,
      transferredCount: transfers.filter((t) => t.status === 'COMPLETED').length,
      graduatedCount: enrollments.filter((e) => e.status === 'graduated').length,
      suspendedCount: students.filter((s) => s.status === 'suspended').length,
      withdrawnCount: students.filter((s) => s.status === 'withdrawn').length,
      retainedCount: promotions.filter((p) => p.promotionType === 'RETAINED_REPEAT').length,
      tcIssuedCount: tcs.filter((t) => t.status === 'ACTIVE').length
    };

    res.json({
      success: true,
      stats
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ============================================================================
// 2. ENROLLMENTS & TIMELINE
// ============================================================================

/**
 * GET /api/promotions-transfers/enrollments
 * Filterable list of academic enrollments
 */
promotionsTransfersRouter.get('/enrollments', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { studentId, academicSessionId, classId, sectionId, status, search } = req.query as Record<string, string>;

    let enrollments = [...(database.academicEnrollments || [])];

    if (studentId) {
      enrollments = enrollments.filter((e) => e.studentId === studentId);
    }
    if (academicSessionId) {
      enrollments = enrollments.filter((e) => e.academicSessionId === academicSessionId);
    }
    if (classId) {
      enrollments = enrollments.filter((e) => e.classId === classId);
    }
    if (sectionId) {
      enrollments = enrollments.filter((e) => e.sectionId === sectionId);
    }
    if (status) {
      enrollments = enrollments.filter((e) => e.status === status);
    }
    if (search) {
      const q = search.toLowerCase();
      enrollments = enrollments.filter(
        (e) =>
          e.studentName.toLowerCase().includes(q) ||
          e.studentAdmissionNumber.toLowerCase().includes(q) ||
          e.enrollmentNumber.toLowerCase().includes(q) ||
          e.rollNumber.toLowerCase().includes(q)
      );
    }

    // Sort descending by enrollment date
    enrollments.sort((a, b) => new Date(b.enrollmentDate || b.createdAt).getTime() - new Date(a.enrollmentDate || a.createdAt).getTime());

    res.json({
      success: true,
      total: enrollments.length,
      enrollments
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * GET /api/promotions-transfers/student/:studentId/timeline
 * Complete historical academic timeline for a student (enrollments, promotions, transfers, status changes)
 */
promotionsTransfersRouter.get('/student/:studentId/timeline', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { studentId } = req.params;

    // RBAC: Check student access permissions
    if (req.user?.role === 'STUDENT') {
      const loggedStudent = database.studentProfiles.find((s) => s.userId === req.user?.id);
      if (loggedStudent && loggedStudent.id !== studentId) {
        res.status(403).json({ success: false, error: 'Access denied. You can only view your own academic timeline.' });
        return;
      }
    } else if (req.user?.role === 'GUARDIAN') {
      const guardian = database.guardians.find((g) => g.userId === req.user?.id);
      if (guardian && !guardian.studentIds.includes(studentId)) {
        res.status(403).json({ success: false, error: 'Access denied. You can only view academic timeline for your registered children.' });
        return;
      }
    }

    const student = database.studentProfiles.find((s) => s.id === studentId);
    if (!student) {
      res.status(404).json({ success: false, error: 'Student profile not found.' });
      return;
    }

    const enrollments = (database.academicEnrollments || [])
      .filter((e) => e.studentId === studentId)
      .sort((a, b) => new Date(a.enrollmentDate || a.createdAt).getTime() - new Date(b.enrollmentDate || b.createdAt).getTime());

    const promotions = (database.studentPromotionRecords || [])
      .filter((p) => p.studentId === studentId)
      .sort((a, b) => new Date(a.promotedAt).getTime() - new Date(b.promotedAt).getTime());

    const transfers = (database.studentTransferRecords || [])
      .filter((t) => t.studentId === studentId)
      .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());

    const transferCertificates = (database.transferCertificates || [])
      .filter((tc) => tc.studentId === studentId);

    const statusHistory = (database.studentStatusHistory || [])
      .filter((sh) => sh.studentId === studentId)
      .sort((a, b) => new Date(a.changedAt).getTime() - new Date(b.changedAt).getTime());

    const standing = calculateStudentStanding(studentId);

    res.json({
      success: true,
      student: {
        id: student.id,
        name: `${student.firstName || ''} ${student.lastName || ''}`.trim(),
        admissionNumber: student.admissionNumber,
        rollNumber: student.rollNumber,
        currentClass: student.className,
        currentSection: student.sectionName,
        currentSession: student.academicSessionName,
        status: student.status,
        avatarUrl: student.avatarUrl
      },
      enrollments,
      promotions,
      transfers,
      transferCertificates,
      statusHistory,
      standing
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * GET /api/promotions-transfers/student/:studentId/standing
 * Get academic standing summary
 */
promotionsTransfersRouter.get('/student/:studentId/standing', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { studentId } = req.params;
    const { sessionId } = req.query as { sessionId?: string };

    const student = database.studentProfiles.find((s) => s.id === studentId);
    if (!student) {
      res.status(404).json({ success: false, error: 'Student profile not found.' });
      return;
    }

    const standing = calculateStudentStanding(studentId, sessionId);
    res.json({
      success: true,
      studentId,
      studentName: `${student.firstName || ''} ${student.lastName || ''}`.trim(),
      standing
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ============================================================================
// 3. BULK PROMOTION DRY-RUN / PREVIEW & EXECUTE
// ============================================================================

/**
 * POST /api/promotions-transfers/preview-bulk
 * Comprehensive dry-run validation of a promotion batch before committing
 */
promotionsTransfersRouter.post('/preview-bulk', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const {
      sourceSessionId,
      sourceClassId,
      sourceSectionId,
      targetSessionId,
      targetClassId,
      targetSectionId,
      minGpa = 2.0,
      minAttendanceRate = 75.0,
      requireFeeClearance = false
    } = req.body;

    if (!sourceSessionId || !sourceClassId || !targetSessionId || !targetClassId) {
      res.status(400).json({
        success: false,
        error: 'sourceSessionId, sourceClassId, targetSessionId, and targetClassId are required fields.'
      });
      return;
    }

    const sourceSession = database.academicSessions.find((s) => s.id === sourceSessionId);
    const targetSession = database.academicSessions.find((s) => s.id === targetSessionId);
    const sourceClass = database.classes.find((c) => c.id === sourceClassId);
    const targetClass = database.classes.find((c) => c.id === targetClassId);

    if (!sourceSession || !targetSession || !sourceClass || !targetClass) {
      res.status(404).json({
        success: false,
        error: 'Specified academic session or class does not exist in records.'
      });
      return;
    }

    // Find all eligible candidate students in source session and class
    let candidateStudents = database.studentProfiles.filter((s) => {
      const matchesClass = s.classId === sourceClassId;
      const matchesSession = s.academicSessionId === sourceSessionId || (!s.academicSessionId && sourceSession.isActive);
      const matchesSection = !sourceSectionId || s.sectionId === sourceSectionId;
      const isEligibleStatus = s.status === 'active' || s.status === 'inactive';
      return matchesClass && matchesSession && matchesSection && isEligibleStatus;
    });

    // If source students list is empty, also check active AcademicEnrollments in source
    if (candidateStudents.length === 0) {
      const sourceEnrollments = database.academicEnrollments.filter((e) => {
        const matchesClass = e.classId === sourceClassId;
        const matchesSession = e.academicSessionId === sourceSessionId;
        const matchesSection = !sourceSectionId || e.sectionId === sourceSectionId;
        return matchesClass && matchesSession && matchesSection && e.status === 'active';
      });

      const studentIds = sourceEnrollments.map((e) => e.studentId);
      candidateStudents = database.studentProfiles.filter((s) => studentIds.includes(s.id));
    }

    // Target Sections for assignment
    const targetSections = database.sections.filter((s) => s.classId === targetClassId);
    const defaultTargetSection = targetSectionId
      ? targetSections.find((s) => s.id === targetSectionId) || targetSections[0]
      : targetSections[0];

    // Existing rolls in target class & section for target session
    const existingTargetRolls = new Set(
      database.academicEnrollments
        .filter((e) => e.classId === targetClassId && e.academicSessionId === targetSessionId && e.status === 'active')
        .map((e) => e.rollNumber?.toLowerCase())
    );

    let nextRollSeq = 1;
    const previewStudents: BulkPromotionPreviewStudent[] = candidateStudents.map((s) => {
      const standing = calculateStudentStanding(s.id, sourceSessionId);
      const studentName = `${s.firstName || ''} ${s.lastName || ''}`.trim();

      const validationErrors: string[] = [];
      const validationWarnings: string[] = [];
      let eligibilityStatus: PromotionDecisionStatus = 'ELIGIBLE';
      let decision: PromotionAction = 'PROMOTE';
      let promotionType: PromotionType = 'REGULAR_PROMOTION';

      // Academic criteria check
      if (standing.cumulativeGPA < minGpa) {
        validationErrors.push(`Cumulative GPA (${standing.cumulativeGPA}) is below minimum threshold (${minGpa}).`);
        eligibilityStatus = 'FAILED_ACADEMIC';
        decision = 'RETAIN';
        promotionType = 'RETAINED_REPEAT';
      }

      if (!standing.passedAllCore) {
        validationWarnings.push(`Student failed ${standing.failedExams} core examination(s). Conditional promotion recommended.`);
        if (eligibilityStatus === 'ELIGIBLE') {
          eligibilityStatus = 'WARNING_ATTENDANCE';
          promotionType = 'CONDITIONAL_PROMOTION';
        }
      }

      // Attendance criteria check
      if (standing.attendancePercentage < minAttendanceRate) {
        validationWarnings.push(`Attendance rate (${standing.attendancePercentage}%) is below recommended threshold (${minAttendanceRate}%).`);
        if (eligibilityStatus === 'ELIGIBLE') {
          eligibilityStatus = 'WARNING_ATTENDANCE';
        }
      }

      // Financial check
      if (standing.hasOutstandingFees) {
        if (requireFeeClearance) {
          validationErrors.push(`Unresolved fee balance of $${standing.totalDueFees.toFixed(2)}. Fee clearance required.`);
          eligibilityStatus = 'WARNING_FEES';
        } else {
          validationWarnings.push(`Outstanding fee balance of $${standing.totalDueFees.toFixed(2)}. Administrative override applicable.`);
          if (eligibilityStatus === 'ELIGIBLE') {
            eligibilityStatus = 'WARNING_FEES';
          }
        }
      }

      // Determine suggested target section
      // Match section name if exists in target, else use default target section
      let suggestedSec = defaultTargetSection;
      if (!targetSectionId && s.sectionName) {
        const matchingSec = targetSections.find((sec) => sec.name.toLowerCase() === s.sectionName?.toLowerCase());
        if (matchingSec) suggestedSec = matchingSec;
      }

      // Suggest next available roll
      const prefix = targetClass.name.replace(/\s+/g, '').toUpperCase().slice(0, 3);
      const secLetter = suggestedSec?.name ? suggestedSec.name.replace(/Section\s*/i, '').trim().toUpperCase() : 'A';
      let suggestedRoll = `${prefix}-${secLetter}-${String(nextRollSeq).padStart(2, '0')}`;
      while (existingTargetRolls.has(suggestedRoll.toLowerCase())) {
        nextRollSeq++;
        suggestedRoll = `${prefix}-${secLetter}-${String(nextRollSeq).padStart(2, '0')}`;
      }
      existingTargetRolls.add(suggestedRoll.toLowerCase());
      nextRollSeq++;

      return {
        studentId: s.id,
        studentName,
        admissionNumber: s.admissionNumber,
        currentRollNumber: s.rollNumber || 'N/A',
        currentClassId: s.classId,
        currentClassName: s.className || sourceClass.name,
        currentSectionId: s.sectionId,
        currentSectionName: s.sectionName || 'Section A',
        suggestedClassId: targetClass.id,
        suggestedClassName: targetClass.name,
        suggestedSectionId: suggestedSec ? suggestedSec.id : '',
        suggestedSectionName: suggestedSec ? suggestedSec.name : '',
        suggestedRollNumber: suggestedRoll,
        gpa: standing.cumulativeGPA,
        percentage: standing.overallPercentage,
        attendanceRate: standing.attendancePercentage,
        passedAllCore: standing.passedAllCore,
        failedSubjectsCount: standing.failedExams,
        totalDue: standing.totalDueFees,
        decision,
        promotionType,
        eligibilityStatus,
        validationErrors,
        validationWarnings,
        feeOverrideApproved: false
      };
    });

    const eligibleCount = previewStudents.filter((p) => p.eligibilityStatus === 'ELIGIBLE').length;
    const warningCount = previewStudents.filter((p) => p.eligibilityStatus === 'WARNING_FEES' || p.eligibilityStatus === 'WARNING_ATTENDANCE').length;
    const failedCount = previewStudents.filter((p) => p.eligibilityStatus === 'FAILED_ACADEMIC').length;

    res.json({
      success: true,
      sourceSessionName: sourceSession.sessionName,
      targetSessionName: targetSession.sessionName,
      sourceClassName: sourceClass.name,
      targetClassName: targetClass.name,
      summary: {
        totalStudents: previewStudents.length,
        eligibleCount,
        warningCount,
        failedCount,
        availableTargetSections: targetSections.map((s) => ({ id: s.id, name: s.name, capacity: s.capacity }))
      },
      students: previewStudents
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * POST /api/promotions-transfers/execute-bulk
 * Transactional, atomic execution of a verified bulk student promotion batch
 */
promotionsTransfersRouter.post('/execute-bulk', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const {
      title,
      sourceSessionId,
      sourceClassId,
      sourceSectionId,
      targetSessionId,
      targetClassId,
      targetSectionId,
      decisions
    } = req.body as {
      title: string;
      sourceSessionId: string;
      sourceClassId: string;
      sourceSectionId?: string;
      targetSessionId: string;
      targetClassId: string;
      targetSectionId?: string;
      decisions: Array<{
        studentId: string;
        decision: PromotionAction;
        promotionType: PromotionType;
        targetClassId: string;
        targetSectionId: string;
        targetRollNumber: string;
        feeOverrideApproved?: boolean;
        feeOverrideReason?: string;
        remarks?: string;
      }>;
    };

    if (!sourceSessionId || !targetSessionId || !decisions || decisions.length === 0) {
      res.status(400).json({
        success: false,
        error: 'Missing required promotion execution parameters.'
      });
      return;
    }

    const sourceSession = database.academicSessions.find((s) => s.id === sourceSessionId);
    const targetSession = database.academicSessions.find((s) => s.id === targetSessionId);
    const sourceClass = database.classes.find((c) => c.id === sourceClassId);
    const targetClass = database.classes.find((c) => c.id === targetClassId);

    if (!sourceSession || !targetSession || !sourceClass || !targetClass) {
      res.status(404).json({
        success: false,
        error: 'Academic session or class records not found.'
      });
      return;
    }

    // Step 1: Pre-commit Validation: Roll Number Collision Detection
    const activeRollsInTarget = new Map<string, string>(); // rollNumber -> studentId
    // Populate with currently active target enrollments
    for (const enr of database.academicEnrollments) {
      if (enr.academicSessionId === targetSessionId && enr.classId === targetClassId && enr.status === 'active') {
        activeRollsInTarget.set(`${enr.sectionId}::${enr.rollNumber?.toLowerCase()}`, enr.studentId);
      }
    }

    // Check decisions for internal duplicates or collision with existing active
    const batchRolls = new Set<string>();
    for (const d of decisions) {
      if (d.decision === 'PROMOTE' || d.decision === 'RETAIN') {
        const rollKey = `${d.targetSectionId}::${d.targetRollNumber?.trim().toLowerCase()}`;
        if (batchRolls.has(rollKey)) {
          res.status(409).json({
            success: false,
            error: `Roll number collision detected: Roll number '${d.targetRollNumber}' is duplicated within the promotion batch for target section.`,
            code: 'ROLL_COLLISION'
          });
          return;
        }
        batchRolls.add(rollKey);

        const existingHolder = activeRollsInTarget.get(rollKey);
        if (existingHolder && existingHolder !== d.studentId) {
          res.status(409).json({
            success: false,
            error: `Roll number collision detected: Roll number '${d.targetRollNumber}' is already occupied in target section by an existing enrolled student.`,
            code: 'ROLL_ALREADY_OCCUPIED'
          });
          return;
        }
      }
    }

    // Step 2: Atomic Execution
    const batchId = `prom-batch-${Date.now()}`;
    const timestamp = new Date().toISOString();
    const executedBy = req.user?.id || 'usr-admin-1';
    const executedByName = req.user?.name || 'System Administrator';

    const createdRecords: StudentPromotionRecord[] = [];
    let promotedCount = 0;
    let retainedCount = 0;
    let graduatedCount = 0;
    let excludedCount = 0;

    for (const item of decisions) {
      if (item.decision === 'EXCLUDE') {
        excludedCount++;
        continue;
      }

      const student = database.studentProfiles.find((s) => s.id === item.studentId);
      if (!student) continue;

      const standing = calculateStudentStanding(student.id, sourceSessionId);
      const studentName = `${student.firstName || ''} ${student.lastName || ''}`.trim();
      const targetSec = database.sections.find((sec) => sec.id === item.targetSectionId);
      const tClass = database.classes.find((c) => c.id === item.targetClassId) || targetClass;

      // 1. Find and update the historical active enrollment in source session
      const previousEnrollment = database.academicEnrollments.find(
        (e) => e.studentId === student.id && e.academicSessionId === sourceSessionId && e.status === 'active'
      );

      const promotionRecordId = `prom-rec-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
      const newEnrollmentId = `enr-${Date.now()}-${Math.floor(Math.random() * 1000)}`;

      if (previousEnrollment) {
        previousEnrollment.status = item.decision === 'PROMOTE' ? 'promoted' : item.decision === 'RETAIN' ? 'retained' : 'graduated';
        previousEnrollment.completionDate = timestamp.split('T')[0];
        previousEnrollment.promotionRecordId = promotionRecordId;
        previousEnrollment.promotedToSessionId = targetSessionId;
        previousEnrollment.promotedToClassId = item.targetClassId;
        previousEnrollment.promotedToSectionId = item.targetSectionId;
        previousEnrollment.resultSummary = {
          gpa: standing.cumulativeGPA,
          overallGrade: standing.overallGrade,
          percentage: standing.overallPercentage,
          passed: standing.passedAllCore,
          attendancePercentage: standing.attendancePercentage
        };
        previousEnrollment.updatedAt = timestamp;
      }

      if (item.decision === 'PROMOTE' || item.decision === 'RETAIN') {
        if (item.decision === 'PROMOTE') promotedCount++;
        if (item.decision === 'RETAIN') retainedCount++;

        // 2. Create new AcademicEnrollment in target session
        const nextEnrollmentSeq = database.academicEnrollments.length + 1;
        const newEnrollmentNumber = `ENR-${new Date().getFullYear()}-${String(nextEnrollmentSeq).padStart(4, '0')}`;

        const newEnrollment: AcademicEnrollment = {
          id: newEnrollmentId,
          enrollmentNumber: newEnrollmentNumber,
          studentId: student.id,
          studentAdmissionNumber: student.admissionNumber,
          studentName,
          academicSessionId: targetSessionId,
          academicSessionName: targetSession.sessionName,
          classId: item.targetClassId,
          className: tClass.name,
          sectionId: item.targetSectionId,
          sectionName: targetSec?.name || 'Section A',
          rollNumber: item.targetRollNumber,
          enrollmentDate: timestamp.split('T')[0],
          status: 'active',
          promotionRecordId,
          remarks: item.remarks || (item.decision === 'PROMOTE' ? 'Promoted from previous academic session' : 'Retained in academic session repeat'),
          createdAt: timestamp,
          updatedAt: timestamp
        };
        database.academicEnrollments.push(newEnrollment);

        // 3. Update active StudentProfile
        student.academicSessionId = targetSessionId;
        student.academicSessionName = targetSession.sessionName;
        student.classId = item.targetClassId;
        student.className = tClass.name;
        student.sectionId = item.targetSectionId;
        student.sectionName = targetSec?.name || 'Section A';
        student.rollNumber = item.targetRollNumber;
        student.status = 'active';
        student.updatedAt = timestamp;
      } else if (item.decision === 'GRADUATE') {
        graduatedCount++;
        student.status = 'graduated';
        student.updatedAt = timestamp;
      }

      // 4. Create promotion record
      const promRecord: StudentPromotionRecord = {
        id: promotionRecordId,
        batchId,
        studentId: student.id,
        studentName,
        admissionNumber: student.admissionNumber,
        fromSessionId: sourceSessionId,
        fromSessionName: sourceSession.sessionName,
        fromClassId: sourceClassId,
        fromClassName: sourceClass.name,
        fromSectionId: student.sectionId,
        fromSectionName: student.sectionName || 'Section A',
        fromRollNumber: student.rollNumber || 'N/A',
        toSessionId: targetSessionId,
        toSessionName: targetSession.sessionName,
        toClassId: item.targetClassId,
        toClassName: tClass.name,
        toSectionId: item.targetSectionId,
        toSectionName: targetSec?.name || 'Section A',
        toRollNumber: item.targetRollNumber,
        promotionType: item.promotionType || (item.decision === 'RETAIN' ? 'RETAINED_REPEAT' : 'REGULAR_PROMOTION'),
        action: item.decision,
        academicStanding: {
          gpa: standing.cumulativeGPA,
          percentage: standing.overallPercentage,
          passedExams: standing.passedExams,
          failedExams: standing.failedExams,
          attendancePercentage: standing.attendancePercentage,
          standingGrade: standing.overallGrade,
          passedAllCore: standing.passedAllCore
        },
        feeStatus: {
          hasOutstandingDues: standing.hasOutstandingFees,
          totalDue: standing.totalDueFees,
          overrideApproved: !!item.feeOverrideApproved,
          overrideReason: item.feeOverrideReason
        },
        status: 'COMPLETED',
        promotedBy: executedBy,
        promotedByName: executedByName,
        promotedAt: timestamp,
        remarks: item.remarks || 'Bulk promotion batch processed',
        previousEnrollmentId: previousEnrollment?.id,
        newEnrollmentId: item.decision !== 'GRADUATE' ? newEnrollmentId : undefined
      };

      database.studentPromotionRecords.push(promRecord);
      createdRecords.push(promRecord);
    }

    // Save batch record
    const batchRecord: BulkPromotionBatch = {
      id: batchId,
      title: title || `Annual Promotion Batch ${sourceSession.sessionName} -> ${targetSession.sessionName}`,
      sourceSessionId,
      sourceSessionName: sourceSession.sessionName,
      sourceClassId,
      sourceClassName: sourceClass.name,
      sourceSectionId,
      sourceSectionName: database.sections.find((s) => s.id === sourceSectionId)?.name,
      targetSessionId,
      targetSessionName: targetSession.sessionName,
      targetClassId,
      targetClassName: targetClass.name,
      targetSectionId,
      targetSectionName: database.sections.find((s) => s.id === targetSectionId)?.name,
      totalStudents: decisions.length,
      promotedCount,
      retainedCount,
      graduatedCount,
      excludedCount,
      executedBy,
      executedByName,
      executedAt: timestamp,
      records: createdRecords
    };

    database.bulkPromotionBatches.push(batchRecord);

    // Audit Log
    recordAuditLog(
      req,
      'PROMOTION_BULK_EXECUTE',
      `Executed bulk promotion batch '${batchRecord.title}': ${promotedCount} promoted, ${retainedCount} retained, ${graduatedCount} graduated.`,
      { batchId, sourceClassId, targetClassId, totalProcessed: createdRecords.length },
      batchId
    );

    res.json({
      success: true,
      batchId,
      summary: {
        totalSubmitted: decisions.length,
        promotedCount,
        retainedCount,
        graduatedCount,
        excludedCount
      },
      records: createdRecords
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ============================================================================
// 4. INDIVIDUAL STUDENT PROMOTION
// ============================================================================

/**
 * POST /api/promotions-transfers/promote-individual
 */
promotionsTransfersRouter.post('/promote-individual', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const {
      studentId,
      targetSessionId,
      targetClassId,
      targetSectionId,
      targetRollNumber,
      promotionType = 'REGULAR_PROMOTION',
      feeOverrideApproved = false,
      feeOverrideReason,
      remarks
    } = req.body;

    if (!studentId || !targetSessionId || !targetClassId || !targetSectionId || !targetRollNumber) {
      res.status(400).json({
        success: false,
        error: 'studentId, targetSessionId, targetClassId, targetSectionId, and targetRollNumber are required.'
      });
      return;
    }

    const student = database.studentProfiles.find((s) => s.id === studentId);
    if (!student) {
      res.status(404).json({ success: false, error: 'Student profile not found.' });
      return;
    }

    const targetSession = database.academicSessions.find((s) => s.id === targetSessionId);
    const targetClass = database.classes.find((c) => c.id === targetClassId);
    const targetSection = database.sections.find((sec) => sec.id === targetSectionId);

    if (!targetSession || !targetClass || !targetSection) {
      res.status(404).json({ success: false, error: 'Target academic session, class, or section not found.' });
      return;
    }

    // Check roll collision in target section
    const isRollOccupied = database.academicEnrollments.some(
      (e) =>
        e.academicSessionId === targetSessionId &&
        e.classId === targetClassId &&
        e.sectionId === targetSectionId &&
        e.status === 'active' &&
        e.rollNumber?.toLowerCase() === targetRollNumber.trim().toLowerCase() &&
        e.studentId !== studentId
    );

    if (isRollOccupied) {
      res.status(409).json({
        success: false,
        error: `Roll number '${targetRollNumber}' is already occupied in ${targetClass.name} - ${targetSection.name} for this session.`,
        code: 'ROLL_NUMBER_EXISTS'
      });
      return;
    }

    const standing = calculateStudentStanding(studentId, student.academicSessionId);
    const timestamp = new Date().toISOString();
    const executedBy = req.user?.id || 'usr-admin-1';
    const executedByName = req.user?.name || 'System Administrator';
    const studentName = `${student.firstName || ''} ${student.lastName || ''}`.trim();

    // 1. Close current active enrollment
    const currentEnrollment = database.academicEnrollments.find(
      (e) => e.studentId === studentId && e.status === 'active'
    );

    const promotionRecordId = `prom-rec-${Date.now()}`;
    const newEnrollmentId = `enr-${Date.now()}`;

    if (currentEnrollment) {
      currentEnrollment.status = promotionType === 'RETAINED_REPEAT' ? 'retained' : 'promoted';
      currentEnrollment.completionDate = timestamp.split('T')[0];
      currentEnrollment.promotionRecordId = promotionRecordId;
      currentEnrollment.promotedToSessionId = targetSessionId;
      currentEnrollment.promotedToClassId = targetClassId;
      currentEnrollment.promotedToSectionId = targetSectionId;
      currentEnrollment.resultSummary = {
        gpa: standing.cumulativeGPA,
        overallGrade: standing.overallGrade,
        percentage: standing.overallPercentage,
        passed: standing.passedAllCore,
        attendancePercentage: standing.attendancePercentage
      };
      currentEnrollment.updatedAt = timestamp;
    }

    // 2. Create new active enrollment
    const nextEnrollmentSeq = database.academicEnrollments.length + 1;
    const newEnrollmentNumber = `ENR-${new Date().getFullYear()}-${String(nextEnrollmentSeq).padStart(4, '0')}`;

    const newEnrollment: AcademicEnrollment = {
      id: newEnrollmentId,
      enrollmentNumber: newEnrollmentNumber,
      studentId: student.id,
      studentAdmissionNumber: student.admissionNumber,
      studentName,
      academicSessionId: targetSessionId,
      academicSessionName: targetSession.sessionName,
      classId: targetClassId,
      className: targetClass.name,
      sectionId: targetSectionId,
      sectionName: targetSection.name,
      rollNumber: targetRollNumber,
      enrollmentDate: timestamp.split('T')[0],
      status: 'active',
      promotionRecordId,
      remarks: remarks || `Promoted to ${targetClass.name} - ${targetSection.name}`,
      createdAt: timestamp,
      updatedAt: timestamp
    };
    database.academicEnrollments.push(newEnrollment);

    // 3. Update StudentProfile
    const fromSessionId = student.academicSessionId;
    const fromSessionName = student.academicSessionName || 'Previous Session';
    const fromClassId = student.classId;
    const fromClassName = student.className || 'Previous Class';
    const fromSectionId = student.sectionId;
    const fromSectionName = student.sectionName || 'Previous Section';
    const fromRollNumber = student.rollNumber || 'N/A';

    student.academicSessionId = targetSessionId;
    student.academicSessionName = targetSession.sessionName;
    student.classId = targetClassId;
    student.className = targetClass.name;
    student.sectionId = targetSectionId;
    student.sectionName = targetSection.name;
    student.rollNumber = targetRollNumber;
    student.status = 'active';
    student.updatedAt = timestamp;

    // 4. Create promotion record
    const promotionRecord: StudentPromotionRecord = {
      id: promotionRecordId,
      studentId: student.id,
      studentName,
      admissionNumber: student.admissionNumber,
      fromSessionId,
      fromSessionName,
      fromClassId,
      fromClassName,
      fromSectionId,
      fromSectionName,
      fromRollNumber,
      toSessionId: targetSessionId,
      toSessionName: targetSession.sessionName,
      toClassId: targetClassId,
      toClassName: targetClass.name,
      toSectionId: targetSectionId,
      toSectionName: targetSection.name,
      toRollNumber: targetRollNumber,
      promotionType,
      action: promotionType === 'RETAINED_REPEAT' ? 'RETAIN' : 'PROMOTE',
      academicStanding: {
        gpa: standing.cumulativeGPA,
        percentage: standing.overallPercentage,
        passedExams: standing.passedExams,
        failedExams: standing.failedExams,
        attendancePercentage: standing.attendancePercentage,
        standingGrade: standing.overallGrade,
        passedAllCore: standing.passedAllCore
      },
      feeStatus: {
        hasOutstandingDues: standing.hasOutstandingFees,
        totalDue: standing.totalDueFees,
        overrideApproved: !!feeOverrideApproved,
        overrideReason: feeOverrideReason
      },
      status: 'COMPLETED',
      promotedBy: executedBy,
      promotedByName: executedByName,
      promotedAt: timestamp,
      remarks,
      previousEnrollmentId: currentEnrollment?.id,
      newEnrollmentId
    };

    database.studentPromotionRecords.push(promotionRecord);

    recordAuditLog(
      req,
      'PROMOTION_INDIVIDUAL',
      `Promoted student ${studentName} (${student.admissionNumber}) from ${fromClassName} to ${targetClass.name} - ${targetSection.name}.`,
      { studentId, fromClassId, targetClassId, promotionRecordId },
      studentId
    );

    res.json({
      success: true,
      message: `Student ${studentName} successfully promoted to ${targetClass.name} - ${targetSection.name}.`,
      record: promotionRecord,
      enrollment: newEnrollment
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ============================================================================
// 5. INTERNAL SECTION / CLASS TRANSFER
// ============================================================================

/**
 * POST /api/promotions-transfers/transfer-internal
 */
promotionsTransfersRouter.post('/transfer-internal', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const {
      studentId,
      transferType = 'INTERNAL_SECTION', // 'INTERNAL_SECTION' | 'INTERNAL_CLASS'
      targetClassId,
      targetSectionId,
      targetRollNumber,
      reason,
      effectiveDate,
      libraryCleared = true,
      feesCleared = true
    } = req.body;

    if (!studentId || !targetSectionId || !reason) {
      res.status(400).json({
        success: false,
        error: 'studentId, targetSectionId, and reason are required for internal transfer.'
      });
      return;
    }

    const student = database.studentProfiles.find((s) => s.id === studentId);
    if (!student) {
      res.status(404).json({ success: false, error: 'Student profile not found.' });
      return;
    }

    const effectiveTargetClassId = targetClassId || student.classId;
    const targetClass = database.classes.find((c) => c.id === effectiveTargetClassId);
    const targetSection = database.sections.find((s) => s.id === targetSectionId);

    if (!targetClass || !targetSection) {
      res.status(404).json({ success: false, error: 'Target class or section not found.' });
      return;
    }

    // Auto-generate target roll if not specified
    const assignedRoll = targetRollNumber || suggestNextRollNumber(targetClass.id, targetSection.id, student.academicSessionId);

    // Roll collision check
    const rollOccupied = database.academicEnrollments.some(
      (e) =>
        e.academicSessionId === student.academicSessionId &&
        e.classId === effectiveTargetClassId &&
        e.sectionId === targetSectionId &&
        e.status === 'active' &&
        e.rollNumber?.toLowerCase() === assignedRoll.trim().toLowerCase() &&
        e.studentId !== studentId
    );

    if (rollOccupied) {
      res.status(409).json({
        success: false,
        error: `Roll number '${assignedRoll}' is already assigned in ${targetClass.name} - ${targetSection.name}.`,
        code: 'ROLL_COLLISION'
      });
      return;
    }

    const timestamp = new Date().toISOString();
    const approvedBy = req.user?.id || 'usr-admin-1';
    const approvedByName = req.user?.name || 'System Administrator';
    const studentName = `${student.firstName || ''} ${student.lastName || ''}`.trim();

    // 1. Close current enrollment with 'transferred' status
    const currentEnrollment = database.academicEnrollments.find(
      (e) => e.studentId === studentId && e.status === 'active'
    );
    const transferRecordId = `trf-rec-${Date.now()}`;
    const newEnrollmentId = `enr-${Date.now()}`;

    if (currentEnrollment) {
      currentEnrollment.status = 'transferred';
      currentEnrollment.transferRecordId = transferRecordId;
      currentEnrollment.completionDate = (effectiveDate || timestamp).split('T')[0];
      currentEnrollment.updatedAt = timestamp;
    }

    // 2. Create new active enrollment in target section/class
    const nextEnrollmentSeq = database.academicEnrollments.length + 1;
    const newEnrollmentNumber = `ENR-${new Date().getFullYear()}-${String(nextEnrollmentSeq).padStart(4, '0')}`;

    const newEnrollment: AcademicEnrollment = {
      id: newEnrollmentId,
      enrollmentNumber: newEnrollmentNumber,
      studentId: student.id,
      studentAdmissionNumber: student.admissionNumber,
      studentName,
      academicSessionId: student.academicSessionId,
      academicSessionName: student.academicSessionName || 'Current Session',
      classId: effectiveTargetClassId,
      className: targetClass.name,
      sectionId: targetSectionId,
      sectionName: targetSection.name,
      rollNumber: assignedRoll,
      enrollmentDate: effectiveDate || timestamp.split('T')[0],
      status: 'active',
      transferRecordId,
      remarks: `Transferred from ${student.className} ${student.sectionName}: ${reason}`,
      createdAt: timestamp,
      updatedAt: timestamp
    };
    database.academicEnrollments.push(newEnrollment);

    // 3. Create Transfer Record
    const transferRecord: TransferRecord = {
      id: transferRecordId,
      studentId: student.id,
      studentName,
      admissionNumber: student.admissionNumber,
      transferType,
      effectiveDate: effectiveDate || timestamp.split('T')[0],
      reason,
      fromSessionId: student.academicSessionId,
      fromSessionName: student.academicSessionName || 'Current Session',
      fromClassId: student.classId,
      fromClassName: student.className || '',
      fromSectionId: student.sectionId,
      fromSectionName: student.sectionName || '',
      fromRollNumber: student.rollNumber || '',
      toClassId: effectiveTargetClassId,
      toClassName: targetClass.name,
      toSectionId: targetSectionId,
      toSectionName: targetSection.name,
      toRollNumber: assignedRoll,
      clearanceDetails: {
        libraryCleared: !!libraryCleared,
        feesCleared: !!feesCleared,
        labSportsCleared: true,
        allCleared: !!libraryCleared && !!feesCleared
      },
      status: 'COMPLETED',
      approvedBy,
      approvedByName,
      createdAt: timestamp,
      updatedAt: timestamp,
      previousEnrollmentId: currentEnrollment?.id,
      newEnrollmentId
    };
    database.studentTransferRecords.push(transferRecord);

    // 4. Update Student Profile
    student.classId = effectiveTargetClassId;
    student.className = targetClass.name;
    student.sectionId = targetSectionId;
    student.sectionName = targetSection.name;
    student.rollNumber = assignedRoll;
    student.updatedAt = timestamp;

    recordAuditLog(
      req,
      'TRANSFER_INTERNAL',
      `Internal transfer for ${studentName}: moved to ${targetClass.name} - ${targetSection.name} (Roll: ${assignedRoll}). Reason: ${reason}`,
      { studentId, targetClassId: effectiveTargetClassId, targetSectionId },
      studentId
    );

    res.json({
      success: true,
      message: `Student transferred successfully to ${targetClass.name} - ${targetSection.name}.`,
      record: transferRecord,
      enrollment: newEnrollment
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ============================================================================
// 6. EXTERNAL TRANSFER & TRANSFER CERTIFICATE (TC)
// ============================================================================

/**
 * GET /api/promotions-transfers/transfer-certificates
 */
promotionsTransfersRouter.get('/transfer-certificates', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { search, status } = req.query as { search?: string; status?: string };
    let list = [...(database.transferCertificates || [])];

    if (status) {
      list = list.filter((tc) => tc.status === status);
    }
    if (search) {
      const q = search.toLowerCase();
      list = list.filter(
        (tc) =>
          tc.studentName.toLowerCase().includes(q) ||
          tc.tcNumber.toLowerCase().includes(q) ||
          tc.admissionNumber.toLowerCase().includes(q)
      );
    }

    list.sort((a, b) => new Date(b.issueDate).getTime() - new Date(a.issueDate).getTime());

    res.json({
      success: true,
      total: list.length,
      certificates: list
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * GET /api/promotions-transfers/transfer-certificates/:id
 */
promotionsTransfersRouter.get('/transfer-certificates/:id', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { id } = req.params;
    const certificate = database.transferCertificates.find((tc) => tc.id === id || tc.tcNumber === id);

    if (!certificate) {
      res.status(404).json({ success: false, error: 'Transfer certificate not found.' });
      return;
    }

    res.json({
      success: true,
      certificate
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * POST /api/promotions-transfers/transfer-certificate/issue
 */
promotionsTransfersRouter.post('/transfer-certificate/issue', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const {
      studentId,
      dateOfLeaving,
      reasonForLeaving,
      generalConduct = 'EXCELLENT',
      targetSchoolName,
      libraryCleared = true,
      feesCleared = true,
      labSportsCleared = true,
      clearanceOverride = false,
      remarks
    } = req.body;

    if (!studentId || !reasonForLeaving) {
      res.status(400).json({
        success: false,
        error: 'studentId and reasonForLeaving are required to issue a Transfer Certificate.'
      });
      return;
    }

    const student = database.studentProfiles.find((s) => s.id === studentId);
    if (!student) {
      res.status(404).json({ success: false, error: 'Student profile not found.' });
      return;
    }

    // Clearance check
    const standing = calculateStudentStanding(studentId);
    if (standing.hasOutstandingFees && !feesCleared && !clearanceOverride) {
      res.status(400).json({
        success: false,
        error: `Cannot issue Transfer Certificate: Student has pending fee balance of $${standing.totalDueFees.toFixed(2)}. Fee clearance or administrative override required.`,
        code: 'FEE_DUES_PENDING'
      });
      return;
    }

    const timestamp = new Date().toISOString();
    const issuedBy = req.user?.id || 'usr-admin-1';
    const issuedByName = req.user?.name || 'System Administrator';
    const tcNumber = generateNextTCNumber();
    const studentName = `${student.firstName || ''} ${student.lastName || ''}`.trim();
    const tcId = `tc-rec-${Date.now()}`;
    const transferRecordId = `trf-ext-${Date.now()}`;

    // 1. Create Transfer Certificate
    const transferCert: TransferCertificate = {
      id: tcId,
      tcNumber,
      studentId: student.id,
      studentName,
      admissionNumber: student.admissionNumber,
      fatherName: student.guardianName || 'Guardian on record',
      motherName: 'Mother on record',
      dateOfBirth: student.dateOfBirth || '2010-01-01',
      nationality: student.nationality || 'United States',
      academicSessionId: student.academicSessionId,
      academicSessionName: student.academicSessionName || 'Current Academic Session',
      classLeft: student.className || 'Current Class',
      sectionLeft: student.sectionName || 'Current Section',
      dateOfLeaving: dateOfLeaving || timestamp.split('T')[0],
      reasonForLeaving,
      generalConduct,
      totalAttendanceDays: 180,
      attendedDays: Math.round((180 * standing.attendancePercentage) / 100),
      feeDuesPaidUpto: dateOfLeaving || timestamp.split('T')[0],
      hasClearedAllDues: !standing.hasOutstandingFees || feesCleared || clearanceOverride,
      issueDate: timestamp.split('T')[0],
      issuedBy,
      issuedByName,
      verifiedBy: 'Office of the Registrar',
      status: 'ACTIVE',
      qrCodeData: `SYG:TC:${tcNumber}:${student.admissionNumber}:${studentName.replace(/\s+/g, '-')}:VERIFIED`,
      remarks,
      createdAt: timestamp
    };

    database.transferCertificates.push(transferCert);

    // 2. Create external transfer record
    const transferRecord: TransferRecord = {
      id: transferRecordId,
      studentId: student.id,
      studentName,
      admissionNumber: student.admissionNumber,
      transferType: 'EXTERNAL_SCHOOL',
      effectiveDate: dateOfLeaving || timestamp.split('T')[0],
      reason: reasonForLeaving,
      fromSessionId: student.academicSessionId,
      fromSessionName: student.academicSessionName || '',
      fromClassId: student.classId,
      fromClassName: student.className || '',
      fromSectionId: student.sectionId,
      fromSectionName: student.sectionName || '',
      fromRollNumber: student.rollNumber || '',
      targetSchoolName: targetSchoolName || 'External Institution',
      tcNumber,
      tcIssueDate: timestamp.split('T')[0],
      conductCertificate: generalConduct,
      clearanceDetails: {
        libraryCleared: !!libraryCleared,
        feesCleared: !standing.hasOutstandingFees || feesCleared,
        duesAmount: standing.totalDueFees,
        labSportsCleared: !!labSportsCleared,
        allCleared: true,
        overriddenBy: clearanceOverride ? issuedByName : undefined
      },
      status: 'COMPLETED',
      approvedBy: issuedBy,
      approvedByName: issuedByName,
      createdAt: timestamp,
      updatedAt: timestamp
    };

    database.studentTransferRecords.push(transferRecord);

    // 3. Update current academic enrollment to 'transferred'
    const activeEnrollment = database.academicEnrollments.find(
      (e) => e.studentId === studentId && e.status === 'active'
    );
    if (activeEnrollment) {
      activeEnrollment.status = 'transferred';
      activeEnrollment.transferRecordId = transferRecordId;
      activeEnrollment.completionDate = dateOfLeaving || timestamp.split('T')[0];
      activeEnrollment.remarks = `External transfer certificate issued (${tcNumber}): ${reasonForLeaving}`;
      activeEnrollment.updatedAt = timestamp;
    }

    // 4. Update Student Profile Status to 'transferred'
    const previousStatus = student.status as StudentStatusType;
    student.status = 'transferred';
    student.updatedAt = timestamp;

    // 5. Update associated User account status to 'inactive'
    if (student.userId) {
      const studentUser = database.users.find((u) => u.id === student.userId);
      if (studentUser) {
        studentUser.status = 'inactive';
        studentUser.updatedAt = timestamp;
      }
    }

    // 6. Log status history
    database.studentStatusHistory.push({
      id: `ssh-${Date.now()}`,
      studentId: student.id,
      admissionNumber: student.admissionNumber,
      studentName,
      fromStatus: previousStatus || 'active',
      toStatus: 'transferred',
      effectiveDate: dateOfLeaving || timestamp.split('T')[0],
      reason: `Transfer Certificate ${tcNumber} issued for: ${reasonForLeaving}`,
      remarks,
      changedBy: issuedBy,
      changedByName: issuedByName,
      changedAt: timestamp
    });

    recordAuditLog(
      req,
      'TC_ISSUED',
      `Issued Transfer Certificate ${tcNumber} for student ${studentName} (${student.admissionNumber}). Reason: ${reasonForLeaving}`,
      { studentId, tcNumber, dateOfLeaving },
      tcNumber
    );

    res.json({
      success: true,
      message: `Transfer Certificate ${tcNumber} successfully issued for ${studentName}.`,
      certificate: transferCert,
      transferRecord
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ============================================================================
// 7. CENTRALIZED STUDENT STATUS LIFECYCLE MANAGEMENT
// ============================================================================

/**
 * POST /api/promotions-transfers/status-change
 * Transitions a student status with audit logging and cascade updates
 */
promotionsTransfersRouter.post('/status-change', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const {
      studentId,
      newStatus,
      effectiveDate,
      endDate,
      reason,
      suspensionTerms,
      remarks,
      documentUrl
    } = req.body as {
      studentId: string;
      newStatus: StudentStatusType;
      effectiveDate: string;
      endDate?: string;
      reason: string;
      suspensionTerms?: string;
      remarks?: string;
      documentUrl?: string;
    };

    if (!studentId || !newStatus || !reason) {
      res.status(400).json({
        success: false,
        error: 'studentId, newStatus, and reason are required for status transition.'
      });
      return;
    }

    const student = database.studentProfiles.find((s) => s.id === studentId);
    if (!student) {
      res.status(404).json({ success: false, error: 'Student profile not found.' });
      return;
    }

    const timestamp = new Date().toISOString();
    const changedBy = req.user?.id || 'usr-admin-1';
    const changedByName = req.user?.name || 'System Administrator';
    const fromStatus = (student.status as StudentStatusType) || 'active';
    const studentName = `${student.firstName || ''} ${student.lastName || ''}`.trim();

    // 1. Update Student Profile
    student.status = newStatus;
    student.updatedAt = timestamp;

    // 2. Cascade update to User account
    if (student.userId) {
      const studentUser = database.users.find((u) => u.id === student.userId);
      if (studentUser) {
        if (newStatus === 'active') {
          studentUser.status = 'active';
        } else if (newStatus === 'suspended') {
          studentUser.status = 'suspended';
        } else {
          studentUser.status = 'inactive';
        }
        studentUser.updatedAt = timestamp;
      }
    }

    // 3. Update active AcademicEnrollment status if withdrawing or suspending
    const activeEnrollment = database.academicEnrollments.find(
      (e) => e.studentId === studentId && e.status === 'active'
    );
    if (activeEnrollment) {
      if (newStatus === 'suspended') {
        activeEnrollment.status = 'suspended';
        activeEnrollment.remarks = `Suspended on ${effectiveDate || timestamp.split('T')[0]}: ${reason}`;
      } else if (newStatus === 'withdrawn') {
        activeEnrollment.status = 'withdrawn';
        activeEnrollment.completionDate = effectiveDate || timestamp.split('T')[0];
        activeEnrollment.remarks = `Withdrawn on ${effectiveDate || timestamp.split('T')[0]}: ${reason}`;
      } else if (newStatus === 'active' && fromStatus === 'suspended') {
        activeEnrollment.status = 'active';
        activeEnrollment.remarks = `Reinstated to active standing on ${effectiveDate || timestamp.split('T')[0]}`;
      }
      activeEnrollment.updatedAt = timestamp;
    }

    // 4. Record in Student Status History
    const historyEntry: StudentStatusHistoryEntry = {
      id: `ssh-${Date.now()}`,
      studentId: student.id,
      admissionNumber: student.admissionNumber,
      studentName,
      fromStatus,
      toStatus: newStatus,
      effectiveDate: effectiveDate || timestamp.split('T')[0],
      endDate,
      reason,
      remarks,
      documentUrl,
      suspensionTerms,
      changedBy,
      changedByName,
      changedAt: timestamp
    };

    database.studentStatusHistory.push(historyEntry);

    recordAuditLog(
      req,
      'STUDENT_STATUS_CHANGE',
      `Changed status for ${studentName} (${student.admissionNumber}) from '${fromStatus}' to '${newStatus}'. Reason: ${reason}`,
      { studentId, fromStatus, toStatus: newStatus, effectiveDate },
      studentId
    );

    res.json({
      success: true,
      message: `Student status updated from '${fromStatus}' to '${newStatus}'.`,
      historyEntry,
      student: {
        id: student.id,
        name: studentName,
        status: student.status
      }
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * GET /api/promotions-transfers/status-history/:studentId
 */
promotionsTransfersRouter.get('/status-history/:studentId', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { studentId } = req.params;
    const history = (database.studentStatusHistory || [])
      .filter((h) => h.studentId === studentId)
      .sort((a, b) => new Date(b.changedAt).getTime() - new Date(a.changedAt).getTime());

    res.json({
      success: true,
      history
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ============================================================================
// 8. PROMOTION BATCHES & RECORDS
// ============================================================================

/**
 * GET /api/promotions-transfers/batches
 */
promotionsTransfersRouter.get('/batches', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const batches = [...(database.bulkPromotionBatches || [])].sort(
      (a, b) => new Date(b.executedAt).getTime() - new Date(a.executedAt).getTime()
    );

    res.json({
      success: true,
      total: batches.length,
      batches
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * GET /api/promotions-transfers/promotions
 */
promotionsTransfersRouter.get('/promotions', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { studentId, batchId, sessionId } = req.query as Record<string, string>;
    let list = [...(database.studentPromotionRecords || [])];

    if (studentId) list = list.filter((p) => p.studentId === studentId);
    if (batchId) list = list.filter((p) => p.batchId === batchId);
    if (sessionId) list = list.filter((p) => p.toSessionId === sessionId || p.fromSessionId === sessionId);

    list.sort((a, b) => new Date(b.promotedAt).getTime() - new Date(a.promotedAt).getTime());

    res.json({
      success: true,
      total: list.length,
      promotions: list
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * GET /api/promotions-transfers/transfers
 */
promotionsTransfersRouter.get('/transfers', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { studentId, type } = req.query as Record<string, string>;
    let list = [...(database.studentTransferRecords || [])];

    if (studentId) list = list.filter((t) => t.studentId === studentId);
    if (type) list = list.filter((t) => t.transferType === type);

    list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

    res.json({
      success: true,
      total: list.length,
      transfers: list
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

/**
 * POST /api/promotions-transfers/revert-promotion/:recordId
 * Safe rollback of a promotional assignment
 */
promotionsTransfersRouter.post('/revert-promotion/:recordId', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { recordId } = req.params;
    const { reason } = req.body;

    const record = database.studentPromotionRecords.find((p) => p.id === recordId);
    if (!record) {
      res.status(404).json({ success: false, error: 'Promotion record not found.' });
      return;
    }

    if (record.status === 'REVERTED') {
      res.status(400).json({ success: false, error: 'This promotion has already been reverted.' });
      return;
    }

    const student = database.studentProfiles.find((s) => s.id === record.studentId);
    if (!student) {
      res.status(404).json({ success: false, error: 'Associated student profile not found.' });
      return;
    }

    const timestamp = new Date().toISOString();

    // 1. Revert previous enrollment to active
    if (record.previousEnrollmentId) {
      const prev = database.academicEnrollments.find((e) => e.id === record.previousEnrollmentId);
      if (prev) {
        prev.status = 'active';
        prev.remarks = `Restored via rollback of promotion ${record.id}: ${reason || 'Administrative revert'}`;
        prev.updatedAt = timestamp;
      }
    }

    // 2. Remove or cancel the new enrollment
    if (record.newEnrollmentId) {
      const newEnrIdx = database.academicEnrollments.findIndex((e) => e.id === record.newEnrollmentId);
      if (newEnrIdx !== -1) {
        database.academicEnrollments.splice(newEnrIdx, 1);
      }
    }

    // 3. Revert student profile placement
    student.academicSessionId = record.fromSessionId;
    student.academicSessionName = record.fromSessionName;
    student.classId = record.fromClassId;
    student.className = record.fromClassName;
    student.sectionId = record.fromSectionId;
    student.sectionName = record.fromSectionName;
    student.rollNumber = record.fromRollNumber;
    student.updatedAt = timestamp;

    // 4. Mark record as reverted
    record.status = 'REVERTED';
    record.remarks = `${record.remarks || ''} [REVERTED on ${timestamp}: ${reason || 'Admin revert'}]`.trim();

    recordAuditLog(
      req,
      'PROMOTION_REVERT',
      `Reverted promotion for ${record.studentName} back to ${record.fromClassName} - ${record.fromSectionName}. Reason: ${reason || 'Administrative rollback'}`,
      { recordId, studentId: student.id },
      recordId
    );

    res.json({
      success: true,
      message: `Promotion for ${record.studentName} has been successfully reverted to ${record.fromClassName}.`,
      record
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});
