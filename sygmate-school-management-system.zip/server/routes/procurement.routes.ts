/**
 * Procurement & Purchase Workflow Express Router (Part 14D)
 * Sygmate School Management System
 */

import { Router, Response } from 'express';
import { requireAuth, requirePermission, AuthenticatedRequest } from '../security/auth.js';
import { ProcurementService } from '../services/procurement.service.js';
import { database } from '../db/database.js';

export const procurementRouter = Router();

function resolveSchoolId(req: AuthenticatedRequest): string {
  if (req?.tenant?.schoolId) return req.tenant.schoolId;
  if (req?.user?.schoolId) return req.user.schoolId;
  return database.schoolSettings?.id || 'school-main';
}

// ============================================================================
// DASHBOARD & ANALYTICS
// ============================================================================

/**
 * GET /api/inventory/procurement/dashboard
 * Summary KPI statistics for procurement
 */
procurementRouter.get(
  '/dashboard',
  requireAuth,
  requirePermission('inventory.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = resolveSchoolId(req);
      const summary = ProcurementService.getDashboardSummary(schoolId);
      res.json({ success: true, data: summary });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to load procurement dashboard' });
    }
  }
);

// ============================================================================
// PURCHASE REQUESTS
// ============================================================================

/**
 * GET /api/inventory/procurement/requests
 * List purchase requests
 */
procurementRouter.get(
  '/requests',
  requireAuth,
  requirePermission('procurement.requests.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = resolveSchoolId(req);
      const { status, priority, department, search, page, limit } = req.query;
      const result = ProcurementService.listPurchaseRequests(schoolId, {
        status: status as string,
        priority: priority as string,
        department: department as string,
        search: search as string,
        page: page ? parseInt(page as string, 10) : undefined,
        limit: limit ? parseInt(limit as string, 10) : undefined
      });
      res.json({ success: true, ...result });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to fetch purchase requests' });
    }
  }
);

/**
 * GET /api/inventory/procurement/requests/:id
 * Get single purchase request
 */
procurementRouter.get(
  '/requests/:id',
  requireAuth,
  requirePermission('procurement.requests.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = resolveSchoolId(req);
      const pr = ProcurementService.getPurchaseRequestById(schoolId, req.params.id);
      res.json({ success: true, data: pr });
    } catch (error: any) {
      res.status(404).json({ success: false, error: error.message || 'Purchase request not found' });
    }
  }
);

/**
 * POST /api/inventory/procurement/requests
 * Create new purchase request
 */
procurementRouter.post(
  '/requests',
  requireAuth,
  requirePermission('procurement.requests.create'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = resolveSchoolId(req);
      const pr = ProcurementService.createPurchaseRequest(schoolId, req.body, req.user);
      res.status(201).json({ success: true, data: pr, message: `Purchase request ${pr.requestNumber} created successfully.` });
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message || 'Failed to create purchase request' });
    }
  }
);

/**
 * PUT /api/inventory/procurement/requests/:id
 * Update draft / submitted purchase request
 */
procurementRouter.put(
  '/requests/:id',
  requireAuth,
  requirePermission('procurement.requests.create'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = resolveSchoolId(req);
      const pr = ProcurementService.updatePurchaseRequest(schoolId, req.params.id, req.body, req.user);
      res.json({ success: true, data: pr, message: `Purchase request ${pr.requestNumber} updated successfully.` });
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message || 'Failed to update purchase request' });
    }
  }
);

/**
 * POST /api/inventory/procurement/requests/:id/review
 * Approve or Reject purchase request
 */
procurementRouter.post(
  '/requests/:id/review',
  requireAuth,
  requirePermission('procurement.requests.approve'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = resolveSchoolId(req);
      const pr = ProcurementService.reviewPurchaseRequest(schoolId, req.params.id, req.body, req.user);
      res.json({
        success: true,
        data: pr,
        message: `Purchase request ${pr.requestNumber} has been ${pr.status.toLowerCase()}.`
      });
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message || 'Failed to review purchase request' });
    }
  }
);

/**
 * POST /api/inventory/procurement/requests/:id/cancel
 * Cancel purchase request
 */
procurementRouter.post(
  '/requests/:id/cancel',
  requireAuth,
  requirePermission('procurement.requests.create'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = resolveSchoolId(req);
      const pr = ProcurementService.cancelPurchaseRequest(schoolId, req.params.id, req.body?.reason, req.user);
      res.json({ success: true, data: pr, message: `Purchase request ${pr.requestNumber} cancelled.` });
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message || 'Failed to cancel purchase request' });
    }
  }
);

/**
 * POST /api/inventory/procurement/requests/:id/convert-to-po
 * Convert approved purchase request to purchase order
 */
procurementRouter.post(
  '/requests/:id/convert-to-po',
  requireAuth,
  requirePermission('procurement.orders.create'),
  async (req: AuthenticatedRequest, res: Response): Promise<void> => {
    try {
      const schoolId = resolveSchoolId(req);
      const po = await ProcurementService.convertRequestToPurchaseOrder(schoolId, req.params.id, req.body, req.user);
      res.status(201).json({
        success: true,
        data: po,
        message: `Purchase order ${po.poNumber} created from request.`
      });
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message || 'Failed to convert request to PO' });
    }
  }
);

// ============================================================================
// PURCHASE ORDERS
// ============================================================================

/**
 * GET /api/inventory/procurement/orders
 * List purchase orders
 */
procurementRouter.get(
  '/orders',
  requireAuth,
  requirePermission('procurement.orders.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = resolveSchoolId(req);
      const { status, supplierId, search, page, limit } = req.query;
      const result = ProcurementService.listPurchaseOrders(schoolId, {
        status: status as string,
        supplierId: supplierId as string,
        search: search as string,
        page: page ? parseInt(page as string, 10) : undefined,
        limit: limit ? parseInt(limit as string, 10) : undefined
      });
      res.json({ success: true, ...result });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to fetch purchase orders' });
    }
  }
);

/**
 * GET /api/inventory/procurement/orders/:id
 * Get single purchase order
 */
procurementRouter.get(
  '/orders/:id',
  requireAuth,
  requirePermission('procurement.orders.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = resolveSchoolId(req);
      const po = ProcurementService.getPurchaseOrderById(schoolId, req.params.id);
      res.json({ success: true, data: po });
    } catch (error: any) {
      res.status(404).json({ success: false, error: error.message || 'Purchase order not found' });
    }
  }
);

/**
 * POST /api/inventory/procurement/orders
 * Create new purchase order directly
 */
procurementRouter.post(
  '/orders',
  requireAuth,
  requirePermission('procurement.orders.create'),
  async (req: AuthenticatedRequest, res: Response): Promise<void> => {
    try {
      const schoolId = resolveSchoolId(req);
      const po = await ProcurementService.createPurchaseOrder(schoolId, req.body, req.user);
      res.status(201).json({ success: true, data: po, message: `Purchase order ${po.poNumber} created successfully.` });
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message || 'Failed to create purchase order' });
    }
  }
);

/**
 * POST /api/inventory/procurement/orders/:id/review
 * Approve or Reject purchase order
 */
procurementRouter.post(
  '/orders/:id/review',
  requireAuth,
  requirePermission('procurement.orders.approve'),
  async (req: AuthenticatedRequest, res: Response): Promise<void> => {
    try {
      const schoolId = resolveSchoolId(req);
      const po = await ProcurementService.reviewPurchaseOrder(schoolId, req.params.id, req.body, req.user);
      res.json({
        success: true,
        data: po,
        message: `Purchase order ${po.poNumber} has been ${po.status.toLowerCase()}.`
      });
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message || 'Failed to review purchase order' });
    }
  }
);

/**
 * POST /api/inventory/procurement/orders/:id/send
 * Mark PO as sent to supplier
 */
procurementRouter.post(
  '/orders/:id/send',
  requireAuth,
  requirePermission('procurement.orders.create'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = resolveSchoolId(req);
      const po = ProcurementService.markPurchaseOrderSent(schoolId, req.params.id, req.user);
      res.json({ success: true, data: po, message: `Purchase order ${po.poNumber} marked as sent to supplier.` });
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message || 'Failed to mark PO as sent' });
    }
  }
);

/**
 * POST /api/inventory/procurement/orders/:id/cancel
 * Cancel purchase order
 */
procurementRouter.post(
  '/orders/:id/cancel',
  requireAuth,
  requirePermission('procurement.orders.cancel'),
  async (req: AuthenticatedRequest, res: Response): Promise<void> => {
    try {
      const schoolId = resolveSchoolId(req);
      const po = await ProcurementService.cancelPurchaseOrder(schoolId, req.params.id, req.body?.reason, req.user);
      res.json({ success: true, data: po, message: `Purchase order ${po.poNumber} cancelled.` });
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message || 'Failed to cancel purchase order' });
    }
  }
);

// ============================================================================
// GOODS RECEIVING & WAREHOUSE INTAKE
// ============================================================================

/**
 * GET /api/inventory/procurement/receiving
 * List Goods Receipts
 */
procurementRouter.get(
  '/receiving',
  requireAuth,
  requirePermission('procurement.receiving.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = resolveSchoolId(req);
      const { purchaseOrderId, supplierId, search, page, limit } = req.query;
      const result = ProcurementService.listGoodsReceipts(schoolId, {
        purchaseOrderId: purchaseOrderId as string,
        supplierId: supplierId as string,
        search: search as string,
        page: page ? parseInt(page as string, 10) : undefined,
        limit: limit ? parseInt(limit as string, 10) : undefined
      });
      res.json({ success: true, ...result });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to list goods receipts' });
    }
  }
);

/**
 * GET /api/inventory/procurement/receiving/:id
 * Get single Goods Receipt
 */
procurementRouter.get(
  '/receiving/:id',
  requireAuth,
  requirePermission('procurement.receiving.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = resolveSchoolId(req);
      const grn = ProcurementService.getGoodsReceiptById(schoolId, req.params.id);
      res.json({ success: true, data: grn });
    } catch (error: any) {
      res.status(404).json({ success: false, error: error.message || 'Goods receipt not found' });
    }
  }
);

/**
 * POST /api/inventory/procurement/orders/:id/receive
 * Receive physical goods against an approved PO
 * INCREASES STOCK AUTHORITATIVELY VIA STOCKSERVICE
 */
procurementRouter.post(
  '/orders/:id/receive',
  requireAuth,
  requirePermission('procurement.receiving.manage'),
  async (req: AuthenticatedRequest, res: Response): Promise<void> => {
    try {
      const schoolId = resolveSchoolId(req);
      const result = await ProcurementService.receiveGoods(schoolId, req.params.id, req.body, req.user);
      res.status(201).json({
        success: true,
        data: result,
        message: `Goods receipt ${result.goodsReceipt.receiptNumber} recorded. Inventory stock increased by ${result.goodsReceipt.totalAcceptedQty} accepted units.`
      });
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message || 'Failed to process goods receiving' });
    }
  }
);

/**
 * POST /api/inventory/procurement/receiving/create-asset
 * Convert a received line item into a registered capital asset
 */
procurementRouter.post(
  '/receiving/create-asset',
  requireAuth,
  requirePermission('assets.manage'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = resolveSchoolId(req);
      const asset = ProcurementService.createAssetFromReceiptLine(schoolId, req.body, req.user);
      res.status(201).json({
        success: true,
        data: asset,
        message: `Asset '${asset.name}' (${asset.assetTag}) registered successfully from goods receipt.`
      });
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message || 'Failed to create asset from receipt' });
    }
  }
);

// ============================================================================
// SUPPLIER PROCUREMENT ANALYTICS
// ============================================================================

/**
 * GET /api/inventory/procurement/suppliers/:id/history
 * Rich supplier procurement orders and fulfillment history
 */
procurementRouter.get(
  '/suppliers/:id/history',
  requireAuth,
  requirePermission('inventory.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = resolveSchoolId(req);
      const history = ProcurementService.getSupplierProcurementHistory(schoolId, req.params.id);
      res.json({ success: true, data: history });
    } catch (error: any) {
      res.status(404).json({ success: false, error: error.message || 'Failed to get supplier history' });
    }
  }
);
