/**
 * Sygmate School Management System
 * Staff HR Reports & Analytics Routes (Part 12F)
 * Endpoint: /api/staff/reports/*
 */

import { Router, Response } from 'express';
import { requireAuth, requirePermission, AuthenticatedRequest } from '../security/auth.js';
import { staffReportsService } from '../services/staff-reports.service.js';
import { HRReportFilterQuery, HRExportAuditPayload } from '../../src/types/index.js';

export const staffReportsRouter = Router();

/**
 * Helper to extract query parameters securely
 */
function parseFilterQuery(req: AuthenticatedRequest): HRReportFilterQuery {
  return {
    academicSessionId: req.query.academicSessionId as string,
    departmentId: req.query.departmentId as string,
    designationId: req.query.designationId as string,
    staffType: req.query.staffType as string,
    employmentStatus: req.query.employmentStatus as string,
    startDate: req.query.startDate as string,
    endDate: req.query.endDate as string,
    staffId: req.query.staffId as string,
    leaveTypeId: req.query.leaveTypeId as string,
    jobOpeningId: req.query.jobOpeningId as string,
    reviewCycleId: req.query.reviewCycleId as string,
    search: req.query.search as string
  };
}

/**
 * 1. GET /api/staff/reports/dashboard
 * Centralized executive HR dashboard KPIs
 */
staffReportsRouter.get(
  '/dashboard',
  requireAuth,
  requirePermission('staff.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const query = parseFilterQuery(req);
      const kpis = staffReportsService.getHRDashboardKPIs(query, req.user);
      res.json({ success: true, data: kpis });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message || 'Failed to fetch HR dashboard metrics' });
    }
  }
);

/**
 * 2. GET /api/staff/reports/headcount
 * Detailed Staff Headcount & Distribution (by Department, Designation, Category, Status)
 */
staffReportsRouter.get(
  '/headcount',
  requireAuth,
  requirePermission('staff.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const query = parseFilterQuery(req);
      const report = staffReportsService.getStaffHeadcountReport(query, req.user);
      res.json({ success: true, data: report });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message || 'Failed to fetch staff headcount report' });
    }
  }
);

/**
 * 3. GET /api/staff/reports/attendance
 * Staff Attendance Reports & Analytics
 */
staffReportsRouter.get(
  '/attendance',
  requireAuth,
  requirePermission('staff.attendance.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const query = parseFilterQuery(req);
      const report = staffReportsService.getStaffAttendanceReport(query, req.user);
      res.json({ success: true, data: report });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message || 'Failed to fetch staff attendance report' });
    }
  }
);

/**
 * 4. GET /api/staff/reports/leaves
 * Staff Leave Application Status, Department & Monthly Reports
 */
staffReportsRouter.get(
  '/leaves',
  requireAuth,
  requirePermission('staff.leaves.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const query = parseFilterQuery(req);
      const report = staffReportsService.getStaffLeaveReport(query, req.user);
      res.json({ success: true, data: report });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message || 'Failed to fetch staff leave report' });
    }
  }
);

/**
 * 5. GET /api/staff/reports/leave-balances
 * Authoritative Leave Balance & Utilization Reports
 */
staffReportsRouter.get(
  '/leave-balances',
  requireAuth,
  requirePermission('staff.leaves.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const query = parseFilterQuery(req);
      const report = staffReportsService.getLeaveBalanceUtilizationReport(query, req.user);
      res.json({ success: true, data: report });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message || 'Failed to fetch leave balance report' });
    }
  }
);

/**
 * 6. GET /api/staff/reports/recruitment
 * Recruitment Pipeline & Stage-wise Funnel Report
 */
staffReportsRouter.get(
  '/recruitment',
  requireAuth,
  requirePermission('staff.recruitment.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const query = parseFilterQuery(req);
      const report = staffReportsService.getRecruitmentFunnelReport(query);
      res.json({ success: true, data: report });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message || 'Failed to fetch recruitment funnel report' });
    }
  }
);

/**
 * 7. GET /api/staff/reports/recruitment-performance
 * Operational Recruitment Efficiency & Conversion Rates
 */
staffReportsRouter.get(
  '/recruitment-performance',
  requireAuth,
  requirePermission('staff.recruitment.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const report = staffReportsService.getRecruitmentPerformanceReport();
      res.json({ success: true, data: report });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message || 'Failed to fetch recruitment performance' });
    }
  }
);

/**
 * 8. GET /api/staff/reports/onboarding
 * Staff Onboarding Progress, Checklist & Overdue Tasks
 */
staffReportsRouter.get(
  '/onboarding',
  requireAuth,
  requirePermission('staff.onboarding.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const query = parseFilterQuery(req);
      const report = staffReportsService.getOnboardingReport(query);
      res.json({ success: true, data: report });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message || 'Failed to fetch onboarding report' });
    }
  }
);

/**
 * 9. GET /api/staff/reports/performance
 * Performance Appraisal Cycle Status & Review Completion
 */
staffReportsRouter.get(
  '/performance',
  requireAuth,
  requirePermission('staff.performance.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const query = parseFilterQuery(req);
      const report = staffReportsService.getPerformanceCompletionReport(query);
      res.json({ success: true, data: report });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message || 'Failed to fetch performance report' });
    }
  }
);

/**
 * 10. GET /api/staff/reports/goals
 * Goal Achievement & Department Metrics
 */
staffReportsRouter.get(
  '/goals',
  requireAuth,
  requirePermission('staff.performance.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const query = parseFilterQuery(req);
      const report = staffReportsService.getGoalAchievementReport(query);
      res.json({ success: true, data: report });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message || 'Failed to fetch goal achievement report' });
    }
  }
);

/**
 * 11. GET /api/staff/reports/turnover
 * Staff Status & Turnover / Movement Historical Reports
 */
staffReportsRouter.get(
  '/turnover',
  requireAuth,
  requirePermission('staff.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const report = staffReportsService.getStaffTurnoverReport();
      res.json({ success: true, data: report });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message || 'Failed to fetch staff turnover report' });
    }
  }
);

/**
 * 12. GET /api/staff/reports/cross-session
 * Multi-Session Academic Year Trend Comparisons
 */
staffReportsRouter.get(
  '/cross-session',
  requireAuth,
  requirePermission('staff.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const report = staffReportsService.getCrossSessionHRReport();
      res.json({ success: true, data: report });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message || 'Failed to fetch cross-session report' });
    }
  }
);

/**
 * 13. GET /api/staff/reports/drilldown
 * Metric Click-through Drill-down Details
 */
staffReportsRouter.get(
  '/drilldown',
  requireAuth,
  requirePermission('staff.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const metricKey = (req.query.metricKey as string) || 'active_staff';
      const query = parseFilterQuery(req);
      const details = staffReportsService.getDrilldownRecords(metricKey, query, req.user);
      res.json({ success: true, data: details });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message || 'Failed to fetch drilldown records' });
    }
  }
);

/**
 * 14. POST /api/staff/reports/export/audit
 * Server-side Audit Logging for Export Action
 */
staffReportsRouter.post(
  '/export/audit',
  requireAuth,
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      if (!req.user) {
        res.status(401).json({ success: false, message: 'Unauthenticated' });
        return;
      }
      const payload = req.body as HRExportAuditPayload;
      staffReportsService.logExportAudit(payload, req.user, req.ip);
      res.json({ success: true, message: 'Export audited' });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message || 'Failed to audit export' });
    }
  }
);
