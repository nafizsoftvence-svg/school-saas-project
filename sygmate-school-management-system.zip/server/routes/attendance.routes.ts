import { Router, Response } from 'express';
import { database } from '../db/database.js';
import { requireAuth, requirePermission, requireRole, AuthenticatedRequest } from '../security/auth.js';
import { logAudit } from '../security/audit.js';
import {
  AttendanceRecord,
  AttendanceStatus,
  AttendanceSheetData,
  AttendanceSheetStudent,
  AttendanceSummaryStats,
  StudentAttendanceHistoryData,
  StudentLeaveApplication,
  LeaveType,
  LeaveApplication,
  ApplicantType,
  LeaveStatus,
  AttendanceSettings,
  HolidayRecord,
  SpecialWorkingDayRecord,
  SchoolCalendarEvent,
  AcademicCalendarMonthViewResponse,
  CalendarDayDetails,
  DayOfWeekName,
  TeacherAttendanceRecord,
  TeacherAttendanceStatus,
  TeacherAttendanceCorrectionHistoryItem,
  TeacherDailyAttendanceResponse,
  TeacherDailyAttendanceRosterItem,
  TeacherMonthlyAttendanceResponse,
  TeacherMonthlyMatrixDay,
  TeacherMonthlyMatrixRow,
  TeacherMyAttendanceResponse,
  TeacherMyAttendanceDay
} from '../../src/types/index.js';
import { attendanceNotificationsRouter } from './attendance-notifications.routes.js';
import { AttendanceNotificationService } from '../services/attendance-notifications.service.js';

export const attendanceRouter = Router();

// Mount Attendance Notifications Sub-Router
attendanceRouter.use('/notifications', attendanceNotificationsRouter);

// Helper to convert JS getDay() (0=Sun, 1=Mon... 6=Sat) to DayOfWeekName
export function getDayOfWeekName(dayIndex: number): DayOfWeekName {
  const days: DayOfWeekName[] = [
    'SUNDAY',
    'MONDAY',
    'TUESDAY',
    'WEDNESDAY',
    'THURSDAY',
    'FRIDAY',
    'SATURDAY'
  ];
  return days[dayIndex] || 'MONDAY';
}

// Helper to check if dayIndex is in configured weekendDays
export function isWeekendDay(dayIndex: number, weekendDays?: DayOfWeekName[]): boolean {
  const configured = weekendDays || database.attendanceSettings?.weekendDays || ['SATURDAY', 'SUNDAY'];
  const dayName = getDayOfWeekName(dayIndex);
  return configured.includes(dayName);
}

// Helper to check working day status for a given date
export function getDateWorkingStatus(dateStr: string, sessionId?: string) {
  const settings = database.attendanceSettings;
  const holidays = database.holidays || [];
  const specialDays = database.specialWorkingDays || [];

  const targetSessionId = sessionId || database.schoolSettings.academicSessionId;

  // 1. Check Special Working Day override
  const specialDay = specialDays.find(
    (s) => s.date === dateStr && s.status === 'ACTIVE' && (!targetSessionId || s.academicSessionId === targetSessionId)
  );
  if (specialDay) {
    return {
      isWorkingDay: true,
      dayType: 'SPECIAL_WORKING_DAY' as const,
      reason: specialDay.reason,
      specialDay
    };
  }

  // 2. Check Holidays
  const activeHoliday = holidays.find(
    (h) =>
      h.status === 'ACTIVE' &&
      dateStr >= h.startDate &&
      dateStr <= h.endDate &&
      (!targetSessionId || h.academicSessionId === targetSessionId)
  );
  if (activeHoliday) {
    return {
      isWorkingDay: false,
      dayType: 'HOLIDAY' as const,
      reason: activeHoliday.holidayName,
      holiday: activeHoliday
    };
  }

  // 3. Check Weekend Day
  const [year, month, day] = dateStr.split('-').map(Number);
  const dateObj = new Date(year, month - 1, day);
  const dayIndex = dateObj.getDay();
  const isWeekend = isWeekendDay(dayIndex, settings?.weekendDays);

  if (isWeekend) {
    return {
      isWorkingDay: false,
      dayType: 'WEEKEND' as const,
      reason: 'Scheduled Weekend',
      dayIndex
    };
  }

  return {
    isWorkingDay: true,
    dayType: 'WORKING_DAY' as const,
    reason: 'Regular Working Day',
    dayIndex
  };
}

// Helper to calculate working dates and non-working dates in a leave date range
export function calculateLeaveWorkingDates(startDateStr: string, endDateStr: string, sessionId?: string) {
  const workingDates: string[] = [];
  const nonWorkingDates: { date: string; dayType: string; reason: string }[] = [];

  const start = new Date(startDateStr + 'T00:00:00Z');
  const end = new Date(endDateStr + 'T00:00:00Z');

  if (isNaN(start.getTime()) || isNaN(end.getTime()) || start > end) {
    return {
      startDate: startDateStr,
      endDate: endDateStr,
      totalCalendarDays: 0,
      totalWorkingLeaveDays: 0,
      workingDates: [],
      nonWorkingDates: []
    };
  }

  const current = new Date(start);
  let totalCalendarDays = 0;
  while (current <= end) {
    totalCalendarDays++;
    const dateStr = current.toISOString().split('T')[0];
    const status = getDateWorkingStatus(dateStr, sessionId);
    if (status.isWorkingDay) {
      workingDates.push(dateStr);
    } else {
      nonWorkingDates.push({
        date: dateStr,
        dayType: status.dayType,
        reason: status.reason
      });
    }
    current.setUTCDate(current.getUTCDate() + 1);
  }

  return {
    startDate: startDateStr,
    endDate: endDateStr,
    totalCalendarDays,
    totalWorkingLeaveDays: workingDates.length,
    workingDates,
    nonWorkingDates
  };
}

// Helper to detect overlapping leaves for applicant
export function detectOverlappingLeave(
  applicantId: string,
  startDateStr: string,
  endDateStr: string,
  excludeId?: string,
  onlyApproved = false
): LeaveApplication | undefined {
  if (!database.leaveApplications) database.leaveApplications = [];

  const targetStatuses = onlyApproved
    ? ['APPROVED']
    : ['APPROVED', 'SUBMITTED', 'PENDING', 'UNDER_REVIEW'];

  return database.leaveApplications.find((app) => {
    if (excludeId && app.id === excludeId) return false;

    const matchesApplicant =
      app.applicantId === applicantId ||
      app.studentId === applicantId ||
      app.teacherProfileId === applicantId ||
      app.userId === applicantId;

    if (!matchesApplicant) return false;
    if (!targetStatuses.includes(app.status)) return false;

    const appStart = app.startDate || app.leaveDate;
    const appEnd = app.endDate || app.startDate || app.leaveDate;

    // Overlap condition: !(appEnd < startDateStr || appStart > endDateStr)
    return !(appEnd < startDateStr || appStart > endDateStr);
  });
}

/**
 * Helper: Resolve Teacher Profile for Authenticated User with strict cohort access
 */
function getTeacherContext(req: AuthenticatedRequest) {
  const user = req.user!;
  if (user.role === 'SUPER_ADMIN') {
    return {
      isAdmin: true,
      teacherProfile: null,
      assignedClassIds: database.classes.map((c) => c.id)
    };
  }
  const teacherProfile = database.teacherProfiles.find((t) => t.userId === user.id);
  const assignedClassIds = new Set<string>(teacherProfile?.assignedClassIds || []);

  // Also include classes where teacher is section class teacher
  if (teacherProfile) {
    database.sections.forEach((sec) => {
      if (sec.classTeacherId === teacherProfile.id && sec.classId) {
        assignedClassIds.add(sec.classId);
      }
    });

    // Also include classes where teacher teaches subjects
    database.subjects.forEach((subj) => {
      if (subj.teacherId === teacherProfile.id) {
        if (subj.classId) assignedClassIds.add(subj.classId);
        if (subj.classIds) subj.classIds.forEach((cid) => assignedClassIds.add(cid));
      }
    });
  }

  return {
    isAdmin: false,
    teacherProfile,
    assignedClassIds: Array.from(assignedClassIds)
  };
}

/**
 * Helper: Check if user is authorized to access student attendance records (RBAC + IDOR security)
 */
function isUserAuthorizedForStudent(
  req: AuthenticatedRequest,
  student: { id: string; userId?: string; classId?: string; guardianEmail?: string }
): boolean {
  const user = req.user!;
  if (user.role === 'SUPER_ADMIN') return true;

  if (user.role === 'STUDENT') {
    return (
      user.id === student.userId ||
      database.studentProfiles.find((s) => s.userId === user.id)?.id === student.id
    );
  }

  if (user.role === 'GUARDIAN') {
    const guardian = (database.guardians || []).find((g) => g.userId === user.id);
    if (guardian && guardian.studentIds.includes(student.id)) return true;
    if (student.guardianEmail && student.guardianEmail.toLowerCase() === user.email.toLowerCase()) return true;
    return false;
  }

  if (user.role === 'TEACHER') {
    const { assignedClassIds } = getTeacherContext(req);
    return !!(student.classId && assignedClassIds.includes(student.classId));
  }

  return false;
}

// =========================================================================
// 1. GET ATTENDANCE SHEET (Load student roster for marking attendance)
// =========================================================================
attendanceRouter.get('/sheet', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { classId, sectionId, date, subjectId } = req.query as {
      classId?: string;
      sectionId?: string;
      date?: string;
      subjectId?: string;
    };

    if (!classId || !sectionId) {
      res.status(400).json({
        success: false,
        error: 'Both Class and Section are required to load the attendance sheet.'
      });
      return;
    }

    const effectiveDate = (date || new Date().toISOString().split('T')[0]).trim();
    const { isAdmin, teacherProfile, assignedClassIds } = getTeacherContext(req);

    // SECURITY: Validate Teacher Class Assignment
    if (!isAdmin && (!teacherProfile || !assignedClassIds.includes(classId))) {
      res.status(403).json({
        success: false,
        error: 'Access denied. You are not assigned to teach or manage this class cohort.',
        code: 'FORBIDDEN_CLASS_ACCESS'
      });
      return;
    }

    const cls = database.classes.find((c) => c.id === classId);
    const sec = database.sections.find((s) => s.id === sectionId);
    const subj = subjectId ? database.subjects.find((sb) => sb.id === subjectId) : undefined;
    const activeSession = database.academicSessions.find((s) => s.isActive) || database.academicSessions[0];

    if (!cls || !sec) {
      res.status(404).json({
        success: false,
        error: 'Specified class or section was not found.'
      });
      return;
    }

    // Fetch students enrolled in this class and section
    const enrolledProfiles = database.studentProfiles.filter(
      (s) => s.classId === classId && s.sectionId === sectionId && s.status !== 'inactive'
    );

    // Fetch existing attendance records for this class, section, date, and subject (if any)
    const existingRecords = database.attendanceRecords.filter((r) => {
      const matchBasic = r.classId === classId && r.sectionId === sectionId && r.date === effectiveDate;
      if (!matchBasic) return false;
      if (subjectId) {
        return r.subjectId === subjectId;
      }
      return !r.subjectId || r.subjectId === 'daily';
    });

    const isExisting = existingRecords.length > 0;
    const firstExisting = existingRecords[0];

    const sheetStudents: AttendanceSheetStudent[] = enrolledProfiles.map((p) => {
      const u = database.users.find((usr) => usr.id === p.userId);
      const nameParts = (u?.name || `${p.firstName || ''} ${p.lastName || ''}`.trim() || 'Student').split(' ');
      const existing = existingRecords.find((r) => r.studentId === p.id);

      return {
        studentId: p.id,
        userId: p.userId,
        admissionNumber: p.admissionNumber,
        rollNumber: p.rollNumber,
        firstName: p.firstName || nameParts[0],
        lastName: p.lastName || nameParts.slice(1).join(' ') || 'Student',
        fullName: u?.name || `${p.firstName || ''} ${p.lastName || ''}`.trim() || 'Student Name',
        avatarUrl: u?.avatarUrl || p.avatarUrl,
        gender: p.gender || 'unspecified',
        status: existing ? existing.status : 'PRESENT',
        remarks: existing?.remarks || '',
        existingRecordId: existing?.id
      };
    });

    // Sort by roll number ascending
    sheetStudents.sort((a, b) => (a.rollNumber || '').localeCompare(b.rollNumber || ''));

    // Compute Summary counts
    const dayWorkingStatus = getDateWorkingStatus(effectiveDate, activeSession?.id);
    const total = sheetStudents.length;
    const present = sheetStudents.filter((s) => s.status === 'PRESENT').length;
    const absent = sheetStudents.filter((s) => s.status === 'ABSENT').length;
    const late = sheetStudents.filter((s) => s.status === 'LATE').length;
    const halfDay = sheetStudents.filter((s) => s.status === 'HALF_DAY').length;
    const excused = sheetStudents.filter((s) => s.status === 'EXCUSED' || (s.status as string) === 'LEAVE').length;
    const attendanceRate = total > 0 ? Math.round(((present + late + (halfDay * 0.5)) / total) * 1000) / 10 : 0;

    const sheetData: AttendanceSheetData & {
      isWorkingDay: boolean;
      dayType: string;
      nonWorkingReason?: string;
      submissionStatus: 'DRAFT' | 'SUBMITTED' | 'FINALIZED';
    } = {
      classId,
      className: cls.name,
      sectionId,
      sectionName: sec.name,
      subjectId: subj?.id,
      subjectName: subj?.name,
      academicSessionId: activeSession?.id || 'session-2026-2027',
      academicSessionName: activeSession?.sessionName || '2026-2027 Academic Year',
      date: effectiveDate,
      isExisting,
      recordedByTeacherName: firstExisting?.recordedByTeacherName,
      lastUpdated: firstExisting?.updatedAt || firstExisting?.createdAt,
      isWorkingDay: dayWorkingStatus.isWorkingDay,
      dayType: dayWorkingStatus.dayType,
      nonWorkingReason: dayWorkingStatus.reason,
      submissionStatus: firstExisting?.submissionStatus || (isExisting ? 'SUBMITTED' : 'DRAFT'),
      students: sheetStudents,
      summary: {
        total,
        present,
        absent,
        late,
        halfDay,
        excused,
        attendanceRate
      }
    };

    res.json({
      success: true,
      data: sheetData
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// =========================================================================
// 2. SUBMIT NEW ATTENDANCE (With duplicate prevention)
// =========================================================================
attendanceRouter.post('/', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    const { classId, sectionId, subjectId, date, records, submissionStatus, allowOverride, overrideReason } = req.body as {
      classId: string;
      sectionId: string;
      subjectId?: string;
      date: string;
      records: Array<{ studentId: string; status: AttendanceStatus; remarks?: string }>;
      submissionStatus?: 'DRAFT' | 'SUBMITTED' | 'FINALIZED';
      allowOverride?: boolean;
      overrideReason?: string;
    };

    if (!classId || !sectionId || !date || !Array.isArray(records) || records.length === 0) {
      res.status(400).json({
        success: false,
        error: 'Class, Section, Date, and at least one student attendance record are required.'
      });
      return;
    }

    // Validate Date format YYYY-MM-DD
    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
    if (!dateRegex.test(date)) {
      res.status(400).json({
        success: false,
        error: 'Invalid date format. Expected YYYY-MM-DD.'
      });
      return;
    }

    const { isAdmin, teacherProfile, assignedClassIds } = getTeacherContext(req);

    // SECURITY: Validate Teacher Class Assignment
    if (!isAdmin && (!teacherProfile || !assignedClassIds.includes(classId))) {
      res.status(403).json({
        success: false,
        error: 'Access denied. You are not authorized to submit attendance for this class.',
        code: 'FORBIDDEN_CLASS_ACCESS'
      });
      return;
    }

    const cls = database.classes.find((c) => c.id === classId);
    const sec = database.sections.find((s) => s.id === sectionId);
    const subj = subjectId ? database.subjects.find((sb) => sb.id === subjectId) : undefined;
    const activeSession = database.academicSessions.find((s) => s.isActive) || database.academicSessions[0];

    if (!cls || !sec) {
      res.status(404).json({ success: false, error: 'Specified class or section was not found.' });
      return;
    }

    // ACADEMIC SESSION VALIDATION
    if (activeSession) {
      if (date < activeSession.startDate || date > activeSession.endDate) {
        res.status(400).json({
          success: false,
          error: `Attendance date (${date}) is outside the active academic session range (${activeSession.startDate} to ${activeSession.endDate}).`,
          code: 'DATE_OUTSIDE_SESSION'
        });
        return;
      }
    }

    // CALENDAR WORKING DAY VALIDATION (Weekends & Holidays)
    const dayWorkingStatus = getDateWorkingStatus(date, activeSession?.id);
    if (!dayWorkingStatus.isWorkingDay && !allowOverride) {
      res.status(400).json({
        success: false,
        error: `Attendance cannot be recorded on a ${dayWorkingStatus.dayType.toLowerCase()} (${dayWorkingStatus.reason}) without authorized override.`,
        code: 'NON_WORKING_DAY_RESTRICTION',
        dayType: dayWorkingStatus.dayType,
        reason: dayWorkingStatus.reason
      });
      return;
    }

    if (!dayWorkingStatus.isWorkingDay && allowOverride && (!overrideReason || !overrideReason.trim())) {
      res.status(400).json({
        success: false,
        error: 'An override reason is mandatory when recording attendance on a non-working day (weekend/holiday).',
        code: 'OVERRIDE_REASON_REQUIRED'
      });
      return;
    }

    // PREVENT DUPLICATE SUBMISSION: Check if attendance already recorded for class+section+date+subject
    const duplicateRecords = database.attendanceRecords.filter((r) => {
      const matchBasic = r.classId === classId && r.sectionId === sectionId && r.date === date;
      if (!matchBasic) return false;
      if (subjectId) {
        return r.subjectId === subjectId;
      }
      return !r.subjectId || r.subjectId === 'daily';
    });

    const isExistingDraft =
      duplicateRecords.length > 0 &&
      duplicateRecords.every((r) => r.submissionStatus === 'DRAFT' || r.isDraft);

    if (duplicateRecords.length > 0 && !isExistingDraft) {
      res.status(409).json({
        success: false,
        error: `Attendance for ${cls.name} (${sec.name}) on ${date} has already been recorded. Please use the Edit Attendance option to make corrections.`,
        code: 'ATTENDANCE_ALREADY_EXISTS',
        existingCount: duplicateRecords.length
      });
      return;
    }

    if (isExistingDraft) {
      // Clear previous draft entries so updated draft or final submission records take their place
      database.attendanceRecords = database.attendanceRecords.filter(
        (r) => !duplicateRecords.includes(r)
      );
    }

    // Check individual student uniqueness constraint
    for (const item of records) {
      const studentProfile = database.studentProfiles.find(
        (s) => s.id === item.studentId || s.userId === item.studentId
      );
      const studentTargetId = studentProfile?.id || item.studentId;
      const studentUserId = studentProfile?.userId || item.studentId;

      const existingRec = database.attendanceRecords.find(
        (r) =>
          (r.studentId === studentTargetId || r.userId === studentUserId || r.studentId === item.studentId) &&
          r.date === date &&
          (!subjectId || r.subjectId === subjectId)
      );
      if (existingRec) {
        res.status(409).json({
          success: false,
          error: `Duplicate attendance detected: Student ID ${item.studentId} already has an attendance entry on ${date}.`,
          code: 'DUPLICATE_STUDENT_ATTENDANCE'
        });
        return;
      }
    }

    const now = new Date().toISOString();
    const teacherName = user.name || (teacherProfile ? `${teacherProfile.firstName || ''} ${teacherProfile.lastName || ''}`.trim() : 'Instructor');
    const teacherId = teacherProfile?.id || user.id;

    const createdRecords: AttendanceRecord[] = [];

    for (const item of records) {
      const studentProfile = database.studentProfiles.find(
        (s) => s.id === item.studentId || s.userId === item.studentId
      );
      if (!studentProfile) continue;

      // Ensure student belongs to class & section
      if (studentProfile.classId !== classId || studentProfile.sectionId !== sectionId) {
        continue;
      }

      const u = database.users.find((usr) => usr.id === studentProfile.userId);
      const studentName = u?.name || `${studentProfile.firstName || ''} ${studentProfile.lastName || ''}`.trim() || 'Student';

      const validStatus: AttendanceStatus = ['PRESENT', 'ABSENT', 'LATE', 'HALF_DAY', 'EXCUSED', 'LEAVE'].includes(item.status)
        ? item.status
        : 'PRESENT';

      const newRec: AttendanceRecord = {
        id: `att-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
        studentId: studentProfile.id,
        userId: studentProfile.userId,
        studentName,
        admissionNumber: studentProfile.admissionNumber,
        rollNumber: studentProfile.rollNumber,
        avatarUrl: u?.avatarUrl || studentProfile.avatarUrl,
        classId,
        className: cls.name,
        sectionId,
        sectionName: sec.name,
        subjectId: subj?.id,
        subjectName: subj?.name,
        academicSessionId: studentProfile.academicSessionId || activeSession?.id || 'session-2026-2027',
        academicSessionName: activeSession?.sessionName || '2026-2027 Academic Year',
        date,
        status: validStatus,
        remarks: item.remarks?.trim() || '',
        submissionStatus: submissionStatus === 'DRAFT' ? 'DRAFT' : 'SUBMITTED',
        isOverridden: !dayWorkingStatus.isWorkingDay && !!allowOverride,
        overrideReason: !dayWorkingStatus.isWorkingDay ? overrideReason?.trim() : undefined,
        correctionHistory: [],
        recordedByTeacherId: teacherId,
        recordedByTeacherName: teacherName,
        createdAt: now,
        updatedAt: now
      };

      database.attendanceRecords.push(newRec);
      createdRecords.push(newRec);
    }

    // AUDIT LOG
    logAudit({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action: submissionStatus === 'DRAFT' ? 'CREATE' : 'SUBMIT',
      entity: 'ATTENDANCE',
      entityType: 'ATTENDANCE',
      entityId: `${classId}-${sectionId}-${date}`,
      details: `${submissionStatus === 'DRAFT' ? 'Saved draft' : 'Submitted'} attendance for ${cls.name} - ${sec.name} on date ${date} (${createdRecords.length} students recorded). Recorded by ${teacherName}.${!dayWorkingStatus.isWorkingDay ? ` Override: ${overrideReason}` : ''}`,
      ipAddress: req.ip
    });

    const presentCount = createdRecords.filter((r) => r.status === 'PRESENT').length;
    const absentCount = createdRecords.filter((r) => r.status === 'ABSENT').length;
    const lateCount = createdRecords.filter((r) => r.status === 'LATE').length;
    const halfDayCount = createdRecords.filter((r) => r.status === 'HALF_DAY').length;
    const excusedCount = createdRecords.filter((r) => r.status === 'EXCUSED' || (r.status as string) === 'LEAVE').length;

    // Trigger Attendance Notifications asynchronously (Part 8F)
    if (submissionStatus !== 'DRAFT') {
      AttendanceNotificationService.processBulkAttendanceAlerts({
        records: createdRecords.map((r) => ({
          studentId: r.studentId,
          status: r.status,
          remarks: r.remarks,
          attendanceRecordId: r.id
        })),
        date,
        actorUser: { id: user.id, name: user.name, role: user.role }
      });
    }

    res.status(201).json({
      success: true,
      message: `Attendance successfully ${submissionStatus === 'DRAFT' ? 'saved as draft' : 'submitted'} for ${cls.name} (${sec.name}) on ${date}.`,
      data: {
        totalRecorded: createdRecords.length,
        presentCount,
        absentCount,
        lateCount,
        halfDayCount,
        excusedCount,
        submissionStatus: submissionStatus === 'DRAFT' ? 'DRAFT' : 'SUBMITTED',
        date,
        records: createdRecords
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// =========================================================================
// 3. EDIT / CORRECT ATTENDANCE (With audit tracking)
// =========================================================================
attendanceRouter.put('/', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    const { classId, sectionId, subjectId, date, records, changeReason } = req.body as {
      classId: string;
      sectionId: string;
      subjectId?: string;
      date: string;
      records: Array<{ studentId: string; status: AttendanceStatus; remarks?: string }>;
      changeReason?: string;
    };

    if (!classId || !sectionId || !date || !Array.isArray(records) || records.length === 0) {
      res.status(400).json({
        success: false,
        error: 'Class, Section, Date, and updated student records are required.'
      });
      return;
    }

    const { isAdmin, teacherProfile, assignedClassIds } = getTeacherContext(req);

    // SECURITY: Validate Teacher Class Assignment
    if (!isAdmin && (!teacherProfile || !assignedClassIds.includes(classId))) {
      res.status(403).json({
        success: false,
        error: 'Access denied. You are not authorized to modify attendance for this class.',
        code: 'FORBIDDEN_CLASS_ACCESS'
      });
      return;
    }

    const cls = database.classes.find((c) => c.id === classId);
    const sec = database.sections.find((s) => s.id === sectionId);
    const subj = subjectId ? database.subjects.find((sb) => sb.id === subjectId) : undefined;
    const activeSession = database.academicSessions.find((s) => s.isActive) || database.academicSessions[0];

    const now = new Date().toISOString();
    const teacherName = user.name || (teacherProfile ? `${teacherProfile.firstName || ''} ${teacherProfile.lastName || ''}`.trim() : 'Instructor');
    const teacherId = teacherProfile?.id || user.id;

    let modifiedCount = 0;
    const updatedRecords: AttendanceRecord[] = [];
    const changesSummary: string[] = [];

    for (const item of records) {
      const studentProfile = database.studentProfiles.find(
        (s) => s.id === item.studentId || s.userId === item.studentId
      );
      if (!studentProfile) continue;

      const studentTargetId = studentProfile.id;
      const studentUserId = studentProfile.userId;

      const existingIndex = database.attendanceRecords.findIndex((r) => {
        const matchBasic =
          (r.studentId === studentTargetId || r.userId === studentUserId || r.studentId === item.studentId) &&
          r.classId === classId &&
          r.sectionId === sectionId &&
          r.date === date;
        if (!matchBasic) return false;
        if (subjectId) return r.subjectId === subjectId;
        return !r.subjectId || r.subjectId === 'daily';
      });

      const validStatus: AttendanceStatus = ['PRESENT', 'ABSENT', 'LATE', 'HALF_DAY', 'EXCUSED', 'LEAVE'].includes(item.status)
        ? item.status
        : 'PRESENT';

      if (existingIndex !== -1) {
        const prev = database.attendanceRecords[existingIndex];
        if (prev.status !== validStatus || prev.remarks !== item.remarks) {
          changesSummary.push(`${prev.studentName || 'Student'}: ${prev.status} → ${validStatus}`);
          if (prev.status !== validStatus) {
            const hist = prev.correctionHistory || [];
            hist.push({
              previousStatus: prev.status,
              newStatus: validStatus,
              changedByUserId: user.id,
              changedByUserName: teacherName,
              changedAt: now,
              reason: (changeReason || 'Attendance correction').trim()
            });
            prev.correctionHistory = hist;

            // Trigger Attendance Correction Alert (Part 8F)
            AttendanceNotificationService.dispatchEvent({
              eventType: 'ATTENDANCE_CORRECTION',
              date,
              studentId: prev.studentId,
              attendanceRecordId: prev.id,
              previousStatus: prev.status,
              newStatus: validStatus,
              reason: changeReason || 'Batch attendance correction',
              remarks: item.remarks,
              actorUser: { id: user.id, name: user.name, role: user.role }
            });
          }
        }
        database.attendanceRecords[existingIndex] = {
          ...prev,
          status: validStatus,
          remarks: item.remarks !== undefined ? item.remarks.trim() : prev.remarks,
          submissionStatus: (req.body.submissionStatus as any) || prev.submissionStatus || 'SUBMITTED',
          updatedByTeacherId: teacherId,
          updatedByTeacherName: teacherName,
          updatedAt: now
        };
        updatedRecords.push(database.attendanceRecords[existingIndex]);
        modifiedCount++;
      } else {
        // Record didn't exist yet, insert as newly recorded
        const u = database.users.find((usr) => usr.id === studentProfile.userId);
        const newRec: AttendanceRecord = {
          id: `att-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
          studentId: studentProfile.id,
          userId: studentProfile.userId,
          studentName: u?.name || `${studentProfile.firstName || ''} ${studentProfile.lastName || ''}`.trim() || 'Student',
          admissionNumber: studentProfile.admissionNumber,
          rollNumber: studentProfile.rollNumber,
          avatarUrl: u?.avatarUrl || studentProfile.avatarUrl,
          classId,
          className: cls?.name || 'Class',
          sectionId,
          sectionName: sec?.name || 'Section',
          subjectId: subj?.id,
          subjectName: subj?.name,
          academicSessionId: studentProfile.academicSessionId || activeSession?.id || 'session-2026-2027',
          academicSessionName: activeSession?.sessionName || '2026-2027 Academic Year',
          date,
          status: validStatus,
          remarks: item.remarks?.trim() || '',
          submissionStatus: (req.body.submissionStatus as any) || 'SUBMITTED',
          correctionHistory: [],
          recordedByTeacherId: teacherId,
          recordedByTeacherName: teacherName,
          updatedByTeacherId: teacherId,
          updatedByTeacherName: teacherName,
          createdAt: now,
          updatedAt: now
        };
        database.attendanceRecords.push(newRec);
        updatedRecords.push(newRec);
        modifiedCount++;
      }
    }

    // AUDIT LOG
    logAudit({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action: 'UPDATE',
      entity: 'ATTENDANCE',
      entityType: 'ATTENDANCE',
      entityId: `${classId}-${sectionId}-${date}`,
      details: `Corrected attendance for ${cls?.name || 'Class'} - ${sec?.name || 'Section'} on ${date} (${modifiedCount} updates). Reason: ${changeReason || 'Correction by faculty'}. Updated by ${teacherName}.`,
      ipAddress: req.ip,
      metadata: {
        changeReason: changeReason || 'Routine Correction',
        changes: changesSummary.slice(0, 10)
      }
    });

    res.json({
      success: true,
      message: `Attendance records successfully updated for ${cls?.name || 'Class'} on ${date}.`,
      data: {
        modifiedCount,
        updatedRecords
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// =========================================================================
// 3B. MARK OR CORRECT SINGLE STUDENT ATTENDANCE (Super Admin & Authorized Teacher)
// =========================================================================
attendanceRouter.post('/students/mark', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    const {
      studentId,
      date,
      status,
      remarks,
      changeReason,
      classId,
      sectionId,
      subjectId,
      academicSessionId,
      allowOverride,
      overrideReason
    } = req.body as {
      studentId: string;
      date: string;
      status: AttendanceStatus;
      remarks?: string;
      changeReason?: string;
      classId?: string;
      sectionId?: string;
      subjectId?: string;
      academicSessionId?: string;
      allowOverride?: boolean;
      overrideReason?: string;
    };

    if (!studentId || !date || !status) {
      res.status(400).json({
        success: false,
        error: 'Student ID, date, and attendance status are required.'
      });
      return;
    }

    const studentProfile = database.studentProfiles.find((s) => s.id === studentId || s.userId === studentId);
    if (!studentProfile) {
      res.status(404).json({ success: false, error: 'Student profile was not found.' });
      return;
    }

    const effectiveClassId = classId || studentProfile.classId;
    const effectiveSectionId = sectionId || studentProfile.sectionId;
    const { isAdmin, teacherProfile, assignedClassIds } = getTeacherContext(req);

    if (!isAdmin && (!teacherProfile || !assignedClassIds.includes(effectiveClassId))) {
      res.status(403).json({
        success: false,
        error: 'Access denied. You are not authorized to mark attendance for this student.',
        code: 'FORBIDDEN_STUDENT_ACCESS'
      });
      return;
    }

    const activeSession = academicSessionId
      ? database.academicSessions.find((s) => s.id === academicSessionId)
      : database.academicSessions.find((s) => s.isActive) || database.academicSessions[0];

    // CALENDAR WORKING DAY VALIDATION
    const dayWorkingStatus = getDateWorkingStatus(date, activeSession?.id);
    if (!dayWorkingStatus.isWorkingDay && !allowOverride) {
      res.status(400).json({
        success: false,
        error: `Attendance cannot be recorded on a ${dayWorkingStatus.dayType.toLowerCase()} (${dayWorkingStatus.reason}) without authorized override.`,
        code: 'NON_WORKING_DAY_RESTRICTION',
        dayType: dayWorkingStatus.dayType,
        reason: dayWorkingStatus.reason
      });
      return;
    }

    if (!dayWorkingStatus.isWorkingDay && allowOverride && (!overrideReason || !overrideReason.trim())) {
      res.status(400).json({
        success: false,
        error: 'An override reason is mandatory when recording attendance on a non-working day.',
        code: 'OVERRIDE_REASON_REQUIRED'
      });
      return;
    }

    const validStatus: AttendanceStatus = ['PRESENT', 'ABSENT', 'LATE', 'HALF_DAY', 'EXCUSED', 'LEAVE'].includes(status)
      ? status
      : 'PRESENT';

    const now = new Date().toISOString();
    const actorName = user.name || (teacherProfile ? `${teacherProfile.firstName || ''} ${teacherProfile.lastName || ''}`.trim() : 'Staff');
    const actorId = teacherProfile?.id || user.id;

    // Check existing record
    const existingIndex = database.attendanceRecords.findIndex(
      (r) => r.studentId === studentId && r.date === date && (!subjectId || r.subjectId === subjectId)
    );

    let savedRecord: AttendanceRecord;

    if (existingIndex !== -1) {
      const prev = database.attendanceRecords[existingIndex];
      const prevStatus = prev.status;
      const history = prev.correctionHistory || [];

      if (prevStatus !== validStatus) {
        history.push({
          previousStatus: prevStatus,
          newStatus: validStatus,
          changedByUserId: user.id,
          changedByUserName: actorName,
          changedAt: now,
          reason: (changeReason || 'Direct attendance correction').trim()
        });

        // Trigger Attendance Correction Alert (Part 8F)
        AttendanceNotificationService.dispatchEvent({
          eventType: 'ATTENDANCE_CORRECTION',
          date,
          studentId: studentProfile.id,
          attendanceRecordId: prev.id,
          previousStatus: prevStatus,
          newStatus: validStatus,
          reason: changeReason || 'Direct attendance correction',
          remarks,
          actorUser: { id: user.id, name: user.name, role: user.role }
        });
      }

      savedRecord = {
        ...prev,
        status: validStatus,
        remarks: remarks !== undefined ? remarks.trim() : prev.remarks,
        correctionHistory: history,
        isOverridden: !dayWorkingStatus.isWorkingDay ? true : prev.isOverridden,
        overrideReason: !dayWorkingStatus.isWorkingDay ? overrideReason : prev.overrideReason,
        updatedByTeacherId: actorId,
        updatedByTeacherName: actorName,
        updatedAt: now
      };
      database.attendanceRecords[existingIndex] = savedRecord;

      logAudit({
        userId: user.id,
        userName: user.name,
        userRole: user.role,
        action: 'CORRECT',
        entity: 'ATTENDANCE',
        entityType: 'ATTENDANCE',
        entityId: savedRecord.id,
        details: `Corrected attendance for ${savedRecord.studentName || 'Student'} on ${date}: ${prevStatus} → ${validStatus}. Reason: ${changeReason || 'Administrative correction'}.`,
        ipAddress: req.ip
      });
    } else {
      const cls = database.classes.find((c) => c.id === effectiveClassId);
      const sec = database.sections.find((s) => s.id === effectiveSectionId);
      const subj = subjectId ? database.subjects.find((s) => s.id === subjectId) : undefined;
      const u = database.users.find((usr) => usr.id === studentProfile.userId);

      savedRecord = {
        id: `att-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
        studentId: studentProfile.id,
        userId: studentProfile.userId,
        studentName: u?.name || `${studentProfile.firstName || ''} ${studentProfile.lastName || ''}`.trim() || 'Student',
        admissionNumber: studentProfile.admissionNumber,
        rollNumber: studentProfile.rollNumber,
        avatarUrl: u?.avatarUrl || studentProfile.avatarUrl,
        classId: effectiveClassId,
        className: cls?.name || 'Class',
        sectionId: effectiveSectionId,
        sectionName: sec?.name || 'Section',
        subjectId: subj?.id,
        subjectName: subj?.name,
        academicSessionId: activeSession?.id || 'session-2026-2027',
        academicSessionName: activeSession?.sessionName || '2026-2027 Academic Year',
        date,
        status: validStatus,
        remarks: remarks?.trim() || '',
        submissionStatus: 'SUBMITTED',
        isOverridden: !dayWorkingStatus.isWorkingDay,
        overrideReason: !dayWorkingStatus.isWorkingDay ? overrideReason?.trim() : undefined,
        correctionHistory: [],
        recordedByTeacherId: actorId,
        recordedByTeacherName: actorName,
        createdAt: now,
        updatedAt: now
      };
      database.attendanceRecords.push(savedRecord);

      logAudit({
        userId: user.id,
        userName: user.name,
        userRole: user.role,
        action: 'CREATE',
        entity: 'ATTENDANCE',
        entityType: 'ATTENDANCE',
        entityId: savedRecord.id,
        details: `Recorded attendance for ${savedRecord.studentName || 'Student'} on ${date} as ${validStatus}.`,
        ipAddress: req.ip
      });

      // Trigger Absence, Late, or Half-day alerts for new attendance record (Part 8F)
      if (validStatus === 'ABSENT') {
        AttendanceNotificationService.dispatchEvent({
          eventType: 'STUDENT_ABSENT',
          date,
          studentId: studentProfile.id,
          attendanceRecordId: savedRecord.id,
          newStatus: 'ABSENT',
          remarks: savedRecord.remarks,
          actorUser: { id: user.id, name: user.name, role: user.role }
        });
      } else if (validStatus === 'LATE') {
        AttendanceNotificationService.dispatchEvent({
          eventType: 'STUDENT_LATE',
          date,
          studentId: studentProfile.id,
          attendanceRecordId: savedRecord.id,
          newStatus: 'LATE',
          remarks: savedRecord.remarks,
          actorUser: { id: user.id, name: user.name, role: user.role }
        });
      } else if (validStatus === 'HALF_DAY') {
        AttendanceNotificationService.dispatchEvent({
          eventType: 'STUDENT_HALF_DAY',
          date,
          studentId: studentProfile.id,
          attendanceRecordId: savedRecord.id,
          newStatus: 'HALF_DAY',
          remarks: savedRecord.remarks,
          actorUser: { id: user.id, name: user.name, role: user.role }
        });
      }
    }

    res.json({
      success: true,
      message: `Attendance for ${savedRecord.studentName || 'Student'} successfully saved.`,
      data: savedRecord
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// =========================================================================
// 3C. EDIT SINGLE ATTENDANCE RECORD BY ID (Super Admin & Faculty)
// =========================================================================
attendanceRouter.put('/records/:id', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    const { id } = req.params;
    const { status, remarks, reason } = req.body as {
      status?: AttendanceStatus;
      remarks?: string;
      reason: string;
    };

    if (!reason || !reason.trim()) {
      res.status(400).json({
        success: false,
        error: 'A mandatory correction reason is required to modify an attendance record.',
        code: 'REASON_REQUIRED'
      });
      return;
    }

    const recordIndex = database.attendanceRecords.findIndex((r) => r.id === id);
    if (recordIndex === -1) {
      res.status(404).json({ success: false, error: 'Attendance record not found.' });
      return;
    }

    const prev = database.attendanceRecords[recordIndex];
    const { isAdmin, teacherProfile, assignedClassIds } = getTeacherContext(req);

    if (!isAdmin && (!teacherProfile || !assignedClassIds.includes(prev.classId))) {
      res.status(403).json({
        success: false,
        error: 'Access denied. You are not authorized to modify this attendance record.',
        code: 'FORBIDDEN_RECORD_ACCESS'
      });
      return;
    }

    const now = new Date().toISOString();
    const actorName = user.name || (teacherProfile ? `${teacherProfile.firstName || ''} ${teacherProfile.lastName || ''}`.trim() : 'Staff');
    const actorId = teacherProfile?.id || user.id;

    const validStatus: AttendanceStatus = status && ['PRESENT', 'ABSENT', 'LATE', 'HALF_DAY', 'EXCUSED', 'LEAVE'].includes(status)
      ? status
      : prev.status;

    const history = [...(prev.correctionHistory || [])];
    history.push({
      previousStatus: prev.status,
      newStatus: validStatus,
      changedByUserId: user.id,
      changedByUserName: actorName,
      changedAt: now,
      reason: reason.trim()
    });

    const updatedRec: AttendanceRecord & { editHistory?: any[] } = {
      ...prev,
      status: validStatus,
      remarks: remarks !== undefined ? remarks.trim() : prev.remarks,
      correctionHistory: history,
      editHistory: history,
      updatedByTeacherId: actorId,
      updatedByTeacherName: actorName,
      updatedAt: now
    };

    database.attendanceRecords[recordIndex] = updatedRec;

    logAudit({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action: 'CORRECT',
      entity: 'ATTENDANCE',
      entityType: 'ATTENDANCE',
      entityId: id,
      details: `Corrected attendance record ${id} for ${prev.studentName} on ${prev.date}: ${prev.status} → ${validStatus}. Reason: ${reason.trim()}`,
      ipAddress: req.ip
    });

    if (prev.status !== validStatus) {
      AttendanceNotificationService.dispatchEvent({
        eventType: 'ATTENDANCE_CORRECTION',
        date: prev.date,
        studentId: prev.studentId,
        attendanceRecordId: prev.id,
        previousStatus: prev.status,
        newStatus: validStatus,
        reason: reason.trim(),
        remarks: remarks !== undefined ? remarks.trim() : prev.remarks,
        actorUser: { id: user.id, name: user.name, role: user.role }
      });
    }

    res.json({
      success: true,
      message: 'Attendance record successfully updated.',
      data: updatedRec
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// =========================================================================
// 3D. DELETE / VOID ATTENDANCE RECORD (Super Admin Only)
// =========================================================================
attendanceRouter.delete('/records/:id', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    const { id } = req.params;
    const { reason } = req.body as { reason?: string };

    if (user.role !== 'SUPER_ADMIN') {
      res.status(403).json({
        success: false,
        error: 'Only Super Administrators can void or delete attendance records.',
        code: 'FORBIDDEN_ACTION'
      });
      return;
    }

    if (!reason || !reason.trim()) {
      res.status(400).json({
        success: false,
        error: 'A mandatory justification reason is required to void an attendance record.',
        code: 'REASON_REQUIRED'
      });
      return;
    }

    const recordIndex = database.attendanceRecords.findIndex((r) => r.id === id);
    if (recordIndex === -1) {
      res.status(404).json({ success: false, error: 'Attendance record not found.' });
      return;
    }

    const [deletedRec] = database.attendanceRecords.splice(recordIndex, 1);

    logAudit({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action: 'DELETE',
      entity: 'ATTENDANCE',
      entityType: 'ATTENDANCE',
      entityId: id,
      details: `Voided attendance record for ${deletedRec.studentName} on date ${deletedRec.date} (was ${deletedRec.status}). Reason: ${reason.trim()}`,
      ipAddress: req.ip
    });

    res.json({
      success: true,
      message: `Attendance record for ${deletedRec.studentName} on ${deletedRec.date} was successfully voided.`
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// =========================================================================
// 4. ATTENDANCE HISTORY & FILTERABLE LOGS
// =========================================================================
attendanceRouter.get('/history', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const {
      classId,
      sectionId,
      subjectId,
      studentId,
      date,
      startDate,
      endDate,
      status,
      academicSessionId,
      submissionStatus,
      search,
      page = '1',
      limit = '20'
    } = req.query as {
      classId?: string;
      sectionId?: string;
      subjectId?: string;
      studentId?: string;
      date?: string;
      startDate?: string;
      endDate?: string;
      status?: string;
      academicSessionId?: string;
      submissionStatus?: string;
      search?: string;
      page?: string;
      limit?: string;
    };

    const { isAdmin, teacherProfile, assignedClassIds } = getTeacherContext(req);

    const user = req.user!;

    // SECURITY: Role-based boundary enforcement
    if (!isAdmin) {
      if (user.role === 'TEACHER') {
        if (classId && !assignedClassIds.includes(classId)) {
          res.status(403).json({
            success: false,
            error: 'Access denied. You do not have authorization to view attendance history for this class.',
            code: 'FORBIDDEN_CLASS_ACCESS'
          });
          return;
        }
      } else if (user.role === 'STUDENT') {
        const studentProfile = database.studentProfiles.find((s) => s.userId === user.id);
        if (studentId && studentId !== user.id && studentId !== studentProfile?.id) {
          res.status(403).json({
            success: false,
            error: 'Access denied. You cannot view attendance history of other students.',
            code: 'FORBIDDEN_STUDENT_ACCESS'
          });
          return;
        }
      } else if (user.role === 'GUARDIAN') {
        const guardian = (database.guardians || []).find((g) => g.userId === user.id);
        if (studentId && (!guardian || !guardian.studentIds.includes(studentId))) {
          res.status(403).json({
            success: false,
            error: 'Access denied. You cannot view attendance history of students not linked to your family account.',
            code: 'FORBIDDEN_GUARDIAN_ACCESS'
          });
          return;
        }
      }
    }

    let records = database.attendanceRecords.filter((r) => {
      // Role scope filter (RBAC + IDOR)
      if (!isAdmin) {
        if (user.role === 'TEACHER') {
          if (!assignedClassIds.includes(r.classId)) return false;
        } else if (user.role === 'STUDENT') {
          const studentProfile = database.studentProfiles.find((s) => s.userId === user.id);
          if (r.userId !== user.id && r.studentId !== studentProfile?.id) return false;
        } else if (user.role === 'GUARDIAN') {
          const guardian = (database.guardians || []).find((g) => g.userId === user.id);
          if (!guardian || !guardian.studentIds.includes(r.studentId)) return false;
        } else {
          return false;
        }
      }

      if (classId && classId !== 'ALL' && r.classId !== classId) return false;
      if (sectionId && sectionId !== 'ALL' && r.sectionId !== sectionId) return false;
      if (subjectId && subjectId !== 'ALL' && r.subjectId !== subjectId) return false;
      if (studentId && r.studentId !== studentId && r.userId !== studentId) return false;
      if (status && status !== 'ALL' && r.status !== status) return false;
      if (academicSessionId && academicSessionId !== 'ALL' && r.academicSessionId !== academicSessionId) return false;
      if (submissionStatus && submissionStatus !== 'ALL' && (r.submissionStatus || 'SUBMITTED') !== submissionStatus) return false;
      if (date && r.date !== date) return false;
      if (startDate && r.date < startDate) return false;
      if (endDate && r.date > endDate) return false;

      if (search && search.trim()) {
        const q = search.toLowerCase().trim();
        const matchName = (r.studentName || '').toLowerCase().includes(q);
        const matchAdm = (r.admissionNumber || '').toLowerCase().includes(q);
        const matchRoll = (r.rollNumber || '').toLowerCase().includes(q);
        const matchRemark = (r.remarks || '').toLowerCase().includes(q);
        if (!matchName && !matchAdm && !matchRoll && !matchRemark) return false;
      }

      return true;
    });

    // Sort by date DESC, then class, then roll number
    records.sort((a, b) => {
      if (a.date !== b.date) return b.date.localeCompare(a.date);
      const clsA = a.className || '';
      const clsB = b.className || '';
      if (clsA !== clsB) return clsA.localeCompare(clsB);
      return (a.rollNumber || '').localeCompare(b.rollNumber || '');
    });

    // Compute dynamic statistics on filtered dataset
    const totalRecords = records.length;
    const presentCount = records.filter((r) => r.status === 'PRESENT').length;
    const absentCount = records.filter((r) => r.status === 'ABSENT').length;
    const lateCount = records.filter((r) => r.status === 'LATE').length;
    const halfDayCount = records.filter((r) => r.status === 'HALF_DAY').length;
    const excusedCount = records.filter((r) => r.status === 'EXCUSED' || (r.status as string) === 'LEAVE').length;
    const attendancePercentage = totalRecords > 0 ? Math.round(((presentCount + lateCount + (halfDayCount * 0.5)) / totalRecords) * 1000) / 10 : 0;

    // Pagination
    const pageNum = Math.max(1, parseInt(page, 10) || 1);
    const limitNum = Math.max(1, parseInt(limit, 10) || 20);
    const totalPages = Math.ceil(totalRecords / limitNum) || 1;
    const paginatedRecords = records.slice((pageNum - 1) * limitNum, pageNum * limitNum);

    res.json({
      success: true,
      data: paginatedRecords,
      summary: {
        totalRecords,
        presentCount,
        absentCount,
        lateCount,
        halfDayCount,
        excusedCount,
        attendancePercentage
      },
      pagination: {
        page: pageNum,
        limit: limitNum,
        total: totalRecords,
        totalPages
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Also support GET / for history
attendanceRouter.get('/', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  // Delegate to history handler
  (attendanceRouter as any).handle(
    Object.assign(req, { url: '/history' }),
    res
  );
});

// =========================================================================
// 5. ATTENDANCE SUMMARY & AGGREGATE STATS
// =========================================================================
attendanceRouter.get('/summary', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { classId, sectionId, subjectId, date, startDate, endDate } = req.query as {
      classId?: string;
      sectionId?: string;
      subjectId?: string;
      date?: string;
      startDate?: string;
      endDate?: string;
    };

    const { isAdmin, teacherProfile, assignedClassIds } = getTeacherContext(req);

    if (!isAdmin && classId && !assignedClassIds.includes(classId)) {
      res.status(403).json({
        success: false,
        error: 'Access denied to class statistics.',
        code: 'FORBIDDEN_CLASS_ACCESS'
      });
      return;
    }

    const filtered = database.attendanceRecords.filter((r) => {
      if (!isAdmin && !assignedClassIds.includes(r.classId)) return false;
      if (classId && classId !== 'ALL' && r.classId !== classId) return false;
      if (sectionId && sectionId !== 'ALL' && r.sectionId !== sectionId) return false;
      if (subjectId && subjectId !== 'ALL' && r.subjectId !== subjectId) return false;
      if (date && r.date !== date) return false;
      if (startDate && r.date < startDate) return false;
      if (endDate && r.date > endDate) return false;
      return true;
    });

    const totalRecords = filtered.length;
    const presentCount = filtered.filter((r) => r.status === 'PRESENT').length;
    const absentCount = filtered.filter((r) => r.status === 'ABSENT').length;
    const lateCount = filtered.filter((r) => r.status === 'LATE').length;
    const halfDayCount = filtered.filter((r) => r.status === 'HALF_DAY').length;
    const excusedCount = filtered.filter((r) => r.status === 'EXCUSED' || (r.status as string) === 'LEAVE').length;
    const attendancePercentage = totalRecords > 0 ? Math.round(((presentCount + lateCount + (halfDayCount * 0.5)) / totalRecords) * 1000) / 10 : 0;

    // Build class breakdown
    const classMap = new Map<string, {
      classId: string;
      sectionId: string;
      total: number;
      present: number;
      absent: number;
      late: number;
      halfDay: number;
      name: string;
      sectionName: string;
    }>();
    filtered.forEach((r) => {
      const key = `${r.classId}:::${r.sectionId}`;
      const existing = classMap.get(key) || {
        classId: r.classId,
        sectionId: r.sectionId,
        total: 0,
        present: 0,
        absent: 0,
        late: 0,
        halfDay: 0,
        name: r.className || 'Class',
        sectionName: r.sectionName || 'Section'
      };
      existing.total++;
      if (r.status === 'PRESENT') existing.present++;
      if (r.status === 'LATE') existing.late++;
      if (r.status === 'HALF_DAY') existing.halfDay++;
      if (r.status === 'ABSENT') existing.absent++;
      classMap.set(key, existing);
    });

    const classBreakdown = Array.from(classMap.values()).map((stats) => {
      const attended = stats.present + stats.late + (stats.halfDay * 0.5);
      return {
        classId: stats.classId,
        sectionId: stats.sectionId,
        className: stats.name,
        sectionName: stats.sectionName,
        total: stats.total,
        present: stats.present,
        absent: stats.absent,
        late: stats.late,
        halfDay: stats.halfDay,
        rate: stats.total > 0 ? Math.round((attended / stats.total) * 1000) / 10 : 0
      };
    });

    const summaryStats: AttendanceSummaryStats = {
      totalRecords,
      presentCount,
      absentCount,
      lateCount,
      halfDayCount,
      excusedCount,
      attendancePercentage,
      classBreakdown
    };

    res.json({
      success: true,
      data: summaryStats
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// =========================================================================
// 6. INDIVIDUAL STUDENT ATTENDANCE HISTORY
// =========================================================================
attendanceRouter.get('/students/:studentId', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { studentId } = req.params;
    const { startDate, endDate, subjectId } = req.query as {
      startDate?: string;
      endDate?: string;
      subjectId?: string;
    };

    // Find student
    const student = database.studentProfiles.find(
      (s) => s.id === studentId || s.userId === studentId || s.admissionNumber === studentId
    );

    if (!student) {
      res.status(404).json({ success: false, error: 'Student record not found.' });
      return;
    }

    // SECURITY: Enforce RBAC and IDOR prevention
    if (!isUserAuthorizedForStudent(req, student)) {
      res.status(403).json({
        success: false,
        error: 'Access denied. You are not authorized to inspect attendance records for this student.',
        code: 'FORBIDDEN_STUDENT_ACCESS'
      });
      return;
    }

    const u = database.users.find((usr) => usr.id === student.userId);
    const cls = database.classes.find((c) => c.id === student.classId);
    const sec = database.sections.find((s) => s.id === student.sectionId);
    const activeSession = database.academicSessions.find((s) => s.isActive) || database.academicSessions[0];
    const nameParts = (u?.name || `${student.firstName || ''} ${student.lastName || ''}`.trim() || 'Student Name').split(' ');

    const safeStudentInfo = {
      id: student.id,
      userId: student.userId,
      admissionNumber: student.admissionNumber,
      rollNumber: student.rollNumber,
      firstName: student.firstName || nameParts[0],
      lastName: student.lastName || nameParts.slice(1).join(' ') || 'Student',
      email: student.email || u?.email || 'student@sygmate.edu',
      avatarUrl: u?.avatarUrl || student.avatarUrl,
      classId: student.classId,
      className: cls?.name || 'Class',
      sectionId: student.sectionId,
      sectionName: sec?.name || 'Section',
      academicSessionId: student.academicSessionId || activeSession?.id,
      academicSessionName: activeSession?.sessionName || '2026-2027 Academic Year',
      dateOfBirth: student.dateOfBirth,
      gender: student.gender,
      bloodGroup: student.bloodGroup,
      address: student.address,
      guardianName: student.guardianName || 'Guardian on File',
      guardianRelation: student.guardianRelation || 'Parent / Guardian',
      guardianPhone: student.guardianPhone || 'N/A',
      guardianEmail: student.guardianEmail || 'N/A',
      enrollmentStatus: student.enrollmentStatus || 'active',
      status: student.status || 'active'
    };

    // Filter student records
    const studentRecords = database.attendanceRecords.filter((r) => {
      if (r.studentId !== student.id && r.userId !== student.userId) return false;
      if (startDate && r.date < startDate) return false;
      if (endDate && r.date > endDate) return false;
      if (subjectId && subjectId !== 'ALL' && r.subjectId !== subjectId) return false;
      return true;
    });

    // Sort by date DESC
    studentRecords.sort((a, b) => b.date.localeCompare(a.date));

    const totalSessions = studentRecords.length;
    const present = studentRecords.filter((r) => r.status === 'PRESENT').length;
    const absent = studentRecords.filter((r) => r.status === 'ABSENT').length;
    const late = studentRecords.filter((r) => r.status === 'LATE').length;
    const halfDay = studentRecords.filter((r) => r.status === 'HALF_DAY').length;
    const excused = studentRecords.filter((r) => r.status === 'EXCUSED' || (r.status as string) === 'LEAVE').length;
    const percentage =
      totalSessions > 0
        ? Math.round(((present + late + (halfDay * 0.5)) / totalSessions) * 1000) / 10
        : 100;

    const responseData: StudentAttendanceHistoryData = {
      student: safeStudentInfo as any,
      stats: {
        totalSessions,
        present,
        absent,
        late,
        halfDay,
        excused,
        percentage
      },
      summary: {
        totalSessions,
        presentCount: present,
        absentCount: absent,
        lateCount: late,
        halfDayCount: halfDay,
        excusedCount: excused,
        attendancePercentage: percentage
      },
      records: studentRecords
    };

    res.json({
      success: true,
      data: responseData
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// =========================================================================
// 7. LEAVE TYPES CONFIGURATION (Part 8D - Super Admin)
// =========================================================================

// GET /api/attendance/leave-types
attendanceRouter.get('/leave-types', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { applicableTo, activeOnly } = req.query as {
      applicableTo?: string;
      activeOnly?: string;
    };

    if (!database.leaveTypes) database.leaveTypes = [];

    let types = [...database.leaveTypes];

    if (activeOnly === 'true') {
      types = types.filter((t) => t.isActive);
    }

    if (applicableTo && applicableTo !== 'ALL') {
      const target = applicableTo.toUpperCase();
      types = types.filter((t) => t.applicableTo === target || t.applicableTo === 'BOTH');
    }

    res.json({
      success: true,
      data: types,
      total: types.length
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/attendance/leave-types (Super Admin Only)
attendanceRouter.post('/leave-types', requireAuth, requireRole('SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    const {
      name,
      code,
      description,
      applicableTo,
      maxDays,
      requiresAttachment,
      requiresApproval,
      isActive
    } = req.body as Partial<LeaveType>;

    if (!name || !name.trim()) {
      res.status(400).json({ success: false, error: 'Leave type name is required.' });
      return;
    }

    const validApplicable = ['STUDENT', 'TEACHER', 'BOTH'].includes(applicableTo || '')
      ? (applicableTo as 'STUDENT' | 'TEACHER' | 'BOTH')
      : 'BOTH';

    if (!database.leaveTypes) database.leaveTypes = [];

    // Duplicate name or code check
    const existing = database.leaveTypes.find(
      (t) => t.name.toLowerCase() === name.trim().toLowerCase() || (code && t.code.toLowerCase() === code.trim().toLowerCase())
    );
    if (existing) {
      res.status(409).json({ success: false, error: `A leave type with this name or code already exists.` });
      return;
    }

    const now = new Date().toISOString();
    const newType: LeaveType = {
      id: `lt-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      name: name.trim(),
      code: code?.trim().toUpperCase() || name.trim().substring(0, 3).toUpperCase(),
      description: description?.trim() || '',
      applicableTo: validApplicable,
      maxDays: typeof maxDays === 'number' && maxDays > 0 ? maxDays : undefined,
      requiresAttachment: Boolean(requiresAttachment),
      requiresApproval: requiresApproval !== undefined ? Boolean(requiresApproval) : true,
      isActive: isActive !== undefined ? Boolean(isActive) : true,
      createdAt: now,
      updatedAt: now
    };

    database.leaveTypes.push(newType);

    logAudit({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action: 'CREATE',
      entity: 'LEAVE_TYPE',
      entityType: 'LEAVE_TYPE',
      entityId: newType.id,
      details: `Created leave type: ${newType.name} (${newType.code}), Applicable: ${newType.applicableTo}`,
      ipAddress: req.ip
    });

    res.status(201).json({
      success: true,
      message: `Leave type '${newType.name}' created successfully.`,
      data: newType
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// PUT /api/attendance/leave-types/:id (Super Admin Only)
attendanceRouter.put('/leave-types/:id', requireAuth, requireRole('SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    const { id } = req.params;
    const updates = req.body as Partial<LeaveType>;

    if (!database.leaveTypes) database.leaveTypes = [];
    const index = database.leaveTypes.findIndex((t) => t.id === id);

    if (index === -1) {
      res.status(404).json({ success: false, error: 'Leave type not found.' });
      return;
    }

    const current = database.leaveTypes[index];
    const now = new Date().toISOString();

    const updated: LeaveType = {
      ...current,
      name: updates.name?.trim() || current.name,
      code: updates.code?.trim().toUpperCase() || current.code,
      description: updates.description !== undefined ? updates.description.trim() : current.description,
      applicableTo: updates.applicableTo || current.applicableTo,
      maxDays: updates.maxDays !== undefined ? updates.maxDays : current.maxDays,
      requiresAttachment: updates.requiresAttachment !== undefined ? Boolean(updates.requiresAttachment) : current.requiresAttachment,
      requiresApproval: updates.requiresApproval !== undefined ? Boolean(updates.requiresApproval) : current.requiresApproval,
      isActive: updates.isActive !== undefined ? Boolean(updates.isActive) : current.isActive,
      updatedAt: now
    };

    database.leaveTypes[index] = updated;

    logAudit({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action: 'UPDATE',
      entity: 'LEAVE_TYPE',
      entityType: 'LEAVE_TYPE',
      entityId: id,
      details: `Updated leave type '${updated.name}' (${updated.code})`,
      ipAddress: req.ip
    });

    res.json({
      success: true,
      message: `Leave type '${updated.name}' updated successfully.`,
      data: updated
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// DELETE /api/attendance/leave-types/:id (Super Admin Only)
attendanceRouter.delete('/leave-types/:id', requireAuth, requireRole('SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    const { id } = req.params;

    if (!database.leaveTypes) database.leaveTypes = [];
    const index = database.leaveTypes.findIndex((t) => t.id === id);

    if (index === -1) {
      res.status(404).json({ success: false, error: 'Leave type not found.' });
      return;
    }

    const type = database.leaveTypes[index];

    // Check if in use
    const inUse = (database.leaveApplications || []).some((l) => l.leaveTypeId === id);
    if (inUse) {
      // Soft deactivate instead
      type.isActive = false;
      type.updatedAt = new Date().toISOString();
      res.json({
        success: true,
        message: `Leave type '${type.name}' is referenced in existing applications and has been deactivated instead of deleted.`,
        data: type
      });
      return;
    }

    database.leaveTypes.splice(index, 1);

    logAudit({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action: 'DELETE',
      entity: 'LEAVE_TYPE',
      entityType: 'LEAVE_TYPE',
      entityId: id,
      details: `Deleted leave type '${type.name}'`,
      ipAddress: req.ip
    });

    res.json({
      success: true,
      message: `Leave type '${type.name}' removed successfully.`
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// =========================================================================
// 8. LEAVE WORKING DAYS CALCULATION & ATTACHMENT UPLOAD
// =========================================================================

// POST /api/attendance/calculate-leave-days
attendanceRouter.post('/calculate-leave-days', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { startDate, endDate, sessionId } = req.body as {
      startDate: string;
      endDate: string;
      sessionId?: string;
    };

    if (!startDate || !endDate) {
      res.status(400).json({ success: false, error: 'startDate and endDate are required in YYYY-MM-DD format.' });
      return;
    }

    if (startDate > endDate) {
      res.status(400).json({ success: false, error: 'startDate cannot be after endDate.' });
      return;
    }

    const result = calculateLeaveWorkingDates(startDate, endDate, sessionId);
    res.json({ success: true, data: result });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/attendance/leave/upload-attachment
attendanceRouter.post('/leave/upload-attachment', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { fileName, fileSizeBytes, fileData } = req.body as {
      fileName: string;
      fileSizeBytes: number;
      fileData?: string;
    };

    if (!fileName || !fileName.trim()) {
      res.status(400).json({ success: false, error: 'File name is required.' });
      return;
    }

    const ext = fileName.split('.').pop()?.toLowerCase() || '';
    const allowed = ['pdf', 'png', 'jpg', 'jpeg', 'webp', 'doc', 'docx'];
    if (!allowed.includes(ext)) {
      res.status(400).json({
        success: false,
        error: `Unsupported file format .${ext}. Allowed formats: ${allowed.join(', ')}`
      });
      return;
    }

    const size = Number(fileSizeBytes) || 0;
    const maxSizeBytes = 10 * 1024 * 1024; // 10MB
    if (size > maxSizeBytes) {
      res.status(400).json({
        success: false,
        error: `Attachment exceeds maximum allowed size of 10MB.`
      });
      return;
    }

    const sanitizedName = fileName.replace(/[^a-zA-Z0-9._-]/g, '_');
    const safeUrl = fileData && fileData.startsWith('data:')
      ? fileData
      : `https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?auto=format&fit=crop&q=80&w=800`;

    res.json({
      success: true,
      data: {
        fileUrl: safeUrl,
        fileName: sanitizedName,
        fileSize: size > 0 ? `${(size / 1024).toFixed(1)} KB` : '512 KB',
        fileSizeBytes: size > 0 ? size : 512 * 1024,
        fileType: ext
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// =========================================================================
// 9. TEACHER LEAVE APPLICATIONS (Part 8D - Teacher Portal)
// =========================================================================

// GET /api/attendance/teacher/leave
attendanceRouter.get('/teacher/leave', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    const teacherProfile = database.teacherProfiles.find((t) => t.userId === user.id);

    if (!teacherProfile && user.role !== 'SUPER_ADMIN') {
      res.status(404).json({ success: false, error: 'Teacher profile not found.' });
      return;
    }

    const { status } = req.query as { status?: string };
    if (!database.leaveApplications) database.leaveApplications = [];

    const targetId = teacherProfile ? teacherProfile.id : user.id;

    let applications = database.leaveApplications.filter(
      (l) => l.applicantType === 'TEACHER' && (l.applicantId === targetId || l.teacherProfileId === targetId || l.userId === user.id)
    );

    if (status && status !== 'ALL') {
      applications = applications.filter((l) => l.status === status.toUpperCase());
    }

    applications.sort((a, b) => b.createdAt.localeCompare(a.createdAt));

    res.json({
      success: true,
      data: applications,
      total: applications.length
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/attendance/teacher/leave (Teacher Apply / Draft Leave)
attendanceRouter.post('/teacher/leave', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    const teacherProfile = database.teacherProfiles.find((t) => t.userId === user.id);

    if (!teacherProfile) {
      res.status(403).json({ success: false, error: 'Teacher profile required to apply for teacher leave.' });
      return;
    }

    const {
      leaveTypeId,
      startDate,
      endDate,
      reason,
      description,
      remarks,
      attachmentUrl,
      attachmentName,
      attachmentSize,
      attachmentType,
      status: submissionMode
    } = req.body as {
      leaveTypeId: string;
      startDate: string;
      endDate?: string;
      reason: string;
      description?: string;
      remarks?: string;
      attachmentUrl?: string;
      attachmentName?: string;
      attachmentSize?: number;
      attachmentType?: string;
      status?: 'DRAFT' | 'SUBMITTED';
    };

    const start = startDate?.trim();
    const end = (endDate || startDate)?.trim();

    if (!start || !/^\d{4}-\d{2}-\d{2}$/.test(start)) {
      res.status(400).json({ success: false, error: 'Valid startDate (YYYY-MM-DD) is required.' });
      return;
    }

    if (!end || !/^\d{4}-\d{2}-\d{2}$/.test(end)) {
      res.status(400).json({ success: false, error: 'Valid endDate (YYYY-MM-DD) is required.' });
      return;
    }

    if (start > end) {
      res.status(400).json({ success: false, error: 'startDate cannot be after endDate.' });
      return;
    }

    if (!reason || !reason.trim()) {
      res.status(400).json({ success: false, error: 'Reason for leave is mandatory.' });
      return;
    }

    // Leave type validation
    const leaveType = (database.leaveTypes || []).find((lt) => lt.id === leaveTypeId);
    if (!leaveType) {
      res.status(400).json({ success: false, error: 'Invalid or unconfigured leave type selected.' });
      return;
    }

    if (leaveType.applicableTo === 'STUDENT') {
      res.status(400).json({ success: false, error: `Leave type '${leaveType.name}' is only applicable to students.` });
      return;
    }

    const isDraft = submissionMode === 'DRAFT';

    // Mandatory attachment check if submitted
    if (!isDraft && leaveType.requiresAttachment && (!attachmentUrl || !attachmentUrl.trim())) {
      res.status(400).json({
        success: false,
        error: `An official documentation attachment is required for ${leaveType.name}.`,
        code: 'ATTACHMENT_REQUIRED'
      });
      return;
    }

    // Active session
    const activeSession = database.academicSessions.find((s) => s.isActive) || database.academicSessions[0];

    // Working days calculation
    const calc = calculateLeaveWorkingDates(start, end, activeSession?.id);
    if (calc.totalWorkingLeaveDays === 0 && !isDraft) {
      res.status(400).json({
        success: false,
        error: 'The selected date range contains only scheduled non-working days or weekends. No working leave days required.',
        code: 'NO_WORKING_DAYS'
      });
      return;
    }

    // Overlapping leave detection (prevent duplicate/overlapping submitted or approved leaves)
    if (!isDraft) {
      const overlap = detectOverlappingLeave(teacherProfile.id, start, end, undefined, false);
      if (overlap) {
        res.status(409).json({
          success: false,
          error: `An overlapping leave application (${overlap.startDate} to ${overlap.endDate}) already exists with status: ${overlap.status}. Duplicate or conflicting leave is not permitted.`,
          code: 'OVERLAPPING_LEAVE',
          overlappingApplication: overlap
        });
        return;
      }
    }

    if (!database.leaveApplications) database.leaveApplications = [];

    const now = new Date().toISOString();
    const newApp: LeaveApplication = {
      id: `leave-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      applicantType: 'TEACHER',
      applicantId: teacherProfile.id,
      userId: user.id,
      applicantName: `${teacherProfile.firstName || ''} ${teacherProfile.lastName || ''}`.trim() || user.name,
      teacherProfileId: teacherProfile.id,
      teacherName: `${teacherProfile.firstName || ''} ${teacherProfile.lastName || ''}`.trim() || user.name,
      employeeCode: teacherProfile.employeeCode,
      departmentId: teacherProfile.departmentId,
      departmentName: teacherProfile.departmentName,
      academicSessionId: activeSession?.id || 'session-2026-2027',
      academicSessionName: activeSession?.sessionName || 'Academic Session',
      leaveTypeId: leaveType.id,
      leaveTypeName: leaveType.name,
      startDate: start,
      endDate: end,
      leaveDate: start,
      totalDays: calc.totalWorkingLeaveDays > 0 ? calc.totalWorkingLeaveDays : calc.totalCalendarDays,
      reason: reason.trim(),
      description: description?.trim() || reason.trim(),
      remarks: remarks?.trim(),
      attachmentUrl: attachmentUrl?.trim(),
      attachmentName: attachmentName?.trim() || (attachmentUrl ? 'Leave_Attachment.pdf' : undefined),
      attachmentSize,
      attachmentType,
      status: isDraft ? 'DRAFT' : 'SUBMITTED',
      submissionDate: isDraft ? undefined : now.split('T')[0],
      submittedAt: isDraft ? undefined : now,
      createdAt: now,
      updatedAt: now
    };

    database.leaveApplications.push(newApp);

    logAudit({
      userId: user.id,
      userName: newApp.applicantName,
      userRole: user.role,
      action: 'CREATE',
      entity: 'LEAVE_APPLICATION',
      entityType: 'LEAVE_APPLICATION',
      entityId: newApp.id,
      details: `${isDraft ? 'Saved draft' : 'Submitted'} teacher leave application for ${start} to ${end} (${newApp.totalDays} days). Reason: ${reason}.`,
      ipAddress: req.ip
    });

    if (!isDraft) {
      // Centralized Attendance Notification & Alert System (Part 8F)
      AttendanceNotificationService.dispatchEvent({
        eventType: 'LEAVE_SUBMITTED',
        date: start,
        teacherId: teacherProfile.id,
        leaveApplicationId: newApp.id,
        leaveType: leaveType.name,
        leaveStartDate: start,
        leaveEndDate: end,
        reason: reason.trim(),
        actorUser: { id: user.id, name: newApp.applicantName, role: user.role }
      });

      if (!database.notifications) database.notifications = [];
      database.notifications.push({
        id: `notif-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        roleTarget: 'SUPER_ADMIN',
        title: 'New Teacher Leave Application',
        message: `${newApp.applicantName} (${teacherProfile.departmentName || 'Faculty'}) submitted a leave application for ${start} to ${end}. Reason: ${reason}.`,
        category: 'academic',
        isRead: false,
        createdAt: now
      });
    }

    res.status(201).json({
      success: true,
      message: isDraft
        ? 'Leave application draft saved successfully.'
        : `Leave application for ${start} to ${end} submitted successfully and forwarded for review.`,
      data: newApp
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// DELETE /api/attendance/teacher/leave/:id (Teacher Cancel Own Leave)
attendanceRouter.delete('/teacher/leave/:id', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    const { id } = req.params;

    if (!database.leaveApplications) database.leaveApplications = [];
    const index = database.leaveApplications.findIndex((l) => l.id === id);

    if (index === -1) {
      res.status(404).json({ success: false, error: 'Leave application not found.' });
      return;
    }

    const application = database.leaveApplications[index];

    // Ownership check
    const isOwner = application.userId === user.id || (user.role === 'SUPER_ADMIN');
    if (!isOwner) {
      res.status(403).json({ success: false, error: 'Access denied. You cannot cancel leave applications belonging to other teachers.' });
      return;
    }

    if (!['DRAFT', 'SUBMITTED', 'PENDING'].includes(application.status)) {
      res.status(400).json({
        success: false,
        error: `Cannot directly delete a leave application that has already been ${application.status.toLowerCase()}. Please use administrative cancellation workflow.`
      });
      return;
    }

    database.leaveApplications.splice(index, 1);

    logAudit({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action: 'DELETE',
      entity: 'LEAVE_APPLICATION',
      entityType: 'LEAVE_APPLICATION',
      entityId: id,
      details: `Cancelled pending teacher leave application for ${application.startDate} to ${application.endDate}.`,
      ipAddress: req.ip
    });

    res.json({
      success: true,
      message: 'Pending teacher leave application has been cancelled.'
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// =========================================================================
// 10. UNIFIED LEAVE DIRECTORY & REVIEW (Part 8D - Students & Teachers)
// =========================================================================

// GET /api/attendance/leave-applications (Admin & Teacher Unified Directory)
attendanceRouter.get('/leave-applications', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const {
      applicantType,
      leaveTypeId,
      classId,
      sectionId,
      departmentId,
      status,
      date,
      startDate,
      endDate,
      academicSessionId,
      search,
      page = 1,
      limit = 50
    } = req.query as Record<string, any>;

    const { isAdmin, teacherProfile, assignedClassIds } = getTeacherContext(req);
    const user = req.user!;

    if (!database.leaveApplications) database.leaveApplications = [];

    let applications = database.leaveApplications.filter((app) => {
      // 1. Role Scope Authorization (RBAC + IDOR):
      if (!isAdmin) {
        if (app.applicantType === 'TEACHER') {
          // A teacher can only view their own leave application
          if (app.userId !== user.id && app.applicantId !== teacherProfile?.id) {
            return false;
          }
        } else if (app.applicantType === 'STAFF') {
          // A staff member can only view their own leave application
          const staffProfile = (database.staffProfiles || []).find((s) => s.userId === user.id);
          if (app.userId !== user.id && app.applicantId !== staffProfile?.id && app.staffId !== staffProfile?.id) {
            return false;
          }
        } else {
          if (user.role === 'TEACHER') {
            // For students: teacher can only see applications from their assigned classes
            if (!assignedClassIds.includes(app.classId || '')) {
              return false;
            }
          } else if (user.role === 'STUDENT') {
            const studentProfile = database.studentProfiles.find((s) => s.userId === user.id);
            if (app.userId !== user.id && app.applicantId !== studentProfile?.id && app.studentId !== studentProfile?.id) {
              return false;
            }
          } else if (user.role === 'GUARDIAN') {
            const guardian = (database.guardians || []).find((g) => g.userId === user.id);
            const targetStudentId = app.studentId || app.applicantId;
            if (!guardian || !guardian.studentIds.includes(targetStudentId || '')) {
              return false;
            }
          } else {
            return false;
          }
        }
      }

      // 2. Applicant Type filter
      if (applicantType && applicantType !== 'ALL') {
        const targetType = applicantType.toUpperCase();
        const currentType = app.applicantType || 'STUDENT';
        if (currentType !== targetType) return false;
      }

      // 3. Leave Type filter
      if (leaveTypeId && leaveTypeId !== 'ALL' && app.leaveTypeId !== leaveTypeId) {
        return false;
      }

      // 4. Academic Session filter
      if (academicSessionId && academicSessionId !== 'ALL' && app.academicSessionId !== academicSessionId) {
        return false;
      }

      // 5. Class & Section filters (for students)
      if (classId && classId !== 'ALL' && app.classId !== classId) return false;
      if (sectionId && sectionId !== 'ALL' && app.sectionId !== sectionId) return false;

      // 6. Department filter (for teachers)
      if (departmentId && departmentId !== 'ALL' && app.departmentId !== departmentId) return false;

      // 7. Status filter
      if (status && status !== 'ALL') {
        const targetStatus = status.toUpperCase();
        if (targetStatus === 'PENDING') {
          if (app.status !== 'PENDING' && app.status !== 'SUBMITTED') return false;
        } else {
          if (app.status !== targetStatus) return false;
        }
      }

      // 8. Single Date match
      const appStart = app.startDate || app.leaveDate;
      const appEnd = app.endDate || app.startDate || app.leaveDate;
      if (date && (date < appStart || date > appEnd)) {
        return false;
      }

      // 9. Date Range match
      if (startDate && appEnd < startDate) return false;
      if (endDate && appStart > endDate) return false;

      // 10. Search query match
      if (search && search.trim()) {
        const q = search.toLowerCase().trim();
        const matchName = (app.applicantName || app.studentName || app.teacherName || '').toLowerCase().includes(q);
        const matchAdm = (app.admissionNumber || app.employeeCode || '').toLowerCase().includes(q);
        const matchReason = (app.reason || '').toLowerCase().includes(q);
        const matchDesc = (app.description || '').toLowerCase().includes(q);
        const matchType = (app.leaveTypeName || '').toLowerCase().includes(q);
        if (!matchName && !matchAdm && !matchReason && !matchDesc && !matchType) return false;
      }

      return true;
    });

    applications.sort((a, b) => b.createdAt.localeCompare(a.createdAt));

    // Summary counts before pagination
    const totalCount = applications.length;
    const pendingCount = applications.filter((a) => a.status === 'PENDING' || a.status === 'SUBMITTED').length;
    const underReviewCount = applications.filter((a) => a.status === 'UNDER_REVIEW').length;
    const approvedCount = applications.filter((a) => a.status === 'APPROVED').length;
    const rejectedCount = applications.filter((a) => a.status === 'REJECTED').length;
    const cancelledCount = applications.filter((a) => a.status === 'CANCELLED').length;

    // Pagination
    const pageNum = Math.max(1, Number(page) || 1);
    const limitNum = Math.max(1, Number(limit) || 50);
    const totalPages = Math.ceil(totalCount / limitNum) || 1;
    const startIndex = (pageNum - 1) * limitNum;
    const paginatedItems = applications.slice(startIndex, startIndex + limitNum);

    res.json({
      success: true,
      data: paginatedItems,
      total: totalCount,
      page: pageNum,
      limit: limitNum,
      totalPages,
      summary: {
        totalCount,
        pendingCount,
        underReviewCount,
        approvedCount,
        rejectedCount,
        cancelledCount
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/attendance/leave-applications/:id (Application Details)
attendanceRouter.get('/leave-applications/:id', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    const { id } = req.params;

    if (!database.leaveApplications) database.leaveApplications = [];
    const application = database.leaveApplications.find((l) => l.id === id);

    if (!application) {
      res.status(404).json({ success: false, error: 'Leave application not found.' });
      return;
    }

    const { isAdmin, teacherProfile, assignedClassIds } = getTeacherContext(req);

    // Authorization (RBAC + IDOR)
    if (!isAdmin) {
      if (application.applicantType === 'TEACHER') {
        if (application.userId !== user.id && application.applicantId !== teacherProfile?.id) {
          res.status(403).json({ success: false, error: 'Access denied to this teacher leave application.' });
          return;
        }
      } else {
        if (user.role === 'STUDENT') {
          const studentProfile = database.studentProfiles.find((s) => s.userId === user.id);
          if (application.userId !== user.id && application.studentId !== studentProfile?.id && application.applicantId !== studentProfile?.id) {
            res.status(403).json({ success: false, error: 'Access denied. You cannot view leave applications of other students.' });
            return;
          }
        } else if (user.role === 'GUARDIAN') {
          const guardian = (database.guardians || []).find((g) => g.userId === user.id);
          const targetStudentId = application.studentId || application.applicantId;
          if (!guardian || !guardian.studentIds.includes(targetStudentId || '')) {
            res.status(403).json({ success: false, error: 'Access denied. You cannot view leave applications for scholars not linked to your family account.' });
            return;
          }
        } else if (user.role === 'TEACHER') {
          if (!assignedClassIds.includes(application.classId || '')) {
            res.status(403).json({ success: false, error: 'Access denied to student cohort.' });
            return;
          }
        } else {
          res.status(403).json({ success: false, error: 'Access denied.' });
          return;
        }
      }
    }

    const start = application.startDate || application.leaveDate;
    const end = application.endDate || application.startDate || application.leaveDate;
    const workingBreakdown = calculateLeaveWorkingDates(start, end, application.academicSessionId);

    res.json({
      success: true,
      data: {
        ...application,
        workingBreakdown
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// PUT /api/attendance/leave-applications/:id/review (Approve / Reject / Under Review with Attendance Integration)
attendanceRouter.put('/leave-applications/:id/review', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    const { id } = req.params;
    const { status, adminRemarks, rejectionReason } = req.body as {
      status: 'APPROVED' | 'REJECTED' | 'UNDER_REVIEW';
      adminRemarks?: string;
      rejectionReason?: string;
    };

    if (!status || !['APPROVED', 'REJECTED', 'UNDER_REVIEW'].includes(status)) {
      res.status(400).json({
        success: false,
        error: "Status must be either 'APPROVED', 'REJECTED', or 'UNDER_REVIEW'."
      });
      return;
    }

    if (!database.leaveApplications) database.leaveApplications = [];
    const index = database.leaveApplications.findIndex((l) => l.id === id);

    if (index === -1) {
      res.status(404).json({ success: false, error: 'Leave application not found.' });
      return;
    }

    const application = database.leaveApplications[index];
    const { isAdmin, teacherProfile, assignedClassIds } = getTeacherContext(req);

    // SECURITY & RBAC CHECK:
    // Only Super Admin can review Teacher leave applications!
    if (application.applicantType === 'TEACHER' && !isAdmin) {
      res.status(403).json({
        success: false,
        error: 'Access denied. Only Super Administrators are authorized to review teacher leave applications.',
        code: 'FORBIDDEN_TEACHER_LEAVE_REVIEW'
      });
      return;
    }

    // For Student leave applications: Teachers can only review students in their assigned cohort
    if (application.applicantType !== 'TEACHER' && !isAdmin && !assignedClassIds.includes(application.classId || '')) {
      res.status(403).json({
        success: false,
        error: 'Access denied. You are not authorized to review leave applications for students in this class cohort.',
        code: 'FORBIDDEN_LEAVE_REVIEW'
      });
      return;
    }

    // Reviewable status validation & Invalid State Transition Protection (Part 8G Audit)
    if (['CANCELLED'].includes(application.status)) {
      res.status(400).json({
        success: false,
        error: `Cannot review an application that has already been cancelled.`,
        code: 'CANNOT_REVIEW_CANCELLED'
      });
      return;
    }

    if (application.status === 'REJECTED' && status === 'APPROVED') {
      res.status(400).json({
        success: false,
        error: 'Invalid state transition: Cannot directly approve a previously rejected leave application.',
        code: 'INVALID_STATUS_TRANSITION'
      });
      return;
    }

    if (application.status === 'APPROVED' && status === 'REJECTED') {
      res.status(400).json({
        success: false,
        error: 'Invalid state transition: Cannot reject an already approved leave application. The application must first be cancelled to safely reconcile and restore previous attendance records.',
        code: 'INVALID_STATUS_TRANSITION'
      });
      return;
    }

    if (application.status === status) {
      res.status(400).json({
        success: false,
        error: `Leave application is already marked as ${status}.`,
        code: 'ALREADY_IN_STATUS'
      });
      return;
    }

    // REJECTION VALIDATION: Rejection reason is mandatory
    if (status === 'REJECTED' && (!rejectionReason || !rejectionReason.trim())) {
      res.status(400).json({
        success: false,
        error: 'A specific rejection reason is mandatory when rejecting a leave application.',
        code: 'REJECTION_REASON_REQUIRED'
      });
      return;
    }

    const start = application.startDate || application.leaveDate;
    const end = application.endDate || application.startDate || application.leaveDate;
    const reviewerName = user.name || (teacherProfile ? `${teacherProfile.firstName || ''} ${teacherProfile.lastName || ''}`.trim() : 'Academic Administration');
    const reviewerRole = user.role;
    const now = new Date().toISOString();

    // APPROVAL VALIDATIONS:
    if (status === 'APPROVED') {
      // 1. Overlapping approved leave validation:
      const targetApplicantId = application.applicantId || application.studentId || application.teacherProfileId || application.userId;
      const overlapApproved = detectOverlappingLeave(targetApplicantId, start, end, application.id, true);
      if (overlapApproved) {
        res.status(409).json({
          success: false,
          error: `Cannot approve: An overlapping approved leave (${overlapApproved.startDate} to ${overlapApproved.endDate}) already exists for this applicant.`,
          code: 'OVERLAPPING_APPROVED_LEAVE',
          conflictingLeave: overlapApproved
        });
        return;
      }

      // 2. Attachment check if required:
      const leaveType = (database.leaveTypes || []).find((lt) => lt.id === application.leaveTypeId);
      if (leaveType?.requiresAttachment && (!application.attachmentUrl || !application.attachmentUrl.trim())) {
        res.status(400).json({
          success: false,
          error: `Cannot approve: Documentation attachment is required for ${leaveType.name}.`,
          code: 'MISSING_REQUIRED_ATTACHMENT'
        });
        return;
      }
    }

    // Track previous attendance states for rollback on cancellation
    const previousAttendanceStates: Record<
      string,
      {
        recordId?: string;
        previousStatus: string;
        wasAutoCreated: boolean;
      }
    > = application.previousAttendanceStates ? { ...application.previousAttendanceStates } : {};

    const appliedAttendanceDates: string[] = [];

    // =========================================================================
    // CRITICAL ATTENDANCE INTEGRATION:
    // When APPROVED, convert applicable working days to 'LEAVE'
    // Do NOT create Leave attendance for: Weekend, Holiday, Non-working days!
    // If previously Absent, change to Leave!
    // =========================================================================
    if (status === 'APPROVED') {
      const workingBreakdown = calculateLeaveWorkingDates(start, end, application.academicSessionId);
      const isTeacher = application.applicantType === 'TEACHER';
      const isStaff = application.applicantType === 'STAFF';

      const activeSession = database.academicSessions.find((s) => s.id === application.academicSessionId) ||
        database.academicSessions.find((s) => s.isActive) ||
        database.academicSessions[0];

      for (const workingDate of workingBreakdown.workingDates) {
        appliedAttendanceDates.push(workingDate);

        if (isStaff) {
          // Staff attendance integration (Part 12B)
          if (!database.staffAttendanceRecords) database.staffAttendanceRecords = [];
          const staffId = application.staffId || application.applicantId;
          const staff = (database.staffProfiles || []).find((s) => s.id === staffId || s.userId === application.userId);

          const existingIndex = database.staffAttendanceRecords.findIndex(
            (r) => (r.staffId === staffId || (staff && r.staffId === staff.id)) && r.date === workingDate && !r.isDeleted
          );

          if (existingIndex !== -1) {
            const prev = database.staffAttendanceRecords[existingIndex];
            previousAttendanceStates[workingDate] = {
              recordId: prev.id,
              previousStatus: prev.status,
              wasAutoCreated: false
            };

            const historyItem = {
              id: `s-hist-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
              fromStatus: prev.status,
              toStatus: 'LEAVE' as any,
              reason: `Approved Leave Application: ${application.leaveTypeName || application.reason}`,
              correctedByUserId: user.id,
              correctedByUserName: reviewerName,
              correctedAt: now
            };

            database.staffAttendanceRecords[existingIndex] = {
              ...prev,
              status: 'LEAVE',
              remarks: `Approved Leave (${application.leaveTypeName || application.reason})${adminRemarks ? ' - ' + adminRemarks : ''}`,
              updatedBy: user.id,
              updatedByName: reviewerName,
              updatedAt: now,
              history: [...(prev.history || []), historyItem]
            };

            logAudit({
              userId: user.id,
              userName: reviewerName,
              userRole: reviewerRole,
              action: 'UPDATE',
              entity: 'STAFF_ATTENDANCE_RECORD',
              entityType: 'STAFF_ATTENDANCE_RECORD',
              entityId: prev.id,
              details: `Auto-updated staff attendance for ${application.applicantName} on ${workingDate} from ${prev.status} to LEAVE.`,
              ipAddress: req.ip
            });
          } else {
            const newRecordId = `s-att-leave-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
            previousAttendanceStates[workingDate] = {
              recordId: newRecordId,
              previousStatus: 'UNMARKED',
              wasAutoCreated: true
            };

            const newStaffRecord = {
              id: newRecordId,
              staffId: staff?.id || staffId,
              teacherProfileId: staff?.teacherProfileId,
              userId: application.userId || staff?.userId || user.id,
              staffName: application.staffName || application.applicantName,
              employeeCode: application.employeeCode || staff?.employeeCode || '',
              staffType: (application.staffType as any) || staff?.staffType || 'support',
              departmentId: application.departmentId || staff?.departmentId,
              departmentName: application.departmentName || staff?.departmentName,
              designationId: staff?.designationId,
              designation: application.designation || staff?.designation,
              avatarUrl: staff?.avatarUrl,
              academicSessionId: application.academicSessionId || activeSession?.id || 'session-2026-2027',
              academicSessionName: activeSession?.name || 'Academic Session 2026-2027',
              date: workingDate,
              status: 'LEAVE' as any,
              remarks: `Approved Leave (${application.leaveTypeName || application.reason})${adminRemarks ? ' - ' + adminRemarks : ''}`,
              createdBy: user.id,
              createdByName: reviewerName,
              updatedBy: user.id,
              updatedByName: reviewerName,
              createdAt: now,
              updatedAt: now,
              history: []
            };

            database.staffAttendanceRecords.push(newStaffRecord);

            logAudit({
              userId: user.id,
              userName: reviewerName,
              userRole: reviewerRole,
              action: 'CREATE',
              entity: 'STAFF_ATTENDANCE_RECORD',
              entityType: 'STAFF_ATTENDANCE_RECORD',
              entityId: newRecordId,
              details: `Auto-created staff attendance record as LEAVE for ${application.applicantName} on ${workingDate}.`,
              ipAddress: req.ip
            });
          }

          // If linked to a teacher, also update teacher attendance records
          if (staff?.teacherProfileId) {
            if (!database.teacherAttendanceRecords) database.teacherAttendanceRecords = [];
            const tIdx = database.teacherAttendanceRecords.findIndex(
              (r) => r.teacherProfileId === staff.teacherProfileId && r.date === workingDate
            );
            if (tIdx !== -1) {
              database.teacherAttendanceRecords[tIdx].status = 'LEAVE';
              database.teacherAttendanceRecords[tIdx].updatedAt = now;
            }
          }
        } else if (isTeacher) {
          // Teacher attendance integration
          if (!database.teacherAttendanceRecords) database.teacherAttendanceRecords = [];
          const teacherId = application.teacherProfileId || application.applicantId;

          const existingIndex = database.teacherAttendanceRecords.findIndex(
            (r) => r.teacherProfileId === teacherId && r.date === workingDate
          );

          if (existingIndex !== -1) {
            const prev = database.teacherAttendanceRecords[existingIndex];
            previousAttendanceStates[workingDate] = {
              recordId: prev.id,
              previousStatus: prev.status,
              wasAutoCreated: false
            };

            const historyItem: TeacherAttendanceCorrectionHistoryItem = {
              id: `t-hist-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
              fromStatus: prev.status,
              toStatus: 'LEAVE',
              reason: `Approved Leave Application: ${application.leaveTypeName || application.reason}`,
              correctedByUserId: user.id,
              correctedByUserName: reviewerName,
              correctedAt: now
            };

            database.teacherAttendanceRecords[existingIndex] = {
              ...prev,
              status: 'LEAVE',
              remarks: `Approved Leave (${application.leaveTypeName || application.reason})${adminRemarks ? ' - ' + adminRemarks : ''}`,
              updatedBy: user.id,
              updatedByName: reviewerName,
              updatedAt: now,
              history: [...(prev.history || []), historyItem]
            };

            logAudit({
              userId: user.id,
              userName: reviewerName,
              userRole: reviewerRole,
              action: 'UPDATE',
              entity: 'TEACHER_ATTENDANCE_RECORD',
              entityType: 'TEACHER_ATTENDANCE_RECORD',
              entityId: prev.id,
              details: `Auto-updated teacher attendance for ${application.applicantName} on ${workingDate} from ${prev.status} to LEAVE.`,
              ipAddress: req.ip
            });
          } else {
            // Auto-create teacher attendance record with status LEAVE
            const newRecordId = `t-att-leave-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
            previousAttendanceStates[workingDate] = {
              recordId: newRecordId,
              previousStatus: 'UNMARKED',
              wasAutoCreated: true
            };

            const teacherUser = database.teacherProfiles.find((t) => t.id === teacherId);
            const newTeacherRecord: TeacherAttendanceRecord = {
              id: newRecordId,
              teacherProfileId: teacherId,
              userId: application.userId || teacherUser?.userId || user.id,
              teacherName: application.teacherName || application.applicantName,
              employeeCode: application.employeeCode || '',
              departmentId: application.departmentId || '',
              departmentName: application.departmentName || '',
              academicSessionId: application.academicSessionId || activeSession?.id || 'session-2026-2027',
              date: workingDate,
              status: 'LEAVE',
              remarks: `Approved Leave (${application.leaveTypeName || application.reason})${adminRemarks ? ' - ' + adminRemarks : ''}`,
              createdBy: user.id,
              createdByName: reviewerName,
              updatedBy: user.id,
              updatedByName: reviewerName,
              createdAt: now,
              updatedAt: now,
              history: []
            };

            database.teacherAttendanceRecords.push(newTeacherRecord);

            logAudit({
              userId: user.id,
              userName: reviewerName,
              userRole: reviewerRole,
              action: 'CREATE',
              entity: 'TEACHER_ATTENDANCE_RECORD',
              entityType: 'TEACHER_ATTENDANCE_RECORD',
              entityId: newRecordId,
              details: `Auto-created teacher attendance record as LEAVE for ${application.applicantName} on ${workingDate}.`,
              ipAddress: req.ip
            });
          }
        } else {
          // Student attendance integration
          if (!database.attendanceRecords) database.attendanceRecords = [];
          const studentId = application.studentId || application.applicantId;

          const existingIndex = database.attendanceRecords.findIndex(
            (r) => (r.studentId === studentId || r.userId === application.userId) && r.date === workingDate
          );

          const cls = database.classes.find((c) => c.id === application.classId);
          const sec = database.sections.find((s) => s.id === application.sectionId);

          if (existingIndex !== -1) {
            const prev = database.attendanceRecords[existingIndex];
            previousAttendanceStates[workingDate] = {
              recordId: prev.id,
              previousStatus: prev.status,
              wasAutoCreated: false
            };

            const historyItem = {
              previousStatus: prev.status,
              newStatus: 'LEAVE' as AttendanceStatus,
              changedByUserId: user.id,
              changedByUserName: reviewerName,
              changedAt: now,
              reason: `Approved Leave Application: ${application.leaveTypeName || application.reason}`
            };

            database.attendanceRecords[existingIndex] = {
              ...prev,
              status: 'LEAVE',
              remarks: `Approved Leave (${application.leaveTypeName || application.reason})${adminRemarks ? ' - ' + adminRemarks : ''}`,
              updatedByTeacherId: teacherProfile?.id || user.id,
              updatedByTeacherName: reviewerName,
              updatedAt: now,
              correctionHistory: [...(prev.correctionHistory || []), historyItem]
            };

            logAudit({
              userId: user.id,
              userName: reviewerName,
              userRole: reviewerRole,
              action: 'UPDATE',
              entity: 'ATTENDANCE_RECORD',
              entityType: 'ATTENDANCE_RECORD',
              entityId: prev.id,
              details: `Auto-updated student attendance for ${application.applicantName} on ${workingDate} from ${prev.status} to LEAVE.`,
              ipAddress: req.ip
            });
          } else {
            // Auto-create student attendance record as LEAVE
            const newRecordId = `att-leave-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
            previousAttendanceStates[workingDate] = {
              recordId: newRecordId,
              previousStatus: 'UNMARKED',
              wasAutoCreated: true
            };

            const newStudentRecord: AttendanceRecord = {
              id: newRecordId,
              studentId,
              userId: application.userId,
              studentName: application.studentName || application.applicantName,
              admissionNumber: application.admissionNumber,
              rollNumber: application.rollNumber,
              classId: application.classId || 'class-g10',
              className: cls?.name || application.className || 'Class',
              sectionId: application.sectionId || 'sec-g10-a',
              sectionName: sec?.name || application.sectionName || 'Section',
              academicSessionId: application.academicSessionId || activeSession?.id || 'session-2026-2027',
              academicSessionName: activeSession?.sessionName || 'Academic Session',
              date: workingDate,
              status: 'LEAVE',
              remarks: `Approved Leave (${application.leaveTypeName || application.reason})${adminRemarks ? ' - ' + adminRemarks : ''}`,
              recordedByTeacherId: teacherProfile?.id || user.id,
              recordedByTeacherName: reviewerName,
              createdAt: now,
              updatedAt: now,
              correctionHistory: []
            };

            database.attendanceRecords.push(newStudentRecord);

            logAudit({
              userId: user.id,
              userName: reviewerName,
              userRole: reviewerRole,
              action: 'CREATE',
              entity: 'ATTENDANCE_RECORD',
              entityType: 'ATTENDANCE_RECORD',
              entityId: newRecordId,
              details: `Auto-created student attendance record as LEAVE for ${application.applicantName} on ${workingDate}.`,
              ipAddress: req.ip
            });
          }
        }
      }
    }

    // UPDATE APPLICATION RECORD
    database.leaveApplications[index] = {
      ...application,
      status,
      adminRemarks: adminRemarks?.trim() || (status === 'APPROVED' ? 'Approved by Academic Administration' : undefined),
      rejectionReason: status === 'REJECTED' ? rejectionReason?.trim() : undefined,
      reviewedByUserId: user.id,
      reviewedByName: reviewerName,
      reviewedByRole: reviewerRole,
      reviewedAt: now,
      appliedAttendanceDates: status === 'APPROVED' ? appliedAttendanceDates : application.appliedAttendanceDates,
      previousAttendanceStates: status === 'APPROVED' ? previousAttendanceStates : application.previousAttendanceStates,
      updatedAt: now
    };

    const updatedApp = database.leaveApplications[index];

    // AUDIT LOG FOR LEAVE APPLICATION REVIEW
    logAudit({
      userId: user.id,
      userName: reviewerName,
      userRole: reviewerRole,
      action: 'UPDATE',
      entity: 'LEAVE_APPLICATION',
      entityType: 'LEAVE_APPLICATION',
      entityId: id,
      details: `${status} leave application for ${application.applicantName} (${start} to ${end}).${status === 'REJECTED' ? ' Reason: ' + rejectionReason : ''}`,
      ipAddress: req.ip,
      metadata: {
        status,
        adminRemarks: adminRemarks || '',
        rejectionReason: rejectionReason || '',
        appliedDates: appliedAttendanceDates
      }
    });

    // IN-APP NOTIFICATION TO APPLICANT
    if (!database.notifications) database.notifications = [];
    database.notifications.push({
      id: `notif-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      userId: application.userId,
      roleTarget: application.applicantType === 'TEACHER' ? 'TEACHER' : 'STUDENT',
      title: `Leave Application ${status === 'APPROVED' ? 'Approved' : status === 'REJECTED' ? 'Rejected' : 'Under Review'}`,
      message: status === 'APPROVED'
        ? `Your leave application for ${start} to ${end} has been approved.${adminRemarks ? ' Remarks: ' + adminRemarks : ''}`
        : status === 'REJECTED'
        ? `Your leave application for ${start} to ${end} has been rejected. Reason: ${rejectionReason}`
        : `Your leave application for ${start} to ${end} is currently under administrative evaluation.`,
      category: 'academic',
      isRead: false,
      createdAt: now
    });

    // Centralized Attendance Notification & Alert System (Part 8F)
    if (status === 'APPROVED') {
      AttendanceNotificationService.dispatchEvent({
        eventType: 'LEAVE_APPROVED',
        date: start,
        studentId: application.applicantType === 'STUDENT' ? (application.studentId || application.applicantId) : undefined,
        teacherId: application.applicantType === 'TEACHER' ? (application.teacherProfileId || application.applicantId) : undefined,
        leaveApplicationId: application.id,
        leaveType: application.leaveTypeName,
        leaveStartDate: start,
        leaveEndDate: end,
        remarks: adminRemarks,
        actorUser: { id: user.id, name: reviewerName, role: reviewerRole }
      });
    } else if (status === 'REJECTED') {
      AttendanceNotificationService.dispatchEvent({
        eventType: 'LEAVE_REJECTED',
        date: start,
        studentId: application.applicantType === 'STUDENT' ? (application.studentId || application.applicantId) : undefined,
        teacherId: application.applicantType === 'TEACHER' ? (application.teacherProfileId || application.applicantId) : undefined,
        leaveApplicationId: application.id,
        leaveType: application.leaveTypeName,
        leaveStartDate: start,
        leaveEndDate: end,
        reason: rejectionReason,
        remarks: adminRemarks,
        actorUser: { id: user.id, name: reviewerName, role: reviewerRole }
      });
    }

    res.json({
      success: true,
      message: `Leave application has been marked as ${status.replace('_', ' ').toLowerCase()}.`,
      data: updatedApp
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/attendance/leave-applications/:id/cancel (Cancel Leave & Revert Attendance)
attendanceRouter.post('/leave-applications/:id/cancel', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    const { id } = req.params;
    const { cancellationReason } = req.body as { cancellationReason?: string };

    if (!database.leaveApplications) database.leaveApplications = [];
    const index = database.leaveApplications.findIndex((l) => l.id === id);

    if (index === -1) {
      res.status(404).json({ success: false, error: 'Leave application not found.' });
      return;
    }

    const application = database.leaveApplications[index];
    const { isAdmin, teacherProfile } = getTeacherContext(req);

    // Authorization: Super admin or owner can cancel
    const isOwner = application.userId === user.id ||
      application.applicantId === user.id ||
      application.applicantId === teacherProfile?.id;

    if (!isAdmin && !isOwner) {
      res.status(403).json({ success: false, error: 'Access denied. You cannot cancel this leave application.' });
      return;
    }

    if (application.status === 'CANCELLED') {
      res.status(400).json({ success: false, error: 'This leave application is already cancelled.' });
      return;
    }

    const now = new Date().toISOString();

    // =========================================================================
    // SAFE ATTENDANCE RESTORATION (Part 8D - Requirement 15):
    // Restore previous attendance states for approved leave without destroying manual overrides
    // =========================================================================
    if (application.status === 'APPROVED' && application.appliedAttendanceDates && application.appliedAttendanceDates.length > 0) {
      const isTeacher = application.applicantType === 'TEACHER';
      const isStaff = application.applicantType === 'STAFF';
      const prevStates = application.previousAttendanceStates || {};

      for (const dateStr of application.appliedAttendanceDates) {
        const recordedState = prevStates[dateStr];

        if (isStaff) {
          if (!database.staffAttendanceRecords) database.staffAttendanceRecords = [];
          const recIndex = database.staffAttendanceRecords.findIndex(
            (r) =>
              (r.staffId === (application.staffId || application.applicantId) || r.userId === application.userId) &&
              r.date === dateStr &&
              !r.isDeleted
          );

          if (recIndex !== -1) {
            const currentRec = database.staffAttendanceRecords[recIndex];
            if (currentRec.status === 'LEAVE') {
              if (recordedState?.wasAutoCreated) {
                database.staffAttendanceRecords.splice(recIndex, 1);
              } else if (recordedState?.previousStatus && recordedState.previousStatus !== 'UNMARKED') {
                currentRec.status = recordedState.previousStatus as any;
                currentRec.remarks = 'Restored previous status after leave cancellation';
                currentRec.updatedAt = now;
              }
            }
          }
        } else if (isTeacher) {
          if (!database.teacherAttendanceRecords) database.teacherAttendanceRecords = [];
          const recIndex = database.teacherAttendanceRecords.findIndex(
            (r) => r.teacherProfileId === (application.teacherProfileId || application.applicantId) && r.date === dateStr
          );

          if (recIndex !== -1) {
            const currentRec = database.teacherAttendanceRecords[recIndex];
            // Only revert if current status is still LEAVE (preserve if admin made other manual adjustments)
            if (currentRec.status === 'LEAVE') {
              if (recordedState?.wasAutoCreated) {
                // Delete auto-created record
                database.teacherAttendanceRecords.splice(recIndex, 1);
              } else if (recordedState?.previousStatus && recordedState.previousStatus !== 'UNMARKED') {
                // Restore previous status (e.g. ABSENT)
                currentRec.status = recordedState.previousStatus as TeacherAttendanceStatus;
                currentRec.remarks = `Restored previous status after leave cancellation`;
                currentRec.updatedAt = now;
              }
            }
          }
        } else {
          if (!database.attendanceRecords) database.attendanceRecords = [];
          const recIndex = database.attendanceRecords.findIndex(
            (r) => (r.studentId === (application.studentId || application.applicantId) || r.userId === application.userId) && r.date === dateStr
          );

          if (recIndex !== -1) {
            const currentRec = database.attendanceRecords[recIndex];
            if (currentRec.status === 'LEAVE') {
              if (recordedState?.wasAutoCreated) {
                // Delete auto-created record
                database.attendanceRecords.splice(recIndex, 1);
              } else if (recordedState?.previousStatus && recordedState.previousStatus !== 'UNMARKED') {
                // Restore previous status (e.g. ABSENT)
                currentRec.status = recordedState.previousStatus as AttendanceStatus;
                currentRec.remarks = `Restored previous status after leave cancellation`;
                currentRec.updatedAt = now;
              }
            }
          }
        }
      }
    }

    database.leaveApplications[index] = {
      ...application,
      status: 'CANCELLED',
      remarks: cancellationReason?.trim() || application.remarks,
      updatedAt: now
    };

    const updatedApp = database.leaveApplications[index];

    logAudit({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action: 'UPDATE',
      entity: 'LEAVE_APPLICATION',
      entityType: 'LEAVE_APPLICATION',
      entityId: id,
      details: `Cancelled leave application for ${application.applicantName} (${application.startDate} to ${application.endDate}). Reason: ${cancellationReason || 'User requested cancellation'}.`,
      ipAddress: req.ip
    });

    // Centralized Attendance Notification & Alert System (Part 8F)
    AttendanceNotificationService.dispatchEvent({
      eventType: 'LEAVE_CANCELLED',
      date: application.startDate || application.leaveDate,
      studentId: application.applicantType === 'STUDENT' ? (application.studentId || application.applicantId) : undefined,
      teacherId: application.applicantType === 'TEACHER' ? (application.teacherProfileId || application.applicantId) : undefined,
      leaveApplicationId: application.id,
      leaveType: application.leaveTypeName,
      leaveStartDate: application.startDate || application.leaveDate,
      leaveEndDate: application.endDate || application.startDate || application.leaveDate,
      reason: cancellationReason || 'User requested cancellation',
      actorUser: { id: user.id, name: user.name, role: user.role }
    });

    res.json({
      success: true,
      message: 'Leave application has been cancelled and associated attendance states safely reconciled.',
      data: updatedApp
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// =========================================================================
// 9. GET /api/attendance/settings (Attendance Configuration & Rules)
// =========================================================================
attendanceRouter.get('/settings', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { academicSessionId } = req.query as { academicSessionId?: string };
    const targetSessionId =
      academicSessionId ||
      database.schoolSettings?.academicSessionId ||
      database.academicSessions.find((s) => s.isActive)?.id ||
      'session-2026-2027';
    const targetSchoolId = database.schoolSettings?.id || 'school-main';

    if (!database.attendanceSettings) {
      database.attendanceSettings = {
        id: 'att-settings-main',
        academicSessionId: targetSessionId,
        schoolId: targetSchoolId,
        studentAttendance: {
          enabled: true,
          mode: 'ONCE_DAILY',
          allowTeacherEdit: true,
          teacherEditGracePeriodHours: 24,
          requireAdminApprovalForCorrection: false,
          autoNotifyParentsOnAbsent: true,
          cutoffTime: '09:30',
          lateThresholdMinutes: 15,
          halfDayThresholdMinutes: 120,
          countLateAs: 'LATE',
          consecutiveLateToAbsentThreshold: 3
        },
        teacherAttendance: {
          enabled: true,
          mode: 'MANUAL_ENTRY',
          checkInStartTime: '07:30',
          cutoffTime: '08:30',
          lateThresholdMinutes: 15,
          halfDayThresholdMinutes: 180,
          requireGeofence: false
        },
        workingDays: ['MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY'],
        weekendDays: ['SATURDAY', 'SUNDAY'],
        holidayRules: {
          autoMarkHolidayInAttendance: true,
          allowAttendanceOverrideOnHoliday: false,
          allowOvertimeOnHoliday: true
        },
        leaveRules: {
          requireAdvanceApplication: true,
          maxCasualLeavesPerYear: 12,
          maxMedicalLeavesPerYear: 14,
          autoApproveWithinDays: 3
        },
        attendanceStatuses: [
          {
            id: 'status-present',
            code: 'PRESENT',
            name: 'Present',
            color: 'emerald',
            weight: 1.0,
            isLate: false,
            isExcused: false,
            isActive: true,
            description: 'Physically present and attended all scheduled sessions.'
          },
          {
            id: 'status-absent',
            code: 'ABSENT',
            name: 'Absent',
            color: 'rose',
            weight: 0.0,
            isLate: false,
            isExcused: false,
            isActive: true,
            description: 'Unexcused absence without prior leave authorization.'
          },
          {
            id: 'status-late',
            code: 'LATE',
            name: 'Late Arrival',
            color: 'amber',
            weight: 0.5,
            isLate: true,
            isExcused: false,
            isActive: true,
            description: 'Arrived past the official institutional cutoff threshold.'
          },
          {
            id: 'status-half-day',
            code: 'HALF_DAY',
            name: 'Half Day',
            color: 'orange',
            weight: 0.5,
            isLate: false,
            isExcused: false,
            isActive: true,
            description: 'Attended only morning or afternoon session.'
          },
          {
            id: 'status-leave',
            code: 'LEAVE',
            name: 'Approved Leave',
            color: 'purple',
            weight: 1.0,
            isLate: false,
            isExcused: true,
            isActive: true,
            description: 'Officially approved student or staff leave request.'
          },
          {
            id: 'status-excused',
            code: 'EXCUSED',
            name: 'Excused Absence',
            color: 'blue',
            weight: 1.0,
            isLate: false,
            isExcused: true,
            isActive: true,
            description: 'Medical, institutional representation, or administrative exemption.'
          }
        ],
        updatedAt: new Date().toISOString(),
        updatedBy: req.user!.id,
        updatedByName: req.user!.name
      };
    } else {
      if (!database.attendanceSettings.academicSessionId) {
        database.attendanceSettings.academicSessionId = targetSessionId;
      }
      if (!database.attendanceSettings.schoolId) {
        database.attendanceSettings.schoolId = targetSchoolId;
      }
      if (!database.attendanceSettings.teacherAttendance) {
        database.attendanceSettings.teacherAttendance = {
          enabled: true,
          mode: 'MANUAL_ENTRY',
          checkInStartTime: '07:30',
          cutoffTime: '08:30',
          lateThresholdMinutes: 15,
          halfDayThresholdMinutes: 180,
          requireGeofence: false
        };
      }
      if (!database.attendanceSettings.studentAttendance) {
        database.attendanceSettings.studentAttendance = {
          enabled: true,
          mode: 'ONCE_DAILY',
          allowTeacherEdit: true,
          teacherEditGracePeriodHours: 24,
          requireAdminApprovalForCorrection: false,
          autoNotifyParentsOnAbsent: true,
          cutoffTime: '09:30',
          lateThresholdMinutes: 15,
          halfDayThresholdMinutes: 120,
          countLateAs: 'LATE',
          consecutiveLateToAbsentThreshold: 3
        };
      }
    }

    res.json({
      success: true,
      data: database.attendanceSettings
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// =========================================================================
// 10. PUT /api/attendance/settings (Update Attendance Configuration)
// =========================================================================
attendanceRouter.put('/settings', requireAuth, requireRole('SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const updates = req.body;
    if (!updates || typeof updates !== 'object') {
      res.status(400).json({ success: false, error: 'Invalid attendance settings payload provided.' });
      return;
    }

    const defaultSettings: AttendanceSettings = {
      id: 'att-settings-main',
      studentAttendance: {
        enabled: true,
        mode: 'ONCE_DAILY',
        cutoffTime: '09:00',
        lateThresholdMinutes: 15,
        halfDayThresholdMinutes: 120,
        allowTeacherEdit: true,
        teacherEditGracePeriodHours: 24,
        requireAdminApprovalForCorrection: false,
        autoNotifyParentsOnAbsent: true,
        countLateAs: 'LATE',
        consecutiveLateToAbsentThreshold: 3
      },
      teacherAttendance: {
        enabled: true,
        mode: 'MANUAL_ENTRY',
        checkInStartTime: '07:30',
        cutoffTime: '08:30',
        lateThresholdMinutes: 15,
        halfDayThresholdMinutes: 180,
        requireGeofence: false
      },
      workingDays: ['MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY'],
      weekendDays: ['SATURDAY', 'SUNDAY'],
      holidayRules: {
        autoMarkHolidayInAttendance: true,
        allowAttendanceOverrideOnHoliday: false,
        allowOvertimeOnHoliday: false
      },
      leaveRules: {
        requireAdvanceApplication: true,
        maxCasualLeavesPerYear: 12,
        maxMedicalLeavesPerYear: 14,
        autoApproveWithinDays: 2
      },
      attendanceStatuses: [
        {
          id: 'status-present',
          code: 'PRESENT',
          name: 'Present',
          color: 'emerald',
          weight: 1.0,
          isLate: false,
          isExcused: false,
          isActive: true,
          description: 'Full attendance recorded on time.'
        },
        {
          id: 'status-absent',
          code: 'ABSENT',
          name: 'Absent',
          color: 'rose',
          weight: 0.0,
          isLate: false,
          isExcused: false,
          isActive: true,
          description: 'Unexcused absence without authorized leave.'
        },
        {
          id: 'status-late',
          code: 'LATE',
          name: 'Late Arrival',
          color: 'amber',
          weight: 0.5,
          isLate: true,
          isExcused: false,
          isActive: true,
          description: 'Arrived after institutional cutoff time.'
        },
        {
          id: 'status-half-day',
          code: 'HALF_DAY',
          name: 'Half Day',
          color: 'orange',
          weight: 0.5,
          isLate: false,
          isExcused: false,
          isActive: true,
          description: 'Present for at least 50% of instructional hours.'
        },
        {
          id: 'status-leave',
          code: 'LEAVE',
          name: 'Approved Leave',
          color: 'purple',
          weight: 1.0,
          isLate: false,
          isExcused: true,
          isActive: true,
          description: 'Authorized medical, casual, or family leave.'
        },
        {
          id: 'status-excused',
          code: 'EXCUSED',
          name: 'Excused Absence',
          color: 'blue',
          weight: 1.0,
          isLate: false,
          isExcused: true,
          isActive: true,
          description: 'Medical, institutional representation, or administrative exemption.'
        }
      ],
      updatedAt: new Date().toISOString(),
      updatedBy: 'system',
      updatedByName: 'System Initializer'
    };

    const current: AttendanceSettings = database.attendanceSettings || defaultSettings;
    const now = new Date().toISOString();

    // Validate working and weekend days
    const validDays: DayOfWeekName[] = [
      'MONDAY',
      'TUESDAY',
      'WEDNESDAY',
      'THURSDAY',
      'FRIDAY',
      'SATURDAY',
      'SUNDAY'
    ];

    let workingDays = updates.workingDays || current.workingDays || ['MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY'];
    let weekendDays = updates.weekendDays || current.weekendDays || ['SATURDAY', 'SUNDAY'];

    if (!Array.isArray(workingDays) || workingDays.some((d) => !validDays.includes(d))) {
      res.status(400).json({ success: false, error: 'Working days array contains invalid day names.' });
      return;
    }

    if (!Array.isArray(weekendDays) || weekendDays.some((d) => !validDays.includes(d))) {
      res.status(400).json({ success: false, error: 'Weekend days array contains invalid day names.' });
      return;
    }

    if (workingDays.length === 0 && weekendDays.length === 0) {
      res.status(400).json({ success: false, error: 'At least one working or weekend day must be configured.' });
      return;
    }

    // Validate Student Attendance Rules
    const studentRules = {
      ...current.studentAttendance,
      ...(updates.studentAttendance || {})
    };

    if (studentRules.cutoffTime && !/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/.test(studentRules.cutoffTime)) {
      res.status(400).json({ success: false, error: 'Student cutoff time must be in valid HH:MM 24-hour format.' });
      return;
    }

    if (studentRules.lateThresholdMinutes !== undefined && Number(studentRules.lateThresholdMinutes) < 0) {
      res.status(400).json({ success: false, error: 'Late threshold minutes cannot be negative.' });
      return;
    }

    // Validate Teacher Attendance Rules
    const teacherRules = {
      ...current.teacherAttendance,
      ...(updates.teacherAttendance || {})
    };

    if (teacherRules.cutoffTime && !/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/.test(teacherRules.cutoffTime)) {
      res.status(400).json({ success: false, error: 'Teacher cutoff time must be in valid HH:MM 24-hour format.' });
      return;
    }

    // Validate Attendance Statuses
    let statuses = updates.attendanceStatuses || current.attendanceStatuses || [];
    if (!Array.isArray(statuses) || statuses.length === 0) {
      res.status(400).json({ success: false, error: 'At least one attendance status must be defined.' });
      return;
    }

    // Sanitize and ensure IDs on statuses
    statuses = statuses.map((st: any, idx: number) => ({
      id: st.id || `status-${st.code ? st.code.toLowerCase() : idx}-${Date.now()}`,
      code: (st.code || `STATUS_${idx}`).toUpperCase().trim(),
      name: (st.name || st.code || `Status ${idx}`).trim(),
      color: st.color || 'slate',
      weight: typeof st.weight === 'number' ? Math.max(0, Math.min(1, st.weight)) : 1.0,
      isLate: Boolean(st.isLate),
      isExcused: Boolean(st.isExcused),
      isActive: st.isActive !== undefined ? Boolean(st.isActive) : true,
      description: (st.description || '').trim()
    }));

    const updatedSettings: AttendanceSettings = {
      id: current.id || 'att-settings-main',
      studentAttendance: studentRules,
      teacherAttendance: teacherRules,
      workingDays,
      weekendDays,
      holidayRules: {
        ...current.holidayRules,
        ...(updates.holidayRules || {})
      },
      leaveRules: {
        ...current.leaveRules,
        ...(updates.leaveRules || {})
      },
      attendanceStatuses: statuses,
      academicSessionId: updates.academicSessionId || current.academicSessionId || database.schoolSettings?.academicSessionId || 'session-2026-2027',
      schoolId: updates.schoolId || current.schoolId || database.schoolSettings?.id || 'school-main',
      updatedAt: now,
      updatedBy: req.user!.id,
      updatedByName: req.user!.name
    };

    database.attendanceSettings = updatedSettings;

    // AUDIT LOG
    logAudit({
      userId: req.user!.id,
      userName: req.user!.name,
      userRole: req.user!.role,
      action: 'UPDATE',
      entity: 'ATTENDANCE_SETTINGS',
      entityType: 'ATTENDANCE_SETTINGS',
      entityId: updatedSettings.id,
      details: `Updated institutional attendance configuration, weekend days (${weekendDays.join(', ')}), and attendance rules.`,
      ipAddress: req.ip
    });

    res.json({
      success: true,
      message: 'Attendance configuration & rules successfully updated.',
      data: database.attendanceSettings
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// =========================================================================
// 11. GET /api/attendance/holidays (List Holidays with filter)
// =========================================================================
attendanceRouter.get('/holidays', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { academicSessionId, status, year } = req.query as {
      academicSessionId?: string;
      status?: string;
      year?: string;
    };

    let holidays = [...(database.holidays || [])];

    if (academicSessionId && academicSessionId !== 'ALL') {
      holidays = holidays.filter((h) => h.academicSessionId === academicSessionId);
    }

    if (status && status !== 'ALL') {
      holidays = holidays.filter((h) => h.status === status);
    }

    if (year) {
      holidays = holidays.filter((h) => h.startDate.startsWith(year) || h.endDate.startsWith(year));
    }

    // Enrich with session name
    const enriched = holidays.map((h) => {
      const sess = database.academicSessions.find((s) => s.id === h.academicSessionId);
      return {
        ...h,
        academicSessionName: sess?.sessionName || h.academicSessionName || 'Academic Session'
      };
    });

    // Sort chronologically
    enriched.sort((a, b) => a.startDate.localeCompare(b.startDate));

    res.json({
      success: true,
      data: enriched
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// =========================================================================
// 12. POST /api/attendance/holidays (Create Holiday)
// =========================================================================
attendanceRouter.post('/holidays', requireAuth, requireRole('SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { holidayName, startDate, endDate, holidayType, description, status, academicSessionId } = req.body;

    if (!holidayName || !holidayName.trim()) {
      res.status(400).json({ success: false, error: 'Holiday Name is required.' });
      return;
    }

    if (!startDate || !endDate) {
      res.status(400).json({ success: false, error: 'Both Start Date and End Date are required.' });
      return;
    }

    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
    if (!dateRegex.test(startDate) || !dateRegex.test(endDate)) {
      res.status(400).json({ success: false, error: 'Dates must be in valid YYYY-MM-DD format.' });
      return;
    }

    if (startDate > endDate) {
      res.status(400).json({ success: false, error: 'Start Date must not be after End Date.' });
      return;
    }

    const sessionId = academicSessionId || database.schoolSettings.academicSessionId || database.academicSessions[0]?.id;
    const session = database.academicSessions.find((s) => s.id === sessionId);
    if (!session) {
      res.status(400).json({ success: false, error: 'Selected Academic Session does not exist.' });
      return;
    }

    // Prevent duplicate holiday name in the same session
    const duplicate = (database.holidays || []).find(
      (h) =>
        h.academicSessionId === sessionId &&
        h.holidayName.trim().toLowerCase() === holidayName.trim().toLowerCase() &&
        h.status === 'ACTIVE'
    );
    if (duplicate) {
      res.status(400).json({
        success: false,
        error: `An active holiday named '${holidayName.trim()}' already exists for session '${session.sessionName}'.`
      });
      return;
    }

    const now = new Date().toISOString();
    const newHoliday: HolidayRecord = {
      id: `hol-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      holidayName: holidayName.trim(),
      startDate,
      endDate,
      holidayType: holidayType || 'INSTITUTIONAL',
      description: (description || '').trim(),
      status: status || 'ACTIVE',
      academicSessionId: sessionId,
      academicSessionName: session.sessionName,
      createdAt: now,
      updatedAt: now
    };

    if (!database.holidays) database.holidays = [];
    database.holidays.push(newHoliday);

    // AUDIT LOG
    logAudit({
      userId: req.user!.id,
      userName: req.user!.name,
      userRole: req.user!.role,
      action: 'CREATE',
      entity: 'HOLIDAY',
      entityType: 'HOLIDAY',
      entityId: newHoliday.id,
      details: `Created holiday '${newHoliday.holidayName}' (${startDate} to ${endDate}) for ${session.sessionName}.`,
      ipAddress: req.ip
    });

    res.status(201).json({
      success: true,
      message: `Holiday '${newHoliday.holidayName}' created successfully.`,
      data: newHoliday
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// =========================================================================
// 13. PUT /api/attendance/holidays/:id (Update Holiday)
// =========================================================================
attendanceRouter.put('/holidays/:id', requireAuth, requireRole('SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { id } = req.params;
    const { holidayName, startDate, endDate, holidayType, description, status, academicSessionId } = req.body;

    if (!database.holidays) database.holidays = [];
    const index = database.holidays.findIndex((h) => h.id === id);
    if (index === -1) {
      res.status(404).json({ success: false, error: 'Specified holiday record not found.' });
      return;
    }

    const prev = database.holidays[index];
    const sDate = startDate || prev.startDate;
    const eDate = endDate || prev.endDate;

    if (sDate > eDate) {
      res.status(400).json({ success: false, error: 'Start Date must not be after End Date.' });
      return;
    }

    const sessionId = academicSessionId || prev.academicSessionId;
    const session = database.academicSessions.find((s) => s.id === sessionId);

    // Check duplicate name if renamed
    if (holidayName && holidayName.trim().toLowerCase() !== prev.holidayName.toLowerCase()) {
      const duplicate = database.holidays.find(
        (h) =>
          h.id !== id &&
          h.academicSessionId === sessionId &&
          h.holidayName.trim().toLowerCase() === holidayName.trim().toLowerCase() &&
          h.status === 'ACTIVE'
      );
      if (duplicate) {
        res.status(400).json({
          success: false,
          error: `An active holiday named '${holidayName.trim()}' already exists for this session.`
        });
        return;
      }
    }

    const now = new Date().toISOString();
    const updatedHoliday: HolidayRecord = {
      ...prev,
      holidayName: holidayName ? holidayName.trim() : prev.holidayName,
      startDate: sDate,
      endDate: eDate,
      holidayType: holidayType || prev.holidayType,
      description: description !== undefined ? description.trim() : prev.description,
      status: status || prev.status,
      academicSessionId: sessionId,
      academicSessionName: session?.sessionName || prev.academicSessionName,
      updatedAt: now
    };

    database.holidays[index] = updatedHoliday;

    logAudit({
      userId: req.user!.id,
      userName: req.user!.name,
      userRole: req.user!.role,
      action: 'UPDATE',
      entity: 'HOLIDAY',
      entityType: 'HOLIDAY',
      entityId: id,
      details: `Updated holiday '${updatedHoliday.holidayName}' (${sDate} to ${eDate}).`,
      ipAddress: req.ip
    });

    res.json({
      success: true,
      message: `Holiday '${updatedHoliday.holidayName}' updated successfully.`,
      data: updatedHoliday
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// =========================================================================
// 14. DELETE /api/attendance/holidays/:id (Delete Holiday)
// =========================================================================
attendanceRouter.delete('/holidays/:id', requireAuth, requireRole('SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { id } = req.params;
    if (!database.holidays) database.holidays = [];
    const index = database.holidays.findIndex((h) => h.id === id);
    if (index === -1) {
      res.status(404).json({ success: false, error: 'Specified holiday record not found.' });
      return;
    }

    const deleted = database.holidays.splice(index, 1)[0];

    logAudit({
      userId: req.user!.id,
      userName: req.user!.name,
      userRole: req.user!.role,
      action: 'DELETE',
      entity: 'HOLIDAY',
      entityType: 'HOLIDAY',
      entityId: id,
      details: `Deleted holiday record '${deleted.holidayName}' (${deleted.startDate} to ${deleted.endDate}).`,
      ipAddress: req.ip
    });

    res.json({
      success: true,
      message: `Holiday '${deleted.holidayName}' was successfully deleted.`,
      data: deleted
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// =========================================================================
// 15. GET /api/attendance/special-working-days (List Special Working Days)
// =========================================================================
attendanceRouter.get('/special-working-days', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { academicSessionId } = req.query as { academicSessionId?: string };
    let list = [...(database.specialWorkingDays || [])];

    if (academicSessionId && academicSessionId !== 'ALL') {
      list = list.filter((s) => s.academicSessionId === academicSessionId);
    }

    const enriched = list.map((swd) => {
      const session = database.academicSessions.find((s) => s.id === swd.academicSessionId);
      return {
        ...swd,
        academicSessionName: session?.sessionName || swd.academicSessionName || 'Academic Session'
      };
    });

    enriched.sort((a, b) => a.date.localeCompare(b.date));

    res.json({
      success: true,
      data: enriched
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// =========================================================================
// 16. POST /api/attendance/special-working-days (Create Special Working Day)
// =========================================================================
attendanceRouter.post('/special-working-days', requireAuth, requireRole('SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { date, reason, overridesDayType, academicSessionId, status } = req.body;

    if (!date || !/^\d{4}-\d{2}-\d{2}$/.test(date)) {
      res.status(400).json({ success: false, error: 'A valid date in YYYY-MM-DD format is required.' });
      return;
    }

    if (!reason || !reason.trim()) {
      res.status(400).json({ success: false, error: 'Reason for special working day is required.' });
      return;
    }

    const sessionId = academicSessionId || database.schoolSettings.academicSessionId || database.academicSessions[0]?.id;
    const session = database.academicSessions.find((s) => s.id === sessionId);

    // Prevent duplicate on same date
    const duplicate = (database.specialWorkingDays || []).find(
      (s) => s.academicSessionId === sessionId && s.date === date && s.status === 'ACTIVE'
    );
    if (duplicate) {
      res.status(400).json({
        success: false,
        error: `A special working day override already exists for date ${date}.`
      });
      return;
    }

    const now = new Date().toISOString();
    const newSpecialDay: SpecialWorkingDayRecord = {
      id: `swd-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      date,
      reason: reason.trim(),
      overridesDayType: overridesDayType || 'WEEKEND',
      academicSessionId: sessionId,
      academicSessionName: session?.sessionName || 'Academic Session',
      status: status || 'ACTIVE',
      createdAt: now,
      updatedAt: now
    };

    if (!database.specialWorkingDays) database.specialWorkingDays = [];
    database.specialWorkingDays.push(newSpecialDay);

    logAudit({
      userId: req.user!.id,
      userName: req.user!.name,
      userRole: req.user!.role,
      action: 'CREATE',
      entity: 'SPECIAL_WORKING_DAY',
      entityType: 'SPECIAL_WORKING_DAY',
      entityId: newSpecialDay.id,
      details: `Configured special working day override for ${date}. Reason: ${newSpecialDay.reason}.`,
      ipAddress: req.ip
    });

    res.status(201).json({
      success: true,
      message: `Special working day override configured for ${date}.`,
      data: newSpecialDay
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// =========================================================================
// 17. DELETE /api/attendance/special-working-days/:id
// =========================================================================
attendanceRouter.delete('/special-working-days/:id', requireAuth, requireRole('SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { id } = req.params;
    if (!database.specialWorkingDays) database.specialWorkingDays = [];
    const index = database.specialWorkingDays.findIndex((s) => s.id === id);
    if (index === -1) {
      res.status(404).json({ success: false, error: 'Specified special working day record not found.' });
      return;
    }

    const deleted = database.specialWorkingDays.splice(index, 1)[0];

    logAudit({
      userId: req.user!.id,
      userName: req.user!.name,
      userRole: req.user!.role,
      action: 'DELETE',
      entity: 'SPECIAL_WORKING_DAY',
      entityType: 'SPECIAL_WORKING_DAY',
      entityId: id,
      details: `Removed special working day override for ${deleted.date}.`,
      ipAddress: req.ip
    });

    res.json({
      success: true,
      message: `Special working day override for ${deleted.date} removed.`,
      data: deleted
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// =========================================================================
// 18. GET /api/attendance/calendar-events (List School Calendar Events)
// =========================================================================
attendanceRouter.get('/calendar-events', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { academicSessionId, month, year, targetAudience } = req.query as {
      academicSessionId?: string;
      month?: string;
      year?: string;
      targetAudience?: string;
    };

    let events = [...(database.schoolCalendarEvents || [])];

    if (academicSessionId && academicSessionId !== 'ALL') {
      events = events.filter((e) => e.academicSessionId === academicSessionId);
    }

    if (targetAudience && targetAudience !== 'ALL') {
      events = events.filter((e) => e.targetAudience === 'ALL' || e.targetAudience === targetAudience);
    }

    if (year && month) {
      const padMonth = String(month).padStart(2, '0');
      const targetPrefix = `${year}-${padMonth}`;
      events = events.filter((e) => e.startDate.startsWith(targetPrefix) || e.endDate.startsWith(targetPrefix));
    } else if (year) {
      events = events.filter((e) => e.startDate.startsWith(year) || e.endDate.startsWith(year));
    }

    events.sort((a, b) => a.startDate.localeCompare(b.startDate));

    res.json({
      success: true,
      data: events
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// =========================================================================
// 19. POST /api/attendance/calendar-events (Create School Event)
// =========================================================================
attendanceRouter.post('/calendar-events', requireAuth, requireRole('SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { title, startDate, endDate, eventType, description, targetAudience, color, academicSessionId } = req.body;

    if (!title || !title.trim()) {
      res.status(400).json({ success: false, error: 'Event title is required.' });
      return;
    }

    if (!startDate || !endDate) {
      res.status(400).json({ success: false, error: 'Start Date and End Date are required.' });
      return;
    }

    if (startDate > endDate) {
      res.status(400).json({ success: false, error: 'Start Date cannot be after End Date.' });
      return;
    }

    const sessionId = academicSessionId || database.schoolSettings.academicSessionId || database.academicSessions[0]?.id;
    const session = database.academicSessions.find((s) => s.id === sessionId);

    const now = new Date().toISOString();
    const newEvent: SchoolCalendarEvent = {
      id: `evt-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      title: title.trim(),
      startDate,
      endDate,
      eventType: eventType || 'ACADEMIC',
      description: (description || '').trim(),
      targetAudience: targetAudience || 'ALL',
      academicSessionId: sessionId,
      academicSessionName: session?.sessionName || 'Academic Session',
      color: color || '#3b82f6',
      createdAt: now,
      updatedAt: now
    };

    if (!database.schoolCalendarEvents) database.schoolCalendarEvents = [];
    database.schoolCalendarEvents.push(newEvent);

    logAudit({
      userId: req.user!.id,
      userName: req.user!.name,
      userRole: req.user!.role,
      action: 'CREATE',
      entity: 'CALENDAR_EVENT',
      entityType: 'CALENDAR_EVENT',
      entityId: newEvent.id,
      details: `Created institutional calendar event '${newEvent.title}' (${startDate} to ${endDate}).`,
      ipAddress: req.ip
    });

    res.status(201).json({
      success: true,
      message: `Event '${newEvent.title}' created successfully.`,
      data: newEvent
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// =========================================================================
// 20. DELETE /api/attendance/calendar-events/:id (Delete School Event)
// =========================================================================
attendanceRouter.delete('/calendar-events/:id', requireAuth, requireRole('SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { id } = req.params;
    if (!database.schoolCalendarEvents) database.schoolCalendarEvents = [];
    const index = database.schoolCalendarEvents.findIndex((e) => e.id === id);
    if (index === -1) {
      res.status(404).json({ success: false, error: 'Event record not found.' });
      return;
    }

    const deleted = database.schoolCalendarEvents.splice(index, 1)[0];

    logAudit({
      userId: req.user!.id,
      userName: req.user!.name,
      userRole: req.user!.role,
      action: 'DELETE',
      entity: 'CALENDAR_EVENT',
      entityType: 'CALENDAR_EVENT',
      entityId: id,
      details: `Deleted calendar event '${deleted.title}'.`,
      ipAddress: req.ip
    });

    res.json({
      success: true,
      message: `Event '${deleted.title}' deleted.`,
      data: deleted
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// =========================================================================
// 21. GET /api/attendance/academic-calendar (Comprehensive Month Grid View)
// =========================================================================
attendanceRouter.get('/academic-calendar', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { academicSessionId, year: qYear, month: qMonth } = req.query as {
      academicSessionId?: string;
      year?: string;
      month?: string;
    };

    const targetSessionId =
      academicSessionId && academicSessionId !== 'ALL'
        ? academicSessionId
        : database.schoolSettings.academicSessionId || database.academicSessions.find((s) => s.isActive)?.id || database.academicSessions[0]?.id;

    const session = database.academicSessions.find((s) => s.id === targetSessionId) || database.academicSessions[0];

    const today = new Date();
    const year = qYear ? parseInt(qYear, 10) : today.getFullYear();
    const month = qMonth ? parseInt(qMonth, 10) : today.getMonth() + 1; // 1-12

    const monthNames = [
      'January', 'February', 'March', 'April', 'May', 'June',
      'July', 'August', 'September', 'October', 'November', 'December'
    ];
    const monthName = monthNames[month - 1] || 'Month';

    const daysInMonth = new Date(year, month, 0).getDate();
    const weekendDays = database.attendanceSettings?.weekendDays || ['SATURDAY', 'SUNDAY'];

    const monthHolidays = (database.holidays || []).filter(
      (h) =>
        h.status === 'ACTIVE' &&
        h.academicSessionId === targetSessionId &&
        ((h.startDate <= `${year}-${String(month).padStart(2, '0')}-${String(daysInMonth).padStart(2, '0')}` &&
          h.endDate >= `${year}-${String(month).padStart(2, '0')}-01`))
    );

    const monthSpecialDays = (database.specialWorkingDays || []).filter(
      (s) =>
        s.status === 'ACTIVE' &&
        s.academicSessionId === targetSessionId &&
        s.date.startsWith(`${year}-${String(month).padStart(2, '0')}`)
    );

    const monthEvents = (database.schoolCalendarEvents || []).filter(
      (e) =>
        e.academicSessionId === targetSessionId &&
        ((e.startDate <= `${year}-${String(month).padStart(2, '0')}-${String(daysInMonth).padStart(2, '0')}` &&
          e.endDate >= `${year}-${String(month).padStart(2, '0')}-01`))
    );

    // Also get exam schedules for the month if any
    const monthExams = (database.examSchedules || []).filter((ex) =>
      ex.examDate.startsWith(`${year}-${String(month).padStart(2, '0')}`)
    );

    const days: CalendarDayDetails[] = [];
    let totalWorkingDays = 0;
    let totalWeekends = 0;
    let totalHolidays = 0;
    let totalSpecialWorkingDays = 0;

    const dayNameLabels = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

    for (let d = 1; d <= daysInMonth; d++) {
      const dayPad = String(d).padStart(2, '0');
      const dateStr = `${year}-${String(month).padStart(2, '0')}-${dayPad}`;
      const dateObj = new Date(year, month - 1, d);
      const dayOfWeek = dateObj.getDay();
      const dayName = dayNameLabels[dayOfWeek];

      const specialDay = monthSpecialDays.filter((s) => s.date === dateStr);
      const dayHolidays = monthHolidays.filter((h) => dateStr >= h.startDate && dateStr <= h.endDate);
      const dayEvents = monthEvents.filter((e) => dateStr >= e.startDate && dateStr <= e.endDate);
      const dayExams = monthExams.filter((ex) => ex.examDate === dateStr);

      const isWeekend = isWeekendDay(dayOfWeek, weekendDays);

      let dayType: 'WORKING_DAY' | 'WEEKEND' | 'HOLIDAY' | 'SPECIAL_WORKING_DAY';
      let isWorkingDay = true;

      if (specialDay.length > 0) {
        dayType = 'SPECIAL_WORKING_DAY';
        isWorkingDay = true;
        totalSpecialWorkingDays++;
        totalWorkingDays++;
      } else if (dayHolidays.length > 0) {
        dayType = 'HOLIDAY';
        isWorkingDay = false;
        totalHolidays++;
      } else if (isWeekend) {
        dayType = 'WEEKEND';
        isWorkingDay = false;
        totalWeekends++;
      } else {
        dayType = 'WORKING_DAY';
        isWorkingDay = true;
        totalWorkingDays++;
      }

      days.push({
        date: dateStr,
        dayOfWeek,
        dayName,
        dayType,
        isWorkingDay,
        holidays: dayHolidays,
        specialWorkingDays: specialDay,
        events: dayEvents,
        exams: dayExams
      });
    }

    const responseData: AcademicCalendarMonthViewResponse = {
      academicSessionId: targetSessionId,
      academicSessionName: session?.sessionName || 'Academic Session',
      year,
      month,
      monthName,
      totalDays: daysInMonth,
      totalWorkingDays,
      totalWeekends,
      totalHolidays,
      totalSpecialWorkingDays,
      totalEvents: monthEvents.length,
      days,
      holidays: monthHolidays,
      specialWorkingDays: monthSpecialDays,
      events: monthEvents,
      weekendDays
    };

    res.json({
      success: true,
      data: responseData
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ==========================================
// PART 8B — TEACHER ATTENDANCE ENDPOINTS
// ==========================================

/**
 * GET /api/attendance/teacher/daily
 * Get teacher attendance roster for a specific date
 */
attendanceRouter.get('/teacher/daily', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const user = req.user!;
    const date = (req.query.date as string) || new Date().toISOString().split('T')[0];
    const academicSessionId = (req.query.academicSessionId as string) || database.schoolSettings.academicSessionId;
    const departmentId = req.query.departmentId as string;
    const search = ((req.query.search as string) || '').toLowerCase().trim();

    const session = database.academicSessions.find((s) => s.id === academicSessionId);
    const dayStatus = getDateWorkingStatus(date, academicSessionId);

    // Get active teachers
    let teachers = database.teacherProfiles.filter((t) => t.status === 'active');
    
    // Strict RBAC: If a TEACHER accesses this, only return their own profile
    if (user.role === 'TEACHER') {
      teachers = teachers.filter((t) => t.userId === user.id);
    } else if (departmentId && departmentId !== 'ALL') {
      teachers = teachers.filter((t) => t.departmentId === departmentId);
    }

    if (search) {
      teachers = teachers.filter((t) => {
        const u = database.users.find((userObj) => userObj.id === t.userId);
        const name = (u?.name || t.employeeCode || '').toLowerCase();
        const code = (t.employeeCode || '').toLowerCase();
        const dept = (t.departmentName || t.department || '').toLowerCase();
        return name.includes(search) || code.includes(search) || dept.includes(search);
      });
    }

    // Get attendance records for this date
    const allRecords = database.teacherAttendanceRecords || [];
    const dateRecords = allRecords.filter((r) => r.date === date && !r.isDeleted);

    let presentCount = 0;
    let absentCount = 0;
    let lateCount = 0;
    let halfDayCount = 0;
    let leaveCount = 0;
    let excusedCount = 0;
    let markedCount = 0;

    const roster: TeacherDailyAttendanceRosterItem[] = teachers.map((t) => {
      const u = database.users.find((userObj) => userObj.id === t.userId);
      const record = dateRecords.find((r) => r.teacherProfileId === t.id);

      if (record) {
        markedCount++;
        if (record.status === 'PRESENT') presentCount++;
        else if (record.status === 'ABSENT') absentCount++;
        else if (record.status === 'LATE') lateCount++;
        else if (record.status === 'HALF_DAY') halfDayCount++;
        else if (record.status === 'LEAVE') leaveCount++;
        else if (record.status === 'EXCUSED') excusedCount++;
      }

      return {
        teacherProfileId: t.id,
        userId: t.userId,
        teacherName: u?.name || 'Teacher',
        employeeCode: t.employeeCode,
        departmentId: t.departmentId,
        departmentName: t.departmentName || t.department,
        avatarUrl: u?.avatarUrl,
        status: record?.status,
        recordId: record?.id,
        checkInTime: record?.checkInTime,
        checkOutTime: record?.checkOutTime,
        remarks: record?.remarks,
        isOverridden: record?.isOverridden,
        overrideReason: record?.overrideReason,
        history: record?.history,
        updatedAt: record?.updatedAt,
        updatedByName: record?.updatedByName
      };
    });

    const totalTeachers = teachers.length;
    const unmarkedCount = totalTeachers - markedCount;
    const effectiveAttended = presentCount + lateCount + halfDayCount;
    const attendanceRate = totalTeachers > 0 ? Math.round((effectiveAttended / totalTeachers) * 100) : 0;

    const responseData: TeacherDailyAttendanceResponse = {
      date,
      academicSessionId,
      academicSessionName: session?.sessionName || 'Academic Session',
      dayType: dayStatus.dayType,
      isWorkingDay: dayStatus.isWorkingDay,
      dayReason: dayStatus.reason,
      canMarkAttendance: dayStatus.isWorkingDay || user.role === 'SUPER_ADMIN',
      stats: {
        totalTeachers,
        markedTeachers: markedCount,
        presentCount,
        absentCount,
        lateCount,
        halfDayCount,
        leaveCount,
        excusedCount,
        unmarkedCount,
        attendanceRate
      },
      roster
    };

    res.json({
      success: true,
      data: responseData
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * GET /api/attendance/teacher/monthly
 * Matrix view of teacher attendance across a full month
 */
attendanceRouter.get('/teacher/monthly', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const user = req.user!;
    const now = new Date();
    const year = parseInt((req.query.year as string) || String(now.getFullYear()), 10);
    const month = parseInt((req.query.month as string) || String(now.getMonth() + 1), 10);
    const academicSessionId = (req.query.academicSessionId as string) || database.schoolSettings.academicSessionId;
    let teacherProfileId = req.query.teacherProfileId as string;
    const departmentId = req.query.departmentId as string;
    const search = ((req.query.search as string) || '').toLowerCase().trim();

    // Strict RBAC: If Teacher, only allow self
    if (user.role === 'TEACHER') {
      const ownProfile = database.teacherProfiles.find((t) => t.userId === user.id);
      if (ownProfile) {
        teacherProfileId = ownProfile.id;
      }
    }

    const session = database.academicSessions.find((s) => s.id === academicSessionId);
    const daysInMonth = new Date(year, month, 0).getDate();
    const monthNames = [
      'January', 'February', 'March', 'April', 'May', 'June',
      'July', 'August', 'September', 'October', 'November', 'December'
    ];
    const dayNameLabels = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

    // Build day columns
    const days: TeacherMonthlyMatrixDay[] = [];
    let totalWorkingDays = 0;

    for (let d = 1; d <= daysInMonth; d++) {
      const dayPad = String(d).padStart(2, '0');
      const dateStr = `${year}-${String(month).padStart(2, '0')}-${dayPad}`;
      const dateObj = new Date(year, month - 1, d);
      const dayOfWeek = dateObj.getDay();
      const status = getDateWorkingStatus(dateStr, academicSessionId);

      if (status.isWorkingDay) {
        totalWorkingDays++;
      }

      days.push({
        date: dateStr,
        dayOfMonth: d,
        dayOfWeek,
        dayName: dayNameLabels[dayOfWeek],
        dayType: status.dayType,
        isWorkingDay: status.isWorkingDay,
        reason: status.reason
      });
    }

    // Filter teachers
    let teachers = database.teacherProfiles.filter((t) => t.status === 'active');
    if (teacherProfileId && teacherProfileId !== 'ALL') {
      teachers = teachers.filter((t) => t.id === teacherProfileId);
    }
    if (departmentId && departmentId !== 'ALL') {
      teachers = teachers.filter((t) => t.departmentId === departmentId);
    }
    if (search) {
      teachers = teachers.filter((t) => {
        const u = database.users.find((userObj) => userObj.id === t.userId);
        const name = (u?.name || '').toLowerCase();
        const code = (t.employeeCode || '').toLowerCase();
        return name.includes(search) || code.includes(search);
      });
    }

    // Retrieve monthly records
    const startDate = `${year}-${String(month).padStart(2, '0')}-01`;
    const endDate = `${year}-${String(month).padStart(2, '0')}-${String(daysInMonth).padStart(2, '0')}`;
    const allRecords = database.teacherAttendanceRecords || [];
    const monthRecords = allRecords.filter(
      (r) => r.date >= startDate && r.date <= endDate && !r.isDeleted
    );

    let grandPresent = 0;
    let grandAbsent = 0;
    let grandLate = 0;
    let grandHalfDay = 0;
    let grandLeave = 0;
    let grandExcused = 0;
    let totalRateSum = 0;

    const teacherRows: TeacherMonthlyMatrixRow[] = teachers.map((t) => {
      const u = database.users.find((userObj) => userObj.id === t.userId);
      const tRecords = monthRecords.filter((r) => r.teacherProfileId === t.id);

      const attendanceByDate: Record<string, any> = {};
      let present = 0;
      let absent = 0;
      let late = 0;
      let halfDay = 0;
      let leave = 0;
      let excused = 0;

      tRecords.forEach((r) => {
        attendanceByDate[r.date] = {
          status: r.status,
          recordId: r.id,
          checkInTime: r.checkInTime,
          checkOutTime: r.checkOutTime,
          remarks: r.remarks,
          isOverridden: r.isOverridden
        };

        if (r.status === 'PRESENT') present++;
        else if (r.status === 'ABSENT') absent++;
        else if (r.status === 'LATE') late++;
        else if (r.status === 'HALF_DAY') halfDay++;
        else if (r.status === 'LEAVE') leave++;
        else if (r.status === 'EXCUSED') excused++;
      });

      grandPresent += present;
      grandAbsent += absent;
      grandLate += late;
      grandHalfDay += halfDay;
      grandLeave += leave;
      grandExcused += excused;

      const effectivePresent = present + late + halfDay;
      const rate = totalWorkingDays > 0 ? Math.round((effectivePresent / totalWorkingDays) * 100) : 0;
      totalRateSum += rate;

      return {
        teacherProfileId: t.id,
        userId: t.userId,
        teacherName: u?.name || 'Teacher',
        employeeCode: t.employeeCode,
        departmentName: t.departmentName || t.department || 'Faculty',
        avatarUrl: u?.avatarUrl,
        attendanceByDate,
        summary: {
          totalApplicableWorkingDays: totalWorkingDays,
          present,
          absent,
          late,
          halfDay,
          leave,
          excused,
          rate
        }
      };
    });

    const averageAttendanceRate =
      teachers.length > 0 ? Math.round(totalRateSum / teachers.length) : 0;

    const responseData: TeacherMonthlyAttendanceResponse = {
      academicSessionId,
      academicSessionName: session?.sessionName || 'Academic Session',
      year,
      month,
      monthName: monthNames[month - 1],
      days,
      teachers: teacherRows,
      totalWorkingDays,
      overallSummary: {
        totalTeachers: teachers.length,
        averageAttendanceRate,
        totalPresent: grandPresent,
        totalAbsent: grandAbsent,
        totalLate: grandLate,
        totalHalfDay: grandHalfDay,
        totalLeave: grandLeave,
        totalExcused: grandExcused
      }
    };

    res.json({
      success: true,
      data: responseData
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * GET /api/attendance/teacher/my-attendance
 * Teacher Portal: Get own attendance for current/requested month
 */
attendanceRouter.get('/teacher/my-attendance', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const user = req.user!;
    let teacher = database.teacherProfiles.find((t) => t.userId === user.id);

    // If Super Admin testing the endpoint, permit fallback
    if (!teacher && user.role === 'SUPER_ADMIN') {
      const requestedTeacherId = req.query.teacherProfileId as string;
      if (requestedTeacherId) {
        teacher = database.teacherProfiles.find((t) => t.id === requestedTeacherId);
      }
      if (!teacher) {
        teacher = database.teacherProfiles[0];
      }
    }

    if (!teacher) {
      return res.status(403).json({
        success: false,
        error: 'Teacher profile not found for authenticated user account.'
      });
    }

    const teacherUser = database.users.find((u) => u.id === teacher!.userId);
    const now = new Date();
    const year = parseInt((req.query.year as string) || String(now.getFullYear()), 10);
    const month = parseInt((req.query.month as string) || String(now.getMonth() + 1), 10);
    const academicSessionId = (req.query.academicSessionId as string) || database.schoolSettings.academicSessionId;

    const session = database.academicSessions.find((s) => s.id === academicSessionId);
    const daysInMonth = new Date(year, month, 0).getDate();
    const monthNames = [
      'January', 'February', 'March', 'April', 'May', 'June',
      'July', 'August', 'September', 'October', 'November', 'December'
    ];
    const dayNameLabels = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

    const startDate = `${year}-${String(month).padStart(2, '0')}-01`;
    const endDate = `${year}-${String(month).padStart(2, '0')}-${String(daysInMonth).padStart(2, '0')}`;

    const allRecords = database.teacherAttendanceRecords || [];
    const teacherRecords = allRecords.filter(
      (r) => r.teacherProfileId === teacher!.id && r.date >= startDate && r.date <= endDate && !r.isDeleted
    );

    let totalWorkingDays = 0;
    let present = 0;
    let absent = 0;
    let late = 0;
    let halfDay = 0;
    let leave = 0;
    let excused = 0;

    const calendarDays: TeacherMyAttendanceDay[] = [];

    for (let d = 1; d <= daysInMonth; d++) {
      const dayPad = String(d).padStart(2, '0');
      const dateStr = `${year}-${String(month).padStart(2, '0')}-${dayPad}`;
      const dateObj = new Date(year, month - 1, d);
      const dayOfWeek = dateObj.getDay();
      const statusObj = getDateWorkingStatus(dateStr, academicSessionId);

      if (statusObj.isWorkingDay) {
        totalWorkingDays++;
      }

      const rec = teacherRecords.find((r) => r.date === dateStr);
      if (rec) {
        if (rec.status === 'PRESENT') present++;
        else if (rec.status === 'ABSENT') absent++;
        else if (rec.status === 'LATE') late++;
        else if (rec.status === 'HALF_DAY') halfDay++;
        else if (rec.status === 'LEAVE') leave++;
        else if (rec.status === 'EXCUSED') excused++;
      }

      calendarDays.push({
        date: dateStr,
        dayOfMonth: d,
        dayOfWeek,
        dayName: dayNameLabels[dayOfWeek],
        dayType: statusObj.dayType,
        isWorkingDay: statusObj.isWorkingDay,
        reason: statusObj.reason,
        status: rec?.status,
        checkInTime: rec?.checkInTime,
        checkOutTime: rec?.checkOutTime,
        remarks: rec?.remarks,
        recordId: rec?.id,
        isOverridden: rec?.isOverridden
      });
    }

    const effectivePresent = present + late + halfDay;
    const attendanceRate = totalWorkingDays > 0 ? Math.round((effectivePresent / totalWorkingDays) * 100) : 0;

    const responseData: TeacherMyAttendanceResponse = {
      teacher: {
        teacherProfileId: teacher.id,
        userId: teacher.userId,
        name: teacherUser?.name || 'Teacher',
        employeeCode: teacher.employeeCode,
        designation: teacher.designation || 'Faculty Member',
        departmentName: teacher.departmentName || teacher.department || 'Academic Faculty',
        avatarUrl: teacherUser?.avatarUrl
      },
      academicSessionId,
      academicSessionName: session?.sessionName || 'Academic Session',
      year,
      month,
      monthName: monthNames[month - 1],
      summary: {
        totalWorkingDays,
        present,
        absent,
        late,
        halfDay,
        leave,
        excused,
        attendanceRate
      },
      stats: {
        totalWorkingDays,
        presentCount: present,
        absentCount: absent,
        lateCount: late,
        halfDayCount: halfDay,
        leaveCount: leave,
        excusedCount: excused,
        attendanceRate
      },
      days: calendarDays,
      calendarDays,
      historyRecords: teacherRecords.sort((a, b) => b.date.localeCompare(a.date))
    };

    res.json({
      success: true,
      data: responseData
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * GET /api/attendance/teacher/history
 * Comprehensive teacher attendance logs with audit and search filters
 */
attendanceRouter.get('/teacher/history', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const user = req.user!;
    let teacherProfileId = req.query.teacherProfileId as string;
    const startDate = req.query.startDate as string;
    const endDate = req.query.endDate as string;
    const status = req.query.status as string;
    const departmentId = req.query.departmentId as string;
    const search = ((req.query.search as string) || '').toLowerCase().trim();
    const academicSessionId = req.query.academicSessionId as string;

    // Strict RBAC: Teachers view ONLY their own records
    if (user.role === 'TEACHER') {
      const ownProfile = database.teacherProfiles.find((t) => t.userId === user.id);
      if (ownProfile) {
        teacherProfileId = ownProfile.id;
      }
    }

    let records = (database.teacherAttendanceRecords || []).filter((r) => !r.isDeleted);

    if (teacherProfileId && teacherProfileId !== 'ALL') {
      records = records.filter((r) => r.teacherProfileId === teacherProfileId);
    }
    if (academicSessionId && academicSessionId !== 'ALL') {
      records = records.filter((r) => r.academicSessionId === academicSessionId);
    }
    if (departmentId && departmentId !== 'ALL') {
      records = records.filter((r) => r.departmentId === departmentId);
    }
    if (status && status !== 'ALL') {
      records = records.filter((r) => r.status === status);
    }
    if (startDate) {
      records = records.filter((r) => r.date >= startDate);
    }
    if (endDate) {
      records = records.filter((r) => r.date <= endDate);
    }
    if (search) {
      records = records.filter((r) => {
        const name = (r.teacherName || '').toLowerCase();
        const code = (r.employeeCode || '').toLowerCase();
        const rem = (r.remarks || '').toLowerCase();
        return name.includes(search) || code.includes(search) || rem.includes(search);
      });
    }

    // Sort descending by date, then createdAt
    records.sort((a, b) => b.date.localeCompare(a.date) || b.createdAt.localeCompare(a.createdAt));

    res.json({
      success: true,
      data: records,
      total: records.length
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * POST /api/attendance/teacher/mark
 * Mark or record single teacher attendance (Super Admin)
 */
attendanceRouter.post('/teacher/mark', requireAuth, requireRole('SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response) => {
  try {
    const user = req.user!;
    const {
      teacherProfileId,
      date,
      status,
      checkInTime,
      checkOutTime,
      remarks,
      academicSessionId,
      allowOverride,
      overrideReason
    } = req.body;

    if (!teacherProfileId || !date || !status) {
      return res.status(400).json({
        success: false,
        error: 'Teacher Profile ID, Date, and Status are required.'
      });
    }

    const validStatuses: TeacherAttendanceStatus[] = ['PRESENT', 'ABSENT', 'LATE', 'HALF_DAY', 'LEAVE', 'EXCUSED'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({
        success: false,
        error: `Invalid attendance status: ${status}. Must be one of ${validStatuses.join(', ')}.`
      });
    }

    const teacher = database.teacherProfiles.find((t) => t.id === teacherProfileId);
    if (!teacher) {
      return res.status(404).json({
        success: false,
        error: `Teacher profile not found with ID ${teacherProfileId}`
      });
    }

    const targetSessionId = academicSessionId || database.schoolSettings.academicSessionId;
    const session = database.academicSessions.find((s) => s.id === targetSessionId);

    // Validate date working status
    const workingStatus = getDateWorkingStatus(date, targetSessionId);
    if (!workingStatus.isWorkingDay && !allowOverride) {
      return res.status(400).json({
        success: false,
        error: `Cannot mark attendance on non-working day: ${date} is a ${workingStatus.dayType} (${workingStatus.reason}). Super Admin override required with reason.`
      });
    }

    // Backend duplicate prevention: A teacher must not have multiple active attendance records for the same teacher + session + date
    if (!database.teacherAttendanceRecords) {
      database.teacherAttendanceRecords = [];
    }

    const existingRecord = database.teacherAttendanceRecords.find(
      (r) =>
        r.teacherProfileId === teacherProfileId &&
        r.date === date &&
        (!r.academicSessionId || r.academicSessionId === targetSessionId) &&
        !r.isDeleted
    );

    if (existingRecord) {
      return res.status(400).json({
        success: false,
        error: `Duplicate Attendance Error: An attendance record already exists for ${teacher.employeeCode} on ${date} (Status: ${existingRecord.status}). Please use the Edit/Correction feature to modify existing records.`,
        existingRecordId: existingRecord.id
      });
    }

    const teacherUser = database.users.find((u) => u.id === teacher.userId);

    const newRecord: TeacherAttendanceRecord = {
      id: `t-att-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      teacherProfileId,
      userId: teacher.userId,
      teacherName: teacherUser?.name || 'Faculty Member',
      employeeCode: teacher.employeeCode,
      departmentId: teacher.departmentId,
      departmentName: teacher.departmentName || teacher.department,
      avatarUrl: teacherUser?.avatarUrl,
      academicSessionId: targetSessionId,
      academicSessionName: session?.sessionName || 'Academic Session',
      date,
      status,
      checkInTime: checkInTime || (status === 'PRESENT' || status === 'LATE' ? '08:00' : undefined),
      checkOutTime: checkOutTime || (status === 'PRESENT' ? '16:00' : undefined),
      remarks: remarks || undefined,
      isOverridden: !workingStatus.isWorkingDay && allowOverride ? true : false,
      overrideReason: !workingStatus.isWorkingDay && allowOverride ? overrideReason : undefined,
      history: [],
      createdBy: user.id,
      createdByName: user.name,
      updatedBy: user.id,
      updatedByName: user.name,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    database.teacherAttendanceRecords.push(newRecord);

    logAudit({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action: 'CREATE',
      entityType: 'TEACHER_ATTENDANCE',
      entityId: newRecord.id,
      details: `Marked attendance for ${newRecord.teacherName} on ${date} as ${status}.`,
      metadata: {
        teacherProfileId,
        teacherName: newRecord.teacherName,
        date,
        status,
        isOverridden: newRecord.isOverridden
      }
    });

    res.status(201).json({
      success: true,
      message: `Teacher attendance marked successfully for ${newRecord.teacherName}.`,
      data: newRecord
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * POST /api/attendance/teacher/bulk-mark
 * Bulk mark or update teacher attendance for a specific date (Super Admin)
 */
attendanceRouter.post('/teacher/bulk-mark', requireAuth, requireRole('SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response) => {
  try {
    const user = req.user!;
    const { date, academicSessionId, records, allowOverride, overrideReason } = req.body;

    if (!date || !Array.isArray(records) || records.length === 0) {
      return res.status(400).json({
        success: false,
        error: 'Date and an array of teacher attendance records are required.'
      });
    }

    const targetSessionId = academicSessionId || database.schoolSettings.academicSessionId;
    const session = database.academicSessions.find((s) => s.id === targetSessionId);
    const workingStatus = getDateWorkingStatus(date, targetSessionId);

    if (!workingStatus.isWorkingDay && !allowOverride) {
      return res.status(400).json({
        success: false,
        error: `Cannot bulk mark attendance on non-working day: ${date} is a ${workingStatus.dayType} (${workingStatus.reason}). Super Admin override required with reason.`
      });
    }

    if (!database.teacherAttendanceRecords) {
      database.teacherAttendanceRecords = [];
    }

    let createdCount = 0;
    let updatedCount = 0;
    const processedRecords: TeacherAttendanceRecord[] = [];

    for (const item of records) {
      const teacher = database.teacherProfiles.find((t) => t.id === item.teacherProfileId);
      if (!teacher) continue;

      const teacherUser = database.users.find((u) => u.id === teacher.userId);
      const existing = database.teacherAttendanceRecords.find(
        (r) => r.teacherProfileId === item.teacherProfileId && r.date === date && !r.isDeleted
      );

      if (existing) {
        // If status or times changed, record correction history
        if (existing.status !== item.status || existing.remarks !== item.remarks) {
          const historyItem: TeacherAttendanceCorrectionHistoryItem = {
            id: `hist-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
            fromStatus: existing.status,
            toStatus: item.status,
            fromCheckInTime: existing.checkInTime,
            toCheckInTime: item.checkInTime,
            fromCheckOutTime: existing.checkOutTime,
            toCheckOutTime: item.checkOutTime,
            reason: item.remarks || 'Bulk attendance update by Super Admin',
            correctedByUserId: user.id,
            correctedByUserName: user.name,
            correctedAt: new Date().toISOString()
          };
          existing.history = existing.history || [];
          existing.history.push(historyItem);
        }

        existing.status = item.status;
        if (item.checkInTime !== undefined) existing.checkInTime = item.checkInTime;
        if (item.checkOutTime !== undefined) existing.checkOutTime = item.checkOutTime;
        if (item.remarks !== undefined) existing.remarks = item.remarks;
        existing.updatedBy = user.id;
        existing.updatedByName = user.name;
        existing.updatedAt = new Date().toISOString();
        updatedCount++;
        processedRecords.push(existing);
      } else {
        const newRecord: TeacherAttendanceRecord = {
          id: `t-att-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
          teacherProfileId: item.teacherProfileId,
          userId: teacher.userId,
          teacherName: teacherUser?.name || 'Faculty Member',
          employeeCode: teacher.employeeCode,
          departmentId: teacher.departmentId,
          departmentName: teacher.departmentName || teacher.department,
          avatarUrl: teacherUser?.avatarUrl,
          academicSessionId: targetSessionId,
          academicSessionName: session?.sessionName || 'Academic Session',
          date,
          status: item.status,
          checkInTime: item.checkInTime || (item.status === 'PRESENT' || item.status === 'LATE' ? '08:00' : undefined),
          checkOutTime: item.checkOutTime || (item.status === 'PRESENT' ? '16:00' : undefined),
          remarks: item.remarks,
          isOverridden: !workingStatus.isWorkingDay && allowOverride ? true : false,
          overrideReason: !workingStatus.isWorkingDay && allowOverride ? overrideReason : undefined,
          history: [],
          createdBy: user.id,
          createdByName: user.name,
          updatedBy: user.id,
          updatedByName: user.name,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        };
        database.teacherAttendanceRecords.push(newRecord);
        createdCount++;
        processedRecords.push(newRecord);
      }
    }

    logAudit({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action: 'UPDATE',
      entityType: 'TEACHER_ATTENDANCE_BULK',
      entityId: date,
      details: `Bulk marked teacher attendance on ${date}: ${createdCount} created, ${updatedCount} updated.`,
      metadata: {
        date,
        createdCount,
        updatedCount,
        totalProcessed: processedRecords.length
      }
    });

    res.json({
      success: true,
      message: `Successfully processed ${processedRecords.length} teacher attendance entries (${createdCount} new, ${updatedCount} updated).`,
      data: {
        createdCount,
        updatedCount,
        records: processedRecords
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * PUT /api/attendance/teacher/:id
 * Correct / edit teacher attendance record with mandatory audit history (Super Admin)
 */
attendanceRouter.put('/teacher/:id', requireAuth, requireRole('SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response) => {
  try {
    const user = req.user!;
    const { id } = req.params;
    const { status, checkInTime, checkOutTime, remarks, reason } = req.body;

    if (!database.teacherAttendanceRecords) {
      database.teacherAttendanceRecords = [];
    }

    const record = database.teacherAttendanceRecords.find((r) => r.id === id && !r.isDeleted);
    if (!record) {
      return res.status(404).json({
        success: false,
        error: `Teacher attendance record not found with ID ${id}`
      });
    }

    if (!reason || reason.trim().length < 3) {
      return res.status(400).json({
        success: false,
        error: 'A valid correction reason (minimum 3 characters) is required for audit compliance.'
      });
    }

    const validStatuses: TeacherAttendanceStatus[] = ['PRESENT', 'ABSENT', 'LATE', 'HALF_DAY', 'LEAVE', 'EXCUSED'];
    if (status && !validStatuses.includes(status)) {
      return res.status(400).json({
        success: false,
        error: `Invalid status: ${status}. Must be one of ${validStatuses.join(', ')}.`
      });
    }

    // Build correction history item
    const historyItem: TeacherAttendanceCorrectionHistoryItem = {
      id: `hist-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      fromStatus: record.status,
      toStatus: status || record.status,
      fromCheckInTime: record.checkInTime,
      toCheckInTime: checkInTime !== undefined ? checkInTime : record.checkInTime,
      fromCheckOutTime: record.checkOutTime,
      toCheckOutTime: checkOutTime !== undefined ? checkOutTime : record.checkOutTime,
      reason: reason.trim(),
      correctedByUserId: user.id,
      correctedByUserName: user.name,
      correctedAt: new Date().toISOString()
    };

    record.history = record.history || [];
    record.history.push(historyItem);

    if (status) record.status = status;
    if (checkInTime !== undefined) record.checkInTime = checkInTime;
    if (checkOutTime !== undefined) record.checkOutTime = checkOutTime;
    if (remarks !== undefined) record.remarks = remarks;
    record.updatedBy = user.id;
    record.updatedByName = user.name;
    record.updatedAt = new Date().toISOString();

    logAudit({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action: 'UPDATE',
      entityType: 'TEACHER_ATTENDANCE',
      entityId: record.id,
      details: `Corrected attendance for teacher ${record.teacherName} on ${record.date} from ${historyItem.fromStatus} to ${record.status}. Reason: ${reason.trim()}`,
      metadata: {
        fromStatus: historyItem.fromStatus,
        toStatus: record.status,
        reason: reason.trim(),
        teacherName: record.teacherName,
        date: record.date
      }
    });

    res.json({
      success: true,
      message: `Attendance for ${record.teacherName} on ${record.date} corrected successfully.`,
      data: record
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * DELETE /api/attendance/teacher/:id
 * Soft-delete / void teacher attendance record with audit logging (Super Admin)
 */
attendanceRouter.delete('/teacher/:id', requireAuth, requireRole('SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response) => {
  try {
    const user = req.user!;
    const { id } = req.params;
    const reason = (req.body?.reason || req.query?.reason || 'Record voided by Super Admin') as string;

    if (!database.teacherAttendanceRecords) {
      database.teacherAttendanceRecords = [];
    }

    const record = database.teacherAttendanceRecords.find((r) => r.id === id && !r.isDeleted);
    if (!record) {
      return res.status(404).json({
        success: false,
        error: `Teacher attendance record not found with ID ${id}`
      });
    }

    record.isDeleted = true;
    record.deletedAt = new Date().toISOString();
    record.deletedBy = user.id;
    record.updatedAt = new Date().toISOString();
    record.updatedBy = user.id;

    logAudit({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action: 'DELETE',
      entityType: 'TEACHER_ATTENDANCE',
      entityId: record.id,
      details: `Voided attendance record for teacher ${record.teacherName} on ${record.date}. Reason: ${reason}`,
      metadata: {
        teacherName: record.teacherName,
        date: record.date,
        status: record.status,
        voidReason: reason
      }
    });

    res.json({
      success: true,
      message: `Teacher attendance record for ${record.teacherName} on ${record.date} has been voided.`
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * POST /api/attendance/teacher/check-in
 * Teacher self-service check-in for current day
 */
attendanceRouter.post('/teacher/check-in', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const user = req.user!;
    const teacher = database.teacherProfiles.find((t) => t.userId === user.id);
    if (!teacher) {
      return res.status(403).json({ success: false, error: 'Only registered teachers can perform check-in.' });
    }

    const now = new Date();
    const today = now.toISOString().split('T')[0];
    const currentTime = now.toTimeString().split(' ')[0].substring(0, 5); // 'HH:MM'
    const targetSessionId = database.schoolSettings.academicSessionId;
    const session = database.academicSessions.find((s) => s.id === targetSessionId);

    const workingStatus = getDateWorkingStatus(today, targetSessionId);
    if (!workingStatus.isWorkingDay) {
      return res.status(400).json({
        success: false,
        error: `Cannot check-in on a scheduled ${workingStatus.dayType} (${workingStatus.reason}).`
      });
    }

    if (!database.teacherAttendanceRecords) {
      database.teacherAttendanceRecords = [];
    }

    let record = database.teacherAttendanceRecords.find(
      (r) => r.teacherProfileId === teacher.id && r.date === today && !r.isDeleted
    );

    const teacherSettings = database.attendanceSettings?.teacherAttendance;
    const lateThreshold = teacherSettings?.lateThresholdMinutes || 15;
    // Assuming official start is 08:00
    const [hours, mins] = currentTime.split(':').map(Number);
    const minutesPastMidnight = hours * 60 + mins;
    const lateCutoffMinutes = 8 * 60 + lateThreshold; // 08:15 default

    const status: TeacherAttendanceStatus = minutesPastMidnight > lateCutoffMinutes ? 'LATE' : 'PRESENT';

    if (record) {
      if (record.checkInTime) {
        return res.status(400).json({
          success: false,
          error: `You have already checked in today at ${record.checkInTime}.`
        });
      }
      record.checkInTime = currentTime;
      record.status = status;
      record.updatedAt = new Date().toISOString();
      record.updatedBy = user.id;
    } else {
      record = {
        id: `t-att-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
        teacherProfileId: teacher.id,
        userId: user.id,
        teacherName: user.name,
        employeeCode: teacher.employeeCode,
        departmentId: teacher.departmentId,
        departmentName: teacher.departmentName || teacher.department,
        avatarUrl: user.avatarUrl,
        academicSessionId: targetSessionId,
        academicSessionName: session?.sessionName || 'Academic Session',
        date: today,
        status,
        checkInTime: currentTime,
        history: [],
        createdBy: user.id,
        createdByName: user.name,
        updatedBy: user.id,
        updatedByName: user.name,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      database.teacherAttendanceRecords.push(record);
    }

    logAudit({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action: 'CHECK_IN',
      entityType: 'TEACHER_ATTENDANCE',
      entityId: record.id,
      details: `Teacher ${user.name} checked in at ${currentTime} (Status: ${status}).`,
      metadata: {
        teacherName: user.name,
        checkInTime: currentTime,
        status
      }
    });

    res.json({
      success: true,
      message: `Checked in successfully at ${currentTime} (Status: ${status}).`,
      data: record
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * POST /api/attendance/teacher/check-out
 * Teacher self-service check-out for current day
 */
attendanceRouter.post('/teacher/check-out', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  try {
    const user = req.user!;
    const teacher = database.teacherProfiles.find((t) => t.userId === user.id);
    if (!teacher) {
      return res.status(403).json({ success: false, error: 'Only registered teachers can perform check-out.' });
    }

    const now = new Date();
    const today = now.toISOString().split('T')[0];
    const currentTime = now.toTimeString().split(' ')[0].substring(0, 5); // 'HH:MM'

    if (!database.teacherAttendanceRecords) {
      database.teacherAttendanceRecords = [];
    }

    const record = database.teacherAttendanceRecords.find(
      (r) => r.teacherProfileId === teacher.id && r.date === today && !r.isDeleted
    );

    if (!record) {
      return res.status(400).json({
        success: false,
        error: 'No check-in record found for today. Please check in first.'
      });
    }

    record.checkOutTime = currentTime;
    record.updatedAt = new Date().toISOString();
    record.updatedBy = user.id;

    logAudit({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action: 'CHECK_OUT',
      entityType: 'TEACHER_ATTENDANCE',
      entityId: record.id,
      details: `Teacher ${user.name} checked out at ${currentTime}.`,
      metadata: {
        teacherName: user.name,
        checkOutTime: currentTime
      }
    });

    res.json({
      success: true,
      message: `Checked out successfully at ${currentTime}.`,
      data: record
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// =========================================================================
// PART 8E: ATTENDANCE REPORTS & ANALYTICS API ENDPOINTS
// =========================================================================

/**
 * GET /api/attendance/reports/dashboard
 * Aggregates high-level metrics for dashboard cards, charts, and trends.
 */
attendanceRouter.get('/reports/dashboard', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const user = req.user!;
    if (user.role !== 'SUPER_ADMIN' && user.role !== 'TEACHER') {
      return res.status(403).json({ success: false, error: 'Access denied. Authorized personnel only.' });
    }

    const { isAdmin, assignedClassIds, teacherProfile } = getTeacherContext(req);
    const { academicSessionId, date, startDate, endDate, month, classId, sectionId } = req.query;

    const targetSessionId = (academicSessionId as string) || database.schoolSettings.academicSessionId;
    const thresholdPercentage = database.attendanceSettings?.studentAttendance?.minimumAttendancePercentage || 75;

    // 1. Determine student scope
    let students = database.studentProfiles.filter((s) => s.status === 'active' || s.enrollmentStatus === 'active');
    if (!isAdmin) {
      students = students.filter((s) => s.classId && assignedClassIds.includes(s.classId));
    }
    if (classId) {
      students = students.filter((s) => s.classId === classId);
    }
    if (sectionId) {
      students = students.filter((s) => s.sectionId === sectionId);
    }

    const studentIds = new Set(students.map((s) => s.id));

    // 2. Filter attendance records
    let records = (database.attendanceRecords || []).filter((r) => !r.isDeleted);
    if (!isAdmin) {
      records = records.filter((r) => r.classId && assignedClassIds.includes(r.classId));
    }
    if (classId) {
      records = records.filter((r) => r.classId === classId);
    }
    if (sectionId) {
      records = records.filter((r) => r.sectionId === sectionId);
    }

    // Filter by date / range / month
    if (date) {
      records = records.filter((r) => r.date === date);
    } else if (startDate && endDate) {
      records = records.filter((r) => r.date >= (startDate as string) && r.date <= (endDate as string));
    } else if (month) {
      records = records.filter((r) => r.date.startsWith(month as string));
    }

    // 3. Compute student attendance counts
    let presentCount = 0;
    let absentCount = 0;
    let lateCount = 0;
    let halfDayCount = 0;
    let excusedCount = 0;
    let onLeaveCount = 0;

    records.forEach((r) => {
      if (r.status === 'PRESENT') presentCount++;
      else if (r.status === 'ABSENT') absentCount++;
      else if (r.status === 'LATE') lateCount++;
      else if (r.status === 'HALF_DAY') halfDayCount++;
      else if (r.status === 'EXCUSED') excusedCount++;
      else if (r.status === 'LEAVE') onLeaveCount++;
    });

    const totalRecords = presentCount + absentCount + lateCount + halfDayCount + excusedCount + onLeaveCount;
    const averageAttendancePercentage = totalRecords > 0
      ? Math.round(((presentCount + lateCount + (halfDayCount * 0.5)) / totalRecords) * 1000) / 10
      : 0;

    // 4. Students below threshold (< thresholdPercentage)
    // Calculate for all enrolled students across all records in the session
    const allSessionRecords = (database.attendanceRecords || []).filter((r) => !r.isDeleted);
    const studentsBelowThreshold: Array<{
      studentId: string;
      studentName: string;
      rollNumber?: string;
      admissionNumber?: string;
      className: string;
      sectionName: string;
      percentage: number;
      present: number;
      absent: number;
      totalWorkingDays: number;
    }> = [];

    students.forEach((stud) => {
      const studRecords = allSessionRecords.filter((r) => r.studentId === stud.id);
      if (studRecords.length > 0) {
        let p = 0;
        let a = 0;
        let l = 0;
        let hd = 0;
        studRecords.forEach((r) => {
          if (r.status === 'PRESENT') p++;
          else if (r.status === 'ABSENT') a++;
          else if (r.status === 'LATE') l++;
          else if (r.status === 'HALF_DAY') hd++;
        });
        const totalStudRecs = studRecords.length;
        const rate = Math.round(((p + l + (hd * 0.5)) / totalStudRecs) * 1000) / 10;
        if (rate < thresholdPercentage) {
          const cls = database.classes.find((c) => c.id === stud.classId);
          const sec = database.sections.find((s) => s.id === stud.sectionId);
          const usr = database.users.find((u) => u.id === stud.userId);
          studentsBelowThreshold.push({
            studentId: stud.id,
            studentName: usr?.name || 'Student',
            rollNumber: stud.rollNumber,
            admissionNumber: stud.admissionNumber,
            className: cls?.name || 'Class',
            sectionName: sec?.name || 'Section',
            percentage: rate,
            present: p,
            absent: a,
            totalWorkingDays: totalStudRecs
          });
        }
      }
    });

    // 5. Daily trend (past 14-30 dates or filtered dates)
    const dateMap = new Map<string, { present: number; absent: number; late: number; halfDay: number; leave: number }>();
    const allDates = Array.from(new Set(records.map((r) => r.date))).sort();
    allDates.forEach((d) => {
      dateMap.set(d, { present: 0, absent: 0, late: 0, halfDay: 0, leave: 0 });
    });

    records.forEach((r) => {
      const entry = dateMap.get(r.date);
      if (entry) {
        if (r.status === 'PRESENT') entry.present++;
        else if (r.status === 'ABSENT') entry.absent++;
        else if (r.status === 'LATE') entry.late++;
        else if (r.status === 'HALF_DAY') entry.halfDay++;
        else if (r.status === 'LEAVE') entry.leave++;
      }
    });

    const dayLabels = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const dailyTrends = Array.from(dateMap.entries()).map(([d, counts]) => {
      const [yr, mo, dy] = d.split('-').map(Number);
      const dObj = new Date(yr, mo - 1, dy);
      const total = counts.present + counts.absent + counts.late + counts.halfDay + counts.leave;
      const pct = total > 0 ? Math.round(((counts.present + counts.late + (counts.halfDay * 0.5)) / total) * 1000) / 10 : 0;
      return {
        date: d,
        dayName: dayLabels[dObj.getDay()],
        ...counts,
        total,
        percentage: pct,
        attendancePercentage: pct
      };
    });

    // 6. Monthly trend
    const monthMap = new Map<string, { present: number; absent: number; late: number; halfDay: number; leave: number }>();
    records.forEach((r) => {
      const m = r.date.substring(0, 7);
      if (!monthMap.has(m)) {
        monthMap.set(m, { present: 0, absent: 0, late: 0, halfDay: 0, leave: 0 });
      }
      const entry = monthMap.get(m)!;
      if (r.status === 'PRESENT') entry.present++;
      else if (r.status === 'ABSENT') entry.absent++;
      else if (r.status === 'LATE') entry.late++;
      else if (r.status === 'HALF_DAY') entry.halfDay++;
      else if (r.status === 'LEAVE') entry.leave++;
    });

    const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const monthlyTrends = Array.from(monthMap.entries()).sort(([a], [b]) => a.localeCompare(b)).map(([m, counts]) => {
      const [yr, mo] = m.split('-').map(Number);
      const total = counts.present + counts.absent + counts.late + counts.halfDay + counts.leave;
      const pct = total > 0 ? Math.round(((counts.present + counts.late + (counts.halfDay * 0.5)) / total) * 1000) / 10 : 0;
      return {
        month: m,
        monthName: `${monthNames[mo - 1]} ${yr}`,
        ...counts,
        percentage: pct
      };
    });

    // 7. Class-wise percentages
    const classMap = new Map<string, { className: string; present: number; absent: number; late: number; halfDay: number; total: number }>();
    records.forEach((r) => {
      if (!classMap.has(r.classId)) {
        classMap.set(r.classId, {
          className: r.className || 'Class',
          present: 0,
          absent: 0,
          late: 0,
          halfDay: 0,
          total: 0
        });
      }
      const item = classMap.get(r.classId)!;
      item.total++;
      if (r.status === 'PRESENT') item.present++;
      else if (r.status === 'ABSENT') item.absent++;
      else if (r.status === 'LATE') item.late++;
      else if (r.status === 'HALF_DAY') item.halfDay++;
    });

    const classPercentages = Array.from(classMap.entries()).map(([cid, data]) => ({
      classId: cid,
      className: data.className,
      percentage: data.total > 0 ? Math.round(((data.present + data.late + (data.halfDay * 0.5)) / data.total) * 1000) / 10 : 0,
      present: data.present,
      absent: data.absent,
      total: data.total
    }));

    // 8. Leave distribution (Approved leaves)
    const approvedLeaves = (database.leaveApplications || []).filter(
      (l) => l.status === 'APPROVED' && (!academicSessionId || l.academicSessionId === targetSessionId)
    );
    const leaveDistMap = new Map<string, { leaveTypeName: string; count: number; totalDays: number }>();
    approvedLeaves.forEach((l) => {
      if (!leaveDistMap.has(l.leaveTypeId)) {
        leaveDistMap.set(l.leaveTypeId, {
          leaveTypeName: l.leaveTypeName || 'Leave',
          count: 0,
          totalDays: 0
        });
      }
      const item = leaveDistMap.get(l.leaveTypeId)!;
      item.count++;
      item.totalDays += l.workingDays || l.totalDays || 1;
    });

    const leaveDistribution = Array.from(leaveDistMap.entries()).map(([tid, data]) => ({
      leaveTypeId: tid,
      ...data
    }));

    // 9. Teacher stats
    let teacherStats = {
      totalTeachers: database.teacherProfiles.length,
      present: 0,
      absent: 0,
      late: 0,
      onLeave: 0,
      halfDay: 0,
      averageAttendancePercentage: 0
    };

    if (isAdmin) {
      let tRecords = (database.teacherAttendanceRecords || []).filter((r) => !r.isDeleted);
      if (date) {
        tRecords = tRecords.filter((r) => r.date === date);
      } else if (startDate && endDate) {
        tRecords = tRecords.filter((r) => r.date >= (startDate as string) && r.date <= (endDate as string));
      } else if (month) {
        tRecords = tRecords.filter((r) => r.date.startsWith(month as string));
      }

      let tp = 0;
      let ta = 0;
      let tl = 0;
      let thd = 0;
      let tlev = 0;
      tRecords.forEach((r) => {
        if (r.status === 'PRESENT') tp++;
        else if (r.status === 'ABSENT') ta++;
        else if (r.status === 'LATE') tl++;
        else if (r.status === 'HALF_DAY') thd++;
        else if (r.status === 'LEAVE') tlev++;
      });
      const tTotal = tp + ta + tl + thd + tlev;
      teacherStats = {
        totalTeachers: database.teacherProfiles.length,
        present: tp,
        absent: ta,
        late: tl,
        onLeave: tlev,
        halfDay: thd,
        averageAttendancePercentage: tTotal > 0 ? Math.round(((tp + tl + (thd * 0.5)) / tTotal) * 1000) / 10 : 0
      };
    } else if (teacherProfile) {
      // Teacher sees only their own attendance
      const tRecords = (database.teacherAttendanceRecords || []).filter(
        (r) => r.teacherProfileId === teacherProfile.id && !r.isDeleted
      );
      let tp = 0;
      let ta = 0;
      let tl = 0;
      let thd = 0;
      let tlev = 0;
      tRecords.forEach((r) => {
        if (r.status === 'PRESENT') tp++;
        else if (r.status === 'ABSENT') ta++;
        else if (r.status === 'LATE') tl++;
        else if (r.status === 'HALF_DAY') thd++;
        else if (r.status === 'LEAVE') tlev++;
      });
      const tTotal = tp + ta + tl + thd + tlev;
      teacherStats = {
        totalTeachers: 1,
        present: tp,
        absent: ta,
        late: tl,
        onLeave: tlev,
        halfDay: thd,
        averageAttendancePercentage: tTotal > 0 ? Math.round(((tp + tl + (thd * 0.5)) / tTotal) * 1000) / 10 : 0
      };
    }

    res.json({
      success: true,
      data: {
        summary: {
          attendancePercentage: averageAttendancePercentage,
          totalStudents: students.length,
          totalPresent: presentCount,
          totalAbsent: absentCount,
          totalLate: lateCount,
          totalHalfDay: halfDayCount,
          totalLeaves: onLeaveCount,
          totalExcused: excusedCount,
          totalRecords,
          defaultersCount: studentsBelowThreshold.length
        },
        studentStats: {
          totalEnrolled: students.length,
          present: presentCount,
          absent: absentCount,
          late: lateCount,
          halfDay: halfDayCount,
          excused: excusedCount,
          onLeave: onLeaveCount,
          averageAttendancePercentage,
          belowThresholdCount: studentsBelowThreshold.length,
          thresholdPercentage
        },
        classComparisons: classPercentages.map((cp) => ({
          classId: cp.classId,
          className: cp.className,
          attendancePercentage: cp.percentage,
          totalStudents: cp.total,
          totalRecords: cp.total,
          present: cp.present,
          absent: cp.absent
        })),
        statusBreakdown: {
          present: presentCount,
          absent: absentCount,
          leave: onLeaveCount,
          late: lateCount,
          halfDay: halfDayCount
        },
        teacherStats,
        dailyTrends,
        monthlyTrends,
        classPercentages,
        leaveDistribution,
        studentsBelowThreshold
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * GET /api/attendance/reports/students
 * Detailed Student-wise attendance summary report with pagination, server-side filtering, and search.
 */
attendanceRouter.get('/reports/students', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const user = req.user!;
    if (user.role !== 'SUPER_ADMIN' && user.role !== 'TEACHER') {
      return res.status(403).json({ success: false, error: 'Access denied.' });
    }

    const { isAdmin, assignedClassIds } = getTeacherContext(req);
    const {
      academicSessionId,
      classId,
      sectionId,
      studentId,
      date,
      startDate,
      endDate,
      month,
      status,
      gender,
      search,
      belowThresholdOnly,
      page = '1',
      limit = '20',
      sortBy = 'attendancePercentage',
      sortOrder = 'asc'
    } = req.query;

    const thresholdPercentage = database.attendanceSettings?.studentAttendance?.minimumAttendancePercentage || 75;

    // Filter students
    let students = database.studentProfiles.filter((s) => s.status === 'active' || s.enrollmentStatus === 'active');
    if (!isAdmin) {
      students = students.filter((s) => s.classId && assignedClassIds.includes(s.classId));
    }
    if (classId) {
      students = students.filter((s) => s.classId === classId);
    }
    if (sectionId) {
      students = students.filter((s) => s.sectionId === sectionId);
    }
    if (studentId) {
      students = students.filter((s) => s.id === studentId);
    }
    if (gender) {
      students = students.filter((s) => s.gender?.toLowerCase() === (gender as string).toLowerCase());
    }

    // Filter attendance records
    let records = (database.attendanceRecords || []).filter((r) => !r.isDeleted);
    if (date) {
      records = records.filter((r) => r.date === date);
    } else if (startDate && endDate) {
      records = records.filter((r) => r.date >= (startDate as string) && r.date <= (endDate as string));
    } else if (month) {
      records = records.filter((r) => r.date.startsWith(month as string));
    }

    // Calculate metrics for each student
    const resultItems: any[] = [];

    students.forEach((stud) => {
      const userObj = database.users.find((u) => u.id === stud.userId);
      const studentName = userObj?.name || 'Student';
      const cls = database.classes.find((c) => c.id === stud.classId);
      const sec = database.sections.find((s) => s.id === stud.sectionId);

      const studRecs = records.filter((r) => r.studentId === stud.id);
      let presentDays = 0;
      let absentDays = 0;
      let lateDays = 0;
      let halfDays = 0;
      let excusedDays = 0;
      let approvedLeaveDays = 0;

      studRecs.forEach((r) => {
        if (r.status === 'PRESENT') presentDays++;
        else if (r.status === 'ABSENT') absentDays++;
        else if (r.status === 'LATE') lateDays++;
        else if (r.status === 'HALF_DAY') halfDays++;
        else if (r.status === 'EXCUSED') excusedDays++;
        else if (r.status === 'LEAVE') approvedLeaveDays++;
      });

      const totalWorkingDays = studRecs.length;
      const attendancePercentage = totalWorkingDays > 0
        ? Math.round(((presentDays + lateDays + (halfDays * 0.5)) / totalWorkingDays) * 1000) / 10
        : 0;

      const isBelowThreshold = attendancePercentage < thresholdPercentage;

      // Filter by status if specified
      if (status && status !== 'ALL') {
        if (status === 'PRESENT' && presentDays === 0) return;
        if (status === 'ABSENT' && absentDays === 0) return;
        if (status === 'LATE' && lateDays === 0) return;
        if (status === 'HALF_DAY' && halfDays === 0) return;
        if (status === 'EXCUSED' && excusedDays === 0) return;
        if (status === 'LEAVE' && approvedLeaveDays === 0) return;
      }

      // Filter by threshold
      if (belowThresholdOnly === 'true' && !isBelowThreshold) {
        return;
      }

      // Filter by search
      if (search) {
        const q = (search as string).toLowerCase();
        const matches =
          studentName.toLowerCase().includes(q) ||
          (stud.admissionNumber && stud.admissionNumber.toLowerCase().includes(q)) ||
          (stud.rollNumber && stud.rollNumber.toLowerCase().includes(q)) ||
          (cls?.name && cls.name.toLowerCase().includes(q));
        if (!matches) return;
      }

      resultItems.push({
        studentId: stud.id,
        studentName,
        admissionNumber: stud.admissionNumber || 'N/A',
        rollNumber: stud.rollNumber || 'N/A',
        gender: stud.gender,
        classId: stud.classId,
        className: cls?.name || 'Class',
        sectionId: stud.sectionId,
        sectionName: sec?.name || 'Section',
        academicSessionId: stud.academicSessionId,
        academicSessionName: '2026-2027 Academic Year',
        totalWorkingDays,
        presentDays,
        absentDays,
        lateDays,
        halfDays,
        excusedDays,
        approvedLeaveDays,
        attendancePercentage,
        isBelowThreshold
      });
    });

    // Sorting
    resultItems.sort((a, b) => {
      let fieldA = a[sortBy as string];
      let fieldB = b[sortBy as string];
      if (typeof fieldA === 'string') fieldA = fieldA.toLowerCase();
      if (typeof fieldB === 'string') fieldB = fieldB.toLowerCase();
      if (fieldA < fieldB) return sortOrder === 'asc' ? -1 : 1;
      if (fieldA > fieldB) return sortOrder === 'asc' ? 1 : -1;
      return 0;
    });

    // Pagination
    const pageNum = parseInt(page as string, 10) || 1;
    const limitNum = parseInt(limit as string, 10) || 20;
    const total = resultItems.length;
    const totalPages = Math.ceil(total / limitNum) || 1;
    const startIndex = (pageNum - 1) * limitNum;
    const paginatedItems = resultItems.slice(startIndex, startIndex + limitNum);

    res.json({
      success: true,
      data: paginatedItems,
      pagination: {
        total,
        page: pageNum,
        limit: limitNum,
        totalPages
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * GET /api/attendance/reports/classes
 * Class-wise & Section-wise attendance aggregated breakdown.
 */
attendanceRouter.get('/reports/classes', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const user = req.user!;
    if (user.role !== 'SUPER_ADMIN' && user.role !== 'TEACHER') {
      return res.status(403).json({ success: false, error: 'Access denied.' });
    }

    const { isAdmin, assignedClassIds } = getTeacherContext(req);
    const { academicSessionId, classId, sectionId, date, startDate, endDate, month } = req.query;

    let targetClasses = database.classes;
    if (!isAdmin) {
      targetClasses = targetClasses.filter((c) => assignedClassIds.includes(c.id));
    }
    if (classId) {
      targetClasses = targetClasses.filter((c) => c.id === classId);
    }

    // Filter attendance records
    let records = (database.attendanceRecords || []).filter((r) => !r.isDeleted);
    if (date) {
      records = records.filter((r) => r.date === date);
    } else if (startDate && endDate) {
      records = records.filter((r) => r.date >= (startDate as string) && r.date <= (endDate as string));
    } else if (month) {
      records = records.filter((r) => r.date.startsWith(month as string));
    }

    const resultItems: any[] = [];

    targetClasses.forEach((cls) => {
      const classSections = database.sections.filter((s) => s.classId === cls.id);
      const sectionsToProcess = sectionId
        ? classSections.filter((s) => s.id === sectionId)
        : classSections;

      sectionsToProcess.forEach((sec) => {
        const classTeacher = database.teacherProfiles.find((t) => t.id === sec.classTeacherId);
        const classTeacherUser = classTeacher ? database.users.find((u) => u.id === classTeacher.userId) : null;

        const enrolledStudents = database.studentProfiles.filter(
          (s) => s.classId === cls.id && s.sectionId === sec.id && (s.status === 'active' || s.enrollmentStatus === 'active')
        );

        const secRecords = records.filter((r) => r.classId === cls.id && r.sectionId === sec.id);

        let present = 0;
        let absent = 0;
        let late = 0;
        let halfDay = 0;
        let excused = 0;
        let leave = 0;

        secRecords.forEach((r) => {
          if (r.status === 'PRESENT') present++;
          else if (r.status === 'ABSENT') absent++;
          else if (r.status === 'LATE') late++;
          else if (r.status === 'HALF_DAY') halfDay++;
          else if (r.status === 'EXCUSED') excused++;
          else if (r.status === 'LEAVE') leave++;
        });

        const totalRecords = secRecords.length;
        const averageAttendancePercentage = totalRecords > 0
          ? Math.round(((present + late + (halfDay * 0.5)) / totalRecords) * 1000) / 10
          : 0;

        resultItems.push({
          classId: cls.id,
          className: cls.name,
          sectionId: sec.id,
          sectionName: sec.name,
          classTeacherName: classTeacherUser?.name || 'Unassigned',
          totalStudents: enrolledStudents.length,
          present,
          absent,
          late,
          halfDay,
          excused,
          leave,
          totalRecords,
          averageAttendancePercentage,
          attendancePercentage: averageAttendancePercentage
        });
      });
    });

    res.json({
      success: true,
      data: resultItems
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * GET /api/attendance/reports/records
 * Raw detailed attendance records with filtering, searching, and pagination.
 * Supports Daily Report, Date Range Report, Absent Report, Late Report, Half-day Report, Excused Report.
 */
attendanceRouter.get('/reports/records', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const user = req.user!;
    if (user.role !== 'SUPER_ADMIN' && user.role !== 'TEACHER') {
      return res.status(403).json({ success: false, error: 'Access denied.' });
    }

    const { isAdmin, assignedClassIds } = getTeacherContext(req);
    const {
      academicSessionId,
      classId,
      sectionId,
      studentId,
      date,
      startDate,
      endDate,
      month,
      status,
      search,
      page = '1',
      limit = '25'
    } = req.query;

    let records = (database.attendanceRecords || []).filter((r) => !r.isDeleted);

    if (!isAdmin) {
      records = records.filter((r) => r.classId && assignedClassIds.includes(r.classId));
    }
    if (classId) {
      records = records.filter((r) => r.classId === classId);
    }
    if (sectionId) {
      records = records.filter((r) => r.sectionId === sectionId);
    }
    if (studentId) {
      records = records.filter((r) => r.studentId === studentId);
    }

    if (date) {
      records = records.filter((r) => r.date === date);
    } else if (startDate && endDate) {
      records = records.filter((r) => r.date >= (startDate as string) && r.date <= (endDate as string));
    } else if (month) {
      records = records.filter((r) => r.date.startsWith(month as string));
    }

    if (status && status !== 'ALL') {
      records = records.filter((r) => r.status === status);
    }

    if (search) {
      const q = (search as string).toLowerCase();
      records = records.filter(
        (r) =>
          (r.studentName && r.studentName.toLowerCase().includes(q)) ||
          (r.admissionNumber && r.admissionNumber.toLowerCase().includes(q)) ||
          (r.rollNumber && r.rollNumber.toLowerCase().includes(q)) ||
          (r.remarks && r.remarks.toLowerCase().includes(q))
      );
    }

    // Sort by date descending, then class, then rollNumber
    records.sort((a, b) => b.date.localeCompare(a.date));

    // Pagination
    const pageNum = parseInt(page as string, 10) || 1;
    const limitNum = parseInt(limit as string, 10) || 25;
    const total = records.length;
    const totalPages = Math.ceil(total / limitNum) || 1;
    const startIndex = (pageNum - 1) * limitNum;
    const paginatedItems = records.slice(startIndex, startIndex + limitNum).map((r) => ({
      id: r.id,
      date: r.date,
      studentId: r.studentId,
      studentName: r.studentName,
      admissionNumber: r.admissionNumber,
      rollNumber: r.rollNumber,
      classId: r.classId,
      className: r.className,
      sectionId: r.sectionId,
      sectionName: r.sectionName,
      status: r.status,
      remarks: r.remarks,
      recordedByTeacherName: r.recordedByTeacherName || 'Class Teacher',
      updatedByTeacherName: r.updatedByTeacherName,
      isOverridden: r.isOverridden,
      overrideReason: r.overrideReason,
      correctionHistoryCount: r.correctionHistory?.length || 0
    }));

    res.json({
      success: true,
      data: paginatedItems,
      pagination: {
        total,
        page: pageNum,
        limit: limitNum,
        totalPages
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * GET /api/attendance/reports/teachers
 * Teacher attendance summary and history reports.
 * RBAC: Super Admin gets all teachers; Teacher gets only own profile.
 */
attendanceRouter.get('/reports/teachers', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const user = req.user!;
    if (user.role !== 'SUPER_ADMIN' && user.role !== 'TEACHER') {
      return res.status(403).json({ success: false, error: 'Access denied.' });
    }

    const { isAdmin, teacherProfile } = getTeacherContext(req);
    const {
      academicSessionId,
      departmentId,
      teacherProfileId,
      date,
      startDate,
      endDate,
      month,
      status,
      search,
      page = '1',
      limit = '20'
    } = req.query;

    let teachers = database.teacherProfiles;
    if (!isAdmin) {
      if (!teacherProfile) {
        return res.status(403).json({ success: false, error: 'Teacher profile not linked.' });
      }
      teachers = teachers.filter((t) => t.id === teacherProfile.id);
    } else if (teacherProfileId) {
      teachers = teachers.filter((t) => t.id === teacherProfileId);
    }

    if (departmentId) {
      teachers = teachers.filter((t) => t.departmentId === departmentId);
    }

    // Filter teacher records
    let records = (database.teacherAttendanceRecords || []).filter((r) => !r.isDeleted);
    if (!isAdmin && teacherProfile) {
      records = records.filter((r) => r.teacherProfileId === teacherProfile.id);
    }
    if (date) {
      records = records.filter((r) => r.date === date);
    } else if (startDate && endDate) {
      records = records.filter((r) => r.date >= (startDate as string) && r.date <= (endDate as string));
    } else if (month) {
      records = records.filter((r) => r.date.startsWith(month as string));
    }

    const resultItems: any[] = [];

    teachers.forEach((t) => {
      const userObj = database.users.find((u) => u.id === t.userId);
      const teacherName = userObj?.name || 'Faculty Member';
      const dept = database.departments.find((d) => d.id === t.departmentId);

      const tRecs = records.filter((r) => r.teacherProfileId === t.id);

      let present = 0;
      let absent = 0;
      let late = 0;
      let halfDay = 0;
      let leave = 0;
      let excused = 0;

      tRecs.forEach((r) => {
        if (r.status === 'PRESENT') present++;
        else if (r.status === 'ABSENT') absent++;
        else if (r.status === 'LATE') late++;
        else if (r.status === 'HALF_DAY') halfDay++;
        else if (r.status === 'LEAVE') leave++;
      });

      const totalWorkingDays = tRecs.length;
      const attendancePercentage = totalWorkingDays > 0
        ? Math.round(((present + late + (halfDay * 0.5)) / totalWorkingDays) * 1000) / 10
        : 0;

      if (status && status !== 'ALL') {
        if (status === 'PRESENT' && present === 0) return;
        if (status === 'ABSENT' && absent === 0) return;
        if (status === 'LATE' && late === 0) return;
        if (status === 'HALF_DAY' && halfDay === 0) return;
        if (status === 'LEAVE' && leave === 0) return;
      }

      if (search) {
        const q = (search as string).toLowerCase();
        const matches =
          teacherName.toLowerCase().includes(q) ||
          (t.employeeCode && t.employeeCode.toLowerCase().includes(q)) ||
          (dept?.name && dept.name.toLowerCase().includes(q));
        if (!matches) return;
      }

      resultItems.push({
        teacherProfileId: t.id,
        teacherName,
        employeeCode: t.employeeCode || 'N/A',
        departmentId: t.departmentId,
        departmentName: dept?.name || 'Academic Faculty',
        designation: t.designation || 'Teacher',
        totalWorkingDays,
        present,
        absent,
        late,
        halfDay,
        leave,
        excused,
        attendancePercentage
      });
    });

    const pageNum = parseInt(page as string, 10) || 1;
    const limitNum = parseInt(limit as string, 10) || 20;
    const total = resultItems.length;
    const totalPages = Math.ceil(total / limitNum) || 1;
    const startIndex = (pageNum - 1) * limitNum;
    const paginatedItems = resultItems.slice(startIndex, startIndex + limitNum);

    res.json({
      success: true,
      data: paginatedItems,
      pagination: {
        total,
        page: pageNum,
        limit: limitNum,
        totalPages
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * GET /api/attendance/reports/leaves
 * Leave applications reporting with applicant filters, status filters, and working days verification.
 */
attendanceRouter.get('/reports/leaves', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const user = req.user!;
    if (user.role !== 'SUPER_ADMIN' && user.role !== 'TEACHER') {
      return res.status(403).json({ success: false, error: 'Access denied.' });
    }

    const { isAdmin, assignedClassIds, teacherProfile } = getTeacherContext(req);
    const {
      applicantType,
      status,
      leaveTypeId,
      classId,
      sectionId,
      startDate,
      endDate,
      search,
      page = '1',
      limit = '20'
    } = req.query;

    let leaves = (database.leaveApplications || []).filter((l) => !l.isDeleted);

    // RBAC:
    if (!isAdmin) {
      leaves = leaves.filter((l) => {
        if (l.applicantType === 'TEACHER') {
          return teacherProfile && l.applicantId === teacherProfile.id;
        }
        if (l.applicantType === 'STUDENT') {
          return l.classId && assignedClassIds.includes(l.classId);
        }
        return false;
      });
    }

    if (applicantType && applicantType !== 'ALL') {
      leaves = leaves.filter((l) => l.applicantType === applicantType);
    }

    if (status && status !== 'ALL') {
      leaves = leaves.filter((l) => l.status === status);
    }

    if (leaveTypeId) {
      leaves = leaves.filter((l) => l.leaveTypeId === leaveTypeId);
    }

    if (classId) {
      leaves = leaves.filter((l) => l.classId === classId);
    }

    if (sectionId) {
      leaves = leaves.filter((l) => l.sectionId === sectionId);
    }

    if (startDate && endDate) {
      leaves = leaves.filter(
        (l) => l.startDate <= (endDate as string) && l.endDate >= (startDate as string)
      );
    }

    if (search) {
      const q = (search as string).toLowerCase();
      leaves = leaves.filter(
        (l) =>
          (l.applicantName && l.applicantName.toLowerCase().includes(q)) ||
          (l.reason && l.reason.toLowerCase().includes(q)) ||
          (l.leaveTypeName && l.leaveTypeName.toLowerCase().includes(q))
      );
    }

    leaves.sort((a, b) => {
      const dateA = a.appliedAt || a.submittedAt || a.startDate || '';
      const dateB = b.appliedAt || b.submittedAt || b.startDate || '';
      return dateB.localeCompare(dateA);
    });

    const pageNum = parseInt(page as string, 10) || 1;
    const limitNum = parseInt(limit as string, 10) || 20;
    const total = leaves.length;
    const totalPages = Math.ceil(total / limitNum) || 1;
    const startIndex = (pageNum - 1) * limitNum;
    const paginatedItems = leaves.slice(startIndex, startIndex + limitNum).map((l) => ({
      id: l.id,
      applicantType: l.applicantType,
      applicantId: l.applicantId,
      applicantName: l.applicantName,
      details: l.className ? `${l.className} - ${l.sectionName}` : 'Staff Faculty',
      leaveTypeId: l.leaveTypeId,
      leaveTypeName: l.leaveTypeName,
      startDate: l.startDate,
      endDate: l.endDate,
      totalDays: l.totalDays,
      workingDays: l.workingDays || l.totalDays,
      reason: l.reason,
      status: l.status,
      appliedAt: l.appliedAt || l.submittedAt || l.startDate,
      reviewedBy: l.reviewedByName || l.reviewedByTeacherName || '—',
      reviewedAt: l.reviewedAt,
      reviewNotes: l.adminRemarks || l.rejectionReason || l.reviewNotes || ''
    }));

    res.json({
      success: true,
      data: paginatedItems,
      pagination: {
        total,
        page: pageNum,
        limit: limitNum,
        totalPages
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * POST /api/attendance/reports/audit-export
 * Audit trail logging when reports are exported (CSV, Print, PDF).
 */
attendanceRouter.post('/reports/audit-export', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  try {
    const user = req.user!;
    const { reportType, format, filters, recordCount } = req.body;

    logAudit({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action: 'EXPORT_REPORT',
      entityType: 'ATTENDANCE_REPORT',
      entityId: reportType || 'ATTENDANCE',
      details: `${user.name} exported ${reportType || 'Attendance'} report in ${format || 'CSV'} format (${recordCount || 0} records).`,
      metadata: {
        reportType,
        format,
        filters,
        recordCount,
        timestamp: new Date().toISOString()
      }
    });

    res.json({
      success: true,
      message: 'Export logged in audit trail.'
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});


