/**
 * Issue, Return & Department Allocation Routes (Part 14E)
 * Sygmate School Management System
 */

import { Router, Response } from 'express';
import { requireAuth, requirePermission, AuthenticatedRequest } from '../security/auth.js';
import { IssueService } from '../services/issue.service.js';
import { database } from '../db/database.js';
import { ensureInventoryCollections } from './inventory.routes.js';

export const issueRouter = Router();

/**
 * Resolves authoritative schoolId from database settings.
 * Strictly avoids trusting schoolId from request parameters or payload.
 */
function resolveSchoolId(req: AuthenticatedRequest): string {
  if (req?.tenant?.schoolId) return req.tenant.schoolId;
  if (req?.user?.schoolId) return req.user.schoolId;
  return database.schoolSettings?.id || 'school-main';
}

// ============================================================================
// ISSUE REQUESTS ENDPOINTS
// ============================================================================

/**
 * GET /api/inventory/issues/requests
 * List issue requests with multifaceted filters
 */
issueRouter.get(
  '/requests',
  requireAuth,
  requirePermission('inventory.issues.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = resolveSchoolId(req);
      const result = IssueService.getIssueRequests(schoolId, {
        search: req.query.search as string,
        status: req.query.status as any,
        departmentId: req.query.departmentId as string,
        recipientId: req.query.recipientId as string,
        sourceLocationId: req.query.sourceLocationId as string,
        page: req.query.page ? parseInt(req.query.page as string, 10) : 1,
        limit: req.query.limit ? parseInt(req.query.limit as string, 10) : 20
      });
      res.json({ success: true, ...result });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to fetch issue requests' });
    }
  }
);

/**
 * GET /api/inventory/issues/requests/:id
 * Retrieve single issue request by ID
 */
issueRouter.get(
  '/requests/:id',
  requireAuth,
  requirePermission('inventory.issues.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = resolveSchoolId(req);
      const request = IssueService.getIssueRequestById(schoolId, req.params.id);
      res.json({ success: true, data: request });
    } catch (error: any) {
      res.status(404).json({ success: false, error: error.message || 'Issue request not found' });
    }
  }
);

/**
 * POST /api/inventory/issues/requests
 * Create new issue request
 */
issueRouter.post(
  '/requests',
  requireAuth,
  requirePermission('inventory.issues.create'),
  async (req: AuthenticatedRequest, res: Response): Promise<void> => {
    try {
      const schoolId = resolveSchoolId(req);
      const request = await IssueService.createIssueRequest(schoolId, req.body, req.user);
      res.status(201).json({
        success: true,
        data: request,
        message: `Issue request ${request.requestNumber} submitted successfully.`
      });
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message || 'Failed to create issue request' });
    }
  }
);

/**
 * POST /api/inventory/issues/requests/:id/review
 * Approve or reject issue request
 */
issueRouter.post(
  '/requests/:id/review',
  requireAuth,
  requirePermission('inventory.issues.approve'),
  async (req: AuthenticatedRequest, res: Response): Promise<void> => {
    try {
      const schoolId = resolveSchoolId(req);
      const request = await IssueService.reviewIssueRequest(schoolId, req.params.id, req.body, req.user);
      res.json({
        success: true,
        data: request,
        message: `Issue request ${request.requestNumber} has been ${request.status.toLowerCase()}.`
      });
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message || 'Failed to review issue request' });
    }
  }
);

// ============================================================================
// STOCK ISSUE EXECUTION (Deducts Stock Atomically)
// ============================================================================

/**
 * GET /api/inventory/issues
 * List executed stock issues
 */
issueRouter.get(
  '/',
  requireAuth,
  requirePermission('inventory.issues.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = resolveSchoolId(req);
      const result = IssueService.getStockIssues(schoolId, {
        search: req.query.search as string,
        recipientId: req.query.recipientId as string,
        departmentId: req.query.departmentId as string,
        locationId: req.query.locationId as string,
        status: req.query.status as string,
        page: req.query.page ? parseInt(req.query.page as string, 10) : 1,
        limit: req.query.limit ? parseInt(req.query.limit as string, 10) : 20
      });
      res.json({ success: true, ...result });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to fetch stock issues' });
    }
  }
);

/**
 * POST /api/inventory/issues/execute
 * Execute stock issue and atomically deduct stock balance
 */
issueRouter.post(
  '/execute',
  requireAuth,
  requirePermission('inventory.issues.execute'),
  async (req: AuthenticatedRequest, res: Response): Promise<void> => {
    try {
      const schoolId = resolveSchoolId(req);
      const issue = await IssueService.executeStockIssue(schoolId, req.body, req.user);
      res.status(201).json({
        success: true,
        data: issue,
        message: `Stock successfully dispatched under Issue #${issue.issueNumber}.`
      });
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message || 'Failed to execute stock issue' });
    }
  }
);

// ============================================================================
// INVENTORY RETURNS (Restores Stock Atomically)
// ============================================================================

/**
 * GET /api/inventory/issues/returns
 * List inventory returns
 */
issueRouter.get(
  '/returns',
  requireAuth,
  requirePermission('inventory.returns.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = resolveSchoolId(req);
      const result = IssueService.getInventoryReturns(schoolId, {
        search: req.query.search as string,
        returnedById: req.query.returnedById as string,
        departmentId: req.query.departmentId as string,
        locationId: req.query.locationId as string,
        page: req.query.page ? parseInt(req.query.page as string, 10) : 1,
        limit: req.query.limit ? parseInt(req.query.limit as string, 10) : 20
      });
      res.json({ success: true, ...result });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to fetch inventory returns' });
    }
  }
);

/**
 * POST /api/inventory/issues/returns
 * Record inventory return
 */
issueRouter.post(
  '/returns',
  requireAuth,
  requirePermission('inventory.returns.create'),
  async (req: AuthenticatedRequest, res: Response): Promise<void> => {
    try {
      const schoolId = resolveSchoolId(req);
      const invReturn = await IssueService.createInventoryReturn(schoolId, req.body, req.user);
      res.status(201).json({
        success: true,
        data: invReturn,
        message: `Inventory Return ${invReturn.returnNumber} processed successfully.`
      });
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message || 'Failed to process inventory return' });
    }
  }
);

// ============================================================================
// BULK ASSET ALLOCATION & DEPARTMENT ALLOCATIONS
// ============================================================================

/**
 * POST /api/inventory/issues/assets/bulk-allocate
 * Allocate multiple assets to a custodian or department
 */
issueRouter.post(
  '/assets/bulk-allocate',
  requireAuth,
  requirePermission('assets.allocation.manage'),
  async (req: AuthenticatedRequest, res: Response): Promise<void> => {
    try {
      const schoolId = resolveSchoolId(req);
      const result = await IssueService.bulkAllocateAssets(schoolId, req.body, req.user);
      res.json({
        success: true,
        data: result,
        message: `Successfully allocated ${result.assignedCount} assets to ${req.body.assigneeName}.`
      });
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message || 'Failed to allocate assets' });
    }
  }
);

/**
 * GET /api/inventory/issues/departments/summary
 * Summarize allocations by department
 */
issueRouter.get(
  '/departments/summary',
  requireAuth,
  requirePermission('inventory.issues.view'),
  (req: AuthenticatedRequest, res: Response): void => {
    try {
      const schoolId = resolveSchoolId(req);
      const summary = IssueService.getDepartmentAllocations(schoolId);
      res.json({ success: true, data: summary });
    } catch (error: any) {
      res.status(500).json({ success: false, error: error.message || 'Failed to fetch department allocation summary' });
    }
  }
);
