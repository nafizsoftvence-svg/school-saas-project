import { Router, Response } from 'express';
import crypto from 'crypto';
import { database, StoredUser } from '../db/database.js';
import {
  createSession,
  destroySession,
  requireAuth,
  AuthenticatedRequest,
  verifyPassword,
  hashPassword,
  validatePasswordStrength,
  invalidateUserSessions,
  generateSecureToken
} from '../security/auth.js';
import {
  checkLoginLockout,
  recordLoginFailure,
  clearLoginFailures,
  checkResetRateLimit,
  recordResetRequest
} from '../security/rate-limiter.js';
import { logAudit } from '../security/audit.js';
import { getDefaultRedirectForRole } from '../security/rbac.js';
import { UserRole, ParentInvitation, PasswordResetToken } from '../../src/types/index.js';
import { getUserMemberships, getUserSchools } from '../security/tenant.js';

export const authRouter = Router();

/**
 * POST /api/auth/login
 * Standard credential-based login with rate-limiting, lockout protection, and anti-enumeration
 */
authRouter.post('/login', (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { identifier, password } = req.body;
    const clientIp = (req.ip || req.socket.remoteAddress || '127.0.0.1').toString();

    if (!identifier || !password) {
      res.status(400).json({
        success: false,
        error: 'Please provide both email/username and password.',
        code: 'VALIDATION_ERROR'
      });
      return;
    }

    const trimmedIdentifier = identifier.trim().toLowerCase();

    // 1. Brute-Force Check
    const lockout = checkLoginLockout(trimmedIdentifier, clientIp);
    if (lockout.isLocked) {
      logAudit({
        userId: 'anonymous',
        userName: trimmedIdentifier,
        userRole: 'STUDENT',
        action: 'UNAUTHORIZED_ATTEMPT',
        entity: 'SESSION',
        details: `Login blocked by rate-limiter for '${trimmedIdentifier}'. Lockout remaining: ${lockout.remainingSeconds}s.`,
        ipAddress: clientIp
      });

      res.status(429).json({
        success: false,
        error: `Too many failed login attempts. For your security, this account is temporarily locked. Please try again in ${lockout.remainingSeconds} seconds.`,
        code: 'RATE_LIMITED',
        lockoutRemainingSeconds: lockout.remainingSeconds
      });
      return;
    }

    // 2. Lookup Account
    const storedUser = database.users.find(
      (u) => u.email.toLowerCase() === trimmedIdentifier || u.username.toLowerCase() === trimmedIdentifier
    );

    if (!storedUser) {
      const failInfo = recordLoginFailure(trimmedIdentifier, clientIp);
      logAudit({
        userId: 'anonymous',
        userName: trimmedIdentifier,
        userRole: 'STUDENT',
        action: 'UNAUTHORIZED_ATTEMPT',
        entity: 'SESSION',
        details: `Failed login: Identifier '${trimmedIdentifier}' not found. (${failInfo.attemptsLeft} attempts remaining)`,
        ipAddress: clientIp
      });

      // Generic error message to prevent account enumeration
      res.status(401).json({
        success: false,
        error: 'Invalid username/email or password. Please verify your credentials.',
        code: 'INVALID_CREDENTIALS',
        attemptsLeft: failInfo.attemptsLeft
      });
      return;
    }

    // 3. Lifecycle Status Verification
    const rawStatus = (storedUser.status || '').toLowerCase();
    if (rawStatus === 'invited' || rawStatus === 'pending') {
      res.status(403).json({
        success: false,
        error: 'Your account is pending activation. Please use the invitation link sent to your email to set your password and activate your account.',
        code: 'ACCOUNT_PENDING_ACTIVATION'
      });
      return;
    }

    if (rawStatus === 'disabled' || rawStatus === 'suspended' || rawStatus === 'locked' || rawStatus === 'inactive') {
      res.status(403).json({
        success: false,
        error: `Account is currently ${rawStatus}. Access is restricted. Please contact the school administration.`,
        code: 'ACCOUNT_INACTIVE'
      });
      return;
    }

    // 4. Password Verification
    const isValidPassword = verifyPassword(password, storedUser.passwordHash, storedUser.passwordSalt);

    if (!isValidPassword) {
      const failInfo = recordLoginFailure(trimmedIdentifier, clientIp);
      logAudit({
        userId: storedUser.id,
        userName: storedUser.name,
        userRole: storedUser.role,
        action: 'UNAUTHORIZED_ATTEMPT',
        entity: 'SESSION',
        details: `Failed password verification for '${storedUser.email}'. (${failInfo.attemptsLeft} attempts remaining)`,
        ipAddress: clientIp
      });

      res.status(401).json({
        success: false,
        error: 'Invalid username/email or password. Please verify your credentials.',
        code: 'INVALID_CREDENTIALS',
        attemptsLeft: failInfo.attemptsLeft
      });
      return;
    }

    // Successful login: clear brute force counter
    clearLoginFailures(trimmedIdentifier, clientIp);

    // Attach role-specific profile data
    let teacherProfile;
    let studentProfile;
    let guardianProfile;

    if (storedUser.role === 'TEACHER') {
      teacherProfile = database.teacherProfiles.find((t) => t.userId === storedUser.id);
    } else if (storedUser.role === 'STUDENT') {
      studentProfile = database.studentProfiles.find((s) => s.userId === storedUser.id);
    } else if (storedUser.role === 'GUARDIAN') {
      guardianProfile = database.guardians.find(
        (g) => g.userId === storedUser.id || g.email.toLowerCase() === storedUser.email.toLowerCase()
      );
    }

    // Strip sensitive password fields for client
    const { passwordHash, passwordSalt, ...cleanUser } = storedUser;
    cleanUser.lastLoginAt = new Date().toISOString();
    storedUser.lastLoginAt = cleanUser.lastLoginAt;

    // Multi-Tenant context resolution (Phase 1)
    const userMemberships = getUserMemberships(storedUser.id);
    const userSchools = getUserSchools(storedUser.id);
    const currentSchoolId = storedUser.schoolId || userMemberships[0]?.schoolId || 'school-main';
    const activeSchool = database.schools.find((s) => s.id === currentSchoolId) || database.schools[0];
    const schoolContext = activeSchool ? {
      id: activeSchool.id,
      name: activeSchool.name,
      code: activeSchool.code,
      plan: activeSchool.plan,
      status: activeSchool.status
    } : undefined;
    const availableSchools = userSchools.map((s) => ({
      id: s.id,
      name: s.name,
      code: s.code,
      role: storedUser.role
    }));

    cleanUser.memberships = userMemberships;
    cleanUser.schoolId = currentSchoolId;
    cleanUser.isPlatformAdmin = storedUser.role === 'SUPER_ADMIN';

    const session = createSession(cleanUser, {
      teacherProfile,
      studentProfile,
      guardianProfile,
      schoolContext,
      availableSchools
    });

    logAudit({
      userId: storedUser.id,
      userName: storedUser.name,
      userRole: storedUser.role,
      action: 'LOGIN',
      entity: 'SESSION',
      details: `Successful authentication for ${storedUser.role} role.`,
      ipAddress: clientIp
    });

    res.json({
      success: true,
      data: {
        session,
        redirectTo: getDefaultRedirectForRole(storedUser.role)
      },
      message: `Welcome back, ${storedUser.name}!`
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: 'An internal error occurred during authentication.',
      code: 'SERVER_ERROR'
    });
  }
});

/**
 * GET /api/auth/invitation/verify
 * Public endpoint to verify a parent activation invitation token
 */
authRouter.get('/invitation/verify', (req: AuthenticatedRequest, res: Response): void => {
  try {
    const token = req.query.token as string;

    if (!token || typeof token !== 'string') {
      res.status(400).json({
        success: false,
        error: 'Invitation token is required.',
        code: 'MISSING_TOKEN'
      });
      return;
    }

    const invitation = database.parentInvitations.find((inv) => inv.token === token.trim());

    if (!invitation || invitation.status === 'revoked') {
      res.status(404).json({
        success: false,
        error: 'This invitation token is invalid or has been revoked.',
        code: 'INVALID_TOKEN'
      });
      return;
    }

    if (invitation.status === 'accepted') {
      res.status(400).json({
        success: false,
        error: 'This invitation has already been accepted. Please log in with your credentials.',
        code: 'ALREADY_ACCEPTED'
      });
      return;
    }

    // Check expiry
    if (new Date(invitation.expiresAt) < new Date() || invitation.status === 'expired') {
      invitation.status = 'expired';
      res.status(410).json({
        success: false,
        error: 'This invitation has expired. Please request a new invitation from the school administration.',
        code: 'TOKEN_EXPIRED'
      });
      return;
    }

    const guardian = database.guardians.find((g) => g.id === invitation.guardianId);
    const linkedUser = invitation.userId ? database.users.find((u) => u.id === invitation.userId) : undefined;

    // Resolve linked students with details
    const studentList: any[] = [];
    if (guardian) {
      const studentIdSet = new Set<string>(guardian.studentIds || []);
      database.studentProfiles.forEach((st) => {
        if (st.guardianId === guardian.id || st.secondaryGuardianId === guardian.id) {
          studentIdSet.add(st.id);
        }
      });
      database.parentStudentRelationships.forEach((rel) => {
        if (rel.guardianId === guardian.id) {
          studentIdSet.add(rel.studentId);
        }
      });

      for (const sid of Array.from(studentIdSet)) {
        const st = database.studentProfiles.find((s) => s.id === sid);
        if (st) {
          const cls = database.classes.find((c) => c.id === st.classId);
          const sec = database.sections.find((s) => s.id === st.sectionId);
          const rel = database.parentStudentRelationships.find(
            (r) => r.guardianId === guardian.id && r.studentId === sid
          );
          const stUser = database.users.find((u) => u.id === st.userId);
          const childName = stUser?.name || (st.firstName && st.lastName ? `${st.firstName} ${st.lastName}` : (st as any).name || 'Student Scholar');
          studentList.push({
            id: st.id,
            name: childName,
            admissionNumber: st.admissionNumber,
            rollNumber: st.rollNumber,
            className: cls?.name || 'Standard Curriculum',
            sectionName: sec?.name || 'Section A',
            relationshipType: rel?.relationshipType || guardian.relationship || 'Child',
            isPrimary: rel?.isPrimaryGuardian ?? (guardian.isPrimaryGuardian || false)
          });
        }
      }
    }

    const maskedPhone = guardian?.phone
      ? guardian.phone.replace(/(\+?\d{1,3})?[\s-]?\(?\d{3}\)?[\s-]?\d{3}[\s-]?(\d{4})/, '***-***-$1')
      : '';

    res.json({
      success: true,
      data: {
        valid: true,
        invitation,
        guardian: guardian || {
          id: invitation.guardianId,
          name: invitation.guardianName || 'Parent / Guardian',
          email: invitation.email,
          phone: maskedPhone
        },
        students: studentList,
        token: invitation.token,
        guardianId: invitation.guardianId,
        guardianName: guardian?.name || invitation.guardianName || 'Parent / Guardian',
        email: invitation.email,
        phone: maskedPhone,
        username: linkedUser?.username || guardian?.email.split('@')[0] || '',
        expiresAt: invitation.expiresAt
      },
      message: 'Invitation is valid.'
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: 'Failed to verify invitation.',
      code: 'SERVER_ERROR'
    });
  }
});

/**
 * POST /api/auth/invitation/activate
 * Public endpoint to activate a parent account by setting a secure password
 */
authRouter.post('/invitation/activate', (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { token, password, confirmPassword, username } = req.body;
    const clientIp = (req.ip || req.socket.remoteAddress || '127.0.0.1').toString();

    if (!token) {
      res.status(400).json({ success: false, error: 'Invitation token is required.' });
      return;
    }

    if (!password || !confirmPassword) {
      res.status(400).json({ success: false, error: 'Password and confirmation are required.' });
      return;
    }

    if (password !== confirmPassword) {
      res.status(400).json({ success: false, error: 'Passwords do not match.' });
      return;
    }

    // Complexity validation
    const strength = validatePasswordStrength(password);
    if (!strength.valid) {
      res.status(400).json({ success: false, error: strength.message });
      return;
    }

    // Verify invitation record
    const invitation = database.parentInvitations.find((inv) => inv.token === token.trim());
    if (!invitation || invitation.status !== 'pending') {
      res.status(400).json({
        success: false,
        error: 'Invalid or already processed invitation token.'
      });
      return;
    }

    if (new Date(invitation.expiresAt) < new Date()) {
      invitation.status = 'expired';
      res.status(410).json({
        success: false,
        error: 'This invitation token has expired. Please contact school administration for a new invitation.'
      });
      return;
    }

    // Resolve Guardian
    const guardian = database.guardians.find((g) => g.id === invitation.guardianId);
    if (!guardian) {
      res.status(404).json({
        success: false,
        error: 'Associated guardian profile could not be located.'
      });
      return;
    }

    // Hash the password securely
    const hashed = hashPassword(password);

    // Resolve or provision linked user
    let user = database.users.find(
      (u) => u.id === invitation.userId || u.id === guardian.userId || u.email.toLowerCase() === invitation.email.toLowerCase()
    );

    const chosenUsername = username?.trim() || user?.username || guardian.email.split('@')[0].toLowerCase().replace(/[^a-z0-9]/g, '');

    if (user) {
      user.passwordHash = hashed.hash;
      user.passwordSalt = hashed.salt;
      user.status = 'active';
      user.username = chosenUsername;
      user.updatedAt = new Date().toISOString();
      user.lastLoginAt = new Date().toISOString();
      guardian.userId = user.id;
    } else {
      const newUserId = `usr-guardian-${Date.now()}`;
      const newUser: StoredUser = {
        id: newUserId,
        name: guardian.name,
        email: guardian.email,
        username: chosenUsername,
        role: 'GUARDIAN',
        status: 'active',
        phoneNumber: guardian.phone,
        passwordHash: hashed.hash,
        passwordSalt: hashed.salt,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        lastLoginAt: new Date().toISOString()
      };
      database.users.push(newUser);
      user = newUser;
      guardian.userId = newUserId;
    }

    // Mark guardian as active
    guardian.status = 'active';
    guardian.updatedAt = new Date().toISOString();

    // Mark invitation accepted
    invitation.status = 'accepted';
    invitation.acceptedAt = new Date().toISOString();

    // Create immediate active session for frictionless onboard
    const { passwordHash: _, passwordSalt: __, ...cleanUser } = user;
    const session = createSession(cleanUser, { guardianProfile: guardian });

    logAudit({
      userId: user.id,
      userName: user.name,
      userRole: 'GUARDIAN',
      action: 'LOGIN',
      entity: 'USER',
      entityId: user.id,
      details: `Parent account successfully activated and password set via invitation for guardian ${guardian.name}.`,
      ipAddress: clientIp
    });

    res.json({
      success: true,
      message: 'Account successfully activated! Welcome to the Sygmate Parent Portal.',
      data: {
        session,
        redirectTo: '/guardian/dashboard'
      }
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: 'Failed to complete account activation.',
      code: 'SERVER_ERROR'
    });
  }
});

/**
 * POST /api/auth/forgot-password
 * Public endpoint to request a password reset link (anti-enumeration & rate-limited)
 */
authRouter.post('/forgot-password', (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { identifier } = req.body;
    const clientIp = (req.ip || req.socket.remoteAddress || '127.0.0.1').toString();

    if (!identifier || typeof identifier !== 'string') {
      res.status(400).json({
        success: false,
        error: 'Please enter your account email or username.'
      });
      return;
    }

    const trimmed = identifier.trim().toLowerCase();

    // Check rate limit
    const rate = checkResetRateLimit(trimmed, clientIp);
    if (rate.isLimited) {
      res.status(429).json({
        success: false,
        error: `Too many password reset requests. Please wait ${rate.remainingSeconds} seconds before requesting again.`,
        code: 'RATE_LIMITED'
      });
      return;
    }

    recordResetRequest(trimmed, clientIp);

    const user = database.users.find(
      (u) => u.email.toLowerCase() === trimmed || u.username.toLowerCase() === trimmed
    );

    let generatedToken: string | undefined;

    if (user && user.status === 'active') {
      // Invalidate existing pending tokens
      database.passwordResetTokens
        .filter((t) => t.userId === user.id && t.status === 'pending')
        .forEach((t) => {
          t.status = 'revoked';
        });

      // Generate 1-hour reset token
      const token = generateSecureToken(24);
      const resetRecord: PasswordResetToken = {
        id: `prt-${Date.now()}`,
        userId: user.id,
        email: user.email,
        token,
        status: 'pending',
        expiresAt: new Date(Date.now() + 60 * 60 * 1000).toISOString(),
        createdAt: new Date().toISOString()
      };

      database.passwordResetTokens.push(resetRecord);
      generatedToken = token;

      // Add in-app notification
      database.notifications.push({
        id: `notif-pwd-${Date.now()}`,
        userId: user.id,
        title: 'Password Reset Requested',
        message: 'A password reset request was initiated for your Sygmate account. If this was not you, please contact support immediately.',
        category: 'security',
        type: 'SECURITY_ALERT',
        isRead: false,
        createdAt: new Date().toISOString()
      });

      logAudit({
        userId: user.id,
        userName: user.name,
        userRole: user.role,
        action: 'UPDATE',
        entity: 'USER',
        entityId: user.id,
        details: `Password reset token generated for user ${user.email}.`,
        ipAddress: clientIp
      });
    }

    // Always return success to prevent username/email enumeration
    res.json({
      success: true,
      message: 'If an account matches that email or username, password reset instructions have been dispatched.',
      // Provided in development/sandbox environment for frictionless testing
      data: generatedToken ? { resetToken: generatedToken } : undefined
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: 'Failed to process password reset request.'
    });
  }
});

/**
 * POST /api/auth/reset-password
 * Public endpoint to submit new password with a valid reset token
 */
authRouter.post('/reset-password', (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { token, confirmPassword } = req.body;
    const newPassword = req.body.newPassword || req.body.password;
    const clientIp = (req.ip || req.socket.remoteAddress || '127.0.0.1').toString();

    if (!token) {
      res.status(400).json({ success: false, error: 'Password reset token is required.' });
      return;
    }

    if (!newPassword || !confirmPassword) {
      res.status(400).json({ success: false, error: 'Please enter and confirm your new password.' });
      return;
    }

    if (newPassword !== confirmPassword) {
      res.status(400).json({ success: false, error: 'Passwords do not match.' });
      return;
    }

    const strength = validatePasswordStrength(newPassword);
    if (!strength.valid) {
      res.status(400).json({ success: false, error: strength.message });
      return;
    }

    const resetToken = database.passwordResetTokens.find(
      (t) => t.token === token.trim() && t.status === 'pending'
    );

    if (!resetToken) {
      res.status(400).json({
        success: false,
        error: 'Invalid or expired password reset token.'
      });
      return;
    }

    if (new Date(resetToken.expiresAt) < new Date()) {
      resetToken.status = 'expired';
      res.status(410).json({
        success: false,
        error: 'This password reset token has expired. Please request a new reset link.'
      });
      return;
    }

    const user = database.users.find((u) => u.id === resetToken.userId);
    if (!user) {
      res.status(404).json({ success: false, error: 'User account not found.' });
      return;
    }

    // Update password
    const hashed = hashPassword(newPassword);
    user.passwordSalt = hashed.salt;
    user.passwordHash = hashed.hash;
    user.updatedAt = new Date().toISOString();

    if (user.status === 'locked') {
      user.status = 'active';
    }

    // Mark token as used
    resetToken.status = 'used';
    resetToken.usedAt = new Date().toISOString();

    // Invalidate all prior sessions across devices
    invalidateUserSessions(user.id);

    logAudit({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action: 'UPDATE',
      entity: 'USER',
      entityId: user.id,
      details: `Password reset successfully completed for user ${user.email}.`,
      ipAddress: clientIp
    });

    res.json({
      success: true,
      message: 'Your password has been successfully reset. You can now log in with your new credentials.'
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: 'Failed to reset password.'
    });
  }
});

/**
 * POST /api/auth/change-password
 * Authenticated endpoint for active user to change their password
 */
authRouter.post('/change-password', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { currentPassword, newPassword, confirmPassword } = req.body;
    const user = database.users.find((u) => u.id === req.user!.id);

    if (!user) {
      res.status(404).json({ success: false, error: 'User not found.' });
      return;
    }

    if (!currentPassword || !newPassword || !confirmPassword) {
      res.status(400).json({
        success: false,
        error: 'Current password, new password, and confirmation are required.'
      });
      return;
    }

    // Verify current password
    const isCurrentValid = verifyPassword(currentPassword, user.passwordHash, user.passwordSalt);
    if (!isCurrentValid) {
      logAudit({
        userId: user.id,
        userName: user.name,
        userRole: user.role,
        action: 'UNAUTHORIZED_ATTEMPT',
        entity: 'USER',
        entityId: user.id,
        details: 'Failed password change: current password incorrect.',
        ipAddress: req.ip
      });

      res.status(400).json({
        success: false,
        error: 'Current password is incorrect.'
      });
      return;
    }

    if (newPassword !== confirmPassword) {
      res.status(400).json({
        success: false,
        error: 'New password and confirmation do not match.'
      });
      return;
    }

    if (newPassword === currentPassword) {
      res.status(400).json({
        success: false,
        error: 'New password must be different from your current password.'
      });
      return;
    }

    const strength = validatePasswordStrength(newPassword);
    if (!strength.valid) {
      res.status(400).json({
        success: false,
        error: strength.message
      });
      return;
    }

    // Update password
    const hashed = hashPassword(newPassword);
    user.passwordSalt = hashed.salt;
    user.passwordHash = hashed.hash;
    user.updatedAt = new Date().toISOString();

    logAudit({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action: 'UPDATE',
      entity: 'USER',
      entityId: user.id,
      details: 'User successfully updated their password.',
      ipAddress: req.ip
    });

    res.json({
      success: true,
      message: 'Password updated successfully.'
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: 'Failed to update password.'
    });
  }
});

/**
 * GET /api/auth/demo-status
 * Checks if Quick Demo Personas are enabled for the current environment
 */
authRouter.get('/demo-status', (_req: AuthenticatedRequest, res: Response): void => {
  const isDemoEnabled = !(process.env.NODE_ENV === 'production' && process.env.ENABLE_DEMO_PERSONAS !== 'true');
  res.json({
    success: true,
    data: {
      isDemoEnabled
    }
  });
});

/**
 * POST /api/auth/switch-demo
 * Fast-switch between test accounts for architecture inspection
 */
authRouter.post('/switch-demo', (req: AuthenticatedRequest, res: Response): void => {
  try {
    // Quick Demo Personas are available strictly in development/demo environments
    if (process.env.NODE_ENV === 'production' && process.env.ENABLE_DEMO_PERSONAS !== 'true') {
      res.status(403).json({
        success: false,
        error: 'Quick demo personas are disabled in production environment.',
        code: 'DEMO_MODE_DISABLED'
      });
      return;
    }

    const { role } = req.body as { role: UserRole };
    if (!role || !['SUPER_ADMIN', 'ADMIN', 'TEACHER', 'STUDENT', 'GUARDIAN'].includes(role)) {
      res.status(400).json({
        success: false,
        error: 'Invalid demo role selected.',
        code: 'INVALID_ROLE'
      });
      return;
    }

    const storedUser = role === 'ADMIN'
      ? (database.users.find((u) => u.role === 'ADMIN' && u.schoolId === 'school-main' && u.status === 'active') ||
         database.users.find((u) => u.role === 'ADMIN' && u.status === 'active'))
      : database.users.find((u) => u.role === role && u.status === 'active');

    if (!storedUser) {
      res.status(404).json({
        success: false,
        error: `No active demo user found for role ${role}`,
        code: 'USER_NOT_FOUND'
      });
      return;
    }

    let teacherProfile;
    let studentProfile;
    let guardianProfile;

    if (storedUser.role === 'TEACHER') {
      teacherProfile = database.teacherProfiles.find((t) => t.userId === storedUser.id);
    } else if (storedUser.role === 'STUDENT') {
      studentProfile = database.studentProfiles.find((s) => s.userId === storedUser.id);
    } else if (storedUser.role === 'GUARDIAN') {
      guardianProfile = database.guardians.find(
        (g) => g.userId === storedUser.id || g.email.toLowerCase() === storedUser.email.toLowerCase()
      );
    }

    const { passwordHash, passwordSalt, ...cleanUser } = storedUser;
    cleanUser.lastLoginAt = new Date().toISOString();
    storedUser.lastLoginAt = cleanUser.lastLoginAt;

    // Multi-Tenant context resolution (Phase 1)
    const userMemberships = getUserMemberships(storedUser.id);
    const userSchools = getUserSchools(storedUser.id);
    const currentSchoolId = storedUser.schoolId || userMemberships[0]?.schoolId || 'school-main';
    const activeSchool = database.schools.find((s) => s.id === currentSchoolId) || database.schools[0];
    const schoolContext = activeSchool ? {
      id: activeSchool.id,
      name: activeSchool.name,
      code: activeSchool.code,
      plan: activeSchool.plan,
      status: activeSchool.status
    } : undefined;
    const availableSchools = userSchools.map((s) => ({
      id: s.id,
      name: s.name,
      code: s.code,
      role: storedUser.role
    }));

    cleanUser.memberships = userMemberships;
    cleanUser.schoolId = currentSchoolId;
    cleanUser.isPlatformAdmin = storedUser.role === 'SUPER_ADMIN';

    const session = createSession(cleanUser, {
      teacherProfile,
      studentProfile,
      guardianProfile,
      schoolContext,
      availableSchools
    });

    logAudit({
      userId: storedUser.id,
      userName: storedUser.name,
      userRole: storedUser.role,
      action: 'LOGIN',
      entity: 'SESSION',
      details: `Switched into ${storedUser.role} portal session.`,
      ipAddress: req.ip
    });

    res.json({
      success: true,
      data: {
        session,
        redirectTo: getDefaultRedirectForRole(storedUser.role)
      },
      message: `Switched to ${storedUser.name} (${storedUser.role})`
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Failed to switch demo account.'
    });
  }
});

/**
 * POST /api/auth/switch-school
 * Fast-switch active school context for multi-school users or platform super admin
 */
authRouter.post('/switch-school', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    const { schoolId } = req.body as { schoolId: string };
    if (!schoolId) {
      res.status(400).json({
        success: false,
        error: 'School ID is required.',
        code: 'MISSING_SCHOOL_ID'
      });
      return;
    }

    const user = req.user!;
    const isPlatformAdmin = user.role === 'SUPER_ADMIN';
    const hasMembership = database.schoolMemberships.some(
      (m) => m.userId === user.id && m.schoolId === schoolId && m.status === 'active'
    );

    if (!isPlatformAdmin && !hasMembership) {
      res.status(403).json({
        success: false,
        error: `Forbidden. You are not an authorized member of school '${schoolId}'.`,
        code: 'FORBIDDEN_TENANT_ACCESS'
      });
      return;
    }

    const school = database.schools.find((s) => s.id === schoolId);
    if (!school) {
      res.status(404).json({
        success: false,
        error: `School '${schoolId}' not found.`,
        code: 'SCHOOL_NOT_FOUND'
      });
      return;
    }

    // Update active school in database and in user object
    const storedUser = database.users.find((u) => u.id === user.id);
    if (storedUser) {
      storedUser.schoolId = schoolId;
    }
    user.schoolId = schoolId;

    if (req.session) {
      req.session.schoolContext = {
        id: school.id,
        name: school.name,
        code: school.code,
        plan: school.plan,
        status: school.status
      };
      req.session.user.schoolId = schoolId;
    }

    logAudit({
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      action: 'UPDATE',
      entity: 'TENANT',
      details: `Switched active school tenant to ${school.name} (${school.id}).`,
      ipAddress: req.ip
    });

    res.json({
      success: true,
      data: {
        schoolId,
        school,
        session: req.session
      },
      message: `Switched active school context to ${school.name}`
    });
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: 'Failed to switch school context.'
    });
  }
});

/**
 * GET /api/auth/me
 * Validate session token and retrieve current user context
 */
authRouter.get('/me', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  res.json({
    success: true,
    data: req.session
  });
});

/**
 * POST /api/auth/logout
 * Terminate active session
 */
authRouter.post('/logout', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  if (req.token) {
    destroySession(req.token);
  }

  if (req.user) {
    logAudit({
      userId: req.user.id,
      userName: req.user.name,
      userRole: req.user.role,
      action: 'LOGOUT',
      entity: 'SESSION',
      details: `User logged out successfully.`,
      ipAddress: req.ip
    });
  }

  res.json({
    success: true,
    message: 'Logged out successfully.'
  });
});
