import { Router, Response } from 'express';
import { requireAuth, requireRole, AuthenticatedRequest } from '../security/auth.js';
import { AttendanceNotificationService } from '../services/attendance-notifications.service.js';
import { logAudit } from '../security/audit.js';
import { database } from '../db/database.js';
import { UserRole } from '../../src/types/index.js';

export const attendanceNotificationsRouter = Router();

// Require valid authentication session for all notification administrative routes
attendanceNotificationsRouter.use(requireAuth);

// =========================================================================
// 1. GET ATTENDANCE NOTIFICATION SETTINGS (Super Admin)
// =========================================================================
attendanceNotificationsRouter.get('/settings', requireRole('SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const settings = AttendanceNotificationService.getSettings();
    res.json({
      success: true,
      data: settings
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// =========================================================================
// 2. UPDATE ATTENDANCE NOTIFICATION SETTINGS (Super Admin)
// =========================================================================
attendanceNotificationsRouter.put('/settings', requireRole('SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    const updates = req.body;

    if (!updates || typeof updates !== 'object') {
      res.status(400).json({ success: false, error: 'Valid settings object is required.' });
      return;
    }

    const updated = AttendanceNotificationService.updateSettings(updates, {
      id: user.id,
      name: user.name
    });

    logAudit({
      userId: user.id,
      userName: user.name,
      userRole: user.role as UserRole,
      action: 'UPDATE',
      entity: 'ATTENDANCE',
      entityType: 'ATTENDANCE',
      entityId: updated.id,
      details: `Updated attendance notification & alert settings (duplicates prevention: ${updated.preventDuplicates}, max retries: ${updated.maxRetries}).`,
      ipAddress: req.ip
    });

    res.json({
      success: true,
      message: 'Attendance notification settings saved successfully.',
      data: updated
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// =========================================================================
// 3. GET NOTIFICATION TEMPLATES (Super Admin)
// =========================================================================
attendanceNotificationsRouter.get('/templates', requireRole('SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const templates = AttendanceNotificationService.getTemplates();
    res.json({
      success: true,
      data: templates
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// =========================================================================
// 4. UPDATE NOTIFICATION TEMPLATE (Super Admin)
// =========================================================================
attendanceNotificationsRouter.put('/templates/:id', requireRole('SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    const { id } = req.params;
    const { titleTemplate, bodyTemplate } = req.body as { titleTemplate: string; bodyTemplate: string };

    if (!titleTemplate || !bodyTemplate) {
      res.status(400).json({
        success: false,
        error: 'Both titleTemplate and bodyTemplate are required.'
      });
      return;
    }

    const result = AttendanceNotificationService.updateTemplate(
      id,
      { titleTemplate, bodyTemplate },
      { id: user.id }
    );

    if (!result.success) {
      res.status(400).json({
        success: false,
        error: result.errors?.join(', ') || 'Failed to validate notification template.',
        errors: result.errors
      });
      return;
    }

    logAudit({
      userId: user.id,
      userName: user.name,
      userRole: user.role as UserRole,
      action: 'UPDATE',
      entity: 'ATTENDANCE',
      entityType: 'ATTENDANCE',
      entityId: id,
      details: `Updated attendance notification template '${result.template?.name}' (${result.template?.eventType}).`,
      ipAddress: req.ip
    });

    res.json({
      success: true,
      message: 'Notification template updated and validated successfully.',
      data: result.template
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// =========================================================================
// 5. RESET NOTIFICATION TEMPLATES TO DEFAULTS (Super Admin)
// =========================================================================
attendanceNotificationsRouter.post('/templates/reset', requireRole('SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    const fresh = AttendanceNotificationService.resetTemplates({ id: user.id });

    logAudit({
      userId: user.id,
      userName: user.name,
      userRole: user.role as UserRole,
      action: 'RESET',
      entity: 'ATTENDANCE',
      entityType: 'ATTENDANCE',
      entityId: 'att-templates-reset',
      details: `Reset all attendance notification templates to default system standards.`,
      ipAddress: req.ip
    });

    res.json({
      success: true,
      message: 'All notification templates have been reset to system defaults.',
      data: fresh
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// =========================================================================
// 6. GET NOTIFICATION HISTORY / LOGS WITH FILTERS (Super Admin)
// =========================================================================
attendanceNotificationsRouter.get('/history', requireRole('SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const {
      startDate,
      endDate,
      eventType,
      channel,
      status,
      studentId,
      teacherId,
      search,
      page,
      limit
    } = req.query as Record<string, string>;

    const result = AttendanceNotificationService.getHistory({
      startDate,
      endDate,
      eventType,
      channel,
      status,
      studentId,
      teacherId,
      search,
      page: page ? parseInt(page, 10) : 1,
      limit: limit ? parseInt(limit, 10) : 20
    });

    res.json({
      success: true,
      ...result
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// =========================================================================
// 7. GET NOTIFICATION ANALYTICS & STATS (Super Admin)
// =========================================================================
attendanceNotificationsRouter.get('/stats', requireRole('SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const stats = AttendanceNotificationService.getStats();
    res.json({
      success: true,
      data: stats
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// =========================================================================
// 8. RETRY FAILED NOTIFICATION (Super Admin)
// =========================================================================
attendanceNotificationsRouter.post('/retry/:id', requireRole('SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    const { id } = req.params;

    const result = AttendanceNotificationService.retryNotification(id, {
      id: user.id,
      name: user.name
    });

    if (!result.success) {
      res.status(400).json({ success: false, error: result.error });
      return;
    }

    res.json({
      success: true,
      message: 'Notification retry has been scheduled.',
      data: result.log
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// =========================================================================
// 9. CANCEL NOTIFICATION (Super Admin)
// =========================================================================
attendanceNotificationsRouter.post('/cancel/:id', requireRole('SUPER_ADMIN'), (req: AuthenticatedRequest, res: Response): void => {
  try {
    const user = req.user!;
    const { id } = req.params;

    const result = AttendanceNotificationService.cancelNotification(id, {
      id: user.id,
      name: user.name
    });

    if (!result.success) {
      res.status(400).json({ success: false, error: result.error });
      return;
    }

    res.json({
      success: true,
      message: 'Notification has been cancelled.',
      data: result.log
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// =========================================================================
// 10. TEST DISPATCH ALERT (Super Admin)
// =========================================================================
attendanceNotificationsRouter.post('/test-dispatch', requireRole('SUPER_ADMIN'), async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  try {
    const user = req.user!;
    const { eventType, studentId } = req.body as { eventType: any; studentId?: string };

    if (!eventType) {
      res.status(400).json({ success: false, error: 'eventType is required.' });
      return;
    }

    // Select target student or default to first student profile
    const targetStudent = studentId
      ? database.studentProfiles.find((s) => s.id === studentId || s.userId === studentId)
      : database.studentProfiles[0];

    const today = new Date().toISOString().split('T')[0];

    const dispatchResult = await AttendanceNotificationService.dispatchEvent({
      eventType,
      date: today,
      studentId: targetStudent?.id,
      newStatus: eventType === 'STUDENT_ABSENT' ? 'ABSENT' : eventType === 'STUDENT_LATE' ? 'LATE' : 'PRESENT',
      previousStatus: 'UNMARKED',
      reason: 'Automated test simulation initiated from Super Admin console',
      remarks: 'Simulated attendance trigger',
      actorUser: { id: user.id, name: user.name, role: user.role }
    });

    res.json({
      success: true,
      message: `Test alert dispatched (${dispatchResult.sentCount} sent, ${dispatchResult.queuedCount} queued/sandbox, ${dispatchResult.duplicateCount} duplicates suppressed).`,
      data: dispatchResult
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});
